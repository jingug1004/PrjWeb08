CREATE TRIGGER TRIGGERATCMITEMM_TEST
AFTER INSERT OR UPDATE OR DELETE
  ON CMITEMM
FOR EACH ROW
  DECLARE
    p_div        varchar2(20)    := ''; 
 BEGIN

    IF INSERTING THEN
       p_div := 'I';
    END IF;
    IF DELETING THEN
       p_div := 'D';
    END IF;
    IF UPDATING THEN
       p_div := 'U';
    END IF;

    --테스트용--
    xy_sample_11(p_div);
    
 END;
/
