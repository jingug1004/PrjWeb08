CREATE TRIGGER TRIGGERATWAREHOUSINGTESTSOP
AFTER INSERT OR UPDATE OR DELETE
  ON WAREHOUSINGTESTSOP
FOR EACH ROW
  DECLARE
    p_userid        varchar2(20)    := ''; 
    p_reasondiv     varchar2(5)     := ''; 
    p_reasontext    varchar2(50)    := ''; 
    p_idata         varchar(1)      := ''; 
    p_ddata         varchar(1)      := ''; 
    STR             VARCHAR2(4000)  := '';
    atcnt           INT := 0;
 BEGIN
        FOR REC IN(
               SELECT COUNT(*) D1
            FROM   ATINFO
        )
        LOOP
               atcnt := REC.D1;
        END LOOP;
       IF (atcnt <> 0) THEN
   FOR REC IN(
       SELECT USERID,
              REASONDIV,
              REASONTEXT
       FROM   ATINFO
   )
   LOOP
       p_userid := REC.USERID;
       p_reasondiv := REC.REASONDIV;
       p_reasontext := REC.REASONTEXT;
   END LOOP;
       ELSE
       FOR REC IN(
            SELECT SUBSTR(NVL(s.username || '(' || s.terminal || ')', 'unKnown'),1,20) D1,
                   'SQL' D2,
                   'IP_' || SYS_CONTEXT ('USERENV', 'IP_ADDRESS') || '/MAC_' D3
            FROM   v$session s, v$process p
            WHERE  s.paddr = p.addr
                   AND s.sid = (SELECT sid
                                FROM   v$mystat
                                WHERE  ROWNUM = 1)
       )
       LOOP
           p_userid := REC.D1;
           p_reasondiv := REC.D2;
           p_reasontext := REC.D3;
       END LOOP;
       END IF;


    --입력/수정/삭제 이벤트를 알기 위한 변수 선언
    IF INSERTING THEN
       p_idata := 'I';
    END IF;
    IF DELETING THEN
       p_ddata := 'D';
    END IF;
    IF UPDATING THEN
       p_idata := 'I';
       p_ddata := 'D';
    END IF;

   FOR REC IN(
        SELECT ':NEW.' || COLUMN_NAME || ',' D1
        FROM USER_TAB_COLUMNS
        WHERE TABLE_NAME = 'WAREHOUSINGTESTSOP'
        )
        LOOP
            STR := STR || REC.D1;
        END LOOP;

        STR := SUBSTR(STR, 1,LENGTH(STR)-1);
    --입력이벤트  
    IF(p_idata is not null and p_ddata is null)  THEN

      insert into  atWAREHOUSINGTESTSOP

      (select SYSDATE,p_idata,p_userid,p_reasondiv,p_reasontext,:NEW.WAREHOUSINGTESTDIV,:NEW.WAREHOUSINGTESTID,:NEW.WAREHOUSINGTESTSEQ,:NEW.WAREHOUSINGTESTCONTENTS,:NEW.WAREHOUSINGTESTRESULTDIV,:NEW.PLANTCODE FROM DUAL);

    --삭제이벤트

    ELSIF(p_idata is null and p_ddata is not null) THEN

      insert into  atWAREHOUSINGTESTSOP

      (select SYSDATE,p_ddata,p_userid,p_reasondiv,p_reasontext,:OLD.WAREHOUSINGTESTDIV,:OLD.WAREHOUSINGTESTID,:OLD.WAREHOUSINGTESTSEQ,:OLD.WAREHOUSINGTESTCONTENTS,:OLD.WAREHOUSINGTESTRESULTDIV,:OLD.PLANTCODE FROM DUAL);

    --수정이벤트  
    ELSIF(p_idata is not null and p_ddata is not null) THEN 

      insert into  atWAREHOUSINGTESTSOP

      (select SYSDATE,'U',p_userid,p_reasondiv,p_reasontext,:NEW.WAREHOUSINGTESTDIV,:NEW.WAREHOUSINGTESTID,:NEW.WAREHOUSINGTESTSEQ,:NEW.WAREHOUSINGTESTCONTENTS,:NEW.WAREHOUSINGTESTRESULTDIV,:NEW.PLANTCODE FROM DUAL);

    END IF;
 END;
/
