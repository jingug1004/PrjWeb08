CREATE PACKAGE        LOGINACCESS_PKG AS 

TYPE T_CURSOR IS REF CURSOR;
 
PROCEDURE SPLOGINACCESS ( 
    p_div                  IN VARCHAR2  := '',
    p_startdate            IN VARCHAR2  := '',
    p_enddate              IN VARCHAR2  := '',
    p_empcode              IN VARCHAR2  := '',
    p_locationno           IN VARCHAR2  := '',
    p_programcode          IN VARCHAR2  := '',
    p_loginid              IN INT       := 0,
    p_programaccessid      IN INT       := 0,
    p_logindt              IN DATE      := NULL,
    p_logoutdt             IN DATE      := NULL,
    p_errordiv             IN VARCHAR2  := '',

    p_userid               IN VARCHAR2  := '',
    p_reasondiv            IN VARCHAR2  := '',
    p_reasontext           IN VARCHAR2  := '',
        
    message                IN OUT VARCHAR2,
    IO_CURSOR              IN OUT T_CURSOR,    
    IO_CURSOR2             IN OUT T_CURSOR    
);    

END LOGINACCESS_PKG;
/
