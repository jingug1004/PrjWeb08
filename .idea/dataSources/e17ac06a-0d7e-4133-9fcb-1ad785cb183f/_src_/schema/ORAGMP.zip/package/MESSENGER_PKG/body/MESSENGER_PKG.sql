CREATE PACKAGE BODY        MESSENGER_PKG
AS
	PROCEDURE SPMESSENGER(
		p_div			IN	   VARCHAR2 := NULL,
		p_plantcode 	IN	   VARCHAR2 := NULL,
		p_empcode		IN	   VARCHAR2 := NULL,
		p_nickname		IN	   VARCHAR2 := NULL,
		p_ip			IN	   VARCHAR2 := NULL,
		p_loginstat 	IN	   VARCHAR2 := NULL,
		p_userid		IN	   VARCHAR2 := NULL,
		p_reasondiv 	IN	   VARCHAR2 := NULL,
		p_reasontext	IN	   VARCHAR2 := NULL,
		MESSAGE 		IN OUT VARCHAR2,
		IO_CURSOR		IN OUT TYPES.DataSet
	)
	IS
		v_nickname	  VARCHAR2(50);
	BEGIN
		DBMS_OUTPUT.PUT_LINE('===== spGetCommon PROCEDURE START =====');
		MESSAGE := '데이터 확인';

		IF (p_div = 'S') THEN
        
			OPEN IO_CURSOR FOR
            
				SELECT DISTINCT TO_CHAR(NVL(b.predeptname, '') || ' ' || NVL(deptname, '')) AS ParentID,
								A.empcode AS ID,
								A.nickname AS nickname,
								A.ip,
								NVL(loginstat, 'X') AS loginstat,
								'P' AS mdiv,
								CASE WHEN A.empcode = p_empcode THEN 'Y' END AS isme
				FROM   SYSMESSENGER A LEFT JOIN vnEMP b ON A.empcode = b.empcode
				WHERE  NVL(loginstat, 'X') = 'O'
				UNION ALL
				SELECT DISTINCT '' AS ParentID,
								TO_CHAR(NVL(b.predeptname, '') || ' ' || NVL(b.deptname, '')) AS ID,
								TO_CHAR(NVL(b.predeptname, '') || ' ' || NVL(b.deptname, '')) AS nickname,
								'' AS ip,
								'' AS loginstat,
								'M' AS mdiv,
								'' AS isme
				FROM   SYSMESSENGER A LEFT JOIN vnEMP b ON A.empcode = b.empcode
				WHERE  NVL(loginstat, 'X') = 'O'
				ORDER BY ID;
                
		ELSIF (p_div = 'S2') THEN
        
			OPEN IO_CURSOR FOR
            
				SELECT empcode,
					   nickname,
					   ip
				FROM   SYSMESSENGER
				WHERE  NVL(loginstat, 'X') = 'O'
					   AND empcode = p_empcode
				UNION ALL
				SELECT empcode,
					   nickname,
					   ip
				FROM   SYSMESSENGER
				WHERE  NVL(loginstat, 'X') = 'O'
					   AND empcode = p_userid;
                       
		ELSIF (p_div = 'S3') THEN
        
			OPEN IO_CURSOR FOR
            
				SELECT empcode,
					   nickname,
					   ip
				FROM   SYSMESSENGER
				WHERE  empcode = p_empcode
				
                UNION ALL
                
				SELECT empcode,
					   nickname,
					   ip
				FROM   SYSMESSENGER
				WHERE  empcode = p_userid;
                
		ELSIF (p_div = 'IO') THEN
        
			-- 메신져 테이블 정리
			DELETE FROM SYSMESSENGER
			WHERE		TO_CHAR(logdt, 'YYYY-MM-DD') <> TO_CHAR(SYSDATE, 'YYYY-MM-DD')
						AND loginstat = 'O';

			SELECT empname
			INTO   v_nickname
			FROM   CMEMPM A
			WHERE  empcode = p_empcode;

			UPDATE SYSMESSENGER
			SET    ip = p_ip, nickname = v_nickname, loginstat = 'O', logdt = SYSDATE
			WHERE  empcode = p_empcode;

			IF (SQL%ROWCOUNT = 0)
			THEN
				INSERT INTO SYSMESSENGER(empcode, nickname, ip, loginstat, logdt)
					SELECT p_empcode,
						   v_nickname,
						   p_ip,
						   'O',
						   SYSDATE
					FROM   DUAL;
			END IF;
            
		ELSIF (p_div = 'IX') THEN
        
			UPDATE SYSMESSENGER
			SET    loginstat = 'X'
                   , logdt = SYSDATE
			WHERE  empcode = p_empcode;
            
		END IF;

		IF (IO_CURSOR IS NULL) THEN
			OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
		END IF;

		DBMS_OUTPUT.PUT_LINE('===== spGetCommon PROCEDURE END =====');
	END SPMESSENGER;
    
END MESSENGER_PKG;
/
