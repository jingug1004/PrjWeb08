CREATE PACKAGE BODY        MENULISTLOAD_PKG
AS
   PROCEDURE SPMENULISTLOAD (p_div          IN     VARCHAR2 := NULL,
                             p_empcode      IN     VARCHAR2 := NULL,
                             p_parentmenu   IN     VARCHAR2 := NULL,
                             p_plantcode    IN     VARCHAR2 := NULL,
                             p_deptcode     IN     VARCHAR2 := NULL,
                             p_userid       IN     VARCHAR2 := NULL,
                             p_reasondiv    IN     VARCHAR2 := NULL,
                             p_reasontext   IN     VARCHAR2 := NULL,
                             MESSAGE        IN OUT VARCHAR2,
                             IO_CURSOR      IN OUT T_CURSOR)
   IS
      V_CURSOR   T_CURSOR;
   BEGIN
      DBMS_OUTPUT.PUT_LINE ('===== spGetCommon PROCEDURE START =====');
      MESSAGE := '데이터베이스 성공';

      IF (p_div = 'S1')
      THEN
         OPEN V_CURSOR FOR
              SELECT DISTINCT a.menucode, a.menuname, a.menuseq
                FROM MENU a
                     INNER JOIN
                     (SELECT a.parentmenu
                        FROM MENU a
                             INNER JOIN
                             (SELECT b.menucode
                                FROM (SELECT programcode
                                        FROM USERACCESSAUTHORITY
                                       WHERE     empcode = p_empcode
                                             AND (   searchck = 'Y'
                                                  OR insertck = 'Y'
                                                  OR modifyck = 'Y'
                                                  OR deleteck = 'Y'
                                                  OR printck = 'Y'
                                                  OR convertck = 'Y')) a
                                     INNER JOIN MENUPROGRAMMANAGE b
                                        ON a.programcode = b.programcode) b
                                ON a.menucode = b.menucode) b
                        ON a.menucode = b.parentmenu
               WHERE a.menulevel = '2'
            ORDER BY a.menuseq;
      ELSIF (p_div = 'S2')
      THEN
         OPEN V_CURSOR FOR
              SELECT DISTINCT a.menucode,
                              a.menuname,
                              a.parentmenu,
                              a.menuseq
                FROM MENU a
                     INNER JOIN
                     (SELECT b.menucode
                        FROM (SELECT programcode
                                FROM USERACCESSAUTHORITY
                               WHERE     empcode = p_empcode
                                     AND (   searchck = 'Y'
                                          OR insertck = 'Y'
                                          OR modifyck = 'Y'
                                          OR deleteck = 'Y'
                                          OR printck = 'Y'
                                          OR convertck = 'Y')) a
                             INNER JOIN MENUPROGRAMMANAGE b
                                ON a.programcode = b.programcode) b
                        ON a.menucode = b.menucode
               --and a.parentmenu = @parentmenu

               WHERE a.menulevel = '3'
            ORDER BY a.menuseq;
      ELSIF (p_div = 'S3')
      THEN
         OPEN V_CURSOR FOR
              SELECT a.programcode, c.programname, b.menucode
                FROM (SELECT programcode
                        FROM USERACCESSAUTHORITY
                       WHERE     empcode = p_empcode
                             AND (   searchck = 'Y'
                                  OR insertck = 'Y'
                                  OR modifyck = 'Y'
                                  OR deleteck = 'Y'
                                  OR printck = 'Y'
                                  OR convertck = 'Y')) a
                     INNER JOIN MENUPROGRAMMANAGE b
                        ON a.programcode = b.programcode
                     INNER JOIN PROGRAMMANAGE c
                        ON a.programcode = c.programcode
               WHERE b.menucode = p_parentmenu
            ORDER BY b.programseq;
      ELSIF (p_div = 'S4')
      THEN
         OPEN V_CURSOR FOR
            SELECT DISTINCT a.programcode, c.dllpath, c.programname
              FROM (SELECT programcode
                      FROM USERACCESSAUTHORITY
                     WHERE     empcode = p_empcode
                           AND (   searchck = 'Y'
                                OR insertck = 'Y'
                                OR modifyck = 'Y'
                                OR deleteck = 'Y'
                                OR printck = 'Y'
                                OR convertck = 'Y')) a
                   INNER JOIN PROGRAMMANAGE c
                      ON a.programcode = c.programcode;
      ELSIF (p_div = 'NL')
      THEN                                                          --새로운메뉴리스트
         OPEN V_CURSOR FOR
              SELECT DISTINCT a.menucode, a.menuname, a.menuseq
                FROM MENU a
                     JOIN
                     (SELECT DISTINCT
                             a.menucode,
                             CASE
                                WHEN a.menulevel = 2 THEN a.menucode
                                ELSE a.parentmenu
                             END
                                parentmenu
                        FROM MENU a
                             JOIN
                             (SELECT DISTINCT
                                     a.menucode,
                                     CASE
                                        WHEN a.menulevel = 2 THEN a.menucode
                                        ELSE a.parentmenu
                                     END
                                        parentmenu
                                FROM MENU a
                                     JOIN
                                     (SELECT DISTINCT a.menucode
                                        FROM MENUPROGRAMMANAGE a
                                             JOIN
                                             (SELECT programcode
                                                FROM USERACCESSAUTHORITY
                                               WHERE     empcode = p_empcode
                                                     AND (   NVL (searchck, '') =
                                                                'Y'
                                                          OR NVL (insertck, '') =
                                                                'Y'
                                                          OR NVL (modifyck, '') =
                                                                'Y'
                                                          OR NVL (deleteck, '') =
                                                                'Y'
                                                          OR NVL (printck, '') =
                                                                'Y'
                                                          OR NVL (convertck,
                                                                  '') = 'Y')) b
                                                ON a.programcode =
                                                      b.programcode
                                             JOIN
                                             PROGRAMMANAGE c
                                                ON a.programcode =
                                                      c.programcode) b
                                        ON a.menucode = b.menucode) b
                                ON a.menucode = b.parentmenu) b
                        ON a.menucode = b.parentmenu
               WHERE a.menulevel = '2'
            ORDER BY a.menuseq;
      ELSIF (p_div = 'NL1')
      THEN                                                      --새로운메뉴리스트(서브)
         OPEN V_CURSOR FOR
            WITH tempo
                 AS (SELECT a.menucode AS menucodesearch,
                            a.programcode AS programcodesearch
                       FROM MENUPROGRAMMANAGE a
                            LEFT OUTER JOIN MENU b ON a.menucode = b.menucode
                            LEFT OUTER JOIN MENU c
                               ON b.parentmenu = c.menucode
                     UNION ALL
                     SELECT DISTINCT
                            CASE
                               WHEN b.menulevel = '3' THEN b.menucode
                               ELSE b.parentmenu
                            END,
                            a.programcode
                       FROM MENUPROGRAMMANAGE a
                            LEFT OUTER JOIN MENU b ON a.menucode = b.menucode
                            LEFT OUTER JOIN MENU c
                               ON b.parentmenu = c.menucode),
                 tempx
                 AS (SELECT DISTINCT a.menucode AS ID,
                                     a.parentmenu AS Pid,
                                     a.menuname AS nm,
                                     a.menulevel AS lvl,
                                     a.menuseq AS seq,
                                     'M' AS mdiv             --메뉴는 M / 프로그램은 P
                                                ,
                                     '0' AS ImageIndex,
                                     '' AS dllpath
                       FROM MENU a
                            JOIN
                            (SELECT DISTINCT a.menucodesearch AS menucode
                               FROM tempo a
                                    JOIN
                                    (  SELECT programcode
                                         FROM USERACCESSAUTHORITY
                                        WHERE     empcode = p_empcode
                                              AND (   NVL (searchck, '') = 'Y'
                                                   OR NVL (insertck, '') = 'Y'
                                                   OR NVL (modifyck, '') = 'Y'
                                                   OR NVL (deleteck, '') = 'Y'
                                                   OR NVL (printck, '') = 'Y'
                                                   OR NVL (convertck, '') = 'Y')
                                     GROUP BY programcode) b
                                       ON a.programcodesearch = b.programcode
                                    LEFT OUTER JOIN PROGRAMMANAGE c
                                       ON a.programcodesearch = c.programcode) b
                               ON a.menucode = b.menucode
                            LEFT OUTER JOIN MENU c
                               ON c.menucode = a.parentmenu               --추가
                      WHERE     (b.menucode IS NOT NULL OR a.menulevel > 2) --<>3)
                            AND (CASE
                                    WHEN a.menulevel = '4' THEN c.parentmenu
                                    ELSE a.parentmenu
                                 END) = p_parentmenu),
                 tempx1
                 AS (SELECT a.programcode AS ID,
                            a.menucode AS Pid,
                            c.programname AS nm,
                            4 AS lvl,
                            programseq AS seq,
                            'P' AS mdiv                      --메뉴는 M / 프로그램은 P
                                       ,
                            '1' AS ImageIndex,
                            c.dllpath AS dllpath
                       FROM MENUPROGRAMMANAGE a
                            JOIN
                            (  SELECT programcode
                                 FROM USERACCESSAUTHORITY
                                WHERE     empcode = p_empcode
                                      AND (   NVL (searchck, '') = 'Y'
                                           OR NVL (insertck, '') = 'Y'
                                           OR NVL (modifyck, '') = 'Y'
                                           OR NVL (deleteck, '') = 'Y'
                                           OR NVL (printck, '') = 'Y'
                                           OR NVL (convertck, '') = 'Y')
                             GROUP BY programcode) b
                               ON a.programcode = b.programcode
                            LEFT OUTER JOIN PROGRAMMANAGE c
                               ON a.programcode = c.programcode
                            JOIN tempx d ON a.menucode = d.ID)
            SELECT ID AS ID,
                   Pid AS ParentID,
                   nm,
                   lvl,
                   seq,
                   mdiv,
                   ImageIndex,
                   ID AS programcode,
                   dllpath
              FROM tempx
            UNION ALL
            SELECT ID AS ID,
                   Pid AS ParentID,
                   nm,
                   lvl,
                   seq,
                   mdiv,
                   ImageIndex,
                   ID AS programcode,
                   dllpath
              FROM tempx1
            ORDER BY lvl, seq, mdiv;
      --  즐겨찾기메뉴
      ELSIF (p_div = 'FA')
      THEN
         OPEN V_CURSOR FOR
            SELECT keyfield AS ID,
                   parentmenu AS ParentID,
                   menudiv,
                   menucode,
                   parentmenu,
                   menuname,
                   menulevel,
                   menuseq
              FROM MENUF
             WHERE plantcode = p_plantcode AND empcode = p_empcode
            UNION ALL
            SELECT a.menucode || a.programcode AS ID,
                   a.menucode AS ParentID,
                   a.menudiv,
                   a.programcode,
                   a.menucode,
                   b.programname,
                   a.menulevel,
                   a.programseq
              FROM MENUPROGRAMF a
                   JOIN PROGRAMMANAGE b ON a.programcode = b.programcode
             WHERE a.plantcode = p_plantcode AND a.empcode = p_empcode
            --and menulevel = 1

            ORDER BY menulevel, menuseq;
      --  새로운메뉴리스트(서브)
      ELSIF (p_div = 'NLA')
      THEN
         OPEN V_CURSOR FOR
            WITH Menu4
                 AS (SELECT DISTINCT c.*
                       FROM USERACCESSAUTHORITY a
                            JOIN MENUPROGRAMMANAGE b
                               ON a.programcode = b.programcode
                            JOIN MENU c ON b.menucode = c.menucode
                      WHERE     c.menulevel IN (2, 3, 4)
                            AND a.empcode = p_empcode
                            AND (   NVL (searchck, '') = 'Y'
                                 OR NVL (insertck, '') = 'Y'
                                 OR NVL (modifyck, '') = 'Y'
                                 OR NVL (deleteck, '') = 'Y'
                                 OR NVL (printck, '') = 'Y'
                                 OR NVL (convertck, '') = 'Y')),
                 Menu3
                 AS (SELECT DISTINCT a.*
                       FROM MENU a JOIN Menu4 b ON a.menucode = b.parentmenu
                      WHERE a.menulevel = '3'),
                 Menu2
                 AS (SELECT DISTINCT a.*
                       FROM MENU a
                            LEFT JOIN Menu3 b ON a.menucode = b.parentmenu
                            LEFT JOIN Menu4 c ON a.menucode = c.parentmenu
                      WHERE     a.menulevel = '2'
                            AND (b.parentmenu <> ' ' OR c.parentmenu <> ' '))
            SELECT menucode AS ID,
                   'TPMs' AS ParentID,
                   menuname AS nm,
                   menulevel AS lvl,
                   menuseq AS seq,
                   'M' AS mdiv,
                   0 AS ImageIndex,
                   menucode AS programcode,
                   '' AS dllpath
              FROM menu2
            UNION
            SELECT menucode AS ID,
                   parentmenu AS ParentID,
                   menuname AS nm,
                   menulevel AS lvl,
                   menuseq AS seq,
                   'M' AS mdiv,
                   1 AS ImageIndex,
                   menucode AS programcode,
                   '' AS dllpath
              FROM menu3
            UNION
            SELECT menucode AS ID,
                   parentmenu AS ParentID,
                   menuname AS nm,
                   menulevel AS lvl,
                   menuseq AS seq,
                   'M' AS mdiv,
                   2 AS ImageIndex,
                   menucode AS programcode,
                   '' AS dllpath
              FROM menu4
            UNION
            SELECT a.programcode AS ID,
                   a.menucode AS ParentID,
                   b.programname AS nm,
                   5 AS lvl,
                   a.programseq AS seq,
                   'P' AS mdiv,
                   3 AS ImageIndex,
                   a.programcode AS programcode,
                   b.dllpath AS dllpath
              FROM MENUPROGRAMMANAGE a
                   JOIN PROGRAMMANAGE b ON a.programcode = b.programcode
                   JOIN
                   USERACCESSAUTHORITY c
                      ON     b.programcode = c.programcode
                         AND c.empcode = p_empcode
                         AND (   NVL (searchck, '') = 'Y'
                              OR NVL (insertck, '') = 'Y'
                              OR NVL (modifyck, '') = 'Y'
                              OR NVL (deleteck, '') = 'Y'
                              OR NVL (printck, '') = 'Y'
                              OR NVL (convertck, '') = 'Y')
            ORDER BY lvl, seq, mdiv;
      --  즐겨찾기메뉴
      ELSIF (p_div = 'FA1')
      THEN
         OPEN V_CURSOR FOR
              SELECT menucode AS ID,
                     parentmenu AS ParentID,
                     menudiv,
                     menucode,
                     parentmenu,
                     menuname,
                     menulevel,
                     menuseq
                FROM MENUF
               WHERE plantcode = p_plantcode AND empcode = p_empcode
            ORDER BY menulevel, menuseq;
      --  즐겨찾기메뉴
      ELSIF (p_div = 'FA2')
      THEN
         OPEN V_CURSOR FOR
              SELECT a.programcode + a.menucode AS ID,
                     a.menucode AS ParentID,
                     a.menudiv,
                     a.programcode,
                     a.menucode,
                     b.programname,
                     a.menulevel,
                     a.programseq,
                     b.dllpath
                FROM MENUPROGRAMF a
                     JOIN PROGRAMMANAGE b ON a.programcode = b.programcode
               WHERE plantcode = p_plantcode AND empcode = p_empcode --and     menulevel = 1
                     AND a.menucode = p_parentmenu
            ORDER BY menulevel, programseq;
      END IF;

      IF (V_CURSOR IS NULL)
      THEN
         OPEN V_CURSOR FOR SELECT 1 FROM DUAL;
      END IF;

      IO_CURSOR := V_CURSOR;

      DBMS_OUTPUT.PUT_LINE ('===== spGetCommon PROCEDURE END =====');
   END SPMENULISTLOAD;
END MENULISTLOAD_PKG;
/
