CREATE PACKAGE        ELECTRONICSIGNHISTORY_PKG
AS
	TYPE T_CURSOR IS REF CURSOR;

	PROCEDURE SPELECTRONICSIGNHISTORY(
		p_div			   IN	  VARCHAR2 := NULL,
		p_programcode	   IN	  VARCHAR2 := NULL,
		p_keys			   IN	  VARCHAR2 := NULL,
		p_signseq				  NUMBER := NULL,
		p_signlevel 			  NUMBER := NULL,
		p_workseq				  NUMBER := NULL,
		p_status		   IN	  VARCHAR2 := NULL,
		p_statuswhere	   IN	  VARCHAR2 := NULL,
		p_signreasondiv    IN	  VARCHAR2 := NULL,
		p_signempcode	   IN	  VARCHAR2 := NULL,
		p_signtext		   IN	  VARCHAR2 := NULL,
		p_empcode		   IN	  VARCHAR2 := NULL,
		p_agent 		   IN	  VARCHAR2 := NULL,
		p_revisionno			  NUMBER := NULL,
		p_actiondiv 	   IN	  VARCHAR2 := NULL,
		p_pwd			   IN	  VARCHAR2 := NULL,
		p_signtype		   IN	  VARCHAR2 := NULL,
		p_deptcode		   IN	  VARCHAR2 := NULL,
		p_plantcode 	   IN	  VARCHAR2 := NULL,
		p_userid		   IN	  VARCHAR2 := NULL,
		p_reasondiv 	   IN	  VARCHAR2 := NULL,
		p_reasontext	   IN	  VARCHAR2 := NULL,
		MESSAGE 		   IN OUT VARCHAR2,
		IO_CURSOR		   IN OUT T_CURSOR
	);
END ELECTRONICSIGNHISTORY_PKG;
/
