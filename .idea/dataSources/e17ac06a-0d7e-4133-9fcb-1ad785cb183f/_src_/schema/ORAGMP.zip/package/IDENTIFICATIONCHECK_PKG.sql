CREATE PACKAGE        IDENTIFICATIONCHECK_PKG AS 

    --TYPE T_CURSOR IS REF CURSOR; 
PROCEDURE SPIDENTIFICATIONCHECK (                            
    p_div             IN varchar2 := '',
    p_id              IN varchar2 := '',
    p_pwd             IN varchar2 := '',
    p_signtype        IN varchar2 := '',
    p_failed          IN NUMBER   := 0,
    p_programcode     IN varchar2 := '',
    p_empcode         IN varchar2 := '',
    p_empname         IN varchar2 := '',
    p_personid        IN varchar2 := '',

    p_userid          IN varchar2 := '',
    p_reasondiv       IN varchar2 := '',
    p_reasontext      IN varchar2 := '',

    message           IN OUT varchar2,
    IO_CURSOR         IN OUT TYPES.DATASET
    
);                         
             
END IDENTIFICATIONCHECK_PKG;
/
