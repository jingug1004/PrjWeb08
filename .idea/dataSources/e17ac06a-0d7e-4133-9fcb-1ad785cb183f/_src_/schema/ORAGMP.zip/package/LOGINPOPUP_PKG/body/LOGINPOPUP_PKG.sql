CREATE PACKAGE BODY        LOGINPOPUP_PKG
AS
	PROCEDURE SPLOGINPOPUP(
		p_div			IN	   VARCHAR2 := '',
		p_plantcode 	IN	   VARCHAR2 := '',
		p_empcode		IN	   VARCHAR2 := '',
		p_deptcode		IN	   VARCHAR2 := '',
		p_userid		IN	   VARCHAR2 := '',
		p_reasondiv 	IN	   VARCHAR2 := '',
		p_reasontext	IN	   VARCHAR2 := '',
		MESSAGE 		   OUT VARCHAR2,
		IO_CURSOR		   OUT TYPES.DataSet
	)
	IS
		p_notecnt		 VARCHAR2(5);
		p_msg			 VARCHAR2(1000);
		p_limssigner1	 VARCHAR2(20);
		p_limssigner2	 VARCHAR2(20);
	BEGIN
		MESSAGE := '데이터베이스 성공';

		IF (p_div = 'MSG')
		THEN -- << 구분자 절대 변경금지 >>
			--------------프로그램 시작시 쪽지함을 확인한다---------------- 없을경우 insert 가 되지않는다.
			FOR REC IN (SELECT COUNT(seq) seq
						FROM   SYSMESSENGERMSGBOX
						WHERE  recv = p_empcode
							   AND readyn = 'N')
			LOOP
				p_notecnt := REC.seq;
			END LOOP;

			OPEN IO_CURSOR FOR
				SELECT	 'cmfMessengerMsgBox' programcode,
						 '읽지않은 쪽지가 있습니다 (' || p_notecnt || ')' title,
						 empname || ' / ' || TO_CHAR(senddt, 'YYYY-MM-DD HH24:MI:SS') || CHR(10) || '내용 : ' || msg msg
				FROM	 SYSMESSENGERMSGBOX LEFT OUTER JOIN CMEMPM ON sender = empcode
				WHERE	 recv = p_empcode
						 AND readyn = 'N'
						 AND ROWNUM = 1
				ORDER BY seq DESC;

		ELSIF (p_div = 'S')
		THEN
			FOR REC IN (SELECT value1,
							   value2
						FROM   SYSPARAMETERMANAGE
						WHERE  parametercode = 'LimsSigner')
			LOOP
				p_limssigner1 := REC.value1;
				p_limssigner2 := REC.value2;
				p_msg := NULL;
			END LOOP;


			FOR REC IN (SELECT COUNT(seq) seq
						FROM   SYSMESSENGERMSGBOX
						WHERE  recv = p_empcode
							   AND readyn = 'N')
			LOOP
				p_notecnt := REC.seq;
			END LOOP;

			EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_SPLOGINPOPUP_MASTERBASE';

			INSERT INTO VGT.TT_SPLOGINPOPUP_MASTERBASE
				SELECT	 'cmfMessengerMsgBox' programcode,
						 '읽지않은 쪽지가 있습니다 (' || p_notecnt || ')' title,
						 empname || ' / ' || TO_CHAR(senddt, 'YYYY-MM-DD HH24:MI:SS') || CHR(10) || '내용 : ' || msg msg
				FROM	 SYSMESSENGERMSGBOX LEFT OUTER JOIN CMEMPM ON sender = empcode
				WHERE	 recv = p_empcode
						 AND readyn = 'N'
						 AND ROWNUM = 1
				ORDER BY seq DESC;

			IF (p_empcode IN ('iisys', 'iisys2', 'iisys3', 'gmpit'))
			THEN --관리자, 운영자
				INSERT INTO VGT.TT_SPLOGINPOPUP_MASTERBASE
					SELECT	 'stmErrorResearch' programcode,
								'시스템보고정보 ('
							 || (SELECT TO_CHAR(COUNT(id))
								 FROM	SYSERRORRESEARCH
								 WHERE	NVL(remark, ' ') = ' ')
							 || ')'
								 title,
							 b.empname || ' / ' || TO_CHAR(a.errordt, 'YYYY-MM-DD HH24:MI:SS') || ' / ' || source || CHR(10) || a.errormessage
					FROM	 SYSERRORRESEARCH a LEFT OUTER JOIN CMEMPM b ON a.empcode = b.empcode
					WHERE	 NVL(remark, ' ') = ' '
							 AND ROWNUM = 1
					ORDER BY a.id DESC;
			END IF;
		END IF;

		IF (IO_CURSOR IS NULL)
		THEN
			OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
		END IF;
	END SPLOGINPOPUP;
END LOGINPOPUP_PKG;
/
