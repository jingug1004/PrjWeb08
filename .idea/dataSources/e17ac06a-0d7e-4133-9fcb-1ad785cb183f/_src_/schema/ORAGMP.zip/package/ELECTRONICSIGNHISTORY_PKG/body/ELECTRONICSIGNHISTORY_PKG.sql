CREATE PACKAGE BODY        ELECTRONICSIGNHISTORY_PKG
AS
	PROCEDURE SPELECTRONICSIGNHISTORY(
		p_div			   IN	  VARCHAR2 := NULL,
		p_programcode	   IN	  VARCHAR2 := NULL,
		p_keys			   IN	  VARCHAR2 := NULL,
		p_signseq				  NUMBER := NULL,
		p_signlevel 			  NUMBER := NULL,
		p_workseq				  NUMBER := NULL,
		p_status		   IN	  VARCHAR2 := NULL,
		p_statuswhere	   IN	  VARCHAR2 := NULL,
		p_signreasondiv    IN	  VARCHAR2 := NULL,
		p_signempcode	   IN	  VARCHAR2 := NULL,
		p_signtext		   IN	  VARCHAR2 := NULL,
		p_empcode		   IN	  VARCHAR2 := NULL,
		p_agent 		   IN	  VARCHAR2 := NULL,
		p_revisionno			  NUMBER := NULL,
		p_actiondiv 	   IN	  VARCHAR2 := NULL,
		p_pwd			   IN	  VARCHAR2 := NULL,
		p_signtype		   IN	  VARCHAR2 := NULL,
		p_deptcode		   IN	  VARCHAR2 := NULL,
		p_plantcode 	   IN	  VARCHAR2 := NULL,
		p_userid		   IN	  VARCHAR2 := NULL,
		p_reasondiv 	   IN	  VARCHAR2 := NULL,
		p_reasontext	   IN	  VARCHAR2 := NULL,
		MESSAGE 		   IN OUT VARCHAR2,
		IO_CURSOR		   IN OUT T_CURSOR
	)
	IS
		V_CURSOR		 T_CURSOR;

		v_check 		 INT;
		v_signempcode	 VARCHAR2(100);
	BEGIN
		DBMS_OUTPUT.PUT_LINE('===== spGetCommon PROCEDURE START =====');
		MESSAGE := '데이터 확인';

		-- 서명정보 조회
		IF (p_div = 'S1')
		THEN
			-- 서명체계 검색 -> 이력정보를 반영하기 위해서 사용유무에 상관없이

			SELECT COUNT(programcode)
			INTO   v_check
			FROM   ElectronicSignMaster
			WHERE  programcode = p_programcode
				   AND useyn = 'Y';

			IF (v_check > 0)
			THEN
				SELECT COUNT(programcode)
				INTO   v_check
				FROM   ElectronicSignHistory
				WHERE  programcode = p_programcode
					   AND KEYS = p_keys;
			--and plantcode = p_plantcode

			END IF;

			--강현철. p_keys 체크추가. 키가없이 들어갈경우 생성되는것을 방지
			--2010.3.17
			IF (v_check = 0 AND NVL(p_keys,' ') != ' ')
				
			THEN
				INSERT INTO ElectronicSignHistory(programcode,
												  revisionno,
												  KEYS,
												  signseq,
												  workseq,
												  status,
												  signreasondiv,
												  empcode,
												  agent,
												  deptcode,
												  signtype,
												  plantcode)
					SELECT A.programcode,
						   A.revisionno,
						   p_keys,
						   A.signseq,
						   1,
						   '01',
						   '01',
						   A.empcode,
						   A.agent,
						   A.deptcode,
						   A.signtype,
						   p_plantcode
					FROM   ElectronicSignDetail A
						   INNER JOIN ElectronicSignMaster b
							   ON A.programcode = b.programcode
								  AND A.revisionno = b.revisionno
								  AND b.useyn = 'Y'
					WHERE  b.programcode = p_programcode;
			END IF;

			OPEN V_CURSOR FOR
				SELECT	 NVL(A.programcode, '') AS programcode,
						 NVL(b.KEYS, '') AS KEYS,
						 NVL(A.signseq, 0) AS signseq,
						 NVL(A.signlevel, 0) AS signlevel,
						 NVL(b.workseq, 0) AS workseq,
						 NVL(A.revisionno, 0) AS revisionno,
						 NVL(A.signdiv, '') AS signdiv,
						 NVL(G.divname, '') AS signdivname,
						 NVL(b.status, '') AS status,
						 NVL(h.divname, '') AS statusname,
						 NVL(b.signreasondiv, '') AS signreasondiv,
						 NVL(i.divname, '') AS signreasondivname,
                         NVL(b.empcode, '') AS empcode,
						 NVL(M.ID, '') AS empcodeid,
						 NVL(d.empname, '') AS empname,
						 NVL(b.agent, '') AS agent,
						 NVL(n.ID, '') AS agentid,
						 NVL(E.empname, '') AS agentname,
						 NVL(b.deptcode, '') AS deptcode,
						 NVL(f.deptname, '') AS deptname,
						 NVL(b.signtype, '') AS signtype,
						 NVL(b.signempcode, '') AS signempcode,
						 NVL(l.ID, '') AS signempcodeid,
						 NVL(j.empname, '') AS signempname,
						 TO_CHAR(b.signdt, 'yyyy-mm-dd') AS signdt,
						 NVL(b.signtext, '') AS signtext--,k.divname || ' - ' ||
														-- case when b.signtype = '01' and nvl(b.agent,'') = '' then nvl(d.empname,'')
														--  when b.signtype = '01' and nvl(b.agent,'') <> '' then nvl(d.empname,'') || ', 대행자 - ' || nvl(e.empname,'')
														--  when b.signtype = '02' and nvl(b.signempcode,'') = '' then nvl(f.deptname,'')
														--  when b.signtype = '02' and nvl(b.signempcode,'') <> '' then nvl(f.deptname,'') || ', 서명자 - ' || nvl(j.empname,'')
														--  when b.signtype = '03' and nvl(b.signempcode,'') <> '' then '서명자 - ' || nvl(j.empname,'')
														--  else '' end
														-- as displaytext1
						 ,
							NVL(G.divname, '')
						 || ' : '
						 || K.divname
						 || ' - '
						 || CASE
								WHEN b.signtype = '01'
									 AND NVL(b.agent, ' ') = ' '
								THEN
									NVL(d.empname, '')
								WHEN b.signtype = '01'
									 AND NVL(b.agent, ' ') <> ' '
								THEN
									NVL(d.empname, '') || ', ' || NVL(E.empname, '')
								WHEN b.signtype = '02'
									 AND NVL(b.signempcode, ' ') = ' '
								THEN
									NVL(f.deptname, '')
								WHEN b.signtype = '02'
									 AND NVL(b.signempcode, ' ') <> ' '
								THEN
									NVL(f.deptname, '') || ', ' || NVL(j.empname, '')
								WHEN b.signtype = '03'
									 AND NVL(b.signempcode, ' ') <> ' '
								THEN
									'' || NVL(j.empname, '')
								ELSE
									''
							END
							 AS displaytext1--,nvl(g.divname,'') || ' : ' || k.divname || ' - ' ||
											-- case when b.signtype = '01' and nvl(b.agent,'') = '' then nvl(d.empname,'')
											--  when b.signtype = '01' and nvl(b.agent,'') <> '' then nvl(d.empname,'') || ', 대행자 - ' || nvl(e.empname,'')
											--  when b.signtype = '02' and nvl(b.signempcode,'') = '' then nvl(f.deptname,'')
											--  when b.signtype = '02' and nvl(b.signempcode,'') <> '' then nvl(f.deptname,'') || ', 서명자 - ' || nvl(j.empname,'')
											--  when b.signtype = '03' and nvl(b.signempcode,'') <> '' then '서명자 - ' || nvl(j.empname,'')
											--  else '' end
											-- as displaytext1
											--,nvl(h.divname,'') || ' - ' || nvl(i.divname,'') || ' : ' || nvl(convert(varchar2(19), b.signdt, 121),'')
						 ,
						 NVL(i.divname, '') || ' : ' || NVL(TO_CHAR(b.signdt, 'yyyy-mm-dd'), '') AS displaytext2,
						 NVL(b.signtext, '') AS displaytext3,
						 b.plantcode
				FROM	 ElectronicSignDetail A
						 INNER JOIN ElectronicSignHistory b
							 ON A.programcode = b.programcode
								AND A.revisionno = b.revisionno
								AND A.signseq = b.signseq
						 INNER JOIN (SELECT   programcode,
											  KEYS,
											  signseq,
											  MAX(workseq) AS workseq
									 FROM	  ElectronicSignHistory
									 WHERE	  programcode = p_programcode --'mpmMakingOrders' --
											  AND KEYS = p_keys -- 'M200710290001' --
									 --and plantcode = p_plantcode
									 GROUP BY programcode, KEYS, signseq) c
							 ON b.programcode = c.programcode
								AND b.KEYS = c.KEYS
								AND b.signseq = c.signseq
								AND b.workseq = c.workseq
						 LEFT JOIN employeemaster d ON b.empcode = d.empcode
						 LEFT JOIN employeemaster E ON b.agent = E.empcode
						 LEFT JOIN placemaster f ON b.deptcode = f.deptcode
						 INNER JOIN commonmaster G
							 ON A.signdiv = G.divcode
								AND G.cmmcode = 'CMM14'
						 INNER JOIN commonmaster h
							 ON b.status = h.divcode
								AND h.cmmcode = 'CMM50'
						 INNER JOIN commonmaster i
							 ON b.signreasondiv = i.divcode
								AND i.cmmcode = 'CMM51'
						 LEFT JOIN employeemaster j ON b.signempcode = j.empcode
						 INNER JOIN commonmaster K
							 ON b.signtype = K.divcode
								AND K.cmmcode = 'CMM49'
						 LEFT JOIN ElectronicSign l ON b.signempcode = l.empcode
						 LEFT JOIN ElectronicSign M ON b.empcode = M.empcode
						 LEFT JOIN ElectronicSign n ON b.agent = n.empcode
				WHERE	 A.programcode = p_programcode
						 AND b.KEYS = p_keys
				--and b.plantcode = p_plantcode

				ORDER BY A.signseq, A.signlevel, b.workseq;
		-- 서명자 인증 확인
		ELSIF (p_div = 'S2')
		THEN
			IF (p_signtype = '01'
				OR p_signtype = '03')
			THEN
				OPEN V_CURSOR FOR
					SELECT empcode
					FROM   ElectronicSign
					WHERE  ID = p_signempcode
						   AND pwd = p_pwd;
			
		    ELSIF (p_signtype = '02')
		    THEN
			OPEN V_CURSOR FOR
				SELECT A.empcode
				FROM   ElectronicSign A
					   INNER JOIN employeemaster b ON A.empcode = b.empcode
					   INNER JOIN placemaster c ON b.deptcode = b.deptcode
				WHERE  A.ID = p_signempcode
					   AND c.deptcode = p_deptcode
					   AND A.pwd = p_pwd;
                       
		    ELSIF (NVL(p_signtype,' ') = ' ')
		    THEN
			OPEN V_CURSOR FOR
				SELECT b.empname
				FROM   ElectronicSign A INNER JOIN employeemaster b ON A.empcode = b.empcode
				WHERE  A.ID = p_signempcode;
            END IF;    
		-- 서명액션 실행가능여부 확인
		ELSIF (p_div = 'S3')
		THEN
			MESSAGE := '';
            
            FOR rec IN (SELECT spname
			INTO   MESSAGE
			FROM   ElectronicSignAction
			WHERE  programcode = p_programcode
				   AND revisionno = p_revisionno
				   AND signseq = p_signseq
				   AND actiondiv = p_actiondiv)
        LOOP
	      MESSAGE := rec.spname;
        END LOOP;
         
         --			SELECT spname
--			INTO   MESSAGE
--			FROM   ElectronicSignAction
--			WHERE  programcode = p_programcode
--				   AND revisionno = p_revisionno
--				   AND signseq = p_signseq
--				   AND actiondiv = p_actiondiv;
		-- 서명이력 조회
		ELSIF (p_div = 'S4')
		THEN
			OPEN V_CURSOR FOR
				SELECT	 NVL(G.divname, '') || ' : ' || NVL(h.divname, '') || ' : ' || NVL(i.divname, '') || ' : ' || NVL(TO_CHAR(b.signdt, 'yyyy-mm-dd'), '') || ' : ' || NVL(j.empname, '') || ' : ' || NVL(b.signtext, '') AS displaytext
				FROM	 ElectronicSignDetail A
						 INNER JOIN ElectronicSignHistory b
							 ON A.programcode = b.programcode
								AND A.revisionno = b.revisionno
								AND A.signseq = b.signseq
						 INNER JOIN commonmaster G
							 ON A.signdiv = G.divcode
								AND G.cmmcode = 'CMM14'
						 INNER JOIN commonmaster h
							 ON b.status = h.divcode
								AND h.cmmcode = 'CMM50'
						 INNER JOIN commonmaster i
							 ON b.signreasondiv = i.divcode
								AND i.cmmcode = 'CMM51'
						 LEFT JOIN employeemaster j ON b.signempcode = j.empcode
				WHERE	 A.programcode = p_programcode
						 AND b.KEYS = p_keys
						 AND b.plantcode = p_plantcode
						 AND b.signseq LIKE CASE WHEN p_signseq = 0 THEN '' ELSE TRIM(TO_CHAR(p_signseq)) END || '%'
				ORDER BY b.signdt, A.signseq;
		-- 사용자 정보 조회
		ELSIF (p_div = 'S5')
		THEN
			OPEN V_CURSOR FOR
				SELECT A.empcode,
					   SYSDATE AS signtime
				FROM   ElectronicSign A LEFT OUTER JOIN employeemaster b ON A.empcode = b.empcode
				WHERE  A.ID = p_signempcode
					   AND A.pwd = p_pwd;
		-- 승인/반려 등록
		ELSIF (p_div = 'I1')
		THEN
			--강현철. 승인취소할경우 기존 03번 승인완료상태를 04번으로 변경 (status = 03은 유니크하도록 함)
			--2010.3.17
			IF (p_signreasondiv = '05')
			THEN
				UPDATE ElectronicSignHistory
				SET    status = '04'
				WHERE  programcode = p_programcode
					   AND KEYS = p_keys
					   AND plantcode = p_plantcode
					   AND workseq = p_workseq
					   AND signseq = p_signseq
					   AND status = '03';
			END IF;

			SELECT empcode
			INTO   v_signempcode
			FROM   ElectronicSign
			WHERE  ID = p_signempcode;


			INSERT INTO ElectronicSignHistory(programcode,
											  revisionno,
											  KEYS,
											  signseq,
											  workseq,
											  status,
											  signreasondiv,
											  empcode,
											  agent,
											  deptcode,
											  signtype,
											  signempcode,
											  signdt,
											  signtext,
											  plantcode)
				SELECT programcode,
					   revisionno,
					   KEYS,
					   signseq,
					   workseq || 1,
					   p_status,
					   p_signreasondiv,
					   p_empcode,
					   p_agent,
					   p_deptcode,
					   p_signtype,
					   v_signempcode,
					   SYSDATE,
					   p_signtext,
					   p_plantcode
				FROM   ElectronicSignHistory
				WHERE  programcode = p_programcode
					   AND KEYS = p_keys
					   AND plantcode = p_plantcode
					   AND signseq = p_signseq
					   AND workseq = p_workseq;
		-- 반려/취소(승인,반려)에 따른 서명 등록
		ELSIF (p_div = 'I2')
		THEN
			INSERT INTO ElectronicSignHistory(programcode,
											  revisionno,
											  KEYS,
											  signseq,
											  workseq,
											  status,
											  signreasondiv,
											  empcode,
											  agent,
											  deptcode,
											  signtype,
											  signempcode,
											  signdt,
											  signtext,
											  plantcode)
				SELECT A.programcode,
					   A.revisionno,
					   A.KEYS,
					   A.signseq,
					   fnSeekMaxNo('ElectronicSignHistory', A.programcode || TO_CHAR(A.revisionno) || A.KEYS || TO_CHAR(A.signseq)) || 1,
					   p_status,
					   p_signreasondiv,
					   A.empcode,
					   A.agent,
					   A.deptcode,
					   A.signtype,
					   A.signempcode,
					   SYSDATE,
					   p_signtext,
					   p_plantcode
				FROM   ElectronicSignHistory A
					   INNER JOIN (SELECT	A.programcode,
											A.revisionno,
											A.KEYS,
											A.signseq,
											b.signlevel,
											MAX(A.workseq) AS workseq
								   FROM 	ElectronicSignHistory A
											INNER JOIN ElectronicSignDetail b
												ON A.programcode = b.programcode
												   AND A.revisionno = b.revisionno
												   AND A.signseq = b.signseq
								   WHERE	A.programcode = p_programcode
											AND A.KEYS = p_keys
											AND A.plantcode = p_plantcode
											AND b.signlevel = p_signlevel
											AND A.status LIKE p_statuswhere || '%'
								   GROUP BY A.programcode, A.revisionno, A.KEYS, A.signseq, b.signlevel) b
						   ON A.programcode = b.programcode
							  AND A.KEYS = b.KEYS
							  AND A.signseq = b.signseq
							  AND A.workseq = b.workseq
				WHERE  A.programcode = p_programcode
					   AND A.KEYS = p_keys
					   AND A.plantcode = p_plantcode;
		--     and a.signlevel = p_signlevel


		END IF;

		IF (V_CURSOR IS NULL)
		THEN
			OPEN V_CURSOR FOR SELECT 1 FROM DUAL;
		END IF;

		IO_CURSOR := V_CURSOR;

		DBMS_OUTPUT.PUT_LINE('===== spGetCommon PROCEDURE END =====');
	END SPELECTRONICSIGNHISTORY;
END ELECTRONICSIGNHISTORY_PKG;
/
