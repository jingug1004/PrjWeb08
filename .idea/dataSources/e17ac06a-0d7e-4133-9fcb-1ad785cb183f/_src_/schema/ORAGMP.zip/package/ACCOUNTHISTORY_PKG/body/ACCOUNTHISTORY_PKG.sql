CREATE PACKAGE BODY        ACCOUNTHISTORY_PKG
AS
	PROCEDURE SPACCOUNTHISTORY(
		p_div			IN	   VARCHAR2 := '',
		p_empcode		IN	   VARCHAR2 := '',
		p_userid		IN	   VARCHAR2 := '',
		p_reasondiv 	IN	   VARCHAR2 := '',
		p_reasontext	IN	   VARCHAR2 := '',
		MESSAGE 		   OUT VARCHAR2,
		IO_CURSOR		   OUT TYPES.DATASET
	)
	IS
		v_enabledate   VARCHAR2(10);
	BEGIN
		DBMS_OUTPUT.PUT_LINE('===== spGetCommon PROCEDURE START =====');
		MESSAGE := '데이터베이스 성공';

		IF (p_div = 'S')
		THEN
			/*
                      CREATE TABLE temp_AccountHistory (
                        companyname   varchar2(50) -- 회사상호
                     ,accountdt   varchar2(19) -- 계정 등록/변경일시
                     ,accountperiod  varchar2(10) -- 계정 유효기한
                     ,accountchangecnt int    -- 아이디.비밀번호 변경 횟수
                     ,logoutdt   varchar2(19)  -- 최근시스템종료일시
                      )
                      ON COMMIT DELETE ROWS;
                     */

			DELETE temp_AccountHistory;

			--회사상호
			INSERT INTO temp_AccountHistory(companyname)
				SELECT compname
				FROM   CMCOMPM
				WHERE  ROWNUM = 1;


			--계정 등록/변경일시
			UPDATE temp_AccountHistory
			SET    accountdt =
					   (SELECT TO_CHAR(NVL(changedate, inputdate), 'yyyy-mm-dd hh24:mi:ss')
						FROM   ELECTRONICSIGN
						WHERE  empcode = p_empcode);

			--계정 유효기한
			SELECT TO_CHAR(NVL(changedate, inputdate), 'yyyy-mm-dd')
			INTO   v_enabledate
			FROM   ElectronicSign
			WHERE  empcode = p_empcode;

			--!!! to_date 함수에서 반드시 두번째 인자 포맷 변수 넘겨줄 것 : 'yyyy-mm-dd hh24:mi:ss'

			UPDATE temp_AccountHistory
			SET    accountperiod =
					   (SELECT CASE is_date(v_enabledate) WHEN 1 THEN TO_CHAR(TO_DATE(v_enabledate, 'yyyy-mm-dd hh24:mi:ss') + TO_NUMBER(value1) - 1, 'yyyy-mm-dd') ELSE '' END
						FROM   parametermanage
						WHERE  parametercode = 'ESignPeriod');


			--아이디.비밀번호 변경 횟수
			UPDATE temp_AccountHistory
			SET    accountchangecnt =
					   (SELECT COUNT(empcode)
						FROM   SignHistory
						WHERE  empcode = p_empcode);


			--최근시스템종료일시
			UPDATE temp_AccountHistory
			SET    logoutdt =
					   (SELECT	 TO_CHAR(MAX(logoutdt), 'yyyy-mm-dd hh24:mi:ss')
						FROM	 LoginAccess
						WHERE	 empcode = p_empcode
								 AND is_date(logoutdt) = 1
						GROUP BY empcode);


			--최근 사용 프로그램


			OPEN IO_CURSOR FOR SELECT * FROM temp_AccountHistory;
		END IF;

		IF (IO_CURSOR IS NULL)
		THEN
			OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
		END IF;

		DBMS_OUTPUT.PUT_LINE('===== spGetCommon PROCEDURE END =====');
	END SPACCOUNTHISTORY;
END ACCOUNTHISTORY_PKG;
/
