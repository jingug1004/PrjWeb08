CREATE VIEW VNCUSTREL AS SELECT a.custcode,
		   a.orderdiv,
		   a.relcustcode,
		   b.custname,
		   b.utdiv,
		   b.utdivnm,
		   b1.custname relcustname,
		   b1.ceoname,
		   b1.telno,
		   b1.addr1,
		   b1.sagodiv,
		   NVL(b1.stopdate, ' ') relstopdate,
		   a.custmngdiv,
		   a.useyn --사용여부 추가 20140303:이세민
	FROM   CMCUSTRELS a
		   LEFT JOIN vnCUST b ON a.custcode = b.custcode
		   LEFT JOIN vnCUST b1 ON a.relcustcode = b1.custcode
/
