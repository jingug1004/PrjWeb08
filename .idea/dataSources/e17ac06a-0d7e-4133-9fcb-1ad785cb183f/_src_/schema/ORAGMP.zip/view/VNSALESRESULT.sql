CREATE VIEW VNSALESRESULT AS SELECT a.plantcode, -- isnull(a.plantcode,'') as plantcode
		   a.orderno, -- isnull(a.orderno,'') as orderno   -- 사업장 / 주문번호
		   a.orderdate, -- isnull(a.orderdate,'') as orderdate
		   a.yymm yymm, -- 주문일자
		   a.orderseq, -- isnull(a.orderseq,'') as orderseq
		   b.seq, -- isnull(b.seq,0) as seq     -- 주문순번 / 일련번호
		   a.saldiv saldiv, -- 주문구분
		   a.datadiv datadiv, -- 자료구분
		   '' coldiv, -- 수금구분
		   a.orderdiv orderdiv, -- 영업영역
		   CASE WHEN c.custdiv = '8' THEN c.custmajorcode ELSE a.custcode END custcode, -- 거래처
		   CASE WHEN c.custdiv = '8' THEN D.deptcode ELSE a.deptcode END deptcode,
		   CASE WHEN c.custdiv = '8' THEN D.empcode ELSE a.empcode END empcode,
		   CASE WHEN c.custdiv = '8' THEN c.custmajorcode ELSE a.ecustcode END ecustcode, -- 거래처
		   CASE WHEN c.custdiv = '8' THEN D.deptcode ELSE a.edeptcode END edeptcode,
		   CASE WHEN c.custdiv = '8' THEN D.empcode ELSE a.eempcode END eempcode,
		   CASE WHEN c.custdiv = '8' THEN D.utdiv ELSE a.utdiv END utdiv,
		   CASE WHEN c.custdiv = '8' THEN D.utdiv ELSE a.eutdiv END eutdiv,
		   a.appdate, -- isnull(a.appdate,'') as appdate
		   a.statediv, -- isnull(a.statediv,'') as statediv  -- 매출적용일자 / 상태구분
		   b.itemcode, -- isnull(b.itemcode,'') as itemcode
		   NVL(b.salqty, 0) salqty, -- 제품코드 / 판매수량
		   NVL(b.givqty, 0) givqty,
		   b.lotno lotno, -- 할증수량 / 제조번호
		   NVL(b.drugprc, 0) drugprc,
		   NVL(b.drugamt, 0) drugamt, -- 기준가 / 기준금액
		   NVL(b.salprc, 0) salprc,
		   NVL(b.salamt, 0) salamt,
		   NVL(b.salvat, 0) salvat, -- 판매금액 / 부가세
		   NVL(b.totamt, 0) totamt,
		   NVL(b.salprc1, 0) salprc1,
		   NVL(b.salamt1, 0) salamt1,
		   NVL(b.salvat1, 0) salvat1, -- 판매금액1 / 부가세1
		   NVL(b.totamt1, 0) totamt1,
		   0 colamt,
		   '' accountno, --나머지는 union all을 맞추기
		   '' billno, --위해 존재..
		   '' issdate,
		   '' expdate,
		   '' paybank,
		   '' issempnm,
		   '' cardcomp,
		   '' cardno,
		   '' cardokno,
		   0 divmonth,
		   '' discntdate,
		   a.pda pda,
		   b.aftamt aftamt,
		   'N' tasooyn,
		   D.custdiv
	FROM   SLORDM a --주문마스터
		   LEFT JOIN SLORDD b --주문서제품내역
			   ON a.plantcode = b.plantcode
				  AND a.orderno = b.orderno
		   LEFT JOIN CMCUSTM c ON a.custcode = c.custcode
		   LEFT JOIN CMCUSTM D ON RTRIM(c.custmajorcode) = D.custcode
	WHERE  a.statediv <> '99' --반려제외
	UNION ALL
	--수금
	SELECT SLCOLM.plantcode, -- isnull(SLCOLM.plantcode,'') as plantcode
		   SLCOLM.colno, -- isnull(SLCOLM.colno,'') as colno  -- 사업장코드 / 수금번호
		   SLCOLM.coldate, -- isnull(SLCOLM.coldate,'') as coldate
		   SUBSTR(NVL(appdate, ' '), 1, 7) yymm, -- 전표일자
		   SLCOLM.colseq, -- isnull(SLCOLM.colseq,'') as colseq
		   0 seq, -- 전표순번(번호)
		   SLCOLM.saldiv saldiv, -- 영업구분
		   '' datadiv, -- 자료구분
		   SLCOLM.coldiv coldiv, -- 수금구분
		   SLCOLM.orderdiv orderdiv, -- 영업영역
		   SLCOLM.custcode custcode, -- 거래처
		   SLCOLM.deptcode deptcode,
		   SLCOLM.empcode empcode, -- 영업소 / 담당자
		   SLCOLM.ecustcode ecustcode,
		   SLCOLM.edeptcode edeptcode, -- 간납거래처 / 간납영업소
		   SLCOLM.eempcode eempcode,
		   SLCOLM.utdiv utdiv, -- 간납담당자 / 유통구분
		   SLCOLM.eutdiv eutdiv,
		   SLCOLM.appdate, -- isnull(SLCOLM.appdate,'') as appdate
		   SLCOLM.statediv, -- isnull(SLCOLM.statediv,'') as statediv -- 매출적용일자 / 상태구분
		   '' itemcode,
		   0 salqty,
		   0 givqty,
		   '' lotno,
		   0 drugprc,
		   0 drugamt,
		   0 salprc,
		   0 salamt,
		   0 salvat,
		   0 totamt,
		   0 salprc1,
		   0 salamt1,
		   0 salvat1,
		   0 totamt1,
		   NVL(SLCOLM.colamt, 0) colamt,
		   SLCOLM.accountno accountno, -- 수금금액 / 계좌번호
		   SLCOLM.billno billno,
		   SLCOLM.issdate issdate,
		   SLCOLM.expdate expdate, -- 발행일자 / 만기일자
		   SLCOLM.paybank paybank,
		   SLCOLM.issempnm issempnm, -- 지급은행 / 발행인
		   SLCOLM.cardcomp cardcomp,
		   SLCOLM.cardno cardno, --카드사 / 카드번호
		   SLCOLM.cardokno cardokno,
		   NVL(SLCOLM.divmonth, 0) divmonth, -- 카드승인번호 / 할부기간
		   SLCOLM.discntdate discntdate,
		   pda pda,
		   0 aftamt,
		   NVL(tasooyn, 'N') tasooyn,
		   ' ' custdiv
	FROM   SLCOLM -- 수금마스터
	WHERE  statediv <> '99' --반려제외
/
