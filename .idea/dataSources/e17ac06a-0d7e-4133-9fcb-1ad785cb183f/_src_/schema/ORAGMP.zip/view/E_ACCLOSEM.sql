CREATE VIEW E_ACCLOSEM AS SELECT closeym CLOSEYM,
		   accdiv CLOSEDIV,
		   apprcloseyn CLOSEYN
	FROM   CMCLOSEM
	WHERE  accdiv IN ('C', 'S')
/
