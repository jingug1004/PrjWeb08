CREATE VIEW PARAMETERMANAGE AS SELECT parametercode,
		   parameterdiv,
		   parameterexplanation,
		   value1,
		   value2,
		   value3,
		   usediv
	FROM   SYSPARAMETERMANAGE
/
