CREATE VIEW NVSTOCKITEMALL AS SELECT a.itemcode
		  , --품목코드
		   a.itemkorname
		  , --품목명
		   a.warehousingdate
		  , --입고일자
		   a.warehousingno
		  , --입고번호
		   a.manufacturecode
		  , --제조처코드
		   a.lotno
		  , --제조번호
		   a.lotdate
		  , --제조일자
		   a.validityperiod
		  , --유효일자
		   a.retestdate
		  , --재시험기한
		   a.warehousingstate
		  , --입고상태
		   a.itemunit
		  , --단위
		   a.itemunitname
		  ,a.testno
		  , --시험번호
		   a.classifyjudgerate cjrate
		  , --시험함량/역가
		   a.classifyjudgerateB cjrateB
		  , --시험함량/역가B
		   a.itemdiv
		  , --원부자재구분
		   a.itemdivname
		  ,a.itembranch
		  , --원부자재분류
		   a.itembranchname
		  ,a.testresult
		  , --시험결과(Y/N/Blank:적합/부적합/진행)
		   a.retestno
		  ,a.totalwarehousingqty inputqty
		  , --입고수량
		   NVL(b.inputetcqty, 0) inputetcqty
		  , --기타입고량
		   NVL(c.outqty, 0) outqty
		  , --일반출고량
		   NVL(E.weighinguseqty, 0) weighinguseqty
		  , --칭량작업량
		   NVL(c.outwaitqty, 0) outwaitqty
		  , --출고대기량
		   NVL(D.outputetcqty, 0) + NVL(f.returnqty, 0) outputetcqty
		  , --기타출고량(폐기포함)
		   CASE WHEN NVL(outrockdiv, '') = 'N' THEN a.totalwarehousingqty + NVL(b.inputetcqty, 0) - NVL(c.outqty, 0) - NVL(D.outputetcqty, 0) - NVL(f.returnqty, 0) ELSE 0 END unuseqty
		  , --불용량
		   a.totalwarehousingqty + NVL(b.inputetcqty, 0) - NVL(c.outqty, 0) - NVL(D.outputetcqty, 0) - NVL(f.returnqty, 0) asstock
		  , --가용재고
		   a.totalwarehousingqty + NVL(b.inputetcqty, 0) - NVL(c.outqty, 0) - NVL(D.outputetcqty, 0) - NVL(f.returnqty, 0) nowstock
		  , --현재재고
		   a.outrockdiv
		  ,a.testcheck
		  ,a.itemdetaildiv
		  ,a.requestcheck
		  ,a.requestperiod
		  ,NVL(f.returnqty, 0) returnqty
		  , --폐기량
		   a.custcode
		  ,a.testno2
		  ,a.retestcheck
		  ,a.price
		  ,a.warehousediv
		  ,a.costcenter
		  ,a.testdate
		  ,a.safestockqty --안전재고량
          ,a.plantcode
	FROM   ( --입고자료(일반)
			SELECT a.itemcode
				  , --품목코드
				   b.itemname itemkorname
				  , --품목명
				   TO_CHAR(a.warehousingdt, 'YYYY-MM-DD') warehousingdate
				  , --입고일자
				   a.warehousingno
				  , --입고번호
				   a.manufacturecode
				  , --제조처코드
				   a.lotno
				  , --제조번호
				   a.lotdate
				  , --제조일자
				   a.validityperiod
				  , --유효일자
				   a.retestdate
				  ,a.warehousingstate
				  , --입고상태
				   b.unit itemunit
				  , --단위
				   NVL(G.divname, ' ') itemunitname
				  ,a.testno
				  , --시험번호
				   a.classifyjudgerate
				  , --시험함량/역가
				   a.classifyjudgerateB
				  , --시험함량/역가B
				   a.totalwarehousingqty
				  , --입고수량
				   b.itemdiv
				  , --원부자재구분
				   NVL(h.divname, '') itemdivname
				  ,b.itembranch
				  , --원부자재분류
				   NVL(i.divname, '') itembranchname
				  ,a.testresult
				  , --시험결과
				   a.retestno
				  ,NVL(a.outrockdiv, 'Y') outrockdiv
				  ,NVL(b.testcheck, 'N') testcheck
				  ,f.remark itemdetaildiv
				  ,NVL(b.requestcheck, 'N') requestcheck
				  ,NVL(b.requestperiod, 0) requestperiod
				  ,NVL(a.custcode, '') custcode
				  ,NVL(a.testno2, '') testno2
				  ,NVL(a.retestcheck, 'N') retestcheck
				  ,NVL(a.warehousingprice, 0) price
				  ,a.warehousediv
				  ,'' costcenter
				  ,NVL(x.testdate, TO_CHAR(a.testdt, 'YYYY-MM-DD')) testdate
				  ,NVL(b.safeqty, 0) safestockqty --안전재고량
                  ,a.plantcode
			FROM   Warehousing a
				   JOIN CMITEMM b ON a.itemcode = b.itemcode
				   --and a.warehousingtestresult = 'Y'   --입고검수(적합)
				   --and a.stockzero is null    --재고여부(>0)
				   --and a.testresult = 'Y'
				   --and (a.outrockdiv is null or a.outrockdiv = 'Y')  --상태정상
				   --and a.validityperiod >= convert(nvarchar(10), getdate(), 121)

				   LEFT JOIN TestManage x ON a.testno = x.testno
				   LEFT JOIN CMCOMMONM G
					   ON b.unit = G.divcode
						  AND G.cmmcode = 'CMM02'
				   LEFT JOIN CMCOMMONM h
					   ON b.itemdiv = h.divcode
						  AND h.cmmcode = 'CMM01'
				   LEFT JOIN CMCOMMONM i
					   ON b.itembranch = i.divcode
						  AND i.cmmcode = 'MPM09'
				   JOIN CMCOMMONM f
					   ON b.itembranch = f.divcode
						  AND f.cmmcode = 'MPM09'
						  AND b.itemdiv IN ('01', '02', '07')) a
		   LEFT JOIN ( --입고자료(기타)
					  SELECT   a.warehousingno
							  ,SUM(a.inputetcqty) inputetcqty --입고수량
					  FROM	   (SELECT warehousingno warehousingno
									  ,etcinoutnoqty inputetcqty
								FROM   MaterialEtcInOut
								WHERE  SUBSTR(inoutdiv, 0, 1) = 'I') a
					  GROUP BY a.warehousingno) b
			   ON a.warehousingno = b.warehousingno
		   LEFT JOIN ( --출고자료(일반,출고대기)
					  SELECT   a.warehousingno
							  ,SUM(a.outqty) outqty
							  , --출고수량
							   SUM(a.outwaitqty) outwaitqty --출고대기수량
					  FROM	   (SELECT warehousingno
									  ,CASE WHEN rowoutstate = '04' THEN rowoutorderqty ELSE 0 END outqty
									  , --출고완료
									   CASE WHEN rowoutstate <> '04' THEN rowoutorderqty ELSE 0 END outwaitqty --출고대기
								FROM   TakingOutRowDetail
								UNION ALL
								SELECT warehousingno
									  ,CASE WHEN materialoutstate = '04' THEN materialoutorderqty ELSE 0 END outqty
									  ,CASE WHEN materialoutstate <> '04' THEN materialoutorderqty ELSE 0 END outwaitqty
								FROM   TakingOutMaterialDetail) a
					  GROUP BY a.warehousingno) c
			   ON a.warehousingno = c.warehousingno
		   LEFT JOIN ( --출고자료(기타)
					  SELECT   warehousingno
							  ,SUM(etcinoutnoqty) outputetcqty
					  FROM	   MaterialEtcInOut
					  WHERE    SUBSTR(inoutdiv, 0, 1) = 'O'
					  GROUP BY warehousingno) D
			   ON a.warehousingno = D.warehousingno
		   LEFT JOIN ( --칭량자료(실시간재고)
					  SELECT   warehousingno
							  ,SUM(subdetailqty) weighinguseqty
					  FROM	   WeighingSubDetail
					  GROUP BY warehousingno) E
			   ON a.warehousingno = E.warehousingno
		   LEFT JOIN ( --폐기자료(기타)
					  SELECT   warehousingno
							  ,SUM(totalwarehousingreturnqty) returnqty
					  FROM	   WarehousingReturning
					  GROUP BY warehousingno) f
			   ON a.warehousingno = f.warehousingno
/
