CREATE VIEW NVITEMMASTER AS SELECT DISTINCT itemcode,
					itemname ITEMKORNAME,
					itemsname itemshortname,
					itemename itemengname,
					itemunit,
					itembranch,
					itemdiv,
					costcenter
	FROM   CMITEMM
	WHERE  costcenter IN ('01')
		   AND itemdiv = '04'
	UNION
	SELECT DISTINCT itemcode,
					itemname ITEMKORNAME,
					itemsname itemshortname,
					itemename itemengname,
					itemunit,
					itembranch,
					itemdiv,
					costcenter
	FROM   CMITEMM
	WHERE  itemdiv = '05'
/
