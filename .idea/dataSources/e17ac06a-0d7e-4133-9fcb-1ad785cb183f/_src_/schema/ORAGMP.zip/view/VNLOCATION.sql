CREATE VIEW VNLOCATION AS SELECT a.plantcode,
		   a.warehouse,
		   b.whname,
		   a.location,
		   a.locname
	FROM   SLLOCATIONM a
		   LEFT JOIN SLSTOREHOUSEM b
			   ON a.plantcode = b.plantcode
				  AND a.warehouse = b.warehouse
/
