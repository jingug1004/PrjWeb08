CREATE VIEW VNPSINSUM AS SELECT NVL(b.plantcode, ' ') plantcode,
		   NVL(a.yearmonth, ' ') yearmonth,
		   NVL(b.topdeptcode, ' ') topdeptcode,
		   NVL(b.topdeptname, ' ') topdeptname,
		   NVL(b.predeptcode, ' ') predeptcode,
		   NVL(b.predeptname, ' ') predeptname,
		   NVL(b.deptcode, ' ') deptcode,
		   NVL(b.deptname, ' ') deptname,
		   NVL(b.findname, ' ') findname,
		   NVL(a.empcode, ' ') empcode,
		   NVL(b.empname, ' ') empname,
		   NVL(b.positiondiv, ' ') positiondiv,
		   NVL(b.jikwi, ' ') jikwi,
		   NVL(c.insuratep, 0) insuratep,
		   NVL(c.insuratec, 0) insuratec,
		   NVL(c.mediratep, 0) mediratep,
		   NVL(c.mediratec, 0) mediratec,
		   NVL(a.taxamt, 0) taxamt,
		   NVL(a.taxmonth, 0) taxmonth,
		   NVL(a.fixamt, 0) fixamt,
		   NVL(a.insuamtp, 0) insuamtp,
		   NVL(a.insuamtc, 0) insuamtc,
		   NVL(b.enterdt, ' ') enterdt,
		   NVL(b.retiredt, ' ') retiredt
	FROM   PSINSUM a
		   JOIN vnEMP b ON a.empcode = b.empcode
		   LEFT JOIN PSTAXRATEM c
			   ON a.yearmonth = c.yearmonth
				  AND 1 = 1
--				select * from vndept
/
