CREATE VIEW E_ITEMSTOCK AS SELECT	 b.itemoldcode itemcode,
			 a.lotno,
			 MAX(a.lotdate) lotdate,
			 MAX(a.expdate) expdate,
			 SUM(a.qty) qty,
			 SUM(a.qty) useqty
	FROM	 SLWAREHOUSEM a JOIN CMITEMM b ON a.itemcode = b.itemcode
	GROUP BY b.itemoldcode, a.lotno
--select	itemcode, lotno, max(lotdate) as lotdate, max(expdate) as expdate, sum(qty) as qty
--from	SLWAREHOUSEM
--group by itemcode, lotno
/
