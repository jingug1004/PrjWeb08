CREATE VIEW VNSALESCHONGPAN AS SELECT (a.plantcode) plantcode,
          yymm yymm,                                                  --사업장 코드
          (a.orderdate) orderdate,                                      --주문일자
          (a.orderseq) orderseq,
          a.orderno,        -- ISNULL(a.orderno, N'') AS orderno,       --주문구분
          (a.saldiv) saldiv,                                            --판매구분
          CASE
             WHEN (NVL (a.saldiv, ' ') = 'C01')
                  AND (NVL (a.tasooyn, 'N') = 'N')
             THEN
                NVL (SL18.divname, '')
             WHEN (NVL (a.saldiv, ' ') = 'C01')
                  AND (NVL (a.tasooyn, 'N') = 'Y')
             THEN
                NVL (SL18.divname, '') || '(타)'
             ELSE
                NVL (D.divname, '')
          END
             saldivnm,
          (a.tasooyn) tasooyn,
          (a.datadiv) datadiv,
          (E.divname) datadivnm,
          (a.coldiv) coldiv,
          (a.orderdiv) orderdiv,
          (a.outputdiv) outputdiv,
          (f.divname) outputdivnm,
          (a.transferdiv) transferdiv,
          (G.divname) transferdivnm,
          (b.telno) telno,
          (b.faxno) faxno,
          (b.ceoname) ceoname,
          (b.businessno) businessno,
          (b.POST) POST,
          (b.addr1) addr1,
          (b.addr2) addr2,
          (b.addr1) || ' ' || (b.addr2) addr,
          CASE
             WHEN b.custdiv = '8' THEN NVL (b.custmajorcode, '')
             ELSE NVL (a.custcode, '')
          END
             custcode,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.custname, '')
             ELSE NVL (b.custname, '')
          END
             custname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.utdiv, '')
             ELSE NVL (a.utdiv, '')
          END
             utdiv,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.utdivnm, '')
             ELSE NVL (o.divname, '')
          END
             utdivnm,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.findname, '')
             ELSE NVL (h.findname, '')
          END
             findname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.topdeptcode, '')
             ELSE NVL (h.topdeptcode, '')
          END
             topdeptcode,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.topdeptname, '')
             ELSE NVL (h.topdeptname, '')
          END
             topdeptname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.predeptcode, '')
             ELSE NVL (h.predeptcode, '')
          END
             predeptcode,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.predeptname, '')
             ELSE NVL (h.predeptname, '')
          END
             predeptname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.deptcode, '')
             ELSE NVL (a.deptcode, '')
          END
             deptcode,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.deptname, '')
             ELSE NVL (h.deptname, '')
          END
             deptname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.empcode, '')
             ELSE NVL (a.empcode, '')
          END
             empcode,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.empname, '')
             ELSE NVL (i.empname, '')
          END
             empname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.positiondiv, '')
             ELSE NVL (i.positiondiv, '')
          END
             positiondiv,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.jikwi, '')
             ELSE NVL (U.divname, '')
          END
             jikwi,
          CASE
             WHEN b.custdiv = '8' THEN NVL (b.custmajorcode, '')
             ELSE NVL (a.ecustcode, '')
          END
             ecustcode,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.custname, '')
             ELSE NVL (c.custname, '')
          END
             ecustname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.utdiv, '')
             ELSE NVL (a.eutdiv, '')
          END
             eutdiv,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.utdivnm, '')
             ELSE NVL (P.divname, '')
          END
             eutdivnm,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.findname, '')
             ELSE NVL (j.findname, '')
          END
             efindname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.topdeptcode, '')
             ELSE NVL (j.topdeptcode, '')
          END
             etopdeptcode,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.topdeptname, '')
             ELSE NVL (j.topdeptname, '')
          END
             etopdeptname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.predeptcode, '')
             ELSE NVL (j.predeptcode, '')
          END
             epredeptcode,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.predeptname, '')
             ELSE NVL (j.predeptname, '')
          END
             epredeptname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.deptcode, '')
             ELSE NVL (a.edeptcode, '')
          END
             edeptcode,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.deptname, '')
             ELSE NVL (j.deptname, '')
          END
             edeptname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.empcode, '')
             ELSE NVL (a.eempcode, '')
          END
             eempcode,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.empname, '')
             ELSE NVL (K.empname, '')
          END
             eempname,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.positiondiv, '')
             ELSE NVL (K.positiondiv, '')
          END
             epositiondiv,
          CASE
             WHEN b.custdiv = '8' THEN NVL (bb.jikwi, '')
             ELSE NVL (v.divname, '')
          END
             ejikwi,
          (a.bnorderno) bnorderno,
          (a.taxdate) taxdate,
          (a.tradedate) tradedate,
          (a.appdate) appdate,
          (a.statediv) statediv,
          (l.divname) statedivnm,
          (a.remark) remark,
          (a.seq) seq,
          (a.itemcode) itemcode,
          (M.itemname) itemname,
          (M.itemunit) unit,
          (M.drugdiv) drugdiv,
          (W.divname) drugdivnm,
          (M.medimaxprc) medimaxprc,
          (M.mitemcode) mitemcode,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.salqty)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.salqty)
             ELSE 0
          END
             salqty,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.givqty)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.givqty)
             ELSE 0
          END
             givqty,
          --             CASE WHEN LEFT(a.saldiv, 1) = 'A' THEN (a.pieceqty)
          --WHEN LEFT(a.saldiv, 1) = 'B' THEN - (a.pieceqty)
          --ELSE 0 END AS pieceqty,
          (a.drugprc) drugprc,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.drugamt)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.drugamt)
             ELSE 0
          END
             drugamt,
          a.makingcost makingcost,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.makingamt)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.makingamt)
             ELSE 0
          END
             makingamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.makinggivamt)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.makinggivamt)
             ELSE 0
          END
             makinggivamt,
          (a.salprc) salprc,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.salamt)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.salamt)
             ELSE 0
          END
             salamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.salvat)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.salvat)
             ELSE 0
          END
             salvat,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.totamt)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.totamt)
             ELSE 0
          END
             totamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.befamt)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.befamt)
             ELSE 0
          END
             befamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.aftamt)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.aftamt)
             ELSE 0
          END
             aftamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.incamt)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.incamt)
             ELSE 0
          END
             incamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.totdiscount)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.totdiscount)
             ELSE 0
          END
             totdiscount,
          (a.givrate) givrate,
          (a.befrate) befrate,
          (a.aftrate) aftrate,
          (a.incrate) incrate,
          (a.salprc1) salprc1,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.salamt1)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.salamt1)
             ELSE 0
          END
             salamt1,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.salvat1)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.salvat1)
             ELSE 0
          END
             salvat1,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.totamt1)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.totamt1)
             ELSE 0
          END
             totamt1,
          --코드체계에 대한 하드코딩부분 확인 20131122:이세민 ==========================================================
          --CASE WHEN a.saldiv = 'C01' AND a.coldiv IN ('01','02') THEN (a.colamt)
          --  ELSE 0 END AS cashcol,  --현금수금
          --20131122: 이세민[실적관리 테이블 적용] 실적에 적용할 내용만 포함되도록 함
          CASE
             WHEN a.saldiv = 'C01'
                  AND (SUBSTR (a.coldiv, 0, 1) = '0'
                       AND a.coldiv IN (SELECT divcode FROM SLCONDRESULT))
             THEN
                (a.colamt)
             ELSE
                0
          END
             cashcol,                                                   --현금수금
          CASE
             WHEN a.saldiv = 'C01'
                  AND (SUBSTR (a.coldiv, 0, 1) = '1'
                       AND a.coldiv IN (SELECT divcode FROM SLCONDRESULT))
             THEN
                (a.colamt)
             ELSE
                0
          END
             bankcol,                                                   --은행입금
          CASE
             WHEN a.saldiv = 'C01'
                  AND (SUBSTR (a.coldiv, 0, 1) = '2'
                       AND a.coldiv IN (SELECT divcode FROM SLCONDRESULT))
             THEN
                (a.colamt)
             ELSE
                0
          END
             cardcol,                                                   --카드수금
          CASE
             WHEN a.saldiv = 'C01'
                  AND (SUBSTR (a.coldiv, 0, 1) = '3'
                       AND a.coldiv IN (SELECT divcode FROM SLCONDRESULT))
             THEN
                NVL (a.colamt, 0)
             ELSE
                0
          END
             billcol,                                                   --어음수금
          CASE
             WHEN a.saldiv = 'C01'
                  AND (a.coldiv > '39'
                       AND a.coldiv IN (SELECT divcode FROM SLCONDRESULT))
             THEN
                NVL (a.colamt, 0)
             ELSE
                0
          END
             etccol,                                                    --기타수금
          --//==========================================================================================================
          (a.colamt) colamt,
          (a.sampck) sampck,
          (a.custprtyn) custprtyn,
          (a.outputqty) outputqty,
          (a.recalldiv) recalldiv,
          (x.divname) recalldivnm,
          (a.absyn) absyn,
          (a.pieceyn) pieceyn,
          (a.enuriyn) eruriyn,
          CASE
             WHEN a.coldiv LIKE '3%'
             THEN
                NVL (a.paybank, ''                                      --지금은행
                                  )
             WHEN SUBSTR (a.coldiv, 0, 1) = '1'
             THEN
                NVL (T.bankname, U'') || ' ' || NVL (T.branchname, U'') --계좌은행
             WHEN (SUBSTR (a.coldiv, 0, 1) = '2')
                  AND (NVL (a.divmonth, 0) = 0)
             THEN
                NVL (AC17.divname, U''                                   --카드사
                                      )
             WHEN (SUBSTR (a.coldiv, 0, 1) = '2')
                  AND (NVL (a.divmonth, 0) > 0)
             THEN
                   NVL (AC17.divname, U'')
                || ' '
                || TO_CHAR (divmonth)
                || '개월'                                              --카드사
             ELSE
                ' '
          END
             gubun,
          (a.billno) billno,
          (a.accountno) accountno,
          CASE WHEN a.coldiv LIKE '3%' THEN a.issdate ELSE '' END issdate,
          CASE WHEN a.coldiv LIKE '3%' THEN (a.expdate) ELSE '' END expdate,
          CASE WHEN a.coldiv LIKE '3%' THEN (a.discntdate) ELSE '' END
             discntdate,
          (a.paybank) paybank,
          (a.cardcomp) cardcomp,
          NVL (AC17.divname, U'') cardcompnm,
          (a.cardno) cardno,
          (a.cardokno) cardokno,
          NVL (T.bankname, U'') || ' ' || NVL (T.branchname, U'')
             accountbanknm,
          (a.pda) pda,
          NVL (b.areadiv, '') areadiv,
          NVL (uu.divname, '') areadivnm,
          (i.retiredt) retiredt,
          (K.retiredt) eretiredt,
          (h.deptgroup) deptgroup,
          (j.deptgroup) edeptgroup,
          (b.custmajorcode) custmajorcode,
          CASE WHEN b.custdiv = '8' THEN (bb.opendate) ELSE b.opendate END
             opendate,
          CASE WHEN b.custdiv = '8' THEN (bb.stopdate) ELSE b.stopdate END
             stopdate,
          CASE WHEN b.custdiv = '8' THEN (bb.opendate) ELSE c.opendate END
             eopendate,
          CASE WHEN b.custdiv = '8' THEN (bb.stopdate) ELSE c.stopdate END
             estopdate,
          (i.ratediv) ratediv,
          (K.ratediv) eratediv,
          (oo.divname) ratedivnm,
          (pp.divname) eratedivnm,
          CASE
             WHEN b.custdiv = '8' THEN (bb.ascustcheck)
             ELSE b.ascustcheck
          END
             ascustcheck,
          CASE
             WHEN b.custdiv = '8' THEN (bb.ascustcheck)
             ELSE c.ascustcheck
          END
             eascustcheck,
          h.seqtopdeptcode,
          h.seqpredeptcode,
          h.seqdeptcode,
          j.seqtopdeptcode eseqtopdeptcode,
          j.seqpredeptcode eseqpredeptcode,
          j.seqdeptcode eseqdeptcode,
          a.sagock sagodiv,
          i.partdiv partdiv
     FROM vnSalesEnd a
          LEFT JOIN CMCUSTM b
             ON a.custcode = b.custcode
          LEFT JOIN CMCUSTM c
             ON a.ecustcode = c.custcode
          LEFT JOIN vnCUST bb
             ON b.custmajorcode = bb.custcode
          LEFT JOIN CMCOMMONM D
             ON a.saldiv = D.divcode AND D.cmmcode = 'SL10'
          LEFT JOIN CMCOMMONM E
             ON a.datadiv = E.divcode AND E.cmmcode = 'SL11'
          LEFT JOIN CMCOMMONM f
             ON a.outputdiv = f.divcode AND f.cmmcode = 'SL12'
          LEFT JOIN CMCOMMONM G
             ON a.transferdiv = G.divcode AND G.cmmcode = 'SL14'
          LEFT JOIN vnDEPT h
             ON a.deptcode = h.deptcode
          LEFT JOIN CMEMPM i
             ON a.empcode = i.empcode
          LEFT JOIN vnDEPT j
             ON a.edeptcode = j.deptcode
          LEFT JOIN CMEMPM K
             ON a.eempcode = K.empcode
          LEFT JOIN CMCOMMONM l
             ON a.statediv = l.divcode AND l.cmmcode = 'SL17'
          LEFT JOIN CMITEMM M
             ON a.itemcode = M.itemcode
          LEFT JOIN CMCOMMONM N
             ON M.unit = N.divcode AND N.cmmcode = 'CM38'
          LEFT JOIN CMCOMMONM o
             ON a.utdiv = o.divcode AND o.cmmcode = 'CM15'
          LEFT JOIN CMCOMMONM P
             ON a.eutdiv = P.divcode AND P.cmmcode = 'CM15'
          LEFT JOIN CMCOMMONM SL18
             ON a.coldiv = SL18.divcode AND SL18.cmmcode = 'SL18'
          LEFT JOIN CMCOMMONM AC17
             ON a.cardcomp = AC17.divcode AND AC17.cmmcode = 'AC17'
          LEFT JOIN CMACCOUNTM S
             ON a.accountno = S.accountno
          LEFT JOIN CMBANKM T
             ON S.bankcode = T.bankcode
          LEFT JOIN CMCOMMONM U
             ON i.positiondiv = U.divcode AND U.cmmcode = 'PS29'
          LEFT JOIN CMCOMMONM v
             ON K.positiondiv = v.divcode AND v.cmmcode = 'PS29'
          LEFT JOIN CMCOMMONM W
             ON M.drugdiv = W.divcode AND W.cmmcode = 'CM23'
          LEFT JOIN CMCOMMONM x
             ON a.recalldiv = x.divcode AND x.cmmcode = 'SL16'
          LEFT JOIN CMCOMMONM uu
             ON b.areadiv = uu.divcode AND uu.cmmcode = 'CM03'
          LEFT JOIN CMCOMMONM oo
             ON i.ratediv = oo.divcode AND oo.cmmcode = 'SL50'
          LEFT JOIN CMCOMMONM pp
             ON K.ratediv = pp.divcode AND pp.cmmcode = 'SL50'
/
