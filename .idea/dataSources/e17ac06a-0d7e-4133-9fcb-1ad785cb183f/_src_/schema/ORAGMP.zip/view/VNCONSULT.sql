CREATE VIEW VNCONSULT AS SELECT a.plantcode, -- isnull(a.plantcode,'') as plantcode
		   a.cstdate, -- isnull(a.cstdate,'') as cstdate
		   a.cstno, -- isnull(a.cstno,'') as cstno
		   NVL(b.topdeptcode, ' ') topdeptcode,
		   NVL(b.topdeptname, ' ') topdeptname,
		   NVL(b.predeptcode, ' ') predeptcode,
		   NVL(b.predeptname, ' ') predeptname,
		   NVL(a.deptcode, ' ') deptcode,
		   NVL(b.deptname, ' ') deptname,
		   NVL(b.findname, ' ') findname,
		   NVL(c.positiondiv, ' ') positiondiv,
		   NVL(a.empcode, ' ') empcode,
		   NVL(c.empname, ' ') empname,
		   NVL(j.divname, ' ') jikwi,
		   NVL(a.title, ' ') title,
		   NVL(a.custcode, ' ') custcode,
		   NVL(D.custname, ' ') custname,
		   NVL(D.addr, ' ') addr,
		   NVL(D.ceoname, ' ') ceoname,
		   NVL(D.businessno, ' ') businessno,
		   NVL(a.goodyn, ' ') goodyn,
		   NVL(a.sdt, ' ') sdt,
		   NVL(a.edt, ' ') edt,
		   NVL(a.speyn, ' ') speyn,
		   NVL(a.cstamt, 0) cstamt,
		   NVL(a.supportdiv, ' ') supportdiv,
		   NVL(e.divname, ' ') supportdivnm,
		   NVL(a.targetdept, ' ') targetdept,
		   NVL(f.deptname, ' ') targetdaptnm,
		   NVL(a.paydate, ' ') paydate,
		   NVL(a.accountdiv, ' ') accountdiv,
		   NVL(g.divname, ' ') accountdivnm,
		   NVL(a.promotediv, ' ') promotediv,
		   NVL(h.divname, ' ') promotedivnm,
		   NVL(a.remark, ' ') remark,
		   NVL(a.returnnm, ' ') returnnm,
		   NVL(a.appseq, 0) appseq,
		   NVL(a.statediv, ' ') statediv,
		   NVL(i.divname, ' ') statedivnm,
		   NVL(a.payamt, 0) payamt,
		   NVL(a.ediamt1, 0) ediamt1,
		   NVL(a.ediamt2, 0) ediamt2,
		   NVL(a.ediamt3, 0) ediamt3,
		   NVL(a.etcamt1, 0) etcamt1,
		   NVL(a.etcamt2, 0) etcamt2,
		   NVL(a.etcamt3, 0) etcamt3,
		   NVL(a.otcamt1, 0) otcamt1,
		   NVL(a.otcamt2, 0) otcamt2,
		   NVL(a.otcamt3, 0) otcamt3,
		   NVL(a.colamt1, 0) colamt1,
		   NVL(a.colamt2, 0) colamt2,
		   NVL(a.colamt3, 0) colamt3
	FROM   SLCONSULTM a
		   LEFT JOIN vnDEPT b ON a.deptcode = b.deptcode
		   LEFT JOIN vnEMP c ON a.empcode = c.empcode
		   LEFT JOIN vnCUST D ON a.custcode = D.custcode
		   LEFT JOIN (SELECT *
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'SL67') e
			   ON a.supportdiv = e.divcode
		   LEFT JOIN vnDEPT f ON a.targetdept = f.deptcode
		   LEFT JOIN (SELECT *
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'SL80') g
			   ON a.accountdiv = g.divcode
		   LEFT JOIN (SELECT *
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'SL81') h
			   ON a.promotediv = h.divcode
		   LEFT JOIN (SELECT *
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'SL17') i
			   ON a.statediv = i.divcode
		   LEFT JOIN (SELECT *
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'PS29') j
			   ON c.positiondiv = j.divcode
/
