CREATE VIEW EMPLOYEEMASTER AS SELECT empcode
		  ,empname
		  ,a.deptcode
		  ,b.deptname
		  ,enterdt enteringdate
		  ,retiredt retirementdate
		  ,a.sexdiv
		  ,c.divname sexdivname
		  ,a.positiondiv
		  ,D.divname positiondivname
		  ,classdiv responsibilitydiv
		  ,E.divname responsibilitydivname
		  ,a.empdiv
		  ,f.divname empdivname
		  ,CASE WHEN NVL(a.retiredt, ' ') = ' ' THEN 'N' ELSE 'Y' END retireyn
		  ,a.email
		  ,NVL(a.signdate, '') signdate
		  ,a.pdaid adid
		  ,a.uempcode limsempcode
          ,a.plantcode
	FROM   CMEMPM a
		   LEFT JOIN CMDEPTM b ON a.deptcode = b.deptcode
		   LEFT JOIN CMCOMMONM c
			   ON a.sexdiv = c.divcode
				  AND c.cmmcode = 'CMM37'
		   LEFT JOIN CMCOMMONM D
			   ON a.positiondiv = D.divcode
				  AND D.cmmcode = 'CMM27'
		   LEFT JOIN CMCOMMONM E
			   ON a.classdiv = E.divcode
				  AND E.cmmcode = 'CMM28'
		   LEFT JOIN CMCOMMONM f
			   ON a.empdiv = f.divcode
				  AND f.cmmcode = 'CMM26'
/
