CREATE VIEW PDWHSD AS SELECT rowbarcode,
		   warehousingdiv,
		   warehousingno,
		   warehousingpackseq,
		   packingvesselgross,
		   packwarehouseqty,
		   samplingqty,
		   sampleobjcheck,
		   samplingendcheck,
		   remark,
		   plantcode
	FROM   WarehousingDetail
/
