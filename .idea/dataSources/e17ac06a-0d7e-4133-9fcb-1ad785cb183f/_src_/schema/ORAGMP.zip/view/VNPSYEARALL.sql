CREATE VIEW VNPSYEARALL AS SELECT NVL(a.plantcode, '') AS plantcode,
		   cm.compname AS plantname,
		   NVL(cm.addr1 || ' ' || cm.addr2, '') AS paddress, -- 주소
		   cm.businessno,
		   ROW_NUMBER() OVER (PARTITION BY xx.businessno, a.taxyear ORDER BY xx.businessno, a.empcode) AS seq,
		   NVL(a.taxyear, '') AS taxyear,
		   NVL(a.calcyymm, '') AS calcyymm, --    정산년월
		   NVL(a.yeardiv, '') AS yeardiv, --  0:연말정산, 1:중도퇴사
		   NVL(a.empcode, '') AS empcode,
		   NVL(b.householder, '') AS householder, --    세대주여부
		   NVL(b.liveyn, '1') AS liveyn, --    거주구분        N:거주자, Y:비거주자
		   NVL(b.nationyn, '1') AS nationyn, --    외국인구분       N:내국인, Y:외국인
		   NVL(b.nationcode, '') AS nationcode, --    국적코드
		   NVL(n.divname, '') AS nationname, --    국적명
		   NVL(b.fixtaxyn, '2') AS fixtaxyn, --    외국인단일세율 적용
		   NVL(b.worksdt, '') AS worksdt, --    근무시작일
		   NVL(b.workedt, '') AS workedt, --    근무종료일
		   NVL(b.reducesdt, '') AS reducesdt, --    감면기간시작
		   NVL(b.reduceedt, '') AS reduceedt, --    감면기간종료
		   NVL(d.enterdt, '') AS enterdt, --    입사일자
		   NVL(d.retiredt, '') AS retiredt, --    퇴사일자
		   NVL(d.personid, '') AS personid, --    주민번호
		   NVL(e.topdeptcode, '') AS topdeptcode, --    부서
		   NVL(e.predeptcode, '') AS predeptcode, --    지점
		   d.deptcode, --    팀
		   NVL(e.topdeptname, '') AS topdeptname, --    부서명
		   NVL(e.predeptname, '') AS predeptname, --    지점명
		   NVL(e.deptname, '') AS deptname, --    팀명
		   NVL(e.findname, '') AS findname, --    부서검색
		   d.empname, --    사원명
		   d.workdiv, --    근무지
		   NVL(s.divname, '') AS workdivnm, --    근무지명
		   d.sexdiv, --    성별
		   NVL(h.divname, '') AS sexdivnm,
		   d.empdiv, --    사원구분
		   NVL(i.divname, '') AS empdivnm,
		   d.enterdiv, --    입사구분
		   NVL(p.divname, '') AS enterdivnm,
		   d.positiondiv, --    직위
		   NVL(f.divname, '') AS jikwi,
		   d.gradediv, --    직급
		   NVL(j.divname, '') AS gradedivnm,
		   d.empstep, --    호봉
		   d.responsibilitydiv, --    직종
		   NVL(g.divname, '') AS responsibilitydivnm,
		   d.classdiv, --    직책
		   NVL(d.address || ' ' || d.detailaddress, '') AS address, -- 주소
		   NVL(q.divname, '') AS classdivnm,
		   NVL(a.precompcnt, 0) AS precompcnt, --    종전근무처수
		   NVL(a.payamt, 0) AS payamt, --    주현총액
		   NVL(b.payamt, 0) AS salaryamt, --    급여총액
		   NVL(b.bonusamt, 0) AS bonusamt, --    상여총액
		   NVL(b.bonusinamt, 0) AS bonusinamt, --    인정상여
		   NVL(b.stockamt, 0) AS stockamt, --    주민매수선택권행사이익
		   NVL(b.wooriinamt, 0) AS wooriinamt, --    우리사주조합인출금
		   NVL(b.dretoverlmtamt, 0) AS dretoverlmtamt, --    임원퇴직한도초과액
		   NVL(a.precompamt, 0) AS precompamt, --    종전총액
		   NVL(a.ntaxamt, 0) AS ntaxamt, --    주현비과세
		   NVL(b.ntaxyj, 0) AS ntaxyj, --    연장비과세
		   NVL(b.ntaxeat, 0) AS ntaxeat, --    식사비과세(전산매체 표기 없음)
		   NVL(b.ntaxcar, 0) AS ntaxcar, --    차량비과세(전산매체 표기 없음)
		   NVL(b.ntaxedu, 0) AS ntaxedu, --    학자금비과세
		   NVL(b.ntaxstu, 0) AS ntaxstu, --    연구비과세
		   NVL(b.ntaxfor, 0) AS ntaxfor, --    외국인기술자비과세
		   NVL(b.ntaxbor, 0) AS ntaxbor, --    출산보육비과세
		   NVL(b.ntaxarea, 0) AS ntaxarea, --    벽지비과세
		   NVL(b.ntaxoutside, 0) AS ntaxoutside, --    국외근로비과세
		   NVL(b.ntaxetc, 0) AS ntaxetc, --    지정비과세(기타)
		   NVL(a.precompntaxamt, 0) AS precompntaxamt, --    종전비과세
		   NVL(a.totpayamt, 0) AS totpayamt, --    총급여액
		   NVL(a.totamt, 0) AS totamt, --    총액(비과세포함)
		   NVL(a.incomsub, 0) AS incomsub, --    근로소득공제
		   NVL(a.incomamt, 0) AS incomamt, --    근로소득금액
		   NVL(a.boninsub, 0) AS boninsub, --    본인공제
		   NVL(a.wifesub, 0) AS wifesub, --    배우자공제
		   NVL(a.familycnt, 0) AS familycnt, --    부양가족공제인원
		   NVL(a.familysub, 0) AS familysub, --    부양가족공제
		   NVL(a.oldcnt, 0) AS oldcnt, --    경로우대인원
		   NVL(a.oldsub, 0) AS oldsub, --    경로우대공제
		   NVL(a.obscnt, 0) AS obscnt, --    장애인인원
		   NVL(a.obssub, 0) AS obssub, --    장애인공제
		   NVL(a.womansub, 0) AS womansub, --    부녀자공제
		   NVL(a.singleparentsub, 0) AS singleparentsub, --    한부모공제
		   NVL(a.bringcnt, 0) AS bringcnt, --    자녀양육비인원
		   NVL(a.bringsub, 0) AS bringsub, --    자녀양육비공제
		   NVL(a.borncnt, 0) AS borncnt, --    출산입양인원
		   NVL(a.bornsub, 0) AS bornsub, --    출산입양공제
		   NVL(a.manysoncnt, 0) AS manysoncnt, --    다자녀인원
		   NVL(a.manysonsub, 0) AS manysonsub, --    다자녀공제
		   NVL(a.penssub, 0) AS penssub, --    국민연금공제
		   NVL(a.etcpenssub, 0) AS etcpenssub, --    기타연금공제
		   NVL(a.retiresub, 0) AS retiresub, --    퇴직연금공제
		   NVL(a.insusub, 0) AS insusub, --    건강보험공제
		   NVL(a.hiresub, 0) AS hiresub, --    고용보험공제        계산변경
		   NVL(a.insusecsub, 0) AS insusecsub, --    보장성보험공제        계산변경
		   NVL(a.insuobssub, 0) AS insuobssub, --    장애인보험공제        계산변경
		   NVL(a.mediobssub, 0) AS mediobssub, --    의료비공제-장애인
		   NVL(a.medisub, 0) AS medisub, --    의료비공제
		   NVL(a.eduobssub, 0) AS eduobssub, --    교육비공제-장애인
		   NVL(a.edusub, 0) AS edusub, --    교육비공제
		   NVL(a.houseimsub, 0) AS houseimsub, --    주택임차차임금원리금상환액공제_대출기관
		   NVL(a.houseimgsub, 0) AS houseimgsub, --    주택임차차임금원리금상환액공제_거주자
		   NVL(a.housejusub, 0) AS housejusub, --    장기주택저당차입금이자상환액공제_15년미만
		   NVL(a.houseju15sub, 0) AS houseju15sub, --    장기주택저당차입금이자상환액공제_15~29년
		   NVL(a.houseju30sub, 0) AS houseju30sub, --    장기주택저당차입금이자상환액공제_30년이상
		   NVL(a.housegosub, 0) AS housegosub, --    (2012년 이후 차입분)고정금리？비거치 상환 대출
		   NVL(a.houseetcsub, 0) AS houseetcsub, --    (2012년 이후 차입분)기타 대출
		   NVL(a.housegobiamt151sub, 0) AS housegobiamt151sub, --    장기주택저당차입금이자상환액_2015년 이후_15년 이상_고정금리이면서 비거치상환대출
		   NVL(a.housegobiamt152sub, 0) AS housegobiamt152sub, --    장기주택저당차입금이자상환액_2015년 이후_15년 이상_고정금리이거나 비거치상환대출
		   NVL(a.houseetcamt15sub, 0) AS houseetcamt15sub, --    장기주택저당차입금이자상환액_2015년 이후_15년 이상_그밖의 대출
		   NVL(a.housegobiamt153sub, 0) AS housegobiamt153sub, --    장기주택저당차입금이자상환액_2015년 이후_10년~15년_고정금리이거나 비거치상환대출
		   NVL(a.housemonsub, 0) AS housemonsub, --    월세공제            계산변경
		   NVL(a.givesubno, 0) AS givesubno, --    기부금공제    지정기부금(종교단체 외)
		   NVL(a.givesub, 0) AS givesub, --    기부금공제    지정기부금(종교단체)
		   NVL(a.givejungsub, 0) AS givejungsub, --    기부금공제    정치기부금공제
		   NVL(a.givebubsub, 0) AS givebubsub, --    기부금공제    법정기부금공제
		   NVL(a.givewoorisub, 0) AS givewoorisub, --    기부금공제    우리사주기부금공제
		   NVL(a.givewoo, 0) AS givewoo, --    기부금세액공제 우리사주조합기부금(2015년 이후 기부분)
		   NVL(a.spesubtot, 0) AS spesubtot, --    특별공제계
		   NVL(a.stdsub, 0) AS stdsub, --    표준공제
		   NVL(a.subincomamt, 0) AS subincomamt, --    차감소득금액
		   NVL(a.pensperssub, 0) AS pensperssub, --    개인연금저축공제
		   NVL(a.penssavesub, 0) AS penssavesub, --    연금저축공제
		   NVL(a.mincorpsub, 0) AS mincorpsub, --    소기업/소상공인공제부금
		   NVL(a.housesavesub, 0) AS housesavesub, --    주택마련저축공제-장기주택마련저축        계산변경
		   NVL(a.housebondsub, 0) AS housebondsub, --    주택마련저축공제-청약저축                계산변경
		   NVL(a.houseallsub, 0) AS houseallsub, --    주택마련저축공제-주택청약종합저축        계산변경
		   NVL(a.houseworksub, 0) AS houseworksub, --    주택마련저축공제-근로자주택마련저축        계산변경
		   NVL(a.invcorpsub, 0) AS invcorpsub, --    중소기업창업투자조합출자등 소득공제
		   NVL(a.cardsub, 0) AS cardsub, --    신용카드등사용금액공제
		   NVL(a.woorisub, 0) AS woorisub, --    우리사주조합출연금공제
		   NVL(a.stocksavesub, 0) AS stocksavesub, --    장기주식형저축소득공제
		   NVL(a.empleadsub, 0) AS empleadsub, --    고용유지중소기업근로자공제
		   NVL(a.repaysub, 0) AS repaysub, --    목돈안드는이자상환공제
		   NVL(a.etcsubtot, 0) AS etcsubtot, --    그밖의 소득공제계
		   NVL(a.spesublimitoveramt, 0) AS spesublimitoveramt, --    특별공제종합한도초과액
		   NVL(a.stdtaxamt, 0) AS stdtaxamt, --    종합소득과세표준
		   NVL(a.calctaxamt, 0) AS calctaxamt, --    산출세액
		   NVL(a.taxincsub, 0) AS taxincsub, --    세액감면(소득세법)
		   NVL(a.taxspesub, 0) AS taxspesub, --    세액감면(조특법)
		   NVL(a.taxincspetot, 0) AS taxincspetot, --    세액감면계
		   NVL(a.incomtaxsub, 0) AS incomtaxsub, --    근로소득세액공제
		   NVL(a.taxcombsub, 0) AS taxcombsub, --    을근납세조합공제
		   NVL(a.houseloansub, 0) AS houseloansub, --    주택자금차입금이자세액공제
		   NVL(a.givegosub, 0) AS givegosub, --    정치자금기부금세액공제
		   NVL(a.fortaxsub, 0) AS fortaxsub, --    외국납부세액공제
		   NVL(a.cnreducesub, 0) AS cnreducesub, --    청년취업세액공제
		   NVL(a.taxsubtot, 0) AS taxsubtot, --    세액공제계
		   NVL(a.fixincometax, 0) AS fixincometax, --    결정소득세
		   NVL(a.fixresitax, 0) AS fixresitax, --    결정주민세
		   NVL(a.fixfarmtax, 0) AS fixfarmtax, --    결정농특세
		   NVL(a.fixtaxtot, 0) AS fixtaxtot, --    결정세액계
		   NVL(a.payincometax, 0) AS payincometax, --    기납부소득세
		   NVL(a.payresitax, 0) AS payresitax, --    기납부주민세
		   NVL(a.payfarmtax, 0) AS payfarmtax, --    기납부농특세
		   NVL(a.paytaxtot, 0) AS paytaxtot, --    기납부세액계
		   NVL(a.preincometax, 0) AS preincometax, --    종전소득세
		   NVL(a.preresitax, 0) AS preresitax, --    종전주민세
		   NVL(a.prefarmtax, 0) AS prefarmtax, --    종전농특세
		   NVL(a.pretaxtot, 0) AS pretaxtot, --    종전세액계
		   NVL(a.subincometax, 0) AS subincometax, --    차감소득세
		   NVL(a.subresitax, 0) AS subresitax, --    차감주민세
		   NVL(a.subfarmtax, 0) AS subfarmtax, --    차감농특세
		   NVL(a.subtaxtot, 0) AS subtaxtot, --    차감세액계
		   NVL(a.fixyn, '') AS fixyn, --    마감여부
		   CASE WHEN NVL(a.fixyn, 'N') = 'N' THEN '미마감' ELSE '마감' END AS fixynnm,
		   NVL(d.nationdiv, '') AS nationdiv,
		   NVL(b.cnreduceamt, 0) + NVL(b.cnreduceamt1, 0) + NVL(b.cnreduceamt2, 0) AS cnreduceamt, -- 청년공제대상금액
		   NVL(b.cnreduceamt, 0) AS cnreduceamt100,
		   NVL(b.cnreduceamt1, 0) AS cnreduceamt50,
		   NVL(b.cnreduceamt2, 0) AS cnreduceamt70,
		   NVL(a.spetaxsub, 0) spetaxsub,
		   NVL(a.giveiwalsub, 0) giveiwalsub,
		   NVL(a.longtermstocksub, 0) longtermstocksub,
		   NVL(a.retireamttarget, 0) retireamttarget,
		   NVL(a.penssaveamttarget, 0) penssaveamttarget,
		   NVL(a.insuobsamttarget, 0) insuobsamttarget,
		   NVL(a.insusecamttarget, 0) insusecamttarget,
		   NVL(a.mediobsamttarget, 0) mediobsamttarget,
		   NVL(a.mediamttarget, 0) mediamttarget,
		   NVL(a.eduobsamttarget, 0) eduobsamttarget,
		   NVL(a.eduamttarget, 0) eduamttarget,
		   NVL(a.givejungamttarget, 0) givejungamttarget,
		   NVL(a.givejung1amttarget, 0) givejung1amttarget,
		   NVL(a.givebubamttarget, 0) givebubamttarget,
		   NVL(a.givewooamttarget, 0) givewooamttarget,
		   NVL(a.giveamttargetno, 0) giveamttargetno,
		   NVL(a.giveamttarget, 0) giveamttarget,
		   NVL(a.housemonamttarget, 0) housemonamttarget,
		   NVL(a.applyperiod, 0) applyperiod
	FROM   PSYEARM a
		   JOIN PSYEARBASEM b
			   ON a.taxyear = b.taxyear
				  AND a.empcode = b.empcode
		   LEFT JOIN (SELECT   a.plantcode,
							   a.taxyear,
							   a.empcode,
							   SUM(CASE WHEN subdiv = '11' THEN subamt ELSE 9 END) AS retireamt --    본인/65이상 의료비
																							   ,
							   SUM(CASE WHEN subdiv = '22' THEN subamt ELSE 9 END) AS penssaveamt --    본인/65이상 의료비
					  FROM	   PSYEARSUBM a
					  GROUP BY a.plantcode, a.taxyear, a.empcode) c1
			   ON a.taxyear = c1.taxyear
				  AND a.empcode = c1.empcode
		   JOIN CMEMPM d ON a.empcode = d.empcode
		   LEFT JOIN vndept e ON d.deptcode = e.deptcode
		   LEFT JOIN cmcommonm f
			   ON d.positiondiv = f.divcode
				  AND f.cmmcode = 'ps29'
		   LEFT JOIN cmcommonm g
			   ON d.responsibilitydiv = g.divcode
				  AND g.cmmcode = 'ps07'
		   LEFT JOIN cmcommonm h
			   ON d.sexdiv = h.divcode
				  AND h.cmmcode = 'ps30'
		   LEFT JOIN cmcommonm i
			   ON d.empdiv = i.divcode
				  AND i.cmmcode = 'ps41'
		   LEFT JOIN CMCOMMONM j
			   ON d.gradediv = j.divcode
				  AND j.cmmcode = 'PS01'
		   LEFT JOIN cmcommonm p
			   ON d.enterdiv = p.divcode
				  AND p.cmmcode = 'ps09'
		   LEFT JOIN cmcommonm q
			   ON d.classdiv = q.divcode
				  AND q.cmmcode = 'ps42'
		   LEFT JOIN CMCOMMONM s
			   ON d.workdiv = s.divcode
				  AND s.cmmcode = 'ps26'
		   LEFT JOIN CMCOMMONM n
			   ON b.nationcode = n.divcode
				  AND n.cmmcode = 'CM70'
		   JOIN CMPLANTM xx ON a.plantcode = xx.plantcode
		   LEFT JOIN CMCOMPM cm ON xx.compcode = cm.compcode
/
