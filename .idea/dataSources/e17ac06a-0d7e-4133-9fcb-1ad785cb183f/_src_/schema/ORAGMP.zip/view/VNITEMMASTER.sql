CREATE VIEW VNITEMMASTER AS SELECT a.itemcode itemcode
		  , --품목코드
		   a.itemdiv itemdiv
		  , --품목구분
		   b.managecode managecode
		  , --품목구분(시스템)
		   b.divname itemdivname
		  , --품목구분명(*)
		   a.itemname itemkorname
		  , --품목명(국문)
		   a.itemsname itemshortname
		  , --품목명(약명)
		   a.itemename itemengname
		  , --품목명(영문)
		   a.standarddiv standarddiv
		  , --시험규격코드
		   c.divname standarddivname
		  , --시험규격(*)
		   a.validityperiod validityperiod
		  , --유통기한(월)
		   a.unit itemunit
		  , --단위코드
		   D.divname itemunitname
		  , --단위(*)
		   a.keepingmethod keepingmethod
		  , --보관방법
		   a.itembranch itembranch
		  , --품목분류코드
		   E.divname itembranchname
		  , --품목분류(*)
		   a.warehouse keepingwarehouse
		  , --보관창고코드
		   f.divname keepingwarehousename
		  , --보관창고(*)
		   a.internaldiv internaldiv
		  , --국내외구분코드(원자재/상품)
		   G.divname internaldivname
		  , --국내외구분(*)
		   a.enteringrackdiv enteringrackdiv
		  , --입고랙종류코드(원자재/상품)
		   h.divname enteringrackdivname
		  , --입고랙종류(*)
		   a.enteringrackqty enteringrackqty
		  , --입고랙적재량(원자재/상품)
		   a.testcheck testcheck
		  , --시험여부
		   a.safeqty safestockqty
		  , --안전재고량
		   a.properstockqty properstockqty
		  , --적정재고량
		   a.buyperiod buyperiod
		  , --구매기간
		   a.usediv usediv
		  , --사용여부
		   CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname
		  , --사용여부(*)
		   notproductdiv notusediv
		  , --미사용원인코드
		   i.divname notusedivname
		  , --미사용원인(*)
		   NULL revisionno
		  , --관리번호(제조제품)
		   NULL contentqty
		  , --함량Num(제조제품)
		   NULL contentunit
		  , --함량단위코드(제조제품)
		   NULL contentunitname
		  , --함량단위(*)
		   NULL contentqtyname
		  , --함량Text(*)
		   NULL BATCHSIZE
		  , --배치크기Num(제조제품)
		   NULL batchsizename
		  , --배치크기Text(*)
		   NULL itemformdiv
		  , --제품유형코드(제조제품)
		   NULL itemformdivname
		  , --제품유형(*)
		   NULL maxmanageyield
		  , --관리수율(상한)(제조제품)
		   NULL minmanageyield
		  , --관리수율(하한)(제조제품)
		   NULL makingcost
		  , --제조원가(제조,포장)
		   NULL docuno
		  , --문서번호(제조,포장)
		   NULL productcheck
		  , --생산여부(제조,포장)
		   NULL notproductdiv
		  , --미생산원인코드(제조,포장)
		   NULL notproductdivname
		  , --미생산원인(*)
		   NULL typicalitemcode
		  , --대표제품코드(포장제품)
		   NULL typicalitemname
		  , --대표제품명(*)
		   NULL packingunitqty
		  , --포장단위량Num(포장제품)
		   NULL packingunitqtyname
		  , --포장단위Text(*)
		   NULL packingtypediv
		  , --포장타입코드(포장제품)
		   NULL packingtypedivname
		  , --포장타입(*)
		   NULL typicalpackingcheck
		  , --포장대표여부(포장제품)
		   NULL cartondiv
		  , --지함종류코드(포장제품)
		   NULL cartondivname
		  , --지함종류(*)
		   NULL cartonqty
		  , --지함적재량(포장제품)
		   NULL barcode
		  , --바코드(포장제품)
		   NULL soprevisionid
		  , --표준운영절차관리번호(추가080424)
		   NULL itemrevisionid
		  , --품목허가관리번호(추가080424)
		   NULL teststandardid
		  , --시험규격관리번호(추가080424)
		   NULL prescriptionid
		  , --처방전 관리번호(추가080424)
		   a.abc abc
		  ,a.buyunit
		  ,a.customcode
		  ,a.orderprice
		  ,a.exchangeunit
		  ,a.paydiv
		  ,a.offer
          ,a.plantcode
	FROM   CMITEMM a
		   LEFT JOIN CommonMaster b
			   ON b.cmmcode = 'CMM01'
				  AND b.divcode = a.itemdiv
		   LEFT JOIN CommonMaster c
			   ON c.cmmcode = 'LMM06'
				  AND c.divcode = a.standarddiv
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'CMM02'
				  AND D.divcode = a.unit
		   LEFT JOIN CommonMaster E
			   ON E.cmmcode = 'MPM09'
				  AND E.divcode = a.itembranch
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'MPM11'
				  AND f.divcode = a.warehouse
		   LEFT JOIN CommonMaster G
			   ON G.cmmcode = 'MPM15'
				  AND G.divcode = a.internaldiv
		   LEFT JOIN CommonMaster h
			   ON h.cmmcode = 'MPM08'
				  AND h.divcode = a.enteringrackdiv
		   LEFT JOIN CommonMaster i
			   ON i.cmmcode = 'MPM12'
				  AND i.divcode = a.notproductdiv
	WHERE  NVL(a.usediv, 'N') = 'Y'
		   AND itemdiv IN ('01', '02') --사용구분에 사용중인 항목만 조회된다.
	UNION
	--제품표준서 반영
	SELECT a.itemcode itemcode
		  , --품목코드
		   c.divcode itemdiv
		  , --품목구분
		   c.managecode managecode
		  , --품목구분(시스템)
		   c.divname itemdivname
		  , --품목구분명
		   b.itemkorname itemkorname
		  , --품목명(국문)
		   b.itemshortname itemshortname
		  , --품목명(약명)
		   b.itemengname itemengname
		  , --품목명(영문)
		   b.standarddiv standarddiv
		  , --시험규격코드
		   D.divname standarddivname
		  , --시험규격명
		   b.validityperiod validityperiod
		  , --유통기한(월)
		   b.itemunit itemunit
		  , --단위코드
		   E.divname itemunitname
		  , --단위명
		   b.keepingmethod keepingmethod
		  , --보관방법
		   b.itemdiv itembranch
		  , --품목분류코드
		   f.divname itembranchname
		  , --품목분류명
		   b.keepingwarehouse keepingwarehouse
		  , --보관창고코드
		   G.divname keepingwarehousename
		  , --보관창고명
		   NULL internaldiv
		  , --국내외구분코드(원자재/상품)
		   NULL internaldivname
		  , --국내외구분(*)
		   NULL enteringrackdiv
		  , --입고랙종류코드(원자재/상품)
		   NULL enteringrackdivname
		  , --입고랙종류(*)
		   NULL enteringrackqty
		  , --입고랙적재량(원자재/상품)
		   'Y' testcheck
		  , --시험여부
		   NULL safestockqty
		  , --안전재고량
		   NULL properstockqty
		  , --적정재고량
		   NULL buyperiod
		  , --구매기간
		   b.usediv usediv
		  , --사용여부
		   CASE b.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname
		  , --사용여부(*)
		   NULL notusediv
		  , --미사용원인코드
		   NULL notusedivname
		  , --미사용원인(*)
		   b.revisionno revisionno
		  , --관리번호(제조제품)--수정되여야 한다.
		   b.contentqty contentqty
		  , --단위중량(제조제품)
		   b.contentunit contentunit
		  , --단위중량단위코드(제조제품)
		   h.divname contentunitname
		  , --단위중량단위(*)
		   fnNumericToString(b.contentqty, 'S') || h.divname contentqtyname
		  , --함량Text(*)
		   b.BATCHSIZE BATCHSIZE
		  , --배치크기Num(제조제품)
		   fnNumericToString(b.BATCHSIZE, 'S') || E.divname batchsizename
		  , --배치크기Text(*)
		   b.itemformdiv itemformdiv
		  , --제품유형코드(제조제품)
		   i.divname itemformdivname
		  , --제품유형(*)
		   b.maxmanageyield maxmanageyield
		  , --관리수율(상한)(제조제품)
		   b.minmanageyield minmanageyield
		  , --관리수율(하한)(제조제품)
		   b.makingcost makingcost
		  , --제조원가(제조,포장)
		   b.docuno docuno
		  , --문서번호(제조,포장)
		   b.productcheck productcheck
		  , --생산여부(제조,포장)
		   b.notproductdiv notproductdiv
		  , --미생산원인코드(제조,포장)
		   j.divname notproductdivname
		  , --미생산원인(*)
		   NULL typicalitemcode
		  , --대표제품코드(포장제품)
		   NULL typicalitemname
		  , --대표제품명(*)
		   NULL packingunitqty
		  , --포장단위량Num(포장제품)
		   NULL packingunitqtyname
		  , --포장단위Text(*)
		   NULL packingtypediv
		  , --포장타입코드(포장제품)
		   NULL packingtypedivname
		  , --포장타입(*)
		   NULL typicalpackingcheck
		  , --포장대표여부(포장제품)
		   NULL cartondiv
		  , --지함종류코드(포장제품)
		   NULL cartondivname
		  , --지함종류(*)
		   NULL cartonqty
		  , --지함적재량(포장제품)
		   NULL barcode
		  , --바코드(포장제품)
		   a.soprevisionid soprevisionid
		  , --표준운영절차관리번호(추가080424)
		   a.itemrevisionid itemrevisionid
		  , --품목허가관리번호(추가080424)
		   a.teststandardid teststandardid
		  , --시험규격관리번호(추가080424)
		   a.prescriptionid prescriptionid
		  , --처방전 관리번호(추가080424)
		   b.abc abc
		  ,NULL buyunit
		  ,NULL customcode
		  ,NULL orderprice
		  ,NULL exchangeunit
		  ,NULL paydiv
		  ,NULL offer
          ,a.plantcode
	FROM   GoodsStandardRevision a
		   JOIN MakingGoodsMaster b
			   ON a.itemcode = b.itemcode
				  AND a.itemrevisionid = b.revisionno
		   JOIN (SELECT divcode
					   ,divname
					   ,managecode
				 FROM	vnCommonMaster
				 WHERE	cmmcode = 'CMM01'
						AND managecode = '03') c
			   ON a.itemcode NOT IN (c.divcode)
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'LMM06'
				  AND b.standarddiv = D.divcode
		   LEFT JOIN CommonMaster E
			   ON E.cmmcode = 'CMM02'
				  AND b.itemunit = E.divcode
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'MPM23'
				  AND b.itemdiv = f.divcode
		   LEFT JOIN CommonMaster G
			   ON G.cmmcode = 'MPM11'
				  AND b.keepingwarehouse = G.divcode
		   LEFT JOIN CommonMaster h
			   ON h.cmmcode = 'CMM02'
				  AND b.contentunit = h.divcode
		   LEFT JOIN CommonMaster i
			   ON i.cmmcode = 'MPM29'
				  AND b.itemformdiv = i.divcode
		   LEFT JOIN CommonMaster j
			   ON j.cmmcode = 'MPM24'
				  AND b.notproductdiv = j.divcode
	WHERE  a.approvalcheck = 'Y' -- 승인완료된 항목조회
		   AND a.usediv = 'Y' -- 사용중인 항목조회
	UNION
	--포장제품

	SELECT a.itemcode itemcode
		  , --품목코드
		   b.divcode itemdiv
		  , --품목구분
		   b.managecode managecode
		  , --품목구분(시스템)
		   b.divname itemdivname
		  , --품목구분명(*)
		   a.itemkorname itemkorname
		  , --품목명(국문)
		   a.itemshortname itemshortname
		  , --품목명(약명)
		   a.itemengname itemengname
		  , --품목명(영문)
		   c.standarddiv standarddiv
		  , --시험규격코드
		   D.divname standarddivname
		  , --시험규격(*)
		   c.validityperiod validityperiod
		  , --유통기한(월)
		   c.itemunit itemunit
		  , --단위코드
		   E.divname itemunitname
		  , --단위(*)
		   c.keepingmethod keepingmethod
		  , --보관방법
		   c.itemdiv itembranch
		  , --품목분류코드
		   f.divname itembranchname
		  , --품목분류(*)
		   a.keepingwarehouse keepingwarehouse
		  , --보관창고코드
		   G.divname keepingwarehousename
		  , --보관창고(*)
		   NULL internaldiv
		  , --국내외구분코드(원자재/상품)
		   NULL internaldivname
		  , --국내외구분(*)
		   a.enteringrackdiv enteringrackdiv
		  , --입고랙종류코드(원자재/상품)
		   h.divname enteringrackdivname
		  , --입고랙종류(*)
		   a.enteringrackqty enteringrackqty
		  , --입고랙적재량(원자재/상품)
		   'Y' testcheck
		  , --시험여부
		   a.safestockqty safestockqty
		  , --안전재고량
		   a.properstockqty properstockqty
		  , --적정재고량
		   NULL buyperiod
		  , --구매기간
		   c.usediv usediv
		  , --사용여부
		   CASE c.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname
		  , --사용여부(*)
		   NULL notusediv
		  , --미사용원인코드
		   NULL notusedivname
		  , --미사용원인(*)
		   c.revisionno revisionno
		  , --관리번호(제조제품)
		   c.contentqty contentqty
		  , --함량Num(제조제품)
		   c.contentunit contentunit
		  , --함량단위코드(제조제품)
		   i.divname contentunitname
		  , --함량단위(*)
		   fnNumericToString(c.contentqty, 'S') || i.divname contentqtyname
		  , --함량Text(*)
		   c.BATCHSIZE BATCHSIZE
		  , --배치크기Num(제조제품)
		   fnNumericToString(c.BATCHSIZE, 'S') || E.divname batchsizename
		  , --배치크기Text(*)
		   NULL itemformdiv
		  , --제품유형코드(제조제품)
		   NULL itemformdivname
		  , --제품유형(*)
		   c.maxmanageyield maxmanageyield
		  , --관리수율(상한)(제조제품)
		   c.minmanageyield minmanageyield
		  , --관리수율(하한)(제조제품)
		   NULL makingcost
		  , --제조원가(제조,포장)
		   a.docuno docuno
		  , --문서번호(제조,포장)
		   a.productcheck productcheck
		  , --생산여부(제조,포장)
		   a.notproductdiv notproductdiv
		  , --미생산원인코드(제조,포장)
		   j.divname notproductdivname
		  , --미생산원인(*)
		   a.typicalitemcode typicalitemcode
		  , --대표제품코드(포장제품)
		   c.itemkorname typicalitemname
		  , --대표제품명(*)
		   a.packingunitqty packingunitqty
		  , --포장단위량Num(포장제품)
		   fnNumericToString(a.packingunitqty, 'S') || E.divname packingunitqtyname
		  , --포장단위Text(*)
		   a.packingtypediv packingtypediv
		  , --포장타입코드(포장제품)
		   K.divname packingtypedivname
		  , --포장타입(*)
		   a.typicalpackingcheck typicalpackingcheck
		  , --포장대표여부(포장제품)
		   a.cartondiv cartondiv
		  , --지함종류코드(포장제품)
		   l.divname cartondivname
		  , --지함종류(*)
		   a.cartonqty cartonqty
		  , --지함적재량(포장제품)
		   a.barcode barcode
		  , --바코드(포장제품)
		   NULL soprevisionid
		  , --표준운영절차관리번호(추가080424)
		   NULL itemrevisionid
		  , --품목허가관리번호(추가080424)
		   NULL teststandardid
		  , --시험규격관리번호(추가080424)
		   NULL prescriptionid
		  , --처방전 관리번호(추가080424)
		   NULL abc
		  ,a.buyunit
		  ,a.customcode
		  ,a.orderprice
		  ,a.exchangeunit
		  ,a.paydiv
		  ,a.offer
          ,a.plantcode
	FROM   PackingGoodsMaster a
		   LEFT JOIN (SELECT divcode
							,divname
							,managecode
					  FROM	 vnCommonMaster
					  WHERE  cmmcode = 'CMM01'
							 AND managecode = '04') b
			   ON a.itemcode NOT IN (b.divcode)
		   JOIN MakingGoodsMaster c ON a.typicalitemcode = c.itemcode
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'LMM06'
				  AND D.divcode = c.standarddiv
		   LEFT JOIN CommonMaster E
			   ON E.cmmcode = 'CMM02'
				  AND E.divcode = c.itemunit
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'MPM23'
				  AND f.divcode = c.itemdiv
		   LEFT JOIN CommonMaster G
			   ON G.cmmcode = 'MPM11'
				  AND G.divcode = a.keepingwarehouse
		   LEFT JOIN CommonMaster h
			   ON h.cmmcode = 'MPM08'
				  AND h.divcode = a.enteringrackdiv
		   LEFT JOIN CommonMaster i
			   ON i.cmmcode = 'CMM02'
				  AND i.divcode = c.contentunit
		   LEFT JOIN CommonMaster j
			   ON j.cmmcode = 'MPM24'
				  AND j.divcode = a.notproductdiv
		   LEFT JOIN CommonMaster K
			   ON K.cmmcode = 'MPM72'
				  AND K.divcode = a.packingtypediv
		   LEFT JOIN CommonMaster l
			   ON l.cmmcode = 'MPM67'
				  AND l.divcode = a.cartondiv
	UNION
	--상품
	SELECT a.itemcode itemcode
		  , --품목코드
		   b.divcode itemdiv
		  , --품목구분
		   b.managecode managecode
		  , --품목구분(시스템)
		   b.divname itemdivname
		  , --품목구분명(*)
		   a.itemkorname itemkorname
		  , --품목명(국문)
		   a.itemshortname itemshortname
		  , --품목명(약명)
		   a.itemengname itemengname
		  , --품목명(영문)
		   a.standarddiv standarddiv
		  , --시험규격코드
		   G.divname standarddivname
		  , --시험규격(*)
		   a.validityperiod validityperiod
		  , --유통기한(월)
		   a.itemunit itemunit
		  , --단위코드
		   c.divname itemunitname
		  , --단위(*)
		   NULL keepingmethod
		  , --보관방법
		   NULL itembranch
		  , --품목분류코드
		   NULL itembranchname
		  , --품목분류(*)
		   a.keepingwarehouse keepingwarehouse
		  , --보관창고코드
		   D.divname keepingwarehousename
		  , --보관창고(*)
		   a.internaldiv internaldiv
		  , --국내외구분코드(원자재/상품)
		   E.divname internaldivname
		  , --국내외구분(*)
		   a.enteringrackdiv enteringrackdiv
		  , --입고랙종류코드(원자재/상품)
		   f.divname enteringrackdivname
		  , --입고랙종류(*)
		   a.enteringrackqty enteringrackqty
		  , --입고랙적재량(원자재/상품)
		   'N' testcheck
		  , --시험여부
		   a.safestockqty safestockqty
		  , --안전재고량
		   a.properstockqty properstockqty
		  , --적정재고량
		   a.buyperiod buyperiod
		  , --구매기간
		   a.usediv usediv
		  , --사용여부
		   CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname
		  , --사용여부(*)
		   NULL notusediv
		  , --미사용원인코드
		   NULL notusedivname
		  , --미사용원인(*)
		   NULL revisionno
		  , --관리번호(제조제품)
		   NULL contentqty
		  , --함량Num(제조제품)
		   NULL contentunit
		  , --함량단위코드(제조제품)
		   NULL contentunitname
		  , --함량단위(*)
		   NULL contentqtyname
		  , --함량Text(*)
		   NULL BATCHSIZE
		  , --배치크기Num(제조제품)
		   NULL batchsizename
		  , --배치크기Text(*)
		   NULL itemformdiv
		  , --제품유형코드(제조제품)
		   NULL itemformdivname
		  , --제품유형(*)
		   NULL maxmanageyield
		  , --관리수율(상한)(제조제품)
		   NULL minmanageyield
		  , --관리수율(하한)(제조제품)
		   NULL makingcost
		  , --제조원가(제조,포장)
		   NULL docuno
		  , --문서번호(제조,포장)
		   NULL productcheck
		  , --생산여부(제조,포장)
		   NULL notproductdiv
		  , --미생산원인코드(제조,포장)
		   NULL notproductdivname
		  , --미생산원인(*)
		   NULL typicalitemcode
		  , --대표제품코드(포장제품)
		   NULL typicalitemname
		  , --대표제품명(*)
		   NULL packingunitqty
		  , --포장단위량Num(포장제품)
		   fnNumericToString(a.packingcnt, 'S') || c.divname packingunitqtyname
		  , --포장단위Text(*)
		   NULL packingtypediv
		  , --포장타입코드(포장제품)
		   NULL packingtypedivname
		  , --포장타입(*)
		   NULL typicalpackingcheck
		  , --포장대표여부(포장제품)
		   NULL cartondiv
		  , --지함종류코드(포장제품)
		   NULL cartondivname
		  , --지함종류(*)
		   NULL cartonqty
		  , --지함적재량(포장제품)
		   NULL barcode
		  , --바코드(포장제품)
		   NULL soprevisionid
		  , --표준운영절차관리번호(추가080424)
		   NULL itemrevisionid
		  , --품목허가관리번호(추가080424)
		   NULL teststandardid
		  , --시험규격관리번호(추가080424)
		   NULL prescriptionid
		  , --처방전 관리번호(추가080424)
		   a.abc abc
		  ,a.buyunit
		  ,a.customcode
		  ,a.orderprice
		  ,a.exchangeunit
		  ,a.paydiv
		  ,a.offer
          ,a.plantcode
	FROM   ProductMaster a
		   LEFT JOIN (SELECT divcode
							,divname
							,managecode
					  FROM	 vnCommonMaster
					  WHERE  cmmcode = 'CMM01'
							 AND managecode = '05') b
			   ON a.itemcode NOT IN (b.divcode)
		   LEFT JOIN CommonMaster c
			   ON c.cmmcode = 'CMM02'
				  AND c.divcode = a.itemunit
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'MPM11'
				  AND D.divcode = a.keepingwarehouse
		   LEFT JOIN CommonMaster E
			   ON E.cmmcode = 'MPM15'
				  AND E.divcode = a.internaldiv
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'MPM08'
				  AND f.divcode = a.enteringrackdiv
		   LEFT JOIN CommonMaster G
			   ON G.cmmcode = 'LMM06'
				  AND G.divcode = a.standarddiv
/
