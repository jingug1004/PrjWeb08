CREATE VIEW VNEMPCOLS AS (SELECT a.plantcode, -- NVL(a.plantcode, '') AS plantcode,
			a.coldate AS orderdate, -- NVL(a.coldate, '') AS orderdate,
			a.colseq AS orderseq, -- NVL(a.colseq, '') AS orderseq,
			a.colno AS orderno, -- NVL(a.colno, '') AS orderno,
			NVL(a.saldiv, '') AS saldiv,
			SUBSTR(NVL(a.appdate, ''), 1, 7) AS yymm,
			CASE WHEN NVL(a.tasooyn, 'N') = 'Y' THEN NVL(SL18.divname, '') || '(타)' ELSE NVL(SL18.divname, '') END AS saldivnm,
			NVL(a.tasooyn, 'N') AS tasooyn,
			NVL(a.coldiv, '') AS coldiv,
			NVL(a.orderdiv, '') AS orderdiv,
			a.custcode, -- NVL(a.custcode, '') AS custcode,
			NVL(b.custname, '') AS custname,
			NVL(b.ceoname, '') AS ceoname,
			NVL(b.businessno, '') AS businessno,
			NVL(b.telno, '') AS telno,
			NVL(b.faxno, '') AS faxno,
			NVL(b.POST, '') AS POST,
			NVL(b.addr1, '') AS addr1,
			NVL(b.addr2, '') AS addr2,
			NVL(b.addr1, '') || ' ' || NVL(b.addr2, '') AS addr,
			NVL(h.topdeptcode, '') AS topdeptcode,
			NVL(h.topdeptname, '') AS topdeptname,
			NVL(h.predeptcode, '') AS predeptcode,
			NVL(h.predeptname, '') AS predeptname,
			a.deptcode, -- NVL(a.deptcode, '') AS deptcode,
			NVL(h.findname, '') AS findname,
			NVL(h.deptname, '') AS deptname,
			a.empcode, -- NVL(a.empcode, '') AS empcode,
			NVL(i.positiondiv, '') AS positiondiv,
			NVL(i.empname, '') AS empname,
			NVL(U.divname, '') AS jikwi,
			a.ecustcode, -- NVL(a.ecustcode, '') AS ecustcode,
			NVL(c.custname, '') AS ecustname,
			NVL(j.topdeptcode, '') AS etopdeptcode,
			NVL(j.topdeptname, '') AS etopdeptname,
			NVL(j.predeptcode, '') AS epredeptcode,
			NVL(j.predeptname, '') AS epredeptname,
			a.edeptcode, -- NVL(a.edeptcode, '') AS edeptcode,
			NVL(j.findname, '') AS efindname,
			NVL(j.deptname, '') AS edeptname,
			a.eempcode, -- NVL(a.eempcode, '') AS eempcode,
			NVL(K.positiondiv, '') AS epositiondiv,
			NVL(K.empname, '') AS eempname,
			NVL(v.divname, '') AS ejikwi,
			NVL(a.utdiv, '') AS utdiv,
			NVL(o.divname, '') AS utdivnm,
			NVL(a.eutdiv, '') AS eutdiv,
			NVL(P.divname, '') AS eutdivnm,
			a.appdate, -- NVL(a.appdate, '') AS appdate,
			a.statediv, -- NVL(a.statediv, '') AS statediv,
			NVL(l.divname, '') AS statedivnm,
			NVL(a.remark, '') AS remark,
			NVL(a.enuriyn, '') AS enuriyn,
			CASE
				WHEN a.saldiv = 'C01'
					 AND a.coldiv IN ('01', '02')
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS cashcol, --현금수금
			-- CASE WHEN a.saldiv = 'CC' AND a.coldiv IN ('02') THEN NVL(a.colamt, 0)
			--ELSE 0 END AS changecol,    --물품대체
			CASE
				WHEN a.saldiv = 'C01'
					 AND SUBSTR(a.coldiv, 1, 1) = '1'
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS bankcol, --은행입금
			CASE
				WHEN a.saldiv = 'C01'
					 AND SUBSTR(a.coldiv, 1, 1) = '2'
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS cardcol, --카드수금
			CASE
				WHEN a.saldiv = 'C01'
					 AND SUBSTR(a.coldiv, 1, 1) = '3'
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS billcol, --어음수금
			CASE
				WHEN a.saldiv = 'C01'
					 AND a.coldiv > '39'
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS etccol, --기타수금
			NVL(a.colamt, 0) AS colamt,
			NVL(a.custprtyn, '') AS custprtyn,
			NVL(divmonth, 0) AS divmonth,
			CASE
				WHEN a.coldiv LIKE '3%'
				THEN
					NVL(a.paybank, '') --지금은행
				WHEN SUBSTR(a.coldiv, 1, 1) = '1'
				THEN
					NVL(s.accremark, '') --계좌은행
				WHEN (SUBSTR(a.coldiv, 1, 1) = '2')
					 AND (NVL(a.divmonth, 0) = 0)
				THEN
					NVL(AC17.divname, '') --카드사
				WHEN (SUBSTR(a.coldiv, 1, 1) = '2')
					 AND (NVL(a.divmonth, 0) > 0)
				THEN
					NVL(AC17.divname, '') || ' ' || TO_CHAR(divmonth) || '개월' --카드사
				ELSE
					''
			END
				AS gubun,
			NVL(a.billno, '') AS billno,
			NVL(a.accountno, '') AS accountno,
			CASE WHEN a.coldiv LIKE '3%' THEN NVL(a.issdate, '') ELSE '' END AS issdate,
			CASE WHEN a.coldiv LIKE '3%' THEN NVL(a.expdate, '') ELSE '' END AS expdate,
			CASE WHEN a.coldiv LIKE '3%' THEN NVL(a.discntdate, '') ELSE '' END AS discntdate,
			NVL(a.issempnm, '') AS issempnm,
			NVL(a.paybank, '') AS paybank,
			NVL(a.cardcomp, '') AS cardcomp,
			NVL(AC17.divname, '') AS cardcompnm,
			NVL(a.cardno, '') AS cardno,
			NVL(a.cardokno, '') AS cardokno,
			NVL(s.accremark, '') AS accountbanknm,
			NVL(a.pda, '') AS pda,
			NVL(a.colnolink, '') AS colnolink,
			NVL(b.areadiv, '') AS areadiv,
			NVL(M.divname, '') AS areadivnm,
			NVL(c.areadiv, '') AS eareadiv,
			NVL(n.divname, '') AS eareadivnm,
			NVL(i.retiredt, '') AS retiredt,
			NVL(K.retiredt, '') AS eretiredt,
			NVL(h.deptgroup, '') AS deptgroup,
			NVL(j.deptgroup, '') AS edeptgroup,
			NVL(b.custmajorcode, '') AS custmajorcode,
			h.seqtopdeptcode,
			h.seqpredeptcode,
			h.seqdeptcode,
			j.seqtopdeptcode AS eseqtopdeptcode,
			j.seqpredeptcode AS eseqpredeptcode,
			j.seqdeptcode AS eseqdeptcode
	 FROM	vnColsEnd a
			JOIN CMCUSTM b ON a.custcode = b.custcode
			JOIN CMCUSTM c ON a.ecustcode = c.custcode
			JOIN vndept h ON b.deptcode = h.deptcode
			JOIN CMEMPM i ON b.empcode = i.empcode
			JOIN vndept j ON c.deptcode = j.deptcode
			JOIN CMEMPM K ON c.empcode = K.empcode
			LEFT JOIN CMCOMMONM l
				ON a.statediv = l.divcode
				   AND l.cmmcode = 'SL17'
			LEFT JOIN CMCOMMONM o
				ON a.utdiv = o.divcode
				   AND o.cmmcode = 'CM15'
			LEFT JOIN CMCOMMONM P
				ON a.eutdiv = P.divcode
				   AND P.cmmcode = 'CM15'
			LEFT JOIN CMCOMMONM SL18
				ON a.coldiv = SL18.divcode
				   AND SL18.cmmcode = 'SL18'
			LEFT JOIN CMCOMMONM AC17
				ON a.cardcomp = AC17.divcode
				   AND AC17.cmmcode = 'AC17'
			LEFT OUTER JOIN CMACCOUNTM s ON a.accountno = s.accountno
			LEFT OUTER JOIN cmbankm T ON s.bankcode = T.bankcode
			LEFT JOIN CMCOMMONM U
				ON i.positiondiv = U.divcode
				   AND U.cmmcode = 'PS29'
			LEFT JOIN CMCOMMONM v
				ON K.positiondiv = v.divcode
				   AND v.cmmcode = 'PS29'
			LEFT JOIN CMCOMMONM M
				ON b.areadiv = M.divcode
				   AND M.cmmcode = 'CM03'
			LEFT JOIN CMCOMMONM n
				ON c.areadiv = n.divcode
				   AND n.cmmcode = 'CM03')
/
