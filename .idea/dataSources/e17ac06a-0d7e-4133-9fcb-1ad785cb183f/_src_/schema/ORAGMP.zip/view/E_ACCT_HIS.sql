CREATE VIEW E_ACCT_HIS AS SELECT RTRIM(NVL(b.accountno, a.acct_no)) ACCOUNTNO, -- 계좌번호
		   fnstuff(fnstuff(RTRIM(a.acct_txday), 5, 0, '-'), 8, 0, '-') ACCT_TXDAY, -- 거래일자
		   fnstuff(fnstuff(RTRIM(a.acct_txtime), 3, 0, ':'), 6, 0, ':') ACCT_TXTIME, -- 거래시간
		   RTRIM(a.jeokyo) JEOKYO, -- 적요
		   a.tx_amt TX_AMT -- 입금액
	FROM   IBK_ACCT_HIS a LEFT JOIN CMACCOUNTM b ON a.acct_no = REPLACE(b.accountno, '-', '')
	WHERE  a.inout_gubun = '2'
/
