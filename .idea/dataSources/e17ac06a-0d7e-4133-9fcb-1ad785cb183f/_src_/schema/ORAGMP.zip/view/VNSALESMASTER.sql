CREATE VIEW VNSALESMASTER AS (SELECT a.plantcode,
			a.orderno,
			a.yymm yymm, -- 주문일자
			b.seq,
			a.saldiv saldiv,
			a.datadiv datadiv, -- 영업구분 / 자료구분
			'' coldiv,
			a.orderdiv orderdiv, -- 주문서구분
			a.custcode,
			'N' tasooyn,
			a.ecustcode,
			a.utdiv utdiv, -- 간납담당자 / 유통구분
			a.utdiv eutdiv,
			a.bnorderno bnorderno, -- 간납유통구분 / 상계주문번호
			a.appdate,
			a.statediv,
			b.itemcode,
			NVL(b.salqty, 0) salqty, -- 제품코드 / 판매수량
			NVL(b.givqty, 0) givqty,
			NVL(b.drugprc, 0) drugprc,
			NVL(b.drugamt, 0) drugamt, -- 기준가 / 기준금액
			NVL(b.salprc, 0) salprc, -- 제조할증금액 / 출하단가
			NVL(b.salamt, 0) salamt,
			NVL(b.salvat, 0) salvat, -- 판매금액 / 부가세
			NVL(b.totamt, 0) totamt,
			0 colamt,
			'' accountno,
			'' billno, --위해 존재..
			'' issdate,
			'' expdate,
			'' paybank,
			'' issempnm,
			'' cardcomp,
			'' cardno,
			'' cardokno,
			0 divmonth,
			'' discntdate,
			'' gubun,
			c.deptcode,
			c.empcode,
			d.deptcode edeptcode,
			d.empcode eempcode,
			c.custname,
			d.custname ecustname,
			b.aftamt,
			b.totamt1,
			b.befrate,
			b.aftrate,
			b.salprc1,
			c.custmajorcode custmajorcode,
			d.custmajorcode ecustmajorcode,
			a.remark
	 FROM	SLORDM a --주문마스터
			LEFT JOIN SLORDD b --주문서제품내역
							  ON a.orderno = b.orderno
			LEFT JOIN CMCUSTM c ON a.custcode = c.custcode
			LEFT JOIN CMCUSTM d ON a.ecustcode = d.custcode
	 WHERE	a.statediv = '09' --반려가 아닌거
	 UNION ALL
	 SELECT a.plantcode,
			a.colno,
			SUBSTR(a.appdate, 1, 7) yymm, -- 전표일자
			0 seq, -- 전표순번(번호)
			a.saldiv saldiv,
			'' datadiv, -- 영업구분(판매) /
			a.coldiv coldiv,
			a.orderdiv orderdiv, -- 수금구분 / 주문구분
			a.custcode,
			NVL(tasooyn, 'N') tasooyn,
			a.ecustcode,
			a.utdiv utdiv, -- 간납담당자 / 유통구분
			a.eutdiv eutdiv,
			'' bnorderno, -- 간납유통구분 /
			a.appdate,
			a.statediv,
			'' itemcode,
			0 salqty,
			0 givqty,
			0 drugprc,
			0 drugamt,
			0 salprc,
			0 salamt,
			0 salvat,
			0 totamt,
			NVL(a.colamt, 0) colamt,
			a.accountno accountno,
			a.billno billno,
			a.issdate issdate,
			a.expdate expdate, -- 발행일자 / 만기일자
			a.paybank paybank,
			a.issempnm issempnm, -- 지급은행 / 발행인
			a.cardcomp cardcomp,
			a.cardno cardno, --카드사 / 카드번호
			a.cardokno cardokno,
			NVL(a.divmonth, 0) divmonth, -- 카드승인번호 / 할부기간
			a.discntdate discntdate,
			CASE
				WHEN a.coldiv LIKE '3%'
				THEN
					a.paybank --지금은행
				WHEN SUBSTR(a.coldiv, 0, 1) = '1'
				THEN
					s.accremark --계좌은행
				WHEN (SUBSTR(a.coldiv, 0, 1) = '2')
					 AND (NVL(a.divmonth, 0) = 0)
				THEN
					AC17.divname --카드사
				WHEN (SUBSTR(a.coldiv, 0, 1) = '2')
					 AND (NVL(a.divmonth, 0) > 0)
				THEN
					AC17.divname || ' ' || TO_CHAR(divmonth) || '개월' --카드사
				ELSE
					''
			END
				gubun,
			c.deptcode,
			c.empcode,
			d.deptcode edeptcode,
			d.empcode eempcode,
			c.custname,
			d.custname ecustname,
			0 aftamt,
			0 totamt1,
			0 befrate,
			0 aftrate,
			0 salprc1,
			c.custmajorcode custmajorcode,
			d.custmajorcode ecustmajorcode,
			a.remark
	 FROM	SLCOLM a
			LEFT JOIN CMCUSTM c ON a.custcode = c.custcode
			LEFT JOIN CMCUSTM d ON a.ecustcode = d.custcode
			LEFT JOIN CMCOMMONM AC17
				ON a.cardcomp = AC17.divcode
				   AND AC17.cmmcode = 'AC17'
			LEFT OUTER JOIN CMACCOUNTM s ON a.accountno = s.accountno
	 WHERE	statediv = '09')
/
