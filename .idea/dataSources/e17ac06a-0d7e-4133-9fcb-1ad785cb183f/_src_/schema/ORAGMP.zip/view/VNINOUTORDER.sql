CREATE VIEW VNINOUTORDER AS SELECT a.gb,
          a.plantcode,
          a.inoutno,
          a.inoutdate,
          a.inoutdiv,
          b.divname inoutdivnm,
          a.custcode,
          f.custname,
          a.warehouse,
          g.whname,
          a.location,
          a.itemcode,
          e.itemname,
          e.itemunit unit,
          a.lotno,
          a.lotdate,
          a.expdate,
          a.orderqty,
          a.inoutstate,
          c.divname inoutstatenm,
          a.remark,
          a.empcd,
          d.empname,
          g.workdiv,
          NVL (h.divname, '') workdivnm,
          NVL (a.unitchg, '') unitchg,
          a.returnyn,
          a.addrseq,
          e.plantcode as factorycode
     FROM (SELECT 'out' gb,
                  plantcode,
                  outputno inoutno,
                  outputdate inoutdate,
                  outputdiv inoutdiv,
                  custcode,
                  warehouse,
                  location,
                  itemcode,
                  lotno,
                  lotdate,
                  expdate,
                  orderqty,
                  outputstate inoutstate,
                  remark,
                  empcd,
                  'N' unitchg,
                  NVL (returnyn, 'N') returnyn,
                  addrseq
             FROM sloutorderm
        UNION ALL
           SELECT 'in' gb,
                  plantcode,
                  inputno inoutno,
                  inputdate inoutdate,
                  inputdiv inoutdiv,
                  custcode,
                  warehouse,
                  '' location,
                  itemcode,
                  lotno,
                  lotdate,
                  expdate,
                  orderqty,
                  inputstate inoutstate,
                  remark,
                  empcd,
                  NVL (unitchg, 'N'),
                  'N' returnyn,
                  0 addrseq
             FROM slinorderm
          ) a
  LEFT JOIN CMCOMMONM b
         ON a.inoutdiv = b.divcode
        AND b.cmmcode = 'SL25'
  LEFT JOIN CMCOMMONM c
         ON a.inoutstate = c.divcode
        AND c.cmmcode = 'SL70'
  LEFT JOIN CMEMPM d
         ON a.empcd = d.empcode
  LEFT JOIN CMITEMM e
         ON a.itemcode = e.itemcode
  LEFT JOIN CMCUSTM f
         ON a.custcode = f.custcode
       JOIN SLSTOREHOUSEM g
         ON a.warehouse = g.warehouse                -->>연동처리 20131127:이세민
       JOIN CMCOMMONM h
         ON g.workdiv = h.divcode AND h.cmmcode = 'PS26'
/
