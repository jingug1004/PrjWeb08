CREATE VIEW VNPDAREALSTOCK AS SELECT A_1.itemcode
            ,A_1.qty - NVL(B_1.realqty, 0) realqty
        FROM (    SELECT NVL(warehouse, ' ') warehouse
                      ,NVL(itemcode, ' ') itemcode
                      ,NVL(SUM(qty), 0) qty
                  FROM SLWAREHOUSEM a
                 WHERE (itemcode LIKE ' ' || '%')
                       AND (warehouse = '01')
              GROUP BY itemcode, warehouse) A_1
             LEFT JOIN (  SELECT a.itemcode
                                ,SUM(a.salqty + a.givqty - a.outputqty) realqty
                            FROM SLORDD a
                                 JOIN SLORDM b
                                     ON a.plantcode = b.plantcode
                                        AND a.orderno = b.orderno
                                        AND b.saldiv LIKE 'A%'
                                        AND b.saldiv NOT IN ('A03', 'A07', 'A25', 'A40', 'A51')
                                        AND b.statediv NOT IN ('99')
                           WHERE (a.salqty > a.outputqty)
                                 AND (a.itemcode LIKE ' ' || '%')
                                 AND (b.warehouse = '01')
                                 
                                 -- 2017-09-04 : 아래와 같이 되어 있어서 수정함
                                 -- AND (a.orderdate < UTILS.CONVERT_TO_VARCHAR2(utils.dateadd('MM', 1, SYSDATE), 10, p_style => 121))
                                 AND (a.orderdate < TO_CHAR(ADD_MONTHS(SYSDATE, 1), 'YYYY-MM-DD'))
                        GROUP BY a.itemcode, b.warehouse) B_1
                 ON A_1.itemcode = B_1.itemcode
    ORDER BY A_1.itemcode
/
