CREATE VIEW VNGPITEMMASTERNOW AS SELECT a.itemcode itemcode, --품목코드
		   b.itemkorname itemkorname, --품목명(국문)
		   b.itemdiv itemdiv, --품목구분
		   b.itemunit itemunit, --단위코드
		   NULL safestockqty, --안전재고량
		   b.usediv usediv, --사용여부
		   fnNumericToString(b.contentqty, 'S') || NVL(h.divname, ' ') contentqtyname, --함량Text(*)
		   b.BATCHSIZE BATCHSIZE, --배치크기Num(제조제품)
		   b.itemformdiv itemformdiv, --제품유형코드(제조제품)
		   b.maxmanageyield maxmanageyield, --관리수율(상한)(제조제품)
		   b.productcheck productcheck, --생산여부(제조,포장)
		   CASE b.productiondiv WHEN '08' THEN a.itemcode ELSE NULL END typicalitemcode, --대표제품코드(포장제품)
		   CASE b.productiondiv WHEN '08' THEN b.BATCHSIZE ELSE NULL END packingunitqty, --포장단위량Num(포장제품)
		   CASE b.productiondiv WHEN '08' THEN fnNumericToString(b.BATCHSIZE, 'S') + b.itemunit ELSE NULL END packingunitqtyname, --포장단위Text(*)
		   NULL minpackingcheck,
		   b.productiondiv productiondiv,
		   0 testperiod,
		   shape,
		   b.revisionno,
		   b.validityperiod,
		   b.itemengname,
		   c.divname itemunitname,
		   D.divname transunitname,
		   a.approvalcheck,
		   b.itemshortname,
		   b.transqty,
		   b.itemdiv itembranch, --품목분류코드
		   f.divname itembranchname, --품목분류명
		   ' ' typicalpackingcheck,
		   ' ' minpackingrate
	FROM   PDGSTANDARDREVISIOND a
		   JOIN PDMAKINGGM b
			   ON a.itemcode = b.itemcode
				  AND a.itemrevisionid = b.revisionno
		   LEFT JOIN CommonMaster h
			   ON h.cmmcode = 'CMM02'
				  AND b.contentunit = h.divcode
		   LEFT JOIN CommonMaster c
			   ON c.cmmcode = 'CMM02'
				  AND b.itemunit = c.divcode
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'CMM02'
				  AND b.transunit = D.divcode
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'CMM02'
				  AND b.transunit = f.divcode
	WHERE  a.approvalcheck = 'Y' -- 승인완료된 항목조회
		   AND a.usediv = 'Y' -- 사용중인 항목조회
	UNION
	--where  a.usediv = 'Y'

	--포장제품
	SELECT a.itemcode itemcode, --품목코드
		   a.itemkorname itemkorname, --품목명(국문)
		   a.itemdiv itemdiv, --품목구분
		   c.itemunit itemunit, --단위코드
		   a.safestockday safestockqty, --안전재고량
		   a.usediv usediv, --사용여부
		   fnNumericToString(c.contentqty, 'S') || NVL(i.divname, ' ') contentqtyname, --함량Text(*)
		   c.BATCHSIZE BATCHSIZE, --배치크기Num(제조제품)
		   c.itemformdiv itemformdiv, --제품유형코드(제조제품)
		   c.maxmanageyield maxmanageyield, --관리수율(상한)(제조제품)
		   a.productcheck productcheck, --생산여부(제조,포장)
		   a.typicalitemcode typicalitemcode, --대표제품코드(포장제품)
		   a.packingunitqty packingunitqty, --포장단위량Num(포장제품)
		   fnNumericToString(a.packingunitqty, 'S') + e.divname packingunitqtyname, --포장단위Text(*)
		   a.minpackingcheck minpackingcheck,
		   c.productiondiv productiondiv,
		   a.testperiod,
		   shape,
		   c.revisionno,
		   c.validityperiod,
		   c.itemengname,
		   D.divname itemunitname,
		   f.divname transunitname,
		   M.approvalcheck,
		   a.itemshortname,
		   c.transqty,
		   c.itemdiv itembranch, --품목분류코드
		   g.divname itembranchname, --품목분류명
		   a.typicalpackingcheck,
		   a.minpackingrate
	FROM   PDGSTANDARDREVISIOND M
		   JOIN PDPACKINGGM a
			   ON M.itemcode = a.itemcode
				  AND M.itemrevisionid = a.revisionno
		   JOIN PDMAKINGGM c
			   ON a.typicalitemcode = c.itemcode
				  AND c.revisionno = (SELECT MAX(PDMAKINGGM.revisionno)
									  FROM	 PDMAKINGGM
									  WHERE  PDMAKINGGM.itemcode = c.itemcode)
		   LEFT JOIN CommonMaster e
			   ON e.cmmcode = 'CMM02'
				  AND e.divcode = a.packingunit
		   LEFT JOIN CommonMaster i
			   ON i.cmmcode = 'CMM02'
				  AND i.divcode = c.contentunit
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'CMM02'
				  AND c.itemunit = D.divcode
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'CMM02'
				  AND c.transunit = f.divcode
		   LEFT JOIN CommonMaster g
			   ON g.cmmcode = 'MPM23'
				  AND c.transunit = g.divcode
	WHERE  M.approvalcheck = 'Y' -- 승인완료된 항목조회
		   AND M.usediv = 'Y' -- 사용중인 항목조회

--where		m.usediv = 'Y'  
/
