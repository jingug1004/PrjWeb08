CREATE VIEW VNSPESALE AS SELECT NVL(a.plantcode, ' ') plantcode,
		   NVL(a.spedate, ' ') spedate,
		   NVL(a.custcode, ' ') custcode,
		   NVL(b.custname, ' ') custname,
		   NVL(b.addr, ' ') addr,
		   NVL(b.telno, ' ') telno,
		   NVL(b.ceoname, ' ') ceoname,
		   NVL(a.chasoo, 0) chasoo,
		   NVL(a.spediv, ' ') spediv,
		   NVL(e.divname, ' ') spedivnm,
		   NVL(a.supportdiv, ' ') supportdiv,
		   NVL(f.divname, ' ') supportdivnm,
		   NVL(c.topdeptcode, ' ') topdeptcode,
		   NVL(c.topdeptname, ' ') topdeptname,
		   NVL(c.predeptcode, ' ') predeptcode,
		   NVL(c.predeptname, ' ') predeptname,
		   NVL(a.deptcode, ' ') deptcode,
		   NVL(c.deptname, ' ') deptname,
		   NVL(c.findname, ' ') findname,
		   NVL(a.empcode, ' ') empcode,
		   NVL(D.empname, ' ') empname,
		   NVL(D.positiondiv, ' ') positiondiv,
		   NVL(g.divname, ' ') jikwi,
		   NVL(a.spedts, ' ') spedts,
		   NVL(a.spedte, ' ') spedte,
		   NVL(a.promamt, 0) promamt,
		   NVL(a.promamtm, 0) promamtm,
		   NVL(a.endyn, ' ') endyn,
		   NVL(a.enddate, ' ') enddate,
		   NVL(a.rtyn, ' ') rtyn,
		   NVL(a.rtamt, 0) rtamt,
		   NVL(a.rtrate, 0) rtrate,
		   NVL(a.goodrate, 0) goodrate,
		   NVL(a.remark, ' ') remark
	FROM   SLSPESALEM a
		   JOIN vnCUST b ON a.custcode = b.custcode
		   JOIN vnDEPT c ON a.deptcode = c.deptcode
		   JOIN CMEMPM D ON a.empcode = D.empcode
		   LEFT JOIN CMCOMMONM e
			   ON a.spediv = e.divcode
				  AND e.cmmcode = 'SL66' --특매분류
		   LEFT JOIN CMCOMMONM f
			   ON a.supportdiv = f.divcode
				  AND f.cmmcode = 'SL67' --지원분류
		   LEFT JOIN CMCOMMONM g
			   ON D.positiondiv = g.divcode
				  AND g.cmmcode = 'PS29'
/
