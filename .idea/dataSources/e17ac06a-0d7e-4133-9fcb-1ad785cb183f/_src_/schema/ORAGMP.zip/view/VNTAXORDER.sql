CREATE VIEW VNTAXORDER AS SELECT a.plantcode
            ,MAX(a.orderdate) orderdate
            ,MAX(a.orderseq) orderseq
            ,a.orderno
            ,MAX(a.appdate) appdate
            ,NVL(MAX(a.orderdiv), ' ') orderdiv
            ,CASE WHEN NVL(MAX(a.orderdiv), ' ') = '1' THEN '급여' ELSE '비급여' END orderdivnm
            ,NVL(MAX(pp.plantfullname), ' ') plantname
            ,NVL(MAX(pp.businessno), ' ') pbusinessno
            ,NVL(MAX(pp.owner), ' ') powner
            ,NVL(MAX(pp.address), ' ') paddr1
            ,NVL(MAX(pp.detailaddress), ' ') paddr2
            ,NVL(MAX(pp.telno), ' ') ptelno
            ,NVL(MAX(pp.postcode), ' ') ppostcode
            ,NVL(MAX(pp.businessstatus), ' ') pcustcondition
            , --업태
             NVL(MAX(pp.businesscategory), ' ') pcustitem
            ,SUBSTR(a.orderno, 1, 8) || '-' || SUBSTR(a.orderno, 9, 4) ordno
            ,NVL(MAX(a.saldiv), ' ') saldiv
            ,NVL(MAX(b.divname), ' ') saldivnm
            ,NVL(MAX(a.outputdiv), ' ') outputdiv
            ,NVL(MAX(h.divname), ' ') outputdivnm
            ,NVL(MAX(a.transferdiv), ' ') transferdiv
            ,NVL(MAX(i.divname), ' ') transferdivnm
            ,NVL(MAX(a.custcode), ' ') custcode
            ,NVL(MAX(c.custname), ' ') custname
            ,NVL(MAX(c.custcondition), ' ') custcondition
            ,NVL(MAX(c.custitem), ' ') custitem
            ,NVL(MAX(c.businessno), ' ') businessno
            ,NVL(MAX(c.ceoname), ' ') ceoname
            ,NVL(MAX(c.telno), ' ') telno
            ,NVL(MAX(c.faxno), ' ') faxno
            ,NVL(MAX(c.POST), ' ') POST
            ,NVL(MAX(c.addr1), ' ') addr1
            ,NVL(MAX(c.addr2), ' ') addr2
            ,NVL(MAX(c.addr1 || ' ' || c.addr2), ' ') addr
            ,NVL(MAX(a.utdiv), ' ') utdiv
            ,NVL(MAX(M.divname), ' ') utdivnm
            ,NVL(MAX(a.ecustcode), ' ') ecustcode
            ,NVL(MAX(o.custname), ' ') ecustname
            ,NVL(MAX(o.addr1 || ' ' || o.addr2), ' ') eaddr
            ,NVL(MAX(a.deptcode), ' ') deptcode
            ,NVL(MAX(D.deptname), ' ') deptname
            ,NVL(MAX(e.deptcode), ' ') predeptcode
            ,NVL(MAX(e.deptname), ' ') predeptname
            ,NVL(MAX(f.deptcode), ' ') topdeptcode
            ,NVL(MAX(f.deptname), ' ') topdeptname
            ,NVL(MAX(g.positiondiv), ' ') positiondiv
            ,NVL(MAX(a.empcode), ' ') empcode
            ,NVL(MAX(g.empname), ' ') empname
            ,NVL(MAX(j.divname), ' ') jikwi
            ,NVL(MAX(g.phone), ' ') phone
            ,NVL(MAX(a.statediv), ' ') statediv
            ,NVL(MAX(k.divname), ' ') statedivnm
            ,NVL(MAX(z.itemcode), ' ') itemcode
            ,NVL(MAX(l.itemname), ' ') itemname
            ,NVL(MAX(L.itemunit), ' ') unit
            ,NVL(COUNT(z.itemcode), 0) itemcnt
            ,CASE
                 WHEN NVL(COUNT(z.itemcode), 0) = 1 THEN NVL(MAX(l.itemname || ' ' || l.itemunit), ' ')
                 -- 2017-09-04 : 아래와 같이 되어 있어서 수정                 
--                 WHEN NVL(COUNT(z.itemcode), ' ') > 1 THEN NVL(MAX(l.itemname || ' ' || l.itemunit), ' ') || ' 외' || UTILS.CONVERT_TO_VARCHAR2(COUNT(z.itemcode) - 1, 30) || '건'
                 WHEN NVL(COUNT(z.itemcode), ' ') > 1 THEN NVL(MAX(l.itemname || ' ' || l.itemunit), ' ') || ' 외' || TO_CHAR(COUNT(z.itemcode) - 1, 30) || '건'
             END
                 itemnm
            ,CASE WHEN MAX(SUBSTR(a.saldiv, 0, 1)) = 'A' THEN NVL(SUM(z.salamt), 0) ELSE -1 * NVL(SUM(z.salamt), 0) END salamt
            ,CASE WHEN MAX(SUBSTR(a.saldiv, 0, 1)) = 'A' THEN NVL(SUM(z.salvat), 0) ELSE -1 * NVL(SUM(z.salvat), 0) END salvat
            ,CASE WHEN MAX(SUBSTR(a.saldiv, 0, 1)) = 'A' THEN NVL(SUM(z.totamt), 0) ELSE -1 * NVL(SUM(z.totamt), 0) END totamt
            ,NVL(MAX(a.taxmanagedate), ' ') taxmanagedate
            ,NVL(MAX(a.trademanagedate), ' ') trademanagedate
            ,NVL(MAX(a.taxdate), ' ') taxdate
            ,NVL(MAX(a.tradedate), ' ') tradedate
            ,CASE WHEN NVL(MAX(a.taxmanagedate), ' ') = ' ' THEN '미발행' WHEN NVL(MAX(a.taxmanagedate), ' ') <> ' ' THEN '발행' ELSE '미발행' END taxmngprintgb
            ,CASE WHEN NVL(MAX(a.trademanagedate), ' ') = ' ' THEN '미발행' WHEN NVL(MAX(a.trademanagedate), ' ') <> ' ' THEN '발행' ELSE '미발행' END trademngprintgb
            ,CASE WHEN NVL(MAX(a.taxdate), ' ') = ' ' THEN '미발행' WHEN NVL(MAX(a.taxdate), ' ') <> ' ' THEN '발행' ELSE '미발행' END taxprintgb
            ,CASE WHEN NVL(MAX(a.tradedate), ' ') = ' ' THEN '미발행' WHEN NVL(MAX(a.tradedate), ' ') <> ' ' THEN '발행' ELSE '미발행' END tradeprintgb
            ,CASE WHEN MAX(SUBSTR(a.saldiv, 0, 1)) = 'A' THEN NVL(SUM(z.salqty + z.givqty), 0) ELSE -1 * NVL(SUM(z.salqty + z.givqty), 0) END salqty
            ,NVL(SUM(z.outputqty), 0) outputqty
            ,CASE
                 -- 2017-09-04 : 아래와 같이 되어 있어서 수정
--                 WHEN MAX(SUBSTR(a.saldiv, 0, 1)) = 'A' THEN SUBSTR('          ' || UTILS.CONVERT_TO_VARCHAR2(UTILS.CONVERT_TO_NUMBER(SUM(z.salamt), 10, 0), 30), -10, 10)
--                 ELSE SUBSTR('          ' || '-' || UTILS.CONVERT_TO_VARCHAR2(UTILS.CONVERT_TO_NUMBER(SUM(z.salamt), 10, 0), 30), -10, 10)
                 WHEN MAX(SUBSTR(a.saldiv, 0, 1)) = 'A' THEN SUBSTR('          ' || TO_CHAR(SUM(z.salamt)), -10, 10)
                 ELSE SUBSTR('          ' || '-' || TO_CHAR(SUM(z.salamt)), -10, 10)                 
             END
                 amt_print
            ,CASE
                 -- 2017-09-04 : 아래와 같이 되어 있어서 수정                 
--                 WHEN MAX(SUBSTR(a.saldiv, 0, 1)) = 'A' THEN SUBSTR('         ' || UTILS.CONVERT_TO_VARCHAR2(UTILS.CONVERT_TO_NUMBER(SUM(z.salvat), 10, 0), 30), -9, 9)
--                 ELSE SUBSTR('         ' || '-' || UTILS.CONVERT_TO_VARCHAR2(UTILS.CONVERT_TO_NUMBER(SUM(z.salvat), 10, 0), 30), -9, 9)
                 WHEN MAX(SUBSTR(a.saldiv, 0, 1)) = 'A' THEN SUBSTR('         ' || TO_CHAR(SUM(z.salvat)), -9, 9)
                 ELSE SUBSTR('         ' || '-' || TO_CHAR(SUM(z.salvat)), -9, 9)
             END
                 vat_print
            ,SUBSTR(MAX(a.appdate), 1, 4) YYYY
            ,SUBSTR(MAX(a.appdate), 1, 2) yy1
            ,SUBSTR(MAX(a.appdate), 3, 2) yy2
            ,SUBSTR(MAX(a.appdate), 6, 2) MM
            ,SUBSTR(MAX(a.appdate), 9, 2) DD
                 -- 2017-09-04 : 아래와 같이 되어 있어서 수정
--            ,10 - LENGTH(UTILS.CONVERT_TO_NUMBER(SUM(z.salamt), 10, 0)) blank_cnt
            ,10 - LENGTH(TO_CHAR(SUM(z.salamt))) blank_cnt
            ,MAX(a.remark) remark
            ,NVL(MAX(a.fixdate), ' ') fixdate
            ,NVL(MAX(a.fixseq), 0) fixseq
            ,NVL(MAX(a.warehouse), ' ') warehouse
        FROM SLORDM a
             JOIN SLORDD z ON a.orderno = z.orderno
             LEFT JOIN CMCOMMONM b
                 ON a.saldiv = b.divcode
                    AND b.cmmcode = 'SL10'
             JOIN CMCUSTM c ON a.custcode = c.custcode
             JOIN CMDEPTM D ON a.deptcode = D.deptcode
             LEFT JOIN CMDEPTM e ON D.predeptcode = e.deptcode
             LEFT JOIN CMDEPTM f ON e.predeptcode = f.deptcode
             JOIN CMEMPM g ON a.empcode = g.empcode
             LEFT JOIN (SELECT divcode
                              ,divname
                          FROM CMCOMMONM
                         WHERE cmmcode = 'PS29') j
                 ON g.positiondiv = j.divcode
             LEFT JOIN (SELECT divcode
                              ,divname
                          FROM CMCOMMONM
                         WHERE cmmcode = 'SL12') h
                 ON a.outputdiv = h.divcode
             LEFT JOIN (SELECT divcode
                              ,divname
                          FROM CMCOMMONM
                         WHERE cmmcode = 'SL14') i
                 ON a.transferdiv = i.divcode
             LEFT JOIN (SELECT divcode
                              ,divname
                          FROM CMCOMMONM
                         WHERE cmmcode = 'SL17') k
                 ON a.statediv = k.divcode
             JOIN CMITEMM l ON z.itemcode = l.itemcode
             LEFT JOIN (SELECT divcode
                              ,divname
                          FROM CMCOMMONM
                         WHERE cmmcode = 'CM15') M
                 ON a.utdiv = M.divcode
             LEFT JOIN CMCUSTM o ON a.ecustcode = o.custcode
             JOIN CMPLANTM pp ON a.plantcode = pp.plantcode
    GROUP BY a.plantcode, a.orderno
/
