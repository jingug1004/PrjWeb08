CREATE VIEW VNEMPSALES AS (SELECT b.plantcode,
			NVL(a.yymm, '') AS yymm, --사업장 코드
			a.orderdate,
			a.orderseq,
			a.orderno, --주문구분
			NVL(a.saldiv, '') AS saldiv, --판매구분
			CASE
				WHEN (NVL(a.saldiv, ' ') = 'CC')
					 AND (NVL(a.tasooyn, 'N') = 'N')
				THEN
					NVL(SL18.divname, '')
				WHEN (NVL(a.saldiv, ' ') = 'CC')
					 AND (NVL(a.tasooyn, 'N') = 'Y')
				THEN
					NVL(SL18.divname, '') || '(타)'
				ELSE
					NVL(d.divname, '')
			END
				AS saldivnm,
			NVL(a.tasooyn, 'N') AS tasooyn,
			NVL(a.datadiv, '') AS datadiv,
			NVL(E.divname, '') AS datadivnm,
			NVL(a.coldiv, '') AS coldiv,
			NVL(a.orderdiv, '') AS orderdiv,
			NVL(a.outputdiv, '') AS outputdiv,
			NVL(f.divname, '') AS outputdivnm,
			NVL(a.transferdiv, '') AS transferdiv,
			NVL(G.divname, '') AS transferdivnm,
			a.custcode,
			NVL(b.custname, '') AS custname,
			NVL(b.telno, '') AS telno,
			NVL(b.faxno, '') AS faxno,
			NVL(b.ceoname, '') AS ceoname,
			NVL(b.businessno, '') AS businessno,
			NVL(b.POST, '') AS POST,
			NVL(b.addr1, '') AS addr1,
			NVL(b.addr2, '') AS addr2,
			NVL(b.addr1, '') || ' ' || NVL(b.addr2, '') AS addr,
			b.deptcode,
			NVL(h.deptname, '') AS deptname,
			b.empcode,
			NVL(h.topdeptcode, '') AS topdeptcode,
			NVL(j.topdeptcode, '') AS etopdeptcode,
			NVL(h.topdeptname, '') AS topdeptname,
			NVL(j.topdeptname, '') AS etopdeptname,
			NVL(h.predeptcode, '') AS predeptcode,
			NVL(j.predeptcode, '') AS epredeptcode,
			NVL(h.predeptname, '') AS predeptname,
			NVL(j.predeptname, '') AS epredeptname,
			NVL(h.findname, '') AS findname,
			NVL(j.findname, '') AS efindname,
			NVL(i.positiondiv, '') AS positiondiv,
			NVL(U.divname, '') AS jikwi,
			NVL(i.empname, '') AS empname,
			a.ecustcode,
			NVL(c.custname, '') AS ecustname,
			c.deptcode AS edeptcode,
			NVL(j.deptname, '') AS edeptname,
			c.empcode AS eempcode,
			NVL(K.positiondiv, '') AS epositiondiv,
			NVL(v.divname, '') AS ejikwi,
			NVL(K.empname, '') AS eempname,
			NVL(a.utdiv, '') AS utdiv,
			NVL(o.divname, '') AS utdivnm,
			NVL(a.eutdiv, '') AS eutdiv,
			NVL(P.divname, '') AS eutdivnm,
			NVL(a.bnorderno, '') AS bnorderno,
			NVL(a.taxdate, '') AS taxdate,
			NVL(a.tradedate, '') AS tradedate,
			a.appdate,
			a.statediv,
			NVL(l.divname, '') AS statedivnm,
			NVL(a.remark, '') AS remark,
			a.seq,
			a.itemcode,
			NVL(M.itemname, '') AS itemname,
			NVL(M.itemunit, '') AS unit,
			NVL(M.drugdiv, '') AS drugdiv,
			NVL(w.divname, '') AS drugdivnm,
			NVL(M.medimaxprc, '') AS medimaxprc,
			NVL(M.mitemcode, '') AS mitemcode,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.salqty, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.salqty, 0) ELSE 0 END AS salqty,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.givqty, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.givqty, 0) ELSE 0 END AS givqty,
			NVL(a.drugprc, 0) AS drugprc,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.drugamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.drugamt, 0) ELSE 0 END AS drugamt,
			NVL(a.makingcost, 0) AS makingcost,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.makingamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.makingamt, 0) ELSE 0 END AS makingamt,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.makinggivamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.makinggivamt, 0) ELSE 0 END AS makinggivamt,
			NVL(a.salprc, 0) AS salprc,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.salamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.salamt, 0) ELSE 0 END AS salamt,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.salvat, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.salvat, 0) ELSE 0 END AS salvat,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.totamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.totamt, 0) ELSE 0 END AS totamt,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.befamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.befamt, 0) ELSE 0 END AS befamt,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.aftamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.aftamt, 0) ELSE 0 END AS aftamt,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.incamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.incamt, 0) ELSE 0 END AS incamt,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.totdiscount, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.totdiscount, 0) ELSE 0 END AS totdiscount,
			NVL(a.givrate, 0) AS givrate,
			NVL(a.befrate, 0) AS befrate,
			NVL(a.aftrate, 0) AS aftrate,
			NVL(a.incrate, 0) AS incrate,
			NVL(a.salprc1, 0) AS salprc1,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.salamt1, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.salamt1, 0) ELSE 0 END AS salamt1,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.salvat1, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.salvat1, 0) ELSE 0 END AS salvat1,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.totamt1, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.totamt1, 0) ELSE 0 END AS totamt1,
			CASE
				WHEN a.saldiv = 'C01'
					 AND a.coldiv IN ('01')
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS cashcol, --현금수금
			CASE
				WHEN a.saldiv = 'C01'
					 AND a.coldiv IN ('02')
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS changecol, --채권상계
			CASE
				WHEN a.saldiv = 'C01'
					 AND SUBSTR(a.coldiv, 1, 1) = '1'
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS bankcol, --은행입금
			CASE
				WHEN a.saldiv = 'C01'
					 AND SUBSTR(a.coldiv, 1, 1) = '2'
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS cardcol, --카드수금
			CASE
				WHEN a.saldiv = 'C01'
					 AND SUBSTR(a.coldiv, 1, 1) = '3'
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS billcol, --어음수금
			CASE
				WHEN a.saldiv = 'C01'
					 AND a.coldiv > '39'
				THEN
					NVL(a.colamt, 0)
				ELSE
					0
			END
				AS etccol, --기타수금
			NVL(a.colamt, 0) AS colamt,
			NVL(a.custprtyn, '') AS custprtyn,
			NVL(a.outputqty, 0) AS outputqty,
			NVL(a.recalldiv, '') AS recalldiv,
			NVL(x.divname, '') AS recalldivnm,
			NVL(a.absyn, '') AS absyn,
			NVL(a.pieceyn, '') AS pieceyn,
			NVL(a.enuriyn, '') AS eruriyn,
			CASE
				WHEN a.coldiv LIKE '3%'
				THEN
					NVL(a.paybank, '') --지금은행
				WHEN SUBSTR(a.coldiv, 1, 1) = '1'
				THEN
					NVL(T.bankname, '') || ' ' || NVL(T.branchname, '') --계좌은행
				WHEN (SUBSTR(a.coldiv, 1, 1) = '2')
					 AND (NVL(a.divmonth, 0) = 0)
				THEN
					NVL(AC17.divname, '') --카드사
				WHEN (SUBSTR(a.coldiv, 1, 1) = '2')
					 AND (NVL(a.divmonth, 0) > 0)
				THEN
					NVL(AC17.divname, '') || ' ' || TO_CHAR(divmonth) || '개월' --카드사
				ELSE
					''
			END
				AS gubun,
			NVL(a.billno, '') AS billno,
			NVL(a.accountno, '') AS accountno,
			CASE WHEN a.coldiv LIKE '3%' THEN NVL(a.issdate, '') ELSE '' END AS issdate,
			CASE WHEN a.coldiv LIKE '3%' THEN NVL(a.expdate, '') ELSE '' END AS expdate,
			CASE WHEN a.coldiv LIKE '3%' THEN NVL(a.discntdate, '') ELSE '' END AS discntdate,
			NVL(a.paybank, '') AS paybank,
			NVL(a.cardcomp, '') AS cardcomp,
			NVL(AC17.divname, '') AS cardcompnm,
			NVL(a.cardno, '') AS cardno,
			NVL(a.cardokno, '') AS cardokno,
			NVL(T.bankname, '') || ' ' || NVL(T.branchname, '') AS accountbanknm,
			NVL(a.pda, '') AS pda,
			NVL(b.areadiv, '') AS areadiv,
			NVL(uu.divname, '') AS areadivnm,
			NVL(i.retiredt, '') AS retiredt,
			NVL(K.retiredt, '') AS eretiredt,
			NVL(h.deptgroup, '') AS deptgroup,
			NVL(j.deptgroup, '') AS edeptgroup,
			NVL(b.custmajorcode, '') AS custmajorcode,
			NVL(b.opendate, '') AS opendate,
			NVL(b.stopdate, '') AS stopdate,
			h.seqtopdeptcode,
			h.seqpredeptcode,
			h.seqdeptcode,
			j.seqtopdeptcode AS eseqtopdetpcode,
			j.seqpredeptcode AS eseqpredeptcode,
			j.seqdeptcode AS eseqdeptcode
	 FROM	vnSalesEnd a
			JOIN CMCUSTM b ON a.custcode = b.custcode
			JOIN CMCUSTM c ON a.ecustcode = c.custcode
			LEFT JOIN CMCOMMONM d
				ON a.saldiv = d.divcode
				   AND d.cmmcode = 'SL10'
			LEFT JOIN CMCOMMONM E
				ON a.datadiv = E.divcode
				   AND E.cmmcode = 'SL11'
			LEFT JOIN CMCOMMONM f
				ON a.outputdiv = f.divcode
				   AND f.cmmcode = 'SL12'
			LEFT JOIN CMCOMMONM G
				ON a.transferdiv = G.divcode
				   AND G.cmmcode = 'SL14'
			JOIN vndept h ON b.deptcode = h.deptcode
			JOIN CMEMPM i ON b.empcode = i.empcode
			JOIN vndept j ON c.deptcode = j.deptcode
			JOIN CMEMPM K ON c.empcode = K.empcode
			LEFT JOIN CMCOMMONM l
				ON a.statediv = l.divcode
				   AND l.cmmcode = 'SL17'
			LEFT JOIN CMitemm M ON a.itemcode = M.itemcode
			LEFT JOIN CMCOMMONM n
				ON M.unit = n.divcode
				   AND n.cmmcode = 'CM38'
			LEFT JOIN CMCOMMONM o
				ON a.utdiv = o.divcode
				   AND o.cmmcode = 'CM15'
			LEFT JOIN CMCOMMONM P
				ON a.eutdiv = P.divcode
				   AND P.cmmcode = 'CM15'
			LEFT JOIN CMCOMMONM SL18
				ON a.coldiv = SL18.divcode
				   AND SL18.cmmcode = 'SL18'
			LEFT JOIN CMCOMMONM AC17
				ON a.cardcomp = AC17.divcode
				   AND AC17.cmmcode = 'AC17'
			LEFT OUTER JOIN CMACCOUNTM s ON a.accountno = s.accountno
			LEFT OUTER JOIN cmbankm T ON s.bankcode = T.bankcode
			LEFT JOIN CMCOMMONM U
				ON i.positiondiv = U.divcode
				   AND U.cmmcode = 'PS29'
			LEFT JOIN CMCOMMONM v
				ON K.positiondiv = v.divcode
				   AND v.cmmcode = 'PS29'
			LEFT JOIN CMCOMMONM w
				ON M.drugdiv = w.divcode
				   AND w.cmmcode = 'CM23'
			LEFT JOIN CMCOMMONM x
				ON a.recalldiv = x.divcode
				   AND x.cmmcode = 'SL16'
			LEFT JOIN CMCOMMONM uu
				ON b.areadiv = uu.divcode
				   AND uu.cmmcode = 'CM03')
/
