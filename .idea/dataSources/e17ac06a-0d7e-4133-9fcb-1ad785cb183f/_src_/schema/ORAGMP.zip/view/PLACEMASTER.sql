CREATE VIEW PLACEMASTER AS SELECT deptcode,
		   deptname,
		   plantcode
	FROM   vnDEPT a
/
