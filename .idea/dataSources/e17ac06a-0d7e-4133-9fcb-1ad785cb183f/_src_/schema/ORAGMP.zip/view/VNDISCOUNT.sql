CREATE VIEW VNDISCOUNT AS SELECT a.plantcode, -- isnull(a.plantcode,'') as plantcode
		   a.saldiv, -- isnull(a.saldiv,'') as saldiv    --매출할인입력 구분 (A:매출입력, C:수금입력, N:직접입력)
		   NVL(p.divname, ' ') saldivnm,
		   a.appdate, -- isnull(a.appdate,'') as appdate
		   SUBSTR(NVL(a.cleandate, ' '), 1, 7) yymm,
		   a.cleandate, -- isnull(a.cleandate,'') as cleandate
		   a.seq, -- ISNULL(a.seq,0) as seq
		   a.custcode, -- isnull(a.custcode,'') as custcode
		   NVL(b.custname, ' ') custname,
		   NVL(b.utdiv, ' ') utdiv,
		   NVL(b.utdivnm, ' ') utdivnm,
		   NVL(c.topdeptcode, ' ') topdeptcode,
		   NVL(c.topdeptname, ' ') topdeptname,
		   NVL(c.predeptcode, ' ') predeptcode,
		   NVL(c.predeptname, ' ') predeptname,
		   a.deptcode, -- isnull(a.deptcode,'') as deptcode
		   NVL(c.deptname, ' ') deptname,
		   NVL(c.findname, ' ') findname,
		   NVL(f.positiondiv, ' ') positiondiv,
		   a.empcode, -- isnull(a.empcode,'') as empcode
		   NVL(f.empname, ' ') empname,
		   NVL(g.divname, ' ') jikwi,
		   NVL(a.ecustcode, ' ') ecustcode,
		   NVL(i.custname, ' ') ecustname,
		   NVL(i.utdiv, ' ') eutdiv,
		   NVL(i.utdivnm, ' ') eutdivnm,
		   NVL(j.topdeptcode, ' ') etopdeptcode,
		   NVL(j.topdeptname, ' ') etopdeptname,
		   NVL(j.predeptcode, ' ') epredeptcode,
		   NVL(j.predeptname, ' ') epredeptname,
		   NVL(a.edeptcode, ' ') edeptcode,
		   NVL(j.deptname, ' ') edeptname,
		   NVL(j.findname, ' ') efindname,
		   NVL(M.positiondiv, ' ') epositiondiv,
		   NVL(a.eempcode, ' ') eempcode,
		   NVL(M.empname, ' ') eempname,
		   NVL(N.divname, ' ') ejikwi,
		   NVL(a.appdates, ' ') appdates, --주문(수금)일자 부터
		   NVL(a.appdatee, ' ') appdatee, --주문(수금)일자 까지
		   NVL(a.discountdiv, ' ') discountdiv, --매출할인구분:SL60   select * from cmcommonm where cmmcode = 'SL60'
		   NVL(o.divname, ' ') discountdivnm,
		   NVL(a.fixrate, 0) fixrate, --수금할인율
		   NVL(a.maechul, 0) maechul, --매출할인액
		   NVL(a.panmae, 0) panmae, --판매장려금
		   NVL(a.cleanamt, 0) cleanamt, --할인금액
		   NVL(a.disamt, 0) disamt, --주문:할인액, 수금:수금액
		   NVL(a.taxamt, 0) taxamt, --세금계산서금액(주문)
		   NVL(a.costamt, 0) costamt, --실가(주문)
		   NVL(a.turncnt, 0) turncnt, --회전일
		   a.orderno, -- isnull(a.orderno,'') as orderno    --주문번호
		   NVL(a.panmaeno, 0) panmaeno, --수금번호
		   a.statediv, -- isnull(a.statediv,'') as statediv    --상태(01:입력, 09:승인)
		   NVL(h.divname, ' ') statedivnm, --상태명
		   NVL(a.remark, ' ') remark,
		   c.seqtopdeptcode,
		   c.seqpredeptcode,
		   c.seqdeptcode,
		   j.seqtopdeptcode eseqtopdeptcode,
		   j.seqpredeptcode eseqpredeptcode,
		   j.seqdeptcode eseqdeptcode
	FROM   SLDISCOUNTM a
		   JOIN vnCUST b ON a.custcode = b.custcode
		   JOIN vnDEPT c ON a.deptcode = c.deptcode
		   JOIN CMEMPM f ON a.empcode = f.empcode
		   LEFT JOIN CMCOMMONM g
			   ON f.positiondiv = g.divcode
				  AND g.cmmcode = 'PS29'
		   LEFT JOIN CMCOMMONM h
			   ON a.statediv = h.divcode
				  AND h.cmmcode = 'SL17'
		   LEFT JOIN vnCUST i ON a.ecustcode = i.custcode
		   LEFT JOIN vnDEPT j ON a.edeptcode = j.deptcode
		   LEFT JOIN CMEMPM M ON a.eempcode = M.empcode
		   LEFT JOIN CMCOMMONM N
			   ON M.positiondiv = N.divcode
				  AND N.cmmcode = 'PS29'
		   LEFT JOIN CMCOMMONM o
			   ON a.discountdiv = o.divcode
				  AND o.cmmcode = 'SL60'
		   LEFT JOIN CMCOMMONM P
			   ON a.saldiv = P.divcode
				  AND P.cmmcode = 'SL61'
/
