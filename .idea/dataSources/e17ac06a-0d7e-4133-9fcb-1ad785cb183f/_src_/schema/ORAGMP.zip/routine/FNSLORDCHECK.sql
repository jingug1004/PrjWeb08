CREATE FUNCTION        fnSLordCheck
-- --------------------------------------------------------------------
 -- 함 수 명		  : fnSLordCheck
 -- 작 성 자         : 김만수
 -- 작성일자         : 2017-11-15
 -- -------------------------------------------------------------------
 -- 함수설명	     : 주문등록시 거래처 채권에 대한 제한내역을 체크하는 함수
 -- -------------------------------------------------------------------
(
    p_plantcode                IN    VARCHAR2 DEFAULT '',    --사업장
    p_orderdate                IN    VARCHAR2 DEFAULT '',    --주문일자
    p_yearmonth                IN    VARCHAR2 DEFAULT '',
    p_custcode                 IN    VARCHAR2 DEFAULT '',    --거래처코드
    p_orderkind                IN    VARCHAR2 DEFAULT ''    --주문경로 : ERP, SFA, 온라인

)

RETURN FN_SLORDCHECK_TABLE
AS
   v_utyn                     VARCHAR2(01);           --유통채권체크사용여부
   v_dmcreditlmt              FLOAT   (53);           --도매여신잔고
   v_ykcreditlmt              FLOAT   (53);           --약국여신잔고
   v_bwcreditlmt              FLOAT   (53);           --병원여신잔고
   v_ohcreditlmt              FLOAT   (53);           --의원여신잔고
   v_etccreditlmt             FLOAT   (53);           --기타여신잔고
   v_dmbalancelmt             FLOAT   (53);           --도매잔고
   v_ykbalancelmt             FLOAT   (53);           --약국잔고
   v_bwbalancelmt             FLOAT   (53);           --병원잔고
   v_ohbalancelmt             FLOAT   (53);           --의원잔고
   v_etcbalancelmt            FLOAT   (53);           --기타잔고
   v_dmturn                   FLOAT   (53);           --도매회전일
   v_ykturn                   FLOAT   (53);           --약국회전일
   v_bwturn                   FLOAT   (53);           --병원회전일
   v_ohturn                   FLOAT   (53);           --의원회전일
   v_etcturn                  FLOAT   (53);           --기타회전일
   v_ckyn                     VARCHAR2(01);           --채권체크사용여부
   v_nocollmt                 FLOAT   (53);           --무수금개월
   v_dmnocol                  FLOAT   (53);           --도매무수금개월
   v_yknocol                  FLOAT   (53);           --약국무수금
   v_bwnocol                  FLOAT   (53);           --병원무수금
   v_ohnocol                  FLOAT   (53);           --의원무수금
   v_etcnocol                 FLOAT   (53);           --기타무수금
   v_securitylmt              FLOAT   (53);           --담보가치한도
   v_c_utdiv                  VARCHAR2(05);           --유통구분
   v_c_credityn               VARCHAR2(01);           --신용불량구분
   v_c_sagodiv                VARCHAR2(05);           --사고처구분
   v_c_creditlmt              FLOAT   (53);           --여신한도액
   v_c_balancelmt             FLOAT   (53);           --잔고한도액
   v_c_nocollmt               FLOAT   (53);           --무수금개월
   v_c_securitylmt            FLOAT   (53);           --담보가치한도
   v_c_turnlmt                FLOAT   (53);           --회전일한도
   v_c_useyn                  VARCHAR2(01);           --채권한도사용구분
   v_balance                  FLOAT   (53);           --잔고
   v_pendbillcol              FLOAT   (53);           --미결어음
   v_totbalance               FLOAT   (53);           --총대차
   v_turncnt                  FLOAT   (53);           --회전일
   v_beforedt                 VARCHAR2(10);           --개월이전일
   v_scrtamt                  FLOAT   (53);           --담보가치
   v_creditck                 VARCHAR2(01);           --신용불량 체크
   v_sagock                   VARCHAR2(01);           --사고처 체크
   v_loanlmtck                VARCHAR2(01);           --여신한도 체크
   v_balancelmtck             VARCHAR2(01);           --잔고한도 체크
   v_nocollmtck               VARCHAR2(01);           --무수금한도 체크
   v_securitylmtck            VARCHAR2(01);           --담보가치한도 체크
   v_turnlmtck                VARCHAR2(01);           --회전일한도 체크
   
   --함수내에서 변수 저장용 변수 초기화
   SLORDCHECKLISTRECODE FN_SLORDCHECK_TABLE := FN_SLORDCHECK_TABLE(); 
BEGIN
  
   --영업기초정보
   FOR rec IN (SELECT utyn          ,
                      dmcreditlmt   ,
                      ykcreditlmt   ,
                      bwcreditlmt   ,
                      ohcreditlmt   ,
                      etccreditlmt  ,
                      dmbalancelmt  ,
                      ykbalancelmt  ,
                      bwbalancelmt  ,
                      ohbalancelmt  ,
                      etcbalancelmt ,
                      dmturn        ,
                      ykturn        ,
                      bwturn        ,
                      ohturn        ,
                      etcturn       ,
                      ckyn          ,
                      nocollmt      ,
                      securitylmt
                 FROM SLBASEM)
   LOOP
      v_utyn          := rec.utyn         ;
      v_dmcreditlmt   := rec.dmcreditlmt  ;
      v_ykcreditlmt   := rec.ykcreditlmt  ;
      v_bwcreditlmt   := rec.bwcreditlmt  ;
      v_ohcreditlmt   := rec.ohcreditlmt  ;
      v_etccreditlmt  := rec.etccreditlmt ;
      v_dmbalancelmt  := rec.dmbalancelmt ;
      v_ykbalancelmt  := rec.ykbalancelmt ;
      v_bwbalancelmt  := rec.bwbalancelmt ;
      v_ohbalancelmt  := rec.ohbalancelmt ;
      v_etcbalancelmt := rec.etcbalancelmt;
      v_dmturn        := rec.dmturn       ;
      v_ykturn        := rec.ykturn       ;
      v_bwturn        := rec.bwturn       ;
      v_ohturn        := rec.ohturn       ;
      v_etcturn       := rec.etcturn      ;
      v_ckyn          := rec.ckyn         ;
      v_nocollmt      := rec.nocollmt     ;
      v_securitylmt   := rec.securitylmt  ;
   END LOOP;

   --사용 항목의 초기화 체크
   IF (NVL (v_utyn         , 'N') = 'N') THEN v_utyn          := 'N'; END IF;          --유통채권체크사용여부
   IF (NVL (v_dmcreditlmt  , 0  ) = 0  ) THEN v_dmcreditlmt   := 0;   END IF;          --도매여신잔고
   IF (NVL (v_ykcreditlmt  , 0  ) = 0  ) THEN v_ykcreditlmt   := 0;   END IF;          --약국여신잔고
   IF (NVL (v_bwcreditlmt  , 0  ) = 0  ) THEN v_bwcreditlmt   := 0;   END IF;          --병원여신잔고
   IF (NVL (v_ohcreditlmt  , 0  ) = 0  ) THEN v_ohcreditlmt   := 0;   END IF;          --의원여신잔고
   IF (NVL (v_etccreditlmt , 0  ) = 0  ) THEN v_etccreditlmt  := 0;   END IF;          --기타여신잔고
   IF (NVL (v_dmbalancelmt , 0  ) = 0  ) THEN v_dmbalancelmt  := 0;   END IF;          --도매잔고
   IF (NVL (v_ykbalancelmt , 0  ) = 0  ) THEN v_ykbalancelmt  := 0;   END IF;          --약국잔고
   IF (NVL (v_bwbalancelmt , 0  ) = 0  ) THEN v_bwbalancelmt  := 0;   END IF;          --병원잔고
   IF (NVL (v_ohbalancelmt , 0  ) = 0  ) THEN v_ohbalancelmt  := 0;   END IF;          --의원잔고
   IF (NVL (v_etcbalancelmt, 0  ) = 0  ) THEN v_etcbalancelmt := 0;   END IF;          --기타잔고
   IF (NVL (v_dmturn       , 0  ) = 0  ) THEN v_dmturn        := 0;   END IF;          --도매회전일
   IF (NVL (v_ykturn       , 0  ) = 0  ) THEN v_ykturn        := 0;   END IF;          --약국회전일
   IF (NVL (v_bwturn       , 0  ) = 0  ) THEN v_bwturn        := 0;   END IF;          --병원회전일
   IF (NVL (v_ohturn       , 0  ) = 0  ) THEN v_ohturn        := 0;   END IF;          --의원회전일
   IF (NVL (v_etcturn      , 0  ) = 0  ) THEN v_etcturn       := 0;   END IF;          --기타회전일
   IF (NVL (v_ckyn         , 'N') = 'N') THEN v_ckyn          := 'N'; END IF;          --채권체크사용여부
   IF (NVL (v_nocollmt     , 0  ) = 0  ) THEN v_nocollmt      := 0;   END IF;          --무수금개월
   IF (NVL (v_securitylmt  , 0  ) = 0  ) THEN v_securitylmt   := 0;   END IF;          --담보가치한도


   --거래처마스터
   FOR rec IN (SELECT UTDIV      ,
                      CREDITYN   ,
                      SAGODIV    ,
                      CREDITLMT  ,
                      BALANCELMT ,
                      NOCOLLMT   ,
                      SECURITYLMT,
                      TURNLMT    ,
                      USEYN
                 FROM CMCUSTM
                WHERE CUSTCODE = p_custcode)
   LOOP
      v_c_utdiv       := rec.utdiv      ;
      v_c_credityn    := rec.credityn   ;
      v_c_sagodiv     := rec.sagodiv    ;
      v_c_creditlmt   := rec.creditlmt  ;
      v_c_balancelmt  := rec.balancelmt ;
      v_c_nocollmt    := rec.nocollmt   ;
      v_c_securitylmt := rec.securitylmt;
      v_c_turnlmt     := rec.turnlmt    ;
      v_c_useyn       := rec.useyn      ;
   END LOOP;

   --사용 항목의 초기화 체크
   IF (NVL (v_c_utdiv      , ' ') = ' ') THEN v_c_utdiv       := ' '; END IF;          --유통구분
   IF (NVL (v_c_credityn   , ' ') = ' ') THEN v_c_credityn    := 'N'; END IF;          --신용불량구분
   IF (NVL (v_c_sagodiv    , ' ') = ' ') THEN v_c_sagodiv     := 'N'; END IF;          --거래처상태
   IF (NVL (v_c_creditlmt  , 0  ) = 0  ) THEN v_c_creditlmt   := 0;   END IF;          --채권체크관리정보_여신한도액
   IF (NVL (v_c_balancelmt , 0  ) = 0  ) THEN v_c_balancelmt  := 0;   END IF;          --채권체크관리정보_잔고한도액
   IF (NVL (v_c_nocollmt   , 0  ) = 0  ) THEN v_c_nocollmt    := 0;   END IF;          --채권체크관리정보_무수금한도개월
   IF (NVL (v_c_securitylmt, 0  ) = 0  ) THEN v_c_securitylmt := 0;   END IF;          --채권체크관리정보_담보가치한도
   IF (NVL (v_c_turnlmt    , 0  ) = 0  ) THEN v_c_turnlmt     := 0;   END IF;          --채권체크관리정보_회전일한도
   IF (NVL (v_c_useyn      , ' ') = ' ') THEN v_c_useyn       := 'N'; END IF;          --채권체크관리정보_사용여부


/*
   SELECT SUM(A.JWTOTAMT    )             AS JWTOTAMT    ,  --전월잔고
          SUM(A.TOTAMT - A.RETURNTOTAMT)  AS SLTOTAMT    ,  --금월판매
          SUM(A.TOTCOL      )             AS TOTCOL      ,  --금월수금
          SUM(A.BALANCE     )             AS BALANCE     ,  --잔고
          SUM(A.PENDBILLCOL )             AS PENDBILLCOL ,  --미도래어음
          SUM(A.PENDBILLCOLJ)             AS PENDBILLCOLJ,  --자수어음
          SUM(A.PENDBILLCOLT)             AS PENDBILLCOLT,  --타수어음
          SUM(A.BALANCE + A.PENDBILLCOLJ) AS TOTYEOSIN      --총여신
     FROM (SELECT 0                   AS JWTOTAMT    ,      --전월잔고
                  SUM(TOTAMT)         AS TOTAMT      ,      --금월판매
                  SUM(RETURNTOTAMT)   AS RETURNTOTAMT,      --금월반품
                  SUM(TOTCOL)         AS TOTCOL      ,      --금월수금
                  SUM(BALANCE)        AS BALANCE     ,      --잔고
                  SUM(PENDBILLCOL)    AS PENDBILLCOL ,      --미도래어음
                  SUM(PENDBILLCOLJ)   AS PENDBILLCOLJ,      --자수어음
                  SUM(PENDBILLCOLT)   AS PENDBILLCOLT       --타수어음
             FROM SLRESULTM
            WHERE CUSTCODE  = '200393'
              AND YEARMONTH = '2017-07'
        UNION ALL
           SELECT SUM(BALANCE)        AS JWTOTAMT    ,      --전월잔고
                  SUM(TOTAMT)         AS TOTAMT      ,      --금월판매
                  SUM(RETURNTOTAMT)   AS RETURNTOTAMT,      --금월반품
                  SUM(TOTCOL)         AS TOTCOL      ,      --금월수금
                  SUM(BALANCE)        AS BALANCE     ,      --잔고
                  SUM(PENDBILLCOL)    AS PENDBILLCOL ,      --미도래어음
                  SUM(PENDBILLCOLJ)   AS PENDBILLCOLJ,      --자수어음
                  SUM(PENDBILLCOLT)   AS PENDBILLCOLT       --타수어음
             FROM SLRESULTM
            WHERE CUSTCODE  = '200393'
              AND YEARMONTH = '2017-06'
          ) A
*/

   --마감테이블(
   FOR rec IN (SELECT SUM(balance)       AS alias1,                  --잔고
                      SUM(pendbillcol)   AS alias2,                  --미도래어음
                      SUM(balance) + SUM(pendbillcol) AS alias3      --총잔고
                 FROM SLRESULTM
                WHERE custcode  = p_custcode
                  AND yearmonth = p_yearmonth)
   LOOP
      v_balance     := rec.alias1;
      v_pendbillcol := rec.alias2;
      v_totbalance  := rec.alias3;
   END LOOP;


   -- 거래처 회전일
   FOR rec IN (SELECT turncnt
                 FROM SLTURNCUSTM
                WHERE custcode = p_custcode
                  AND yearmonth = p_yearmonth)
   LOOP
      v_turncnt := rec.turncnt;
   END LOOP;


   --사용 항목의 초기화 체크
   IF (NVL (v_balance   , 0) = 0) THEN v_balance    := 0; END IF;
   IF (NVL (v_totbalance, 0) = 0) THEN v_totbalance := 0; END IF;
   IF (NVL (v_turncnt   , 0) = 0) THEN v_turncnt    := 0; END IF;
   IF (NVL (v_scrtamt   , 0) = 0) THEN v_scrtamt    := 0; END IF;

   v_creditck      := 'N';
   v_sagock        := 'N';
   v_loanlmtck     := 'N';
   v_balancelmtck  := 'N';
   v_nocollmtck    := 'N';
   v_securitylmtck := 'N';
   v_turnlmtck     := 'N';

   IF (NVL (v_c_credityn, 'N') = 'Y' ) THEN v_creditck := '*'; END IF;                                   --신용불량
   IF (NVL (v_c_sagodiv , 'N') <> '1') THEN v_sagock   := '*'; END IF;                                   --거래처상태(1:정산거래처를 제외하고는 사고거래처로 처리)


   --거래처마스터▶채권한도 사용이 Yes

   IF (NVL (v_c_useyn, 'Y') = 'Y' ) THEN

      IF ( (v_totbalance > 0) AND (v_c_creditlmt < v_totbalance) AND v_c_creditlmt != 0) THEN  v_loanlmtck    := '*'; END IF;   --여신한도  여신한도 0인 경우 무제한 출하
      IF ( (v_balance    > 0) AND (v_c_balancelmt < v_balance))   THEN  v_balancelmtck := '*'; END IF;   --잔고한도
      
      
      IF(v_c_securitylmt = 0) --담보가치금액이 0인 경우 담보내역 합계 금액 
      THEN
          --거래처담보내역(담보금액)
          --반환여부(returnyn)는 No 인 자료
          FOR rec IN (SELECT NVL (SUM (scrtamt), 0) AS alias1
                        FROM CMCUSTSCRTD
                       WHERE custcode = p_custcode
                         AND NVL(returnyn, 'N') <> 'Y')
          LOOP
             v_c_securitylmt := rec.alias1;
          END LOOP;
      END IF;
      
      --거래처담보내역(담보가치한도금액 혹은 담보내역 합계)
      v_scrtamt := v_c_securitylmt;

      IF ( (v_scrtamt > 0) AND (v_totbalance > v_scrtamt) AND v_c_creditlmt != 0) THEN v_securitylmtck := '*'; END IF;          --담보가치한도 여신한도 0인 경우 무제한 출하
      IF ( (v_turncnt > 0) AND (v_c_turnlmt  < v_turncnt)) THEN v_turnlmtck     := '*'; END IF;          --회전한도

      --무수금처 산출
      IF (v_balance > 0) THEN

         v_beforedt := TO_CHAR (ADD_MONTHS (TO_DATE (SUBSTR(p_orderdate,1,10), 'YYYY-MM-DD'), -v_c_nocollmt), 'YYYY-MM-DD');

         FOR rec IN (SELECT (CASE WHEN (DECODE (a.opendate, '', TO_CHAR (SYSDATE, 'YYYY') || '-' || SUBSTR (TO_CHAR (SYSDATE, 'MM'), 1, 1)) <>
                                        DECODE (SUBSTR(p_orderdate,1,10), '', TO_CHAR (SYSDATE, 'YYYY') || '-' || SUBSTR (TO_CHAR (SYSDATE, 'MM'), 1, 1)))
                                   AND (v_c_nocollmt > 0)
                                   AND (a.col_dt1 < v_beforedt)
                                  THEN '*'
                                  ELSE 'N'
                             END) AS alias1
                       FROM (SELECT a.custcode,
                                    a.opendate,
                                    last_col_dt,
                                    CASE WHEN last_col_dt IS NOT NULL
                                         THEN last_col_dt
                                         ELSE opendate
                                    END
                                    col_dt1
                               FROM CMCUSTM a
                          LEFT JOIN (SELECT custcode,
                                            MAX (CASE SUBSTR (saldiv, 0, 1) WHEN 'C'
                                                                             THEN orderdate
                                                                             ELSE NULL
                                                 END) last_col_dt
                                       FROM vnSalesEnd                 --주문수금VIEW
                                      WHERE orderdate <= SUBSTR(p_orderdate,1,10)
                                        AND SUBSTR (saldiv, 0, 1) = 'C'
                                   GROUP BY custcode
                                    ) b
                                  ON a.custcode = b.custcode
                            WHERE a.custcode = p_custcode
                            ) a)
         LOOP
            v_nocollmtck := rec.alias1;
         END LOOP;

      END IF;

   END IF;


   --거래처마스터▶채권한도 사용이 No,
   --영업기초정보▶채권체크의 채권체크 사용여부가 Yes

   IF ( (NVL (v_c_useyn, 'Y') = 'N') AND (NVL (v_ckyn, 'N') = 'Y')) THEN
      IF ( (v_scrtamt > 0) AND (v_totbalance > v_scrtamt)) THEN v_securitylmtck := '*'; END IF;                   --담보가치한도
   END IF;


   --거래처마스터▶채권한도 사용이 No,
   --영업기초정보▶유통별 채권관리 기준의 유통별 채권관리 기준 사용여부가 Yes

   IF ( (NVL (v_c_useyn, 'Y') = 'N') AND (NVL (v_utyn, 'N') = 'Y')) THEN

      --여신한도
      IF (SUBSTR (v_c_utdiv, 0, 1) = '1') THEN
         IF ( (v_totbalance > 0) AND (v_dmcreditlmt < v_totbalance))    THEN v_loanlmtck := '*';      END IF;     --도매
      ELSIF (SUBSTR (v_c_utdiv, 0, 1) = '2') THEN
         IF ( (v_totbalance > 0) AND (v_ykcreditlmt < v_totbalance))    THEN v_loanlmtck := '*';      END IF;     --약국
      ELSIF (SUBSTR (v_c_utdiv, 0, 1) = '3') THEN
         IF ( (v_totbalance > 0) AND (v_bwcreditlmt < v_totbalance))    THEN v_loanlmtck := '*';      END IF;     --병원
      ELSIF (SUBSTR (v_c_utdiv, 0, 1) = '4') THEN
         IF ( (v_totbalance > 0) AND (v_ohcreditlmt < v_totbalance))    THEN v_loanlmtck := '*';      END IF;     --의원
      ELSE
         IF ( (v_totbalance > 0) AND (v_etccreditlmt < v_totbalance))   THEN v_loanlmtck := '*';      END IF;     --기타
      END IF;

      --잔고한도
      IF (SUBSTR (v_c_utdiv, 0, 1) = '1') THEN
         IF ( (v_balance > 0) AND (v_dmbalancelmt < v_balance))         THEN v_balancelmtck := '*';   END IF;     --도매
      ELSIF (SUBSTR (v_c_utdiv, 0, 1) = '2') THEN
         IF ( (v_balance > 0) AND (v_ykbalancelmt < v_balance))         THEN v_balancelmtck := '*';   END IF;     --약국
      ELSIF (SUBSTR (v_c_utdiv, 0, 1) = '3') THEN
         IF ( (v_balance > 0) AND (v_bwbalancelmt < v_balance))         THEN v_balancelmtck := '*';   END IF;     --병원
      ELSIF (SUBSTR (v_c_utdiv, 0, 1) = '4') THEN
         IF ( (v_balance > 0) AND (v_ohbalancelmt < v_balance))         THEN v_balancelmtck := '*';   END IF;     --의원
      ELSE
         IF ( (v_balance > 0) AND (v_etcbalancelmt < v_balance))        THEN v_balancelmtck := '*';   END IF;     --기타
      END IF;

      --회전한도
      IF (SUBSTR (v_c_utdiv, 0, 1) = '1') THEN
         IF ( (v_turncnt > 0) AND (v_dmturn < v_turncnt))               THEN v_turnlmtck := '*';      END IF;     --도매
      ELSIF (SUBSTR (v_c_utdiv, 0, 1) = '2') THEN
         IF ( (v_turncnt > 0) AND (v_ykturn < v_turncnt))               THEN v_turnlmtck := '*';      END IF;     --약국
      ELSIF (SUBSTR (v_c_utdiv, 0, 1) = '3') THEN
         IF ( (v_turncnt > 0) AND (v_bwturn < v_turncnt))               THEN v_turnlmtck := '*';      END IF;     --병원
      ELSIF (SUBSTR (v_c_utdiv, 0, 1) = '4') THEN
         IF ( (v_turncnt > 0) AND (v_ohturn < v_turncnt))               THEN v_turnlmtck := '*';      END IF;     --의원
      ELSE
         IF ( (v_turncnt > 0) AND (v_etcturn < v_turncnt))              THEN v_turnlmtck := '*';      END IF;     --기타
      END IF;

      v_beforedt := TO_CHAR ( ADD_MONTHS (TO_DATE (SUBSTR(p_orderdate,1,10), 'yyyy-mm-dd' ), - v_nocollmt), 'yyyy-mm-dd');

      --UTILS.CONVERT_TO_VARCHAR2(utils.dateadd('MONTH', -v_nocollmt, v_orderdate),10,v_style=>121) ;

      --무수금처
      IF (v_balance > 0) THEN

         FOR rec IN (SELECT (CASE WHEN(DECODE (a.opendate, '', TO_CHAR (SYSDATE, 'YYYY') || '-' || SUBSTR (TO_CHAR (SYSDATE, 'MM'), 1, 1)) <>
                                       DECODE (SUBSTR(p_orderdate,1,10), '', TO_CHAR (SYSDATE, 'YYYY') || '-' || SUBSTR (TO_CHAR (SYSDATE, 'MM'), 1, 1)))
                                   AND (v_nocollmt > 0)
                                   AND (a.col_dt1 < v_beforedt)
                                   AND (a.sal_dt1 < v_beforedt)
                                  THEN '*'
                                  ELSE 'N'
                             END) AS alias1
                       FROM (SELECT a.custcode,
                                    a.opendate,
                                    last_col_dt,
                                    last_sal_dt,
                                    CASE WHEN last_col_dt IS NOT NULL
                                         THEN last_col_dt
                                         ELSE opendate
                                    END col_dt1,
                                    CASE WHEN last_sal_dt IS NOT NULL
                                         THEN last_sal_dt
                                         ELSE opendate
                                    END sal_dt1
                               FROM CMCUSTM a
                          LEFT JOIN (SELECT custcode,
                                            MAX (CASE SUBSTR (saldiv, 0, 1) WHEN 'C'
                                                                            THEN appdate
                                                                            ELSE NULL
                                                 END) last_col_dt,
                                            MAX (CASE WHEN SUBSTR (saldiv, 0, 1) = 'A'
                                                      THEN appdate
                                                      ELSE NULL
                                                 END) last_sal_dt
                                       FROM vnSalesEnd                                           --주문수금VIEW
                                      WHERE orderdate <= SUBSTR(p_orderdate,1,10)
                                        AND SUBSTR (saldiv, 0, 1) <> 'B'
                                        AND (saldiv IN (SELECT divcode
                                                          FROM SLCONDRESULT)
                                         OR  coldiv IN (SELECT divcode
                                                          FROM SLCONDRESULT))
                                        AND statediv = '09'
                                   GROUP BY custcode
                                    ) b
                                 ON a.custcode = b.custcode
                              WHERE a.custcode = p_custcode
                            ) A)
         LOOP
            v_nocollmtck := rec.alias1;
         END LOOP;

      END IF;

   END IF;

   SLORDCHECKLISTRECODE.EXTEND;
   SLORDCHECKLISTRECODE(1) := FN_SLORDCHECK_VARIABLE(v_creditck, v_sagock, v_loanlmtck, v_balancelmtck, v_nocollmtck, v_securitylmtck, v_turnlmtck);
   
   RETURN (SLORDCHECKLISTRECODE);

EXCEPTION WHEN OTHERS THEN RETURN (SLORDCHECKLISTRECODE);
END;
/
