CREATE PROCEDURE        spACacc0916R
-- ---------------------------------------------------------------
-- 프로시저명   : spACacc0916R
-- 작 성 자   : 최용석
-- 작성일자    : 2017-11-23
-- 프로시저 설명 : 기간별수금현황을 조회하는 프로시저이다.
-- ---------------------------------------------------------------
(
    p_div            IN VARCHAR2 DEFAULT '',

    p_compcode		   IN VARCHAR2 DEFAULT '',
    p_plantcode 	   IN VARCHAR2 DEFAULT '',
    p_strdate  		   IN VARCHAR2 DEFAULT '',
    p_enddate  		   IN VARCHAR2 DEFAULT '',

    p_userid		     IN VARCHAR2 DEFAULT '',
    p_reasondiv 	   IN VARCHAR2 DEFAULT '',
    p_reasontext	   IN VARCHAR2 DEFAULT '',
    MESSAGE 		     OUT VARCHAR2,
    IO_CURSOR		     OUT TYPES.DataSet
)
AS
BEGIN

    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    if (p_div = 'T') then   -- 계정명칭 조회
        open IO_CURSOR for
        select   max(case when ord =  1 then divname else '' end) as colamt01
                ,max(case when ord =  2 then divname else '' end) as colamt02
                ,max(case when ord =  3 then divname else '' end) as colamt03
                ,max(case when ord =  4 then divname else '' end) as colamt04
                ,max(case when ord =  5 then divname else '' end) as colamt05
                ,max(case when ord =  6 then divname else '' end) as colamt06
                ,max(case when ord =  7 then divname else '' end) as colamt07
                ,max(case when ord =  8 then divname else '' end) as colamt08
                ,max(case when ord =  9 then divname else '' end) as colamt09
                ,max(case when ord = 10 then divname else '' end) as colamt10
                ,max(case when ord = 11 then divname else '' end) as colamt11
                ,max(case when ord = 12 then divname else '' end) as colamt12
                ,max(case when ord = 13 then divname else '' end) as colamt13
                ,max(case when ord = 14 then divname else '' end) as colamt14
                ,max(case when ord = 15 then divname else '' end) as colamt15
                ,max(case when ord = 16 then divname else '' end) as colamt16
                ,max(case when ord = 17 then divname else '' end) as colamt17
                ,max(case when ord = 18 then divname else '' end) as colamt18
                ,max(case when ord = 19 then divname else '' end) as colamt19
                ,max(case when ord = 20 then divname else '' end) as colamt20
        from (
--            select  divcode, divname, row_number() over(order by divcode) as ord
--            from    CMCOMMONM
--            where   cmmcode = 'SL18'
--                    and usediv = 'Y'
            select  distinct b.divcode, b.divname, b.ord
            from    SLCOLM a
                    join (
                        select  divcode, divname, row_number() over(order by divcode) as ord
                        from    CMCOMMONM
                        where   cmmcode = 'SL18'
                                and usediv = 'Y'
                    ) b on a.coldiv = b.divcode
            where   a.plantcode like p_plantcode
                    and a.appdate between p_strdate and p_enddate
                    and a.statediv = '09'
        ) a;

    elsif (p_div = 'S') then
        open IO_CURSOR for
        select   a.custcode
                ,max(b.custname) as custname
                ,max(b.businessno) as businessno
                ,sum(case when a.ord =  1 then a.colamt else 0 end) as colamt01
                ,sum(case when a.ord =  2 then a.colamt else 0 end) as colamt02
                ,sum(case when a.ord =  3 then a.colamt else 0 end) as colamt03
                ,sum(case when a.ord =  4 then a.colamt else 0 end) as colamt04
                ,sum(case when a.ord =  5 then a.colamt else 0 end) as colamt05
                ,sum(case when a.ord =  6 then a.colamt else 0 end) as colamt06
                ,sum(case when a.ord =  7 then a.colamt else 0 end) as colamt07
                ,sum(case when a.ord =  8 then a.colamt else 0 end) as colamt08
                ,sum(case when a.ord =  9 then a.colamt else 0 end) as colamt09
                ,sum(case when a.ord = 10 then a.colamt else 0 end) as colamt10
                ,sum(case when a.ord = 11 then a.colamt else 0 end) as colamt11
                ,sum(case when a.ord = 12 then a.colamt else 0 end) as colamt12
                ,sum(case when a.ord = 13 then a.colamt else 0 end) as colamt13
                ,sum(case when a.ord = 14 then a.colamt else 0 end) as colamt14
                ,sum(case when a.ord = 15 then a.colamt else 0 end) as colamt15
                ,sum(case when a.ord = 16 then a.colamt else 0 end) as colamt16
                ,sum(case when a.ord = 17 then a.colamt else 0 end) as colamt17
                ,sum(case when a.ord = 18 then a.colamt else 0 end) as colamt18
                ,sum(case when a.ord = 19 then a.colamt else 0 end) as colamt19
                ,sum(case when a.ord = 20 then a.colamt else 0 end) as colamt20
                ,sum(a.colamt) as colamt
                ,min(FNstuff(c.slipinno,9,0,'-')) as slipinno
        from (
            select  a.custcode
                    ,a.colno
                    ,a.colamt
                    ,b.ord
            from    SLCOLM a
                    join (
                        select  divcode, row_number() over(order by divcode) as ord
                        from    CMCOMMONM
                        where   cmmcode = 'SL18'
                                and usediv = 'Y'
                    ) b on a.coldiv = b.divcode
            where   a.plantcode like p_plantcode
                    and a.appdate between p_strdate and p_enddate
                    and a.statediv = '09'
        ) a
            left join CMCUSTM b
                on a.custcode = b.custcode
            left join ACAUTOORDT c
                on a.colno = c.acatno
        group by a.custcode
        order by a.custcode;

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
