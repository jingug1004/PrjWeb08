CREATE FUNCTION        FNdatediff
(
  p_div   IN VARCHAR2 DEFAULT ' ', 
  p_sTime IN VARCHAR2 DEFAULT ' ' ,
  p_eTime IN VARCHAR2 DEFAULT ' ' 
 
)
RETURN NUMBER
AS
   --p_dTime VARCHAR2(10);
   p_dTime NUMBER;
BEGIN
    
   
    
    
    IF (LENGTH(p_sTime) =5 ) THEN
        IF ( UPPER(p_div) = 'DAY' OR UPPER(p_div) = 'DD' ) THEN 
            p_dTime := CEIL(TO_DATE(p_eTime,'HH24:MISS')  - TO_DATE(p_sTime,'HH24:MISS'));     -- 일
        ELSIF ( UPPER(p_div) = 'HH' ) THEN 
            p_dTime := (TO_DATE(p_eTime,'HH24:MISS')  - TO_DATE(p_sTime,'HH24:MISS'))*24;       -- 시                      
        ELSIF ( UPPER(p_div) = 'MI' ) THEN 
            p_dTime := (TO_DATE(p_eTime,'HH24:MISS')  - TO_DATE(p_sTime,'HH24:MISS'))*24*60;    -- 분
        ELSIF ( UPPER(p_div) = 'SEC' ) THEN
            p_dTime := (TO_DATE(p_eTime,'HH24:MISS')  - TO_DATE(p_sTime,'HH24:MISS'))*24*60*60; -- 초
        END IF;    
        
       
    ELSIF (LENGTH(p_sTime) > 5 ) THEN
        
        IF ( UPPER(p_div) = 'DAY' OR UPPER(p_div) = 'DD' ) THEN 
            p_dTime := CEIL(TO_DATE(p_eTime,'YYYY-MM-DDHH24:MISS')  - TO_DATE(p_sTime,'YYYY-MM-DDHH24:MISS'));     -- 일
        ELSIF ( UPPER(p_div) = 'HH' ) THEN 
            p_dTime := (TO_DATE(p_eTime,'YYYY-MM-DDHH24:MISS')  - TO_DATE(p_sTime,'YYYY-MM-DDHH24:MISS'))*24;       -- 시                      
        ELSIF ( UPPER(p_div) = 'MI' ) THEN 
            p_dTime := (TO_DATE(p_eTime,'YYYY-MM-DDHH24:MISS')  - TO_DATE(p_sTime,'YYYY-MM-DDHH24:MISS'))*24*60;    -- 분
        ELSIF ( UPPER(p_div) = 'SEC' ) THEN
            p_dTime := (TO_DATE(p_eTime,'YYYY-MM-DDHH24:MISS')  - TO_DATE(p_sTime,'YYYY-MM-DDHH24:MISS'))*24*60*60; -- 초
        ELSIF ( UPPER(p_div) = 'MONTH' ) THEN
            p_dTime := (TO_DATE(p_eTime,'YYYY-MM-DD')  - TO_DATE(p_sTime,'YYYY-MM-DD')); -- 초
        END IF;    
    ELSE
        p_dTime :=0;
    END IF;
    
    RETURN (TO_NUMBER(p_dTime));
    --EXCEPTION WHEN OTHERS THEN utils.handleerror(SQLCODE,SQLERRM);
END ;
/
