CREATE PROCEDURE        spACbase0003P
  -- ---------------------------------------------------------------
  -- 프로시저명      : spACbase0003P
  -- 작 성 자      : 최기홍
  -- 작성일자       : 2010-08-23
  -- 수 정 자      : 강현호
  -- E-Mail     : roykang0722@gmail.com
  -- 수정일자      : 2016-12-12
  -- ---------------------------------------------------------------
  -- 프로시저 설명    : 법인카드마스터 (ACCARDM)를 등록,수정,삭제,조회하는 프로시저이다.
  -- ---------------------------------------------------------------
(
    p_div         IN     VARCHAR2 DEFAULT '',

    p_compcode    IN     VARCHAR2 DEFAULT '',
    p_cardno      IN     VARCHAR2 DEFAULT '',
    p_cardname    IN     VARCHAR2 DEFAULT '',
    p_carddiv     IN     VARCHAR2 DEFAULT '',
    p_cardcls     IN     VARCHAR2 DEFAULT '',
    p_cardcustom  IN     VARCHAR2 DEFAULT '',
    p_limitamt    IN     FLOAT    DEFAULT 0,
    p_apprday     IN     CHAR     DEFAULT '',
    p_publishdate IN     VARCHAR2 DEFAULT '',
    p_validdate   IN     VARCHAR2 DEFAULT '',
    p_bankcode    IN     VARCHAR2 DEFAULT '',
    p_accountno   IN     VARCHAR2 DEFAULT '',
    p_empcode     IN     VARCHAR2 DEFAULT '',
    p_deptcode    IN     VARCHAR2 DEFAULT '',
    p_plantcode   IN     VARCHAR2 DEFAULT '',
    p_custcode    IN     VARCHAR2 DEFAULT '',
    p_enddiv      IN     VARCHAR2 DEFAULT '',
    p_useyn       IN     VARCHAR2 DEFAULT '',
    p_iempcode    IN     VARCHAR2 DEFAULT '',

    p_userid      IN     VARCHAR2 DEFAULT '',
    p_reasondiv   IN     VARCHAR2 DEFAULT '',
    p_reasontext  IN     VARCHAR2 DEFAULT '',
    MESSAGE       OUT    VARCHAR2,
    IO_CURSOR     OUT    TYPES.DataSet
)
AS
    v_temp          NUMBER := 0;

BEGIN

    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    if (p_div = 'S') then
        open IO_CURSOR for
        select  nvl(a.compcode, '') as compcode,
                nvl(a.cardno, '') as cardno,
                nvl(a.cardname, '') as cardname,
                nvl(a.carddiv, '') as carddiv,
                nvl(a.cardcls, '') as cardcls,
                nvl(a.cardcustom, '') as cardcustom,
                nvl(a.limitamt, 0) as limitamt,
                nvl(a.apprday, '') as apprday,
                nvl(a.publishdate, '') as publishdate,
                nvl(a.validdate, '') as validdate,
                nvl(a.bankcode, '') as bankcode,
                nvl(a.accountno, '') as accountno,
                nvl(a.empcode, '') as empcode,
                nvl(a.deptcode, '') as deptcode,
                nvl(a.plantcode, '') as plantcode,
                nvl(a.enddiv, '') as enddiv,
                nvl(a.useyn, '') as useyn,
                nvl(b.empname, '') as empname,
                nvl(c.deptname, '') as deptname,
                nvl(d.accremark, '') as accremark,
                nvl(a.custcode, '') as custcode,
                nvl(e.custname, '') as custname
        from    ACCARDM a
                left join CMEMPM b
                    on a.empcode = b.empcode
                left join CMDEPTM c
                    on a.deptcode = c.deptcode
                left join CMACCOUNTM d
                    on a.compcode = d.compcode
                    and a.accountno = d.accountno
                left join CMCUSTM e
                    on a.custcode = e.custcode
        where   a.compcode = p_compcode
                and replace(replace(a.cardno, '_', ''), '-', '') like '%' || replace(replace(p_cardno, '_', ''), '-', '') || '%'
                and nvl(a.deptcode, ' ') like p_deptcode || '%'
        order by a.cardno;

    -- 키중복체크
    elsif (p_div = 'SC') then
        for rec in (
            select  count(compcode) as cardcnt
            from    ACCARDM
            where   compcode = p_compcode
                    and cardno = p_cardno)
        loop
            MESSAGE := rec.cardcnt;
        end loop;

    elsif (p_div = 'I') then
        insert into ACCARDM
            (
                compcode,
                cardno,
                cardname,
                carddiv,
                cardcls,
                cardcustom,
                limitamt,
                apprday,
                publishdate,
                validdate,
                bankcode,
                accountno,
                empcode,
                deptcode,
                plantcode,
                custcode,
                enddiv,
                useyn,
                insertdt,
                iempcode
            )
        values
            (
                p_compcode,
                p_cardno,
                p_cardname,
                p_carddiv,
                p_cardcls,
                p_cardcustom,
                p_limitamt,
                p_apprday,
                p_publishdate,
                p_validdate,
                p_bankcode,
                p_accountno,
                p_empcode,
                p_deptcode,
                p_plantcode,
                p_custcode,
                p_enddiv,
                p_useyn,
                sysdate,
                p_iempcode
            );

    elsif (p_div = 'U') then
        update  ACCARDM
        set     cardname = p_cardname,
                carddiv = p_carddiv,
                cardcls = p_cardcls,
                cardcustom = p_cardcustom,
                limitamt = p_limitamt,
                apprday = p_apprday,
                publishdate = p_publishdate,
                validdate = p_validdate,
                bankcode = p_bankcode,
                accountno = p_accountno,
                empcode = p_empcode,
                deptcode = p_deptcode,
                plantcode = p_plantcode,
                custcode = p_custcode,
                enddiv = p_enddiv,
                useyn = p_useyn,
                updatedt = sysdate,
                uempcode = p_iempcode
        where   compcode = p_compcode
                and cardno = p_cardno;

    elsif (p_div = 'D') then
        delete
        from    ACCARDM
        where   compcode = p_compcode
                and cardno = p_cardno;

    elsif (p_div = 'I2') then
        select  count(*) into v_temp
        from    ACCARDM
        where   compcode = p_compcode
                and cardno = p_cardno;

        if v_temp = 1 then
            update  ACCARDM
            set     cardname = p_cardname,
                    carddiv = p_carddiv,
                    cardcls = p_cardcls,
                    cardcustom = p_cardcustom,
                    limitamt = p_limitamt,
                    apprday = p_apprday,
                    publishdate = p_publishdate,
                    validdate = p_validdate,
                    bankcode = p_bankcode,
                    accountno = p_accountno,
                    empcode = p_empcode,
                    deptcode = p_deptcode,
                    plantcode = p_plantcode,
                    custcode = p_custcode,
                    enddiv = p_enddiv,
                    useyn = p_useyn,
                    updatedt = sysdate,
                    uempcode = p_iempcode
            where   compcode = p_compcode
                    and cardno = p_cardno;
        else
            insert into ACCARDM
                (
                    compcode,
                    cardno,
                    cardname,
                    carddiv,
                    cardcls,
                    cardcustom,
                    limitamt,
                    apprday,
                    publishdate,
                    validdate,
                    bankcode,
                    accountno,
                    empcode,
                    deptcode,
                    plantcode,
                    custcode,
                    enddiv,
                    useyn,
                    insertdt,
                    iempcode
                )
            select  p_compcode,
                    p_cardno,
                    p_cardname,
                    p_carddiv,
                    p_cardcls,
                    p_cardcustom,
                    p_limitamt,
                    p_apprday,
                    p_publishdate,
                    p_validdate,
                    p_bankcode,
                    p_accountno,
                    p_empcode,
                    p_deptcode,
                    p_plantcode,
                    p_custcode,
                    p_enddiv,
                    p_useyn,
                    sysdate,
                    p_iempcode
            from    DUAL;
        end if;

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
