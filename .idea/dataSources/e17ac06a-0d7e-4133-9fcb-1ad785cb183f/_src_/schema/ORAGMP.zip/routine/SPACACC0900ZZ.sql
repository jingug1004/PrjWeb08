CREATE PROCEDURE        spACacc0900ZZ(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0900ZZ
	-- 작 성 자         : 이영재
	-- 작성일자         : 2010-11-25
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-19
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 전표로드 공통함수 구성
	-- 수정 : 2011-02-09 이영재 영업 매출전표로드 처리를 회계모듈로 변경 작업
	--   매입 세금계산서와 회계로드 개별 기능을 실행한다.
	-- ---------------------------------------------------------------


	p_div			   IN	  VARCHAR2 DEFAULT '',
	p_compcode		   IN	  VARCHAR2 DEFAULT '',
	p_plantcode 	   IN	  VARCHAR2 DEFAULT '',
	p_plantname 	   IN	  VARCHAR2 DEFAULT '',
	p_sdt			   IN	  VARCHAR2 DEFAULT '',
	p_edt			   IN	  VARCHAR2 DEFAULT '',
	p_taxno 		   IN	  VARCHAR2 DEFAULT '',
	p_appdate		   IN	  VARCHAR2 DEFAULT '',
	p_slipindate	   IN	  VARCHAR2 DEFAULT '',
	p_slipinseq 	   IN	  NUMBER DEFAULT 0,
	p_buydiv		   IN	  VARCHAR2 DEFAULT '',
	p_deptcode		   IN	  VARCHAR2 DEFAULT '',
	p_empcode		   IN	  VARCHAR2 DEFAULT '',
	p_taxamt1		   IN	  FLOAT DEFAULT 0,
	p_taxamt2		   IN	  FLOAT DEFAULT 0,
	p_taxamt3		   IN	  FLOAT DEFAULT 0,
	p_finishamt1	   IN	  FLOAT DEFAULT 0,
	p_finishamt2	   IN	  FLOAT DEFAULT 0,
	p_finishamt3	   IN	  FLOAT DEFAULT 0,
	p_finishamt4	   IN	  FLOAT DEFAULT 0,
	p_finishamt5	   IN	  FLOAT DEFAULT 0,
	p_finishamt6	   IN	  FLOAT DEFAULT 0,
	p_finishamt7	   IN	  FLOAT DEFAULT 0,
	p_finishamt8	   IN	  FLOAT DEFAULT 0,
	p_itemnm		   IN	  VARCHAR2 DEFAULT '', --매입 적요와 상품명(세금계산서)
	p_chk			   IN	  VARCHAR2 DEFAULT '',
	p_custcode		   IN	  VARCHAR2 DEFAULT '',
	p_custname		   IN	  VARCHAR2 DEFAULT '',
	p_businessno	   IN	  VARCHAR2 DEFAULT '',
	p_iempcode		   IN	  VARCHAR2 DEFAULT '',
	p_loadstatus	   IN	  VARCHAR2 DEFAULT '',
	p_actrnstate	   IN	  VARCHAR2 DEFAULT '',
	p_acatrulecode	   IN	  VARCHAR2 DEFAULT '',
	p_warehousingno    IN	  VARCHAR2 DEFAULT '',
	p_lccode		   IN	  VARCHAR2 DEFAULT '',
	p_lcname		   IN	  VARCHAR2 DEFAULT '',
	p_userid		   IN	  VARCHAR2 DEFAULT '',
	p_reasondiv 	   IN	  VARCHAR2 DEFAULT '',
	p_reasontext	   IN	  VARCHAR2 DEFAULT '',
	MESSAGE 			  OUT VARCHAR2,
	IO_CURSOR			  OUT TYPES.DATASET
)
AS
	ip_compcode   VARCHAR2(3) := p_compcode;
	ip_taxno	  VARCHAR2(40) := p_taxno;
	p_slipno	  VARCHAR2(20);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	FOR rec IN (SELECT compcode -- 법인코드 확인
				FROM   CMPLANTM
				WHERE  plantcode LIKE p_plantcode || '%'
					   AND ROWNUM <= 1)
	LOOP
		ip_compcode := rec.compcode;
	END LOOP;

	IF (UPPER(P_DIV) = 'TAXDTL')
	THEN
		--영업 회계로드에서 세금계산서별 상세 매출 내역 확인
		OPEN IO_CURSOR FOR
			SELECT z.taxno taxno,
				   a.orderdate orderdate,
				   a.orderno orderno,
				   a.orderseq orderseq,
				   a.saldiv saldiv,
				   NVL(sl10.divname, '') saldivname,
				   b.itemcode itemcode,
				   D.itemname itemname,
				   b.salqty salqty,
				   b.salprc salprc,
				   b.salamt * CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END salamt,
				   CASE WHEN NVL(D.itempart, '') NOT IN ('02', '08') THEN b.salamt * CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END ELSE 0 END amt1,
				   CASE WHEN NVL(D.itempart, '') IN ('02', '08') THEN b.salamt * CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END ELSE 0 END amt2,
				   b.salvat * CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END salvat,
				   b.totamt * CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END totamt
			FROM   SLTAXM z
				   JOIN SLORDM a ON z.taxno = a.taxdate
				   JOIN SLORDD b ON a.orderno = b.orderno
				   JOIN CMITEMM D ON b.itemcode = D.itemcode
				   LEFT JOIN CMCOMMONM sl10
					   ON sl10.cmmcode = 'SL10'
						  AND sl10.divcode = a.saldiv
			WHERE  z.plantcode LIKE p_plantcode
				   AND z.taxdt BETWEEN p_sdt AND p_edt
				   AND NVL(z.deleteyn, ' ') <> 'Y'
				   AND NVL(z.taxno, ' ') = NVL(ip_taxno,' ');
	ELSIF (UPPER(P_DIV) = 'TAXDTL2')
	THEN
		--영업 회계로드에서 세금계산서별 상세 매출 내역 확인
		OPEN IO_CURSOR FOR
			SELECT a.taxdate taxno,
				   a.orderdate orderdate,
				   a.orderno orderno,
				   a.orderseq orderseq,
				   a.saldiv saldiv,
				   NVL(sl10.divname, '') saldivname,
				   b.itemcode itemcode,
				   D.itemname itemname,
				   b.salqty salqty,
				   b.salprc salprc,
				   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN b.salamt ELSE (-1) * b.salamt END salamt,
				   CASE WHEN NVL(D.itempart, ' ') NOT IN ('02', '08') THEN CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN b.salamt ELSE (-1) * b.salamt END ELSE 0 END amt1,
				   CASE WHEN NVL(D.itempart, ' ') IN ('02', '08') THEN CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN b.salamt ELSE (-1) * b.salamt END ELSE 0 END amt2,
				   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN b.salvat ELSE (-1) * b.salvat END salvat,
				   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN b.totamt ELSE (-1) * b.totamt END totamt
			FROM   SLORDM a
				   JOIN SLORDD b ON a.orderno = b.orderno
				   JOIN CMITEMM D ON b.itemcode = D.itemcode
				   LEFT JOIN CMCOMMONM sl10
					   ON sl10.cmmcode = 'SL10'
						  AND sl10.divcode = a.saldiv
				   LEFT JOIN CMCUSTM c ON c.custcode = a.custcode
			WHERE  a.plantcode = p_plantcode
				   AND a.custcode = p_custcode
				   AND a.appdate BETWEEN p_sdt AND p_edt
				   AND NVL(a.statediv, ' ') = '09'
				   AND (p_buydiv = '91' -- 역발행
						AND a.saldiv NOT IN ('A09', 'A21', 'A22', 'A61', 'A63', 'A71', 'A73', 'B51', 'B52', 'B61')
						AND (SUBSTR(c.utdiv, 0, 1) = '5'
							 OR c.taxdiv = '9')
						OR p_buydiv = '92' -- 사원판매
						   AND NVL(a.saldiv, ' ') = 'A09'
						OR p_buydiv = '99' -- 직수출
						   AND NVL(a.saldiv, ' ') = 'A22');
	ELSIF (UPPER(P_DIV) = 'ORDDTL')
	THEN
		--영업 회계로드에서 세금계산서별 상세 매출 내역 확인
		OPEN IO_CURSOR FOR
			SELECT b.seq orderseq,
				   b.itemcode itemcode,
				   c.itemname itemname,
				   b.salqty salqty,
				   b.salprc salprc,
				   b.salamt * CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END salamt,
				   CASE WHEN NVL(c.itempart, ' ') NOT IN ('02', '08') THEN b.salamt * CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END ELSE 0 END amt1,
				   CASE WHEN NVL(c.itempart, ' ') IN ('02', '08') THEN b.salamt * CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END ELSE 0 END amt2,
				   b.salvat * CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END salvat,
				   b.totamt * CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END totamt
			FROM   SLORDM a
				   JOIN SLORDD b ON a.orderno = b.orderno
				   JOIN CMITEMM c ON b.itemcode = c.itemcode
			WHERE  a.plantcode LIKE p_plantcode
				   AND a.orderno = ip_taxno;
	ELSIF (UPPER(P_DIV) = 'ITAXSALE')
	THEN
		--세금계산서 생성.
		ip_taxno := SUBSTR(REPLACE(p_slipindate, '-', ''), 0, 6) || '1' || SUBSTR(p_buydiv, -1, 1); -- 자동생성구분

		FOR rec IN (SELECT ip_taxno || SUBSTR('00000' || TO_CHAR((NVL(SUBSTR(MAX(taxno), -5, 5), 0) + 1)), -5, 5) AS alias1
					FROM   ACTAXM
					WHERE  compcode = ip_compcode
						   --and plantcode = @plantcode
						   AND taxno LIKE ip_taxno || '%'
						   AND LENGTH(taxno) = 13
						   AND iotaxdiv = '02'
						   AND saleinyn = 'Y')
		LOOP
			ip_taxno := rec.alias1;
		END LOOP;

		INSERT INTO ACTAXM(compcode,
						   plantcode,
						   taxno, --yyyy1xnnnnn
						   taxdiv, --계산서 구분( select * from cmcommonm where cmmcode = 'AC60' )
						   iotaxdiv, --매입매출구분( select * from cmcommonm where cmmcode = 'AC61' )
						   sdeptcode,
						   taxdate,
						   custcode,
						   custname,
						   businessno,
						   biznotype, --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
						   blankcnt,
						   amt,
						   vat,
						   vatamt,
						   purposediv, --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
						   importsdate,
						   importedate,
						   electaxyn, --전자세금계산서여부
						   saleinyn, --영업자동생성여부
						   insertdt,
						   iempcode)
		VALUES		(ip_compcode,
					 p_plantcode,
					 ip_taxno, -- yyyy1xnnnnn  번호 생성
					 CASE WHEN p_buydiv = '91' THEN '115' --역발행매입구분(  select * from cmcommonm where cmmcode = 'AC60'  )
														 WHEN p_buydiv = '92' THEN '101' --매출 - 과세(  select * from cmcommonm where cmmcode = 'AC60'  )
																						WHEN p_buydiv = '99' THEN '106' --매출 - 수출(  select * from cmcommonm where cmmcode = 'AC60'  )
																													   ELSE '115' --계산서 구분(  select * from cmcommonm where cmmcode = 'AC60'  )
																																 END,
					 '02', --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
					 p_deptcode,
					 p_slipindate,
					 p_custcode,
					 p_custname,
					 p_businessno,
					 CASE WHEN p_buydiv = '92' THEN '02' ELSE '01' --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
																  END,
					 0,
					 p_taxamt1,
					 p_taxamt2,
					 p_taxamt3,
					 CASE WHEN p_buydiv = '91' THEN '02' ELSE '01' --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
																  END,
					 p_sdt,
					 p_edt,
					 'Y' --전자세금계산서여부
						,
					 'Y' --영업자동생성여부
						,
					 SYSDATE,
					 p_iempcode);

		INSERT INTO ACTAXD(compcode,
						   plantcode,
						   taxno, -- yyyy11nnnnn
						   seq,
						   itemnm, -- ITEM
						   amt,
						   vat,
						   vatamt,
						   insertdt,
						   iempcode)
		VALUES		(ip_compcode, -- select * from actaxm
					 p_plantcode,
					 ip_taxno, -- yyyy11nnnnn  번호 생성
					 1,
					 p_itemnm, --+ ' 외'
					 p_taxamt1,
					 p_taxamt2,
					 p_taxamt3,
					 SYSDATE,
					 p_iempcode);

		-- 영업전표의 세금계산서번호 저장
		MERGE INTO SLORDM a
		USING	   (SELECT A.ORDERNO, A.ORDERDATE, A.ORDERSEQ
					FROM   SLORDM a
						   JOIN SLORDD b ON a.orderno = b.orderno
						   JOIN CMITEMM D ON b.itemcode = D.itemcode
						   LEFT JOIN CMCOMMONM sl10
							   ON sl10.cmmcode = 'SL10'
								  AND sl10.divcode = a.saldiv
						   JOIN CMCUSTM c ON a.custcode = c.custcode
					WHERE  a.plantcode = p_plantcode
						   AND a.custcode = p_custcode
						   AND a.appdate BETWEEN p_sdt AND p_edt
						   AND NVL(a.statediv, ' ') = '09'
						   AND (p_buydiv = '91' -- 역발행
								AND a.saldiv NOT IN ('A09', 'A21', 'A22', 'A61', 'A63', 'A71', 'A73', 'B51', 'B52', 'B61')
								AND (SUBSTR(c.utdiv, 0, 1) = '5'
									 OR c.taxdiv = '9')
								OR p_buydiv = '92' -- 사원판매
								   AND NVL(a.saldiv, ' ') = 'A09'
								OR p_buydiv = '99' -- 직수출
								   AND NVL(a.saldiv, ' ') = 'A22')) src
		ON		   (A.ORDERNO = SRC.ORDERNO
					AND A.ORDERDATE = SRC.ORDERDATE
					AND A.ORDERSEQ = SRC.ORDERSEQ)
		WHEN MATCHED
		THEN
			UPDATE SET a.taxdate = ip_taxno;
	ELSIF (UPPER(P_DIV) = 'UTAXSALE')
	THEN
		--세금계산서 수정.
		MERGE INTO ACTAXM a
		USING	   (SELECT A.COMPCODE,
						   A.PLANTCODE,
						   A.TAXNO,
						   CASE WHEN p_buydiv = '91' THEN '115' WHEN p_buydiv = '92' THEN '101' WHEN p_buydiv = '99' THEN '106' ELSE '115' END AS pos_2,
						   '02', --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
						   CASE WHEN p_buydiv = '92' THEN '02' ELSE '01' END AS pos_9,
						   CASE WHEN p_buydiv = '91' THEN '02' ELSE '01' END AS pos_13,
						   'Y', --전자세금계산서여부
						   'Y' --영업/구매 자동생성여부
					FROM   ACTAXM a LEFT JOIN CMCUSTM c ON c.custcode = p_custcode
					WHERE  a.compcode = ip_compcode
						   AND a.plantcode = p_plantcode
						   AND a.taxno = ip_taxno) src
		ON		   (A.COMPCODE = SRC.COMPCODE
					AND A.PLANTCODE = SRC.PLANTCODE
					AND A.TAXNO = SRC.TAXNO)
		WHEN MATCHED
		THEN
			UPDATE SET a.taxdiv = pos_2, --매입과세 계산서 구분(  select * from cmcommonm where cmmcode = 'AC60'  )
					   --매출 - 과세(  select * from cmcommonm where cmmcode = 'AC60'  )
					   --매입-계산서 계산서 구분(  select * from cmcommonm where cmmcode = 'AC60'  )
					   a.iotaxdiv = '02',
					   a.sdeptcode = p_deptcode,
					   a.taxdate = p_slipindate,
					   a.custcode = p_custcode,
					   a.custname = p_custname,
					   a.businessno = p_businessno,
					   a.biznotype = pos_9, -- 사업자등록번호 사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
					   --,blankcnt =@compcode
					   a.amt = p_taxamt1,
					   a.vat = p_taxamt2,
					   a.vatamt = p_taxamt3,
					   a.purposediv = pos_13, --영수청구구분( select * from cmcommonm where cmmcode = 'AC62'   )
					   a.electaxyn = 'Y',
					   a.saleinyn = 'Y',
					   a.updatedt = SYSDATE,
					   a.uempcode = p_iempcode,
					   a.importsdate = p_sdt,
					   a.importedate = p_edt;

		UPDATE ACTAXD a
		SET    a.itemnm = p_itemnm,
			   a.gyugeok = '',
			   a.qty = 0,
			   a.prc = 0,
			   a.amt = p_taxamt1,
			   a.vat = p_taxamt2,
			   a.vatamt = p_taxamt3,
			   a.remark = '',
			   a.updatedt = SYSDATE,
			   a.uempcode = p_iempcode
		WHERE  compcode = ip_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno
			   AND seq = 1;

		MERGE INTO SLORDM a
		USING	   (SELECT A.ORDERNO, A.ORDERDATE, A.ORDERSEQ
					FROM   SLORDM a
						   JOIN SLORDD b ON a.orderno = b.orderno
						   JOIN CMITEMM D ON b.itemcode = D.itemcode
						   LEFT JOIN CMCOMMONM sl10
							   ON sl10.cmmcode = 'SL10'
								  AND sl10.divcode = a.saldiv
						   JOIN CMCUSTM c ON a.custcode = c.custcode
					WHERE  a.plantcode = p_plantcode
						   AND a.custcode = p_custcode
						   AND a.appdate BETWEEN p_sdt AND p_edt
						   AND NVL(a.statediv, ' ') = '09'
						   AND (p_buydiv = '91' -- 역발행
								AND a.saldiv NOT IN ('A09', 'A21', 'A22', 'A61', 'A63', 'A71', 'A73', 'B51', 'B52', 'B61')
								AND (SUBSTR(c.utdiv, 0, 1) = '5'
									 OR c.taxdiv = '9')
								OR p_buydiv = '92' -- 사원판매
								   AND NVL(a.saldiv, ' ') = 'A09'
								OR p_buydiv = '99' -- 직수출
								   AND NVL(a.saldiv, ' ') = 'A22')) src
		ON		   (A.ORDERNO = SRC.ORDERNO
					AND A.ORDERDATE = SRC.ORDERDATE
					AND A.ORDERSEQ = SRC.ORDERSEQ)
		WHEN MATCHED
		THEN
			UPDATE SET a.taxdate = ip_taxno;
	ELSIF (UPPER(P_DIV) = 'DTAXSALE')
	THEN
		--세금계산서 삭제.
		-- 회계전표 삭제
		FOR rec IN (SELECT slipno
					FROM   ACAUTOORDT a
						   JOIN ACORDM b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'S'
						   AND a.acatno = ip_taxno)
		LOOP
			p_slipno := rec.slipno;
		END LOOP;

		IF TRIM(p_slipno) IS NOT NULL
		THEN
			spACord0000MM('B',
								ip_compcode,
								p_slipno,
								'',
								'',
								'',
								p_userid,
								p_reasondiv,
								p_reasontext,
								MESSAGE,
								IO_CURSOR);
		END IF;

		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ, B.MNGCLUCODE
					FROM   ACAUTOORDT a
						   JOIN ACORDS b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno -- 회계전표 관리항목
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'S'
						   AND a.taxno = ip_taxno)
		LOOP
			DELETE FROM ACORDS B -- 회계전표 관리항목
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO
						AND B.SLIPINSEQ = REC.SLIPINSEQ
						AND B.MNGCLUCODE = REC.MNGCLUCODE;
		END LOOP;



		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ
					FROM   ACAUTOORDT a
						   JOIN ACORDD b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno -- 회계전표 계정과목
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'S'
						   AND a.acatno = ip_taxno)
		LOOP
			DELETE FROM ACORDD B -- 회계전표 계정과목
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO
						AND B.SLIPINSEQ = REC.SLIPINSEQ;
		END LOOP;



		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO
					FROM   ACAUTOORDT a
						   JOIN ACORDM b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno -- 회계전표 마스터
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'S'
						   AND a.acatno = ip_taxno)
		LOOP
			DELETE FROM ACORDM B -- 회계전표 마스터
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO;
		END LOOP;

		-- 자동분개 삭제
		DELETE ACAUTOORDT
		WHERE  compcode = ip_compcode
			   AND acattype = 'S'
			   AND acatno = ip_taxno;

		-- 세금계산서 삭제
		DELETE ACTAXD
		WHERE  compcode = ip_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno;

		DELETE ACTAXM
		WHERE  compcode = ip_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno;

		MERGE INTO SLORDM a
		USING	   (SELECT A.ORDERNO, A.ORDERDATE, A.ORDERSEQ, '' AS taxdate
					FROM   SLORDM a
						   JOIN SLORDD b ON a.orderno = b.orderno
						   JOIN CMCUSTM c ON a.custcode = c.custcode /*a.plantcode = @plantcode
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         and*/
					WHERE  a.custcode = p_custcode
						   --and a.appdate between @sdt and @edt
						   AND a.taxdate = ip_taxno
						   AND NVL(a.statediv, ' ') = '09'
						   AND (p_buydiv = '91' -- 역발행
								AND a.saldiv NOT IN ('A09', 'A21', 'A22', 'A61', 'A63', 'A71', 'A73', 'B51', 'B52', 'B61')
								AND (SUBSTR(c.utdiv, 0, 1) = '5'
									 OR c.taxdiv = '9')
								OR p_buydiv = '92' -- 사원판매
								   AND NVL(a.saldiv, ' ') = 'A09'
								OR p_buydiv = '99' -- 직수출
								   AND NVL(a.saldiv, ' ') = 'A22')) src
		ON		   (A.ORDERNO = SRC.ORDERNO
					AND A.ORDERDATE = SRC.ORDERDATE
					AND A.ORDERSEQ = SRC.ORDERSEQ)
		WHEN MATCHED
		THEN
			UPDATE SET a.taxdate = src.taxdate;
	ELSIF (UPPER(P_DIV) = 'CTAX')
	THEN
		DECLARE
			p_chktaxno	 VARCHAR2(20);
		--세금계산서 존재확인. 매입로드에서 사용
		BEGIN
			p_chktaxno := '';

			FOR rec IN (SELECT NVL(taxno, '') AS alias1
						FROM   ACTAXM
						WHERE  compcode = ip_compcode
							   --and plantcode = @plantcode
							   AND taxno = ip_taxno)
			LOOP
				p_chktaxno := rec.alias1;
			END LOOP;

			IF p_chktaxno = ''
			THEN
				MESSAGE := 'NO';
			ELSE
				MESSAGE := 'YES';
			END IF;
		END;
	ELSIF (UPPER(P_DIV) = 'ITAX')
	THEN
		--세금계산서 생성.
		ip_taxno := SUBSTR(REPLACE(p_slipindate, '-', ''), 0, 6) || '03'; --매입구분 구매자동생성구분

		FOR rec IN (SELECT ip_taxno || SUBSTR('00000' || TO_CHAR((NVL(SUBSTR(MAX(taxno), -5, 5), 0) + 1)), -5, 5) AS alias1
					FROM   ACTAXM
					WHERE  compcode = ip_compcode
						   --and plantcode = @plantcode
						   AND taxno LIKE ip_taxno || '%'
						   AND LENGTH(taxno) = 13
						   AND iotaxdiv = '01'
						   AND saleinyn = 'Y')
		LOOP
			ip_taxno := rec.alias1;
		END LOOP; --구매 구분 매입세금계산서

		INSERT INTO ACTAXM(compcode,
						   plantcode,
						   taxno, -- yyyymm03nnnnn
						   taxdiv, --계산서 구분(  select * from cmcommonm where cmmcode = 'AC60'  )
						   iotaxdiv, --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
						   sdeptcode,
						   taxdate,
						   custcode,
						   custname,
						   businessno,
						   biznotype, --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
						   blankcnt,
						   amt,
						   vat,
						   vatamt,
						   purposediv, --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
						   credittot,
						   importsdate,
						   importedate,
						   electaxyn, --전자세금계산서여부
						   purdiv,
						   saleinyn, --영업자동생성여부
						   insertdt,
						   iempcode)
		VALUES		(ip_compcode,
					 p_plantcode,
					 ip_taxno, -- yyyymm03nnnnn  번호 생성
					 CASE WHEN p_buydiv = '01' THEN '201' --매입-과세
														 WHEN p_buydiv = '02' THEN '203' --매입-계산서
																						WHEN p_buydiv = '03' THEN '202' --매입-영세
																													   WHEN p_buydiv = '04' THEN '201' --매입-과세
																																					  ELSE '203' --매입-계산서
																																								END,
					 '01', --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
					 '',
					 p_slipindate,
					 p_custcode,
					 p_custname,
					 p_businessno,
					 '01', --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
					 0,
					 p_taxamt1,
					 p_taxamt2,
					 p_taxamt3,
					 '02', --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
					 p_taxamt3,
					 p_sdt,
					 p_edt,
					 'Y', --전자세금계산서여부
					 CASE WHEN p_buydiv = '05' THEN '2' ELSE '0' END,
					 'Y' --구매자동생성여부
						,
					 SYSDATE,
					 p_iempcode);

		INSERT INTO ACTAXD(compcode,
						   plantcode,
						   taxno, -- yyyymm03nnnnn
						   seq,
						   itemnm, -- ITEM
						   amt,
						   vat,
						   vatamt,
						   insertdt,
						   iempcode)
		VALUES		(ip_compcode,
					 p_plantcode,
					 ip_taxno, -- yyyymm03nnnnn  번호 생성
					 1,
					 p_itemnm, -- + ' 외'
					 p_taxamt1,
					 p_taxamt2,
					 p_taxamt3,
					 SYSDATE,
					 p_iempcode);

		MERGE INTO PDWAREHOUSINGM a
		USING	   (SELECT A.warehousingdiv, A.warehousingno, A.plantcode
					FROM   PDWAREHOUSINGM a
						   LEFT JOIN CMCOMMONM MPM04
							   ON MPM04.cmmcode = 'MPM04'
								  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
					WHERE  NVL(a.plantcode, ' ') LIKE p_plantcode || '%'
						   AND SUBSTR(a.warehousingdt, 1, 10) BETWEEN p_sdt AND p_edt
						   AND NVL(MPM04.filter2, ' ') = 'Acc'
						   AND NVL(a.custcode, ' ') = NVL(p_custcode,' ')) src
		ON		   (A.warehousingdiv = SRC.warehousingdiv
					AND A.warehousingno = SRC.warehousingno
					AND A.plantcode = SRC.plantcode)
		WHEN MATCHED
		THEN
			UPDATE SET a.accountno = ip_taxno, a.accountday = p_slipindate;
	ELSIF (UPPER(P_DIV) = 'ITAXUNIT')
	THEN
		--세금계산서 개별생성.
		ip_taxno := SUBSTR(REPLACE(p_slipindate, '-', ''), 0, 6) || '03'; --매입구분 구매자동생성구분

		FOR rec IN (SELECT ip_taxno || SUBSTR('00000' || TO_CHAR((NVL(SUBSTR(MAX(taxno), -5, 5), 0) + 1)), -5, 5) AS alias1
					FROM   ACTAXM
					WHERE  compcode = ip_compcode
						   --and plantcode = @plantcode
						   AND taxno LIKE ip_taxno || '%'
						   AND LENGTH(taxno) = 13
						   AND iotaxdiv = '01'
						   AND saleinyn = 'Y')
		LOOP
			ip_taxno := rec.alias1;
		END LOOP; --구매 구분 매입세금계산서

		INSERT INTO ACTAXM(compcode,
						   plantcode,
						   taxno, -- yyyy03nnnnn
						   taxdiv, --계산서 구분(  select * from cmcommonm where cmmcode = 'AC60'  )
						   iotaxdiv, --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
						   sdeptcode,
						   taxdate,
						   custcode,
						   custname,
						   businessno,
						   biznotype, --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
						   blankcnt,
						   amt,
						   vat,
						   vatamt,
						   purposediv, --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
						   credittot,
						   importsdate,
						   importedate,
						   electaxyn, --전자세금계산서여부
						   purdiv,
						   saleinyn, --영업자동생성여부
						   insertdt,
						   iempcode)
		VALUES		(ip_compcode,
					 p_plantcode,
					 ip_taxno, -- yyyy03nnnnn  번호 생성
					 CASE WHEN p_buydiv = '01' THEN '201' --매입-과세
														 WHEN p_buydiv = '02' THEN '203' --매입-계산서
																						WHEN p_buydiv = '03' THEN '202' --매입-영세
																													   WHEN p_buydiv = '04' THEN '201' --매입-과세
																																					  ELSE '203' --매입-계산서
																																								END,
					 '01', --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
					 '',
					 p_slipindate,
					 p_custcode,
					 p_custname,
					 p_businessno,
					 '01', --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
					 0,
					 p_taxamt1,
					 p_taxamt2,
					 p_taxamt3,
					 '02', --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
					 p_taxamt3,
					 p_sdt,
					 p_edt,
					 'Y', --전자세금계산서여부
					 CASE WHEN p_buydiv = '05' THEN '2' ELSE '0' END,
					 'Y', --구매자동생성여부
					 SYSDATE,
					 p_iempcode);

		INSERT INTO ACTAXD(compcode,
						   plantcode,
						   taxno, -- yyyy03nnnnn
						   seq,
						   itemnm, -- ITEM
						   amt,
						   vat,
						   vatamt,
						   insertdt,
						   iempcode)
		VALUES		(ip_compcode,
					 p_plantcode,
					 ip_taxno, -- yyyy0301nnnnn  번호 생성
					 1,
					 p_itemnm, -- + ' 외'
					 p_taxamt1,
					 p_taxamt2,
					 p_taxamt3,
					 SYSDATE,
					 p_iempcode);

		MERGE INTO PDWAREHOUSINGM a
		USING	   (SELECT A.warehousingdiv, A.warehousingno, A.plantcode
					FROM   PDWAREHOUSINGM a
						   JOIN (SELECT codes warehousingno FROM TABLE(fnSplit(p_warehousingno, ';'))) b ON a.warehousingno = b.warehousingno
						   LEFT JOIN CMCOMMONM MPM04
							   ON MPM04.cmmcode = 'MPM04'
								  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
					WHERE  NVL(a.plantcode, ' ') LIKE p_plantcode || '%'
						   AND SUBSTR(a.warehousingdt, 1, 10) BETWEEN p_sdt AND p_edt
						   AND NVL(MPM04.filter2, ' ') = 'Acc'
						   AND NVL(a.custcode, ' ') = NVL(p_custcode,' ')) src
		ON		   (A.warehousingdiv = SRC.warehousingdiv
					AND A.warehousingno = SRC.warehousingno
					AND A.plantcode = SRC.plantcode)
		WHEN MATCHED
		THEN
			UPDATE SET a.accountno = ip_taxno, a.accountday = p_slipindate;
	ELSIF (UPPER(P_DIV) = 'ITAX2')
	THEN
		--세금계산서 생성.
		ip_taxno := SUBSTR(REPLACE(p_slipindate, '-', ''), 0, 6) || '03'; --매입구분 구매자동생성구분

		FOR rec IN (SELECT ip_taxno || SUBSTR('00000' || TO_CHAR((NVL(SUBSTR(MAX(taxno), -5, 5), 0) + 1)), -5, 5) AS alias1
					FROM   ACTAXM
					WHERE  compcode = ip_compcode
						   --and plantcode = @plantcode
						   AND taxno LIKE ip_taxno || '%'
						   AND LENGTH(taxno) = 13
						   AND iotaxdiv = '01'
						   AND saleinyn = 'Y')
		LOOP
			ip_taxno := rec.alias1;
		END LOOP; --구매 구분 매입세금계산서

		INSERT INTO ACTAXM(compcode,
						   plantcode,
						   taxno, -- yyyymm03nnnnn
						   taxdiv, --계산서 구분(  select * from cmcommonm where cmmcode = 'AC60'  )
						   iotaxdiv, --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
						   sdeptcode,
						   taxdate,
						   custcode,
						   custname,
						   businessno,
						   biznotype, --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
						   blankcnt,
						   amt,
						   vat,
						   vatamt,
						   purposediv, --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
						   credittot,
						   importsdate,
						   importedate,
						   electaxyn, --전자세금계산서여부
						   purdiv,
						   saleinyn, --영업자동생성여부
						   insertdt,
						   iempcode)
		VALUES		(ip_compcode,
					 p_plantcode,
					 ip_taxno, -- yyyymm03nnnnn  번호 생성
					 CASE WHEN p_buydiv = '01' THEN '201' --매입-과세
														 WHEN p_buydiv = '02' THEN '203' --매입-계산서
																						WHEN p_buydiv = '03' THEN '202' --매입-영세
																													   WHEN p_buydiv = '04' THEN '201' --매입-과세
																																					  ELSE '203' --매입-계산서
																																								END,
					 '01', --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
					 '',
					 p_slipindate,
					 p_custcode,
					 p_custname,
					 p_businessno,
					 '01', --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
					 0,
					 p_taxamt1,
					 p_taxamt2,
					 p_taxamt3,
					 '02', --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
					 p_taxamt3,
					 p_slipindate,
					 p_slipindate,
					 'Y', --전자세금계산서여부
					 CASE WHEN p_buydiv = '05' THEN '2' ELSE '0' END,
					 'Y', --구매자동생성여부
					 SYSDATE,
					 p_iempcode);

		INSERT INTO ACTAXD(compcode,
						   plantcode,
						   taxno, -- yyyymm03nnnnn
						   seq,
						   itemnm, -- ITEM
						   amt,
						   vat,
						   vatamt,
						   insertdt,
						   iempcode)
		VALUES		(ip_compcode,
					 p_plantcode,
					 ip_taxno, -- yyyymm03nnnnn  번호 생성
					 1,
					 p_itemnm, -- + ' 외'
					 p_taxamt1,
					 p_taxamt2,
					 p_taxamt3,
					 SYSDATE,
					 p_iempcode);

		--set @plantcode = '1000'
		MERGE INTO PDWAREHOUSINGM a
		USING	   (SELECT A.WAREHOUSINGDIV, A.WAREHOUSINGNO, A.PLANTCODE
					FROM   PDWAREHOUSINGM a
						   LEFT JOIN CMCOMMONM MPM04
							   ON MPM04.cmmcode = 'MPM04'
								  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
					WHERE  a.plantcode = p_plantcode
						   AND a.custcode = p_custcode
						   AND a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq
						   AND MPM04.filter2 = 'Acc') src
		ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
					AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
					AND A.PLANTCODE = SRC.PLANTCODE)
		WHEN MATCHED
		THEN
			UPDATE SET a.accountno = ip_taxno;

		MERGE INTO PDWAREHOUSINGRM a
		USING	   (SELECT A.WAREHOUSINGRETURNINGNO, A.WAREHOUSINGDIV, A.PLANTCODE
					FROM   PDWAREHOUSINGRM a
						   JOIN PDWAREHOUSINGM b
							   ON a.warehousingno = b.warehousingno
								  AND b.plantcode = p_plantcode
								  AND b.custcode = p_custcode
					WHERE  a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq) src
		ON		   (A.WAREHOUSINGRETURNINGNO = SRC.WAREHOUSINGRETURNINGNO
					AND A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
					AND A.PLANTCODE = SRC.PLANTCODE)
		WHEN MATCHED
		THEN
			UPDATE SET A.accountno = ip_taxno;

		MERGE INTO PDPURCHASEDC a
		USING	   (SELECT A.DISCOUNTID
					FROM   PDPURCHASEDC a
						   JOIN PDWAREHOUSINGM b
							   ON a.warehousingno = b.warehousingno
								  AND b.plantcode = p_plantcode
								  AND b.custcode = p_custcode
								  AND TRIM(b.accountday) IS NOT NULL
					WHERE  a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq) src
		ON		   (A.DISCOUNTID = SRC.DISCOUNTID)
		WHEN MATCHED
		THEN
			UPDATE SET A.accountno = ip_taxno;
	ELSIF (UPPER(P_DIV) = 'UTAX')
	THEN
		--세금계산서 수정.
		MERGE INTO ACTAXM a
		USING	   (SELECT A.COMPCODE,
						   A.PLANTCODE,
						   A.TAXNO,
						   CASE WHEN p_buydiv = '01' THEN '201' WHEN p_buydiv = '02' THEN '203' WHEN p_buydiv = '03' THEN '202' WHEN p_buydiv = '04' THEN '201' ELSE '203' END AS pos_2,
						   '01' --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
							   ,
						   p_deptcode,
						   p_slipindate --회계처리일자
									   ,
						   p_custcode,
						   p_custname -- c.custname --거래처명
									 ,
						   p_businessno,
						   '01' -- 사업자등록번호 사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
							   --,blankcnt = ???
						   ,
						   p_taxamt1,
						   p_taxamt2,
						   p_taxamt3,
						   '02' --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
							   ,
						   'Y' --전자세금계산서여부
							  ,
						   'Y' --구매 자동생성여부
							  ,
						   CASE WHEN p_buydiv = '05' THEN '2' ELSE '0' END AS pos_16,
						   SYSDATE,
						   p_iempcode,
						   p_sdt,
						   p_edt
					FROM   ACTAXM a LEFT JOIN CMCUSTM c ON c.custcode = p_custcode
					WHERE  a.compcode = ip_compcode
						   AND a.plantcode = p_plantcode
						   AND a.taxno = ip_taxno) src
		ON		   (A.COMPCODE = SRC.COMPCODE
					AND A.PLANTCODE = SRC.PLANTCODE
					AND A.TAXNO = SRC.TAXNO)
		WHEN MATCHED
		THEN
			UPDATE SET a.taxdiv = pos_2, --매입-과세
					   --매입-계산서
					   --매입-영세
					   --매입-과세

					   a.iotaxdiv = '01',
					   a.sdeptcode = p_deptcode,
					   a.taxdate = p_slipindate,
					   a.custcode = p_custcode,
					   a.custname = p_custname,
					   a.businessno = p_businessno,
					   a.biznotype = '01',
					   a.amt = p_taxamt1,
					   a.vat = p_taxamt2,
					   a.vatamt = p_taxamt3,
					   a.purposediv = '02',
					   a.electaxyn = 'Y',
					   a.saleinyn = 'Y',
					   a.purdiv = pos_16,
					   a.updatedt = SYSDATE,
					   a.uempcode = p_iempcode,
					   a.importsdate = p_sdt,
					   a.importedate = p_edt;

		UPDATE ACTAXD a
		SET    a.itemnm = p_itemnm,
			   a.gyugeok = '',
			   a.qty = 0,
			   a.prc = 0,
			   a.amt = p_taxamt1,
			   a.vat = p_taxamt2,
			   a.vatamt = p_taxamt3,
			   a.remark = '',
			   a.updatedt = SYSDATE,
			   a.uempcode = p_iempcode
		WHERE  compcode = ip_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno
			   AND seq = 1;
	ELSIF (UPPER(P_DIV) = 'UTAX2')
	THEN
		--세금계산서 수정.
		MERGE INTO ACTAXM a
		USING	   (SELECT A.COMPCODE, A.PLANTCODE, A.TAXNO, CASE WHEN p_buydiv = '01' THEN '201' WHEN p_buydiv = '02' THEN '203' WHEN p_buydiv = '03' THEN '202' WHEN p_buydiv = '04' THEN '201' ELSE '203' END AS pos_2, CASE WHEN p_buydiv = '05' THEN '2' ELSE '0' END AS pos_16
					FROM   ACTAXM a LEFT JOIN CMCUSTM c ON c.custcode = p_custcode
					WHERE  a.compcode = ip_compcode
						   AND a.plantcode = p_plantcode
						   AND a.taxno = ip_taxno) src
		ON		   (A.COMPCODE = SRC.COMPCODE
					AND A.PLANTCODE = SRC.PLANTCODE
					AND A.TAXNO = SRC.TAXNO)
		WHEN MATCHED
		THEN
			UPDATE SET a.taxdiv = pos_2, --매입-과세
					   --매입-계산서
					   --매입-영세
					   --매입-선급

					   a.iotaxdiv = '01',
					   a.sdeptcode = p_deptcode,
					   a.taxdate = p_slipindate,
					   a.custcode = p_custcode,
					   a.custname = p_custname,
					   a.businessno = p_businessno,
					   a.biznotype = '01',
					   a.amt = p_taxamt1,
					   a.vat = p_taxamt2,
					   a.vatamt = p_taxamt3,
					   a.purposediv = '02',
					   a.electaxyn = 'Y',
					   a.saleinyn = 'Y',
					   a.purdiv = pos_16,
					   a.updatedt = SYSDATE,
					   a.uempcode = p_iempcode,
					   a.importsdate = p_slipindate,
					   a.importedate = p_slipindate;

		UPDATE ACTAXD a
		SET    a.itemnm = p_itemnm,
			   a.gyugeok = '',
			   a.qty = 0,
			   a.prc = 0,
			   a.amt = p_taxamt1,
			   a.vat = p_taxamt2,
			   a.vatamt = p_taxamt3,
			   a.remark = '',
			   a.updatedt = SYSDATE,
			   a.uempcode = p_iempcode
		WHERE  compcode = ip_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno
			   AND seq = 1;

		--set @plantcode = '1000'
		MERGE INTO PDWAREHOUSINGM a
		USING	   (SELECT A.WAREHOUSINGDIV, A.WAREHOUSINGNO, A.PLANTCODE
					FROM   PDWAREHOUSINGM a
						   LEFT JOIN CMCOMMONM MPM04
							   ON MPM04.cmmcode = 'MPM04'
								  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
					WHERE  a.plantcode = p_plantcode
						   AND a.custcode = p_custcode
						   AND a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq
						   AND MPM04.filter2 = 'Acc') src
		ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
					AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
					AND A.PLANTCODE = SRC.PLANTCODE)
		WHEN MATCHED
		THEN
			UPDATE SET a.accountno =ip_taxno;

		MERGE INTO PDWAREHOUSINGRM a
		USING	   (SELECT A.WAREHOUSINGRETURNINGNO, A.WAREHOUSINGDIV, A.PLANTCODE
					FROM   PDWAREHOUSINGRM a
						   JOIN PDWAREHOUSINGM b
							   ON a.warehousingno = b.warehousingno
								  AND b.plantcode = p_plantcode
								  AND b.custcode = p_custcode
					--and b.finishamt <> 0
					--and b.accountday <> ''

					WHERE  a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq) src
		ON		   (A.WAREHOUSINGRETURNINGNO = SRC.WAREHOUSINGRETURNINGNO
					AND A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
					AND A.PLANTCODE = SRC.PLANTCODE)
		WHEN MATCHED
		THEN
			UPDATE SET A.accountno = ip_taxno;

		MERGE INTO PDPURCHASEDC a
		USING	   (SELECT A.DISCOUNTID
					FROM   PDPURCHASEDC a
						   JOIN PDWAREHOUSINGM b
							   ON a.warehousingno = b.warehousingno
								  AND b.plantcode = p_plantcode
								  AND b.custcode = p_custcode
								  AND TRIM(b.accountday) IS NOT NULL
					WHERE  a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq) src
		ON		   (A.DISCOUNTID = SRC.DISCOUNTID)
		WHEN MATCHED
		THEN
			UPDATE SET A.accountno = ip_taxno;
	ELSIF (UPPER(P_DIV) = 'DTAX')
	THEN
		--세금계산서 삭제.
		-- 회계전표 삭제
		FOR rec IN (SELECT slipno
					FROM   ACAUTOORDT a
						   JOIN ACORDM b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'P'
						   AND a.acatno = ip_taxno)
		LOOP
			p_slipno := rec.slipno;
		END LOOP;

		IF TRIM(p_slipno) IS NOT NULL
		THEN
			spACord0000MM('B',
								ip_compcode,
								p_slipno,
								'',
								'',
								'',
								p_userid,
								p_reasondiv,
								p_reasontext,
								MESSAGE,
								IO_CURSOR);
		END IF;

		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ, B.MNGCLUCODE
					FROM   ACAUTOORDT a
						   JOIN ACORDS b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno -- 회계전표 관리항목
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'P'
						   AND a.acatno = ip_taxno)
		LOOP
			DELETE FROM ACORDS B -- 회계전표 관리항목
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO
						AND B.SLIPINSEQ = REC.SLIPINSEQ
						AND B.MNGCLUCODE = REC.MNGCLUCODE;
		END LOOP;



		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ
					FROM   ACAUTOORDT a
						   JOIN ACORDD b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno -- 회계전표 계정과목
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'P'
						   AND a.acatno = ip_taxno)
		LOOP
			DELETE FROM ACORDD B -- 회계전표 계정과목
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO
						AND B.SLIPINSEQ = REC.SLIPINSEQ;
		END LOOP;


		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO
					FROM   ACAUTOORDT a
						   JOIN ACORDM b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno -- 회계전표 마스터
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'P'
						   AND a.acatno = ip_taxno)
		LOOP
			DELETE FROM ACORDM b -- 회계전표 마스터
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO;
		END LOOP;



		-- 자동분개 삭제

		DELETE ACAUTOORDT
		WHERE  compcode = ip_compcode
			   AND acattype = 'P'
			   AND acatno = ip_taxno;

		-- 세금계산서 삭제
		DELETE ACTAXD
		WHERE  compcode = ip_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno;

		DELETE ACTAXM
		WHERE  compcode = ip_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno;

		-- 입고전표 갱신
		MERGE INTO PDWAREHOUSINGM a
		USING	   (SELECT A.WAREHOUSINGDIV,
						   A.WAREHOUSINGNO,
						   A.PLANTCODE,
						   '' AS pos_2,
						   '' AS pos_3,
						   '' AS pos_4
					FROM   PDWAREHOUSINGM a
						   LEFT JOIN CMCOMMONM MPM04
							   ON MPM04.cmmcode = 'MPM04'
								  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
					WHERE  NVL(a.plantcode, ' ') LIKE p_plantcode || '%'
						   AND SUBSTR(a.warehousingdt, 1, 10) BETWEEN p_sdt AND p_edt
						   AND NVL(MPM04.filter2, ' ') = 'Acc'
						   AND NVL(a.custcode, ' ') = NVL(p_custcode,' ')
						   AND NVL(a.accountday, ' ') = NVL(p_slipindate,' ')
						   AND NVL(a.accountno, ' ') = NVL(ip_taxno,' ')) src
		ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
					AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
					AND A.PLANTCODE = SRC.PLANTCODE)
		WHEN MATCHED
		THEN
			UPDATE SET a.accountno = pos_2, a.accountday = pos_3, a.accountcheck = pos_4;
	ELSIF (UPPER(P_DIV) = 'DTAX2'
		   OR UPPER(P_DIV) = 'DTAXNO2')
	THEN
		--세금계산서 삭제.
		-- 회계전표 삭제
		FOR rec IN (SELECT slipno
					FROM   ACAUTOORDT a
						   JOIN ACORDM b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'P'
						   AND a.acatno = ip_taxno)
		LOOP
			p_slipno := rec.slipno;
		END LOOP;

		IF TRIM(p_slipno) IS NOT NULL
		THEN
			spACord0000MM('B',
								ip_compcode,
								p_slipno,
								'',
								'',
								'',
								p_userid,
								p_reasondiv,
								p_reasontext,
								MESSAGE,
								IO_CURSOR);
		END IF;

		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ, B.MNGCLUCODE
					FROM   ACAUTOORDT a
						   JOIN ACORDS b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno -- 회계전표 관리항목
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'P'
						   AND a.acatno = ip_taxno)
		LOOP
			DELETE FROM ACORDS B -- 회계전표 관리항목
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO
						AND B.SLIPINSEQ = REC.SLIPINSEQ
						AND B.MNGCLUCODE = REC.MNGCLUCODE;
		END LOOP;



		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ
					FROM   ACAUTOORDT a
						   JOIN ACORDD b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno -- 회계전표 계정과목
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'P'
						   AND a.acatno = ip_taxno)
		LOOP
			DELETE FROM ACORDD b -- 회계전표 계정과목
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO
						AND B.SLIPINSEQ = REC.SLIPINSEQ;
		END LOOP;


		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO
					FROM   ACAUTOORDT a
						   JOIN ACORDM b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno -- 회계전표 마스터
					WHERE  a.compcode = ip_compcode
						   AND a.acattype = 'P'
						   AND a.acatno = ip_taxno)
		LOOP
			DELETE FROM ACORDM b -- 회계전표 마스터
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO;
		END LOOP;

		-- 자동분개 삭제
		DELETE ACAUTOORDT
		WHERE  compcode = ip_compcode
			   AND acattype = 'P'
			   AND acatno = ip_taxno;

		-- 세금계산서 삭제
		DELETE ACTAXD
		WHERE  compcode = ip_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno;

		DELETE ACTAXM
		WHERE  compcode = ip_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno;

		--set @plantcode = '1000'
		-- 입고전표 갱신
		MERGE INTO PDWAREHOUSINGM a
		USING	   (SELECT A.WAREHOUSINGDIV, A.WAREHOUSINGNO, A.PLANTCODE, '' AS pos_2, '' AS pos_3
					FROM   PDWAREHOUSINGM a
						   LEFT JOIN CMCOMMONM MPM04
							   ON MPM04.cmmcode = 'MPM04'
								  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
					WHERE  a.plantcode = p_plantcode
						   AND a.custcode = p_custcode
						   AND a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq
						   AND MPM04.filter2 = 'Acc') src
		ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
					AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
					AND A.PLANTCODE = SRC.PLANTCODE)
		WHEN MATCHED
		THEN
			UPDATE SET a.accountno = pos_2, a.accountcheck = pos_3;


		MERGE INTO PDWAREHOUSINGRM a
		USING	   (SELECT A.WAREHOUSINGRETURNINGNO, A.WAREHOUSINGDIV, A.PLANTCODE, '' AS pos_2, '' AS pos_3
					FROM   PDWAREHOUSINGRM a
						   JOIN PDWAREHOUSINGM b
							   ON a.warehousingno = b.warehousingno
								  AND b.plantcode = p_plantcode
								  AND b.custcode = p_custcode
					--and b.finishamt <> 0
					--and b.accountday <> ''

					WHERE  a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq) src
		ON		   (A.WAREHOUSINGRETURNINGNO = SRC.WAREHOUSINGRETURNINGNO
					AND A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
					AND A.PLANTCODE = SRC.PLANTCODE)
		WHEN MATCHED
		THEN
			UPDATE SET A.accountno = pos_2, A.accountcheck = pos_3;



		MERGE INTO PDPURCHASEDC a
		USING	   (SELECT A.DISCOUNTID, '' AS pos_2, '' AS pos_3
					FROM   PDPURCHASEDC a
						   JOIN PDWAREHOUSINGM b
							   ON a.warehousingno = b.warehousingno
								  AND b.plantcode = p_plantcode
								  AND b.custcode = p_custcode
								  AND TRIM(b.accountday) IS NOT NULL
					WHERE  a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq) src
		ON		   (A.DISCOUNTID = SRC.DISCOUNTID)
		WHEN MATCHED
		THEN
			UPDATE SET A.accountno = pos_2, A.discountchk = pos_3;
	ELSIF (UPPER(P_DIV) = 'DTAXNO')
	THEN
		--세금계산서 번호를 입고테이블에서 수정 .
		MERGE INTO PDWAREHOUSINGM a
		USING	   (SELECT A.WAREHOUSINGDIV,
						   A.WAREHOUSINGNO,
						   A.PLANTCODE,
						   '' AS pos_2,
						   '' AS pos_3,
						   '' AS pos_4
					FROM   PDWAREHOUSINGM a
						   LEFT JOIN CMCOMMONM MPM04
							   ON MPM04.cmmcode = 'MPM04'
								  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
					WHERE  NVL(a.plantcode, ' ') LIKE p_plantcode || '%'
						   AND SUBSTR(a.warehousingdt, 1, 10) BETWEEN p_sdt AND p_edt
						   AND NVL(MPM04.filter2, ' ') = 'Acc'
						   AND NVL(a.custcode, ' ') = NVL(p_custcode,' ')
						   AND NVL(a.accountday, ' ') LIKE p_slipindate || '%'
						   AND NVL(a.accountno, ' ') LIKE ip_taxno || '%') src
		ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
					AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
					AND A.PLANTCODE = SRC.PLANTCODE)
		WHEN MATCHED
		THEN
			UPDATE SET a.accountno = pos_2, a.accountday = pos_3, a.accountcheck = pos_4;
	ELSIF (UPPER(P_DIV) = 'DTAXNO2')
	THEN
		--세금계산서 번호를 입고테이블에서 수정 .
		--set @plantcode = '1000'
		MERGE INTO PDWAREHOUSINGM a
		USING	   (SELECT A.WAREHOUSINGDIV, A.WAREHOUSINGNO, A.PLANTCODE, '' AS pos_2, '' AS pos_3
					FROM   PDWAREHOUSINGM a
						   LEFT JOIN CMCOMMONM MPM04
							   ON MPM04.cmmcode = 'MPM04'
								  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
					WHERE  a.plantcode = p_plantcode
						   AND a.custcode = p_custcode
						   AND a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq
						   AND MPM04.filter2 = 'Acc') src
		ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
					AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
					AND A.PLANTCODE = SRC.PLANTCODE)
		WHEN MATCHED
		THEN
			UPDATE SET a.accountno = pos_2, a.accountcheck = pos_3;

		MERGE INTO PDWAREHOUSINGRM a
		USING	   (SELECT A.WAREHOUSINGRETURNINGNO, A.WAREHOUSINGDIV, A.PLANTCODE, '' AS pos_2, '' AS pos_3
					FROM   PDWAREHOUSINGRM a
						   JOIN PDWAREHOUSINGM b
							   ON a.warehousingno = b.warehousingno
								  AND b.plantcode = p_plantcode
								  AND b.custcode = p_custcode
					--and b.finishamt <> 0
					--and b.accountday <> ''

					WHERE  a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq) src
		ON		   (A.WAREHOUSINGRETURNINGNO = SRC.WAREHOUSINGRETURNINGNO
					AND A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
					AND A.PLANTCODE = SRC.PLANTCODE)
		WHEN MATCHED
		THEN
			UPDATE SET A.accountno = pos_2, A.accountcheck = pos_3;

		MERGE INTO PDPURCHASEDC a
		USING	   (SELECT A.DISCOUNTID, '' AS pos_2, '' AS pos_3
					FROM   PDPURCHASEDC a
						   JOIN PDWAREHOUSINGM b
							   ON a.warehousingno = b.warehousingno
								  AND b.plantcode = p_plantcode
								  AND b.custcode = p_custcode
								  AND TRIM(b.accountday) IS NOT NULL
					WHERE  a.accountday = p_slipindate
						   AND NVL(a.accountseq, 0) = p_slipinseq) src
		ON		   (A.DISCOUNTID = SRC.DISCOUNTID)
		WHEN MATCHED
		THEN
			UPDATE SET A.accountno = pos_2, A.discountchk = pos_3;
	ELSIF (UPPER(P_DIV) = 'PPSSD')
	THEN
		--상세 내용 정보 확인
		OPEN IO_CURSOR FOR
			SELECT 'N' selyn,
				   NVL(a.warehousingno, '') warehousingno,
				   NVL(a.orderno, '') orderno,
				   NVL(a.itemcode, '') itemcode,
				   NVL(M.itemname, '') itemname,
				   NVL(a.lotdate, '') lotdate,
				   NVL(a.lotno, '') lotno,
				   NVL(a.buydiv, '') buydiv2, -- 세금 구분
				   NVL(MPM17.divname, '') buydivname2,
				   NVL(a.warehousingdiv, '') warehousediv, -- 입고구분
				   CASE WHEN a.warehousingdiv = '01' THEN '원자재입고' WHEN a.warehousingdiv = '02' THEN '상품입고' WHEN a.warehousingdiv = '03' THEN '위탁입고' END ipgodivname, --입고구분명
				   NVL(a.totalwarehousingqty, 0) totqty,
				   NVL(a.warehousingprice, 0) price,
				   NVL(a.warehousingamt, 0) amount, --LightPink
				   NVL(a.finishamt, 0) finishamt2, --PaleGoldenrod
				   NVL(a.vat, 0) vat2, --NavajoWhite
				   NVL(a.finishamt, 0) + NVL(a.vat, 0) sumamt2,
				   NVL(M.itemdiv, '') itemdiv,
				   NVL(CMM01.divname, '') itemdivname,
				   NVL(a.warehousingstate, '') warehousestate2, --입고상태
				   NVL(MPM04.divname, '') instatename, -- 입고 상태 명
				   NVL(a.accountno, '') taxno2,
				   NVL(a.accountday, '') slipindate2
			FROM   PDWAREHOUSINGM a
				   LEFT JOIN CMITEMM M
					   ON a.plantcode = M.plantcode
						  AND a.itemcode = M.itemcode
				   LEFT JOIN CMCOMMONM MPM17
					   ON MPM17.cmmcode = 'MPM17'
						  AND MPM17.divcode = a.buydiv
				   LEFT JOIN CMCOMMONM MPM04
					   ON MPM04.cmmcode = 'MPM04'
						  AND MPM04.divcode = a.warehousingstate
				   LEFT JOIN CommonMaster CMM01 --select * from CMCOMMONM where cmmcode = 'CMM01'
					   ON CMM01.cmmcode = 'CMM01' --select * from CMCOMMONM where cmmcode = 'CMM01'
						  AND CMM01.divcode = M.itemdiv --select * from CMITEMM
			WHERE  NVL(a.plantcode, ' ') LIKE p_plantcode || '%'
				   AND SUBSTR(a.warehousingdt, 1, 10) BETWEEN p_sdt AND p_edt
				   AND NVL(MPM04.filter2, ' ') = 'Acc'
				   AND NVL(a.custcode, ' ') = NVL(p_custcode,' ')
				   AND (ip_taxno = ' '
						AND TRIM(a.accountno) IS NULL
						OR TRIM(ip_taxno) IS NOT NULL
						   AND NVL(a.accountno, ' ') LIKE ip_taxno || '%');
	ELSIF (UPPER(P_DIV) = 'PPSSD2')
	THEN
		--상세 내용 정보 확인
		--set @plantcode = '1000'
		OPEN IO_CURSOR FOR
			SELECT NVL(a.warehousingno, '') warehousingno,
				   NVL(a.orderno, '') orderno,
				   NVL(b.ritemcode, a.itemcode) itemcode,
				   NVL(M.itemname, '') itemname,
				   NVL(a.lotdate, '') lotdate,
				   NVL(a.lotno, '') lotno,
				   NVL(a.buydiv, '') buydiv2, -- 세금 구분
				   NVL(MPM17.divname, '') buydivname2,
				   NVL(a.warehousingdiv, '') warehousediv, -- 입고구분
				   CASE WHEN a.warehousingdiv = '01' THEN '원자재입고' WHEN a.warehousingdiv = '02' THEN '상품입고' WHEN a.warehousingdiv = '03' THEN '위탁입고' END ipgodivname, --입고구분명
				   NVL(a.totalwarehousingqty, 0) totqty,
				   NVL(a.warehousingprice, 0) price,
				   NVL(a.warehousingamt, 0) amount, --LightPink
				   NVL(a.finishamt, 0) finishamt2, --PaleGoldenrod
				   NVL(a.vat, 0) vat2, --NavajoWhite
				   NVL(a.finishamt, 0) + NVL(a.vat, 0) sumamt2,
				   NVL(M.itemdiv, '') itemdiv,
				   NVL(CMM01.divname, '') itemdivname,
				   NVL(a.warehousingstate, '') warehousestate2, --입고상태
				   NVL(MPM04.divname, '') instatename, -- 입고 상태 명
				   NVL(a.accountno, '') taxno2,
				   NVL(a.accountday, '') slipindate2
			FROM   PDWAREHOUSINGM a
				   LEFT JOIN PDITEMRELATION b ON a.itemcode = b.itemcode
				   LEFT JOIN CMITEMM M ON NVL(b.ritemcode, a.itemcode) = M.itemcode
				   LEFT JOIN CMCOMMONM MPM17
					   ON MPM17.cmmcode = 'MPM17'
						  AND MPM17.divcode = a.buydiv
				   LEFT JOIN CMCOMMONM MPM04
					   ON MPM04.cmmcode = 'MPM04'
						  AND MPM04.divcode = a.warehousingstate
				   LEFT JOIN CommonMaster CMM01
					   ON CMM01.cmmcode = 'CMM01'
						  AND CMM01.divcode = M.itemdiv
			WHERE  a.plantcode = p_plantcode
				   AND a.custcode = p_custcode
				   AND a.accountday = p_slipindate
				   AND NVL(a.accountseq, 0) = p_slipinseq
				   AND MPM04.filter2 = 'Acc'
				   AND NVL(TRIM(a.changechk), 'N') = 'N'
			UNION ALL
			SELECT NVL(a.warehousingno, '') warehousingno,
				   NVL(b.orderno, '') orderno,
				   NVL(c.ritemcode, b.itemcode) itemcode,
				   NVL(M.itemname, '') itemname,
				   NVL(b.lotdate, '') lotdate,
				   NVL(b.lotno, '') lotno,
				   NVL(b.buydiv, '') buydiv2, -- 세금 구분
				   NVL(MPM17.divname, '') buydivname2,
				   '92' warehousediv, -- 입고구분
				   '상품할인' ipgodivname, --입고구분명
				   NVL(b.totalwarehousingqty, 0) totqty,
				   NVL(CASE WHEN a.discountdiv = '03' THEN a.dcpriceA - a.dcpriceB ELSE a.dcpriceB - a.dcpriceA END, 0) price,
				   NVL(CASE WHEN a.discountdiv = '03' THEN a.discountamt ELSE -a.discountamt END, 0) amount, --LightPink
				   NVL(CASE WHEN a.discountdiv = '03' THEN a.discountamt ELSE -a.discountamt END, 0) finishamt2, --PaleGoldenrod
				   NVL(CASE WHEN a.discountdiv = '03' THEN a.discountvat ELSE -a.discountvat END, 0) vat2, --NavajoWhite
				   NVL(CASE WHEN a.discountdiv = '03' THEN a.discountamt + a.discountvat ELSE -a.discountamt - a.discountvat END, 0) sumamt2,
				   NVL(M.itemdiv, '') itemdiv,
				   NVL(CMM01.divname, '') itemdivname,
				   NVL(b.warehousingstate, '') warehousestate2, --입고상태
				   NVL(MPM04.divname, '') instatename, -- 입고 상태 명
				   NVL(a.accountno, '') taxno2,
				   NVL(a.accountday, '') slipindate2
			FROM   PDPURCHASEDC a
				   JOIN PDWAREHOUSINGM b
					   ON a.warehousingno = b.warehousingno
						  AND TRIM(b.accountday) IS NOT NULL
				   LEFT JOIN PDITEMRELATION c ON b.itemcode = c.itemcode
				   LEFT JOIN CMITEMM M ON NVL(c.ritemcode, b.itemcode) = M.itemcode
				   LEFT JOIN CMCOMMONM MPM17
					   ON MPM17.cmmcode = 'MPM17'
						  AND MPM17.divcode = b.buydiv
				   LEFT JOIN CMCOMMONM MPM04
					   ON MPM04.cmmcode = 'MPM04'
						  AND MPM04.divcode = b.warehousingstate
				   LEFT JOIN CommonMaster CMM01
					   ON CMM01.cmmcode = 'CMM01'
						  AND CMM01.divcode = M.itemdiv
			WHERE  b.plantcode = p_plantcode
				   AND b.custcode = p_custcode
				   AND a.accountday = p_slipindate
				   AND NVL(a.accountseq, 0) = p_slipinseq
				   AND MPM04.filter2 = 'Acc'
			UNION ALL
			SELECT NVL(a.warehousingno, '') warehousingno,
				   NVL(b.orderno, '') orderno,
				   NVL(c.ritemcode, b.itemcode) itemcode,
				   NVL(M.itemname, '') itemname,
				   NVL(b.lotdate, '') lotdate,
				   NVL(b.lotno, '') lotno,
				   NVL(b.buydiv, '') buydiv2, -- 세금 구분
				   NVL(MPM17.divname, '') buydivname2,
				   CASE WHEN a.warehousingdiv = '01' THEN '81' WHEN a.warehousingdiv = '02' THEN '82' WHEN a.warehousingdiv = '03' THEN '83' END warehousediv, -- 입고구분
				   CASE WHEN a.warehousingdiv = '01' THEN '원자재반품' WHEN a.warehousingdiv = '02' THEN '상품반품' WHEN a.warehousingdiv = '03' THEN '위탁반품' END ipgodivname, --입고구분명
				   NVL(a.totalwarehousingreturnqty, 0) totqty,
				   NVL(-a.warehousingreturningprice, 0) price,
				   NVL(-a.warehousingreturningamt, 0) amount, --LightPink
				   NVL(-a.warehousingreturningamt, 0) finishamt2, --PaleGoldenrod
				   NVL(-a.vat, 0) vat2, --NavajoWhite
				   NVL(-a.warehousingreturningamt, 0) + NVL(-a.vat, 0) sumamt2,
				   NVL(M.itemdiv, '') itemdiv,
				   NVL(CMM01.divname, '') itemdivname,
				   NVL(b.warehousingstate, '') warehousestate2, --입고상태
				   NVL(MPM04.divname, '') instatename, -- 입고 상태 명
				   NVL(a.accountno, '') taxno2,
				   NVL(a.accountday, '') slipindate2
			FROM   PDWAREHOUSINGRM a
				   JOIN PDWAREHOUSINGM b
					   ON a.plantcode = b.plantcode
						  AND a.warehousingdiv = b.warehousingdiv
						  AND a.warehousingno = b.warehousingno
				   --and b.finishamt <> 0
				   --and b.accountday <> ''

				   LEFT JOIN PDITEMRELATION c ON b.itemcode = c.itemcode
				   LEFT JOIN CMITEMM M ON NVL(c.ritemcode, b.itemcode) = M.itemcode
				   --on b.itemcode = m.itemcode

				   LEFT JOIN CMCOMMONM MPM17
					   ON MPM17.cmmcode = 'MPM17'
						  AND MPM17.divcode = b.buydiv
				   LEFT JOIN CMCOMMONM MPM04
					   ON MPM04.cmmcode = 'MPM04'
						  AND MPM04.divcode = b.warehousingstate
				   LEFT JOIN CommonMaster CMM01
					   ON CMM01.cmmcode = 'CMM01'
						  AND CMM01.divcode = M.itemdiv
			WHERE  b.plantcode = p_plantcode
				   AND b.custcode = p_custcode
				   AND a.accountday = p_slipindate
				   AND NVL(a.accountseq, 0) = p_slipinseq
				   AND MPM04.filter2 = 'Acc'
				   AND NVL(a.workdiv, '02') = '02'
      order by warehousingno;
	ELSIF (UPPER(P_DIV) = 'PPLOAD1')
	THEN
		IF (p_actrnstate = '1')
		THEN
			--신규 생성
			-- 기간동안의 모든 전표를 생성한다.
			INSERT INTO ACAUTOORDT(compcode, --회사코드
								   acattype, --전표유형(P)
								   acatno, --taxno
								   slipindate, --발의일자(세금계산서일자)
								   acatrulecode, --분개률코드(P01001)
								   deptcode, --부서
								   plantcode, --사업장
								   empcode, --발의사원코드
								   remark, --
								   custcode, --거래처코드
								   taxno, --계산서번호
								   trn1amt, --원재료매입액
								   trn2amt, --부재료매입액
								   trn3amt, --외주가공비
								   trn4amt, --상품매입액
								   trn5amt, --부가세
								   trn6amt, --합계금액
								   actrnstate, --실행상태
								   userdef3code, --사업장명
								   userdef4code, --부서명
								   userdef5code, --발의사원명
								   userdef6code, --거래처명
								   insertdt, --입력일자
								   iempcode) --입력사원
				(SELECT ip_compcode, --회사코드
						'P', --전표유형(P)
						ip_taxno, --적요@itemnm
						p_slipindate, --발의일자(세금계산서일자)
						p_acatrulecode, --분개률코드(P01001)
						(SELECT deptcode
						 FROM	CMEMPM
						 WHERE	empcode = p_iempcode), --부서
						p_plantcode, --사업장
						p_iempcode, --발의사원코드
						p_itemnm, --적요
						p_custcode, --거래처코드
						ip_taxno, --계산서번호
						p_finishamt1, --원재료금액
						p_finishamt2, --부재료
						p_finishamt3, --외주가공
						p_finishamt4, --상품
						p_taxamt2, --부가세
						p_taxamt3, --합계금액
						'1', --실행상태 신규
						(SELECT plantname
						 FROM	CMPLANTM
						 WHERE	plantcode = p_plantcode), --사업장명
						(SELECT D.deptname
						 FROM	CMEMPM E JOIN CMDEPTM D ON D.deptcode = E.deptcode
						 WHERE	E.empcode = p_iempcode), --부서명
						(SELECT E.empname
						 FROM	CMEMPM E
						 WHERE	E.empcode = p_iempcode), --발의사원명
						(SELECT custname
						 FROM	CMCUSTM
						 WHERE	custcode = p_custcode), --거래처명
						SYSDATE,
						--입력일자
						p_iempcode --입력사원
				 FROM	DUAL);

			MERGE INTO PDWAREHOUSINGM a
			USING	   (SELECT A.WAREHOUSINGDIV, A.WAREHOUSINGNO, A.PLANTCODE, 'Y'
						FROM   PDWAREHOUSINGM a
							   LEFT JOIN CMCOMMONM MPM04
								   ON MPM04.cmmcode = 'MPM04'
									  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
						WHERE  NVL(a.plantcode, ' ') LIKE p_plantcode || '%'
							   AND SUBSTR(a.warehousingdt, 1, 10) BETWEEN p_sdt AND p_edt
							   AND NVL(MPM04.filter2, ' ') = 'Acc'
							   AND NVL(a.custcode, ' ') = NVL(p_custcode,' ')
							   AND NVL(a.accountday, ' ') = NVL(p_slipindate,' ')
							   AND NVL(a.accountno, ' ') = NVL(ip_taxno,' ')) src
			ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
						AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
						AND A.PLANTCODE = SRC.PLANTCODE)
			WHEN MATCHED
			THEN
				UPDATE SET a.accountcheck = 'Y';
		ELSIF (p_actrnstate = '3')
		THEN
			--수정
			UPDATE ACAUTOORDT b
			SET    b.slipindate = p_slipindate,
				   b.acatrulecode = p_acatrulecode, --분개률코드(P01001)
				   b.deptcode =
					   (SELECT deptcode
						FROM   CMEMPM
						WHERE  empcode = p_iempcode), --부서
				   b.plantcode = p_plantcode, --사업장
				   b.empcode = p_iempcode, --발의사원코드
				   b.remark = p_itemnm, --
				   b.custcode = p_custcode, --거래처코드
				   b.taxno = ip_taxno, --계산서번호
				   b.trn1amt = p_finishamt1, --원재료매입액
				   b.trn2amt = p_finishamt2, --부재료매입액
				   b.trn3amt = p_finishamt3, --외주가공비
				   b.trn4amt = p_finishamt4, --상품매입액
				   b.trn5amt = p_taxamt2, --부가세
				   b.trn6amt = p_taxamt3, --합계금액
				   b.actrnstate = p_actrnstate, --실행상태
				   b.userdef3code =
					   (SELECT plantname
						FROM   CMPLANTM
						WHERE  plantcode = p_plantcode), --사업장명
				   b.userdef4code =
					   (SELECT D.deptname
						FROM   CMEMPM E LEFT JOIN CMDEPTM D ON D.deptcode = E.deptcode
						WHERE  E.empcode = p_iempcode), --부서명
				   b.userdef5code =
					   (SELECT E.empname
						FROM   CMEMPM E
						WHERE  E.empcode = p_iempcode), --사원명
				   b.userdef6code =
					   (SELECT custname
						FROM   CMCUSTM
						WHERE  custcode = p_custcode), --거래처명
				   b.updatedt --입력일자
							  = SYSDATE,
				   b.uempcode = p_iempcode
			WHERE  b.compcode = ip_compcode
				   AND b.acattype = 'P'
				   AND b.acatno = ip_taxno;
		ELSIF (p_actrnstate = '4')
		THEN
			UPDATE ACAUTOORDT b
			SET    b.actrnstate = p_actrnstate, b.remark = p_itemnm, b.updatedt = SYSDATE, b.uempcode = p_iempcode
			WHERE  b.compcode = ip_compcode
				   AND b.acattype = 'P'
				   AND b.acatno = ip_taxno;
		END IF;
	ELSIF (UPPER(P_DIV) = 'PPLOAD2')
	THEN
		IF (p_actrnstate = '1')
		THEN
			--신규 생성
			-- 기간동안의 모든 전표를 생성한다.
			INSERT INTO ACAUTOORDT(compcode, --회사코드
								   acattype, --전표유형(P)
								   acatno, --taxno
								   slipindate, --발의일자(세금계산서일자)
								   acatrulecode, --분개률코드(P01001)
								   deptcode, --부서
								   plantcode, --사업장
								   empcode, --발의사원코드
								   remark, --
								   custcode, --거래처코드
								   taxno, --계산서번호
								   trn1amt, --원재료매입액
								   trn2amt, --부재료매입액
								   trn3amt, --외주가공비
								   trn4amt, --상품매입액
								   trn5amt, --부가세
								   trn6amt, --합계금액
								   trn11amt, --수입원재료매입액
								   trn12amt, --수입상품매입액
								   actrnstate, --실행상태
								   userdef3code, --사업장명
								   userdef4code, --부서명
								   userdef5code, --발의사원명
								   userdef6code, --거래처명
								   insertdt, --입력일자
								   iempcode) --입력사원
				(SELECT ip_compcode, --회사코드
						'P', --전표유형(P)
						ip_taxno, --적요@itemnm
						p_slipindate, --발의일자(세금계산서일자)
						p_acatrulecode, --분개률코드(P01001)
						(SELECT deptcode
						 FROM	CMEMPM
						 WHERE	empcode = p_iempcode), --부서
						p_plantcode, --사업장
						p_iempcode, --발의사원코드
						p_itemnm, --적요
						p_custcode, --거래처코드
						ip_taxno, --계산서번호
						p_finishamt1, --원재료금액
						p_finishamt2, --부재료
						p_finishamt3, --외주가공
						p_finishamt4, --상품
						p_taxamt2, --부가세
						p_taxamt3, --합계금액
						p_finishamt5, --수입원재료매입액
						p_finishamt6, --수입상품매입액
						'1', --실행상태 신규
						(SELECT plantname
						 FROM	CMPLANTM
						 WHERE	plantcode = p_plantcode), --사업장명
						(SELECT D.deptname
						 FROM	CMEMPM E JOIN CMDEPTM D ON D.deptcode = E.deptcode
						 WHERE	E.empcode = p_iempcode), --부서명
						(SELECT E.empname
						 FROM	CMEMPM E
						 WHERE	E.empcode = p_iempcode), --발의사원명
						(SELECT custname
						 FROM	CMCUSTM
						 WHERE	custcode = p_custcode), --거래처명
						SYSDATE,
						--입력일자
						p_iempcode --입력사원
				 FROM	DUAL);

			--set @plantcode = '1000'
			MERGE INTO PDWAREHOUSINGM a
			USING	   (SELECT A.WAREHOUSINGDIV, A.WAREHOUSINGNO, A.PLANTCODE, 'Y'
						FROM   PDWAREHOUSINGM a
							   LEFT JOIN CMCOMMONM MPM04
								   ON MPM04.cmmcode = 'MPM04'
									  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
						WHERE  a.plantcode = p_plantcode
							   AND a.custcode = p_custcode
							   AND a.accountno = ip_taxno
							   AND MPM04.filter2 = 'Acc') src
			ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
						AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
						AND A.PLANTCODE = SRC.PLANTCODE)
			WHEN MATCHED
			THEN
				UPDATE SET a.accountcheck = 'Y';

			MERGE INTO PDWAREHOUSINGRM a
			USING	   (SELECT A.WAREHOUSINGRETURNINGNO, A.WAREHOUSINGDIV, A.PLANTCODE, 'Y'
						FROM   PDWAREHOUSINGRM a
							   JOIN PDWAREHOUSINGM b
								   ON a.warehousingno = b.warehousingno
									  AND b.plantcode = p_plantcode
									  AND b.custcode = p_custcode
						--and b.finishamt <> 0
						--and b.accountday <> ''

						WHERE  a.accountno = ip_taxno) src
			ON		   (A.WAREHOUSINGRETURNINGNO = SRC.WAREHOUSINGRETURNINGNO
						AND A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
						AND A.PLANTCODE = SRC.PLANTCODE)
			WHEN MATCHED
			THEN
				UPDATE SET A.accountcheck = 'Y';

			MERGE INTO PDPURCHASEDC a
			USING	   (SELECT A.DISCOUNTID, 'Y'
						FROM   PDPURCHASEDC a
							   JOIN PDWAREHOUSINGM b
								   ON a.warehousingno = b.warehousingno
									  AND b.plantcode = p_plantcode
									  AND b.custcode = p_custcode
									  AND TRIM(b.accountday) IS NOT NULL
						WHERE  a.accountno = ip_taxno) src
			ON		   (A.DISCOUNTID = SRC.DISCOUNTID)
			WHEN MATCHED
			THEN
				UPDATE SET A.discountchk = 'Y';

			MERGE INTO PDWAREHOUSINGM a
			USING	   (SELECT A.WAREHOUSINGDIV, A.WAREHOUSINGNO, A.PLANTCODE, 'Y'
						FROM   PDWAREHOUSINGM a
							   JOIN (SELECT accountday, PDWAREHOUSINGM.accountseq
									 FROM	PDWAREHOUSINGM
									 WHERE	PDWAREHOUSINGM.plantcode = p_plantcode
											AND PDWAREHOUSINGM.custcode = p_custcode
											AND PDWAREHOUSINGM.warehousingno = ip_taxno
									 UNION
									 SELECT a.accountday, a.accountseq
									 FROM	PDWAREHOUSINGRM a
											JOIN PDWAREHOUSINGM b
												ON a.warehousingno = b.warehousingno
												   AND b.plantcode = p_plantcode
												   AND b.custcode = p_custcode
									 --and b.finishamt <> 0

									 --and b.accountday <> ''
									 WHERE	a.warehousingreturningno = ip_taxno) b
								   ON a.accountday = b.accountday
									  AND NVL(a.accountseq, 0) = NVL(b.accountseq, 0)
							   LEFT JOIN CMCOMMONM MPM04
								   ON MPM04.cmmcode = 'MPM04'
									  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
						WHERE  a.plantcode = p_plantcode
							   AND a.custcode = p_custcode
							   AND MPM04.filter2 = 'Acc') src
			ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
						AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
						AND A.PLANTCODE = SRC.PLANTCODE)
			WHEN MATCHED
			THEN
				UPDATE SET a.accountcheck = 'Y', a.accountno = ip_taxno;

			MERGE INTO PDWAREHOUSINGRM a
			USING	   (SELECT A.WAREHOUSINGRETURNINGNO, A.WAREHOUSINGDIV, A.PLANTCODE, 'Y'
						FROM   PDWAREHOUSINGRM a
							   JOIN PDWAREHOUSINGM b
								   ON a.warehousingno = b.warehousingno
									  AND b.plantcode = p_plantcode
									  AND b.custcode = p_custcode
							   JOIN ( --and b.finishamt <> 0
									 --and b.accountday <> ''
									 SELECT accountday, PDWAREHOUSINGM.accountseq
									 FROM	PDWAREHOUSINGM
									 WHERE	PDWAREHOUSINGM.plantcode = p_plantcode
											AND PDWAREHOUSINGM.custcode = p_custcode
											AND PDWAREHOUSINGM.warehousingno = ip_taxno
									 UNION
									 SELECT a.accountday, a.accountseq
									 FROM	PDWAREHOUSINGRM a
											JOIN PDWAREHOUSINGM b
												ON a.warehousingno = b.warehousingno
												   AND b.plantcode = p_plantcode
												   AND b.custcode = p_custcode
									 --and b.finishamt <> 0

									 --and b.accountday <> ''
									 WHERE	a.warehousingreturningno = ip_taxno) c
								   ON a.accountday = c.accountday
									  AND NVL(a.accountseq, 0) = NVL(c.accountseq, 0)) src
			ON		   (A.WAREHOUSINGRETURNINGNO = SRC.WAREHOUSINGRETURNINGNO
						AND A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
						AND A.PLANTCODE = SRC.PLANTCODE)
			WHEN MATCHED
			THEN
				UPDATE SET A.accountcheck = 'Y', A.accountno = ip_taxno;
		ELSIF (p_actrnstate = '3')
		THEN
			--수정
			UPDATE ACAUTOORDT b
			SET    b.slipindate = p_slipindate,
				   b.acatrulecode = p_acatrulecode --분개률코드(P01001)
												  ,
				   b.deptcode =
					   (SELECT deptcode
						FROM   CMEMPM
						WHERE  empcode = p_iempcode), --부서
				   b.plantcode = p_plantcode, --사업장
				   b.empcode = p_iempcode, --발의사원코드
				   b.remark = p_itemnm, --
				   b.custcode = p_custcode, --거래처코드
				   b.taxno = ip_taxno, --계산서번호
				   b.trn1amt = p_finishamt1, --원재료매입액
				   b.trn2amt = p_finishamt2, --부재료매입액
				   b.trn3amt = p_finishamt3, --외주가공비
				   b.trn4amt = p_finishamt4, --상품매입액
				   b.trn5amt = p_taxamt2, --부가세
				   b.trn6amt = p_taxamt3, --합계금액
				   b.trn11amt = p_finishamt5, --수입원재료매입액
				   b.trn12amt = p_finishamt6, --수입상품매입액
				   b.actrnstate = p_actrnstate, --실행상태
				   b.userdef3code =
					   (SELECT plantname
						FROM   CMPLANTM
						WHERE  plantcode = p_plantcode), --사업장명
				   b.userdef4code =
					   (SELECT D.deptname
						FROM   CMEMPM E LEFT JOIN CMDEPTM D ON D.deptcode = E.deptcode
						WHERE  E.empcode = p_iempcode), --부서명
				   b.userdef5code =
					   (SELECT E.empname
						FROM   CMEMPM E
						WHERE  E.empcode = p_iempcode), --사원명
				   b.userdef6code =
					   (SELECT custname
						FROM   CMCUSTM
						WHERE  custcode = p_custcode), --거래처명
				   b.updatedt = SYSDATE, --입력일자
				   b.uempcode = p_iempcode
			WHERE  b.compcode = ip_compcode
				   AND b.acattype = 'P'
				   AND b.acatno = ip_taxno;
		ELSIF (p_actrnstate = '4')
		THEN
			UPDATE ACAUTOORDT b
			SET    b.actrnstate = p_actrnstate, b.remark = p_itemnm, b.updatedt = SYSDATE, b.uempcode = p_iempcode
			WHERE  b.compcode = ip_compcode
				   AND b.acattype = 'P'
				   AND b.acatno = ip_taxno;
		END IF;
	ELSIF (UPPER(P_DIV) = 'PPLOAD3')
	THEN
		IF (p_actrnstate = '1')
		THEN
			--신규 생성
			-- 기간동안의 모든 전표를 생성한다.
			INSERT INTO ACAUTOORDT(compcode, --회사코드
								   acattype, --전표유형(P)
								   acatno, --taxno
								   slipindate, --발의일자(세금계산서일자)
								   acatrulecode, --분개률코드(P01001)
								   deptcode, --부서
								   plantcode, --사업장
								   empcode, --발의사원코드
								   remark, --
								   custcode, --거래처코드
								   taxno, --계산서번호
								   trn1amt, --원재료매입액
								   trn2amt, --부재료매입액
								   trn3amt, --외주가공비
								   trn4amt, --상품매입액
								   trn5amt, --부가세
								   trn6amt, --합계금액
								   trn11amt, --수입원재료매입액
								   trn12amt, --수입상품매입액
								   trn13amt, --시약매입액
								   trn14amt, --소모품매입액
								   actrnstate, --실행상태
								   userdef3code, --사업장명
								   userdef4code, --부서명
								   userdef5code, --발의사원명
								   userdef6code, --거래처명
								   userdef9code, --LC코드
								   userdef10code, --LC명
								   insertdt, --입력일자
								   iempcode) --입력사원
				(SELECT ip_compcode, --회사코드
						'P', --전표유형(P)
						ip_taxno, --적요@itemnm
						p_slipindate, --발의일자(세금계산서일자)
						p_acatrulecode, --분개률코드(P01001)
						(SELECT deptcode
						 FROM	CMEMPM
						 WHERE	empcode = p_iempcode), --부서
						p_plantcode, --사업장
						p_iempcode, --발의사원코드
						p_itemnm, --적요
						p_custcode, --거래처코드
						ip_taxno, --계산서번호
						p_finishamt1, --원재료금액
						p_finishamt2, --부재료
						p_finishamt3, --외주가공
						p_finishamt4, --상품
						p_taxamt2, --부가세
						p_taxamt3, --합계금액
						p_finishamt5, --수입원재료매입액
						p_finishamt6, --수입상품매입액
						p_finishamt7, --시약매입액
						p_finishamt8, --소모품매입액
						'1', --실행상태 신규
						(SELECT plantname
						 FROM	CMPLANTM
						 WHERE	plantcode = p_plantcode), --사업장명
						(SELECT D.deptname
						 FROM	CMEMPM E JOIN CMDEPTM D ON D.deptcode = E.deptcode
						 WHERE	E.empcode = p_iempcode), --부서명
						(SELECT E.empname
						 FROM	CMEMPM E
						 WHERE	E.empcode = p_iempcode), --발의사원명
						(SELECT custname
						 FROM	CMCUSTM
						 WHERE	custcode = p_custcode), --거래처명
						p_lccode, --LC코드
						p_lcname, --LC명
						SYSDATE,
						--입력일자
						p_iempcode --입력사원
				 FROM	DUAL);

			--set @plantcode = '1000'
			MERGE INTO PDWAREHOUSINGM a
			USING	   (SELECT A.WAREHOUSINGDIV, A.WAREHOUSINGNO, A.PLANTCODE, 'Y'
						FROM   PDWAREHOUSINGM a
							   LEFT JOIN CMCOMMONM MPM04
								   ON MPM04.cmmcode = 'MPM04'
									  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
						WHERE  a.plantcode = p_plantcode
							   AND a.custcode = p_custcode
							   AND a.accountno = ip_taxno
							   AND MPM04.filter2 = 'Acc') src
			ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
						AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
						AND A.PLANTCODE = SRC.PLANTCODE)
			WHEN MATCHED
			THEN
				UPDATE SET a.accountcheck = 'Y';

			MERGE INTO PDWAREHOUSINGRM a
			USING	   (SELECT A.WAREHOUSINGRETURNINGNO, A.WAREHOUSINGDIV, A.PLANTCODE, 'Y'
						FROM   PDWAREHOUSINGRM a
							   JOIN PDWAREHOUSINGM b
								   ON a.warehousingno = b.warehousingno
									  AND b.plantcode = p_plantcode
									  AND b.custcode = p_custcode
						--and b.finishamt <> 0
						--and b.accountday <> ''

						WHERE  a.accountno = ip_taxno) src
			ON		   (A.WAREHOUSINGRETURNINGNO = SRC.WAREHOUSINGRETURNINGNO
						AND A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
						AND A.PLANTCODE = SRC.PLANTCODE)
			WHEN MATCHED
			THEN
				UPDATE SET A.accountcheck = 'Y';

			MERGE INTO PDPURCHASEDC a
			USING	   (SELECT A.DISCOUNTID, 'Y'
						FROM   PDPURCHASEDC a
							   JOIN PDWAREHOUSINGM b
								   ON a.warehousingno = b.warehousingno
									  AND b.plantcode = p_plantcode
									  AND b.custcode = p_custcode
									  AND TRIM(b.accountday) IS NOT NULL
						WHERE  a.accountno = ip_taxno) src
			ON		   (A.DISCOUNTID = SRC.DISCOUNTID)
			WHEN MATCHED
			THEN
				UPDATE SET A.discountchk = 'Y';

			MERGE INTO PDWAREHOUSINGM a
			USING	   (SELECT A.WAREHOUSINGDIV, A.WAREHOUSINGNO, A.PLANTCODE, 'Y'
						FROM   PDWAREHOUSINGM a
							   JOIN (SELECT accountday, PDWAREHOUSINGM.accountseq
									 FROM	PDWAREHOUSINGM
									 WHERE	PDWAREHOUSINGM.plantcode = p_plantcode
											AND PDWAREHOUSINGM.custcode = p_custcode
											AND PDWAREHOUSINGM.warehousingno = ip_taxno
									 UNION
									 SELECT a.accountday, a.accountseq
									 FROM	PDWAREHOUSINGRM a
											JOIN PDWAREHOUSINGM b
												ON a.warehousingno = b.warehousingno
												   AND b.plantcode = p_plantcode
												   AND b.custcode = p_custcode
									 --and b.finishamt <> 0

									 --and b.accountday <> ''
									 WHERE	a.warehousingreturningno = ip_taxno) b
								   ON a.accountday = b.accountday
									  AND NVL(a.accountseq, 0) = NVL(b.accountseq, 0)
							   LEFT JOIN CMCOMMONM MPM04
								   ON MPM04.cmmcode = 'MPM04'
									  AND MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 Acc값 적용됨.)
						WHERE  a.plantcode = p_plantcode
							   AND a.custcode = p_custcode
							   AND MPM04.filter2 = 'Acc') src
			ON		   (A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
						AND A.WAREHOUSINGNO = SRC.WAREHOUSINGNO
						AND A.PLANTCODE = SRC.PLANTCODE)
			WHEN MATCHED
			THEN
				UPDATE SET a.accountcheck = 'Y', a.accountno = ip_taxno;

			MERGE INTO PDWAREHOUSINGRM a
			USING	   (SELECT A.WAREHOUSINGRETURNINGNO, A.WAREHOUSINGDIV, A.PLANTCODE, 'Y'
						FROM   PDWAREHOUSINGRM a
							   JOIN PDWAREHOUSINGM b
								   ON a.warehousingno = b.warehousingno
									  AND b.plantcode = p_plantcode
									  AND b.custcode = p_custcode
							   JOIN ( --and b.finishamt <> 0
									 --and b.accountday <> ''
									 SELECT accountday, PDWAREHOUSINGM.accountseq
									 FROM	PDWAREHOUSINGM
									 WHERE	PDWAREHOUSINGM.plantcode = p_plantcode
											AND PDWAREHOUSINGM.custcode = p_custcode
											AND PDWAREHOUSINGM.warehousingno = ip_taxno
									 UNION
									 SELECT a.accountday, a.accountseq
									 FROM	PDWAREHOUSINGRM a
											JOIN PDWAREHOUSINGM b
												ON a.warehousingno = b.warehousingno
												   AND b.plantcode = p_plantcode
												   AND b.custcode = p_custcode
									 --and b.finishamt <> 0

									 --and b.accountday <> ''
									 WHERE	a.warehousingreturningno = ip_taxno) c
								   ON a.accountday = c.accountday
									  AND NVL(a.accountseq, 0) = NVL(c.accountseq, 0)) src
			ON		   (A.WAREHOUSINGRETURNINGNO = SRC.WAREHOUSINGRETURNINGNO
						AND A.WAREHOUSINGDIV = SRC.WAREHOUSINGDIV
						AND A.PLANTCODE = SRC.PLANTCODE)
			WHEN MATCHED
			THEN
				UPDATE SET A.accountcheck = 'Y', A.accountno = ip_taxno;
		ELSIF (p_actrnstate = '3')
		THEN
			--수정
			UPDATE ACAUTOORDT b
			SET    b.slipindate = p_slipindate,
				   b.acatrulecode = p_acatrulecode, --분개률코드(P01001)
				   b.deptcode =
					   (SELECT deptcode
						FROM   CMEMPM
						WHERE  empcode = p_iempcode), --부서
				   b.plantcode = p_plantcode, --사업장
				   b.empcode = p_iempcode, --발의사원코드
				   b.remark = p_itemnm, --
				   b.custcode = p_custcode, --거래처코드
				   b.taxno = ip_taxno, --계산서번호
				   b.trn1amt = p_finishamt1, --원재료매입액
				   b.trn2amt = p_finishamt2, --부재료매입액
				   b.trn3amt = p_finishamt3, --외주가공비
				   b.trn4amt = p_finishamt4, --상품매입액
				   b.trn5amt = p_taxamt2, --부가세
				   b.trn6amt = p_taxamt3, --합계금액
				   b.trn11amt = p_finishamt5, --수입원재료매입액
				   b.trn12amt = p_finishamt6, --수입상품매입액
				   b.trn13amt = p_finishamt7, --시약매입액
				   b.trn14amt = p_finishamt8, --소모품매입액
				   b.actrnstate = p_actrnstate, --실행상태
				   b.userdef3code =
					   (SELECT plantname
						FROM   CMPLANTM
						WHERE  plantcode = p_plantcode), --사업장명
				   b.userdef4code =
					   (SELECT D.deptname
						FROM   CMEMPM E LEFT JOIN CMDEPTM D ON D.deptcode = E.deptcode
						WHERE  E.empcode = p_iempcode), --부서명
				   b.userdef5code =
					   (SELECT E.empname
						FROM   CMEMPM E
						WHERE  E.empcode = p_iempcode), --사원명
				   b.userdef6code =
					   (SELECT custname
						FROM   CMCUSTM
						WHERE  custcode = p_custcode), --거래처명
				   b.userdef9code = p_lccode, --LC코드
				   b.userdef10code = p_lcname, --LC명
				   b.updatedt --입력일자
							  = SYSDATE,
				   b.uempcode = p_iempcode
			WHERE  b.compcode = ip_compcode
				   AND b.acattype = 'P'
				   AND b.acatno = ip_taxno;
		ELSIF (p_actrnstate = '4')
		THEN
			UPDATE ACAUTOORDT b
			SET    b.actrnstate = p_actrnstate, b.remark = p_itemnm, b.updatedt = SYSDATE, b.uempcode = p_iempcode
			WHERE  b.compcode = ip_compcode
				   AND b.acattype = 'P'
				   AND b.acatno = ip_taxno;
		END IF;
	ELSIF (UPPER(P_DIV) = 'HEAD')
	THEN
		--일괄전송방식의 head레코드 처리 (매입)
		--메타 테이블에 해당일자의 매입 전표 로드 내용 삭제
		DELETE ACAUTOORD
		WHERE  slipindate = p_slipindate
			   AND plantcode LIKE p_plantcode || '%'
			   AND acattype = 'P';

		-- 기간동안의 모든 개시전표를 생성한다.
		INSERT INTO ACAUTOORD(compcode, --회사코드
							  slipindate, --발의일자(급여지급일자)
							  acatrulecode, --분개룰코드(S01001)
							  acattype, --전표유형(H)
							  plantcode, --사업장
							  actrnstate, --실행상태
							  insertdt, --입력일자
							  iempcode) --입력사원
		VALUES		(ip_compcode,
					 p_slipindate,
					 '', --분개룰코드
					 'P',
					 '', --@plantcode
					 '1',
					 SYSDATE,
					 p_iempcode);
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
