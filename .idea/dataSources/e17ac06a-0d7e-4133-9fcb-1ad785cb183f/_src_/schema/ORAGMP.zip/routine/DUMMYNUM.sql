CREATE FUNCTION        dummynum
-----------------------------------------------
 -- 넘겨준 숫자 이하의 숫자 테이블 생성
 -- 작성자 : 조성희
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2017-01-19 
 -----------------------------------------------
(
    p_start_i   IN NUMBER DEFAULT 0,
    p_max_i     IN NUMBER DEFAULT 0
)
RETURN FN_DUMMYNUM_TABLE
AS
    p_i NUMBER := 0;
    
    p_index NUMBER := 1;
       
    --함수내에서 변수 저장용 변수 초기화
    dummynumListRecode FN_DUMMYNUM_TABLE := FN_DUMMYNUM_TABLE(); 
BEGIN

    p_i := p_start_i ;
       
    WHILE ( p_i <= p_max_i ) LOOP 

         
        dummynumListRecode.EXTEND;
        dummynumListRecode(p_index) := FN_DUMMYNUM_VARIABLE(p_i);
            

        p_i := p_i + 1 ;
        p_index := p_index + 1 ;
          
    END LOOP;
   

    RETURN dummynumListRecode;

END;
/
