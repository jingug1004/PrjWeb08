CREATE PROCEDURE        spACass0101R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACass0101R
	-- 작 성 자         : 이영재
	-- 작성일자         : 2011-03-15
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2017-01-02
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 자산변경현황대장을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_assdiv		IN	   VARCHAR2 DEFAULT '',
	p_asscls		IN	   VARCHAR2 DEFAULT '',
	p_assstate		IN	   VARCHAR2 DEFAULT '',
	p_sasscode		IN	   VARCHAR2 DEFAULT '',
	p_easscode		IN	   VARCHAR2 DEFAULT '',
	p_enddate		IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '',
	p_asschgdiv 	IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT SYS_REFCURSOR
)
AS
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S')
	THEN
		OPEN IO_CURSOR FOR
			SELECT	 a.compcode compcode, --회사코드
					 a.asscode asscode, --자산코드
					 a.assname assname, --자산명
					 b.closediv closediv, --결산구분
					 b.chgdate chgdate,
					 b.asschgdiv asschgdiv, --변경구분
					 b.custcode custcode, --거래처코드
					 b.deptcode deptcode, --부서코드
					 b.deprdiv chgdeprdiv, --변경감가상각기준
					 b.keeprmk chgrmk, --
					 NVL(b.curassamt + b.chgamt, 0) gucurassamt, --변경전자산가액
					 NVL(b.chgamt, 0) chgcurassamt, --변경금액
					 NVL(b.curassamt, 0) rejudvaryamt, --변경후자산가액
					 NVL(b.lifeyear, 0) chglifeyear, --
					 NVL(b.seq, 0) seq,
					 a.assdiv assdiv, --자산구분 유,무형
					 a.asscls asscls, --토지,건물,건축물
					 a.strdate strdate, --취득일자
					 NVL(a.lifeyear, 0) lifeyear, -- 내용년수
					 a.plantcode plantcode, --사업장코드
					 a.mngdeptcode mngdeptcode, --관리부서
					 a.acccode acccode, --계정코드
					 a.keeprmk keeprmk, --비고
					 a.masscode masscode, --설비코드
					 a.acqdiv acqdiv, --취득방법
					 a.depryn depryn, --상각여부
					 a.deprdiv deprdiv, --상각방법
					 a.remark remark, --비고
					 a.deprendyn deprendyn, --감가상각종료여부
					 a.assstate assstate, --자산상태
					 NVL(a.curassamt, 0) curassamt, --취득가액
					 NVL(a.lstassamt, 0) lstassamt, --비망가액
					 a.subsidyn subsidyn, --정부지원여부
					 a.subsidrmk subsidrmk, --정부지원내용
					 NVL(a.subsidassamt, 0) subsidassamt, --정보지원금액
					 e.deptname mngdeptname,
					 f.accname accname,
					 M.equipmentkorname massname,
					 p.plantname plantname,
					 ac76.divname assstatename,
					 ac71.divname assclsname,
					 ac70.divname assdivname,
					 NVL(b.deprate, a.deprate) deprerate,
					 ac02.divname closedivname,
					 ac77.divname asschgdivname,
					 ac74.divname deprdivname,
					 ac74.divname chgdeprdivname,
					 cust.custname custname,
					 dept.deptname deptname
			FROM	 ACASSM a
					 LEFT JOIN ACASSD b --변동내역
						 ON a.compcode = b.compcode
							AND b.closediv LIKE p_closediv || '%'
							AND (NVL(p_enddate,' ') > ' '
								 AND b.chgdate <= p_enddate
								 OR trim(p_enddate) is null )
							AND NVL(b.asscode,' ') = NVL(a.asscode,' ')
							AND b.asschgdiv LIKE p_asschgdiv || '%'
					 LEFT JOIN CMDEPTM e ON a.mngdeptcode = e.deptcode
					 LEFT JOIN ACACCM f ON a.acccode = f.acccode
					 LEFT JOIN PDEQUIPMENTM M ON M.equipmentcode = a.masscode
					 LEFT JOIN CMPLANTM p ON p.plantcode = a.plantcode
					 LEFT JOIN CMCOMMONM ac76
						 ON ac76.cmmcode = 'AC76'
							AND ac76.divcode = a.assstate
					 LEFT JOIN CMCOMMONM ac71 --자산분류
						 ON ac71.cmmcode = 'AC71'
							AND ac71.divcode = a.asscls
					 LEFT JOIN CMCOMMONM ac70
						 ON ac70.cmmcode = 'AC70' --자산형태
							AND ac70.divcode = a.assdiv
					 LEFT JOIN ACDEPRM rate
						 ON rate.compcode = a.compcode
							AND rate.lifeyear = a.lifeyear
							AND rate.deprdiv = a.deprdiv
					 LEFT JOIN ACDEPRM rate2
						 ON rate2.compcode = b.compcode
							AND rate2.lifeyear = b.lifeyear
							AND rate2.deprdiv = b.deprdiv
					 LEFT JOIN CMCOMMONM ac02
						 ON ac02.cmmcode = 'AC02' --결산구분
							AND ac02.divcode = b.closediv
					 LEFT JOIN CMCOMMONM ac77
						 ON ac77.cmmcode = 'AC77' --자산형태
							AND ac77.divcode = b.asschgdiv
					 LEFT JOIN CMCOMMONM ac74
						 ON ac74.cmmcode = 'AC74' --상각방법
							AND ac74.divcode = a.deprdiv
					 LEFT JOIN CMCOMMONM chgac74
						 ON chgac74.cmmcode = 'AC74' --상각방법(변경)
							AND chgac74.divcode = b.deprdiv
					 LEFT JOIN CMCUSTM cust ON cust.custcode = b.custcode
					 LEFT JOIN CMDEPTM dept ON dept.deptcode = b.deptcode
			WHERE	 a.compcode = p_compcode
					 AND (NVL(p_sasscode,' ') > ' '
						  AND NVL(a.asscode,' ') >= NVL(p_sasscode,' ')
						  OR trim(p_sasscode) is null )
					 AND (NVL(p_easscode,' ') > ' '
						  AND NVL(a.asscode,' ') <= NVL(p_easscode,' ')
						  OR trim(p_easscode) is null )
					 AND a.plantcode LIKE p_plantcode || '%'
					 AND a.assdiv LIKE p_assdiv || '%'
					 AND a.asscls LIKE p_asscls || '%'
					 AND a.assstate LIKE p_assstate || '%'
			ORDER BY a.asscode, b.closediv, b.asschgdiv, b.chgdate DESC, b.seq DESC;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
