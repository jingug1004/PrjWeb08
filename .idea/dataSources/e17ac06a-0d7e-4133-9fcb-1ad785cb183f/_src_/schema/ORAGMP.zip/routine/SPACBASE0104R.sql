CREATE PROCEDURE        spACbase0104R
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACbase0104R
   -- 작 성 자         : 최기홍
   -- 작성일자         : 2010-09-15
   -- 임정호          : 임 정호
   -- 수정일          : 2016-12-12
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 재무양식현황물을 조회하는 프로시저이다.
   -- ---------------------------------------------------------------
(
   p_div          IN     VARCHAR2 DEFAULT ' ',
   p_compcode     IN     VARCHAR2 DEFAULT ' ',
   p_rptdiv       IN     VARCHAR2 DEFAULT ' ',
   p_rptyear      IN     VARCHAR2 DEFAULT ' ',
   p_prtdiv       IN     VARCHAR2 DEFAULT ' ',
   p_userid       IN     VARCHAR2 DEFAULT ' ',
   p_reasondiv    IN     VARCHAR2 DEFAULT ' ',
   p_reasontext   IN     VARCHAR2 DEFAULT ' ',
   IO_CURSOR         OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2)
AS
BEGIN
    MESSAGE := '데이터 확인';


    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( p_div = 'S' ) THEN


      OPEN  IO_CURSOR FOR
         SELECT NVL(a.compcode, '') compcode  ,
                NVL(a.rptdiv, '') rptdiv  ,
                NVL(a.rptyear, '') rptyear  ,
                NVL(a.seqline, '') seqline  ,
                NVL(a.acccode, '') acccode  ,
                NVL(a.accrname, '') accrname  ,
                NVL(a.acckname, '') acckname  ,
                NVL(a.objdatadiv, '') objdatadiv  ,
                NVL(a.calcdiv, '') calcdiv  ,
                NVL(a.sseqline, '') sseqline  ,
                NVL(a.cseqline, '') cseqline  ,
                NVL(a.calcseq, 0) calcseq  ,
                NVL(a.lrdiv, '') lrdiv  ,
                NVL(a.prtyn, '') prtyn  ,
                NVL(a.prtdiv, '') prtdiv  ,
                NVL(a.remark, '') remark  ,
                NVL(a.useyn, '') useyn
           FROM ACRPTM a
                  LEFT JOIN ACACCM b   ON a.acccode = b.acccode
          WHERE  a.compcode = p_compcode
                   AND a.rptdiv = p_rptdiv
                   AND a.rptyear = p_rptyear
                   AND ( a.prtdiv LIKE p_prtdiv
                   OR a.prtdiv = 'B' )
           ORDER BY a.seqline;


    ELSIF ( p_div = 'SY' ) THEN


         OPEN  IO_CURSOR FOR
            SELECT rptyear keyfield  ,
                   rptyear displayfield
              FROM ( SELECT DISTINCT TO_CHAR(SYSDATE,'YYYY') rptyear
                     FROM CMCOMPM
                      WHERE  NOT EXISTS ( SELECT *
                                          FROM ACRPTM
                                           WHERE  compcode = p_compcode
                                                    AND rptdiv = p_rptdiv )
                     UNION ALL
                     SELECT DISTINCT rptyear
                     FROM ACRPTM
                      WHERE  compcode = p_compcode
                               AND rptdiv = p_rptdiv ) a
              ORDER BY rptyear DESC;


    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
