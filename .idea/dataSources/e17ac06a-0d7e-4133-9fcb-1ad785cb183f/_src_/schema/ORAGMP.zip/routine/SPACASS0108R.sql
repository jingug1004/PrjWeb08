CREATE PROCEDURE        spACass0108R (
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACass0108R
   -- 작 성 자         : 최인범
   -- 작성일자         : 2010-10-04
   -- 수 정 자         : 임 정호
   -- 수정일자         : 2017-01-02
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 신규취득자산명세서를 조회하는 프로시저이다.
   -- ---------------------------------------------------------------


   p_div          IN     VARCHAR2 DEFAULT '',
   p_compcode     IN     VARCHAR2 DEFAULT '',
   p_plantcode    IN     VARCHAR2 DEFAULT '',
   p_closediv     IN     VARCHAR2 DEFAULT '',
   p_caldiv       IN     VARCHAR2 DEFAULT '',
   p_assym        IN     VARCHAR2 DEFAULT '',
   p_assdiv       IN     VARCHAR2 DEFAULT '',
   p_deptcode     IN     VARCHAR2 DEFAULT '',
   p_workdiv      IN     VARCHAR2 DEFAULT '',
   p_userid       IN     VARCHAR2 DEFAULT '',
   p_reasondiv    IN     VARCHAR2 DEFAULT '',
   p_reasontext   IN     VARCHAR2 DEFAULT '',
   IO_CURSOR         OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2)
AS
   p_strym     VARCHAR2 (7);
   p_strdate   VARCHAR2 (10);
   p_enddate   VARCHAR2 (10);
BEGIN
   MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

   -- 계산기간 설정
   p_strym := SUBSTR (p_assym, 0, 4) || '-01';

   SELECT MAX (SUBSTR (curstrdate, 0, 7)) INTO  p_strym
   FROM ACSESSION a
   WHERE compcode = p_compcode AND cyear <= SUBSTR (p_assym, 0, 4) ;


   IF SUBSTR (p_assym, -2) < SUBSTR (p_strym, -2) THEN

      p_strym := (SUBSTR (p_assym, 1, 4) - 1 ) || SUBSTR (p_strym, -3);

   ELSE
      p_strym := SUBSTR (p_assym, 1, 4) || SUBSTR (p_strym, -3);
   END IF;

   p_strdate := p_strym || '-01';
   p_enddate := TO_CHAR(LAST_DAY(TO_DATE(p_assym,'YYYY-MM')),'YYYY-MM-DD');
   p_strdate := p_assym || '-01';

   IF (p_div = 'S') THEN
      OPEN IO_CURSOR FOR
           SELECT NVL (a.asscode, '') asscode,                         --자산코드
                  NVL (a.assname, '') assname,                          --자산명
                  NVL (a.assdiv, '') assdiv,                      --자산구분 유,무형
                  NVL (a.strdate, '') strdate,                         --취득일자
                  NVL (a.lifeyear, 0) lifeyear,                         --내용년수
                  NVL (a.deprate, 0) deprate,                            --상각율
                  NVL (a.deprdiv, '') deprdiv,                         --상각방법
                  NVL (a.curassamt, 0) curassamt,                       --취득가액
                  NVL (b.depamt, 0) depamt,                              --상각액
                  NVL (b.yetdepamt, 0) yetdepamt,                       --미상각액
                  NVL (ac70.divname, '') assdivname,
                  NVL (ac74.divname, '') deprdivname
             FROM ACASSM a
                  LEFT JOIN CMCOMMONM ac70
                     ON     ac70.cmmcode = 'AC70'                           --자산형태
                        AND ac70.divcode = a.assdiv
                  LEFT JOIN CMCOMMONM ac74
                     ON     ac74.cmmcode = 'AC74'
                        AND ac74.divcode = a.deprdiv
                  LEFT JOIN
                  ACASSDEPR b
                     ON     a.compcode = b.compcode
                        AND b.closediv = p_closediv
                        AND b.caldiv = p_caldiv
                        AND b.assym = p_assym
                        AND a.asscode = b.asscode
            WHERE     a.compcode = p_compcode
                  AND a.plantcode LIKE p_plantcode
                  AND a.assdiv LIKE p_assdiv
                  AND a.workdiv LIKE p_workdiv
                  AND a.strdate BETWEEN p_strdate AND p_enddate
                  AND NVL (a.mngdeptcode, ' ') LIKE p_deptcode || '%'
         ORDER BY a.asscode;
   END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
