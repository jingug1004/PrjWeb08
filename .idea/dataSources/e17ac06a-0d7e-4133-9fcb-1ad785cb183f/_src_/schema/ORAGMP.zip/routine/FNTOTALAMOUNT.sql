CREATE FUNCTION        fnTotalAmount
-- ---------------------------------------------------------------
 -- 함 수 명			: fnTotalAmount
 -- 작 성 자         : 조성희
 -- 작성일자         : 2008-10-22
 -- ---------------------------------------------------------------
 -- 함수설명			: 주문서의 공급금액 합계, 부가세 합계, 매출금액 합계를 가져온다.
 -- ---------------------------------------------------------------
(
    p_orderno   IN VARCHAR2 DEFAULT '' ,
    p_gb        IN VARCHAR2 DEFAULT '' 
)
RETURN FLOAT
AS
    p_amt FLOAT := 0;
BEGIN
   
    IF ( LOWER(p_gb) = 'salamt' ) THEN
    
        FOR  rec IN (   SELECT  SUM(SALAMT) AS alias1
                        FROM    SLORDD
                        WHERE   ORDERNO = p_orderno
        )
        LOOP
            p_amt := rec.alias1 ;
        END LOOP;
   
    ELSIF ( LOWER(p_gb) = 'salvat' ) THEN
      
        FOR  rec IN (   SELECT  SUM(salvat) AS alias1
                        FROM    SLORDD
                        WHERE   ORDERNO = p_orderno
        )
        LOOP
            p_amt := rec.alias1 ;
        END LOOP;
      
    ELSIF ( LOWER(p_gb) = 'totamt' ) THEN
         
        FOR  rec IN (   SELECT  SUM(totamt) AS alias1
                        FROM    SLORDD
                        WHERE   ORDERNO = p_orderno
        )
        LOOP
            p_amt := rec.alias1 ;
        END LOOP;

   END IF;
   
   RETURN (p_amt);

EXCEPTION WHEN OTHERS THEN RETURN (p_amt);
END;
/
