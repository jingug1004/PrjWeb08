CREATE PROCEDURE        spACacc0192R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0192R
 -- 작 성 자         : 최용석
 -- 작성일자         : 2015-08-14
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-12
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 업체별 수금현황 리스트 쿼리.
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '%' ,
    p_colym         IN VARCHAR2 DEFAULT '' ,
    p_custcode      IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,

    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS

    p_strdate VARCHAR2(10);
    p_enddate VARCHAR2(10);

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    IF ( p_div = 'S' ) THEN

        p_strdate := p_colym || '-01' ;
        p_enddate := TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 1) - 1, 'YYYY-MM-DD');

        OPEN  IO_CURSOR FOR

            SELECT  ROW_NUMBER() OVER ( ORDER BY NVL(a.slipinno, 'z'), a.custcode  ) seqno  ,
                    a.custcode ,
                    MAX(b.custname)  custname  ,
                    SUM(saleamt1)  saleamt1  ,
                    SUM(saleamt2)  saleamt2  ,
                    SUM(saleamt3)  saleamt3  ,
                    SUM(saleamt1 + saleamt2 + saleamt3)  saleamt  ,
                    SUM(accamt1)  accamt1  ,
                    SUM(accamt2)  accamt2  ,
                    SUM(accamt3)  accamt3  ,
                    SUM(accamt1 + accamt2 + accamt3)  accamt  ,
                    SUM(saleamt1 + saleamt2 + saleamt3)  - SUM(accamt1 + accamt2 + accamt3)  diffamt  ,
                    MAX(a.updatedt)  updatedt

            FROM (  SELECT  c.slipinno ,
                            a.custcode ,
                            SUM(CASE WHEN a.coldiv IN ( '01','10','11' ) THEN a.colamt ELSE 0 END)  saleamt1  ,
                            SUM(CASE WHEN a.coldiv IN ( '21' ) THEN a.colamt ELSE 0 END)  saleamt2  ,
                            SUM(CASE WHEN a.coldiv LIKE '3%' THEN a.colamt ELSE 0 END)  saleamt3  ,
                            SUM(CASE WHEN NVL(TRIM(c.slipinno), '') IS NOT NULL AND a.coldiv IN ( '01','10','11' ) THEN a.colamt ELSE 0 END)  accamt1  ,
                            SUM(CASE WHEN NVL(TRIM(c.slipinno), '') IS NOT NULL AND a.coldiv IN ( '21' ) THEN a.colamt ELSE 0 END)  accamt2  ,
                            SUM(CASE WHEN NVL(TRIM(c.slipinno), '') IS NOT NULL AND a.coldiv LIKE '3%' THEN a.colamt ELSE 0 END)  accamt3  ,
                            MAX(TO_CHAR(NVL(c.updatedt, c.insertdt),'YYYY-MM-DD'))  updatedt -- 최종수정일

                    FROM    SLCOLM a
                            LEFT JOIN ACAUTOORDT b   ON b.acattype = 'C' AND a.colno = b.acatno
                            LEFT JOIN ACORDM c   ON b.slipinno = c.slipinno
                    WHERE   a.plantcode LIKE p_plantcode
                            AND a.appdate BETWEEN p_strdate AND p_enddate
                            AND a.statediv = '09'
                            AND a.custcode LIKE p_custcode || '%'
                    GROUP BY c.slipinno,a.custcode ) a

                LEFT JOIN CMCUSTM b   ON a.custcode = b.custcode

            GROUP BY a.slipinno,a.custcode

            HAVING  SUM(saleamt1)  <> 0
                    OR SUM(saleamt2)  <> 0
                    OR SUM(saleamt3)  <> 0
                    OR SUM(accamt1)  <> 0
                    OR SUM(accamt2)  <> 0
                    OR SUM(accamt3)  <> 0

            ORDER BY NVL(a.slipinno, 'z'), a.custcode ;


   END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
