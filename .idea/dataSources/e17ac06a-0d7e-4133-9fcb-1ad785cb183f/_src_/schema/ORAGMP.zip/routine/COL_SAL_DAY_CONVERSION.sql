CREATE PROCEDURE        col_Sal_Day_Conversion
-- ---------------------------------------------------------------
-- 프로시저명        :
-- 작 성 자          :
-- 작성일자          :
-- ---------------------------------------------------------------
-- 프로시저 설명     : 가 오픈 시 사용하는 주문,수금 자료 생성 프로시저이다
--                가상계좌수금 과 전자어음은 별도로 반영되므로 여기서 생성하지 않음
-- ---------------------------------------------------------------
(
   p_ymd                IN    VARCHAR2 DEFAULT ''
)
AS

   p_plantcode                VARCHAR2(30);
   p_coldate                  VARCHAR2(30);
   p_coldiv                   VARCHAR2(30);
   p_coldtldiv                VARCHAR2(30);
   p_orderdiv                 VARCHAR2(30);
   p_tasooyn                  VARCHAR2(30);
   p_custcode                 VARCHAR2(30);
   p_deptcode                 VARCHAR2(30);
   p_empcode                  VARCHAR2(30);
   p_ecustcode                VARCHAR2(30);
   p_edeptcode                VARCHAR2(30);
   p_eempcode                 VARCHAR2(30);
   p_colamt                   FLOAT := 0;
   p_colvat                   FLOAT := 0;
   p_accountno                VARCHAR2(30);
   p_billno                   VARCHAR2(30);
   p_issdate                  VARCHAR2(30);
   p_expdate                  VARCHAR2(30);
   p_paybank                  VARCHAR2(30);
   p_paybankbr                VARCHAR2(30);
   p_issempnm                 VARCHAR2(30);
   p_baeseo                   VARCHAR2(30);
   p_cardcomp                 VARCHAR2(30);
   p_cardno                   VARCHAR2(50);
   p_cardokno                 VARCHAR2(30);
   p_carddate                 VARCHAR2(30);
   p_divmonth                 FLOAT := 0;
   p_autoyn                   VARCHAR2(30);
   p_appdate                  VARCHAR2(30);
   p_discntdate               VARCHAR2(30);
   p_custprtyn                VARCHAR2(30);
   p_remark                   VARCHAR2(30);
   p_apprstatus               VARCHAR2(30);
   p_moneycode                VARCHAR2(30);
   p_exrtrate                 FLOAT := 0;
   p_exrtamt                  FLOAT := 0;
   p_iempcode                 VARCHAR2(30);

   p_bill_gb                  VARCHAR2(10);

   v_spSLSALERESULT_N_param   VARCHAR2(256);
--
--   MESSAGE                 VARCHAR2(32767);
--   IO_CURSOR               TYPES.DataSet;


   CURSOR CARD_SUGUM_READ IS
      SELECT TO_CHAR(A.YMD,'YYYY-MM-DD') AS COLDATE  ,     --입력일자
             A.BILL_NO        AS CARDNO   ,     --카드번호
             A.AMT            AS COLAMT   ,     --수금액
             B.CARD_ACCEPT_NO AS CARDOKNO ,     --거래승인번호
             B.CUST_ID        AS CUSTCODE ,     --거래처코드
             D.INSA_SAWON_ID  AS EMPCODE  ,     --인사사원번호
             E.DEPT_CD        AS DEPTCODE ,     --부서코드
             B.RCUST_ID       AS ECUSTCODE,     --간납거래처코드
             H.INSA_SAWON_ID  AS EEMPCODE ,     --인사사원번호
             I.DEPT_CD        AS EDEPTCODE,     --부서코드
             A.BILL_GB                    ,     --어음구분(수금구분)100-신용카드,101-압인수금,102-수기카드
             B.CARD_USE_PERIOD AS EXPDATE       --재발행용:유효기간            
        FROM SALE.SALE0402@REAL_SALE.HANA.CO.KR          A,
             SALE.SALE0401@REAL_SALE.HANA.CO.KR          B,
             SALE.SALE0007@REAL_SALE.HANA.CO.KR          D,    --사원정보
             HANAHR.HR_HC_EMPBAS_0@REAL_SALE.HANA.CO.KR  E,    --부서정보
             SALE.SALE0003@REAL_SALE.HANA.CO.KR          G,    --거래처정보
             SALE.SALE0007@REAL_SALE.HANA.CO.KR          H,    --사원정보
             HANAHR.HR_HC_EMPBAS_0@REAL_SALE.HANA.CO.KR  I     --부서정보
       WHERE A.YMD = B.YMD
         AND A.JUNPYO_NO = B.JUNPYO_NO
         AND B.SAWON_ID       = D.SAWON_ID
         AND D.INSA_SAWON_ID  = E.EMP_NO
         AND B.RCUST_ID       = G.CUST_ID
         AND G.SAWON_ID       = H.SAWON_ID
         AND H.INSA_SAWON_ID  = I.EMP_NO
         AND TO_CHAR(A.YMD,'YYYYMMDD') = REPLACE(p_ymd,'-','')
         and a.junpyo_no not in (   
                            select distinct a.junpyo_no   
                              from sale.sale0401@REAL_SALE.HANA.CO.KR a ,sale.sale0402@REAL_SALE.HANA.CO.KR b 
                             where a.junpyo_no = b.junpyo_no(+) 
                               and a.junpyo_no like p_ymd||'%'
                               and a.bigo      like '가상%'   --가상
                            union
                            select distinct a.junpyo_no   
                              from sale.sale0401@REAL_SALE.HANA.CO.KR a ,sale.sale0402@REAL_SALE.HANA.CO.KR b 
                             where a.junpyo_no = b.junpyo_no(+) 
                               and a.junpyo_no like p_ymd||'%'
                               and b.bill_gb  in ('010','040') and substr(b.jigeub,3,4) = '0000' -- 전자 어음
                            )
    ORDER BY A.JUNPYO_NO, A.INPUT_SEQ;  

BEGIN
   
   --테스트 서버의 수급 자료 삭제
   DELETE FROM SLCOLM
    WHERE REPLACE(COLDATE,'-','') = REPLACE(p_ymd,'-','');

   -- 가상계좌 전자어음제외 처리 
   OPEN CARD_SUGUM_READ;
   LOOP
      FETCH CARD_SUGUM_READ INTO p_coldate  , p_cardno  , p_colamt   , p_cardokno ,
                                 p_custcode , p_empcode , p_deptcode ,
                                 p_ecustcode, p_eempcode, p_edeptcode, p_bill_gb  ,
                                 p_expdate  ;
      EXIT WHEN CARD_SUGUM_READ%NOTFOUND ;

      p_plantcode  := '1000';
    --p_coldate    := :NEW.수금일자;               --일자형식 - 2017-11-01
      p_coldiv     := '21';
      p_orderdiv   := '4';
      p_tasooyn    := 'N';
    --p_custcode   := :NEW.수금처코드;
    --p_deptcode   := :NEW.수금담당부서코드;
    --p_empcode    := :NEW.수금담당코드;
    --p_ecustcode  := p_custcode;                  --수금처코드
    --p_edeptcode  := p_deptcode;                  --수금담당부서코드
    --p_eempcode   := p_empcode;                   --수금담당코드
    --p_colamt     := :NEW.수금액;
      p_colvat     := 0;
      p_accountno  := '';
      p_billno     := '';
      p_issdate    := '';
      --p_expdate    := '';
      p_paybank    := '';
      p_paybankbr  := '';
      p_issempnm   := '';
      p_baeseo     := '';
      p_cardcomp   := '999';                       --카드사코드 없으면 '999'
    --p_cardno     := :NEW.카드번호;
    --p_cardokno   := :NEW.카드승인번호;
      p_carddate   := '';
      p_divmonth   := 0;
      p_carddate   := p_coldate; --:NEW.수금일자;               --일자형식 - 2017-11-01
      p_autoyn     := CASE p_bill_gb WHEN '100' THEN 'Y' ELSE 'N' END;
      p_carddate   := p_coldate; --:NEW.수금일자:               --일자형식 - 2017-11-01
      p_discntdate := '';
      p_custprtyn  := 'N';
      p_remark     := CASE p_bill_gb WHEN '100' THEN '신용카드' WHEN '101' THEN '압인카드' WHEN '102' THEN '수기카드' ELSE '기타' END;
      p_apprstatus := '00';
      p_exrtrate   := 0;
      p_exrtamt    := 0;
      p_iempcode   := 'card Auto';                      --작업자사번

      v_spSLSALERESULT_N_param := 'N';

      ORAGMP.COL_SAL_spSLcol0099P (p_plantcode   => p_plantcode  
                          ,p_coldate     => p_coldate    
                          ,p_coldiv      => p_coldiv     
                          ,p_coldtldiv   => p_coldtldiv  
                          ,p_orderdiv    => p_orderdiv   
                          ,p_tasooyn     => p_tasooyn    
                          ,p_custcode    => p_custcode   
                          ,p_deptcode    => p_deptcode   
                          ,p_empcode     => p_empcode    
                          ,p_ecustcode   => p_ecustcode  
                          ,p_edeptcode   => p_edeptcode  
                          ,p_eempcode    => p_eempcode   
                          ,p_colamt      => p_colamt     
                          ,p_colvat      => p_colvat     
                          ,p_accountno   => p_accountno  
                          ,p_billno      => p_billno     
                          ,p_issdate     => p_issdate    
                          ,p_expdate     => p_expdate    
                          ,p_paybank     => p_paybank    
                          ,p_paybankbr   => p_paybankbr  
                          ,p_issempnm    => p_issempnm   
                          ,p_baeseo      => p_baeseo     
                          ,p_cardcomp    => p_cardcomp   
                          ,p_cardno      => p_cardno     
                          ,p_cardokno    => p_cardokno   
                          ,p_carddate    => p_carddate
                          ,p_divmonth    => p_divmonth   
                          ,p_autoyn      => p_autoyn     
                          ,p_discntdate  => p_discntdate 
                          ,p_custprtyn   => p_custprtyn
                          ,p_remark      => p_remark     
                          ,p_apprstatus  => p_apprstatus 
                          ,p_moneycode   => p_moneycode  
                          ,p_exrtrate    => p_exrtrate   
                          ,p_exrtamt     => p_exrtamt    
                          ,p_iempcode    => p_iempcode   
--                          ,MESSAGE       => v_spSLSALERESULT_N_param
--                          ,IO_CURSOR     => IO_CURSOR
                          );

   END LOOP;
   CLOSE CARD_SUGUM_READ; 
  
   --주문 명세
   DELETE FROM ORAGMP.SLORDM
    WHERE SUBSTR(ORDERNO,1,8) = REPLACE(p_ymd,'-','');

   --주문 상세
   DELETE FROM ORAGMP.SLORDD
    WHERE SUBSTR(ORDERNO,1,8) = REPLACE(p_ymd,'-','');
    
   DELETE FROM ORAGMP.SLAPPRHDORD
    WHERE SUBSTR(ORDERNO,1,8) = REPLACE(p_ymd,'-','');
    
   DELETE FROM ORAGMP.SLAPPRHORD
    WHERE SUBSTR(ORDERNO,1,8) = REPLACE(p_ymd,'-','');

   INSERT INTO ORAGMP.SLORDM
         (PLANTCODE
         ,ORDERNO
         ,ORDERDATE
         ,ORDERSEQ
         ,SALDIV
         ,DATADIV
         ,ORDERDIV
         ,OUTPUTDIV
         ,TRANSFERDIV
         ,CUSTCODE
         ,DEPTCODE
         ,EMPCODE
         ,ECUSTCODE
         ,EDEPTCODE
         ,EEMPCODE
         ,UTDIV
         ,EUTDIV
         ,BNORDERNO
         ,TAXDATE
         ,TRADEDATE
         ,TAXMANAGEDATE
         ,TRADEMANAGEDATE
         ,FIXDATE
         ,FIXSEQ
         ,CREDITCK
         ,SAGOCK
         ,LOANLMTCK
         ,BALANCELMTCK
         ,NOCOLLMTCK
         ,SECURITYLMTCK
         ,AVGAMTLMTCK
         ,SAMPCK
         ,TURNLMTCK
         ,APPDATE
         ,YYMM
         ,STATEDIV
         ,REMARK
         ,PDA
         ,WAREHOUSE
         ,APPRSTATUS
         ,MONEYCODE
         ,EXRTRATE
         ,INSERTDT
         ,IEMPCODE
         ,UPDATEDT
         ,UEMPCODE
         ,RECHK
         ,SENDDT
         ,SENDEMP
         ,SENDSEQ
         ,SENDYN
         ,SUPPLYDIV
         ,TRANADDR1
         ,TRANADDR2
         ,TRANADDRB1
         ,TRANADDRB2
         ,TRANPOST
         ,TRANPOSTB
         ,EMAILSENDYN
         ,ADDRSEQ
         ,OFFERNO
         ,EXDOCUNO
         ,LCNO
         ,BLNO
         ,ORDERKIND
         ,CLEANDATE
         ,CLEANSEQ
         ,DOMAEOUTGB
         ,THREEAVGCK
         )
   SELECT '1000'                                                                                         --PLANTCODE
         ,A.GUMAE_NO                                                                                     --ORDERNO
         ,TO_CHAR(TO_DATE(SUBSTR(A.GUMAE_NO,1,8),'YYYYMMDD'),'YYYY-MM-DD')                               --ORDERDATE
         ,SUBSTR(A.GUMAE_NO,9.4)                                                                         --ORDERSEQ
         ,'A01'                                                                                          --SALDIV
         ,CASE WHEN A.CUST_ID = A.RCUST_ID THEN '11' ELSE '12' END                                       --DATADIV
         ,CASE WHEN A.CUST_ID = A.RCUST_ID THEN '4'  ELSE '3'  END                                       --ORDERDIV  
         ,'1'                                                                                            --OUTPUTDIV
         ,'1'                                                                                            --TRANSFERDIV
         ,A.CUST_ID                                                                                      --CUSTCODE
         ,C.DEPT_CD                                                                                      --DEPTCODE
         ,B.INSA_SAWON_ID                                                                                --EMPCODE
         ,A.RCUST_ID                                                                                     --ECUSTCODE
         ,NVL(E.DEPT_CD, C.DEPT_CD)                                                                                      --EDEPTCODE
         ,NVL(D.INSA_SAWON_ID, B.INSA_SAWON_ID)                                                                                --EEMPCODE
         ,''                                                                                             --UTDIV
         ,''                                                                                             --EUTDIV
         ,''                                                                                             --BNORDERNO
         ,CASE A.ACCEPT_YN WHEN 'Y' THEN TO_CHAR(A.YMD, 'YYYY-MM-DD')  
          ELSE '' END                                                                                    --TAXDATE
         ,''                                                                                             --TRADEDATE
         ,''                                                                                             --TAXMANAGEDATE
         ,''                                                                                             --TRADEMANAGEDATE
         ,TO_CHAR(TO_DATE(SUBSTR(GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM-DD')                                --FIXDATE
         ,''                                                                                            --FIXSEQ    -- TO_CHAR(TO_DATE(SUBSTR(GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM')
         ,'N'                                                                                            --CREDITCK
         ,'N'                                                                                            --SAGOCK
         ,'N'                                                                                            --LOANLMTCK
         ,'N'                                                                                            --BALANCELMTCK
         ,'N'                                                                                            --NOCOLLMTCK
         ,'N'                                                                                            --SECURITYLMTCK
         ,'N'                                                                                            --AVGAMTLMTCK
         ,'N'                                                                                            --SAMPCK
         ,CASE A.WIBAN_KIND WHEN '1' THEN '*' ELSE 'N' END                                               --TURNLMTCK
         ,CASE A.ACCEPT_YN WHEN 'S' THEN TO_CHAR(TO_DATE(SUBSTR(GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM-DD')
          ELSE '' END                                                                                            --APPDATE   -- TO_CHAR(TO_DATE(SUBSTR(GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM-DD')
         ,CASE A.ACCEPT_YN WHEN 'S' THEN TO_CHAR(TO_DATE(SUBSTR(GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM')
          ELSE '' END                                                                                               --YYMM      -- TO_CHAR(TO_DATE(SUBSTR(GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM')
         ,CASE A.ACCEPT_YN WHEN 'S' THEN '09'
                                    ELSE CASE A.LIMIT_YN WHEN 'Y' THEN '03' ELSE '01' END END            --STATEDIV
         ,A.BIGO                                                                                         --REMARK
         ,''                                                                                             --PDA
         ,'001'                                                                                          --WAREHOUSE
         ,CASE A.RECEIPT_GB WHEN '1' THEN '01' WHEN '2' THEN '03' WHEN '3' THEN '04' ELSE '' END         --APPRSTATUS
         ,''                                                                                             --MONEYCODE
         ,''                                                                                             --EXRTRATE
         ,A.INPUT_YMD                                                                                    --INSERTDT
         ,'cvs'                                                                                          --IEMPCODE
         ,''                                                                                             --UPDATEDT
         ,''                                                                                             --UEMPCODE
         ,''                                                                                             --RECHK
         ,''                                                                                             --SENDDT
         ,''                                                                                             --SENDEMP
         ,''                                                                                             --SENDSEQ
         ,''                                                                                             --SENDYN
         ,''                                                                                             --SUPPLYDIV
         ,''                                                                                             --TRANADDR1
         ,''                                                                                             --TRANADDR2
         ,''                                                                                             --TRANADDRB1
         ,''                                                                                             --TRANADDRB2
         ,''                                                                                             --TRANPOST
         ,''                                                                                             --TRANPOSTB
         ,''                                                                                             --EMAILSENDYN
         ,0                                                                                              --ADDRSEQ
         ,''                                                                                             --OFFERNO
         ,''                                                                                             --EXDOCUNO
         ,''                                                                                             --LCNO
         ,''                                                                                             --BLNO
         ,CASE A.SLIP_GB WHEN '1' THEN '10' WHEN '2' THEN '20' ELSE '30' END                             --ORDERKIND
         ,''                                                                                             --CLEANDATE
         ,0                                                                                              --CLEANSEQ
         ,''                                                                                             --DOMAEOUTGB
         ,CASE A.WIBAN_KIND WHEN '2' THEN '*' ELSE '' END                                                --THREEAVGCK
     FROM SALE_ON.SALE0203@REAL_SALE.HANA.CO.KR       A,
          SALE.SALE0007@REAL_SALE.HANA.CO.KR          B, --영업사원 SAWON_ID INSA_SAWON_ID
          HANAHR.HR_HC_EMPBAS_0@REAL_SALE.HANA.CO.KR  C, --인사사원 EMP_NO, DEPT_CD
          SALE.SALE0007@REAL_SALE.HANA.CO.KR          D,
          HANAHR.HR_HC_EMPBAS_0@REAL_SALE.HANA.CO.KR  E
    WHERE A.SAWON_ID      = B.SAWON_ID
      AND B.INSA_SAWON_ID = C.EMP_NO(+)
      AND A.RSAWON_ID     = D.SAWON_ID(+)
      AND D.INSA_SAWON_ID = E.EMP_NO(+)
      AND A.GUMAE_GB      = '01'
      AND SUBSTR(A.GUMAE_NO,1,8) = REPLACE(p_ymd,'-','')
 ORDER BY A.GUMAE_NO;


   INSERT INTO ORAGMP.SLORDD
         (ORDERNO
         ,PLANTCODE
         ,SEQ
         ,ORDERDATE
         ,ORDERSEQ
         ,ITEMCODE
         ,UNITDIV
         ,SALQTY
         ,GIVQTY
         ,BONUSQTY
         ,DRUGPRC
         ,DRUGAMT
         ,MAKINGCOST
         ,EXRTPRC
         ,EXRTAMT
         ,SALPRC
         ,SALAMT
         ,SALVAT
         ,TOTAMT
         ,BEFAMT
         ,AFTAMT
         ,INCAMT
         ,TOTDISCOUNT
         ,GIVRATE
         ,BEFRATE
         ,AFTRATE
         ,INCRATE
         ,SALPRC1
         ,SALAMT1
         ,SALVAT1
         ,TOTAMT1
         ,CUSTPRTYN
         ,OUTPUTQTY
         ,RECALLDIV
         ,ABSYN
         ,PIECEYN
         ,ENURIYN
         ,JUORDNO
         ,BPQTY
         ,LOTNO
         ,EXPDATE
         ,INSERTDT
         ,IEMPCODE
         ,UPDATEDT
         ,UEMPCODE
         ,AVGQTY
         ,AVGQTYLMTCK
         ,LOTDATE
         ,PIECEQTY
         ,REALOUTQTY
         ,SUPPLYDIV
         ,EMPCODE
         ,ORDQTYBSUNIT
         ,OUTPROTYN
         ,MPLANTCODE
         ,PAIDYN
         ,REQQTY
         )
   SELECT B.GUMAE_NO                                                               --ORDERNO
         ,'1000'                                                                   --PLANTCODE
         ,ROW_NUMBER() OVER(PARTITION BY B.GUMAE_NO ORDER BY B.GUMAE_NO)           --SEQ
         ,TO_CHAR(TO_DATE(SUBSTR(A.GUMAE_NO,1,8),'YYYYMMDD'),'YYYY-MM-DD')         --ORDERDATE
         ,SUBSTR(A.GUMAE_NO,9.4)                                                   --ORDERSEQ
         ,G.NEW_ITEM_ID                                                            --ITEMCODE
         ,''                                                                       --UNITDIV
         ,B.QTY                                                                    --SALQTY
         ,B.DC_QTY                                                                 --GIVQTY
         ,0                                                                        --BONUSQTY
         ,0  --기준가                                                              --DRUGPRC
         ,0  --기준금액                                                            --DRUGAMT
         ,0                                                                        --MAKINGCOST
         ,0                                                                        --EXRTPRC
         ,0                                                                        --EXRTAMT
         ,B.DANGA                                                                  --SALPRC
         ,B.AMT                                                                    --SALAMT
         ,B.VAT                                                                    --SALVAT
         ,B.AMT + B.VAT                                                            --TOTAMT
         ,0                                                                        --BEFAMT
         ,0                                                                        --AFTAMT
         ,0                                                                        --INCAMT
         ,0                                                                        --TOTDISCOUNT
         ,B.DC_DANGA                                                               --GIVRATE
         ,0                                                                        --BEFRATE
         ,0                                                                        --AFTRATE
         ,0                                                                        --INCRATE
         ,0                                                                        --SALPRC1
         ,0                                                                        --SALAMT1
         ,0                                                                        --SALVAT1
         ,0                                                                        --TOTAMT1
         ,'N'                                                                      --CUSTPRTYN
         ,0                                                                        --OUTPUTQTY
         ,''                                                                       --RECALLDIV
         ,'N'                                                                      --ABSYN
         ,'N'                                                                      --PIECEYN
         ,''                                                                       --ENURIYN
         ,''                                                                       --JUORDNO
         ,''                                                                       --BPQTY
         ,''                                                                       --LOTNO
         ,''                                                                       --EXPDATE
         ,A.INPUT_YMD                                                              --INSERTDT
         ,'cvs'                                                                    --IEMPCODE
         ,''                                                                       --UPDATEDT
         ,''                                                                       --UEMPCODE
         ,0                                                                        --AVGQTY
         ,''                                                                       --AVGQTYLMTCK
         ,''                                                                       --LOTDATE
         ,0                                                                        --PIECEQTY
         ,''                                                                       --REALOUTQTY
         ,''                                                                       --SUPPLYDIV
         ,''                                                                       --EMPCODE
         ,0                                                                        --ORDQTYBSUNIT
         ,'N'                                                                      --OUTPROTYN
         ,H.MPLANTCODE                                                              --MPLANTCODE
         ,'N'                                                                      --PAIDYN
         ,B.QTY                                                                    --REQQTY
    FROM SALE_ON.SALE0203@REAL_SALE.HANA.CO.KR A,
         SALE_ON.SALE0204@REAL_SALE.HANA.CO.KR B,
         SALE.SALE0007@REAL_SALE.HANA.CO.KR C,          --영업사원 SAWON_ID INSA_SAWON_ID
         HANAHR.HR_HC_EMPBAS_0@REAL_SALE.HANA.CO.KR D,  --인사사원 EMP_NO, DEPT_CD
         SALE.SALE0007@REAL_SALE.HANA.CO.KR E,
         HANAHR.HR_HC_EMPBAS_0@REAL_SALE.HANA.CO.KR F,
         SALE.SALE0004@REAL_SALE.HANA.CO.KR G,
         ORAGMP.CMITEMM H
   WHERE A.GUMAE_NO      = B.GUMAE_NO
     AND A.SAWON_ID      = C.SAWON_ID
     AND C.INSA_SAWON_ID = D.EMP_NO(+)
     AND A.RSAWON_ID     = E.SAWON_ID
     AND E.INSA_SAWON_ID = F.EMP_NO(+)
     AND B.ITEM_ID       = G.ITEM_ID
     AND G.NEW_ITEM_ID = H.ITEMCODE
     AND A.GUMAE_GB      = '01'
     AND SUBSTR(A.GUMAE_NO,1,8) = REPLACE(p_ymd,'-','')
ORDER BY A.GUMAE_NO, B.INPUT_SEQ;


   MERGE INTO SLORDD A
   USING     (
               SELECT A.ORDERNO
                     ,A.CUSTCODE
                     ,A.ECUSTCODE
                     ,B.ITEMCODE
                     ,B.SEQ
                     ,B.SALQTY
                     ,C.DRUGPRC
                     ,(C.DRUGPRC * B.SALQTY)                                                                   DRUGAMT
                     ,NVL(D.BEFPRC, C.DRUGPRC)                                                                 SALPRC      --발행가          --SALPRC
                     ,(NVL(D.BEFPRC, C.DRUGPRC) * SALQTY)                                                      TOTAMT      --발행가 총금액   --TOTAMT
                     ,(C.DRUGPRC * B.SALQTY) - (NVL(D.BEFPRC, C.DRUGPRC) * SALQTY)                             BEFAMT      --발행가 할인금액 --BEFPRC
                     ,(NVL(D.BEFPRC, C.DRUGPRC) * SALQTY) - (NVL(D.AFTPRC, C.DRUGPRC) * B.SALQTY)              AFTAMT      --약정가 할인금액 --AFTPRC
                     ,NVL(D.BEFRATE, 0)                                                                        BEFRATE     --BEFRATE
                     ,NVL(D.AFTRATE, 0)                                                                        AFTRATE     --AFTRATE
                     ,ROUND((NVL(D.BEFPRC, C.DRUGPRC) * SALQTY) / 1.1)                                         SALAMT
                     ,(NVL(D.BEFPRC, C.DRUGPRC) * SALQTY) - ROUND((NVL(D.BEFPRC, C.DRUGPRC) * SALQTY) / 1.1)   SALVAT
                     ,NVL(D.AFTPRC, C.DRUGPRC)                                                                 SALPRC1      --약정가          --SALPRC1
                     ,(NVL(D.AFTPRC, C.DRUGPRC) * SALQTY)                                                      TOTAMT1      --약정가 총금액   --TOTAMT1
                     ,ROUND((NVL(D.AFTPRC, C.DRUGPRC) * SALQTY) / 1.1)                                         SALAMT1
                     ,(NVL(D.AFTPRC, C.DRUGPRC) * SALQTY) - ROUND((NVL(D.AFTPRC, C.DRUGPRC) * SALQTY) / 1.1)   SALVAT1
                 FROM SLORDM  A
                 JOIN SLORDD  B
                   ON A.ORDERNO = B.ORDERNO
                 JOIN CMITEMM C
                   ON B.ITEMCODE = C.ITEMCODE
            LEFT JOIN (SELECT CUSTCODE, ECUSTCODE, ITEMCODE, MAX(BEFPRC) BEFPRC, MAX(AFTPRC) AFTPRC, MAX(BEFRATE) BEFRATE, MAX(AFTRATE) AFTRATE
                         FROM SLPROMPRCM
                        WHERE EDATE <= '2017-12-04'
                     GROUP BY CUSTCODE, ECUSTCODE, ITEMCODE
                      ) D
                   ON A.CUSTCODE  = D.CUSTCODE
                  AND A.ECUSTCODE = D.ECUSTCODE
                  AND B.ITEMCODE  = D.ITEMCODE
                WHERE SUBSTR(A.ORDERNO,1,8) = REPLACE(p_ymd,'-','')
             ) B
             ON (
                      SUBSTR(A.ORDERNO,1,8) = REPLACE(p_ymd,'-','')
                  AND A.ORDERNO  = B.ORDERNO
                  AND A.ITEMCODE = B.ITEMCODE
                  AND A.SEQ = B.SEQ
                 )
    WHEN MATCHED THEN
    UPDATE SET   A.SALPRC  = NVL(B.SALPRC, A.SALPRC)
    ,            A.TOTAMT  = NVL(B.TOTAMT, A.TOTAMT)
    ,            A.BEFAMT  = NVL(B.BEFAMT, A.BEFAMT)
    ,            A.AFTAMT  = NVL(B.AFTAMT, A.AFTAMT)
    ,            A.BEFRATE = NVL(B.BEFRATE, A.BEFRATE)
    ,            A.AFTRATE = NVL(B.AFTRATE, A.AFTRATE)
    ,            A.SALAMT  = NVL(B.SALAMT, A.SALAMT)
    ,            A.SALVAT  = NVL(B.SALVAT, A.SALVAT)
    ,            A.REQQTY  = A.SALQTY
    ,            A.DRUGPRC = B.DRUGPRC
    ,            A.DRUGAMT = B.DRUGAMT
    ,            A.SALPRC1 = NVL(B.SALPRC1, A.SALPRC)
    ,            A.SALAMT1 = NVL(B.SALAMT1, A.SALAMT)
    ,            A.SALVAT1 = NVL(B.SALVAT1, A.SALVAT)
    ,            A.TOTAMT1 = NVL(B.TOTAMT1, A.TOTAMT)
    ;


    INSERT INTO ORAGMP.SLAPPRHORD
            (PLANTCODE   ,
             ORDERNO     ,
             APPRDIV     ,
             APPRLASTSEQ ,
             APPRWORKSEQ ,
             INSERT_DT   ,
             IEMPCODE    )
         SELECT '1000' ,
                A.GUMAE_NO,
                APPRDIV     ,
                APPRLASTSEQ ,
                APPRWORKSEQ ,
                SYSDATE   ,
                B.INSA_SAWON_ID
           FROM SALE_ON.SALE0203@REAL_SALE.HANA.CO.KR A
                , SALE.SALE0007@REAL_SALE.HANA.CO.KR B --영업사원 SAWON_ID INSA_SAWON_ID
                , SLAPPRM C
          WHERE A.SAWON_ID      = B.SAWON_ID
            AND A.GUMAE_GB      = '01'
            AND SUBSTR(A.GUMAE_NO,1,8) = REPLACE(p_ymd,'-','')
            AND APPRDIV         = '01';

    INSERT INTO ORAGMP.SLAPPRHDORD
          (PLANTCODE ,
           ORDERNO   ,
           APPRSEQ   ,
           APPRCODE  ,
           EDITYN    ,
           EMPCODE   ,
           APPRYN    ,
           INSERT_DT ,
           IEMPCODE  )
         SELECT '1000',
                A.GUMAE_NO   ,
                C.APPRSEQ    ,
                C.APPRCODE   ,
                C.EDITYN     ,
                B.INSA_SAWON_ID  ,
                'N'        ,
                SYSDATE  ,
                B.INSA_SAWON_ID
           FROM SALE_ON.SALE0203@REAL_SALE.HANA.CO.KR A
                , SALE.SALE0007@REAL_SALE.HANA.CO.KR B --영업사원 SAWON_ID INSA_SAWON_ID
                , SLAPPRD C
          WHERE A.SAWON_ID      = B.SAWON_ID
            AND A.GUMAE_GB      = '01'
            AND SUBSTR(A.GUMAE_NO,1,8) = REPLACE(p_ymd,'-','')
            AND C.APPRDIV = '01'
       ORDER BY A.GUMAE_NO;
    
END;
/
