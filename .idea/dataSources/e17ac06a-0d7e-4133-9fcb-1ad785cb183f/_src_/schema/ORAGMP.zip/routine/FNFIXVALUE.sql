CREATE FUNCTION        fnFixValue
(
    p_Gubun             IN VARCHAR2,
    p_Old_Value         IN VARCHAR2,
    p_Value             IN NUMBER
)
RETURN VARCHAR2
AS
    ip_Old_Value        VARCHAR2(700) := p_Old_Value;
    p_New_Value         VARCHAR2(700);
    p_i                 NUMBER(10,0);
    p_LEN               NUMBER(10,0);
    p_R_End_char        CHAR(1);
    p_LEN1              NUMBER(10,0);
    p_R_End_char1       CHAR(1);
    
    ip_Old_Value_LEN    NUMBER(10,0);
BEGIN
    p_i := 1 ;
   
   /*-------------------*/
   /* 문자를 처리하는 경우 */
   /*-------------------*/
    IF p_Gubun = 'X' THEN

        ip_Old_Value := NVL(ip_Old_Value, '') ;
        
        --현재 자료가 원하는 길이보다 길면....
        IF p_Value < LENGTHB(ip_Old_Value) THEN
            
            --현재 자료가 원하는 길이보다 같거나 작을때까지 한글자씩 잘라낸다. 
            p_i := p_Value ;
            WHILE p_Value < LENGTHB(ip_Old_Value) 
            LOOP 
               p_i := p_i - 1 ;
               ip_Old_Value := SUBSTR(ip_Old_Value, 1, p_i) ;
            END LOOP;
            
            --BYTE 길이가 서로 다를때는 1 BYTE가 차이가 나는 경우이다.
            IF LENGTHB(ip_Old_Value) <> p_Value THEN
                p_New_Value := ip_Old_Value || ' ' ;
            ELSE
                p_New_Value := ip_Old_Value ;
            END IF;
            
        --현재 자료가 원하는 길이보다 짧거나 같으면....
        ELSE
            --차이만큼 공백을 붙여준다. 
            IF ip_Old_Value IS NULL THEN
                p_New_Value := LPAD(' ', p_Value, ' ') ;
            ELSE  
                p_New_Value := ip_Old_Value || LPAD(' ', p_Value - LENGTHB(ip_Old_Value), ' ') ;
            END IF;
        END IF;
        
    /*-------------------*/
    /* 문자를 숫자처럼 처리하는 경우 */
    /*-------------------*/
    ELSIF ( p_Gubun = 'X9' ) THEN
        ip_Old_Value := NVL(ip_Old_Value, ' ') ;

        -- p_New_Value  := LPAD (ip_Old_Value, p_Value, ' ' );
        p_New_Value  := SUBSTR(LPAD(' ', p_Value, ' ') || ip_Old_Value, -p_Value) ;
        
    /*-------------------*/
    /* 숫자를 처리하는 경우 */
    /*-------------------*/
    ELSIF ( p_Gubun = '9' ) THEN
        ip_Old_Value := NVL(ip_Old_Value, '0') ;
        
        -- p_New_Value := LPAD (ip_Old_Value, p_Value, '0' );
        p_New_Value := LPAD (ip_Old_Value, p_Value, '0' );
        p_New_Value  := SUBSTR(LPAD('0', p_Value, '0') || ip_Old_Value, -p_Value) ;
    
    ELSIF ( p_Gubun = 'S9' ) THEN
        
        ip_Old_Value := NVL(ip_Old_Value, '0') ;
        
        --앞에 -를 붙인다
        
        IF SUBSTR(ip_Old_Value, 1, 1) = '-' THEN           
            
            ip_Old_Value := SUBSTR( ip_Old_Value, 2, LENGTH(ip_Old_Value)-1 );  
            
            --p_New_Value := LPAD ('-' || SUBSTR (ip_Old_Value,-p_Value+1), p_Value, '0' )  ;            
            p_New_Value := '-' || SUBSTR ( LPAD('0', p_Value, '0') || ip_Old_Value, -p_Value+1) ;
            
        ELSE
            
            --p_New_Value := LPAD (SUBSTR  (ip_Old_Value, -p_Value), p_Value, '0')  ;
            p_New_Value := SUBSTR(LPAD('0', p_Value, '0') || ip_Old_Value , -p_Value); 

        END IF;
        
    ELSIF ( p_Gubun = 'SS9' ) THEN
        
        ip_Old_Value := NVL(ip_Old_Value, '0') ;
        
        --음수인 경우에 multi-key-in 방법으로 표현
        IF SUBSTR(ip_Old_Value, 1, 1) = '-' THEN
            
            p_LEN1 := LENGTH(ip_Old_Value) ;
            
            p_R_End_char1 := CASE SUBSTR(ip_Old_Value, -1, 1)
                                                         WHEN '1' THEN 'J'
                                                         WHEN '2' THEN 'K'
                                                         WHEN '3' THEN 'L'
                                                         WHEN '4' THEN 'M'
                                                         WHEN '5' THEN 'N'
                                                         WHEN '6' THEN 'O'
                                                         WHEN '7' THEN 'P'
                                                         WHEN '8' THEN 'Q'
                                                         WHEN '9' THEN 'R'
                                                         WHEN '0' THEN '}'   
                            END ;
                            
            ip_Old_Value := SUBSTR(ip_Old_Value, 2, p_LEN1 - 2) || p_R_End_char1 ;
            
        END IF;
        
        --p_New_Value := SUBSTR(LPAD('0',p_Value,'0') || ip_Old_Value, -p_Value, p_Value) ;
        p_New_Value := SUBSTR(LPAD('0',p_Value,'0') || ip_Old_Value, -p_Value) ;
        
    END IF;

    RETURN (p_New_Value);

END;
/
