CREATE PROCEDURE        spACacc0194R
-- ---------------------------------------------------------------
-- 프로시저명      : spACacc0194R
-- 작 성 자      : 최용석
-- 작성일자       : 2017-07-14
-- 프로시저 설명    : 채권채무 내역을 조회하는 프로시저이다.
-- ---------------------------------------------------------------
(
	p_div			 IN 	VARCHAR2 DEFAULT '',
	p_compcode		 IN 	VARCHAR2 DEFAULT '',
	p_plantcode 	 IN 	VARCHAR2 DEFAULT '',
	p_datadiv		 IN 	VARCHAR2 DEFAULT '',
	p_costym		 IN 	VARCHAR2 DEFAULT '',
	p_distdiv		 IN 	VARCHAR2 DEFAULT '',
	p_costcode		 IN 	VARCHAR2 DEFAULT '',
	p_processcode	 IN 	VARCHAR2 DEFAULT '',
	p_prrate		 IN 	NUMBER   DEFAULT 0,
	p_iempcode		 IN 	VARCHAR2 DEFAULT '',
	p_userid		 IN 	VARCHAR2 DEFAULT '',
	p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
	p_reasontext	 IN 	VARCHAR2 DEFAULT '',
	MESSAGE 		 OUT    VARCHAR2,
	IO_CURSOR		 OUT    TYPES.DataSet
)
AS
	p_splantcode   VARCHAR2(4);
	p_costsym	   VARCHAR2(7);
	p_calcmathod   VARCHAR2(20);
	p_startym	   VARCHAR2(7);
	p_preym 	   VARCHAR2(7);
	p_startdt	   VARCHAR2(10);
	p_enddt 	   VARCHAR2(10);

    v_temp         NUMBER := 0;
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	p_splantcode := p_plantcode;

	p_costsym := p_costym;

	FOR rec IN (SELECT  CASE WHEN NVL(TRIM(value1), '') IS NOT NULL THEN '%' ELSE p_plantcode END AS alias1
                        , CASE WHEN NVL(TRIM(value3), '') IS NULL THEN p_costym ELSE value3 END AS alias2
				FROM    SYSPARAMETERMANAGE
				WHERE   parametercode = 'calcostplant')
	LOOP
		p_splantcode := rec.alias1 ;
		p_costsym    := rec.alias2 ;
	END LOOP;

	p_calcmathod := '총평균' ;

	FOR rec IN (SELECT value1
				FROM   SYSPARAMETERMANAGE
				WHERE  parametercode = 'calgoods')
	LOOP
		p_calcmathod := rec.value1 ;
	END LOOP;

	p_startym := CASE WHEN p_calcmathod = '월총평균' THEN p_costym ELSE SUBSTR(p_costym, 0, 5) || '01' END ;
	p_preym   := TO_CHAR(ADD_MONTHS(TO_DATE(p_startym || '-01', 'YYYY-MM-DD'), -1), 'YYYY-DD') ;
	p_startdt := CASE WHEN p_calcmathod = '월총평균' THEN p_costym || '-01' ELSE SUBSTR(p_costym, 0, 5) || '01-01' END ;
	p_enddt   := TO_CHAR(ADD_MONTHS(TO_DATE(p_costym || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD') ;



	IF (p_div = 'S') THEN -- 공정명칭 조회

        OPEN IO_CURSOR FOR

            SELECT MAX(CASE WHEN ord = 1  THEN processname ELSE '' END) processname01,
                   MAX(CASE WHEN ord = 2  THEN processname ELSE '' END) processname02,
                   MAX(CASE WHEN ord = 3  THEN processname ELSE '' END) processname03,
                   MAX(CASE WHEN ord = 4  THEN processname ELSE '' END) processname04,
                   MAX(CASE WHEN ord = 5  THEN processname ELSE '' END) processname05,
                   MAX(CASE WHEN ord = 6  THEN processname ELSE '' END) processname06,
                   MAX(CASE WHEN ord = 7  THEN processname ELSE '' END) processname07,
                   MAX(CASE WHEN ord = 8  THEN processname ELSE '' END) processname08,
                   MAX(CASE WHEN ord = 9  THEN processname ELSE '' END) processname09,
                   MAX(CASE WHEN ord = 10 THEN processname ELSE '' END) processname10,
                   MAX(CASE WHEN ord = 11 THEN processname ELSE '' END) processname11,
                   MAX(CASE WHEN ord = 12 THEN processname ELSE '' END) processname12,
                   MAX(CASE WHEN ord = 13 THEN processname ELSE '' END) processname13,
                   MAX(CASE WHEN ord = 14 THEN processname ELSE '' END) processname14,
                   MAX(CASE WHEN ord = 15 THEN processname ELSE '' END) processname15,
                   MAX(CASE WHEN ord = 16 THEN processname ELSE '' END) processname16,
                   MAX(CASE WHEN ord = 17 THEN processname ELSE '' END) processname17,
                   MAX(CASE WHEN ord = 18 THEN processname ELSE '' END) processname18,
                   MAX(CASE WHEN ord = 19 THEN processname ELSE '' END) processname19,
                   MAX(CASE WHEN ord = 20 THEN processname ELSE '' END) processname20,
                   MAX(CASE WHEN ord = 21 THEN processname ELSE '' END) processname21,
                   MAX(CASE WHEN ord = 22 THEN processname ELSE '' END) processname22,
                   MAX(CASE WHEN ord = 23 THEN processname ELSE '' END) processname23,
                   MAX(CASE WHEN ord = 24 THEN processname ELSE '' END) processname24,
                   MAX(CASE WHEN ord = 25 THEN processname ELSE '' END) processname25,
                   MAX(CASE WHEN ord = 26 THEN processname ELSE '' END) processname26,
                   MAX(CASE WHEN ord = 27 THEN processname ELSE '' END) processname27,
                   MAX(CASE WHEN ord = 28 THEN processname ELSE '' END) processname28,
                   MAX(CASE WHEN ord = 29 THEN processname ELSE '' END) processname29,
                   MAX(CASE WHEN ord = 30 THEN processname ELSE '' END) processname30
            FROM   (SELECT	 A.processcode, b.processname, ROW_NUMBER() OVER (ORDER BY A.processcode) ord
                    FROM	 CSDPDIV A LEFT JOIN PDPROCESSM b ON A.processcode = b.processcode
                    WHERE	 A.compcode = p_compcode
                             AND A.plantcode = p_plantcode
                             AND A.datadiv = p_datadiv
                             AND A.costym = p_costym
                    GROUP BY A.processcode, b.processname ) A ;

    ELSIF (p_div = 'S1') THEN -- 배분기준배분율 조회

		OPEN IO_CURSOR FOR

            SELECT	 compcode,
                     plantcode,
                     datadiv,
                     costym,
                     distdiv,
                     MAX(CASE WHEN ord = 1  THEN processcode ELSE '' END) processcode01,
                     MAX(CASE WHEN ord = 2  THEN processcode ELSE '' END) processcode02,
                     MAX(CASE WHEN ord = 3  THEN processcode ELSE '' END) processcode03,
                     MAX(CASE WHEN ord = 4  THEN processcode ELSE '' END) processcode04,
                     MAX(CASE WHEN ord = 5  THEN processcode ELSE '' END) processcode05,
                     MAX(CASE WHEN ord = 6  THEN processcode ELSE '' END) processcode06,
                     MAX(CASE WHEN ord = 7  THEN processcode ELSE '' END) processcode07,
                     MAX(CASE WHEN ord = 8  THEN processcode ELSE '' END) processcode08,
                     MAX(CASE WHEN ord = 9  THEN processcode ELSE '' END) processcode09,
                     MAX(CASE WHEN ord = 10 THEN processcode ELSE '' END) processcode10,
                     MAX(CASE WHEN ord = 11 THEN processcode ELSE '' END) processcode11,
                     MAX(CASE WHEN ord = 12 THEN processcode ELSE '' END) processcode12,
                     MAX(CASE WHEN ord = 13 THEN processcode ELSE '' END) processcode13,
                     MAX(CASE WHEN ord = 14 THEN processcode ELSE '' END) processcode14,
                     MAX(CASE WHEN ord = 15 THEN processcode ELSE '' END) processcode15,
                     MAX(CASE WHEN ord = 16 THEN processcode ELSE '' END) processcode16,
                     MAX(CASE WHEN ord = 17 THEN processcode ELSE '' END) processcode17,
                     MAX(CASE WHEN ord = 18 THEN processcode ELSE '' END) processcode18,
                     MAX(CASE WHEN ord = 19 THEN processcode ELSE '' END) processcode19,
                     MAX(CASE WHEN ord = 20 THEN processcode ELSE '' END) processcode20,
                     MAX(CASE WHEN ord = 21 THEN processcode ELSE '' END) processcode21,
                     MAX(CASE WHEN ord = 22 THEN processcode ELSE '' END) processcode22,
                     MAX(CASE WHEN ord = 23 THEN processcode ELSE '' END) processcode23,
                     MAX(CASE WHEN ord = 24 THEN processcode ELSE '' END) processcode24,
                     MAX(CASE WHEN ord = 25 THEN processcode ELSE '' END) processcode25,
                     MAX(CASE WHEN ord = 26 THEN processcode ELSE '' END) processcode26,
                     MAX(CASE WHEN ord = 27 THEN processcode ELSE '' END) processcode27,
                     MAX(CASE WHEN ord = 28 THEN processcode ELSE '' END) processcode28,
                     MAX(CASE WHEN ord = 29 THEN processcode ELSE '' END) processcode29,
                     MAX(CASE WHEN ord = 30 THEN processcode ELSE '' END) processcode30,
                     MAX(CASE WHEN ord = 1  THEN prrate ELSE 0 END) prrate01,
                     MAX(CASE WHEN ord = 2  THEN prrate ELSE 0 END) prrate02,
                     MAX(CASE WHEN ord = 3  THEN prrate ELSE 0 END) prrate03,
                     MAX(CASE WHEN ord = 4  THEN prrate ELSE 0 END) prrate04,
                     MAX(CASE WHEN ord = 5  THEN prrate ELSE 0 END) prrate05,
                     MAX(CASE WHEN ord = 6  THEN prrate ELSE 0 END) prrate06,
                     MAX(CASE WHEN ord = 7  THEN prrate ELSE 0 END) prrate07,
                     MAX(CASE WHEN ord = 8  THEN prrate ELSE 0 END) prrate08,
                     MAX(CASE WHEN ord = 9  THEN prrate ELSE 0 END) prrate09,
                     MAX(CASE WHEN ord = 10 THEN prrate ELSE 0 END) prrate10,
                     MAX(CASE WHEN ord = 11 THEN prrate ELSE 0 END) prrate11,
                     MAX(CASE WHEN ord = 12 THEN prrate ELSE 0 END) prrate12,
                     MAX(CASE WHEN ord = 13 THEN prrate ELSE 0 END) prrate13,
                     MAX(CASE WHEN ord = 14 THEN prrate ELSE 0 END) prrate14,
                     MAX(CASE WHEN ord = 15 THEN prrate ELSE 0 END) prrate15,
                     MAX(CASE WHEN ord = 16 THEN prrate ELSE 0 END) prrate16,
                     MAX(CASE WHEN ord = 17 THEN prrate ELSE 0 END) prrate17,
                     MAX(CASE WHEN ord = 18 THEN prrate ELSE 0 END) prrate18,
                     MAX(CASE WHEN ord = 19 THEN prrate ELSE 0 END) prrate19,
                     MAX(CASE WHEN ord = 20 THEN prrate ELSE 0 END) prrate20,
                     MAX(CASE WHEN ord = 21 THEN prrate ELSE 0 END) prrate21,
                     MAX(CASE WHEN ord = 22 THEN prrate ELSE 0 END) prrate22,
                     MAX(CASE WHEN ord = 23 THEN prrate ELSE 0 END) prrate23,
                     MAX(CASE WHEN ord = 24 THEN prrate ELSE 0 END) prrate24,
                     MAX(CASE WHEN ord = 25 THEN prrate ELSE 0 END) prrate25,
                     MAX(CASE WHEN ord = 26 THEN prrate ELSE 0 END) prrate26,
                     MAX(CASE WHEN ord = 27 THEN prrate ELSE 0 END) prrate27,
                     MAX(CASE WHEN ord = 28 THEN prrate ELSE 0 END) prrate28,
                     MAX(CASE WHEN ord = 29 THEN prrate ELSE 0 END) prrate29,
                     MAX(CASE WHEN ord = 30 THEN prrate ELSE 0 END) prrate30
            FROM	 (SELECT   compcode,
                               plantcode,
                               datadiv,
                               costym,
                               distdiv,
                               processcode,
                               prrate,
                               ROW_NUMBER() OVER (PARTITION BY distdiv ORDER BY processcode) ord
                      FROM	   CSDPDIV
                      WHERE    compcode = p_compcode
                               AND plantcode = p_plantcode
                               AND datadiv = p_datadiv
                               AND costym = p_costym
                      GROUP BY compcode,
                               plantcode,
                               datadiv,
                               costym,
                               distdiv,
                               processcode,
                               prrate) A
            GROUP BY compcode, plantcode, datadiv, costym, distdiv
            ORDER BY distdiv ;

    ELSIF (p_div = 'S2') THEN -- 원가요소배분율 조회

		OPEN IO_CURSOR FOR

			SELECT	 A.compcode,
					 A.plantcode,
					 A.datadiv,
					 A.costym,
					 A.costcode,
					 MAX(b.costname) costname,
					 MAX(CASE WHEN A.ord = 1  THEN A.processcode ELSE '' END) processcode01,
					 MAX(CASE WHEN A.ord = 2  THEN A.processcode ELSE '' END) processcode02,
					 MAX(CASE WHEN A.ord = 3  THEN A.processcode ELSE '' END) processcode03,
					 MAX(CASE WHEN A.ord = 4  THEN A.processcode ELSE '' END) processcode04,
					 MAX(CASE WHEN A.ord = 5  THEN A.processcode ELSE '' END) processcode05,
					 MAX(CASE WHEN A.ord = 6  THEN A.processcode ELSE '' END) processcode06,
					 MAX(CASE WHEN A.ord = 7  THEN A.processcode ELSE '' END) processcode07,
					 MAX(CASE WHEN A.ord = 8  THEN A.processcode ELSE '' END) processcode08,
					 MAX(CASE WHEN A.ord = 9  THEN A.processcode ELSE '' END) processcode09,
					 MAX(CASE WHEN A.ord = 10 THEN A.processcode ELSE '' END) processcode10,
					 MAX(CASE WHEN A.ord = 11 THEN A.processcode ELSE '' END) processcode11,
					 MAX(CASE WHEN A.ord = 12 THEN A.processcode ELSE '' END) processcode12,
					 MAX(CASE WHEN A.ord = 13 THEN A.processcode ELSE '' END) processcode13,
					 MAX(CASE WHEN A.ord = 14 THEN A.processcode ELSE '' END) processcode14,
					 MAX(CASE WHEN A.ord = 15 THEN A.processcode ELSE '' END) processcode15,
					 MAX(CASE WHEN A.ord = 16 THEN A.processcode ELSE '' END) processcode16,
					 MAX(CASE WHEN A.ord = 17 THEN A.processcode ELSE '' END) processcode17,
					 MAX(CASE WHEN A.ord = 18 THEN A.processcode ELSE '' END) processcode18,
					 MAX(CASE WHEN A.ord = 19 THEN A.processcode ELSE '' END) processcode19,
					 MAX(CASE WHEN A.ord = 20 THEN A.processcode ELSE '' END) processcode20,
					 MAX(CASE WHEN A.ord = 21 THEN A.processcode ELSE '' END) processcode21,
					 MAX(CASE WHEN A.ord = 22 THEN A.processcode ELSE '' END) processcode22,
					 MAX(CASE WHEN A.ord = 23 THEN A.processcode ELSE '' END) processcode23,
					 MAX(CASE WHEN A.ord = 24 THEN A.processcode ELSE '' END) processcode24,
					 MAX(CASE WHEN A.ord = 25 THEN A.processcode ELSE '' END) processcode25,
					 MAX(CASE WHEN A.ord = 26 THEN A.processcode ELSE '' END) processcode26,
					 MAX(CASE WHEN A.ord = 27 THEN A.processcode ELSE '' END) processcode27,
					 MAX(CASE WHEN A.ord = 28 THEN A.processcode ELSE '' END) processcode28,
					 MAX(CASE WHEN A.ord = 29 THEN A.processcode ELSE '' END) processcode29,
					 MAX(CASE WHEN A.ord = 30 THEN A.processcode ELSE '' END) processcode30,
					 MAX(CASE WHEN A.ord = 1  THEN A.prrate ELSE 0 END) prrate01,
					 MAX(CASE WHEN A.ord = 2  THEN A.prrate ELSE 0 END) prrate02,
					 MAX(CASE WHEN A.ord = 3  THEN A.prrate ELSE 0 END) prrate03,
					 MAX(CASE WHEN A.ord = 4  THEN A.prrate ELSE 0 END) prrate04,
					 MAX(CASE WHEN A.ord = 5  THEN A.prrate ELSE 0 END) prrate05,
					 MAX(CASE WHEN A.ord = 6  THEN A.prrate ELSE 0 END) prrate06,
					 MAX(CASE WHEN A.ord = 7  THEN A.prrate ELSE 0 END) prrate07,
					 MAX(CASE WHEN A.ord = 8  THEN A.prrate ELSE 0 END) prrate08,
					 MAX(CASE WHEN A.ord = 9  THEN A.prrate ELSE 0 END) prrate09,
					 MAX(CASE WHEN A.ord = 10 THEN A.prrate ELSE 0 END) prrate10,
					 MAX(CASE WHEN A.ord = 11 THEN A.prrate ELSE 0 END) prrate11,
					 MAX(CASE WHEN A.ord = 12 THEN A.prrate ELSE 0 END) prrate12,
					 MAX(CASE WHEN A.ord = 13 THEN A.prrate ELSE 0 END) prrate13,
					 MAX(CASE WHEN A.ord = 14 THEN A.prrate ELSE 0 END) prrate14,
					 MAX(CASE WHEN A.ord = 15 THEN A.prrate ELSE 0 END) prrate15,
					 MAX(CASE WHEN A.ord = 16 THEN A.prrate ELSE 0 END) prrate16,
					 MAX(CASE WHEN A.ord = 17 THEN A.prrate ELSE 0 END) prrate17,
					 MAX(CASE WHEN A.ord = 18 THEN A.prrate ELSE 0 END) prrate18,
					 MAX(CASE WHEN A.ord = 19 THEN A.prrate ELSE 0 END) prrate19,
					 MAX(CASE WHEN A.ord = 20 THEN A.prrate ELSE 0 END) prrate20,
					 MAX(CASE WHEN A.ord = 21 THEN A.prrate ELSE 0 END) prrate21,
					 MAX(CASE WHEN A.ord = 22 THEN A.prrate ELSE 0 END) prrate22,
					 MAX(CASE WHEN A.ord = 23 THEN A.prrate ELSE 0 END) prrate23,
					 MAX(CASE WHEN A.ord = 24 THEN A.prrate ELSE 0 END) prrate24,
					 MAX(CASE WHEN A.ord = 25 THEN A.prrate ELSE 0 END) prrate25,
					 MAX(CASE WHEN A.ord = 26 THEN A.prrate ELSE 0 END) prrate26,
					 MAX(CASE WHEN A.ord = 27 THEN A.prrate ELSE 0 END) prrate27,
					 MAX(CASE WHEN A.ord = 28 THEN A.prrate ELSE 0 END) prrate28,
					 MAX(CASE WHEN A.ord = 29 THEN A.prrate ELSE 0 END) prrate29,
					 MAX(CASE WHEN A.ord = 30 THEN A.prrate ELSE 0 END) prrate30
			FROM	 (SELECT   compcode,
							   plantcode,
							   datadiv,
							   costym,
							   costcode,
							   processcode,
							   prrate,
							   ROW_NUMBER() OVER (PARTITION BY costcode ORDER BY processcode) ord
					  FROM	   CSCPDIV
					  WHERE    compcode = p_compcode
							   AND plantcode = p_plantcode
							   AND datadiv = p_datadiv
							   AND costym = p_costym
					  GROUP BY compcode,
							   plantcode,
							   datadiv,
							   costym,
							   costcode,
							   processcode,
							   prrate) A
					 LEFT JOIN CSCOSTM b
						 ON A.compcode = b.compcode
							AND A.costcode = b.costcode
			GROUP BY A.compcode, A.plantcode, A.datadiv, A.costym, A.costcode
			ORDER BY costcode ;

    ELSIF (p_div = 'U1') THEN -- 분배기준배분율 수정

		UPDATE  CSDPDIV A
		SET     prrate = p_prrate
                , updatedt = SYSDATE
                , uempcode = p_iempcode
		WHERE  compcode = p_compcode
			   AND plantcode = p_plantcode
			   AND datadiv = p_datadiv
			   AND costym = p_costym
			   AND distdiv = p_distdiv
			   AND processcode = p_processcode ;

	ELSIF (p_div = 'U2') THEN -- 원가요소배분율 수정

		UPDATE  CSCPDIV A
		SET     prrate = p_prrate
                , updatedt = SYSDATE
                , uempcode = p_iempcode
		WHERE  compcode = p_compcode
			   AND plantcode = p_plantcode
			   AND datadiv = p_datadiv
			   AND costym = p_costym
			   AND costcode = p_costcode
			   AND processcode = p_processcode ;

	ELSIF (p_div = 'C1') THEN -- 분배기준배분율 집계

        IF p_costym < p_costsym THEN
            IF (IO_CURSOR IS NULL) THEN
                OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY; 
            END IF;

            RETURN ;
        END IF ;



        -- 제조/판매제품 표준을 생성
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_CSCOST0010P_GPITEMMASTER';

        INSERT INTO VGT.TT_CSCOST0010P_GPITEMMASTER (

            SELECT A.itemcode,
                   NVL(b.revisionno, c.revisionno) revisionno,
                   NVL(c.typicalitemcode, '') mitemcode,
                   NVL(b.itemkorname, c.itemkorname) itemkorname,
                   NVL(b.contentqty, c.packingunitqty) contentqty,
                   NVL(b.itemdiv, c.itemdiv) itemdiv,
                   NVL(b.itemunit, c.packingunit) itemunit,
                   NVL(b.itempart, '01') itempart,
                   NVL(b.BATCHSIZE, 0) BATCHSIZE,
                   NVL(NULLIF(c.typicalpackingcheck, NULL), 'N') standardyn,
                   COALESCE(NULLIF(A.drugprc, 0), c.drugprc, 0) drugprc,
                   0 salprc,
                   0 batchamt,
                   0 manhr
            FROM   CMITEMM A
                   LEFT JOIN PDMAKINGGM b  ON A.itemcode = b.itemcode
                   LEFT JOIN PDPACKINGGM c ON A.itemcode = c.itemcode
            WHERE  NVL(TRIM(A.mitemcode), '') IS NOT NULL              
        ) ;



        -- 판매제품의 제조제품 soprevisionid,batchsize 를 다시검색
        FOR rec IN (
                        SELECT  --update data
                                b.batchsize
                                --compare data
                                , A.mitemcode
                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON NVL(TRIM(A.mitemcode), ' ') = b.itemcode
        )
        LOOP
        
            UPDATE  VGT.TT_CSCOST0010P_GPITEMMASTER A
            SET     A.batchsize = rec.batchsize
            WHERE   A.mitemcode = rec.mitemcode ;
            
        END LOOP ;



        -- 제품의 매출액 및 평균단가 산출
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_CSCOST0010P_SLORDM';

        INSERT INTO VGT.TT_CSCOST0010P_SLORDM
            SELECT  A.itemcode
                    , b.mitemcode
                    , A.salamt
                    , A.salprc
                    , ROW_NUMBER() OVER (PARTITION BY b.mitemcode ORDER BY A.salamt DESC) ord
            FROM    ( SELECT	b.itemcode
                                , SUM(b.salamt) salamt
                                , CASE WHEN SUM(b.salqty) > 0 THEN ( SUM(b.salamt) / SUM(b.salqty) ) ELSE 0 END salprc
                      FROM      SLORDM A
                                JOIN SLORDD b ON A.plantcode = b.plantcode
                                                 AND A.orderno = b.orderno
                      WHERE     A.plantcode LIKE p_splantcode
                                AND A.appdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_costym || '-01', 'YYYY-MM-DD'), -12), 'YYYY-MM') AND p_costym || '-31'
                                AND SUBSTR(A.saldiv, -2, 2) < '50' AND A.saldiv <> 'A09' -- SL10
                                AND A.statediv = '09'
                      GROUP BY b.itemcode
                      HAVING	 SUM(b.salqty) > 0 ) A
                    JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode ;



        -- 판매대표제품이 2개이상인경우 매출액이 큰코드를 대표제품으로
        FOR rec IN (
                        SELECT  --compare data
                                A.itemcode                                
                                , A.mitemcode                                
                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                JOIN    (   SELECT  mitemcode
                                            FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                            WHERE   standardyn = 'Y'
                                            GROUP BY mitemcode
                                            HAVING  MIN(itemcode) <> MAX(itemcode) ) b ON NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(b.mitemcode), ' ')
                                JOIN VGT.TT_CSCOST0010P_SLORDM c ON NVL(TRIM(b.mitemcode), ' ') = NVL(TRIM(c.mitemcode), ' ')
                                                                    AND A.itemcode = c.itemcode
                                                                    AND c.ord <> 1
        )
        LOOP
        
            UPDATE  VGT.TT_CSCOST0010P_GPITEMMASTER A
            SET     A.standardyn = 'N'
            WHERE   A.itemcode = rec.itemcode
                    AND NVL(TRIM(A.mitemcode), ' ')  = NVL(TRIM(rec.mitemcode), ' ') ;
        END LOOP ;



        -- 판매대표제품이 2개이상인경우 큰코드를 대표제품으로
        FOR rec IN (
                        SELECT  --compare data
                                A.itemcode
                                , A.mitemcode
                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                JOIN    (   SELECT  mitemcode
                                                    , MIN(itemcode) AS mincode
                                                    , MAX(itemcode) AS maxcode
                                            FROM    VGT.TT_CSCOST0010P_GPITEMMASTER
                                            WHERE   standardyn = 'Y'
                                            GROUP BY mitemcode
                                            HAVING  MIN(itemcode) <> MAX(itemcode) ) b ON NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(b.mitemcode), ' ')
                                                                                          AND A.itemcode <> b.maxcode

        )
        LOOP

            UPDATE  VGT.TT_CSCOST0010P_GPITEMMASTER A
            SET     A.standardyn = 'N'
            WHERE   A.itemcode = rec.itemcode
                    AND NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(rec.mitemcode), ' ') ;

        END LOOP ;



        -- 판매대표제품을 설정(동일한 제조제품의 최초코드로 설정)
        FOR rec IN (
                        SELECT --compare data
                                A.itemcode                               
                                , A.mitemcode
                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                        JOIN (  SELECT  mitemcode
                                FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                WHERE   NVL(TRIM(mitemcode), '') IS NOT NULL
                                GROUP BY mitemcode
                                HAVING   MAX(standardyn) = 'N') b ON NVL(TRIM(A.mitemcode), ' ') = b.mitemcode
                        JOIN VGT.TT_CSCOST0010P_SLORDM c ON b.mitemcode = NVL(TRIM(c.mitemcode), ' ')
                                                            AND A.itemcode = c.itemcode
                                                            AND c.ord = 1 
                        ORDER BY A.itemcode, A.MITEMCODE                                                           
        )
        LOOP
            
            UPDATE  VGT.TT_CSCOST0010P_GPITEMMASTER A
            SET     A.standardyn = 'Y'
            WHERE   A.itemcode = rec.itemcode
                    AND NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(rec.mitemcode), ' ') ;
                    
        END LOOP ;



		-- 판매대표제품을 설정(동일한 제조제품의 큰코드를 대표제품으로)
        FOR rec IN (
                        SELECT  --compare data
                                A.itemcode
                                , A.mitemcode
                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                JOIN (  SELECT  A.mitemcode
                                                , MAX(A.itemcode) itemcode
                                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                        WHERE   NVL(TRIM(A.mitemcode), '') IS NOT NULL
                                        GROUP BY A.mitemcode
                                        HAVING   MAX(A.standardyn) = 'N') b ON NVL(TRIM(A.mitemcode), ' ') = b.mitemcode
                                                                               AND A.itemcode = b.itemcode
        )
        LOOP
            
            UPDATE  VGT.TT_CSCOST0010P_GPITEMMASTER A
            SET     A.standardyn = 'Y'
            WHERE   A.itemcode  = rec.itemcode
                    AND NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(rec.mitemcode), ' ') ;
                    
        END LOOP ;



        -- 제품 평균단가와 표준공수를 산출
        FOR REC IN (        
                        SELECT  --update data
                                NVL(b.salprc, A.salprc)             AS salprc
                                , NVL(c.manhr, 0) + NVL(D.manhr, 0) AS manhr
                                --compare data
                                , A.itemcode
                                , A.mitemcode
                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                LEFT JOIN VGT.TT_CSCOST0010P_SLORDM b ON A.itemcode = b.itemcode
                                LEFT JOIN ( SELECT  itemcode
                                                    , revisionno
                                                    , NVL(SUM(mannum * manhr), 0) + NVL(SUM(womannum * womanhr), 0) manhr
                                            FROM    PDSOPPROCESSM A
                                            GROUP BY A.itemcode, A.revisionno ) c ON NVL(TRIM(A.mitemcode), ' ') = c.itemcode
                                                                                     AND NVL(TRIM(A.mitemcode), ' ') <> A.itemcode
                                LEFT JOIN ( SELECT  itemcode
                                                    , revisionno
                                                    , NVL(SUM(mannum * manhr), 0) + NVL(SUM(womannum * womanhr), 0) manhr
                                            FROM    PDSOPPROCESSM A
                                            GROUP BY A.itemcode, A.revisionno ) D ON A.itemcode = D.itemcode 
                        ORDER BY A.itemcode , D.revisionno DESC -- 이부분 지우면 안됨. MS SQL 과 정렬 기준이 않맞어 넣었음                                                                   
        )
        LOOP
                
            UPDATE  VGT.TT_CSCOST0010P_GPITEMMASTER A
            SET     A.salprc = rec.salprc
                    , A.manhr = rec.manhr
            WHERE   A.itemcode = rec.itemcode
                    AND NVL(TRIM(A.MITEMCODE), ' ') = NVL(TRIM(rec.mitemcode), ' ') ;
                        
        END LOOP ;



        -- 매출이 없는경우는 대표제품을 환산하여 단가를 산정, 아니면 약가를 산정        
        FOR rec IN (
                        SELECT  --UPDATE DATA
                                case when b.contentqty > 0 then round(b.salprc * a.contentqty / b.contentqty,7) else a.drugprc end AS salprc  -- cys
                                -- COMPARE DATA
                                , A.mitemcode
                                , A.itemcode
                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                LEFT JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.mitemcode = b.mitemcode
                                                                               AND b.standardyn = 'Y'
                                                                               AND b.contentqty > 0
                                                                               AND b.salprc <> 0
                        WHERE   A.salprc <= 0                                
        )
        LOOP

            UPDATE VGT.TT_CSCOST0010P_GPITEMMASTER A
            SET     A.salprc = rec.salprc
            WHERE   NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(rec.mitemcode), ' ')
                    AND A.itemcode = rec.itemcode
                    AND A.salprc <= 0 ;

        END LOOP ;



        -- 이것 저것 아무것도 없는 경우는 판매제품의 평균단가로 산정
        FOR rec IN (
                        SELECT  --update data
                                b.salprc
                                --compare data
                                , A.mitemcode
                                , A.itemcode
                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                JOIN (  SELECT  AVG(salprc) salprc
                                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                        WHERE   NVL(TRIM(A.mitemcode), '') IS NOT NULL
                                                AND A.salprc > 0) b ON 1 = 1
                        WHERE   NVL(TRIM(A.mitemcode), '') IS NOT NULL
                                AND A.salprc <= 0
        )
        LOOP
        
            UPDATE  VGT.TT_CSCOST0010P_GPITEMMASTER A
            SET     A.salprc = rec.salprc
            WHERE   NVL(TRIM(A.mitemcode), ' ')  = NVL(TRIM(rec.mitemcode), ' ')
                    AND A.itemcode = rec.itemcode
                    AND A.salprc <= 0 ;
        END LOOP ;



        -- 판매제품의 batch금액을 설정
        UPDATE VGT.TT_CSCOST0010P_GPITEMMASTER A
        SET    A.batchamt = CASE WHEN contentqty > 0 THEN salprc * BATCHSIZE / contentqty ELSE 0 END
        WHERE  NVL(TRIM(A.mitemcode), '') IS NOT NULL
               AND A.contentqty > 0 ;



        -- 제조제품의 batch금액을 설정(판매제품batch금액 * 제조HR / 영업MH)
        FOR REC IN (
                        SELECT  --update data
                                 CASE WHEN b.manhr > 0 THEN  b.batchamt * A.manhr / b.manhr ELSE 0 END  AS batchamt
                                --compare data                                
                                , A.itemcode
                        FROM    VGT.TT_CSCOST0010P_GPITEMMASTER A
                                JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = NVL(TRIM(b.mitemcode), ' ')
                                                                          AND b.standardyn = 'Y'
                                                                          AND b.manhr > 0
                        WHERE   NVL(TRIM(A.mitemcode), '') IS NULL
        )
        LOOP
        
            UPDATE  VGT.TT_CSCOST0010P_GPITEMMASTER A
            SET     A.batchamt = rec.batchamt
            WHERE   NVL(TRIM(A.mitemcode), '') IS NULL
                    AND A.itemcode = rec.itemcode ;
                    
        END LOOP ;



        -- 포장지시 배분율 생성
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_PDPACKINGORDERS ';

        INSERT INTO VGT.TT_CSCOST0010P_PDPACKINGORDERS (
            SELECT  b.orderno,
                    A.packingorderno,
                    b.itemcode mitemcode,
                    A.batchno lotno,
                    A.itemcode,
                    A.packingqty * c.packingunitqty * NVL(c.salepackingqty, 1) packingqty,
                    100 rate
             FROM	PDPACKINGORDERS A
                    JOIN PDMAKINGORDERSM b ON A.orderno = b.orderno
                    JOIN PDPACKINGGM c ON A.itemcode = c.itemcode
             WHERE	A.plantcode LIKE p_splantcode
                    AND A.packingorderdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_costym || '-01', 'YYYY-MM-DD'), -12*7), 'YYYY-MM-DD') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_costym || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD')
        ) ;



        -- 분할생산된 제품의 비율을 생성
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_PACKINGORDERSDU ';

        INSERT INTO VGT.TT_CSCOST0010P_PACKINGORDERSDU (
            SELECT  orderno
                    , SUM(packingqty) packingqty
            FROM    VGT.TT_CSCOST0010P_PDPACKINGORDERS
            GROUP BY orderno
            HAVING COUNT(*) > 1 AND SUM(packingqty) > 0
        ) ;



        FOR rec IN (
                        SELECT  --update data
                                CASE WHEN b.packingqty <> 0 THEN  A.packingqty * 100 / b.packingqty  ELSE 0 END AS rate
                                --compare data
                                , A.orderno
                                , A.packingorderno
                        FROM    VGT.TT_CSCOST0010P_PDPACKINGORDERS A
                                JOIN VGT.TT_CSCOST0010P_PACKINGORDERSDU b ON A.orderno = b.orderno
        )
        LOOP

            UPDATE  VGT.TT_CSCOST0010P_PDPACKINGORDERS A
            SET     A.rate = rec.rate
            WHERE   A.orderno = rec.orderno 
                    AND A.packingorderno = REC.packingorderno ;

        END LOOP ;



        -- 제품/LotNo/공정별 MH 생성
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_CSRTCLS ';

        INSERT INTO VGT.TT_CSCOST0010P_CSRTCLS
            SELECT	 c.mitemcode,
                     c.itemcode,
                     A.lotno,
                     A.processcode,
                     ROUND(SUM(A.maletimehour + A.femaletimehour) * MAX(c.rate) / 100, 0) manhr,
                     ROW_NUMBER() OVER (PARTITION BY c.mitemcode, A.lotno, A.processcode ORDER BY SUM(A.maletimehour + A.femaletimehour) * MAX(c.rate), c.itemcode) ord
            FROM	 CSRTCLS A
                     JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode
                                                               AND NVL(TRIM(b.mitemcode), '') IS NULL
                     JOIN VGT.TT_CSCOST0010P_PDPACKINGORDERS c ON A.itemcode = c.mitemcode
                                                                  AND A.lotno = c.lotno
                                                                  AND c.rate <> 100
            WHERE	 A.compcode = p_compcode
                     AND A.plantcode = p_plantcode
                     AND A.costym BETWEEN p_startym AND p_costym
            GROUP BY c.mitemcode, c.itemcode, A.lotno, A.processcode ;



        FOR rec IN (
            SELECT  --UPDATE DATA
                    manhr + CASE WHEN b.diffhr < 0 THEN -1 ELSE 1 END AS manhr                    
                    --COMPARE DATA
                    , A.mitemcode
                    , A.itemcode
                    , A.lotno
                    , A.processcode
                    , A.ord
            FROM    VGT.TT_CSCOST0010P_CSRTCLS A
                    JOIN (  SELECT  A.mitemcode
                                    , A.lotno
                                    , A.processcode
                                    , b.manhr - A.manhr diffhr
                            FROM    (   SELECT  mitemcode
                                                , lotno
                                                , processcode
                                                , SUM(manhr) manhr
                                        FROM    VGT.TT_CSCOST0010P_CSRTCLS A
                                        GROUP BY mitemcode, lotno, processcode ) A
                                    JOIN (  SELECT  A.itemcode
                                                    , A.lotno
                                                    , A.processcode
                                                    , SUM(A.maletimehour + A.femaletimehour ) manhr
                                            FROM    CSRTCLS A
                                                    JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode
                                                                                              AND NVL(TRIM(b.mitemcode), '') IS NULL
                                                    JOIN (  SELECT DISTINCT mitemcode
                                                                            , lotno
                                                            FROM    VGT.TT_CSCOST0010P_PDPACKINGORDERS A
                                                            WHERE   A.rate <> 100 ) c ON A.itemcode = c.mitemcode
                                                                                         AND A.lotno = c.lotno
                                            WHERE   A.compcode = p_compcode
                                                    AND A.plantcode = p_plantcode
                                                    AND A.costym BETWEEN p_startym AND p_costym
                                            GROUP BY A.itemcode, A.lotno, A.processcode ) b ON A.mitemcode = b.itemcode
                                                                                               AND A.lotno = b.lotno
                                                                                               AND A.processcode = b.processcode
                                                                                               AND A.manhr <> b.manhr ) b ON NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(b.mitemcode), ' ')
                                                                                                                             AND A.lotno = b.lotno
                                                                                                                             AND A.processcode = b.processcode
                                                                                                                             AND A.ord <= ABS(diffhr)
        )
        LOOP

            UPDATE VGT.TT_CSCOST0010P_CSRTCLS A
            SET     A.manhr = rec.manhr
            WHERE   NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(rec.mitemcode), ' ')
                    AND A.itemcode      = rec.itemcode
                    AND A.lotno         = rec.lotno
                    AND A.processcode   = rec.processcode
                    AND A.ord           = rec.ord ;

        END LOOP ;



        INSERT INTO VGT.TT_CSCOST0010P_CSRTCLS (
            SELECT    A.itemcode,
                      '',
                      A.lotno,
                      A.processcode,
                      SUM(A.maletimehour + A.femaletimehour) manhr,
                      0
             FROM	  CSRTCLS A
                      JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode
                                                                AND NVL(TRIM(b.mitemcode), '') IS NULL
                      LEFT JOIN VGT.TT_CSCOST0010P_PDPACKINGORDERS c ON A.itemcode = NVL(TRIM(c.mitemcode), ' ')
                                                                        AND A.lotno = NVL(TRIM(c.lotno), ' ')
                                                                        AND c.rate = 100
             WHERE	  A.compcode = p_compcode
                      AND A.plantcode = p_plantcode
                      AND A.costym BETWEEN p_startym AND p_costym
                      AND NVL(TRIM(c.mitemcode), '') IS NULL
             GROUP BY A.itemcode, A.lotno, A.processcode
        ) ;



        INSERT INTO VGT.TT_CSCOST0010P_CSRTCLS (
            SELECT    MAX(b.mitemcode),
                      A.itemcode,
                      A.lotno,
                      A.processcode,
                      SUM(A.maletimehour + A.femaletimehour) manhr,
                      0
             FROM	  CSRTCLS A
                      JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode
                                                                  AND NVL(TRIM(b.mitemcode), '') IS NOT NULL                                                                  
             WHERE	  A.compcode = p_compcode
                      AND A.plantcode = p_plantcode
                      AND A.costym BETWEEN p_startym AND p_costym
             GROUP BY A.itemcode, A.lotno, A.processcode
        ) ;



		-- 제품/LotNo별 재공hr 생성
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_CSWGCLS ';

        INSERT INTO VGT.TT_CSCOST0010P_CSWGCLS
            SELECT	 c.mitemcode
                     , c.itemcode
                     , A.lotno
                     , ROUND(SUM(A.maletimehour + A.femaletimehour) * MAX(c.rate) / 100, 0) manhr
                     , ROW_NUMBER() OVER (PARTITION BY c.mitemcode , A.lotno ORDER BY SUM(A.maletimehour + A.femaletimehour) * MAX(c.rate) , c.itemcode) ord
            FROM	 CSWGCLS A
                     JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode
                                                               AND NVL(TRIM(b.mitemcode), '') IS NULL
                     JOIN VGT.TT_CSCOST0010P_PDPACKINGORDERS c ON A.itemcode = NVL(TRIM(c.mitemcode), ' ')
                                                                  AND A.lotno = NVL(TRIM(c.lotno), ' ')
                                                                  AND c.rate <> 100
            WHERE	 A.compcode = p_compcode
                     AND A.plantcode = p_plantcode
                     AND A.costym = p_preym
            GROUP BY c.mitemcode, c.itemcode, A.lotno ;



        FOR rec IN (
                        SELECT  --update data
                                manhr + CASE WHEN b.diffhr < 0 THEN -1 ELSE 1 END AS manhr
                                --compare data
                                , A.mitemcode
                                , A.itemcode
                                , A.lotno
                                , A.ord
                        FROM    VGT.TT_CSCOST0010P_CSWGCLS A
                                JOIN (  SELECT  A.mitemcode
                                                , A.lotno
                                                , b.manhr - A.manhr diffhr
                                        FROM    (   SELECT  A.mitemcode
                                                            , A.lotno
                                                            , SUM(A.manhr) manhr
                                                    FROM    VGT.TT_CSCOST0010P_CSWGCLS A
                                                    GROUP BY mitemcode, lotno ) A
                                                JOIN (  SELECT  A.itemcode
                                                                , A.lotno
                                                                , SUM(A.maletimehour + A.femaletimehour) manhr
                                                        FROM    CSWGCLS A
                                                                JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode
                                                                                                          AND NVL(TRIM(b.mitemcode), '') IS NULL
                                                                JOIN (  SELECT DISTINCT A.mitemcode
                                                                                        , A.lotno
                                                                        FROM    VGT.TT_CSCOST0010P_PDPACKINGORDERS A
                                                                        WHERE   A.rate <> 100 ) c ON A.itemcode = NVL(TRIM(c.mitemcode), ' ')
                                                                                                     AND A.lotno = c.lotno
                                                        WHERE   A.compcode = p_compcode
                                                                AND A.plantcode = p_plantcode
                                                                AND A.costym = p_preym
                                                        GROUP BY A.itemcode, A.lotno ) b ON NVL(TRIM(A.mitemcode), ' ') = b.itemcode
                                                                                            AND A.lotno = b.lotno
                                                                                            AND A.manhr <> b.manhr ) b ON NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(b.mitemcode), ' ')
                                                                                                                          AND A.lotno = b.lotno
                                                                                                                          AND A.ord <= ABS(diffhr)
        )
        LOOP
        
            UPDATE  VGT.TT_CSCOST0010P_CSWGCLS A
            SET     A.manhr = rec.manhr
            WHERE   NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(rec.mitemcode), ' ')
                    AND A.itemcode  = rec.itemcode
                    AND A.lotno     = rec.lotno
                    AND A.ord       = rec.ord ;
                    
        END LOOP ;



        INSERT INTO VGT.TT_CSCOST0010P_CSWGCLS (
            SELECT    A.itemcode
                      , ''
                      , A.lotno
                      , SUM(A.maletimehour + A.femaletimehour) manhr
                      , 0
             FROM	  CSWGCLS A
                      JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode
                                                                AND NVL(TRIM(b.mitemcode), '') IS NULL
                      LEFT JOIN VGT.TT_CSCOST0010P_PDPACKINGORDERS c ON A.itemcode = NVL(TRIM(c.mitemcode), ' ')
                                                                        AND A.lotno = NVL(TRIM(c.lotno), ' ')
                                                                        AND c.rate = 100
             WHERE	  A.compcode = p_compcode
                      AND A.plantcode = p_plantcode
                      AND A.costym = p_preym
                      AND NVL(TRIM(c.mitemcode), '') IS NULL
             GROUP BY A.itemcode, A.lotno
        );
        


        INSERT INTO VGT.TT_CSCOST0010P_CSWGCLS (
            SELECT   MAX(b.mitemcode)
                     , A.itemcode
                     , A.lotno
                     , SUM(A.maletimehour + A.femaletimehour) manhr
                     , 0
             FROM	  CSWGCLS A
                      JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode
                                                                AND NVL(TRIM(b.mitemcode), '') IS NOT NULL
             WHERE	  A.compcode = p_compcode
                      AND A.plantcode = p_plantcode
                      AND A.costym = p_preym
             GROUP BY A.itemcode, A.lotno
        );



		-- 공정/MH별 배부기준 생성
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_CSDPDIV ';

        INSERT INTO VGT.TT_CSCOST0010P_CSDPDIV
            SELECT  ROW_NUMBER() OVER (ORDER BY SUM(manhr) DESC, processcode) ord
                    , processcode
                    , SUM(manhr) manhr
                    , 0 prrate
            FROM	 VGT.TT_CSCOST0010P_CSRTCLS
            GROUP BY processcode ;



        -- 공정별 배부율을 계산
        MERGE INTO   VGT.TT_CSCOST0010P_CSDPDIV TG
        USING   (
                    SELECT  SUM(MANHR) MANHR 
                    FROM    VGT.TT_CSCOST0010P_CSDPDIV
        ) SRC ON ( 1 = 1 )
        WHEN MATCHED THEN
            UPDATE SET TG.prrate = CASE WHEN SRC.MANHR > 0 THEN ROUND( (TG.manhr / SRC.manhr) * 100, 3) ELSE 0 END ;



        -- 배부율 계산 후 차이를 상위 n개에서 보정
        WHILE TRUE LOOP

            SELECT  COUNT(*)
            INTO    v_temp
            FROM    DUAL
            WHERE   EXISTS( SELECT 100000 - SUM(prrate) * 1000 differrate
                            FROM    VGT.TT_CSCOST0010P_CSDPDIV
                            HAVING 100000 - SUM(VGT.TT_CSCOST0010P_CSDPDIV.prrate) * 1000 <> 0 ) ;

            --LOOP EXIT
            EXIT WHEN v_temp <= 0 ;

            FOR REC IN (
                            SELECT  A.prrate + CASE WHEN b.differrate < 0 THEN -0.001 ELSE 0.001 END AS prrate
                                    , A.ord
                            FROM    VGT.TT_CSCOST0010P_CSDPDIV A
                                    JOIN (SELECT 100000 - SUM(prrate) * 1000 differrate
                                          FROM    VGT.TT_CSCOST0010P_CSDPDIV
                                          HAVING 100000 - SUM(prrate) * 1000 <> 0) b ON A.ord <= ABS(b.differrate)
            )
            LOOP
                
                UPDATE  VGT.TT_CSCOST0010P_CSDPDIV A
                SET     A.prrate = rec.prrate
                WHERE   A.ord = rec.ord ;
                
            END LOOP ;

        END LOOP ;

 

        -- 제품/LotNo 판매금액, Lot수, 작업량 생성
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_CSPRCLS ';

        INSERT INTO VGT.TT_CSCOST0010P_CSPRCLS (        
            SELECT  b.mitemcode,
                    c.batchno lotno,
                    A.itemcode,                                                                                   
                    round(case when d.inqty > 0 and b.batchsize > 0
                           then round(round(b.batchamt * (a.inqty / d.inqty),6) * round(e.manufactureqty / b.batchsize,15),6)
                           else 0 end * case when f.prehr > 0 then f.manhr / (f.prehr+f.manhr) when f.manhr = 0 then 0 else 1 end,6) as batchamt,	-- cys
                    CASE WHEN f.prehr > 0 THEN  f.manhr / (f.prehr + f.manhr)
                                WHEN f.manhr = 0 THEN 0 
                                ELSE 1 
                           END lotcnt,
                    ROUND( E.manufactureqty * CASE WHEN f.prehr > 0 THEN f.manhr / (f.prehr + f.manhr) WHEN f.manhr = 0 THEN 0 ELSE 1 END, 6) batchqty
             FROM	CSPRCLS A
                    JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode
                    JOIN PDPACKINGORDERS c ON A.itemcode = c.itemcode
                                              AND A.lotno = c.batchno
                    JOIN (SELECT   c.orderno, SUM(A.inqty * b.contentqty) inqty
                          FROM	   CSPRCLS A
                                   JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = b.itemcode
                                   JOIN PDPACKINGORDERS c ON A.itemcode = c.itemcode
                                                                  AND A.lotno = c.batchno
                          WHERE    A.compcode = p_compcode
                                   AND A.plantcode = p_plantcode
                                   AND A.costym BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_costym || '-01', 'YYYY-MM-DD'), -12*2), 'YYYY-MM') AND p_costym
                          GROUP BY c.orderno) D ON c.orderno = D.orderno
                    JOIN PDMAKINGORDERSM E ON c.orderno = E.orderno
                    LEFT JOIN (SELECT	itemcode, lotno, SUM(prehr) prehr, SUM(manhr) manhr
                               FROM 	(SELECT itemcode
                                                , lotno
                                                , 0 prehr
                                                , manhr
                                         FROM	VGT.TT_CSCOST0010P_CSRTCLS
                                         WHERE	NVL(TRIM(itemcode), '') IS NOT NULL
                                         UNION ALL
                                         SELECT itemcode
                                                , lotno
                                                , manhr
                                                , 0
                                         FROM	VGT.TT_CSCOST0010P_CSWGCLS
                                         WHERE	NVL(TRIM(itemcode), '') IS NOT NULL ) A
                               GROUP BY itemcode, lotno ) f ON A.itemcode = f.itemcode
                                                               AND A.lotno = f.lotno
             WHERE	A.compcode = p_compcode
                    AND A.plantcode = p_plantcode
                    AND A.costym BETWEEN p_startym AND p_costym
                    AND CASE WHEN f.prehr > 0 THEN f.manhr / (f.prehr + f.manhr) WHEN f.manhr = 0 THEN 0 ELSE 1 END > 0                                      
        ) ;
    


        -- 재공/LotNo 판매금액, Lot수, 작업량 생성      
        INSERT INTO VGT.TT_CSCOST0010P_CSPRCLS (
        
            SELECT  NVL(NULLIF(b.mitemcode, NULL), b.itemcode) mitemcode           
                    , NVL(c.lotno, A.lotno) lotno
                    , NVL(c.itemcode, '') itemcode
                    , round(case when d.workqty > 0 and b.batchsize > 0 and b.manhr > 0
                                 then b.batchamt * (a.workqty / d.workqty) * (e.manufactureqty / b.batchsize) * nvl(f.manhr,0)/b.manhr
                                 else 0 end,6) as batchamt
                    , case when b.manhr > 0 then round(nvl(f.manhr,0)/b.manhr,6) else 0 end as lotcnt
                    , round(e.manufactureqty * case when b.manhr > 0 then round(nvl(f.manhr,0)/b.manhr,6) else 0 end,6) as batchqty
             FROM	CSWGCLS A
                    JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = NVL(TRIM(b.itemcode), ' ')
                    LEFT JOIN PDPACKINGORDERS c ON A.itemcode = NVL(TRIM(c.itemcode), ' ')
                                                   AND A.lotno = NVL(TRIM(c.batchno), ' ')
                    JOIN (SELECT   NVL(NULLIF(b.mitemcode, NULL), b.itemcode) mitemcode
                                   , NVL(c.lotno, A.lotno) lotno
                                   , SUM(A.workqty) workqty
                          FROM	   CSWGCLS A
                                   JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON A.itemcode = NVL(TRIM(b.itemcode), ' ')
                                   LEFT JOIN PDPACKINGORDERS c ON A.itemcode = NVL(TRIM(c.itemcode), ' ')
                                                                  AND A.lotno = NVL(TRIM(c.batchno), ' ')
                          WHERE    A.compcode = p_compcode
                                   AND A.plantcode = p_plantcode
                                   AND A.costym = p_costym
                          GROUP BY NVL(NULLIF(b.mitemcode, NULL), b.itemcode), NVL(c.lotno, A.lotno)) D ON NVL(NULLIF(TRIM(b.mitemcode), NULL), b.itemcode) = NVL(TRIM(D.mitemcode), ' ')
                                                                                                           AND NVL(c.lotno, A.lotno) = D.lotno
                    LEFT JOIN PDMAKINGORDERSM E ON NVL(NULLIF(TRIM(b.mitemcode), NULL), b.itemcode) = NVL(TRIM(E.itemcode), ' ')
                                                   AND NVL(c.lotno, A.lotno) = E.lotno
                    LEFT JOIN (SELECT	mitemcode
                                        , '' itemcode
                                        , lotno
                                        , SUM(manhr) manhr
                               FROM 	VGT.TT_CSCOST0010P_CSRTCLS
                               GROUP BY mitemcode, lotno
                               UNION ALL
                               SELECT	mitemcode
                                        , itemcode
                                        , lotno
                                        , SUM(manhr) manhr
                               FROM 	VGT.TT_CSCOST0010P_CSRTCLS
                               WHERE	NVL(TRIM(itemcode), '') IS NOT NULL
                               GROUP BY mitemcode, itemcode, lotno) f ON NVL(NULLIF(TRIM(b.mitemcode), NULL), b.itemcode) = NVL(TRIM(f.mitemcode), ' ')
                                                                         AND NVL(c.itemcode, ' ') = NVL(TRIM(f.itemcode), ' ')
                                                                         AND NVL(c.lotno, A.lotno) = NVL(TRIM(f.lotno), ' ')
             WHERE	A.compcode = p_compcode
                    AND A.plantcode = p_plantcode
                    AND A.costym = p_costym
                    AND CASE WHEN b.manhr > 0 THEN NVL(f.manhr, 0) / b.manhr ELSE 0 END > 0       
        ) ;



        -- 제품/LotNo/공정별 판매금액, Lot수, 작업량 생성: 여기 느림
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_CSPRCLS2 ';

        INSERT INTO VGT.TT_CSCOST0010P_CSPRCLS2 (
            SELECT  b.processcode,
                    NVL(NULLIF(A.itemcode, NULL), A.mitemcode) itemcode,
                    a.lotno,
                    round(a.batchamt * b.manhr / c.manhr, 6) batchamt,
                    round(a.lotcnt   * b.manhr / c.manhr, 6) lotcnt,
                    round(a.batchqty * b.manhr / c.manhr, 6) batchqty
             FROM	VGT.TT_CSCOST0010P_CSPRCLS A
                    JOIN (SELECT   mitemcode, '' itemcode
                                   , lotno, processcode
                                   , SUM(manhr) manhr
                          FROM	   VGT.TT_CSCOST0010P_CSRTCLS
                          GROUP BY mitemcode, lotno, processcode
                          UNION ALL
                          SELECT   mitemcode
                                   , itemcode
                                   , lotno
                                   , processcode
                                   , SUM(manhr) manhr
                          FROM	   VGT.TT_CSCOST0010P_CSRTCLS
                          WHERE    NVL(TRIM(itemcode), '') IS NOT NULL
                          GROUP BY mitemcode, itemcode, lotno, processcode) b ON NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(b.mitemcode), ' ')
                                                                                 AND NVL(TRIM(b.itemcode), ' ') = NVL(TRIM(b.itemcode), ' ')
                                                                                 AND NVL(TRIM(A.lotno), ' ') = NVL(TRIM(b.lotno), ' ')
                    JOIN (SELECT   mitemcode
                                   , '' itemcode
                                   , lotno, SUM(manhr) manhr
                          FROM	   VGT.TT_CSCOST0010P_CSRTCLS
                          GROUP BY mitemcode, lotno
                          UNION ALL
                          SELECT   mitemcode
                                   , itemcode
                                   , lotno, SUM(manhr) manhr
                          FROM	   VGT.TT_CSCOST0010P_CSRTCLS
                          WHERE    NVL(TRIM(itemcode), '') IS NOT NULL
                          GROUP BY mitemcode, itemcode, lotno) c ON NVL(TRIM(A.mitemcode), ' ') = NVL(TRIM(b.mitemcode), ' ')
                                                                    AND NVL(TRIM(b.itemcode), ' ') = NVL(TRIM(b.itemcode), ' ')
                                                                    AND NVL(TRIM(A.lotno), ' ') = NVL(TRIM(b.lotno), ' ')
        ) ;



        -- 공정별 투입금액을 산출
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_CSDPDIV2 ';

        INSERT INTO VGT.TT_CSCOST0010P_CSDPDIV2
            SELECT	 ROW_NUMBER() OVER (ORDER BY SUM(A.batchamt) DESC) ord
                    , A.processcode
                    , ROUND(SUM(A.batchamt), 0) batchamt
                    , 0 prrate
            FROM	 VGT.TT_CSCOST0010P_CSPRCLS2 A
            WHERE	 A.batchamt > 0
            GROUP BY A.processcode ;



        -- 공정별 배부율을 계산
        FOR rec IN (
            
            SELECT    A.ord
                    , A.processcode
                    , A.batchamt
                    , CASE WHEN b.batchamt > 0 THEN ROUND(A.batchamt / b.batchamt * 100, 3) ELSE 0 END prrate
            FROM    VGT.TT_CSCOST0010P_CSDPDIV2 A
                    JOIN (
                        SELECT SUM(BATCHAMT) BATCHAMT
                        FROM   VGT.TT_CSCOST0010P_CSDPDIV2
                    ) B ON 1 = 1 
        )
        LOOP
            UPDATE  VGT.TT_CSCOST0010P_CSDPDIV2 A
            SET     A.prrate = rec.prrate 
            WHERE   A.ord = REC.ord
                    AND A.processcode = REC.processcode
                    AND A.batchamt = REC.batchamt ;
        END LOOP;



        -- 배부율 계산 후 차이를 상위 n개에서 보정
        v_temp := 0;
        WHILE TRUE LOOP

            SELECT  COUNT(*)
            INTO    v_temp
            FROM    DUAL
            WHERE   EXISTS( SELECT 100000 - SUM(prrate) * 1000 differrate
                            FROM    VGT.TT_CSCOST0010P_CSDPDIV2
                            HAVING 100000 - SUM(prrate) * 1000 <> 0 ) ;

            --LOOP EXIT
            EXIT WHEN v_temp = 0 ;

            FOR REC IN (
                            SELECT  A.prrate + CASE WHEN b.differrate < 0 THEN -0.001 ELSE 0.001 END AS prrate
                                    , A.ord
                                    , b.differrate
                            FROM    VGT.TT_CSCOST0010P_CSDPDIV2 A
                                    JOIN (SELECT 100000 - SUM(prrate) * 1000 differrate
                                          FROM    VGT.TT_CSCOST0010P_CSDPDIV2
                                          HAVING 100000 - SUM(prrate) * 1000 <> 0) b ON A.ord <= ABS(b.differrate)
            )
            LOOP
                UPDATE  VGT.TT_CSCOST0010P_CSDPDIV2 A
                SET     A.prrate = rec.prrate
                WHERE   A.ord = rec.ord ;
            END LOOP ;

        END LOOP ;



	    -- 공정별 LOT수를 산출
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_CSDPDIV3 ';

        INSERT INTO VGT.TT_CSCOST0010P_CSDPDIV3
            SELECT  ROW_NUMBER() OVER (ORDER BY SUM(A.lotcnt) DESC) ord
                    , A.processcode
                    , ROUND(SUM(A.lotcnt), 3) lotcnt
                    , 0 prrate
            FROM	 VGT.TT_CSCOST0010P_CSPRCLS2 A
            WHERE	 A.lotcnt > 0
            GROUP BY A.processcode ;



        -- 공정별 배부율을 계산
        FOR REC IN
        (
            SELECT    A.ord
                    , A.processcode
                    , A.lotcnt
                    , CASE WHEN b.lotcnt > 0 THEN ROUND(A.lotcnt / b.lotcnt * 100, 3) ELSE 0 END   prrate
            FROM    VGT.TT_CSCOST0010P_CSDPDIV3 A
                    JOIN (
                        SELECT SUM(lotcnt) lotcnt
                        FROM   VGT.TT_CSCOST0010P_CSDPDIV3
                    ) B ON 1 = 1
        )
        LOOP
            UPDATE  VGT.TT_CSCOST0010P_CSDPDIV3 A
            SET     A.prrate = REC.prrate
            WHERE   A.ORD = REC.ord
                    AND A.PROCESSCODE = REC.processcode 
                    AND A.LOTCNT = REC.lotcnt ;
        END LOOP;   



        -- 배부율 계산 후 차이를 상위 n개에서 보정
        v_temp := 0;
        WHILE TRUE LOOP

            SELECT  COUNT(*)
            INTO    v_temp
            FROM    DUAL
            WHERE   EXISTS( SELECT 100000 - SUM(prrate) * 1000 differrate
                            FROM    VGT.TT_CSCOST0010P_CSDPDIV3
                            HAVING 100000 - SUM(prrate) * 1000 <> 0 ) ;

            --LOOP EXIT
            EXIT WHEN v_temp = 0 ;

            FOR REC IN (
                            SELECT  A.prrate + CASE WHEN b.differrate < 0 THEN -0.001 ELSE 0.001 END AS prrate
                                    , A.ord
                                    , b.differrate
                            FROM    VGT.TT_CSCOST0010P_CSDPDIV3 A
                                    JOIN (SELECT 100000 - SUM(prrate) * 1000 differrate
                                          FROM    VGT.TT_CSCOST0010P_CSDPDIV3
                                          HAVING 100000 - SUM(prrate) * 1000 <> 0) b ON A.ord <= ABS(b.differrate)
            )
            LOOP
                UPDATE  VGT.TT_CSCOST0010P_CSDPDIV3 A
                SET     A.prrate = rec.prrate
                WHERE   A.ord = rec.ord ;
            END LOOP ;

        END LOOP ;



        -- 공정별 작업량을 산출
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_CSDPDIV4 ';

        INSERT INTO VGT.TT_CSCOST0010P_CSDPDIV4
            SELECT	 ROW_NUMBER() OVER (ORDER BY SUM(A.batchqty) DESC) ord
                    , A.processcode
                    , ROUND(SUM(A.batchqty), 0) batchqty
                    , 0 prrate
            FROM	 VGT.TT_CSCOST0010P_CSPRCLS2 A
            WHERE	 A.batchqty > 0
            GROUP BY A.processcode ;



        -- 공정별 배부율을 계산
        FOR REC IN
        (
            SELECT  A.ORD
                    , A.PROCESSCODE
                    , A.BATCHQTY
                    , CASE WHEN b.batchqty > 0 THEN ROUND(A.batchqty / b.batchqty * 100, 3) ELSE 0 END AS PRRATE                    
            FROM    VGT.TT_CSCOST0010P_CSDPDIV4 A
                    JOIN (
                            SELECT  SUM(batchqty) batchqty 
                            FROM    VGT.TT_CSCOST0010P_CSDPDIV4 
                    ) b ON 1 = 1
        )
        LOOP
            UPDATE  VGT.TT_CSCOST0010P_CSDPDIV4 A
            SET     prrate = REC.PRRATE
            WHERE   A.ord = REC.ord
                    AND A.PROCESSCODE = REC.PROCESSCODE
                    AND A.BATCHQTY = REC.BATCHQTY ;                   
        END LOOP;



        -- 배부율 계산 후 차이를 상위 n개에서 보정
        v_temp := 0;
        WHILE TRUE LOOP

            SELECT  COUNT(*)
            INTO    v_temp
            FROM    DUAL
            WHERE   EXISTS( SELECT 100000 - SUM(prrate) * 1000 differrate
                            FROM    VGT.TT_CSCOST0010P_CSDPDIV4
                            HAVING 100000 - SUM(prrate) * 1000 <> 0 ) ;

            --LOOP EXIT
            EXIT WHEN v_temp = 0 ;

            FOR REC IN (
                            SELECT  A.prrate + CASE WHEN b.differrate < 0 THEN -0.001 ELSE 0.001 END AS prrate
                                    , A.ord
                                    , b.differrate
                            FROM    VGT.TT_CSCOST0010P_CSDPDIV4 A
                                    JOIN (SELECT 100000 - SUM(prrate) * 1000 differrate
                                          FROM    VGT.TT_CSCOST0010P_CSDPDIV4
                                          HAVING 100000 - SUM(prrate) * 1000 <> 0) b ON A.ord <= ABS(b.differrate)
            )
            LOOP
                UPDATE  VGT.TT_CSCOST0010P_CSDPDIV4 A
                SET     A.prrate = rec.prrate
                WHERE   A.ord = rec.ord ;
            END LOOP ;

        END LOOP ;



        -- 요소배분기준 요소별 생성
        -- 기존분배기준배분율 삭제
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_CSDPDIV5 ';

        INSERT INTO VGT.TT_CSCOST0010P_CSDPDIV5 (
            SELECT  *
            FROM	CSDPDIV
            WHERE	compcode = p_compcode
                    AND plantcode = p_plantcode
                    AND datadiv = p_datadiv
                    AND costym = p_costym
        ) ;



        DELETE CSDPDIV
        WHERE  compcode = p_compcode
               AND plantcode = p_plantcode
               AND datadiv = p_datadiv
               AND costym = p_costym ;



        -- 공정임시파일 생성
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_PDPROCESSM ';

        INSERT INTO VGT.TT_CSCOST0010P_PDPROCESSM
            SELECT  ROW_NUMBER() OVER (ORDER BY processcode) processseq, processcode
            FROM    PDPROCESSM
            WHERE   plantcode LIKE p_splantcode ;



        -- 분배기준배분율 생성
        INSERT INTO CSDPDIV (
            SELECT  p_compcode,
                    p_plantcode,
                    p_datadiv,
                    p_costym,
                    b.divcode,
                    A.processcode,
                    NVL(c.prrate, 0),
                    NVL(c.manhr, 0),
                    SYSDATE,
                    p_iempcode,
                    NULL,
                    NULL
             FROM	VGT.TT_CSCOST0010P_PDPROCESSM A
                    JOIN CMCOMMONM b ON b.cmmcode = 'CS04'
                                        AND b.filter2 = 'M'
                                        AND b.usediv = 'Y'
                    LEFT JOIN VGT.TT_CSCOST0010P_CSDPDIV c ON NVL(TRIM(A.processcode), ' ')  = NVL(TRIM(c.processcode), ' ')
        );



        INSERT INTO CSDPDIV (
            SELECT p_compcode,
                    p_plantcode,
                    p_datadiv,
                    p_costym,
                    b.divcode,
                    A.processcode,
                    NVL(c.prrate, 0),
                    NVL(c.batchamt, 0),
                    SYSDATE,
                    p_iempcode,
                    NULL,
                    NULL
             FROM	VGT.TT_CSCOST0010P_PDPROCESSM A
                    JOIN CMCOMMONM b ON b.cmmcode = 'CS04'
                                        AND b.filter2 = 'P'
                                        AND b.usediv = 'Y'
                    LEFT JOIN VGT.TT_CSCOST0010P_CSDPDIV2 c ON NVL(TRIM(A.processcode), ' ') = NVL(TRIM(c.processcode), ' ')
        );



        INSERT INTO CSDPDIV (
            SELECT p_compcode,
                    p_plantcode,
                    p_datadiv,
                    p_costym,
                    b.divcode,
                    A.processcode,
                    NVL(c.prrate, 0),
                    NVL(c.lotcnt, 0),
                    SYSDATE,
                    p_iempcode,
                    NULL,
                    NULL
             FROM	VGT.TT_CSCOST0010P_PDPROCESSM A
                    JOIN CMCOMMONM b ON b.cmmcode = 'CS04'
                                        AND b.filter2 = 'L'
                                        AND b.usediv = 'Y'
                    LEFT JOIN VGT.TT_CSCOST0010P_CSDPDIV3 c ON NVL(TRIM(A.processcode), ' ') = NVL(TRIM(c.processcode), ' ')
        ) ;



        INSERT INTO CSDPDIV (
            SELECT p_compcode,
                    p_plantcode,
                    p_datadiv,
                    p_costym,
                    b.divcode,
                    A.processcode,
                    NVL(c.prrate, 0),
                    NVL(c.batchqty, 0),
                    SYSDATE,
                    p_iempcode,
                    NULL,
                    NULL
             FROM	VGT.TT_CSCOST0010P_PDPROCESSM A
                    JOIN CMCOMMONM b ON b.cmmcode = 'CS04'
                                        AND b.filter2 = 'Q'
                                        AND b.usediv = 'Y'
                    LEFT JOIN VGT.TT_CSCOST0010P_CSDPDIV4 c ON A.processcode = c.processcode
        ) ;



        -- 당월백업 복사
        INSERT INTO CSDPDIV (
            SELECT A.compcode,
                    A.plantcode,
                    A.datadiv,
                    A.costym,
                    A.distdiv,
                    A.processcode,
                    A.prrate,
                    A.distbasis,
                    SYSDATE,
                    p_iempcode,
                    NULL,
                    NULL
             FROM	VGT.TT_CSCOST0010P_CSDPDIV5 A
                    JOIN CMCOMMONM b ON b.cmmcode = 'CS04'
                                        AND A.distdiv = b.divcode
                                        AND b.filter2 = 'U'
                                        AND b.usediv = 'Y'
        ) ;



        -- 전월복사 생성
        INSERT INTO CSDPDIV (
            SELECT A.compcode,
                    A.plantcode,
                    A.datadiv,
                    p_costym,
                    A.distdiv,
                    A.processcode,
                    A.prrate,
                    A.distbasis,
                    SYSDATE,
                    p_iempcode,
                    NULL,
                    NULL
             FROM	CSDPDIV A
                    JOIN CMCOMMONM b ON b.cmmcode = 'CS04'
                                        AND A.distdiv = b.divcode
                                        AND b.filter2 = 'U'
                                        AND b.usediv = 'Y'
                    LEFT JOIN CSDPDIV c ON c.compcode = p_compcode
                                           AND c.plantcode = p_plantcode
                                           AND c.datadiv = p_datadiv
                                           AND c.costym = p_costym
             WHERE	A.compcode = p_compcode
                    AND A.plantcode = p_plantcode
                    AND A.datadiv = p_datadiv
                    AND A.costym = p_preym
                    AND c.compcode IS NULL
        ) ;



        -- 신규자료 생성
        INSERT INTO CSDPDIV (
            SELECT p_compcode,
                    p_plantcode,
                    p_datadiv,
                    p_costym,
                    b.divcode,
                    A.processcode,
                    0,
                    0,
                    SYSDATE,
                    p_iempcode,
                    NULL,
                    NULL
             FROM	VGT.TT_CSCOST0010P_PDPROCESSM A
                    JOIN CMCOMMONM b ON b.cmmcode = 'CS04'
                                        AND b.filter2 = 'U'
                                        AND b.usediv = 'Y'
                    LEFT JOIN CSDPDIV c ON c.compcode = p_compcode
                                           AND c.plantcode = p_plantcode
                                           AND c.datadiv = p_datadiv
                                           AND c.costym = p_costym
                                           AND b.divcode = c.distdiv
                                           AND A.processcode = c.processcode
             WHERE	c.compcode IS NULL
        ) ;



        -- 분배기준율내역 생성
        -- 기존 분배기준율내역 삭제
        DELETE CSDPDIVD
        WHERE  compcode = p_compcode
               AND plantcode = p_plantcode
               AND datadiv = p_datadiv
               AND costym = p_costym ;



        -- 분배기준율내역 저장
        INSERT INTO CSDPDIVD (
            SELECT   p_compcode,
                      p_plantcode,
                      p_datadiv,
                      p_costym,
                      A.divcode,
                      b.processcode,
                      b.itemcode,
                      b.lotno,
                      SUM(b.maletimehour + b.femaletimehour)
             FROM	  CMCOMMONM A
                      JOIN CSRTCLS b ON b.compcode = p_compcode
                                        AND b.plantcode = p_plantcode
                                        AND b.costym BETWEEN p_startym AND p_costym
                                        AND b.maletimehour + b.femaletimehour > 0
             WHERE	  A.cmmcode = 'CS04'
                      AND A.filter2 = 'M'
                      AND A.usediv = 'Y'
             GROUP BY A.divcode, b.processcode, b.itemcode, b.lotno
        ) ;



        INSERT INTO CSDPDIVD (
            SELECT   p_compcode,
                      p_plantcode,
                      p_datadiv,
                      p_costym,
                      A.divcode,
                      b.processcode,
                      b.itemcode,
                      b.lotno,
                      SUM(b.batchamt)
             FROM	  CMCOMMONM A 
                      JOIN VGT.TT_CSCOST0010P_CSPRCLS2 b ON b.batchamt > 0
             WHERE	  A.cmmcode = 'CS04'
                      AND A.filter2 = 'P'
                      AND A.usediv = 'Y'
             GROUP BY A.divcode, b.processcode, b.itemcode, b.lotno
        ) ;



        INSERT INTO CSDPDIVD (
            SELECT   p_compcode,
                      p_plantcode,
                      p_datadiv,
                      p_costym,
                      A.divcode,
                      b.processcode,
                      b.itemcode,
                      b.lotno,
                      SUM(b.lotcnt)
             FROM	  CMCOMMONM A 
                      JOIN VGT.TT_CSCOST0010P_CSPRCLS2 b ON b.lotcnt > 0
             WHERE	  A.cmmcode = 'CS04'
                      AND A.filter2 = 'L'
                      AND A.usediv = 'Y'
             GROUP BY A.divcode, b.processcode, b.itemcode, b.lotno
        ) ;



        INSERT INTO CSDPDIVD (
            SELECT   p_compcode,
                      p_plantcode,
                      p_datadiv,
                      p_costym,
                      A.divcode,
                      b.processcode,
                      b.itemcode,
                      b.lotno,
                      SUM(b.batchqty)
             FROM	  CMCOMMONM A 
                      JOIN VGT.TT_CSCOST0010P_CSPRCLS2 b ON b.batchqty > 0
             WHERE	  A.cmmcode = 'CS04'
                      AND A.filter2 = 'Q'
                      AND A.usediv = 'Y'
             GROUP BY A.divcode, b.processcode, b.itemcode, b.lotno
        ) ;



        -- QAMH 분배기준율내역 저장
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_PDMAKINGORDERSM ';

        INSERT INTO VGT.TT_CSCOST0010P_PDMAKINGORDERSM (
            SELECT  *
             FROM	PDMAKINGORDERSM
             WHERE	plantcode LIKE p_splantcode
                    AND orderdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_startdt, 'YYYY-MM-DD'), -12*7), 'YYYY-MM-DD') AND p_enddt
        ) ;



        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_PDTAKINGORM ';

        INSERT INTO VGT.TT_CSCOST0010P_PDTAKINGORM (
            SELECT  *
             FROM	PDTAKINGORM
             WHERE	rowoutdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_startdt, 'YYYY-MM-DD'), -12*7), 'YYYY-MM-DD') AND p_enddt
                    AND rowoutorderstatus = '02'
        ) ;



        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_CSCOST0010P_PDTAKINGORD ';

        INSERT INTO VGT.TT_CSCOST0010P_PDTAKINGORD (
            SELECT  b.*
             FROM	VGT.TT_CSCOST0010P_PDTAKINGORM A
                    JOIN PDTAKINGORD b ON A.rowoutorderno = b.rowoutorderno
        );



        INSERT INTO CSDPDIVD (
            SELECT  p_compcode,
                    p_plantcode,
                    p_datadiv,
                    p_costym,
                    'Z',
                    A.processcode,
                    A.itemcode,
                    A.lotno,
                    SUM(A.testtime) testtime
            FROM    (   SELECT  E.processcode
                                , b.itemcode
                                , b.lotno
                                , D.testtime
                        FROM    VGT.TT_CSCOST0010P_PDTAKINGORM A
                                JOIN VGT.TT_CSCOST0010P_PDMAKINGORDERSM b ON A.orderno = b.orderno
                                JOIN VGT.TT_CSCOST0010P_PDTAKINGORD c ON A.rowoutorderno = c.rowoutorderno
                                JOIN CMITEMM D ON c.itemcode = D.itemcode
                                                  AND D.testtime > 0
                                JOIN (  SELECT  A.itemcode,
                                                b.processcode
                                        FROM   (    SELECT  A.itemcode
                                                            , A.revisionno
                                                            , MIN(b.processseq) processseq
                                                    FROM	 PDMAKINGGM A
                                                            JOIN PDSOPPROCESSM b ON A.itemcode = b.itemcode
                                                                                    AND A.revisionno = b.revisionno
                                                    GROUP BY A.itemcode, A.revisionno ) A
                                                JOIN PDSOPPROCESSM b ON A.itemcode = b.itemcode
                                                                        AND A.revisionno = b.revisionno
                                                                        AND A.processseq = b.processseq ) E ON A.itemcode = E.itemcode
                                        WHERE   A.rowoutdate BETWEEN p_startdt AND p_enddt
                                                AND A.rowoutorderdiv IN ('01', '02' ) -- 불출구분(MPM34)
                                                AND A.rowoutorderstatus = '02'
                                                AND b.plantcode LIKE p_splantcode -- 불출완료(MPM37)
                                        UNION
                                        SELECT  A.processcode
                                                , A.itemcode
                                                , A.lotno
                                                , c.womanhr
                                        FROM    PDWORKFLOWM A
                                                JOIN PDMAKINGGM b ON A.itemcode = b.itemcode
                                                JOIN PDSOPPROCESSM c ON A.itemcode = c.itemcode
                                                                        AND b.revisionno = c.revisionno
                                                                        AND A.processseq = c.processseq
                                                                        AND c.womanhr > 0
                                        WHERE   A.giverdt BETWEEN TO_DATE(p_startdt,'YYYY-MM-DD') AND TO_DATE(p_enddt || '23:59:59', 'YYYY-MM-DD HH24:MI:SS')
                                                AND A.plantcode LIKE p_splantcode
                                        UNION
                                        SELECT  c.processcode
                                                , A.itemcode
                                                , D.lotno
                                                , c.womanhr * D.rate / 100
                                        FROM    PDPACKINGRM A
                                                JOIN VGT.TT_CSCOST0010P_GPITEMMASTER b ON NVL(TRIM(A.itemcode), ' ') = NVL(TRIM(b.itemcode), ' ')
                                                JOIN PDSOPPROCESSM c ON A.itemcode = c.itemcode
                                                                        AND b.revisionno = c.revisionno
                                                                        AND c.womanhr > 0
                                                JOIN VGT.TT_CSCOST0010P_PDPACKINGORDERS D ON A.packingorderno = D.packingorderno
                                        WHERE   A.plantcode LIKE p_splantcode
                                                AND A.workdt BETWEEN TO_DATE(p_startdt,'YYYY-MM-DD') AND TO_DATE(p_enddt || '23:59:59', 'YYYY-MM-DD HH24:MI:SS') ) A
                                        GROUP BY A.processcode, A.itemcode, A.lotno
        );

    ELSIF ( p_div = 'C2' ) THEN -- 원가요소배분율 집계

        IF p_costym < p_costsym THEN

            IF (IO_CURSOR IS NULL) THEN
                OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
            END IF;

            RETURN;
        END IF;



        DELETE  CSCPDIV
        WHERE	compcode = p_compcode
                AND plantcode = p_plantcode
                AND datadiv = p_datadiv
                AND costym = p_costym ;



        INSERT INTO CSCPDIV (
            SELECT  A.compcode ,
                    A.plantcode ,
                    A.datadiv ,
                    A.costym ,
                    b.costcode ,
                    A.processcode ,
                    A.prrate ,
                    A.distbasis ,
                    SYSDATE ,
                    p_iempcode ,
                    NULL ,
                    NULL
            FROM    CSDPDIV A
                    JOIN CSCOSTM b ON A.compcode = b.compcode
            WHERE	A.compcode = p_compcode
                    AND A.plantcode = p_plantcode
                    AND A.datadiv = p_datadiv
                    AND A.costym = p_costym
                    AND A.distdiv = b.distdiv
        ) ;

   END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
    
END;
/
