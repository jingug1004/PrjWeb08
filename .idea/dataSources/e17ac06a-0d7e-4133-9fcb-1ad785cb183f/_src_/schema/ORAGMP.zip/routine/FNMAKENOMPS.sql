CREATE FUNCTION        fnMakeNoMPS(
    -- ---------------------------------------------------------------
    -- 함 수 명   : fnMakeNo
    -- 작 성 자         : 최인범
    -- 작성일자         : 2007-10-25
    -- 수정자         : 노영래
    -- 주석 TABLE 부재(주석 부분 바로 사용 불가, 수정 후 사용 가능)
    -- ---------------------------------------------------------------
    -- 함수설명   : 전표번호 생성
    -- ---------------------------------------------------------------

    p_div IN VARCHAR2 DEFAULT '', p_makedate IN VARCHAR2 DEFAULT ''
)
	RETURN VARCHAR2
AS
	p_tostring	 VARCHAR2(20);
BEGIN
	-- IF (p_div = 'ComplainRecall')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(makeno, 0, 5) || SUBSTR('00' || TO_CHAR(SUBSTR(makeno, -2, 2) + 1), -2, 2), SUBSTR(REPLACE(p_makedate, '-', ''), 3, 4) || '-01') AS alias1
	--     FROM   (SELECT MAX(recallno) makeno
	--       FROM   ComplainRecall
	--       WHERE  SUBSTR(recallno, 1, 4) = SUBSTR(REPLACE(p_makedate, '-', ''), 3, 4)) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	-- ELS
	IF (UPPER(p_div) = 'SLINORDERM')
	THEN
		FOR rec IN (SELECT DECODE(inputno, NULL, REPLACE(p_makedate, '-', '') || '001', SUBSTR(inputno, 0, 8) || SUBSTR('000' || TO_CHAR(SUBSTR(inputno, 9, 3) + 1), -3, 3)) AS alias1
					  FROM (SELECT MAX(inputno) inputno
							  FROM SLINORDERM
							 WHERE SUBSTR(inputdate, 1, 10) = p_makedate
								   AND inputdiv = '1R') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	-- ELSIF (UPPER(p_div) = 'OOSMANAGE')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(oosmanageid, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(oosmanageid, -4, 4) + 1), -4, 4), 'O' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(oosmanageid) oosmanageid
	--       FROM   OosManage
	--       WHERE  SUBSTR(oosmanageid, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	-- ELSIF (UPPER(p_div) = 'VALIDATIONPLANMANAGE')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(vpno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(vpno, -4, 4) + 1), -4, 4), 'V' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(vpno) vpno
	--       FROM   ValidationPlanManage
	--       WHERE  SUBSTR(vpno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	-- ELSIF (UPPER(p_div) = 'CULTUREITEM')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(culturemanageno, 0, 7) || SUBSTR('00' || TO_CHAR(SUBSTR(culturemanageno, -2, 2) + 1), -2, 2), 'C' || SUBSTR(REPLACE(p_makedate, '-', ''), 0, 6) || '01') AS alias1
	--     FROM   (SELECT MAX(culturemanageno) culturemanageno
	--       FROM   CultureItem
	--       WHERE  SUBSTR(culturemanageno, 2, 6) = SUBSTR(REPLACE(p_makedate, '-', ''), 0, 6)) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	-- ELSIF (UPPER(p_div) = 'COMPLAINMAIN')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(complainno, 0, 5) || SUBSTR('00' || TO_CHAR(SUBSTR(complainno, -2, 2) + 1), -2, 2), SUBSTR(REPLACE(p_makedate, '-', ''), 3, 4) || '-01') AS alias1
	--     FROM   (SELECT MAX(complainno) complainno
	--       FROM   ComplainMain
	--       WHERE  SUBSTR(complainno, 1, 4) = SUBSTR(REPLACE(p_makedate, '-', ''), 3, 4)) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	-- ELSIF (UPPER(p_div) = 'REVISEORDER')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(reviseno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(reviseno, -4, 4) + 1), -4, 4), 'R' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(reviseno) reviseno
	--       FROM   ReviseOrder
	--       WHERE  SUBSTR(reviseno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	-- ELSIF (UPPER(p_div) = 'REVISEAPPRAISAL')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(appraisalno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(appraisalno, -4, 4) + 1), -4, 4), 'A' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(appraisalno) appraisalno
	--       FROM   ReviseAppraisal
	--       WHERE  SUBSTR(appraisalno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	-- ELSIF (UPPER(p_div) = 'SPAREPARTDETAIL')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(sparepartdetailno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(sparepartdetailno, -4, 4) + 1), -4, 4), 'E' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(sparepartdetailno) sparepartdetailno
	--       FROM   SparepartDetail
	--       WHERE  SUBSTR(sparepartdetailno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	ELSIF (UPPER(p_div) = 'REQUEST')
	THEN
		FOR rec IN (SELECT DECODE(requestno, NULL, 'R' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(requestno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(requestno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(requestno) requestno
							  FROM Request
							 WHERE SUBSTR(requestno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'REQUESTRM')
	THEN
		FOR rec IN (SELECT DECODE(requestno, NULL, 'R' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(requestno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(requestno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(requestno) requestno
							  FROM Request
							 WHERE SUBSTR(requestno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'REQUESTCP')
	THEN
		FOR rec IN (SELECT DECODE(requestno, NULL, 'R' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(requestno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(requestno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(requestno) requestno
							  FROM Request
							 WHERE SUBSTR(requestno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'REQUESTOS')
	THEN
		FOR rec IN (SELECT DECODE(requestno, NULL, 'R' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(requestno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(requestno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(requestno) requestno
							  FROM Request
							 WHERE SUBSTR(requestno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'PURCHASEORDERRM')
	THEN
		FOR rec IN (SELECT DECODE(orderno, NULL, 'O' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(orderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(orderno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(orderno) orderno
							  FROM PurchaseOrder
							 WHERE SUBSTR(orderno, 2, 8) = REPLACE(p_makedate, '-', '')
								   AND SUBSTR(orderno, 0, 1) = 'O') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'PURCHASEORDER')
	THEN
		FOR rec IN (SELECT DECODE(orderno, NULL, 'O' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(orderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(orderno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(orderno) orderno
							  FROM PurchaseOrder
							 WHERE SUBSTR(orderno, 2, 8) = REPLACE(p_makedate, '-', '')
								   AND SUBSTR(orderno, 0, 1) = 'O') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'PURCHASEORDEROS')
	THEN
		FOR rec IN (SELECT DECODE(orderno, NULL, 'S' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(orderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(orderno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(orderno) orderno
							  FROM PurchaseOrder
							 WHERE SUBSTR(orderno, 2, 8) = REPLACE(p_makedate, '-', '')
								   AND SUBSTR(orderno, 0, 1) = 'S') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'WAREHOUSING')
	THEN
		FOR rec
			IN (SELECT DECODE(warehousingno, NULL, 'W' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(warehousingno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(warehousingno, -4, 4) + 1), -4, 4))
						   AS alias1
				  FROM (SELECT MAX(warehousingno) warehousingno
						  FROM Warehousing
						 WHERE SUBSTR(warehousingno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'MAKINGORDERS')
	THEN
		FOR rec IN (SELECT DECODE(orderno, NULL, 'M' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(orderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(orderno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(orderno) orderno
							  FROM MakingOrders
							 WHERE SUBSTR(orderno, 2, 8) = REPLACE(p_makedate, '-', '')
								   AND SUBSTR(orderno, 0, 1) = 'M') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'TAKINGOUTROW')
	THEN
		FOR rec
			IN (SELECT DECODE(rowoutorderno, NULL, 'R' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(rowoutorderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(rowoutorderno, -4, 4) + 1), -4, 4))
						   AS alias1
				  FROM (SELECT MAX(rowoutorderno) rowoutorderno
						  FROM TakingOutRow
						 WHERE SUBSTR(rowoutorderno, 2, 8) = REPLACE(p_makedate, '-', '')
							   AND SUBSTR(rowoutorderno, 0, 1) = 'R') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'MATERIALETCINOUT')
	THEN
		FOR rec
			IN (SELECT DECODE(etcinoutno, NULL, 'E' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(etcinoutno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(etcinoutno, -4, 4) + 1), -4, 4)) AS alias1
				  FROM (SELECT MAX(etcinoutno) etcinoutno
						  FROM MaterialEtcInOut
						 WHERE SUBSTR(etcinoutno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'PACKINGORDERS')
	THEN
		FOR rec
			IN (SELECT DECODE(packingorderno, NULL, 'P' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(packingorderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(packingorderno, -4, 4) + 1), -4, 4))
						   AS alias1
				  FROM (SELECT MAX(packingorderno) packingorderno
						  FROM PackingOrders
						 WHERE SUBSTR(packingorderno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'TAKINGOUTMATERIAL')
	THEN
		FOR rec
			IN (SELECT DECODE(
						   materialoutorderno
						  ,NULL, 'M' || REPLACE(p_makedate, '-', '') || '0001'
						  ,SUBSTR(materialoutorderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(materialoutorderno, -4, 4) + 1), -4, 4)
					   )
						   AS alias1
				  FROM (SELECT MAX(materialoutorderno) materialoutorderno
						  FROM TakingOutMaterial
						 WHERE SUBSTR(materialoutorderno, 2, 8) = REPLACE(p_makedate, '-', '')
							   AND SUBSTR(materialoutorderno, 0, 1) = 'M') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	-- ELSIF (UPPER(p_div) = 'IMPORTSHEET')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(importshtno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(importshtno, -4, 4) + 1), -4, 4), 'T' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(importshtno) importshtno
	--       FROM   importsheet
	--       WHERE  SUBSTR(importshtno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	-- ELSIF (UPPER(p_div) = 'SHIPPINGMANAGE')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(shippingno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(shippingno, -4, 4) + 1), -4, 4), 'S' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(shippingno) shippingno
	--       FROM   importshippingmanage
	--       WHERE  SUBSTR(shippingno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	-- ELSIF (UPPER(p_div) = 'ENTRYEXPECT')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(entryexpectno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(entryexpectno, -4, 4) + 1), -4, 4), 'E' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(entryexpectno) entryexpectno
	--       FROM   importshippingmanage
	--       WHERE  SUBSTR(entryexpectno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	ELSIF (UPPER(p_div) = 'RETURNINGREGISTRATION')
	THEN
		FOR rec
			IN (SELECT DECODE(saleorderno, NULL, 'G' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(saleorderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(saleorderno, -4, 4) + 1), -4, 4))
						   AS alias1
				  FROM (SELECT MAX(saleorderno) saleorderno
						  FROM ReturningSheet
						 WHERE SUBSTR(saleorderno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'RETURNINGCLASSIFY')
	THEN
		FOR rec
			IN (SELECT DECODE(classifyno, NULL, 'C' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(classifyno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(classifyno, -4, 4) + 1), -4, 4)) AS alias1
				  FROM (SELECT MAX(classifyno) classifyno
						  FROM ReturningClassify
						 WHERE SUBSTR(classifyno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'RETURNINGCLASSIFY2')
	THEN
		FOR rec
			IN (SELECT DECODE(classifyno, NULL, 'C' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(classifyno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(classifyno, -4, 4) + 1), -4, 4)) AS alias1
				  FROM (SELECT MAX(classifyno) classifyno
						  FROM ReturningClassify2
						 WHERE SUBSTR(classifyno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'RETURNINGDISCARD')
	THEN
		FOR rec IN (SELECT DECODE(discardno, NULL, 'D' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(discardno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(discardno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(discardno) discardno
							  FROM ReturningDiscard
							 WHERE SUBSTR(discardno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'RETURNINGREPACKORDER')
	THEN
		FOR rec
			IN (SELECT DECODE(repackorderno, NULL, 'R' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(repackorderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(repackorderno, -4, 4) + 1), -4, 4))
						   AS alias1
				  FROM (SELECT MAX(A.repackorderno) repackorderno
						  FROM (SELECT repackorderno FROM ReturningRepackOrder
								UNION
								SELECT orderno repackorderno
								  FROM MakingOrders
								 WHERE SUBSTR(orderno, 0, 1) = 'R') A
						 WHERE SUBSTR(A.repackorderno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'RETURNINGOUTPUT')
	THEN
		FOR rec
			IN (SELECT DECODE(
						   returningoutputno
						  ,NULL, 'O' || REPLACE(p_makedate, '-', '') || '0001'
						  ,SUBSTR(returningoutputno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(returningoutputno, -4, 4) + 1), -4, 4)
					   )
						   AS alias1
				  FROM (SELECT MAX(returningoutputno) returningoutputno
						  FROM ReturningOutput
						 WHERE SUBSTR(returningoutputno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'CUSTOMERCODE')
	THEN
		--거래처코드 자동생성
		FOR rec IN (SELECT DECODE(custcode, NULL, '00001', SUBSTR('00000' || TO_CHAR(SUBSTR(custcode, -5, 5) + 1), -5, 5)) AS alias1
					  FROM (SELECT MAX(custcode) custcode
							  FROM CustomerMaster
							 WHERE isnumeric(custcode) = 1
								   AND LENGTH(custcode) = 5) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	-- ELSIF (UPPER(p_div) = 'weighingtime')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(weighingtimeid, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(weighingtimeid, -4, 4) + 1), -4, 4), 'P' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(weighingtimeid) weighingtimeid
	--       FROM   weighingtime
	--       WHERE  SUBSTR(weighingtimeid, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	-- ELSIF (UPPER(p_div) = 'WeighingInterim')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(interferimid, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(interferimid, -4, 4) + 1), -4, 4), 'I' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(interferimid) interferimid
	--       FROM   WeighingInterim
	--       WHERE  SUBSTR(interferimid, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	ELSIF (UPPER(p_div) = 'EQUIPMENTFAULT')
	THEN
		FOR rec IN (SELECT DECODE(faultno, NULL, 'F' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(faultno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(faultno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(faultno) faultno
							  FROM EquipmentFault
							 WHERE SUBSTR(faultno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'WAREHOUSINGRM')
	THEN
		FOR rec
			IN (SELECT DECODE(warehousingno, NULL, 'W' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(warehousingno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(warehousingno, -4, 4) + 1), -4, 4))
						   AS alias1
				  FROM (SELECT MAX(warehousingno) warehousingno
						  FROM Warehousing
						 WHERE SUBSTR(warehousingno, 2, 8) = REPLACE(p_makedate, '-', '')
							   AND SUBSTR(warehousingno, 0, 1) = 'W'
							   AND warehousingdiv = '01') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'WAREHOUSINGOS')
	THEN
		FOR rec
			IN (SELECT DECODE(warehousingno, NULL, 'U' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(warehousingno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(warehousingno, -4, 4) + 1), -4, 4))
						   AS alias1
				  FROM (SELECT MAX(warehousingno) warehousingno
						  FROM Warehousing
						 WHERE SUBSTR(warehousingno, 2, 8) = REPLACE(p_makedate, '-', '')
							   AND SUBSTR(warehousingno, 0, 1) = 'U'
							   AND warehousingdiv = '03') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'WAREHOUSINGCP')
	THEN
		FOR rec
			IN (SELECT DECODE(warehousingno, NULL, 'C' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(warehousingno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(warehousingno, -4, 4) + 1), -4, 4))
						   AS alias1
				  FROM (SELECT MAX(warehousingno) warehousingno
						  FROM Warehousing
						 WHERE SUBSTR(warehousingno, 2, 8) = REPLACE(p_makedate, '-', '')
							   AND SUBSTR(warehousingno, 0, 1) = 'C'
							   AND warehousingdiv = '02') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	-- ELSIF (UPPER(p_div) = 'SalesOrders')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(salesorderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(salesorderno, -4, 4) + 1), -4, 4), 'S' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(salesorderno) salesorderno
	--       FROM   SalesOrders
	--       WHERE  SUBSTR(salesorderno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	ELSIF (UPPER(p_div) = 'WAREHOUSINGRETURNING')
	THEN
		FOR rec
			IN (SELECT DECODE(
						   warehousingreturningno
						  ,NULL, 'J' || REPLACE(p_makedate, '-', '') || '0001'
						  ,SUBSTR(warehousingreturningno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(warehousingreturningno, -4, 4) + 1), -4, 4)
					   )
						   AS alias1
				  FROM (SELECT MAX(warehousingreturningno) warehousingreturningno
						  FROM WarehousingReturning
						 WHERE SUBSTR(warehousingreturningno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	-- ELSIF (UPPER(p_div) = 'WorkOrder')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(workorderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(workorderno, -4, 4) + 1), -4, 4), 'P' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(workorderno) workorderno
	--       FROM   WorkOrder
	--       WHERE  SUBSTR(workorderno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	ELSIF (UPPER(p_div) = 'RETURNINGINPUTORDER')
	THEN
		FOR rec
			IN (SELECT DECODE(inputorderno, NULL, 'I' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(inputorderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(inputorderno, -4, 4) + 1), -4, 4))
						   AS alias1
				  FROM (SELECT MAX(inputorderno) inputorderno
						  FROM ReturningInputOrder
						 WHERE SUBSTR(inputorderno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'ACCOUNTSEND1')
	THEN
		FOR rec IN (SELECT DECODE(trninseq, NULL, REPLACE(p_makedate, '-', '') || '0001', SUBSTR(trninseq, 0, 8) || SUBSTR('0000' || TO_CHAR(SUBSTR(trninseq, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(trninseq) trninseq
							  FROM ACAUTOORD
							 WHERE SUBSTR(trninseq, 0, 8) = REPLACE(p_makedate, '-', '')
								   AND acatrulecode = 'P01001') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'ACCOUNTNO')
	THEN
		FOR rec IN (SELECT DECODE(taxno, NULL, SUBSTR(REPLACE(p_makedate, '-', ''), 0, 6) || '030001', SUBSTR(taxno, 0, 8) || SUBSTR('0000' || TO_CHAR(SUBSTR(taxno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(taxno) taxno
							  FROM ACAUTOORD
							 WHERE SUBSTR(taxno, 0, 8) = REPLACE(p_makedate, '-', '')
								   AND acatrulecode = 'P01001') A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	-- ELSIF (UPPER(p_div) = 'ERPSalesend')
	-- THEN
	--  FOR rec IN (SELECT NVL(SUBSTR(erpendno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(erpendno, -4, 4) + 1), -4, 4), 'S' || REPLACE(p_makedate, '-', '') || '0001') AS alias1
	--     FROM   (SELECT MAX(erpendno) erpendno
	--       FROM   ERPSalesend
	--       WHERE  SUBSTR(erpendno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
	--  LOOP
	--   p_tostring := rec.alias1;
	--  END LOOP;
	ELSIF (UPPER(p_div) = 'MAKINGORDERS2')
	THEN
		FOR rec IN (SELECT DECODE(orderno, NULL, 'M' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(orderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(orderno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(orderno) orderno
							  FROM (SELECT MAX(orderno) orderno
									  FROM MakingOrders
									 WHERE SUBSTR(orderno, 2, 8) = REPLACE(p_makedate, '-', '')
										   AND SUBSTR(orderno, 0, 1) = 'M'
									UNION
									SELECT MAX(orderno) orderno
									  FROM PackingResults
									 WHERE SUBSTR(orderno, 2, 8) = REPLACE(p_makedate, '-', '')
										   AND SUBSTR(orderno, 0, 1) = 'M') A) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'PACKINGORDERS2')
	THEN
		FOR rec
			IN (SELECT DECODE(packingorderno, NULL, 'P' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(packingorderno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(packingorderno, -4, 4) + 1), -4, 4))
						   AS alias1
				  FROM (SELECT MAX(packingorderno) packingorderno
						  FROM (SELECT MAX(packingorderno) packingorderno
								  FROM PackingOrders
								 WHERE SUBSTR(packingorderno, 2, 8) = REPLACE(p_makedate, '-', '')
									   AND SUBSTR(packingorderno, 0, 1) = 'P'
								UNION
								SELECT MAX(packingorderno) packingorderno
								  FROM PackingResults
								 WHERE SUBSTR(packingorderno, 2, 8) = REPLACE(p_makedate, '-', '')
									   AND SUBSTR(packingorderno, 0, 1) = 'P') A) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'PDRCLASSIFYM')
	THEN
		FOR rec
			IN (SELECT DECODE(classifyno, NULL, 'C' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(classifyno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(classifyno, -4, 4) + 1), -4, 4)) AS alias1
				  FROM (SELECT MAX(classifyno) classifyno
						  FROM PDRCLASSIFYM
						 WHERE SUBSTR(classifyno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'PDRDISCARDM')
	THEN
		FOR rec IN (SELECT DECODE(discardno, NULL, 'D' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(discardno, 0, 9) || SUBSTR('0000' || TO_CHAR(SUBSTR(discardno, -4, 4) + 1), -4, 4)) AS alias1
					  FROM (SELECT MAX(discardno) discardno
							  FROM PDRDISCARDM
							 WHERE SUBSTR(discardno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_div = 'PDIMPORTSHEETM')
	THEN
		FOR REC
			IN (SELECT DECODE(importshtno, NULL, 'T' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(importshtno, 1, 9) || SUBSTR('0000' || TO_CHAR(TO_NUMBER(SUBSTR(importshtno, -4)) + 1), -4)) C1
				  FROM (SELECT MAX(importshtno) importshtno
						  FROM PDIMPORTSHEETM
						 WHERE SUBSTR(importshtno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
		LOOP
			p_tostring := REC.C1;
		END LOOP;
	ELSIF (p_div = 'PDIMPORTSHIPM')
	THEN
		FOR REC IN (SELECT DECODE(shippingno, NULL, 'S' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(shippingno, 1, 9) || SUBSTR('0000' || TO_CHAR(TO_NUMBER(SUBSTR(shippingno, -4)) + 1), -4)) C1
					  FROM (SELECT MAX(shippingno) AS shippingno
							  FROM PDIMPORTSHIPM
							 WHERE SUBSTR(shippingno, 2, 8) = REPLACE(p_makedate, '-', '')) A)
		LOOP
			p_tostring := REC.C1;
		END LOOP;
	ELSIF (p_div = 'PDIMPORTCUSTOMS')
	THEN
		FOR REC IN (SELECT DECODE(customsno, NULL, 'E' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(customsno, 1, 9) || SUBSTR('0000' || TO_CHAR(TO_NUMBER(SUBSTR(customsno, -4)) + 1), -4)) C1
					  FROM (SELECT MAX(customsno) customsno
							  FROM PDIMPORTCUSTOMS
							 WHERE SUBSTR(customsno, 2, 8) = REPLACE(p_makedate, '-', '')) a)
		LOOP
			p_tostring := REC.C1;
		END LOOP;
        
    ELSIF (p_div = 'SLSHINOUTM')
    THEN
        FOR REC IN (SELECT DECODE(INOUTNO, NULL, 'I' || REPLACE(p_makedate, '-', '') || '0001', SUBSTR(INOUTNO, 9) || SUBSTR('0000' || TO_CHAR(TO_NUMBER(SUBSTR(INOUTNO, -4)) + 1), -4)) C1
                      FROM (SELECT MAX(INOUTNO) INOUTNO
                              FROM SLSHINOUTM
                             WHERE SUBSTR(INOUTNO, 2, 8) = REPLACE(p_makedate, '-', '')) a)
        LOOP
            p_tostring := REC.C1;
        END LOOP;
	END IF;

	RETURN (p_tostring);
EXCEPTION
	WHEN OTHERS
	THEN
		NULL;
END;
/
