CREATE FUNCTION        ISDATE(
/* 데이터가 DATE 형인지 검사하는 함수임. 1 이 나오면 DATE 형임 */
	v_str_date 	IN 	VARCHAR2
)
	RETURN NUMBER
IS 
	V_DATE	  DATE;
BEGIN
	IF (LENGTH(v_str_date) = 0) OR v_str_date IS NULL OR (LENGTH(v_str_date) = 6) OR (LENGTH(v_str_date) = 7)
	THEN
		RETURN 0;
	ELSIF (LENGTH(v_str_date) = 4)    
	THEN
		V_DATE := TO_DATE(v_str_date, 'YYYY');
		RETURN 1;
	ELSIF (LENGTH(v_str_date) = 8)
	THEN
		V_DATE := TO_DATE(v_str_date, 'YYYYMMDD');
		RETURN 1;
	ELSIF (LENGTH(v_str_date) = 10)
    THEN
		V_DATE := TO_DATE(v_str_date, 'YYYY-MM-DD');
		RETURN 1;
    ELSIF (LENGTH(v_str_date) = 14)
    THEN
		V_DATE := TO_DATE(v_str_date, 'YYYYMMDD HH24:MI');
		RETURN 1;
    ELSIF (LENGTH(v_str_date) = 16)
    THEN
		V_DATE := TO_DATE(v_str_date, 'YYYY-MM-DD HH24:MI');
		RETURN 1;
        
    ELSIF ( LENGTH(v_str_date) = 5 AND INSTR(v_str_date, ':') > 0 )
    THEN 
        V_DATE := TO_DATE(v_str_date, 'HH24:MI');
        RETURN 1;        
    ELSE
    	RETURN 0;
	END IF;

EXCEPTION WHEN OTHERS THEN RETURN 0;
END;
/
