CREATE FUNCTION        fnSLordItemCheck
-- --------------------------------------------------------------------
 -- 함 수 명          : fnSLordItemCheck
 -- 작 성 자         : 김만수
 -- 작성일자         : 2017-11-15
 -- -------------------------------------------------------------------
 -- 함수설명         : 주문등록시 제품에 대한 제한내역을 체크하는 함수
 -- -------------------------------------------------------------------
(
    p_plantcode                IN    VARCHAR2 DEFAULT '',    --사업장
    p_orderdate                IN    VARCHAR2 DEFAULT '',    --주문일자
    p_custcode                 IN    VARCHAR2 DEFAULT '',    --거래처코드
    p_ecustcode                IN    VARCHAR2 DEFAULT '',    --간납처코드
    p_itemcode                 IN    VARCHAR2 DEFAULT '',    --제품코드
    p_orderqty                 IN    NUMBER   DEFAULT 0,     --주문수량
    p_orderkind                IN    VARCHAR2 DEFAULT '',    --주문경로 : ERP(30), SFA(20), 온라인(10)
    p_salprc                   IN    FLOAT    DEFAULT ''    --주문단가
)
RETURN VARCHAR2
AS
    v_useyn                   VARCHAR2(5);           --거래처별 채권체크 사용여부  
    v_mplantcode               VARCHAR2(5);           --제품 관리사업장  1001: 도매, 2001: 하길, 2002: 하길(향정)                  
    v_utdiv                   VARCHAR2(5);           --유통구분 / 10: 원내처방, 20: 원외처방, 40: 도매, 45: 도매약국, 60: 종합병원, 80: 준종합병원, 90: 입찰, 95: 처방처, 99: 기타
    v_drugprc                 FLOAT;                 --기준단가
             
    v_threeavgck               VARCHAR2(5);           --수량통제 체크
    v_productdivck            VARCHAR(5);            --출하중지여부 체크
    v_usedivck                 VARCHAR(5);           --사용중지여부 체크
    v_outprotck                VARCHAR(5);           --퇴장방지품목 할인율 체크
    v_ordqtybsck               VARCHAR(5);           --주문배수단위 체크
    v_mayakck                  VARCHAR(5);           --마약출하 체크
    v_hangjungck                 VARCHAR(5);           --향정출하 체크
    v_steroidck                VARCHAR(5);           --경구제출하 체크
    v_piececk                  VARCHAR(5);          --낱알구분 체크
    v_bohdivck                 VARCHAR(5);          --비급여 단가 체크
    v_promprcck                VARCHAR(5);          --간납처 계약단가여부 체크
   
    v_threeavglmt              NUMBER;               --주문수량한도(%)  
    v_mayak                   varchar2(5);           --마약취급여부 / Y: 취급, N: 제한
    v_hangjung                varchar(5);            --향정취급여부 / Y: 취급, N: 제한
    v_steroidyn               VARCHAR(5);            --경구제출하여부 / Y: 출하, N: 제한
   
    v_productdiv              VARCHAR(5);            --생산분류 / 01: 주력, 02:정책, 03:일반, 04:중지, 90:생산중단 (CM40)
    v_outprotyn               VARCHAR(5);            --퇴장방지여부/ Y: 퇴장방지품목, N: 일반
    v_ordqtybsunit             NUMBER;                 --주문배수단위
    v_pieceyn                 VARCHAR(5);            --낱알여부 / Y: 낱알, N: 일반
    v_itemgbdiv               VARCHAR(5);            --제품분류 / 01: 일반, 02: 마약, 03:의약외품, 04: 향정신성, 09: 냉동  
    v_usediv                  VARCHAR(5);            --사용중지여부 / Y: 사용중지, N: 일반
    v_bohdiv                 VARCHAR(5);             --의보구분 / 1: 급여, 2: 비급여
    v_itemname                VARCHAR(150);          --제품명
    
    v_startdt                  VARCHAR2(10);              --주문월 시작일 (1일)
    v_enddt                    VARCHAR2(10);              --주문월 말일
    v_thrstartdt               VARCHAR2(10);               --주문월 기준 3개월 전 시작일(1일)
    v_threnddt                 VARCHAR2(10);              --주문월 기준 전달 말일
    v_thatmonth                FLOAT(53);                 --주문월 주문수량 합계 + 해당 주문 수량
    v_threeavgcnt              FLOAT(53);                  --3개월 평균주문수량 * 주문수량한도(%)
    v_tahtmonthamt             FLOAT(53);              --당월주문금액 합계 / 당월 주문금액 + 해당 주문금액 
    v_amtlmt                  FLOAT(53);              --주문가능금액 / (해당거래처, 간납처의 총 주문금액 / 거래개시개월수) = 주문가능금액
    v_month                  NUMBER;                 --개시개월수
    v_jaegoqty               NUMBER := 0;            --가용재고수량 
   
    v_promprccnt              NUMBER;                --계약단가 확인
    v_message               VARCHAR2(200) := '0';      -- 0인 경우 정상 주문
BEGIN
   
   v_message := '에러';   
   
   IF (p_orderkind = '99')
   THEN
       SELECT NVL(MPLANTCODE, ' ') MPLANTCODE
       INTO   v_message
       FROM   CMITEMM
       WHERE  ITEMCODE = p_itemcode;
       GOTO ENDFUNCTION;
   END IF; 

   --거래처마스터
   FOR rec IN (SELECT  UTDIV                --유통구분
               ,       USEYN                --거래처별 채권체크 사용여부
               ,       JUMUN_LIMIT           --주문수량한도(%)
               ,       mayak                --마약취급여부
               ,       hangjung             --향정취급여부
               ,       steroidyn            --경구제출하여부
                 FROM CMCUSTM
                WHERE CUSTCODE = p_custcode)
   LOOP
      v_utdiv       := rec.utdiv      ;
      v_useyn       := rec.useyn      ;
      v_threeavglmt  := rec.jumun_limit;
      v_mayak     := rec.mayak      ;
      v_hangjung    := rec.hangjung    ;
      v_steroidyn   := rec.steroidyn   ;
   END LOOP;
   
   --제품마스터
   FOR rec IN (SELECT  productdiv     --생산분류 
              ,        outprotyn     --퇴장방지여부
              ,        ordqtybsunit   --주문배수단위
              ,        pieceyn       --낱알구분
              ,        itemgbdiv     --제품분류
              ,        usediv       --사용여부
              ,        bohdiv       --의보구분
              ,        drugprc      --기준단가
              ,        itemname     --제품명
                 FROM  CMITEMM
                WHERE  ITEMCODE = p_itemcode)
   LOOP
      v_productdiv    := rec.productdiv;
      v_outprotyn     := rec.outprotyn;
      v_ordqtybsunit  := rec.ordqtybsunit; 
      v_pieceyn       := rec.pieceyn;
      v_itemgbdiv     := rec.itemgbdiv;
      v_bohdiv        := rec.bohdiv;
      v_usediv        := rec.usediv;
      v_drugprc       := rec.drugprc;
      v_itemname      := rec.itemname;
   END LOOP;
        
   --사용 항목의 초기화 체크
   --거래처
   IF (v_utdiv IS NULL)      THEN v_utdiv       := ' ';      END IF;   --유통구분
   IF (v_useyn IS NULL)      THEN v_useyn       := 'Y';      END IF;   --채권체크관리정보_사용여부 기본값 Y: 거래처별 채권체크 관리
   IF (v_threeavglmt IS NULL) THEN v_threeavglmt  := 1.1;     END IF;   --주문수량한도 기본값 110%   기본값 1.1 (110%)
   IF (v_mayakck IS NULL)    THEN v_mayakck      := 'N';      END IF;   --마약거래여부             기본값 N: 불가
   IF (v_hangjung IS NULL)   THEN v_hangjung     := 'N';      END IF;   --향정거래여부              기본값 N: 불가
   IF (v_steroidyn IS NULL)  THEN v_steroidyn    := 'N';      END IF;   --경구제출하여부            기본값 N: 불가
   IF (v_promprccnt IS NULL) THEN v_promprccnt    := 0;       END IF;   --계약단가 내역 조회        기본값 0
   IF (v_month IS NULL)      THEN v_month       := 0;        END IF;   --거래개시월                기본값 0
   
   --제품
   IF (v_productdiv IS NULL)     THEN v_productdiv      := '03';      END IF;   --생산구분           기본값 03: 일반
   IF (v_outprotyn IS NULL)      THEN v_outprotyn       := 'N';      END IF;   --퇴장방지품목여부   기본값 N: 일반
   IF (v_ordqtybsunit IS NULL)   THEN v_ordqtybsunit     := 0;        END IF;   --주문배수단위       기본값 0
   IF (v_pieceyn IS NULL)        THEN v_pieceyn         := 'N';      END IF;   --낱알여부           기본값 N: 일반
   IF (v_itemgbdiv IS NULL)      THEN v_itemgbdiv       := '01';      END IF;   --제품분류          기본값 01: 일반 
   IF (v_bohdiv IS NULL)        THEN v_bohdiv          := '1';        END IF;   --의보구분          기본값 1: 급여
   IF (v_usediv IS NULL)         THEN v_usediv         := 'Y';       END IF;   --사용여부           기본값 Y: 사용
   IF (v_drugprc IS NULL)        THEN v_drugprc         := 0;        END IF;   --기준단가           기본값 0
  
-- 사용여부 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    IF(p_orderkind IN ('10', '20', '30') AND v_usediv = 'N') --사용여부가 N: 중지 인경우 체크
    THEN
        v_message := '1. [' || v_itemname || '] 제품은 사용중지 품목입니다.';
        GOTO ENDFUNCTION;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
   
-- 출하중지 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    IF(p_orderkind IN ('10', '20', '30') AND v_productdiv = '04') --생산분류가 04: 중지 인경우 체크
    THEN
        v_message := '2. [' || v_itemname || '] 제품은 출하중지 품목입니다.';
        GOTO ENDFUNCTION;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 생산중단 체크 (단종)
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    IF(p_orderkind IN ('10', '20', '30') AND v_productdiv = '90') --생산분류가 04: 중지 인경우 체크
    THEN
        v_message := '3. [' || v_itemname || '] 제품은 단종 품목입니다.';
        GOTO ENDFUNCTION;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 퇴장방지품목 할인율 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    IF(p_orderkind IN ('30') AND v_outprotyn = 'Y' AND (p_salprc / v_drugprc * 100) < 91) --퇴장방지품목여부가 Y인 경우 및 할인율 9% 초과인 경우 체크
    THEN
        v_message := '4. 퇴장방지품목 [' || v_itemname || '] 의 할인율은 9%를 넘을 수 없습니다.';
        GOTO ENDFUNCTION;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 주문배수단위 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    IF(p_orderkind IN ('30') AND v_ordqtybsunit != 0 AND MOD(p_orderqty, v_ordqtybsunit) != 0) --주문배수단위가 0이 아닌경우 주문배수단위 주문 체크
    THEN
        v_message := '5. [' || v_itemname || '] 제품은 ' || v_ordqtybsunit || '의 배수단위로만 주문가능합니다.';
        GOTO ENDFUNCTION;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 비급여품목 계약단가 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    IF(p_orderkind IN ('20', '30') AND v_bohdiv = '2') --비급여품목인 경우 계약단가 내역 필수
    THEN
        FOR rec IN (SELECT COUNT(*) AS alias1
                        FROM   SLPROMPRCM
                        WHERE  custcode = p_custcode
                               AND ecustcode = p_ecustcode
                               AND itemcode = p_itemcode
                               AND EDATE >= TO_CHAR(SYSDATE, 'yyyy-MM-dd'))
        LOOP
            v_promprccnt := rec.alias1;
        END LOOP;

        IF(v_promprccnt = 0)
        THEN
            v_message := '6. 비급여품목 [' || v_itemname || '] 에 대한 계약단가 내역이 존재하지않습니다.';
            GOTO ENDFUNCTION;
        END IF;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 낱알여부 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    IF(p_orderkind IN ('30') AND v_pieceyn = 'Y') --제품 낱알여부 Y: 낱알 체크
    THEN
        v_message := '7. [' || v_itemname || '] 제품은 낱알 품목으로 등록할 수 없습니다.';
        GOTO ENDFUNCTION;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 경구제 출하여부 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    IF(p_orderkind IN ('10', '20', '30') AND v_utdiv != '40' AND SUBSTR(p_itemcode, 1, 1) IN ('1', '3', '4') AND v_steroidyn != 'Y') --제품코드 첫자리 1, 3, 4인 경우 경구제
    THEN
        v_message := '8. 해당 거래처는 경구제 품목 [' || v_itemname || '] 에 대한 등록이 제한됩니다.' ;
        GOTO ENDFUNCTION;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 마약거래여부 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    IF(p_orderkind IN ('10', '30') AND v_mplantcode = '2001') --마약제품인 경우 주문유형이 3(간납)이 아닌경우 OR 마약거래여부 N: 제한 인 경우  v_itemgbdiv = '02' 마약
    THEN
        IF(v_utdiv = '40' AND v_mayak = 'N')
        THEN
            v_message := '9-1. 해당 도매업체는 마약제품을 등록할 수 없습니다.';
            GOTO ENDFUNCTION;
        ELSIF(v_utdiv != '40')
        THEN
            v_message := '9-2. 직거래처에는 마약제품을 등록할 수 없습니다.';
            GOTO ENDFUNCTION;
        END IF;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 향정거래여부 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    --직납인 경우 체크 제외
    IF(p_orderkind IN ('10', '30') AND v_mplantcode = '2002' AND (v_utdiv = '40' AND v_hangjung = 'N')) --향정제품인 경우 주문유형이 4(직납)이 아닌경우 AND 향정거래여부 N: 제한 인 경우 v_itemgbdiv = '04' 향정
    THEN
        v_message := '10. 해당 도매업체는 향정제품을 등록할 수 없습니다.';
        GOTO ENDFUNCTION;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 간납거래 계약단가 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
   -- IF(v_utdiv = '40') -- 간납거래인 경우 계약단가 내역 필수 체크
    IF(p_orderkind IN ('10', '20', '30') AND SUBSTR(p_custcode, 0 , 1) NOT IN ('3', '4')) --거래처코드의 첫자리가 3, 4 인 경우 직납 거래
    THEN
        FOR rec IN (SELECT COUNT(*) AS alias1
                    FROM   SLPROMPRCM
                    WHERE  custcode = p_custcode
                           AND ecustcode = p_ecustcode
                           AND itemcode = p_itemcode
                           AND EDATE >= TO_CHAR(SYSDATE, 'yyyy-MM-dd'))
        LOOP
            v_promprccnt := rec.alias1;
        END LOOP;

        IF(v_promprccnt = 0)
        THEN
            v_message := '11. 해당 거래처에 [' || v_itemname || '] 제품에 대한 계약단가 내역이 존재하지 않습니다.';
            GOTO ENDFUNCTION;
        END IF;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 제품 재고 체크
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
    IF(p_orderkind IN ('10', '20', '30'))
    THEN
        FOR rec IN (
                        SELECT NVL(SUM(A.QTY) - SUM(NVL (B.REALQTY, 0)) - MAX(NVL(C.CONTROLQTY, 0)), 0) REALQTY    --주문수량, 품절방지수량 제외한 재고
                          FROM SLWAREHOUSEM A
                                LEFT JOIN (
                                                 SELECT A.ITEMCODE                    ,
                                                        NVL (B.WAREHOUSE, '001') WAREHOUSE,
                                                        SUM (A.SALQTY + A.GIVQTY + A.BONUSQTY - A.OUTPUTQTY) REALQTY
                                                   FROM SLORDD A
                                                   JOIN SLORDM B
                                                     ON A.PLANTCODE = B.PLANTCODE
                                                    AND A.ORDERNO = B.ORDERNO
                                                    AND B.SALDIV LIKE 'A%'
                                                    AND B.SALDIV NOT IN ('A03', 'A07', 'A25', 'A40', 'A51', 'A53')
                                                    AND B.STATEDIV NOT IN ('99')
                                                  WHERE A.ITEMCODE = p_itemcode
                                                    AND A.SALQTY + A.GIVQTY + A.BONUSQTY > A.OUTPUTQTY
                                               GROUP BY A.ITEMCODE, B.WAREHOUSE
                                            ) B
                                            ON A.ITEMCODE = B.ITEMCODE
                                            AND A.WAREHOUSE = B.WAREHOUSE 
                                     JOIN CMITEMM C
                                            ON A.ITEMCODE = C.ITEMCODE                               
                         WHERE A.ITEMCODE = p_itemcode
                           AND A.STOPYN = 'N'  --제조번호단위 출하중지 여부 체
                      GROUP BY A.ITEMCODE, A.WAREHOUSE
                    )
         LOOP
            v_jaegoqty := rec.REALQTY;
         END LOOP;
         
         IF(v_jaegoqty < p_orderqty)   --가용수량이 주문수량보다 적을 경우 
         THEN
             v_message := '12. [' || v_itemname || '] 제품의 재고가 부족합니다.';
         END IF;
    END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/

-- 수량통제 체크   
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
   IF(p_orderkind IN ('10', '20', '30') AND v_mplantcode != '2001') --마약제품인 경우 수량통제 Pass v_itemgbdiv != '02' 마약 
   THEN
        --기준날짜 설정
        v_startdt := TO_CHAR(TO_DATE(SUBSTR(p_orderdate, 0, 7), 'YYYY-MM'), 'YYYY-MM') || '-01';    --주문월 1일
        v_enddt := TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(p_orderdate, 0, 7), 'YYYY-MM')), 'YYYY-MM-DD'); --주문월 말일
        
        v_thrstartdt := TO_CHAR(ADD_MONTHS(TO_DATE(SUBSTR(p_orderdate, 0, 7), 'YYYY-MM'), -3), 'YYYY-MM') || '-01'; -- 주문월 기준 3개월 이전 시작일(1일)
        v_threnddt := TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(p_orderdate, 0, 7), 'YYYY-MM'), -1)), 'YYYY-MM-DD');              --주문월 기준 전달 말일
        
        --개시개월수 설정
        FOR rec IN (
                        SELECT TRUNC(MONTHS_BETWEEN(TO_DATE(TO_CHAR(SUBSTR(p_orderdate, 1, 7)), 'yyyy-mm'), TO_DATE(TO_CHAR(SUBSTR(OPENDATE, 1, 7)), 'yyyy-mm'))) AS ALIAS1
                        FROM   CMCUSTM
                        WHERE  CUSTCODE = p_custcode
                    )
        LOOP
            v_month := rec.alias1;
        END LOOP;
        
        
        --당월 판매수량
        FOR rec IN (SELECT NVL(SUM(b.salqty), 0) + p_orderqty AS alias1         --이번달 주문합계 + 해당 주문 수량 = 이번달 총주문수량
                    FROM   SLORDM a
                           LEFT JOIN SLORDD b
                               ON a.orderno = b.orderno
                                  AND a.plantcode = b.plantcode
                    WHERE  a.orderdate BETWEEN v_startdt AND v_enddt
                           AND a.custcode = p_custcode
                           AND a.ecustcode = p_ecustcode
                           AND a.plantcode = p_plantcode
    --                               AND a.statediv = '09' --매출확정인 상태의 정보만 조회
                           AND b.itemcode = p_itemcode)
        LOOP
            v_thatmonth := rec.alias1;  --이번달 주문합계 + 해당 주문 수량 = 이번달 총주문수량
        END LOOP;
            
        --평균 주문수량 / 거래개시월 1,2 개월인 경우 / 거래개시월, 3개월 이상인 경우 /3 
        FOR rec IN (SELECT ROUND((TO_NUMBER(NVL(SUM(b.salqty), 0) / CASE WHEN v_month IN (1, 2) THEN v_month ELSE 3 END) * v_threeavglmt)) AS alias1 -- 평균주문수량 * 주문수량한도(%) 계산 수량
                    FROM   SLORDM a
                           LEFT JOIN SLORDD b
                               ON a.orderno = b.orderno
                                  AND a.plantcode = b.plantcode
                    WHERE  a.orderdate BETWEEN v_thrstartdt AND v_threnddt
                           AND a.custcode = p_custcode
                           AND a.ecustcode = p_ecustcode
                           AND a.plantcode = p_plantcode
                           AND a.statediv = '09' --매출확정인 상태의 정보만 조회
                           AND b.itemcode = p_itemcode)
        LOOP
            v_threeavgcnt := rec.alias1;  --평균주문수량 * 주문수량한도(%) 계산 수량
        END LOOP;
        
        --당월 주문금액 합계
        FOR rec IN (
                        SELECT  ROUND(NVL(SUM(B.TOTAMT), 0)) AS alias1
                        FROM    SLORDM A
                               ,SLORDD B
                        WHERE   A.PLANTCODE = B.PLANTCODE
                        AND     A.ORDERNO = B.ORDERNO
                        AND     A.ORDERDATE BETWEEN v_thrstartdt AND v_threnddt
                        AND     A.CUSTCODE = p_custcode
                        AND     A.ECUSTCODE = p_ecustcode
                    )
        LOOP
            v_tahtmonthamt := rec.alias1;
        END LOOP;
        
        IF(v_month = 0)
        THEN
             IF(v_thatmonth > 10)      --거래개시개월 0인 경우 이번달 주문수량 + 현재 주문수량이 10개를 초과할 수 없음
             THEN
                 v_message := '20-1. [' || v_itemname || '] 의 이달 주문합계수량('|| v_thatmonth || ')이 10개를 초과하였습니다';
                 GOTO ENDFUNCTION;
             END IF;
        ELSIF(v_month IN (1, 2)) --거래개시개월 1, 2개월 인 경우
        THEN
            IF(v_thatmonth > 10)
            THEN
                IF(v_thatmonth > v_threeavgcnt)
                THEN
                    v_message := '20-2. [' || v_itemname || '] 의 ' || v_month || '개월 평균주문수량의 '|| v_threeavglmt || '배인 ' || v_threeavgcnt ||' 개를 초과하였습니다.';  
                    GOTO ENDFUNCTION;  
                END IF;
            ELSE
                IF(v_thatmonth > v_threeavgcnt)
                THEN
                     --주문 가능금액
                    FOR rec IN (
                                    SELECT  (ROUND(NVL(SUM(B.TOTAMT), 0)) / v_month) * v_threeavglmt AS alias1  --(총주문금액 / 거래개시개월수) * 주문수량한도 = 주문가능금액
                                    FROM    SLORDM A
                                           ,SLORDD B
                                    WHERE   A.PLANTCODE = B.PLANTCODE
                                    AND     A.ORDERNO = B.ORDERNO
                                    AND     A.CUSTCODE = p_custcode
                                    AND     A.ECUSTCODE = p_ecustcode
                                )
                    LOOP
                        v_amtlmt := rec.alias1;  --주문 가능금액
                    END LOOP;
                    
                    IF(v_tahtmonthamt > v_amtlmt) --이달주문금액과 주문가능금액 비교
                    THEN
                        v_message := '20-3. [' || v_itemname || ']의 이달 주문합계금액('|| v_tahtmonthamt || ')이 '|| v_thatmonth ||' 개월평균주문금액의 ' || v_threeavglmt || '배인 '|| v_amtlmt ||' 원을 초과하였습니다.';
                        GOTO ENDFUNCTION; 
                    END IF;
                ELSE
                    v_message := '20-4. [' || v_itemname || '] 의 ' || v_month || '개월 평균주문수량의 '|| v_threeavglmt || '배인 ' || v_threeavgcnt ||' 개를 초과하였습니다.';  
                    GOTO ENDFUNCTION;  
                END IF;  
            END IF;
        ELSE  -- 거래개시개월 3개월 이상인 경우
            IF(v_thatmonth > 10)
            THEN
                IF  (v_threeavgcnt < v_thatmonth) --3개월 평균주문수량 * 주문수량한도 < 이번달 주문수량 + 현재 주문수량
                THEN
                    v_message := '20-5. [' || v_itemname || '] 의 이달 주문합계수량('|| v_thatmonth || ')이 3개월평균주문수량의' || v_threeavglmt || '배인 ' || v_threeavgcnt ||' 개를 초과하였습니다.';    
                    GOTO ENDFUNCTION;        
                END IF;
                
            ELSE
                IF  (v_threeavgcnt < v_thatmonth) --3개월 평균주문수량 * 주문수량한도 < 이번달 주문수량 + 현재 주문수량
                THEN
                     --3개월 주문 평균금액 (제품상관없음) * 주문한도 
                    FOR rec IN (
                                    SELECT  ROUND(NVL(SUM(B.TOTAMT), 0) / 3) * v_threeavglmt AS alias1  --(총주문금액 / 3) * 주문수량한도 = 주문가능금액
                                    FROM    SLORDM A
                                           ,SLORDD B
                                    WHERE   A.PLANTCODE = B.PLANTCODE
                                    AND     A.ORDERNO = B.ORDERNO
                                    AND     A.ORDERDATE BETWEEN v_thrstartdt AND v_threnddt 
                                    AND     A.CUSTCODE = p_custcode
                                    AND     A.ECUSTCODE = p_ecustcode
                                )
                    LOOP
                        v_amtlmt := rec.alias1;  --주문 가능금액
                    END LOOP;
                    
                    IF(v_tahtmonthamt > v_amtlmt)
                    THEN
                        v_message := '20-6. [' || v_itemname || '] 의 이달 주문합계금액('|| v_tahtmonthamt || ')이 3개월평균주문금액의' || v_threeavglmt || '인 '|| v_amtlmt ||' 원을 초과하였습니다(개시3개월이상)';
                    END IF;
                
                END IF;   
            END IF;
        END IF;
   END IF;
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
   <<ENDFUNCTION>>
   
   IF(v_message = '에러')
   THEN
       v_message := '0';         -- 0: 정상주문
   END IF;
   
   RETURN (v_message);

EXCEPTION WHEN OTHERS THEN RETURN (v_message);
END;
/
