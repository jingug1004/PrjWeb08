CREATE PROCEDURE        spACacc00151P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc00151P
 -- 작 성 자         : 최용석
 -- 작성일자         : 2017-09-23
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 법인카드 내역을 승인하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '',

    p_compcode      IN VARCHAR2 DEFAULT '',
    p_slipsdate     IN VARCHAR2 DEFAULT '',
    p_slipedate     IN VARCHAR2 DEFAULT '',
    p_confdiv       IN VARCHAR2 DEFAULT '',
    p_cardno        IN VARCHAR2 DEFAULT '',
    p_empcode       IN VARCHAR2 DEFAULT '',

    p_card_no       IN VARCHAR2 DEFAULT '',
    p_use_dt        IN VARCHAR2 DEFAULT '',
    p_use_tm        IN VARCHAR2 DEFAULT '',
    p_card_ok_no    IN VARCHAR2 DEFAULT '',
    p_use_gubun     IN VARCHAR2 DEFAULT '',
    p_gongjae_yn    IN VARCHAR2 DEFAULT '',
    p_use_detail    IN VARCHAR2 DEFAULT '',
    p_acccode       IN VARCHAR2 DEFAULT '',
    p_team_yn       IN VARCHAR2 DEFAULT '',
    p_jukyo         IN VARCHAR2 DEFAULT '',
    p_iempcode      IN VARCHAR2 DEFAULT '',

    p_conf_yn        IN VARCHAR2 DEFAULT '',
    p_deduction      IN VARCHAR2 DEFAULT '',

    p_userid        IN VARCHAR2 DEFAULT '',
    p_reasondiv     IN VARCHAR2 DEFAULT '',
    p_reasontext    IN VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
BEGIN

    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo (userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    -- 카드전표내역 검색
    if ( p_div = 'S') then
        open IO_CURSOR for
        select  'N' as seldiv                                                       -- 선택
                ,FNstuff(FNstuff(a.use_dt,5,0,'-'),8,0,'-') as use_dt               -- 사용일자
                ,FNstuff(FNstuff(a.use_tm,3,0,':'),6,0,':') as use_tm               -- 사용시간
                ,b.cardno as card_no                                                -- 카드번호
                ,a.card_ok_no as card_ok_no                                         -- 승인번호
                ,case when a.use_gubun = '03' then '승인' else '취소' end as use_gubun  -- 사용구분
                ,b.empcode                                                          -- 사용사원
                ,c.empname                                                          -- 사용사원명
                ,c.deptcode                                                         -- 부서코드
                ,d.deptname                                                         -- 부서명
                ,a.use_amt                                                          -- 사용금액
                ,a.saupjang_nm                                                      -- 가맹점명
                ,a.vendor_mmc_name                                                  -- 업종
                ,FNstuff(FNstuff(a.saup_no,4,0,'-'),7,0,'-') as saup_no             -- 사업자번호
                ,a.saupjang_addr                                                    -- 주소
                ,case a.tax_gb when '1' then '일반' when '2' then '간이' when '3' then '면세' when '4' then '비영리' when '9' then '휴업' else '폐업' end as tax_gb   -- 과세구분
                ,i.divname as gongjae_yn                                            -- 공제여부
                ,a.use_detail                                                       -- 상세내역
                ,a.gaejung_cd as acccode                                            -- 계정코드
                ,e.accname                                                          -- 계정명
                ,a.teamjang_conf_yn as team_yn                                      -- 입력상태
                ,a.teamjang_conf_sabun                                              -- 입력사원
                ,f.empname as teamempname                                           -- 입력사원명
                ,case when a.salecamp_conf_yn = '2' then '승인' else '미승인' end as conf_yn -- 승인상태
                ,a.salecamp_conf_sabun                                              -- 승인사원
                ,g.empname as confempname                                           -- 승인사원명
                ,a.jukyo                                                            -- 적요
                ,a.deduction_yn_cd                                                  -- 관리자승인
                ,case when a.junpyo_yn = '1' then '미생성' else '생성' end as junpyo_yn  -- 전표생성
                ,FNstuff(h.slipinno,8,0,'-') as junpyo_no                           -- 전표번호
                ,a.seq                                                              -- 순번

        from    IBK_ACQUIRE_DATA a
                join ACCARDM b
                    on b.compcode = p_compcode
                    and a.card_no = replace(b.cardno,'-','')
                left join CMEMPM c
                    on b.empcode = c.empcode
                left join CMDEPTM d
                    on c.deptcode = d.deptcode
                left join ACACCM e
                    on a.gaejung_cd = e.acccode
                left join CMEMPM f
                    on a.teamjang_conf_sabun = f.empcode
                left join CMEMPM g
                    on a.salecamp_conf_sabun = g.empcode
                left join ACORDM h
                    on h.compcode = p_compcode
                    and a.junpyo_no = h.slipinno
                left join CMCOMMONM i
                    on i.cmmcode = 'AC682'
                    and a.gongjae_yn = i.divcode
                left join IBK_ACQUIRE_COMP j
                    on a.card_no = j.card_no
                    and a.use_dt = j.use_dt
                    and a.use_tm = j.use_tm
                    and a.card_ok_no = j.card_ok_no
                    and a.use_gubun = j.use_gubun
                    and a.seq = j.seq

        where   a.use_dt between replace(p_slipsdate, '-', '') and replace(p_slipedate, '-', '')
--                and a.teamjang_conf_yn = 'Y'
                and (p_confdiv = '0' and a.salecamp_conf_yn = '1' or
                     p_confdiv = '1' and a.salecamp_conf_yn = '2')
                and b.cardno in ( select  a.cardno
                                  from    ACCARDM a
                                          left join ACCRDMNG b
                                              on a.compcode = b.compcode
                                              and a.cardno = b.cardno
                                          left join CMEMPM c
                                              on nvl(a.empcode, b.empcode) = c.empcode
                                          left join CMEMPM d
                                              on c.deptcode = d.deptcode
                                              and d.classdiv in ('27030', '27035')
                                  where   a.compcode = p_compcode
                                          and a.card_no like '%' || replace(p_cardno,'-','') || '%'
                                          and coalesce(b.cempcode, d.empcode) = p_empcode)
                and j.card_no is null

        order by a.use_dt, a.use_tm, a.card_no;

    -- 법인카드 승인부서
    elsif ( p_div = 'SD') then
        open IO_CURSOR for
        select  a.deptcode
        from    CMEMPM a
                join CMCOMMONM b
                    on b.cmmcode = 'AC684'
                    and a.deptcode = b.divcode
        where   a.empcode = p_iempcode;

    -- 카드전표내역 선택저장
    elsif ( p_div = 'U') then
        update  IBK_ACQUIRE_DATA a
        set     gongjae_yn = p_gongjae_yn
                ,use_detail = p_use_detail
                ,gaejung_cd = p_acccode
                ,teamjang_conf_yn = p_team_yn
                ,teamjang_conf_sabun = p_iempcode
                ,jukyo = p_jukyo
        where   card_no = replace(p_card_no,'-','')
                and use_dt = replace(p_use_dt,'-','')
                and use_tm = replace(p_use_tm,':','')
                and card_ok_no = p_card_ok_no
                and use_gubun = case when p_use_gubun = '승인' then '03' else '04' end;

    -- 카드전표내역 승인
    elsif ( p_div = 'C') then
        update  IBK_ACQUIRE_DATA a
        set     salecamp_conf_yn = p_conf_yn
                ,salecamp_conf_sabun = case when p_conf_yn = '2' then p_iempcode end
                ,deduction_yn_cd = p_deduction
        where   card_no = replace(p_card_no,'-','')
                and use_dt = replace(p_use_dt,'-','')
                and use_tm = replace(p_use_tm,':','')
                and card_ok_no = p_card_ok_no
                and use_gubun = case when p_use_gubun = '승인' then '03' else '04' end;

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
