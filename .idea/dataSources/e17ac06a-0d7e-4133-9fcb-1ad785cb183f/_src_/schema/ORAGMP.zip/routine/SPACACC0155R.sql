CREATE PROCEDURE        spACacc0155R(
    -- ---------------------------------------------------------------
    -- 프로시저명       : spACacc0155R
    -- 작 성 자         : 배종성
    -- 작성일자         : 2010-12-08
    -- 수 정 자     : 노영래
    -- E-Mail       : 0rae0926@gmail.com
    -- 수정일자      : 2016-12-20
    -- ---------------------------------------------------------------
    -- 프로시저 설명    : 관리항목원장을 조회하는 프로시저이다.
    -- ---------------------------------------------------------------

    p_div           IN       VARCHAR2 DEFAULT '',
    p_compcode      IN       VARCHAR2 DEFAULT '',
    p_plantcode     IN       VARCHAR2 DEFAULT '',
    p_acccode       IN       VARCHAR2 DEFAULT '',
    p_dcdiv         IN       VARCHAR2 DEFAULT '',
    p_startdt       IN       VARCHAR2 DEFAULT '',
    p_enddt         IN       VARCHAR2 DEFAULT '',
    p_mngclucode    IN       VARCHAR2 DEFAULT '',
    p_mngcluval1    IN       VARCHAR2 DEFAULT '',
    p_mngcluval2    IN       VARCHAR2 DEFAULT '',
    p_outputdiv     IN       VARCHAR2 DEFAULT '',
    p_userid        IN       VARCHAR2 DEFAULT '',
    p_reasondiv     IN       VARCHAR2 DEFAULT '',
    p_reasontext    IN       VARCHAR2 DEFAULT '',
    MESSAGE            OUT VARCHAR2,
    IO_CURSOR           OUT TYPES.DATASET
)
AS
    p_colview       VARCHAR2(1);
    ip_mngclucode   VARCHAR2(50) := p_mngclucode;
    p_mngcluval     VARCHAR2(50);
    p_mngcludec     VARCHAR2(50);
    p_slipdate      VARCHAR2(13);
    p_slipnum       VARCHAR2(5);
    p_remark        VARCHAR2(100);
    p_debamt        FLOAT(53);
    p_creamt        FLOAT(53);
    p_fnamt         FLOAT(53);
    p_rows          NUMBER(10, 0);
    p_odiv1         VARCHAR2(5);
    p_odiv2         VARCHAR2(5);
    spsl_cursor     SYS_REFCURSOR;
    spsl_cursor1    SYS_REFCURSOR;
BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    p_colview := '_';

    FOR rec IN (SELECT value1
                FROM   SYSPARAMETERMANAGE
                WHERE  UPPER(parametercode) = UPPER('accldgcolview') )
    LOOP
        p_colview := rec.value1;
    END LOOP;

	IF (p_colview = '_') THEN
    	p_colview := '0';
    END IF;

    IF (p_outputdiv = '1')
    THEN
        --K-GAAP
        p_odiv1 := '20';
        p_odiv2 := 'F';
    END IF;

    IF (p_outputdiv = '2')
    THEN
        --IFRS
        p_odiv1 := '30';
        p_odiv2 := 'K';
    END IF;

    IF (p_div = 'S')
    THEN
        -- 관리항목구분코드, 관리항목명, 전표일자, 전표번호, 적요, 차대변금액, 잔액
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 출력구분 [K-GAAP, IFRS]
        -- 관리항목코드
        -- 관리항목명
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 차변금액
        -- 대변금액
        -- K-GAAP <> 'F', IFRS <> 'K'
        -- 관리항목코드
        -- 관리항목명
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 차변금액
        -- 대변금액
        -- K-GAAP <> 'F', IFRS <> 'K'
        --월계
        -- 관리항목코드
        -- 관리항목명
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 차변금액
        -- 대변금액
        -- 관리항목코드
        -- 관리항목명
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 차변금액
        -- 대변금액

        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0155R_ACACC0155R ';



        IF p_fnamt IS NULL
        THEN
            p_fnamt := 0;
        END IF;

        OPEN spsl_cursor FOR
            SELECT     mngclucode,
                     mngcluval,
                     mngcludec,
                     slipdate,
                     slipnum,
                     remark,
                     debamt,
                     creamt
            FROM     (SELECT   mngclucode mngclucode,
                               '' mngcluval,
                               '' mngcludec,
                               '1000-00-00' slipdate,
                               '' slipnum,
                               '' remark,
                               SUM(debamt) debamt,
                               SUM(creamt) creamt
                      FROM       (SELECT '' mngclucode,
                                       '' mngcluval,
                                       '' mngcludec,
                                       '이월' slipdate,
                                       '' slipnum,
                                       '' remark,
                                       NVL(bsdebamt, 0) debamt,
                                       NVL(bscreamt, 0) creamt
                                FROM   ACORDDMM
                                WHERE  compcode = p_compcode
                                       AND plantcode LIKE p_plantcode
                                       AND slipym = SUBSTR(p_startdt, 0, 7)
                                       AND (closediv = '10'
                                            OR closediv = p_odiv1)
                                       AND acccode = p_acccode
                                UNION ALL
                                SELECT '' mngclucode,
                                       '' mngcluval,
                                       '' mngcludec,
                                       A.slipdate slipdate,
                                       A.slipnum slipnum,
                                       A.remark1 remark,
                                       NVL(A.debamt, 0) debamt,
                                       NVL(A.creamt, 0) creamt
                                FROM   ACORDD A, ACORDM c
                                WHERE  A.compcode = p_compcode
                                       AND A.plantcode LIKE p_plantcode
                                       AND A.acccode = p_acccode
                                       AND NVL(A.slipdate, ' ') < p_startdt
                                       AND NVL(A.slipdate, ' ') >= SUBSTR(p_startdt, 1, 7) || '-01'
                                       AND A.compcode = c.compcode
                                       AND A.plantcode = c.plantcode
                                       AND A.slipinno = c.slipinno
                                       AND c.slipdiv <> p_odiv2
                                       AND c.slipinstate = '4' ) A
                      GROUP BY mngclucode
                      UNION ALL
                      SELECT '' mngclucode,
                             '' mngcluval,
                             '' mngcludec,
                             A.slipdate slipdate,
                             A.slipnum slipnum,
                             A.remark1 remark,
                             NVL(A.debamt, 0) debamt,
                             NVL(A.creamt, 0) creamt
                      FROM     ACORDD A, ACORDM c
                      WHERE  A.compcode = p_compcode
                             AND A.plantcode LIKE p_plantcode
                             AND A.slipdate BETWEEN p_startdt AND p_enddt
                             AND A.acccode = p_acccode
                             AND A.compcode = c.compcode
                             AND A.plantcode = c.plantcode
                             AND A.slipinno = c.slipinno
                             AND c.slipdiv <> p_odiv2
                             AND c.slipinstate = '4'
                      UNION ALL
                      SELECT   mngclucode mngclucode,
                               '' mngcluval,
                               '' mngcludec,
                               slipdate slipdate,
                               '' slipnum,
                               '' remark,
                               SUM(A.debamt) debamt,
                               SUM(A.creamt) creamt
                      FROM       (SELECT '' mngclucode,
                                       '' mngcluval,
                                       '' mngcludec,
                                       SUBSTR(A.slipdate, 0, 7) || '-90-99' slipdate,
                                       '' slipnum,
                                       '' remark,
                                       debamt,
                                       creamt
                                FROM   ACORDD A
                                       JOIN ACORDM c
                                           ON A.compcode = c.compcode
                                              AND A.plantcode = c.plantcode
                                              AND A.slipinno = c.slipinno
                                WHERE  A.compcode = p_compcode
                                       AND A.plantcode LIKE p_plantcode
                                       AND A.acccode = p_acccode
                                       AND A.slipdate BETWEEN p_startdt AND p_enddt
                                       AND c.slipinstate = '4') A
                      GROUP BY A.mngclucode, slipdate) A
            ORDER BY slipdate, REPLACE(slipnum, 'C', p_colview);

        -- @fnamt 나중에 이월의 잔액을 넣어줘야함.
        LOOP
            FETCH spsl_cursor
                INTO ip_mngclucode, p_mngcluval, p_mngcludec, p_slipdate, p_slipnum, p_remark, p_debamt, p_creamt;

            EXIT WHEN spsl_cursor%NOTFOUND;

            IF (SUBSTR(p_slipdate, -2, 2) <> '99')
            THEN
                IF (p_dcdiv = '1')
                THEN
                    p_fnamt := NVL(p_fnamt, 0) + NVL(p_debamt, 0) - NVL(p_creamt, 0);
                ELSIF (p_dcdiv = '2')
                THEN
                    p_fnamt := NVL(p_fnamt, 0) + NVL(p_creamt, 0) - NVL(p_debamt, 0);
                END IF;
            END IF;

            INSERT INTO VGT.TT_ACACC0155R_ACACC0155R
            VALUES        (ip_mngclucode,
                         p_mngcluval,
                         p_mngcludec,
                         p_slipdate,
                         p_slipnum,
                         p_remark,
                         p_debamt,
                         p_creamt,
                         p_fnamt);

            IF (SUBSTR(p_slipdate, -5, 5) = '90-99')
            THEN
                IF (p_dcdiv = '1')
                THEN
                    INSERT INTO VGT.TT_ACACC0155R_ACACC0155R
                        (SELECT ip_mngclucode,
                                '',
                                '',
                                SUBSTR(p_slipdate, 0, 7) || '-99-99',
                                '' slipnum,
                                '' remark,
                                SUM(debamt) debamt,
                                SUM(creamt) creamt,
                                SUM(debamt) - SUM(creamt) fnamt
                         FROM    VGT.TT_ACACC0155R_ACACC0155R
                         WHERE    NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                                AND slipdate BETWEEN '1000-00-00' AND p_slipdate);
                ELSIF (p_dcdiv = '2')
                THEN
                    INSERT INTO VGT.TT_ACACC0155R_ACACC0155R
                        (SELECT ip_mngclucode,
                                '',
                                '',
                                SUBSTR(p_slipdate, 0, 7) || '-99-99',
                                '',
                                '',
                                SUM(debamt) debamt,
                                SUM(creamt) creamt,
                                SUM(creamt) - SUM(debamt) fnamt
                         FROM    VGT.TT_ACACC0155R_ACACC0155R
                         WHERE    NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                                AND slipdate BETWEEN '1000-00-00' AND p_slipdate);
                END IF;
            END IF;
        END LOOP;

        CLOSE spsl_cursor;

        IF (SUBSTR(p_slipdate, -2, 2) != '99')
        THEN
            IF (p_dcdiv = '1')
            THEN
                INSERT INTO VGT.TT_ACACC0155R_ACACC0155R
                    (SELECT ip_mngclucode,
                            '',
                            '',
                            SUBSTR(p_slipdate, 0, 7) || '-99-99',
                            '' slipnum,
                            '' remark,
                            SUM(debamt) debamt,
                            SUM(creamt) creamt,
                            SUM(debamt) - SUM(creamt) fnamt
                     FROM    VGT.TT_ACACC0155R_ACACC0155R
                     WHERE    NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                            AND slipdate BETWEEN '1000-00-00' AND p_slipdate);
            ELSIF (p_dcdiv = '2')
            THEN
                INSERT INTO VGT.TT_ACACC0155R_ACACC0155R
                    (SELECT ip_mngclucode,
                            '',
                            '',
                            SUBSTR(p_slipdate, 0, 7) || '-99-99',
                            '',
                            '',
                            SUM(debamt) debamt,
                            SUM(creamt) creamt,
                            SUM(creamt) - SUM(debamt) fnamt
                     FROM    VGT.TT_ACACC0155R_ACACC0155R
                     WHERE    NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                            AND slipdate BETWEEN '1000-00-00' AND p_slipdate);
            END IF;
        END IF;

        FOR rec IN (SELECT COUNT(*) AS alias1 FROM VGT.TT_ACACC0155R_ACACC0155R)
        LOOP
            p_rows := rec.alias1;
        END LOOP;

        IF (p_rows = 1)
        THEN
            IF (p_dcdiv = '1')
            THEN
                INSERT INTO VGT.TT_ACACC0155R_ACACC0155R
                    (SELECT MAX(mngclucode) mngclucode,
                            '' mngcluval,
                            '' mngcludec,
                            '1000-00-01' slipdate,
                            '' slipnum,
                            '' remark,
                            SUM(debamt),
                            SUM(creamt),
                            SUM(debamt) - SUM(creamt) fnamt
                     FROM    VGT.TT_ACACC0155R_ACACC0155R);
            ELSIF (p_dcdiv = '2')
            THEN
                INSERT INTO VGT.TT_ACACC0155R_ACACC0155R
                    (SELECT MAX(mngclucode) mngclucode,
                            '' mngcluval,
                            '' mngcludec,
                            '1000-00-01' slipdate,
                            '' slipnum,
                            '' remark,
                            SUM(debamt),
                            SUM(creamt),
                            SUM(creamt) - SUM(debamt) fnamt
                     FROM    VGT.TT_ACACC0155R_ACACC0155R);
            END IF;

            OPEN IO_CURSOR FOR
                SELECT     mngclucode mngclucode,
                         mngcluval mngcluval,
                         mngcludec mngcludec,
                         (CASE SUBSTR(slipdate, -5, 5) WHEN '90-99' THEN '이월' WHEN '99-99' THEN '누계' ELSE slipdate END) slipdate,
                         slipdate slipdate2,
                         slipnum slipnum,
                         remark remark,
                         NVL(debamt, 0) debamt,
                         NVL(creamt, 0) creamt,
                         (CASE SUBSTR(slipdate, -5, 5) WHEN '90-99' THEN 0 ELSE NVL(fnamt, 0) END) fnamt
                FROM     VGT.TT_ACACC0155R_ACACC0155R A
                ORDER BY slipdate2, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9') ,slipnum;
        ELSE
            OPEN IO_CURSOR FOR
                SELECT     mngclucode mngclucode,
                         mngcluval mngcluval,
                         mngcludec mngcludec,
                         (CASE SUBSTR(slipdate, -5, 5) WHEN '00-00' THEN '이월' WHEN '90-99' THEN '월계' WHEN '99-99' THEN '누계' ELSE slipdate END) slipdate,
                         slipdate slipdate2,
                         slipnum slipnum,
                         remark remark,
                         NVL(debamt, 0) debamt,
                         NVL(creamt, 0) creamt,
                         (CASE SUBSTR(slipdate, -5, 5) WHEN '90-99' THEN 0 ELSE NVL(fnamt, 0) END) fnamt
                FROM     VGT.TT_ACACC0155R_ACACC0155R A
                ORDER BY slipdate2, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9') ,slipnum;
        END IF;
    ELSIF (p_div = 'S1')
    THEN
        -- 관리항목구분코드, 관리항목명, 전표일자, 전표번호, 적요, 차대변금액, 잔액
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 출력구분 [K-GAAP, IFRS]
        -- 관리항목코드
        -- 관리항목명
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 차변금액
        -- 대변금액
        -- K-GAAP <> 'F', IFRS <> 'K'
        -- 관리항목코드
        -- 관리항목명
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 차변금액
        -- 대변금액
        -- K-GAAP <> 'F', IFRS <> 'K'
        --월계
        -- 관리항목코드
        -- 관리항목명
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 차변금액
        -- 대변금액
        -- 관리항목코드
        -- 관리항목명
        -- 전표일자
        -- 전표번호
        -- 적요
        -- 차변금액
        -- 대변금액

        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0155R_ACacc0155R1 ';



        IF p_fnamt IS NULL
        THEN
            p_fnamt := 0;
        END IF;

        OPEN spsl_cursor1 FOR
            SELECT     mngclucode,
                     mngcluval,
                     mngcludec,
                     slipdate,
                     slipnum,
                     remark,
                     debamt,
                     creamt
            FROM     (SELECT   mngclucode mngclucode,
                               '' mngcluval,
                               '' mngcludec,
                               '1000-00-00' slipdate,
                               '' slipnum,
                               '' remark,
                               SUM(debamt) debamt,
                               SUM(creamt) creamt
                      FROM       (SELECT '' mngclucode,
                                       '' mngcluval,
                                       '' mngcludec,
                                       '이월' slipdate,
                                       '' slipnum,
                                       '' remark,
                                       NVL(bsdebamt, 0) debamt,
                                       NVL(bscreamt, 0) creamt
                                FROM   ACORDDMM
                                WHERE  compcode = p_compcode
                                       AND plantcode LIKE p_plantcode
                                       AND slipym = SUBSTR(p_startdt, 0, 7)
                                       AND (closediv = '10'
                                            OR closediv = p_odiv1)
                                       AND acccode = p_acccode
                                UNION ALL
                                SELECT '' mngclucode,
                                       '' mngcluval,
                                       '' mngcludec,
                                       A.slipdate slipdate,
                                       A.slipnum slipnum,
                                       A.remark1 remark,
                                       NVL(A.debamt, 0) debamt,
                                       NVL(A.creamt, 0) creamt
                                FROM   ACORDD A, ACORDM c
                                WHERE  A.compcode = p_compcode
                                       AND A.plantcode LIKE p_plantcode
                                       AND A.acccode = p_acccode
                                       AND NVL(A.slipdate, ' ') < p_startdt
                                       AND NVL(A.slipdate, ' ') >= SUBSTR(p_startdt, 1, 7) || '-01'
                                       AND A.compcode = c.compcode
                                       AND A.plantcode = c.plantcode
                                       AND A.slipinno = c.slipinno
                                       AND c.slipdiv <> p_odiv2
                                       AND c.slipinstate = '4') A
                      GROUP BY mngclucode
                      UNION ALL
                      SELECT '' mngclucode,
                             '' mngcluval,
                             '' mngcludec,
                             A.slipdate slipdate,
                             A.slipnum slipnum,
                             A.remark1 remark,
                             NVL(A.debamt, 0) debamt,
                             NVL(A.creamt, 0) creamt
                      FROM     ACORDD A, ACORDM c
                      WHERE  A.compcode = p_compcode
                             AND A.plantcode LIKE p_plantcode
                             AND A.slipdate BETWEEN p_startdt AND p_enddt
                             AND A.acccode = p_acccode
                             AND A.compcode = c.compcode
                             AND A.plantcode = c.plantcode
                             AND A.slipinno = c.slipinno
                             AND c.slipdiv <> p_odiv2
                             AND c.slipinstate = '4'
                      UNION ALL
                      SELECT   mngclucode mngclucode,
                               '' mngcluval,
                               '' mngcludec,
                               slipdate slipdate,
                               '' slipnum,
                               '' remark,
                               SUM(A.debamt) debamt,
                               SUM(A.creamt) creamt
                      FROM       (SELECT '' mngclucode,
                                       '' mngcluval,
                                       '' mngcludec,
                                       SUBSTR(A.slipdate, 0, 7) || '-90-99' slipdate,
                                       '' slipnum,
                                       '' remark,
                                       debamt,
                                       creamt
                                FROM   ACORDD A
                                       JOIN ACORDM c
                                           ON A.compcode = c.compcode
                                              AND A.plantcode = c.plantcode
                                              AND A.slipinno = c.slipinno
                                WHERE  A.compcode = p_compcode
                                       AND A.plantcode LIKE p_plantcode
                                       AND acccode = p_acccode
                                       AND A.slipdate BETWEEN p_startdt AND p_enddt
                                       AND A.acccode = p_acccode
                                       AND c.slipinstate = '4') A
                      GROUP BY A.mngclucode, slipdate) A
            ORDER BY slipdate, REPLACE(slipnum, 'C', p_colview);

        -- @fnamt 나중에 이월의 잔액을 넣어줘야함.
        LOOP
            FETCH spsl_cursor1
                INTO ip_mngclucode, p_mngcluval, p_mngcludec, p_slipdate, p_slipnum, p_remark, p_debamt, p_creamt;

            EXIT WHEN spsl_cursor1%NOTFOUND;

            IF (SUBSTR(p_slipdate, -2, 2) <> '99')
            THEN
                IF (p_dcdiv = '1')
                THEN
                    p_fnamt := NVL(p_fnamt, 0) + NVL(p_debamt, 0) - NVL(p_creamt, 0);
                ELSIF (p_dcdiv = '2')
                THEN
                    p_fnamt := NVL(p_fnamt, 0) + NVL(p_creamt, 0) - NVL(p_debamt, 0);
                END IF;
            END IF;

            INSERT INTO VGT.TT_ACACC0155R_ACacc0155R1
            VALUES        (ip_mngclucode,
                         p_mngcluval,
                         p_mngcludec,
                         p_slipdate,
                         p_slipnum,
                         p_remark,
                         p_debamt,
                         p_creamt,
                         p_fnamt);

            IF (SUBSTR(p_slipdate, -5, 5) = '90-99')
            THEN
                IF (p_dcdiv = '1')
                THEN
                    INSERT INTO VGT.TT_ACACC0155R_ACacc0155R1
                        (SELECT ip_mngclucode,
                                '',
                                '',
                                SUBSTR(p_slipdate, 0, 7) || '-99-99',
                                '' slipnum,
                                '' remark,
                                SUM(debamt) debamt,
                                SUM(creamt) creamt,
                                SUM(debamt) - SUM(creamt) fnamt
                         FROM    VGT.TT_ACACC0155R_ACacc0155R1
                         WHERE    NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                                AND slipdate BETWEEN '1000-00-00' AND p_slipdate);
                ELSIF (p_dcdiv = '2')
                THEN
                    INSERT INTO VGT.TT_ACACC0155R_ACacc0155R1
                        (SELECT ip_mngclucode,
                                '',
                                '',
                                SUBSTR(p_slipdate, 0, 7) || '-99-99',
                                '',
                                '',
                                SUM(debamt) debamt,
                                SUM(creamt) creamt,
                                SUM(creamt) - SUM(debamt) fnamt
                         FROM    VGT.TT_ACACC0155R_ACacc0155R1
                         WHERE    NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                                AND slipdate BETWEEN '1000-00-00' AND p_slipdate);
                END IF;
            END IF;
        END LOOP;

        CLOSE spsl_cursor1;

        FOR rec IN (SELECT COUNT(*) AS alias1 FROM VGT.TT_ACACC0155R_ACacc0155R1)
        LOOP
            p_rows := rec.alias1;
        END LOOP;

        IF (p_rows = 1)
        THEN
            IF (p_dcdiv = '1')
            THEN
                INSERT INTO VGT.TT_ACACC0155R_ACacc0155R1
                    (SELECT MAX(mngclucode) mngclucode,
                            '' mngcluval,
                            '' mngcludec,
                            '1000-99-99' slipdate,
                            '' slipnum,
                            '' remark,
                            SUM(debamt),
                            SUM(creamt),
                            SUM(debamt) - SUM(creamt) fnamt
                     FROM    VGT.TT_ACACC0155R_ACacc0155R1);
            ELSIF (p_dcdiv = '2')
            THEN
                INSERT INTO VGT.TT_ACACC0155R_ACacc0155R1
                    (SELECT MAX(mngclucode) mngclucode,
                            '' mngcluval,
                            '' mngcludec,
                            '1000-99-99' slipdate,
                            '' slipnum,
                            '' remark,
                            SUM(debamt),
                            SUM(creamt),
                            SUM(creamt) - SUM(debamt) fnamt
                     FROM    VGT.TT_ACACC0155R_ACacc0155R1);
            END IF;

            OPEN IO_CURSOR FOR
                SELECT     mngclucode mngclucode,
                         mngcluval mngcluval,
                         mngcludec mngcludec,
                         (CASE SUBSTR(slipdate, -5, 5) WHEN '00-00' THEN '이월' WHEN '90-99' THEN '월계' WHEN '99-99' THEN '누계' ELSE slipdate END) slipdate,
                         slipdate slipdate2,
                         slipnum slipnum,
                         remark remark,
                         NVL(debamt, 0) debamt,
                         NVL(creamt, 0) creamt,
                         (CASE SUBSTR(slipdate, -5, 5) WHEN '90-99' THEN 0 ELSE NVL(fnamt, 0) END) fnamt
                FROM     VGT.TT_ACACC0155R_ACacc0155R1 A
                ORDER BY slipdate2, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9') ,slipnum;
        ELSE
            OPEN IO_CURSOR FOR
                SELECT     mngclucode mngclucode,
                         mngcluval mngcluval,
                         mngcludec mngcludec,
                         (CASE SUBSTR(slipdate, -5, 5) WHEN '00-00' THEN '이월' WHEN '90-99' THEN '월계' WHEN '99-99' THEN '누계' ELSE slipdate END) slipdate,
                         slipdate slipdate2,
                         slipnum slipnum,
                         remark remark,
                         NVL(debamt, 0) debamt,
                         NVL(creamt, 0) creamt,
                         (CASE SUBSTR(slipdate, -5, 5) WHEN '90-99' THEN 0 ELSE NVL(fnamt, 0) END) fnamt
                FROM     VGT.TT_ACACC0155R_ACacc0155R1 A
                ORDER BY slipdate2, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9') ,slipnum;
        END IF;
    ELSIF (p_div = 'A1')
    THEN
        OPEN IO_CURSOR FOR
            SELECT     b.mngclucode keyfield, MAX(b.mngcluname) displayfield
            FROM     ACACCM A LEFT JOIN ACACCMNGM b ON A.acccode = b.acccode
            WHERE     A.acccode = p_acccode
            GROUP BY b.mngclucode
            ORDER BY keyfield;
    ELSIF (p_div = 'A2')
    THEN
        OPEN IO_CURSOR FOR
            SELECT A.mngclucode mngclucode, A.mngcluname mngcluname, A.mngcludiv mngcludiv, c.divname mngcludivnm, D.filter1 codeseek
            FROM   ACMNGM A --select * from ACMNGM
                   LEFT JOIN CMCOMMONM c
                       ON A.mngcludiv = c.divcode
                          AND c.cmmcode = 'AC12'
                   LEFT JOIN CMCOMMONM D
                       ON A.mngclucode = D.divcode
                          AND D.cmmcode = 'CMHL'
            WHERE  A.mngclucode = ip_mngclucode;
    ELSIF (p_div = 'A3')
    THEN
        OPEN IO_CURSOR FOR
            SELECT acccode, dcdiv
            FROM   ACACCM
            WHERE  acccode = p_acccode;
    ELSIF (p_div = 'RMK')
    THEN
        -- 코드헬프 검색
        OPEN IO_CURSOR FOR
            SELECT codehelp codehelp, -- 코드헬프번호
                   remark codermk -- 코드헬프비고
            FROM   ACMNGM
            WHERE  mngclucode = ip_mngclucode;
    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
