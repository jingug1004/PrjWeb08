CREATE PROCEDURE        spACacc0212R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0212R
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-10-08
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 이익잉여금처분계산서를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_rptdiv		IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '',
	p_basisym		IN	   VARCHAR2 DEFAULT '',
	p_viewyn		IN	   VARCHAR2 DEFAULT 'Y',
	p_pretype		IN	   VARCHAR2 DEFAULT '1',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	IO_CURSOR		   OUT TYPES.DataSet,
	MESSAGE 		   OUT VARCHAR2
)
AS
	ip_basisym	  VARCHAR2(7) := p_basisym;
	p_basisyy	  VARCHAR2(4);
	p_beyymm	  VARCHAR2(7);
	p_yyyy01	  VARCHAR2(7);
	p_beyy01	  VARCHAR2(7);
	p_cashcode	  VARCHAR2(20);
	-- 임시테이블의 calcseq의 최대값을 조회
	p_maxseq	  NUMBER(10, 0);
	p_curseq	  NUMBER(10, 0);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S'
		OR p_div = 'P')
	THEN
		-- 기간 설정
		p_yyyy01 := SUBSTR(ip_basisym, 0, 4) || '-01';

		FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
					FROM   ACSESSION
					WHERE  compcode = p_compcode
						   AND cyear <= SUBSTR(ip_basisym, 0, 4))
		LOOP
			p_yyyy01 := rec.alias1;
		END LOOP;

		IF SUBSTR(ip_basisym, -2) < SUBSTR(p_yyyy01, -2)
		THEN
			p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(ip_basisym || '-01', 'YYYY-MM-DD'), -12), 'YYYY-') || SUBSTR(p_yyyy01, -2);
		ELSE
			p_yyyy01 := SUBSTR(ip_basisym, 0, 5) || SUBSTR(p_yyyy01, -2);
		END IF;

		IF p_pretype = '1'
		THEN
			p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(ip_basisym || '-01', 'YYYY-MM-DD'), -12), 'YYYY-MM');
		ELSIF p_pretype = '2'
			  OR p_pretype = '3'
				 AND SUBSTR(ip_basisym, -2) = SUBSTR(p_yyyy01, -2)
		THEN
			p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01 || '-01', 'YYYY-MM-DD'), -1), 'YYYY-MM');
		ELSE
			p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(ip_basisym || '-01', 'YYYY-MM-DD'), -1), 'YYYY-MM');
		END IF;

		IF p_pretype = '3'
		   AND SUBSTR(ip_basisym, -2, 2) <> SUBSTR(p_yyyy01, -2, 2)
		THEN
			p_beyy01 := p_yyyy01;
		ELSE
			p_beyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01 || '-01', 'YYYY-MM-DD'), -12), 'YYYY-MM');
		END IF;

		p_cashcode := '11101010';

		FOR rec IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'acccashcode')
		LOOP
			p_cashcode := rec.value1;
		END LOOP;

		-- 보고서 조회년도 설정
		FOR rec IN (SELECT MAX(rptyear) AS alias1
					FROM   ACRPTM
					WHERE  compcode = p_compcode
						   AND rptdiv = p_rptdiv
						   AND rptyear <= SUBSTR(ip_basisym, 0, 4))
		LOOP
			p_basisyy := rec.alias1;
		END LOOP;

		p_yyyy01 := CASE WHEN p_yyyy01 IS NOT NULL THEN TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01 || '-01', 'YYYY-MM-DD'), 3), 'YYYY-MM') ELSE NULL END;
		ip_basisym := CASE WHEN ip_basisym IS NOT NULL THEN TO_CHAR(ADD_MONTHS(TO_DATE(ip_basisym || '-01', 'YYYY-MM-DD'), 3), 'YYYY-MM') ELSE NULL END;
		p_beyy01 := CASE WHEN p_beyy01 IS NOT NULL THEN TO_CHAR(ADD_MONTHS(TO_DATE(p_beyy01 || '-01', 'YYYY-MM-DD'), 3), 'YYYY-MM') ELSE NULL END;
		p_beyymm := CASE WHEN p_beyymm IS NOT NULL THEN TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm || '-01', 'YYYY-MM-DD'), 3), 'YYYY-MM') ELSE NULL END;

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0212R_ACORDDMM';

		-- 전표에서 월집계 임시파일을 생성
		INSERT INTO VGT.TT_ACACC0212R_ACORDDMM
			SELECT	 p_compcode compcode,
					 p_plantcode plantcode,
					 ip_basisym slipym,
					 CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
					 acccode,
					 SUM(totdebamt) totdebamt,
					 SUM(totcreamt) totcreamt
			FROM	 (SELECT b.acccode,
							 b.debamt totdebamt,
							 b.creamt totcreamt
					  FROM	 ACORDM a
							 JOIN ACORDD b
								 ON a.compcode = b.compcode
									AND a.slipinno = b.slipinno
					  WHERE  a.compcode = p_compcode
							 AND a.plantcode LIKE p_plantcode
							 AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(ip_basisym || '-01', 'YYYY-MM-DD'), 1), 'YYYYMM')
							 AND a.slipinstate = '4'
							 AND (a.slipdiv NOT IN ('K', 'F')
								  OR p_closediv = '1'
									 AND a.slipdiv = 'K'
								  OR p_closediv = '2'
									 AND a.slipdiv = 'F')
					  UNION ALL
					  SELECT p_cashcode acccode,
							 b.creamt totdebamt,
							 b.debamt totcreamt
					  FROM	 ACORDM a
							 JOIN ACORDD b
								 ON a.compcode = b.compcode
									AND a.slipinno = b.slipinno
									AND b.dcdiv IN ('3', '4')
					  WHERE  a.compcode = p_compcode
							 AND a.plantcode LIKE p_plantcode
							 AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(ip_basisym || '-01', 'YYYY-MM-DD'), 1), 'YYYYMM')
							 AND a.slipinstate = '4'
							 AND (a.slipdiv NOT IN ('K', 'F')
								  OR p_closediv = '1'
									 AND a.slipdiv = 'K'
								  OR p_closediv = '2'
									 AND a.slipdiv = 'F')
					  UNION ALL
					  SELECT acccode,
							 bsdebamt totdebamt,
							 bscreamt totcreamt
					  FROM	 ACORDDMM
					  WHERE  compcode = p_compcode
							 AND plantcode LIKE p_plantcode
							 AND slipym = p_yyyy01
							 AND (p_closediv = '1'
								  AND closediv IN ('10', '20')
								  OR p_closediv = '2'
									 AND closediv IN ('10', '30'))) a
			GROUP BY acccode;


		INSERT INTO VGT.TT_ACACC0212R_ACORDDMM
			SELECT	 p_compcode compcode,
					 p_plantcode plantcode,
					 p_beyymm slipym,
					 CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
					 acccode,
					 SUM(totdebamt) totdebamt,
					 SUM(totcreamt) totcreamt
			FROM	 (SELECT b.acccode,
							 b.debamt totdebamt,
							 b.creamt totcreamt
					  FROM	 ACORDM a
							 JOIN ACORDD b
								 ON a.compcode = b.compcode
									AND a.slipinno = b.slipinno
					  WHERE  a.compcode = p_compcode
							 AND a.plantcode LIKE p_plantcode
							 AND a.slipno BETWEEN REPLACE(p_beyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYYMM')
							 AND a.slipinstate = '4'
							 AND (a.slipdiv NOT IN ('K', 'F')
								  OR p_closediv = '1'
									 AND a.slipdiv = 'K'
								  OR p_closediv = '2'
									 AND a.slipdiv = 'F')
					  UNION ALL
					  SELECT p_cashcode acccode,
							 b.creamt totdebamt,
							 b.debamt totcreamt
					  FROM	 ACORDM a
							 JOIN ACORDD b
								 ON a.compcode = b.compcode
									AND a.slipinno = b.slipinno
									AND b.dcdiv IN ('3', '4')
					  WHERE  a.compcode = p_compcode
							 AND a.plantcode LIKE p_plantcode
							 AND a.slipno BETWEEN REPLACE(p_beyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYYMM')
							 AND a.slipinstate = '4'
							 AND (a.slipdiv NOT IN ('K', 'F')
								  OR p_closediv = '1'
									 AND a.slipdiv = 'K'
								  OR p_closediv = '2'
									 AND a.slipdiv = 'F')
					  UNION ALL
					  SELECT acccode,
							 bsdebamt totdebamt,
							 bscreamt totcreamt
					  FROM	 ACORDDMM
					  WHERE  compcode = p_compcode
							 AND plantcode LIKE p_plantcode
							 AND slipym = p_beyy01
							 AND (p_closediv = '1'
								  AND closediv IN ('10', '20')
								  OR p_closediv = '2'
									 AND closediv IN ('10', '30'))) a
			GROUP BY acccode;

		-- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0212R_ACC212A  ';

		INSERT INTO VGT.TT_ACACC0212R_ACC212A(seqline,
											  acccode,
											  accrname,
											  acckname,
											  lrdiv,
											  prtyn,
											  prtdiv,
											  prtbold,
											  sseqline,
											  calcseq,
											  calcdiv,
											  cseqline,
											  cgb,
											  objdatadiv,
											  amt,
											  beamt)
			SELECT	 a.seqline,
					 MAX(a.acccode),
					 MAX(a.accrname),
					 MAX(a.acckname),
					 MAX(a.lrdiv),
					 MAX(a.prtyn),
					 MAX(a.prtdiv),
					 MAX(a.prtbold),
					 MAX(a.sseqline),
					 MAX(a.calcseq),
					 MAX(a.calcdiv),
					 MAX(a.cseqline),
					 '1',
					 MAX(a.objdatadiv),
					 NVL(SUM(CASE WHEN c.slipym = ip_basisym THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END END), 0)
						 amt2,
					 NVL(SUM(CASE WHEN c.slipym = p_beyymm THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END END), 0)
						 amt4
			FROM	 ACRPTM a
					 LEFT JOIN ACACCM b ON NVL(a.acccode, ' ') = NVL(b.acccode, ' ')
					 LEFT JOIN VGT.TT_ACACC0212R_ACORDDMM c
						 ON a.compcode = c.compcode
							AND c.plantcode LIKE p_plantcode
							AND c.slipym IN (ip_basisym, p_beyymm)
							AND (p_closediv = '1'
								 AND c.closediv IN ('10', '20')
								 OR p_closediv = '2'
									AND c.closediv IN ('10', '30'))
							AND NVL(a.acccode, ' ') = NVL(c.acccode, ' ')
			WHERE	 a.compcode = p_compcode
					 AND a.rptdiv = p_rptdiv
					 AND a.rptyear = p_basisyy
					 AND a.useyn = 'Y'
			GROUP BY a.seqline
			ORDER BY a.seqline;


		-- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
		MERGE INTO VGT.TT_ACACC0212R_ACC212A TG
		USING	   (SELECT a.lrdiv,
						   a.prtdiv,
						   a.calcdiv,
						   a.objdatadiv,
						   a.seqline,
						   a.acccode,
						   a.sseqline,
						   a.cseqline,
						   a.accrname,
						   a.acckname,
						   a.prtyn,
						   a.prtbold,
						   a.calcseq,
						   a.cgb,
						   a.amt,
						   a.calcamt,
						   a.beamt,
						   a.becalcamt,
						   CASE WHEN a.objdatadiv = 'A' THEN b.amt ELSE a.amt - b.amt END AS pos_2,
						   CASE WHEN a.objdatadiv = 'A' THEN b.beamt ELSE a.beamt - b.beamt END AS pos_3
					FROM   VGT.TT_ACACC0212R_ACC212A a
						   JOIN
						   (SELECT	 a.seqline,
									 NVL(SUM(CASE WHEN c.slipym = p_yyyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) amt,
									 NVL(SUM(CASE WHEN c.slipym = p_beyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) beamt
							FROM	 ACRPTM a
									 LEFT JOIN ACACCM b ON NVL(a.acccode, ' ') = NVL(b.acccode, ' ')
									 LEFT JOIN ACORDDMM c
										 ON a.compcode = c.compcode
											AND c.plantcode LIKE p_plantcode
											AND c.slipym IN (p_yyyy01, p_beyy01)
											AND (p_closediv = '1'
												 AND c.closediv IN ('10', '20')
												 OR p_closediv = '2'
													AND c.closediv IN ('10', '30'))
											AND NVL(a.acccode, ' ') = NVL(c.acccode, ' ')
							WHERE	 a.compcode = p_compcode
									 AND a.rptdiv = p_rptdiv
									 AND a.rptyear = p_basisyy
									 AND a.useyn = 'Y'
									 AND a.objdatadiv IN ('A', 'E', 'F')
							GROUP BY a.seqline) b
							   ON (NVL(a.seqline, ' ') = NVL(b.seqline, ' '))) SRC
		ON		   (NVL(tg.lrdiv, ' ') = NVL(src.lrdiv, ' ')
					AND NVL(tg.prtdiv, ' ') = NVL(src.prtdiv, ' ')
					AND NVL(tg.calcdiv, ' ') = NVL(src.calcdiv, ' ')
					AND NVL(tg.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
					AND NVL(tg.seqline, ' ') = NVL(src.seqline, ' ')
					AND NVL(tg.acccode, ' ') = NVL(src.acccode, ' ')
					AND NVL(tg.sseqline, ' ') = NVL(src.sseqline, ' ')
					AND NVL(tg.cseqline, ' ') = NVL(src.cseqline, ' ')
					AND NVL(tg.accrname, ' ') = NVL(src.accrname, ' ')
					AND NVL(tg.acckname, ' ') = NVL(src.acckname, ' ')
					AND NVL(tg.prtyn, ' ') = NVL(src.prtyn, ' ')
					AND NVL(tg.prtbold, ' ') = NVL(src.prtbold, ' ')
					AND NVL(tg.calcseq, 0) = NVL(src.calcseq, 0)
					AND NVL(tg.cgb, 0) = NVL(src.cgb, 0)
					AND NVL(tg.calcamt, 0) = NVL(src.calcamt, 0)
					AND NVL(tg.becalcamt, 0) = NVL(src.becalcamt, 0))
		WHEN MATCHED
		THEN
			UPDATE SET TG.amt = SRC.pos_2, TG.beamt = SRC.pos_3;

		p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01 || '-01', 'YYYY-MM-DD'), -3), 'YYYY-MM');
		ip_basisym := TO_CHAR(ADD_MONTHS(TO_DATE(ip_basisym || '-01', 'YYYY-MM-DD'), -3), 'YYYY-MM');
		p_beyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_beyy01 || '-01', 'YYYY-MM-DD'), -3), 'YYYY-MM');
		p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm || '-01', 'YYYY-MM-DD'), -3), 'YYYY-MM');

		-- 당기순이익을 구함
		spACacc0208R(p_div => 'S',
					 p_compcode => p_compcode,
					 p_plantcode => p_plantcode,
					 p_rptdiv => '5',
					 p_closediv => p_closediv,
					 p_basisym => ip_basisym,
					 p_viewyn => 'N',
					 p_pretype => p_pretype,
					 MESSAGE => MESSAGE,
					 IO_CURSOR => IO_CURSOR);

		IF MESSAGE <> '데이터 확인'
		THEN
			MERGE INTO VGT.TT_ACACC0212R_ACC212A TG
			USING	   (SELECT a.lrdiv,
							   a.prtdiv,
							   a.calcdiv,
							   a.objdatadiv,
							   a.seqline,
							   a.acccode,
							   a.sseqline,
							   a.cseqline,
							   a.accrname,
							   a.acckname,
							   a.prtyn,
							   a.prtbold,
							   a.calcseq,
							   a.cgb,
							   a.amt,
							   a.calcamt,
							   a.beamt,
							   a.becalcamt,
							   B.compcode,
							   B.rptdiv,
							   B.rptyear,
							   NVL(SUBSTR(MESSAGE, 0, INSTR(MESSAGE, ';') - 1), 0) AS pos_2,
							   NVL(SUBSTR(MESSAGE, -(LENGTH(MESSAGE) - INSTR(MESSAGE, ';'))), 0) AS pos_3
						FROM   VGT.TT_ACACC0212R_ACC212A a
							   JOIN ACRPTM b
								   ON b.compcode = p_compcode
									  AND b.rptdiv = p_rptdiv
									  AND b.rptyear = p_basisyy
									  AND a.seqline = b.seqline
						WHERE  b.remark = '당기순이익') src
			ON		   (NVL(TG.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(TG.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(TG.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(TG.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
						AND NVL(TG.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(TG.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(TG.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(TG.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
						AND NVL(TG.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(TG.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(TG.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(TG.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
						AND NVL(TG.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(TG.CGB, 0) = NVL(SRC.CGB, 0)
						AND NVL(TG.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
						AND NVL(TG.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
			WHEN MATCHED
			THEN
				UPDATE SET TG.amt = pos_2, TG.beamt = pos_3;
		END IF;

		p_curseq := 0;

		FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0212R_ACC212A)
		LOOP
			p_maxseq := rec.alias1;
		END LOOP;

		-- 각 레벨별로 sum을하여 update
		WHILE p_curseq <= p_maxseq
		LOOP
			MERGE INTO VGT.TT_ACACC0212R_ACC212A TG
			USING	   (SELECT a.lrdiv,
							   a.prtdiv,
							   a.calcdiv,
							   a.objdatadiv,
							   a.seqline,
							   a.acccode,
							   a.sseqline,
							   a.cseqline,
							   a.accrname,
							   a.acckname,
							   a.prtyn,
							   a.prtbold,
							   a.calcseq,
							   a.cgb,
							   a.amt,
							   a.calcamt,
							   a.beamt,
							   a.becalcamt,
							   a.amt + b.amt AS pos_2,
							   a.beamt + b.beamt AS pos_3
						FROM   VGT.TT_ACACC0212R_ACC212A a
							   JOIN (SELECT   sseqline,
											  SUM(CASE WHEN calcdiv = '+' THEN amt ELSE amt * -1 END) amt,
											  SUM(CASE WHEN calcdiv = '+' THEN beamt ELSE beamt * -1 END) beamt
									 FROM	  VGT.TT_ACACC0212R_ACC212A
									 WHERE	  calcseq = p_curseq
											  AND TRIM(sseqline) IS NOT NULL
									 GROUP BY sseqline) b
								   ON a.seqline = b.sseqline) src
			ON		   (NVL(TG.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(TG.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(TG.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(TG.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
						AND NVL(TG.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(TG.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(TG.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(TG.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
						AND NVL(TG.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(TG.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(TG.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(TG.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
						AND NVL(TG.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(TG.CGB, 0) = NVL(SRC.CGB, 0)
						AND NVL(TG.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
						AND NVL(TG.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
			WHEN MATCHED
			THEN
				UPDATE SET TG.amt = SRC.pos_2, TG.beamt = SRC.pos_3;

			p_curseq := p_curseq + 1;
		END LOOP;

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0212R_ACC212B  ';

		INSERT INTO VGT.TT_ACACC0212R_ACC212B
			SELECT	 a.cseqline,
					 a.seqline,
					 a.amt,
					 a.beamt,
					 0,
					 0,
					 b.amt,
					 b.beamt,
					 0,
					 ROWNUM RN
			FROM	 VGT.TT_ACACC0212R_ACC212A a JOIN VGT.TT_ACACC0212R_ACC212A b ON a.cseqline = b.seqline
			WHERE	 (a.amt <> 0
					  OR a.beamt <> 0)
			ORDER BY a.cseqline, a.seqline DESC;


		MERGE INTO VGT.TT_ACACC0212R_ACC212B TG
		USING	   (SELECT a.cseqline,
						   a.seqline,
						   a.num,
						   a.ord,
						   a.amt,
						   a.beamt,
						   a.amt2,
						   a.beamt2,
						   a.amt3,
						   a.beamt3,
						   a.ord - b.minNo + 1 AS pos_2
					FROM   VGT.TT_ACACC0212R_ACC212B a
						   JOIN (SELECT   cseqline,
										  MIN(ord) minNo
								 FROM	  VGT.TT_ACACC0212R_ACC212B N
								 GROUP BY N.cseqline) b
							   ON a.cseqline = b.cseqline) src
		ON		   (NVL(tg.cseqline, ' ') = NVL(src.cseqline, ' ')
					AND NVL(tg.seqline, ' ') = NVL(src.seqline, ' ')
					AND NVL(tg.ord, 0) = NVL(src.ord, 0)
					AND NVL(tg.amt, 0) = NVL(src.amt, 0)
					AND NVL(tg.beamt, 0) = NVL(src.beamt, 0)
					AND NVL(tg.amt3, 0) = NVL(src.amt3, 0)
					AND NVL(tg.beamt3, 0) = NVL(src.beamt3, 0))
		WHEN MATCHED
		THEN
			UPDATE SET TG.num = SRC.pos_2, TG.amt2 = 0, TG.beamt2 = 0;

		MERGE INTO VGT.TT_ACACC0212R_ACC212B TG
		USING	   (SELECT a.cseqline,
						   a.seqline,
						   a.num,
						   a.ord,
						   a.amt,
						   a.beamt,
						   a.amt2,
						   a.beamt2,
						   a.amt3,
						   a.beamt3,
						   b.amt amtB,
						   b.beamt beamtB
					FROM   VGT.TT_ACACC0212R_ACC212B a
						   JOIN (SELECT   cseqline,
										  SUM(amt) amt,
										  SUM(beamt) beamt
								 FROM	  VGT.TT_ACACC0212R_ACC212B
								 GROUP BY cseqline) b
							   ON a.cseqline = b.cseqline
								  AND num = 1) src
		ON		   (NVL(tg.cseqline, ' ') = NVL(src.cseqline, ' ')
					AND NVL(tg.seqline, ' ') = NVL(src.seqline, ' ')
					AND NVL(tg.num, 0) = NVL(src.num, 0)
					AND NVL(tg.ord, 0) = NVL(src.ord, 0)
					AND NVL(tg.amt, 0) = NVL(src.amt, 0)
					AND NVL(tg.beamt, 0) = NVL(src.beamt, 0)
					AND NVL(tg.amt3, 0) = NVL(src.amt3, 0)
					AND NVL(tg.beamt3, 0) = NVL(src.beamt3, 0))
		WHEN MATCHED
		THEN
			UPDATE SET tg.amt2 = src.amtB, tg.beamt2 = src.beamtB;

		MERGE INTO VGT.TT_ACACC0212R_ACC212A TG
		USING	   (SELECT a.lrdiv,
						   a.prtdiv,
						   a.calcdiv,
						   a.objdatadiv,
						   a.seqline,
						   a.acccode,
						   a.sseqline,
						   a.cseqline,
						   a.accrname,
						   a.acckname,
						   a.prtyn,
						   a.prtbold,
						   a.calcseq,
						   a.cgb,
						   a.amt,
						   a.calcamt,
						   a.beamt,
						   a.becalcamt
					FROM   VGT.TT_ACACC0212R_ACC212A a
						   JOIN (SELECT DISTINCT cseqline FROM VGT.TT_ACACC0212R_ACC212B
								 UNION
								 SELECT seqline FROM VGT.TT_ACACC0212R_ACC212B) b
							   ON a.seqline = b.cseqline) src
		ON		   (NVL(tg.prtdiv, ' ') = NVL(src.prtdiv, ' ')
					AND NVL(tg.calcdiv, ' ') = NVL(src.calcdiv, ' ')
					AND NVL(tg.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
					AND NVL(tg.seqline, ' ') = NVL(src.seqline, ' ')
					AND NVL(tg.acccode, ' ') = NVL(src.acccode, ' ')
					AND NVL(tg.sseqline, ' ') = NVL(src.sseqline, ' ')
					AND NVL(tg.cseqline, ' ') = NVL(src.cseqline, ' ')
					AND NVL(tg.accrname, ' ') = NVL(src.accrname, ' ')
					AND NVL(tg.acckname, ' ') = NVL(src.acckname, ' ')
					AND NVL(tg.prtyn, ' ') = NVL(src.prtyn, ' ')
					AND NVL(tg.prtbold, ' ') = NVL(src.prtbold, ' ')
					AND NVL(tg.calcseq, 0) = NVL(src.calcseq, 0)
					AND NVL(tg.cgb, 0) = NVL(src.cgb, 0)
					AND NVL(tg.amt, 0) = NVL(src.amt, 0)
					AND NVL(tg.calcamt, 0) = NVL(src.calcamt, 0)
					AND NVL(tg.beamt, 0) = NVL(src.beamt, 0)
					AND NVL(tg.becalcamt, 0) = NVL(src.becalcamt, 0))
		WHEN MATCHED
		THEN
			UPDATE SET tg.lrdiv = 'L';


		MERGE INTO VGT.TT_ACACC0212R_ACC212A TG
		USING	   (SELECT a.lrdiv,
						   a.prtdiv,
						   a.calcdiv,
						   a.objdatadiv,
						   a.seqline,
						   a.acccode,
						   a.sseqline,
						   a.cseqline,
						   a.accrname,
						   a.acckname,
						   a.prtyn,
						   a.prtbold,
						   a.calcseq,
						   a.cgb,
						   a.amt,
						   a.calcamt,
						   a.beamt,
						   a.becalcamt,
						   b.amt3 - amt2 AS pos_2,
						   b.beamt3 - beamt2 AS pos_3
					FROM   VGT.TT_ACACC0212R_ACC212A a
						   JOIN (SELECT seqline,
										amt2,
										amt3,
										beamt2,
										beamt3
								 FROM	VGT.TT_ACACC0212R_ACC212B
								 WHERE	num = 1) b
							   ON a.seqline = b.seqline) src
		ON		   (NVL(tg.lrdiv, ' ') = NVL(src.lrdiv, ' ')
					AND NVL(tg.prtdiv, ' ') = NVL(src.prtdiv, ' ')
					AND NVL(tg.calcdiv, ' ') = NVL(src.calcdiv, ' ')
					AND NVL(tg.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
					AND NVL(tg.seqline, ' ') = NVL(src.seqline, ' ')
					AND NVL(tg.acccode, ' ') = NVL(src.acccode, ' ')
					AND NVL(tg.sseqline, ' ') = NVL(src.sseqline, ' ')
					AND NVL(tg.cseqline, ' ') = NVL(src.cseqline, ' ')
					AND NVL(tg.accrname, ' ') = NVL(src.accrname, ' ')
					AND NVL(tg.acckname, ' ') = NVL(src.acckname, ' ')
					AND NVL(tg.prtyn, ' ') = NVL(src.prtyn, ' ')
					AND NVL(tg.prtbold, ' ') = NVL(src.prtbold, ' ')
					AND NVL(tg.calcseq, 0) = NVL(src.calcseq, 0)
					AND NVL(tg.amt, 0) = NVL(src.amt, 0)
					AND NVL(tg.beamt, 0) = NVL(src.beamt, 0))
		WHEN MATCHED
		THEN
			UPDATE SET tg.calcamt = pos_2, tg.becalcamt = pos_3, tg.cgb = '2';

		-- 최종조회
		IF (p_div = 'P')
		THEN
			OPEN IO_CURSOR FOR
				SELECT NULLIF(CASE
								  WHEN a.lrdiv = 'L'
									   AND a.prtyn = 'Y'
								  THEN
									  a.amt
							  END,
							  0)
						   baldramt,
					   NULLIF(CASE
								  WHEN a.cgb = '2'
									   AND a.prtyn = 'Y'
								  THEN
									  a.calcamt
								  WHEN a.cgb <> '2'
									   AND a.lrdiv = 'R'
									   AND a.prtyn = 'Y'
								  THEN
									  a.amt
							  END,
							  0)
						   dramt,
					   NULL mondramt,
					   CASE WHEN a.amt >= 0 THEN a.accrname ELSE a.acckname END accname,
					   NULL moncramt,
					   NULLIF(CASE
								  WHEN a.lrdiv = 'L'
									   AND a.prtyn = 'Y'
								  THEN
									  a.beamt
							  END,
							  0)
						   cramt,
					   NULLIF(CASE
								  WHEN a.cgb = '2'
									   AND a.prtyn = 'Y'
								  THEN
									  a.becalcamt
								  WHEN a.cgb <> '2'
									   AND a.lrdiv = 'R'
									   AND a.prtyn = 'Y'
								  THEN
									  a.beamt
							  END,
							  0)
						   balcramt,
					   a.prtbold,
					   D.session1 || SUBSTR(ip_basisym, 0, 4) || '년  ' || SUBSTR(ip_basisym, 6, 2) || '월  ' || TO_CHAR(LAST_DAY(TO_DATE(ip_basisym || '-01', 'YYYY-MM-DD')), 'DD') || '일  현재' title1,
					   D.session2 || SUBSTR(p_beyymm, 0, 4) || '년  ' || SUBSTR(p_beyymm, 6, 2) || '월  ' || TO_CHAR(LAST_DAY(TO_DATE(p_beyymm || '-01', 'YYYY-MM-DD')), 'DD') || '일  현재' title2,
					   CASE WHEN p_plantcode = '%' THEN '회사명 : ' || b.compname ELSE '사업장명 : ' || NVL(NULLIF(c.plantfullname, ' '), c.plantname) END compname,
					   '(단위 : 원)' prtunit,
					   NULL baldramt2,
					   NULL dramt2,
					   NULL mondramt2,
					   NULL accname2,
					   NULL moncramt2,
					   NULL cramt2,
					   NULL balcramt2
				FROM   VGT.TT_ACACC0212R_ACC212A a
					   LEFT JOIN CMCOMPM b ON b.compcode = p_compcode
					   LEFT JOIN CMPLANTM c ON c.plantcode = p_plantcode
					   LEFT JOIN (SELECT MAX('제 ' || CASE WHEN cyear = SUBSTR(ip_basisym, 0, 4) THEN sseq END || '기  ') session1,
										 MAX('제 ' || CASE WHEN cyear = SUBSTR(p_beyymm, 0, 4) THEN sseq END || '기  ') session2
								  FROM	 ACSESSION
								  WHERE  compcode = p_compcode
										 AND cyear IN (SUBSTR(ip_basisym, 0, 4), SUBSTR(p_beyymm, 0, 4))) D
						   ON 1 = 1
				WHERE  a.prtdiv <> 'C'
					   AND (a.amt <> 0
							OR a.calcamt <> 0
							OR a.beamt <> 0
							OR a.becalcamt <> 0
							OR a.prtdiv = 'A');
		ELSIF (p_viewyn = 'Y')
		THEN
			OPEN IO_CURSOR FOR
				SELECT CASE WHEN amt >= 0 THEN accrname ELSE acckname END accname,
					   NULLIF(CASE
								  WHEN lrdiv = 'L'
									   AND prtyn = 'Y'
								  THEN
									  amt
							  END,
							  0)
						   amt1,
					   NULLIF(CASE
								  WHEN cgb = '2'
									   AND prtyn = 'Y'
								  THEN
									  calcamt
								  WHEN cgb <> '2'
									   AND lrdiv = 'R'
									   AND prtyn = 'Y'
								  THEN
									  amt
							  END,
							  0)
						   amt2,
					   NULLIF(CASE
								  WHEN lrdiv = 'L'
									   AND prtyn = 'Y'
								  THEN
									  beamt
							  END,
							  0)
						   amt3,
					   NULLIF(CASE
								  WHEN cgb = '2'
									   AND prtyn = 'Y'
								  THEN
									  becalcamt
								  WHEN cgb <> '2'
									   AND lrdiv = 'R'
									   AND prtyn = 'Y'
								  THEN
									  beamt
							  END,
							  0)
						   amt4,
               p_plantcode plantcode,
               p_yyyy01 || '-01' strdate,
               TO_CHAR(LAST_DAY(TO_DATE(p_basisym, 'YYYY-MM')), 'YYYY-MM-DD') enddate,
               acccode,
               p_closediv closediv,
               prtbold
				FROM   VGT.TT_ACACC0212R_ACC212A
				WHERE  prtdiv <> 'C'
					   AND (amt <> 0
							OR calcamt <> 0
							OR beamt <> 0
							OR becalcamt <> 0
							OR prtdiv = 'A');
		END IF;
	END IF;

	---------------------------------------------------------------------------
	FOR rec IN (SELECT NVL(amt, 0) || ';' || NVL(beamt, 0) AS alias1
				FROM   VGT.TT_ACACC0212R_ACC212A
				WHERE  seqline = (SELECT MAX(seqline) FROM VGT.TT_ACACC0212R_ACC212A))
	LOOP
		MESSAGE := rec.alias1;
	END LOOP;

	---------------------------------------------------------------------------
	IF (p_div = 'Y')
	THEN
		OPEN IO_CURSOR FOR
			SELECT *
			FROM   (SELECT	 CASE WHEN cyear = SUBSTR(ip_basisym, 0, 4) THEN TO_CHAR(sseq) ELSE TO_CHAR(sseq - cyear) || SUBSTR(ip_basisym, 0, 4) END sseq
					FROM	 ACSESSION
					WHERE	 compcode = p_compcode
							 AND cyear <= SUBSTR(ip_basisym, 0, 4)
					ORDER BY cyear DESC)
			WHERE  ROWNUM <= 1;
	END IF;

	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
