CREATE PROCEDURE        spACacc0228R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0228R
 -- 작 성 자         : 최용석
 -- 작성일자         : 2013-08-27
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-26
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 월별손익계산서를 조회하는 프로시저이다.
 -- ---------------------------------------------------------------

(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '' ,
    p_rptdiv        IN VARCHAR2 DEFAULT '' ,
    p_closediv      IN VARCHAR2 DEFAULT '' ,
    p_basisym       IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,

    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_yyyy01 VARCHAR2(7);

    p_cnt number := 0;

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( UPPER(p_div) = 'S' OR UPPER(p_div) = 'P' ) THEN

        -- 기간 설정
        p_yyyy01 := SUBSTR(p_basisym, 0, 4) || '-01' ;

        FOR  rec IN (   SELECT  SUBSTR(curstrdate, 0, 7)  AS alias1
                        FROM    ACSESSION
                        WHERE   compcode = p_compcode
                                AND cyear <= SUBSTR(p_basisym, 0, 4)
        )
        LOOP
            p_yyyy01 := rec.alias1 ;
        END LOOP;


        IF SUBSTR(p_basisym, -2, 2) < SUBSTR(p_yyyy01, -2, 2) THEN
            p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), -12), 'YYYY-') || SUBSTR(p_yyyy01, -2, 2) ;
        ELSE
            p_yyyy01 := SUBSTR(p_basisym, 0, 5) || SUBSTR(p_yyyy01, -2, 2) ;
        END IF;


        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0228R_DUAL';

        INSERT INTO VGT.TT_ACACC0228R_DUAL (
            SELECT  SUBSTR(p_yyyy01, 0, 5) || '00' ,
                    seqline ,
                    acccode ,
                    accrname ,
                    prtbold ,
                    NULLIF(CASE WHEN prtyn = 'Y' THEN amt END, 0) amt
            FROM    TABLE(fnMakeACRPTM2(p_compcode, p_plantcode, p_rptdiv, p_closediv, p_yyyy01, p_basisym))
            WHERE  prtdiv <> 'C'
            AND ( amt <> 0 OR prtdiv = 'A' )
        );

        WHILE ( p_yyyy01 <= p_basisym ) LOOP


            INSERT INTO VGT.TT_ACACC0228R_DUAL (
                SELECT
                        p_yyyy01 ,
                        seqline ,
                        acccode ,
                        accrname ,
                        prtbold ,
                        NULLIF(CASE WHEN prtyn = 'Y' THEN amt END, 0) amt
                FROM    TABLE(fnMakeACRPTM2(p_compcode, p_plantcode, p_rptdiv, p_closediv, p_yyyy01, p_yyyy01))
                WHERE   prtdiv <> 'C'
                        AND ( amt <> 0 OR prtdiv = 'A' )
            );


            p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01 || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM') ;

        END LOOP;




      -- 최종조회
      IF ( UPPER(p_div) = 'P' ) THEN

         OPEN  IO_CURSOR FOR

            SELECT  MAX(accname)  accname  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '00' THEN amt   END)  amt00  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '01' THEN amt   END)  amt01  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '02' THEN amt   END)  amt02  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '03' THEN amt   END)  amt03  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '04' THEN amt   END)  amt04  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '05' THEN amt   END)  amt05  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '06' THEN amt   END)  amt06  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '07' THEN amt   END)  amt07  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '08' THEN amt   END)  amt08  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '09' THEN amt   END)  amt09  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '10' THEN amt   END)  amt10  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '11' THEN amt   END)  amt11  ,
                    SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '12' THEN amt   END)  amt12  ,
                    p_plantcode plantcode  ,
                    SUBSTR(p_basisym, 0, 4) || '-01-01' strdate  ,
                    TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD') enddate ,
                    MAX(acccode)  acccode  ,
                    p_closediv closediv  ,
                    MAX(prtbold)  prtbold  ,
                    MAX(D.SESSIONS || SUBSTR(p_basisym, 0, 4) || '년  ' || SUBSTR(p_basisym, 6, 2) || '월  ' || SUBSTR(TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD'), -2, 2) || '일  현재')  title  ,
                    MAX(CASE WHEN p_plantcode = '%' THEN '회사명 : ' || b.compname
                             ELSE '사업장명 : ' || NVL(NULLIF(c.plantfullname, NULL), c.plantname)
                    END)  compname  ,
                    '(단위 : 원)' prtunit
            FROM    VGT.TT_ACACC0228R_DUAL A
                    LEFT JOIN CMCOMPM b   ON b.compcode = p_compcode
                    LEFT JOIN CMPLANTM c   ON c.plantcode = p_plantcode
                    LEFT JOIN ( SELECT  MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_basisym, 0, 4) THEN sseq END) || '기  ')  SESSIONS
                                FROM    ACSESSION
                                WHERE   compcode = p_compcode
                                        AND cyear = SUBSTR(p_basisym, 0, 4) ) D   ON 1 = 1
            GROUP BY A.seqline
            ORDER BY A.seqline ;


        ELSE


            OPEN  IO_CURSOR FOR

                SELECT  MAX(accname)  accname  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '00' THEN amt   END)  amt00  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '01' THEN amt   END)  amt01  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '02' THEN amt   END)  amt02  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '03' THEN amt   END)  amt03  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '04' THEN amt   END)  amt04  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '05' THEN amt   END)  amt05  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '06' THEN amt   END)  amt06  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '07' THEN amt   END)  amt07  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '08' THEN amt   END)  amt08  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '09' THEN amt   END)  amt09  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '10' THEN amt   END)  amt10  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '11' THEN amt   END)  amt11  ,
                        SUM(CASE WHEN SUBSTR(slipym, -2, 2) = '12' THEN amt   END)  amt12  ,
                        p_plantcode plantcode  ,
                        SUBSTR(p_basisym, 0, 4) || '-01-01' strdate  ,
                        TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), 1)-1 , 'YYYY-MM-DD') enddate  ,
                        MAX(acccode)  acccode  ,
                        p_closediv closediv  ,
                        MAX(prtbold)  prtbold
                FROM    VGT.TT_ACACC0228R_DUAL
                GROUP BY seqline
                ORDER BY seqline ;

        END IF;



    END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
