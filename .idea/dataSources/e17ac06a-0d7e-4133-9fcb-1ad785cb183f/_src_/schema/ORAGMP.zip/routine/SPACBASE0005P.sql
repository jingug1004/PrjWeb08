CREATE PROCEDURE        spACbase0005P
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACbase0005P
   -- 작 성 자         : 민승기
   -- 작성일자         : 2010-11-10
   -- 수정자          : 임 정호
   -- 수정일자         : 2016-12-12

   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 자동분개룰 마스터를 등록,수정,삭제,조회하는 프로시저이다.
   -- ---------------------------------------------------------------
   --select * from CMCOMMONM where cmmcode = 'AC94'
   --select * from ACAUTORULE
   --update ACAUTORULE
   --set crtdiv = '1'

(
   p_div             IN     VARCHAR2 DEFAULT '',
   p_acautorcode     IN     VARCHAR2 DEFAULT '',
   p_acautorname     IN     VARCHAR2 DEFAULT '',
   p_accdiv          IN     VARCHAR2 DEFAULT '',
   p_slipindate      IN     VARCHAR2 DEFAULT '',
   p_deptcode        IN     VARCHAR2 DEFAULT '',
   p_plantcode       IN     VARCHAR2 DEFAULT '',
   p_slipinstate     IN     VARCHAR2 DEFAULT '',
   p_remark          IN     VARCHAR2 DEFAULT '',
   p_remark1         IN     VARCHAR2 DEFAULT '',
   p_remark2         IN     VARCHAR2 DEFAULT '',
   p_slipdeptcode    IN     VARCHAR2 DEFAULT '',
   p_slipempcode     IN     VARCHAR2 DEFAULT '',
   p_skreqyn         IN     VARCHAR2 DEFAULT '',
   p_skreqdiv        IN     VARCHAR2 DEFAULT '',
   p_skreqdate       IN     VARCHAR2 DEFAULT '',
   p_skreqdeptcode   IN     VARCHAR2 DEFAULT '',
   p_skreqempcode    IN     VARCHAR2 DEFAULT '',
   p_accountno       IN     VARCHAR2 DEFAULT '',
   p_iempcode        IN     VARCHAR2 DEFAULT '',
   p_acautoseq       IN     NUMBER   DEFAULT 0,
   p_dcdiv           IN     VARCHAR2 DEFAULT '',
   p_acacccode       IN     VARCHAR2 DEFAULT '',
   p_amtdiv          IN     VARCHAR2 DEFAULT '+',
   p_accamtdiv       IN     VARCHAR2 DEFAULT '',
   p_acccalcdiv      IN     VARCHAR2 DEFAULT '',
   p_accsamtdiv      IN     VARCHAR2 DEFAULT '',
   p_mngclucode      IN     VARCHAR2 DEFAULT '',
   p_mngcluvaldiv    IN     VARCHAR2 DEFAULT '',
   p_mngcludecdiv    IN     VARCHAR2 DEFAULT '',
   p_crtdiv          IN     VARCHAR2 DEFAULT '',
   p_condition1      IN     VARCHAR2 DEFAULT '',
   p_condition2      IN     VARCHAR2 DEFAULT '',
   p_condition3      IN     VARCHAR2 DEFAULT '',
   p_userid          IN     VARCHAR2 DEFAULT '',
   p_reasondiv       IN     VARCHAR2 DEFAULT '',
   p_reasontext      IN     VARCHAR2 DEFAULT '',
   IO_CURSOR         OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2
)
AS
BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    IF (p_div = 'SM')    THEN

      OPEN IO_CURSOR FOR
         SELECT NVL (a.acautorcode, '') acautorcode,
                NVL (a.acautorname, '') acautorname,
                NVL (a.accdiv, '') accdiv,
                NVL (a.slipindate, '') slipindate,
                NVL (a.deptcode, '') deptcode,
                NVL (a.plantcode, '') plantcode,
                NVL (a.slipinstate, '') slipinstate,
                NVL (a.remark, '') remark,
                NVL (a.remark1, '') remark1,
                NVL (a.remark2, '') remark2,
                NVL (a.slipdeptcode, '') slipdeptcode,
                NVL (a.slipempcode, '') slipempcode,
                NVL (a.skreqyn, '') skreqyn,
                NVL (a.skreqdiv, '') skreqdiv,
                NVL (a.skreqdate, '') skreqdate,
                NVL (a.skreqdeptcode, '') skreqdeptcode,
                NVL (a.skreqempcode, '') skreqempcode,
                NVL (a.accountno, '') accountno,
                NVL (ac20.divname, '') accdivname,
                NVL (a.condition1, '') condition1,
                NVL (a.condition2, '') condition2,
                NVL (a.condition3, '') condition3,
                NVL (a.crtdiv, '') crtdiv,
                NVL (ac94.divname, '') crtdivname
           FROM ACAUTORULE a
                LEFT JOIN CMCOMMONM ac20
                   ON a.accdiv = ac20.divcode AND ac20.cmmcode = 'AC20'
                LEFT JOIN CMCOMMONM ac94
                   ON ac94.divcode = a.crtdiv AND ac94.cmmcode = 'AC94'
          WHERE a.acautorcode LIKE p_acautorcode || '%'
          ORDER BY a.acautorcode;

   ELSIF (p_div = 'IM')    THEN

      INSERT INTO ACAUTORULE (acautorcode,
                              acautorname,
                              accdiv,
                              slipindate,
                              deptcode,
                              plantcode,
                              slipinstate,
                              remark,
                              remark1,
                              remark2,
                              slipdeptcode,
                              slipempcode,
                              skreqyn,
                              skreqdiv,
                              skreqdate,
                              skreqdeptcode,
                              skreqempcode,
                              accountno,
                              condition1,
                              condition2,
                              condition3,
                              crtdiv,
                              insertdt,
                              iempcode)
           VALUES (p_acautorcode,
                   p_acautorname,
                   p_accdiv,
                   p_slipindate,
                   p_deptcode,
                   p_plantcode,
                   p_slipinstate,
                   p_remark,
                   p_remark1,
                   p_remark2,
                   p_slipdeptcode,
                   p_slipempcode,
                   p_skreqyn,
                   p_skreqdiv,
                   p_skreqdate,
                   p_skreqdeptcode,
                   p_skreqempcode,
                   p_accountno,
                   p_condition1,
                   p_condition2,
                   p_condition3,
                   p_crtdiv,
                   SYSDATE,
                   p_iempcode);

   ELSIF (p_div = 'UM') THEN

      UPDATE ACAUTORULE
         SET acautorcode = p_acautorcode,
             acautorname = p_acautorname,
             accdiv = p_accdiv,
             slipindate = p_slipindate,
             deptcode = p_deptcode,
             plantcode = p_plantcode,
             slipinstate = p_slipinstate,
             remark = p_remark,
             remark1 = p_remark1,
             remark2 = p_remark2,
             slipdeptcode = p_slipdeptcode,
             slipempcode = p_slipempcode,
             skreqyn = p_skreqyn,
             skreqdiv = p_skreqdiv,
             skreqdate = p_skreqdate,
             skreqdeptcode = p_skreqdeptcode,
             skreqempcode = p_skreqempcode,
             accountno = p_accountno,
             condition1 = p_condition1,
             condition2 = p_condition2,
             condition3 = p_condition3,
             crtdiv = p_crtdiv,
             updatedt = SYSDATE,
             uempcode = p_iempcode
       WHERE acautorcode = p_acautorcode;

   ELSIF (p_div = 'DM')    THEN

      DELETE ACAUTORULE
       WHERE acautorcode = p_acautorcode;

   ELSIF (p_div = 'SD')    THEN

      OPEN IO_CURSOR FOR
         SELECT NVL (a.acautorcode, '') acautorcode,
                NVL (a.acautoseq, 0) acautoseq,
                NVL (a.dcdiv, '') dcdiv,
                NVL (a.acacccode, '') acacccode,
                NVL (a.amtdiv, '') amtdiv,
                NVL (a.accamtdiv, '') accamtdiv,
                NVL (a.acccalcdiv, '') acccalcdiv,
                NVL (a.accsamtdiv, '') accsamtdiv,
                NVL (b.accname, '') acaccname,
                NVL (ac22.divname, '') dcdivname,
                NVL (ac08.divname, '') accamtdivname,
                NVL (ac08s.divname, '') accsamtdivname,
                NVL (ac03.divname, '') acccalcdivname
           FROM ACAUTORULESM a
                LEFT JOIN ACACCM b ON a.acacccode = b.acccode
                LEFT JOIN CMCOMMONM ac22
                   ON a.dcdiv = ac22.divcode AND ac22.cmmcode = 'AC22'
                LEFT JOIN CMCOMMONM ac08
                   ON a.accamtdiv = ac08.divcode AND ac08.cmmcode = 'AC08'
                LEFT JOIN CMCOMMONM ac03
                   ON a.acccalcdiv = ac03.divcode AND ac03.cmmcode = 'AC03'
                LEFT JOIN CMCOMMONM ac08s
                   ON a.accsamtdiv = ac08s.divcode AND ac08s.cmmcode = 'AC08'
          WHERE a.acautorcode = p_acautorcode
          ORDER BY a.acautoseq;

   ELSIF (p_div = 'ID')    THEN

      INSERT INTO ACAUTORULESM (acautorcode,
                                acautoseq,
                                dcdiv,
                                acacccode,
                                amtdiv,
                                accamtdiv,
                                acccalcdiv,
                                accsamtdiv,
                                insertdt,
                                iempcode)
           VALUES (p_acautorcode,
                   p_acautoseq,
                   p_dcdiv,
                   p_acacccode,
                   p_amtdiv,
                   p_accamtdiv,
                   p_acccalcdiv,
                   p_accsamtdiv,
                   SYSDATE,
                   p_iempcode);

   ELSIF (p_div = 'UD')    THEN

      UPDATE ACAUTORULESM
         SET acautorcode = p_acautorcode,
             acautoseq = p_acautoseq,
             dcdiv = p_dcdiv,
             acacccode = p_acacccode,
             amtdiv = p_amtdiv,
             accamtdiv = p_accamtdiv,
             acccalcdiv = p_acccalcdiv,
             accsamtdiv = p_accsamtdiv,
             updatedt = SYSDATE,
             uempcode = p_iempcode
       WHERE acautorcode = p_acautorcode AND acautoseq = p_acautoseq;

   ELSIF (p_div = 'DD') THEN

      DELETE ACAUTORULESM
       WHERE acautorcode = p_acautorcode AND acautoseq = p_acautoseq;

   ELSIF (p_div = 'SS') THEN

      OPEN IO_CURSOR FOR
         SELECT NVL (a.acautorcode, '') acautorcode,
                NVL (a.acautoseq, 0) acautoseq,
                NVL (a.mngclucode, '') mngclucode,
                NVL (a.mngcluvaldiv, '') mngcluvaldiv,
                NVL (a.mngcludecdiv, '') mngcludecdiv,
                NVL (c.mngcluname, '') mngcluname,
                NVL (D.requireyn, '') requireyn
           FROM ACAUTORULEDS a
                JOIN
                ACAUTORULESM b
                   ON     a.acautorcode = b.acautorcode
                      AND a.acautoseq = b.acautoseq
                LEFT JOIN ACMNGM c ON a.mngclucode = c.mngclucode
                LEFT JOIN
                ACACCMNGM D
                   ON     D.acccode = b.acacccode
                      AND D.dcdiv =
                             CASE
                                WHEN b.dcdiv IN ('1', '4') THEN '1'
                                ELSE '2'
                             END
                      AND D.mngclucode = a.mngclucode
          WHERE a.acautorcode = p_acautorcode
          ORDER BY acautoseq, mngclucode;

   ELSIF (p_div = 'AM') THEN

      -- 계정별 관리항목 검색

      OPEN IO_CURSOR FOR
           SELECT p_acautorcode acautorcode,                          -- 분개룰코드
                  p_acautoseq acautoseq,                               -- 전표순번
                  NVL (a.mngclucode, '') mngclucode,                -- 관리항목코드
                  '' mngcluvaldiv,                                   -- 관리항목값
                  '' mngcludecdiv,                                  -- 관리항목값명
                  NVL (a.mngcluname, '') mngcluname,                 -- 관리항목명
                  NVL (a.requireyn, '') requireyn                   -- 필수입력여부
             FROM ACACCMNGM a LEFT JOIN ACMNGM b                     -- 관리항목정보
                                                ON a.mngclucode = b.mngclucode
            WHERE     a.acccode = p_acacccode
                  AND a.dcdiv =
                         CASE WHEN p_dcdiv IN ('1', '4') THEN '1' ELSE '2' END
         ORDER BY a.seq;

   ELSIF (p_div = 'IS') THEN

      INSERT INTO ACAUTORULEDS (acautorcode,
                                acautoseq,
                                mngclucode,
                                mngcluvaldiv,
                                mngcludecdiv,
                                insertdt,
                                iempcode)
           VALUES (p_acautorcode,
                   p_acautoseq,
                   p_mngclucode,
                   p_mngcluvaldiv,
                   p_mngcludecdiv,
                   SYSDATE,
                   p_iempcode);

   ELSIF (p_div = 'US') THEN

      UPDATE ACAUTORULEDS
         SET acautorcode = p_acautorcode,
             acautoseq = p_acautoseq,
             mngclucode = p_mngclucode,
             mngcluvaldiv = p_mngcluvaldiv,
             mngcludecdiv = p_mngcludecdiv,
             updatedt = SYSDATE,
             uempcode = p_iempcode
       WHERE     acautorcode = p_acautorcode
             AND acautoseq = p_acautoseq
             AND mngclucode = p_mngclucode;

   ELSIF (p_div = 'DS')    THEN

      DELETE ACAUTORULEDS
       WHERE acautorcode = p_acautorcode AND acautoseq = p_acautoseq; --and mngclucode = @mngclucode
   END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
