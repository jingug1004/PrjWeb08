CREATE FUNCTION        fnNextWorkingDateInVarchar(
	-- ---------------------------------------------------------------
    -- 함 수 명   : fnNextWorkingDate
    -- 작 성 자         : 민승기
    -- 작성일자         : 2007-11-01
    -- ---------------------------------------------------------------
    -- 함수설명   : 다음 근무일 계산
    -- ---------------------------------------------------------------

	p_daycnt IN NUMBER DEFAULT 0, 
    p_basedate IN VARCHAR2 DEFAULT ''
)
	RETURN DATE
AS
	ip_basedate    DATE;
	p_todate	   DATE;
	p_rowcnt	   NUMBER(10, 0);
BEGIN
	IF (p_basedate IS NOT NULL)
	THEN
		ip_basedate := TO_DATE(p_basedate, 'YYYY-MM-DD');
	ELSE
		ip_basedate := TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD'), 'YYYY-MM-DD');
	END IF;

	FOR rec IN (SELECT MAX(a.calymd) AS alias1,
					   COUNT(*) - 1 AS alias2
				FROM   (SELECT *
						FROM   (SELECT	 calymd
								FROM	 PSCALM
								WHERE	 NVL(plantcode,' ') = NVL((SELECT MIN(plantcode) FROM CMPLANTM), ' ')
										 AND calymd BETWEEN TO_CHAR(ip_basedate, 'YYYY-MM-DD') AND TO_CHAR(ip_basedate + ABS(p_daycnt), 'YYYY-MM-DD')
										 AND caldiv = '01'
								--and daydiv in ('D','P') -- 평일,반일
								--and isnull(daydiv,'') not in ('H') -- 휴일

								ORDER BY calymd ASC)
						WHERE  ROWNUM <= ABS(NVL(p_daycnt, 0)) + 1) a)
	LOOP
		p_todate := TO_DATE(rec.alias1,'YYYY-MM-DD');
		p_rowcnt := rec.alias2;
	END LOOP;

	IF (p_rowcnt <> p_daycnt)
	THEN
		p_todate := ip_basedate + ABS(p_daycnt);
	END IF;

	RETURN (p_todate);
EXCEPTION
	WHEN OTHERS
	THEN
		RETURN NULL;
END;
/
