CREATE PROCEDURE        spACbase0108R
  -- ---------------------------------------------------------------
  -- 프로시저명     : spACbase0108R
  -- 작 성 자      : 최기홍
  -- 작성일자      : 2010-09-14
  -- 수 정 자      : 강현호
  -- E-Mail       : roykang0722@gmail.com
  -- 수정일자      : 2016-12-12
  -- ---------------------------------------------------------------
  -- 프로시저 설명    : 법인카드마스터현황물 조회하는 프로시저이다.
  -- ---------------------------------------------------------------
(
    p_div         IN     VARCHAR2 DEFAULT '',

    p_compcode    IN     VARCHAR2 DEFAULT '',
    p_cardno      IN     VARCHAR2 DEFAULT '',
    p_plantcode   IN     VARCHAR2 DEFAULT '',

    p_userid      IN     VARCHAR2 DEFAULT '',
    p_reasondiv   IN     VARCHAR2 DEFAULT '',
    p_reasontext  IN     VARCHAR2 DEFAULT '',
    MESSAGE       OUT    VARCHAR2,
    IO_CURSOR     OUT    TYPES.DataSet
)
AS
BEGIN

    message := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);
    
    if (p_div = 'S') then
        open IO_CURSOR for
        select  nvl(a.compcode, '') as compcode,
                nvl(a.cardno, '') as cardno,
                nvl(a.cardname, '') as cardname,
                nvl(a.carddiv, '') as carddiv,
                nvl(a.cardcls, '') as cardcls,
                nvl(a.cardcustom, '') as cardcustom,
                nvl(a.limitamt, 0) as limitamt,
                nvl(a.apprday, '') as apprday,
                nvl(a.publishdate, '') as publishdate,
                nvl(a.validdate, '') as validdate,
                nvl(a.bankcode, '') as bankcode,
                nvl(a.accountno, '') as accountno,
                nvl(a.empcode, '') as empcode,
                nvl(a.plantcode, '') as plantcode,
                case when nvl(a.useyn, '') = 'Y' then '사용' else '미사용' end as useyn,
                nvl(b.empname, '') as empname

        from    ACCARDM a
                left join CMEMPM b on
                    a.empcode = b.empcode
        
        where   a.compcode = p_compcode
                and a.plantcode like p_plantcode
                and (a.cardno like '%' || p_cardno || '%' or a.cardname like '%' || p_cardno || '%')

        order by cardno;
    
    end if;
    
    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
