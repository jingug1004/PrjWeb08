CREATE PROCEDURE        spACacc00183P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc00183P
 -- 작 성 자         : 최용석
 -- 작성일자         : 2017-12-03
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 법인카드 원시자료를 확인하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '',

    p_compcode      IN VARCHAR2 DEFAULT '',
    p_slipsdate     IN VARCHAR2 DEFAULT '',
    p_slipedate     IN VARCHAR2 DEFAULT '',
    p_empdiv        IN VARCHAR2 DEFAULT '',
    p_cardno        IN VARCHAR2 DEFAULT '',
    p_deptcode      IN VARCHAR2 DEFAULT '',
    p_empcode       IN VARCHAR2 DEFAULT '',
    p_custname      IN VARCHAR2 DEFAULT '',

    p_userid        IN VARCHAR2 DEFAULT '',
    p_reasondiv     IN VARCHAR2 DEFAULT '',
    p_reasontext    IN VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
BEGIN

    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo (userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    -- 카드전표내역 검색
    if (p_div = 'S') then
        open IO_CURSOR for
        select   FNstuff(FNstuff(a.approve_date,5,0,'-'),8,0,'-') as use_dt        -- 사용일자
                ,FNstuff(FNstuff(a.approve_time,3,0,':'),6,0,':') as use_tm        -- 사용시간
                ,b.cardno as card_no                                               -- 카드번호
                ,a.approve_num as card_ok_no                                       -- 승인번호
                ,case when a.gubun = '03' then '승인' else '취소' end as use_gubun  -- 사용구분
                ,b.empcode                                                         -- 사용사원
                ,c.empname                                                         -- 사용사원명
                ,c.deptcode                                                        -- 부서코드
                ,d.deptname                                                        -- 부서명
                ,a.approve_total as use_amt                                        -- 사용금액
                ,a.vendor_name as saupjang_nm                                      -- 가맹점명
                ,a.vendor_mmc_name                                                 -- 업종
                ,FNstuff(FNstuff(a.vendor_tax_num,4,0,'-'),7,0,'-') as saup_no     -- 사업자번호
                ,a.vendor_address1 || ' ' || a.vendor_address2 as saupjang_addr    -- 주소
                ,case a.vendor_tax_gb when '1' then '일반' when '2' then '간이' when '3' then '면세' when '4' then '비영리' when '9' then '휴업' else '폐업' end as tax_gb   -- 과세구분
                ,a.tax_gongjae_yn as gongjae_yn                                    -- 공제여부
                ,a.sale0601_proc_yn                                                -- 처리상태
                ,a.proc_date                                                       -- 처리일자
                ,a.fail_reason                                                     -- 오류사유
                ,a.seq                                                             -- 순번

        from    HANALINK.IBK_ACQUIRE_DATA a
                join ACCARDM b
                    on b.compcode = p_compcode
                    and a.card_num = replace(b.cardno,'-','')
                    and a.card_num like '%' || replace(p_cardno,'-','') || '%'
                    and nvl(b.empcode,' ') like p_empcode || '%'
                left join CMEMPM c
                    on b.empcode = c.empcode
                left join CMDEPTM d
                    on c.deptcode = d.deptcode

        where   a.approve_date between replace(p_slipsdate, '-', '') and replace(p_slipedate, '-', '')
                and (p_empdiv = '0' or
                     p_empdiv = '1' and case when c.responsibilitydiv = '0003' then '2' else '1' end = '2' or
                     p_empdiv = '2' and case when c.responsibilitydiv = '0003' then '2' else '1' end <> '2')
                and nvl(c.deptcode,' ') like p_deptcode || '%'
                and nvl(a.vendor_name,' ') like '%' || p_custname || '%'

        order by a.approve_date, a.approve_time, a.card_num;

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
