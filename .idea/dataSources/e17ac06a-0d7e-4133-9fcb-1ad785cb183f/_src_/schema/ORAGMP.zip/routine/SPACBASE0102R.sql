CREATE PROCEDURE        spACbase0102R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbase0102R
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-09-10
    -- 수 정 자     : 강현호
    -- E-Mail       : roykang0722@gmail.com
    -- 수정일자      : 2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 계정과목현황을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------
(
	p_div			IN	   VARCHAR2 DEFAULT '',
	p_acccode		IN	   VARCHAR2 DEFAULT '',
	p_orduseyn		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',

    MESSAGE         OUT    VARCHAR2,
    IO_CURSOR       OUT    TYPES.DataSet
)
AS
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	OPEN IO_CURSOR FOR

		SELECT	 a.acccode acccode,
				 accname,
				 a.dcdiv dcdiv,
				 CASE WHEN a.orduseyn = 'Y' THEN '사용' ELSE '' END orduseyn,					-- 전표사용여부
				 CASE WHEN a.budgmngyn = 'Y' THEN '관리' ELSE '' END budgmngyn,				-- 예산관리여부
				 CASE WHEN a.budglimityn = 'Y' THEN '통제' ELSE '' END budglimityn,			-- 예산통제여부
				 b.dcdiv mngdcdiv,
				 b.seq,
				 b.mngclucode mngclucode,
				 b.mngcluname mngcluname,
				 CASE WHEN b.remainyn = 'Y' THEN '관리' ELSE '' END remainyn,	                -- 잔액관리
				 NVL(ac04.divname, '') dcdivname,
				 NVL(ac04mng.divname, '') mngdcdivname

		FROM	 ACACCM a
				 LEFT JOIN ACACCMNGM b ON a.acccode = b.acccode
				 LEFT JOIN CMCOMMONM ac04 ON a.dcdiv = ac04.divcode
						                     AND ac04.cmmcode = 'AC04'
				 LEFT JOIN CMCOMMONM ac04mng ON b.dcdiv = ac04mng.divcode
						                        AND ac04mng.cmmcode = 'AC04'

		WHERE	 (a.acccode LIKE p_acccode || '%' OR a.accname LIKE p_acccode || '%')
				 AND (a.acccode LIKE p_acccode || '%' OR a.accname LIKE p_acccode || '%')
				 AND (a.orduseyn = p_orduseyn OR p_orduseyn = 'N')

		ORDER BY a.acccode, b.dcdiv, b.seq; 							                    --end

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
