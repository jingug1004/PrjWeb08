CREATE PROCEDURE        spACacc0140R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0140R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2013-01-03
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-20
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 계정별거래처원장을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_strdate		IN	   VARCHAR2 DEFAULT '',
	p_enddate		IN	   VARCHAR2 DEFAULT '',
	p_stracccode	IN	   VARCHAR2 DEFAULT '',
	p_endacccode	IN	   VARCHAR2 DEFAULT '',
	p_outputdiv 	IN	   VARCHAR2 DEFAULT '',
	p_downview		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	p_colview		VARCHAR2(1);
	p_acccashcode	VARCHAR2(20);
	p_odiv1 		VARCHAR2(5);
	p_odiv2 		VARCHAR2(5);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0140R_ACORDD13 ';

	p_colview := '_';

	FOR rec IN (SELECT value1
				FROM   SYSPARAMETERMANAGE
				WHERE  parametercode = 'accldgcolview')
	LOOP
		p_colview := rec.value1;
	END LOOP;

	IF (p_colview = '_') THEN
    	p_colview := '0';
    END IF;

	IF (p_div = 'S')
	THEN
		-- 현금계정은 제외
		FOR rec IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'acccashcode'
						   AND usediv = 'Y')
		LOOP
			p_acccashcode := rec.value1;
		END LOOP;

		IF (p_outputdiv = '1')
		THEN
			--K-GAAP
			p_odiv1 := '20';
			p_odiv2 := 'F';
		END IF;

		IF (p_outputdiv = '2')
		THEN
			--IFRS
			p_odiv1 := '30';
			p_odiv2 := 'K';
		END IF;

		INSERT INTO VGT.TT_ACACC0140R_ACORDD13
			(SELECT   NVL(b.grp, 0) grp,
					  CASE WHEN b.grp = 1 THEN A.acccode || A.slipdate || REPLACE(A.slipno, 'C', p_colview) || LPAD(A.slipinseq, 5, '0') WHEN b.grp = 2 THEN A.acccode || SUBSTR(A.slipdate, 0, 7) || '98' WHEN b.grp = 3 THEN A.acccode || SUBSTR(A.slipdate, 0, 7) || '99' ELSE A.acccode END ord,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipinno END) slipinno,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipinseq END) slipinseq,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipindate END) slipindate,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipinnum END) slipinnum,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipno END) slipno,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipdate ELSE SUBSTR(A.slipdate, 0, 7) END) slipdate,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipnum WHEN b.grp = 2 THEN '월계' WHEN b.grp = 3 THEN '누계' ELSE '이월' END) slipnum,
					  A.acccode,
					  MAX(c.accname) accname,
					  MAX(CASE WHEN b.grp = 1 THEN A.remark END) remark,
					  SUM(debamt) debamt,
					  SUM(creamt) creamt,
					  SUM(CASE WHEN c.dcdiv = '1' THEN A.debamt - A.creamt ELSE A.creamt - A.debamt END) fnamt,
					  MAX(A.acccode || ' : ' || c.accname) acccodename
			 FROM	  (SELECT '' slipinno,
							  0 slipinseq,
							  '' slipindate,
							  '' slipinnum,
							  '' slipno,
							  SUBSTR(p_strdate, 0, 7) || '-00' slipdate,
							  '' slipnum,
							  b.acccode,
							  '' remark,
							  A.bsdebamt debamt,
							  A.bscreamt creamt
					   FROM   ACORDDMM A
							  JOIN (SELECT A.acccode, A.accname, A.dcdiv, COALESCE(c.acccode, b.acccode, A.acccode) downcode
									FROM   ACACCM A
										   LEFT JOIN ACACCM b
											   ON (A.acccode = b.acccode
												   OR A.acccode = b.hacccode)
												  AND p_downview = 'Y'
										   LEFT JOIN ACACCM c
											   ON A.acccode <> b.acccode
												  AND b.acccode = c.hacccode
												  AND p_downview = 'Y'
									WHERE  NVL(A.acccode,' ') BETWEEN NVL(p_stracccode,' ') AND NVL(p_endacccode, 'zzzzzzzz')) b
								  ON A.acccode = b.downcode
					   WHERE  A.compcode = p_compcode
							  AND A.plantcode LIKE p_plantcode || '%'
							  AND A.slipym = SUBSTR(p_strdate, 0, 7)
							  AND (closediv = '10'
								   OR closediv = p_odiv1)
							  AND A.acccode <> p_acccashcode
					   UNION ALL
					   SELECT A.slipinno,
							  A.slipinseq,
							  b.slipindate,
							  b.slipinnum,
							  b.slipno,
							  CASE WHEN A.slipdate < p_strdate THEN SUBSTR(p_strdate, 0, 7) || '-00' ELSE A.slipdate END slipdate,
							  b.slipnum,
							  c.acccode,
							  A.remark1 remark,
							  A.debamt,
							  A.creamt
					   FROM   ACORDD A
							  JOIN ACORDM b
								  ON A.compcode = b.compcode
									 AND A.slipinno = b.slipinno
							  JOIN (SELECT A.acccode, A.accname, A.dcdiv, COALESCE(c.acccode, b.acccode, A.acccode) downcode
									FROM   ACACCM A
										   LEFT JOIN ACACCM b
											   ON (A.acccode = b.acccode
												   OR A.acccode = b.hacccode)
												  AND p_downview = 'Y'
										   LEFT JOIN ACACCM c
											   ON A.acccode <> b.acccode
												  AND b.acccode = c.hacccode
												  AND p_downview = 'Y'
									WHERE  NVL(A.acccode,' ') BETWEEN NVL(p_stracccode,' ') AND NVL(p_endacccode, 'zzzzzzzz')) c
								  ON A.acccode = c.downcode
					   WHERE  A.compcode = p_compcode
							  AND A.plantcode LIKE p_plantcode || '%'
							  AND A.slipdate BETWEEN SUBSTR(p_strdate, 0, 7) || '-01' AND p_enddate
							  AND A.acccode <> p_acccashcode
							  AND b.slipinstate = '4'
							  AND b.slipdiv <> p_odiv2) A
					  LEFT JOIN (SELECT 1 grp FROM DUAL
								 UNION
								 SELECT 2 FROM DUAL
								 UNION
								 SELECT 3 FROM DUAL) b
						  ON A.slipdate >= p_strdate
					  LEFT JOIN ACACCM c ON A.acccode = c.acccode
			 GROUP BY b.grp,
					  A.acccode,
					  CASE WHEN b.grp = 1 THEN A.acccode || A.slipdate || REPLACE(A.slipno, 'C', p_colview) || LPAD(A.slipinseq, 5, '0') WHEN b.grp = 2 THEN A.acccode || SUBSTR(A.slipdate, 0, 7) || '98' WHEN b.grp = 3 THEN A.acccode || SUBSTR(A.slipdate, 0, 7) || '99' ELSE A.acccode END);

        MERGE INTO VGT.TT_ACACC0140R_ACORDD13 A
        USING	   (SELECT A.GRP,
                           A.ORD,
                           A.SLIPINNO,
                           A.SLIPINSEQ,
                           A.SLIPINDATE,
                           A.SLIPINNUM,
                           A.SLIPNO,
                           A.SLIPDATE,
                           A.SLIPNUM,
                           A.ACCCODE,
                           A.ACCNAME,
                           A.REMARK,
                           A.DEBAMT,
                           A.CREAMT,
                           A.ACCCODENAME,
                           CASE WHEN c.dcdiv = '1' THEN b.debamt - b.creamt ELSE b.creamt - b.debamt END AS fnamt
                    FROM   VGT.TT_ACACC0140R_ACORDD13 A
                           JOIN (SELECT   A.ord,
                                          SUM(b.debamt) debamt,
                                          SUM(b.creamt) creamt
                                 FROM	  VGT.TT_ACACC0140R_ACORDD13 A
                                          JOIN VGT.TT_ACACC0140R_ACORDD13 b
                                              ON A.acccode = b.acccode
                                                 AND A.ord >= b.ord
                                                 AND b.grp IN (0, 1)
                                 WHERE	  A.grp = 1
                                 GROUP BY A.ord) b
                               ON A.ord = b.ord
                           LEFT JOIN ACACCM c ON A.acccode = c.acccode) src
        ON		   (NVL(a.ord, ' ') = NVL(src.ord, ' ')
                    AND NVL(a.slipinnum, ' ') = NVL(src.slipinnum, ' ')
                    AND NVL(a.slipnum, ' ') = NVL(src.slipnum, ' ')
                    AND NVL(a.slipinno, ' ') = NVL(src.slipinno, ' ')
                    AND NVL(a.slipno, ' ') = NVL(src.slipno, ' ')
                    AND NVL(a.acccode, ' ') = NVL(src.acccode, ' ')
                    AND NVL(a.acccodename, ' ') = NVL(src.acccodename, ' ')
                    AND NVL(a.accname, ' ') = NVL(src.accname, ' ')
                    AND NVL(a.remark, ' ') = NVL(src.remark, ' ')
                    AND NVL(a.slipindate, ' ') = NVL(src.slipindate, ' ')
                    AND NVL(a.slipdate, ' ') = NVL(src.slipdate, ' ')
                    AND NVL(a.grp, 0) = NVL(src.grp, 0)
                    AND NVL(a.slipinseq, 0) = NVL(src.slipinseq, 0)
                    AND NVL(a.debamt, 0) = NVL(src.debamt, 0)
                    AND NVL(a.creamt, 0) = NVL(src.creamt, 0))
        WHEN MATCHED
        THEN
            UPDATE SET A.fnamt = src.fnamt;

		MERGE INTO VGT.TT_ACACC0140R_ACORDD13 A
		USING	   (SELECT A.GRP,
						   A.ORD,
						   A.SLIPINNO,
						   A.SLIPINSEQ,
						   A.SLIPINDATE,
						   A.SLIPINNUM,
						   A.SLIPNO,
						   A.SLIPDATE,
						   A.SLIPNUM,
						   A.ACCCODE,
						   A.ACCNAME,
						   A.REMARK,
						   A.DEBAMT,
						   A.CREAMT,
						   A.ACCCODENAME,
						   NVL(b.debamt, A.debamt) AS pos_2,
						   NVL(b.creamt, A.creamt) AS pos_3,
						   b.fnamt
					FROM   VGT.TT_ACACC0140R_ACORDD13 A
						   LEFT JOIN (SELECT   A.ord, SUM(b.debamt) debamt, SUM(b.creamt) creamt, SUM(b.fnamt) fnamt
									  FROM	   VGT.TT_ACACC0140R_ACORDD13 A
											   JOIN VGT.TT_ACACC0140R_ACORDD13 b
												   ON A.acccode = b.acccode
													  AND A.ord >= b.ord
													  AND b.grp IN (0, 2)
									  WHERE    A.grp = 3
									  GROUP BY A.ord) b
							   ON A.ord = b.ord
					WHERE  A.grp IN (2, 3)) src
		ON		   (NVL(a.ord, ' ') = NVL(src.ord, ' ')
                    AND NVL(a.slipinnum, ' ') = NVL(src.slipinnum, ' ')
                    AND NVL(a.slipnum, ' ') = NVL(src.slipnum, ' ')
                    AND NVL(a.slipinno, ' ') = NVL(src.slipinno, ' ')
                    AND NVL(a.slipno, ' ') = NVL(src.slipno, ' ')
                    AND NVL(a.acccode, ' ') = NVL(src.acccode, ' ')
                    AND NVL(a.acccodename, ' ') = NVL(src.acccodename, ' ')
                    AND NVL(a.accname, ' ') = NVL(src.accname, ' ')
                    AND NVL(a.remark, ' ') = NVL(src.remark, ' ')
                    AND NVL(a.slipindate, ' ') = NVL(src.slipindate, ' ')
                    AND NVL(a.slipdate, ' ') = NVL(src.slipdate, ' ')
                    AND NVL(a.grp, 0) = NVL(src.grp, 0)
                    AND NVL(a.slipinseq, 0) = NVL(src.slipinseq, 0))
		WHEN MATCHED
		THEN
			UPDATE SET A.debamt = pos_2, A.creamt = pos_3, A.fnamt = src.fnamt;


		OPEN IO_CURSOR FOR
			SELECT	 p_compcode compcode,
					 A.slipinno,
					 A.slipinseq,
					 A.slipindate,
					 A.slipinnum,
					 A.slipno,
					 A.slipdate,
					 A.slipnum,
					 A.acccode,
					 A.accname,
					 A.remark,
					 b.mngcluval,
					 b.mngcludec,
					 c.businessno,
					 A.debamt,
					 A.creamt,
					 A.fnamt,
					 A.acccodename
			FROM	 VGT.TT_ACACC0140R_ACORDD13 A
					 LEFT JOIN ACORDS b
						 ON b.compcode = p_compcode
							AND A.slipinno = b.slipinno
							AND A.slipinseq = b.slipinseq
							AND b.mngclucode = 'S010'
					 LEFT JOIN CMCUSTM c ON b.mngcluval = c.custcode
			ORDER BY A.acccode, A.ord ;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
