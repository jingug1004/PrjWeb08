CREATE PROCEDURE        spACacc0048P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0048P
	-- 작 성 자         : 민승기
	-- 작성일자         : 2010-11-23
	--  수 정 일 : 2013-10-22
	--  수 정 자 : 민승기
	--  수정내역 : 회계전표승인처리 자료 조회시(특히 전표상태를 "승인"으로 할 때)
	--      조회 성능이 저하되어 튜닝한다.
	--      (반제 전표 내역을 템프러리로 생성함.)
    -- 수정일자     	:   노영래
	-- E-mail    	 :   0rae0926@gmail.com
	-- 수정일자     	:   2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계전표를 승인할 자료를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			 IN 	VARCHAR2 DEFAULT '',
	p_compcode		 IN 	VARCHAR2 DEFAULT '',
	p_plantcode 	 IN 	VARCHAR2 DEFAULT '',
	p_slipdiv		 IN 	VARCHAR2 DEFAULT '',
	p_slipinstate	 IN 	VARCHAR2 DEFAULT '',
	p_dategb		 IN 	VARCHAR2 DEFAULT '',
	p_strdate		 IN 	VARCHAR2 DEFAULT '',
	p_enddate		 IN 	VARCHAR2 DEFAULT '',
	p_strdeptcode	 IN 	VARCHAR2 DEFAULT '',
	p_enddeptcode	 IN 	VARCHAR2 DEFAULT '',
	p_stracccode	 IN 	VARCHAR2 DEFAULT '',
	p_endacccode	 IN 	VARCHAR2 DEFAULT '',
	p_acautorcode	 IN 	VARCHAR2 DEFAULT '',
	p_eviddiv		 IN 	VARCHAR2 DEFAULT '',
	p_chk			 IN 	CHAR DEFAULT '',
	p_slipinno		 IN 	VARCHAR2 DEFAULT '',
	p_strempcode	 IN 	VARCHAR2 DEFAULT '',
	p_endempcode	 IN 	VARCHAR2 DEFAULT '',
	p_userid		 IN 	VARCHAR2 DEFAULT '',
	p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
	p_reasontext	 IN 	VARCHAR2 DEFAULT '',
	MESSAGE 			OUT VARCHAR2,
	IO_CURSOR			OUT TYPES.DATASET
)
AS
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (UPPER(P_DIV) = 'S') THEN
		-- 회계전표내역 검색
		OPEN IO_CURSOR FOR
			SELECT	 p_chk chk, 																																																																	   -- 선택
					 a.compcode,																																																																	 -- 회사코드
					 a.slipinno,																																																																   -- 결의전표번호
					 b.slipinstate, 																																																															   -- 결의전표상태
					 b.slipindate,																																																																	 -- 결의일자
					 b.slipinnum,																																																																	 -- 결의번호
					 b.slipremark,																																																																	 -- 처리사유
					 b.slipdate,																																																																	 -- 전표일자
					 b.slipnum, 																																																																	 -- 전표번호
					 b.slipdiv, 																																																																	 -- 전표유형
					 c.deptname,																																																																	 -- 결의부서
					 D.empname, 																																																																	 -- 결의사원
					 a.debamt,																																																																		 -- 차변금액
					 a.creamt,																																																																		 -- 대변금액
					 b.slipinremark,																																																																 -- 결의내용
					 b.slipincomment,																																																																 -- 특이사항
					 b.eviddiv, 																																																																	 -- 증빙구분
					 b.plantcode,																																																																	  -- 사업장
					 e.plantname,																																																																	 -- 사업장명
					 TO_CHAR(b.updatedt, 'YYYY-MM-DD') updatedt,																																																			 -- 처리일자
					 f.deptname slipdeptname,																																																														 -- 승인부서
					 g.empname slipempname, 																																																														  -- 승인자
					 CASE WHEN TRIM(h.slipinno) IS NOT NULL THEN 'Y' ELSE 'N' END rpyyn 																																																					   -- 반제처리여부
			FROM	 (SELECT   a.compcode,																																																															 -- 회사코드
							  a.slipinno,																																																											   -- 결의전표번호
							  SUM(b.debamt) debamt,																																																						   -- 결의상태코드
							  SUM(b.creamt) creamt																																																		 -- 결의일자
					 FROM	  ACORDM a																																																																 -- 전표내역
							  JOIN ACORDD b 																																																													   -- 전표상세내역
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
							  JOIN CMCOMMONM c
								  ON c.cmmcode = 'AC20'
									 AND a.slipdiv = c.divcode
									 AND c.filter1 = 'A'
					 WHERE	  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipdiv LIKE p_slipdiv
							  AND a.slipinstate = p_slipinstate
							  AND NVL(a.eviddiv, ' ') LIKE p_eviddiv
							  AND (p_dategb = '0'
								   AND a.slipindate BETWEEN p_strdate AND p_enddate
								   OR p_dategb = '1'
									  AND a.slipdate BETWEEN p_strdate AND p_enddate)
							  AND (p_strdeptcode > ' '
								   AND a.deptcode >= p_strdeptcode
								   OR p_strdeptcode IS NULL)
							  AND (p_enddeptcode > ' '
								   AND a.deptcode <= p_enddeptcode
								   OR p_enddeptcode IS NULL)
							  AND (p_strempcode > ' '
								   AND a.empcode >= p_strempcode
								   OR p_strempcode IS NULL)
							  AND (p_endempcode > ' '
								   AND a.empcode <= p_endempcode
								   OR p_endempcode IS NULL)
							  AND (p_stracccode > ' '
								   AND b.acccode >= p_stracccode
								   OR p_stracccode IS NULL)
							  AND (p_endacccode > ' '
								   AND b.acccode <= p_endacccode
								   OR p_endacccode IS NULL)
							  AND (p_acautorcode IN ('%')
                              	   OR p_acautorcode IS NULL
								   OR p_acautorcode = a.acautorcode)
					 GROUP BY a.compcode, a.slipinno) a
					 JOIN ACORDM b
						 ON a.compcode = b.compcode
							AND a.slipinno = b.slipinno
					 LEFT JOIN CMDEPTM c ON b.deptcode = c.deptcode
					 LEFT JOIN CMEMPM D ON b.empcode = D.empcode
					 LEFT JOIN CMPLANTM e ON b.plantcode = e.plantcode
					 LEFT JOIN CMDEPTM f ON b.slipdeptcode = f.deptcode
					 LEFT JOIN CMEMPM g ON b.slipempcode = g.empcode
					 LEFT JOIN (SELECT DISTINCT a.compcode, NVL(b.slipinno, c.slipinno) slipinno
					 FROM	(SELECT   a.compcode,																																																															 -- 회사코드
							  a.slipinno,																																																											   -- 결의전표번호
							  SUM(b.debamt) debamt,																																																						   -- 결의상태코드
							  SUM(b.creamt) creamt																																																		 -- 결의일자
					 FROM	  ACORDM a																																																																 -- 전표내역
							  JOIN ACORDD b 																																																													   -- 전표상세내역
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
							  JOIN CMCOMMONM c
								  ON c.cmmcode = 'AC20'
									 AND a.slipdiv = c.divcode
									 AND c.filter1 = 'A'
					 WHERE	  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipdiv LIKE p_slipdiv
							  AND a.slipinstate = p_slipinstate
							  AND NVL(a.eviddiv, ' ') LIKE p_eviddiv
							  AND (p_dategb = '0'
								   AND a.slipindate BETWEEN p_strdate AND p_enddate
								   OR p_dategb = '1'
									  AND a.slipdate BETWEEN p_strdate AND p_enddate)
							  AND (p_strdeptcode > ' '
								   AND a.deptcode >= p_strdeptcode
								   OR p_strdeptcode IS NULL)
							  AND (p_enddeptcode > ' '
								   AND a.deptcode <= p_enddeptcode
								   OR p_enddeptcode IS NULL)
							  AND (p_strempcode > ' '
								   AND a.empcode >= p_strempcode
								   OR p_strempcode IS NULL)
							  AND (p_endempcode > ' '
								   AND a.empcode <= p_endempcode
								   OR p_endempcode IS NULL)
							  AND (p_stracccode > ' '
								   AND b.acccode >= p_stracccode
								   OR p_stracccode IS NULL)
							  AND (p_endacccode > ' '
								   AND b.acccode <= p_endacccode
								   OR p_endacccode IS NULL)
							  AND (p_acautorcode IN ('%')
                              	   OR p_acautorcode IS NULL
								   OR p_acautorcode = a.acautorcode)
					 GROUP BY a.compcode, a.slipinno) a
							LEFT JOIN ACORDRPYR b
								ON a.compcode = b.compcode
								   AND a.slipinno = b.slipinno
							LEFT JOIN ACORDRPYD c
								ON a.compcode = c.compcode
								   AND a.slipinno = c.slipinno
								   AND c.crtslipinno IS NOT NULL) h
						 ON a.compcode = h.compcode
							AND a.slipinno = h.slipinno
			ORDER BY a.compcode, a.slipinno;
	ELSIF (UPPER(P_DIV) = 'S1') THEN
		-- 회계전표상세내역 검색
		OPEN IO_CURSOR FOR
			SELECT	 a.compcode,
					 a.slipinno,
					 a.slipinseq,
					 a.dcdiv,
					 a.acccode,
					 c.accname,
					 c.dcdiv adcdiv,
					 a.debamt,
					 a.creamt,
					 a.remark1,
					 a.remark2,
					 a.fundcode,
					 f.fundname,
					 case when d.taxno is null then '' else d.taxno || '-' || d.electaxyn end as taxno,
					 d.amt taxamt,
					 d.vat taxvat,
					 b.mngclucode1,
					 b.mngclucode2,
					 b.mngclucode3,
					 b.mngclucode4,
					 b.mngclucode5,
					 b.mngclucode6,
					 b.mngcluval1,
					 b.mngcluval2,
					 b.mngcluval3,
					 b.mngcluval4,
					 b.mngcluval5,
					 b.mngcluval6,
					 b.mngcludec1,
					 b.mngcludec2,
					 b.mngcludec3,
					 b.mngcludec4,
					 b.mngcludec5,
					 b.mngcludec6,
					 NVL(e.usediv, '9') usediv,
					 NVL(e.popdiv, '') popdiv,
					 NVL(e.accdiv, '') accdiv
			FROM	 ACORDD a
					 LEFT JOIN (SELECT	 slipinseq,
										 MAX(CASE WHEN seq = 1 THEN mngclucode ELSE '' END) mngclucode1,
										 MAX(CASE WHEN seq = 2 THEN mngclucode ELSE '' END) mngclucode2,
										 MAX(CASE WHEN seq = 3 THEN mngclucode ELSE '' END) mngclucode3,
										 MAX(CASE WHEN seq = 4 THEN mngclucode ELSE '' END) mngclucode4,
										 MAX(CASE WHEN seq = 5 THEN mngclucode ELSE '' END) mngclucode5,
										 MAX(CASE WHEN seq = 6 THEN mngclucode ELSE '' END) mngclucode6,
										 MAX(CASE WHEN seq = 1 THEN mngcluval ELSE '' END) mngcluval1,
										 MAX(CASE WHEN seq = 2 THEN mngcluval ELSE '' END) mngcluval2,
										 MAX(CASE WHEN seq = 3 THEN mngcluval ELSE '' END) mngcluval3,
										 MAX(CASE WHEN seq = 4 THEN mngcluval ELSE '' END) mngcluval4,
										 MAX(CASE WHEN seq = 5 THEN mngcluval ELSE '' END) mngcluval5,
										 MAX(CASE WHEN seq = 6 THEN mngcluval ELSE '' END) mngcluval6,
										 MAX(CASE WHEN seq = 1 THEN mngcludec || businessno ELSE '' END) mngcludec1,
										 MAX(CASE WHEN seq = 2 THEN mngcludec || businessno ELSE '' END) mngcludec2,
										 MAX(CASE WHEN seq = 3 THEN mngcludec || businessno ELSE '' END) mngcludec3,
										 MAX(CASE WHEN seq = 4 THEN mngcludec || businessno ELSE '' END) mngcludec4,
										 MAX(CASE WHEN seq = 5 THEN mngcludec || businessno ELSE '' END) mngcludec5,
										 MAX(CASE WHEN seq = 6 THEN mngcludec || businessno ELSE '' END) mngcludec6
								FROM	 (SELECT a.slipinseq,
												 ROW_NUMBER() OVER (PARTITION BY a.slipinseq ORDER BY a.seq) seq,
												 a.mngclucode,
												 a.mngcluval,
												 a.mngcludec,
												 NVL(' ' || b.businessno, '') businessno
										  FROM	 ACORDS a
												 LEFT JOIN CMCUSTM b
													 ON a.mngclucode = 'S010'
														AND a.mngcluval = b.custcode
										  WHERE  a.compcode = p_compcode
												 AND a.slipinno = NVL(p_slipinno,' ')) a
								GROUP BY slipinseq) b
						 ON a.slipinseq = b.slipinseq
					 LEFT JOIN ACACCM c ON a.acccode = c.acccode
					 LEFT JOIN ACTAXM D
						 ON a.compcode = D.compcode
							AND a.taxno = D.taxno
					 LEFT JOIN (SELECT NVL(a.filter1, '') acccode,
									   NVL(a.filter2, '') accdiv,
									   NVL(TRIM(b.filter1), '0') usediv,
									   NVL(b.filter2, '') popdiv,
									   CASE
										   WHEN b.filter1 = '3'
												OR p_slipdiv = 'R'
												   AND b.filter1 = '4'
												OR p_slipdiv = 'A'
												   AND b.filter1 = '5'
										   THEN b.divname
										   ELSE ''
									   END popname
								FROM   CMCOMMONM a
									   JOIN CMCOMMONM b
										   ON a.hcmmcode = b.cmmcode
											  AND a.hdivcode = b.divcode
											  AND b.usediv = 'Y'
								WHERE  a.cmmcode = 'AC251'
									   AND a.usediv = 'Y') e
						 ON NVL(a.acccode,' ') LIKE NVL(e.acccode, '%') || '%'
					 LEFT JOIN ACFUNDM f
						 ON a.compcode = f.compcode
							AND a.fundcode = f.fundcode
			WHERE	 a.compcode = p_compcode
					 AND NVL(a.slipinno,' ') = NVL(p_slipinno,' ')
			ORDER BY a.slipinseq;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
