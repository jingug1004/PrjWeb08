CREATE PROCEDURE        spACacc0214R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0214R
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-10-08
	-- 수 정 자      : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자       : 2016-12-21
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 결손금처리계산서를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_rptdiv		IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '',
	p_basisym		IN	   VARCHAR2 DEFAULT '',
	p_viewyn		IN	   VARCHAR2 DEFAULT 'Y',
	p_pretype		IN	   VARCHAR2 DEFAULT '1',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	p_basisyy	 VARCHAR2(4);
	p_beyymm	 VARCHAR2(7);
	p_yyyy01	 VARCHAR2(7);
	p_beyy01	 VARCHAR2(7);
	p_cashcode	 VARCHAR2(20);
	-- 임시테이블의 calcseq의 최대값을 조회
	p_maxseq	 NUMBER(10, 0);
	p_curseq	 NUMBER(10, 0);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S' OR p_div = 'P')
	THEN
		-- 기간 설정
		p_yyyy01 := SUBSTR(p_basisym, 0, 4) || '-01';

		FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
					FROM   ACSESSION
					WHERE  compcode = p_compcode
						   AND cyear <= SUBSTR(p_basisym, 0, 4))
		LOOP
			p_yyyy01 := rec.alias1;
		END LOOP;

		IF SUBSTR(p_basisym, -2, 2) < SUBSTR(p_yyyy01, -2, 2)
		THEN
			p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), -12), 'YYYY-') || SUBSTR(p_yyyy01, -2, 2);
		ELSE
			p_yyyy01 := SUBSTR(p_basisym, 0, 5) || SUBSTR(p_yyyy01, -2, 2);
		END IF;

		IF p_pretype = '1'
		THEN
			p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), -12), 'YYYY-MM');
		ELSIF p_pretype = '2' OR p_pretype = '3' AND SUBSTR(p_basisym, -2, 2) = SUBSTR(p_yyyy01, -2, 2) THEN
            p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01, 'YYYY-MM'), -1), 'YYYY-MM');
        ELSE
            p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), -1), 'YYYY-MM');
		END IF;

		IF p_pretype = '3' AND SUBSTR(p_basisym, -2, 2) <> SUBSTR(p_yyyy01, -2, 2)
		THEN
			p_beyy01 := p_yyyy01;
		ELSE
			p_beyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01, 'YYYY-MM'), -12), 'YYYY-MM');
		END IF;

		p_beyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01, 'YYYY-MM'), -12), 'YYYY-MM');
		p_cashcode := '11101010';

		FOR rec IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'acccashcode')
		LOOP
			p_cashcode := rec.value1;
		END LOOP;

		-- 보고서 조회년도 설정
		FOR rec IN (SELECT MAX(rptyear) AS alias1
					FROM   ACRPTM
					WHERE  compcode = p_compcode
						   AND rptdiv = p_rptdiv
						   AND rptyear <= SUBSTR(p_basisym, 0, 4))
		LOOP
			p_basisyy := rec.alias1;
		END LOOP;

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0214R_ACORDDMM9 ';

		-- 전표에서 월집계 임시파일을 생성
		INSERT INTO VGT.TT_ACACC0214R_ACORDDMM9
			(SELECT   p_compcode compcode,
					  p_plantcode plantcode,
					  p_basisym slipym,
					  CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
					  acccode,
					  SUM(CASE WHEN slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), 1), 'YYYY-MM-DD') THEN totdebamt ELSE 0 END) totdebamt,
					  SUM(CASE WHEN slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), 1), 'YYYY-MM-DD') THEN totcreamt ELSE 0 END) totcreamt,
					  SUM(CASE WHEN slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01, 'YYYY-MM'), 3), 'YYYY-MM-DD') AND TO_CHAR(LAST_DAY(TO_DATE(p_basisym, 'YYYY-MM')), 'YYYY-MM-DD') THEN totdebamt ELSE 0 END) debamt0412,
					  SUM(CASE WHEN slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01, 'YYYY-MM'), 3), 'YYYY-MM-DD') AND TO_CHAR(LAST_DAY(TO_DATE(p_basisym, 'YYYY-MM')), 'YYYY-MM-DD') THEN totcreamt ELSE 0 END) creamt0412,
					  SUM(CASE WHEN TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), 1), 'YYYY-MM-DD') <= slipdate THEN totdebamt ELSE 0 END) debamt0103,
					  SUM(CASE WHEN TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), 1), 'YYYY-MM-DD') <= slipdate THEN totcreamt ELSE 0 END) creamt0103
			 FROM	  (SELECT b.acccode, a.slipdate, b.debamt totdebamt, b.creamt totcreamt
					   FROM   ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
					   WHERE  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), 4), 'YYYYMM')
							  AND a.slipinstate = '4'
							  AND (a.slipdiv NOT IN ('K', 'F')
								   OR p_closediv = '1'
									  AND a.slipdiv = 'K'
								   OR p_closediv = '2'
									  AND a.slipdiv = 'F')
					   UNION ALL
					   SELECT p_cashcode acccode, a.slipdate, b.creamt totdebamt, b.debamt totcreamt
					   FROM   ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
									 AND b.dcdiv IN ('3', '4')
					   WHERE  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), 4), 'YYYYMM')
							  AND a.slipinstate = '4'
							  AND (a.slipdiv NOT IN ('K', 'F')
								   OR p_closediv = '1'
									  AND a.slipdiv = 'K'
								   OR p_closediv = '2'
									  AND a.slipdiv = 'F')
					   UNION ALL
					   SELECT acccode, p_yyyy01 || '-00' slipdate, bsdebamt totdebamt, bscreamt totcreamt
					   FROM   ACORDDMM
					   WHERE  compcode = p_compcode
							  AND plantcode LIKE p_plantcode
							  AND slipym = p_yyyy01
							  AND (p_closediv = '1'
								   AND closediv IN ('10', '20')
								   OR p_closediv = '2'
									  AND closediv IN ('10', '30'))) a
			 GROUP BY acccode);

		INSERT INTO VGT.TT_ACACC0214R_ACORDDMM9
			(SELECT   p_compcode compcode,
					  p_plantcode plantcode,
					  p_beyymm slipym,
					  CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
					  acccode,
					  SUM(CASE WHEN slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm, 'YYYY-MM'), 1), 'YYYY-MM-DD') THEN totdebamt ELSE 0 END) totdebamt,
					  SUM(CASE WHEN slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm, 'YYYY-MM'), 1), 'YYYY-MM-DD') THEN totcreamt ELSE 0 END) totcreamt,
					  SUM(CASE WHEN slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_beyy01, 'YYYY-MM'), 1), 'YYYY-MM-DD') AND TO_CHAR(LAST_DAY(TO_DATE(p_beyymm, 'YYYY-MM')), 'YYYY-MM-DD') THEN totdebamt ELSE 0 END) debamt0412,
					  SUM(CASE WHEN slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_beyy01, 'YYYY-MM'), 1), 'YYYY-MM-DD') AND TO_CHAR(LAST_DAY(TO_DATE(p_beyymm, 'YYYY-MM')), 'YYYY-MM-DD') THEN totcreamt ELSE 0 END) creamt0412,
					  SUM(CASE WHEN TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm, 'YYYY-MM'), 1), 'YYYY-MM-DD') <= slipdate THEN totdebamt ELSE 0 END) debamt0103,
					  SUM(CASE WHEN TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm, 'YYYY-MM'), 1), 'YYYY-MM-DD') <= slipdate THEN totcreamt ELSE 0 END) creamt0103
			 FROM	  (SELECT b.acccode, a.slipdate, b.debamt totdebamt, b.creamt totcreamt
					   FROM   ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
					   WHERE  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipno BETWEEN REPLACE(p_beyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm, 'YYYY-MM'), 4), 'YYYYMM')
							  AND a.slipinstate = '4'
							  AND (a.slipdiv NOT IN ('K', 'F')
								   OR p_closediv = '1'
									  AND a.slipdiv = 'K'
								   OR p_closediv = '2'
									  AND a.slipdiv = 'F')
					   UNION ALL
					   SELECT p_cashcode acccode, a.slipdate, b.creamt totdebamt, b.debamt totcreamt
					   FROM   ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
									 AND b.dcdiv IN ('3', '4')
					   WHERE  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipno BETWEEN REPLACE(p_beyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm, 'YYYY-MM'), 4), 'YYYYMM')
							  AND a.slipinstate = '4'
							  AND (a.slipdiv NOT IN ('K', 'F')
								   OR p_closediv = '1'
									  AND a.slipdiv = 'K'
								   OR p_closediv = '2'
									  AND a.slipdiv = 'F')
					   UNION ALL
					   SELECT acccode, p_beyy01 || '-00' slipdate, bsdebamt totdebamt, bscreamt totcreamt
					   FROM   ACORDDMM
					   WHERE  compcode = p_compcode
							  AND plantcode LIKE p_plantcode
							  AND slipym = p_beyy01
							  AND (p_closediv = '1'
								   AND closediv IN ('10', '20')
								   OR p_closediv = '2'
									  AND closediv IN ('10', '30'))) a
			 GROUP BY acccode);

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0214R_ACC214A ';

		-- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
		INSERT INTO VGT.TT_ACACC0214R_ACC214A(seqline,
											  acccode,
											  accrname,
											  acckname,
											  lrdiv,
											  prtyn,
											  prtdiv,
											  prtbold,
											  sseqline,
											  calcseq,
											  calcdiv,
											  cseqline,
											  cgb,
											  objdatadiv,
											  remark,
											  amt,
											  beamt)
			SELECT	 a.seqline,
					 MAX(a.acccode),
					 MAX(a.accrname),
					 MAX(a.acckname),
					 MAX(a.lrdiv),
					 MAX(a.prtyn),
					 MAX(a.prtdiv),
					 MAX(a.prtbold),
					 MAX(a.sseqline),
					 MAX(a.calcseq),
					 MAX(a.calcdiv),
					 MAX(a.cseqline),
					 '1',
					 MAX(a.objdatadiv),
					 MAX(a.remark),
					 NVL(SUM(CASE
								 WHEN c.slipym = p_basisym
								 THEN
									 CASE
										 WHEN a.objdatadiv IN ('D', 'F')
											  AND a.remark = '0412'
										 THEN
											 c.debamt0412
										 WHEN a.objdatadiv IN ('D', 'F')
											  AND a.remark = '0103'
										 THEN
											 c.debamt0103
										 WHEN a.objdatadiv IN ('D', 'F')
										 THEN
											 c.totdebamt
										 WHEN a.objdatadiv IN ('C', 'E')
											  AND a.remark = '0412'
										 THEN
											 c.creamt0412
										 WHEN a.objdatadiv IN ('C', 'E')
											  AND a.remark = '0103'
										 THEN
											 c.creamt0103
										 WHEN a.objdatadiv IN ('C', 'E')
										 THEN
											 c.totcreamt
										 WHEN a.objdatadiv = 'J'
										 THEN
											 CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END
									 END
							 END),
						 0)
						 amt2,
					 NVL(SUM(CASE
								 WHEN c.slipym = p_beyymm
								 THEN
									 CASE
										 WHEN a.objdatadiv IN ('D', 'F')
											  AND a.remark = '0412'
										 THEN
											 c.debamt0412
										 WHEN a.objdatadiv IN ('D', 'F')
											  AND a.remark = '0103'
										 THEN
											 c.debamt0103
										 WHEN a.objdatadiv IN ('D', 'F')
										 THEN
											 c.totdebamt
										 WHEN a.objdatadiv IN ('C', 'E')
											  AND a.remark = '0412'
										 THEN
											 c.creamt0412
										 WHEN a.objdatadiv IN ('C', 'E')
											  AND a.remark = '0103'
										 THEN
											 c.creamt0103
										 WHEN a.objdatadiv IN ('C', 'E')
										 THEN
											 c.totcreamt
										 WHEN a.objdatadiv = 'J'
										 THEN
											 CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END
									 END
							 END),
						 0)
						 amt4
			FROM	 ACRPTM a
					 LEFT JOIN ACACCM b ON a.acccode = b.acccode
					 LEFT JOIN VGT.TT_ACACC0214R_ACORDDMM9 c
						 ON a.compcode = c.compcode
							AND c.plantcode LIKE p_plantcode
							AND c.slipym IN (p_basisym, p_beyymm)
							AND (p_closediv = '1'
								 AND c.closediv IN ('10', '20')
								 OR p_closediv = '2'
									AND c.closediv IN ('10', '30'))
							AND a.acccode = c.acccode
			WHERE	 a.compcode = p_compcode
					 AND a.rptdiv = p_rptdiv
					 AND a.rptyear = p_basisyy
					 AND a.useyn = 'Y'
			GROUP BY a.seqline
			ORDER BY a.seqline;


		-- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
		MERGE INTO VGT.TT_ACACC0214R_ACC214A a
		USING	   (SELECT A.SEQLINE,
						   A.ACCCODE,
						   A.ACCRNAME,
						   A.ACCKNAME,
						   A.LRDIV,
						   A.PRTYN,
						   A.PRTDIV,
						   A.PRTBOLD,
						   A.SSEQLINE,
						   A.CALCSEQ,
						   A.CALCDIV,
						   A.CSEQLINE,
						   A.CGB,
						   A.OBJDATADIV,
						   A.REMARK,
						   A.AMT,
						   A.CALCAMT,
						   A.BEAMT,
						   A.BECALCAMT,
						   CASE WHEN a.objdatadiv = 'A' THEN b.amt ELSE a.amt - b.amt END AS pos_2,
						   CASE WHEN a.objdatadiv = 'A' THEN b.beamt ELSE a.beamt - b.beamt END AS pos_3
					FROM   VGT.TT_ACACC0214R_ACC214A a
						   JOIN
						   (SELECT	 a.seqline,
									 NVL(SUM(CASE WHEN c.slipym = p_yyyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) amt,
									 NVL(SUM(CASE WHEN c.slipym = p_beyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) beamt
							FROM	 ACRPTM a
									 LEFT JOIN ACACCM b ON a.acccode = b.acccode
									 LEFT JOIN ACORDDMM c
										 ON a.compcode = c.compcode
											AND c.plantcode LIKE p_plantcode
											AND c.slipym IN (p_yyyy01, p_beyy01)
											AND (p_closediv = '1'
												 AND c.closediv IN ('10', '20')
												 OR p_closediv = '2'
													AND c.closediv IN ('10', '30'))
											AND a.acccode = c.acccode
							WHERE	 a.compcode = p_compcode
									 AND a.rptdiv = p_rptdiv
									 AND a.rptyear = p_basisyy
									 AND a.useyn = 'Y'
									 AND a.objdatadiv IN ('A', 'E', 'F')
							GROUP BY a.seqline) b
							   ON a.seqline = b.seqline
					WHERE  TRIM(a.remark) IS NULL) src
		ON		   (A.SEQLINE = SRC.SEQLINE)
		WHEN MATCHED
		THEN
			UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;

		-- 당기순이익을 구함
		spACacc0208R(p_div => 'S',
						   p_compcode => p_compcode,
						   p_plantcode => p_plantcode,
						   p_rptdiv => '5',
						   p_closediv => p_closediv,
						   p_basisym => p_basisym,
						   p_viewyn => 'N',
						   MESSAGE => MESSAGE,
						   IO_CURSOR => IO_CURSOR);

		IF MESSAGE <> '데이터 확인'
		THEN
			MERGE INTO VGT.TT_ACACC0214R_ACC214A a
			USING	   (SELECT A.SEQLINE,
							   b.compcode,
                               b.rptdiv,
                               b.rptyear,
							   TO_CHAR(SUBSTR(MESSAGE, 0, INSTR(MESSAGE, ';') - 1)) AS pos_2,
							   TO_CHAR(SUBSTR(MESSAGE, INSTR(MESSAGE, ';') + 1, LENGTH(MESSAGE))) AS pos_3
						FROM   VGT.TT_ACACC0214R_ACC214A a
							   JOIN ACRPTM b
								   ON b.compcode = p_compcode
									  AND b.rptdiv = p_rptdiv
									  AND b.rptyear = p_basisyy
									  AND a.seqline = b.seqline
						WHERE  b.remark = '당기순이익') src
			ON		   (A.SEQLINE = SRC.SEQLINE
						AND SRC.compcode = p_compcode
						AND SRC.rptdiv = p_rptdiv
						AND SRC.rptyear = p_basisyy)
			WHEN MATCHED
			THEN
				UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;
		END IF;

		p_curseq := 0;

		FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0214R_ACC214A)
		LOOP
			p_maxseq := rec.alias1;
		END LOOP;

		-- 각 레벨별로 sum을하여 update
		WHILE p_curseq <= p_maxseq
		LOOP
			MERGE INTO VGT.TT_ACACC0214R_ACC214A a
			USING	   (SELECT A.SEQLINE,
            				   b.sseqline,
							   a.amt + b.amt AS pos_2,
							   a.beamt + b.beamt AS pos_3
						FROM   VGT.TT_ACACC0214R_ACC214A a
							   JOIN (SELECT   sseqline, SUM(CASE WHEN calcdiv = '+' THEN amt ELSE -amt END) amt, SUM(CASE WHEN calcdiv = '+' THEN beamt ELSE -beamt END) beamt
									 FROM	  VGT.TT_ACACC0214R_ACC214A
									 WHERE	  calcseq = p_curseq
											  AND TRIM(sseqline) IS NOT NULL
									 GROUP BY sseqline) b
								   ON a.seqline = b.sseqline) src
			ON		   (A.SEQLINE = SRC.SEQLINE)
			WHEN MATCHED
			THEN
				UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;

			p_curseq := p_curseq + 1;
		END LOOP;

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACacc0214R_ACC214B ';

		INSERT INTO VGT.TT_ACacc0214R_ACC214B
			SELECT	 a.cseqline,
					 a.seqline,
					 a.amt,
					 a.beamt,
					 0,
					 0,
					 b.amt,
					 b.beamt,
					 0,
					 ROWNUM
			FROM	 VGT.TT_ACACC0214R_ACC214A a JOIN VGT.TT_ACACC0214R_ACC214A b ON a.cseqline = b.seqline
			WHERE	 (a.amt <> 0
					  OR a.beamt <> 0)
			ORDER BY a.cseqline, a.seqline DESC;

		MERGE INTO VGT.TT_ACacc0214R_ACC214B a
		USING	   (SELECT A.ORD, a.ord - b.minNo + 1 AS pos_2
					FROM   VGT.TT_ACacc0214R_ACC214B a
						   JOIN (SELECT   cseqline, MIN(ord) minNo
								 FROM	  VGT.TT_ACacc0214R_ACC214B
								 GROUP BY cseqline) b
							   ON a.cseqline = b.cseqline) src
		ON		   (A.ORD = src.ORD)
		WHEN MATCHED
		THEN
			UPDATE SET A.num = SRC.pos_2, A.amt2 = 0, A.beamt2 = 0;

		MERGE INTO VGT.TT_ACacc0214R_ACC214B a
		USING	   (SELECT A.ORD, b.amt, b.beamt,a.cseqline, b.cseqline cseqline_B,A.NUM
					FROM   VGT.TT_ACacc0214R_ACC214B a
						   JOIN (SELECT   cseqline, SUM(amt) amt, SUM(beamt) beamt
								 FROM	  VGT.TT_ACacc0214R_ACC214B
								 GROUP BY VGT.TT_ACacc0214R_ACC214B.cseqline) b
							   ON a.cseqline = b.cseqline
								  AND num = 1) src
		ON		   (A.cseqline = src.cseqline_B
        		AND A.NUM = 1)
--		ON		   (A.ORD = src.ORD)
		WHEN MATCHED
		THEN
			UPDATE SET A.amt2 = src.amt, A.beamt2 = src.beamt;

		MERGE INTO VGT.TT_ACACC0214R_ACC214A a
		USING	   (SELECT A.SEQLINE,
						   b.cseqline
					FROM   VGT.TT_ACACC0214R_ACC214A a
						   JOIN (SELECT DISTINCT cseqline FROM VGT.TT_ACacc0214R_ACC214B
								 UNION
								 SELECT seqline FROM VGT.TT_ACacc0214R_ACC214B) b
							   ON a.seqline = b.cseqline) src
		ON		   (A.SEQLINE = SRC.cseqline)
		WHEN MATCHED
		THEN
			UPDATE SET A.lrdiv = 'L';

		MERGE INTO VGT.TT_ACACC0214R_ACC214A a
		USING	   (SELECT A.SEQLINE,
						   b.seqline seqline_B,
						   b.amt3 - amt2 AS pos_2,
						   b.beamt3 - beamt2 AS pos_3
					FROM   VGT.TT_ACACC0214R_ACC214A a
						   JOIN (SELECT seqline, amt2, amt3, beamt2, beamt3
								 FROM	VGT.TT_ACacc0214R_ACC214B
								 WHERE	num = 1) b
							   ON a.seqline = b.seqline) src
		ON		   (A.SEQLINE = SRC.seqline_B)
		WHEN MATCHED
		THEN
			UPDATE SET A.calcamt = SRC.pos_2, A.becalcamt = SRC.pos_3, A.cgb = '2';

		-- 최종조회
		IF (p_div = 'P')
		THEN
			OPEN IO_CURSOR FOR
				SELECT NULLIF(CASE
								  WHEN a.lrdiv = 'L'
									   AND a.prtyn = 'Y'
								  THEN
									  a.amt
							  END,
							  0)
						   baldramt,
					   NULLIF(CASE
								  WHEN a.cgb = '2'
									   AND a.prtyn = 'Y'
								  THEN
									  a.calcamt
								  WHEN a.cgb <> '2'
									   AND a.lrdiv = 'R'
									   AND a.prtyn = 'Y'
								  THEN
									  a.amt
							  END,
							  0)
						   dramt,
					   NULL mondramt,
					   CASE WHEN a.amt >= 0 THEN a.accrname ELSE a.acckname END accname,
					   NULL moncramt,
					   NULLIF(CASE
								  WHEN a.lrdiv = 'L'
									   AND a.prtyn = 'Y'
								  THEN
									  a.beamt
							  END,
							  0)
						   cramt,
					   NULLIF(CASE
								  WHEN a.cgb = '2'
									   AND a.prtyn = 'Y'
								  THEN
									  a.becalcamt
								  WHEN a.cgb <> '2'
									   AND a.lrdiv = 'R'
									   AND a.prtyn = 'Y'
								  THEN
									  a.beamt
							  END,
							  0)
						   balcramt,
					   a.prtbold,
					   D.session1 || SUBSTR(p_basisym, 0, 4) || '년  ' || SUBSTR(p_basisym, 6, 2) || '월  ' || SUBSTR(TO_CHAR(LAST_DAY(TO_DATE(p_basisym, 'YYYY-MM')), 'YYYY-MM-DD'), -2, 2) || '일  현재' title1,
					   D.session2 || SUBSTR(p_beyymm, 0, 4) || '년  ' || SUBSTR(p_beyymm, 6, 2) || '월  ' || SUBSTR(TO_CHAR(LAST_DAY(TO_DATE(p_beyymm, 'YYYY-MM')), 'YYYY-MM-DD'), -2, 2) || '일  현재' title2,
					   CASE WHEN p_plantcode = '%' THEN '회사명 : ' || b.compname ELSE '사업장명 : ' || NVL(c.plantfullname, c.plantname) END compname,
					   '(단위 : 원)' prtunit,
					   NULL baldramt2,
					   NULL dramt2,
					   NULL mondramt2,
					   NULL accname2,
					   NULL moncramt2,
					   NULL cramt2,
					   NULL balcramt2
				FROM   VGT.TT_ACACC0214R_ACC214A a
					   LEFT JOIN CMCOMPM b ON b.compcode = p_compcode
					   LEFT JOIN CMPLANTM c ON c.plantcode = p_plantcode
					   LEFT JOIN (SELECT MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_basisym, 0, 4) THEN sseq END) || '기  ') session1, MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_beyymm, 0, 4) THEN sseq END) || '기  ') session2
								  FROM	 ACSESSION
								  WHERE  compcode = p_compcode
										 AND cyear IN (SUBSTR(p_basisym, 0, 4), SUBSTR(p_beyymm, 0, 4))) D
						   ON 1 = 1
				WHERE  a.prtdiv <> 'C'
					   AND (a.amt <> 0
							OR a.calcamt <> 0
							OR a.beamt <> 0
							OR a.becalcamt <> 0
							OR a.prtdiv = 'A');
		ELSIF (p_viewyn = 'Y')
		THEN
			OPEN IO_CURSOR FOR
				SELECT CASE WHEN amt >= 0 THEN accrname ELSE acckname END accname,
					   NULLIF(CASE
								  WHEN NVL(lrdiv,' ') = 'L'
									   AND prtyn = 'Y'
								  THEN
									  amt
							  END,
							  0)
						   amt1,
					   NULLIF(CASE
								  WHEN NVL(cgb,0) = 2
									   AND prtyn = 'Y'
								  THEN
									  calcamt
								  WHEN NVL(cgb,0) <> 2
									   AND lrdiv = 'R'
									   AND prtyn = 'Y'
								  THEN
									  amt
							  END,
							  0)
						   amt2,
					   NULLIF(CASE
								  WHEN NVL(lrdiv,' ') = 'L'
									   AND prtyn = 'Y'
								  THEN
									  beamt
							  END,
							  0)
						   amt3,
					   NULLIF(CASE
								  WHEN NVL(cgb,0) = 2
									   AND prtyn = 'Y'
								  THEN
									  becalcamt
								  WHEN NVL(cgb,0) <> 2
									   AND lrdiv = 'R'
									   AND prtyn = 'Y'
								  THEN
									  beamt
							  END,
							  0)
						   amt4,
               p_plantcode plantcode,
               p_yyyy01 || '-01' strdate,
               TO_CHAR(LAST_DAY(TO_DATE(p_basisym, 'YYYY-MM')), 'YYYY-MM-DD') enddate,
               acccode,
               p_closediv closediv,
               prtbold
				FROM   VGT.TT_ACACC0214R_ACC214A
				WHERE  prtdiv <> 'C'
					   AND (NVL(amt,0) <> 0
							OR NVL(calcamt,0) <> 0
							OR NVL(beamt,0) <> 0
							OR NVL(becalcamt,0) <> 0
							OR prtdiv = 'A');
		END IF;

		FOR rec IN (SELECT TO_CHAR(TRUNC(NVL(amt, 0))) || ';' || TO_CHAR(TRUNC(NVL(beamt, 0))) AS alias1
					FROM   VGT.TT_ACACC0214R_ACC214A
					WHERE  seqline = (SELECT MAX(seqline) FROM VGT.TT_ACACC0214R_ACC214A))
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;
	ELSIF (p_div = 'Y')
	THEN
		OPEN IO_CURSOR FOR
			SELECT *
			FROM   (SELECT	 CASE WHEN cyear = SUBSTR(p_basisym, 0, 4) THEN sseq ELSE sseq - TO_NUMBER(cyear) + TO_NUMBER(SUBSTR(p_basisym, 0, 4)) END sseq
					FROM	 ACSESSION
					WHERE	 compcode = p_compcode
							 AND cyear <= SUBSTR(p_basisym, 0, 4)
					ORDER BY cyear DESC)
			WHERE  ROWNUM <= 1;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
