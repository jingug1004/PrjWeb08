CREATE PROCEDURE        spACbase0016P
-- ---------------------------------------------------------------
-- 프로시저명     : spACbase0016P
-- 작 성 자         : 최용석
-- 작성일자        : 2017-09-19
-- ---------------------------------------------------------------
-- 프로시저 설명 : 법인카드 정리자(ACCRDMNG)를 등록,수정,삭제,조회하는 프로시저이다.
-- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '',

    p_compcode      IN VARCHAR2 DEFAULT '',
    p_cardno        IN VARCHAR2 DEFAULT '',
    p_deptcode      IN VARCHAR2 DEFAULT '',
    p_empcode       IN VARCHAR2 DEFAULT '',
    p_cempcode      IN VARCHAR2 DEFAULT '',
    p_iempcode      IN VARCHAR2 DEFAULT '',

    p_userid        IN VARCHAR2 DEFAULT '',
    p_reasondiv     IN VARCHAR2 DEFAULT '',
    p_reasontext    IN VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    v_temp             NUMBER := 0;

BEGIN

    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    if (p_div = 'S') then
        open IO_CURSOR for
        select  nvl(a.cardno, '') as cardno,
                nvl(a.cardname, '') as cardname,
                nvl(a.cardcls, '') as cardcls,
                nvl(a.cardcustom, '') as cardcustom,
                nvl(a.deptcode, '') as deptcode,
                nvl(b.deptname, '') as deptname,
                nvl(a.empcode, '') as empcode,
                nvl(c.empname, '') as empname,
                nvl(d.empcode, '') as mngcode,
                nvl(e.empname, '') as mngname,
                nvl(d.cempcode, '') as concode,
                nvl(f.empname, '') as conname
        from    ACCARDM a
                left join CMDEPTM b
                    on a.deptcode = b.deptcode
                left join CMEMPM c
                    on a.empcode = c.empcode
                left join ACCRDMNG d
                    on a.compcode = d.compcode
                    and a.cardno = d.cardno
                left join CMEMPM e
                    on d.empcode = e.empcode
                left join CMEMPM f
                    on d.cempcode = f.empcode
        where   a.compcode = p_compcode
                and replace(replace(a.cardno, '_', ''), '-', '') like '%' || replace(replace(p_cardno, '_', ''), '-', '') || '%'
                and nvl(a.deptcode, ' ') like p_deptcode || '%'
                and a.useyn = 'Y'
        order by a.cardno;

    elsif (p_div = 'I') then
        select  count(*) into v_temp
        from    ACCRDMNG
        where   compcode = p_compcode
                and cardno = p_cardno;

        if v_temp = 1 and p_empcode is null and p_cempcode is null then
            delete
            from    ACCRDMNG
            where   compcode = p_compcode
                    and cardno = p_cardno;
        elsif v_temp = 1 then
            update  ACCRDMNG
            set     empcode = p_empcode,
                    cempcode = p_cempcode,
                    updatedt = sysdate,
                    uempcode = p_iempcode
            where   compcode = p_compcode
                    and cardno = p_cardno;
        else
            insert into ACCRDMNG
                (
                    compcode,
                    cardno,
                    empcode,
                    cempcode,
                    insertdt,
                    iempcode
                )
            values
                (
                    p_compcode,
                    p_cardno,
                    p_empcode,
                    p_cempcode,
                    sysdate,
                    p_iempcode
                );
        end if;

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
