CREATE PROCEDURE        spACacc0236R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0236R
 -- 작 성 자         : 최용석
 -- 작성일자         : 2015-08-17
 --수정자         : 임정호
 -- 작성일자         : 2016-12-26
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 사업장별 손익계산서를 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_rptdiv        IN VARCHAR2 DEFAULT '' ,
    p_closediv      IN VARCHAR2 DEFAULT '' ,
    p_basisym       IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,
    IO_CURSOR       OUT TYPES.DataSet,
    MESSAGE         OUT VARCHAR2
)
AS

    p_yyyy01 VARCHAR2(7);
    p_plantcode VARCHAR2(4);
    p_seq NUMBER(10,0);


BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( p_div = 'T' ) THEN

      OPEN  IO_CURSOR FOR
         SELECT plantcode ,
                plantname
           FROM CMPLANTM
          WHERE  compcode = p_compcode
           ORDER BY plantcode ;

    ELSIF ( p_div = 'S' ) THEN

         -- 기간 설정
        p_yyyy01 := SUBSTR(p_basisym, 1, 4) || '-01' ;

        FOR  rec IN
        (
            SELECT  SUBSTR(curstrdate, 1, 7)  AS alias1
            FROM    ACSESSION
            WHERE   compcode = p_compcode
                    AND cyear <= SUBSTR(p_basisym, 1, 4)
        )
        LOOP
            p_yyyy01 := rec.alias1   ;
        END LOOP;

        IF SUBSTR(p_basisym, -2) < SUBSTR(p_yyyy01, -2) THEN
            p_yyyy01 := TO_CHAR(ADD_MONTHS (TO_DATE (p_basisym || '-01'),-12),'YYYY-') || SUBSTR (p_yyyy01,-2);
        ELSE
            p_yyyy01 := SUBSTR(p_basisym, 1, 5) || SUBSTR(p_yyyy01, -2) ;
        END IF;


        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0236R_ACC236';

        INSERT INTO VGT.TT_ACACC0236R_ACC236
        SELECT  0 ,
                seqline ,
                acccode ,
                accrname ,
                prtbold ,
                NULLIF(CASE WHEN prtyn = 'Y' THEN amt   END, 0) amt
        FROM    TABLE(fnMakeACRPTM2(p_compcode, '%', p_rptdiv, p_closediv, p_yyyy01, p_basisym))
        WHERE   prtdiv <> 'C'
            AND ( amt <> 0 OR prtdiv = 'A' ) ;

        FOR REC IN
        (
            SELECT  ROW_NUMBER() OVER ( ORDER BY plantcode  ) seq  , plantcode
            FROM    CMPLANTM
            WHERE   compcode = p_compcode
            ORDER BY plantcode
        )

        LOOP
            p_seq          :=rec.seq;
            p_plantcode    :=rec.plantcode;
            INSERT INTO VGT.TT_ACACC0236R_ACC236
            SELECT  p_seq ,
                    seqline ,
                    acccode ,
                    accrname ,
                    prtbold ,
                    NULLIF(CASE WHEN prtyn = 'Y' THEN amt   END, 0) amt
            FROM    TABLE(fnMakeACRPTM2(p_compcode, p_plantcode, p_rptdiv, p_closediv, p_yyyy01, p_basisym))
            WHERE   prtdiv <> 'C'
                AND ( amt <> 0 OR prtdiv = 'A' ) ;
         END LOOP;


        OPEN  IO_CURSOR FOR
        SELECT MAX(accname)  accname  ,
                   SUM(CASE WHEN plantseq = 0 THEN amt   END)  amt00  ,
                   SUM(CASE WHEN plantseq = 1 THEN amt   END)  amt01  ,
                   SUM(CASE WHEN plantseq = 2 THEN amt   END)  amt02  ,
                   SUM(CASE WHEN plantseq = 3 THEN amt   END)  amt03  ,
                   SUM(CASE WHEN plantseq = 4 THEN amt   END)  amt04  ,
                   SUM(CASE WHEN plantseq = 5 THEN amt   END)  amt05  ,
                   SUM(CASE WHEN plantseq = 6 THEN amt   END)  amt06  ,
                   SUM(CASE WHEN plantseq = 7 THEN amt   END)  amt07  ,
                   SUM(CASE WHEN plantseq = 8 THEN amt   END)  amt08  ,
                   SUM(CASE WHEN plantseq = 9 THEN amt   END)  amt09  ,
                   SUM(CASE WHEN plantseq = 10 THEN amt   END)  amt10  ,
                   SUBSTR(p_basisym, 0, 4) || '-01-01' strdate ,
                   TO_CHAR(LAST_DAY(TO_DATE(p_basisym || '-01','YYYY-MM-DD')),'YYYY-MM-DD') enddate  ,
                   MAX(acccode)  acccode  ,
                   p_closediv    closediv ,
                   MAX(prtbold)  prtbold
              FROM  VGT.TT_ACACC0236R_ACC236
              GROUP BY seqline
              ORDER BY seqline ;
    END IF;



    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
