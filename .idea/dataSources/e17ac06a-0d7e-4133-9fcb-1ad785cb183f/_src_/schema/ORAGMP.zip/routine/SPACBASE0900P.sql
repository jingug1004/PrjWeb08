CREATE PROCEDURE        spACbase0900P
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACbase0900P
   -- 작 성 자         : 민승기
   -- 작성일자         : 2010-11-04
   --수정장            : 임정호
   --수정일            : 2016-12-12
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 회계전표 기초잔액 테이블 내역을 등록하는 프로시저이다.
   -- ---------------------------------------------------------------

(
   p_div          IN     VARCHAR2 DEFAULT ' ',
   p_compcode     IN     VARCHAR2 DEFAULT ' ',
   p_plantcode    IN     VARCHAR2 DEFAULT ' ',
   p_slipym       IN     VARCHAR2 DEFAULT ' ',
   p_closediv     IN     VARCHAR2 DEFAULT ' ',
   p_acccode      IN     VARCHAR2 DEFAULT ' ',
   p_bsdebamt     IN     FLOAT DEFAULT 0,
   p_bscreamt     IN     FLOAT DEFAULT 0,
   p_debamt       IN     FLOAT DEFAULT 0,
   p_creamt       IN     FLOAT DEFAULT 0,
   p_totdebamt    IN     FLOAT DEFAULT 0,
   p_totcreamt    IN     FLOAT DEFAULT 0,
   p_mngclucode   IN     VARCHAR2 DEFAULT ' ',
   p_mngcluval    IN     VARCHAR2 DEFAULT ' ',
   p_mngcludec    IN     VARCHAR2 DEFAULT ' ',
   p_iempcode     IN     VARCHAR2 DEFAULT ' ',
   p_cyear        IN     VARCHAR2 DEFAULT ' ',
   p_dcdiv        IN     VARCHAR2 DEFAULT ' ',
   p_userid       IN     VARCHAR2 DEFAULT ' ',
   p_reasondiv    IN     VARCHAR2 DEFAULT ' ',
   p_reasontext   IN     VARCHAR2 DEFAULT ' ',
   IO_CURSOR         OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2)
AS
BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF (p_div = 'SESS') THEN

      -- 회계기수 검색

      FOR rec IN (SELECT a.sseq AS alias1
                    FROM ACSESSION a
                   WHERE a.compcode = p_compcode
                   AND a.cyear = p_cyear)
      LOOP
         MESSAGE := rec.alias1;
      END LOOP;
    ELSIF (p_div = 'RMK')  THEN

        -- 코드헬프 검색
        OPEN IO_CURSOR FOR
        SELECT  NVL (codehelp, '') codehelp,                        -- 코드헬프번호
                NVL (remark, '') codermk -- 코드헬프비고
           FROM ACMNGM
          WHERE mngclucode = p_mngclucode;
    ELSIF (p_div = 'MNG') THEN

      -- 계정에 대한 콤보셋팅
        OPEN IO_CURSOR FOR
        SELECT a.mngclucode keyfield,
              a.mngcluname displayfield,
              NVL (c.mngcludiv, '') mngcludiv                   -- 관리항목형태
         FROM ACACCMNGM a
              JOIN ACACCM b ON a.acccode = b.acccode
              JOIN ACMNGM c ON a.mngclucode = c.mngclucode
        WHERE     a.acccode = p_acccode
              AND a.dcdiv = p_dcdiv
              AND a.remainyn = 'Y'
        ORDER BY a.seq;
    ELSIF (p_div = 'SD') THEN

      -- 계정별 잔액조회
        OPEN IO_CURSOR FOR
        SELECT  NVL (a.compcode, '') compcode,                      -- 회사코드
                NVL (a.plantcode, '') plantcode,                   -- 사업장코드
                NVL (a.slipym, '') slipym,                          -- 회계년월
                NVL (a.closediv, '') closediv,                      -- 결산구분
                NVL (a.acccode, '') acccode,                        -- 계정코드
                NVL (a.bsdebamt, 0) bsdebamt,                      -- 기초차변금액
                NVL (a.bscreamt, 0) bscreamt,                      -- 기초대변금액
                NVL (a.debamt, 0) debamt,                            -- 차변금액
                NVL (a.creamt, 0) creamt,                            -- 대변금액
                NVL (a.totdebamt, 0) totdebamt,                    -- 누계차변금액
                NVL (a.totcreamt, 0) totcreamt,                    -- 누계대변금액
                CASE
                    WHEN b.dcdiv = '1' THEN
                        NVL (a.totdebamt, 0) - NVL (a.totcreamt, 0)
                    ELSE
                        NVL (a.totcreamt, 0) - NVL (a.totdebamt, 0)
                END  fnlamt,                                             -- 잔액
                NVL (b.accname, '') accname,                            -- 계정명
                NVL (b.dcdiv, '') dcdiv,                               -- 차대구분코드
                NVL (ac04.divname, '') dcdivname                       -- 차대구분명
         FROM ACORDDMM a
              JOIN ACACCM b ON a.acccode = b.acccode
              LEFT JOIN CMCOMMONM ac04                             -- 차대구분
                 ON ac04.cmmcode = 'AC04' AND b.dcdiv = ac04.divcode
        WHERE     a.compcode = p_compcode
              AND a.plantcode = p_plantcode
              AND a.slipym = p_slipym
              AND a.closediv = p_closediv
              AND a.acccode LIKE p_acccode || '%'
        ORDER BY a.acccode;

   ELSIF (p_div = 'SS') THEN
       -- 계정 관리항목별 잔액조회
        OPEN IO_CURSOR FOR
        SELECT  NVL (a.compcode, '') compcode,                      -- 회사코드
                NVL (a.plantcode, '') plantcode,                   -- 사업장코드
                NVL (a.slipym, '') slipym,                          -- 회계년월
                NVL (a.closediv, '') closediv,                      -- 결산구분
                NVL (a.acccode, '') acccode,                        -- 계정코드
                NVL (a.mngclucode, '') mngclucode,                -- 관리항목코드
                NVL (a.mngcluval, '') mngcluval,                   -- 관리항목값
                NVL (a.mngcludec, '') mngcludec,                  -- 관리항목값명
                NVL (a.bsdebamt, 0) bsdebamt,                      -- 기초차변금액
                NVL (a.bscreamt, 0) bscreamt,                      -- 기초대변금액
                NVL (a.debamt, 0) debamt,                            -- 차변금액
                NVL (a.creamt, 0) creamt,                            -- 대변금액
                NVL (a.totdebamt, 0) totdebamt,                    -- 누계차변금액
                NVL (a.totcreamt, 0) totcreamt,                    -- 누계대변금액
                CASE
                 WHEN b.dcdiv = '1'
                 THEN
                    NVL (a.totdebamt, 0) - NVL (a.totcreamt, 0)
                 ELSE
                    NVL (a.totcreamt, 0) - NVL (a.totdebamt, 0)
                END
                 fnlamt,                                             -- 잔액
                NVL (b.accname, '') accname,                         -- 계정명
                NVL (c.mngcluname, '') mngcluname                  -- 관리항목명
         FROM   ACORDSMM a
                JOIN ACACCM b ON a.acccode = b.acccode
                LEFT JOIN ACMNGM c ON a.mngclucode = c.mngclucode
        WHERE     a.compcode = p_compcode
              AND a.plantcode = p_plantcode
              AND a.slipym = p_slipym
              AND a.closediv = p_closediv
              AND a.acccode = p_acccode
              AND a.mngclucode = p_mngclucode
        ORDER BY a.acccode;
   ELSIF (p_div = 'ID') THEN

      -- 계정별 잔액등록
      INSERT INTO ACORDDMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
                    VALUES (p_compcode,
                           p_plantcode,
                           p_slipym,
                           p_closediv,
                           p_acccode,
                           p_bsdebamt,
                           p_bscreamt,
                           p_debamt,
                           p_creamt,
                           p_totdebamt,
                           p_totcreamt);

   ELSIF (p_div = 'UD')    THEN
      -- 계정별 잔액수정
      UPDATE ACORDDMM
         SET bsdebamt = p_bsdebamt,
             bscreamt = p_bscreamt,
             debamt = p_debamt,
             creamt = p_creamt,
             totdebamt = p_totdebamt,
             totcreamt = p_totcreamt
       WHERE     compcode = p_compcode
             AND plantcode = p_plantcode
             AND slipym = p_slipym
             AND closediv = p_closediv
             AND acccode = p_acccode;

   ELSIF (p_div = 'DD')    THEN

      -- 계정별 잔액삭제

        DELETE FROM ACORDDMM
        WHERE   compcode = p_compcode
            AND plantcode = p_plantcode
            AND slipym = p_slipym
            AND closediv = p_closediv
            AND acccode = p_acccode;
   ELSIF (p_div = 'IS') THEN

      -- 계정 관리항목별 잔액등록
      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
                   VALUES (p_compcode,
                           p_plantcode,
                           p_slipym,
                           p_closediv,
                           p_acccode,
                           p_mngclucode,
                           p_mngcluval,
                           p_mngcludec,
                           p_bsdebamt,
                           p_bscreamt,
                           p_debamt,
                           p_creamt,
                           p_totdebamt,
                           p_totcreamt);

   ELSIF (p_div = 'US') THEN
      -- 계정 관리항목별 잔액수정

      UPDATE ACORDSMM
         SET mngcludec = p_mngcludec,
             bsdebamt = p_bsdebamt,
             bscreamt = p_bscreamt,
             debamt = p_debamt,
             creamt = p_creamt,
             totdebamt = p_totdebamt,
             totcreamt = p_totcreamt
       WHERE compcode = p_compcode
         AND plantcode = p_plantcode
         AND slipym = p_slipym
         AND closediv = p_closediv
         AND acccode = p_acccode
         AND mngclucode = p_mngclucode
         AND mngcluval = p_mngcluval;

   ELSIF (p_div = 'DS')    THEN

      -- 계정 관리항목별 잔액삭제
        DELETE  FROM    ACORDSMM
        WHERE   compcode = p_compcode
            AND plantcode = p_plantcode
            AND slipym = p_slipym
            AND closediv = p_closediv
            AND acccode = p_acccode
            AND mngclucode = p_mngclucode
            AND mngcluval = p_mngcluval;
   ELSIF (p_div = 'DSALL') THEN

      -- 계정 관리항목 전체삭제

      DELETE FROM ACORDSMM
      WHERE     compcode = p_compcode
            AND plantcode = p_plantcode
            AND slipym = p_slipym
            AND closediv = p_closediv
            AND acccode = p_acccode;

   ELSIF (p_div = 'CD') THEN
      -- 계정생성
      INSERT INTO ACORDDMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
         (SELECT p_compcode,
                 p_plantcode,
                 p_slipym,
                 p_closediv,
                 a.acccode,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0
            FROM ACACCM a
                 LEFT JOIN
                 ACORDDMM c
                    ON     c.compcode = p_compcode
                       AND c.plantcode = p_plantcode
                       AND c.slipym = p_slipym
                       AND c.closediv = p_closediv
                       AND a.acccode = c.acccode
           WHERE     a.acccode LIKE p_acccode || '%'
                 AND a.remainyn = 'Y'
                 AND a.orduseyn = 'Y'
                 AND c.acccode IS NULL);

   ELSIF (p_div = 'S010')    THEN

      -- 계정 관리항목생성 (거래처코드)

      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
                 (SELECT    p_compcode,
                            p_plantcode,
                            p_slipym,
                            p_closediv,
                            b.acccode,
                            b.mngclucode,
                            D.code,
                            D.NAME,
                            0,
                            0,
                            0,
                            0,
                            0,
                            0
                    FROM ACACCM a
                         JOIN
                         ACACCMNGM b
                            ON     a.acccode = b.acccode
                               AND b.dcdiv = p_dcdiv
                               AND b.mngclucode = p_div
                         JOIN
                         (SELECT to_char(custcode) code,
                                 to_char(custname) NAME
                            FROM CMCUSTM
                           WHERE plantcode = p_plantcode) D
                            ON 1 = 1
                         LEFT JOIN
                         ACORDSMM c
                            ON     c.compcode = p_compcode
                               AND c.plantcode = p_plantcode
                               AND c.slipym = p_slipym
                               AND c.closediv = p_closediv
                               AND b.acccode = c.acccode
                               AND b.mngclucode = c.mngclucode
                               AND D.code = c.mngcluval
                    WHERE a.acccode = p_acccode AND c.acccode IS NULL);

   ELSIF (p_div = 'S020')    THEN

      -- 계정 관리항목생성 (예금계좌)

      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
                     (SELECT p_compcode,
                             p_plantcode,
                             p_slipym,
                             p_closediv,
                             b.acccode,
                             b.mngclucode,
                             D.code,
                             D.NAME,
                             0,
                             0,
                             0,
                             0,
                             0,
                             0
                        FROM ACACCM a
                             JOIN
                             ACACCMNGM b
                                ON     a.acccode = b.acccode
                                   AND b.dcdiv = p_dcdiv
                                   AND b.mngclucode = p_div
                             JOIN
                             (SELECT to_char (accountno) code,
                                     to_char (accremark) NAME
                                FROM CMACCOUNTM
                               WHERE compcode = p_compcode AND plantcode = p_plantcode) D
                                ON 1 = 1
                             LEFT JOIN
                             ACORDSMM c
                                ON     c.compcode = p_compcode
                                   AND c.plantcode = p_plantcode
                                   AND c.slipym = p_slipym
                                   AND c.closediv = p_closediv
                                   AND b.acccode = c.acccode
                                   AND b.mngclucode = c.mngclucode
                                   AND D.code = c.mngcluval
                       WHERE a.acccode = p_acccode AND c.acccode IS NULL);

   ELSIF (p_div = 'S030') THEN

      -- 계정 관리항목생성 (은행코드)

      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
                     (SELECT p_compcode,
                             p_plantcode,
                             p_slipym,
                             p_closediv,
                             b.acccode,
                             b.mngclucode,
                             D.code,
                             D.NAME,
                             0,
                             0,
                             0,
                             0,
                             0,
                             0
                        FROM ACACCM a
                             JOIN
                             ACACCMNGM b
                                ON     a.acccode = b.acccode
                                   AND b.dcdiv = p_dcdiv
                                   AND b.mngclucode = p_div
                             JOIN
                             (SELECT to_char (bankcode) code,
                                     to_char (bankname) NAME
                                FROM CMBANKM
                               WHERE plantcode = p_plantcode) D
                                ON 1 = 1
                             LEFT JOIN
                             ACORDSMM c
                                ON     c.compcode = p_compcode
                                   AND c.plantcode = p_plantcode
                                   AND c.slipym = p_slipym
                                   AND c.closediv = p_closediv
                                   AND b.acccode = c.acccode
                                   AND b.mngclucode = c.mngclucode
                                   AND D.code = c.mngcluval
                       WHERE a.acccode = p_acccode AND c.acccode IS NULL);

   ELSIF (p_div = 'S040') THEN

      -- 계정 관리항목생성 (부서코드)
      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
                     (SELECT p_compcode,
                             p_plantcode,
                             p_slipym,
                             p_closediv,
                             b.acccode,
                             b.mngclucode,
                             D.code,
                             D.NAME,
                             0,
                             0,
                             0,
                             0,
                             0,
                             0
                        FROM ACACCM a
                             JOIN
                             ACACCMNGM b
                                ON     a.acccode = b.acccode
                                   AND b.dcdiv = p_dcdiv
                                   AND b.mngclucode = p_div
                             JOIN
                             (SELECT to_char (deptcode) code,
                                     to_char (deptname) NAME
                                FROM CMDEPTM
                               WHERE plantcode = p_plantcode) D
                                ON 1 = 1
                             LEFT JOIN
                             ACORDSMM c
                                ON     c.compcode = p_compcode
                                   AND c.plantcode = p_plantcode
                                   AND c.slipym = p_slipym
                                   AND c.closediv = p_closediv
                                   AND b.acccode = c.acccode
                                   AND b.mngclucode = c.mngclucode
                                   AND D.code = c.mngcluval
                       WHERE a.acccode = p_acccode AND c.acccode IS NULL);
    ELSIF (p_div = 'S050') THEN

      -- 계정 관리항목생성 (사원코드)

        INSERT INTO ACORDSMM (  compcode,
                                plantcode,
                                slipym,
                                closediv,
                                acccode,
                                mngclucode,
                                mngcluval,
                                mngcludec,
                                bsdebamt,
                                bscreamt,
                                debamt,
                                creamt,
                                totdebamt,
                                totcreamt)
                         (SELECT p_compcode,
                                 p_plantcode,
                                 p_slipym,
                                 p_closediv,
                                 b.acccode,
                                 b.mngclucode,
                                 D.code,
                                 D.NAME,
                                 0,
                                 0,
                                 0,
                                 0,
                                 0,
                                 0
                            FROM ACACCM a
                                 JOIN
                                 ACACCMNGM b
                                    ON     a.acccode = b.acccode
                                       AND b.dcdiv = p_dcdiv
                                       AND b.mngclucode = p_div
                                 JOIN
                                 (SELECT to_char (empcode) code,
                                         to_char (empname) NAME
                                    FROM CMEMPM
                                   WHERE plantcode = p_plantcode) D
                                    ON 1 = 1
                                 LEFT JOIN
                                 ACORDSMM c
                                    ON     c.compcode = p_compcode
                                       AND c.plantcode = p_plantcode
                                       AND c.slipym = p_slipym
                                       AND c.closediv = p_closediv
                                       AND b.acccode = c.acccode
                                       AND b.mngclucode = c.mngclucode
                                       AND D.code = c.mngcluval
                           WHERE a.acccode = p_acccode AND c.acccode IS NULL);

    ELSIF (p_div = 'S060') THEN

        -- 계정 관리항목생성 (카드코드)

        INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
                     (SELECT p_compcode,
                             p_plantcode,
                             p_slipym,
                             p_closediv,
                             b.acccode,
                             b.mngclucode,
                             D.code,
                             D.NAME,
                             0,
                             0,
                             0,
                             0,
                             0,
                             0
                        FROM ACACCM a
                             JOIN
                             ACACCMNGM b
                                ON     a.acccode = b.acccode
                                   AND b.dcdiv = p_dcdiv
                                   AND b.mngclucode = p_div
                             JOIN
                             (SELECT to_char (cardno) code,
                                     to_char (cardname) NAME
                                FROM ACCARDM
                               WHERE compcode = p_compcode AND plantcode = p_plantcode) D
                                ON 1 = 1
                             LEFT JOIN
                             ACORDSMM c
                                ON     c.compcode = p_compcode
                                   AND c.plantcode = p_plantcode
                                   AND c.slipym = p_slipym
                                   AND c.closediv = p_closediv
                                   AND b.acccode = c.acccode
                                   AND b.mngclucode = c.mngclucode
                                   AND D.code = c.mngcluval
                       WHERE a.acccode = p_acccode AND c.acccode IS NULL);

    ELSIF (p_div = 'S072') THEN

      -- 계정 관리항목생성 (외화종류)
        INSERT INTO ACORDSMM (  compcode,
                                plantcode,
                                slipym,
                                closediv,
                                acccode,
                                mngclucode,
                                mngcluval,
                                mngcludec,
                                bsdebamt,
                                bscreamt,
                                debamt,
                                creamt,
                                totdebamt,
                                totcreamt)
                         (SELECT p_compcode,
                                 p_plantcode,
                                 p_slipym,
                                 p_closediv,
                                 b.acccode,
                                 b.mngclucode,
                                 D.code,
                                 D.NAME,
                                 0,
                                 0,
                                 0,
                                 0,
                                 0,
                                 0
                            FROM ACACCM a
                                 JOIN
                                 ACACCMNGM b
                                    ON     a.acccode = b.acccode
                                       AND b.dcdiv = p_dcdiv
                                       AND b.mngclucode = p_div
                                 JOIN
                                 (SELECT to_char (divcode) code,
                                         to_char (divname) NAME
                                    FROM CMCOMMONM
                                   WHERE cmmcode = 'TR01' AND usediv = 'Y') D
                                    ON 1 = 1
                                 LEFT JOIN
                                 ACORDSMM c
                                    ON     c.compcode = p_compcode
                                       AND c.plantcode = p_plantcode
                                       AND c.slipym = p_slipym
                                       AND c.closediv = p_closediv
                                       AND b.acccode = c.acccode
                                       AND b.mngclucode = c.mngclucode
                                       AND D.code = c.mngcluval
                           WHERE a.acccode = p_acccode AND c.acccode IS NULL);
   ELSIF (p_div = 'S080')    THEN

      -- 계정 관리항목생성 (자산코드)
      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
         (SELECT p_compcode,
                 p_plantcode,
                 p_slipym,
                 p_closediv,
                 b.acccode,
                 b.mngclucode,
                 D.code,
                 D.NAME,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0
            FROM ACACCM a
                 JOIN
                 ACACCMNGM b
                    ON     a.acccode = b.acccode
                       AND b.dcdiv = p_dcdiv
                       AND b.mngclucode = p_div
                 JOIN
                 (SELECT asscode code,
                         assname NAME
                    FROM ACASSM
                   WHERE compcode = p_compcode AND plantcode = p_plantcode) D
                    ON 1 = 1
                 LEFT JOIN
                 ACORDSMM c
                    ON     c.compcode = p_compcode
                       AND c.plantcode = p_plantcode
                       AND c.slipym = p_slipym
                       AND c.closediv = p_closediv
                       AND b.acccode = c.acccode
                       AND b.mngclucode = c.mngclucode
                       AND D.code = c.mngcluval
           WHERE a.acccode = p_acccode AND c.acccode IS NULL);

   ELSIF (p_div = 'S090') THEN

      -- 계정 관리항목생성 (차입계좌)

      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
         (SELECT p_compcode,
                 p_plantcode,
                 p_slipym,
                 p_closediv,
                 b.acccode,
                 b.mngclucode,
                 D.code,
                 D.NAME,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0
            FROM ACACCM a
                 JOIN
                 ACACCMNGM b
                    ON     a.acccode = b.acccode
                       AND b.dcdiv = p_dcdiv
                       AND b.mngclucode = p_div
                 JOIN
                 (SELECT to_char (loanno) code,
                         to_char (loanname) NAME
                    FROM ACLOANM
                   WHERE compcode = p_compcode AND plantcode = p_plantcode) D
                    ON 1 = 1
                 LEFT JOIN
                 ACORDSMM c
                    ON     c.compcode = p_compcode
                       AND c.plantcode = p_plantcode
                       AND c.slipym = p_slipym
                       AND c.closediv = p_closediv
                       AND b.acccode = c.acccode
                       AND b.mngclucode = c.mngclucode
                       AND D.code = c.mngcluval
           WHERE a.acccode = p_acccode AND c.acccode IS NULL);
   ELSIF (p_div = 'S100')
   THEN
      -- 계정 관리항목생성 (유가증권)

      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
         (SELECT p_compcode,
                 p_plantcode,
                 p_slipym,
                 p_closediv,
                 b.acccode,
                 b.mngclucode,
                 D.code,
                 D.NAME,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0
            FROM ACACCM a
                 JOIN
                 ACACCMNGM b
                    ON     a.acccode = b.acccode
                       AND b.dcdiv = p_dcdiv
                       AND b.mngclucode = p_div
                 JOIN
                 (SELECT to_char (bondno) code,
                         to_char (bondname) NAME
                    FROM ACBONDM
                   WHERE compcode = p_compcode AND plantcode = p_plantcode) D
                    ON 1 = 1
                 LEFT JOIN
                 ACORDSMM c
                    ON     c.compcode = p_compcode
                       AND c.plantcode = p_plantcode
                       AND c.slipym = p_slipym
                       AND c.closediv = p_closediv
                       AND b.acccode = c.acccode
                       AND b.mngclucode = c.mngclucode
                       AND D.code = c.mngcluval
           WHERE a.acccode = p_acccode AND c.acccode IS NULL);
   ELSIF (p_div = 'S110')
   THEN
      -- 계정 관리항목생성 (어음번호)

      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
         (SELECT p_compcode,
                 p_plantcode,
                 p_slipym,
                 p_closediv,
                 b.acccode,
                 b.mngclucode,
                 D.code,
                 D.NAME,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0
            FROM ACACCM a
                 JOIN
                 ACACCMNGM b
                    ON     a.acccode = b.acccode
                       AND b.dcdiv = p_dcdiv
                       AND b.mngclucode = p_div
                 JOIN
                 (SELECT to_char (billno) code,
                         ' ' NAME
                    FROM ACBILLM
                   WHERE compcode = p_compcode AND plantcode = p_plantcode) D
                    ON 1 = 1
                 LEFT JOIN
                 ACORDSMM c
                    ON     c.compcode = p_compcode
                       AND c.plantcode = p_plantcode
                       AND c.slipym = p_slipym
                       AND c.closediv = p_closediv
                       AND b.acccode = c.acccode
                       AND b.mngclucode = c.mngclucode
                       AND D.code = c.mngcluval
           WHERE a.acccode = p_acccode AND c.acccode IS NULL);
   ELSIF (p_div = 'S120')
   THEN
      -- 계정 관리항목생성 (제품코드)

      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
         (SELECT p_compcode,
                 p_plantcode,
                 p_slipym,
                 p_closediv,
                 b.acccode,
                 b.mngclucode,
                 D.code,
                 D.NAME,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0
            FROM ACACCM a
                 JOIN
                 ACACCMNGM b
                    ON     a.acccode = b.acccode
                       AND b.dcdiv = p_dcdiv
                       AND b.mngclucode = p_div
                 JOIN
                 (SELECT to_char (itemcode) code,
                         to_char (itemname) NAME
                    FROM CMITEMM
                   WHERE plantcode = p_plantcode AND itemdiv = '1') D
                    ON 1 = 1
                 LEFT JOIN
                 ACORDSMM c
                    ON     c.compcode = p_compcode
                       AND c.plantcode = p_plantcode
                       AND c.slipym = p_slipym
                       AND c.closediv = p_closediv
                       AND b.acccode = c.acccode
                       AND b.mngclucode = c.mngclucode
                       AND D.code = c.mngcluval
           WHERE a.acccode = p_acccode AND c.acccode IS NULL);
   ELSIF (p_div = 'S130')
   THEN
      -- 계정 관리항목생성 (자재코드)

      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
         (SELECT p_compcode,
                 p_plantcode,
                 p_slipym,
                 p_closediv,
                 b.acccode,
                 b.mngclucode,
                 D.code,
                 D.NAME,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0
            FROM ACACCM a
                 JOIN
                 ACACCMNGM b
                    ON     a.acccode = b.acccode
                       AND b.dcdiv = p_dcdiv
                       AND b.mngclucode = p_div
                 JOIN
                 (SELECT to_char (itemcode) code,
                         to_char (itemname) NAME
                    FROM CMITEMM
                   WHERE plantcode = p_plantcode
                    AND itemdiv IN ('3', '4')) D
                    ON 1 = 1
                 LEFT JOIN
                 ACORDSMM c
                    ON     c.compcode = p_compcode
                       AND c.plantcode = p_plantcode
                       AND c.slipym = p_slipym
                       AND c.closediv = p_closediv
                       AND b.acccode = c.acccode
                       AND b.mngclucode = c.mngclucode
                       AND D.code = c.mngcluval
           WHERE a.acccode = p_acccode AND c.acccode IS NULL);
   ELSIF (p_div = 'S140')
   THEN
      -- 계정 관리항목생성 (계정코드)

      INSERT INTO ACORDSMM (compcode,
                            plantcode,
                            slipym,
                            closediv,
                            acccode,
                            mngclucode,
                            mngcluval,
                            mngcludec,
                            bsdebamt,
                            bscreamt,
                            debamt,
                            creamt,
                            totdebamt,
                            totcreamt)
         (SELECT p_compcode,
                 p_plantcode,
                 p_slipym,
                 p_closediv,
                 b.acccode,
                 b.mngclucode,
                 D.code,
                 D.NAME,
                 0,
                 0,
                 0,
                 0,
                 0,
                 0
            FROM ACACCM a
                 JOIN
                 ACACCMNGM b
                    ON     a.acccode = b.acccode
                       AND b.dcdiv = p_dcdiv
                       AND b.mngclucode = p_div
                 JOIN
                 (SELECT to_char (acccode) code,
                         to_char (accname) NAME
                    FROM ACACCM
                   WHERE remainyn = 'Y') D
                    ON 1 = 1
                 LEFT JOIN
                 ACORDSMM c
                    ON     c.compcode = p_compcode
                       AND c.plantcode = p_plantcode
                       AND c.slipym = p_slipym
                       AND c.closediv = p_closediv
                       AND b.acccode = c.acccode
                       AND b.mngclucode = c.mngclucode
                       AND D.code = c.mngcluval
           WHERE a.acccode = p_acccode AND c.acccode IS NULL);
   END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
