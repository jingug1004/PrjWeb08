CREATE FUNCTION        fnCommonNM
-- ---------------------------------------------------------------
 -- 함 수 명			: fnCommonNM
 -- 작 성 자         : 조성희
 -- 작성일자         : 2008-10-22
 -- ---------------------------------------------------------------
 -- 함수설명			: 공통코드명, 사원명, 부서명, 거래처명을 가져온다.
 -- ---------------------------------------------------------------
(
    p_gb        IN VARCHAR2 DEFAULT '' ,
    p_cmmcode   IN VARCHAR2 DEFAULT '' ,
    p_divcode   IN VARCHAR2 DEFAULT '' 
)
RETURN VARCHAR2
AS
    p_tostring VARCHAR2(20) :='';
BEGIN
   
    IF ( LOWER(p_gb) = 'comm' ) THEN
    
        FOR  rec IN (   SELECT  NVL(divname, '')  AS alias1  
                        FROM    CMCOMMONM 
                        WHERE   cmmcode = p_cmmcode
                                AND divcode = p_divcode
        )
        LOOP
            p_tostring := rec.alias1 ;
        END LOOP;
   
    ELSIF ( LOWER(p_gb) = 'emp' ) THEN
      
        FOR  rec IN (   SELECT  NVL(empname, '')  AS alias1  
                        FROM    CMEMPM 
                        WHERE   empcode = p_cmmcode
        )
        LOOP
            p_tostring := rec.alias1 ;
        END LOOP;
      
    ELSIF ( LOWER(p_gb) = 'dept' ) THEN
         
        FOR  rec IN (   SELECT  NVL(deptname, '')  AS alias1  
                        FROM    CMDEPTM 
                        WHERE   deptcode = p_cmmcode
        )
        LOOP
            p_tostring := rec.alias1 ;
        END LOOP;
         
    ELSIF ( LOWER(p_gb) = 'cust' ) THEN
    
        FOR  rec IN (   SELECT  NVL(custname, '')  AS alias1  
                        FROM    CMCUSTM 
                        WHERE   custcode = p_cmmcode
        )
        LOOP
            p_tostring := rec.alias1 ;
        END LOOP;
        
    ELSIF ( LOWER(p_gb) = 'item' ) THEN
    
        FOR  rec IN (   SELECT  NVL(itemname, '')  AS alias1  
                        FROM    CMITEMM 
                        WHERE   itemcode = p_cmmcode
        )
        LOOP
            p_tostring := rec.alias1 ;
        END LOOP;

   END IF;
   
   RETURN (p_tostring);

EXCEPTION WHEN OTHERS THEN RETURN (p_tostring);
END;
/
