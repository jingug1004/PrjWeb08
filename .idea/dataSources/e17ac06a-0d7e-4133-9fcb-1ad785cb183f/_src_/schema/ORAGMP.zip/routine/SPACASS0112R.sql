CREATE PROCEDURE        spACass0112R
-- ---------------------------------------------------------------
-- 프로시저명       : spACass0112R
-- 작 성 자         : 최인범
-- 작성일자         : 2010-10-04
-- ---------------------------------------------------------------
-- 프로시저 설명    : 폐기자산명세서를 조회하는 프로시저이다.
-- ---------------------------------------------------------------

(p_div          IN     VARCHAR2 DEFAULT '',
 p_compcode     IN     VARCHAR2 DEFAULT '',
 p_plantcode    IN     VARCHAR2 DEFAULT '',
 p_closediv     IN     VARCHAR2 DEFAULT '',
 p_caldiv       IN     VARCHAR2 DEFAULT '',
 p_assym        IN     VARCHAR2 DEFAULT '',
 p_assdiv       IN     VARCHAR2 DEFAULT '',
 p_deptcode     IN     VARCHAR2 DEFAULT '',
 p_workdiv      IN     VARCHAR2 DEFAULT '',
 p_userid       IN     VARCHAR2 DEFAULT '',
 p_reasondiv    IN     VARCHAR2 DEFAULT '',
 p_reasontext   IN     VARCHAR2 DEFAULT '',
 IO_CURSOR         OUT TYPES.DataSet,
 MESSAGE           OUT VARCHAR2)
AS
   p_strym     VARCHAR2 (7);
   p_strdate   VARCHAR2 (10);
   p_enddate   VARCHAR2 (10);
BEGIN
   MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

   -- 계산기간 설정
   p_strym := SUBSTR (p_assym, 0, 4) || '-01';

   SELECT MAX (SUBSTR (curstrdate, 0, 7))
     INTO p_strym
     FROM ACSESSION a
    WHERE compcode = p_compcode AND cyear <= SUBSTR (p_assym, 0, 4);

   IF SUBSTR (p_assym, -2) < SUBSTR (p_strym, -2) THEN
      p_strym := (SUBSTR (p_assym, 1, 4) - 1) || SUBSTR (p_strym, -3);
   ELSE
      p_strym := SUBSTR (p_assym, 1, 4) || SUBSTR (p_strym, -3);
   END IF;

   p_strdate := p_strym || '-01';
   p_enddate := TO_CHAR (ADD_MONTHS (TO_DATE (p_assym || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD');
   p_strdate := p_assym || '-01';

   IF (p_div = 'S') THEN

      OPEN IO_CURSOR FOR
           SELECT a.asscode asscode,
                  b.assname assname,
                  b.strdate strdate,                                                                --취득일자
                  a.chgdate chgdate,                                                                --변동일자
                  a.lifeyear lifeyear,                                                              --내용년수
                  SUBSTR (a.chgdate, 1, 4) - SUBSTR (b.strdate, 1, 4) runlifeyear,                  --경과년수
                  a.lifeyear - SUBSTR (a.chgdate, 1, 4) + SUBSTR (b.strdate, 1, 4) lastlifeyear,
                  a.chgqty assqty,                                                                  --폐기수량
                  a.chgamt assamt,                                                                  --폐기자산액
                  a.drpamt drpamt,                                                                  --상각감소액
                  a.saleamt saleamt,                                                                --자산폐기액
                  a.salepro salepro                                                                 --폐기손실액
             FROM ACASSD a
                  LEFT JOIN ACASSM b
                     ON b.compcode = a.compcode AND b.asscode = a.asscode
            WHERE     a.compcode = p_compcode
                  AND a.closediv = p_closediv
                  AND a.chgdate BETWEEN p_strdate AND p_enddate
                  AND a.asschgdiv = '04'
                  AND b.plantcode LIKE p_plantcode
                  AND NVL (b.mngdeptcode, ' ') LIKE p_deptcode || '%'
                  AND NVL (b.assdiv, ' ') LIKE p_assdiv
                  AND NVL (b.workdiv, ' ') LIKE p_workdiv
         ORDER BY a.asscode;
   END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
