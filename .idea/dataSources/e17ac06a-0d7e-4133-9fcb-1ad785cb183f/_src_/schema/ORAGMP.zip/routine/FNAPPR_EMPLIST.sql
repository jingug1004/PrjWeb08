CREATE FUNCTION        fnappr_emplist /******
작 성 자: 이세민
작성일자: 2013-09-03
설    명: 영업에서 사용하는 결재 권한 처리를 위해 사용하는 테이블 반환함수
예    제: select * from dbo.fnappr_emplist('50') -- 영업본부 전체에 해당하는 사원 리스트 추출
		  select * from dbo.fnappr_emplist('00062601') --사번이 00062601인 사람만 조회됨.
******/
(
  p_setvalues IN VARCHAR2
)
RETURN FN_APPR_EMPLIST_TABLE
AS
    i NUMBER := 1;
    
    --함수내에서 변수 저장용 변수 초기화
    apprEmpListRecode FN_APPR_EMPLIST_TABLE := FN_APPR_EMPLIST_TABLE(); 

BEGIN
   
   IF( NVL(TRIM(p_setvalues), '') IS NULL OR NVL(TRIM(p_setvalues), '') = '%' ) THEN
   
        FOR  rec IN (
            SELECT empcode FROM CMEMPM ORDER BY empcode ASC 
        )                                               
        LOOP
            apprEmpListRecode.EXTEND;
            apprEmpListRecode(i) := FN_APPR_EMPLIST_VARIABLE(rec.empcode);
            i := i+1;            
        END LOOP;   
   
   ELSE

        FOR  rec IN (   WITH CTEWORDERS(DEPTCODE, PREDEPTCODE, NAME, org_level) AS
                        (
                            SELECT  DEPTCODE, PREDEPTCODE, deptname, 1  Org_Level
                            FROM    CMDEPTM
                                    WHERE DEPTCODE = p_setvalues
                            UNION ALL

                            SELECT  A.DEPTCODE, A.PREDEPTCODE, A.deptname, b.org_level + 1 org_level
                            FROM    CMDEPTM A
                                    INNER JOIN CTEWORDERS b ON A.PREDEPTCODE = b.DEPTCODE
                        ) 
                               
                        SELECT  DISTINCT empcode
                        
                        FROM (  SELECT  empcode
                                FROM    CMEMPM
                                WHERE   deptcode IN ( SELECT DEPTCODE FROM CTEWORDERS )
                                
                                UNION ALL 
                                
                                SELECT p_setvalues FROM dual
                              ) A 
                        ORDER BY empcode ASC        
        )                                       
        
        LOOP
            apprEmpListRecode.EXTEND;
            apprEmpListRecode(i) := FN_APPR_EMPLIST_VARIABLE(rec.empcode);
            i := i+1;            
        END LOOP;                         
   
   END IF;

    RETURN apprEmpListRecode;
    
END;
/
