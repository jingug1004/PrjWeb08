CREATE PROCEDURE        SPACACC0047PL(
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0047PL
-- 작 성 자         : 최용석
-- 작성일자         : 2011-02-22
-- 수정일자      :   노영래
-- E-mail      :   0rae0926@gmail.com
-- 수정일자      :   2016-12-12
-- ---------------------------------------------------------------
-- 프로시저 설명    : 자동분개 불러오기를 처리하는 프로시저이다.
-- ---------------------------------------------------------------

    p_div           IN  VARCHAR2 DEFAULT '',

    p_compcode      IN  VARCHAR2 DEFAULT '',
    p_slipdiv       IN  VARCHAR2 DEFAULT '',
    p_program       IN  VARCHAR2 DEFAULT '',
    p_iempcode      IN  VARCHAR2 DEFAULT '',

    p_userid        IN  VARCHAR2 DEFAULT '',
    p_reasondiv     IN  VARCHAR2 DEFAULT '',
    p_reasontext    IN  VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DATASET
)
AS
    v_temp              NUMBER       := 0;
    p_acccode1          VARCHAR2(20 CHAR) := ''; -- 미수금_카드
    p_acccode2          VARCHAR2(20 CHAR) := ''; -- 선급부가세
    p_acccode3          VARCHAR2(20 CHAR) := ''; -- 예수부가세
    p_acccode4          VARCHAR2(20 CHAR) := ''; -- 미지급금(거래처)
    p_acccode5          VARCHAR2(20 CHAR) := ''; -- 선급금
    p_strartym          VARCHAR2(7 CHAR)  := '';
    p_endym             VARCHAR2(7 CHAR)  := '';
    p_ideptcode         VARCHAR2(20 CHAR) := '';
    p_insertdt          DATE              := null;
    p_slipinno          VARCHAR2(20 CHAR) := '';
    p_proccnt           NUMBER            := 0;
    p_salload           VARCHAR2(30 CHAR) := '';
    p_colload           VARCHAR2(30 CHAR) := '';
    p_colseq            VARCHAR2(30)      := '';
    p_expload           VARCHAR2(30 CHAR) := '';
    p_salecust          VARCHAR2(1)       := '';
    p_colcust           VARCHAR2(1)       := '';

    CURSOR SPACC_CURSOR
    IS
        select  distinct replace(a.slipindate,'-','') || a.acattype || NVL(b.slipinnum,c.slipinnum) as slipinno
        from    ACAUTOORDT a
                left join VGT.TT_ACACC0047PL_ACAUTOORDT1 b on a.compcode = b.compcode
                                                                and a.plantcode = b.plantcode
                                                                and a.acattype = b.acattype
                                                                and a.slipindate = b.slipindate
                                                                and case when p_salload = 'empcode' and a.acattype = 'S' then a.empcode
                                                                         when p_salload = 'iempcode' and a.acattype = 'S' then a.iempcode
                                                                         when p_salload = 'newload' and a.acattype = 'S' then a.iempcode
                                                                         when p_salload = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                                                                         when p_colload = 'empcode' and a.acattype = 'C' then a.empcode
                                                                         when p_colload = 'iempcode' and a.acattype = 'C' then a.iempcode
                                                                         when p_colload = 'newload' and a.acattype = 'C' then a.iempcode
                                                                         when p_colload = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                                                                         when p_colload = 'custcode' and a.acattype = 'C' then a.custcode
                                                                         when p_expload = 'importshtno' and a.acattype = 'N' then a.billno
                                                                         when a.acattype = 'H' then a.plantcode
                                                                         else ''
                                                                     end = b.acatrulecode
                left join VGT.TT_ACACC0047PL_ACAUTOORDT2 c on a.compcode = c.compcode
                                                                and a.acattype = c.acattype
                                                                and a.slipindate = c.slipindate
                                                                and a.acatno = c.acatno
        where   a.compcode = p_compcode
                and a.actrnstate in ('1', '3')
                and a.acattype like p_slipdiv
                and a.acattype = 'N'
                and TRIM(p_expload) IS NOT NULL
        order by slipinno ;

BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    v_temp := 0;


    SELECT COUNT(*)
    INTO   v_temp
    FROM   DUAL
    WHERE  NOT EXISTS
               (SELECT *
                FROM   ACAUTOORDT
                WHERE  compcode = p_compcode
                       AND actrnstate IN ('1', '3', '4')
                       AND acattype LIKE p_slipdiv
                       AND acattype NOT IN (SELECT CASE b.grp WHEN 1 THEN A.value1 WHEN 2 THEN A.value2 ELSE A.value3 END VALUE
                                            FROM   SYSPARAMETERMANAGE A
                                                   JOIN (SELECT 1 grp FROM DUAL
                                                         UNION
                                                         SELECT 2 FROM DUAL
                                                         UNION
                                                         SELECT 3 FROM DUAL) b
                                                       ON 1 = 1
                                            WHERE  UPPER(parametercode) = 'ACCOTHERLOAD'
                                                   AND TRIM(p_program) IS NULL)
                       AND acattype NOT IN (SELECT CASE b.grp WHEN 1 THEN A.value1 WHEN 2 THEN A.value2 ELSE A.value3 END VALUE
                                            FROM   SYSPARAMETERMANAGE A
                                                   JOIN (SELECT 1 grp FROM DUAL
                                                         UNION
                                                         SELECT 2 FROM DUAL
                                                         UNION
                                                         SELECT 3 FROM DUAL) b
                                                       ON 1 = 1
                                            WHERE  UPPER(parametercode) = 'ACCOTHERLOAD2'
                                                   AND TRIM(p_program) IS NULL));

    IF v_temp <> 0
    THEN
        MESSAGE := '0';
        GOTO LASTLINE;
    END IF;



    p_acccode1 := '11120020';

    FOR rec IN (SELECT filter1
                FROM   CMCOMMONM
                WHERE  UPPER(cmmcode) = 'AC261'
                       AND divcode = '11120020')
    LOOP
        p_acccode1 := rec.filter1;
    END LOOP;



    p_acccode2 := '11135';

    FOR rec IN (SELECT filter1
                FROM   CMCOMMONM
                WHERE  UPPER(cmmcode) = 'AC261'
                       AND divcode = '11135')
    LOOP
        p_acccode2 := rec.filter1;
    END LOOP;



    p_acccode3 := '21050';

    FOR rec IN (SELECT filter1
                FROM   CMCOMMONM
                WHERE  UPPER(cmmcode) = 'AC261'
                       AND divcode = '21050')
    LOOP
        p_acccode3 := rec.filter1;
    END LOOP;



    p_acccode4 := '21030200';

    FOR rec IN (SELECT filter1
                FROM   CMCOMMONM
                WHERE  UPPER(cmmcode) = 'AC261'
                       AND divcode = '21030200')
    LOOP
        p_acccode4 := rec.filter1;
    END LOOP;



    p_acccode5 := '11131000';

    FOR rec IN (SELECT filter1
                FROM   CMCOMMONM
                WHERE  UPPER(cmmcode) = 'AC261'
                       AND divcode = '11131000')
    LOOP
        p_acccode5 := rec.filter1;
    END LOOP;



    -- 예산집계를 위한 일자범위 지정
    FOR rec IN (SELECT MIN(SUBSTR(slipindate, 1, 7)) AS alias1
                       , TO_CHAR(SYSDATE, 'YYYY-MM') AS alias2
                FROM   ACAUTOORDT
                WHERE  compcode = p_compcode
                       AND actrnstate IN ('1', '3', '4') -- 1신규, 2완료 3수정, 4삭제
                       AND NVL(TRIM(acattype), ' ') LIKE NVL(p_slipdiv, ' '))
    LOOP
        p_strartym := rec.alias1;
        p_endym    := rec.alias2;
    END LOOP;



    FOR rec IN (SELECT deptcode
                FROM   CMEMPM
                WHERE  empcode = p_iempcode)
    LOOP
        p_ideptcode := rec.deptcode;
    END LOOP;



    p_insertdt := SYSDATE;



    FOR rec IN (SELECT value2
                FROM   SYSPARAMETERMANAGE
                WHERE  UPPER(parametercode) = 'ACCSALLOAD')
    LOOP
        p_salload := rec.value2;
    END LOOP;



    FOR rec IN (SELECT value2, value3
                FROM   SYSPARAMETERMANAGE
                WHERE  UPPER(parametercode) = 'ACCCOLLOAD')
    LOOP
        p_colload := rec.value2;
        p_colseq := rec.value3;
    END LOOP;



    FOR rec IN (SELECT value2
                FROM   SYSPARAMETERMANAGE
                WHERE  UPPER(parametercode) = 'ACCEXPLOAD')
    LOOP
        p_expload := rec.value2;
    END LOOP;



    -- 부문별 자료가 변경,삭제된 경우 기존자료(동일전표번호)를 수정으로 변경
    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.slipinno
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate IN ('3', '4')
                               AND A.acattype LIKE p_slipdiv ) A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.slipinno = b.slipinno
                              AND b.actrnstate = '2') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3';



    -- 매출 자료가 변경,삭제된 경우 신규자료(일자,사원)를 수정으로 변경
    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.empcode
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate = '1'
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'S'
                               AND UPPER(p_salload) = 'EMPCODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.empcode = b.empcode
                              AND b.actrnstate = '2') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3';



    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, A.slipinno
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.empcode, A.slipinno
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate IN ('3', '4')
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'S'
                               AND UPPER(p_salload) = 'EMPCODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.empcode = b.empcode
                              AND b.actrnstate = '1') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3'
                   , b.slipinno = src.slipinno ;



    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.iempcode
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate = '1'
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'S'
                               AND UPPER(p_salload) = 'IEMPCODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.iempcode = b.iempcode
                              AND b.actrnstate = '2') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3';



    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, A.slipinno
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.iempcode, A.slipinno
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate IN ('3', '4')
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'S'
                               AND UPPER(p_salload) = 'IEMPCODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.iempcode = b.iempcode
                              AND b.actrnstate = '1') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3'
                   , b.slipinno = src.slipinno ;



    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.acatrulecode, A.iempcode
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate = '1'
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'S'
                               AND UPPER(p_salload) = 'ACATRULECODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.acatrulecode = b.acatrulecode
                              AND A.iempcode = b.iempcode
                              AND b.actrnstate = '2') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3';



    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, A.slipinno
                FROM   (SELECT DISTINCT A.compcode,
                                        A.acattype,
                                        A.slipindate,
                                        A.acatrulecode,
                                        A.iempcode,
                                        A.slipinno
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate IN ('3', '4')
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'S'
                               AND UPPER(p_salload) = 'ACATRULECODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.acatrulecode = b.acatrulecode
                              AND A.iempcode = b.iempcode
                              AND b.actrnstate = '1') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3'
                   , b.slipinno = src.slipinno ;



    -- 수금 자료가 변경,삭제된 경우 신규자료(일자,사원)를 수정으로 변경
    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.empcode
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate = '1'
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'C'
                               AND UPPER(p_colload) = 'EMPCODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.empcode = b.empcode
                              AND b.actrnstate = '2') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3' ;



    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, A.slipinno
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.empcode, A.slipinno
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate IN ('3', '4')
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'C'
                               AND UPPER(p_colload) = 'EMPCODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.empcode = b.empcode
                              AND b.actrnstate = '1') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3'
                   , b.slipinno = src.slipinno ;



    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.iempcode
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate = '1'
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'C'
                               AND UPPER(p_colload) = 'IEMPCODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.iempcode = b.iempcode
                              AND b.actrnstate = '2') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3' ;



    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, A.slipinno
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.iempcode, A.slipinno
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate IN ('3', '4')
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'C'
                               AND UPPER(p_colload) = 'IEMPCODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.iempcode = b.iempcode
                              AND b.actrnstate = '1') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3'
                   , b.slipinno = src.slipinno ;

    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.acatrulecode, A.iempcode
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate = '1'
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'C'
                               AND UPPER(p_colload) = 'ACATRULECODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.acatrulecode = b.acatrulecode
                              AND A.iempcode = b.iempcode
                              AND b.actrnstate = '2') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3' ;

    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, A.slipinno
                FROM   (SELECT DISTINCT A.compcode,
                                        A.acattype,
                                        A.slipindate,
                                        A.acatrulecode,
                                        A.iempcode,
                                        A.slipinno
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate IN ('3', '4')
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'C'
                               AND UPPER(p_colload) = 'ACATRULECODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.acatrulecode = b.acatrulecode
                              AND A.iempcode = b.iempcode
                              AND b.actrnstate = '1') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3'
                   , b.slipinno = src.slipinno ;

    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.custcode, A.iempcode
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                   AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate = '1'
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'C'
                               AND UPPER(p_colload) = 'CUSTCODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.custcode = b.custcode
                              AND b.actrnstate = '2') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3' ;

    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, A.slipinno
                FROM   (SELECT DISTINCT A.compcode,
                                        A.acattype,
                                        A.slipindate,
                                        A.custcode,
                                        A.slipinno
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate IN ('3', '4')
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'C'
                               AND UPPER(p_colload) = 'CUSTCODE') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.slipindate = b.slipindate
                              AND A.custcode = b.custcode
                              AND b.actrnstate = '1') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3'
                   , b.slipinno = src.slipinno ;


    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.billno, A.slipindate
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate = '1'
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'N'
                               AND UPPER(p_expload) = 'IMPORTSHTNO') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.billno = b.billno
                              AND b.actrnstate = '2') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3' ;



    MERGE INTO ACAUTOORDT b
    USING       (SELECT B.COMPCODE,
                       B.ACATTYPE,
                       B.ACATNO,
                       A.slipindate,
                       A.slipinno
                FROM   (SELECT DISTINCT A.compcode, A.acattype, A.billno, A.slipindate, A.slipinno
                        FROM   ACAUTOORDT A
                               JOIN ACAUTORULE b
                                   ON A.acatrulecode = b.acautorcode
                                      AND b.crtdiv = '1'
                        WHERE  A.compcode = p_compcode
                               AND A.actrnstate IN ('3', '4')
                               AND A.acattype LIKE p_slipdiv
                               AND A.acattype = 'N'
                               AND UPPER(p_expload) = 'IMPORTSHTNO') A
                       JOIN ACAUTOORDT b
                           ON A.compcode = b.compcode
                              AND A.acattype = b.acattype
                              AND A.billno = b.billno
                              AND b.actrnstate = '1') src
    ON           (B.COMPCODE = SRC.COMPCODE
                AND B.ACATTYPE = SRC.ACATTYPE
                AND B.ACATNO = SRC.ACATNO)
    WHEN MATCHED
    THEN
        UPDATE SET b.actrnstate = '3'
                   , b.slipindate = src.slipindate
                   , b.slipinno = src.slipinno ;



    -- 관리항목삭제
    FOR rec IN (

                SELECT  b.compcode
                        , b.slipinno
                        , b.slipinseq
                        , b.mngclucode
                FROM    ACAUTOORDT a
                        join ACORDS b on a.compcode = b.compcode
                                         and a.slipinno = b.slipinno
                where   a.compcode = p_compcode
                        and a.actrnstate in ('3','4')
                        and a.acattype like p_slipdiv

    )
    LOOP

        DELETE FROM ACORDS a
        WHERE   a.compcode          = rec.compcode
                AND a.slipinno      = rec.slipinno
                AND a.slipinseq     = rec.slipinseq
                AND a.mngclucode    = rec.mngclucode ;

    END LOOP;



    -- 전표상세삭제
    FOR rec IN (

                SELECT  b.compcode
                        , b.slipinno
                        , b.slipinseq
                from    ACAUTOORDT a
                        join ACORDD b on a.compcode = b.compcode
                                         and a.slipinno = b.slipinno
                where   a.compcode = p_compcode
                        and a.actrnstate in ('3', '4')
                        and a.acattype like p_slipdiv

    )
    LOOP

        DELETE FROM ACORDD a
        WHERE   a.compcode          = rec.compcode
                AND a.slipinno      = rec.slipinno
                AND a.slipinseq     = rec.slipinseq ;

    END LOOP ;



    -- 회계전표삭제
    FOR rec IN (

                    select  b.compcode
                            , b.slipinno
                    from    ACAUTOORDT a
                            join ACORDM b on a.compcode = b.compcode
                                             and a.slipinno = b.slipinno
                    where   a.compcode = p_compcode
                            and a.actrnstate in ('3', '4')
                            and a.acattype like p_slipdiv
    )
    LOOP

            DELETE FROM ACORDM a
            WHERE   a.compcode          = rec.compcode
                    AND a.slipinno      = rec.slipinno ;

    END LOOP ;



    -- 무역전표 마지막일자 생성을 위해 일자변경
    MERGE INTO ACAUTOORDT a
    USING (

        select  -- compare data
                a.compcode
                , a.acattype
                , a.acatno
                -- update data
                , b.slipindate
        from    ACAUTOORDT a
                join (  select  a.compcode
                                , a.acattype
                                , a.billno
                                , max(a.slipindate) as slipindate
                        from    ACAUTOORDT a
                                join ACAUTORULE b on a.acatrulecode = b.acautorcode
                                                     and b.crtdiv = '1'
                        where   a.compcode = p_compcode
                                and a.actrnstate in ('1', '3')
                                and a.acattype like p_slipdiv
                                and a.acattype = 'N'
                                and UPPER(p_expload) = UPPER('importshtno')
                        group by a.compcode, a.acattype, a.billno
                ) b on a.compcode = b.compcode
                       and a.acattype = b.acattype
                       and a.billno = b.billno
        where   a.compcode = p_compcode
                and a.actrnstate in ('1', '3')
                and a.acattype like p_slipdiv
                and a.acattype = 'N'
                and UPPER(p_expload) = UPPER('importshtno')

    ) src ON (    -- 비교
                a.compcode     = src.compcode
                AND a.acattype = src.acattype
                AND a.acatno   = src.acatno
    )
    WHEN MATCHED THEN
        UPDATE SET    -- 업데이트 문장
               a.slipindate = src.slipindate ;



    -- 수금전표 승인일 변경 시 신규로 처리
    update  ACAUTOORDT a
    set     a.actrnstate = '1'
            , a.slipinno = null
    where   a.acattype = 'C'
            and a.actrnstate = '3'
            and SUBSTR(a.slipinno, 0, 8) <> replace(a.slipindate,'-','') ;



    -- 무역전표 승인일 변경 시 신규로 처리
    update  ACAUTOORDT a
    set     actrnstate = '1'
            , slipinno = null
    where   a.acattype = 'N'
            and a.actrnstate = '3'
            and SUBSTR(a.slipinno, 0, 8) <> replace(a.slipindate,'-','') ;



    -- 자동분개 회계전표 생성
    -- 해당일자의 전표유형에 해당하는 회계전표 마지막번호를 검색
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACORDMN';

    INSERT INTO VGT.TT_ACACC0047PL_ACORDMN (
        select  compcode
                , slipindate
                , acattype
                , NVL(TO_NUMBER(SUBSTR(MAX(slipinno), -4, 4)), 0) as slipinnum
        from    ACAUTOORDT a
        where   a.compcode = p_compcode
                and a.actrnstate in (2, 3)
                and a.acattype like p_slipdiv
        group by compcode, slipindate, acattype
    ) ;



    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACORDMN2';

    INSERT INTO VGT.TT_ACACC0047PL_ACORDMN2 (
        select  a.compcode
                , a.slipindate
                , a.acattype
                , NVL(TO_NUMBER(SUBSTR(MAX(b.slipinnum), -4, 4)), 0) as slipinnum
        from    ACAUTOORDT a
                left join ACORDM b on a.compcode = b.compcode
                                      and a.slipindate = b.slipindate
                                      and a.acattype = b.slipdiv
        where   a.compcode = p_compcode
                and a.actrnstate = '1'
                and a.acattype like p_slipdiv
        group by a.compcode, a.slipindate, a.acattype
    ) ;




    MERGE INTO VGT.TT_ACACC0047PL_ACORDMN a
    USING (

        SELECT  -- compare data
                a.compcode
                , a.acattype
                , a.slipindate
                -- update data
                , b.slipinnum as slipinnum_update
        FROM    VGT.TT_ACACC0047PL_ACORDMN a
                LEFT JOIN VGT.TT_ACACC0047PL_ACORDMN2 b ON a.compcode = b.compcode
                                                            and a.acattype = b.acattype
                                                            and a.slipindate = b.slipindate
                                                            and a.slipinnum < b.slipinnum

    ) src ON (  -- 비교
                a.compcode          = src.compcode
                AND a.acattype      = src.acattype
                AND a.slipindate    = src.slipindate
    )
    WHEN MATCHED THEN
        UPDATE SET    -- 업데이트 문장
                a.slipinnum = src.slipinnum_update ;



    INSERT INTO VGT.TT_ACACC0047PL_ACORDMN
    (
        SELECT  a.compcode
                , a.slipindate
                , a.acattype
                , NVL(MAX(a.slipinnum), 0) AS slipinnum
        FROM    VGT.TT_ACACC0047PL_ACORDMN2 a
                LEFT JOIN VGT.TT_ACACC0047PL_ACORDMN b ON a.compcode = b.compcode
                                                           AND a.acattype = b.acattype
                                                           AND a.slipindate = b.slipindate
        WHERE   b.slipinnum IS NULL
        GROUP BY a.compcode, a.slipindate, a.acattype
    ) ;



    -- 부문별은 분개기준(acatrulecode)으로 전표순번을 정함(신규)
    -- @salload, @colload이 empcode인 경우는 사원으로 전표순번을 정함
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACAUTOORDT1';

    INSERT INTO VGT.TT_ACACC0047PL_ACAUTOORDT1 (
        SELECT  a.compcode
                , a.plantcode
                , a.acattype
                , a.slipindate
                , a.acatrulecode
                , a.acautorname
                , a.remark1
                , a.remark2
                , SUBSTR('000' || TO_CHAR(row_number() over(partition by a.compcode, a.slipindate, a.acattype order by a.acatrulecode) || TO_CHAR(b.slipinnum) ), -4, 4) as slipinnum
        FROM    (
                    SELECT  DISTINCT a.compcode
                            , a.plantcode
                            , a.acattype
                            , a.slipindate
                            , CASE  WHEN LOWER(p_salload) = 'empcode'      AND a.acattype = 'S' THEN a.empcode
                                    WHEN LOWER(p_salload) = 'iempcode'     AND a.acattype = 'S' THEN a.iempcode
                                    WHEN LOWER(p_salload) = 'newload'      AND a.acattype = 'S' THEN a.iempcode
                                    WHEN LOWER(p_salload) = 'acatrulecode' AND a.acattype = 'S' THEN a.acatrulecode || a.iempcode
                                    WHEN LOWER(p_colload) = 'empcode'      AND a.acattype = 'C' THEN a.empcode
                                    WHEN LOWER(p_colload) = 'iempcode'     AND a.acattype = 'C' THEN a.iempcode
                                    WHEN LOWER(p_colload) = 'newload'      AND a.acattype = 'C' THEN a.iempcode
                                    WHEN LOWER(p_colload) = 'acatrulecode' AND a.acattype = 'C' THEN a.acatrulecode || a.iempcode
                                    WHEN LOWER(p_colload) = 'custcode' AND a.acattype = 'C' THEN a.custcode
                                    WHEN LOWER(p_expload) = 'importshtno'  AND a.acattype = 'N' THEN a.billno
                                    WHEN a.acattype = 'H' THEN a.plantcode
                                    ELSE a.acatrulecode
                            END AS acatrulecode
                            , CASE  WHEN LOWER(p_salload) IN ('empcode','iempcode','newload') AND a.acattype = 'S' THEN '영업매출-자동분개'
                                    WHEN LOWER(p_colload) IN ('empcode','iempcode','newload','custcode') AND a.acattype = 'C' THEN '영업수금-자동분개'
                                    WHEN LOWER(p_expload) = 'importshtno' AND a.acattype = 'N' THEN a.billno || ' 수입비용-자동분개'
                                    WHEN a.acattype = 'H' THEN '급상여-자동분개'
                                    ELSE b.acautorname
                            END AS acautorname
                            , CASE  WHEN LOWER(p_salload) IN ('empcode','iempcode','newload') AND a.acattype = 'S' THEN '영업매출-자동분개'
                                    WHEN LOWER(p_colload) IN ('empcode','iempcode','newload','custcode') AND a.acattype = 'C' THEN '영업수금-자동분개'
                                    WHEN LOWER(p_expload) = 'importshtno' AND a.acattype = 'N' THEN a.billno || ' 수입비용-자동분개'
                                    WHEN a.acattype = 'H' THEN '급상여-자동분개'
                                    ELSE b.remark1
                            END AS remark1
                            , CASE  WHEN LOWER(p_salload) IN ('empcode','iempcode','newload') AND a.acattype = 'S' THEN '영업매출-자동분개'
                                    WHEN LOWER(p_colload) IN ('empcode','iempcode','newload','custcode') AND a.acattype = 'C' THEN '영업수금-자동분개'
                                    WHEN LOWER(p_expload) = 'importshtno' AND a.acattype = 'N' THEN a.billno || ' 수입비용-자동분개'
                                    WHEN a.acattype = 'H' THEN '급상여-자동분개'
                                    ELSE b.remark2
                            END AS remark2

                    FROM    ACAUTOORDT a
                            JOIN ACAUTORULE b ON a.acatrulecode = b.acautorcode
                                                 AND b.crtdiv = '1'

                    WHERE   a.compcode = p_compcode
                            AND a.actrnstate = '1'
                            AND a.acattype LIKE p_slipdiv
                ) a
                JOIN VGT.TT_ACACC0047PL_ACORDMN b ON a.compcode = b.compcode
                                                      AND a.slipindate = b.slipindate
                                                      AND a.acattype = b.acattype
    ) ;



    -- 기존 부문별자료의 전표순번 추가
    INSERT INTO VGT.TT_ACACC0047PL_ACAUTOORDT1 (
        SELECT  DISTINCT a.compcode
                , a.plantcode
                , a.acattype
                , a.slipindate
                , CASE  WHEN LOWER(p_salload) = 'empcode'  AND a.acattype = 'S' THEN a.empcode
                        WHEN LOWER(p_salload) = 'iempcode' AND a.acattype = 'S' THEN a.iempcode
                        WHEN LOWER(p_salload) = 'newload'  AND a.acattype = 'S' THEN a.iempcode
                        WHEN LOWER(p_salload) = 'acatrulecode' AND a.acattype = 'S' THEN a.acatrulecode || a.iempcode
                        WHEN LOWER(p_colload) = 'empcode'  AND a.acattype = 'C' THEN a.empcode
                        WHEN LOWER(p_colload) = 'iempcode' AND a.acattype = 'C' THEN a.iempcode
                        WHEN LOWER(p_colload) = 'newload'  AND a.acattype = 'C' THEN a.iempcode
                        WHEN LOWER(p_colload) = 'acatrulecode' AND a.acattype = 'C' THEN a.acatrulecode || a.iempcode
                        WHEN LOWER(p_colload) = 'custcode'  AND a.acattype = 'C' THEN a.custcode
                        WHEN LOWER(p_expload) = 'importshtno'  AND a.acattype = 'N' THEN a.billno
                        WHEN a.acattype = 'H' THEN a.plantcode
                        ELSE a.acatrulecode
                END AS acatrulecode
                , CASE  WHEN LOWER(p_salload) IN ('empcode','iempcode','newload') AND a.acattype = 'S' THEN '영업매출-자동분개'
                        WHEN LOWER(p_colload) IN ('empcode','iempcode','newload','custcode') AND a.acattype = 'C' THEN '영업수금-자동분개'
                        WHEN LOWER(p_expload) = 'importshtno' AND a.acattype = 'N' THEN a.billno || ' 수입비용-자동분개'
                        WHEN a.acattype = 'H' THEN '급상여-자동분개'
                        ELSE b.acautorname
                END AS acautorname
                , CASE WHEN LOWER(p_salload) IN ('empcode','iempcode','newload') AND a.acattype = 'S' THEN '영업매출-자동분개'
                       WHEN LOWER(p_colload) IN ('empcode','iempcode','newload','custcode') AND a.acattype = 'C' THEN '영업수금-자동분개'
                       WHEN LOWER(p_expload) = 'importshtno' AND a.acattype = 'N' THEN a.billno || ' 수입비용-자동분개'
                       WHEN a.acattype = 'H' then '급상여-자동분개'
                       ELSE b.remark1
                END AS remark1
                , CASE WHEN LOWER(p_salload) IN ('empcode','iempcode','newload') AND a.acattype = 'S' THEN '영업매출-자동분개'
                       WHEN LOWER(p_colload) IN ('empcode','iempcode','newload','custcode') AND a.acattype = 'C' THEN '영업수금-자동분개'
                       WHEN LOWER(p_expload) = 'importshtno' AND a.acattype = 'N' THEN a.billno || ' 수입비용-자동분개'
                       WHEN a.acattype = 'H' THEN '급상여-자동분개'
                       ELSE b.remark2
                END AS remark2
                , SUBSTR(a.slipinno, -4, 4) AS slipinnum
        FROM    ACAUTOORDT a
                JOIN ACAUTORULE b ON a.acatrulecode = b.acautorcode
                                     AND b.crtdiv = '1'
        WHERE   a.compcode = p_compcode
                AND a.actrnstate = '3'
                AND a.acattype LIKE p_slipdiv
    ) ;



    -- 일자별 전표번호 최대값 갱신
    MERGE INTO VGT.TT_ACACC0047PL_ACORDMN a
    USING (

        SELECT  -- comare data
                a.compcode
                , a.slipindate
                , a.acattype
                -- update data
                , b.slipinnum as slipinnum_update
        FROM    VGT.TT_ACACC0047PL_ACORDMN a
                JOIN (
                        SELECT  compcode
                                , slipindate
                                , acattype
                                , MAX(slipinnum) AS slipinnum
                        FROM    VGT.TT_ACACC0047PL_ACAUTOORDT1
                        GROUP BY compcode, slipindate, acattype
                ) b ON  a.compcode = b.compcode
                        AND a.slipindate = b.slipindate
                        AND a.acattype = b.acattype
                        AND a.slipinnum < b.slipinnum

    ) src ON (  -- 비교
                a.compcode          = src.compcode
                AND a.slipindate    = src.slipindate
                AND a.acattype      = src.acattype
    )
    WHEN MATCHED THEN
        UPDATE SET  -- 업데이트 문장
                    a.slipinnum = src.slipinnum_update ;



    -- 개별은 전표번호(acatno)으로 전표순번을 정함(신규)
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACAUTOORDT2';

    INSERT INTO VGT.TT_ACACC0047PL_ACAUTOORDT2 (
        select  a.compcode
                , a.acattype
                , a.slipindate
                , a.acatno
                , c.acautorname
                , c.remark1
                , c.remark2
                , SUBSTR('000' || TO_CHAR(row_number() over(partition by a.compcode, a.slipindate, a.acattype order by a.acatno) || TO_NUMBER(b.slipinnum)), -4, 4) as slipinnum

        FROM    ACAUTOORDT a
                join VGT.TT_ACACC0047PL_ACORDMN b on a.compcode = b.compcode
                                    and a.slipindate = b.slipindate
                                    and a.acattype = b.acattype
                join ACAUTORULE c on a.acatrulecode = c.acautorcode
                                     and c.crtdiv = '2'
        where   a.compcode = p_compcode
                and a.actrnstate = '1'
                and a.acattype like p_slipdiv
    ) ;



    -- 기존 개별자료의 전표순번 추가
    INSERT INTO VGT.TT_ACACC0047PL_ACAUTOORDT2
    (
        SELECT  DISTINCT a.compcode
                , a.acattype
                , a.slipindate
                , a.acatno
                , b.acautorname
                , b.remark1
                , b.remark2
                , SUBSTR(a.slipinno, -4, 4) as slipinnum
        FROM    ACAUTOORDT a
                join ACAUTORULE b on a.acatrulecode = b.acautorcode
                                     and b.crtdiv = '2'
        WHERE   a.compcode = p_compcode
                and a.actrnstate = '3'
                and a.acattype like p_slipdiv
    ) ;



    -- 회계전표생성(부문,개별)
    INSERT INTO ACORDM (
        compcode
        , slipinno
        , slipdiv
        , slipindate
        , slipinnum
        , deptcode
        , plantcode
        , empcode
        , eviddiv
        , slipinremark
        , slipno
        , slipdate
        , slipnum
        , slipdeptcode
        , slipempcode
        , skreqyn
        , skreqdiv
        , skreqdate
        , skreqdeptcode
        , skreqempcode
        , accountno
        , slipinstate
        , slipremark
        , acautorcode
        , insertdt
        , iempcode
    )
    SELECT  DISTINCT a.compcode
            , REPLACE(a.slipindate,'-','') || a.acattype || NVL(b.slipinnum, c.slipinnum)
            , a.acattype
            , a.slipindate
            , a.acattype || NVL(b.slipinnum, c.slipinnum)
            , CASE  WHEN b.slipinnum IS NULL OR LOWER(p_salload) = 'empcode' AND a.acattype = 'S' OR LOWER(p_colload) in ('empcode','custcode') AND a.acattype = 'C' THEN a.deptcode
                    WHEN LOWER(p_salload) IN ('iempcode','newload','acatrulecode') AND a.acattype = 'S' OR LOWER(p_colload) IN ('iempcode','newload','acatrulecode') AND a.acattype = 'C' OR LOWER(p_expload) = 'importshtno' and a.acattype = 'N' then f.deptcode
                    ELSE p_ideptcode
            END
            , NVL(d.plantcode, a.plantcode)
            , CASE WHEN b.slipinnum IS NULL OR LOWER(p_salload) = 'empcode' AND a.acattype = 'S' OR LOWER(p_colload) in ('empcode','custcode') AND a.acattype = 'C' THEN a.empcode
                   WHEN LOWER(P_salload) IN ('iempcode','newload','acatrulecode') AND a.acattype = 'S' OR LOWER(p_colload) IN ('iempcode','newload','acatrulecode') AND a.acattype = 'C' OR LOWER(p_expload) = 'importshtno' AND a.acattype = 'N' THEN a.iempcode
                   ELSE p_iempcode
            END
            , '99'
            , NVL(b.acautorname, c.acautorname)
            , CASE WHEN e.condition1 = '1' THEN replace(a.slipindate,'-','') || a.acattype || NVL(b.slipinnum,c.slipinnum) ELSE '' END
            , CASE WHEN e.condition1 = '1' THEN a.slipindate ELSE '' END
            , CASE WHEN e.condition1 = '1' THEN a.acattype || NVL(b.slipinnum,c.slipinnum) ELSE '' END
            , a.slipdeptcode
            , CASE when e.condition1 = '1' THEN p_iempcode ELSE a.slipempcode END
            , a.skreqyn
            , a.skreqdiv
            , a.skreqdate
            , a.skreqdeptcode
            , a.skreqempcode
            , a.accountno
            , case when e.condition1 = '1' THEN '4' else '2' end
            , ''
            , case when LOWER(p_salload) in ('empcode','iempcode','newload') AND a.acattype = 'S' OR LOWER(p_colload) in ('empcode','iempcode','newload','custcode') AND a.acattype = 'C' OR LOWER(p_expload) = 'importshtno' AND a.acattype = 'N' OR a.acattype = 'H' THEN a.acattype
                   else a.acatrulecode end
            , p_insertdt
            , p_iempcode

    from    ACAUTOORDT a
            left join VGT.TT_ACACC0047PL_ACAUTOORDT1 b on a.compcode = b.compcode
                                                          and a.plantcode = b.plantcode
                                                          and a.acattype = b.acattype
                                                          and a.slipindate = b.slipindate
                                                          and case  when LOWER(p_salload) = 'empcode'      and a.acattype = 'S' then a.empcode
                                                                    when LOWER(p_salload) = 'iempcode'     and a.acattype = 'S' then a.iempcode
                                                                    when LOWER(p_salload) = 'newload'      and a.acattype = 'S' then a.iempcode
                                                                    when LOWER(p_salload) = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                                                                    when LOWER(p_colload) = 'empcode'      and a.acattype = 'C' then a.empcode
                                                                    when LOWER(p_colload) = 'iempcode'     and a.acattype = 'C' then a.iempcode
                                                                    when LOWER(p_colload) = 'newload'      and a.acattype = 'C' then a.iempcode
                                                                    when LOWER(p_colload) = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                                                                    when LOWER(p_colload) = 'custcode'      and a.acattype = 'C' then a.custcode
                                                                    when LOWER(p_expload) = 'importshtno'  and a.acattype = 'N' then a.billno
                                                                    when a.acattype = 'H' then a.plantcode
                                                                    else a.acatrulecode
                                                              end = b.acatrulecode
            left join VGT.TT_ACACC0047PL_ACAUTOORDT2 c on a.compcode = c.compcode
                                                            and a.acattype = c.acattype
                                                            and a.slipindate = c.slipindate
                                                            and a.acatno = c.acatno
            left join ( select  a.divcode
                                , b.plantcode
                        from    CMCOMMONM a
                                join CMPLANTM b on a.filter2 = b.plantcode
                        where   a.cmmcode = 'AC201'
                      ) d on a.acattype = d.divcode
            left join ACAUTORULE e on a.acatrulecode = e.acautorcode
            left join CMEMPM f on a.iempcode = f.empcode

    where   a.compcode = p_compcode
            and a.actrnstate in ('1', '3')
            and a.acattype like p_slipdiv ;



    p_proccnt := SQL%ROWCOUNT;



    -- 전표상세임시파일생성(부문)
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACORDD1';

    INSERT INTO VGT.TT_ACACC0047PL_ACORDD1
    (
        select  a.compcode
                , replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno
                , c.acautoseq
                , c.dcdiv
                , c.acacccode || case when c.acautorcode like 'H%' and c.accamtdiv in ('10','11') then '1' else '' end as acccode
                , NVL(d.plantcode, a.plantcode) as plantcode
                , case when c.dcdiv in ('1','4') then    -- 차변,출금
                    fnAcAutoORDamt ( c.amtdiv,c.accamtdiv,c.acccalcdiv,c.accsamtdiv
                                     , a.trn1amt,a.trn2amt,a.trn3amt,a.trn4amt,a.trn5amt
                                     , a.trn6amt,a.trn7amt,a.trn8amt,a.trn9amt,a.trn10amt
                                     , a.trn11amt,a.trn12amt,a.trn13amt,a.trn14amt,a.trn15amt
                                     , a.trn16amt,a.trn17amt,a.trn18amt,a.trn19amt,a.trn20amt
                                     , a.trn21amt,a.trn22amt,a.trn23amt,a.trn24amt,a.trn25amt
                                     , a.trn26amt,a.trn27amt,a.trn28amt,a.trn29amt,a.trn30amt )
                       else 0
                end as debamt
                , case when c.dcdiv in ('2','3') then    -- 대변,입금
                    fnAcAutoORDamt ( c.amtdiv,c.accamtdiv,c.acccalcdiv,c.accsamtdiv
                                     , a.trn1amt,a.trn2amt,a.trn3amt,a.trn4amt,a.trn5amt
                                     , a.trn6amt,a.trn7amt,a.trn8amt,a.trn9amt,a.trn10amt
                                     , a.trn11amt,a.trn12amt,a.trn13amt,a.trn14amt,a.trn15amt
                                     , a.trn16amt,a.trn17amt,a.trn18amt,a.trn19amt,a.trn20amt
                                     , a.trn21amt,a.trn22amt,a.trn23amt,a.trn24amt,a.trn25amt
                                     , a.trn26amt,a.trn27amt,a.trn28amt,a.trn29amt,a.trn30amt )
                       else 0
                end as creamt
                , case  when a.acattype = 'H' then case when c.accamtdiv in ('01','02','03','04','20') then SUBSTR(a.remark, 0, 4) || '분 급여'
                                                        when c.accamtdiv = '05' then SUBSTR(a.remark, 0, 4) || '분 근로소득세'
                                                        when c.accamtdiv = '06' then SUBSTR(a.remark, 0, 4) || '분 근로주민세'
                                                        when c.accamtdiv = '12' then SUBSTR(a.remark, 0, 4) || '분 농특세'
                                                        when c.accamtdiv = '07' then SUBSTR(a.remark, 0, 4) || '분 국민연금 본인부담금'
                                                        when c.accamtdiv = '08' then SUBSTR(a.remark, 0, 4) || '분 건강보험 본인부담금'
                                                        when c.accamtdiv = '09' then SUBSTR(a.remark, 0, 4) || '분 고용보험 본인부담금'
                                                        when c.accamtdiv = '13' then SUBSTR(a.remark, 0, 4) || '분 기타'
                                                        else NVL(nullif(a.remark, ''), b.remark1)
                                                   end
                        else NVL(nullif(a.remark, ''), b.remark1)
                end as remark1
                , NVL(nullif(a.remark2, ''), b.remark2) as remark2
                , a.taxno
                , a.acatno

        from    ACAUTOORDT a
                join VGT.TT_ACACC0047PL_ACAUTOORDT1 b on   a.compcode = b.compcode
                                                           and a.plantcode = b.plantcode
                                                           and a.acattype = b.acattype
                                                           and a.slipindate = b.slipindate
                                                           and case when a.acattype = 'H' then a.plantcode else '' end = b.acatrulecode
                join ACAUTORULESM c on a.acatrulecode = c.acautorcode
                left join (
                            select  a.divcode, b.plantcode
                            from    CMCOMMONM a
                                    join CMPLANTM b on a.filter2 = b.plantcode
                            where   a.cmmcode = 'AC201'
                ) d on a.acattype = d.divcode

        where   a.compcode = p_compcode
                and a.actrnstate in ('1','3')
                and a.acattype like p_slipdiv
    ) ;



    -- 관리항목임시파일생성(부문)
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACORDS1';

    INSERT INTO VGT.TT_ACACC0047PL_ACORDS1
    (
        select  a.compcode
                , replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno
                , c.acautoseq
                , d.mngclucode
                , e.seq
                , fnAcAutoORDval (  d.mngcluvaldiv
                                    , a.userdef1code,  a.userdef2code,  a.userdef3code,   a.userdef4code,  a.userdef5code
                                    , a.userdef6code,  a.userdef7code,  a.userdef8code,   a.userdef9code,  a.userdef10code
                                    , a.userdef11code, a.userdef12code, a.userdef13code,  a.userdef14code, a.userdef15code
                                    , a.userdef16code, a.userdef17code, a.userdef18code,  a.userdef19code, a.userdef20code
                                    , a.userdef21code, a.userdef22code, a.userdef23code,  a.userdef24code, a.userdef25code
                                    , a.userdef26code, a.userdef27code, a.userdef28code,  a.userdef29code, a.userdef30code
                                    , a.deptcode,      a.custcode,      a.taxno,a.billno, a.issdate,a.expdate,a.cardno,a.empcode,a.cardokno ) as mngcluval
                , fnAcAutoORDval (  d.mngcludecdiv
                                    , a.userdef1code,a.userdef2code,a.userdef3code,a.userdef4code,a.userdef5code
                                    , a.userdef6code,a.userdef7code,a.userdef8code,a.userdef9code,a.userdef10code
                                    , a.userdef11code,a.userdef12code,a.userdef13code,a.userdef14code,a.userdef15code
                                    , a.userdef16code,a.userdef17code,a.userdef18code,a.userdef19code,a.userdef20code
                                    , a.userdef21code,a.userdef22code,a.userdef23code,a.userdef24code,a.userdef25code
                                    , a.userdef26code,a.userdef27code,a.userdef28code,a.userdef29code,a.userdef30code
                                    , a.deptcode,a.custcode,a.taxno,a.billno,a.issdate,a.expdate,a.cardno,a.empcode,a.cardokno ) as mngcludec
                ,a.acatno
        from    ACAUTOORDT a
                join VGT.TT_ACACC0047PL_ACAUTOORDT1 b on  a.compcode = b.compcode
                                                          and a.plantcode = b.plantcode
                                                          and a.acattype = b.acattype
                                                          and a.slipindate = b.slipindate
                                                          and case when a.acattype = 'H' then a.plantcode else a.acatrulecode end = b.acatrulecode
        join ACAUTORULESM c on a.acatrulecode = c.acautorcode
        join ACAUTORULEDS d on c.acautorcode = d.acautorcode
                               and c.acautoseq = d.acautoseq
        join ACACCMNGM e on c.acacccode = e.acccode
                            and e.dcdiv = case when c.dcdiv in ('1','4') then '1' else '2' end
                            and d.mngclucode = e.mngclucode

        where   a.compcode = p_compcode
                and a.actrnstate in ('1','3')
                and a.acattype like p_slipdiv
    ) ;



    -- 급여 이체포멧메 맞게 변경
    delete from VGT.TT_ACACC0047PL_ACORDD1 a
    where   a.slipinno like '%H%'
            and a.debamt = 0
            and a.creamt = 0 ;



    MERGE INTO VGT.TT_ACACC0047PL_ACORDS1 a
    USING (

            SELECT  --compare data
                    a.compcode
                    , a.slipinno
                    , a.acautoseq
                    , a.mngclucode
                    , a.seq
                    , a.acatno
                    --update data
                    , case when c.accamtdiv = '05' then ''
                           when c.accamtdiv = '06' then ''
                           when c.accamtdiv = '12' then ''
                           when c.accamtdiv = '07' then ''
                           when c.accamtdiv = '08' then ''
                           when c.accamtdiv = '09' then ''
                           when c.accamtdiv = '13' then ''
                           when c.accamtdiv = '20' then ''
                           else ''
                    end as mngcluval_update
                    , case when c.accamtdiv = '05' then '청주세무서'
                           when c.accamtdiv = '06' then '청원군'
                           when c.accamtdiv = '12' then '청주세무서'
                           when c.accamtdiv = '07' then '국민연금관리공단'
                           when c.accamtdiv = '08' then '국민건강보험공단'
                           when c.accamtdiv = '09' then '근로복지공단'
                           when c.accamtdiv = '13' then ''
                           when c.accamtdiv = '20' then ''
                           else ''
                    end as mngcludec_update

            from    VGT.TT_ACACC0047PL_ACORDS1 a
                    join VGT.TT_ACACC0047PL_ACORDD1 b on a.slipinno = b.slipinno
                                                         and a.acautoseq = b.acautoseq
                                                         and a.acatno = b.acatno
                    join ACAUTORULESM c on c.acautorcode = 'H01001'
                                           and b.acautoseq = c.acautoseq
            where   a.slipinno like '%H%'
                    and a.mngclucode = 'S010'


    ) src ON (  -- 비교
                a.compcode          = src.compcode
                AND a.slipinno      = src.slipinno
                AND a.acautoseq     = src.acautoseq
                AND a.mngclucode    = src.mngclucode
                AND a.seq           = src.seq
                AND a.acatno        = src.acatno
    )
    WHEN MATCHED THEN
        UPDATE SET      -- 업데이트 문장
                        a.mngcluval   = src.mngcluval_update
                        , a.mngcludec = src.mngcludec_update ;



    -- 영업거래처 대표거래처로 변경
    FOR rec IN (
                    select  value1
                            , value2
                    from    SYSPARAMETERMANAGE
                    where   parametercode = 'accsalescustload'
    )
    LOOP

        p_salecust := rec.value1 ;
        p_colcust  := rec.value2 ;

    END LOOP ;



    MERGE INTO VGT.TT_ACACC0047PL_ACORDS1 a
    USING (
            SELECT  --comare data
                    a.acatno
                    , a.acautoseq
                    , a.compcode
                    , a.mngclucode
                    , a.seq
                    , a.slipinno
                    -- update data
                    , NVL(c.custcode, a.mngcluval) AS mngcluval_update
                    , NVL(c.custname, a.mngcludec) AS mngcludec_update
            from    VGT.TT_ACACC0047PL_ACORDS1 a
                    join CMCUSTM b on a.mngcluval = b.custcode
                    join CMCUSTM c on b.custmajorcode = c.custcode
            where   a.mngclucode = 'S010'
                    and (   p_salecust = 'Y' and a.slipinno like '%S%' OR
                            p_colcust = 'Y' and a.slipinno like '%C%' )


    ) src ON (  -- 비교
                a.acatno            = src.acatno
                AND a.acautoseq     = src.acautoseq
                AND a.compcode      = src.compcode
                AND a.mngclucode    = src.mngclucode
                AND a.seq           = src.seq
                AND a.slipinno      = src.slipinno
    )
    WHEN MATCHED THEN
        UPDATE SET      -- 업데이트 문장
                        a.mngcluval   = src.mngcluval_update
                        , a.mngcludec = src.mngcludec_update ;



    -- 부문별합계 임시파일 생성
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACORDDS';

    INSERT INTO VGT.TT_ACACC0047PL_ACORDDS
    (
        select    compcode, slipinno, row_number() over(partition by compcode, slipinno order by min(acautoseq), min(acatno)) as slipinseq,
                dcdiv, acccode, max(plantcode) as plantcode, SUM(debamt) as debamt, SUM(creamt) as creamt,
                remark1 as remark1, max(remark2) as remark2, max(taxno) as taxno,
                mngclucode1, mngclucode2, mngclucode3, mngclucode4, mngclucode5, mngclucode6,
                mngcluval1, mngcluval2, mngcluval3, mngcluval4, mngcluval5, mngcluval6,
                max(mngcludec1) as mngcludec1, max(mngcludec2) as mngcludec2, max(mngcludec3) as mngcludec3,
                max(mngcludec4) as mngcludec4, max(mngcludec5) as mngcludec5, max(mngcludec6) as mngcludec6
        from (
            select    a.compcode, a.slipinno, a.acautoseq, a.dcdiv, a.acccode, a.plantcode, a.taxno,
                    max(a.debamt) as debamt, max(a.creamt) as creamt, a.remark1, a.remark2, a.acatno,
                    max(case when seq = 1 then mngclucode else '' end) as mngclucode1,
                    max(case when seq = 2 then mngclucode else '' end) as mngclucode2,
                    max(case when seq = 3 then mngclucode else '' end) as mngclucode3,
                    max(case when seq = 4 then mngclucode else '' end) as mngclucode4,
                    max(case when seq = 5 then mngclucode else '' end) as mngclucode5,
                    max(case when seq = 6 then mngclucode else '' end) as mngclucode6,
                    max(case when seq = 1 then mngcluval else '' end) as mngcluval1,
                    max(case when seq = 2 then mngcluval else '' end) as mngcluval2,
                    max(case when seq = 3 then mngcluval else '' end) as mngcluval3,
                    max(case when seq = 4 then mngcluval else '' end) as mngcluval4,
                    max(case when seq = 5 then mngcluval else '' end) as mngcluval5,
                    max(case when seq = 6 then mngcluval else '' end) as mngcluval6,
                    max(case when seq = 1 then mngcludec else '' end) as mngcludec1,
                    max(case when seq = 2 then mngcludec else '' end) as mngcludec2,
                    max(case when seq = 3 then mngcludec else '' end) as mngcludec3,
                    max(case when seq = 4 then mngcludec else '' end) as mngcludec4,
                    max(case when seq = 5 then mngcludec else '' end) as mngcludec5,
                    max(case when seq = 6 then mngcludec else '' end) as mngcludec6
            from    VGT.TT_ACACC0047PL_ACORDD1 a
                    left join VGT.TT_ACACC0047PL_ACORDS1 b
                        on a.slipinno = b.slipinno
                        and a.acautoseq = b.acautoseq
                        and a.acatno = b.acatno
            group by a.compcode, a.slipinno, a.acautoseq, a.dcdiv, a.taxno,
                     a.acccode, a.plantcode, a.remark1, a.remark2, a.acatno
            having sum(a.debamt) <> 0 or sum(a.creamt) <> 0
        ) a

        group by compcode, slipinno, dcdiv, acccode, remark1, mngclucode1, mngclucode2, mngclucode3, mngclucode4,
                 mngclucode5, mngclucode6, mngcluval1, mngcluval2, mngcluval3, mngcluval4, mngcluval5, mngcluval6
        having SUM(debamt) <> 0 or SUM(creamt) <> 0
    );



    -- 부문별자료 생성
    MERGE INTO VGT.TT_ACACC0047PL_ACORDDS a
     USING (SELECT a.slipinseq
                  ,a.debamt
                  ,a.creamt
                  ,a.remark1
                  ,a.remark2
                  ,a.taxno
                  ,a.mngclucode1
                  ,a.mngclucode2
                  ,a.mngclucode3
                  ,a.mngclucode4
                  ,a.mngclucode5
                  ,a.mngclucode6
                  ,a.acccode
                  ,a.compcode
                  ,a.slipinno
                  ,a.plantcode
                  ,a.dcdiv
                  ,CASE WHEN a.mngclucode1 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptcode ELSE a.mngcluval1 END c1
                  ,CASE WHEN a.mngclucode2 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptcode ELSE a.mngcluval2 END c2
                  ,CASE WHEN a.mngclucode3 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptcode ELSE a.mngcluval3 END c3
                  ,CASE WHEN a.mngclucode4 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptcode ELSE a.mngcluval4 END c4
                  ,CASE WHEN a.mngclucode5 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptcode ELSE a.mngcluval5 END c5
                  ,CASE WHEN a.mngclucode6 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptcode ELSE a.mngcluval6 END c6
                  ,CASE WHEN a.mngclucode1 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptname ELSE a.mngcludec1 END c7
                  ,CASE WHEN a.mngclucode2 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptname ELSE a.mngcludec2 END c8
                  ,CASE WHEN a.mngclucode3 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptname ELSE a.mngcludec3 END c9
                  ,CASE WHEN a.mngclucode4 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptname ELSE a.mngcludec4 END c10
                  ,CASE WHEN a.mngclucode5 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptname ELSE a.mngcludec5 END c11
                  ,CASE WHEN a.mngclucode6 = 'S040' AND TRIM(c.deptcode) IS NOT NULL THEN c.deptname ELSE a.mngcludec6 END c12
              FROM VGT.TT_ACACC0047PL_ACORDDS a
                   JOIN SYSPARAMETERMANAGE b ON b.parametercode = 'accpayloaddept'
                                                AND b.usediv = 'Y'
                   JOIN CMDEPTM c ON b.value1 = c.deptcode
             WHERE p_slipdiv = 'H'
        ) src ON (  NVL(a.slipinseq, 0) = NVL(src.slipinseq, 0)
                    AND NVL(a.debamt, 0) = NVL(src.debamt, 0)
                    AND NVL(a.creamt, 0) = NVL(src.creamt, 0)
                    AND NVL(a.remark1, ' ') = NVL(src.remark1, ' ')
                    AND NVL(a.remark2, ' ') = NVL(src.remark2, ' ')
                    AND NVL(a.taxno, ' ') = NVL(src.taxno, ' ')
                    AND NVL(a.mngclucode1, ' ') = NVL(src.mngclucode1, ' ')
                    AND NVL(a.mngclucode2, ' ') = NVL(src.mngclucode2, ' ')
                    AND NVL(a.mngclucode3, ' ') = NVL(src.mngclucode3, ' ')
                    AND NVL(a.mngclucode4, ' ') = NVL(src.mngclucode4, ' ')
                    AND NVL(a.mngclucode5, ' ') = NVL(src.mngclucode5, ' ')
                    AND NVL(a.mngclucode6, ' ') = NVL(src.mngclucode6, ' ')
                    AND NVL(a.acccode, ' ') = NVL(src.acccode, ' ')
                    AND NVL(a.compcode, ' ') = NVL(src.compcode, ' ')
                    AND NVL(a.slipinno, ' ') = NVL(src.slipinno, ' ')
                    AND NVL(a.plantcode, ' ') = NVL(src.plantcode, ' ')
                    AND NVL(a.dcdiv, ' ') = NVL(src.dcdiv, ' ')
                )
    WHEN MATCHED
    THEN
        UPDATE SET a.mngcluval1 = src.c1
                  ,a.mngcluval2 = src.c2
                  ,a.mngcluval3 = src.c3
                  ,a.mngcluval4 = src.c4
                  ,a.mngcluval5 = src.c5
                  ,a.mngcluval6 = src.c6
                  ,a.mngcludec1 = src.c7
                  ,a.mngcludec2 = src.c8
                  ,a.mngcludec3 = src.c9
                  ,a.mngcludec4 = src.c10
                  ,a.mngcludec5 = src.c11
                  ,a.mngcludec6 = src.c12;



    INSERT INTO ACORDD(
                    compcode
                   ,slipinno
                   ,slipinseq
                   ,dcdiv
                   ,acccode
                   ,plantcode
                   ,debamt
                   ,creamt
                   ,slipdate
                   ,slipnum
                   ,remark1
                   ,remark2
                   ,taxno
                   ,datadiv
                   ,rptseq
                   ,insertdt
                   ,iempcode
                )
        SELECT a.compcode
              ,a.slipinno
              ,a.slipinseq
              ,a.dcdiv
              ,SUBSTR(a.acccode, 0, 8)
              ,a.plantcode
              ,a.debamt
              ,a.creamt
              ,b.slipdate
              ,b.slipnum
              ,a.remark1
              ,a.remark2
              ,CASE WHEN a.acccode LIKE p_acccode2 || '%' or a.acccode like p_acccode3 || '%' then NVL(a.taxno,'') else '' end
              ,''
              , a.slipinseq
              , SYSDATE
              , p_iempcode
        from    VGT.TT_ACACC0047PL_ACORDDS a
                join ACORDM b on a.slipinno = b.slipinno ;



    INSERT INTO ACORDS(
                    compcode
                   ,slipinno
                   ,slipinseq
                   ,mngclucode
                   ,seq
                   ,mngcluval
                   ,mngcludec
                   ,insertdt
                   ,iempcode
                )
        SELECT compcode
              ,slipinno
              ,slipinseq
              ,mngclucode1
              ,1
              ,mngcluval1
              ,mngcludec1
              ,SYSDATE
              ,p_iempcode
          FROM VGT.TT_ACACC0047PL_ACORDDS
         WHERE TRIM(mngclucode1) IS NOT NULL;



    INSERT INTO ACORDS(
                    compcode
                   ,slipinno
                   ,slipinseq
                   ,mngclucode
                   ,seq
                   ,mngcluval
                   ,mngcludec
                   ,insertdt
                   ,iempcode
                )
        SELECT compcode
              ,slipinno
              ,slipinseq
              ,mngclucode2
              ,2
              ,mngcluval2
              ,mngcludec2
              ,SYSDATE
              ,p_iempcode
          FROM VGT.TT_ACACC0047PL_ACORDDS
         WHERE TRIM(mngclucode2) IS NOT NULL;



    INSERT INTO ACORDS(
                    compcode
                   ,slipinno
                   ,slipinseq
                   ,mngclucode
                   ,seq
                   ,mngcluval
                   ,mngcludec
                   ,insertdt
                   ,iempcode
                )
        SELECT compcode
              ,slipinno
              ,slipinseq
              ,mngclucode3
              ,3
              ,mngcluval3
              ,mngcludec3
              ,SYSDATE
              ,p_iempcode
          FROM VGT.TT_ACACC0047PL_ACORDDS
         WHERE TRIM(mngclucode3) IS NOT NULL;



    INSERT INTO ACORDS(
                    compcode
                   ,slipinno
                   ,slipinseq
                   ,mngclucode
                   ,seq
                   ,mngcluval
                   ,mngcludec
                   ,insertdt
                   ,iempcode
                )
        SELECT compcode
              ,slipinno
              ,slipinseq
              ,mngclucode4
              ,4
              ,mngcluval4
              ,mngcludec4
              ,SYSDATE
              ,p_iempcode
          FROM VGT.TT_ACACC0047PL_ACORDDS
         WHERE TRIM(mngclucode4) IS NOT NULL;



    INSERT INTO ACORDS(
                    compcode
                   ,slipinno
                   ,slipinseq
                   ,mngclucode
                   ,seq
                   ,mngcluval
                   ,mngcludec
                   ,insertdt
                   ,iempcode
                )
        SELECT compcode
              ,slipinno
              ,slipinseq
              ,mngclucode5
              ,5
              ,mngcluval5
              ,mngcludec5
              ,SYSDATE
              ,p_iempcode
          FROM VGT.TT_ACACC0047PL_ACORDDS
         WHERE TRIM(mngclucode5) IS NOT NULL;



    INSERT INTO ACORDS(
                    compcode
                   ,slipinno
                   ,slipinseq
                   ,mngclucode
                   ,seq
                   ,mngcluval
                   ,mngcludec
                   ,insertdt
                   ,iempcode
                )
        SELECT compcode
              ,slipinno
              ,slipinseq
              ,mngclucode6
              ,6
              ,mngcluval6
              ,mngcludec6
              ,SYSDATE
              ,p_iempcode
          FROM VGT.TT_ACACC0047PL_ACORDDS
         WHERE TRIM(mngclucode6) IS NOT NULL;



    -- 전표상세임시파일생성(개별)
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACORDD2';

    INSERT INTO VGT.TT_ACACC0047PL_ACORDD2
    (
        select    a.compcode
                ,replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno
                ,c.acautoseq
                ,c.dcdiv
                ,c.acacccode as acccode
                ,NVL(d.plantcode, a.plantcode) as plantcode
                ,case when c.dcdiv in ('1','4') then    -- 차변,출금
                        fnAcAutoORDamt (c.amtdiv,c.accamtdiv,c.acccalcdiv,c.accsamtdiv
                                ,a.trn1amt,a.trn2amt,a.trn3amt,a.trn4amt,a.trn5amt
                                ,a.trn6amt,a.trn7amt,a.trn8amt,a.trn9amt,a.trn10amt
                                ,a.trn11amt,a.trn12amt,a.trn13amt,a.trn14amt,a.trn15amt
                                ,a.trn16amt,a.trn17amt,a.trn18amt,a.trn19amt,a.trn20amt
                                ,a.trn21amt,a.trn22amt,a.trn23amt,a.trn24amt,a.trn25amt
                                ,a.trn26amt,a.trn27amt,a.trn28amt,a.trn29amt,a.trn30amt)
                        else 0 end as debamt
                ,case when c.dcdiv in ('2','3') then    -- 대변,입금
                        fnAcAutoORDamt (c.amtdiv,c.accamtdiv,c.acccalcdiv,c.accsamtdiv
                                ,a.trn1amt,a.trn2amt,a.trn3amt,a.trn4amt,a.trn5amt
                                ,a.trn6amt,a.trn7amt,a.trn8amt,a.trn9amt,a.trn10amt
                                ,a.trn11amt,a.trn12amt,a.trn13amt,a.trn14amt,a.trn15amt
                                ,a.trn16amt,a.trn17amt,a.trn18amt,a.trn19amt,a.trn20amt
                                ,a.trn21amt,a.trn22amt,a.trn23amt,a.trn24amt,a.trn25amt
                                ,a.trn26amt,a.trn27amt,a.trn28amt,a.trn29amt,a.trn30amt)
                        else 0 end as creamt
                ,NVL(nullif(a.remark, ''), b.remark1) as remark1
                ,NVL(nullif(a.remark2, ''), b.remark2) as remark2
                ,a.taxno
                ,case when p_colseq = 'Y' then a.trn30amt else 0 end as crtord

        from    ACAUTOORDT a
                join VGT.TT_ACACC0047PL_ACAUTOORDT2 b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.acatno = b.acatno
                join ACAUTORULESM c
                    on a.acatrulecode = c.acautorcode
                left join (
                    select    a.divcode, b.plantcode
                    from    CMCOMMONM a
                            join CMPLANTM b
                                on a.filter2 = b.plantcode
                    where    a.cmmcode = 'AC201'
                ) d on a.acattype = d.divcode

        where    a.compcode = p_compcode
                and a.actrnstate in ('1', '3')
                and a.acattype like p_slipdiv
    ) ;



    -- 관리항목임시파일생성(개별)
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACORDS2';

    INSERT INTO VGT.TT_ACACC0047PL_ACORDS2
    (
        select  a.compcode
                , replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno
                , c.acautoseq
                , d.mngclucode
                , e.seq
                , fnAcAutoORDval (  d.mngcluvaldiv
                                    ,a.userdef1code,a.userdef2code,a.userdef3code,a.userdef4code,a.userdef5code
                                    ,a.userdef6code,a.userdef7code,a.userdef8code,a.userdef9code,a.userdef10code
                                    ,a.userdef11code,a.userdef12code,a.userdef13code,a.userdef14code,a.userdef15code
                                    ,a.userdef16code,a.userdef17code,a.userdef18code,a.userdef19code,a.userdef20code
                                    ,a.userdef21code,a.userdef22code,a.userdef23code,a.userdef24code,a.userdef25code
                                    ,a.userdef26code,a.userdef27code,a.userdef28code,a.userdef29code,a.userdef30code
                                    ,a.deptcode,nvl(g.custcode,a.custcode),a.taxno,a.billno,a.issdate,a.expdate,a.cardno,a.empcode,a.cardokno ) as mngcluval
                ,  fnAcAutoORDval ( d.mngcludecdiv
                                    ,a.userdef1code,a.userdef2code,a.userdef3code,a.userdef4code,a.userdef5code
                                    ,nvl(g.custname,a.userdef6code),a.userdef7code,a.userdef8code,a.userdef9code,a.userdef10code
                                    ,a.userdef11code,a.userdef12code,a.userdef13code,a.userdef14code,a.userdef15code
                                    ,a.userdef16code,a.userdef17code,a.userdef18code,a.userdef19code,a.userdef20code
                                    ,a.userdef21code,a.userdef22code,a.userdef23code,a.userdef24code,a.userdef25code
                                    ,a.userdef26code,a.userdef27code,a.userdef28code,a.userdef29code,a.userdef30code
                                    ,a.deptcode,a.custcode,a.taxno,a.billno,a.issdate,a.expdate,a.cardno,a.empcode,a.cardokno ) as mngcludec
        from    ACAUTOORDT a
                join VGT.TT_ACACC0047PL_ACAUTOORDT2 b on a.compcode = b.compcode
                                                         and a.acattype = b.acattype
                                                         and a.slipindate = b.slipindate
                                                         and a.acatno = b.acatno
                join ACAUTORULESM c on a.acatrulecode = c.acautorcode
                join ACAUTORULEDS d on c.acautorcode = d.acautorcode
                                       and c.acautoseq = d.acautoseq
                join ACACCMNGM e on c.acacccode = e.acccode
                                    and e.dcdiv = case when c.dcdiv in ('1',' 4') then '1' else '2' end
                                    and d.mngclucode = e.mngclucode
                -- 카드수금인경우 미수금의 거래처를 연결거래처로 변경
                left join CMCOMMONM f on a.acatrulecode = 'C01002'
                                         and c.acacccode = p_acccode1
                                         and f.cmmcode = 'AC17'
                                         and a.cardcomp = f.divcode
                left join CMCUSTM g on a.acatrulecode = 'C01002'
                                       and c.acacccode = p_acccode1
                                       and NVL(nullif(f.remark, NULL),'') = g.custcode

        where    a.compcode = p_compcode
                and a.actrnstate in ('1', '3')
                and a.acattype like p_slipdiv

    ) ;



    -- 전표상세임시파일생성(부문:수금)
    insert into VGT.TT_ACACC0047PL_ACORDD2 (
        select    a.compcode
                ,replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno
                ,row_number() over(partition by a.slipindate || a.acattype || b.slipinnum order by a.acatno, c.acautoseq)
                ,c.dcdiv
                ,c.acacccode as acccode
                ,NVL(d.plantcode, a.plantcode) as plantcode
                ,case when c.dcdiv in ('1','4') then    -- 차변,출금
                        fnAcAutoORDamt (c.amtdiv,c.accamtdiv,c.acccalcdiv,c.accsamtdiv
                                ,a.trn1amt,a.trn2amt,a.trn3amt,a.trn4amt,a.trn5amt
                                ,a.trn6amt,a.trn7amt,a.trn8amt,a.trn9amt,a.trn10amt
                                ,a.trn11amt,a.trn12amt,a.trn13amt,a.trn14amt,a.trn15amt
                                ,a.trn16amt,a.trn17amt,a.trn18amt,a.trn19amt,a.trn20amt
                                ,a.trn21amt,a.trn22amt,a.trn23amt,a.trn24amt,a.trn25amt
                                ,a.trn26amt,a.trn27amt,a.trn28amt,a.trn29amt,a.trn30amt)
                        else 0 end as debamt
                ,case when c.dcdiv in ('2','3') then    -- 대변,입금
                        fnAcAutoORDamt (c.amtdiv,c.accamtdiv,c.acccalcdiv,c.accsamtdiv
                                ,a.trn1amt,a.trn2amt,a.trn3amt,a.trn4amt,a.trn5amt
                                ,a.trn6amt,a.trn7amt,a.trn8amt,a.trn9amt,a.trn10amt
                                ,a.trn11amt,a.trn12amt,a.trn13amt,a.trn14amt,a.trn15amt
                                ,a.trn16amt,a.trn17amt,a.trn18amt,a.trn19amt,a.trn20amt
                                ,a.trn21amt,a.trn22amt,a.trn23amt,a.trn24amt,a.trn25amt
                                ,a.trn26amt,a.trn27amt,a.trn28amt,a.trn29amt,a.trn30amt)
                        else 0 end as creamt
                ,case when c.acacccode = p_acccode5 then a.userdef10code else NVL(nullif(a.remark, ''), b.remark1) end as remark1
                ,NVL(nullif(a.remark2, NULL), b.remark2) as remark2
                ,a.taxno
                ,case when p_colseq = 'Y' then a.trn30amt else 0 end as crtord

        from    ACAUTOORDT a
                join VGT.TT_ACACC0047PL_ACAUTOORDT1 b on a.compcode = b.compcode
                                                        and a.plantcode = b.plantcode
                                                        and a.acattype = b.acattype
                                                        and a.slipindate = b.slipindate
                                                        and case when LOWER(p_salload) = 'empcode' and a.acattype = 'S' then a.empcode
                                                                 when LOWER(p_salload) = 'iempcode' and a.acattype = 'S' then a.iempcode
                                                                 when LOWER(p_salload) = 'newload' and a.acattype = 'S' then a.iempcode
                                                                 when LOWER(p_salload) = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                                                                 when LOWER(p_colload) = 'empcode' and a.acattype = 'C' then a.empcode
                                                                 when LOWER(p_colload) = 'iempcode' and a.acattype = 'C' then a.iempcode
                                                                 when LOWER(p_colload) = 'newload' and a.acattype = 'C' then a.iempcode
                                                                 when LOWER(p_colload) = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                                                                 when LOWER(p_colload) = 'custcode' and a.acattype = 'C' then a.custcode
                                                                 when LOWER(p_expload) = 'importshtno' and a.acattype = 'N' then a.billno
                                                                 else '' end = b.acatrulecode
                join ACAUTORULESM c on a.acatrulecode = c.acautorcode
                left join (
                            select  a.divcode
                                    , b.plantcode
                            from    CMCOMMONM a
                                    join CMPLANTM b on a.filter2 = b.plantcode
                            where   a.cmmcode = 'AC201' ) d on a.acattype = d.divcode

        where    a.compcode = p_compcode
                and a.actrnstate in ('1','3')
                and a.acattype like p_slipdiv
                and ( TRIM(p_salload) IS NOT NULL or TRIM(p_colload) IS NOT NULL or TRIM(p_expload) IS NOT NULL  )

    ) ;



    -- 관리항목임시파일생성(부문:수금)
    insert into VGT.TT_ACACC0047PL_ACORDS2
    (
        select   a.compcode
                ,a.slipinno2
                ,a.slipinseq2
                ,b.mngclucode
                ,d.seq
                ,fnAcAutoORDval ( b.mngcluvaldiv
                        ,a.userdef1code,a.userdef2code,a.userdef3code,a.userdef4code,a.userdef5code
                        ,a.userdef6code,a.userdef7code,a.userdef8code,a.userdef9code,a.userdef10code
                        ,a.userdef11code,a.userdef12code,a.userdef13code,a.userdef14code,a.userdef15code
                        ,a.userdef16code,a.userdef17code,a.userdef18code,a.userdef19code,a.userdef20code
                        ,a.userdef21code,a.userdef22code,a.userdef23code,a.userdef24code,a.userdef25code
                        ,a.userdef26code,a.userdef27code,a.userdef28code,a.userdef29code,a.userdef30code
                        ,a.deptcode,a.custcode,a.taxno,a.billno,a.issdate,a.expdate,a.cardno,a.empcode,a.cardokno) as mngcluval
                , fnAcAutoORDval ( b.mngcludecdiv
                        ,a.userdef1code,a.userdef2code,a.userdef3code,a.userdef4code,a.userdef5code
                        ,a.userdef6code,a.userdef7code,a.userdef8code,a.userdef9code,a.userdef10code
                        ,a.userdef11code,a.userdef12code,a.userdef13code,a.userdef14code,a.userdef15code
                        ,a.userdef16code,a.userdef17code,a.userdef18code,a.userdef19code,a.userdef20code
                        ,a.userdef21code,a.userdef22code,a.userdef23code,a.userdef24code,a.userdef25code
                        ,a.userdef26code,a.userdef27code,a.userdef28code,a.userdef29code,a.userdef30code
                        ,a.deptcode,a.custcode,a.taxno,a.billno,a.issdate,a.expdate,a.cardno,a.empcode,a.cardokno) as mngcludec
        from (
                select    a.*
                        ,replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno2
                        ,row_number() over(partition by a.slipindate || a.acattype || b.slipinnum order by a.acatno, c.acautoseq) slipinseq2
                        ,c.acautorcode
                        ,c.acautoseq
                        ,c.acacccode
                        ,c.dcdiv
                from    ACAUTOORDT a
                        join VGT.TT_ACACC0047PL_ACAUTOORDT1 b on a.compcode = b.compcode
                                                                and a.plantcode = b.plantcode
                                                                and a.acattype = b.acattype
                                                                and a.slipindate = b.slipindate
                                                                and case when LOWER(p_salload) = 'empcode' and a.acattype = 'S' then a.empcode
                                                                         when LOWER(p_salload) = 'iempcode' and a.acattype = 'S' then a.iempcode
                                                                         when LOWER(p_salload) = 'newload' and a.acattype = 'S' then a.iempcode
                                                                         when LOWER(p_salload) = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                                                                         when LOWER(p_colload) = 'empcode' and a.acattype = 'C' then a.empcode
                                                                         when LOWER(p_colload) = 'iempcode' and a.acattype = 'C' then a.iempcode
                                                                         when LOWER(p_colload) = 'newload' and a.acattype = 'C' then a.iempcode
                                                                         when LOWER(p_colload) = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                                                                         when LOWER(p_colload) = 'custcode' and a.acattype = 'C' then a.custcode
                                                                         when LOWER(p_expload) = 'importshtno' and a.acattype = 'N' then a.billno
                                                                         else '' end = b.acatrulecode
                        join ACAUTORULESM c on a.acatrulecode = c.acautorcode
                where    a.compcode = p_compcode
                        and a.actrnstate in ('1', '3')
                        and a.acattype like p_slipdiv
                        and ( TRIM(p_salload) IS NOT NULL OR TRIM(p_colload) IS NOT NULL OR TRIM(p_expload) IS NOT NULL )
            ) a
            join ACAUTORULEDS b on a.acautorcode = b.acautorcode
                                   and a.acautoseq = b.acautoseq
            join ACACCMNGM d on a.acacccode = d.acccode
                                and d.dcdiv = case when a.dcdiv in ('1','4') then '1' else '2' end
                                and b.mngclucode = d.mngclucode

    ) ;



    -- 차/대변 금액이 0인것은 삭제
    FOR rec IN (

        SELECT  b.acautoseq
                , b.compcode
                , b.mngclucode
                , b.mngcludec
                , b.mngcluval
                , b.seq
                , b.slipinno
        from    VGT.TT_ACACC0047PL_ACORDD2 a
                join VGT.TT_ACACC0047PL_ACORDS2 b on a.compcode = b.compcode
                                                     and a.slipinno = b.slipinno
                                                     and a.acautoseq = b.acautoseq
                left join CMCOMMONM c on c.cmmcode = 'AC251'
                                         and c.hdivcode in ('04', '12')
                                         and a.acccode = c.filter1
        where   a.debamt = 0
                and a.creamt = 0
                and TRIM(c.cmmcode) IS NULL

    )
    LOOP

        DELETE FROM VGT.TT_ACACC0047PL_ACORDS2 a
        WHERE   a.acautoseq         = rec.acautoseq
                AND a.compcode      = rec.compcode
                AND a.mngclucode    = rec.mngclucode
                AND a.mngcludec     = rec.mngcludec
                AND a.mngcluval     = rec.mngcluval
                AND a.seq           = rec.seq
                AND a.slipinno      = rec.slipinno ;

    END LOOP;



    FOR rec IN (

        SELECT  a.acautoseq
                , a.acccode
                , a.compcode
                , a.creamt
                , a.crtord
                , a.dcdiv
                , a.debamt
                , a.plantcode
                , a.remark1
                , a.remark2
                , a.slipinno
                , a.taxno
        from    VGT.TT_ACACC0047PL_ACORDD2 a
                left join CMCOMMONM c on c.cmmcode = 'AC251'
                                         and c.hdivcode in ('04', '12')
                                         and a.acccode = c.filter1
        where   a.debamt = 0
                and a.creamt = 0
                and TRIM(c.cmmcode) IS NULL

    )
    LOOP

        DELETE FROM VGT.TT_ACACC0047PL_ACORDD2 a
        WHERE   a.acautoseq     = rec.acautoseq
                AND a.acccode   = rec.acccode
                AND a.compcode  = rec.compcode
                AND a.creamt    = rec.creamt
                AND a.crtord    = rec.crtord
                AND a.dcdiv     = rec.dcdiv
                AND a.debamt    = rec.debamt
                AND a.plantcode = rec.plantcode
                AND a.remark1   = rec.remark1
                AND a.remark2   = rec.remark2
                AND a.slipinno  = rec.slipinno
                AND a.taxno     = rec.taxno ;

    END LOOP;




    -- 영업거래처 대표거래처로 변경
    MERGE INTO VGT.TT_ACACC0047PL_ACORDS2 a
    USING (
            SELECT  a.compcode
                    , a.slipinno
                    , a.acautoseq
                    , a.mngclucode
                    , a.seq
                    , a.mngcluval
                    , a.mngcludec

                    , NVL(c.custcode, a.mngcluval) AS mngcluval_update
                    , NVL(c.custname, a.mngcludec) AS mngcludec_update

            FROM    VGT.TT_ACACC0047PL_ACORDS2 a
                    JOIN CMCUSTM b ON a.mngcluval = b.custcode
                    JOIN CMCUSTM c ON b.custmajorcode = c.custcode
            where   a.mngclucode = 'S010'
                    AND (p_salecust = 'Y' AND a.slipinno like '%S%' OR p_colcust = 'Y' AND a.slipinno LIKE '%C%' )

    ) src ON (  NVL(a.compcode, ' ')        = NVL(src.compcode, ' ')
                AND NVL(a.slipinno, ' ')    = NVL(src.slipinno, ' ')
                AND NVL(a.acautoseq, ' ')   = NVL(src.acautoseq, ' ')
                AND NVL(a.mngclucode, ' ')  = NVL(src.mngclucode, ' ')
                AND NVL(a.seq, ' ')         = NVL(src.seq, ' ')
    )
        WHEN MATCHED
        THEN
            UPDATE SET  a.mngcluval   = src.mngcluval_update
                        , a.mngcludec = src.mngcludec_update ;



    -- 전표상세일련번호재생성(개별)
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACORDD22';

    INSERT INTO VGT.TT_ACACC0047PL_ACORDD22
    (
        SELECT       compcode
                    ,slipinno
                    ,row_number() over(partition by compcode, slipinno order by crtord, acautoseq) as slipinseq
                    ,dcdiv
                    ,acccode
                    ,plantcode
                    ,debamt
                    ,creamt
                    ,remark1
                    ,remark2
                    ,taxno
                    ,acautoseq

        FROM        VGT.TT_ACACC0047PL_ACORDD2
    ) ;



    -- 전표상세생성(개별)
    INSERT INTO ACORDD (
        compcode
        ,slipinno
        ,slipinseq
        ,dcdiv
        ,acccode
        ,plantcode
        ,debamt
        ,creamt
        ,slipdate
        ,slipnum
        ,remark1
        ,remark2
        ,taxno
        ,datadiv
        ,rptseq
        ,insertdt
        ,iempcode
    )
    SELECT  a.compcode
            , a.slipinno
            , a.slipinseq
            , a.dcdiv
            , a.acccode
            , a.plantcode
            , a.debamt
            , a.creamt
            , b.slipdate
            , b.slipnum
            , a.remark1
            , a.remark2
            , CASE WHEN a.acccode LIKE p_acccode2 || '%' OR a.acccode LIKE p_acccode3 || '%' THEN NVL(a.taxno,'') ELSE '' END
            , ''
            , a.slipinseq
            , p_insertdt
            , p_iempcode
    from    VGT.TT_ACACC0047PL_ACORDD22 a
            JOIN ACORDM b ON a.slipinno = b.slipinno ;



    -- 전표관리생성(개별)
    INSERT INTO ACORDS (
        compcode
        , slipinno
        , slipinseq
        , mngclucode
        , seq
        , mngcluval
        , mngcludec
        , insertdt
        , iempcode
    )
    SELECT  a.compcode
            , a.slipinno
            , b.slipinseq
            , a.mngclucode
            , a.seq
            , a.mngcluval
            , a.mngcludec
            , p_insertdt
            , p_iempcode
    FROM    VGT.TT_ACACC0047PL_ACORDS2 a
            JOIN VGT.TT_ACACC0047PL_ACORDD22 b on a.compcode = b.compcode
                                                  AND a.slipinno = b.slipinno
                                                  AND a.acautoseq = b.acautoseq ;




    -- 회계 자동전표 처리 모니터링 변경
    MERGE INTO ACAUSLIPM a
    USING (

        select  --compare data
                b.compcode
                , b.slipindate
                , b.accdiv
                , b.acautorcode

                -- update data
                , a.iempcode
                , a.insertdt
        from    (
                    select  compcode
                            , slipindate
                            , acattype
                            , acatrulecode
                            , max(iempcode) as iempcode
                            , max(insertdt) as insertdt
                    from    ACAUTOORDT
                    where   compcode = p_compcode
                            and actrnstate in ('1','3','4')
                            and acattype like p_slipdiv

                    group by    compcode, slipindate, acattype, acatrulecode
                ) a
                join ACAUSLIPM b on a.compcode = b.compcode
                                    and a.slipindate = b.slipindate
                                    and a.acattype = b.accdiv
                                    and a.acatrulecode = b.acautorcode

    ) src ON (    -- 비교
                a.compcode        = src.compcode
                AND a.slipindate  = src.slipindate
                AND a.accdiv      = src.accdiv
                AND a.acautorcode = src.acautorcode
    )
    WHEN MATCHED THEN
        UPDATE SET    -- 업데이트 문장
                    a.sndempcode    = src.iempcode
                    , a.snddate     = TO_CHAR(src.insertdt, 'YYYY-MM-DD')
                    , a.trnempcode  = p_iempcode
                    , a.trndate     = TO_CHAR(SYSDATE, 'YYYY-MM-DD')
                    , a.updatedt    = SYSDATE
                    , a.uempcode    = p_iempcode ;



    -- 회계 자동전표 처리 모니터링 입력
    INSERT INTO ACAUSLIPM(
                    compcode
                   ,slipindate
                   ,accdiv
                   ,acautorcode
                   ,sndempcode
                   ,snddate
                   ,trnempcode
                   ,trndate
                   ,insertdt
                   ,iempcode
                )
        SELECT a.compcode
              ,a.slipindate
              ,a.acattype
              ,a.acatrulecode
              ,a.iempcode
              ,TO_CHAR(a.insertdt, 'YYYY-MM-DD')
              ,p_iempcode
              ,TO_CHAR(SYSDATE, 'YYYY-MM-DD')
              ,SYSDATE
              ,p_iempcode
          FROM (  SELECT compcode
                        ,slipindate
                        ,acattype
                        ,acatrulecode
                        ,MAX(iempcode) AS iempcode
                        ,MAX(insertdt) AS insertdt
                    FROM ACAUTOORDT
                   WHERE compcode = p_compcode
                         AND actrnstate IN ('1', '3', '4')
                         AND acattype LIKE p_slipdiv
                GROUP BY compcode
                        ,slipindate
                        ,acattype
                        ,acatrulecode) a
               LEFT JOIN ACAUSLIPM b
                   ON a.compcode = b.compcode
                      AND a.slipindate = b.slipindate
                      AND a.acattype = b.accdiv
                      AND a.acatrulecode = b.acautorcode
         WHERE TRIM(b.compcode) IS NULL;



    OPEN SPACC_CURSOR;

    LOOP
        FETCH SPACC_CURSOR INTO p_slipinno ;

        EXIT WHEN SPACC_CURSOR%NOTFOUND;

            spACfund0021P (     p_div => 'C2'
                                , p_compcode => p_compcode
                                , p_slipinno => p_slipinno
                                , p_iempcode => p_iempcode
                                , p_userid => p_userid
                                , p_reasondiv => p_reasondiv
                                , p_reasontext => p_reasontext
                                , MESSAGE => MESSAGE
                                , IO_CURSOR => IO_CURSOR
                           ) ;

    END LOOP;

    CLOSE SPACC_CURSOR;



    -- 수금전표 생성시 어음생성
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0047PL_ACBILLM';

    INSERT INTO VGT.TT_ACACC0047PL_ACBILLM
    (
        SELECT  a.compcode
                ,a.billno
                ,MAX(b.coldiv) AS billdiv
                ,MIN(b.issdate) AS issdate
                ,MIN(b.coldate) AS coldate
                ,MAX(b.expdate) AS expdate
                ,SUM(b.colamt) AS billamt
                ,MIN(b.custcode) AS custcode
                ,MAX(b.issempnm) AS issempnm
                ,MAX(b.paybank) AS paybank
                ,MAX(b.deptcode) AS deptcode
                ,MAX(b.plantcode) AS plantcode
                ,MAX(b.tasooyn) AS tasooyn
        FROM    ACAUTOORDT a
                JOIN SLCOLM b ON a.acatno = b.colno
                                 AND b.coldiv LIKE '3%'
                WHERE   a.compcode = p_compcode
                        AND a.acattype LIKE p_slipdiv
                        AND a.acattype = 'C'
                        AND a.actrnstate = '1'
                        AND TRIM(a.billno) IS NOT NULL
        GROUP BY a.compcode, a.billno
    );



    MERGE INTO ACBILLM a
    USING (

        select  -- compare data
                a.compcode
                , a.billno
                -- update data
                , b.billamt
        from    ACBILLM a
                join (  select  a.billno
                                , sum(b.colamt) as billamt
                        from    VGT.TT_ACACC0047PL_ACBILLM a
                                join SLCOLM b on a.billno = b.billno
                        group by a.billno
                ) b on a.billno = b.billno

    ) src ON (    -- 비교
            a.compcode = src.compcode
            and a.billno = src.billno
    )
    WHEN MATCHED THEN
        UPDATE SET    -- 업데이트 문장
                a.billamt    = src.billamt
                , a.updatedt = SYSDATE
                , a.uempcode = p_iempcode ;



    insert into ACBILLM (
        compcode
        , billno
        , billcls            --어음구분 AC32
        , billdiv            --어음종류 SL18
        , billtype
        , issdate            --발행일자
        , coldate            --수취일자
        , expdate            --만기일자
        , billamt            --금액
        , custcode
        , issempnm
        , bankcode
        , paybank
        , deptcode
        , plantcode
        , tasooyn
        , issdiv            --발행구분 AC31
        , billstate            --어음상태 AC53
        , accountno
        , billremark
        , insertdt
        , iempcode
    )
    select  a.compcode
            , a.billno
            , '1'
            , a.billdiv
            , ''
            , a.issdate
            , a.coldate
            , a.expdate
            , a.billamt
            , a.custcode
            , a.issempnm
            , ''
            , a.paybank
            , a.deptcode
            , a.plantcode
            , a.tasooyn
            , 'A'
            , '1'
            , ''
            , ''
            , SYSDATE
            , p_iempcode
    from    VGT.TT_ACACC0047PL_ACBILLM a
            LEFT JOIN ACBILLM b on a.billno = b.billno
    where   TRIM(b.billno) IS NULL ;



    -- 해당일자 회계전표유형(신규,수정)을 모두 완료로 변경한다.
    MERGE INTO ACAUTOORDT a
    USING (

        select  -- compare data
                a.compcode
                , a.acattype
                , a.acatno
                -- update data
                , replace(a.slipindate,'-','') || a.acattype || NVL(b.slipinnum, c.slipinnum) as slipinno
        from    ACAUTOORDT a
                left join VGT.TT_ACACC0047PL_ACAUTOORDT1 b on a.compcode = b.compcode
                                                                and a.plantcode = b.plantcode
                                                                and a.acattype = b.acattype
                                                                and a.slipindate = b.slipindate
                                                                and case when LOWER(p_salload) = 'empcode' and a.acattype = 'S' then a.empcode
                                                                         when LOWER(p_salload) = 'iempcode' and a.acattype = 'S' then a.iempcode
                                                                         when LOWER(p_salload) = 'newload' and a.acattype = 'S' then a.iempcode
                                                                         when LOWER(p_salload) = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                                                                         when LOWER(p_colload) = 'empcode' and a.acattype = 'C' then a.empcode
                                                                         when LOWER(p_colload) = 'iempcode' and a.acattype = 'C' then a.iempcode
                                                                         when LOWER(p_colload) = 'newload' and a.acattype = 'C' then a.iempcode
                                                                         when LOWER(p_colload) = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                                                                         when LOWER(p_colload) = 'custcode' and a.acattype = 'C' then a.custcode
                                                                         when LOWER(p_expload) = 'importshtno' and a.acattype = 'N' then a.billno
                                                                         when a.acattype = 'H' then a.plantcode
                                                                         else ''
                                                                    end = b.acatrulecode
                left join VGT.TT_ACACC0047PL_ACAUTOORDT2 c on a.compcode = c.compcode
                                                                and a.acattype = c.acattype
                                                                and a.slipindate = c.slipindate
                                                                and a.acatno = c.acatno

        where   a.compcode = p_compcode
                and a.actrnstate in ('1', '3')
                and a.acattype like p_slipdiv

    ) src ON (    -- 비교
            a.compcode   = src.compcode
            and a.acatno = src.acatno
    )
    WHEN MATCHED THEN
        UPDATE SET    -- 업데이트 문장
                    a.actrnstate = '2'
                    , a.slipinno = src.slipinno ;



    -- 해당일자 회계전표유형(삭제)을 삭제한다.
    delete from ACAUTOORDT a
    where   a.compcode = p_compcode
            and a.actrnstate = '4'
            and a.acattype like p_slipdiv ;



    -- 회계전표 잔액 집계처리
    spACord0000MM(  p_div => 'T',
                    p_compcode => p_compcode, -- 회사코드
                    p_closediv => '10', -- 결산구분(운영)
                    p_strslipym => p_strartym, -- 결의전표번호
                    p_endslipym => p_endym, -- 결의전표번호
                    p_userid => p_userid,
                    p_reasondiv => p_reasondiv,
                    p_reasontext => p_reasontext,
                    MESSAGE => MESSAGE,
                    IO_CURSOR => IO_CURSOR);



    -- 회계전표 예산 집계처리
    spACbudg0000MM(  p_div => 'TO',
                     p_compcode => p_compcode, -- 회사코드
                     p_strbudgym => p_strartym, -- 결의전표번호
                     p_endbudgym => p_endym, -- 결의전표번호
                     p_userid => p_userid,
                     p_reasondiv => p_reasondiv,
                     p_reasontext => p_reasontext,
                     MESSAGE => MESSAGE,
                     IO_CURSOR => IO_CURSOR);

    IF(TRIM(p_strartym) IS NULL) THEN
        p_strartym := '0000-00';
    END IF;

    MESSAGE := p_strartym || '-01' || TO_CHAR(LAST_DAY(TO_DATE(p_endym || '-01', 'YYYY-MM-DD')), 'YYYY-MM-DD') || TO_CHAR(p_proccnt);

   <<LASTLINE>>
    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
