CREATE FUNCTION        ISNUMERIC
(
    str   IN VARCHAR2
) RETURN NUMBER
IS

  v_ret NUMBER := 0;

BEGIN 

    IF str IS NULL OR LENGTH(TRIM(str)) = 0 THEN
        RETURN 0;
    END IF;
    
    v_ret := TO_NUMBER(str);
    
    RETURN 1;

    EXCEPTION WHEN OTHERS THEN RETURN 0;   

END;
/
