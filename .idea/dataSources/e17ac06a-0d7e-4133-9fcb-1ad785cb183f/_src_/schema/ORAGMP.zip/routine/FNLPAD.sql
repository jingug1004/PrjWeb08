CREATE FUNCTION        fnLPAD(
-- =============================================
 -- Author     :	이 동 현
 -- Create date: 2010-05-10
 -- Description:	순번 자릿수 채우는 함수
 -- =============================================
 -- @string    : 순번, 일련번호
 -- @num       : 자릿수
 -- @point     : 빈 공간에 채울 값
 -- 사용 방법  : dbo.fnLPAD(123,4,0)
 -- =============================================


  p_string  IN  VARCHAR2    DEFAULT '',
  p_num     IN  NUMBER      DEFAULT 0,
  p_point   IN  VARCHAR2    DEFAULT ''
)
RETURN VARCHAR2
AS

BEGIN
    RETURN NVL(LPAD(p_point, p_num - LENGTH(p_string), p_point), '') || p_string;
    
    EXCEPTION WHEN OTHERS THEN RETURN NULL; 
END;
/
