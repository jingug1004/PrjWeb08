CREATE PROCEDURE        spACacc0000
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0000
	-- 작 성 자         : 민승기
	-- 작성일자         : 2010-10-06
    -- 수 정 자     : 강현호
    -- E-Mail       : roykang0722@gmail.com
    -- 수정일자      : 2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계전표내역 검색 가능여부 체크하는 프로시저이다.
	-- ---------------------------------------------------------------
(
    p_div			IN	   VARCHAR2 DEFAULT '',
    p_iempcode		IN	   VARCHAR2 DEFAULT '',
    p_userid		IN	   VARCHAR2 DEFAULT '',
    p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
    p_reasontext	IN	   VARCHAR2 DEFAULT '',

    MESSAGE         OUT    VARCHAR2,
    IO_CURSOR       OUT    TYPES.DataSet
)
AS
	p_jurisdictionyn   VARCHAR2(5);
BEGIN

   MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	FOR  rec IN ( SELECT CASE WHEN UPPER(E.empcode) = UPPER('gmpit') OR -- 슈퍼유저
							       E.empcode IN ( '2006030603','2010092701' ) OR -- 유영식, 김원경
							       NVL(TRIM(p1.parametercode), '') IS NOT NULL OR -- 회계슈퍼유저
							       NVL(TRIM(p2.parametercode), '') IS NOT NULL -- 회계슈퍼부서
							       THEN  '%'
						      ELSE D.deptcode
						  END alias1
                 FROM   CMEMPM E
                        JOIN CMDEPTM D	 ON E.deptcode = D.deptcode
                        LEFT JOIN SYSPARAMETERMANAGE p1   ON UPPER(p1.parametercode) = UPPER('slipsuperemp')
                                                             AND ( p1.value1 = E.empcode OR p1.value2 = E.empcode OR p1.value3 = E.empcode )
                        LEFT JOIN SYSPARAMETERMANAGE p2   ON UPPER(p2.parametercode) = UPPER('slipsuperdept')
                                                             AND ( p2.value1 = E.deptcode OR p2.value2 = E.deptcode OR p2.value3 = E.deptcode )
                WHERE  E.empcode = p_iempcode )
    LOOP
        p_jurisdictionyn := rec.alias1;
    END LOOP;

    MESSAGE := p_jurisdictionyn;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
