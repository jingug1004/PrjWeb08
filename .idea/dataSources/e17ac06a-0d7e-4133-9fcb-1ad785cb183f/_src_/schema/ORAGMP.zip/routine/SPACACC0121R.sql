CREATE PROCEDURE        spACacc0121R
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACacc0121R
   -- 작 성 자         : 최용석
   -- 작성일자         : 2011-11-16
   -- 수정자         : 임 정호
   -- 작성일자         : 2016-12-20
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 증빙구분원장을 조회하는 프로시저이다.
   -- ---------------------------------------------------------------
(

    p_div          IN     VARCHAR2 DEFAULT '',
    p_compcode     IN     VARCHAR2 DEFAULT '',
    p_plantcode    IN     VARCHAR2 DEFAULT '',
    p_strdate      IN     VARCHAR2 DEFAULT '',
    p_enddate      IN     VARCHAR2 DEFAULT '',
    p_stracccode   IN     VARCHAR2 DEFAULT '',
    p_endacccode   IN     VARCHAR2 DEFAULT '',
    p_outputdiv    IN     VARCHAR2 DEFAULT '',
    p_eviddiv      IN     VARCHAR2 DEFAULT '',
    p_userid       IN     VARCHAR2 DEFAULT '',
    p_reasondiv    IN     VARCHAR2 DEFAULT '',
    p_reasontext   IN     VARCHAR2 DEFAULT '',
    IO_CURSOR         OUT TYPES.DataSet,
    MESSAGE           OUT VARCHAR2)
AS
   p_slipdiv   VARCHAR2 (5);
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF (p_outputdiv = '1') THEN
      --K-GAAP
      p_slipdiv := 'F';
    ELSIF (p_outputdiv = '2') THEN
      --IFRS
      p_slipdiv := 'K';
    END IF;

    OPEN  IO_CURSOR FOR
    SELECT b.acccode || ' : ' || MAX (D.accname) acccodename,
           CASE WHEN E.grp = 1 THEN a.slipdate ELSE '합계' END slipdate,
           CASE WHEN E.grp = 1 THEN a.slipnum ELSE '' END slipnum,
           CASE WHEN E.grp = 1 THEN b.slipinseq ELSE NULL END slipinseq,
           MAX (CASE WHEN E.grp = 1 THEN b.remark1 ELSE '' END) remark,
           SUM (b.debamt) debamt,
           SUM (b.creamt) creamt,
           MAX (CASE WHEN E.grp = 1 THEN a.eviddiv ELSE NULL END) eviddiv,
           MAX (CASE WHEN E.grp = 1 THEN c.mngcludec1 ELSE NULL END) mngcludec1,
           MAX (CASE WHEN E.grp = 1 THEN c.mngcludec2 ELSE NULL END) mngcludec2,
           MAX (CASE WHEN E.grp = 1 THEN c.mngcludec3 ELSE NULL END) mngcludec3,
           MAX (CASE WHEN E.grp = 1 THEN c.mngcludec4 ELSE NULL END) mngcludec4,
           MAX (CASE WHEN E.grp = 1 THEN c.mngcludec5 ELSE NULL END) mngcludec5,
           MAX (CASE WHEN E.grp = 1 THEN c.mngcludec6 ELSE NULL END) mngcludec6
      FROM ACORDM a
           JOIN ACORDD b
              ON a.compcode = b.compcode AND a.slipinno = b.slipinno
           LEFT JOIN (
                          SELECT slipinno,
                                 slipinseq,
                                 MAX (CASE WHEN seq = 1 THEN mngcludec ELSE NULL END) mngcludec1,
                                 MAX (CASE WHEN seq = 2 THEN mngcludec ELSE NULL END) mngcludec2,
                                 MAX (CASE WHEN seq = 3 THEN mngcludec ELSE NULL END) mngcludec3,
                                 MAX (CASE WHEN seq = 4 THEN mngcludec ELSE NULL END) mngcludec4,
                                 MAX (CASE WHEN seq = 5 THEN mngcludec ELSE NULL END) mngcludec5,
                                 MAX (CASE WHEN seq = 6 THEN mngcludec ELSE NULL END) mngcludec6
                            FROM (SELECT b.slipinno,
                                         b.slipinseq,
                                         ROW_NUMBER () OVER (PARTITION BY b.slipinno, b.slipinseq ORDER BY c.seq) seq,
                                         '[' || NVL (D.mngcluname, '') || ']' || NVL (c.mngcluval, '') || ' : ' || NVL (c.mngcludec, '') || CASE WHEN TRIM(E.custcode) IS NULL THEN '' ELSE ' (' || E.businessno || ')' END mngcludec
                                    FROM ACORDM a
                                         JOIN ACORDD b
                                            ON a.compcode = b.compcode AND a.slipinno = b.slipinno
                                         LEFT JOIN
                                         ACORDS c
                                            ON     b.compcode = c.compcode
                                               AND b.slipinno = c.slipinno
                                               AND b.slipinseq = c.slipinseq
                                         LEFT JOIN ACMNGM D ON c.mngclucode = D.mngclucode
                                         LEFT JOIN CMCUSTM E
                                            ON c.mngclucode = 'S010' AND c.mngcluval = E.custcode
                                   WHERE     a.compcode = p_compcode
                                         AND a.slipdate BETWEEN p_strdate AND p_enddate
                                         AND a.plantcode LIKE p_plantcode
                                         AND a.slipdiv <> p_slipdiv
                                         AND a.eviddiv LIKE p_eviddiv
                                         AND b.acccode BETWEEN NVL(p_stracccode, ' ') AND NVL(p_endacccode, ' ')) a
                        GROUP BY slipinno, slipinseq
                      ) /*VGT.TT_ACACC0000PM_ACORDS_4*/ c
              ON b.slipinno = c.slipinno AND b.slipinseq = c.slipinseq
           LEFT JOIN ACACCM D ON b.acccode = D.acccode
           JOIN (SELECT 1 grp FROM DUAL
                 UNION
                 SELECT 2 FROM DUAL) E
              ON 1 = 1
     WHERE     a.compcode = p_compcode
           AND a.slipdate BETWEEN p_strdate AND p_enddate
           AND a.plantcode LIKE p_plantcode
           AND a.slipdiv <> p_slipdiv
           AND a.eviddiv LIKE p_eviddiv
           AND b.acccode BETWEEN NVL(p_stracccode, ' ') AND NVL(p_endacccode,' ')
    GROUP BY b.acccode,
           CASE WHEN E.grp = 1 THEN a.slipdate ELSE '합계' END,
           CASE WHEN E.grp = 1 THEN a.slipnum ELSE '' END,
           CASE WHEN E.grp = 1 THEN b.slipinseq ELSE NULL END
    ORDER BY b.acccode, slipdate, slipnum, slipinseq;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
