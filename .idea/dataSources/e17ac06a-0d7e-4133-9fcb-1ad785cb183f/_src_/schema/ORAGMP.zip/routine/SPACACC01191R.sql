CREATE PROCEDURE        spACacc01191R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc01191R
 -- 작 성 자         : 배종성
 -- 작성일자         : 2010-12-08
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-20
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 관리항목원장을 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_plantcode     IN  VARCHAR2 DEFAULT '' ,
    p_acccode       IN  VARCHAR2 DEFAULT '' ,
    p_dcdiv         IN  VARCHAR2 DEFAULT '' ,
    p_startdt       IN  VARCHAR2 DEFAULT '' ,
    p_enddt         IN  VARCHAR2 DEFAULT '' ,
    p_mngclucode    IN  VARCHAR2 DEFAULT '' ,
    p_mngcluval1    IN  VARCHAR2 DEFAULT '' ,
    p_outputdiv     IN  VARCHAR2 DEFAULT '' ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
   p_mngcluval VARCHAR2(50);
   p_mngcludec VARCHAR2(50);
   p_slipdate VARCHAR2(13);
   p_slipnum VARCHAR2(5);
   p_remark VARCHAR2(100);
   p_debamt FLOAT(53);
   p_creamt FLOAT(53);
   p_fnamt FLOAT(53);
   p_rows NUMBER(10,0);
   p_odiv1 VARCHAR2(5);
   p_odiv2 VARCHAR2(5);

BEGIN

    MESSAGE := '데이터 확인' ;


    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( p_outputdiv = '1' ) THEN
        --K-GAAP
        p_odiv1 := '20' ;
        p_odiv2 := 'F' ;
    ELSIF ( p_outputdiv = '2' ) THEN
        --IFRS
        p_odiv1 := '30' ;
        p_odiv2 := 'K' ;
    END IF;


    IF ( p_div = 'S' ) THEN

        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC01191R_R1 ';

        INSERT INTO VGT.TT_ACACC01191R_R1 (
            SELECT  a.compcode ,
                    a.slipinno ,
                    a.slipinseq ,
                    a.slipindate ,
                    a.slipinnum ,
                    a.slipno ,
                    a.slipdate ,
                    a.slipnum ,
                    a.acccode ,
                    a.remark ,
                    NVL(a.mngcluval, '') mngcluval  ,
                    a.mngcludec ,
                    a.debamt ,
                    a.creamt
            FROM (  SELECT  a.compcode ,-- 이월 기초 데이타 가지고 오기
                            a.plantcode ,
                            '' slipinno  ,
                            NULL slipinseq  ,
                            '' slipindate  ,
                            '' slipinnum  ,
                            '' slipno  ,
                            SUBSTR(p_startdt, 0, 7) || '-00' slipdate  ,
                            '' slipnum  ,
                            a.acccode ,
                            '' remark  ,
                            mngcluval mngcluval  ,
                            '' mngcludec  ,
                            NVL(a.bsdebamt, 0) debamt  ,
                            NVL(a.bscreamt, 0) creamt
                    FROM    ACORDSMM a
                            JOIN (  SELECT DISTINCT curstrym
                                    FROM (  SELECT  a.cym curstrym
                                            FROM    (
                                                        SELECT  a.cyear ,
                                                                a.curstrdate ,
                                                                a.curenddate ,
                                                                TO_CHAR(a.curstrdate,'YYYY-DD') curstrym  ,
                                                                b.MM ,
                                                                TO_CHAR(ADD_MONTHS(TO_DATE(a.curstrdate, 'YYYY-MM-DD'), b.MM - 1), 'YYYY-MM') cym  ,
                                                                TO_CHAR(ADD_MONTHS(TO_DATE(a.curstrdate, 'YYYY-MM-DD'), b.MM), 'YYYY-MM-DD') nxtstrdate

                                                        FROM    ACSESSION a
                                                        JOIN (  SELECT 1 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 2 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 3 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 4 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 5 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 6 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 7 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 8 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 9 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 10 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 11 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 12 MM FROM DUAL  ) b   ON 1 = 1
                                                        WHERE   a.compcode = p_compcode
                                                                AND a.curenddate >= p_startdt
                                                                AND a.curstrdate <= p_enddt
                                                        ORDER BY a.cyear, b.MM
                                                    ) a

                                            WHERE   a.cym = SUBSTR(p_startdt, 0, 7) -- 해당 년월
                                            UNION
                                            SELECT  a.curstrym
                                            FROM    (
                                                        SELECT  a.cyear ,
                                                                a.curstrdate ,
                                                                a.curenddate ,
                                                                TO_CHAR(a.curstrdate,'YYYY-DD') curstrym  ,
                                                                b.MM ,
                                                                TO_CHAR(ADD_MONTHS(TO_DATE(a.curstrdate, 'YYYY-MM-DD'), b.MM - 1), 'YYYY-MM') cym  ,
                                                                TO_CHAR(ADD_MONTHS(TO_DATE(a.curstrdate, 'YYYY-MM-DD'), b.MM), 'YYYY-MM-DD') nxtstrdate

                                                        FROM    ACSESSION a
                                                        JOIN (  SELECT 1 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 2 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 3 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 4 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 5 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 6 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 7 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 8 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 9 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 10 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 11 MM FROM DUAL
                                                                UNION ALL
                                                                SELECT 12 MM FROM DUAL  ) b   ON 1 = 1
                                                        WHERE   a.compcode = p_compcode
                                                                AND a.curenddate >= p_startdt
                                                                AND a.curstrdate <= p_enddt
                                                        ORDER BY a.cyear, b.MM
                                                    ) a
                                            WHERE   curstrym > SUBSTR(p_startdt, 0, 7) --해당 년월보다 큰것들만
                                         ) a
                                 ) b ON a.slipym = b.curstrym
                    WHERE   a.compcode = p_compcode
                            AND a.plantcode LIKE p_plantcode || '%'
                            AND a.slipym = SUBSTR(p_startdt, 0, 7) -- 나중에 추가
                            AND ( a.mngcluval = p_mngcluval1 OR NVL(p_mngcluval1, '') IS NULL )
                            AND a.mngclucode = p_mngclucode
                            AND ( closediv = '10' OR closediv = p_odiv1 ) -- 운영집계 / 출력구분 [K-GAAP, IFRS]
                            AND a.acccode LIKE p_acccode || '%'

                    UNION ALL

                    SELECT  a.compcode ,
                            a.plantcode ,
                            a.slipinno ,
                            a.slipinseq ,
                            M.slipindate ,
                            M.slipinnum ,
                            M.slipno ,
                            CASE WHEN a.slipdate < p_startdt THEN SUBSTR(p_startdt, 0, 7) || '-00'
                                 ELSE a.slipdate
                            END slipdate  ,
                            M.slipnum slipnum  ,
                            a.acccode ,
                            a.remark1 remark  ,
                            NVL(b.mngcluval, '') mngcluval  ,
                            NVL(b.mngcludec, '') mngcludec  ,
                            NVL(a.debamt, 0) debamt  ,
                            NVL(a.creamt, 0) creamt
                    FROM    ACORDD a
                            LEFT JOIN ACORDS b   ON a.compcode = b.compcode
                                                    AND a.slipinno = b.slipinno
                                                    AND a.slipinseq = b.slipinseq

                            JOIN ACORDM M   ON a.compcode = M.compcode
                                               AND a.slipinno = M.slipinno
                    WHERE   a.compcode = p_compcode
                            AND a.plantcode LIKE p_plantcode || '%'
                            AND ( b.mngcluval = p_mngcluval1 OR NVL(p_mngcluval1, '') IS NULL )
                            AND b.mngclucode = p_mngclucode
                            AND a.slipdate BETWEEN SUBSTR(p_startdt, 0, 7) || '-01' AND p_enddt
                            AND M.slipinstate = '4'
                            AND a.acccode LIKE p_acccode || '%'
                            AND M.slipdiv <> p_odiv2 -- K-GAAP <> 'F', IFRS <> 'K'
                    ) a
        ); --INSERT END



        -- 기수별 기초
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC01191R_RBASE ';

        INSERT INTO VGT.TT_ACACC01191R_RBASE (
            SELECT  a.compcode ,
                    '' slipinno  ,
                    NULL slipinseq  ,
                    '' slipindate  ,
                    '' slipinnum  ,
                    '' slipno  ,
                    a.slipdate ,
                    '' slipnum  ,
                    a.acccode ,
                    '' remark  ,
                    '' mngcluval  ,
                    '' mngcludec  ,
                    SUM(a.debamt)  debamt  ,
                    SUM(a.creamt)  creamt
            FROM    VGT.TT_ACACC01191R_R1 a
            WHERE   SUBSTR(a.slipdate, -2, 2) = '00'
                    AND ( a.mngcluval = p_mngcluval1 OR NVL(p_mngcluval1, '') IS NULL )
            GROUP BY a.compcode,a.slipdate,a.acccode );


        -- 소계
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC01191R_RMSUM ';

        INSERT INTO VGT.TT_ACACC01191R_RMSUM (
            SELECT  a.compcode ,
                    '' slipinno  ,
                    '' slipinseq  ,
                    '' slipindate  ,
                    '' slipinnum  ,
                    '' slipno  ,
                    '9999-00-88' slipdate  ,
                    '' slipnum  ,
                    a.acccode ,
                    '' remark  ,
                    '' mngcluval  ,
                    '' mngcludec  ,
                    SUM(a.debamt)  debamt  ,
                    SUM(a.creamt)  creamt
            FROM    VGT.TT_ACACC01191R_R1 a
            WHERE   ( SUBSTR(a.slipdate, -2, 2) != '00' )
                    AND ( a.mngcluval = p_mngcluval1 OR NVL(p_mngcluval1, '') IS NULL )
            GROUP BY a.compcode,a.acccode );


        -- 누계
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC01191R_RSUM ';

        INSERT INTO VGT.TT_ACACC01191R_RSUM (
            SELECT  a.compcode ,
                    '' slipinno  ,
                    '' slipinseq  ,
                    '' slipindate  ,
                    '' slipinnum  ,
                    '' slipno  ,
                    '9999-99-99' slipdate  ,
                    '' slipnum  ,
                    a.acccode ,
                    '' remark  ,
                    '' mngcluval  ,
                    '' mngcludec  ,
                    SUM(a.debamt)  debamt  ,
                    SUM(a.creamt)  creamt
            FROM (  SELECT  *
                    FROM    VGT.TT_ACACC01191R_RBASE
                    UNION ALL
                    SELECT  *
                    FROM    VGT.TT_ACACC01191R_RMSUM  ) a
            GROUP BY a.compcode ,a.acccode );


        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC01191R_DUAL ';

        INSERT INTO VGT.TT_ACACC01191R_DUAL

            SELECT  ROW_NUMBER() OVER ( ORDER BY a.compcode, a.acccode, a.slipno, slipinseq  ) idseq  ,
                    a.compcode compcode  ,
                    a.slipinno slipinno  ,
                    a.slipinseq slipinseq  ,
                    a.slipindate slipindate  ,
                    a.slipinnum slipinnum  ,
                    a.slipno slipno  ,
                    a.slipdate slipdate  ,
                    a.slipnum slipnum  ,
                    a.acccode acccode  ,
                    a.remark remark  ,
                    a.mngcluval mngcluval  ,
                    a.mngcludec mngcludec  ,
                    a.debamt debamt  ,
                    a.creamt creamt  ,
                    SUBSTR(slipdate, 0, 7) slipyymm
            FROM (  -- 이월
                    SELECT  *
                    FROM    VGT.TT_ACACC01191R_RBASE

                    UNION ALL

                    -- 소계
                    SELECT  *
                    FROM    VGT.TT_ACACC01191R_RMSUM

                    UNION ALL

                    -- 누계
                    SELECT  *
                    FROM    VGT.TT_ACACC01191R_RSUM

                    UNION ALL

                    --건별
                    SELECT  *
                    FROM    VGT.TT_ACACC01191R_R1 a
                    WHERE   ( SUBSTR(a.slipdate, -2, 2) != '00' )
                            AND ( a.mngcluval = p_mngcluval1 OR NVL(p_mngcluval1, '') IS NULL )
                 ) a
            ORDER BY a.compcode, a.acccode, a.slipno, slipinseq ;



        -- 검색한 자료 셀렉트
        OPEN  IO_CURSOR FOR

            SELECT  CASE WHEN SUBSTR(a.slipdate, -2, 2) = '00' THEN '0'
                         WHEN SUBSTR(a.slipdate, -2, 2) = '88' THEN '2'
                         WHEN SUBSTR(a.slipdate, -2, 2) = '99' THEN '3'
                         ELSE '1'
                    END seq  ,
                    a.compcode ,
                    a.slipinno ,
                    a.slipinseq ,
                    a.slipindate ,
                    a.slipinnum ,
                    a.slipno ,
                    CASE WHEN SUBSTR(a.slipdate, -2, 2) = '00' THEN '이월'
                         WHEN SUBSTR(a.slipdate, -2, 2) = '88' THEN '소계'
                         WHEN SUBSTR(a.slipdate, -2, 2) = '99' THEN '누계'
                         ELSE a.slipdate
                    END slipdate  ,
                    CASE WHEN SUBSTR(a.slipdate, -2, 2) IN ( '00','88','99' ) THEN ' '
                         ELSE a.slipnum
                    END slipnum  ,
                    a.acccode ,
                    b.accname ,
                    a.acccode || '-' || accname acccodenm  ,
                    a.remark ,
                    a.mngcluval ,
                    a.mngcludec ,
                    a.debamt ,
                    a.creamt ,
                    CASE WHEN SUBSTR(a.slipdate, -2, 2) IN ( '88' ) THEN NULL
                         WHEN SUBSTR(a.slipdate, -2, 2) IN ( '00','99' ) THEN CASE WHEN b.dcdiv = '1' THEN a.debamt - a.creamt
                                                                                   ELSE a.creamt - a.debamt
                                                                              END
                         ELSE CASE WHEN b.dcdiv = '1' THEN (    SELECT  SUM(N.debamt - N.creamt)
                                                                FROM    VGT.TT_ACACC01191R_DUAL N
                                                                WHERE   N.compcode = a.compcode
                                                                        AND N.acccode = a.acccode
                                                                        AND N.idseq <= a.idseq
                                                                        AND SUBSTR(N.slipdate, -2, 2) NOT IN ( '88','99' )
                                                           )
                                   ELSE (   SELECT  SUM(N.creamt - N.debamt)
                                            FROM    VGT.TT_ACACC01191R_DUAL N
                                            WHERE   N.compcode = a.compcode
                                                    AND N.acccode = a.acccode
                                                    AND N.idseq <= a.idseq
                                                    AND SUBSTR(N.slipdate, -2, 2) NOT IN ( '88','99' )
                                        )
                              END
                    END fnamt  ,
                    a.acccode || ' : ' || b.accname acccodename
            FROM    VGT.TT_ACACC01191R_DUAL a
                    LEFT JOIN ACACCM b   ON a.acccode = b.acccode
            WHERE  NOT ( a.debamt = '0' AND a.creamt = '0' )
            ORDER BY compcode, acccode, slipyymm, seq, slipno, slipinseq ;


    ELSIF ( p_div = 'A1' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  b.mngclucode keyfield  ,
                    MAX(b.mngcluname)  displayfield
            FROM    ACACCM a
                    LEFT JOIN ACACCMNGM b   ON a.acccode = b.acccode
            WHERE   a.acccode = p_acccode
            GROUP BY b.mngclucode
            ORDER BY b.mngclucode ;

    ELSIF ( p_div = 'A2' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  a.mngclucode mngclucode  ,
                    a.mngcluname mngcluname  ,
                    a.mngcludiv mngcludiv  ,
                    b.divname mngcludivnm  ,
                    c.filter1 codeseek  ,
                    NVL(a.remark, '') codermk
            FROM    ACMNGM a
                    LEFT JOIN CMCOMMONM b   ON b.cmmcode = 'AC12'
                                                AND a.mngcludiv = b.divcode
                    LEFT JOIN CMCOMMONM c   ON c.cmmcode = 'CMHL'
                                                AND a.codehelp = c.divcode
            WHERE  a.mngclucode = p_mngclucode ;

    ELSIF ( p_div = 'RMK' ) THEN

        -- 코드헬프 검색
        OPEN  IO_CURSOR FOR

            SELECT  NVL(codehelp, '') codehelp ,-- 코드헬프번호
                    NVL(remark, '') codermk -- 코드헬프비고
            FROM    ACMNGM
            WHERE   mngclucode = p_mngclucode OR p_mngclucode LIKE 'S200%'
                    AND mngclucode = SUBSTR(p_mngclucode, 5, 10)
                    AND codehelp = SUBSTR(p_mngclucode, 0, 4) ;

   END IF;



    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
