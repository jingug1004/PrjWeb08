CREATE PROCEDURE        spACacc0920P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0920P
 -- 작 성 자         : 최용석
 -- 작성일자         : 2012-10-24
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 출장비전표를 생성하는 프로시저이다.
 -- ---------------------------------------------------------------

(
    p_div IN VARCHAR2 DEFAULT '' ,
    p_compcode IN VARCHAR2 DEFAULT '' ,
    p_salesym IN VARCHAR2 DEFAULT '' ,
    p_deptarea IN VARCHAR2 DEFAULT '' ,
    p_applycnt IN NUMBER DEFAULT 0 ,
    p_slipinno IN VARCHAR2 DEFAULT '' ,
    p_slipinseq IN NUMBER DEFAULT 0 ,
    p_plantcode IN VARCHAR2 DEFAULT '' ,
    p_slipamt IN FLOAT DEFAULT 0 ,
    p_remark IN VARCHAR2 DEFAULT '' ,
    p_slipindate IN VARCHAR2 DEFAULT '' ,
    p_empcode IN VARCHAR2 DEFAULT '' ,
    p_accountno IN VARCHAR2 DEFAULT '' ,
    p_iempcode IN VARCHAR2 DEFAULT '' ,
    p_userid IN VARCHAR2 DEFAULT '' ,
    p_reasondiv IN VARCHAR2 DEFAULT '' ,
    p_reasontext IN VARCHAR2 DEFAULT '' ,
    IO_CURSOR         OUT TYPES.DataSet,
    MESSAGE           OUT VARCHAR2
)
AS
    p_basisym VARCHAR2(7);
    p_addper FLOAT(53);
    p_minusper FLOAT(53);
    p_defaultamt FLOAT(53);
    p_acccode1 VARCHAR2(20);

    p_cashcode VARCHAR2(20);
    p_acntcode VARCHAR2(20);
    p_acccode2 VARCHAR2(20);


BEGIN

    MESSAGE := '데이터 확인' ;
    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( p_div = 'S' ) THEN
        FOR  rec IN
        (
            SELECT  MAX(budgym)   AS alias1
            FROM    ACBUDGYYES
            WHERE   compcode = p_compcode
                AND budgym <= p_salesym
                AND targetdiv = '20'
        )
        LOOP
            p_basisym := rec.alias1   ;
        END LOOP;

        FOR  rec IN
        (
            SELECT  applyper
            FROM    ACBUDGYYES
            WHERE   compcode = p_compcode
                AND budgym = p_basisym
                AND targetdiv = '20'
                AND targetper = 80
        )
        LOOP
            p_defaultamt := rec.applyper   ;
        END LOOP;

/* 임시 테이블 내용

DELETE FROM tt_SLTARGETSALEM;


INSERT INTO tt_SLTARGETSALEM
SELECT  empcode ,
        MAX(deptcode)  deptcode  ,
        SUM(targetamt)  targetamt
FROM    SLTARGETSALEM
WHERE   yearmonth = p_salesym
    AND saldiv = 'C'
GROUP BY empcode
HAVING SUM(targetamt)  > 0 ;


DELETE FROM tt_SLCOLM;
INSERT INTO tt_SLCOLM
(
    SELECT  empcode ,
            MAX(deptcode)  deptcode  ,
            SUM(colamt)  colamt
    FROM    SLCOLM
    WHERE   saldiv = 'C01'
        AND statediv = '09'
        AND coldiv < '50'
        AND appdate LIKE nvl(p_salesym,' ') || '%'
    GROUP BY empcode
);

-- 전월 목표/매출실적 집계

DELETE FROM tt_SLTARGETSALEM2;

INSERT INTO tt_SLTARGETSALEM2 (
  SELECT  empcode ,
        SUM(targetamt)  targetamt
    FROM  SLTARGETSALEM
   WHERE  yearmonth = p_salesym
    AND saldiv = 'A'
    GROUP BY empcode
     HAVING SUM(targetamt)  > 0 );

DELETE FROM tt_SLORDM_2;

INSERT INTO tt_SLORDM_2

SELECT  empcode ,
            SUM(CASE
                   WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN salamt
                    ELSE salamt * -1
                END)  salamt
FROM    SLORDM a
        JOIN SLORDD b
            ON      a.orderno = b.orderno
                AND a.plantcode = b.plantcode
WHERE   a.appdate LIKE p_salesym || '%'
    AND a.statediv = '09'
    AND a.saldiv NOT IN ( 'B51' )
    GROUP BY empcode


DELETE FROM tt_ACBUDGYYES2;


INSERT INTO tt_ACBUDGYYES2
SELECT  empcode ,
        SUM(saltarget)  saltarget  ,
        SUM(salamt)     salamt  ,
        SUM(coltarget)  coltarget  ,
        SUM(colamt)     colamt  ,
        SUM(salper)     salper  ,
        SUM(colper)     colper  ,
        (SUM(salper)  + SUM(colper) ) / 2 applyper
  FROM ( SELECT a.empcode ,
                a.targetamt saltarget  ,
                NVL(b.salamt, 0) salamt  ,
                ROUND(NVL(b.salamt, 0) / a.targetamt * 100, 1) salper  ,
                0 coltarget  ,
                0 colamt  ,
                0 colper
        FROM    tt_SLTARGETSALEM2 a
                LEFT JOIN tt_SLORDM_2 b
                    ON  a.empcode = b.empcode
        UNION ALL
        SELECT a.empcode ,
               0 ,
               0 ,
               0 ,
               a.targetamt coltarget  ,
               NVL(b.colamt, 0) colamt  ,
               ROUND(NVL(b.colamt, 0) / a.targetamt * 100, 1) colper
        FROM   tt_SLTARGETSALEM a
                LEFT JOIN tt_SLCOLM b
                    ON a.empcode = b.empcode ) a
  GROUP BY empcode

DELETE FROM tt_ACBUDGYYES3;


INSERT INTO tt_ACBUDGYYES3
SELECT 'N' selcheck  ,
        a.empcode ,
        c.empname ,
        D.deptcode ,
        D.deptname ,
        a.saltarget ,
        a.salamt ,
        a.coltarget ,
        a.colamt ,
        CASE
            WHEN a.salamt >= b.addper AND a.colamt >= b.mtargetper THEN b.applyper
            ELSE b.minusper
        END basisamt  ,
        CASE
            WHEN DECODE(p_salesym,NULL,'N', TO_CHAR(ADD_MONTHS ( TO_DATE(p_salesym || '-01','YYYY-MM-DD'),-3),'YYYY-MM-DD')) <=  c.enterdt THEN 'Y'
            ELSE 'N'
        END newman
  FROM  tt_ACBUDGYYES2 a
        JOIN ( SELECT a.empcode ,
                      b.*
               FROM (   SELECT  a.empcode ,
                                MAX(b.targetper)  targetper
                        FROM    tt_ACBUDGYYES2 a
                                JOIN ACBUDGYYES b
                                    ON      b.compcode = p_compcode
                                        AND b.budgym = p_basisym
                                        AND b.targetdiv = '20'
                                        AND a.applyper >= b.targetper
                                        AND ( b.targetper < 100 OR 100 <= a.salper AND 100 <= a.colper )
                        GROUP BY a.empcode ) a
                        JOIN    ACBUDGYYES b
                            ON      b.compcode = p_compcode
                                AND b.budgym = p_basisym
                                AND b.targetdiv = '20'
                                AND a.targetper = b.targetper ) b
            ON a.empcode = b.empcode
        LEFT JOIN CMEMPM c   ON a.empcode = c.empcode
        LEFT JOIN CMDEPTM D   ON c.deptcode = D.deptcode
 WHERE  ( p_deptarea = '%'
            OR p_deptarea = '01' AND ( a.empcode = '204006' OR D.deptareadiv = p_deptarea )
            OR p_deptarea = '03' AND a.empcode <> '204006' AND D.deptareadiv = p_deptarea
        )
    AND ( D.deptcode < 'M1040' OR a.empcode = '211005' ) ;



*/
        OPEN  IO_CURSOR FOR
        SELECT a.*
        FROM (
                    SELECT  'N' selcheck  ,
                             empcode ,
                             empname ,
                             deptcode ,
                             deptname ,
                             saltarget ,
                             salamt ,
                             ROUND(  CASE
                                        WHEN saltarget > 0 THEN salamt / saltarget * 100
                                        ELSE 0
                                    END, 1) salper  ,
                             coltarget ,
                             colamt ,
                             ROUND( CASE
                                        WHEN coltarget > 0 THEN colamt / coltarget * 100
                                        ELSE 0
                                    END, 1) colper  ,
                             CASE
                                  WHEN empcode = '211005' THEN 30000
                                  WHEN newman = 'Y' AND basisamt < p_defaultamt THEN p_defaultamt
                                  ELSE basisamt
                             END basisamt  ,
                             CASE
                                  WHEN empcode = '211005' THEN 30000
                                  WHEN newman = 'Y' AND basisamt < p_defaultamt THEN p_defaultamt
                                  ELSE basisamt
                             END * p_applycnt slipamt
                    FROM
                            (
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                                SELECT 'N' selcheck  ,
                                        a.empcode ,
                                        c.empname ,
                                        D.deptcode ,
                                        D.deptname ,
                                        a.saltarget ,
                                        a.salamt ,
                                        a.coltarget ,
                                        a.colamt ,
                                        CASE
                                            WHEN a.salamt >= b.addper AND a.colamt >= b.mtargetper THEN b.applyper
                                            ELSE b.minusper
                                        END basisamt  ,
                                        CASE
                                            WHEN DECODE(p_salesym,NULL,'N', TO_CHAR(ADD_MONTHS ( TO_DATE(p_salesym || '-01','YYYY-MM-DD'),-3),'YYYY-MM-DD')) <=  c.enterdt THEN 'Y'
                                            ELSE 'N'
                                        END newman
                                  FROM  (
                                        ----------------------
                                             SELECT  empcode ,
                                                    SUM(saltarget)  saltarget  ,
                                                    SUM(salamt)     salamt  ,
                                                    SUM(coltarget)  coltarget  ,
                                                    SUM(colamt)     colamt  ,
                                                    SUM(salper)     salper  ,
                                                    SUM(colper)     colper  ,
                                                    (SUM(salper)  + SUM(colper) ) / 2 applyper
                                              FROM ( SELECT a.empcode ,
                                                            a.targetamt saltarget  ,
                                                            NVL(b.salamt, 0) salamt  ,
                                                            ROUND(NVL(b.salamt, 0) / a.targetamt * 100, 1) salper  ,
                                                            0 coltarget  ,
                                                            0 colamt  ,
                                                            0 colper
                                                    FROM    (
                                                            ------------
                                                                SELECT  empcode ,
                                                                        SUM(targetamt)  targetamt
                                                                FROM    SLTARGETSALEM
                                                                WHERE   yearmonth = p_salesym
                                                                    AND saldiv = 'A'
                                                                GROUP BY empcode
                                                                HAVING SUM(targetamt)  > 0
                                                            ------------
                                                            ) /*tt_SLTARGETSALEM2*/ a
                                                            LEFT JOIN (
                                                                        SELECT  empcode ,
                                                                                SUM(CASE
                                                                                        WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN salamt
                                                                                        ELSE salamt * -1
                                                                                    END)  salamt
                                                                        FROM    SLORDM a
                                                                                JOIN SLORDD b
                                                                                    ON      a.orderno = b.orderno
                                                                                        AND a.plantcode = b.plantcode
                                                                        WHERE   a.appdate LIKE p_salesym || '%'
                                                                            AND a.statediv = '09'
                                                                            AND a.saldiv NOT IN ( 'B51' )
                                                                        GROUP BY empcode
                                                                      ) /*tt_SLORDM_2*/ b
                                                                ON  a.empcode = b.empcode
                                                    UNION ALL
                                                    SELECT a.empcode ,
                                                           0 ,
                                                           0 ,
                                                           0 ,
                                                           a.targetamt coltarget  ,
                                                           NVL(b.colamt, 0) colamt  ,
                                                           ROUND(NVL(b.colamt, 0) / a.targetamt * 100, 1) colper
                                                    FROM   (
                                                            -----------------------------
                                                                SELECT  empcode ,
                                                                        MAX(deptcode)  deptcode  ,
                                                                        SUM(targetamt)  targetamt
                                                                FROM    SLTARGETSALEM
                                                                WHERE   yearmonth = p_salesym
                                                                    AND saldiv = 'C'
                                                                GROUP BY empcode
                                                                HAVING SUM(targetamt)  > 0
                                                            -----------------------------
                                                            ) /*tt_SLTARGETSALEM*/ a
                                                            LEFT JOIN
                                                                        (
                                                            ----------------------------
                                                                            SELECT  empcode ,
                                                                                    MAX(deptcode)  deptcode  ,
                                                                                    SUM(colamt)  colamt
                                                                            FROM    SLCOLM
                                                                            WHERE   saldiv = 'C01'
                                                                                AND statediv = '09'
                                                                                AND coldiv < '50'
                                                                                AND appdate LIKE nvl(p_salesym,' ') || '%'
                                                                            GROUP BY empcode
                                                            ----------------------------
                                                                        ) /*tt_SLCOLM*/ b

                                                                ON a.empcode = b.empcode ) a
                                              GROUP BY empcode
                                        ----------------------
                                        ) /*tt_ACBUDGYYES2*/ a
                                        JOIN ( SELECT a.empcode ,
                                                      b.*
                                               FROM (   SELECT  a.empcode ,
                                                                MAX(b.targetper)  targetper
                                                        FROM    (
                        -----------------------------------------------------------------------
                                                                    SELECT  empcode ,
                                                                            SUM(saltarget)  saltarget  ,
                                                                            SUM(salamt)     salamt  ,
                                                                            SUM(coltarget)  coltarget  ,
                                                                            SUM(colamt)     colamt  ,
                                                                            SUM(salper)     salper  ,
                                                                            SUM(colper)     colper  ,
                                                                            (SUM(salper)  + SUM(colper) ) / 2 applyper
                                                                      FROM ( SELECT a.empcode ,
                                                                                    a.targetamt saltarget  ,
                                                                                    NVL(b.salamt, 0) salamt  ,
                                                                                    ROUND(NVL(b.salamt, 0) / a.targetamt * 100, 1) salper  ,
                                                                                    0 coltarget  ,
                                                                                    0 colamt  ,
                                                                                    0 colper
                                                                            FROM    (
                                                                                        SELECT  empcode ,
                                                                                                MAX(deptcode)  deptcode  ,
                                                                                                SUM(targetamt)  targetamt
                                                                                        FROM    SLTARGETSALEM
                                                                                        WHERE   yearmonth = p_salesym
                                                                                            AND saldiv = 'C'
                                                                                        GROUP BY empcode
                                                                                        HAVING SUM(targetamt)  > 0
                                                                                    ) /*tt_SLTARGETSALEM2*/ a
                                                                                    LEFT JOIN (
                                                                                                SELECT  empcode ,
                                                                                                        SUM(CASE
                                                                                                               WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN salamt
                                                                                                                ELSE salamt * -1
                                                                                                            END)  salamt
                                                                                            FROM    SLORDM a
                                                                                                    JOIN SLORDD b
                                                                                                        ON      a.orderno = b.orderno
                                                                                                            AND a.plantcode = b.plantcode
                                                                                            WHERE   a.appdate LIKE p_salesym || '%'
                                                                                                AND a.statediv = '09'
                                                                                                AND a.saldiv NOT IN ( 'B51' )
                                                                                                GROUP BY empcode
                                                                                              ) /*tt_SLORDM_2*/ b
                                                                                        ON  a.empcode = b.empcode
                                                                            UNION ALL
                                                                            SELECT a.empcode ,
                                                                                   0 ,
                                                                                   0 ,
                                                                                   0 ,
                                                                                   a.targetamt coltarget  ,
                                                                                   NVL(b.colamt, 0) colamt  ,
                                                                                   ROUND(NVL(b.colamt, 0) / a.targetamt * 100, 1) colper
                                                                            FROM   (
                                                                                    -----------------------------
                                                                                        SELECT  empcode ,
                                                                                                MAX(deptcode)  deptcode  ,
                                                                                                SUM(targetamt)  targetamt
                                                                                        FROM    SLTARGETSALEM
                                                                                        WHERE   yearmonth = p_salesym
                                                                                            AND saldiv = 'C'
                                                                                        GROUP BY empcode
                                                                                        HAVING SUM(targetamt)  > 0
                                                                                    -----------------------------
                                                                                    ) /*tt_SLTARGETSALEM*/ a
                                                                                    LEFT JOIN
                                                                                                (
                                                                                    ----------------------------
                                                                                                    SELECT  empcode ,
                                                                                                            MAX(deptcode)  deptcode  ,
                                                                                                            SUM(colamt)  colamt
                                                                                                    FROM    SLCOLM
                                                                                                    WHERE   saldiv = 'C01'
                                                                                                        AND statediv = '09'
                                                                                                        AND coldiv < '50'
                                                                                                        AND appdate LIKE nvl(p_salesym,' ') || '%'
                                                                                                    GROUP BY empcode
                                                                                    ----------------------------
                                                                                                ) /*tt_SLCOLM*/ b

                                                                                        ON a.empcode = b.empcode ) a
                                                                      GROUP BY empcode
                        -----------------------------------------------------------------------
                                                                ) /*tt_ACBUDGYYES2*/ a
                                                                JOIN ACBUDGYYES b
                                                                    ON      b.compcode = p_compcode
                                                                        AND b.budgym = p_basisym
                                                                        AND b.targetdiv = '20'
                                                                        AND a.applyper >= b.targetper
                                                                        AND ( b.targetper < 100 OR 100 <= a.salper AND 100 <= a.colper )
                                                        GROUP BY a.empcode ) a
                                                        JOIN    ACBUDGYYES b
                                                            ON      b.compcode = p_compcode
                                                                AND b.budgym = p_basisym
                                                                AND b.targetdiv = '20'
                                                                AND a.targetper = b.targetper ) b
                                            ON a.empcode = b.empcode
                                        LEFT JOIN CMEMPM c   ON a.empcode = c.empcode
                                        LEFT JOIN CMDEPTM D   ON c.deptcode = D.deptcode
                                 WHERE  ( p_deptarea = '%'
                                            OR p_deptarea = '01' AND ( a.empcode = '204006' OR D.deptareadiv = p_deptarea )
                                            OR p_deptarea = '03' AND a.empcode <> '204006' AND D.deptareadiv = p_deptarea
                                        )
                                    AND ( D.deptcode < 'M1040' OR a.empcode = '211005' )
--@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
                            ) /*tt_ACBUDGYYES3*/
                    UNION
                    SELECT 'N' selcheck  ,
                            a.empcode ,
                            a.empname ,
                            a.deptcode ,
                            c.deptname ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            p_defaultamt basisamt  ,
                            p_defaultamt * p_applycnt slipamt
                    FROM    CMEMPM a
                            LEFT JOIN (
--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                        SELECT 'N' selcheck  ,
                                                a.empcode ,
                                                c.empname ,
                                                D.deptcode ,
                                                D.deptname ,
                                                a.saltarget ,
                                                a.salamt ,
                                                a.coltarget ,
                                                a.colamt ,
                                                CASE
                                                    WHEN a.salamt >= b.addper AND a.colamt >= b.mtargetper THEN b.applyper
                                                    ELSE b.minusper
                                                END basisamt  ,
                                                CASE
                                                    WHEN DECODE(p_salesym,NULL,'N', TO_CHAR(ADD_MONTHS ( TO_DATE(p_salesym || '-01','YYYY-MM-DD'),-3),'YYYY-MM-DD')) <=  c.enterdt THEN 'Y'
                                                    ELSE 'N'
                                                END newman
                                          FROM  (
                                                ----------------------
                                                     SELECT  empcode ,
                                                            SUM(saltarget)  saltarget  ,
                                                            SUM(salamt)     salamt  ,
                                                            SUM(coltarget)  coltarget  ,
                                                            SUM(colamt)     colamt  ,
                                                            SUM(salper)     salper  ,
                                                            SUM(colper)     colper  ,
                                                            (SUM(salper)  + SUM(colper) ) / 2 applyper
                                                      FROM ( SELECT a.empcode ,
                                                                    a.targetamt saltarget  ,
                                                                    NVL(b.salamt, 0) salamt  ,
                                                                    ROUND(NVL(b.salamt, 0) / a.targetamt * 100, 1) salper  ,
                                                                    0 coltarget  ,
                                                                    0 colamt  ,
                                                                    0 colper
                                                            FROM    (
                                                                        SELECT  empcode ,
                                                                                SUM(targetamt)  targetamt
                                                                        FROM  SLTARGETSALEM
                                                                        WHERE  yearmonth = p_salesym
                                                                        AND saldiv = 'A'
                                                                        GROUP BY empcode
                                                                        HAVING SUM(targetamt)  > 0
                                                                    ) /*tt_SLTARGETSALEM2*/ a
                                                                    LEFT JOIN (
                                                                                SELECT  empcode ,
                                                                                        SUM(CASE
                                                                                                WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN salamt
                                                                                                ELSE salamt * -1
                                                                                            END)  salamt
                                                                                FROM    SLORDM a
                                                                                        JOIN SLORDD b
                                                                                            ON      a.orderno = b.orderno
                                                                                                AND a.plantcode = b.plantcode
                                                                                WHERE   a.appdate LIKE p_salesym || '%'
                                                                                    AND a.statediv = '09'
                                                                                    AND a.saldiv NOT IN ( 'B51' )
                                                                                GROUP BY empcode
                                                                              )/*tt_SLORDM_2*/ b
                                                                        ON  a.empcode = b.empcode
                                                            UNION ALL
                                                            SELECT a.empcode ,
                                                                   0 ,
                                                                   0 ,
                                                                   0 ,
                                                                   a.targetamt coltarget  ,
                                                                   NVL(b.colamt, 0) colamt  ,
                                                                   ROUND(NVL(b.colamt, 0) / a.targetamt * 100, 1) colper
                                                            FROM   (
                                                                    -----------------------------
                                                                        SELECT  empcode ,
                                                                                MAX(deptcode)  deptcode  ,
                                                                                SUM(targetamt)  targetamt
                                                                        FROM    SLTARGETSALEM
                                                                        WHERE   yearmonth = p_salesym
                                                                            AND saldiv = 'C'
                                                                        GROUP BY empcode
                                                                        HAVING SUM(targetamt)  > 0
                                                                    -----------------------------
                                                                    ) /*tt_SLTARGETSALEM*/ a
                                                                    LEFT JOIN
                                                                                (
                                                                    ----------------------------
                                                                                    SELECT  empcode ,
                                                                                            MAX(deptcode)  deptcode  ,
                                                                                            SUM(colamt)  colamt
                                                                                    FROM    SLCOLM
                                                                                    WHERE   saldiv = 'C01'
                                                                                        AND statediv = '09'
                                                                                        AND coldiv < '50'
                                                                                        AND appdate LIKE nvl(p_salesym,' ') || '%'
                                                                                    GROUP BY empcode
                                                                    ----------------------------
                                                                                ) /*tt_SLCOLM*/ b

                                                                        ON a.empcode = b.empcode ) a
                                                      GROUP BY empcode
                                                ----------------------
                                                ) /*tt_ACBUDGYYES2*/ a
                                                JOIN ( SELECT a.empcode ,
                                                              b.*
                                                       FROM (   SELECT  a.empcode ,
                                                                        MAX(b.targetper)  targetper
                                                                FROM    (
                                -----------------------------------------------------------------------
                                                                            SELECT  empcode ,
                                                                                    SUM(saltarget)  saltarget  ,
                                                                                    SUM(salamt)     salamt  ,
                                                                                    SUM(coltarget)  coltarget  ,
                                                                                    SUM(colamt)     colamt  ,
                                                                                    SUM(salper)     salper  ,
                                                                                    SUM(colper)     colper  ,
                                                                                    (SUM(salper)  + SUM(colper) ) / 2 applyper
                                                                              FROM ( SELECT a.empcode ,
                                                                                            a.targetamt saltarget  ,
                                                                                            NVL(b.salamt, 0) salamt  ,
                                                                                            ROUND(NVL(b.salamt, 0) / a.targetamt * 100, 1) salper  ,
                                                                                            0 coltarget  ,
                                                                                            0 colamt  ,
                                                                                            0 colper
                                                                                    FROM    (
                                                                                                SELECT  empcode ,
                                                                                                        SUM(targetamt)  targetamt
                                                                                                FROM    SLTARGETSALEM
                                                                                                WHERE   yearmonth = p_salesym
                                                                                                    AND saldiv = 'A'
                                                                                                GROUP BY empcode
                                                                                                HAVING SUM(targetamt)  > 0
                                                                                            )/*tt_SLTARGETSALEM2*/ a
                                                                                            LEFT JOIN (
                                                                                                        SELECT  empcode ,
                                                                                                                SUM(CASE
                                                                                                                       WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN salamt
                                                                                                                        ELSE salamt * -1
                                                                                                                    END)  salamt
                                                                                                        FROM    SLORDM a
                                                                                                            JOIN SLORDD b
                                                                                                                ON      a.orderno = b.orderno
                                                                                                                    AND a.plantcode = b.plantcode
                                                                                                        WHERE   a.appdate LIKE p_salesym || '%'
                                                                                                            AND a.statediv = '09'
                                                                                                            AND a.saldiv NOT IN ( 'B51' )
                                                                                                        GROUP BY empcode
                                                                                                      ) /*tt_SLORDM_2*/ b
                                                                                                ON  a.empcode = b.empcode
                                                                                    UNION ALL
                                                                                    SELECT a.empcode ,
                                                                                           0 ,
                                                                                           0 ,
                                                                                           0 ,
                                                                                           a.targetamt coltarget  ,
                                                                                           NVL(b.colamt, 0) colamt  ,
                                                                                           ROUND(NVL(b.colamt, 0) / a.targetamt * 100, 1) colper
                                                                                    FROM   (
                                                                                            -----------------------------
                                                                                                SELECT  empcode ,
                                                                                                        MAX(deptcode)  deptcode  ,
                                                                                                        SUM(targetamt)  targetamt
                                                                                                FROM    SLTARGETSALEM
                                                                                                WHERE   yearmonth = p_salesym
                                                                                                    AND saldiv = 'C'
                                                                                                GROUP BY empcode
                                                                                                HAVING SUM(targetamt)  > 0
                                                                                            -----------------------------
                                                                                            ) /*tt_SLTARGETSALEM*/ a
                                                                                            LEFT JOIN
                                                                                                        (
                                                                                            ----------------------------
                                                                                                            SELECT  empcode ,
                                                                                                                    MAX(deptcode)  deptcode  ,
                                                                                                                    SUM(colamt)  colamt
                                                                                                            FROM    SLCOLM
                                                                                                            WHERE   saldiv = 'C01'
                                                                                                                AND statediv = '09'
                                                                                                                AND coldiv < '50'
                                                                                                                AND appdate LIKE nvl(p_salesym,' ') || '%'
                                                                                                            GROUP BY empcode
                                                                                            ----------------------------
                                                                                                        ) /*tt_SLCOLM*/ b

                                                                                                ON a.empcode = b.empcode ) a
                                                                              GROUP BY empcode
                                -----------------------------------------------------------------------
                                                                        ) /*tt_ACBUDGYYES2*/ a

                                                                        JOIN ACBUDGYYES b
                                                                            ON      b.compcode = p_compcode
                                                                                AND b.budgym = p_basisym
                                                                                AND b.targetdiv = '20'
                                                                                AND a.applyper >= b.targetper
                                                                                AND ( b.targetper < 100 OR 100 <= a.salper AND 100 <= a.colper )
                                                                GROUP BY a.empcode ) a
                                                                JOIN    ACBUDGYYES b
                                                                    ON      b.compcode = p_compcode
                                                                        AND b.budgym = p_basisym
                                                                        AND b.targetdiv = '20'
                                                                        AND a.targetper = b.targetper ) b
                                                    ON a.empcode = b.empcode
                                                LEFT JOIN CMEMPM c   ON a.empcode = c.empcode
                                                LEFT JOIN CMDEPTM D   ON c.deptcode = D.deptcode
                                         WHERE  ( p_deptarea = '%'
                                                    OR p_deptarea = '01' AND ( a.empcode = '204006' OR D.deptareadiv = p_deptarea )
                                                    OR p_deptarea = '03' AND a.empcode <> '204006' AND D.deptareadiv = p_deptarea
                                                )
                                            AND ( D.deptcode < 'M1040' OR a.empcode = '211005' )
--%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                      ) /*tt_ACBUDGYYES3*/ b   ON a.empcode = b.empcode
                            LEFT JOIN CMDEPTM c   ON a.deptcode = c.deptcode
                   WHERE    a.responsibilitydiv = '0003'
                        AND TO_CHAR(ADD_MONTHS (TO_DATE(p_salesym||'-01','YYYY-MM-DD'), -3 ),'YYYY-MM-DD') <= a.enterdt
                        AND b.empcode IS NULL
                        AND NVL(c.deptareadiv, ' ') LIKE p_deptarea || '%' ) a
                  LEFT JOIN CMEMPM b   ON a.empcode = b.empcode
           ORDER BY a.deptcode, b.positiondiv, a.empcode ;

    ELSIF ( p_div = 'ID' ) THEN

        FOR  rec IN
        (
            SELECT  value3
            FROM    SYSPARAMETERMANAGE
            WHERE   parametercode = 'acbudgsaleacc'
        )
        LOOP
            p_acccode1 := rec.value3   ;
        END LOOP;

        INSERT INTO ACORDD
                        (   compcode, slipinno, slipinseq, dcdiv, acccode, plantcode, debamt, creamt,
                            slipdate, slipnum, remark1, remark2, taxno, datadiv, rptseq, insertdt, iempcode )
                VALUES  (   p_compcode , p_slipinno , p_slipinseq , '1' , p_acccode1 ,
                            p_plantcode , p_slipamt , 0 , p_slipindate , SUBSTR(p_slipinno, -5, 5) ,
                            p_remark , NULL , NULL , NULL , p_slipinseq , SYSDATE ,p_iempcode );

         INSERT INTO ACORDS
                            ( compcode, slipinno, slipinseq, mngclucode, seq, mngcluval, mngcludec, insertdt, iempcode )
                    SELECT  p_compcode ,
                            p_slipinno ,
                            p_slipinseq ,
                            a.mngclucode ,
                            ROW_NUMBER() OVER ( ORDER BY a.seq  ) ,
                            CASE a.mngclucode
                                WHEN 'S040' THEN NVL(c.deptcode, '')
                                WHEN 'S050' THEN NVL(b.empcode, '')
                                ELSE ' '
                            END ,
                            CASE a.mngclucode
                                WHEN 'S040' THEN NVL(c.deptname, '')
                                WHEN 'S050' THEN NVL(b.empname, '')
                                ELSE ''
                            END ,
                            SYSDATE ,
                            p_iempcode
                    FROM    ACACCMNGM a
                            LEFT JOIN CMEMPM b   ON b.empcode = p_empcode
                            LEFT JOIN CMDEPTM c   ON b.deptcode = c.deptcode
                    WHERE   a.acccode = p_acccode1
                        AND a.dcdiv = '1'
                    ORDER BY a.seq;

    ELSIF ( p_div = 'IC' ) THEN
        p_cashcode := '11101010' ;

        FOR  rec IN
        (
            SELECT value1
            FROM SYSPARAMETERMANAGE
            WHERE  parametercode = 'acccashcode'
        )
        LOOP
            p_cashcode := rec.value1   ;
        END LOOP;

        p_acntcode := '11101031' ;
        FOR  rec IN
        (
            SELECT value2
            FROM SYSPARAMETERMANAGE
            WHERE  parametercode = 'copercardpopup'
        )
        LOOP
            p_acntcode := rec.value2   ;
        END LOOP;

        p_acccode2 :=   CASE
                            WHEN TRIM(p_accountno) IS NULL THEN p_cashcode
                            ELSE p_acntcode
                        END ;
        INSERT INTO ACORDD
                        (   compcode, slipinno, slipinseq, dcdiv, acccode, plantcode, debamt,
                            creamt, slipdate, slipnum, remark1, remark2, taxno, datadiv, rptseq, insertdt, iempcode )
                VALUES  (
                            p_compcode , p_slipinno , p_slipinseq , '2' , p_acccode2 , p_plantcode , 0 ,
                            p_slipamt , p_slipindate , SUBSTR(p_slipinno, -5, 5) , p_remark ,
                            '' , '' , '' , p_slipinseq , SYSDATE , p_iempcode
                        );

        INSERT INTO ACORDS
                      ( compcode, slipinno, slipinseq, mngclucode, seq, mngcluval, mngcludec, insertdt, iempcode )
              SELECT    p_compcode ,
                        p_slipinno ,
                        p_slipinseq ,
                        a.mngclucode ,
                        ROW_NUMBER() OVER ( ORDER BY a.seq  ) ,
                        CASE
                            WHEN a.mngclucode='S020' THEN NVL(TRIM(b.accountno), '')
                            ELSE ''
                        END ,
                        CASE
                            WHEN a.mngclucode='S020' THEN NVL(TRIM(b.accremark), '')
                            ELSE ''
                        END ,
                        SYSDATE ,
                        p_iempcode
                FROM    ACACCMNGM a
                        LEFT JOIN CMACCOUNTM b
                        ON      b.compcode = p_compcode
                        AND b.accountno = p_accountno
                WHERE   a.acccode = p_acccode2
                    AND a.dcdiv = '1'
                ORDER BY a.seq;
    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
