CREATE PROCEDURE        spACacc0142R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0142R
	-- 작 성 자         : 배종성
	-- 작성일자         : 2011-02-21
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 제조경비사용현황을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_date			IN	   VARCHAR2 DEFAULT '',
	p_outputdiv 	IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	IO_CURSOR		   OUT TYPES.DataSet,
	MESSAGE 		   OUT VARCHAR2
)
AS
	p_odiv		 VARCHAR2(5);
	p_makeamt	 VARCHAR2(5);
	p_enddate	 VARCHAR2(10);
BEGIN
	MESSAGE := '데이터 확인';



	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);

	SELECT DECODE(p_date, NULL, NULL, TO_CHAR(ADD_MONTHS(TO_DATE(p_date || '-01', 'YYYY-MM-DD'), 1) - 1, 'YYYY-MM-DD')) INTO p_enddate FROM DUAL;

	IF (TRIM(p_div) = 'S')
	THEN
		IF (p_outputdiv = '1')
		THEN
			--K-GAAP
			p_odiv := '20';
		ELSIF (p_outputdiv = '2')
		THEN
			--IFRS
			p_odiv := '30';
		END IF;

		FOR rec IN (SELECT filter1
					FROM   CMCOMMONM
					WHERE  cmmcode = 'AC27'
						   AND divcode = '6')
		LOOP
			p_makeamt := rec.filter1;
		END LOOP;

		DELETE FROM VGT.TT_ACACC0142R_T1;

        INSERT INTO VGT.TT_ACACC0142R_T1
            (SELECT a.compcode,
                    a.plantcode,
                    a.acccode,
                    M.accname,
                    NVL(b.amt, 0) lastyamt,
                    NVL(c.amt, 0) lastmamt,
                    NVL(a.debamt, 0) amt
             FROM	ACORDDMM a
                    LEFT JOIN (SELECT compcode,
                                      plantcode,
                                      acccode,
                                      NVL(debamt, 0) amt
                               FROM   ACORDDMM
                               WHERE  compcode = p_compcode
                                      AND SUBSTR(acccode, 0, 2) LIKE p_makeamt --제조경비
                                      AND plantcode LIKE p_plantcode
                                      AND slipym = DECODE(p_date, NULL, NULL, TO_CHAR(ADD_MONTHS(TO_DATE(p_date || '-01', 'YYYY-MM-DD'), -12), 'YYYY-MM'))
                                      AND (closediv = '10'
                                           OR closediv = p_odiv)) b
                        ON a.compcode = b.compcode
                           AND a.plantcode = b.plantcode
                           AND a.acccode = b.acccode
                    LEFT JOIN (SELECT compcode,
                                      plantcode,
                                      acccode,
                                      NVL(debamt, 0) amt
                               FROM   ACORDDMM
                               WHERE  compcode = p_compcode
                                      AND SUBSTR(acccode, 0, 2) LIKE p_makeamt --제조경비
                                      AND plantcode LIKE p_plantcode
                                      AND slipym = DECODE(p_date, NULL, NULL, TO_CHAR(ADD_MONTHS(TO_DATE(p_date || '-01', 'YYYY-MM-DD'), -1), 'YYYY-MM'))
                                      AND (closediv = '10'
                                           OR closediv = p_odiv)) c
                        ON a.compcode = c.compcode
                           AND a.plantcode = c.plantcode
                           AND a.acccode = c.acccode
                    LEFT JOIN ACACCM M ON a.acccode = M.acccode
             WHERE	a.compcode = p_compcode
                    AND SUBSTR(a.acccode, 0, 2) LIKE p_makeamt --제조경비
                    AND a.plantcode LIKE p_plantcode
                    AND a.slipym = p_date
                    AND (a.closediv = '10'
                         OR a.closediv = p_odiv));

		OPEN IO_CURSOR FOR
			WITH ACacc0142R
				 AS (SELECT   *
					 FROM	  (SELECT compcode,
									  plantcode,
									  '1' seq,
									  p_date || '-01' startdt,
									  p_enddate enddt,
									  p_outputdiv outputdiv,
									  b.hacccode,
									  c.accname haccname,
									  a.acccode,
									  a.accname,
									  lastyamt,
									  lastmamt,
									  amt,
									  CASE WHEN lastmamt = '0' THEN 0 ELSE (amt - lastmamt) / lastmamt * 100 END diffmper,
									  CASE WHEN lastyamt = '0' THEN 0 ELSE (amt - lastyamt) / lastyamt * 100 END diffyper
							   FROM   VGT.TT_ACACC0142R_T1 a
									  LEFT JOIN ACACCM b ON a.acccode = b.acccode
									  LEFT JOIN ACACCM c ON b.hacccode = c.acccode
							   UNION ALL
							   SELECT	compcode compcode,
										NULL plantcode,
										'2' seq,
										p_date || '-01' startdt,
										p_enddate enddt,
										p_outputdiv outputdiv,
										b.hacccode hacccode,
										MAX(c.accname) haccname,
										NULL acccode,
										'소계' accname,
										SUM(lastyamt) lastyamt,
										SUM(lastmamt) lastmamt,
										SUM(amt) amt,
										CASE WHEN SUM(lastmamt) = '0' THEN 0 ELSE (SUM(amt) - SUM(lastmamt)) / SUM(lastmamt) * 100 END diffmper,
										CASE WHEN SUM(lastyamt) = '0' THEN 0 ELSE (SUM(amt) - SUM(lastyamt)) / SUM(lastyamt) * 100 END diffyper
							   FROM 	VGT.TT_ACACC0142R_T1 a
										LEFT JOIN ACACCM b ON a.acccode = b.acccode
										LEFT JOIN ACACCM c ON b.hacccode = c.acccode
							   GROUP BY compcode, b.hacccode) a
					 ORDER BY hacccode, seq, acccode)
			SELECT compcode,
				   plantcode,
				   startdt,
				   enddt,
				   outputdiv,
				   hacccode,
				   haccname,
				   acccode,
				   accname,
				   lastyamt,
				   lastmamt,
				   amt,
				   ROUND(diffmper,0) diffmper,
				   ROUND(diffyper,0) diffyper
			FROM   ACacc0142R
			UNION ALL
			SELECT	 NULL compcode,
					 NULL plantcode,
					 NULL startdt,
					 NULL enddt,
					 NULL outputdiv,
					 NULL hacccode,
					 NULL haccname,
					 NULL acccode,
					 '합계' accname,
					 SUM(lastyamt) lastyamt,
					 SUM(lastmamt) lastmamt,
					 SUM(amt) amt,
					 CASE WHEN SUM(lastmamt) = '0' THEN 0 ELSE ROUND((SUM(amt) - SUM(lastmamt)) / SUM(lastmamt) * 100,0) END diffmper,
					 CASE WHEN SUM(lastyamt) = '0' THEN 0 ELSE ROUND((SUM(amt) - SUM(lastyamt)) / SUM(lastyamt) * 100,0) END diffyper
			FROM	 ACacc0142R
			WHERE	 SEQ = '1'
			GROUP BY compcode;
	END IF;


	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
