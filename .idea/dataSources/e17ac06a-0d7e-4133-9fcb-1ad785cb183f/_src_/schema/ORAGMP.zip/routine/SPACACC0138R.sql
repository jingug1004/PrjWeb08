CREATE PROCEDURE        spACacc0138R
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0138R
-- 작 성 자         : 배종성
-- 작성일자         : 2011-01-26
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2016-12-20
-- ---------------------------------------------------------------
-- 프로시저 설명    : 분개장을 조회하는 프로시저이다.
-- ---------------------------------------------------------------
-- select * from ACORDD
-- select * from ACACCM
-- exec spACacc0138R 'S','100','1000','2011-01-26','2011-01-26','%', '','','','N'
-- select * from CMCOMMONM where cmmcode = 'AC23' --전표구분
(
    p_div			IN	   VARCHAR2 DEFAULT '',
    p_compcode		IN	   VARCHAR2 DEFAULT '',
    p_plantcode 	IN	   VARCHAR2 DEFAULT '',
    p_startdt		IN	   VARCHAR2 DEFAULT '',
    p_enddt 		IN	   VARCHAR2 DEFAULT '',
    p_dccdiv		IN	   VARCHAR2 DEFAULT '',
    p_userid		IN	   VARCHAR2 DEFAULT '',
    p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
    p_reasontext	IN	   VARCHAR2 DEFAULT '',

    MESSAGE         OUT    VARCHAR2,
    IO_CURSOR       OUT    TYPES.DataSet
)
AS
	p_dcdiv1        VARCHAR2(5);
    p_acccode       VARCHAR2(20);

BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	p_dcdiv1 := p_dccdiv;

    IF (UPPER(p_dccdiv) = '1') THEN

        p_dcdiv1 := '2';

    END IF;

    IF ( UPPER(p_div) = UPPER('S') ) THEN

        -- 발행구분, 전자, 사업자등록번호, 상호, 업태, 종목, 매수, 공급기액, 부가세액
        FOR rec IN (    SELECT value1
                        FROM   SYSPARAMETERMANAGE
                        WHERE  parametercode = 'acccashcode' )
        LOOP
            p_acccode := rec.value1;
        END LOOP;



        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0138R_DUAL';

        INSERT INTO VGT.TT_ACACC0138R_DUAL

            SELECT  '1' seq,
                    a.compcode compcode,
                    a.plantcode plantcode,
                    a.slipdate slipdate,                                    --전표일자
                    a.slipnum slipnum,                                      --전표번호
                    a.slipinseq slipinseq,                                  --순번
                    a.acccode acccode,                                      --계정코드
                    b.accname accname,                                      --계정명
                    CASE WHEN a.dcdiv = '1' THEN '대체'
                         WHEN a.dcdiv = '2' THEN '대체'
                         WHEN a.dcdiv = '3' THEN '입금'
                         ELSE '출금'
                    END dcdiv,                                              --전표구분
                    a.debamt debamt,                                        --차변금액
                    a.creamt creamt,                                        --대변금액
                    a.remark1 remark                                        -- 적요
            FROM    ACORDD a
                    , ACACCM b
            WHERE    a.compcode = p_compcode
                    AND a.plantcode LIKE p_plantcode                        --사업장
                    AND a.slipdate BETWEEN p_startdt AND p_enddt            --조회기간
                    AND (a.dcdiv LIKE p_dccdiv OR a.dcdiv LIKE p_dcdiv1 )   --전표구분 (대체,입금,출금)
                    AND a.acccode = b.acccode

            UNION ALL

            --- 현금 대체개정 생성
            SELECT  '1' seq,
                    a.compcode compcode,
                    a.plantcode plantcode,
                    a.slipdate slipdate,                                    --전표일자
                    a.slipnum slipnum,                                      --전표번호
                    a.slipinseq slipinseq,                                  --순번
                    b.acccode acccode,                                      --계정코드
                    b.accname accname,                                      --계정명
                    CASE WHEN a.dcdiv = '1' THEN '대체'
                         WHEN a.dcdiv = '2' THEN '대체'
                         WHEN a.dcdiv = '3' THEN '입금'
                         ELSE '출금'
                    END dcdiv,                                              --전표구분
                    a.creamt debamt,                                        --차변금액
                    a.debamt creamt,                                        --대변금액
                    a.remark1 remark                                        -- 적요

            FROM    ACORDD a
                    , ACACCM b

            WHERE    a.compcode = p_compcode
                    AND a.plantcode LIKE p_plantcode                        --사업장
                    AND a.slipdate BETWEEN p_startdt AND p_enddt            --조회기간
                    AND (a.dcdiv = '3' OR a.dcdiv = '4')
                    AND (a.dcdiv LIKE p_dccdiv OR a.dcdiv LIKE p_dcdiv1 )   --전표구분 (대체,입금,출금)
                    AND b.acccode = p_acccode

            UNION ALL

            SELECT  '2' seq,
                    a.compcode compcode,
                    ' ' plantcode,
                    ' ' slipdate, --전표일자
                    ' ' slipnum, --전표번호
                    0 slipinseq, --순번
                    ' ' acccode, --계정코드
                    '합계' accname, --계정명
                    ' ' dcdiv, --전표구분
                    SUM(debamt) debamt, --차변금액
                    SUM(creamt) creamt, --대변금액
                    ' ' remark -- 적요
            FROM    (  SELECT
                                 a.compcode compcode,
                                 CASE WHEN a.dcdiv = '1' THEN SUM(NVL(a.debamt, 0))
                                      WHEN a.dcdiv = '2' THEN SUM(NVL(a.debamt, 0))
                                      WHEN a.dcdiv = '3' THEN SUM(NVL(a.debamt, 0)) + SUM(NVL(a.creamt, 0))
                                      WHEN a.dcdiv = '4' THEN SUM(NVL(a.debamt, 0)) + SUM(NVL(a.creamt, 0))
                                 END debamt, --차변금액
                                 CASE WHEN a.dcdiv = '1' THEN SUM(NVL(a.creamt, 0))
                                      WHEN a.dcdiv = '2' THEN SUM(NVL(a.creamt, 0))
                                      WHEN a.dcdiv = '3' THEN SUM(NVL(a.creamt, 0)) + SUM(NVL(a.debamt, 0))
                                      WHEN a.dcdiv = '4' THEN SUM(NVL(a.creamt, 0)) + SUM(NVL(a.debamt, 0))
                                 END creamt --대변금액
                       FROM     ACORDD a
                                , ACACCM b
                       WHERE    a.compcode = p_compcode
                                AND NVL(a.plantcode, ' ') LIKE p_plantcode --사업장
                                AND a.slipdate BETWEEN p_startdt AND p_enddt --조회기간
                                AND (a.dcdiv LIKE p_dccdiv OR a.dcdiv LIKE p_dcdiv1 ) --전표구분 (대체,입금,출금)
                                AND a.acccode = b.acccode
                       GROUP BY compcode, a.dcdiv ) a
            GROUP BY compcode ;




        OPEN IO_CURSOR FOR

            SELECT  a.*
                    , CASE WHEN seq = '1' THEN MOD(b.cnt, 2)
                           WHEN (SELECT COUNT(*) FROM VGT.TT_ACACC0138R_DUAL) <> 0 THEN CASE WHEN MOD(b.cnt, 2) = 0 THEN 1
                                                                                             ELSE 0
                                                                                        END
                    END ord
                    , cnt
            FROM    VGT.TT_ACACC0138R_DUAL a

            JOIN    (   SELECT	slipdate, slipnum, ROW_NUMBER() OVER (ORDER BY slipdate, slipnum) cnt
                        FROM    VGT.TT_ACACC0138R_DUAL a
                        GROUP BY slipdate, slipnum ) b ON a.slipdate = b.slipdate
                                                          AND a.slipnum = b.slipnum

            ORDER BY a.seq, a.dcdiv, a.slipdate, a.slipnum, a.slipinseq, a.acccode DESC;

	END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
