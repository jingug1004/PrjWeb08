CREATE FUNCTION        fnAcAutoORDval
-- ---------------------------------------------------------------
 -- 함 수 명			: fnAcAutoORDval
 -- 작 성 자         : 민승기
 -- 작성일자         : 2010-12-03
 -- ---------------------------------------------------------------
 -- 함수설명			: 회계자동분개 관리항목값매핑
 -- ---------------------------------------------------------------

(
  p_mngcludiv IN VARCHAR2 DEFAULT ' ' ,
  p_userdef1code IN VARCHAR2 DEFAULT NULL ,
  p_userdef2code IN VARCHAR2 DEFAULT NULL ,
  p_userdef3code IN VARCHAR2 DEFAULT NULL ,
  p_userdef4code IN VARCHAR2 DEFAULT NULL ,
  p_userdef5code IN VARCHAR2 DEFAULT NULL ,
  p_userdef6code IN VARCHAR2 DEFAULT NULL ,
  p_userdef7code IN VARCHAR2 DEFAULT NULL ,
  p_userdef8code IN VARCHAR2 DEFAULT NULL ,
  p_userdef9code IN VARCHAR2 DEFAULT NULL ,
  p_userdef10code IN VARCHAR2 DEFAULT NULL ,
  p_userdef11code IN VARCHAR2 DEFAULT NULL ,
  p_userdef12code IN VARCHAR2 DEFAULT NULL ,
  p_userdef13code IN VARCHAR2 DEFAULT NULL ,
  p_userdef14code IN VARCHAR2 DEFAULT NULL ,
  p_userdef15code IN VARCHAR2 DEFAULT NULL ,
  p_userdef16code IN VARCHAR2 DEFAULT NULL ,
  p_userdef17code IN VARCHAR2 DEFAULT NULL ,
  p_userdef18code IN VARCHAR2 DEFAULT NULL ,
  p_userdef19code IN VARCHAR2 DEFAULT NULL ,
  p_userdef20code IN VARCHAR2 DEFAULT NULL ,
  p_userdef21code IN VARCHAR2 DEFAULT NULL ,
  p_userdef22code IN VARCHAR2 DEFAULT NULL ,
  p_userdef23code IN VARCHAR2 DEFAULT NULL ,
  p_userdef24code IN VARCHAR2 DEFAULT NULL ,
  p_userdef25code IN VARCHAR2 DEFAULT NULL ,
  p_userdef26code IN VARCHAR2 DEFAULT NULL ,
  p_userdef27code IN VARCHAR2 DEFAULT NULL ,
  p_userdef28code IN VARCHAR2 DEFAULT NULL ,
  p_userdef29code IN VARCHAR2 DEFAULT NULL ,
  p_userdef30code IN VARCHAR2 DEFAULT NULL ,
  p_deptcode IN VARCHAR2 DEFAULT NULL ,-- 부서코드
  p_custcode IN VARCHAR2 DEFAULT NULL ,-- 거래처코드
  p_taxno IN VARCHAR2 DEFAULT NULL ,-- 계산서번호
  p_billno IN VARCHAR2 DEFAULT NULL ,-- 어음번호
  p_issdate IN VARCHAR2 DEFAULT NULL ,-- 어음시작일자
  p_expdate IN VARCHAR2 DEFAULT NULL ,-- 어음만기일자
  p_cardno IN VARCHAR2 DEFAULT NULL ,-- 카드번호
  p_empcode IN VARCHAR2 DEFAULT NULL ,-- 사원번호
  p_cardokno IN VARCHAR2 DEFAULT NULL 
)
RETURN VARCHAR2
AS
   p_rtn VARCHAR2(50);

 -- 카드승인번호
BEGIN
   p_rtn := CASE NVL(TRIM(p_mngcludiv),' ')
                            WHEN '01' THEN p_deptcode
                            WHEN '02' THEN p_custcode
                            WHEN '03' THEN p_taxno
                            WHEN '04' THEN p_billno
                            WHEN '05' THEN p_expdate
                            WHEN '06' THEN p_cardno
                            WHEN '07' THEN p_empcode
                            WHEN '08' THEN p_cardokno
                            WHEN '11' THEN p_userdef1code
                            WHEN '12' THEN p_userdef2code
                            WHEN '13' THEN p_userdef3code
                            WHEN '14' THEN p_userdef4code
                            WHEN '15' THEN p_userdef5code
                            WHEN '16' THEN p_userdef6code
                            WHEN '17' THEN p_userdef7code
                            WHEN '18' THEN p_userdef8code
                            WHEN '19' THEN p_userdef9code
                            WHEN '20' THEN p_userdef10code
                            WHEN '21' THEN p_userdef11code
                            WHEN '22' THEN p_userdef12code
                            WHEN '23' THEN p_issdate
                            WHEN '24' THEN p_userdef14code
                            WHEN '25' THEN p_userdef15code
                            WHEN '26' THEN p_userdef16code
                            WHEN '27' THEN p_userdef17code
                            WHEN '28' THEN p_userdef18code
                            WHEN '29' THEN p_userdef19code
                            WHEN '30' THEN p_userdef20code
                            WHEN '31' THEN p_userdef21code
                            WHEN '32' THEN p_userdef22code
                            WHEN '33' THEN p_userdef23code
                            WHEN '34' THEN p_userdef24code
                            WHEN '35' THEN p_userdef25code
                            WHEN '36' THEN p_userdef26code
                            WHEN '37' THEN p_userdef27code
                            WHEN '38' THEN p_userdef28code
                            WHEN '39' THEN p_userdef29code
                            WHEN '40' THEN p_userdef30code
   ELSE NULL
      END ;
   p_rtn := NVL(p_rtn, ' ') ;
   RETURN (p_rtn);

END;
/
