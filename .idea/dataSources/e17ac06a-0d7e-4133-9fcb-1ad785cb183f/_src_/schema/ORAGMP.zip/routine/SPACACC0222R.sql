CREATE PROCEDURE        spACacc0222R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0222R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-05-03
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-26
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 기간별 제조원가명세서를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_rptdiv		IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '',
	p_startym		IN	   VARCHAR2 DEFAULT '',
	p_endym 		IN	   VARCHAR2 DEFAULT '',
	p_pretype		IN	   VARCHAR2 DEFAULT '1',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	ip_startym	  VARCHAR2(7) := p_startym;
	p_basisyy	  VARCHAR2(4);
	p_beyymm	  VARCHAR2(7);
	p_yyyy01	  VARCHAR2(7);
	p_beyy01	  VARCHAR2(7);
	p_cashcode	  VARCHAR2(20);
	p_strym 	  VARCHAR2(7);
	-- 임시테이블의 calcseq의 최대값을 조회
	p_maxseq	  NUMBER(10, 0);
	p_curseq	  NUMBER(10, 0);
	-- 시작월의 제조원가명세서 생성
	p_beyymm_p	  VARCHAR2(7);
	p_yyyy01_p	  VARCHAR2(7);
	p_beyy01_p	  VARCHAR2(7);
	-- 임시테이블의 calcseq의 최대값을 조회
	p_maxseq_p	  NUMBER(10, 0);
	p_curseq_p	  NUMBER(10, 0);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);


	IF (p_div = 'S' OR p_div = 'P')
	THEN
		p_strym := ip_startym;

		IF SUBSTR(ip_startym, -2, 2) = '01' AND p_pretype <> '3'
		THEN
			spACacc0208R(p_div => p_div,
						 p_compcode => p_compcode,
						 p_plantcode => p_plantcode,
						 p_rptdiv => p_rptdiv,
						 p_closediv => p_closediv,
						 p_basisym => p_endym,
						 p_viewyn => 'Y',
						 p_pretype => p_pretype,
						 p_userid => p_userid,
						 p_reasondiv => p_reasondiv,
						 p_reasontext => p_reasontext,
						 MESSAGE => MESSAGE,
						 IO_CURSOR => IO_CURSOR);



			GOTO LAST;
		END IF;

		ip_startym := TO_CHAR(ADD_MONTHS(TO_DATE(ip_startym, 'YYYY-MM'), -1), 'YYYY-MM');
		-- 종료월의 제조원가명세서 생성
		-- 기간 설정
		p_yyyy01 := SUBSTR(p_endym, 0, 4) || '-01';

		FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
					FROM   ACSESSION
					WHERE  compcode = p_compcode
						   AND cyear <= SUBSTR(p_endym, 0, 4))
		LOOP
			p_yyyy01 := rec.alias1;
		END LOOP;

		IF SUBSTR(p_endym, -2, 2) < SUBSTR(p_yyyy01, -2, 2)
		THEN
			p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_endym, 'YYYY-MM'), -12), 'YYYY-') || SUBSTR(p_yyyy01, -2, 2);
		ELSE
			p_yyyy01 := SUBSTR(p_endym, 0, 5) || SUBSTR(p_yyyy01, -2, 2);
		END IF;

		IF p_pretype = '1'
		THEN
			p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_endym, 'YYYY-MM'), -12), 'YYYY-MM');
		ELSE
			IF p_pretype = '2'
			THEN
				p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01, 'YYYY-MM'), -1), 'YYYY-MM');
			ELSE
				p_beyymm := p_endym;
			END IF;
		END IF;

		IF p_pretype = '3'
		THEN
			p_beyy01 := p_yyyy01;
		ELSE
			p_beyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01, 'YYYY-MM'), -1), 'YYYY-MM');
		END IF;

		p_cashcode := '11101010';

		FOR rec IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'acccashcode')
		LOOP
			p_cashcode := rec.value1;
		END LOOP;

		-- 보고서 조회년도 설정
		FOR rec IN (SELECT MAX(rptyear) AS alias1
					FROM   ACRPTM
					WHERE  compcode = p_compcode
						   AND rptdiv = p_rptdiv
						   AND rptyear <= SUBSTR(p_endym, 0, 4))
		LOOP
			p_basisyy := rec.alias1;
		END LOOP;

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0222R_ACORDDMM ';

		-- 전표에서 월집계 임시파일을 생성
		INSERT INTO VGT.TT_ACACC0222R_ACORDDMM
			(SELECT   p_compcode compcode,
					  p_plantcode plantcode,
					  p_endym slipym,
					  CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
					  acccode,
					  SUM(totdebamt) totdebamt,
					  SUM(totcreamt) totcreamt
			 FROM	  (SELECT TRIM(b.acccode) acccode,
							  b.debamt totdebamt,
							  b.creamt totcreamt
					   FROM   ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
					   WHERE  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_endym, 'YYYY-MM'), 1), 'YYYYMM')
							  AND a.slipinstate = '4'
							  AND (NVL(a.slipdiv,' ') NOT IN ('K', 'F')
								   OR p_closediv = '1'
									  AND a.slipdiv = 'K'
								   OR p_closediv = '2'
									  AND a.slipdiv = 'F')
					   UNION ALL
					   SELECT TRIM(p_cashcode) acccode,
							  b.creamt totdebamt,
							  b.debamt totcreamt
					   FROM   ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
									 AND b.dcdiv IN ('3', '4')
					   WHERE  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_endym, 'YYYY-MM'), 1), 'YYYYMM')
							  AND a.slipinstate = '4'
							  AND (NVL(a.slipdiv,' ') NOT IN ('K', 'F')
								   OR p_closediv = '1'
									  AND a.slipdiv = 'K'
								   OR p_closediv = '2'
									  AND a.slipdiv = 'F')
					   UNION ALL
					   SELECT TRIM(acccode) acccode,
							  bsdebamt totdebamt,
							  bscreamt totcreamt
					   FROM   ACORDDMM
					   WHERE  compcode = p_compcode
							  AND plantcode LIKE p_plantcode
							  AND slipym = p_yyyy01
							  AND (p_closediv = '1'
								   AND closediv IN ('10', '20')
								   OR p_closediv = '2'
									  AND closediv IN ('10', '30'))) a
			 GROUP BY acccode);

		INSERT INTO VGT.TT_ACACC0222R_ACORDDMM
			(SELECT   p_compcode compcode,
					  p_plantcode plantcode,
					  p_beyymm slipym,
					  CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
					  TRIM(acccode) acccode,
					  SUM(totdebamt) totdebamt,
					  SUM(totcreamt) totcreamt
			 FROM	  ACORDDMM
			 WHERE	  compcode = p_compcode
					  AND plantcode LIKE p_plantcode
					  AND slipym = p_beyymm
					  AND p_endym <> p_beyymm
					  AND (p_closediv = '1'
						   AND closediv IN ('10', '20')
						   OR p_closediv = '2'
							  AND closediv IN ('10', '30'))
			 GROUP BY acccode);

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0222R_ACC222A ';

		-- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
		INSERT INTO VGT.TT_ACACC0222R_ACC222A(seqline,
											  acccode,
											  accrname,
											  acckname,
											  lrdiv,
											  prtyn,
											  prtdiv,
											  prtbold,
											  sseqline,
											  calcseq,
											  calcdiv,
											  cseqline,
											  cgb,
											  objdatadiv,
											  amt,
											  beamt)
			SELECT	 a.seqline,
					 MAX(a.acccode),
					 MAX(a.accrname),
					 MAX(a.acckname),
					 MAX(a.lrdiv),
					 MAX(a.prtyn),
					 MAX(a.prtdiv),
					 MAX(a.prtbold),
					 MAX(a.sseqline),
					 MAX(a.calcseq),
					 MAX(a.calcdiv),
					 MAX(a.cseqline),
					 '1',
					 MAX(a.objdatadiv),
					 NVL(SUM(CASE WHEN c.slipym = p_endym THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END END), 0)
						 amt2,
					 NVL(SUM(CASE WHEN c.slipym = p_beyymm THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END END), 0)
						 amt4
			FROM	 ACRPTM a
					 LEFT JOIN ACACCM b ON NVL(a.acccode,' ') = NVL(b.acccode,' ')
					 LEFT JOIN VGT.TT_ACACC0222R_ACORDDMM c
						 ON a.compcode = c.compcode
							AND c.plantcode LIKE p_plantcode
							AND c.slipym IN (p_endym, p_beyymm)
							AND (p_closediv = '1'
								 AND c.closediv IN ('10', '20')
								 OR p_closediv = '2'
									AND c.closediv IN ('10', '30'))
							AND NVL(a.acccode,' ') = NVL(c.acccode,' ')
			WHERE	 a.compcode = p_compcode
					 AND a.rptdiv = p_rptdiv
					 AND a.rptyear = p_basisyy
					 AND a.useyn = 'Y'
			GROUP BY a.seqline
			ORDER BY a.seqline;
		
        
        
		-- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
		MERGE INTO VGT.TT_ACACC0222R_ACC222A a
		USING	   (SELECT A.SEQLINE,
						   A.ACCCODE,
						   A.ACCRNAME,
						   A.ACCKNAME,
						   A.LRDIV,
						   A.PRTYN,
						   A.PRTDIV,
						   A.PRTBOLD,
						   A.SSEQLINE,
						   A.CALCSEQ,
						   A.CALCDIV,
						   A.CSEQLINE,
						   A.CGB,
						   A.OBJDATADIV,
						   A.CALCAMT,
						   A.BECALCAMT,
						   CASE WHEN a.objdatadiv = 'A' THEN b.amt ELSE a.amt - b.amt END AS pos_2,
						   CASE WHEN a.objdatadiv = 'A' THEN b.beamt ELSE a.beamt - b.beamt END AS pos_3
					FROM   VGT.TT_ACACC0222R_ACC222A a
						   JOIN
						   (SELECT	 a.seqline,
									 NVL(SUM(CASE WHEN c.slipym = p_yyyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) amt,
									 NVL(SUM(CASE WHEN c.slipym = p_beyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) beamt
							FROM	 ACRPTM a
									 LEFT JOIN ACACCM b ON NVL(a.acccode,' ') = NVL(b.acccode,' ')
									 LEFT JOIN ACORDDMM c
										 ON a.compcode = c.compcode
											AND c.plantcode LIKE p_plantcode
											AND c.slipym IN (p_yyyy01, p_beyy01)
											AND (p_closediv = '1'
												 AND c.closediv IN ('10', '20')
												 OR p_closediv = '2'
													AND c.closediv IN ('10', '30'))
											AND NVL(a.acccode,' ') = NVL(c.acccode,' ')
							WHERE	 a.compcode = p_compcode
									 AND a.rptdiv = p_rptdiv
									 AND a.rptyear = p_basisyy
									 AND a.useyn = 'Y'
									 AND a.objdatadiv IN ('A', 'E', 'F')
							GROUP BY a.seqline) b
							   ON a.seqline = b.seqline) src
		ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
					AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
					AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
					AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
					AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
					AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
					AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
					AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
					AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
					AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
					AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
					AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
					AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
					AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
					AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
					AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
		WHEN MATCHED
		THEN
			UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;

		p_curseq := 0;

		FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0222R_ACC222A)
		LOOP
			p_maxseq := rec.alias1;
		END LOOP;

		-- 각 레벨별로 sum을하여 update
		WHILE p_curseq <= p_maxseq
		LOOP
			MERGE INTO VGT.TT_ACACC0222R_ACC222A a
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.PRTBOLD,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.CSEQLINE,
							   A.CGB,
							   A.OBJDATADIV,
							   A.CALCAMT,
							   A.BECALCAMT,
							   a.amt + b.amt AS pos_2,
							   a.beamt + b.beamt AS pos_3
						FROM   VGT.TT_ACACC0222R_ACC222A a
							   JOIN (SELECT   sseqline,
											  SUM(CASE WHEN calcdiv = '+' THEN amt ELSE -amt END) amt,
											  SUM(CASE WHEN calcdiv = '+' THEN beamt ELSE -beamt END) beamt
									 FROM	  VGT.TT_ACACC0222R_ACC222A
									 WHERE	  calcseq = p_curseq
											  AND NVL(sseqline, ' ') <> ' '
									 GROUP BY sseqline) b
								   ON a.seqline = b.sseqline) src
			ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
						AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
						AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
						AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
						AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
						AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
			WHEN MATCHED
			THEN
				UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;

			p_curseq := p_curseq + 1;
		END LOOP;
        
		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0222R_ACC222B ';

		INSERT INTO VGT.TT_ACACC0222R_ACC222B
			SELECT	 a.cseqline,
					 a.seqline,
					 a.amt,
					 a.beamt,
					 0,
					 0,
					 b.amt,
					 b.beamt,
					 0,
					 ROWNUM
			FROM	 VGT.TT_ACACC0222R_ACC222A a JOIN VGT.TT_ACACC0222R_ACC222A b ON a.cseqline = b.seqline
			WHERE	 a.amt <> 0
					 OR a.beamt <> 0
			ORDER BY a.cseqline, a.seqline DESC;

		MERGE INTO VGT.TT_ACACC0222R_ACC222B a
		USING	   (SELECT a.ORD,
						   a.ord - b.minNo + 1 AS pos_2
					FROM   VGT.TT_ACACC0222R_ACC222B a
						   JOIN (SELECT   cseqline,
										  MIN(ord) minNo
								 FROM	  VGT.TT_ACACC0222R_ACC222B
								 GROUP BY VGT.TT_ACACC0222R_ACC222B.cseqline) b
							   ON a.cseqline = b.cseqline) src
		ON		   (a.ORD = src.ORD)
		WHEN MATCHED
		THEN
			UPDATE SET A.num = SRC.pos_2, A.amt2 = 0, A.beamt2 = 0;

		MERGE INTO VGT.TT_ACACC0222R_ACC222B a
		USING	   (SELECT a.ORD,
						   b.amt,
						   b.beamt
					FROM   VGT.TT_ACACC0222R_ACC222B a
						   JOIN (SELECT   cseqline,
										  SUM(amt) amt,
										  SUM(beamt) beamt
								 FROM	  VGT.TT_ACACC0222R_ACC222B
								 GROUP BY VGT.TT_ACACC0222R_ACC222B.cseqline) b
							   ON a.cseqline = b.cseqline
								  AND num = 1) src
		ON		   (a.ORD = src.ORD)
		WHEN MATCHED
		THEN
			UPDATE SET A.amt2 = src.amt, A.beamt2 = src.beamt;

		MERGE INTO VGT.TT_ACACC0222R_ACC222A a
		USING	   (SELECT A.SEQLINE,
						   A.ACCCODE,
						   A.ACCRNAME,
						   A.ACCKNAME,
						   A.PRTYN,
						   A.PRTDIV,
						   A.PRTBOLD,
						   A.SSEQLINE,
						   A.CALCSEQ,
						   A.CALCDIV,
						   A.CSEQLINE,
						   A.CGB,
						   A.OBJDATADIV,
						   A.AMT,
						   A.CALCAMT,
						   A.BEAMT,
						   A.BECALCAMT
					FROM   VGT.TT_ACACC0222R_ACC222A a
						   JOIN (SELECT DISTINCT cseqline FROM VGT.TT_ACACC0222R_ACC222B
								 UNION
								 SELECT seqline FROM VGT.TT_ACACC0222R_ACC222B) b
							   ON a.seqline = b.cseqline) src
		ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
					AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
					AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
					AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
					AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
					AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
					AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
					AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
					AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
					AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
					AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
					AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
					AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
					AND NVL(A.AMT, 0) = NVL(SRC.AMT, 0)
					AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
					AND NVL(A.BEAMT, 0) = NVL(SRC.BEAMT, 0)
					AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
		WHEN MATCHED
		THEN
			UPDATE SET A.lrdiv = 'L';

		MERGE INTO VGT.TT_ACACC0222R_ACC222A a
		USING	   (SELECT A.SEQLINE,
						   A.ACCCODE,
						   A.ACCRNAME,
						   A.ACCKNAME,
						   A.LRDIV,
						   A.PRTYN,
						   A.PRTDIV,
						   A.PRTBOLD,
						   A.SSEQLINE,
						   A.CALCSEQ,
						   A.CALCDIV,
						   A.CSEQLINE,
						   A.OBJDATADIV,
						   A.AMT,
						   A.BEAMT,
						   b.amt3 - amt2 AS pos_2,
						   b.beamt3 - beamt2 AS pos_3,
						   '2'
					FROM   VGT.TT_ACACC0222R_ACC222A a
						   JOIN (SELECT seqline,
										amt2,
										amt3,
										beamt2,
										beamt3
								 FROM	VGT.TT_ACACC0222R_ACC222B
								 WHERE	num = 1) b
							   ON a.seqline = b.seqline) src
		ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
					AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
					AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
					AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
					AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
					AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
					AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
					AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
					AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
					AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
					AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
					AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
					AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
					AND NVL(A.AMT, 0) = NVL(SRC.AMT, 0)
					AND NVL(A.BEAMT, 0) = NVL(SRC.BEAMT, 0))
		WHEN MATCHED
		THEN
			UPDATE SET A.calcamt = SRC.pos_2, A.becalcamt = SRC.pos_3, A.cgb = '2';

		IF p_yyyy01 < p_strym
		THEN
			-- 기간 설정
			p_yyyy01_p := SUBSTR(ip_startym, 0, 4) || '-01';

			FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
						FROM   ACSESSION
						WHERE  compcode = p_compcode
							   AND cyear <= SUBSTR(ip_startym, 0, 4))
			LOOP
				p_yyyy01_p := rec.alias1;
			END LOOP;

			IF SUBSTR(ip_startym, -2, 2) < SUBSTR(p_yyyy01_p, -2, 2)
			THEN
				p_yyyy01_p := TO_CHAR(ADD_MONTHS(TO_DATE(ip_startym, 'YYYY-MM'), -12), 'YYYY-') || SUBSTR(p_yyyy01_p, -2, 2);
			ELSE
				p_yyyy01_p := SUBSTR(ip_startym, 0, 5) || SUBSTR(p_yyyy01_p, -2, 2);
			END IF;

			IF p_pretype = '1'
			THEN
				p_beyymm_p := TO_CHAR(ADD_MONTHS(TO_DATE(ip_startym, 'YYYY-MM'), -12), 'YYYY-MM');
			ELSE
				p_beyymm_p := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01_p, 'YYYY-MM'), -1), 'YYYY-MM');
			END IF;

			p_beyy01_p := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01_p, 'YYYY-MM'), -12), 'YYYY-MM');

			-- 전표에서 월집계 임시파일을 생성

			EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0222R_ACORDDMMP ';

			INSERT INTO VGT.TT_ACACC0222R_ACORDDMMP
				(SELECT   p_compcode compcode,
						  p_plantcode plantcode,
						  ip_startym slipym,
						  CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
						  acccode,
						  SUM(totdebamt) totdebamt,
						  SUM(totcreamt) totcreamt
				 FROM	  (SELECT TRIM(b.acccode) acccode,
								  b.debamt totdebamt,
								  b.creamt totcreamt
						   FROM   ACORDM a
								  JOIN ACORDD b
									  ON a.compcode = b.compcode
										 AND a.slipinno = b.slipinno
						   WHERE  a.compcode = p_compcode
								  AND a.plantcode LIKE p_plantcode
								  AND a.slipno BETWEEN REPLACE(p_yyyy01_p, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(ip_startym, 'YYYY-MM'), 1), 'YYYYMM')
								  AND a.slipinstate = '4'
								  AND (NVL(a.slipdiv,' ') NOT IN ('K', 'F')
									   OR p_closediv = '1'
										  AND a.slipdiv = 'K'
									   OR p_closediv = '2'
										  AND a.slipdiv = 'F')
						   UNION ALL
						   SELECT p_cashcode acccode,
								  b.creamt totdebamt,
								  b.debamt totcreamt
						   FROM   ACORDM a
								  JOIN ACORDD b
									  ON a.compcode = b.compcode
										 AND a.slipinno = b.slipinno
										 AND b.dcdiv IN ('3', '4')
						   WHERE  a.compcode = p_compcode
								  AND a.plantcode LIKE p_plantcode
								  AND a.slipno BETWEEN REPLACE(p_yyyy01_p, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(ip_startym, 'YYYY-MM'), 1), 'YYYYMM')
								  AND a.slipinstate = '4'
								  AND (NVL(a.slipdiv,' ') NOT IN ('K', 'F')
									   OR p_closediv = '1'
										  AND a.slipdiv = 'K'
									   OR p_closediv = '2'
										  AND a.slipdiv = 'F')
						   UNION ALL
						   SELECT TRIM(acccode) acccode,
								  bsdebamt totdebamt,
								  bscreamt totcreamt
						   FROM   ACORDDMM
						   WHERE  compcode = p_compcode
								  AND plantcode LIKE p_plantcode
								  AND slipym = p_yyyy01_p
								  AND (p_closediv = '1'
									   AND closediv IN ('10', '20')
									   OR p_closediv = '2'
										  AND closediv IN ('10', '30'))) a
				 GROUP BY acccode);

			INSERT INTO VGT.TT_ACACC0222R_ACORDDMMP
				(SELECT   p_compcode compcode,
						  p_plantcode plantcode,
						  p_beyymm_p slipym,
						  CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
						  acccode,
						  SUM(totdebamt) totdebamt,
						  SUM(totcreamt) totcreamt
				 FROM	  ACORDDMM
				 WHERE	  compcode = p_compcode
						  AND plantcode LIKE p_plantcode
						  AND slipym = p_beyymm_p
						  AND (p_closediv = '1'
							   AND closediv IN ('10', '20')
							   OR p_closediv = '2'
								  AND closediv IN ('10', '30'))
				 GROUP BY acccode);

			EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0222R_ACC222AP ';

			-- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
			INSERT INTO VGT.TT_ACACC0222R_ACC222AP(seqline,
												   acccode,
												   accrname,
												   acckname,
												   lrdiv,
												   prtyn,
												   prtdiv,
												   sseqline,
												   calcseq,
												   calcdiv,
												   cseqline,
												   cgb,
												   objdatadiv,
												   amt,
												   beamt)
				SELECT	 a.seqline,
						 MAX(a.acccode),
						 MAX(a.accrname),
						 MAX(a.acckname),
						 MAX(a.lrdiv),
						 MAX(a.prtyn),
						 MAX(a.prtdiv),
						 MAX(a.sseqline),
						 MAX(a.calcseq),
						 MAX(a.calcdiv),
						 MAX(a.cseqline),
						 '1',
						 MAX(a.objdatadiv),
						 NVL(SUM(CASE WHEN c.slipym = ip_startym THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END END),
							 0)
							 amt2,
						 NVL(SUM(CASE WHEN c.slipym = p_beyymm_p THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END END),
							 0)
							 amt4
				FROM	 ACRPTM a
						 LEFT JOIN ACACCM b ON NVL(a.acccode,' ') = NVL(b.acccode,' ')
						 LEFT JOIN VGT.TT_ACACC0222R_ACORDDMMP c
							 ON a.compcode = c.compcode
								AND c.plantcode LIKE p_plantcode
								AND c.slipym IN (ip_startym, p_beyymm_p)
								AND (p_closediv = '1'
									 AND c.closediv IN ('10', '20')
									 OR p_closediv = '2'
										AND c.closediv IN ('10', '30'))
								AND NVL(a.acccode,' ') = NVL(c.acccode,' ')
				WHERE	 a.compcode = p_compcode
						 AND a.rptdiv = p_rptdiv
						 AND a.rptyear = p_basisyy
						 AND a.useyn = 'Y'
				GROUP BY a.seqline
				ORDER BY a.seqline;

			-- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
			MERGE INTO VGT.TT_ACACC0222R_ACC222AP a
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.CSEQLINE,
							   A.CGB,
							   A.OBJDATADIV,
							   A.CALCAMT,
							   A.BECALCAMT,
							   CASE WHEN a.objdatadiv = 'A' THEN b.amt ELSE a.amt - b.amt END AS pos_2,
							   CASE WHEN a.objdatadiv = 'A' THEN b.beamt ELSE a.beamt - b.beamt END AS pos_3
						FROM   VGT.TT_ACACC0222R_ACC222AP a
							   JOIN
							   (SELECT	 a.seqline,
										 NVL(SUM(CASE WHEN c.slipym = p_yyyy01_p THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0)
											 amt,
										 NVL(SUM(CASE WHEN c.slipym = p_beyy01_p THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0)
											 beamt
								FROM	 ACRPTM a
										 LEFT JOIN ACACCM b ON NVL(a.acccode,' ') = NVL(b.acccode,' ')
										 LEFT JOIN ACORDDMM c
											 ON a.compcode = c.compcode
												AND c.plantcode LIKE p_plantcode
												AND c.slipym IN (p_yyyy01_p, p_beyy01_p)
												AND (p_closediv = '1'
													 AND c.closediv IN ('10', '20')
													 OR p_closediv = '2'
														AND c.closediv IN ('10', '30'))
												AND NVL(a.acccode,' ') = NVL(c.acccode,' ')
								WHERE	 a.compcode = p_compcode
										 AND a.rptdiv = p_rptdiv
										 AND a.rptyear = p_basisyy
										 AND a.useyn = 'Y'
										 AND a.objdatadiv IN ('A', 'E', 'F')
								GROUP BY a.seqline) b
								   ON a.seqline = b.seqline) src
			ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
						AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
						AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
						AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
						AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
			WHEN MATCHED
			THEN
				UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;

			p_curseq_p := 0;

			FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0222R_ACC222AP)
			LOOP
				p_maxseq_p := rec.alias1;
			END LOOP;

			-- 각 레벨별로 sum을하여 update
			WHILE p_curseq_p <= p_maxseq_p
			LOOP
				BEGIN
					MERGE INTO VGT.TT_ACACC0222R_ACC222AP a
					USING	   (SELECT A.SEQLINE,
									   A.ACCCODE,
									   A.ACCRNAME,
									   A.ACCKNAME,
									   A.LRDIV,
									   A.PRTYN,
									   A.PRTDIV,
									   A.SSEQLINE,
									   A.CALCSEQ,
									   A.CALCDIV,
									   A.CSEQLINE,
									   A.CGB,
									   A.OBJDATADIV,
									   A.CALCAMT,
									   A.BECALCAMT,
									   a.amt + b.amt AS pos_2,
									   a.beamt + b.beamt AS pos_3
								FROM   VGT.TT_ACACC0222R_ACC222AP a
									   JOIN (SELECT   VGT.TT_ACACC0222R_ACC222AP.sseqline,
													  SUM(CASE WHEN VGT.TT_ACACC0222R_ACC222AP.calcdiv = '+' THEN VGT.TT_ACACC0222R_ACC222AP.amt ELSE -VGT.TT_ACACC0222R_ACC222AP.amt END) amt,
													  SUM(CASE WHEN VGT.TT_ACACC0222R_ACC222AP.calcdiv = '+' THEN VGT.TT_ACACC0222R_ACC222AP.beamt ELSE -VGT.TT_ACACC0222R_ACC222AP.beamt END) beamt
											 FROM	  VGT.TT_ACACC0222R_ACC222AP
											 WHERE	  VGT.TT_ACACC0222R_ACC222AP.calcseq = p_curseq_p
													  AND NVL(VGT.TT_ACACC0222R_ACC222AP.sseqline, ' ') <> ' '
											 GROUP BY VGT.TT_ACACC0222R_ACC222AP.sseqline) b
										   ON a.seqline = b.sseqline) src
					ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
								AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
								AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
								AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
								AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
								AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
								AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
								AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
								AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
								AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
								AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
								AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
								AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
								AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
								AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
					WHEN MATCHED
					THEN
						UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;

					p_curseq_p := p_curseq_p + 1;
				END;
			END LOOP;

			INSERT INTO VGT.TT_ACACC0222R_ACC222BP
				SELECT	 a.cseqline,
						 a.seqline,
						 a.amt,
						 a.beamt,
						 0,
						 0,
						 b.amt,
						 b.beamt,
						 0,
						 ROWNUM
				FROM	 VGT.TT_ACACC0222R_ACC222AP a JOIN VGT.TT_ACACC0222R_ACC222AP b ON a.cseqline = b.seqline
				WHERE	 a.amt <> 0
						 OR a.beamt <> 0
				ORDER BY a.cseqline, a.seqline DESC;

			MERGE INTO VGT.TT_ACACC0222R_ACC222BP a
			USING	   (SELECT a.ORD,
							   a.ord - b.minNo + 1 AS pos_2
						FROM   VGT.TT_ACACC0222R_ACC222BP a
							   JOIN (SELECT   cseqline,
											  MIN(ord) minNo
									 FROM	  VGT.TT_ACACC0222R_ACC222BP
									 GROUP BY VGT.TT_ACACC0222R_ACC222BP.cseqline) b
								   ON a.cseqline = b.cseqline) src
			ON		   (a.ORD = src.ORD)
			WHEN MATCHED
			THEN
				UPDATE SET A.num = SRC.pos_2, A.amt2 = 0, A.beamt2 = 0;



			MERGE INTO VGT.TT_ACACC0222R_ACC222BP a
			USING	   (SELECT a.ORD,
							   b.amt,
							   b.beamt
						FROM   VGT.TT_ACACC0222R_ACC222BP a
							   JOIN (SELECT   cseqline,
											  SUM(amt) amt,
											  SUM(beamt) beamt
									 FROM	  VGT.TT_ACACC0222R_ACC222BP
									 GROUP BY VGT.TT_ACACC0222R_ACC222BP.cseqline) b
								   ON a.cseqline = b.cseqline
									  AND num = 1) src
			ON		   (a.ORD = src.ORD)
			WHEN MATCHED
			THEN
				UPDATE SET A.amt2 = src.amt, A.beamt2 = src.beamt;



			MERGE INTO VGT.TT_ACACC0222R_ACC222AP a
			USING	   (SELECT a.seqline
						FROM   VGT.TT_ACACC0222R_ACC222AP a
							   JOIN (SELECT DISTINCT VGT.TT_ACACC0222R_ACC222BP.cseqline FROM VGT.TT_ACACC0222R_ACC222BP
									 UNION
									 SELECT VGT.TT_ACACC0222R_ACC222BP.seqline FROM VGT.TT_ACACC0222R_ACC222BP) b
								   ON a.seqline = b.cseqline) src
			ON		   (a.seqline = src.seqline)
			WHEN MATCHED
			THEN
				UPDATE SET lrdiv = 'L';



			MERGE INTO VGT.TT_ACACC0222R_ACC222AP a
			USING	   (SELECT a.seqline,
							   b.amt3 - amt2 AS pos_2,
							   b.beamt3 - beamt2 AS pos_3
						FROM   VGT.TT_ACACC0222R_ACC222AP a
							   JOIN (SELECT seqline,
											amt2,
											amt3,
											beamt2,
											VGT.TT_ACACC0222R_ACC222BP.beamt3
									 FROM	VGT.TT_ACACC0222R_ACC222BP
									 WHERE	VGT.TT_ACACC0222R_ACC222BP.num = 1) b
								   ON a.seqline = b.seqline) src
			ON		   (a.seqline = src.seqline)
			WHEN MATCHED
			THEN
				UPDATE SET A.calcamt = SRC.pos_2, A.becalcamt = SRC.pos_3, A.cgb = '2';

			-- 종료월에서 시작월자료를 감함
			MERGE INTO VGT.TT_ACACC0222R_ACC222A a
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.PRTBOLD,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.CSEQLINE,
							   A.CGB,
							   A.OBJDATADIV,
							   NULLIF(a.amt - NVL(c.amt, 0), 0) AS pos_2,
							   NULLIF(a.calcamt - NVL(c.calcamt, 0), 0) AS pos_3,
							   CASE WHEN p_pretype = 1 THEN NULLIF(a.beamt - NVL(c.beamt, 0), 0) ELSE a.beamt END AS pos_4,
							   CASE WHEN p_pretype = 1 THEN NULLIF(a.becalcamt - NVL(c.becalcamt, 0), 0) ELSE a.becalcamt END AS pos_5
						FROM   VGT.TT_ACACC0222R_ACC222A a
							   JOIN ACRPTM b
								   ON b.compcode = p_compcode
									  AND b.rptdiv = p_rptdiv
									  AND b.rptyear = p_basisyy
									  AND a.seqline = b.seqline
							   LEFT JOIN VGT.TT_ACACC0222R_ACC222AP c ON b.seqline = c.seqline
							   LEFT JOIN ACRPTM D
								   ON D.compcode = p_compcode
									  AND D.rptdiv = p_rptdiv
									  AND D.rptyear = p_basisyy
									  AND b.remark = D.seqline
						WHERE  D.seqline IS NULL) src
			ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
						AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
						AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
						AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' '))
			WHEN MATCHED
			THEN
				UPDATE SET A.amt = pos_2, A.calcamt = pos_3, A.beamt = pos_4, A.becalcamt = pos_5;

			-- 시작월의 기말재고를 종료월의 기초재고로 설정
			MERGE INTO VGT.TT_ACACC0222R_ACC222A a
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.PRTBOLD,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.CSEQLINE,
							   A.CGB,
							   A.OBJDATADIV,
							   c.amt,
							   c.calcamt,
							   CASE WHEN p_pretype = 1 THEN c.beamt ELSE a.beamt END AS pos_4,
							   CASE WHEN p_pretype = 1 THEN c.becalcamt ELSE a.becalcamt END AS pos_5
						FROM   VGT.TT_ACACC0222R_ACC222A a
							   JOIN ACRPTM b
								   ON b.compcode = p_compcode
									  AND b.rptdiv = p_rptdiv
									  AND b.rptyear = p_basisyy
									  AND a.seqline = b.seqline
									  AND b.seqline <> b.remark
							   JOIN VGT.TT_ACACC0222R_ACC222AP c ON b.remark = c.seqline) src
			ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
						AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
						AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
						AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' '))
			WHEN MATCHED
			THEN
				UPDATE SET A.amt = src.amt, A.calcamt = src.calcamt, A.beamt = pos_4, A.becalcamt = pos_5;
		END IF;

		IF (p_div = 'P')
		THEN
			OPEN IO_CURSOR FOR
				SELECT	 NULLIF(CASE
									WHEN a.lrdiv = 'L'
										 AND a.prtyn = 'Y'
									THEN
										a.amt
								END,
								0)
							 baldramt,
						 NULLIF(CASE
									WHEN a.cgb = '2'
										 AND a.prtyn = 'Y'
									THEN
										a.calcamt
									WHEN a.cgb <> '2'
										 AND a.lrdiv = 'R'
										 AND a.prtyn = 'Y'
									THEN
										a.amt
								END,
								0)
							 dramt,
						 NULL mondramt,
						 CASE WHEN a.amt >= 0 THEN a.accrname ELSE a.acckname END accname,
						 NULL moncramt,
						 NULLIF(CASE
									WHEN a.lrdiv = 'L'
										 AND a.prtyn = 'Y'
									THEN
										a.beamt
								END,
								0)
							 cramt,
						 NULLIF(CASE
									WHEN a.cgb = '2'
										 AND a.prtyn = 'Y'
									THEN
										a.becalcamt
									WHEN a.cgb <> '2'
										 AND a.lrdiv = 'R'
										 AND a.prtyn = 'Y'
									THEN
										a.beamt
								END,
								0)
							 balcramt,
						 a.prtbold,
						 D.session1 || SUBSTR(p_strym, 0, 4) || '년  ' || SUBSTR(p_strym, 6, 2) || '월부터  ' || SUBSTR(p_endym, 6, 2) || '월까지' title1,
						 D.session2 || SUBSTR(p_beyy01, 0, 4) || '년  ' || SUBSTR(CASE WHEN p_pretype = '1' THEN p_strym ELSE p_beyy01 END, 6, 2) || '월부터  ' || SUBSTR(p_beyymm, 6, 2) || '월까지' title2,
						 CASE WHEN p_plantcode = '%' THEN '회사명 : ' || b.compname ELSE '사업장명 : ' || NVL(c.plantfullname, c.plantname) END compname,
						 '(단위 : 원)' prtunit,
						 NULL baldramt2,
						 NULL dramt2,
						 NULL mondramt2,
						 NULL accname2,
						 NULL moncramt2,
						 NULL cramt2,
						 NULL balcramt2
				FROM	 VGT.TT_ACACC0222R_ACC222A a
						 LEFT JOIN CMCOMPM b ON b.compcode = p_compcode
						 LEFT JOIN CMPLANTM c ON c.plantcode = p_plantcode
						 LEFT JOIN (SELECT MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_endym, 0, 4) THEN sseq END) || '기  ') session1,
										   MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_beyymm, 0, 4) THEN sseq END) || '기  ') session2
									FROM   ACSESSION
									WHERE  compcode = p_compcode
										   AND cyear IN (SUBSTR(p_endym, 0, 4), SUBSTR(p_beyymm, 0, 4))) D
							 ON 1 = 1
				WHERE	 a.prtdiv <> 'C'
						 AND (a.amt <> 0
							  OR a.calcamt <> 0
							  OR a.beamt <> 0
							  OR a.becalcamt <> 0
							  OR a.prtdiv = 'A')
				ORDER BY seqline;
		ELSE
			OPEN IO_CURSOR FOR
				SELECT	 CASE WHEN amt >= 0 THEN accrname ELSE acckname END accname,
						 NULLIF(CASE
									WHEN lrdiv = 'L'
										 AND prtyn = 'Y'
									THEN
										amt
								END,
								0)
							 amt1,
						 NULLIF(CASE
									WHEN cgb = '2'
										 AND prtyn = 'Y'
									THEN
										calcamt
									WHEN cgb <> '2'
										 AND lrdiv = 'R'
										 AND prtyn = 'Y'
									THEN
										amt
								END,
								0)
							 amt2,
						 NULLIF(CASE
									WHEN lrdiv = 'L'
										 AND prtyn = 'Y'
									THEN
										beamt
								END,
								0)
							 amt3,
						 NULLIF(CASE
									WHEN cgb = '2'
										 AND prtyn = 'Y'
									THEN
										becalcamt
									WHEN cgb <> '2'
										 AND lrdiv = 'R'
										 AND prtyn = 'Y'
									THEN
										beamt
								END,
								0)
							 amt4,
						 p_plantcode plantcode,
						 p_strym || '-01' strdate,
						 TO_CHAR(LAST_DAY(TO_DATE(p_endym, 'YYYY-MM')), 'YYYY-MM-DD') enddate,
						 acccode,
						 p_closediv closediv,
						 prtbold
				FROM	 VGT.TT_ACACC0222R_ACC222A
				WHERE	 prtdiv <> 'C'
						 AND (amt <> 0
							  OR calcamt <> 0
							  OR beamt <> 0
							  OR becalcamt <> 0
							  OR prtdiv = 'A')
				ORDER BY seqline;
		END IF;
	ELSIF (p_div = 'Y')
	THEN
		OPEN IO_CURSOR FOR
			SELECT *
			FROM   (SELECT	 CASE WHEN cyear = SUBSTR(p_endym, 0, 4) THEN sseq ELSE sseq - cyear + TO_NUMBER(SUBSTR(p_endym, 0, 4)) END sseq,
							 curstrdate
					FROM	 ACSESSION
					WHERE	 compcode = p_compcode
							 AND cyear <= SUBSTR(p_endym, 0, 4)
					ORDER BY cyear DESC)
			WHERE  ROWNUM <= 1;
	END IF;

   <<LAST>>
	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
