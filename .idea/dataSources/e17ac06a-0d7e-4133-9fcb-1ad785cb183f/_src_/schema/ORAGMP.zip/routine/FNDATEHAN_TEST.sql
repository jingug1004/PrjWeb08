CREATE FUNCTION        fnDateHan_Test 
(
  p_gb IN VARCHAR2 DEFAULT 'workdate' ,
  p_string1 IN VARCHAR2 DEFAULT '2004-03-02' ,
  ip_string2 IN VARCHAR2 DEFAULT '2010-05-03' 
)
RETURN VARCHAR2
AS
    p_string2   VARCHAR2(30) := ip_string2;
    p_tostring  VARCHAR2(20);
    p_year11    VARCHAR2(20);
    p_month11   VARCHAR2(20);
    p_day11     VARCHAR2(20); 
    
BEGIN
    
p_tostring := '';
        
        IF (p_string2 IS NULL OR p_string2 = ' ') THEN
            p_string2 :=TO_CHAR(SYSDATE,'YYYY-MM-DD');
        END IF;
        
        
        
        p_tostring := ' ';
        p_year11  := TRUNC((TRUNC(MONTHS_BETWEEN (TO_DATE(p_string2,'YYYY-MM-DD'), p_string1)) -1 ) /12)  ;
        p_month11 := TRUNC(MOD(TRUNC((TRUNC(MONTHS_BETWEEN (TO_DATE(p_string2,'YYYY-MM-DD'), p_string1)) -1 )),12));
        
        p_day11 :='0';
        
        
        IF  (SUBSTR (p_string2,LENGTH(p_string2) -1, LENGTH(p_string2)) < SUBSTR (p_string1,LENGTH(p_string1) -1, LENGTH(p_string1)) ) THEN  
            p_day11 :=    SUBSTR (p_string2,LENGTH(p_string2) -1, LENGTH(p_string2) )
                       +  
                          TO_CHAR(LAST_DAY(p_string1),'DD') 
                       - 
                          SUBSTR(p_string1,LENGTH(p_string1) -1, LENGTH(p_string1) )     
                       +  
                          1;
        ELSE
                                        
            p_day11 :=   SUBSTR (p_string2,LENGTH(p_string2) -1, LENGTH(p_string2) ) 
                       -
                         SUBSTR(p_string1,LENGTH(p_string1) -1, LENGTH(p_string1) )
                       +
                         1 ;  
        END IF; 
         
        IF ( SUBSTR(p_string1,LENGTH(p_string1) -1, LENGTH(p_string1)) <=  SUBSTR (p_string2,LENGTH(p_string2) -1, LENGTH(p_string2) ) ) THEN
            p_month11 := p_month11 + 1;
        
        ELSE
            p_month11 := p_month11;
        
        END IF;    
                    
        IF (TO_CHAR(LAST_DAY(p_string1),'DD') =p_day11 OR  TO_CHAR(LAST_DAY(p_string2),'DD') = p_day11 ) THEN
            p_month11 := p_month11 + 1;
            p_day11 :='0';
        END IF;
        
        IF (p_month11 = '12') THEN
            p_month11 :=0;
            p_year11  := p_year11 +1;
        END IF;
        
        
        IF (p_year11 > 1)  THEN
            p_tostring := p_tostring || p_year11 || '년 ';
        END IF;
        
        IF (p_month11 > 1)  THEN
            p_tostring := p_tostring || p_month11 || '개월 ';
        END IF;
        
        IF (p_day11 > 1)  THEN
            p_tostring := p_tostring || p_day11 || '일';
        END IF;    

        
        RETURN p_tostring;

END;
/
