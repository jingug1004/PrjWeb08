CREATE PROCEDURE        spACacc0188R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0188R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2015-08-14
    -- 수 정 자     : 강현호
    -- E-Mail       : roykang0722@gmail.com
    -- 수정일자      : 2016-12-13
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 외상매입 및 미지급비용현황 쿼리.
	-- ---------------------------------------------------------------
(
    p_div			  IN	 VARCHAR2 DEFAULT '',
    p_compcode		  IN	 VARCHAR2 DEFAULT '',
    p_plantcode 	  IN	 VARCHAR2 DEFAULT '%',
    p_purchaseym	  IN	 VARCHAR2 DEFAULT '',
    p_custcode		  IN	 VARCHAR2 DEFAULT '',
    p_cashamt		  IN	 FLOAT    DEFAULT 0,
    p_billamt		  IN	 FLOAT    DEFAULT 0,
    p_issdate		  IN	 VARCHAR2 DEFAULT '',
    p_expdate		  IN	 VARCHAR2 DEFAULT '',
    p_paycondition	  IN	 VARCHAR2 DEFAULT '',
    p_iempcode		  IN	 VARCHAR2 DEFAULT '',
    p_userid		  IN	 VARCHAR2 DEFAULT '',
    p_reasondiv 	  IN	 VARCHAR2 DEFAULT '',
    p_reasontext	  IN	 VARCHAR2 DEFAULT '',

    MESSAGE           OUT    VARCHAR2,
    IO_CURSOR         OUT    TYPES.DataSet
)
AS

    p_acccode1  VARCHAR2(20);   -- 외상매입금
    p_acccode2  VARCHAR2(20);   -- 미지급금(거래처)
    p_strdate   VARCHAR2(10);
    p_enddate   VARCHAR2(10);

BEGIN

	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    --EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    --INSERT INTO   ATINFO (USERID, REASONDIV, REASONTEXT)
    --VALUES (p_userid, p_reasondiv, p_reasontext);

	IF ( UPPER(p_div) = UPPER('S') ) THEN

        OPEN IO_CURSOR FOR

            SELECT	 a.compcode,
                     a.plantcode,
                     a.purchaseym,
                     ROW_NUMBER() OVER (ORDER BY a.custcode) seqno,
                     a.custcode,
                     b.custname,
                     a.cashamt,
                     a.billamt,
                     a.issdate,
                     a.expdate,
                     a.paycondition
            FROM	 ACPURCHASEPAY a LEFT JOIN CMCUSTM b ON a.custcode = b.custcode
            WHERE	 a.compcode = p_compcode
                     AND a.plantcode LIKE p_plantcode
                     AND a.purchaseym = p_purchaseym
                     AND a.custcode LIKE p_custcode || '%'
            ORDER BY a.custcode;

	ELSIF ( UPPER(p_div) = UPPER('SD') ) THEN

        OPEN IO_CURSOR FOR

            SELECT  CASE WHEN filter2 IS NULL THEN ''
                         ELSE p_purchaseym || '-15' END issdate
                    , CASE WHEN filter2 IS NULL THEN ''
                           ELSE TO_CHAR(ADD_MONTHS(TO_DATE(p_purchaseym || '-15', 'YYYY-MM-DD'), TO_NUMBER(filter2)), 'YYYY-MM-DD')
                    END expdate
            FROM    CMCOMMONM
            WHERE   cmmcode = 'CM44'
                    AND divcode = p_paycondition;

    ELSIF ( UPPER(p_div) = UPPER('I') ) THEN

        INSERT INTO ACPURCHASEPAY(compcode,
                                  plantcode,
                                  purchaseym,
                                  custcode,
                                  cashamt,
                                  billamt,
                                  issdate,
                                  expdate,
                                  paycondition,
                                  insertdt,
                                  iempcode)
            (SELECT p_compcode,
                    p_plantcode,
                    p_purchaseym,
                    p_custcode,
                    p_cashamt,
                    p_billamt,
                    p_issdate,
                    p_expdate,
                    p_paycondition,
                    SYSDATE,
                    p_iempcode
             FROM	DUAL);

    ELSIF ( UPPER(p_div) = UPPER('U') ) THEN

        UPDATE ACPURCHASEPAY a

        SET    a.cashamt = p_cashamt,
               a.billamt = p_billamt,
               a.issdate = p_issdate,
               a.expdate = p_expdate,
               a.paycondition = p_paycondition,
               a.updatedt = SYSDATE,
               a.iempcode = p_iempcode

        WHERE  a.compcode = p_compcode
               AND a.plantcode = p_plantcode
               AND a.purchaseym = p_purchaseym
               AND a.custcode = p_custcode;

    ELSIF ( UPPER(p_div) = UPPER('D') ) THEN

        DELETE ACPURCHASEPAY
        WHERE  compcode = p_compcode
               AND plantcode = p_plantcode
               AND purchaseym = p_purchaseym
               AND custcode = p_custcode;

    ELSIF ( UPPER(p_div) = UPPER('C') ) THEN

        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0188R_ACPURCHASEPAY';

        INSERT INTO VGT.TT_ACACC0188R_ACPURCHASEPAY
            (SELECT *
             FROM	ACPURCHASEPAY
             WHERE	compcode = p_compcode
                    AND plantcode = p_plantcode
                    AND purchaseym = p_purchaseym);

        DELETE ACPURCHASEPAY
        WHERE  compcode = p_compcode
               AND plantcode = p_plantcode
               AND purchaseym = p_purchaseym;

        p_acccode1 := '21010100';

        FOR rec IN (SELECT filter1
                    FROM   CMCOMMONM
                    WHERE  cmmcode = 'AC261'
                           AND divcode = '21010100')
        LOOP
            p_acccode1 := rec.filter1;
        END LOOP;

        p_acccode2 := '21030200';

        FOR rec IN (SELECT filter1
                    FROM   CMCOMMONM
                    WHERE  cmmcode = 'AC261'
                           AND divcode = '21030200')
        LOOP
            p_acccode2 := rec.filter1;
        END LOOP;

        p_strdate := SUBSTR(p_purchaseym, 0, 5) || '01-01';
        p_enddate := TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(p_purchaseym || '-01', 'YYYY-MM-DD'), -1)), 'YYYY-MM-DD');


        -- 1. 거래처별 잔액구하기
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0188R_ACORDSMM3';

        INSERT INTO VGT.TT_ACACC0188R_ACORDSMM3
            (SELECT   a.plantcode, a.custcode, MAX(b.dcdiv) dcdiv, SUM(CASE WHEN b.dcdiv = '1' THEN a.bsdebamt - a.bscreamt ELSE a.bscreamt - a.bsdebamt END) restamt
             FROM	  (SELECT a.plantcode, a.mngcluval custcode, a.bsdebamt, a.bscreamt
                       FROM   ACORDSMM a
                       WHERE  a.compcode = p_compcode
                              AND a.plantcode LIKE p_plantcode
                              AND a.slipym = SUBSTR(p_purchaseym, 0, 5) || '01'
                              AND a.closediv IN ('10', '20')
                              AND a.acccode IN (p_acccode1, p_acccode2)
                              AND a.mngclucode = 'S010'
                              AND a.mngcluval LIKE p_custcode || '%'
                              AND NVL(a.mngcluval, '') IS NOT NULL
                       UNION ALL
                       SELECT a.plantcode, b.mngcluval custcode, a.debamt, a.creamt
                       FROM   ACORDD a
                              JOIN ACORDS b
                                  ON a.compcode = b.compcode
                                     AND a.slipinno = b.slipinno
                                     AND a.slipinseq = b.slipinseq
                                     AND b.mngclucode = 'S010'
                                     AND b.mngcluval LIKE p_custcode || '%'
                                     AND b.mngcluval <> ' '
                              JOIN ACORDM c
                                  ON a.compcode = c.compcode
                                     AND a.slipinno = c.slipinno
                                     AND c.slipdiv <> 'F'
                       WHERE  a.compcode = p_compcode
                              AND a.plantcode LIKE p_plantcode
                              AND a.acccode IN (p_acccode1, p_acccode2)
                              AND a.slipdate BETWEEN p_strdate AND p_enddate) a
                      JOIN ACACCM b ON b.acccode = p_acccode1
             GROUP BY a.plantcode, a.custcode
             HAVING   SUM(CASE WHEN b.dcdiv = '1' THEN a.bsdebamt - a.bscreamt ELSE a.bscreamt - a.bsdebamt END) <> 0);

        INSERT INTO ACPURCHASEPAY(compcode,
                                  plantcode,
                                  purchaseym,
                                  custcode,
                                  cashamt,
                                  billamt,
                                  issdate,
                                  expdate,
                                  paycondition,
                                  insertdt,
                                  iempcode)
            SELECT	 p_compcode,
                     a.plantcode,
                     p_purchaseym,
                     a.custcode,
                     CASE WHEN NVL(TRIM(c.filter2), '') IS NULL THEN a.restamt ELSE 0 END col,
                     CASE WHEN NVL(TRIM(c.filter2), '') IS NOT NULL THEN a.restamt ELSE 0 END col,
                     CASE WHEN NVL(TRIM(c.filter2), '') IS NOT NULL THEN p_purchaseym || '-15' ELSE '' END col,
                     CASE WHEN NVL(TRIM(c.filter2), '') IS NOT NULL THEN TO_CHAR(ADD_MONTHS(TO_DATE(p_purchaseym || '-15', 'YYYY-MM-DD'), TO_NUMBER(filter2)), 'YYYY-MM-DD') ELSE '' END expdate,
                     COALESCE(D.paycondition, b.paydiv, ''),
                     SYSDATE,
                     p_iempcode

            FROM	 VGT.TT_ACACC0188R_ACORDSMM3 a
                     LEFT JOIN CMCUSTM b ON a.custcode = b.custcode
                     LEFT JOIN CMCOMMONM c ON c.cmmcode = 'CM44'
                                              AND b.paydiv = c.divcode
                     LEFT JOIN VGT.TT_ACACC0188R_ACPURCHASEPAY D ON a.custcode = D.custcode

            ORDER BY a.custcode;

    ELSIF ( UPPER(p_div) = UPPER('P') ) THEN

        OPEN IO_CURSOR FOR

            SELECT	 ROW_NUMBER() OVER (ORDER BY a.custcode) seqno,
                     a.custcode,
                     b.custname,
                     a.cashamt,
                     a.billamt,
                     a.issdate,
                     a.expdate,
                     c.divname paycondition,
                     SUBSTR(purchaseym, -2, 2) || '월 ' || '외상매입 및 미지급비용 결제List' title
            FROM	 ACPURCHASEPAY a
                     LEFT JOIN CMCUSTM b ON a.custcode = b.custcode
                     LEFT JOIN CMCOMMONM c ON c.cmmcode = 'CM44'
                                              AND a.paycondition = c.divcode
            WHERE	 a.compcode = p_compcode
                     AND a.plantcode LIKE p_plantcode
                     AND a.purchaseym = p_purchaseym
                     AND a.custcode LIKE p_custcode || '%'

            ORDER BY a.custcode;

	END IF;



    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
