CREATE PROCEDURE        COL_SAL_spSLSALERESULT_N(
    -- ---------------------------------------------------------------
    -- 프로시저명       : [dbo].[spSLSALERESULT_N]
    -- 작 성 자         : 조성희
    -- 작성일자         : 2008-11-13
    -- 수 정 자            : 임정호
    -- 수정일자            : 2017-02-02
    -- 수정내용            : spSLSALEEMPM 를 원본으로 KB-SALE 에 맞게 재구성함.
    -- ---------------------------------------------------------------
    -- 프로시저 설명    : 실마감 작업으로 특정 거래처 잔고을(를) 집계하는 프로시저
    --                        1. 거래처별 월별 잔고            =    [dbo].[SLRESULTM]
    -- ---------------------------------------------------------------


    p_div           IN      VARCHAR2 DEFAULT ''
   ,p_plantcode    IN      VARCHAR2 DEFAULT ''
   ,p_orderdate    IN      VARCHAR2 DEFAULT ''
   ,p_iempcode       IN      VARCHAR2 DEFAULT ''
   ,p_custcode       IN      VARCHAR2 DEFAULT ''
   ,p_ecustcode    IN      VARCHAR2 DEFAULT ''
   ,p_userid       IN      VARCHAR2 DEFAULT ''
   ,p_reasondiv    IN      VARCHAR2 DEFAULT ''
   ,p_reasontext   IN      VARCHAR2 DEFAULT ''
   ,p_deptcode     IN     VARCHAR2 DEFAULT ''       --dy추가
)
AS
    p_get_date            DATE; -- 작업일자              '2013-01-20'
    p_startdate         VARCHAR2(10); -- 작업일자 당월   1일     '2013-01-01'
    p_lastdate            VARCHAR2(10); -- 작업일자 당월  말일      '2013-01-31'
    p_yearmonth         VARCHAR2(7); -- 작업일자 당월          '2013-01'
    p_prevyymm            VARCHAR2(7); -- 작업일자 전월          '2012-12'
    p_nextyymm            VARCHAR2(7); -- 작업일자 다음달         '2013-02'
    ip_deptcode         VARCHAR2(10);

    v_temp                NUMBER(1, 0) := 0;

    user_define_error    EXCEPTION; -- STEP 1
BEGIN

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
         VALUES (p_userid, p_reasondiv, p_reasontext);

    p_get_date := SYSDATE;

    p_startdate := SUBSTR(p_orderdate, 0, 7) || '-01';

    p_lastdate := TO_CHAR(ADD_MONTHS(TO_DATE(p_startdate, 'YYYY-MM-DD'), 1) - 1, 'YYYY-MM-DD');

    p_yearmonth := SUBSTR(p_orderdate, 0, 7);
    p_prevyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_startdate, 'YYYY-MM-DD'), -1), 'YYYY-MM');
    p_nextyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_startdate, 'YYYY-MM-DD'), 1), 'YYYY-MM');

    -- 지난달 마감 정보 추출 ================================================

    EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_SLSALERESULTN_TESTRESULT ';


    INSERT INTO VGT.TT_SLSALERESULTN_TESTRESULT
        (SELECT a.custcode
               ,a.ecustcode
               ,a.orderdiv
               , --영업영역 추가(2013-11-04 : 이세민)
                '1000' plantcode
--                a.plantcode
               ,a.balance
               ,a.balanceetc
               ,a.balanceotc
               ,a.deptcode
               ,a.empcode
               ,a.utdiv
               ,a.edeptcode
               ,a.eempcode
               ,a.eutdiv
           FROM SLRESULTM a
          WHERE a.yearmonth = p_prevyymm
                AND a.custcode = p_custcode
                AND a.ecustcode = p_ecustcode
                AND a.plantcode LIKE p_plantcode);

    -- ======================================================================
    -- 미도래 어음 관련 데이터 추출 =========================================

    EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_SLSALERESULTN_TESTPENDBILL ';


    INSERT INTO VGT.TT_SLSALERESULTN_TESTPENDBILL
        (  SELECT '1000' plantcode
                 ,a.custcode
                 ,a.ecustcode
                 ,a.orderdiv --영업영역 추가(2013-11-04 : 이세민)
                 ,SUM(NVL(a.colamt, 0)) pendbillcol --미도래어음
                 ,SUM(CASE WHEN NVL(a.tasooyn, 'N') = 'N' THEN NVL(a.colamt, 0) ELSE 0 END) pendbillcolj --미도래어음(자수)
                 ,SUM(CASE WHEN NVL(a.tasooyn, 'N') = 'Y' THEN NVL(a.colamt, 0) ELSE 0 END) pendbillcolt --미도래어음(타수)
             FROM SLCOLM a
            WHERE a.appdate < p_lastdate
                  AND a.expdate >= p_lastdate
                  AND a.custcode = p_custcode
                  AND a.ecustcode = p_ecustcode
--                  AND a.plantcode LIKE p_plantcode
                  AND a.coldiv LIKE '3%'
                  AND a.coldiv <> '38' -- 부도어음
                  AND a.statediv = '09' -- 매출확정인 경우에 한함
         GROUP BY a.custcode
                 ,a.ecustcode
                 ,a.orderdiv
--                 ,a.plantcode
                 ); --영업영역 추가(2013-11-04 : 이세민)

    -- ======================================================================
    -- 당월 실적 데이터 추출 ================================================

    EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_SLSALERESULTN_SLRESULT  ';



    INSERT INTO VGT.TT_SLSALERESULTN_SLRESULT
        (  SELECT a.custcode
                 ,a.ecustcode
                 ,a.orderdiv
                 , --영업영역 추가(2013-11-04 : 이세민)
                  a.plantcode
                 ,MAX(a.deptcode) deptcode
                 ,MAX(a.empcode) empcode
                 ,MAX(a.utdiv) utdiv
                 ,MAX(a.edeptcode) edeptcode
                 ,MAX(a.eempcode) eempcode
                 ,MAX(a.eutdiv) eutdiv
                 ,SUM(a.drugamt) drugamt
                 ,SUM(a.salamt) salamt
                 ,SUM(a.salvat) salvat
                 ,SUM(a.totamt) totamt
                 ,SUM(a.returnamt) returnamt
                 ,SUM(a.returnvat) returnvat
                 ,SUM(a.returntotamt) returntotamt
                 ,SUM(a.cashcol) cashcol
                 ,SUM(a.changecol) changecol
                 ,SUM(a.bankcol) bankcol
                 ,SUM(a.cardcol) cardcol
                 ,SUM(a.billcol) billcol
                 ,SUM(a.etccol) etccol
                 ,SUM(a.totcol) totcol
                 ,COUNT(DISTINCT a.colorderno) colcnt
                 ,COUNT(DISTINCT a.salorderno) salcnt
                 ,COUNT(DISTINCT a.banorderno) returncnt
             FROM (SELECT a.custcode
                         ,a.deptcode
                         ,a.empcode
                         ,a.utdiv
                         ,a.orderdiv
                         ,a.ecustcode
                         ,a.edeptcode
                         ,a.eempcode
                         ,a.eutdiv
                         ,'1000' plantcode --a.plantcode
                         ,(CASE WHEN a.saldiv LIKE 'A%' THEN b.drugamt ELSE -b.drugamt END) drugamt
                         ,(CASE WHEN a.saldiv LIKE 'A%' THEN b.salamt ELSE 0 END) salamt
                         ,(CASE WHEN a.saldiv LIKE 'A%' THEN b.salvat ELSE 0 END) salvat
                         ,(CASE WHEN a.saldiv LIKE 'A%' THEN b.totamt ELSE 0 END) totamt
                         ,(CASE WHEN a.saldiv LIKE 'B%' THEN -b.salamt ELSE 0 END) returnamt
                         ,(CASE WHEN a.saldiv LIKE 'B%' THEN -b.salvat ELSE 0 END) returnvat
                         ,(CASE WHEN a.saldiv LIKE 'B%' THEN -b.totamt ELSE 0 END) returntotamt
                         ,0 cashcol
                         ,0 changecol
                         ,0 bankcol
                         ,0 cardcol
                         ,0 billcol
                         ,0 etccol
                         ,0 totcol
                         ,NULL colorderno
                         ,(CASE WHEN a.saldiv LIKE 'A%' THEN a.orderno ELSE NULL END) salorderno
                         ,(CASE WHEN a.saldiv LIKE 'B%' THEN a.orderno ELSE NULL END) banorderno
                     FROM SLORDM a
                          JOIN SLORDD b
                              ON a.orderno = b.orderno
                                 AND a.plantcode = b.plantcode
                    WHERE a.appdate >= p_startdate
                          AND appdate < p_lastdate
                          AND a.custcode = p_custcode
                          AND a.ecustcode = p_ecustcode
--                          AND a.plantcode LIKE p_plantcode
                          AND a.saldiv IN (SELECT divcode FROM SLCONDRESULT) -- 주문은 실적분만
                          AND a.statediv = '09'
                   UNION ALL
                   SELECT a.custcode
                         ,a.deptcode
                         ,a.empcode
                         ,a.utdiv
                         ,a.orderdiv
                         ,a.ecustcode
                         ,a.edeptcode
                         ,a.eempcode
                         ,a.eutdiv
                         ,'1000' --a.plantcode
                         ,0 drugamt
                         ,0 salamt
                         ,0 salvat
                         ,0 totamt
                         ,0 returnamt
                         ,0 returnvat
                         ,0 returntotamt
                         ,(CASE WHEN a.coldiv IN ('01', '02') THEN a.colamt ELSE 0 END) cashcol -- 현금입금,선수금
                         ,(CASE WHEN a.coldiv IN ('XZ') THEN 0 ELSE 0 END) changecol -- 없음
                         ,(CASE WHEN a.coldiv IN ('10') THEN a.colamt ELSE 0 END) bankcol -- 보통예금
                         ,(CASE WHEN a.coldiv IN ('21') THEN a.colamt ELSE 0 END) cardcol -- 신용카드
                         ,(CASE WHEN a.coldiv LIKE '3%' THEN a.colamt ELSE 0 END) billcol -- 어음
                         ,(CASE WHEN M.divcode IS NULL THEN a.colamt ELSE 0 END) etccol -- 기타
                         ,a.colamt totcol
                         ,(CASE WHEN M.divcode IS NOT NULL THEN a.colno ELSE NULL END) colorderno
                         ,NULL salorderno
                         ,NULL banorderno
                     FROM SLCOLM a LEFT JOIN (SELECT divcode FROM SLCONDRESULT) M ON a.coldiv = M.divcode
                    WHERE a.appdate >= p_startdate
                          AND appdate < p_lastdate
                          AND a.custcode = p_custcode
                          AND a.ecustcode = p_ecustcode
--                          AND a.plantcode LIKE p_plantcode
                          AND a.statediv = '09') a
         GROUP BY a.custcode
                 ,a.ecustcode
                 ,a.orderdiv
                 ,a.plantcode
                 );
                 
    -- ====================================================================== dy 추가
    FOR rec IN
            (select deptcode 
               FROM SLRESULTM a
              WHERE a.yearmonth = p_prevyymm
                AND a.custcode = p_custcode
                AND a.ecustcode = p_ecustcode
--                AND a.plantcode LIKE p_plantcode
                AND NOT EXISTS
                        (SELECT b.plantcode
                           FROM SLRESULTM b
                          WHERE b.yearmonth = p_yearmonth
                                AND b.custcode = a.custcode
                                AND b.ecustcode = a.ecustcode
                                AND b.orderdiv = a.orderdiv --영업영역 추가(2013-11-04 : 이세민)
--                                AND b.plantcode = a.plantcode
                                )
         )
         LOOP
            ip_deptcode  := rec.deptcode;
         END LOOP;
                                
    if (ip_deptcode = '') then
        ip_deptcode := p_deptcode;    
    end if;       

    -- ======================================================================
    -- 당월 마감자료가 없는 거래처 등록 =====================================
    INSERT INTO SLRESULTM(
                    yearmonth
                   ,custcode
                   ,ecustcode
                   ,orderdiv
                   ,plantcode
                   ,deptcode
                   ,empcode
                   ,utdiv
                   ,edeptcode
                   ,eempcode
                   ,eutdiv
                   ,balance
                   ,colcnt
                   ,salcnt
                   ,returncnt
                   ,insertdt
                   ,iempcode
                   ,updatedt
                   ,uempcode
                   ,drugamt
                   ,salamt
                   ,salvat
                   ,totamt
                   ,returnamt
                   ,returnvat
                   ,returntotamt
                   ,cashcol
                   ,cardcol
                   ,changecol
                   ,bankcol
                   ,billcol
                   ,etccol
                   ,totcol
                   ,pendbillcol
                   ,pendbillcolj
                   ,pendbillcolt
                   ,turncnt
                   ,turndccnt
                   ,balanceetc
                   ,balanceotc
                )
        (SELECT DISTINCT
                p_yearmonth
               ,a.custcode
               ,a.ecustcode
               ,a.orderdiv
               ,'1000' --a.plantcode
               , --영업영역 추가(2013-11-04 : 이세민)
                --a.deptcode
                ip_deptcode
               ,a.empcode
               ,a.utdiv
               ,a.edeptcode
               ,a.eempcode
               ,a.eutdiv
               ,a.balance
               ,0 colcnt
               ,0 salcnt
               ,0 returncnt
               ,p_get_date insertdt
               ,p_iempcode
               ,p_get_date updatedt
               ,p_iempcode
               ,0 drugamt
               ,0 salamt
               ,0 salvat
               ,0 totamt
               ,0 returnamt
               ,0 returnvat
               ,0 returntotamt
               ,0 cashcol
               ,0 cardcol
               ,0 changecol
               ,0 bankcol
               ,0 billcol
               ,0 etccol
               ,0 totcol
               ,a.pendbillcol
               ,a.pendbillcolj
               ,a.pendbillcolt
               ,0 turncnt
               ,0 turndccnt
               ,0 balanceetc
               ,0 balanceotc
           FROM SLRESULTM a
          WHERE a.yearmonth = p_prevyymm
                AND a.custcode = p_custcode
                AND a.ecustcode = p_ecustcode
--                AND a.plantcode LIKE p_plantcode
                AND NOT EXISTS
                        (SELECT '1000' plantcode --b.plantcode
                           FROM SLRESULTM b
                          WHERE b.yearmonth = p_yearmonth
                                AND b.custcode = a.custcode
                                AND b.ecustcode = a.ecustcode
                                AND b.orderdiv = a.orderdiv --영업영역 추가(2013-11-04 : 이세민)
--                                AND b.plantcode = a.plantcode
                                ));

    -- ======================================================================
    -- 당월신규 거래처 등록 =================================================
    INSERT INTO SLRESULTM(
                    yearmonth
                   ,custcode
                   ,ecustcode
                   ,orderdiv
                   ,plantcode
                   ,deptcode
                   ,empcode
                   ,utdiv
                   ,edeptcode
                   ,eempcode
                   ,eutdiv
                   ,balance
                   ,colcnt
                   ,salcnt
                   ,returncnt
                   ,insertdt
                   ,iempcode
                   ,updatedt
                   ,uempcode
                   ,drugamt
                   ,salamt
                   ,salvat
                   ,totamt
                   ,returnamt
                   ,returnvat
                   ,returntotamt
                   ,cashcol
                   ,cardcol
                   ,changecol
                   ,bankcol
                   ,billcol
                   ,etccol
                   ,totcol
                   ,pendbillcol
                   ,pendbillcolj
                   ,pendbillcolt
                   ,turncnt
                   ,turndccnt
                   ,balanceetc
                   ,balanceotc
                )
        (SELECT DISTINCT
                p_yearmonth yearmonth
               ,a.custcode
               ,a.ecustcode
               ,a.orderdiv
               ,'1000' --a.plantcode
               , --영업영역 추가(2013-11-04 : 이세민)
                a.deptcode
               ,a.empcode
               ,a.utdiv
               ,a.edeptcode
               ,a.eempcode
               ,a.eutdiv
               ,0 balance
               ,0 colcnt
               ,0 salcnt
               ,0 returncnt
               ,p_get_date insertdt
               ,p_iempcode
               ,p_get_date updatedt
               ,p_iempcode
               ,0 drugamt
               ,0 salamt
               ,0 salvat
               ,0 totamt
               ,0 returnamt
               ,0 returnvat
               ,0 returntotamt
               ,0 cashcol
               ,0 cardcol
               ,0 changecol
               ,0 bankcol
               ,0 billcol
               ,0 etccol
               ,0 totcol
               ,0 pendbillcol
               ,0 pendbillcolj
               ,0 pendbillcolt
               ,0 turncnt
               ,0 turndccnt
               ,0 balanceetc
               ,0 balanceotc
           FROM VGT.TT_SLSALERESULTN_SLRESULT a
          WHERE NOT EXISTS
                    (SELECT b.plantcode
                       FROM SLRESULTM b
                      WHERE b.yearmonth = p_yearmonth
                            AND b.custcode = a.custcode
                            AND b.ecustcode = a.ecustcode
                            AND b.orderdiv = a.orderdiv --영업영역 추가(2013-11-04 : 이세민)
--                            AND b.plantcode = a.plantcode
                            ));

    -- ======================================================================
    -- 당월 전체 거래처 잔고 갱신 ===========================================

    MERGE INTO SLRESULTM a
         USING (SELECT 
                       A.PLANTCODE
                      ,A.YEARMONTH
                      ,A.CUSTCODE
                      ,A.ECUSTCODE
                      ,A.ORDERDIV
                      ,A.EMPCODE
                      ,A.EEMPCODE
                      ,NVL(D.balance, 0) + NVL(b.totamt, 0) + NVL(b.returntotamt, 0) - NVL(b.totcol, 0) AS pos_2
                      ,NVL(b.colcnt, 0) AS pos_3
                      ,NVL(b.salcnt, 0) AS pos_4
                      ,NVL(b.returncnt, 0) AS pos_5
                      ,NVL(b.drugamt, 0) AS pos_8
                      ,NVL(b.salamt, 0) AS pos_9
                      ,NVL(b.salvat, 0) AS pos_10
                      ,NVL(b.totamt, 0) AS pos_11
                      ,NVL(b.returnamt, 0) AS pos_12
                      ,NVL(b.returnvat, 0) AS pos_13
                      ,NVL(b.returntotamt, 0) AS pos_14
                      ,NVL(b.cashcol, 0) AS pos_15
                      ,NVL(b.cardcol, 0) AS pos_16
                      ,NVL(b.changecol, 0) AS pos_17
                      ,NVL(b.bankcol, 0) AS pos_18
                      ,NVL(b.billcol, 0) AS pos_19
                      ,NVL(b.etccol, 0) AS pos_20
                      ,NVL(b.totcol, 0) AS pos_21
                      ,NVL(c.pendbillcol, 0) AS pos_22
                      ,NVL(c.pendbillcolj, 0) AS pos_23
                      ,NVL(c.pendbillcolt, 0) AS pos_24
                      ,COALESCE(b.deptcode, D.deptcode, a.deptcode) AS pos_25
                      ,COALESCE(b.empcode, D.empcode, a.empcode) AS pos_26
                      ,COALESCE(b.utdiv, D.utdiv, a.utdiv) AS pos_27
                      ,COALESCE(b.edeptcode, D.edeptcode, a.edeptcode) AS pos_28
                      ,COALESCE(b.eempcode, D.eempcode, a.eempcode) AS pos_29
                      ,COALESCE(b.eutdiv, D.eutdiv, a.eutdiv) AS pos_30
                  FROM SLRESULTM a
                       LEFT JOIN VGT.TT_SLSALERESULTN_SLRESULT b -- 당월실적
                           ON a.custcode = b.custcode
                              AND a.ecustcode = b.ecustcode
                              AND a.orderdiv = b.orderdiv
                              AND a.plantcode = b.plantcode
                       LEFT JOIN VGT.TT_SLSALERESULTN_TESTRESULT -- 전월잔고
                                                                D
                           ON a.custcode = D.custcode
                              AND a.ecustcode = D.ecustcode
                              AND a.orderdiv = D.orderdiv
                              AND a.plantcode = D.plantcode
                       LEFT JOIN VGT.TT_SLSALERESULTN_TESTPENDBILL c -- 당월미도래어음
                           ON a.custcode = c.custcode
                              AND a.ecustcode = c.ecustcode
                              AND a.orderdiv = c.orderdiv
                              AND a.plantcode = c.plantcode
                 WHERE a.yearmonth = p_yearmonth
                       AND a.custcode = p_custcode
                       AND a.ecustcode = p_ecustcode
--                       AND a.plantcode LIKE p_plantcode
                       ) src
            ON (
                A.PLANTCODE = SRC.PLANTCODE
                AND A.YEARMONTH = SRC.YEARMONTH
                AND A.CUSTCODE = SRC.CUSTCODE
                AND A.ECUSTCODE = SRC.ECUSTCODE
                AND A.ORDERDIV = SRC.ORDERDIV --AND A.EMPCODE = SRC.EMPCODE
                                             --AND A.EEMPCODE = SRC.EEMPCODE
               )
    WHEN MATCHED
    THEN
        UPDATE SET a.balance = pos_2
                  ,a.colcnt = pos_3
                  ,a.salcnt = pos_4
                  ,a.returncnt = pos_5
                  ,a.updatedt = p_get_date
                  ,a.uempcode = p_iempcode
                  ,a.drugamt = pos_8
                  ,a.salamt = pos_9
                  ,a.salvat = pos_10
                  ,a.totamt = pos_11
                  ,a.returnamt = pos_12
                  ,a.returnvat = pos_13
                  ,a.returntotamt = pos_14
                  ,a.cashcol = pos_15
                  ,a.cardcol = pos_16
                  ,a.changecol = pos_17
                  ,a.bankcol = pos_18
                  ,a.billcol = pos_19
                  ,a.etccol = pos_20
                  ,a.totcol = pos_21
                  ,a.pendbillcol = pos_22
                  ,a.pendbillcolj = pos_23
                  ,a.pendbillcolt = pos_24
                  ,a.deptcode = pos_25
                  ,a.empcode = pos_26
                  ,a.utdiv = pos_27
                  ,a.edeptcode = pos_28
                  ,a.eempcode = pos_29
                  ,a.eutdiv = pos_30;

    -- ======================================================================
    --마감시 거래처 마스터에 최종판매일, 최종수금일을 업데이트 한다.(2015-10-29:이세민)============================
    MERGE INTO CMCUSTM a
         USING (SELECT '1000' PLANTCODE
                      ,A.CUSTCODE
                      ,b.appdate
                  FROM CMCUSTM a
                       JOIN (  SELECT MAX(appdate) appdate
                                     ,custcode
                                 FROM SLORDM
                                WHERE statediv = '09'
                                      AND SUBSTR(saldiv, 0, 1) <> 'B' --반품제외
                                      AND saldiv IN (SELECT divcode FROM SLCONDRESULT) --실적분만
                             GROUP BY custcode) b
                           ON a.custcode = b.custcode
                 WHERE a.custcode = p_custcode) src
            ON (
--                a.PLANTCODE = src.PLANTCODE
--                AND 
                A.CUSTCODE = src.CUSTCODE)
    WHEN MATCHED
    THEN
        UPDATE SET a.lastsaldate = src.appdate;

    MERGE INTO CMCUSTM a
         USING (SELECT 
--                       A.PLANTCODE
--                      ,
                      A.CUSTCODE
                      ,b.appdate
                  FROM CMCUSTM a
                       JOIN (  SELECT MAX(appdate) appdate
                                     ,custcode
                                 FROM SLCOLM
                                WHERE statediv = '09'
                                      AND coldiv IN (SELECT divcode FROM SLCONDRESULT) --실적분만
                             GROUP BY custcode) b
                           ON a.custcode = b.custcode
                 WHERE a.custcode = p_custcode) src
            ON (
--                a.PLANTCODE = src.PLANTCODE
--                AND 
                A.CUSTCODE = src.CUSTCODE)
    WHEN MATCHED
    THEN
        UPDATE SET a.lastcoldate = src.appdate;


    --================================================================================================================
    
EXCEPTION -- 예외가 발생할 경우 해당 예외를 참조한다.
    WHEN user_define_error
    THEN -- STEP 3
        RAISE_APPLICATION_ERROR(-20000, '거래처가 지정하지 않았거나, ' || p_orderdate || ' 이전일자는 처리할 수 없습니다.');
END;
/
