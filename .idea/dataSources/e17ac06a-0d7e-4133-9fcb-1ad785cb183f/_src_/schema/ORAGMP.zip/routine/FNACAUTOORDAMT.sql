CREATE FUNCTION        fnAcAutoORDamt
-- ---------------------------------------------------------------
 -- 함 수 명			: fnAcAutoORDamt
 -- 작 성 자         : 민승기
 -- 작성일자         : 2010-12-03
 -- ---------------------------------------------------------------
 -- 함수설명			: 회계자동분개 금액정의
 -- ---------------------------------------------------------------

(
  p_amtdiv IN VARCHAR2 DEFAULT ' ' ,
  p_accamtdiv IN VARCHAR2 DEFAULT ' ' ,
  p_acccalcdiv IN VARCHAR2 DEFAULT ' ' ,
  p_accsamtdiv IN VARCHAR2 DEFAULT ' ' ,
  p_trn1amt IN FLOAT DEFAULT NULL ,
  p_trn2amt IN FLOAT DEFAULT NULL ,
  p_trn3amt IN FLOAT DEFAULT NULL ,
  p_trn4amt IN FLOAT DEFAULT NULL ,
  p_trn5amt IN FLOAT DEFAULT NULL ,
  p_trn6amt IN FLOAT DEFAULT NULL ,
  p_trn7amt IN FLOAT DEFAULT NULL ,
  p_trn8amt IN FLOAT DEFAULT NULL ,
  p_trn9amt IN FLOAT DEFAULT NULL ,
  p_trn10amt IN FLOAT DEFAULT NULL ,
  p_trn11amt IN FLOAT DEFAULT NULL ,
  p_trn12amt IN FLOAT DEFAULT NULL ,
  p_trn13amt IN FLOAT DEFAULT NULL ,
  p_trn14amt IN FLOAT DEFAULT NULL ,
  p_trn15amt IN FLOAT DEFAULT NULL ,
  p_trn16amt IN FLOAT DEFAULT NULL ,
  p_trn17amt IN FLOAT DEFAULT NULL ,
  p_trn18amt IN FLOAT DEFAULT NULL ,
  p_trn19amt IN FLOAT DEFAULT NULL ,
  p_trn20amt IN FLOAT DEFAULT NULL ,
  p_trn21amt IN FLOAT DEFAULT NULL ,
  p_trn22amt IN FLOAT DEFAULT NULL ,
  p_trn23amt IN FLOAT DEFAULT NULL ,
  p_trn24amt IN FLOAT DEFAULT NULL ,
  p_trn25amt IN FLOAT DEFAULT NULL ,
  p_trn26amt IN FLOAT DEFAULT NULL ,
  p_trn27amt IN FLOAT DEFAULT NULL ,
  p_trn28amt IN FLOAT DEFAULT NULL ,
  p_trn29amt IN FLOAT DEFAULT NULL ,
  p_trn30amt IN FLOAT DEFAULT NULL 
)
RETURN FLOAT
AS
   p_amt1 FLOAT(53);
   p_amt2 FLOAT(53);
   p_rtn FLOAT(53);

BEGIN
   p_amt1 := CASE p_accamtdiv
                             WHEN '01' THEN NVL(p_trn1amt, 0)
                             WHEN '02' THEN NVL(p_trn2amt, 0)
                             WHEN '03' THEN NVL(p_trn3amt, 0)
                             WHEN '04' THEN NVL(p_trn4amt, 0)
                             WHEN '05' THEN NVL(p_trn5amt, 0)
                             WHEN '06' THEN NVL(p_trn6amt, 0)
                             WHEN '07' THEN NVL(p_trn7amt, 0)
                             WHEN '08' THEN NVL(p_trn8amt, 0)
                             WHEN '09' THEN NVL(p_trn9amt, 0)
                             WHEN '10' THEN NVL(p_trn10amt, 0)
                             WHEN '11' THEN NVL(p_trn11amt, 0)
                             WHEN '12' THEN NVL(p_trn12amt, 0)
                             WHEN '13' THEN NVL(p_trn13amt, 0)
                             WHEN '14' THEN NVL(p_trn14amt, 0)
                             WHEN '15' THEN NVL(p_trn15amt, 0)
                             WHEN '16' THEN NVL(p_trn16amt, 0)
                             WHEN '17' THEN NVL(p_trn17amt, 0)
                             WHEN '18' THEN NVL(p_trn18amt, 0)
                             WHEN '19' THEN NVL(p_trn19amt, 0)
                             WHEN '20' THEN NVL(p_trn20amt, 0)
                             WHEN '21' THEN NVL(p_trn21amt, 0)
                             WHEN '22' THEN NVL(p_trn22amt, 0)
                             WHEN '23' THEN NVL(p_trn23amt, 0)
                             WHEN '24' THEN NVL(p_trn24amt, 0)
                             WHEN '25' THEN NVL(p_trn25amt, 0)
                             WHEN '26' THEN NVL(p_trn26amt, 0)
                             WHEN '27' THEN NVL(p_trn27amt, 0)
                             WHEN '28' THEN NVL(p_trn28amt, 0)
                             WHEN '29' THEN NVL(p_trn29amt, 0)
                             WHEN '30' THEN NVL(p_trn30amt, 0)
   ELSE 0
      END ;
   p_amt2 := CASE p_accsamtdiv
                              WHEN '01' THEN NVL(p_trn1amt, 0)
                              WHEN '02' THEN NVL(p_trn2amt, 0)
                              WHEN '03' THEN NVL(p_trn3amt, 0)
                              WHEN '04' THEN NVL(p_trn4amt, 0)
                              WHEN '05' THEN NVL(p_trn5amt, 0)
                              WHEN '06' THEN NVL(p_trn6amt, 0)
                              WHEN '07' THEN NVL(p_trn7amt, 0)
                              WHEN '08' THEN NVL(p_trn8amt, 0)
                              WHEN '09' THEN NVL(p_trn9amt, 0)
                              WHEN '10' THEN NVL(p_trn10amt, 0)
                              WHEN '11' THEN NVL(p_trn11amt, 0)
                              WHEN '12' THEN NVL(p_trn12amt, 0)
                              WHEN '13' THEN NVL(p_trn13amt, 0)
                              WHEN '14' THEN NVL(p_trn14amt, 0)
                              WHEN '15' THEN NVL(p_trn15amt, 0)
                              WHEN '16' THEN NVL(p_trn16amt, 0)
                              WHEN '17' THEN NVL(p_trn17amt, 0)
                              WHEN '18' THEN NVL(p_trn18amt, 0)
                              WHEN '19' THEN NVL(p_trn19amt, 0)
                              WHEN '20' THEN NVL(p_trn20amt, 0)
                              WHEN '21' THEN NVL(p_trn21amt, 0)
                              WHEN '22' THEN NVL(p_trn22amt, 0)
                              WHEN '23' THEN NVL(p_trn23amt, 0)
                              WHEN '24' THEN NVL(p_trn24amt, 0)
                              WHEN '25' THEN NVL(p_trn25amt, 0)
                              WHEN '26' THEN NVL(p_trn26amt, 0)
                              WHEN '27' THEN NVL(p_trn27amt, 0)
                              WHEN '28' THEN NVL(p_trn28amt, 0)
                              WHEN '29' THEN NVL(p_trn29amt, 0)
                              WHEN '30' THEN NVL(p_trn30amt, 0)
   ELSE 0
      END ;
   p_rtn := CASE p_acccalcdiv
                             WHEN '+' THEN p_amt1 + p_amt2
                             WHEN '-' THEN p_amt1 - p_amt2
   ELSE p_amt1
      END ;
   p_rtn := CASE 
                 WHEN p_amtdiv = '-' THEN -p_rtn
   ELSE p_rtn
      END ;
   RETURN (p_rtn);

END;
/
