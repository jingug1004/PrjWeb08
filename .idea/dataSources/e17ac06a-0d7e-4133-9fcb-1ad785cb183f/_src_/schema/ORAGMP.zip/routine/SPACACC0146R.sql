CREATE PROCEDURE        spACacc0146R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0146R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-10-11
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-20
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 법인카드사용내역서 조회하는 프로시저이다.

	p_div			   IN	  VARCHAR2 DEFAULT '',
	p_compcode		   IN	  VARCHAR2 DEFAULT '',
	p_plantcode 	   IN	  VARCHAR2 DEFAULT '',
	p_cardym		   IN	  VARCHAR2 DEFAULT '',
	p_cardcls		   IN	  VARCHAR2 DEFAULT '',
	p_outputdiv 	   IN	  VARCHAR2 DEFAULT '',
	p_btedeptcodeS1    IN	  VARCHAR2 DEFAULT '',
	p_btedeptcodeS2    IN	  VARCHAR2 DEFAULT '',
	p_userid		   IN	  VARCHAR2 DEFAULT '',
	p_reasondiv 	   IN	  VARCHAR2 DEFAULT '',
	p_reasontext	   IN	  VARCHAR2 DEFAULT '',
	MESSAGE 			  OUT VARCHAR2,
	IO_CURSOR			  OUT TYPES.DATASET
)
AS
	p_odiv		  VARCHAR2(5);
	p_startdate   VARCHAR2(10);
	p_enddate	  VARCHAR2(10);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_outputdiv = '1') THEN
		p_odiv := 'F'; --K-GAAP
	ELSE
		IF (p_outputdiv = '2')
		THEN
			p_odiv := 'K'; --IFRS
		END IF;
	END IF;

	p_startdate := p_cardym || '-01';
	p_enddate := TO_CHAR(ADD_MONTHS(TO_DATE(p_startdate, 'YYYY-MM-DD'), 1) - 1, 'YYYY-MM-DD');

	IF (p_div = 'S') THEN
		OPEN IO_CURSOR FOR
			SELECT	 b.deptcode,
					 NVL(e.deptname, b.deptcode) deptname,
					 c.mngcluval cardno,
					 a.slipdate,
					 a.slipnum,
					 f.empname || '/' || a.remark1 remark,
					 a.creamt,
					 NVL(g.accname, a.acccode) accname
			FROM	 ACORDD a
					 JOIN ACORDM b
						 ON a.compcode = b.compcode
							AND a.slipinno = b.slipinno
							AND b.slipdiv <> p_odiv
					 JOIN ACORDS c
						 ON a.compcode = c.compcode
							AND a.slipinno = c.slipinno
							AND a.slipinseq = c.slipinseq
							AND c.mngclucode = 'S060'
					 LEFT JOIN ACCARDM D ON c.mngcluval = D.cardno
					 LEFT JOIN CMDEPTM e ON b.deptcode = e.deptcode
					 LEFT JOIN CMEMPM f ON b.empcode = f.empcode
					 LEFT JOIN ACACCM g ON a.acccode = g.acccode
			WHERE	 a.compcode = p_compcode
					 AND a.plantcode LIKE p_plantcode
					 AND a.slipdate BETWEEN p_startdate AND p_enddate
					 AND a.creamt <> 0
					 AND (NVL(p_btedeptcodeS1,' ') > ' '
						  AND NVL(b.deptcode,' ') >= NVL(p_btedeptcodeS1,' ')
						  OR TRIM(p_btedeptcodeS1) IS NULL)
					 AND (NVL(p_btedeptcodeS2,' ') > ' '
						  AND b.deptcode <= NVL(p_btedeptcodeS2,' ')
						  OR TRIM(p_btedeptcodeS2) IS NULL)
					 AND NVL(D.cardcls, ' ') LIKE p_cardcls
			ORDER BY b.deptcode, c.mngcluval, a.slipdate, a.slipnum, a.slipinseq;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
