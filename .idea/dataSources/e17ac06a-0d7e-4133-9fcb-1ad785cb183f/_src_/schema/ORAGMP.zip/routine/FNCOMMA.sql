CREATE FUNCTION        fnCOMMA
-- ---------------------------------------------------------------
 -- 함 수 명            : fnDateHan
 -- 작 성 자         : 김  훈
 -- 작성일자         : 2010-04-23
 -- ---------------------------------------------------------------
 -- 함수설명            :    날짜 한글 &&
 --                    :    근무 기간                 
 -- ---------------------------------------------------------------
 --            
 --          select DATEDIFF(month, '2005-06-19', '2010-06-02')

(
  p_num IN VARCHAR2 DEFAULT '' 
)
RETURN VARCHAR2
AS
    p_tostring VARCHAR2(50);

BEGIN
    
    p_tostring := trim(to_char(p_num,'999,999,999,999,999,999,999,999,999'));

    RETURN p_tostring;


EXCEPTION  
    
    WHEN OTHERS THEN
        p_tostring :=' ';      

        
        
    IF p_tostring IS NULL THEN
        p_tostring :='오류';
    END IF;
--EXCEPTION WHEN OTHERS THEN utils.handleerror(SQLCODE,SQLERRM);
END;
/
