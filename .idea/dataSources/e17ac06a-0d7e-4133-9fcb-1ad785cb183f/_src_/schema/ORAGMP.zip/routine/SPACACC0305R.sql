CREATE PROCEDURE        spACacc0305R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0305R
 -- 작 성 자         : 배종성
 -- 작성일자         : 2011-03-21
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-27
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 지급어음명세서를 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_plantcode     IN  VARCHAR2 DEFAULT '' ,
    p_yymm          IN  VARCHAR2 DEFAULT '' ,
    p_viewdiv       IN  VARCHAR2 DEFAULT '' ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_enddate VARCHAR2(10);
BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( p_div = 'S' ) THEN

        -- 부문별
        p_enddate := TO_CHAR(ADD_MONTHS(TO_DATE(p_yymm || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD');

        OPEN  IO_CURSOR FOR
            SELECT  seq ,
                    a.plantcode ,                                       --사업장
                    coldate ,                                           --지급일자
                    NVL(billdiv, '') billdiv ,                                           --어음종류
                    CASE WHEN seq = '1' THEN SL18.divname
                         WHEN seq = '2' THEN SL18.divname || ' 합계'
                         WHEN billdiv = '99' THEN '총합계'
                    END billdivnm  ,
                    a.custcode ,                                        --거래처
                    NVL(b.custname, '') custname  ,
                    billno ,                                            --어음번호
                    expdate ,                                           --만기일자
                    paybank ,                                           --지급지점
                    issempnm ,                                          --발행인
                    billamt                                             --어음금액
            FROM ( SELECT   '1' seq  ,
                            plantcode ,                                 --사업장
                            NVL(coldate, '') coldate ,                 --지급일자
                            NVL(billdiv, '') billdiv ,                                   --어음종류
                            NVL(custcode, '') custcode ,               --거래처
                            billno ,                                    --어음번호
                            expdate ,                                   --만기일자
                            NVL(paybank,  '') paybank ,                 --지급지점
                            NVL(issempnm, '') issempnm ,               --발행인
                            NVL(billamt, 0) billamt                     --어음금액
                    FROM
                            (
                                SELECT  a.compcode ,
                                        a.plantcode ,                                       --사업장
                                        NVL(a.issdate, '') coldate ,                        --지급일자
                                        a.billdiv ,                                         --어음종류
                                        NVL(a.custcode, '') custcode ,                      --거래처
                                        a.billno ,                                          --어음번호
                                        a.expdate ,                                         --만기일자
                                        NVL(b.bankname, '') paybank ,                       --지급지점
                                        NVL(c.compname, '') issempnm ,                      --발행인
                                        NVL(a.billamt, 0) billamt                           --어음금액
                                FROM    ACBILLM a
                                        LEFT JOIN CMBANKM b   ON a.bankcode = b.bankcode
                                        LEFT JOIN CMCOMPM c   ON a.compcode = c.compcode
                                WHERE   a.compcode = p_compcode
                                        AND a.plantcode LIKE p_plantcode
                                        AND a.issdate <= p_enddate
                                        AND p_enddate < a.expdate
                                        AND a.billcls = '2'                                 --지급어음
                            )

                    UNION ALL
                    SELECT  '2' seq  ,
                            '' plantcode ,                             --사업장
                            '' coldate ,                               --지급일자
                            NVL(billdiv, '') billdiv ,                 --어음종류
                            '' custcode ,                              --거래처
                            '' billno ,                                --어음번호
                            '' expdate ,                               --만기일자
                            '' paybank ,                               --지급지점
                            '' issempnm ,                              --발행인
                            SUM(NVL(billamt, 0))  billamt               --어음금액
                    FROM
                            (
                                SELECT  a.compcode ,
                                        a.plantcode ,                                       --사업장
                                        NVL(a.issdate, '') coldate ,                        --지급일자
                                        a.billdiv ,                                         --어음종류
                                        NVL(a.custcode, '') custcode ,                      --거래처
                                        a.billno ,                                          --어음번호
                                        a.expdate ,                                         --만기일자
                                        NVL(b.bankname, '') paybank ,                       --지급지점
                                        NVL(c.compname, '') issempnm ,                      --발행인
                                        NVL(a.billamt, 0) billamt                           --어음금액
                                FROM    ACBILLM a
                                        LEFT JOIN CMBANKM b   ON a.bankcode = b.bankcode
                                        LEFT JOIN CMCOMPM c   ON a.compcode = c.compcode
                                WHERE   a.compcode = p_compcode
                                        AND a.plantcode LIKE p_plantcode
                                        AND a.issdate <= p_enddate
                                        AND p_enddate < a.expdate
                                        AND a.billcls = '2'                                 --지급어음
                            )
                    GROUP BY billdiv
                    UNION ALL
                    SELECT  '3' seq  ,
                            '' plantcode ,                             --사업장
                            '' coldate ,                               --지급일자
                            '99' billdiv ,                              --어음종류
                            '' custcode ,                              --거래처
                            '' billno ,                                --어음번호
                            '' expdate ,                               --만기일자
                            '' paybank ,                               --지급지점
                            '' issempnm ,                              --발행인
                            SUM(NVL(billamt, 0))  billamt               --어음금액
                    FROM
                            (
                                SELECT  a.compcode ,
                                        a.plantcode ,                                       --사업장
                                        NVL(a.issdate, '') coldate ,                        --지급일자
                                        a.billdiv ,                                         --어음종류
                                        NVL(a.custcode, '') custcode ,                      --거래처
                                        a.billno ,                                          --어음번호
                                        a.expdate ,                                         --만기일자
                                        NVL(b.bankname, '') paybank ,                       --지급지점
                                        NVL(c.compname, '') issempnm ,                      --발행인
                                        NVL(a.billamt, 0) billamt                           --어음금액
                                FROM    ACBILLM a
                                        LEFT JOIN CMBANKM b   ON a.bankcode = b.bankcode
                                        LEFT JOIN CMCOMPM c   ON a.compcode = c.compcode
                                WHERE   a.compcode = p_compcode
                                        AND a.plantcode LIKE p_plantcode
                                        AND a.issdate <= p_enddate
                                        AND p_enddate < a.expdate
                                        AND a.billcls = '2'                                 --지급어음
                            )

                    GROUP BY compcode

                    ) a


                LEFT JOIN CMCUSTM b   ON a.custcode = b.custcode
                LEFT JOIN CMCOMMONM SL18   ON SL18.cmmcode = 'SL181'
                                              AND a.billdiv = SL18.divcode

            ORDER BY billdiv, seq, expdate, coldate, billno;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
