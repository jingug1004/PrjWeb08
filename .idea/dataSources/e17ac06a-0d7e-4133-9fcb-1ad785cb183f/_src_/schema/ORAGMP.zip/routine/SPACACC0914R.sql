CREATE PROCEDURE        spACacc0914R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0914R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2016-08-16
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-27
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 일일 종합 내역
	-- ---------------------------------------------------------------


	p_div			IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_enddate		IN	   VARCHAR2 DEFAULT '',
	p_amtunit		IN	   VARCHAR2 DEFAULT '7',
	p_deptname		IN	   VARCHAR2 DEFAULT '',
	p_itemcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET,
	IO_CURSOR2		   OUT TYPES.DATASET,
	IO_CURSOR3		   OUT TYPES.DATASET,
	IO_CURSOR4		   OUT TYPES.DATASET,
	IO_CURSOR5		   OUT TYPES.DATASET
)
AS
	p_strdate	 VARCHAR2(10);
	p_dividamt	 NUMBER(10);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	p_strdate := SUBSTR(p_enddate, 0, 4) || '-01-01';

	FOR rec IN (SELECT filter2
				FROM   CMCOMMONM
				WHERE  cmmcode = 'SL40'
					   AND divcode = p_amtunit)
	LOOP
		p_dividamt := rec.filter2;
	END LOOP;


	IF (p_div = 'S1')
	THEN
		OPEN IO_CURSOR FOR
			SELECT	 CASE WHEN A.deptcode BETWEEN '1301' AND '1399' THEN A.deptcode ELSE '1999' END deptcode, MAX(CASE WHEN A.deptcode BETWEEN '1301' AND '1399' THEN b.deptname ELSE '기타' END) deptname, SUM(A.salamt) / p_dividamt salamt, SUM(A.colamt) / p_dividamt colamt
			FROM	 (SELECT c.deptcode, A.salamt, 0 colamt
					  FROM	 SLTAXM A
							 LEFT JOIN CMCUSTM b ON A.custcode = b.custcode
							 LEFT JOIN CMEMPM c ON b.empcode = c.empcode
					  WHERE  A.plantcode = p_plantcode
							 AND A.taxdt BETWEEN p_strdate AND p_enddate
					  UNION ALL
					  SELECT D.deptcode, CASE WHEN A.saldiv LIKE 'A%' THEN b.salamt ELSE -b.salamt END salamt, 0 colamt
					  FROM	 SLORDM A
							 JOIN SLORDD b ON A.orderno = b.orderno
							 LEFT JOIN CMCUSTM c ON A.custcode = c.custcode
							 LEFT JOIN CMEMPM D ON c.empcode = D.empcode
							 LEFT JOIN (SELECT DISTINCT SUBSTR(taxdt, 0, 7) taxym
										FROM   SLTAXM
										WHERE  plantcode = p_plantcode
											   AND taxdt BETWEEN p_strdate AND p_enddate) E
								 ON SUBSTR(A.appdate, 0, 7) = E.taxym
					  WHERE  A.plantcode = p_plantcode
							 AND A.appdate BETWEEN p_strdate AND p_enddate
							 AND A.statediv = '09'
							 AND E.taxym IS NULL
					  UNION ALL
					  SELECT c.deptcode, 0 salamt, A.colamt
					  FROM	 SLCOLM A
							 LEFT JOIN CMCUSTM b ON A.custcode = b.custcode
							 LEFT JOIN CMEMPM c ON b.empcode = c.empcode
					  WHERE  A.plantcode = p_plantcode
							 AND A.appdate BETWEEN p_strdate AND p_enddate
							 AND A.statediv = '09') A
					 LEFT JOIN CMDEPTM b ON A.deptcode = b.deptcode
			GROUP BY CASE WHEN A.deptcode BETWEEN '1301' AND '1399' THEN A.deptcode ELSE '1999' END
			HAVING	 SUM(A.salamt) <> 0
					 OR SUM(A.colamt) <> 0
			ORDER BY deptcode;

		OPEN IO_CURSOR2 FOR
			SELECT SUM(A.salamt) salamt, SUM(A.colamt) colamt
			FROM   (SELECT A.salamt, 0 colamt
					FROM   SLTAXM A
					WHERE  A.plantcode = p_plantcode
						   AND A.taxdt BETWEEN p_strdate AND p_enddate
					UNION ALL
					SELECT CASE WHEN A.saldiv LIKE 'A%' THEN b.salamt ELSE -b.salamt END salamt, 0 colamt
					FROM   SLORDM A
						   JOIN SLORDD b ON A.orderno = b.orderno
						   LEFT JOIN (SELECT DISTINCT SUBSTR(taxdt, 0, 7) taxym
									  FROM	 SLTAXM
									  WHERE  plantcode = p_plantcode
											 AND taxdt BETWEEN p_strdate AND p_enddate) c
							   ON SUBSTR(A.appdate, 0, 7) = c.taxym
					WHERE  A.plantcode = p_plantcode
						   AND A.appdate BETWEEN p_strdate AND p_enddate
						   AND A.statediv = '09'
						   AND c.taxym IS NULL
					UNION ALL
					SELECT 0 salamt, A.colamt
					FROM   SLCOLM A
					WHERE  A.plantcode = p_plantcode
						   AND A.appdate BETWEEN p_strdate AND p_enddate
						   AND A.statediv = '09') A;

		OPEN IO_CURSOR3 FOR
			SELECT itemcode, itemname, salamt
			FROM   (SELECT	 A.itemcode, A.itemcode || ':' || MAX(b.itemname) itemname, SUM(A.salamt) / p_dividamt salamt
					FROM	 (SELECT b.itemcode, b.salamt
							  FROM	 SLTAXM A JOIN SLTAXD b ON A.taxno = b.taxno
							  WHERE  A.plantcode = p_plantcode
									 AND A.taxdt BETWEEN p_strdate AND p_enddate
							  UNION ALL
							  SELECT b.itemcode, CASE WHEN A.saldiv LIKE 'A%' THEN b.salamt ELSE -b.salamt END salamt
							  FROM	 SLORDM A
									 JOIN SLORDD b ON A.orderno = b.orderno
									 LEFT JOIN (SELECT DISTINCT SUBSTR(taxdt, 0, 7) taxym
												FROM   SLTAXM
												WHERE  plantcode = p_plantcode
													   AND taxdt BETWEEN p_strdate AND p_enddate) c
										 ON SUBSTR(A.appdate, 0, 7) = c.taxym
							  WHERE  A.plantcode = p_plantcode
									 AND A.appdate BETWEEN p_strdate AND p_enddate
									 AND A.statediv = '09'
									 AND c.taxym IS NULL) A
							 LEFT JOIN CMITEMM b ON A.itemcode = b.itemcode
					GROUP BY A.itemcode
					HAVING	 SUM(A.salamt) <> 0
					ORDER BY salamt DESC)
			WHERE  ROWNUM <= 10;
	ELSIF (p_div = 'S1_1')
	THEN
		OPEN IO_CURSOR FOR
			SELECT	 SUBSTR(A.saleym, -2, 2) || '월' saleym, SUM(A.salamt) / p_dividamt salamt, SUM(A.colamt) / p_dividamt colamt
			FROM	 (SELECT SUBSTR(A.taxdt, 0, 7) saleym, c.deptcode, A.salamt, 0 colamt
					  FROM	 SLTAXM A
							 LEFT JOIN CMCUSTM b ON A.custcode = b.custcode
							 LEFT JOIN CMEMPM c ON b.empcode = c.empcode
					  WHERE  A.plantcode = p_plantcode
							 AND A.taxdt BETWEEN p_strdate AND p_enddate
					  UNION ALL
					  SELECT SUBSTR(A.appdate, 0, 7) saleym, D.deptcode, CASE WHEN A.saldiv LIKE 'A%' THEN b.salamt ELSE -b.salamt END salamt, 0 colamt
					  FROM	 SLORDM A
							 JOIN SLORDD b ON A.orderno = b.orderno
							 LEFT JOIN CMCUSTM c ON A.custcode = c.custcode
							 LEFT JOIN CMEMPM D ON c.empcode = D.empcode
							 LEFT JOIN (SELECT DISTINCT SUBSTR(taxdt, 0, 7) taxym
										FROM   SLTAXM
										WHERE  plantcode = p_plantcode
											   AND taxdt BETWEEN p_strdate AND p_enddate) E
								 ON SUBSTR(A.appdate, 0, 7) = E.taxym
					  WHERE  A.plantcode = p_plantcode
							 AND A.appdate BETWEEN p_strdate AND p_enddate
							 AND A.statediv = '09'
							 AND E.taxym IS NULL
					  UNION ALL
					  SELECT SUBSTR(A.appdate, 0, 7) saleym, c.deptcode, 0 salamt, A.colamt
					  FROM	 SLCOLM A
							 LEFT JOIN CMCUSTM b ON A.custcode = b.custcode
							 LEFT JOIN CMEMPM c ON b.empcode = c.empcode
					  WHERE  A.plantcode = p_plantcode
							 AND A.appdate BETWEEN p_strdate AND p_enddate
							 AND A.statediv = '09') A
					 LEFT JOIN CMDEPTM b ON A.deptcode = b.deptcode
			WHERE	 NVL(p_deptname, ' ') = '기타'
					 AND NOT (A.deptcode BETWEEN '1301' AND '1399')
					 OR b.deptname = NVL(p_deptname, ' ')
			GROUP BY saleym
			ORDER BY saleym;
	ELSIF (p_div = 'S1_2')
	THEN
		OPEN IO_CURSOR FOR
			SELECT	 SUBSTR(A.saleym, -2, 2) || '월' saleym, SUM(A.salamt) / p_dividamt salamt
			FROM	 (SELECT SUBSTR(A.taxdt, 0, 7) saleym, b.salamt
					  FROM	 SLTAXM A JOIN SLTAXD b ON A.taxno = b.taxno
					  WHERE  A.plantcode = p_plantcode
							 AND A.taxdt BETWEEN p_strdate AND p_enddate
							 AND b.itemcode = NVL(p_itemcode, ' ')
					  UNION ALL
					  SELECT SUBSTR(A.appdate, 0, 7) saleym, CASE WHEN A.saldiv LIKE 'A%' THEN b.salamt ELSE -b.salamt END salamt
					  FROM	 SLORDM A
							 JOIN SLORDD b ON A.orderno = b.orderno
							 LEFT JOIN (SELECT DISTINCT SUBSTR(taxdt, 0, 7) taxym
										FROM   SLTAXM
										WHERE  plantcode = p_plantcode
											   AND taxdt BETWEEN p_strdate AND p_enddate) c
								 ON SUBSTR(A.appdate, 0, 7) = c.taxym
					  WHERE  A.plantcode = p_plantcode
							 AND A.appdate BETWEEN p_strdate AND p_enddate
							 AND A.statediv = '09'
							 AND c.taxym IS NULL
							 AND b.itemcode = NVL(p_itemcode, ' ')) A
			GROUP BY saleym
			ORDER BY saleym;
	ELSIF (p_div = 'S2')
	THEN
		DECLARE
			p_predate	VARCHAR2(10) := TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -12), 'YYYY-MM-DD');
		BEGIN
			EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0914R_PDMAKINGORDERSM';

			INSERT INTO VGT.TT_ACACC0914R_PDMAKINGORDERSM
				(SELECT divcode "코드",
						divname "제형",
						0 y1,
						0 y2,
						0 "차이",
						0 "성장율"
				 FROM	CMCOMMONM
				 WHERE	cmmcode = 'CM25');

			FOR REC IN(
                SELECT	 COUNT(x.lotno) y1,
                         Y.formdiv
                FROM	 PDMAKINGORDERSM x
                         JOIN CMITEMM Y
                             ON x.itemcode = Y.itemcode
                                AND x.lotdate BETWEEN SUBSTR(p_predate, 0, 4) || '-01-01' AND p_predate
                GROUP BY Y.formdiv                         
            )
            LOOP
                UPDATE VGT.TT_ACACC0914R_PDMAKINGORDERSM A
                SET    A.y1 = rec.y1
                WHERE  rec.formdiv = A.코드;
            END LOOP;

			UPDATE VGT.TT_ACACC0914R_PDMAKINGORDERSM A
			SET    A.차이 = y2 - y1;

			UPDATE VGT.TT_ACACC0914R_PDMAKINGORDERSM A
			SET    A.성장율 = CASE WHEN y1 = 0 THEN 0 ELSE FLOOR((y2 - y1 + 0.0) / y1 * 10000.0) / 100.0 END;

			OPEN IO_CURSOR FOR
				SELECT	 *
				FROM	 VGT.TT_ACACC0914R_PDMAKINGORDERSM
				ORDER BY 코드;


			EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0914R_PDMAKINGORDERSM2';

			INSERT INTO VGT.TT_ACACC0914R_PDMAKINGORDERSM2
				(SELECT divcode "코드", divname "제형", TO_NUMBER(0) y1
				 FROM	CMCOMMONM
				 WHERE	cmmcode = 'CM25');

--			FOR REC IN(
--                SELECT COUNT(x.lotno) y1,
--                       Y.formdiv
--                FROM   PDMAKINGORDERSM x
--                       JOIN CMITEMM Y
--                           ON x.itemcode = Y.itemcode
--                              AND x.lotdate BETWEEN SUBSTR(p_enddate, 0, 4) || '-01-01' AND p_enddate
--                GROUP BY  Y.formdiv
--            )
--            LOOP
--                UPDATE VGT.TT_ACACC0914R_PDMAKINGORDERSM2 A
--                SET    A.y1 = rec.y1
--                WHERE  A.코드=rec.formdiv;
--            END LOOP;


            FOR REC IN 
            (
                SELECT A.코드, NVL(B.CNT,0) LOTNO_CNT
                FROM   VGT.TT_ACACC0914R_PDMAKINGORDERSM2 A,
                       ( 
                        SELECT  y.formdiv, COUNT(x.lotno) CNT
                        FROM    PDMAKINGORDERSM x
                                JOIN CMITEMM y
                                    ON x.itemcode = y.itemcode
                        WHERE  x.lotdate BETWEEN SUBSTR(p_enddate, 1, 4) || '-01-01' AND p_enddate
                        GROUP BY y.formdiv
                       ) B
                WHERE  A.코드 = B.formdiv(+)        
            )
            LOOP
                UPDATE VGT.TT_ACACC0914R_PDMAKINGORDERSM2
                   SET y1 = rec.LOTNO_CNT 
                WHERE  코드 = rec.코드;
            END LOOP;


			OPEN IO_CURSOR2 FOR
				SELECT	 제형 Argument, y1 "Value"
				FROM	 VGT.TT_ACACC0914R_PDMAKINGORDERSM2
				ORDER BY y1 DESC;
		END;
	ELSIF (p_div = 'S3')
	THEN
		DECLARE
			p_compcode	 VARCHAR2(3);
			p_rptdiv	 VARCHAR2(10) := '1';
			p_closediv	 VARCHAR2(10) := '1';
			p_basisym	 VARCHAR2(7);
			p_basisyy	 VARCHAR2(4);
			p_yyyy01	 VARCHAR2(7);
			p_cashcode	 VARCHAR2(20);
			-- 임시테이블의 calcseq의 최대값을 조회
			p_maxseq	 NUMBER(10, 0);
			p_curseq	 NUMBER(10, 0);
		BEGIN
			FOR rec IN (SELECT compcode
						FROM   CMPLANTM
						WHERE  plantcode = p_plantcode)
			LOOP
				p_compcode := rec.compcode;
			END LOOP;

			-- 기간 설정
			p_basisym := SUBSTR(p_enddate, 0, 7);
			p_yyyy01 := SUBSTR(p_basisym, 0, 4) || '-01';

			FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
						FROM   ACSESSION
						WHERE  compcode = p_compcode
							   AND cyear <= SUBSTR(p_basisym, 0, 4))
			LOOP
				p_yyyy01 := rec.alias1;
			END LOOP;

			IF SUBSTR(p_basisym, -2, 2) < SUBSTR(p_yyyy01, -2, 2)
			THEN
				p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), -12), 'YYYY-') || SUBSTR(p_yyyy01, -2, 2);
			ELSE
				p_yyyy01 := SUBSTR(p_basisym, 0, 5) || SUBSTR(p_yyyy01, -2, 2);
			END IF;

			p_cashcode := '11101010';

			FOR rec IN (SELECT value1
						FROM   SYSPARAMETERMANAGE
						WHERE  parametercode = 'acccashcode')
			LOOP
				p_cashcode := rec.value1;
			END LOOP;

			-- 보고서 조회년도 설정
			FOR rec IN (SELECT MAX(rptyear) AS alias1
						FROM   ACRPTM
						WHERE  compcode = p_compcode
							   AND rptdiv = p_rptdiv
							   AND rptyear <= SUBSTR(p_basisym, 0, 4))
			LOOP
				p_basisyy := rec.alias1;
			END LOOP;

			EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0914R_ACC202';

			-- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
			INSERT INTO VGT.TT_ACACC0914R_ACC202(seqline,
												 acccode,
												 accrname,
												 acckname,
												 lrdiv,
												 prtyn,
												 prtdiv,
												 prtbold,
												 sseqline,
												 calcseq,
												 calcdiv,
												 dcdiv,
												 objdatadiv,
												 mondramt,
												 moncramt,
												 dramt,
												 cramt,
												 baldramt,
												 balcramt)
				SELECT	 seqline,
						 acccode,
						 accrname,
						 acckname,
						 lrdiv,
						 prtyn,
						 prtdiv,
						 prtbold,
						 sseqline,
						 calcseq,
						 calcdiv,
						 dcdiv,
						 objdatadiv,
						 NVL(mondramt, 0) mondramt,
						 NVL(moncramt, 0) moncramt,
						 NVL(dramt, 0) dramt,
						 NVL(cramt, 0) cramt,
						 NVL(CASE
								 WHEN lrdiv = 'A' AND dcdiv = '1' OR lrdiv = 'L' THEN
									 CASE WHEN dcdiv = '1' THEN NVL(dramt, 0) - NVL(cramt, 0) ELSE NVL(cramt, 0) - NVL(dramt, 0) END
							 END,
							 0)
							 baldramt,
						 NVL(CASE
								 WHEN lrdiv = 'A'
									  AND dcdiv = '2'
									  OR lrdiv = 'R'
								 THEN
									 CASE WHEN dcdiv = '2' THEN NVL(cramt, 0) - NVL(dramt, 0) ELSE NVL(dramt, 0) - NVL(cramt, 0) END
							 END,
							 0)
							 balcramt
				FROM	 (SELECT   A.seqline,
								   MAX(A.acccode) acccode,
								   MAX(A.accrname) accrname,
								   MAX(A.acckname) acckname,
								   MAX(A.lrdiv) lrdiv,
								   MAX(A.prtyn) prtyn,
								   MAX(A.prtdiv) prtdiv,
								   MAX(A.prtbold) prtbold,
								   MAX(A.sseqline) sseqline,
								   MAX(A.calcseq) calcseq,
								   MAX(A.calcdiv) calcdiv,
								   MAX(b.dcdiv) dcdiv,
								   MAX(A.objdatadiv) objdatadiv,
								   SUM(CASE WHEN A.objdatadiv IN ('D', 'F', 'J') THEN debamt END) mondramt,
								   SUM(CASE WHEN A.objdatadiv IN ('C', 'E', 'J') THEN creamt END) moncramt,
								   SUM(CASE WHEN A.objdatadiv IN ('D', 'F', 'J') THEN totdebamt END) dramt,
								   SUM(CASE WHEN A.objdatadiv IN ('C', 'E', 'J') THEN totcreamt END) cramt
						  FROM	   ACRPTM A
								   LEFT JOIN ACACCM b ON A.acccode = b.acccode
								   LEFT JOIN (SELECT   p_compcode compcode,
													   p_plantcode plantcode,
													   p_basisym slipym,
													   CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
													   acccode,
													   SUM(debamt) debamt,
													   SUM(creamt) creamt,
													   SUM(totdebamt) totdebamt,
													   SUM(totcreamt) totcreamt
											  FROM	   (SELECT b.acccode, CASE WHEN SUBSTR(A.slipdate, 0, 7) = p_basisym THEN b.debamt ELSE 0 END debamt, CASE WHEN SUBSTR(A.slipdate, 0, 7) = p_basisym THEN b.creamt ELSE 0 END creamt, b.debamt totdebamt, b.creamt totcreamt
														FROM   ACORDM A
															   JOIN ACORDD b
																   ON A.compcode = b.compcode
																	  AND A.slipinno = b.slipinno
														WHERE  A.compcode = p_compcode
															   AND A.plantcode LIKE p_plantcode
															   AND A.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') + 1, 'YYYYMMDD')
															   AND A.slipinstate = '4'
															   AND (A.slipdiv NOT IN ('K', 'F')
																	OR p_closediv = '1'
																	   AND A.slipdiv = 'K'
																	OR p_closediv = '2'
																	   AND A.slipdiv = 'F')
														UNION ALL
														SELECT p_cashcode acccode, CASE WHEN SUBSTR(A.slipdate, 0, 7) = p_basisym THEN b.creamt ELSE 0 END debamt, CASE WHEN SUBSTR(A.slipdate, 0, 7) = p_basisym THEN b.debamt ELSE 0 END creamt, b.creamt totdebamt, b.debamt totcreamt
														FROM   ACORDM A
															   JOIN ACORDD b
																   ON A.compcode = b.compcode
																	  AND A.slipinno = b.slipinno
																	  AND b.dcdiv IN ('3', '4')
														WHERE  A.compcode = p_compcode
															   AND A.plantcode LIKE p_plantcode
															   AND A.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') + 1, 'YYYYMMDD')
															   AND A.slipinstate = '4'
															   AND (A.slipdiv NOT IN ('K', 'F')
																	OR p_closediv = '1'
																	   AND A.slipdiv = 'K'
																	OR p_closediv = '2'
																	   AND A.slipdiv = 'F')
														UNION ALL
														SELECT acccode, 0 debamt, 0 creamt, bsdebamt totdebamt, bscreamt totcreamt
														FROM   ACORDDMM
														WHERE  compcode = p_compcode
															   AND plantcode LIKE p_plantcode
															   AND slipym = p_yyyy01
															   AND (p_closediv = '1'
																	AND closediv IN ('10', '20')
																	OR p_closediv = '2'
																	   AND closediv IN ('10', '30'))) A
											  GROUP BY acccode) c -- 전표에서 월집계 임시파일을 생성
									   ON A.compcode = c.compcode
										  AND c.plantcode LIKE p_plantcode
										  AND c.slipym = p_basisym
										  AND (p_closediv = '1'
											   AND c.closediv IN ('10', '20')
											   OR p_closediv = '2'
												  AND c.closediv IN ('10', '30'))
										  AND A.acccode = c.acccode
						  WHERE    A.compcode = p_compcode
								   AND A.rptdiv = p_rptdiv
								   AND A.rptyear = p_basisyy
								   AND A.useyn = 'Y'
						  GROUP BY A.seqline) A
				ORDER BY A.seqline;

			-- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
			MERGE INTO VGT.TT_ACACC0914R_ACC202 A
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.PRTBOLD,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.DCDIV,
							   A.OBJDATADIV,
							   A.MONDRAMT,
							   A.MONCRAMT,
							   CASE WHEN A.objdatadiv = 'A' THEN b.dramt ELSE A.dramt - b.dramt END AS pos_2,
							   CASE WHEN A.objdatadiv = 'A' THEN b.cramt ELSE A.cramt - b.cramt END AS pos_3,
							   CASE WHEN A.objdatadiv = 'A' THEN b.baldramt ELSE A.baldramt - b.baldramt END AS pos_4,
							   CASE WHEN A.objdatadiv = 'A' THEN b.balcramt ELSE A.balcramt - b.balcramt END AS pos_5
						FROM   VGT.TT_ACACC0914R_ACC202 A
							   JOIN (SELECT A.seqline,
											NVL(A.dramt, 0) dramt,
											NVL(A.cramt, 0) cramt,
											NVL(CASE
													WHEN A.lrdiv = 'A'
														 AND A.dcdiv = '1'
														 OR A.lrdiv = 'L'
													THEN
														CASE WHEN A.dcdiv = '1' THEN NVL(A.dramt, 0) - NVL(A.cramt, 0) ELSE NVL(A.cramt, 0) - NVL(A.dramt, 0) END
												END,
												0)
												baldramt,
											NVL(CASE
													WHEN A.lrdiv = 'A'
														 AND A.dcdiv = '2'
														 OR A.lrdiv = 'R'
													THEN
														CASE WHEN A.dcdiv = '2' THEN NVL(A.cramt, 0) - NVL(A.dramt, 0) ELSE NVL(A.dramt, 0) - NVL(A.cramt, 0) END
												END,
												0)
												balcramt
									 FROM	(SELECT   A.seqline, MAX(A.lrdiv) lrdiv, MAX(b.dcdiv) dcdiv, SUM(CASE WHEN A.objdatadiv IN ('A', 'F') THEN bsdebamt END) dramt, SUM(CASE WHEN A.objdatadiv IN ('A', 'E') THEN bscreamt END) cramt
											 FROM	  ACRPTM A
													  LEFT JOIN ACACCM b ON A.acccode = b.acccode
													  LEFT JOIN ACORDDMM c
														  ON A.compcode = c.compcode
															 AND c.plantcode LIKE p_plantcode
															 AND c.slipym = p_yyyy01
															 AND (p_closediv = '1'
																  AND c.closediv IN ('10', '20')
																  OR p_closediv = '2'
																	 AND c.closediv IN ('10', '30'))
															 AND A.acccode = c.acccode
											 WHERE	  A.compcode = p_compcode
													  AND A.rptdiv = p_rptdiv
													  AND A.rptyear = p_basisyy
													  AND A.useyn = 'Y'
													  AND A.objdatadiv IN ('A', 'E', 'F')
											 GROUP BY A.seqline) A) b
								   ON A.seqline = b.seqline) src
			ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
						AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(A.DCDIV, ' ') = NVL(SRC.DCDIV, ' ')
						AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
						AND NVL(A.MONDRAMT, 0) = NVL(SRC.MONDRAMT, 0)
						AND NVL(A.MONCRAMT, 0) = NVL(SRC.MONCRAMT, 0))
			WHEN MATCHED
			THEN
				UPDATE SET A.dramt = SRC.pos_2, A.cramt = SRC.pos_3, A.baldramt = SRC.pos_4, A.balcramt = SRC.pos_5;

			p_curseq := 0;

			FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0914R_ACC202)
			LOOP
				p_maxseq := rec.alias1;
			END LOOP;

			-- 각 레벨별로 sum을하여 update
			WHILE p_curseq <= p_maxseq
			LOOP
				MERGE INTO VGT.TT_ACACC0914R_ACC202 A
				USING	   (SELECT A.SEQLINE,
								   A.ACCCODE,
								   A.ACCRNAME,
								   A.ACCKNAME,
								   A.LRDIV,
								   A.PRTYN,
								   A.PRTDIV,
								   A.PRTBOLD,
								   A.SSEQLINE,
								   A.CALCSEQ,
								   A.CALCDIV,
								   A.DCDIV,
								   A.OBJDATADIV,
								   A.mondramt + b.mondramt AS pos_2,
								   A.moncramt + b.moncramt AS pos_3,
								   A.dramt + b.dramt AS pos_4,
								   A.cramt + b.cramt AS pos_5,
								   A.baldramt + b.baldramt AS pos_6,
								   A.balcramt + b.balcramt AS pos_7
							FROM   VGT.TT_ACACC0914R_ACC202 A
								   JOIN (SELECT   sseqline,
												  SUM(CASE WHEN calcdiv = '+' THEN mondramt ELSE -mondramt END) mondramt,
												  SUM(CASE WHEN calcdiv = '+' THEN moncramt ELSE -moncramt END) moncramt,
												  SUM(CASE WHEN calcdiv = '+' THEN dramt ELSE -dramt END) dramt,
												  SUM(CASE WHEN calcdiv = '+' THEN cramt ELSE -cramt END) cramt,
												  SUM(CASE WHEN calcdiv = '+' THEN baldramt ELSE -baldramt END) baldramt,
												  SUM(CASE WHEN calcdiv = '+' THEN balcramt ELSE -balcramt END) balcramt
										 FROM	  VGT.TT_ACACC0914R_ACC202
										 WHERE	  calcseq = p_curseq
												  AND TRIM(sseqline) IS NOT NULL
										 GROUP BY sseqline) b
									   ON A.seqline = b.sseqline) src
				ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
							AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
							AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
							AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
							AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
							AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
							AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
							AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
							AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
							AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
							AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
							AND NVL(A.DCDIV, ' ') = NVL(SRC.DCDIV, ' ')
							AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' '))
				WHEN MATCHED
				THEN
					UPDATE SET A.mondramt = SRC.pos_2,
							   A.moncramt = SRC.pos_3,
							   A.dramt = SRC.pos_4,
							   A.cramt = SRC.pos_5,
							   A.baldramt = SRC.pos_6,
							   A.balcramt = SRC.pos_7;

				p_curseq := p_curseq + 1;
			END LOOP;

			UPDATE VGT.TT_ACACC0914R_ACC202
			SET    mondramt = ROUND(mondramt / p_dividamt, 0),
				   moncramt = ROUND(moncramt / p_dividamt, 0),
				   dramt = ROUND(dramt / p_dividamt, 0),
				   cramt = ROUND(cramt / p_dividamt, 0),
				   baldramt = ROUND(baldramt / p_dividamt, 0),
				   balcramt = ROUND(balcramt / p_dividamt, 0);

            INSERT INTO VGT.TT_ACACC0914R_ACC202
            SELECT * FROM VGT.TT_ACACC0914R_ACC202;
            COMMIT;

			OPEN IO_CURSOR FOR
				SELECT '101' ord, '현금' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('110110')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '102' ord, '예금' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('110160', '110210', '110260', '110310', '110360')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '103' ord, '매출채권' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('110510', '110860')
						UNION ALL
						SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('110760')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '104' ord, '받을어음' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('110760')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '105' ord, '미수금' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('111210', '111260')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '106' ord, '전도금' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('112260')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '200' ord, '재고자산' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('112660')
						UNION ALL
						SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('112710', '112760', '112810', '112860', '113210')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '201' ord, '상품' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('112710')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '202' ord, '제품' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('112760')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '203' ord, '재공품' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('112810')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '204' ord, '원재료' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('112860')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '205' ord, '부재료' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('113210')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '300' ord, '투자자산' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('120010')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '400' ord, '유형자산' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('121560')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '500' ord, '무형자산' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('123310')) A
				HAVING SUM(balamt) > 0
				UNION ALL
				SELECT '600' ord, '기타자산' accname, SUM(balamt) balamt
				FROM   (SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('124560')) A
				HAVING SUM(balamt) > 0;

			OPEN IO_CURSOR2 FOR
				SELECT '100' ord, '유동부채' accname, SUM(balamt) balamt
				FROM   (SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('210000')
						UNION ALL
						SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('210060', '210110', '210210', '210610', '211410', '210860', '211360', '211610', '211710', '211760', '211860', '211910', '211960')) A
				UNION ALL
				SELECT '101' ord, '외매매입금' accname, SUM(balamt) balamt
				FROM   (SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('210060')) A
				UNION ALL
				SELECT '102' ord, '지급어음' accname, SUM(balamt) balamt
				FROM   (SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('210110')) A
				UNION ALL
				SELECT '103' ord, '미지급금' accname, SUM(balamt) balamt
				FROM   (SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('210210')) A
				UNION ALL
				SELECT '104' ord, '단기차입금' accname, SUM(balamt) balamt
				FROM   (SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('210610', '211410')) A
				UNION ALL
				SELECT '105' ord, '전환사채' accname, SUM(balamt) balamt
				FROM   (SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('210860', '211360', '211610', '211710', '211760', '211860', '211910', '211960')) A
				UNION ALL
				SELECT '200' ord, '비유동부채' accname, SUM(balamt) balamt
				FROM   (SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('220000')
						UNION ALL
						SELECT baldramt - balcramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('220110', '220960', '221010', '221060', '220010', '220060', '221410', '221460', '221560', '221610', '221660', '221710')) A
				UNION ALL
				SELECT '201' ord, '장기차입금' accname, SUM(balamt) balamt
				FROM   (SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('220110', '220960', '221010', '221060')) A
				UNION ALL
				SELECT '202' ord, '사채' accname, SUM(balamt) balamt
				FROM   (SELECT balcramt - baldramt balamt
						FROM   VGT.TT_ACACC0914R_ACC202
						WHERE  seqline IN ('220010', '220060', '221410', '221460', '221560', '221610', '221660', '221710')) A;

			--1. 근태관련 집계정보
			OPEN IO_CURSOR3 FOR
				SELECT COUNT(*) totcnt, --총원
					   SUM(CASE WHEN b.empcode IS NULL THEN 1 ELSE 0 END) workcnt, --근무
					   SUM(CASE WHEN c.filter2 = '1' THEN 1 ELSE 0 END) sagocnt, --연차
					   SUM(CASE WHEN c.filter2 = '2' THEN 1 ELSE 0 END) educnt, --교육/훈련
					   SUM(CASE WHEN c.filter2 = '3' THEN 1 ELSE 0 END) vaccnt, --병가/출산
					   SUM(CASE WHEN c.filter2 = '4' THEN 1 ELSE 0 END) abscnt --무단결근
				FROM   CMEMPM A
					   LEFT JOIN PSWORKEXPM b
						   ON A.empcode = b.empcode
							  AND p_enddate BETWEEN b.workdate1 AND b.workdate2
							  AND b.statediv = 'Y'
					   LEFT JOIN CMCOMMONM c
						   ON c.cmmcode = 'PS08'
							  AND b.attenddiv = c.divcode
							  AND c.filter2 IN ('1', '2', '3', '4')
				WHERE  A.plantcode LIKE p_plantcode
					   --AND TRIM(retiredt) IS NULL --퇴사자 제외
                       AND A.outyn = 'N' --퇴사자 제외
					   AND A.empdiv = '01'; --정규직만 해당

			--2. 부서별 총원/근무 정보(그래프정보)
			--부서별 총원(그래프)
			OPEN IO_CURSOR4 FOR
				SELECT	 MAX(NVL(c.deptname, b.deptname)) Argument, COUNT(*) VALUE
				FROM	 CMEMPM A
						 JOIN CMDEPTM b ON A.deptcode = b.deptcode
						 LEFT JOIN CMDEPTM c
							 ON b.predeptcode = c.deptcode
								AND b.deptlevel = 3
				WHERE	 A.plantcode LIKE p_plantcode
						 --AND TRIM(A.retiredt) IS NULL --퇴사자 제외
                         AND A.outyn = 'N' --퇴사자 제외
						 AND A.empdiv = '01' --정규직만 해당
				GROUP BY NVL(c.deptcode, b.deptcode);

			--부서별 근무(그래프)
			OPEN IO_CURSOR5 FOR
				SELECT	 MAX(NVL(c.deptname, b.deptname)) Argument, COUNT(*) VALUE
				FROM	 CMEMPM A
						 JOIN CMDEPTM b ON A.deptcode = b.deptcode
						 LEFT JOIN CMDEPTM c
							 ON b.predeptcode = c.deptcode
								AND b.deptlevel = 3
						 LEFT JOIN PSWORKEXPM D
							 ON A.empcode = D.empcode
								AND p_enddate BETWEEN D.workdate1 AND D.workdate2
								AND D.statediv = 'Y'
						 LEFT JOIN CMCOMMONM E
							 ON E.cmmcode = 'PS08'
								AND D.attenddiv = E.divcode
								AND E.filter2 IN ('1', '2', '3', '4')
				WHERE	 A.plantcode LIKE p_plantcode
						 --AND TRIM(A.retiredt) IS NULL --퇴사자 제외
                         AND A.outyn = 'N' --퇴사자 제외
						 AND A.empdiv = '01' --정규직만 해당
						 AND E.cmmcode IS NULL
				GROUP BY NVL(c.deptcode, b.deptcode);
		END;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


    IF (IO_CURSOR2 IS NULL) THEN
        OPEN IO_CURSOR2 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

    IF (IO_CURSOR3 IS NULL) THEN
        OPEN IO_CURSOR3 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


    IF (IO_CURSOR4 IS NULL) THEN
        OPEN IO_CURSOR4 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


    IF (IO_CURSOR5 IS NULL) THEN
        OPEN IO_CURSOR5 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
