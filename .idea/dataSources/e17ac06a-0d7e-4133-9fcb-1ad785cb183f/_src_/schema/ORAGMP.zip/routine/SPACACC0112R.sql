CREATE PROCEDURE        spACacc0112R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0112R
 -- 수 정 자            : 배종성
 -- 수정일자            : 2010-12-03
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-20
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 총계정 원장을 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
 -- 수정내용            : 전면 수정
 -- ---------------------------------------------------------------
 -- exec spACacc0112R 'S','100','%','11101010',1,'2011-01-01','2011-02-10','','','1', '','','','N'

(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '' ,
    p_startdt       IN VARCHAR2 DEFAULT '' ,
    p_enddt         IN VARCHAR2 DEFAULT '' ,
    p_acccode       IN VARCHAR2 DEFAULT '' ,
    p_dcdiv         IN VARCHAR2 DEFAULT '' ,
    p_outputdiv     IN VARCHAR2 DEFAULT '' ,
    p_month         IN VARCHAR2 DEFAULT '' ,
    p_downview      IN VARCHAR2 DEFAULT '' ,
    p_bteacccodeS1  IN VARCHAR2 DEFAULT '' ,
    p_bteacccodeS2  IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,

    MESSAGE         OUT    VARCHAR2,
    IO_CURSOR       OUT    TYPES.DataSet
)
AS

    -- 현금계정
    p_acccashcode   VARCHAR2(20);
    p_odiv1         VARCHAR2(5);
    p_odiv2         VARCHAR2(5);

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    IF ( p_div = 'S' ) THEN

        FOR  rec IN (   SELECT  value1
                        FROM    SYSPARAMETERMANAGE
                        WHERE   UPPER(parametercode) = UPPER('acccashcode')
                                AND usediv = 'Y' )
        LOOP
            p_acccashcode := rec.value1 ;
        END LOOP;

        IF ( UPPER(p_outputdiv) = '1' ) THEN
            --K-GAAP
            p_odiv1 := '20' ;
            p_odiv2 := 'F' ;
        ELSIF ( UPPER(p_outputdiv) = '2' ) THEN
            --IFRS
            p_odiv1 := '30' ;
            p_odiv2 := 'K' ;
        END IF;



        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0112R_ACACCM';

        INSERT INTO VGT.TT_ACACC0112R_ACACCM
            SELECT  A.acccode ,
                    A.accname ,
                    A.dcdiv ,
                    COALESCE(c.acccode, b.acccode, A.acccode) downcode
            FROM    ACACCM A
                    LEFT JOIN ACACCM b ON ( A.acccode = b.acccode OR A.acccode = b.hacccode )
                                          AND NVL(p_downview, ' ') = 'Y'
                    LEFT JOIN ACACCM c ON A.acccode <> b.acccode
                                          AND b.acccode = c.hacccode
                                          AND NVL(p_downview, ' ') = 'Y'
            WHERE  A.acccode = p_acccode ;



        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0112R_ACORDD';

        INSERT INTO VGT.TT_ACACC0112R_ACORDD (
            SELECT  NVL(b.grp, 0) grp  ,
                    CASE WHEN b.grp = 1 AND p_month = 'N' THEN A.slipdate
                         WHEN b.grp = 2 AND p_month = 'N' THEN SUBSTR(A.slipdate, 0, 7) || '-98'
                         WHEN b.grp = 3 AND p_month = 'N' THEN SUBSTR(A.slipdate, 0, 7) || '-99'
                         WHEN b.grp = 1 AND p_month = 'Y' THEN SUBSTR(A.slipdate, 0, 7)
                         WHEN b.grp = 2 AND p_month = 'Y' THEN SUBSTR(A.slipdate, 0, 4) || '-98'
                         WHEN b.grp = 3 AND p_month = 'Y' THEN SUBSTR(A.slipdate, 0, 4) || '-99'
                         ELSE ''
                    END ord  ,
                    MAX(CASE WHEN b.grp = 1 AND p_month = 'N' THEN A.slipdate
                             WHEN b.grp = 2 AND p_month = 'N' THEN SUBSTR(A.slipdate, 0, 7) || ' 월계'
                             WHEN b.grp = 3 AND p_month = 'N' THEN SUBSTR(A.slipdate, 0, 7) || ' 누계'
                             WHEN b.grp = 1 AND p_month = 'Y' THEN SUBSTR(A.slipdate, 0, 7)
                             WHEN b.grp = 2 AND p_month = 'Y' THEN '삭제'
                             WHEN b.grp = 3 AND p_month = 'Y' THEN SUBSTR(A.slipdate, 0, 4) || ' 누계'
                             ELSE '이월'
                    END)  slipdate  ,
                    MAX(CASE WHEN b.grp = 1 THEN CASE WHEN p_month = 'N' THEN '일계표에서'
                                                      ELSE '월계표에서'
                                                 END
                             ELSE ''
                        END)  remark  ,
                    SUM(A.debamt)  debamt  ,
                    SUM(A.creamt)  creamt  ,
                    SUM(CASE WHEN c.dcdiv = '1' THEN A.debamt - A.creamt
                             ELSE A.creamt - A.debamt
                        END)  fnamt

            FROM (  SELECT  SUBSTR(p_startdt, 0, 7) || '-00' slipdate  ,
                            A.bsdebamt debamt  ,
                            A.bscreamt creamt
                    FROM    ACORDDMM A
                            JOIN VGT.TT_ACACC0112R_ACACCM b ON A.acccode = b.downcode
                    WHERE   A.compcode = p_compcode
                            AND A.plantcode LIKE p_plantcode || '%'
                            AND A.slipym = SUBSTR(p_startdt, 0, 7)
                            AND ( closediv = '10' OR closediv = p_odiv1 )

                    UNION ALL

                    SELECT  CASE WHEN A.slipdate < p_startdt THEN SUBSTR(p_startdt, 0, 7) || '-00'
                                 ELSE A.slipdate
                            END slipdate  ,
                            A.debamt ,
                            A.creamt
                    FROM    ACORDD A
                            JOIN ACORDM b   ON A.compcode = b.compcode
                                               AND A.slipinno = b.slipinno
                            JOIN VGT.TT_ACACC0112R_ACACCM c   ON A.acccode = c.downcode
                    WHERE   A.compcode = p_compcode
                            AND A.plantcode LIKE p_plantcode || '%'
                            AND A.slipdate BETWEEN SUBSTR(p_startdt, 0, 7) || '-01' AND p_enddt
                            AND b.slipinstate = '4'
                            AND b.slipdiv <> p_odiv2

                    UNION ALL

                    SELECT  CASE WHEN A.slipdate < p_startdt THEN SUBSTR(p_startdt, 0, 7) || '-00'
                                 ELSE A.slipdate
                            END slipdate  ,
                            A.creamt ,
                            A.debamt
                    FROM    ACORDD A
                            JOIN ACORDM b   ON A.compcode = b.compcode
                                               AND A.slipinno = b.slipinno
                            JOIN VGT.TT_ACACC0112R_ACACCM c   ON c.acccode = p_acccashcode
                    WHERE   A.compcode = p_compcode
                            AND A.plantcode LIKE p_plantcode || '%'
                            AND A.slipdate BETWEEN SUBSTR(p_startdt, 0, 7) || '-01' AND p_enddt
                            AND A.dcdiv IN ( '3','4' )

                            AND b.slipinstate = '4'
                            AND b.slipdiv <> p_odiv2 ) A

            LEFT JOIN ( SELECT 1 grp FROM DUAL
                        UNION
                        SELECT 2 FROM DUAL
                        UNION
                        SELECT 3 FROM DUAL  ) b   ON A.slipdate >= p_startdt

            LEFT JOIN ACACCM c   ON c.acccode = p_acccode
            GROUP BY b.grp, CASE WHEN b.grp = 1 AND p_month = 'N' THEN A.slipdate
                                 WHEN b.grp = 2 AND p_month = 'N' THEN SUBSTR(A.slipdate, 0, 7) || '-98'
                                 WHEN b.grp = 3 AND p_month = 'N' THEN SUBSTR(A.slipdate, 0, 7) || '-99'
                                 WHEN b.grp = 1 AND p_month = 'Y' THEN SUBSTR(A.slipdate, 0, 7)
                                 WHEN b.grp = 2 AND p_month = 'Y' THEN SUBSTR(A.slipdate, 0, 4) || '-98'
                                 WHEN b.grp = 3 AND p_month = 'Y' THEN SUBSTR(A.slipdate, 0, 4) || '-99'
                                 ELSE ''
                            END
        );



        MERGE INTO VGT.TT_ACACC0112R_ACORDD A
        USING (
                    SELECT  --UPDATE DATA
                            CASE WHEN c.dcdiv = '1' THEN b.debamt - b.creamt
                                 ELSE b.creamt - b.debamt
                            END AS fnamt
                            --COMPARE DATA
                            , A.ord
                    FROM    VGT.TT_ACACC0112R_ACORDD A
                            JOIN (  SELECT  A.ord ,
                                            SUM(b.debamt)  debamt  ,
                                            SUM(b.creamt)  creamt
                                    FROM    VGT.TT_ACACC0112R_ACORDD A
                                            JOIN VGT.TT_ACACC0112R_ACORDD b ON NVL(A.ord, -1) >= NVL(b.ord, -1)
                                                                               AND b.grp IN ( 0, 1 )
                                    WHERE  A.grp = 1
                                    GROUP BY A.ord ) b ON NVL(A.ord, -1) = NVL(b.ord, -1)
                    LEFT JOIN ACACCM c   ON c.acccode = p_acccode
                ) b ON ( NVL(A.ord, -1) = NVL(b.ord, -1)  )
        WHEN MATCHED THEN UPDATE SET A.fnamt = b.fnamt ;




        MERGE INTO VGT.TT_ACACC0112R_ACORDD A
        USING (
                    SELECT  --UPDATE DATA
                            NVL(b.debamt, A.debamt) AS debamt
                            , NVL(b.creamt, A.creamt) AS creamt
                            , b.fnamt
                            --COMPARE DATA
                            , A.ord
                    FROM    VGT.TT_ACACC0112R_ACORDD A
                            LEFT JOIN ( SELECT  A.ord ,
                                                SUM(b.debamt)  debamt  ,
                                                SUM(b.creamt)  creamt  ,
                                                SUM(b.fnamt)  fnamt
                                        FROM    VGT.TT_ACACC0112R_ACORDD A
                                                JOIN VGT.TT_ACACC0112R_ACORDD b ON NVL(A.ord, -1) >= NVL(b.ord, -1)  
                                                                                   AND b.grp IN ( 0, 2 )
                                        WHERE  A.grp = 3
                                        GROUP BY A.ord ) b ON NVL(A.ord, -1) = NVL(b.ord, -1)
                    WHERE A.grp IN ( 2, 3 )
             ) b ON ( NVL(A.ord, -1) = NVL(b.ord, -1)  )
        WHEN MATCHED THEN UPDATE SET    A.debamt = b.debamt ,
                                        A.creamt = b.creamt ,
                                        A.fnamt  = b.fnamt ;


        OPEN  IO_CURSOR FOR
            SELECT  
                    *
            FROM    VGT.TT_ACACC0112R_ACORDD A
            WHERE   slipdate <> '삭제'
            ORDER BY A.ord NULLS FIRST;


    END IF;

    IF ( UPPER(p_div) = UPPER('A') ) THEN

        OPEN  IO_CURSOR FOR
            SELECT  acccode ,
                    accname ,
                    dcdiv
            FROM    ACACCM
            WHERE   orduseyn = 'Y'
            ORDER BY acccode ;

    END IF;

    IF ( UPPER(p_div) = UPPER('A1') ) THEN

        OPEN  IO_CURSOR FOR
            SELECT  acccode ,
                    accname ,
                    dcdiv
            FROM    ACACCM
            WHERE   orduseyn = 'Y'
                    AND ( ( acccode BETWEEN p_bteacccodeS1 AND p_bteacccodeS2 ) OR
                          ( acccode BETWEEN p_bteacccodeS2 AND p_bteacccodeS1 ) )
            ORDER BY  acccode ; 
                       

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
