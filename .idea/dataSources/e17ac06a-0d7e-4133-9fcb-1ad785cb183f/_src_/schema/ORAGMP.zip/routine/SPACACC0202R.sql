CREATE PROCEDURE        spACacc0202R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0202R
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-10-08
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-21
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 일별합계잔액시산표를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_rptdiv		IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '',
	p_basisdate 	IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	p_basisym	  VARCHAR2(7);
	p_basisyy	  VARCHAR2(4);
	p_yyyy01	  VARCHAR2(7);
	p_strdate	  VARCHAR2(10);
	p_enddate	  VARCHAR2(10);
	p_cashcode	  VARCHAR2(20);
	-- 임시테이블의 calcseq의 최대값을 조회
	p_maxseq	  NUMBER(10, 0);
	p_curseq	  NUMBER(10, 0);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);


	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0202R_DUAL ';

	IF (p_div = 'S'
		OR p_div = 'P')
	THEN
		-- 기간 설정
		p_basisym := SUBSTR(p_basisdate, 0, 7);
		p_yyyy01 := SUBSTR(p_basisym, 0, 4) || '-01';

		FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
					FROM   ACSESSION
					WHERE  compcode = p_compcode
						   AND cyear <= SUBSTR(p_basisym, 0, 4))
		LOOP
			p_yyyy01 := rec.alias1;
		END LOOP;

		IF SUBSTR(p_basisym, -2, 2) < SUBSTR(p_yyyy01, -2, 2)
		THEN
			p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), -12), 'YYYY-') || SUBSTR(p_yyyy01, -2, 2);
		ELSE
			p_yyyy01 := SUBSTR(p_basisym, 0, 5) || SUBSTR(p_yyyy01, -2, 2);
		END IF;

		p_strdate := p_yyyy01 || '-01';
		p_enddate := p_basisdate;
		p_cashcode := '11101010';

		FOR rec IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'acccashcode')
		LOOP
			p_cashcode := rec.value1;
		END LOOP;

		-- 보고서 조회년도 설정
		FOR rec IN (SELECT MAX(rptyear) AS alias1
					FROM   ACRPTM
					WHERE  compcode = p_compcode
						   AND rptdiv = p_rptdiv
						   AND rptyear <= SUBSTR(p_basisym, 0, 4))
		LOOP
			p_basisyy := rec.alias1;
		END LOOP;

		-- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
		INSERT INTO VGT.TT_ACACC0202R_DUAL(seqline,
										   acccode,
										   accrname,
										   acckname,
										   lrdiv,
										   prtyn,
										   prtdiv,
										   prtbold,
										   sseqline,
										   calcseq,
										   calcdiv,
										   dcdiv,
										   objdatadiv,
										   mondramt,
										   moncramt,
										   dramt,
										   cramt,
										   baldramt,
										   balcramt)
			SELECT	 seqline,
					 acccode,
					 accrname,
					 acckname,
					 lrdiv,
					 prtyn,
					 prtdiv,
					 prtbold,
					 sseqline,
					 calcseq,
					 calcdiv,
					 dcdiv,
					 objdatadiv,
					 NVL(mondramt, 0) mondramt,
					 NVL(moncramt, 0) moncramt,
					 NVL(dramt, 0) dramt,
					 NVL(cramt, 0) cramt,
					 NVL(CASE
							 WHEN lrdiv = 'A'
								  AND dcdiv = '1'
								  OR lrdiv = 'L'
							 THEN
								 CASE WHEN dcdiv = '1' THEN NVL(dramt, 0) - NVL(cramt, 0) ELSE NVL(cramt, 0) - NVL(dramt, 0) END
						 END,
						 0)
						 baldramt,
					 NVL(CASE
							 WHEN lrdiv = 'A'
								  AND dcdiv = '2'
								  OR lrdiv = 'R'
							 THEN
								 CASE WHEN dcdiv = '2' THEN NVL(cramt, 0) - NVL(dramt, 0) ELSE NVL(dramt, 0) - NVL(cramt, 0) END
						 END,
						 0)
						 balcramt
			FROM	 (SELECT   a.seqline,
							   MAX(a.acccode) acccode,
							   MAX(a.accrname) accrname,
							   MAX(a.acckname) acckname,
							   MAX(a.lrdiv) lrdiv,
							   MAX(a.prtyn) prtyn,
							   MAX(a.prtdiv) prtdiv,
							   MAX(a.prtbold) prtbold,
							   MAX(a.sseqline) sseqline,
							   MAX(a.calcseq) calcseq,
							   MAX(a.calcdiv) calcdiv,
							   MAX(b.dcdiv) dcdiv,
							   MAX(a.objdatadiv) objdatadiv,
							   SUM(CASE WHEN a.objdatadiv IN ('D', 'F', 'J') THEN debamt END) mondramt,
							   SUM(CASE WHEN a.objdatadiv IN ('C', 'E', 'J') THEN creamt END) moncramt,
							   SUM(CASE WHEN a.objdatadiv IN ('D', 'F', 'J') THEN totdebamt END) dramt,
							   SUM(CASE WHEN a.objdatadiv IN ('C', 'E', 'J') THEN totcreamt END) cramt
					  FROM	   ACRPTM a
							   LEFT JOIN ACACCM b ON NVL(a.acccode, ' ') = NVL(b.acccode, ' ')
							   LEFT JOIN (SELECT   p_compcode compcode,
												   p_plantcode plantcode,
												   p_basisym slipym,
												   CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
												   acccode,
												   SUM(debamt) debamt,
												   SUM(creamt) creamt,
												   SUM(totdebamt) totdebamt,
												   SUM(totcreamt) totcreamt
										  FROM	   (SELECT b.acccode,
														   CASE WHEN SUBSTR(a.slipdate, 0, 7) = p_basisym THEN b.debamt ELSE 0 END debamt,
														   CASE WHEN SUBSTR(a.slipdate, 0, 7) = p_basisym THEN b.creamt ELSE 0 END creamt,
														   b.debamt totdebamt,
														   b.creamt totcreamt
													FROM   ACORDM a
														   JOIN ACORDD b
															   ON a.compcode = b.compcode
																  AND a.slipinno = b.slipinno
													WHERE  a.compcode = p_compcode
														   AND a.plantcode LIKE p_plantcode
														   AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(TO_DATE(p_basisdate, 'YYYY-MM-DD') + 1, 'YYYYMMDD')
														   AND a.slipinstate = '4'
														   AND (a.slipdiv NOT IN ('K', 'F')
																OR p_closediv = '1'
																   AND a.slipdiv = 'K'
																OR p_closediv = '2'
																   AND a.slipdiv = 'F')
													UNION ALL
													SELECT p_cashcode acccode,
														   CASE WHEN SUBSTR(a.slipdate, 0, 7) = p_basisym THEN b.creamt ELSE 0 END debamt,
														   CASE WHEN SUBSTR(a.slipdate, 0, 7) = p_basisym THEN b.debamt ELSE 0 END creamt,
														   b.creamt totdebamt,
														   b.debamt totcreamt
													FROM   ACORDM a
														   JOIN ACORDD b
															   ON a.compcode = b.compcode
																  AND a.slipinno = b.slipinno
																  AND b.dcdiv IN ('3', '4')
													WHERE  a.compcode = p_compcode
														   AND a.plantcode LIKE p_plantcode
														   AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(TO_DATE(p_basisdate, 'YYYY-MM-DD') + 1, 'YYYYMMDD')
														   AND a.slipinstate = '4'
														   AND (a.slipdiv NOT IN ('K', 'F')
																OR p_closediv = '1'
																   AND a.slipdiv = 'K'
																OR p_closediv = '2'
																   AND a.slipdiv = 'F')
													UNION ALL
													SELECT acccode,
														   0 debamt,
														   0 creamt,
														   bsdebamt totdebamt,
														   bscreamt totcreamt
													FROM   ACORDDMM
													WHERE  compcode = p_compcode
														   AND plantcode LIKE p_plantcode
														   AND slipym = p_yyyy01
														   AND (p_closediv = '1'
																AND closediv IN ('10', '20')
																OR p_closediv = '2'
																   AND closediv IN ('10', '30'))) a
										  GROUP BY acccode) c
								   ON a.compcode = c.compcode
									  AND c.plantcode LIKE p_plantcode
									  AND c.slipym = p_basisym
									  AND (p_closediv = '1'
										   AND c.closediv IN ('10', '20')
										   OR p_closediv = '2'
											  AND c.closediv IN ('10', '30'))
									  AND NVL(a.acccode, ' ') = NVL(c.acccode, ' ')
					  WHERE    a.compcode = p_compcode
							   AND a.rptdiv = p_rptdiv
							   AND a.rptyear = p_basisyy
							   AND a.useyn = 'Y'
					  GROUP BY a.seqline) a
			ORDER BY a.seqline;

		-- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
		MERGE INTO VGT.TT_ACACC0202R_DUAL a
		USING	   (SELECT A.SEQLINE,
						   A.ACCCODE,
						   A.ACCRNAME,
						   A.ACCKNAME,
						   A.LRDIV,
						   A.PRTYN,
						   A.PRTDIV,
						   A.PRTBOLD,
						   A.SSEQLINE,
						   A.CALCSEQ,
						   A.CALCDIV,
						   A.DCDIV,
						   A.OBJDATADIV,
						   A.MONDRAMT,
						   A.MONCRAMT,
						   A.DRAMT,
						   A.CRAMT,
						   A.BALDRAMT,
						   A.BALCRAMT,
						   CASE WHEN a.objdatadiv = 'A' THEN b.dramt ELSE a.dramt - b.dramt END AS pos_2,
						   CASE WHEN a.objdatadiv = 'A' THEN b.cramt ELSE a.cramt - b.cramt END AS pos_3,
						   CASE WHEN a.objdatadiv = 'A' THEN b.baldramt ELSE a.baldramt - b.baldramt END AS pos_4,
						   CASE WHEN a.objdatadiv = 'A' THEN b.balcramt ELSE a.balcramt - b.balcramt END AS pos_5
					FROM   VGT.TT_ACACC0202R_DUAL a
						   JOIN (SELECT A.seqline,
										NVL(A.dramt, 0) dramt,
										NVL(A.cramt, 0) cramt,
										NVL(CASE
												WHEN A.lrdiv = 'A'
													 AND A.dcdiv = '1'
													 OR A.lrdiv = 'L'
												THEN
													CASE WHEN A.dcdiv = '1' THEN NVL(A.dramt, 0) - NVL(A.cramt, 0) ELSE NVL(A.cramt, 0) - NVL(A.dramt, 0) END
											END,
											0)
											baldramt,
										NVL(CASE
												WHEN A.lrdiv = 'A'
													 AND A.dcdiv = '2'
													 OR A.lrdiv = 'R'
												THEN
													CASE WHEN A.dcdiv = '2' THEN NVL(A.cramt, 0) - NVL(A.dramt, 0) ELSE NVL(A.dramt, 0) - NVL(A.cramt, 0) END
											END,
											0)
											balcramt
								 FROM	(SELECT   a.seqline,
												  MAX(a.lrdiv) lrdiv,
												  MAX(b.dcdiv) dcdiv,
												  SUM(CASE WHEN a.objdatadiv IN ('A', 'F') THEN bsdebamt END) dramt,
												  SUM(CASE WHEN a.objdatadiv IN ('A', 'E') THEN bscreamt END) cramt
										 FROM	  ACRPTM a
												  LEFT JOIN ACACCM b ON NVL(a.acccode, ' ') = NVL(b.acccode, ' ')
												  LEFT JOIN ACORDDMM c
													  ON a.compcode = c.compcode
														 AND c.plantcode LIKE p_plantcode
														 AND c.slipym = p_yyyy01
														 AND (p_closediv = '1'
															  AND c.closediv IN ('10', '20')
															  OR p_closediv = '2'
																 AND c.closediv IN ('10', '30'))
														 AND NVL(a.acccode, ' ') = NVL(c.acccode, ' ')
										 WHERE	  a.compcode = p_compcode
												  AND a.rptdiv = p_rptdiv
												  AND a.rptyear = p_basisyy
												  AND a.useyn = 'Y'
												  AND a.objdatadiv IN ('A', 'E', 'F')
										 GROUP BY a.seqline) a) b
							   ON a.seqline = b.seqline) src
		ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
					AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
					AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
					AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
					AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
					AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
					AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
					AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
					AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
					AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
					AND NVL(A.DCDIV, ' ') = NVL(SRC.DCDIV, ' ')
					AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
					AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
					AND NVL(A.MONDRAMT, 0) = NVL(SRC.MONDRAMT, 0)
					AND NVL(A.MONCRAMT, 0) = NVL(SRC.MONCRAMT, 0))
		WHEN MATCHED
		THEN
			UPDATE SET A.dramt = SRC.pos_2, A.cramt = SRC.pos_3, A.baldramt = SRC.pos_4, A.balcramt = SRC.pos_5;

		p_curseq := 0;

		FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0202R_DUAL)
		LOOP
			p_maxseq := rec.alias1;
		END LOOP;

		-- 각 레벨별로 sum을하여 update
		WHILE p_curseq <= p_maxseq
		LOOP
			MERGE INTO VGT.TT_ACACC0202R_DUAL a
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.PRTBOLD,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.DCDIV,
							   A.OBJDATADIV,
							   A.MONDRAMT,
							   A.MONCRAMT,
							   A.DRAMT,
							   A.CRAMT,
							   A.BALDRAMT,
							   A.BALCRAMT,
							   a.mondramt + b.mondramt AS pos_2,
							   a.moncramt + b.moncramt AS pos_3,
							   a.dramt + b.dramt AS pos_4,
							   a.cramt + b.cramt AS pos_5,
							   a.baldramt + b.baldramt AS pos_6,
							   a.balcramt + b.balcramt AS pos_7
						FROM   VGT.TT_ACACC0202R_DUAL a
							   JOIN (SELECT   sseqline,
											  SUM(CASE WHEN calcdiv = '+' THEN mondramt ELSE -mondramt END) mondramt,
											  SUM(CASE WHEN calcdiv = '+' THEN moncramt ELSE -moncramt END) moncramt,
											  SUM(CASE WHEN calcdiv = '+' THEN dramt ELSE -dramt END) dramt,
											  SUM(CASE WHEN calcdiv = '+' THEN cramt ELSE -cramt END) cramt,
											  SUM(CASE WHEN calcdiv = '+' THEN baldramt ELSE -baldramt END) baldramt,
											  SUM(CASE WHEN calcdiv = '+' THEN balcramt ELSE -balcramt END) balcramt
									 FROM	  VGT.TT_ACACC0202R_DUAL
									 WHERE	  calcseq = p_curseq
											  AND NVL(sseqline, ' ') <> ' '
									 GROUP BY sseqline) b
								   ON a.seqline = b.sseqline) src
			ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
						AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(A.DCDIV, ' ') = NVL(SRC.DCDIV, ' ')
						AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
						AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0))
			WHEN MATCHED
			THEN
				UPDATE SET A.mondramt = SRC.pos_2,
						   A.moncramt = SRC.pos_3,
						   A.dramt = SRC.pos_4,
						   A.cramt = SRC.pos_5,
						   A.baldramt = SRC.pos_6,
						   A.balcramt = SRC.pos_7;

			p_curseq := p_curseq + 1;
		END LOOP;

		-- 조회
		IF p_div = 'S'
		THEN
			OPEN IO_CURSOR FOR
				SELECT	 NULLIF(CASE WHEN prtyn = 'Y' THEN baldramt END, 0) baldramt,
						 NULLIF(CASE WHEN prtyn = 'Y' THEN dramt END, 0) dramt,
						 NULLIF(CASE WHEN prtyn = 'Y' THEN mondramt END, 0) mondramt,
						 CASE WHEN baldramt + balcramt >= 0 THEN accrname ELSE acckname END accname,
						 NULLIF(CASE WHEN prtyn = 'Y' THEN moncramt END, 0) moncramt,
						 NULLIF(CASE WHEN prtyn = 'Y' THEN cramt END, 0) cramt,
						 NULLIF(CASE WHEN prtyn = 'Y' THEN balcramt END, 0) balcramt,
						 p_plantcode plantcode,
						 p_strdate strdate,
						 p_basisdate enddate,
						 acccode,
						 prtbold,
						 seqline,
						 p_closediv closediv
				FROM	 VGT.TT_ACACC0202R_DUAL
				WHERE	 NVL(prtdiv, ' ') <> 'C'
						 AND (NVL(dramt, 0) <> 0
							  OR NVL(cramt, 0) <> 0
							  OR NVL(prtdiv, ' ') = 'A')
				ORDER BY seqline;
		ELSE
			OPEN IO_CURSOR FOR
				SELECT	 NULLIF(CASE WHEN a.prtyn = 'Y' THEN a.baldramt END, 0) baldramt,
						 NULLIF(CASE WHEN a.prtyn = 'Y' THEN a.dramt END, 0) dramt,
						 NULLIF(CASE WHEN a.prtyn = 'Y' THEN a.mondramt END, 0) mondramt,
						 CASE WHEN a.baldramt + a.balcramt >= 0 THEN a.accrname ELSE a.acckname END accname,
						 NULLIF(CASE WHEN a.prtyn = 'Y' THEN a.moncramt END, 0) moncramt,
						 NULLIF(CASE WHEN a.prtyn = 'Y' THEN a.cramt END, 0) cramt,
						 NULLIF(CASE WHEN a.prtyn = 'Y' THEN a.balcramt END, 0) balcramt,
						 a.prtbold,
						 SUBSTR(p_basisdate, 0, 4) || '년 ' || SUBSTR(p_basisdate, 6, 2) || '월 ' || SUBSTR(p_basisdate, -2, 2) || '일 현재' title1,
						 '' title2,
						 CASE WHEN p_plantcode = '%' THEN '회사명 : ' || c.compname ELSE '사업장명 : ' || NVL(D.plantfullname, D.plantname) END compname,
						 '(단위 : 원)' prtunit,
						 b.baldramt baldramt2,
						 b.dramt dramt2,
						 b.mondramt mondramt2,
						 b.accrname accname2,
						 b.moncramt moncramt2,
						 b.cramt cramt2,
						 b.balcramt balcramt2
				FROM	 VGT.TT_ACACC0202R_DUAL a
						 LEFT JOIN VGT.TT_ACACC0202R_DUAL b ON b.seqline = '900000'
						 LEFT JOIN CMCOMPM c ON compcode = p_compcode
						 LEFT JOIN CMPLANTM D ON D.plantcode = p_plantcode
				WHERE	 a.prtdiv <> 'C'
						 AND (NVL(a.dramt, 0) <> 0
							  OR NVL(a.cramt, 0) <> 0
							  OR NVL(a.prtdiv, ' ') = 'A')
						 AND NVL(a.seqline, ' ') <> '900000'
				ORDER BY a.seqline;
		END IF;
	END IF;

	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
