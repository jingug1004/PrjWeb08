CREATE PROCEDURE        spACacc0000R
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0000R
-- 작 성 자         : 최용석
-- 작성일자         : 2010-12-08
--수 정 자         : 임 정호
-- 수정일자         : 2016-12-13
-- ---------------------------------------------------------------
-- 프로시저 설명    : 회계전표 테이블 내역을 조회하는 프로시저이다.
-- ---------------------------------------------------------------
(
    p_div               IN      VARCHAR2 DEFAULT '',

    p_compcode          IN      VARCHAR2 DEFAULT '',
    p_plantcode         IN      VARCHAR2 DEFAULT '%',
    p_slipsdate         IN      VARCHAR2 DEFAULT '',
    p_slipedate         IN      VARCHAR2 DEFAULT '',
    p_deptcode          IN      VARCHAR2 DEFAULT '',
    p_empcode           IN      VARCHAR2 DEFAULT '',
    p_slipdiv           IN      VARCHAR2 DEFAULT '%',
    p_slipinno          IN      VARCHAR2 DEFAULT '',
    p_slipinno1         IN      VARCHAR2 DEFAULT '', -- 전표번호 yymmdd
    p_slipinno2         IN      VARCHAR2 DEFAULT '', -- 전표번호 고유값
    p_acautorcode       IN      VARCHAR2 DEFAULT '',
    p_acccode           IN      VARCHAR2 DEFAULT '',
    p_dcdiv             IN      VARCHAR2 DEFAULT '',
    p_budgym            IN      VARCHAR2 DEFAULT '',
    p_slipinstate       IN      VARCHAR2 DEFAULT '%',
    p_printdiv          IN      VARCHAR2 DEFAULT '%',
    p_slipinremark      IN      VARCHAR2 DEFAULT '', --결의내용 검색 조건
    p_eviddiv           IN      VARCHAR2 DEFAULT '%',
    p_rptname           IN      VARCHAR2 DEFAULT '',
    p_rptsize           IN      VARCHAR2 DEFAULT '1',
    p_rptauto           IN      VARCHAR2 DEFAULT 'N',

    p_userid            IN      VARCHAR2 DEFAULT '',
    p_reasondiv         IN      VARCHAR2 DEFAULT '',
    p_reasontext        IN      VARCHAR2 DEFAULT '',

    IO_CURSOR           OUT TYPES.DataSet,
    MESSAGE             OUT     VARCHAR2
)
AS
    ip_rptsize          VARCHAR2(5) := p_rptsize;
    ip_slipinno         LONG := p_slipinno;

    ip_slipinno1        LONG := p_slipinno1;
    ip_slipinno2        LONG := p_slipinno2;

    p_pathcode          VARCHAR2(10);

    p_rptname1          VARCHAR2(20);   -- 결의전표명
    p_ordseq            NUMBER(10,0);   -- 출력순번
    p_rowcnt1           NUMBER(10,0);   -- 첫장갯수
    p_rowcnt2           NUMBER(10,0);   -- 뒷장갯수
    p_formtype          NUMBER(10,0);   -- 폼형태
    p_cashprt           NUMBER(10,0);   -- 현금출력(1:전체 2:혼합)

    p_inoutdiv          VARCHAR2(1) := 'O'; -- 입출금구분
    p_acccode1          VARCHAR2(20);       -- 현금
    p_acccode2          VARCHAR2(20);       -- 보통예금
    p_acccode3          VARCHAR2(20);       -- 전도금
    p_acccode4          VARCHAR2(20);       -- 미지급금
    p_acccode5          VARCHAR2(20);       -- 외상매입금

    ip_temp             LONG := ip_slipinno;
    ip_temp1            LONG := ip_slipinno1;
    ip_temp2            LONG := ip_slipinno2;
    ip_index            NUMBER := 0;
    p_SplitChar         VARCHAR2(10) := ';';

    v_temp              VARCHAR2(4000);
    v_temp1             VARCHAR2(4000);
    v_temp2             VARCHAR2(4000);

    ip_acccode          VARCHAR2(30) := '';
BEGIN

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    for rec in (select value3
                from   SYSPARAMETERMANAGE
                where  parametercode = 'accsliprptposs')
    loop
        p_pathcode := rec.value3;
    end loop;

    if (p_div = 'SM') then -- 결의전표내역 검색
        open IO_CURSOR for
        select  nvl(a.compcode,'') as compcode,                                           -- 회사코드
                nvl(a.slipinno,'') as slipinno,                                           -- 전표번호
                nvl(a.slipdiv,'') as slipdiv,                                             -- 전표유형
                nvl(a.slipindate,'') as slipindate,                                       -- 발의일자
                nvl(a.slipinnum,'') as slipinnum,                                         -- 전표넘버
                nvl(a.deptcode,'') as deptcode,                                           -- 발의부서
                nvl(a.plantcode,'') as plantcode,                                         -- 사업장
                nvl(a.empcode,'') as empcode,                                             -- 발의자
                nvl(k.divname,'') as eviddiv,                                             -- 증빙구분
                nvl(a.slipinremark,'') as slipinremark,                                   -- 발의내용
                nvl(a.slipincomment,'') as slipincomment,                                 -- 특이사항
                nvl(a.slipno,'') as slipno,                                               -- 승인번호
                nvl(a.slipdate,'') as slipdate,                                           -- 회계일자
                nvl(a.slipnum,'') as slipnum,                                             -- 승인넘버
                nvl(a.slipdeptcode,'') as slipdeptcode,                                   -- 승인부서
                nvl(a.slipempcode,'') as slipempcode,                                     -- 승인자
                nvl(a.skreqyn,'') as skreqyn,                                             -- 송금의뢰여부
                nvl(a.skreqdiv,'') as skreqdiv,                                           -- 송금의뢰유형
                nvl(a.skreqdate,'') as skreqdate,                                         -- 송금의뢰일자
                nvl(a.skreqdeptcode,'') as skreqdeptcode,                                 -- 송금의뢰부서
                nvl(a.skreqempcode,'') as skreqempcode,                                   -- 송금의뢰자
                nvl(a.accountno,'') as accountno,                                         -- 송금계좌코드
                nvl(a.slipinstate,'') as slipinstate,                                     -- 발의진행상태
                nvl(c.deptname,'') as deptname,                                           -- 발의부서명
                nvl(d.empname,'') as empname,                                             -- 발의자명
                nvl(e.deptname,'') as slipdeptname,                                       -- 승인부서명
                nvl(f.empname,'') as slipempname,                                         -- 승인자명
                nvl(g.deptname,'') as skreqdeptname,                                      -- 송금의뢰부서명
                nvl(h.empname,'') as skreqempname,                                        -- 송금의뢰자명
                nvl(i.divname,'') as skreqdivname,                                        -- 송금의뢰유형명
                nvl(j.plantname,'') as plantname,                                         -- 사업장명
                'N' as slipprint,                                                         -- 출력여부
                to_char(nvl(a.updatedt, a.insertdt), 'yyyy-mm-dd hh24:mi:ss') as updatedt -- 최종수정일
        from    ACORDM a
                join (
                    select  a.compcode, -- 회사코드
                            a.slipinno  -- 전표번호
                    from    ACORDM a
                    where   a.compcode = p_compcode
                            and a.slipdiv <> 'A'
                            and (ip_slipinno is not null
                                 and a.slipinno = upper(trim(ip_slipinno))
                                 and a.deptcode like p_deptcode || '%'
                                 or
                                 ip_slipinno is null
                                 and a.plantcode like p_plantcode
                                 and a.slipdiv like p_slipdiv
                                 and a.slipindate between p_slipsdate and p_slipedate
                                 and a.deptcode like p_deptcode || '%'
                                 and a.empcode like p_empcode || '%'
                                 and (nvl(a.slipinremark, ' ') like '%' || p_slipinremark || '%' or
                                      nvl(a.slipincomment, ' ') like '%' || p_slipinremark || '%')
                                 and nvl(a.acautorcode, ' ') like p_acautorcode || '%'
                                 and a.slipinstate like p_slipinstate
                                 and a.slipinstate <> '6'
                                 and a.eviddiv like p_eviddiv)
                            and (p_printdiv = '%' or
                                 p_printdiv = '01' and a.printdate is not null or
                                 p_printdiv = '02' and a.printdate is null)

                    union

                    select  a.compcode, -- 회사코드
                            a.slipinno  -- 전표번호
                    from    ACORDM a
                            join ACORDD b
                                on a.compcode = b.compcode
                                and a.slipinno = b.slipinno
                    where   a.compcode = p_compcode
                            and a.slipdiv <> 'A'
                            and ip_slipinno is null
                            and a.plantcode like p_plantcode
                            and a.slipdiv like p_slipdiv
                            and a.slipindate between p_slipsdate and p_slipedate
                            and a.deptcode like p_deptcode || '%'
                            and a.empcode like p_empcode || '%'
                            and nvl(a.acautorcode, ' ') like p_acautorcode || '%'
                            and a.slipinstate like p_slipinstate
                            and a.slipinstate <> '6'
                            and a.eviddiv like p_eviddiv
                            and (p_printdiv = '%' or
                                 p_printdiv = '01' and a.printdate is not null or
                                 p_printdiv = '02' and a.printdate is null )
                            and (nvl(b.remark1,' ') like '%' || p_slipinremark || '%' or
                                 nvl(b.remark2,' ') like '%' || p_slipinremark || '%')

                    union

                    select  a.compcode, -- 회사코드
                            a.slipinno  -- 전표번호
                    from    ACORDM a
                            join ACORDS b
                                on a.compcode = b.compcode
                                and a.slipinno = b.slipinno
                    where   a.compcode = p_compcode
                            and a.slipdiv <> 'A'
                            and ip_slipinno is null
                            and a.plantcode like p_plantcode
                            and a.slipdiv like p_slipdiv
                            and a.slipindate between p_slipsdate and p_slipedate
                            and a.deptcode like p_deptcode || '%'
                            and a.empcode like p_empcode || '%'
                            and nvl(a.acautorcode, ' ') like p_acautorcode || '%'
                            and a.slipinstate like p_slipinstate
                            and a.slipinstate <> '6'
                            and a.eviddiv like p_eviddiv
                            and (p_printdiv = '%' or
                                 p_printdiv = '01' and a.printdate is not null or
                                 p_printdiv = '02' and a.printdate is null)
                            and (nvl(b.mngcluval,' ') like '%' || p_slipinremark || '%' or
                                 nvl(b.mngcludec,' ') like '%' || p_slipinremark || '%')
                ) b on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                left join CMDEPTM c
                    on a.deptcode = c.deptcode      -- 발의부서
                left join CMEMPM d
                    on a.empcode = d.empcode        -- 발의자
                left join CMDEPTM e
                    on a.slipdeptcode = e.deptcode  -- 승인부서
                left join CMEMPM f
                    on a.slipempcode = f.empcode    -- 승인자
                left join CMDEPTM g
                    on a.skreqdeptcode = g.deptcode -- 송금의뢰부서
                left join CMEMPM h
                    on a.skreqempcode = h.empcode   -- 송금의뢰자
                left join CMCOMMONM i
                    on i.cmmcode = 'AC27'           -- 송금의뢰유형
                    and a.skreqdiv = i.divcode
                left join CMPLANTM j
                    on a.plantcode = j.plantcode    -- 사업장
                left join CMCOMMONM k
                    on k.cmmcode = 'AC29'           -- 증빙구분
                    and a.eviddiv = k.divcode
        order by slipinno;

    elsif (p_div = 'SN') then -- 회계전표내역 검색 and 계정코드
        open IO_CURSOR for
        select  nvl(a.compcode,'') as compcode,                                           -- 회사코드
                nvl(a.slipinno,'') as slipinno,                                           -- 전표번호
                nvl(a.slipdiv,'') as slipdiv,                                             -- 전표유형
                nvl(a.slipindate,'') as slipindate,                                       -- 발의일자
                nvl(a.slipinnum,'') as slipinnum,                                         -- 전표넘버
                nvl(a.deptcode,'') as deptcode,                                           -- 발의부서
                nvl(a.plantcode,'') as plantcode,                                         -- 사업장
                nvl(a.empcode,'') as empcode,                                             -- 발의자
                nvl(a.slipinremark,'') as slipinremark,                                   -- 발의내용
                nvl(a.slipincomment,'') as slipincomment,                                 -- 특이사항
                nvl(a.slipno,'') as slipno,                                               -- 승인번호
                nvl(a.slipdate,'') as slipdate,                                           -- 회계일자
                nvl(a.slipnum,'') as slipnum,                                             -- 승인넘버
                nvl(a.slipdeptcode,'') as slipdeptcode,                                   -- 승인부서
                nvl(a.slipempcode,'') as slipempcode,                                     -- 승인자
                nvl(a.skreqyn,'') as skreqyn,                                             -- 송금의뢰여부
                nvl(a.skreqdiv,'') as skreqdiv,                                           -- 송금의뢰유형
                nvl(a.skreqdate,'') as skreqdate,                                         -- 송금의뢰일자
                nvl(a.skreqdeptcode,'') as skreqdeptcode,                                 -- 송금의뢰부서
                nvl(a.skreqempcode,'') as skreqempcode,                                   -- 송금의뢰자
                nvl(a.accountno,'') as accountno,                                         -- 송금계좌코드
                nvl(a.slipinstate,'') as slipinstate,                                     -- 발의진행상태
                nvl(c.deptname,'') as deptname,                                           -- 발의부서명
                nvl(d.empname,'') as empname,                                             -- 발의자명
                nvl(e.deptname,'') as slipdeptname,                                       -- 승인부서명
                nvl(f.empname,'') as slipempname,                                         -- 승인자명
                nvl(g.deptname,'') as skreqdeptname,                                      -- 송금의뢰부서명
                nvl(h.empname,'') as skreqempname,                                        -- 송금의뢰자명
                nvl(i.divname,'') as skreqdivname,                                        -- 송금의뢰유형명
                nvl(j.plantname,'') as plantname,                                         -- 사업장명
                'N' as slipprint,                                                         -- 출력여부
                to_char(nvl(a.updatedt, a.insertdt), 'yyyy-mm-dd hh24:mi:ss') as updatedt -- 최종수정일
        from    ACORDM a
                join (
                    select  a.compcode, -- 회사코드
                            a.slipinno  -- 전표번호
                    from    ACORDM a
                    where   a.compcode = p_compcode
                            and a.slipinstate = '4'
                            and (ip_slipinno is not null
                                 and a.slipno = upper(trim(ip_slipinno))
                                 and a.deptcode like p_deptcode || '%'
                                 or
                                 ip_slipinno is null
                                 and a.plantcode like p_plantcode
                                 and a.slipdiv like p_slipdiv
                                 and a.slipdate between p_slipsdate and p_slipedate
                                 and a.deptcode like p_deptcode || '%'
                                 and a.empcode like p_empcode || '%'
                                 and (nvl(a.slipinremark,' ') like '%' || p_slipinremark || '%' or
                                      nvl(a.slipincomment,' ') like '%' || p_slipinremark || '%')
                                 and nvl(a.acautorcode,' ') like p_acautorcode || '%'
                                 and a.eviddiv like p_eviddiv)
                            and (p_printdiv = '%' or
                                 p_printdiv = '01' and a.printdate is not null or
                                 p_printdiv = '02' and a.printdate is null)

                    union

                    select  a.compcode, -- 회사코드
                            a.slipinno  -- 전표번호
                    from    ACORDM a
                            join ACORDD b
                                on a.compcode = b.compcode
                                and a.slipinno = b.slipinno
                    where   a.compcode = p_compcode
                            and a.slipinstate = '4'
                            and ip_slipinno is null
                            and a.plantcode like p_plantcode
                            and a.slipdiv like p_slipdiv
                            and a.slipdate between p_slipsdate and p_slipedate
                            and a.deptcode like p_deptcode || '%'
                            and a.empcode like p_empcode || '%'
                            and nvl(a.acautorcode, ' ') like p_acautorcode || '%'
                            and a.eviddiv like p_eviddiv
                            and (p_printdiv = '%' or
                                 p_printdiv = '01' and a.printdate is not null or
                                 p_printdiv = '02' and a.printdate is null)
                            and (nvl(b.remark1,' ') like '%' || p_slipinremark || '%' or
                                 nvl(b.remark2,' ') like '%' || p_slipinremark || '%')

                    union

                    select  a.compcode, -- 회사코드
                            a.slipinno  -- 전표번호
                    from    ACORDM a
                            join ACORDS b
                                on a.compcode = b.compcode
                                and a.slipinno = b.slipinno
                    where   a.compcode = p_compcode
                            and a.slipinstate = '4'
                            and ip_slipinno is null
                            and a.plantcode like p_plantcode
                            and a.slipdiv like p_slipdiv
                            and a.slipdate between p_slipsdate and p_slipedate
                            and a.deptcode like p_deptcode || '%'
                            and a.empcode like p_empcode || '%'
                            and nvl(a.acautorcode, ' ') like p_acautorcode || '%'
                            and a.eviddiv like p_eviddiv
                            and (p_printdiv = '%' or
                                 p_printdiv = '01' and a.printdate is not null or
                                 p_printdiv = '02' and a.printdate is null)
                            and (nvl(b.mngcluval,' ') like '%' || p_slipinremark || '%' or
                                 nvl(b.mngcludec,' ' ) like '%' || p_slipinremark || '%')
                ) b on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                left join CMDEPTM c                 -- 발의부서
                    on a.deptcode = c.deptcode
                left join CMEMPM d                  -- 발의자
                    on a.empcode = d.empcode
                left join CMDEPTM e                 -- 승인부서
                    on a.slipdeptcode = e.deptcode
                left join CMEMPM f                  -- 승인자
                    on a.slipempcode = f.empcode
                left join CMDEPTM g                 -- 송금의뢰부서
                    on a.skreqdeptcode = g.deptcode
                left join CMEMPM h                  -- 송금의뢰자
                    on a.skreqempcode = h.empcode
                left join CMCOMMONM i               -- 송금의뢰유형
                    on i.cmmcode = 'AC27'
                    and a.skreqdiv = i.divcode
                left join CMPLANTM j                -- 사업장
                    on a.plantcode = j.plantcode
        order by slipno;

    elsif (p_div = 'SD') then -- 회계전표상세내역 검색
        open IO_CURSOR for
        select  nvl(a.compcode,'') as compcode,   -- 회사코드
                nvl(a.slipinno,'') as slipinno,   -- 전표번호
                nvl(a.slipinseq,0) as slipinseq,  -- 순번
                nvl(a.dcdiv,'') as dcdiv,         -- 차대구분
                nvl(a.acccode,'') as acccode,     -- 계정코드
                nvl(a.plantcode,'') as plantcode, -- 사업장
                nvl(a.debamt,0) as debamt,        -- 차변금액
                nvl(a.creamt,0) as creamt,        -- 대변금액
                nvl(a.slipdate,'') as slipdate,   -- 회계일자
                nvl(a.slipnum,'') as slipnum,     -- 승인넘버
                nvl(a.fundcode,'') as fundcode,   -- 자금구분
                nvl(d.fundname,'') as fundname,   -- 자금구분명
                nvl(a.remark1,'') as remark1,     -- 적요
                nvl(a.remark2,'') as remark2,     -- 적요2
                nvl(a.taxno,'') as taxno,         -- 계산서번호
                nvl(b.accname,'') as accname,     -- 계정명
                nvl(c.usediv,'9') as usediv,      -- 팝업
                nvl(c.popdiv,'') as popdiv,       -- 팝업종류
                nvl(b.dcdiv,'') as adcdiv         -- 계정차대구분
        from    ACORDD a
                left join ACACCM b -- 계정과목
                    on a.acccode = b.acccode
                left join (
                    select  nvl(a.filter1,'') as acccode,
                            nvl(b.filter1,'0') as usediv,
                            nvl(b.filter2,'') as popdiv
                    from    CMCOMMONM a
                            join CMCOMMONM b
                                on a.hcmmcode = b.cmmcode
                                and a.hdivcode = b.divcode
                                and b.usediv = 'Y'
                    where   a.cmmcode = 'AC251'
                            and a.usediv = 'Y'
                ) c on a.acccode like c.acccode || '%'
                left join ACFUNDM d
                    on a.compcode = d.compcode
                    and a.fundcode = d.fundcode
        where   a.compcode = p_compcode
                and a.slipinno = upper(trim(ip_slipinno))
        order by a.slipinseq;

    elsif (p_div = 'SS') then -- 회계전표관리항목내역 검색
        open IO_CURSOR for
        select  nvl(a.compcode,'') as compcode,     -- 회사코드
                nvl(a.slipinno,'') as slipinno,     -- 전표번호
                nvl(a.slipinseq,0) as slipinseq,    -- 순번
                nvl(a.seq,0) as seq,                -- 일련번호
                nvl(a.mngclucode,'') as mngclucode, -- 관리항목코드
                nvl(a.mngcluval,'') as mngcluval,   -- 관리항목값
                nvl(a.mngcludec,'') as mngcludec,   -- 관리항목값명
                nvl(d.mngcluname,'') as mngcluname, -- 관리항목명
                nvl(c.requireyn,'') as requireyn,   -- 필수입력여부
                nvl(c.returnyn,'') as returnyn,     -- 반제여부
                nvl(c.remainyn,'') as remainyn,     -- 잔액관리여부
                nvl(d.mngcludiv,'') as mngcludiv,   -- 관리항목형태
                nvl(d.codehelp,'') as codehelp      -- 코드헬프번호
        from    ACORDS a
                join ACORDD b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
                left join ACACCMNGM c               -- 관리항목필수여부
                    on b.acccode = c.acccode
                    and c.dcdiv = case when b.dcdiv in ('1','4') then '1' else '2' end
                    and a.mngclucode = c.mngclucode
                left join ACMNGM d
                    on a.mngclucode = d.mngclucode  -- 관리항목정보
        where   a.compcode = p_compcode
                and a.slipinno = upper(trim(ip_slipinno))
        order by a.slipinseq, c.seq;

    elsif (p_div = 'SA') then -- 계정별 관리항목 검색
        open IO_CURSOR for
        select  nvl(a.seq,0) as seq,                -- 일련번호
                nvl(a.mngclucode,'') as mngclucode, -- 관리항목코드
                '' as mngcluval,                    -- 관리항목값
                '' as mngcludec,                    -- 관리항목값명
                nvl(a.mngcluname,'') as mngcluname, -- 관리항목명
                nvl(a.requireyn,'') as requireyn,   -- 필수입력여부
                nvl(a.returnyn,'') as returnyn,     -- 반제여부
                nvl(a.remainyn,'') as remainyn,     -- 잔액관리여부
                nvl(b.mngcludiv,'') as mngcludiv,   -- 관리항목형태
                nvl(b.codehelp,'') as codehelp,     -- 코드헬프번호
                nvl(c.usediv, '9') as usediv,       -- 팝업
                nvl(c.popdiv,'') as popdiv,         -- 팝업종류
                nvl(d.dcdiv,'') as adcdiv           -- 계정차대구분
        from    ACACCMNGM a
                left join ACMNGM b -- 관리항목정보
                    on a.mngclucode = b.mngclucode
                left join (
                    select  nvl(a.filter1,'') acccode,
                            nvl(nullif(trim(b.filter1), null), '0') usediv,
                            nvl(b.filter2,'') popdiv
                    from    CMCOMMONM a
                            join CMCOMMONM b
                                on a.hcmmcode = b.cmmcode
                                and a.hdivcode = b.divcode
                                and b.usediv = 'Y'
                    where   a.cmmcode = 'AC251'
                            and a.usediv = 'Y'
                ) c on a.acccode like c.acccode || '%'
                left join ACACCM d
                    on a.acccode = d.acccode
        where   a.acccode = p_acccode
                and a.dcdiv = case when p_dcdiv in ('1','4') then '1' else '2' end
        order by a.seq;

    elsif (p_div in ('L', 'L1', 'L2', 'L3', 'LG')) then
        -- 리포트 양식용
        if( p_div = 'L1' or p_rptname in ('ACacc0100CR2', 'ACacc0102CR2') ) then -- 가로 리포트
            p_rowcnt1 := 7;
            p_rowcnt2 := 7;
            p_formtype := 0;
        elsif( p_div = 'L2' ) then -- A5 리포트
            p_rowcnt1 := 4;
            p_rowcnt2 := 4;
            p_formtype := 1;
            ip_rptsize := '1';
        elsif( p_div = 'L3' or p_rptname in ('ACacc0100CR3', 'ACacc0102CR3') ) then -- 세로 리포트
            p_rowcnt1 := 8;
            p_rowcnt2 := 11;
            p_formtype := 1;
        elsif( p_rptname in ('ACacc0100CR6', 'ACacc0102CR6') ) then -- 세로 리포트
            p_rowcnt1 := 6;
            p_rowcnt2 := 10;
            p_formtype := 1;
        elsif( p_rptname in ('ACacc0100CR7', 'ACacc0102CR7') ) then -- 세로 리포트
            p_rowcnt1 := 10;
            p_rowcnt2 := 10;
            p_formtype := 1;
        elsif( p_rptname in ('ACacc0100CR1', 'ACacc0102CR1') ) then
            if (ip_rptsize = '1') then -- A5
                p_rowcnt1 := 4;
                p_rowcnt2 := 4;
                p_formtype := 1;
            else
                p_rowcnt1 := 13;
                p_rowcnt2 := 13;
                p_formtype := 1;
            end if;
        elsif( p_rptname in ('ACacc0100CR4', 'ACacc0102CR4', 'ACacc0100CR5', 'ACacc0102CR5') ) then
            if p_rptauto = 'Y' then
                for rec in (select  case when sum(case when dcdiv in ('1','2') then 1 else 2 end) <= 6 then '1' else '2' end as rptsize
                            from    ACORDD
                            where   slipinno = substr(ip_slipinno1, 1, instr(ip_slipinno1, ';') - 1))
                loop
                    ip_rptsize := rec.rptsize;
                end loop;

            end if;

            if (ip_rptsize = '1') then -- A5
                p_rowcnt1 := 6;
                p_rowcnt2 := 6;
                p_formtype := 1;
            else
                p_rowcnt1 := 20;
                p_rowcnt2 := 20;
                p_formtype := 1;
            end if;
        end if;

        p_rptname1 := 'ACacc0100CR7';
        select  value1 into p_rptname1
        from    SYSPARAMETERMANAGE
        where   parametercode = 'accsliprpt';

        p_cashprt := 2;
        p_ordseq := 1;

        execute immediate ' delete from VGT.TT_ACACC0000R_TEMP ';
        while( instr(ip_temp1, ';') > 0 )
        loop
            v_temp1 := '20'||substr(ip_temp1,0, instr(ip_temp1, ';')-1);
            v_temp2 := substr(ip_temp2,0, instr(ip_temp2, ';')-1);

            ip_temp1 := substr(ip_temp1, instr(ip_temp1, ';')+1, length(ip_temp1) );
            ip_temp2 := substr(ip_temp2, instr(ip_temp2, ';')+1, length(ip_temp2) );

            v_temp := v_temp1 || v_temp2;

            insert into VGT.TT_ACACC0000R_TEMP
            values (p_ordseq, null, v_temp, null, 0);

            p_ordseq := p_ordseq + 1;
        end loop;

        if p_div = 'LG' then
            open IO_CURSOR for
            select  nvl(b.compcode,'') as compcode
                    ,'' as slipinno
                    ,nvl(b.deptcode,'') as deptcode
                    ,nvl(b.acccode,'') as acccode
                    ,nvl(b.accname,'') as accname
                    ,nvl(b.creamt,0) as creamt
                    ,nvl(b.debamt,0) as debamt
                    ,nvl(b.remark1,'') as remark1
                    ,nvl(case a.slipdiv when '1' then '대체' when '3' then '입금' else '출금' end,'') as dcdiv
                    ,nvl(b.deptname,'') as deptname
                    ,nvl(b.prnseq,0) as prnseq
                    ,case when a.prnseq <= p_rowcnt1 or p_formtype = 0 then 0
                          else trunc( 1 + (a.prnseq - p_rowcnt1 - 1) / p_rowcnt2 )
                          end as seq
                    ,'' as mngcludec1
                    ,'' as mngcludec2
                    ,'' as mngcludec3
                    ,case when b.compcode is null or b.prnseq in (1, a.rownums) then sumdebamt end as sumdebamt
                    ,case when b.compcode is null or b.prnseq in (1, a.rownums) then sumcreamt end as sumcreamt
                    ,coalesce(nullif(c.plantfullname,''),c.plantname,'') as plantname
                    ,'' as taxno
                    ,'' as taxno1
                    ,'' as taxno2
                    ,'' as slipno
                    ,a.plantcode || a.slipdiv ||
                     substr('00' || case when a.prnseq <= p_rowcnt1 then '0' else to_char( trunc( 1 + (a.prnseq - p_rowcnt1 - 1) / p_rowcnt2 ) ) end, -3, 3) as gubun
                    ,to_char( case when a.prnseq <= p_rowcnt1 then 1 else trunc( 2 + (a.prnseq - p_rowcnt1 - 1) / p_rowcnt2 ) end ) || ' / ' ||
                     to_char( case when a.rownums <= p_rowcnt1 then 1 else trunc( 2 + (a.rownums - p_rowcnt1 - 1) / p_rowcnt2 ) end ) as pageno
                    ,b.empname
                    ,case when d.compcode is not null then d.pathname0 else e.pathname0 end as pathname0
                    ,case when d.compcode is not null then d.pathname1 else e.pathname1 end as pathname1
                    ,case when d.compcode is not null then d.pathname2 else e.pathname2 end as pathname2
                    ,case when d.compcode is not null then d.pathname3 else e.pathname3 end as pathname3
                    ,case when d.compcode is not null then d.pathname4 else e.pathname4 end as pathname4
                    ,case when d.compcode is not null then d.pathname5 else e.pathname5 end as pathname5
                    ,case when d.compcode is not null then d.pathname6 else e.pathname6 end as pathname6
                    ,case when d.compcode is not null then d.pathname7 else e.pathname7 end as pathname7
                    ,case when d.compcode is not null then d.pathname8 else e.pathname8 end as pathname8
                    ,case when d.compcode is not null then d.pathname9 else e.pathname9 end as pathname9
                    ,case when d.compcode is not null then d.pathname10 else e.pathname10 end as pathname10
                    ,case when d.compcode is not null then d.pathname11 else e.pathname11 end as pathname11
                    ,case when d.compcode is not null then d.pathname12 else e.pathname12 end as pathname12
                    ,case when d.compcode is not null then d.pathname13 else e.pathname13 end as pathname13
                    ,case when d.compcode is not null then d.pathname14 else e.pathname14 end as pathname14
                    ,nvl(f.value1,'담당부서') as pathtitle1
                    ,nvl(f.value2,'자금부서') as pathtitle2
                    ,nvl(f.value3,'회계부서') as pathtitle3
                    ,p_rptsize as rptsize
                    ,nvl(lengthb(b.remark1),0) as remark1_len
                    ,fnwontostring(sumdebamt) as hanslipamt
                    ,a.slipinremark
                    ,substr(a.strdate,-5) || ' ~ ' || substr(a.enddate,-5) as slipindate	--등록일자
            
            from (
                select	a.plantcode, a.slipdiv, b.seq as prnseq, a.rownums, a.sumdebamt, a.sumcreamt, a.strdate, a.enddate, a.slipinremark
                from (
                    select  b.plantcode, case when b.dcdiv in ('1','2') then '1' else b.dcdiv end as slipdiv, count(distinct b.dcdiv || b.acccode) as rownums,
                            min(c.slipindate) as strdate, max(c.slipindate) as enddate, max(c.slipinremark) as slipinremark, sum(b.debamt) as sumdebamt, sum(b.creamt) as sumcreamt
                    from    VGT.TT_ACACC0000R_TEMP a
                            join ACORDD b
                                on b.compcode = p_compcode
                                and a.slipinno = b.slipinno
                            join ACORDM c
                                on b.compcode = c.compcode
                                and b.slipinno = c.slipinno
                    group by b.plantcode, case when b.dcdiv in ('1','2') then '1' else b.dcdiv end
                ) a
                        join SYSCALENDARMASTER b
                            on case when a.rownums <= p_rowcnt1 then p_rowcnt1
                            else ((a.rownums - p_rowcnt1 - 1) / p_rowcnt2 + 1) * p_rowcnt2 + p_rowcnt1 end >= b.seq
            ) a
            left join (
                select  b.compcode, b.plantcode, max(case when b.dcdiv in ('1', '2') then '1' else b.dcdiv end) as slipdiv, b.dcdiv, b.acccode,
                        sum(b.debamt) as debamt, sum(b.creamt) as creamt, max(b.remark1) as remark1, max(c.accname) as accname,
                        max(d.empcode) as empcode, max(d.empname) as empname, max(e.deptcode) as deptcode, max(e.deptname) as deptname,
                        row_number()over(partition by b.plantcode, max(case when b.dcdiv in ('1', '2') then '1' else b.dcdiv end) order by b.dcdiv, b.acccode) as prnseq
                from    VGT.TT_ACACC0000R_TEMP a
                        join ACORDD b
                            on b.compcode = p_compcode
                            and a.slipinno = b.slipinno
                        left join ACACCM c
                            on b.acccode = c.acccode
                        left join CMEMPM d
                            on d.empcode = p_userid
                        left join CMDEPTM e
                            on d.deptcode = e.deptcode
                group by b.compcode, b.plantcode, b.dcdiv, b.acccode
            ) b on a.plantcode = b.plantcode
                and a.slipdiv = b.slipdiv
                and a.prnseq = b.prnseq
            left join CMPLANTM c
                on a.plantcode = c.plantcode
            left join ACORPATH d
                on b.compcode = d.compcode
                and case when p_pathcode = 'emp' then b.empcode else b.deptcode end = d.deptcode
            left join ACORPATH e
                on b.compcode = e.compcode
                and e.deptcode = ''
            left join SYSPARAMETERMANAGE f
                on f.parametercode = 'accslipsigntitle'
            
            order by gubun, a.prnseq;
        else
            merge into VGT.TT_ACACC0000R_TEMP a
            using (
                select  a.ordseq,
                        b.plantcode,
                        case when b.dcmin = 1 and b.dcmax = 1 then '1'
                             when b.dcmin = 1 and b.dcmax = 2 then '1'
                             when b.dcmin = 1 and b.dcmax = 3 then '2'
                             when b.dcmin = 1 and b.dcmax = 4 then '2'
                             when b.dcmin = 2 and b.dcmax = 2 then '1'
                             when b.dcmin = 2 and b.dcmax = 3 then '2'
                             when b.dcmin = 2 and b.dcmax = 4 then '2'
                             when b.dcmin = 3 and b.dcmax = 3 then '3'
                             when b.dcmin = 3 and b.dcmax = 4 then '2'
                             when b.dcmin = 4 and b.dcmax = 4 then '4'
                        end as dcdiv,
                        case when b.rownums <= p_rowcnt1 then p_rowcnt1
                             else ( trunc((b.rownums - p_rowcnt1 - 1) / p_rowcnt2 ) + 1) * p_rowcnt2 + p_rowcnt1
                             end as rownums
                from    VGT.TT_ACACC0000R_TEMP a
                        join (
                            select  a.slipinno,
                                    max(a.plantcode) as plantcode,
                                    min(a.dcdiv) as dcmin,
                                    max(a.dcdiv) as dcmax,
                                    sum(case when p_cashprt = 1 and a.dcdiv in ('3', '4') then 2 else 1 end) as rownums
                            from    ACORDD a
                                    join VGT.TT_ACACC0000R_TEMP b on a.slipinno = b.slipinno
                            where   a.compcode = p_compcode
                            group by a.slipinno
                        ) b on a.slipinno = b.slipinno
            ) b on ( a.ordseq = b.ordseq )
            when matched then
            update set  a.plantcode = b.plantcode,
                        a.dcdiv     = b.dcdiv,
                        a.rownum_   = b.rownums;
    
            execute immediate ' delete from VGT.TT_ACACC0000R_ACORDS ';
            insert into VGT.TT_ACACC0000R_ACORDS
            select  slipinno,
                    slipinseq,
                    max(case when seq = 1 then mngcluval else '' end) as mngcluval1,
                    max(case when seq = 2 then mngcluval else '' end) as mngcluval2,
                    max(case when seq = 3 then mngcluval else '' end) as mngcluval3,
                    max(case when seq = 1 then mngcludec else '' end) as mngcludec1,
                    max(case when seq = 2 then mngcludec else '' end) as mngcludec2,
                    max(case when seq = 3 then mngcludec else '' end) as mngcludec3
            from (
                select  a.slipinno ,
                        a.slipinseq, row_number() over(partition by a.slipinno, a.slipinseq order by a.seq) as seq,
                        nvl(a.mngcluval,'') as mngcluval,
                        nvl(a.mngcludec,'') as mngcludec3,
                        nvl(a.mngcluval,'') || ' : ' || nvl(a.mngcludec,'') ||
                        case when nvl(trim(d.custcode),'') is null then ''
                             else case when nvl(trim(d.businessno),'') is null then ''
                                       else ' (' || d.businessno || ')'
                                  end
                             end as mngcludec2,
                        nvl(a.mngcluval,'') || nvl('-' || nullif(a.mngcludec,''),'') ||
                        case when nvl(trim(d.custcode),'') is null then ''
                             else case when nvl(trim(d.businessno),'') is null then ''
                                       else ' (' || d.businessno || ')'
                                  end
                             end as mngcludec
                from    ACORDS a
                        join VGT.TT_ACACC0000R_TEMP b
                            on a.slipinno = b.slipinno
                        left join ACMNGM c
                            on a.mngclucode = c.mngclucode
                        left join CMCUSTM d
                            on a.mngclucode = 'S010'
                            and a.mngcluval = d.custcode
                        join ACORDM e
                            on a.compcode = e.compcode
                            and a.slipinno = e.slipinno
                where   a.compcode = p_compcode
            ) a
            group by slipinno, slipinseq;
    
            for rec in (
                select  value1
                from    SYSPARAMETERMANAGE
                where   parametercode = 'acccashcode'
            )
            loop
                ip_acccode := rec.value1;
            end loop;
    
            execute immediate ' delete from VGT.TT_ACACC0000R_ACORDD ';
            insert into VGT.TT_ACACC0000R_ACORDD
            select  a.compcode
                    ,a.slipinno
                    ,a.deptcode
                    ,h.deptname
                    ,case when (c.dcdiv = '2' or p_cashprt = 1) and (e.grp = 1 and b.dcdiv = '3' or e.grp = 2 and b.dcdiv = '4')
                          then f.acccode else b.acccode end as acccode
                    ,case when (c.dcdiv = '2' or p_cashprt = 1) and (e.grp = 1 and b.dcdiv = '3' or e.grp = 2 and b.dcdiv = '4')
                          then f.accname else g.accname end as accname
                    ,case when (c.dcdiv = '2' or p_cashprt = 1) and (e.grp = 1 and b.dcdiv = '3' or e.grp = 2 and b.dcdiv = '4')
                          then '' else d.mngcludec1 end as mngcludec1
                    ,case when (c.dcdiv = '2' or p_cashprt = 1) and (e.grp = 1 and b.dcdiv = '3' or e.grp = 2 and b.dcdiv = '4')
                          then '' else d.mngcludec2 end as mngcludec2
                    ,case when (c.dcdiv = '2' or p_cashprt = 1) and (e.grp = 1 and b.dcdiv = '3' or e.grp = 2 and b.dcdiv = '4')
                          then '' else d.mngcludec3 end as mngcludec3
                    ,case when (c.dcdiv = '2' or p_cashprt = 1) and b.dcdiv in ('3','4')
                          then case when e.grp = 1 and b.dcdiv = '3' then b.creamt
                                    when e.grp = 1 and b.dcdiv = '4' then b.debamt
                                    else 0 end
                          else b.debamt end as debamt
                    ,case when (c.dcdiv = '2' or p_cashprt = 1) and b.dcdiv in ('3','4')
                          then case when e.grp = 2 and b.dcdiv = '3' then b.creamt
                                    when e.grp = 2 and b.dcdiv = '4' then b.debamt
                                    else 0 end
                          else b.creamt end as creamt
                    ,case when nvl(trim(l.billno),'') is null then b.remark1 else l.billno || '-' || nvl(trim(m.divname),'') || '-만기:' || l.expdate end as remark1
                    ,case when nvl(trim(b.taxno),'') is not null then b.taxno || ';' || fncomma(j.amt)
                                                                               || ';' || fncomma(j.vat)
                                                                               || case when j.electaxyn = 'Y' then ';전자' else '' end
                          else '' end as taxno
                    ,case when nvl(trim(b.taxno),'') is not null then '계산서번호:' || b.taxno || ' 전자:' || j.electaxyn
                          else '' end as taxno1
                    ,case when nvl(trim(b.taxno),'') is not null then '발행일자:' || j.taxdate || ' 사업자번호:' || j.businessno || ' 금액:' || fncomma(j.amt)
                                                                       || ' 세액:' || fncomma(j.vat) || ' 구분:' || k.divname
                          else '' end as taxno2
                    ,case when c.dcdiv = '1' then '대체'
                          when c.dcdiv = '2' then '대체'
                          when c.dcdiv = '3' then '입금'
                          when c.dcdiv = '4' then '출금'
                    end as dcdiv
                    ,row_number() over (partition by b.slipinno order by b.slipinseq, e.grp) as prnseq
                    ,a.empcode
                    ,i.empname
                    ,a.slipinremark || case when nvl(trim(a.slipincomment),'') is not null then ';' || a.slipincomment else '' end as slipinremark
            from    ACORDM a
                    join ACORDD b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
                    join VGT.TT_ACACC0000R_TEMP c
                        on a.slipinno = c.slipinno
                    left join VGT.TT_ACACC0000R_ACORDS d
                        on b.slipinno = d.slipinno
                        and b.slipinseq = d.slipinseq
                    join (
                        select  1 as grp
                        from    DUAL
                        union
                        select  2
                        from    DUAL
                    ) e on e.grp = 1
                        or (c.dcdiv = '2' or p_cashprt = 1) and b.dcdiv in ('3','4')
                    left join ACACCM f
                        on f.acccode = ip_acccode
                    left join ACACCM g
                        on b.acccode = g.acccode
                    left join CMDEPTM h
                        on a.deptcode = h.deptcode
                    left join CMEMPM i
                        on a.empcode = i.empcode
                    left join ACTAXM j
                        on b.compcode = j.compcode
                        and b.plantcode = j.plantcode
                        and b.taxno = j.taxno
                    left join CMCOMMONM k
                        on k.cmmcode = 'AC86'
                        and j.purdiv = k.divcode
                    left join ACBILLM l
                        on a.compcode = l.compcode
                        and (d.mngcluval1 = l.billno or d.mngcluval2 = l.billno or d.mngcluval3 = l.billno)
                    left join CMCOMMONM m
                        on m.cmmcode = case when l.billcls = '1' then 'AC53' else 'AC54' end
                        and case when a.slipinno like '%C%' then '1' else l.billstate end = m.divcode;
    
            open IO_CURSOR for
            select  nvl(b.compcode,'') as compcode
                    ,case when p_rptname = p_rptname1 then substr(a.slipinno, 1, 8) || '-' || substr(a.slipinno, -5)
                          else substr(a.slipno, 1, 8) || '-' || substr(a.slipno, -5)
                          end as slipinno
                    ,nvl(b.deptcode,'') as deptcode
                    ,nvl(b.acccode,'') as acccode
                    ,nvl(b.accname,'') as accname
                    ,nvl(b.creamt,0) as creamt
                    ,nvl(b.debamt,0) as debamt
                    ,nvl(b.remark1,'') as remark1
                    ,nvl(b.dcdiv,'') as dcdiv
                    ,nvl(b.deptname,'') as deptname
                    ,nvl(b.prnseq,0) as prnseq
                    ,case when a.prnseq <= p_rowcnt1 or p_formtype = 0 then 0
                          else trunc( 1 + (a.prnseq - p_rowcnt1 - 1) / p_rowcnt2 )
                          end as seq
                    ,nvl(b.mngcludec1,'') as mngcludec1
                    ,nvl(b.mngcludec2,'') as mngcludec2
                    ,nvl(b.mngcludec3,'') as mngcludec3
                    ,case when nvl(trim(b.slipinno),'') is null or b.prnseq in (1, a.rownum_) then sumdebamt end as sumdebamt
                    ,case when nvl(trim(b.slipinno),'') is null or b.prnseq in (1, a.rownum_) then sumcreamt end as sumcreamt
                    ,coalesce(nullif(c.plantfullname,''), c.plantname,'') as plantname
                    ,nvl(b.taxno,'') as taxno
                    ,nvl(b.taxno1,'') as taxno1
                    ,nvl(b.taxno2,'') as taxno2
                    ,substr(a.slipno,0, 8) || '-' || substr(a.slipno, -5, 5) as slipno
                    ,substr('00' || to_char(a.ordseq), -3, 3) ||
                     a.slipinno ||
                     substr('00' || case when a.prnseq <= p_rowcnt1 then '0' else to_char( trunc( 1 + (a.prnseq - p_rowcnt1 - 1) / p_rowcnt2 ) ) end, -3, 3) as gubun
                    ,to_char( case when a.prnseq <= p_rowcnt1 then 1 else trunc( 2 + (a.prnseq - p_rowcnt1 - 1) / p_rowcnt2 ) end ) || ' / ' ||
                     to_char( case when a.rownum_ <= p_rowcnt1 then 1 else trunc( 2 + (a.rownum_ - p_rowcnt1 - 1) / p_rowcnt2 ) end ) as pageno
                    ,b.empname
                    ,case when e.compcode is not null then e.pathname0 else f.pathname0 end as pathname0
                    ,case when e.compcode is not null then e.pathname1 else f.pathname1 end as pathname1
                    ,case when e.compcode is not null then e.pathname2 else f.pathname2 end as pathname2
                    ,case when e.compcode is not null then e.pathname3 else f.pathname3 end as pathname3
                    ,case when e.compcode is not null then e.pathname4 else f.pathname4 end as pathname4
                    ,case when e.compcode is not null then e.pathname5 else f.pathname5 end as pathname5
                    ,case when e.compcode is not null then e.pathname6 else f.pathname6 end as pathname6
                    ,case when e.compcode is not null then e.pathname7 else f.pathname7 end as pathname7
                    ,case when e.compcode is not null then e.pathname8 else f.pathname8 end as pathname8
                    ,case when e.compcode is not null then e.pathname9 else f.pathname9 end as pathname9
                    ,case when e.compcode is not null then e.pathname10 else f.pathname10 end as pathname10
                    ,case when e.compcode is not null then e.pathname11 else f.pathname11 end as pathname11
                    ,case when e.compcode is not null then e.pathname12 else f.pathname12 end as pathname12
                    ,case when e.compcode is not null then e.pathname13 else f.pathname13 end as pathname13
                    ,case when e.compcode is not null then e.pathname14 else f.pathname14 end as pathname14
                    ,nvl(h.value1,'담당부서') as pathtitle1
                    ,nvl(h.value2,'자금부서') as pathtitle2
                    ,nvl(h.value3,'회계부서') as pathtitle3
                    ,p_rptsize as rptsize
                    ,nvl(lengthb(b.remark1),0) as remark1_len
                    ,fnwontostring(sumdebamt) as hanslipamt
                    ,b.slipinremark
                    ,case when p_rptname = p_rptname1 then substr(a.slipindate, 1, 4) || '년 ' || substr(a.slipindate, 6, 2) || '월 ' || substr(a.slipindate, -2) || '일'
                          else substr(a.slipdate, 1, 4) || '년 ' || substr(a.slipdate, 6, 2) || '월 ' || substr(a.slipdate, -2) || '일'
                          end as slipindate    --등록일자
            from (
                select  a.ordseq
                        ,a.slipinno
                        ,b.seq as prnseq
                        ,a.rownum_
                        ,a.plantcode
                        ,c.slipno
                        ,c.slipindate
                        ,c.slipdate
                        ,c.slipdiv
                from    VGT.TT_ACACC0000R_TEMP a
                        join SYSCALENDARMASTER b
                            on a.rownum_ >= b.seq
                        left join ACORDM c
                            on c.compcode = p_compcode
                            and a.slipinno = c.slipinno
            ) a
                    left join VGT.TT_ACACC0000R_ACORDD b
                        on a.slipinno = b.slipinno
                        and a.prnseq = b.prnseq
                    left join CMPLANTM c
                        on a.plantcode = c.plantcode
                    left join CMEMPM d
                        on d.empcode = p_userid
                        and p_rptname = 'ACacc0102CR3'
                        and a.slipdiv not in ('A','F','K')
                    left join ACORPATH e
                        on b.compcode = e.compcode
                        and case when p_pathcode = 'emp' then nvl(d.empcode, b.empcode)
                                 else nvl(d.deptcode,b.deptcode)
                                 end = e.deptcode
                    left join ACORPATH f
                        on b.compcode = f.compcode
                        and f.deptcode = ' '
                    left join (
                        select  slipinno
                                ,sum(debamt) as sumdebamt
                                ,sum(creamt) as sumcreamt
                        from    VGT.TT_ACACC0000R_ACORDD
                        group by slipinno
                    ) g on a.slipinno = g.slipinno
                    left join SYSPARAMETERMANAGE h
                        on h.parametercode = 'accslipsigntitle'
            order by gubun, a.slipinno, a.prnseq;
        end if;

        -- 출력일자 변경
        merge into ACORDM a
        using (
            select  a.slipinno,
                    to_char(sysdate, 'yyyy-mm-dd') as printdate
            from    VGT.TT_ACACC0000R_TEMP a
                    join ACORDM b
                        on a.slipinno = b.slipinno
        ) b on ( a.slipinno = b.slipinno )
        when matched then
            update set a.printdate = b.printdate;

    --지출결의서 조회 2015-08-24: 이세민
    elsif (p_div = 'LSR') then
        p_acccode1 := '11101010';
        select  filter2 into p_acccode1
        from    CMCOMMONM
        where   cmmcode = 'AC159'
                and divcode = '001';

        p_acccode2 := '11101031';
        select  filter2 into p_acccode2
        from    CMCOMMONM
        where   cmmcode = 'AC159'
                and divcode = '021';

        p_acccode3 := '11138';
        p_acccode4 := '21030';
        p_acccode5 := '21010100';
        select  filter1 into p_acccode5
        from    CMCOMMONM
        where   cmmcode = 'AC261'
                and divcode = '21010100';

        select  nvl(max('I'), p_inoutdiv) into p_inoutdiv
        from    ACORDD
        where   compcode = p_compcode
                and slipinno = upper(trim(ip_slipinno))
                and (dcdiv = '1' and acccode in (p_acccode1, p_acccode2) or
                     dcdiv = '3');

        open IO_CURSOR for
        select  row_number() over (order by mngcluval) as prtdiv,
                d.empname, --사원명
                e.deptname, --부서명
                substr(a.slipindate,0, 4) || '년 ' || substr(a.slipindate, 6, 2) || '월 ' || substr(a.slipindate, -2, 2) || '일' as slipindate, --등록일자
                c.mngcludec, --거래처명
                c.mngcluval, --거래처코드
                case when b.datadiv is null then nvl(b.remark2, g.divname) else '' end as paydivnm, --지불조건
                b.debamt - b.creamt as debamt, --금액
                b.remark1 || case when b.acccode like '11135%' then ' 부가세' when b.acccode = '74320000' then ' 잡이익' else '' end as remark1, --적요
                a.slipinremark, --비고
                substr(a.slipinno,0, 8) || '-' || substr(a.slipinno, -5, 5) as slipinno,
                b.slipinseq,
                b.compcode,
                nvl(h.pathname0, i.pathname0) as pathname0,
                nvl(h.pathname1, i.pathname1) as pathname1,
                nvl(h.pathname2, i.pathname2) as pathname2,
                nvl(h.pathname3, i.pathname3) as pathname3,
                nvl(h.pathname4, i.pathname4) as pathname4,
                nvl(h.pathname5, i.pathname5) as pathname5,
                nvl(h.pathname6, i.pathname6) as pathname6,
                nvl(h.pathname7, i.pathname7) as pathname7,
                nvl(h.pathname8, i.pathname8) as pathname8,
                nvl(h.pathname9, i.pathname9) as pathname9,
                nvl(h.pathname10, i.pathname10) as pathname10,
                nvl(h.pathname11, i.pathname11) as pathname11,
                nvl(h.pathname12, i.pathname12) as pathname12,
                nvl(h.pathname13, i.pathname13) as pathname13,
                nvl(h.pathname14, i.pathname14) as pathname14,
                '지 출 결 의 서' as title1,
                '다음과 같이 지출코져 하오니 승인하여 주시기 바랍니다.' as title2,
                nvl(j.value1, '결 재') as pathtitle1,
                nvl(j.value2, '담당부서') as pathtitle2,
                coalesce(k.plantfullname, k.plantname, null) as plantname
        from    ACORDM a
                join ACORDD b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                left join ACORDS c
                    on b.compcode = c.compcode
                    and b.slipinno = c.slipinno
                    and b.slipinseq = c.slipinseq
                    and c.mngclucode = 'S010'
                left join CMEMPM d
                    on a.empcode = d.empcode
                left join CMDEPTM e
                    on a.deptcode = e.deptcode
                left join CMCUSTM f
                    on c.mngcluval = f.custcode
                left join CMCOMMONM g
                    on g.cmmcode = 'CM44'
                    and f.paydiv = g.divcode
                left join ACORPATH h
                    on a.compcode = h.compcode
                    and case when p_pathcode = 'emp' then a.empcode else a.deptcode end = h.deptcode
                left join ACORPATH i
                    on a.compcode = i.compcode
                    and i.deptcode is null
                left join SYSPARAMETERMANAGE j
                    on j.parametercode = 'accslipsigntitle'
                left join CMPLANTM k
                    on a.plantcode = k.plantcode
        where   a.compcode = p_compcode
                and a.slipinno = upper(trim(ip_slipinno))
                and p_inoutdiv = 'O'
                and not (b.dcdiv = '2' and (b.acccode in (p_acccode1, p_acccode2, p_acccode5) or
                         b.acccode like p_acccode3 || '%' or
                         b.acccode like p_acccode4 || '%'))

        union all

        select  row_number() over (order by mngcluval) as prtdiv,
                d.empname, --사원명
                e.deptname, --부서명
                substr(a.slipindate,0, 4) || '년 ' || substr(a.slipindate, 6, 2) || '월 ' || substr(a.slipindate, -2) || '일' as slipindate, --등록일자
                c.mngcludec, --거래처명
                c.mngcluval, --거래처코드
                '' paydivnm, --지불조건
                b.creamt - b.debamt as debamt, --금액
                b.remark1, --적요
                a.slipinremark, --비고
                substr(a.slipinno,0, 8) || '-' || substr(a.slipinno, -5, 5) as slipinno,
                b.slipinseq,
                b.compcode,
                nvl(h.pathname0, i.pathname0) as pathname0,
                nvl(h.pathname1, i.pathname1) as pathname1,
                nvl(h.pathname2, i.pathname2) as pathname2,
                nvl(h.pathname3, i.pathname3) as pathname3,
                nvl(h.pathname4, i.pathname4) as pathname4,
                nvl(h.pathname5, i.pathname5) as pathname5,
                nvl(h.pathname6, i.pathname6) as pathname6,
                nvl(h.pathname7, i.pathname7) as pathname7,
                nvl(h.pathname8, i.pathname8) as pathname8,
                nvl(h.pathname9, i.pathname9) as pathname9,
                nvl(h.pathname10, i.pathname10) as pathname10,
                nvl(h.pathname11, i.pathname11) as pathname11,
                nvl(h.pathname12, i.pathname12) as pathname12,
                nvl(h.pathname13, i.pathname13) as pathname13,
                nvl(h.pathname14, i.pathname14) as pathname14,
                '입 금 결 의 서' as title1,
                '다음과 같이 입금코져 하오니 승인하여 주시기 바랍니다.' as title2,
                nvl(j.value1, '결 재') as pathtitle1,
                nvl(j.value2, '담당부서') as pathtitle2,
                coalesce(k.plantfullname, k.plantname, null) as plantname
        from    ACORDM a
                join ACORDD b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                left join ACORDS c
                    on b.compcode = c.compcode
                    and b.slipinno = c.slipinno
                    and b.slipinseq = c.slipinseq
                    and c.mngclucode = 'S010'
                left join CMEMPM d
                    on a.empcode = d.empcode
                left join CMDEPTM e
                    on a.deptcode = e.deptcode
                left join CMCUSTM f
                    on c.mngcluval = f.custcode
                left join CMCOMMONM g
                    on g.cmmcode = 'CM44'
                    and f.paydiv = g.divcode
                left join ACORPATH h
                    on a.compcode = h.compcode
                    and case when p_pathcode = 'emp' then a.empcode else a.deptcode end = h.deptcode
                left join ACORPATH i
                    on a.compcode = i.compcode
                    and i.deptcode is null
                left join SYSPARAMETERMANAGE j
                    on j.parametercode = 'accslipsigntitle'
                left join CMPLANTM k
                    on a.plantcode = k.plantcode
        where   a.compcode = p_compcode
                and a.slipinno = upper(trim(ip_slipinno))
                and p_inoutdiv = 'I'
                and not (b.dcdiv = '1' and b.acccode in (p_acccode1, p_acccode2))
        order by slipinseq;
    end if;

    if (IO_CURSOR is null)
    then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;
END;
/
