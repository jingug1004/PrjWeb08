CREATE PROCEDURE        spAASeek (
   -- ---------------------------------------------------------------
   -- 프로시저명       : spAASeek
   -- 작 성 자         : 조성희
   -- 작성일자         : 2008-10-01
   -- 수 정 자            : 이세민
   -- 수정일자            : 2013-10-01
   -- 수정내용            : salpower 파라미터 일괄 처리 적용.

   --                        2014-02-20. KB Pharm : 거래처코드 뒷자리로 검색
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 코드헬프용 조회문을 작성하는 프로시저이다.
   -- ---------------------------------------------------------------

   /*
            exec spAASeek p_div = 'CMITEMM_P', p_message = ''
            */
   /*
            -- 작성예제(복사해서 사용)
                set p_seektitle        = '프로그램 메뉴코드'
                set p_table            = 'menu'
                set    p_tablekey        =  space(1) || 'menudiv || menucode' || space(1)
                set p_tablecoloums    = 'menudiv || menucode as 메뉴코드, menuname as 메뉴명, menuseq as 순서, menulevel as 메뉴레벨, parentmenu as 상위메뉴코드'
                set    p_coloumsetting    = 'L-100;C-100;R-200;L-200;C-300;'

                select        p_seektitle as name, dbo.fnSeek(p_empcode, p_table, p_tablekey, p_tablecoloums, p_coloumsetting) as sqlstring,' order by ' || p_tablekey || '' as sort, p_coloumsetting as coloumn
            */
   p_div           IN     VARCHAR2 DEFAULT '',
   p_empcode       IN     VARCHAR2 DEFAULT '',
   p_programcode   IN     VARCHAR2 DEFAULT '',
   p_controlname   IN     VARCHAR2 DEFAULT '',
   p_coloumns      IN     VARCHAR2 DEFAULT '',
   p_gbcode        IN     VARCHAR2 DEFAULT '',
   p_useyn         IN     VARCHAR2 DEFAULT '',
   p_gbcode1       IN     VARCHAR2 DEFAULT '',
   p_salpower      IN     VARCHAR2 DEFAULT '',
   p_userid        IN     VARCHAR2 DEFAULT '',
   p_reasondiv     IN     VARCHAR2 DEFAULT '',
   p_reasontext    IN     VARCHAR2 DEFAULT '',
   IO_CURSOR          OUT TYPES.DataSet,
   MESSAGE            OUT VARCHAR2)
AS
   v_seektitle           VARCHAR2 (50);                              --코드헬프타이틀
   v_table               VARCHAR2 (50);                                --검색테이블
   v_tablekey            VARCHAR2 (50);                      --테이블키(복수일 경우 조합)
   v_tablecoloums        VARCHAR2 (4000);                               --컬럼배열
   v_coloumsetting       VARCHAR2 (4000);                             --컬럼속성배열

   --파라미터 3개를 처리하기 위함.
   p_dtemp               VARCHAR2 (200);
   p_dvalue1             VARCHAR2 (20);
   p_dvalue2             VARCHAR2 (20);

   p_cashcode            VARCHAR2 (20);

   p_compcode_csitema    VARCHAR2 (3);
   p_plantcode_csitema   VARCHAR2 (4);
   p_datadiv_csitema     VARCHAR2 (5);
   p_costym_csitema      VARCHAR2 (7);
   p_startym_csitema     VARCHAR2 (7);
   p_preym_csitema       VARCHAR2 (7);

   p_compcode_csitemb    VARCHAR2 (3);
   p_plantcode_csitemb   VARCHAR2 (4);
   p_datadiv_csitemb     VARCHAR2 (5);
   p_costym_csitemb      VARCHAR2 (7);
   p_startym_csitemb     VARCHAR2 (7);
   p_preym_csitemb       VARCHAR2 (7);

   p_compcode_csmakea    VARCHAR2 (3);
   p_plantcode_csmakea   VARCHAR2 (4);
   p_datadiv_csmakea     VARCHAR2 (5);
   p_itemcode_csmakea    VARCHAR2 (20);
   p_costym_csmakea      VARCHAR2 (7);
   p_startym_csmakea     VARCHAR2 (7);
   p_preym_csmakea       VARCHAR2 (7);

   p_compcode_csmakem    VARCHAR2 (3);
   p_plantcode_csmakem   VARCHAR2 (4);
   p_datadiv_csmakem     VARCHAR2 (5);
   p_costyy_csmakem      VARCHAR2 (4);

   p_dvalue1_1           VARCHAR2 (20);
   p_dvalue1_2           VARCHAR2 (20);

   p_dtemp1              VARCHAR2 (200);
   p_dvalue11            VARCHAR2 (20);
   p_dvalue21            VARCHAR2 (20);

   p_pdtemp              VARCHAR2 (200);
   p_pdvalue1            VARCHAR2 (20);
   p_pdvalue2            VARCHAR2 (20);

   p_gbcode1_1           VARCHAR2 (200);

   p_seektitle           VARCHAR2 (50);                              --코드헬프타이틀
   p_table               VARCHAR2 (50);                                --검색테이블
   p_tablekey            VARCHAR2 (50);                      --테이블키(복수일 경우 조합)
   p_tablecoloums        VARCHAR2 (4000);                               --컬럼배열
   p_coloumsetting       VARCHAR2 (4000);                             --컬럼속성배열
BEGIN
   MESSAGE := '데이터 확인';


   IF (p_div = 'MaskProgramCheck')
   THEN
      OPEN IO_CURSOR FOR
         SELECT     ---CASE WHEN NVL(maskck, '') = '' THEN 'N' ELSE maskck END
               NVL (TRIM (maskck), 'N') maskck
           FROM SYSUSERACCESSAUTHORITY
          WHERE empcode = p_empcode AND programcode = p_programcode;
   --  저장된 사용자별 코드헬프 컬럼을 검색한다.
   ELSIF (p_div = 'SeekSetting')
   THEN
      OPEN IO_CURSOR FOR
         SELECT empcode,
                programcode,
                controlname,
                coloumns,
                coloumns
           --ms sql에 이렇게 들어가 있음
           --,coloumns

           --oracle 마이그레이션에 이렇게 되어 있음
           --empcode
           --, programcode
           --, controlname
           --, coloumns

           FROM SYSSEEKSETTING A
          WHERE     empcode = p_empcode
                AND programcode = p_programcode
                AND controlname = p_controlname;
   --지정한 사용자별 코드헬프 컬럼을 저장한다.
   ELSIF (p_div = 'I1')
   THEN
      DELETE SeekSetting
       WHERE     empcode = p_empcode
             AND programcode = p_programcode
             AND controlname = p_controlname;

      INSERT INTO SeekSetting (empcode,
                               programcode,
                               controlname,
                               coloumns)
           VALUES (p_empcode,
                   p_programcode,
                   p_controlname,
                   p_coloumns);

      COMMIT;
   ELSIF (p_div = 'MENU')
   THEN
      v_seektitle := '프로그램 메뉴코드';
      v_table := 'menu';
      v_tablekey := ' ' || 'menudiv || menucode' || ' ';

      v_tablecoloums :=
         'menudiv || menucode "메뉴코드", menuname "메뉴명", menuseq "순서", menulevel "메뉴레벨", parentmenu "상위메뉴코드"';
      v_coloumsetting := 'L-100;C-100;R-200;L-200;C-300;';

      OPEN IO_CURSOR FOR
         SELECT v_seektitle NAME,
                fnSeek (p_empcode,
                        v_table,
                        v_tablekey,
                        v_tablecoloums,
                        v_coloumsetting)
                   sqlstring,
                ' order by ' || v_tablekey || ' ' SORT,
                v_coloumsetting coloumn
           FROM DUAL;
   ELSIF (p_div = 'ProgramManage')
   THEN
      OPEN IO_CURSOR FOR
         SELECT '프로그램 관리' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                            programcode  "프로그램코드",
                            programname  "프로그램명"
                 from        programmanage  a
                          left join    (
                                        select        favoritykey1
                                        from        seekfavority
                                        where        empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''programmanage'' )b on programcode = favoritykey1
                where        a.programcode = programcode
                        and ((a.programcode like '''
                || p_gbcode
                || ''' || ''%'') or (a.programname like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                '
                   sqlstring,
                'order by    programcode' SORT,
                'L-100;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMDEPTD')
   THEN                                                             --부서조회(팀만)
      OPEN IO_CURSOR FOR
         SELECT '부서조회' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                                a.deptcode "부서코드",
                                trim(nvl(a.topdeptname,'''') || '' '' || nvl(a.predeptname,'''') || '' '' || nvl(a.deptname,'''')) 부서명
                    from        vndept  a
                                left join    (   select        favoritykey1
                                                from        seekfavority
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''cmdeptm'' )b on a.deptcode = favoritykey1
                    where        a.deptcode = a.deptcode
                                and ((a.deptcode like '''
                || p_gbcode
                || ''' || ''%'') or (a.findname like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                                and (((''Y'' = '''
                || p_useyn
                || ''') and (nvl(a.useyn,'' '') = ''Y'')) or (''N'' = '''
                || p_useyn
                || ''')) and nvl(topdeptcode,'' '') <> '' ''
                    '
                   sqlstring,
                'order by    a.deptcode' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CustomerMaster')
   THEN                                                     --  2012-09-03 권도영
      OPEN IO_CURSOR FOR
         SELECT '매입거래처 정보' NAME,
                   'select     case when b.favoritykey1 is null then ''N'' else ''Y'' end "√",
                                a.custcode "코드",
                                a.custname "거래처명",
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,'''')) "주소",
                                a.businessno "사업자번호",
                                rtrim(a.ceoname) "대표자",
                                d.predeptname || '' '' || d.deptname "팀",
                                c.empname "담당자"
                    from        CMCUSTM  a
                                left join    (
                                                select      favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where       empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMCUSTM''
                                            ) b
                                            on a.custcode = b.favoritykey1
                                left join CMEMPM c on a.empcode = c.empcode
                                left join vnDEPT d on a.deptcode = d.deptcode
                    where        a.custdiv in (''1'', ''3'', ''4'')
                                and (a.custcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                     a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                                     replace(a.businessno,''-'','''') like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'CMAREA')
   THEN                                                          --지역조회 200910
      OPEN IO_CURSOR FOR
         SELECT '지역조회' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                            a.divcode "지역코드",
                            a.divname "지역명"
                    from    CMCOMMONM a
                            left join    (  select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''CMAREA'' ) b on a.divcode = favoritykey1
                    where   a.cmmcode = ''CM03''
                            and (a.divcode like '''
                || p_gbcode
                || ''' || ''%'' or a.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.usediv,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.divcode' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMSCHOOL')
   THEN                                             -- 학교조회  20100126 등록 : 이동현
      OPEN IO_CURSOR FOR
         SELECT '학교조회' NAME,
                   'select     case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                                    a.schoolcd "학교코드",
                                    a.schoolnm "학교명"
                        from        CMSCHOOLM a
                                    left join    (
                                                    select        favoritykey1
                                                    from        SYSSEEKFAVORITY
                                                    where        empcode = '''
                || p_empcode
                || '''
                                                                and seektable = ''cmschoolm''
                                                ) b
                                                on a.schoolcd = favoritykey1
                        where        (a.schoolcd like '''
                || p_gbcode
                || ''' || ''%'' or
                                     a.schoolnm like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                        '
                   sqlstring,
                'order by a.schoolcd' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMMAJORM')
   THEN                                            -- 학교전공조회 20100126 등록 : 이동현
      OPEN IO_CURSOR FOR
         SELECT '전공조회' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                    a.majorcd  "전공코드",
                                    a.majornm  "학교명"
                        from        CMMAJORM  a
                                    left join    (
                                                    select      favoritykey1
                                                    from        SYSSEEKFAVORITY
                                                    where       empcode = '''
                || p_empcode
                || '''
                                                                and seektable = ''CMMAJORM''
                                                )  b
                                                on a.majorcd = favoritykey1
                        where        (a.majorcd like '''
                || p_gbcode
                || ''' || ''%'' or
                                     a.majornm like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                        '
                   sqlstring,
                'order by a.majorcd' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'EXCHANGEM')
   THEN                                              -- 환율조회 20100510 등록 : 이동현
      OPEN IO_CURSOR FOR
         SELECT '환율조회' NAME,
                   'select     case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                                    a.divcode "환율코드",
                                    a.divname "환율명"
                        from        CMCOMMONM a
                                    left join    (
                                                    select        favoritykey1
                                                    from        SYSSEEKFAVORITY
                                                    where        empcode = '''
                || p_empcode
                || '''
                                                                and seektable = ''CMCOMMONM''
                                                ) b
                                                on a.divcode = favoritykey1
                        where        a.cmmcode = ''TR01''
                                    and (a.divcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                         a.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                    and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.usediv,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                        '
                   sqlstring,
                'order by a.divcode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'NATION')
   THEN                                              -- 국가조회 20100513 등록 : 이동현
      OPEN IO_CURSOR FOR
         SELECT '국가조회' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                                a.divcode "국가코드",
                                a.divname "국가명"
                        from        CMCOMMONM a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMCOMMONM''
                                            ) b
                                            on a.divcode = favoritykey1
                        where        a.cmmcode = ''CM70''
                                and (a.divcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                     a.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.usediv,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                        '
                   sqlstring,
                'order by a.divcode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMDEPTM')
   THEN                                                 --부서조회 080930 등록 : 이세민
      OPEN IO_CURSOR FOR
         SELECT '부서조회' NAME,
                   'select     case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                                a.deptcode as "부서코드",
                                ltrim(NVL(a.topdeptname,'''') || '' '' || NVL(a.predeptname,'''') || '' '' || NVL(a.deptname,'''')) as "부서명"
                    from        vnDEPT a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMDEPTM''
                                            ) b
                                            on a.deptcode = favoritykey1
                    where        (a.deptcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                 a.findname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.useyn,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.deptcode' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMDEPTMA')
   THEN
      OPEN IO_CURSOR FOR
         SELECT '부서조회' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.deptcode  "부서코드",
                            ltrim(NVL(a.topdeptname,'''') || '' '' || NVL(a.predeptname,'''') || '' '' || NVL(a.deptname,'''')) "부서명"
                    from        vnDEPT  a
                    left join (
                                select  favoritykey1
                                from    SYSSEEKFAVORITY
                                where   empcode = '''
                || p_empcode
                || '''
                                        and seektable = ''CMDEPTM'' )  b on a.deptcode = favoritykey1
                    where   (a.deptcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.findname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.useyn,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                            and (a.deptcode like ''1%'' or a.deptcode like ''2%'')
                    '
                   sqlstring,
                'order by a.deptcode' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMDEPTMB')
   THEN
      OPEN IO_CURSOR FOR
         SELECT '부서조회' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.deptcode  "부서코드",
                            ltrim(NVL(a.topdeptname,'''') || '' '' || NVL(a.predeptname,'''') || '' '' || NVL(a.deptname,'''')) 부서명
                    from        vnDEPT  a
                    left join (
                                select  favoritykey1
                                from    SYSSEEKFAVORITY
                                where   empcode = '''
                || p_empcode
                || '''
                                        and seektable = ''CMDEPTM'' )  b on a.deptcode = favoritykey1
                    where   (a.deptcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.findname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.useyn,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.deptcode' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
   --          하나제약 부서코드 체계로 인해 소스 변경 (a.deptcode like ''3%'' or a.deptcode like ''4%'')    제
   --   SELECT '부서조회' NAME
   --      ,   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
   --                            a.deptcode  "부서코드",
   --                            ltrim(NVL(a.topdeptname,'''') || '' '' || NVL(a.predeptname,'''') || '' '' || NVL(a.deptname,'''')) 부서명
   --                    from        vnDEPT  a
   --                    left join (
   --                                select  favoritykey1
   --                                from    SYSSEEKFAVORITY
   --                                where   empcode = '''
   --       || p_empcode
   --       || '''
   --                                        and seektable = ''CMDEPTM'' )  b on a.deptcode = favoritykey1
   --                    where   (a.deptcode like '''
   --       || p_gbcode
   --       || ''' || ''%'' or
   --                            a.findname like ''%'' || '''
   --       || p_gbcode
   --       || ''' || ''%'')
   --                            and (''Y'' = '''
   --       || p_useyn
   --       || ''' and NVL(a.useyn,'' '') = ''Y'' or ''N'' = '''
   --       || p_useyn
   --       || ''')
   --                            and (a.deptcode like ''3%'' or a.deptcode like ''4%'')
   --                    '
   --        sqlstring
   --      ,'order by a.deptcode' SORT
   --      ,'L-100;L-200;L-200;' coloumn
   --     FROM DUAL;
    elsif (p_div = 'ACDEPTM') then    --부서조회 110111 등록 : 최용석
        open IO_CURSOR for
        select  '부서조회' as name,
                'select case when favoritykey1 is null then ''N'' else ''Y'' end as "√",
                        a.deptcode as "부서코드",
                        nvl(a.deptname,'''') as "부서명"
                 from   CMDEPTM a
                        left join (
                            select  favoritykey1
                            from    SYSSEEKFAVORITY
                            where   empcode = ''' || p_empcode || '''
                                    and seektable = ''CMDEPTM''
                        ) b on a.deptcode = b.favoritykey1
                        left join CMDEPTM c
                            on a.deptcode = c.predeptcode
                where   a.deptlevel >= ''4''
                        and c.deptcode is null
                        and (a.deptcode like ''' || p_gbcode || ''' || ''%'' or
                             a.deptname like ''%'' || ''' || p_gbcode || ''' || ''%'')
                        and (''Y'' = ''' || p_useyn || ''' and nvl(a.useyn,'' '') = ''Y'' or
                             ''N'' = ''' || p_useyn || ''') ' as sqlstring,
                'order by a.deptcode' sort,
                'l-100;l-200;' coloumn
        from    DUAL;

   ELSIF (p_div = 'CMDEPTALL')
   THEN                                                      --부서조회 조성희 : 메세지용
      OPEN IO_CURSOR FOR
         SELECT '부서조회' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.deptcode  "부서코드",
                            ltrim(NVL(a.topdeptname,'''') || '' '' || NVL(a.predeptname,'''') || '' '' || NVL(a.deptname,''''))  부서명
                    from    vnDEPT  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMDEPTM''
                                            )  b on a.deptcode = favoritykey1
                    where   (a.deptcode like '''
                || p_gbcode
                || ''' || ''%'' or
                             a.findname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.useyn,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.deptcode' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'PSEMPM')
   THEN                                        --인사정보조회 20100329 : 조성희 --비사원제외
      OPEN IO_CURSOR FOR
         SELECT '사원 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            empcode "사원코드",
                            empname "사원명",
                            NVL(d.deptname,'''') || '' '' || c.deptname  부서명,
                            b.deptcode

                    from    cmempm  b
                            left join    (
                                            select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''cmempm'' )a on empcode = favoritykey1
                            left join CMDEPTM c on b.deptcode = c.deptcode
                            left join CMDEPTM d on c.predeptcode = d.deptcode
                    where   empcode = empcode
                            and ((b.empcode like '''
                || p_gbcode
                || ''' || ''%'') or (b.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                            and (((''Y'' = '''
                || p_useyn
                || ''') and (NVL(b.retiredt,'' '') = '' '')) or
                            (''N'' = '''
                || p_useyn
                || '''))
                    '
                   sqlstring,
                'order by    b.deptcode, b.empcode' SORT,
                'L-100;L-100;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'PSEMPMALL')
   THEN                                        --퇴사자 포함 전부 조회
      OPEN IO_CURSOR FOR
         SELECT '사원 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            empcode "사원코드",
                            empname "사원명",
                            NVL(d.deptname,'''') || '' '' || c.deptname  부서명,
                            b.deptcode

                    from    cmempm  b
                            left join    (
                                            select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''cmempm'' )a on empcode = favoritykey1
                            left join CMDEPTM c on b.deptcode = c.deptcode
                            left join CMDEPTM d on c.predeptcode = d.deptcode
                    where   empcode = empcode
                            and ((b.empcode like '''
                || p_gbcode
                || ''' || ''%'') or (b.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                            and (((''Y'' = '''
                || p_useyn
                || ''') ))
                    '
                   sqlstring,
                'order by    b.deptcode, b.empcode' SORT,
                'L-100;L-100;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'PSEMPMM')
   THEN                                            --개인평가 사원 조회 20150811 : 홍지은
      OPEN IO_CURSOR FOR
         SELECT '사원 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                            a.empcode "사원코드",
                            c.empname "사원명"
                    from    PSEMPEVALUATEE a
                            left join    (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMEMPM''
                                            ) b on a.empcode = b.favoritykey1
                            left join CMEMPM c on a.empcode = c.empcode
                    where   ((a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or c.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                            and ((a.evtemp1 = '''
                || p_empcode
                || ''') or (a.evtemp2 = '''
                || p_empcode
                || ''') or (a.evtemp3 = '''
                || p_empcode
                || '''))
                    '
                   sqlstring,
                'order by a.empcode' SORT,
                'L-100;L-100;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'PSEMPM2')
   THEN                                        --인사정보조회 20100329 : 조성희 --비사원제외
      OPEN IO_CURSOR FOR
         SELECT '사원 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            empcode  "사원코드",
                            empname  "사원명",
                            positiondiv  "직위코드",
                            NVL(PS29.divname,'''')  "직위"

                    from    cmempm  b
                            left join    (  select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''cmempm'' )a on empcode = favoritykey1
                            left join cmcommonm  PS29 on b.positiondiv = PS29.divcode and PS29.cmmcode = ''PS29''

                    where   (b.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            b.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(b.retiredt,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by b.deptcode, b.empcode' SORT,
                'L-100;L-100;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'PSEMPRETM')
   THEN                                --퇴사자인사정보조회 20100329 : 조성희 --비사원제외, 퇴사자
      OPEN IO_CURSOR FOR
         SELECT '사원 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√" ,
                            a.empcode  "사원코드",
                            a.empname  "사원명",
                            d.deptname || '' '' || c.deptname  "부서명",
                            a.deptcode  "부서코드"
                    from    CMEMPM  a
                            left join    (  select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMEMPM'' )  b on a.empcode = b.favoritykey1
                            left join CMDEPTM  c on a.deptcode = c.deptcode
                            left join CMDEPTM  d on c.predeptcode = d.deptcode

                    where   a.empdiv <> ''09''
                            and (a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.retiredt,'' '') <> '' '' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.deptcode, a.empcode' SORT,
                'L-100;L-100;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMEMPM')
   THEN                                               --인사정보조회 080930 등록 : 이세민
      OPEN IO_CURSOR FOR
         SELECT '사원 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            empcode "사원코드",
                            empname "사원명",
                            NVL(d.deptname,'''') || '' '' || NVL(c.deptname,'''')  "부서명",
                            b.deptcode "부서코드"

                    from    cmempm  b
                            left join    ( select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''cmempm'' )a on empcode = favoritykey1
                            left join CMDEPTM  c on rtrim(b.deptcode) = rtrim(c.deptcode)
                            left join CMDEPTM  d on NVL(c.predeptcode,'''') = NVL(d.deptcode,'''')

                    where   empcode = empcode
                            and ((b.empcode like '''
                || p_gbcode
                || ''' || ''%'') or (b.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                            and (((''Y'' = '''
                || p_useyn
                || ''') and (NVL(b.retiredt,'' '') = '' '')) or
                            (''N'' = '''
                || p_useyn
                || '''))
                    '
                   sqlstring,
                'order by    b.deptcode, b.empcode' SORT,
                'L-100;L-100;L-200;L-100;' coloumn
           FROM DUAL;
   --            SELECT        '사원 정보' AS NAME,
   --                'select        case when favoritykey1 is null then ''N'' else ''Y'' end as "√",
   --                            empcode as empcode,
   --                            empname as empname,
   --                            nvl(d.deptname,'''') || '' '' || nvl(c.deptname,'''') as deptname,
   --                            b.deptcode as deptcode
   --
   --                from        cmempm  b
   --                            left join    (
   --                                            select        favoritykey1
   --                                            from        seekfavority
   --                                            where        empcode = ''' || p_empcode || '''
   --                                                        and seektable = ''cmempm''
   --                                        )a
   --                                on empcode = favoritykey1
   --                            left join CMDEPTM  c
   --                                on rtrim(b.deptcode) = rtrim(c.deptcode)
   --                            left join CMDEPTM d
   --                                on nvl(c.predeptcode,'''') = nvl(d.deptcode,'''')
   --                where        empcode = empcode
   --                            and ((b.empcode like ''' || p_gbcode || ''' || ''%'') or (b.empname like ''%'' || ''' || p_gbcode || ''' || ''%''))
   --                            and (((''Y'' = ''' || p_useyn || ''') and (nvl(b.retiredt,'' '') = '' '')) or
   --                                (''N'' = ''' || p_useyn || '''))
   --
   --                            ' AS sqlstring,
   --                            'order by    b.deptcode, b.empcode' AS SORT,
   --                            'L-100;L-100;L-200;L-100;' AS coloumn
   --                FROM dual;

   ELSIF (p_div = 'ACEMPM')
   THEN                                               --인사정보조회 110113 등록 : 최용석
      OPEN io_cursor FOR
         SELECT '사원 정보' AS name,
                   'select  case when favoritykey1 is null then ''N'' else ''Y'' end as "√",
                          a.empcode as "사원코드",
                          a.empname as "사원명",
                          b.deptname as "부서명",
                          a.deptcode as "부서코드"
                  from    CMEMPM a
                          left join (
                              select  favoritykey1
                              from    SYSSEEKFAVORITY
                              where   empcode = '''
                || p_empcode
                || '''
                                      and seektable = ''CMEMPM''
                          ) c on a.empcode = c.favoritykey1
                          left join CMDEPTM b
                              on a.deptcode = b.deptcode
                  where   (a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                           a.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                           b.deptname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                          and (''Y'' = '''
                || p_useyn
                || ''' and nvl(a.retiredt,'' '') = '' '' or
                               ''N'' = '''
                || p_useyn
                || ''')'
                   AS sqlstring,
                'order by a.deptcode, a.empcode' AS sort,
                'l-100;l-100;l-200;l-100;' AS coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACCRDEMPM')
   THEN                                                      --카드정리자의 법인카드 사용자
      OPEN io_cursor FOR
         SELECT '사원 정보' AS name,
                   'select  case when favoritykey1 is null then ''N'' else ''Y'' end as "√",
                          a.empcode as "사원코드",
                          a.empname as "사원명",
                          a.deptname as "부서명",
                          a.deptcode as "부서코드"
                  from (
                      select  b.empcode
                              ,c.empname
                              ,c.deptcode
                              ,d.deptname
                      from    ACCRDMNG a
                              join ACCARDM b
                                  on a.compcode = b.compcode
                                  and a.cardno = b.cardno
                                  and b.useyn = ''Y''
                                  and b.empcode is not null
                              left join CMEMPM c
                                  on b.empcode = c.empcode
                              left join CMDEPTM d
                                  on c.deptcode = d.deptcode
                      where   a.empcode = '''
                || p_empcode
                || '''
                      union
                      select  a.empcode
                              ,b.empname
                              ,b.deptcode
                              ,c.deptname
                      from    ACCARDM a
                              left join CMEMPM b
                                  on a.empcode = b.empcode
                              left join CMDEPTM c
                                  on b.deptcode = c.deptcode
                      where   a.empcode = '''
                || p_empcode
                || '''
                              and a.useyn = ''Y''
                  ) a
                          left join (
                              select  favoritykey1
                              from    SYSSEEKFAVORITY
                              where   empcode = '''
                || p_empcode
                || '''
                                      and seektable = ''ACCRDEMPM''
                          ) b on a.empcode = b.favoritykey1
                  where   (a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                           a.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                           a.deptname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')'
                   AS sqlstring,
                'order by a.deptcode, a.empcode' AS sort,
                'l-100;l-100;l-200;l-100;' AS coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMEMPM2')
   THEN                                  --인사마스터조회 이동현 - 주민번호 검색 추가 , 가족 검색 추가
      OPEN IO_CURSOR FOR
         SELECT '사원 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.empcode  "사원코드",
                            a.empname  "사원명",
                            CASE WHEN length(A.PERSONID) = 14  THEN NVL(A.PERSONID, '''')
                              WHEN length(A.PERSONID) != 14 THEN substr(utl_i18n.raw_to_char(personid,''AL32UTF8''),1,6)
                                                        || ''-'' || substr(utl_i18n.raw_to_char(personid,''AL32UTF8''),7,7)
                              ELSE ''''
                            END  "주민등록번호",
                            d.deptname || '' '' || c.deptname  "부서명",
                            a.deptcode  "부서코드"
                    from    CMEMPM  a
                            left join    (  select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMEMPM''
                                            )  b on a.empcode = b.favoritykey1
                            left join CMDEPTM  c on a.deptcode = c.deptcode
                            left join CMDEPTM  d on c.predeptcode = d.deptcode
                            where   (a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                    a.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                                    a.personid like '''
                || p_gbcode
                || ''' || ''%'')
                                    and (''Y'' = '''
                || p_useyn
                --|| ''' and NVL(a.retiredt,'' '') = '' '' or ''N'' = '''
                --|| ''' and NVL(a.outyn,'' '') = '' '' or ''N'' = '''
                --|| p_useyn
                || ''')

                    union all

                    select  case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.empcode  "사원코드",
                            rtrim(a.empname)  "사원명",
                            e.fampersonid  "주민등록번호",
                            d.deptname || '' '' || c.deptname  "부서명",
                            a.deptcode  "부서코드"

                    from    CMEMPM  a
                            left join    (  select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''CMEMPM''
                                            )  b on a.empcode = b.favoritykey1
                            left join CMDEPTM  c on a.deptcode = c.deptcode
                            left join CMDEPTM  d on c.predeptcode = d.deptcode
                            join CMEMPFAMM  e on a.empcode = e.empcode

                    where   (a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.empname||e.famname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                            e.fampersonid like '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                --|| ''' and NVL(a.retiredt,'' '') = '' '' or ''N'' = '''
                || ''' and NVL(a.outyn,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by "부서코드", "사원코드"' SORT,
                'L-100;L-120;L-120;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMEMPID')
   THEN                                   --주민번호조회 조성희 - 주민번호 검색 추가 , 가족 검색 추가
      OPEN IO_CURSOR FOR
         SELECT '사원 정보' NAME,
                   'select     max(a.gg)  "√",
                        a.personid  "주민등록번호",
                        max(a.empname)  "사원명",
                        max(a.empcode)  "사원코드",
                        max(a.deptname)  "부서명",
                        max(a.deptcode)  "부서코드"
            from    (
                select  case when favoritykey1 is null then ''N'' else ''Y'' end  gg,
                        a.personid,
                        a.empname,
                        a.empcode,
                        d.deptname || '' '' || c.deptname  deptname,
                        a.deptcode

                from    CMEMPM  a
                        left join    (  select  favoritykey1
                                        from    SYSSEEKFAVORITY
                                        where   empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMEMPM''
                                        )  b on a.empcode = b.favoritykey1
                left join CMDEPTM  c on a.deptcode = c.deptcode
                left join CMDEPTM  d on c.predeptcode = d.deptcode
                where   (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.retiredt,'' '') = '' '' or ''N'' = '''
                --|| ''' and NVL(a.outyn,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')

                union all

                select  case when favoritykey1 is null then ''N'' else ''Y'' end  gg,
                        e.fampersonid,
                        rtrim(e.famname)  empname,
                        a.empcode,
                        d.deptname || '' '' || c.deptname  deptname,
                        a.deptcode
                from    CMEMPM  a
                        left join    (  select  favoritykey1
                                        from    SYSSEEKFAVORITY
                                        where   empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMEMPM'' )  b on a.empcode = b.favoritykey1
                        left join CMDEPTM  c on a.deptcode = c.deptcode
                        left join CMDEPTM  d on c.predeptcode = d.deptcode
                        join CMEMPFAMM  e on a.empcode = e.empcode
                where   (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.retiredt,'' '') = '' '' or ''N'' = '''
                --|| ''' and NVL(a.outyn,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
            )  a
            where   (a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                    a.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                    a.personid like '''
                || p_gbcode
                || ''' || ''%'')
            '
                   sqlstring,
                'group by    a.personid, a.deptcode, a.empcode
            order by a.deptcode, a.empcode' SORT,
                'L-100;L-120;L-120;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMEMPALL')
   THEN                                                           -- 조성희(메세지용)
      OPEN IO_CURSOR FOR
         SELECT '사원 정보' NAME,
                   'select     case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.empcode  "사원코드",
                                a.empname  "사원명",
                                d.deptname || '' '' || c.deptname  "부서명",
                                a.deptcode  부서코드
                    from        CMEMPM  a
                                left join    (  select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMEMPM''
                                                )  b on a.empcode = b.favoritykey1
                                left join CMDEPTM  c on a.deptcode = c.deptcode
                                left join CMDEPTM  d on c.predeptcode = d.deptcode

                    where   (a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                --|| ''' and NVL(a.retiredt,'' '') = '' '' or ''N'' = '''
                || ''' and NVL(a.outyn,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
            '
                   sqlstring,
                'order by a.deptcode, a.empcode' SORT,
                'L-100;L-100;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CUSTEMP')
   THEN                                                           -- 거래처별 사원조회
      OPEN IO_CURSOR FOR
         SELECT '사원 정보' NAME,
                   'select        distinct case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.empcode  "사원코드",
                                a.empname  "사원명",
                                a.predeptname || '' '' || a.deptname  "부서명",
                                a.deptcode  "부서코드"

                    from        vnResults  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMEMPM'' )  b on a.empcode = b.favoritykey1

                    where        (a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                b.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.deptcode, a.empcode' SORT,
                'L-100;L-100;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'BUSNO')
   THEN                                    -- 매출거래처마스터조회(사업자번호) 2008-10-01 조성희
      OPEN IO_CURSOR FOR
         SELECT '매출거래처 마스터 정보' NAME,
                   'select        case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.custcode  "코드",
                                a.custname  "거래처명",
                                a.businessno  "사업자번호",
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                                rtrim(a.ceoname)  "대표자",
                                d.predeptname || '' '' || d.deptname  "팀",
                                c.empname  "담당자"

                    from        CMCUSTM  a
                                left join    (  select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMCUSTM''
                                                )  b on a.custcode = b.favoritykey1
                    left join CMEMPM  c on a.empcode = c.empcode
                    left join vnDEPT  d on a.deptcode = d.deptcode
                    join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                    where        (replace(a.businessno,''-'','''') like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                                a.custcode like ''%'' || '''
                || p_gbcode
                || ''')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-100;C-200;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'CEONO')
   THEN                                   -- 매출거래처마스터조회(주민등록번호) 2008-10-01 조성희
      OPEN IO_CURSOR FOR
         SELECT '매출거래처 마스터 정보' NAME,
                   'select        case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.custcode  "코드",
                                a.custname  "거래처명",
                                a.ceono  "주민번호",
                                rtrim(a.ceoname)  "대표자",
                                a.businessno  "사업자번호",
                                d.predeptname || '' '' || d.deptname  "팀",
                                c.empname  "담당자"
                    from        CMCUSTM  a
                                left join    (  select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMCUSTM''
                                                )  b on a.custcode = b.favoritykey1
                                left join CMEMPM  c on a.empcode = c.empcode
                                left join vnDEPT  d on a.deptcode = d.deptcode
                                join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''

                    where        (replace(a.ceono,''-'','''') like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                                a.ceoname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-100;C-100;L-100;L-100;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'CMCUSTM')
   THEN                                            --매출거래처마스터조회 2008-10-01 조성희
      OPEN IO_CURSOR FOR
         SELECT '매출거래처 마스터 정보' NAME,
                   'select        distinct
                                case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.custcode  "코드",
                                a.custname  "거래처명",
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                                a.businessno  "사업자번호",
                                rtrim(a.ceoname)  "대표자",
                                d.predeptname || '' '' || RTRIM(d.deptname)  "팀",
                                c.empname  "담당자",
                                c.empcode "담당코드",
                                a.utdiv "유통구분",
                                a.custitem "종목",
                                a.custcondition "업태",
                                a.post "우편번호",
                                a.plantcode "사업장",
                                a.parents_cust_id "상위 거래처",
                                a.custmajorcode "대표 거래처"

                    from        CMCUSTM  a
                                left join    (  select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMCUSTM'' )  b on a.custcode = b.favoritykey1
                    left join CMEMPM  c on a.empcode = c.empcode
                    left join vnDEPT  d on a.deptcode = d.deptcode
                    join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                    left join CMCUSTRELS  f on a.custcode = f.relcustcode and f.custmngdiv = ''A''

                    where        (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                                a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(TRIM(a.stopdate),'''') IS NULL or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;L-80;L-80;L-80;L-80;L-80;L-80;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;N;N;N;N;N;N;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'CMCUSTE')
   THEN                                            --수출거래처마스터조회 2015-06-03 이욱주
      OPEN IO_CURSOR FOR
         SELECT '수출거래처 마스터 정보' NAME,
                   'select        distinct
                                case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.custcode  "수출처",
                                a.custname  "수출처명",
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                                a.businessno  "사업자번호",
                                rtrim(a.ceoname)  "대표자",
                                d.predeptname || '' '' || d.deptname "팀",
                                c.empname  "담당자"
                    from        CMCUSTM  a
                                left join    (  select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMCUSTE''
                                                )  b on a.custcode = b.favoritykey1
                                left join CMEMPM  c on a.empcode = c.empcode
                                left join vnDEPT  d on a.deptcode = d.deptcode
                                join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                                left join CMCUSTRELS  f on a.custcode = f.relcustcode and f.custmngdiv = ''A''

                    where        (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                                a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                                and (NVL(f.empcode,'' '') in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))) or
                                NVL(a.empcode,'' '') in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))))
                                and a.custdiv = ''2''
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;N;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'CMCUSTALL')
   THEN                                             -- 영업권한 안걸림 2011-01-18 이동현
      OPEN IO_CURSOR FOR
         SELECT '매출거래처 마스터 정보' NAME,
                   'select        case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.custcode  "코드",
                                a.custname  "거래처명",
                                rtrim(a.addr1) || '' '' || rtrim(a.addr2) "주소",
                                a.businessno  "사업자번호",
                                rtrim(a.ceoname)  "대표자",
                                d.predeptname || '' '' || d.deptname  "팀",
                                c.empname  "담당자"
                    from        CMCUSTM  a

                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMCUSTM'' )  b on a.custcode = b.favoritykey1
                                left join CMEMPM  c on a.empcode = c.empcode
                                left join vnDEPT  d on a.deptcode = d.deptcode
                                join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''

                    where        (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                                a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'CMINCUST')
   THEN
      --매출거래처마스터조회 2010-02-10 조성희(입력시사용)
      -- 프로시져 변경. 2013-10-22 이세민
      -- 관련거래처정보를 기준으로 조회하도록 함.
      -- 관련거래처가 등록되지 않은 경우에는 조회되지 않음.

      OPEN IO_CURSOR FOR
         SELECT '매출거래처 마스터 정보' NAME,
                   'select        distinct
                            case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.custcode  "코드",
                            a.custname  "거래처명",
                            rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                            a.businessno  "사업자번호",
                            rtrim(a.ceoname)  "대표자",
                            d.predeptname || '' '' || d.deptname  "팀",
                            c.empname  "담당자"

                from        CMCUSTM  a
                            left join    (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMCUSTM''
                                            )  b on a.custcode = b.favoritykey1
                            left join CMEMPM  c on a.empcode = c.empcode
                            left join vnDEPT  d on a.deptcode = d.deptcode
                            join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                            left join CMCUSTRELS  f on a.custcode = f.relcustcode and f.custmngdiv = ''A''

                where        (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                            a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                            and (f.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))) or
                            a.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))))
                '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'ORDC')
   THEN                                                            -- 전매처리시 사용
      OPEN IO_CURSOR FOR
         SELECT '매출거래처 마스터 정보' NAME,
                   'select        case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.custcode  "코드",
                                a.custname  "거래처명",
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                                a.businessno  "사업자번호",
                                rtrim(a.ceoname)  "대표자",
                                d.predeptname || '' '' || d.deptname  "팀",
                                c.empname  "담당자"

                    from        CMCUSTM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMCUSTM''
                                                )  b on a.custcode = b.favoritykey1
                    left join CMEMPM  c on a.empcode = c.empcode
                    left join vnDEPT  d on a.deptcode = d.deptcode
                    join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''

                    where        (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                                a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'''') = '''' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'CMECUSTM')
   THEN
      --거래처조회 2009-04-21 조성희
      --수정 처방처조회: 이세민 2013-11-18
      --관련거래처에 등록된 처방처만 조회
      --병의원 직납인 경우에도 EDI 거래처 정보로 조회되도록 처리함(20140212)
      -- >>병의원 EDI로 원내처리를 위함이다.

      OPEN IO_CURSOR FOR
         SELECT '거래처 정보' NAME,
                   'select        distinct
                                case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.custcode "코드",
                                a.custname  "거래처명",
                                a.businessno  "사업자번호",
                                rtrim(a.ceoname)  "대표자",
                                NVL(a.addr1,'''') || '' '' || NVL(a.addr2,'''')  "주소",
                                a.empname  "담당자"

                    from        vnCUST  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMCUSTM''
                                                )  b on a.custcode = b.favoritykey1
                                join (
                                        select        custcode
                                                    ,empcode
                                        from        CMCUSTRELS
                                        where        custmngdiv = ''B''

                                        union all

                                        select        x.custcode
                                                    ,x.empcode
                                        from        CMCUSTRELS x
                                                    left join cmcustm x1 on x.custcode = x1.custcode
                                        where        x.custmngdiv = ''A''
                                                    and x1.utdiv in (''30'', ''40'')
                                                    and x.orderdiv = ''4''
                                )c on a.custcode = c.custcode

                    where        left(a.utdiv,1) in (''3'',''4'',''8'')
                                and (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                                a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'''') = '''' or ''N'' = '''
                || p_useyn
                || ''')
                                and c.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || ''')))
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-80;L-150;C-90;L-120;L-500;L-90;' coloumn,
                'N;N;Y;Y;Y;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'CMCUSTA')
   THEN                                              --거래처마스터조회 2008-11-18 조성희
      OPEN IO_CURSOR FOR
         SELECT '거래처 마스터 정보' NAME,
                   'select     distinct
                                case when b.favoritykey1 is null then ''N'' else ''Y'' end "√",
                                a.custcode "코드",
                                a.custname "거래처명",
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                                a.businessno  "사업자번호",
                                rtrim(a.ceoname)  "대표자",
                                d.predeptname || '' '' || d.deptname  "팀",
                                c.empname  "담당자"

                    from        CMCUSTM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMCUSTM'' )  b on a.custcode = b.favoritykey1
                                left join CMEMPM  c on a.empcode = c.empcode
                                left join vnDEPT  d on a.deptcode = d.deptcode
                                left join CMCUSTRELS  f on a.custcode = f.relcustcode and f.custmngdiv = ''A''

                    where        (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                                a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                                and (f.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))) or
                                a.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))))
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'CMCUST')
   THEN                                                         -- 거래처 마스터 등록용
      OPEN IO_CURSOR FOR
         SELECT '거래처 마스터 정보' NAME,
                   'select        distinct
                                case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.custcode  "코드",
                                a.custname  "거래처명",
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                                a.businessno  "사업자번호",
                                rtrim(a.ceoname)  "대표자",
                                d.predeptname || '' '' || d.deptname  "팀",
                                c.empname  "담당자"

                    from        CMCUSTM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMCUSTM''
                                )  b on a.custcode = b.favoritykey1
                                left join CMEMPM  c on a.empcode = c.empcode
                                left join vnDEPT  d on a.deptcode = d.deptcode
                                join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                                left join CMCUSTRELS  f on a.custcode = f.relcustcode and f.custmngdiv = ''A''

                    where        (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                                a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                                and (f.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))) or
                                a.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))))
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'ACCUSTM')
   THEN                                              --거래처마스터조회 2011-01-24 최용석
      OPEN IO_CURSOR FOR
         SELECT '거래처 마스터 정보' NAME,
                   'select      case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.custcode  "코드",
                                a.custname  "거래처명",
                                a.businessno  "사업자번호",
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                                rtrim(a.ceoname)  "대표자",
                                d.predeptname || '' '' || d.deptname  "팀",
                                c.empname  "담당자"

                    from        CMCUSTM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMCUSTM''
                                                )  b on a.custcode = b.favoritykey1
                                left join CMEMPM  c on a.empcode = c.empcode
                                left join vnDEPT  d on a.deptcode = d.deptcode

                    where        (upper(a.custcode) like ''%'' || upper('''
                || p_gbcode
                || ''') or
                                upper(a.custname) like ''%'' || upper('''
                || p_gbcode
                || ''') || ''%'' or
                                replace(a.businessno,''-'','''') like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.ceoname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-150;L-90;C-200;L-80;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'ORDITEMM_EX')
   THEN
      --판매제품마스터정보(주문서 등록시에만 사용하도록 함.)
      --주문대상에 대한 체크를 추가하여 주문시 제품에 대한 대상정보를 조건 처리 함. 20140114:이세민

      OPEN IO_CURSOR FOR
         SELECT '판매제품 마스터 정보' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                b.itemcode  "품목코드",
                                b.itemname  "품목명",
                                NVL(b.itemunit,'''')  "규격",
                                NVL(b.drugprc,0)  "기준단가"

                    from        CMITEMM  b
                    left join    (
                                    select        favoritykey1
                                    from        SYSSEEKFAVORITY
                                    where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMITEMM''
                                    )  a on b.itemcode = favoritykey1
                    left join CMCOMMONM  c on b.unit = c.divcode and c.cmmcode = ''CMM01''

                    where        NVL(b.pieceyn,'' '') <> ''Y''
                                and (b.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                b.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(b.productdiv,'' '') <> ''90'' or ''N'' = '''
                || p_useyn
                || ''')
                                and b.pharmvesselyn = ''Y''
                                and b.itemdiv in (''04'',''05'')
                    '
                   sqlstring,
                'order by b.itemcode' SORT,
                'L-100;L-200;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ORDITEMM')
   THEN                                             --판매제품마스터정보 2008-10-17 조성희
      OPEN IO_CURSOR FOR
         SELECT '판매제품 마스터 정보' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                b.itemcode  "품목코드",
                                b.itemname  "품목명",
                                NVL(b.itemunit,'''')  "규격",
                                NVL(b.drugprc,0)  "기준단가",
                                NVL(b.hscode,'''')  "HS번호"
                                
                    from        CMITEMM  b
                    left join    (
                                    select        favoritykey1
                                    from        SYSSEEKFAVORITY
                                    where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMITEMM''
                                    )  a on b.itemcode = favoritykey1
                    left join CMCOMMONM  c on b.unit = c.divcode and c.cmmcode = ''CMM01''

                    where        NVL(b.pieceyn,'' '') <> ''Y''
                            and (b.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            b.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(b.productdiv,'' '') <> ''90'' or ''N'' = '''
                || p_useyn
                || ''')
                            and b.itemdiv in (''04'',''05'')
                    '
                   sqlstring,
                'order by b.itemcode' SORT,
                'L-100;L-200;L-100;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMITEMM')
   THEN                                             --판매제품마스터정보 2008-10-17 조성희
      OPEN IO_CURSOR FOR
         SELECT '판매제품 마스터 정보' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.itemcode  "품목코드",
                            a.itemname  "품목명",
                            NVL(a.itemunit,'''')  "규격",
                            NVL(a.drugprc,0)  "기준단가"
                from        CMITEMM  a
                            left join    (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMITEMM''
                                            )  b on a.itemcode = b.favoritykey1
                            left join CMCOMMONM  c on a.unit = c.divcode and c.cmmcode = ''CM38''

                where        a.itemdiv in (''04'',''05'')
                            and (a.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.productdiv,'' '') <> ''90'' or ''N'' = '''
                || p_useyn
                || ''')
                '
                   sqlstring,
                'order by a.itemcode' SORT,
                'L-100;L-200;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMITEM')
   THEN                                               --제품마스터정보 2009-05-14 조성희
      OPEN IO_CURSOR FOR
         SELECT '제조/판매 제품 마스터 정보' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.itemcode  "품목코드",
                                a.itemname  "품목명",
                                NVL(a.itemunit,'''')  "규격",
                                NVL(a.drugprc,0)  "기준단가"

                    from        CMITEMM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMITEMM''
                                                )  b on a.itemcode = b.favoritykey1
                    left join CMCOMMONM  c on a.unit = c.divcode
                    and c.cmmcode = ''CM38''

                    where        a.itemdiv in (''03'',''04'',''05'')
                                and (a.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.productdiv,'' '') <> ''90'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.itemcode' SORT,
                'L-100;L-200;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMMITEMM')
   THEN                                             --제조제품마스터정보 2009-04-17 조성희
      OPEN IO_CURSOR FOR
         SELECT '제조제품 마스터 정보' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.itemcode  "품목코드",
                                a.itemname  "품목명",
                                NVL(a.itemunit,'''')  "규격"

                    from        CMITEMM  a
                    left join    (
                                    select        favoritykey1
                                    from        SYSSEEKFAVORITY
                                    where        empcode = '''
                || p_empcode
                || '''
                                    and seektable = ''CMITEMM''
                                    )  b on a.itemcode = favoritykey1

                    where        a.itemdiv in (''03'', ''04'',''05'')
                                and (a.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.productdiv,'' '') <> ''90'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.itemcode' SORT,
                'L-100;L-200;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMMITEMMA')
   THEN                                             --제조제품마스터정보 2009-04-17 조성희
      OPEN IO_CURSOR FOR
         SELECT '제품 마스터 정보' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.itemcode  "품목코드",
                                a.itemname  "품목명",
                                NVL(a.itemunit,'''')  "규격"

                    from        CMITEMM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMITEMM''
                                                )  b on a.itemcode = favoritykey1

                    where        (a.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.productdiv,'' '') <> ''90'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.itemcode' SORT,
                'L-100;L-200;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'LOCM')
   THEN                                                             --위치마스터 정보
      OPEN IO_CURSOR FOR
         SELECT '위치 정보' NAME,
                   'select     case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                b.location  "위치",
                                b.whname  "창고",
                                b.warehouse  "창고코드"

                    from        vnLocation  b
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMEMPM''
                                                )  a on b.location = a.favoritykey1

                    where        (b.location like '''
                || p_gbcode
                || ''' || ''%'' or
                                b.whname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by b.warehouse, b.location' SORT,
                'L-110;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'BANKM')
   THEN                                             --은행마스터 정보 081118 등록 : 조성희
      OPEN IO_CURSOR FOR
         SELECT '은행 정보' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.bankcode  "은행코드",
                                NVL(a.bankname,'''') || '' '' || NVL(a.branchname,'''')  "은행명"

                    from        CMBANKM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMEMPM''
                                                )  b on a.bankcode = b.favoritykey1

                    where        (a.bankcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.bankname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.useyn,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.bankcode' SORT,
                'L-100;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACCOUNTM')
   THEN                                             --계좌마스터 정보 081118 등록 : 조성희
      OPEN IO_CURSOR FOR
         SELECT '계좌 정보' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.accountno  "계좌코드",
                                NVL(a.accremark,'''')  "계좌명",
                                c.bankname || '' '' || c.branchname  "은행명",
                                NVL(AC18.divname,'''')  "입출구분"

                    from        CMACCOUNTM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMEMPM''
                                                )  b
                                                on a.accountno = b.favoritykey1
                                left join CMBANKM  c on a.bankcode = c.bankcode
                                left join CMCOMMONM  AC18 on a.inoutdiv = AC18.divcode and AC18.cmmcode = ''AC18''

                    where        a.useyn = ''Y''
                                and (a.accountno like '''
                || p_gbcode
                || ''' || ''%'' or
                                c.bankname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                                a.accremark like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.accountno' SORT,
                'L-120;L-200;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACACCOUNTM')
   THEN                                                             --계좌마스터 정보
      OPEN IO_CURSOR FOR
         SELECT '계좌 정보' NAME,
                   'select         Case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                    a.accountno  "계좌코드",
                                    NVL(a.accremark,'''')  "계좌명",
                                    c.bankname || '' '' || c.branchname  "은행명",
                                    NVL(AC18.divname,'''')  "입출구분"

                        from        CMACCOUNTM  a
                                    left join    (
                                                    select        favoritykey1
                                                    from        SYSSEEKFAVORITY
                                                    where        empcode = '''
                || p_empcode
                || '''
                                                                and seektable = ''CMEMPM''
                                                    )  b
                                                    on a.accountno = b.favoritykey1
                        left join CMBANKM  c on a.bankcode = c.bankcode
                        left join CMCOMMONM  AC18 on a.inoutdiv = AC18.divcode and AC18.cmmcode = ''AC18''
                        where        a.useyn = ''Y''
                                    and (a.accountno like '''
                || p_gbcode
                || ''' || ''%'' or
                                    c.bankname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                                    a.accremark like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                        '
                   sqlstring,
                'order by a.accountno' SORT,
                'L-120;L-200;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'SLACC')
   THEN                                                      -- 계정 정보 등록 : 조성희
      OPEN IO_CURSOR FOR
         SELECT '계정 정보' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                b.divcode  "계정코드",
                                b.divname  "계정명",
                                c.divname  "구분"

                    from        CMCOMMONM  b
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMEMPM''
                                                )a on b.divcode = favoritykey1
                    left join CMCOMMONM  c on b.filter1 = c.divcode and c.cmmcode = ''SL81''

                    where        b.cmmcode = ''SL80''
                                and (b.divcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                b.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and b.usediv = ''Y''
                    '
                   sqlstring,
                'order by b.divcode' SORT,
                'L-70;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'SALPOWER')
   THEN                                                            --부서 및 사원조회
      OPEN IO_CURSOR FOR
         SELECT '부서 및 사원 조회' NAME,
                   'select        a.gg  "√",
                                a.deptcode  "코드",
                                a.deptname  "거래처명"

                    from (
                            select  case when favoritykey1 is null then ''N'' else ''Y'' end  gg,
                                    a.deptcode  deptcode,
                                    ltrim(NVL(a.topdeptname,'''') || '' '' || NVL(a.predeptname,'''') || '' '' || NVL(a.deptname,''''))  deptname

                            from    vnDEPT  a
                                    left join    (
                                                    select  favoritykey1
                                                    from    SYSSEEKFAVORITY
                                                    where   empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''SALPOWER''
                                                    )  b on a.deptcode = favoritykey1
                            where        (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.useyn,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')

                            union all

                            select  case when favoritykey1 is null then ''N'' else ''Y'' end  gg,
                                    empcode  deptcode,
                                    empname  deptname

                            from    CMEMPM  b
                                    left join    (
                                                    select          favoritykey1
                                                    from            SYSSEEKFAVORITY
                                                    where           empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''SALPOWER'' )a on empcode = favoritykey1

                            where        (''Y'' = '''
                || p_useyn
                --|| ''' and NVL(b.retiredt,'' '') = '' '' or ''N'' = '''
                || '''  or ''N'' = '''
                || p_useyn
                || ''')
                    )  a
                    where        (a.deptcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.deptname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.deptcode' SORT,
                'L-100;L-200;L-200;' coloumn
                --and NVL(a.outyn,'' '') = '' ''
           FROM DUAL;
   ELSIF (p_div = 'CMRELCUST')
   THEN
      OPEN IO_CURSOR FOR
         SELECT '매출거래처 마스터 정보' NAME,
                   'select        a.gg  "√",
                                a.custcode  "코드",
                                a.custname  "거래처명",
                                a.addr  "주소",
                                a.businessno  "사업자번호",
                                rtrim(a.ceoname)  "대표자",
                                a.deptname  "팀",
                                a.empname  "담당자"
                    from    (
                        select  case when b.favoritykey1 is null then ''N'' else ''Y'' end  gg,
                                a.custcode,
                                a.custname,
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  addr,
                                a.businessno,
                                rtrim(a.ceoname)  ceoname,
                                d.predeptname || '' '' || d.deptname  deptname,
                                c.empname  empname,
                                a.deptcode,
                                a.empcode

                        from    CMCUSTM  a
                                left join    (
                                                select  favoritykey1
                                                from    SYSSEEKFAVORITY
                                                where   empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMCUSTM''
                                                )  b on a.custcode = b.favoritykey1
                                left join CMEMPM  c on a.empcode = c.empcode
                                left join vnDEPT  d on a.deptcode = d.deptcode
                                join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''

                        where   a.custcode = '''
                || p_gbcode1
                || '''
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')

                        union all

                        select  case when b.favoritykey1 is null then ''N'' else ''Y'' end  gg,
                                a.custcode,
                                a.custname,
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  addr,
                                a.businessno,
                                rtrim(a.ceoname)  ceoname,
                                d.predeptname || '' '' || d.deptname  deptname,
                                c.empname  empname,
                                a.deptcode,
                                a.empcode

                        from
                        (
                            select  distinct relcustcode
                            from    CMCUSTRELS
                            where   custcode = '''
                || p_gbcode1
                || '''
                                    and custmngdiv = ''A''
                        )  z
                        join CMCUSTM  a on a.custcode = z.relcustcode
                        left join   (
                            select  favoritykey1
                            from    SYSSEEKFAVORITY
                            where   empcode = '''
                || p_empcode
                || '''
                                    and seektable = ''CMCUSTM''
                        ) b on a.custcode = b.favoritykey1
                        left join CMEMPM  c on a.empcode = c.empcode
                        left join vnDEPT  d on a.deptcode = d.deptcode

                        where        (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                    )  a
                    where        (a.custcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'CMRELCUST_P2')
   THEN
      --관련거래처마스터조회_NEW : 2013-10-01:이세민
      p_dvalue1 := SUBSTR (p_gbcode1, 0, INSTR (p_gbcode1, '/'));
      p_dtemp :=
         SUBSTR (p_gbcode1,
                 INSTR (p_gbcode1, '/') + 1,
                 LENGTH (p_gbcode1) - LENGTH (p_dvalue1));
      p_dvalue2 := p_dtemp;

      OPEN IO_CURSOR FOR
            SELECT '관련거래처 정보' NAME,
                   'select distinct
                            case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                            b.ecustcode "코드",
                            c1.custname "거래처명",
                            rtrim(NVL(c1.addr1,'''')) || '' '' || rtrim(NVL(c1.addr2,'''')) "주소",
                            c1.businessno "사업자번호",
                            rtrim(c1.ceoname) "대표자",
                            e.deptname "팀",
                            d.empname "담당자"

                    from    SLPROMPRCM b
                            left join    (
                                            select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''SLPROMPRCM'' )a on b.custcode = favoritykey1
                            join CMCUSTM c  on b.custcode = c.custcode
                            join CMCUSTM c1  on b.ecustcode = c1.custcode
                            left join CMEMPM d  on c1.empcode = d.empcode
                            left join CMDEPTM e  on d.deptcode = e.deptcode

                    where   b.custcode = '''
                || REPLACE(p_dvalue1, '/', '')
                || '''
                            and (b.ecustcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            c1.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by b.ecustcode' SORT,
                'L-80;L-120;L-180;C-90;L-50;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
           FROM DUAL;
      /*
         --useyn 조건 추가 20140303:이세민
         SELECT '관련거래처 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                            b.relcustcode "코드",
                            c1.custname "거래처명",
                            rtrim(NVL(c1.addr1,'''')) || '' '' || rtrim(NVL(c1.addr2,'''')) "주소",
                            c1.businessno "사업자번호",
                            rtrim(c1.ceoname) "대표자",
                            e.deptname "팀",
                            d.empname "담당자"

                    from    CMCUSTRELS b
                            left join    (
                                            select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMCUSTRELS'' )a on b.custcode = favoritykey1
                            join CMCUSTM c  on b.custcode = c.custcode
                            join CMCUSTM c1  on b.relcustcode = c1.custcode
                            left join CMEMPM d  on b.empcode = d.empcode
                            left join CMDEPTM e  on d.deptcode = e.deptcode

                    where   b.custcode = '''
                || REPLACE(p_dvalue1, '/', '')
                || '''
                            and (b.relcustcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            c1.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and b.orderdiv like ''%'
                || p_dvalue2
                || '''
                            and b.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || ''')))
                            and b.custmngdiv = ''A''
                            and b.useyn = ''Y''
                    '
                   sqlstring,
                'order by b.relcustcode' SORT,
                'L-80;L-120;L-180;C-90;L-50;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
           FROM DUAL;
           */
   ELSIF (p_div = 'ORDITEM_EMP')
   THEN
      --계약단가 담당자 조회_NEW
      p_dvalue1 := SUBSTR (p_gbcode1, 0, INSTR (p_gbcode1, '/'));
      
      p_dtemp :=
         SUBSTR (p_gbcode1,
                 INSTR (p_gbcode1, '/') + 1,
                 LENGTH (p_gbcode1) - LENGTH (p_dvalue1));
                 
                       
      p_dvalue2 := SUBSTR (p_dtemp, 0, INSTR (p_dtemp, '/'));
      
      
      p_dtemp :=
         SUBSTR (p_dtemp,
                 INSTR (p_dtemp, '/') + 1,
                 LENGTH (p_dtemp) - LENGTH (p_dvalue2));  
      
      
      OPEN IO_CURSOR FOR
         --useyn 조건 추가 20140303:이세민
         SELECT '제품담당자 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end "√"
                    ,      B.EMPCODE  AS  코드
                    ,      C.EMPNAME  AS  담당자명
                    ,      D.DRUGPRC  AS  기준단가
                    ,      B.BEFPRC   AS  발행가
                    ,      B.AFTPRC   AS  약정가

                    from    SLPROMPRCM b
                            left join    (
                                            select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''SLPROMPRCM'' )a on b.custcode = favoritykey1
                            join CMEMPM c  on b.empcode = c.empcode
                            join CMITEMM d  on b.itemcode = d.itemcode

                    where   b.custcode = '''
                || REPLACE(p_dvalue1, '/', '')
                || '''
                            and b.ecustcode like ''%'
                || REPLACE(p_dvalue2, '/', '')
                || '''
                            and b.itemcode = '''
                || p_dtemp
                || ''''
                   sqlstring,
                'order by b.empcode' SORT,
                'L-80;L-120;L-180;C-90;L-50;L-80;' coloumn,
                'N;N;N;N;N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'CMRELCUST_P3')
   THEN
      p_pdvalue1 := SUBSTR (p_gbcode1, 0, INSTR (p_gbcode1, '/') - 1);
      p_pdtemp :=
         SUBSTR (p_gbcode1,
                 INSTR (p_gbcode1, '/') + 1,
                 LENGTH (p_gbcode1) - LENGTH (p_pdvalue1));
      p_pdvalue2 := p_pdtemp;

      --계약단가 등록용 관련 거래처
      OPEN IO_CURSOR FOR
         SELECT '관련거래처 정보' NAME,
                   'select distinct case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                            b.relcustcode  "코드",
                            c1.custname  "거래처명",
                            rtrim(NVL(c1.addr1,'''')) || '' '' || rtrim(NVL(c1.addr2,'''')) "주소",
                            c1.businessno  "사업자번호",
                            rtrim(c1.ceoname)  "대표자",
                            e.deptname  "팀"

                    from    CMCUSTRELS  b
                            left join    (  select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''CMCUSTRELS'' )a on b.custcode = favoritykey1
                            join CMCUSTM  c on b.custcode = c.custcode
                            join CMCUSTM  c1 on b.relcustcode = c1.custcode
                            left join CMEMPM  d on b.empcode = d.empcode
                            left join CMDEPTM  e on d.deptcode = e.deptcode

                    where   b.custcode = '''
                || p_pdvalue1
                || '''
                            and (b.relcustcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            c1.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and b.orderdiv like ''%'
                || p_pdvalue2
                || '''
                            and b.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || ''')))
                            and b.custmngdiv = ''A''
                    '
                   sqlstring,
                'order by b.relcustcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'CM71')
   THEN                                                  --  금융기관 20101005 조성희
      OPEN IO_CURSOR FOR
         SELECT '금융기관' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.divcode  "기관코드",
                            a.divname  "기관명"

                    from    CMCOMMONM  a
                            left join    (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''ACCARDM''
                            )  b on a.divcode = favoritykey1

                    where   a.cmmcode = ''CM71''
                            and (a.divcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.divcode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'EXPORT')
   THEN                                         -- 수출 행선지 조회 20100519 등록 : 이동현
      OPEN IO_CURSOR FOR
         SELECT '수출행선지조회' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                    a.divcode  "행선지코드",
                                    a.divname  "행선지명"
                        from        CMCOMMONM  a
                                    left join    (
                                                    select        favoritykey1
                                                    from        SYSSEEKFAVORITY
                                                    where        empcode = '''
                || p_empcode
                || '''
                                                                and seektable = ''CMCOMMONM''
                                                )  b
                                                on a.divcode = favoritykey1
                        where        a.cmmcode = ''TR08''
                                    and (a.divcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                         a.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                    and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.usediv,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                        '
                   sqlstring,
                'order by a.divcode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACMNGM')
   THEN                                                               --관리항목코드
      OPEN IO_CURSOR FOR
         SELECT '관리항목코드' NAME,
                   'select case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.mngclucode  "관리항목코드",
                            a.mngcluname  "관리항목명"

                    from    ACMNGM  a
                            left join (
                                        select  favoritykey1
                                        from    SYSSEEKFAVORITY
                                        where   empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''ACMNGM''
                            ) b on a.mngclucode = b.favoritykey1

                    where   ( upper(a.mngclucode) like upper('''
                || p_gbcode
                || ''') || ''%'' or
                            upper(a.mngcluname) like ''%'' || upper( '''
                || p_gbcode
                || ''' ) || ''%'')
                    '
                   sqlstring,
                'order by a.mngclucode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACACCM')
   THEN                                                     --  전표처리가 가능한 계정코드
      OPEN IO_CURSOR FOR
         SELECT '계정코드' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.acccode  "계정코드",
                            a.accname  "계정명"
                    from    ACACCM  a
                    left join (
                                select  favoritykey1
                                from    SYSSEEKFAVORITY
                                where   empcode = '''
                || p_empcode
                || '''
                                        and seektable = ''ACACCM''
                                )  b on a.acccode = favoritykey1
                    where   a.orduseyn = ''Y''
                            and (a.acccode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.accname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and a.deleteyn = ''N''
                    '
                   sqlstring,
                'order by a.acccode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACACCM1')
   THEN                          --  전표처리가 가능한 계정코드 (현금계정 제외) - 2010-12-15 배종성
      p_cashcode := '11101010';

      SELECT value1
        INTO p_cashcode
        FROM SYSPARAMETERMANAGE
       WHERE parametercode = 'acccashcode';

      OPEN IO_CURSOR FOR
         SELECT '계정코드' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.acccode  "계정코드",
                            a.accname  "계정명"

                    from    ACACCM  a
                            left join    (  select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''ACACCM'' )  b on a.acccode = favoritykey1
                    where   a.orduseyn = ''Y''
                            and (a.acccode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.accname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and a.deleteyn = ''N''
                            and a.acccode <> '''
                || p_cashcode
                || '''
                    '
                   sqlstring,
                'order by a.acccode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACACCM2')
   THEN                                                   --  전표처리가 가능한 반제계정코드
      OPEN IO_CURSOR FOR
         SELECT '계정코드' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.acccode  "계정코드",
                            a.accname  "계정명"

                    from        ACACCM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''ACACCM''
                                )  b on a.acccode = favoritykey1

                    where        a.orduseyn = ''Y''
                                and (a.acccode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.accname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and a.deleteyn = ''N''
                                and a.returnyn = ''Y''
                    '
                   sqlstring,
                'order by a.acccode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACACCALL')
   THEN                                                            --  모든 계정코드
      OPEN IO_CURSOR FOR
         SELECT '계정코드' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.acccode  "계정코드",
                            a.accname  "계정명"
                    from        ACACCM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''ACACCM''
                                )  b on a.acccode = favoritykey1
                    where        (a.acccode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.accname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.acccode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACACCBUDYN')
   THEN                                                         --  통제여부 = 'Y'
      OPEN IO_CURSOR FOR
         SELECT '계정코드' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.acccode  "계정코드",
                            a.accname  "계정명"

                    from        ACACCM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''ACACCM''
                                )  b on a.acccode = favoritykey1

                    where        a.budglimityn = ''Y''
                                and (a.acccode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.accname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.acccode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMCOMPM')
   THEN                                                                 --회사정보
      OPEN IO_CURSOR FOR
         SELECT '회사코드' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.compcode  "회사코드",
                            a.compname  "회사명"

                    from    CMCOMPM  a
                            left join ( select  favoritykey1
                                        from    SYSSEEKFAVORITY
                                        where   empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CMCOMPM''
                                        )  b on a.compcode = favoritykey1

                    where        (a.compcode like '''
                || p_gbcode
                || ''' || ''%'' or
                    a.compname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.compcode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACCARDM')
   THEN                                                    --  카드정보 20100914추가
      OPEN IO_CURSOR FOR
         SELECT '카드번호' name,
                   'select  case when favoritykey1 is null then ''N'' else ''Y'' end as "√",
                          a.cardno as "카드번호",
                          a.cardname as "카드명",
                          c.empname as "사용자"
                  from    ACCARDM a
                          left join (
                              select  favoritykey1
                              from    SYSSEEKFAVORITY
                              where   empcode = '''
                || p_empcode
                || '''
                                      and seektable = ''accardm''
                          )  b on a.cardno = favoritykey1
                          left join CMEMPM c
                              on a.empcode = c.empcode
                  where   (a.cardno like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                           a.cardname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                           c.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')'
                   AS sqlstring,
                'order by a.cardno' sort,
                'l-100;l-200;l-100;l-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACCRDMNG')
   THEN
      OPEN IO_CURSOR FOR
         SELECT '카드번호' name,
                   'select  case when favoritykey1 is null then ''N'' else ''Y'' end as "√",
                          a.cardno as "카드번호",
                          c.cardname as "카드명",
                          d.empname as "사용자"
                  from (
                      select  compcode, cardno
                      from    ACCRDMNG
                      where   empcode = '''
                || p_empcode
                || '''
                      union
                      select  compcode, cardno
                      from    ACCARDM
                      where   empcode = '''
                || p_empcode
                || '''
                  ) a
                          left join (
                              select  favoritykey1
                              from    SYSSEEKFAVORITY
                              where   empcode = '''
                || p_empcode
                || '''
                                      and seektable = ''ACCRDMNG''
                          )  b on a.cardno = favoritykey1
                          join ACCARDM c
                              on a.compcode = c.compcode
                              and a.cardno = c.cardno
                              and c.useyn = ''Y''
                          left join CMEMPM d
                              on c.empcode = d.empcode
                  where   (a.cardno like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                           c.cardname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                           d.empname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')'
                   AS sqlstring,
                'order by a.cardno' sort,
                'l-100;l-200;l-100;l-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACBONDM')
   THEN                                               --  증권번호 20100929 추가(회계)
      OPEN IO_CURSOR FOR
         SELECT '증권번호' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.bondno  "관리번호",
                            a.bondname  "증권명칭",
                            a.stcbondno  "증권번호"

                    from        ACBONDM  a
                                left join    (
                                                select      favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where       empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''ACBONDM''
                                                )  b on a.bondno = favoritykey1

                    where        (a.bondno like '''
                || p_gbcode
                || ''' || ''%'' or
                    a.bondname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.bondno' SORT,
                'L-100;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACLOANM')
   THEN                                           --차입계좌마스터 정보 101018 등록 : 민승기
      OPEN IO_CURSOR FOR
         SELECT '차입계좌 정보' NAME,
                   'select     case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.loanno  "차입번호",
                                NVL(a.loanname,'''')  "차입명",
                                c.bankname || '' '' || c.branchname  "은행명",
                                a.accountno  "계좌번호",
                                NVL(AC43.divname,'''')  "차입구분"

                    from        ACLOANM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''ACLOANM''
                                                )  b on a.loanno = favoritykey1
                    left join CMBANKM  c on a.bankcode = c.bankcode
                    left join CMCOMMONM  AC43 on a.loandiv = AC43.divcode and AC43.cmmcode = ''AC43''            --차입구분
                    where   (a.loanno like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.loanname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                            a.accountno like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by  convert(loanno, ''US8ICL'')    ' SORT,
                'L-100;L-200;L-100;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACLOANMALL')
   THEN                                         --차입계좌마스터 모든정보 101223 등록 : 최기홍
      OPEN IO_CURSOR FOR
         SELECT '차입계좌 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.loanno  "차입번호",
                            NVL(a.loanname,'''')  "차입명",
                            a.accountno  "계좌번호",
                            c.accremark  "계좌명칭"

                    from        ACLOANM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''ACLOANM''
                                                ) b on a.loanno = favoritykey1
                    left join CMACCOUNTM  c on a.accountno = c.accountno

                    where        (a.loanno like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.loanname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'' or
                            a.accountno like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.loanno' SORT,
                'L-100;L-200;L-150;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACASSM')
   THEN                                             --자산마스터 정보 101018 등록 : 민승기
      OPEN IO_CURSOR FOR
         SELECT '자산 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.asscode  "자산코드",
                            a.assname  "자산명",
                            NVL(AC70.divname,'''')  "자산분류"

                    from        ACASSM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''ACASSM''
                                                )  b on a.asscode = favoritykey1
                                left join CMCOMMONM  AC70 on a.assdiv = AC70.divcode and AC70.cmmcode = ''AC70''            --자산분류

                    where        a.assstate = ''1''
                                and (a.asscode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.assname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.asscode' SORT,
                'L-100;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACORDM')
   THEN                                              --결의전표 정보 101018 등록 : 민승기
      OPEN IO_CURSOR FOR
         SELECT '결의전표 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.slipinnum  "결의번호",
                            e.empname  "결의사원",
                            a.slipinremark  "결의내용"

                    from    ACORDM  a
                            left join (
                                        select        favoritykey1
                                        from        SYSSEEKFAVORITY
                                        where        empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''ACORDM''
                                        )  b on a.slipinno = favoritykey1
                            left join CMEMPM  e on a.empcode = e.empcode and a.plantcode = e.plantcode

                    where   a.slipdiv <> ''A''
                            and (a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            e.empname like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.slipinremark like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.slipinnum' SORT,
                'L-100;L-100;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACORDM2')
   THEN                                              --회계전표 정보 101018 등록 : 민승기
      OPEN IO_CURSOR FOR
         SELECT '결의전표 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.slipnum  "회계번호",
                            e.empname  "회계사원",
                            a.slipinremark  "회계내용"

                    from    ACORDM  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''ACORDM''
                            )  b on a.slipinno = favoritykey1
                            left join CMEMPM  e on a.empcode = e.empcode and a.plantcode = e.plantcode

                    where  a.slipinstate = ''4''
                            and (a.empcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            e.empname like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.slipinremark like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.slipnum' SORT,
                'L-100;L-100;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'TAXOFFICE')
   THEN                                          --세무서코드마스터 정보 101110 등록 : 배종성
      OPEN IO_CURSOR FOR
         SELECT '세무서조회' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.divcode  "세무서코드",
                            a.divname  "세무서명"

                    from    CMCOMMONM  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMCOMMONM''
                            )  b on a.divcode = favoritykey1

                    where   a.cmmcode = ''CM65''
                            and (a.divcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.usediv,'''') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.divcode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'OFFICE')
   THEN                                          --세무서코드마스터 정보 101110 등록 : 배종성
      OPEN IO_CURSOR FOR
         SELECT '관할구정조회' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.divcode  "관할구청코드",
                            a.divname  "관할구청명"
                    from    CMCOMMONM  a
                            left join    (
                                            select       favoritykey1
                                            from         SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMCOMMONM''
                            )b
                            on a.divcode = favoritykey1

                    where   a.cmmcode = ''CM66''
                            and (a.divcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.usediv,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.divcode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'common')
   THEN                                                                -- 공통코드
      OPEN IO_CURSOR FOR
         SELECT '공통코드' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.divcode  "코드",
                            a.divname  "명"

                    from    CMCOMMONM  a
                            left join    (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMCOMMONM''
                            )  b
                            on a.divcode = favoritykey1

                    where   (a.divcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.usediv,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.divcode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACBILLMA')
   THEN                                                          --어음구분중 받을어음만
      OPEN IO_CURSOR FOR
         SELECT '어음번호' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.billno  "어음번호"
                            ,c.custname  "발행처"
                            ,a.issdate  "발행일자"
                            ,a.expdate  "만기일자"

                    from    ACBILLM  a
                            left join (
                                        select  favoritykey1
                                        from    SYSSEEKFAVORITY
                                        where   empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''ACBILLM'' )  b on a.billno = favoritykey1
                            left join CMCUSTM  c on a.custcode = c.custcode and a.plantcode = c.plantcode
                    left join CMDEPTM  d on a.deptcode = d.deptcode and a.plantcode = d.plantcode

                    where   a.billcls = ''1''
                            and a.billno like '''
                || p_gbcode
                || ''' || ''%''
                    '
                   sqlstring,
                'order by a.billno' SORT,
                'L-100;L-200;L-100;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACBILLMB')
   THEN                                                          --어음구분중 지급어음만
      OPEN IO_CURSOR FOR
         SELECT '어음번호' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.billno  "어음번호"
                            ,c.custname  "발행처"
                            ,a.issdate  "발행일자"
                            ,a.expdate  "만기일자"
                    from    ACBILLM  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''ACBILLM''
                            )  b on a.billno = favoritykey1
                            left join CMCUSTM  c on a.custcode = c.custcode and a.plantcode = c.plantcode
                            left join CMDEPTM  d on a.deptcode = d.deptcode and a.plantcode = d.plantcode
                    where   a.billcls = ''2''
                            and a.billno like '''
                || p_gbcode
                || ''' || ''%''
                    '
                   sqlstring,
                'order by a.billno' SORT,
                'L-100;L-200;L-100;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACBONDM')
   THEN                                            --유가증권 정보조회 101223 등록 : 최기홍
      OPEN IO_CURSOR FOR
         SELECT '유가증권 정보' AS NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end as "√",
                            a.bondno as "관리번호",
                            a.bondname as "증권명칭"
                    from    ACBONDM a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''ACBONDM''
                                            ) as b on a.loanno = favoritykey1
                    where (a.bondno like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.bondname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   AS sqlstring,
                'order by a.bondno' AS SORT,
                'L-100;L-200;L-300;' AS coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACTAXM1')
   THEN                                              --세금계산서조회, 2010-11-25 배종성
      OPEN IO_CURSOR FOR
         SELECT '세금계산서 정보' NAME,
                   'select case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.taxno  "계산서번호",
                            c.custname  "거래처명"

                    from    (select * from ACTAXM where saleinyn = ''Y'')   a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMCUSTM''
                                            )  b on a.custcode = b.favoritykey1
                            left join CMCUSTM  c on a.custcode = c.custcode

                    where   (a.taxno like ''%'
                || p_gbcode
                || ''' || '''' or
                            c.custname like '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.taxno' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACTAXM2')
   THEN                                              --세금계산서조회, 2010-11-25 배종성
      OPEN IO_CURSOR FOR
         SELECT '세금계산서 정보' NAME,
                   'select case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.taxno  "계산서번호",
                            c.custname  "거래처명"

                    from    (select * from ACTAXM where saleinyn = ''N'')   a
                            left join    (
                                            select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''CMCUSTM'' )  b on a.custcode = b.favoritykey1
                            left join CMCUSTM  c on a.custcode = c.custcode

                    where   (a.taxno like ''%'
                || p_gbcode
                || ''' || '''' or
                            c.custname like '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.taxno' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACASSMM')
   THEN
      OPEN IO_CURSOR FOR
         SELECT '자산정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.asscode  "자산코드",
                            a.assname  "자산명"

                    from    ACASSM  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''ACASSM'' )  b on a.asscode = favoritykey1

                    where   (a.asscode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.assname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.asscode' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACAUTORULE')
   THEN
      OPEN IO_CURSOR FOR
         SELECT '자동분개정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.acautorcode  "분개코드",
                            a.acautorname  "분개명"
                    from    ACAUTORULE a
                            left join (
                                        select      favoritykey1
                                        from        SYSSEEKFAVORITY
                                        where       empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''ACAUTORULE''
                                        ) b on a.acautorcode = favoritykey1
                    where   a.acautorcode like ''R%''
                            and (a.acautorcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.acautorname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.acautorcode' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMPLANTM')
   THEN                                             --사업장 정보조회 101124 등록 : 최기홍
      OPEN IO_CURSOR FOR
         SELECT '사업장 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.plantcode  "사업장코드",
                            a.plantname  "사업장명칭"

                    from    CMPLANTM  a
                            left join    (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMPLANTM''
                                            )  b
                                            on a.plantcode = favoritykey1

                    where   (a.plantcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.plantname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.plantcode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'TREXCOSTM')
   THEN                                                            --수출비용코드 정보
      OPEN IO_CURSOR FOR
         --TRCOSTM 테이블 없음
         SELECT '수출비용코드 정보' AS NAME,
                   'select case when b.favoritykey1 is null then ''N'' else ''Y'' end "√",
                            a.costcode as "비용코드",
                            a.costname || ''('' || NVL(c.divname,'''') || '')'' as "비용명",
                            NVL(d.divname,'''') as "분배기준"

                    from    TRCOSTM a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''TRCOSTM''
                                            ) as b on a.costcode = b.favoritykey1
                    left join CMCOMMONM as c on a.groupcode = c.divcode and c.cmmcode = ''TR02''
                    left join CMCOMMONM as d on a.divcode = d.divcode and d.cmmcode = ''TR03''

                    where   a.trgb = ''1''
                            and (a.costcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            NVL(c.divname,'''') || '' '' || a.costname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   AS sqlstring,
                'order by a.costcode' AS SORT,
                'L-50;L-200;L-100;' AS coloumn
           FROM DUAL;
   ELSIF (p_div = 'CSCOSTM')
   THEN                                            --원가요소 정보조회 110302 등록 : 배종성
      OPEN IO_CURSOR FOR
         SELECT '원가요소 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.costcode  "원가요소코드",
                            a.costname  "원가요소명",
                            cs02.divname  "원가유형",
                            cs03.divname  "원가구분",
                            cs04.divname  "분배기준"

                    from    CSCOSTM  a
                            left join (
                                        select      favoritykey1
                                        from        SYSSEEKFAVORITY
                                        where       empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''CSCOSTM''
                                        )  b on a.costcode = favoritykey1
                            left join CMCOMMONM  cs02 on cs02.cmmcode = ''CS02'' and cs02.divcode = a.costcls
                            left join CMCOMMONM  cs03 on cs03.cmmcode = ''CS03'' and cs03.divcode = a.costdiv
                            left join CMCOMMONM  cs04 on cs04.cmmcode = ''CS04'' and cs04.divcode = a.distdiv

                    where   (a.costcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.costname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.costcode' SORT,
                'L-100;L-200;L-100;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'EquipmentMaster')
   THEN                          --생산설비 정보조회 110308 등록 : 이영재 (EquipmentMaster)
      OPEN IO_CURSOR FOR
         SELECT '생산설비 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.equipmentcode  "설비코드",
                            a.equipmentkorname  "설비명",
                            p.plantname  "사업장명"

                    from    PDEQUIPMENTM  a
                            left join (
                                        select      favoritykey1
                                        from        SYSSEEKFAVORITY
                                        where       empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''PDEQUIPMENTM''
                                        )  b on a.equipmentcode = favoritykey1
                            left join CMPLANTM  p on p.plantcode = a.plantcode

                    where   (a.equipmentcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.equipmentkorname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.equipmentcode' SORT,
                'L-100;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CSITEMA')
   THEN                                                       -- 원가제품조회(total)
      IF NVL (p_gbcode1, ' ') <> ' '
      THEN
         p_gbcode1_1 := SUBSTR (p_gbcode1, INSTR (p_gbcode1, ';') + 1, 1000);
         p_compcode_csitema :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_plantcode_csitema :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_datadiv_csitema :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_costym_csitema :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);
      END IF;

      SELECT CASE
                WHEN p_datadiv_csitema = '1' THEN p_costym_csitema
                ELSE SUBSTR (p_costym_csitema, 4) || '-01'
             END
        INTO p_startym_csitema
        FROM DUAL;


      p_preym_csitema :=
         TO_CHAR (ADD_MONTHS (p_costym_csitema || '-01', -1), 'YYYY-MM');


      OPEN IO_CURSOR FOR
         SELECT '원가제품 정보' NAME,
                   'select distinct
                            case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            NVL(d.itemcode, a.itemcode)  "제품코드",
                            NVL(d.itemname, c.itemname)  "제품명"
                    from    (
                                select  itemcode
                                from    CSLOTWCSTD
                                where   compcode = '''
                || p_compcode_csitema
                || '''
                                        and plantcode = '''
                || p_plantcode_csitema
                || '''
                                        and datadiv = '''
                || p_datadiv_csitema
                || '''
                                        and costym = '''
                || p_preym_csitema
                || '''

                                union

                                select  itemcode
                                from    CSLOTCSTD
                                where   compcode = '''
                || p_compcode_csitema
                || '''
                                        and plantcode = '''
                || p_plantcode_csitema
                || '''
                                        and datadiv = '''
                || p_datadiv_csitema
                || '''
                                        and costym between '''
                || p_startym_csitema
                || '''
                                        and '''
                || p_costym_csitema
                || '''

                                union

                                select  itemcode
                                from    CSLOTWCSTD
                                where   compcode = '''
                || p_compcode_csitema
                || '''
                                        and plantcode = '''
                || p_plantcode_csitema
                || '''
                                        and datadiv = '''
                || p_datadiv_csitema
                || '''
                                        and costym = '''
                || p_costym_csitema
                || '''
                    ) a
                    left join (
                                select  favoritykey1
                                from    SYSSEEKFAVORITY
                                where   empcode = '''
                || p_empcode
                || '''
                                        and seektable = ''CMITEMM'' )  b on a.itemcode = favoritykey1
                    join CMITEMM  c on a.itemcode = c.itemcode
                    left join CMITEMM  d on c.mitemcode = d.itemcode
                    where   (NVL(d.itemcode, a.itemcode) like '''
                || p_gbcode
                || ''' || ''%'' or
                            NVL(d.itemname, c.itemname) like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by 제품코드' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CSITEMB')
   THEN                                                -- 원가제품조회(Lot) - 생산제품조회
      IF NVL (p_gbcode1, ' ') <> ' '
      THEN
         p_gbcode1_1 := SUBSTR (p_gbcode1, INSTR (p_gbcode1, ';') + 1, 1000);
         p_compcode_csitemb :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_plantcode_csitemb :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_datadiv_csitemb :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_costym_csitemb :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);
      END IF;

      SELECT CASE
                WHEN p_datadiv_csitemb = '1' THEN p_costym_csitemb
                ELSE SUBSTR (p_costym_csitemb, 4) || '-01'
             END
        INTO p_startym_csitemb
        FROM DUAL;

      OPEN IO_CURSOR FOR
         SELECT '생산제품 정보' NAME,
                   'select distinct
                            case when favoritykey1 is null then ''N'' else ''Y'' end  "√"
                            ,a.itemcode  "제품코드"
                            ,c.itemkorname  "제품명"
                            ,fnNumericToString(c.packingunitqty,''S2'') || d.divname  "함량"

                    from    CSLOTCSTM  a
                            left join (
                                        select  favoritykey1
                                        from    SYSSEEKFAVORITY
                                        where   empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''CSLOTCSTM''
                                        )  b on a.itemcode = favoritykey1
                            left join PDPACKINGGM  c on a.itemcode = c.itemcode
                            left join vnCommonMaster  d on d.cmmcode = ''CMM02'' and c.itemunit = d.divcode

                    where   a.compcode = '''
                || p_compcode_csitemb
                || '''
                            and a.plantcode = '''
                || p_plantcode_csitemb
                || '''
                            and a.datadiv = '''
                || p_datadiv_csitemb
                || '''
                            and a.costym between '''
                || p_startym_csitemb
                || ''' and '''
                || p_costym_csitemb
                || '''
                            and (a.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            c.itemkorname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                ' order by 제품코드' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CSMAKEA')
   THEN                                                -- 생산내역조회 (원가제품조회(Lot))
      IF NVL (p_gbcode1, ' ') <> ' '
      THEN
         p_gbcode1_1 := SUBSTR (p_gbcode1, INSTR (p_gbcode1, ';') + 1, 1000);
         p_compcode_csmakea :=
            SUBSTR (p_gbcode1_1, 1, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_plantcode_csmakea :=
            SUBSTR (p_gbcode1_1, 1, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_datadiv_csmakea :=
            SUBSTR (p_gbcode1_1, 1, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_itemcode_csmakea :=
            SUBSTR (p_gbcode1_1, 1, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_costym_csmakea :=
            SUBSTR (p_gbcode1_1, 1, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);
      END IF;

      SELECT CASE
                WHEN p_datadiv_csmakea = '1' THEN p_costym_csmakea
                ELSE SUBSTR (p_costym_csmakea, 4) || '-01'
             END
        INTO p_startym_csmakea
        FROM DUAL;

      OPEN IO_CURSOR FOR
         SELECT '생산내역 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√"
                            ,a.itemcode  "제품코드"
                            ,c.itemkorname  "제품명"
                            ,a.lotno  "LotNo"
                            ,a.batchsize  "배치크기"
                            ,fnNumericToString(c.packingunitqty,''S2'') || d.divname   "함량"
                            ,a.makeqty  "생산량"

                    from    CSLOTCSTM  a
                            left join   (
                                            select    favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where    empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CSLOTCSTM''
                                            )  b
                                            on a.itemcode = favoritykey1
                            left join PDPACKINGGM  c on a.itemcode = c.itemcode
                            left join vnCommonMaster  d on d.cmmcode = ''CMM02'' and c.itemunit = d.divcode

                    where   a.compcode = '''
                || p_compcode_csmakea
                || '''
                            and a.plantcode = '''
                || p_plantcode_csmakea
                || '''
                            and a.datadiv = '''
                || p_datadiv_csmakea
                || '''
                            and a.costym between '''
                || p_startym_csmakea
                || ''' and '''
                || p_costym_csmakea
                || '''
                            and (a.itemcode like '''
                || p_itemcode_csmakea
                || ''' || ''%'' or
                            c.itemkorname like ''%'' || '''
                || p_itemcode_csmakea
                || ''' || ''%'' )
                            and a.lotno like '''
                || p_gbcode
                || ''' || ''%''
                    '
                   sqlstring,
                ' order by 제품코드, LotNo' SORT,
                'L-100;L-150;L-70;L-80;L-60;L-70;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CSMAKEM')
   THEN                                                              -- 원가제품조회
      IF NVL (p_gbcode1, ' ') <> ' '
      THEN
         p_gbcode1_1 := SUBSTR (p_gbcode1, INSTR (p_gbcode1, ';') + 1, 1000);
         p_compcode_csmakem :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_plantcode_csmakem :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_datadiv_csmakem :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);

         p_costyy_csmakem :=
            SUBSTR (p_gbcode1_1, 0, INSTR (p_gbcode1_1, ';') - 1);
         p_gbcode1_1 :=
            SUBSTR (p_gbcode1_1, INSTR (p_gbcode1_1, ';') + 1, 1000);
      END IF;

      OPEN IO_CURSOR FOR
         SELECT '생산내역 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√"
                            ,a.itemcode  "제품코드"
                            ,c.itemkorname  "제품명"
                            ,fnNumericToString(c.packingunitqty,''S2'') || d.divname  "함량"

                    from    CSITEMCSTM  a
                            left join    (
                                            select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''CSITEMCSTM''
                                            )  b on a.itemcode = favoritykey1
                            left join PDPACKINGGM  c on a.itemcode = c.itemcode
                            left join vnCommonMaster  d on d.cmmcode = ''CMM02'' and    c.itemunit = d.divcode

                    where   a.compcode = '''
                || p_compcode_csmakem
                || '''
                            and a.plantcode = '''
                || p_plantcode_csmakem
                || '''
                            and a.datadiv = '''
                || p_datadiv_csmakem
                || '''
                            and a.costyy = '''
                || p_costyy_csmakem
                || '''
                            and (a.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            c.itemkorname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                ' order by 제품코드' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CSCUSTMAKE')
   THEN                                   --매입(1) (4) (5) 정보조회 111130 등록 : 배종성
      OPEN IO_CURSOR FOR
         SELECT '매출거래처 마스터 정보' NAME,
                   'select case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.custcode  "코드",
                            a.custname  "거래처명",
                            rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                            a.businessno  "사업자번호",
                            rtrim(a.ceoname)  "대표자",
                            d.predeptname || '' '' || d.deptname  "팀",
                            c.empname  "담당자"

                    from CMCUSTM   a
                        left join    (
                                        select      favoritykey1
                                        from        SYSSEEKFAVORITY
                                        where       empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''CMCUSTM''
                                        )  b on a.custcode = b.favoritykey1
                        left join CMEMPM  c on a.empcode = c.empcode
                        left join vnDEPT  d on a.deptcode = d.deptcode

                    where   a.custdiv in (''1'', ''4'', ''5'')
                            and (a.custcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'CMCOMMONM')
   THEN                                                            --  공통항목 조회
      OPEN IO_CURSOR FOR
         SELECT '공통항목정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.divcode  "항목코드",
                            a.divname  "항목명"

                    from    CMCOMMONM  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMCOMMONM''
                                            )  b on a.divcode = favoritykey1

                    where   a.cmmcode = '''
                || p_gbcode1
                || '''
                            and (a.divcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and a.usediv = ''Y''
                    '
                   sqlstring,
                'order by a.divcode' SORT,
                'L-100;L-200;L-300;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMMITEMMEDI')
   THEN              --단가가 등록된 제조제품 조회 2013-09-06: 이세민, 규격표시 제거 2014-02-18:이세민
      OPEN IO_CURSOR FOR
         SELECT '제조제품 마스터 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            b.itemcode  "품목코드",
                            b.itemname  "품목명"
                            /*,NVL(b.itemunit,'''')  규격*/
                    from    CMITEMM  b
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMITEMM''
                                            )  a on b.itemcode = favoritykey1
                            join (
                                    select  itemcode
                                    from    SLEDIPRICEM
                                    group by itemcode
                            )  c on b.itemcode = c.itemcode

                    where   b.itemdiv in (''03'', ''04'' ,''05'')
                            and (b.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            b.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(b.productdiv,'' '') <> ''90'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by b.itemcode' SORT,
                'L-100;L-200;L-100;' coloumn                          --L-100;
           FROM DUAL;
   ELSIF (p_div = 'CMCUSTM_REL')
   THEN                                   --거래처마스터조회(관련거래처 등록용) 2013-10-18 이세민
      --영업권한에 따른 조회는 제거
      --유통구분에 따른 대상 조회 처리.
      --도매인 경우 : 동일도매처 포함 병원만 조회 (의원포함시킴 20140304:이세민)
      --약국 : 동일약국만 조회
      --의원 : 동일의원 포함 약국조회

      p_dvalue1_1 := SUBSTR (p_gbcode1, 0, INSTR (p_gbcode1, '/'));
      p_dvalue1_2 :=
         SUBSTR (p_gbcode1,
                 INSTR (p_gbcode1, '/') + 1,
                 LENGTH (p_gbcode1) - (INSTR ('/', p_gbcode1)));

      OPEN IO_CURSOR FOR
         SELECT '거래처 정보' NAME,
                   'select case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.custcode  "코드",
                            a.custname  "거래처명",
                            rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                            a.businessno  "사업자번호",
                            rtrim(a.ceoname)  "대표자",
                            d.predeptname || '' '' || d.deptname  "팀",
                            c.empname  "담당자"

                    from    CMCUSTM  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMCUSTM''
                                            )  b on a.custcode = b.favoritykey1
                            left join CMEMPM  c on a.empcode = c.empcode
                            left join vnDEPT  d on a.deptcode = d.deptcode
                            join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''

                    where   (a.custcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                            and a.utdiv like ''%''
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'CMINCUST_TS')
   THEN
      OPEN IO_CURSOR FOR
         --이기 반품 거래처 관련 조회시 사용하는 거래처 마스터 조회
         --영업권한에 대한 조회가 제거됨
         SELECT '거래처 마스터 정보' NAME,
                   'select distinct
                            case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.custcode  "코드",
                            a.custname  "거래처명",
                            rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                            a.businessno  "사업자번호",
                            rtrim(a.ceoname)  "대표자",
                            d.predeptname || '' '' || d.deptname  "팀",
                            c.empname  "담당자",
                            a.utdiv  "유통코드",
                            g.divname  "유통"

                    from    CMCUSTM  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMCUSTM''
                                                    )  b on a.custcode = b.favoritykey1
                            left join CMEMPM  c on a.empcode = c.empcode
                            left join vnDEPT  d on a.deptcode = d.deptcode
                            left join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                            join (
                                    select      distinct custcode
                                    from        CMCUSTRELS
                                    where       custmngdiv = ''A''
                            )  f  on a.custcode = f.custcode
                            left join CMCOMMONM  g on g.cmmcode = ''CM15'' and a.utdiv = g.divcode

                    where   (a.custcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'CMRELCUST_TS')
   THEN
      --이기 반품 관련거래처 조회시 사용 20140212:이세민
      --영업권한에 대한 조회가 제거됨.

      p_dvalue11 := SUBSTR (p_gbcode1, 0, INSTR (p_gbcode1, '/') - 1);
      p_dtemp1 :=
         SUBSTR (p_gbcode1,
                 INSTR (p_gbcode1, '/') + 1,
                 LENGTH (p_gbcode1) - LENGTH (p_dvalue11));
      p_dvalue21 := p_dtemp1;

      OPEN IO_CURSOR FOR
         SELECT '관련거래처 정보' AS NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end as "√",
                            b.relcustcode as "코드",
                            c1.custname as "거래처명",
                            rtrim(NVL(c1.addr1,'''')) || '' '' || rtrim(NVL(c1.addr2,'''')) as "주소",
                            c1.businessno as "사업자번호",
                            rtrim(c1.ceoname) as "대표자",
                            e.deptname as "팀",
                            d.empname as "담당자"

                    from    CMCUSTRELS b
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMCUSTRELS''
                                            )a on b.custcode = favoritykey1
                            join CMCUSTM  c on b.custcode = c.custcode
                            join CMCUSTM  c1 on b.relcustcode = c1.custcode
                            left join CMEMPM  d on b.empcode = d.empcode
                            left join CMDEPTM  e on d.deptcode = e.deptcode

                    where   b.custcode = '''
                || p_dvalue11
                || '''
                            and (b.relcustcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            c1.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and b.orderdiv like ''%'
                || p_dvalue21
                || '''
                            and b.custmngdiv = ''A''
                    '
                   AS sqlstring,
                'order by b.relcustcode' AS SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' AS coloumn,
                'N;N;Y;Y;Y;N;N;' AS mask
           FROM DUAL;
   ELSIF (p_div = 'CREDITOR_MES')
   THEN
      OPEN IO_CURSOR FOR
         SELECT '매입처' NAME,
                   'select distinct
                        case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                        a.custcode "코드",
                        a.custname  "거래처명"

                from    CMCUSTM   a
                left join    (
                                select      favoritykey1
                                from        SYSSEEKFAVORITY
                                where       empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMCUSTM''
                                )  b on a.custcode = b.favoritykey1

                where   (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                        a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                        and a.usediv = ''Y''
                '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;' coloumn,
                'N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'ACLCM')
   THEN                                             --LC코드마스터정보 2015-03-23 홍지은
      OPEN IO_CURSOR FOR
         SELECT 'LC코드 마스터 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.lccode  "LC코드",
                            a.lcname  "LC명",
                            a.remark  "비고"
                    from    ACLCM  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''ACLCM''
                                            )  b on a.lccode = b.favoritykey1
                    where   (a.lccode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.lccode like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.lccode' SORT,
                'L-80;L-150;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ACFUNDM')
   THEN                                              --자금마스터 정보 2015-04-03 홍지은
      OPEN IO_CURSOR FOR
         SELECT '자금 마스터 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.fundcode  "자금코드",
                            a.fundname  "자금명칭"
                    from    ACFUNDM  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''ACFUNDM''
                                        )  b on a.fundcode = b.favoritykey1
                    where   (a.fundcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.fundname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.fundcode' SORT,
                'L-80;L-150;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'PDPROCESSM')
   THEN                                                                --공정마스터
      OPEN IO_CURSOR FOR
         SELECT '공정 마스터 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.processcode  "공정코드",
                            a.processname  "공정명칭"
                    from    PDPROCESSM  a
                    left join   (
                                    select      favoritykey1
                                    from        SYSSEEKFAVORITY
                                    where       empcode = '''
                || p_empcode
                || '''
                                                and seektable = ''PDPROCESSM''
                                    )  b on a.processcode = b.favoritykey1
                    where   (a.processcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.processname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                    '
                   sqlstring,
                'order by a.processcode' SORT,
                'L-80;L-150;L-200;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMCUSTMD')
   THEN                                            --대리점 마스터 조회 2015-05-08 홍지은
      OPEN IO_CURSOR FOR
         SELECT '대리점 마스터 정보' NAME,
                   'select distinct
                            case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.custcode  "코드",
                            a.custname  "거래처명",
                            rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                            a.businessno  "사업자번호",
                            rtrim(a.ceoname)  "대표자",
                            d.predeptname || '' '' || d.deptname  "팀",
                            c.empname  "담당자"

                    from    CMCUSTM  a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMCUSTM''
                                            )  b on a.custcode = b.favoritykey1
                    left join CMEMPM  c on a.empcode = c.empcode
                    left join vnDEPT  d on a.deptcode = d.deptcode
                    join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                    left join CMCUSTRELS  f on a.custcode = f.relcustcode and f.custmngdiv = ''A''

                    where   (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                            a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(TRIM(a.stopdate),'''') = IS NULL or ''N'' = '''
                || p_useyn
                || ''')
                            and (f.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))) or
                            a.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))))
                            and a.utdiv = ''92''
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'CMCUSTMRERT')
   THEN                                 --결재반품관련 거래처조회 2015-05-28 이세민 (이글벳 특화)
      OPEN IO_CURSOR FOR
         SELECT '거래처 마스터 정보' NAME,
                   'select distinct
                            case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.custcode  "코드",
                            a.custname  "거래처명",
                            rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                            a.businessno  "사업자번호",
                            rtrim(a.ceoname)  "대표자",
                            d.predeptname || '' '' || d.deptname  "팀",
                            c.empname  "담당자"

                    from CMCUSTM  a
                        left join    (
                                        select    favoritykey1
                                        from      SYSSEEKFAVORITY
                                        where     empcode = '''
                || p_empcode
                || '''
                                                  and seektable = ''CMCUSTM''
                                        )  b on a.custcode = b.favoritykey1
                    left join CMEMPM  c on a.empcode = c.empcode
                    left join vnDEPT  d on a.deptcode = d.deptcode
                    join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                    left join CMCUSTRELS  f on a.custcode = f.relcustcode and f.custmngdiv = ''A''
                    where   (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                            a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                            and a.rertyn = ''Y''
                    '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'CMITEMMRERT')
   THEN                                  --결재반품관련 제품조회 2015-05-28 이세민 (이글벳 특화)
      OPEN IO_CURSOR FOR
         SELECT '판매제품 마스터 정보' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.itemcode  "품목코드",
                            a.itemname  "품목명",
                            NVL(a.itemunit,'''')  "규격",
                            NVL(a.drugprc,0)  "기준단가"
                    from    CMITEMM   a
                            left join    (
                                            select      favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where       empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMITEMM''
                                            )  b on a.itemcode = b.favoritykey1
                    left join CMCOMMONM  c on a.unit = c.divcode and c.cmmcode = ''CM38''
                    where   (a.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                            a.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.productdiv,'' '') <> ''90'' or ''N'' = '''
                || p_useyn
                || ''')
                            and a.rertyn = ''Y''
                    '
                   sqlstring,
                'order by a.itemcode' SORT,
                'L-100;L-200;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMITEMM_P')
   THEN                                                      -- 2015-08-15:이세민
      --포장제품만 조회
      OPEN IO_CURSOR FOR
         SELECT '포장제품 마스터 정보' NAME,
                   'select        case when favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.itemcode "품목코드",
                                a.itemname  "품목명",
                                NVL(a.batchsize,0)  "제조크기",
                                NVL(a.itemunit,0)  "함량"

                    from        CMITEMM a
                                left join (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMITEMM''
                                            ) b on a.itemcode = b.favoritykey1
                    where        NVL(a.pieceyn,'' '') <> ''Y''
                                and (a.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                a.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.productdiv,'' '') <> ''90'' or ''N'' = '''
                || p_useyn
                || ''')
                                and a.itemdiv in (''04'')
                    '
                   sqlstring,
                'order by a.itemcode' SORT,
                'L-100;L-200;R-100;R-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMINCUST_P2')
   THEN
      -- 프로시져 변경. 2013-10-22 이세민
      -- 관련거래처정보를 기준으로 조회하도록 함.
      -- 관련거래처가 등록되지 않은 경우에는 조회되지 않음.
      -- 유통구분추가 2013-12-16 이세민 >>유통구분에 따른 영업영역 셋팅


      OPEN IO_CURSOR FOR
         -- 관련거래처의 담당자 기준으로 모든 거래처 찾기
         -- 관련거래처 사용여부 추가함 20140303:이세민
         SELECT '매출거래처 마스터 정보' NAME,
                   'select        distinct
                                case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                                a.custcode  "코드",
                                a.custname  "거래처명",
                                rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                                a.businessno  "사업자번호",
                                rtrim(a.ceoname)  "대표자",
                                d.predeptname || '' '' || d.deptname  "팀",
                                c.empname  "담당자",
                                a.utdiv  "유통코드",
                                g.divname  "유통",
                                a.jumun_limit "주문수량한도",
                                a.mayak "마약취급여부",
                                a.hangjung "향정취급여부"

                    from        CMCUSTM  a
                                left join    (
                                                select        favoritykey1
                                                from        SYSSEEKFAVORITY
                                                where        empcode = '''
                || p_empcode
                || '''
                                                            and seektable = ''CMCUSTM''
                                                )  b on a.custcode = b.favoritykey1
                                left join CMEMPM  c on a.empcode = c.empcode
                                left join vnDEPT  d on a.deptcode = d.deptcode
                                inner join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                                left join CMCOMMONM  g on g.cmmcode = ''CM15'' and a.utdiv = g.divcode

                    where        1 = 1
                                --                            and ((a.custcode like '''
                || p_gbcode
                || ''' || ''%'') or
                                and ((a.custcode like ''%'' || '''
                || p_gbcode
                || ''') or
                                (a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                                and (((''Y'' = '''
                || p_useyn
                || ''') and (NVL(a.stopdate,'' '') = '' '')) or
                                (''N'' = '''
                || p_useyn
                || '''))
                    '
                   sqlstring,
                'order by    a.custcode' SORT,
                'L-80;L-120;L-180;C-90;L-50;L-80;L-80;L-80;L-80;L-80;L-80;L-80;'
                   coloumn,
                'N;N;Y;Y;Y;N;N;N;N;N;N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'GMITEMM')                      --  일반자재마스터 : 20130628 - 이세민
   THEN
      OPEN IO_CURSOR FOR
         SELECT '일반자재마스터' name,
                   'select		case when favoritykey1 is null then ''N'' else ''Y'' end   "√",
                                        a.itemcode   "자재코드",
                                        a.itemname   "자재명",
                                        a.spec   "규격",
                                        b.divname   "품목구분",
                                        a.unit   "단위"

                            from		GMITEMM   a
                                        join CMCOMMONM b
                                            on b.cmmcode = ''GM09''
                                            and a.stockdiv = b.divcode
                                        left join	(
                                                        select		favoritykey1
                                                        from		SYSSEEKFAVORITY
                                                        where		empcode = '''
                || p_empcode
                || '''
                                                                    and seektable = ''GMITEMM''
                                                    ) c
                                            on a.itemcode = favoritykey1

                            where		(a.itemcode like '''
                || p_gbcode
                || ''' || ''%'' or
                                         a.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                                        and ('''
                || p_useyn
                || ''' = ''Y'' and NVL(a.useyn,'''') = ''Y'' or
                                             '''
                || p_useyn
                || ''' = ''N'')
                                        --and (a.stockdiv like '''
                || p_gbcode1
                || ''' or a.itemcode like '''
                || p_gbcode1
                || ''')
                                        '
                   sqlstring,
                'order by	a.itemcode' sort,
                'L-100;L-200;L-150;L-120;L-80;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'ORDITEMMSU')
   THEN
      OPEN IO_CURSOR FOR
         SELECT '판매제품 마스터 정보' name,
                   'select		case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                                    b.itemcode 품목코드,
                                    b.itemname 품목명,
                                    NVL(b.itemunit,'''') 규격,
                                    NVL(b.drugprc,0) 기준단가
                        from		CMITEMM b
                                    left join	(
                                                    select		favoritykey1
                                                    from		SYSSEEKFAVORITY
                                                    where		empcode = '''
                || p_empcode
                || '''
                                                                and seektable = ''CMITEMM''
                                                ) a
                                                on b.itemcode = favoritykey1
                                    left join CMCOMMONM c
                                                on b.itempart = c.divcode
                                                and c.cmmcode = ''CM41''
                        where		b.itemcode = b.itemcode
                                    and NVL(b.pieceyn,'' '') <> ''Y''
                                    and ((b.itemcode like '''
                || p_gbcode
                || ''' || ''%'') or
                                            (b.itemname like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                                    and (((''Y'' = '''
                || p_useyn
                || ''') and (NVL(b.productdiv,'' '') <> ''90'')) or
                                            (''N'' = '''
                || p_useyn
                || '''))
                                    and ((itemdiv in (''01'')) or (itemdiv in (''04'') and filter1 = ''M''))
                        '
                   sqlstring,
                'order by	b.itemcode' sort,
                'L-100;L-200;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (p_div = 'CMCUSTMSU')
   THEN
      OPEN IO_CURSOR FOR
         SELECT '매입거래처 정보' name,
                   'select		case when b.favoritykey1 is null then ''N'' else ''Y'' end "√",
                                    a.custcode 코드,
                                    a.custname 거래처명,
                                    rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,'''')) 주소,
                                    a.businessno 사업자번호,
                                    rtrim(a.ceoname) 대표자,
                                    d.predeptname || '' '' || d.deptname 팀,
                                    c.empname 담당자
                        from		CMCUSTM  a
                                    left join	(
                                                    select		favoritykey1
                                                    from		SYSSEEKFAVORITY
                                                    where		empcode = '''
                || p_empcode
                || '''
                                                                and seektable = ''CMCUSTM''
                                                ) b
                                                on a.custcode = b.favoritykey1
                                    left join CMEMPM c
                                                on a.empcode = c.empcode
                                    left join vnDEPT d
                                                on a.deptcode = d.deptcode
                        where		a.custcode = custcode
                                    and a.custdiv in (''1'')
                                    and ((a.custcode like '''
                || p_gbcode
                || ''' || ''%'') or
                                            (a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'') or
                                             (replace(a.businessno,''-'','''') like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                                    and (((''Y'' = '''
                || p_useyn
                || ''') and (a.stopdate IS NULL)) or
                                            (''N'' = '''
                || p_useyn
                || '''))
                        '
                   sqlstring,
                'order by	a.custcode' sort,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
           FROM DUAL;
   ELSIF (UPPER (p_div) = 'CUSTOMERMASTER')                 --  2012-09-03 권도영
   THEN
      OPEN IO_CURSOR FOR
         SELECT '매입거래처 정보' name,
                   'select		case when b.favoritykey1 is null then ''N'' else ''Y'' end "√",
                                    a.custcode 코드,
                                    a.custname 거래처명,
                                    rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,'''')) 주소,
                                    a.businessno 사업자번호,
                                    rtrim(a.ceoname) 대표자,
                                    d.predeptname || '' '' || d.deptname 팀,
                                    c.empname 담당자
                        from		CMCUSTM  a
                                    left join	(
                                                    select		favoritykey1
                                                    from		SYSSEEKFAVORITY
                                                    where		empcode = '''
                || p_empcode
                || '''
                                                                and seektable = ''CMCUSTM''
                                                ) b
                                                on a.custcode = b.favoritykey1
                                    left join CMEMPM c
                                                on a.empcode = c.empcode
                                    left join vnDEPT d
                                                on a.deptcode = d.deptcode
                        where		1=1 -- a.custcode = custcode
                                    and a.custdiv in (''1'', ''3'', ''4'')
                                    and ((a.custcode like '''
                || p_gbcode
                || ''' || ''%'') or
                                            (a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'') or
                                             (replace(a.businessno,''-'','''') like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                                    and (((''Y'' = '''
                || p_useyn
                || ''') and (a.stopdate IS NULL)) or
                                            (''N'' = '''
                || p_useyn
                || '''))
                        '
                   sqlstring,
                'order by	a.custcode' sort,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'SLCOSTM')                                       --수출비용마스터정보
   THEN
      OPEN IO_CURSOR FOR
         SELECT '수출비용 마스터 정보' name,
                   'select		case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                                    a.costcode 비용코드,
                                    a.costname 비용명,
                                    c.divname 분배기준
                        from		SLCOSTM a
                                    left join	(
                                                    select		favoritykey1
                                                    from		SYSSEEKFAVORITY
                                                    where		empcode = '''
                || p_empcode
                || '''
                                                                and seektable = ''SLCOSTM''
                                                ) b
                                                on a.costcode = favoritykey1
                                    left join CMCOMMONM c
                                        on c.cmmcode = ''TR03''
                                        and a.costdivisioncode = c.divcode 
                        where		(a.costcode like '''
                || p_gbcode
                || ''' || ''%'') or
                                    (a.costname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                        '
                   sqlstring,
                'order by	a.costcode' sort,
                'L-100;L-200;L-100;L-100;' coloumn
           FROM DUAL;
   ELSIF (UPPER (p_div) = 'CUSTOMERMASTER3')                --  2012-09-03 권도영
   THEN
      OPEN IO_CURSOR FOR
         SELECT '오퍼처 정보' name,
                   'select		case when b.favoritykey1 is null then ''N'' else ''Y'' end "√",
							a.custcode 코드,
							a.custname 거래처명,
							rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,'''')) 주소,
							a.businessno 사업자번호,
							rtrim(a.ceoname) 대표자,
							d.predeptname || '' '' || d.deptname 팀,
							c.empname 담당자
				from		CMCUSTM  a
							left join	(
											select		favoritykey1
											from		SYSSEEKFAVORITY
											where		empcode = '''
                || p_empcode
                || '''
														and seektable = ''CMCUSTM''
										) b
										on a.custcode = b.favoritykey1
							left join CMEMPM c
										on a.empcode = c.empcode
							left join vnDEPT d
										on a.deptcode = d.deptcode
				where		a.custcode = custcode
							and a.custdiv in (''7'')
							and ((a.custcode like '''
                || p_gbcode
                || ''' || ''%'') or
									(a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'') or
									 (replace(a.businessno,''-'','''') like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
							and (((''Y'' = '''
                || p_useyn
                || ''') and (a.stopdate IS NULL)) or
									(''N'' = '''
                || p_useyn
                || '''))
				'
                   sqlstring,
                'order by	a.custcode' sort,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
           FROM DUAL;
   ELSIF (p_div = 'CostMaster')
   THEN
      p_seektitle := '비용코드 정보';
      p_table := 'vnCostMaster';
      p_tablekey := ' costcode ';
      p_tablecoloums :=
         'costcode as 비용코드, costname as 비용명, costgroup as 비용그룹구분코드, costgroupname as 비용그룹구분, costdivisioncode as 분배기준코드, costdivisionname as 분배기준, dracccode as 차변계정, cracccode as 대변계정';
      p_coloumsetting := 'L-50;L-50;L-50;L-50;L-5;L-50;L-100;L-100;';

      OPEN IO_CURSOR FOR
         SELECT p_seektitle AS name,
                fnSeek (p_empcode,
                        p_table,
                        p_tablekey,
                        p_tablecoloums,
                        p_coloumsetting)
                   AS sqlstring,
                ' order by ' || p_tablekey || '' AS sort,
                p_coloumsetting AS coloumn
           FROM DUAL;
   ELSIF (p_div = 'HIRAM')
   THEN
       OPEN IO_CURSOR FOR
            SELECT 'Hira코드 정보' name,
                   'select  case when b.favoritykey1 is null then ''N'' else ''Y'' end "√",
                            a.hiracode HIRA코드,
                            a.hiraname HIRA명,
                            a.hiraaddr 주소
                    from    CMHIRAM  a
                            left join    (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                                        and seektable = ''CMHIRAM''
                                        ) b
                                        on a.hiracode = b.favoritykey1
                     where   ((a.hiracode like '''
                || p_gbcode
                || ''' || ''%'') or
                                    (a.hiraname like ''%'' || '''
                || p_gbcode
                || ''' || ''%''))
                '
                   sqlstring,
                'order by    a.hiracode' sort,
                'L-100;L-200;L-300;' coloumn,
                'N;N;Y;' mask
           FROM DUAL;
--      p_seektitle := 'Hira코드 정보';
--      p_table := 'CMHIRAM';
--      p_tablekey := ' hiracode ';
--      p_tablecoloums := 'hiracode as HIRA코드, hiraname as HIRA명';
--      p_coloumsetting := 'L-50;L-50;';
--
--      OPEN IO_CURSOR FOR
--         SELECT p_seektitle AS name,
--                fnSeek (p_empcode,
--                        p_table,
--                        p_tablekey,
--                        p_tablecoloums,
--                        p_coloumsetting)
--                   AS sqlstring,
--                ' order by ' || p_tablekey || '' AS sort,
--                p_coloumsetting AS coloumn
--           FROM DUAL;
   ELSIF (p_div = 'CMINCUSTV')
   THEN
      --매출거래처마스터조회 가상계좌 조회

      OPEN IO_CURSOR FOR
         SELECT '매출거래처 마스터 정보' NAME,
                   'select        distinct
                            case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.custcode  "코드",
                            a.custname  "거래처명",
                            rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                            a.virtualaccount  "가상계좌번호",
                            rtrim(a.ceoname)  "대표자",
                            d.predeptname || '' '' || d.deptname  "팀",
                            c.empname  "담당자"

                from        CMCUSTM  a
                            left join    (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMCUSTM''
                                            )  b on a.custcode = b.favoritykey1
                            left join CMEMPM  c on a.empcode = c.empcode
                            left join vnDEPT  d on a.deptcode = d.deptcode
                            join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                            left join CMCUSTRELS  f on a.custcode = f.relcustcode and f.custmngdiv = ''A''

                where        (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                            a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.stopdate,'' '') = '' '' or ''N'' = '''
                || p_useyn
                || ''')
                            and (f.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))) or
                            a.empcode in (select empcode_val from TABLE(fnsalpower_emplist('''
                || p_salpower
                || '''))))
                '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   ELSIF (p_div = 'CMINCUSTVEND')
   THEN
      --사용 중지된 거래처 마스터 전부 조회

      OPEN IO_CURSOR FOR
         SELECT '매출거래처 마스터 정보' NAME,
                   'select        distinct
                            case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.custcode  "코드",
                            a.custname  "거래처명",
                            rtrim(NVL(a.addr1,'''')) || '' '' || rtrim(NVL(a.addr2,''''))  "주소",
                            a.virtualaccount  "가상계좌번호",
                            rtrim(a.ceoname)  "대표자",
                            d.predeptname || '' '' || d.deptname  "팀",
                            c.empname  "담당자"

                from        CMCUSTM  a
                            left join    (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMCUSTM''
                                            )  b on a.custcode = b.favoritykey1
                            left join CMEMPM  c on a.empcode = c.empcode
                            left join vnDEPT  d on a.deptcode = d.deptcode
                            join CMCOMMONM  e on a.custdiv = e.divcode and e.cmmcode = ''CM11'' and e.filter1 = ''Y''
                            left join CMCUSTRELS  f on a.custcode = f.relcustcode and f.custmngdiv = ''A''

                where        (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                            a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL
         where  p_gbcode is not null;
   
   ELSIF (p_div = 'ManufactureM')
   THEN
      OPEN IO_CURSOR FOR
      SELECT '거래처정보' NAME,
               'select      distinct
                            case when b.favoritykey1 is null then ''N'' else ''Y'' end  "√",
                            a.custcode  "코드",
                            a.custname  "거래처명",
                            a.custename "거래처명 영문",
                            a.custcondition  "업태",
                            a.custitem  "업종",
                            a.ceoname  "대표자명",
                            a.businessno  "사업자등록번호"

                from        CMCUSTM  a
                            left join    (
                                            select        favoritykey1
                                            from        SYSSEEKFAVORITY
                                            where        empcode = '''
                || p_empcode
                || '''
                                            and seektable = ''CMCUSTM''
                                            )  b on a.custcode = b.favoritykey1

                where        (a.custcode like ''%'' || '''
                || p_gbcode
                || ''' or
                            a.custname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                '
                   sqlstring,
                'order by a.custcode' SORT,
                'L-70;L-100;L-200;C-100;L-100;L-80;L-80;' coloumn,
                'N;N;Y;Y;Y;N;N;' mask
         FROM   DUAL;
--      p_seektitle := '거래처정보';
--      p_table := 'CMCUSTM';
--      p_tablekey := LPAD (' ', 1, ' ') || 'custcode' || LPAD (' ', 1, ' ');
--      p_tablecoloums :=
--         'custcode as 거래처코드, custname as 거래처, custename    as 거래처명_영문, custcondition as 업태, custitem as 업종, ceoname as 대표자명, businessno as 사업자등록번호';
--      p_coloumsetting := 'L-100;L-100;L-100;L-100;L-100;L-100;L-100;L-100;';
--
--      OPEN IO_CURSOR FOR
--         SELECT p_seektitle NAME,
--                fnSeek (p_empcode,
--                        p_table,
--                        p_tablekey,
--                        p_tablecoloums,
--                        p_coloumsetting /*+ ' and custdiv = ''03'' '*/
--                                       )
--                   sqlstring,
--                ' order by ' || p_tablekey || ' ' SORT,
--                p_coloumsetting coloumn
--           FROM DUAL;
   ELSIF (p_div = 'CMCOMMONM')
   THEN                                                          
      OPEN IO_CURSOR FOR
         SELECT '세부구분' NAME,
                   'select case when favoritykey1 is null then ''N'' else ''Y'' end "√",
                            a.divcode "code",
                            a.divname "name"
                    from    CMCOMMONM a
                            left join    (  select  favoritykey1
                                            from    SYSSEEKFAVORITY
                                            where   empcode = '''
                || p_empcode
                || '''
                                                    and seektable = ''CMCOMMONM'' ) b on a.divcode = favoritykey1
                    where   a.cmmcode = ''CM57''
                            and (a.divcode like '''
                || p_gbcode
                || ''' || ''%'' or a.divname like ''%'' || '''
                || p_gbcode
                || ''' || ''%'')
                            and (''Y'' = '''
                || p_useyn
                || ''' and NVL(a.usediv,'' '') = ''Y'' or ''N'' = '''
                || p_useyn
                || ''')
                    '
                   sqlstring,
                'order by a.divcode' SORT,
                'L-100;L-200;L-200;' coloumn
           FROM DUAL;
                    
   END IF;

   IF (IO_CURSOR IS NULL)
   THEN
      OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
   END IF;
END;
/
