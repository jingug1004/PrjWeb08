CREATE PROCEDURE        spACacc0144R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0144
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-07-11
	-- 수정일자       :   노영래
	-- E-mail       :   0rae0926@gmail.com
	-- 수정일자       :   2016-12-14
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 반제처리원장 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_slipdate		IN	   VARCHAR2 DEFAULT '',
	p_acccode		IN	   VARCHAR2 DEFAULT '',
	p_repaydiv		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S') THEN

        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0144R_ACORDD';

		INSERT INTO VGT.TT_ACACC0144R_ACORDD
			(SELECT   a.slipinno,
					  a.slipinseq,
					  MAX(a.acccode) acccode,
					  MAX(b.accname) accname,
					  MAX(b.dcdiv) dcdiv,
					  MAX(a.remark1) remark,
					  MAX(CASE WHEN b.dcdiv = '1' THEN a.debamt - a.creamt ELSE a.creamt - a.debamt END) slipamt,
					  SUM(NVL(c.repayamt, 0) + NVL(D.repayamt, 0)) repayamt,
					  MIN(NVL(c.rpyslipinno, D.crtslipinno)) minslipinno,
					  MAX(NVL(c.rpyslipinno, D.crtslipinno)) maxslipinno

			 FROM	  ACORDD a
					  JOIN ACACCM b ON a.acccode = b.acccode
							           AND b.returnyn = 'Y'
					  LEFT JOIN ACORDRPYP c ON a.compcode = c.compcode
                                                 AND a.slipinno = c.slipinno
                                                 AND a.slipinseq = c.slipinseq
                                                 AND c.rpyslipinno <= REPLACE(p_slipdate, '-', '') || 'ZZ'
					  LEFT JOIN ACORDRPYD D ON a.compcode = D.compcode
                                                 AND a.slipinno = D.slipinno
                                                 AND a.slipinseq = D.slipinseq
                                                 AND D.repaydate <= p_slipdate
                                                 AND D.crtslipinno IS NOT NULL
			 WHERE	  a.compcode = p_compcode
					  AND a.plantcode LIKE p_plantcode
					  AND a.acccode LIKE p_acccode || '%'
					  AND a.slipdate BETWEEN '00000000' AND p_slipdate
					  AND (a.dcdiv IN ('1', '4') AND b.dcdiv = '1' OR
                           a.dcdiv IN ('2', '3') AND b.dcdiv = '2')
					  AND (a.debamt <> 0 OR a.creamt <> 0)

			 GROUP BY a.slipinno, a.slipinseq);

		DELETE FROM VGT.TT_ACACC0144R_ACORDD
		WHERE		p_repaydiv = '0'
					AND slipamt - repayamt = 0 OR p_repaydiv = '1'
					AND repayamt = 0;

		OPEN IO_CURSOR FOR
			SELECT	 c.slipdate,
					 c.slipnum,
					 c.slipindate,
					 c.slipinnum,
					 a.acccode,
					 a.accname,
					 a.remark,
					 a.slipamt,
					 a.repayamt,
					 a.slipamt - a.repayamt restamt,
					 a.minslipinno,
					 CASE WHEN a.minslipinno = a.maxslipinno THEN '' ELSE a.maxslipinno END maxslipinno,
					 b.mngcludec1,
					 b.mngcludec2,
					 b.mngcludec3
			FROM	 VGT.TT_ACACC0144R_ACORDD a
					 LEFT JOIN (SELECT	  slipinno,
                                          slipinseq,
                                          MAX(CASE WHEN seq = 1 THEN mngcludec ELSE '' END) mngcludec1,
                                          MAX(CASE WHEN seq = 2 THEN mngcludec ELSE '' END) mngcludec2,
                                          MAX(CASE WHEN seq = 3 THEN mngcludec ELSE '' END) mngcludec3
								FROM	 (SELECT a.slipinno,
                                                 a.slipinseq, ROW_NUMBER() OVER (PARTITION BY a.slipinno, a.slipinseq ORDER BY b.seq) seq,
                                                 NVL(b.mngcluval, '') || ' : ' || NVL(b.mngcludec, '') mngcludec
										  FROM	 VGT.TT_ACACC0144R_ACORDD a
												 JOIN ACORDS b ON b.compcode = p_compcode
                                                                    AND a.slipinno = b.slipinno
                                                                    AND a.slipinseq = b.slipinseq
												 JOIN ACACCMNGM c ON a.acccode = c.acccode
                                                                        AND a.dcdiv = c.dcdiv
                                                                        AND b.mngclucode = c.mngclucode
                                                                        AND c.remainyn = 'Y'
												 LEFT JOIN ACMNGM D ON b.mngclucode = D.mngclucode) a
								GROUP BY slipinno, slipinseq) b ON a.slipinno = b.slipinno
							                                        AND a.slipinseq = b.slipinseq
					 LEFT JOIN ACORDM c ON c.compcode = p_compcode
							                AND a.slipinno = c.slipinno

            ORDER BY a.acccode, b.mngcludec1, b.mngcludec2, b.mngcludec3, c.slipdate, c.slipnum, a.slipinseq;


	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
