CREATE VIEW V_SAWON_ID_MAP AS SELECT A.EMP_NO,
          A.EMP_KO_NM,
          B.SAWON_ID,
          C.UNO
     FROM hanahr.HR_HC_EMPBAS_0  A
          LEFT OUTER JOIN SALE0007 B
             ON A.EMP_NO = B.INSA_SAWON_ID
          LEFT OUTER JOIN hanagw.TCMUSR C
             ON A.EMP_NO = C.LOIN_USID

/
