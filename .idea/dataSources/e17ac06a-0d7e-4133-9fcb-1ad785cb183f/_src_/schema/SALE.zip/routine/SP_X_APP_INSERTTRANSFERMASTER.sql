CREATE PROCEDURE      SP_X_APP_INSERTTRANSFERMASTER
(
    in_REQ_DATE  IN VARCHAR2,
    in_GUMAE_NO  IN VARCHAR2,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_INSERTTRANSFERMASTER
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  ERP 주문 마스터 이관 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	INSERT INTO SALE.SALE0203(GUMAE_NO, GUMAE_GB, YMD, SAWON_ID, CUST_ID, RSAWON_ID, RCUST_ID, GYULJAE_GB, TAX_TYPE, 
							DECIMAL_PROC, CHAMJO_NM, CHAMJO_RANK, AMT_SUM, VAT_SUM, BIGO, BALJU_YN, CHULGO_YN, NAPGI_YMD, 
							NAPGI_TYPE, CONVEY_TYPE, UPDATE_YN, GUBUN, ACCEPT_YN, INPUT_ID, INPUT_YMD, GUMAE_NOT, YMDT,SLIP_GB)
			SELECT GUMAE_NOT, GUMAE_GB, YMDT, SAWON_ID, CUST_ID, RSAWON_ID, RCUST_ID, GYULJAE_GB, TAX_TYPE, 
					 DECIMAL_PROC, CHAMJO_NM, CHAMJO_RANK, AMT_SUM, VAT_SUM, BIGO, BALJU_YN, CHULGO_YN, NAPGI_YMD, 
					 NAPGI_TYPE, CONVEY_TYPE, UPDATE_YN, GUBUN, ACCEPT_YN, INPUT_ID, INPUT_YMD, GUMAE_NOT, YMDT,SLIP_GB
			  FROM SALE_ON.SALE0203 
			 WHERE YMD = in_REQ_DATE AND GUMAE_NO = in_GUMAE_NO;

    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 INSERT ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 저장';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;
END ;
/
