CREATE PROCEDURE      SP_X_COMMON_COMMONEMPINFO
(
    in_GS_EMPCODE IN VARCHAR2,
    out_RESULT    OUT TYPES.CURSOR_TYPE,
    out_CODE      OUT NUMBER,
    out_MSG       OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_COMMON_COMMONEMPINFO
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명   : 부서코드와 PDA 권한 조회프로시저이다.
-- ---------------------------------------------------------------
BEGIN 

   OPEN out_RESULT FOR	
        SELECT DEPT_CD dept_cd, PDA_AUTH pda_auth
		  FROM SALE.SALE0007
		 WHERE SAWON_ID = in_GS_EMPCODE;
	
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        
END ;
/
