CREATE PROCEDURE      SP_X_MYPL_INSERTPLITEM
(
    in_ITEM_ID            IN VARCHAR2,
    in_ITEM_NM            IN VARCHAR2,
    in_ITEM_EFFECT        IN VARCHAR2,
    in_ITEM_USE_DOES      IN VARCHAR2,
    in_ITEM_KIND1         IN VARCHAR2,
    in_ITEM_KD_NO         IN VARCHAR2,
    in_ITEM_MAIN_SOURCE   IN VARCHAR2,
    in_ITEM_POjANG_UNIT   IN VARCHAR2,
    in_ITEM_OUT_DANGA     IN VARCHAR2,
    in_ITEM_KIND2         IN VARCHAR2,
    in_FONTSIZE_EFFECT    IN VARCHAR2,
    in_FONTSIZE_USE_DOES  IN VARCHAR2,
    in_USE_YN             IN VARCHAR2,
    out_CODE              OUT NUMBER,
    out_MSG               OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_MYPL_INSERTPLITEM
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : P/L용 제품 등록  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	INSERT INTO SALE.SFA_OFFICE_ITEMDOC (
		   ITEM_CODE, ITEM_NAME, ITEM_EFFECT, 
		   ITEM_USE_DOES, ITEM_KIND1, 
		   ITEM_KD_NO, ITEM_MAIN_SOURCE, ITEM_POJANG_UNIT, 
		   ITEM_OUT_DANGA, ITEM_KIND2, FONTSIZE_EFFECT, 
		   FONTSIZE_USE_DOES, USE_YN) 
		VALUES ( in_ITEM_ID
		       , in_ITEM_NM
	           , in_ITEM_EFFECT
	           , in_ITEM_USE_DOES
		       , in_ITEM_KIND1
		       , in_ITEM_KD_NO
		       , in_ITEM_MAIN_SOURCE
		       , in_ITEM_POjANG_UNIT
		       , in_ITEM_OUT_DANGA
		       , in_ITEM_KIND2
		       , in_FONTSIZE_EFFECT
		       , in_FONTSIZE_USE_DOES
		       , in_USE_YN
		    );

    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 INSERT ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 저장';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;

END ;
/
