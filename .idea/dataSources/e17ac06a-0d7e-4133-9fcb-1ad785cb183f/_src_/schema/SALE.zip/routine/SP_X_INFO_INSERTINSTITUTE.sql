CREATE PROCEDURE      SP_X_INFO_INSERTINSTITUTE
(
    in_CUST_ID      IN VARCHAR2,
    in_CUSTOMER_ID  IN VARCHAR2,
    in_SEQ          IN VARCHAR2,
    in_HAKHEO_NM    IN VARCHAR2,
    in_DATEF        IN VARCHAR2,
    in_DATET        IN VARCHAR2,
    in_JIWI         IN VARCHAR2,
    in_GWANSIMDO    IN VARCHAR2,
    in_GITA         IN VARCHAR2,
    out_CODE       OUT NUMBER,
    out_MSG        OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INFO_INSERTINSTITUTE
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :   소속학회 저장 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
  INSERT INTO SALE.CRM_HAKHEO (CUST_ID, CUSTOMER_ID, SEQ, HAKHEO_NM, DATEF, DATET, JIWI, GWANSIMDO, GITA) 
		VALUES (in_CUST_ID      
               ,in_CUSTOMER_ID  
               ,in_SEQ          
               ,in_HAKHEO_NM    
               ,in_DATEF        
               ,in_DATET        
               ,in_JIWI         
               ,in_GWANSIMDO    
               ,in_GITA      
				);
				
    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 INSERT ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 저장';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        
END ;
/
