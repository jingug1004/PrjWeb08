CREATE PROCEDURE      SP_SFA_ITEM_05
(
    in_ITEM_ID           IN  VARCHAR2,    -- 제품코드
    in_ITEM_NM           IN  VARCHAR2,    -- 제품명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 재고/품절현황
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
        
    SELECT COUNT(*) 
      INTO v_num
      FROM SALE0305 A, SALE0004 B
     WHERE A.ITEM_ID = B.ITEM_ID 
       AND TO_CHAR(A.YMD, 'YYYYMM')     = TO_CHAR(SYSDATE, 'YYYYMM')
       AND A.ITEM_ID like NVL(in_ITEM_ID,'%') 
       AND B.ITEM_NM like '%'||NVL(in_ITEM_NM,'%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT A.STORE_LOC                                AS out_STORE_LOC,   -- 창고
               TO_CHAR(A.YMD, 'YYYYMMDD')                 AS out_YMD,         -- 재고월
               A.ITEM_ID                                  AS out_ITEM_ID,     -- 품목코드
               B.ITEM_NM                                  AS out_ITEM_NM,     -- 품목명
               B.STANDARD                                 AS out_STANDARD,    -- 규격
               NVL(A.BEFORE_QTY,0)                        AS out_BEFORE_QTY,  -- 이월수량
               A.BEFORE_AMT                               AS out_BEFORE_AMT,  -- 이월금액
               NVL(A.IPGO_QTY,0)                          AS out_IPGO_QTY,    -- 입고수량
               A.IPGO_AMT                                 AS out_IPGO_AMT,    -- 입고금액
               NVL(A.CHULGO_QTY,0)                        AS out_CHULGO_QTY,  -- 출고수량
               A.CHULGO_AMT                               AS out_CHULGO_AMT,  -- 출고금액
               NVL(A.BEFORE_QTY,0) + NVL(A.IPGO_QTY,0) - NVL(A.CHULGO_QTY,0)  AS out_JAEGO_QTY,   -- 재고수량
               NVL(A.BEFORE_AMT,0) + NVL(A.IPGO_AMT,0) - NVL(A.CHULGO_AMT,0)  AS out_JAEGO_AMT,   -- 재고금액
               NVL(A.BEFORE_QTYS,0)                       AS out_BEFORE_QTYS, -- 주문용이월수량 
               NVL(A.IPGO_QTYS,0)                         AS out_IPGO_QTYS,   -- 주문용입고수량
               NVL(A.CHULGO_QTYS,0)                       AS out_CHULGO_QTYS, -- 주문용출고수량
               NVL(A.CHULGO_QTYST,0)                      AS out_CHULGO_QTYST,   -- 온라인주문용출고수량
               NVL(A.BANPUM_QTYS,0)                       AS out_BANPUM_QTYS,   -- 주문용반품수량
               NVL(A.BEFORE_QTYS,0) + NVL(A.IPGO_QTYS,0) - NVL(A.CHULGO_QTYS,0)  - NVL(A.CHULGO_QTYST,0) + NVL(A.BANPUM_QTYS,0)  AS out_JAEGO_QTYS, -- 주문용재고수량
               (SELECT SUM(NVL(IPGO_QTYS,0) - NVL(CHULGO_QTYS,0) - NVL(CHULGO_QTYST,0) + NVL(BANPUM_QTYS,0)) 
                  FROM SALE0305_1 WHERE STORE_LOC = A.STORE_LOC AND ITEM_ID = A.ITEM_ID )                                        AS out_PROD_QTYS,  -- ?? 제품 재고수량??
               (SELECT CODE1_NM FROM SALE0001 WHERE CODE_GB = '0050' AND CODE1 = B.ITEM_GB1)                                     AS out_ITEM_GB1_NM,  -- 제품분류명
               NVL(B.CHUL_YN,'N')                         AS out_CHUL_YN,  -- 출하중지 여부
               DECODE(NVL(B.CHUL_YN, 'N'), 'Y', '출하중지', '출하')      AS out_CHUL_NM  -- 출하중지여부명
          FROM SALE0305 A, SALE0004 B
         WHERE A.ITEM_ID = B.ITEM_ID 
           AND TO_CHAR(A.YMD, 'YYYYMM')     = TO_CHAR(SYSDATE, 'YYYYMM')
           AND A.ITEM_ID LIKE NVL(IN_ITEM_ID,'%') 
           AND B.ITEM_NM LIKE '%'||NVL(IN_ITEM_NM,'%')||'%';
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
