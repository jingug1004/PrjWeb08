CREATE PROCEDURE      SP_X_COMMON_EMPGRIDTOTAL
(
    in_KEYWORD     IN VARCHAR2,
    in_ASSGNCODE   IN VARCHAR2,
    in_EMP_CD      IN VARCHAR2,
    in_DEPT_CD     IN VARCHAR2,
    out_TOTAL_CNT OUT VARCHAR2,
    out_CODE      OUT NUMBER,
    out_MSG       OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_COMMON_EMPGRIDTOTAL
-- 작 성 자      : 유명배
-- 작성일자      : 2017-12-01
-- 수 정 자      : 
-- 수정일자      : 2017-12-01
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 사원목록 총수 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    SELECT count(*) INTO out_TOTAL_CNT
		  FROM SALE.SALE0007 A
		 WHERE A.SAWON_ID||A.SAWON_NM LIKE '%'||in_KEYWORD||'%'
		   AND (in_ASSGNCODE IN ('27020', '27025')
		        AND A.DEPT_CD IN ( 
                                        select sale_dept_cd 
                                          from hr_co_depart_0 
                                          connect by prior dept_cd = up_dept_cd
                                          start with dept_cd = (    select dept_cd 
                                                                      from hr_co_depart_0 
                                                                     where level = 2
                                                                      connect by  dept_cd = prior up_dept_cd
                                                                      start with dept_cd = (select dept_cd from hr_hc_empbas_0 
                                                                                             where emp_no in (select insa_sawon_id from sale0007 where sawon_id = in_EMP_CD) 
                                                                                            )
                                                               )
                                    ))
            AND (in_ASSGNCODE IN ('27040', '27050') AND A.SAWON_ID = in_EMP_CD)
		    AND A.DEPT_CD = in_DEPT_CD;
    
	out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
