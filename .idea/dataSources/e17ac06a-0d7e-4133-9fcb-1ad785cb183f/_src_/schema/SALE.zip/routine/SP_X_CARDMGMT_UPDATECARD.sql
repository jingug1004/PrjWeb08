CREATE PROCEDURE      SP_X_CARDMGMT_UPDATECARD
(
    in_TAX_GB               IN VARCHAR2,
    in_GONGJAE_YN           IN VARCHAR2,
    in_USE_DETAIL           IN VARCHAR2,
    in_GAEJUNG_CD           IN VARCHAR2,
    in_TEAMJANG_CONF_YN     IN VARCHAR2,
    in_JUKYO                IN VARCHAR2,
    in_TEAMJANG_CONF_SABUN  IN VARCHAR2,
    in_USE_DT               IN VARCHAR2,
    in_USE_TM               IN VARCHAR2,
    in_CARD_NO              IN VARCHAR2,
    in_CARD_OK_NO           IN VARCHAR2,
    out_CODE               OUT NUMBER,
    out_MSG                OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_CARDMGMT_UPDATECARD
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 법인카드관리 BK 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
		UPDATE sale.SALE0601_IBK
		   SET TAX_GB = in_TAX_GB, GONGJAE_YN = in_GONGJAE_YN,
		   	   USE_DETAIL = in_USE_DETAIL, GAEJUNG_CD = in_GAEJUNG_CD,
		   	   TEAMJANG_CONF_YN = in_TEAMJANG_CONF_YN, JUKYO = in_JUKYO,
		   	   TEAMJANG_CONF_SABUN = in_TEAMJANG_CONF_SABUN
		 WHERE USE_DT = in_USE_DT
		   AND USE_TM = in_USE_TM
		   AND CARD_NO = in_CARD_NO 
		   AND CARD_OK_NO = in_CARD_OK_NO
		   AND USE_GUBUN = '03';

    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 UPDATE ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 수정';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 
        ROLLBACK;
END ;
/
