CREATE FUNCTION f_acc_test
		(i_bill_usage  IN    VARCHAR2,         -- 어음구분(1.받을어음, 2.지급어음)
                 i_end_date    IN    VARCHAR2,         -- 회계마감일자
                 i_close_date  IN    VARCHAR2,         -- 어음만기일
                 i_basic_date  IN    VARCHAR2 )        -- 기준일자
RETURN VARCHAR2 AS
v_return   VARCHAR2(9);
BEGIN
  IF i_bill_usage = '2' THEN
     IF i_end_date = i_close_date THEN
 	v_return := '정  상';
     ELSIF i_close_date IS NULL OR i_close_date = '' THEN
	v_return := '미도래';
     END IF;
  ELSIF i_end_date = i_close_date THEN
	IF i_basic_date >= i_close_date THEN
	   v_return := '정  상';
	ELSE
 	   v_return := '미도래';
	END IF;
  ELSIF i_close_date IS NULL OR i_close_date = '' THEN
	IF i_end_date < i_basic_date THEN
	   v_return := '부  도';
	ELSE
	   v_return := '미도래';
	END IF;
  ELSIF i_end_date > i_close_date THEN
	IF i_end_date <= i_basic_date THEN
	   v_return := '배／정';
	ELSE
	   v_return := '배  서';
	END IF;
  END IF;
  RETURN(v_return);
END;


/
