CREATE PROCEDURE      SP_SFA_HELP
(
    in_GUBUN           IN  VARCHAR2,     
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 도움말 
 호출프로그램 : OnlineHelp       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_SYS_PGMHELP  
     WHERE PGM_ID = in_GUBUN 
   ;
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT '['||lst.PGM_NM||']  '||hlp.HELP1                 AS out_HELP
          FROM SFA_SYS_PGMLIST   lst 
                   ,SFA_SYS_PGMHELP hlp            
     WHERE hlp.PGM_ID = in_GUBUN 
          AND lst.PGM_ID = hlp.PGM_ID;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
