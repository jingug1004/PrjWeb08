CREATE PROCEDURE      SP_X_INFO_DELETECUSTOMERINFO
(
    in_CUST_ID      IN VARCHAR2,
    in_CUSTOMER_ID  IN VARCHAR2,
    out_CODE       OUT NUMBER,
    out_MSG        OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INFO_DELETECUSTOMERINFO
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 분기 삭제 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	DELETE FROM SALE.CRM_MASTER 
	      WHERE CUST_ID = in_CUST_ID 
	        AND CUSTOMER_ID = in_CUSTOMER_ID;

    out_CODE := 0;
    out_MSG := '데이터 삭제';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
