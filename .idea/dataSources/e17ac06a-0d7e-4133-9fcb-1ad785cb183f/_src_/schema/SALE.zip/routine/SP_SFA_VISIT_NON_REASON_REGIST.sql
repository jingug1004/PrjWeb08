CREATE PROCEDURE      SP_SFA_VISIT_NON_REASON_REGIST 
(
    in_SAWON_ID          IN  VARCHAR2,   
    in_CDT               IN  VARCHAR2,    
    out_CODE             out NUMBER,
    out_MSG              out VARCHAR2,
    out_COUNT            out NUMBER,
    out_RESULT           out TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문현황
 호출프로그램 : 
 수정내역
  1.2014.04.08 KTA 위반주문 팀장승인상태를 화면에 보여주도록 수정함.    
  2.2014.12.12 KTA 수정버튼시 주문등록화면으로 넘어가면서 가지고갈 회전일 추가.  
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    SELECT COUNT(*)
      INTO v_num
    FROM CO_LUNARSOLARCAL A
      ,(SELECT SALES_PLAN_NO,COUNT(*) PLAN_CNT,SUM(DECODE(CALL_YN,'Y',1,0)) CALL_CNT FROM SFA_VISIT_PLANACT WHERE EMP_NO = IN_SAWON_ID GROUP BY SALES_PLAN_NO ) B
      ,(SELECT SALES_PLAN_NO,REASON_GB1,REASON_GB2,REASON_GB3,NONVISIT_REASON,SEONGINJA_CONF_YN,COMPANY_CONF_YN FROM SFA_VISIT_NON_REASON WHERE EMP_NO = IN_SAWON_ID) C
    WHERE A.SOLAR_DATE LIKE ''||NVL(IN_CDT, '%')||'%' 
       AND A.SOLAR_DATE = B.SALES_PLAN_NO(+)
       AND A.SOLAR_DATE = C.SALES_PLAN_NO(+)
    ORDER BY A.SOLAR_DATE;
    
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDER_LIST','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||'/in_CUST_ID'||in_CUST_ID||' / v_num:'||to_char(v_num));
--COMMIT
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
    
        OPEN out_RESULT FOR
        SELECT  SUBSTR(A.SOLAR_DATE,7,2)||'('||SUBSTR(TO_CHAR(TO_DATE(SOLAR_DATE), 'day'),1,1) ||')' AS out_SOLAR_DATE,
              F_GET_WORKDAY_STATUS(IN_SAWON_ID,A.SOLAR_DATE) AS out_BIGO,  
              B.PLAN_CNT AS out_PLAN_CNT,
              B.CALL_CNT AS out_CALL_CNT,
              C.REASON_GB1 AS out_REASON_GB1, 
              C.REASON_GB2 AS out_REASON_GB2, 
              C.REASON_GB3 AS out_REASON_GB3,
              C.NONVISIT_REASON AS out_NONVISIT_REASON,
              DECODE(C.SEONGINJA_CONF_YN,'0','대기','1','승인','반려')  AS out_SEONGINJA_CONF_YN,
              DECODE(C.COMPANY_CONF_YN,'0','대기','1','승인','반려')   AS out_COMPANY_CONF_YN
        FROM CO_LUNARSOLARCAL A
              ,(SELECT SALES_PLAN_NO,COUNT(*) PLAN_CNT,SUM(DECODE(CALL_YN,'Y',1,0)) CALL_CNT FROM SFA_VISIT_PLANACT WHERE EMP_NO = IN_SAWON_ID GROUP BY SALES_PLAN_NO ) B
              ,(SELECT SALES_PLAN_NO,REASON_GB1,REASON_GB2,REASON_GB3,NONVISIT_REASON,SEONGINJA_CONF_YN,COMPANY_CONF_YN FROM SFA_VISIT_NON_REASON WHERE EMP_NO = IN_SAWON_ID) C
         WHERE A.SOLAR_DATE LIKE ''||NVL(IN_CDT, '%')||'%' 
           AND A.SOLAR_DATE = B.SALES_PLAN_NO(+)
           AND A.SOLAR_DATE = C.SALES_PLAN_NO(+)
           ORDER BY A.SOLAR_DATE;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
