CREATE PROCEDURE      SP_SFA_ORDER_DELETE
 (in_gumae_no           IN VARCHAR2 default NULL, 
  out_CODE              OUT NUMBER,
  out_MSG               OUT VARCHAR2      )
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문삭제
 호출프로그램 : 주문삭제호출하는 부분없음 .확인후 삭제할것      
 ---------------------------------------------------------------------------*/    

    is_ITEM_ID VARCHAR2(10);
    is_QTY     NUMBER;
    
    ll_count   NUMBER;   
    
    ERROR_RAISE EXCEPTION;
    
    
BEGIN

    --1.승인여부체크
    SELECT count(*)
      INTO ll_count
      FROM SALE_ON.SALE0203
     WHERE ACCEPT_YN <> 'Y' -- 승인구분- 'Y' 초기상태, 'S' 승인상태 , null(출하완료상태)
       AND GUMAE_NO = in_gumae_no;
    if ll_count <> 0 then            
        out_CODE := 101;
        RAISE ERROR_RAISE; --- (-20000,'<승인된 주문이므로 삭제 불가합니다>');
    end if;
    
    --DBMS_OUTPUT.PUT_LINE('1.승인여부체크');
    
    --2.주문상세삭제 --삭제된주문에 대한 모든  제품의 수량을 SALE0305 의 에 반영시킨다.
    DECLARE CURSOR Cur_1 IS    
     SELECT ITEM_ID,QTY    
       FROM SALE_ON.SALE0204
      WHERE GUMAE_NO = in_gumae_no;
    BEGIN               
        FOR cur IN Cur_1 LOOP 
            is_ITEM_ID  := cur.ITEM_ID;
            is_QTY      := cur.QTY;
             
            --온라인주문용출고수량에 빼준다
            BEGIN
                UPDATE sale.sale0305
                   SET chulgo_qtyst = nvl(chulgo_qtyst,0) - is_QTY
                 WHERE ymd       = to_date(to_char(sysdate, 'yyyymm')||'01','yyyymmdd')
                   AND store_loc = '01' 
                   AND item_id   = is_ITEM_ID;        
            EXCEPTION 
                 WHEN OTHERS THEN                  
                      out_CODE := SQLCODE; 
                      out_MSG  :='온라인주문용출고수량에 반영 에러=>'||'(제품:'||is_ITEM_ID||')'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                      ROLLBACK;
                      RETURN;
            END;
            
        END LOOP ;        
       
    END;  
    
    --3.주문상세삭제 
    BEGIN
        DELETE SALE_ON.SALE0204
         WHERE gumae_no = in_gumae_no;
    EXCEPTION
         WHEN OTHERS THEN
             out_CODE := SQLCODE; 
             out_MSG  :='주문상세삭제 에러=>'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);  
             ROLLBACK;    
             RETURN;    
    END;
    
    
    --4.주문마스터삭제 
    BEGIN
        DELETE SALE_ON.SALE0203
         WHERE gumae_no = in_gumae_no;
    EXCEPTION
         WHEN OTHERS THEN
             out_CODE := SQLCODE; 
             out_MSG  :='주문마스터삭제 에러=>'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);   
             ROLLBACK;    
             RETURN;           
    END;


EXCEPTION 
     WHEN ERROR_RAISE THEN 
          out_CODE := 1;    
     WHEN OTHERS THEN
          out_CODE := SQLCODE;
          out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
  
END;

/
