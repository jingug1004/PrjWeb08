CREATE PROCEDURE P_PRD00032_IU 
            ( I_PROD_SEQ      IN   VARCHAR2,-- 실제제조번호
			  I_WSEQ          IN   NUMBER,  -- 작업순서
			  I_PROCESS_CD    IN   VARCHAR2,-- 공정코드
			  I_MATRIAL_CD	  IN   VARCHAR2,-- 원부자재코드
			  O_MSG           OUT  VARCHAR2 -- 메시지
) IS 
/* --------------------------------------------------------------------------
   설명: 칭량상세등록에서 칭량수량이 입력되면 해당내용을                              
         원부자재출고테이블(INV0301,INV0302)에 수량을 INSERT OR UPDATE         
         처리한다.                                                                    
---------------------------------------------------------------------------- */
T_UPDATE_CHK   NUMBER;
V_USER_ID      VARCHAR2(10);
V_YMD          VARCHAR2(8);
V_ll_slip_no   NUMBER;
V_lS_slip_no   VARCHAR2(3);
V_JUNPYOGB_CD  VARCHAR2(3);
VS_SEQ         VARCHAR2(3);

   CURSOR CUR1 IS 
		   SELECT PROD_SEQ, 
		          WSEQ, 
				  PROCESS_CD, 
				  MATRIAL_CD,
		          SUM(CON_QTY) CON_QTY, 
		          MIN(YMD)     YMD, 
				  MIN(SLIP_NO) SLIP_NO, 
		          MIN(SEQ)     SEQ
		     FROM PRD00032
            WHERE PROD_SEQ   = I_PROD_SEQ
              AND WSEQ       = I_WSEQ
              AND PROCESS_CD = I_PROCESS_CD
			  AND MATRIAL_CD = I_MATRIAL_CD
			GROUP BY PROD_SEQ,WSEQ,PROCESS_CD,MATRIAL_CD;
BEGIN
   FOR C1 IN CUR1 LOOP
      IF C1.YMD IS NULL THEN --출고전표일자가 NULL이면 INSERT 
	     --전표일자
	     SELECT TO_CHAR(NVL(WORK_DTF,NULL),'YYYYMMDD'), NVL(USER_ID,'ADMIN2'), NVL(JUNPYOGB_CD,'112')
		   INTO V_YMD, V_USER_ID, V_JUNPYOGB_CD
		   FROM PRD0003
		  WHERE PROD_SEQ   = C1.PROD_SEQ
		    AND WSEQ       = C1.WSEQ
		    AND PROCESS_CD = C1.PROCESS_CD;
			
		  IF V_YMD IS NULL THEN
             RAISE_APPLICATION_ERROR( -20001, '작업시작일자가 등록되어있지 않습니다.' ) ;
			 RETURN;		     
		  END IF;
		 
	      --이전 출고일자,출고번호을 찾는다.
		 BEGIN
			  SELECT SLIP_NO
			    INTO V_lS_slip_no
			    FROM INV0301
			   WHERE YMD         = V_YMD
			     AND JUNPYOGB_CD = V_JUNPYOGB_CD
				 AND PROD_SEQ    = C1.PROD_SEQ
				 AND PROCESS_CD  = C1.PROCESS_CD
				 AND SAWON_ID    = V_USER_ID;

			   EXCEPTION
	                WHEN OTHERS THEN
				         V_lS_slip_no := NULL;
	            --       RAISE_APPLICATION_ERROR( -20001, 'XXXXX' ) ;
		  END;
		  IF V_lS_slip_no IS NULL THEN --INSERT
			 --전표번호
		     BEGIN
			   select SEQ + 1
			     into V_ll_slip_no
			     from bas0201
			    where SEQ_GB1 = 'inv_slip_no'
			      AND SEQ_GB2 = V_YMD ;
			   EXCEPTION
	                WHEN OTHERS THEN
				         V_ll_slip_no := NULL;
	            --       RAISE_APPLICATION_ERROR( -20001, 'XXXXX' ) ;
		     END;

			 IF V_ll_slip_no IS NULL THEN
			    V_lS_slip_no := '001';
		        INSERT INTO BAS0201 (SEQ_GB1, SEQ_GB2, SEQ, BIGO)
		 		             VALUES ('inv_slip_no',V_YMD,1,'원/부자재입출고');
			 ELSE
			    V_lS_slip_no := trim(TO_CHAR(V_ll_slip_no,'000'));
				UPDATE BAS0201 SET SEQ = V_ll_slip_no
				             WHERE SEQ_GB1 = 'inv_slip_no'
	 		                   AND SEQ_GB2 = V_YMD ;
			 END IF;
			 VS_SEQ := '001';

		     --원부자재출고 테이블
		     INSERT INTO INV0301(YMD, SLIP_NO, JUNPYOGB_CD, PROD_SEQ, PROCESS_CD, SAWON_ID, STORE_LOC, BIGO)
			             VALUES (V_YMD,V_lS_slip_no, V_JUNPYOGB_CD, C1.PROD_SEQ, C1.PROCESS_CD, V_USER_ID, '01', '칭량실적' );
		  ELSE
		     SELECT TRIM(TO_CHAR(TO_NUMBER(MAX(SEQ)) + 1,'000'))
			   INTO VS_SEQ
			   FROM INV0302
			  WHERE YMD     = V_YMD
			    AND SLIP_NO = V_lS_slip_no ;
		  END IF;

	     --원부자재출고 테이블
	     INSERT INTO INV0302(YMD, SLIP_NO, SEQ, JUNPYOGB_CD, MATERIAL_ID, QTY)
		             VALUES (V_YMD,V_lS_slip_no, VS_SEQ, V_JUNPYOGB_CD, C1.MATRIAL_CD, C1.CON_QTY );

	     --칭량테이블에(PRD00032) 출고전표번호에 값을 셋팅 
	      UPDATE PRD00032 SET YMD     = V_YMD,
		                      SLIP_NO = V_lS_slip_no,
							  SEQ     = VS_SEQ
		                WHERE PROD_SEQ   = C1.PROD_SEQ
					      AND WSEQ       = C1.WSEQ
						  AND PROCESS_CD = C1.PROCESS_CD
						  AND MATRIAL_CD = C1.MATRIAL_CD;
					  
	  ELSE --UPDATE
	      UPDATE INV0302 SET QTY = C1.CON_QTY
		               WHERE YMD     = C1.YMD
					     AND SLIP_NO = C1.SLIP_NO
						 AND SEQ     = C1.SEQ;

      END IF;
   END LOOP;
   O_MSG := 'OK : 출고전표 처리가 완료 되었습니다.';   
   COMMIT; 
END  P_PRD00032_IU ;


/
