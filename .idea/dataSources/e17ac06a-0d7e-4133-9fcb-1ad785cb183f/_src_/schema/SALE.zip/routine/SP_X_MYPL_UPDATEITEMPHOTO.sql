CREATE PROCEDURE      SP_X_MYPL_UPDATEITEMPHOTO
(
    in_ITEM_PHOTO  IN VARCHAR2,
    in_ITEM_CODE   IN VARCHAR2,
    out_CODE      OUT NUMBER,
    out_MSG       OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_MYPL_UPDATEITEMPHOTO
-- 작 성 자      : 유명배
-- 작성일자      : 2017-12-03
-- 수 정 자      : 
-- 수정일자      : 2017-12-03
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 제품 이미지 업데이트 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	UPDATE SALE.SFA_OFFICE_ITEMDOC
		SET    ITEM_PHOTO            = in_ITEM_PHOTO
		WHERE  ITEM_CODE             = in_ITEM_CODE;

    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 UPDATE ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 수정';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK; 

END ;
/
