CREATE PROCEDURE      SP_X_BALANCE_SUMBALANCE
(
    in_CUST_ID  IN VARCHAR2,
    out_RESULT  OUT TYPES.CURSOR_TYPE,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_BALANCE_SUMBALANCE
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  잔고담보 현황 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
	  SELECT F.BEFORE_AMT BEFORE_AMT, F.MISU_AMT SALE_AMT,
		       NVL (F.BEFORE_AMT, 0) + NVL (F.MISU_AMT, 0)
		       - NVL (F.SU_AMT, 0) CUR_AMT, G.JASU_AMT JASU_AMT, G.TASU_AMT TASU_AMT,
		       H.SALE_DAMBO_AMT SALE_DAMBO_AMT
		  FROM SALE.SALE0003 A,
		       (SELECT   CUST_ID, SUM (BEFORE_AMT) BEFORE_AMT, SUM (MISU_AMT)
		                                                                     MISU_AMT,
		                 SUM (SU_AMT) SU_AMT
		            FROM SALE.SALE0306_V
		           WHERE CUST_ID = in_CUST_ID
		             AND YMD =
		                    TO_DATE (TO_CHAR (SYSDATE, 'YYYY/MM') || '/01',
		                             'YYYY/MM/DD'
		                            )
		        GROUP BY CUST_ID) F,
		       (SELECT   X.CUST_ID,
		                 SUM (CASE
		                         WHEN Y.BILL_GB IN
		                                          ('010', '020', '030', '100', '900')
		                            THEN AMT
		                         ELSE 0
		                      END
		                     ) JASU_AMT,
		                 SUM (CASE
		                         WHEN Y.BILL_GB IN ('025', '035', '040')
		                            THEN AMT
		                         ELSE 0
		                      END
		                     ) TASU_AMT
		            FROM SALE.SALE0401_V X, SALE.SALE0402_V Y
		           WHERE X.CUST_ID = in_CUST_ID
		             AND X.YMD = Y.YMD
		             AND X.JUNPYO_NO = Y.JUNPYO_NO
		             AND Y.END_YMD >= SYSDATE
		        GROUP BY X.CUST_ID) G,
		       (SELECT   X.CUST_ID, NVL (SUM (X.SALE_DAMBO_AMT), 0) SALE_DAMBO_AMT
		            FROM SALE.SALE0404 X
		           WHERE X.CUST_ID = in_CUST_ID
		             AND NVL (X.CHULGO_YMD(+), TO_DATE ('2999/01/01', 'YYYY/MM/DD')) =
		                                          TO_DATE ('2999/01/01', 'YYYY/MM/DD')
		        GROUP BY X.CUST_ID) H
		 WHERE A.CUST_ID = in_CUST_ID
		   AND A.CUST_ID = F.CUST_ID(+)
		   AND A.CUST_ID = G.CUST_ID(+)
		   AND A.CUST_ID = H.CUST_ID(+);

    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
