CREATE function      F_GET_SALE0405_SAWONIDH
        ( A_DEAL_NO      VARCHAR2, -- 전표번호 
          A_CUST_ID      VARCHAR2, -- 직납처
          A_RCUST_ID     VARCHAR2, -- 간납처
          A_ITEM_ID      VARCHAR2, -- 제품코드
          A_YMD          DATE      -- 전표일자 
        )
   RETURN VARCHAR2
AS
   user_err       exception   ;
   A_SYMD         VARCHAR2(8);
   V_TRAN_YMD_CD  VARCHAR2(14);
   V_INPUT_SEQ    VARCHAR2(14);
   V_YMD          DATE ;
   V_SYMD         VARCHAR2(8);
   n_rtn_value    VARCHAR2(250);
   v_curr_error   VARCHAR2(250);

/*----------------------------------------------------------------
  이력관리적용부터 사용되는 평션 (2010.01.01 일부터 유효) 
    ==============================================================
   <주의사항> - RETURN갑시이 정상적이 않을을 처리하기 위한 방법  
      1.사원코드등록에 (00000)미지정으로 사원코드들 등록한다.
      2.부서코드등록에 (Z0)미지정으로 부서코들 등록한다.
      3.사원코드등록에서 '00000'코드에 부서코드'Z0'를 지정한다.
    ============================================================== 
       
   변경기록 : 2016.06.09 김태안 - 시행종료일자를 조건절에 포함시킴. 시행종료일이 지난경우 실적은 미지정 AND YMD        >= A_YMD 
----------------------------------------------------------------*/
BEGIN
    
    A_SYMD := TO_CHAR(A_YMD, 'YYYYMMDD');  
    
    SELECT /*+ index_desc(A SALE0405H_PK) */
           a.sawon_id
      into n_rtn_value     
      FROM SALE0405H A
     WHERE CUST_ID     = A_CUST_ID
       AND RCUST_ID    = A_RCUST_ID
       AND ITEM_ID     = A_ITEM_ID                   
       AND APPL_DATE   = (  SELECT /*+ index_desc(A SALE0405H_01) */ 
                                   APPL_DATE
                              FROM SALE0405H A
                             WHERE CUST_ID     = A_CUST_ID
                               AND RCUST_ID    = A_RCUST_ID
                               AND ITEM_ID     = A_ITEM_ID          
                               AND YMD        >= A_YMD         
                               AND APPL_DATE  <= A_SYMD    
                               AND ROWNUM      = 1
                          )
       AND ROWNUM = 1                           
    ;  
    
    RETURN n_rtn_value;

EXCEPTION  
     WHEN NO_DATA_FOUND THEN
          RETURN '00000';
     WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20002, substrb(A_CUST_ID||'-'||A_RCUST_ID||'-'||A_ITEM_ID||'-'||SQLERRM,1,250));
END;
/
