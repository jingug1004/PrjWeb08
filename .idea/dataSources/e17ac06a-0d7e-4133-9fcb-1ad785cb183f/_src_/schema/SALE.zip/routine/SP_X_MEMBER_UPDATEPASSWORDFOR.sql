CREATE PROCEDURE      SP_X_MEMBER_UPDATEPASSWORDFOR
(
    in_NEWPASSWD  IN VARCHAR2,
    in_EMPCODE    IN VARCHAR2,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_MEMBER_UPDATEPASSWORDFOR
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  로그인 비번 수정 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
     UPDATE HANACOMM.CO_US_MEMBER_0 
		SET PASS_WORD = UTL_I18N.STRING_TO_RAW(in_NEWPASSWD,'AL32UTF8')
		WHERE EMP_NO IN (SELECT A.INSA_SAWON_ID
		         FROM SALE.SALE0007 A,  HANACOMM.CO_US_MEMBER_0 B
		        WHERE A.GUBUN = 'Y'
		          AND B.USE_YN = 'Y'
		          AND A.INSA_SAWON_ID = B.EMP_NO 
		          AND A.SAWON_ID = in_EMPCODE);
		          
    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 UPDATE ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 수정';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;
END ;
/
