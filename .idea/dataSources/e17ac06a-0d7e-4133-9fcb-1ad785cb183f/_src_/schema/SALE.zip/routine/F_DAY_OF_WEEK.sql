CREATE FUNCTION      F_DAY_OF_WEEK
(
    in_DAY IN VARCHAR2
) 
RETURN VARCHAR2 IS

        V_DAY_OF_WEEK VARCHAR2(1);  --방문 계획 주간
        
        V_DAY_OF_WEEK_NOW VARCHAR2(1);  --계획을 세우는 시점
        V_MONDAY_TIME VARCHAR2(2); 
        
        V_SUNDAY VARCHAR2(8);
        V_SATURDAY VARCHAR2(8);
        V_THIS_WEEK VARCHAR2(8);        
        
        V_RETURN VARCHAR2(1);  
    
BEGIN

        /* CHOE 20161207
        SP_SFA_VISIT_04_115 함수에 사용 되었다
        날짜가 넘어오면 방문 계획 가능 여부를 알려준다.
        
        절대적인 규칙 - 오늘/과거 방문에 대해서는 새울 수 없다는 조건이 있어야 한다. 1번 2번
        
        V_DAY_OF_WEEK 
        V_DAY_OF_WEEK_NOW 
        2가지 값에 의해 계획을 세우는 것에 제한을 두었다        
        
        V_RETURN - 1 오늘 방문 계획은 불가능
                        2 과거의 방문 계획은 불가능
                        3 월요일 오전 09시 이후 방문 계획 불가능 
                        4 이번주 방문 계획은 불가능
                        5 빈칸
                        0 방문 계획 가능 
        */             
        V_RETURN := '0'; 
        
        
        --1 오늘 방문 계획은 불가능하다.
        IF in_DAY = TO_CHAR(SYSDATE ,'YYYYMMDD') THEN                
                V_RETURN := '1';
        --2 과거의 방문 계획은 불가능
        ELSIF TO_DATE(in_DAY, 'YYYYMMDD') < SYSDATE THEN
                V_RETURN := '2';
        ELSE      
                V_DAY_OF_WEEK := '1';  --일요일 초기값
                --3번 4번이번주 방분계획은 불가능 
                --방문 계획 주간을 찾는다. 계획하는 날이 무슨 요일인지 찾는다. 1-일 2-월 3-화 4-수 5-목 6-금 7-토      
                SELECT TO_CHAR(TO_DATE(in_DAY, 'YYYYMMDD'), 'D')
                INTO V_DAY_OF_WEEK
                FROM DUAL
                ;   
                     
                --이번주 시작(일요일) 찾는다
                V_SUNDAY := '';
                SELECT TO_CHAR(TO_DATE(in_DAY, 'YYYYMMDD') - (TO_NUMBER(V_DAY_OF_WEEK) - 1) , 'YYYYMMDD') 
                INTO V_SUNDAY 
                FROM DUAL
                ;             
                 --이번주 끝(토요일) 찾는다.
                 V_SATURDAY := '';
                SELECT TO_CHAR(TO_DATE(in_DAY, 'YYYYMMDD') + (7 - TO_NUMBER(V_DAY_OF_WEEK)) , 'YYYYMMDD') 
                INTO V_SATURDAY 
                FROM DUAL
                ; 
                
                --4 이번주 인지 확인 Y 이번주 N 이번주가 아님
                V_THIS_WEEK := 'N'; 
                SELECT CASE WHEN SYSDATE < TO_DATE(V_SUNDAY,'YYYYMMDD') THEN 'N' 
                                WHEN SYSDATE > TO_DATE(V_SATURDAY,'YYYYMMDD') THEN 'N'
                                ELSE 'Y'
                         END
                INTO V_THIS_WEEK
                FROM DUAL
                ;         
                
                V_DAY_OF_WEEK_NOW := '1';
                --계획을 세우는 시점 확인
                SELECT TO_CHAR(SYSDATE, 'D')
                INTO V_DAY_OF_WEEK_NOW
                FROM DUAL
                ;           
                
                
                IF V_DAY_OF_WEEK_NOW = '1' THEN --일요일은 언제든지 방문 계획을 세울 수 있음 이번주 다음주 구분 필요 없음
                        V_RETURN := '0';
                ELSIF V_DAY_OF_WEEK_NOW = '7' THEN --토요일은 언제든지 방문 계획을 세울 수 있음 이번주 다음주 구분 필요 없음 
                        V_RETURN := '0';
                ELSIF V_DAY_OF_WEEK_NOW = '2' THEN -- 월요일은 오전 09시  전까지                       
                        --이번주 인 경우
                        IF V_THIS_WEEK = 'Y' THEN                        
                                V_MONDAY_TIME := '';
                                SELECT TO_CHAR(SYSDATE ,'HH24')
                                INTO V_MONDAY_TIME  
                                FROM DUAL
                                ;                                        
                                --3 월요일 오전 09시 이전에 방문 계획 불가능      
                                IF TO_NUMBER(V_MONDAY_TIME) < 9 THEN                
                                        V_RETURN := '0';
                                ELSE
                                        V_RETURN := '3';
                                END IF;
                        ELSE
                                V_RETURN := '0';
                        END IF;
                        
                ELSE  --화수목금                        
                        IF V_THIS_WEEK = 'Y' THEN
                                V_RETURN := '4';
                        ELSE
                                V_RETURN := '0';    
                        END IF;
                END IF; 
        END IF;
        
        RETURN V_RETURN;
    
EXCEPTION
    WHEN NO_DATA_FOUND THEN
            RETURN '';
END;
/
