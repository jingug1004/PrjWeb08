CREATE PROCEDURE      SP_X_INFO_INSTITUTEGRIDLIST
(
    in_CUST_ID      IN VARCHAR2,
    in_CUSTOMER_ID  IN VARCHAR2,
    in_SIDX         IN VARCHAR2,
    in_SORD         IN VARCHAR2,
    out_RESULT      OUT TYPES.CURSOR_TYPE,
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INFO_INSTITUTEGRIDLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  기타사항 검색 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
		SELECT A.CUST_ID, 
		       A.CUSTOMER_ID, 
		       A.SEQ, 
		       A.HAKHEO_NM, 
		       A.DATEF, 
		       A.DATET, 
		       A.JIWI, 
		       A.GWANSIMDO, 
		       A.GITA
		  FROM SALE.CRM_HAKHEO A
		 WHERE A.CUST_ID = in_CUST_ID
		   AND A.CUSTOMER_ID = in_CUSTOMER_ID
		ORDER BY in_SIDX||' '||in_SORD;
													
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
