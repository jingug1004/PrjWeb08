CREATE PROCEDURE      SP_SFA_COLLECT
   (in_FLAG         IN VARCHAR2 DEFAULT NULL,
    in_YMD          IN date,
    in_JUNPYO_NO    IN VARCHAR2 DEFAULT NULL,
    in_CUST_ID      IN VARCHAR2 DEFAULT NULL, 
    in_RCUST_ID     IN VARCHAR2 DEFAULT NULL, 
    in_AMT          IN VARCHAR2 DEFAULT NULL, 
    in_SAWON_ID     IN VARCHAR2 DEFAULT NULL, 
    in_BIGO         IN VARCHAR2 DEFAULT NULL,
    in_BALHANG      IN VARCHAR2 DEFAULT NULL, 
    in_JIGEUB       IN VARCHAR2 DEFAULT NULL, 
    in_BILL_NO      IN VARCHAR2 DEFAULT NULL, 
    in_BILL_GB      IN VARCHAR2 DEFAULT NULL, 
    in_GYULJAE_YMD  IN VARCHAR2 DEFAULT NULL,
    in_SIGN_IMAGE   IN VARCHAR2 DEFAULT NULL, --사인은 여기서 저장하지 않음. apachetomcat서버 측에서 직접 update함.
    in_PDA_RPRT     IN VARCHAR2 DEFAULT NULL,
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2,
    out_COUNT       OUT NUMBER,
    out_RESULT      OUT TYPES.CURSOR_TYPE  
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 카드수금
 호출프로그램 : 110 버전으로 대체 
 수정기록     :       
 ---------------------------------------------------------------------------*/    

    ll_max number := 0;
    ll_count number := 0;
    V_sawon_id VARCHAR2(20);
    V_JUNPYO_NO VARCHAR2(12);
    ERROR_EXCEPTION     EXCEPTION;
    
BEGIN
    
    IF in_JUNPYO_NO IS NULL OR in_JUNPYO_NO = '' THEN
        
        ll_max := 0;
        SP_SYS100C_MAX_VALUE('SALE0401', to_char(sysdate, 'yyyyMMdd'), null,null, null, null, ll_max );

        IF ll_max < 1 THEN
            out_COUNT := 0;
            out_CODE := 1;
            out_MSG := '전표번호 생성 오류'; 
        ELSE
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '전표번호 생성완료'; 
        
            V_JUNPYO_NO := to_char(sysdate, 'yyyyMMdd') || Lpad(to_char(ll_max),4,'0');
            
        END IF;        
    ELSE
        V_JUNPYO_NO := in_JUNPYO_NO ;
    
    END IF;
    
   -- 담당사원  ID 가져오기   
    BEGIN
        select  sawon_id 
        into V_sawon_id
        from sale.sale0003
        where cust_id = in_CUST_ID ;
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '<거래처의 담당영업사번 검색시 오류발생 >'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
        RAISE ERROR_EXCEPTION;
    END;  
   
    
    BEGIN
        INSERT INTO SALE.SALE0401 (
               YMD
              ,JUNPYO_GB
              ,JUNPYO_NO
              ,CUST_ID
              ,RCUST_ID
              ,CASH_AMT
              ,BILL_AMT
              ,SAWON_ID
              ,INPUT_ID
              ,INPUT_YMD
              ,BIGO
              ,LOG_DATE) 
        VALUES ( TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')
                ,'01'
                ,V_JUNPYO_NO
                ,in_CUST_ID
                ,in_RCUST_ID
                ,0
                ,decode( NVL(in_AMT, ''),'','0',to_number(in_AMT)) 
                ,V_sawon_id
                ,in_SAWON_ID
                ,SYSDATE
                ,in_BIGO 
                ,SYSDATE); 
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :='수금마스터 저장실패:'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
        RAISE ERROR_EXCEPTION;
    END;
     
     --상세내역 저장 
    BEGIN
        INSERT INTO SALE.SALE0402
             ( YMD
              ,JUNPYO_NO 
              ,INPUT_SEQ 
              ,END_YMD
              ,AMT
              ,START_YMD
              ,BALHANG
              ,JIGEUB
              ,BILL_NO
              ,BILL_GB
              ,GYULJAE_YMD
              ,BIGO
              ,SIGN_YN
              ,SIGN_IMAGE
              ,PDA_RPRT
              )
       VALUES (TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')
              ,V_JUNPYO_NO
              ,'0001'
              ,TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')
              ,decode( NVL(in_AMT, ''),'','0',to_number(in_AMT))
              ,TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')
              ,in_BALHANG
              ,in_JIGEUB
              ,in_BILL_NO
              ,in_BILL_GB
              ,TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')
              ,in_BIGO
              ,'Y'
              ,in_SIGN_IMAGE
              ,in_PDA_RPRT
           );
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '수금상세 저장실패:'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
        RAISE ERROR_EXCEPTION;
    END; 
    
    out_CODE := 0;
    out_MSG := '수금 정상 처리';
     
EXCEPTION
WHEN ERROR_EXCEPTION THEN
   -- out_CODE := 1; 
   -- out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
    insert into SFA_SP_CALLED_HIST 
    values ('SP_SFA_COLLECT',in_JUNPYO_NO,sysdate
          ,'in_CUST_ID:'||in_CUST_ID||'/in_AMT:'||in_AMT||'/in_SAWON_ID:'||in_SAWON_ID||'/in_AMT:'||in_AMT||
          '/in_BIGO:'||in_BIGO||'/in_BALHANG:'||in_BALHANG||'/in_JIGEUB:'||in_JIGEUB ||'/in_BILL_NO:'||in_BILL_NO ||'/in_BILL_GB:'||in_BILL_GB ||'/in_GYULJAE_YMD:'||in_GYULJAE_YMD||'[out_MSG1:'||out_MSG||']');
   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
    insert into SFA_SP_CALLED_HIST 
    values ('SP_SFA_COLLECT',in_JUNPYO_NO,sysdate
          ,'in_CUST_ID:'||in_CUST_ID||'/in_AMT:'||in_AMT||'/in_SAWON_ID:'||in_SAWON_ID||'/in_AMT:'||in_AMT||
          '/in_BIGO:'||in_BIGO||'/in_BALHANG:'||in_BALHANG||'/in_JIGEUB:'||in_JIGEUB ||'/in_BILL_NO:'||in_BILL_NO ||'/in_BILL_GB:'||in_BILL_GB ||'/in_GYULJAE_YMD:'||in_GYULJAE_YMD||'[out_MSG2:'||out_MSG||']');
END;
/
