CREATE PROCEDURE      SP_X_INFO_UPDATECUSTOMERINFO
(
    in_CUSTOMER_NM      IN VARCHAR2,
    in_SEX              IN VARCHAR2,
    in_BIRTH_DAY        IN VARCHAR2,
    in_ACT_BIRTH        IN VARCHAR2,
    in_MARRY_YN         IN VARCHAR2,    
    in_MARRY_DAY        IN VARCHAR2,
    in_CHILD_KIND       IN VARCHAR2,
    in_DISPOSITION      IN VARCHAR2,
    in_RELIGION         IN VARCHAR2,
    in_HIGHSCHOOL       IN VARCHAR2,
    in_UNIVERSITY       IN VARCHAR2,
    in_ZIP              IN VARCHAR2,
    in_ADDRESS1         IN VARCHAR2,
    in_ADDRESS2         IN VARCHAR2,
    in_TEL              IN VARCHAR2,
    in_MOBILE           IN VARCHAR2,
    in_FAX              IN VARCHAR2,
    in_EMAIL            IN VARCHAR2,
    in_CAR_NO           IN VARCHAR2,
    in_CAR_COLOR        IN VARCHAR2,
    in_FOREIGN_STUDY_YN IN VARCHAR2,
    in_RANK             IN VARCHAR2,
    in_LESSON           IN VARCHAR2,
    in_HOSPITAL         IN VARCHAR2,
    in_MAJOR            IN VARCHAR2,
    in_MAIN_BUYING      IN VARCHAR2,
    in_HUMAN_REL        IN VARCHAR2,
    in_HOBBY            IN VARCHAR2,
    in_TABOO_LIST       IN VARCHAR2,
    in_GITA             IN VARCHAR2,
    in_CUST_ID          IN VARCHAR2,
    in_CUSTOMER_ID      IN VARCHAR2,
    out_CODE           OUT NUMBER,
    out_MSG            OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INFO_UPDATECUSTOMERINFO
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  고객정보 수정 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    UPDATE SALE.CRM_MASTER
		   SET CUSTOMER_NM      = in_CUSTOMER_NM,
		       SEX              = in_SEX,
		       BIRTH_DAY        = in_BIRTH_DAY,
		       ACT_BIRTH_DAY    = in_ACT_BIRTH,
		       MARRY_YN         = in_MARRY_YN,
		       MARRY_DAY        = in_MARRY_DAY,
		       CHILD_KIND       = in_CHILD_KIND,
		       DISPOSITION      = in_DISPOSITION,
		       RELIGION         = in_RELIGION,
		       HIGHSCHOOL       = in_HIGHSCHOOL,
		       UNIVERSITY       = in_UNIVERSITY,
		       ZIP              = in_ZIP,
		       ADDRESS1         = in_ADDRESS1,
		       ADDRESS2         = in_ADDRESS2,
		       TEL              = in_TEL,
		       MOBILE           = in_MOBILE,
		       FAX              = in_FAX,
		       EMAIL            = in_EMAIL,
		       CAR_NO           = in_CAR_NO,
		       CAR_COLOR        = in_CAR_COLOR,
		       FOREIGN_STUDY_YN = in_FOREIGN_STUDY_YN,
		       RANK             = in_RANK,
		       LESSON           = in_LESSON,
		       HOSPITAL         = in_HOSPITAL,
		       MAJOR            = in_MAJOR,
		       MAIN_BUYING      = in_MAIN_BUYING,
		       HUMAN_REL        = in_HUMAN_REL,
		       HOBBY            = in_HOBBY,
		       TABOO_LIST       = in_TABOO_LIST,
		       GITA             = in_GITA
		 WHERE CUST_ID          = in_CUST_ID
		   AND CUSTOMER_ID      = in_CUSTOMER_ID;
		   
 IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 UPDATE ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 수정';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;	 
END ;
/
