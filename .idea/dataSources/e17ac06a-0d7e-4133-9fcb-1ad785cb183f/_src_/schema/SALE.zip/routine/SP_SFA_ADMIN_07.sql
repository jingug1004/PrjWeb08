CREATE PROCEDURE      SP_SFA_ADMIN_07    -- 제품 상세설명 정보
(
    in_ITEM_NM           IN  VARCHAR2,  
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_ITEMDOC
     WHERE ITEM_NAME LIKE '%'||NVL(in_ITEM_NM, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT ITEM_CODE              AS out_ITEM_ID        -- 제품코드
             , ITEM_NAME              AS out_ITEM_NM        -- 제품명
             , ITEM_POINT             AS out_POINT          -- 특장점
             , ITEM_EFFECT            AS out_EFFECT         -- 효능효과
             , ITEM_USE_DOES          AS out_ITEM_USE_DOES  -- 용량용법
             , ITEM_ATTENTION         AS out_ITEM_ATTENTION -- 주의사항
             , ITEM_PHOTO             AS out_PHOTO          -- 이미지
             , ITEM_KIND1             AS out_ITEM_KIND1          -- 의약품구분:1-전문,2-일반
             , ITEM_KD_NO             AS out_ITEM_KD_NO          -- KD번호
             , ITEM_MAIN_SOURCE       AS out_ITEM_MAIN_SOURCE  -- 주성분
             , ITEM_MAIN_SOURCE_SIZE  AS out_ITEM_MAIN_SOURCE_SIZE          -- 주성분함량
             , ITEM_POJANG_UNIT       AS out_ITEM_POJANG_UNIT          -- 포장단위
          FROM SFA_OFFICE_ITEMDOC
         WHERE ITEM_NAME LIKE '%'||NVL(in_ITEM_NM, '%')||'%'
         ORDER BY ITEM_NAME;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
