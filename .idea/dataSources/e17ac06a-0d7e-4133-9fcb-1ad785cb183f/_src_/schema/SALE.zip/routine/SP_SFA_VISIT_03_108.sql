CREATE PROCEDURE      SP_SFA_VISIT_03_108
(
    in_SAWON_ID          IN  VARCHAR2,     
    in_CUST_KEY          IN  VARCHAR2,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 개인방문계획업체별 고객
 호출프로그램 : spVisitPlanCustomer - 방문계획       화면의 hira거래처 클릭시 우측의 고객리스트
                               - 방문추가등록 팝업 화면의 hira거래처 클릭시 우측의 고객리스트
                               - 방문계획승인 리스트 조회                   -- 사용안함   
 수정기록                  
     2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_temp               VARCHAR2(20);
BEGIN

     
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_HIRA_CUSTOMER A
     WHERE A.HIRACODE   = in_CUST_KEY; 
     
    out_COUNT := v_num; 
    
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
       out_CODE := 0;
       out_MSG := '검색 완료';    
      
        OPEN out_RESULT FOR
        SELECT A.HIRACODE                        AS out_SFA_SALES_SEQ,      
               A.SFA_CLIENT_NO                   AS out_CLIENT_NO,
               B.HIRANAME                        AS out_SFA_SALES_NM,                
               A.CLIENT_NAME||' '||A.POSITION_NAME AS out_CLIENT_NAME       
          FROM SFA_HIRA_CUSTOMER A
              ,ORAGMP.CMHIRAM B
         WHERE A.HIRACODE = B.HIRACODE
           AND A.HIRACODE   = in_CUST_KEY
           AND A.DEL_YN = 'N'
         ORDER BY A.CLIENT_NAME;
       
    END IF;
    


    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
 
END;
/
