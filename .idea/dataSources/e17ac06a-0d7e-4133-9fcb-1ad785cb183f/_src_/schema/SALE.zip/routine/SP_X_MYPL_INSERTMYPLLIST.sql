CREATE PROCEDURE      SP_X_MYPL_INSERTMYPLLIST
(
    in_SAWON_ID  IN VARCHAR2,
    in_PLGRP_NO  IN VARCHAR2,
    in_ITEM_ID   IN VARCHAR2,
    in_SORT_SEQ  IN VARCHAR2,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_MYPL_INSERTMYPLLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : P/L 그룹 목록 저장  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	INSERT INTO SALE.SFA_MYPL_01 
					(SAWON_ID, PLGRP_NO, ITEM_ID,SORT_SEQ) 
			 VALUES (in_SAWON_ID
			        ,in_PLGRP_NO
		            ,in_ITEM_ID
			        ,in_SORT_SEQ
			 );
	 
    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 INSERT ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 저장';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK; 

END ;
/
