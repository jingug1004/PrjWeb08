CREATE PROCEDURE      P_SALE_SELLING_BATCH ( AS_FROM_YYYYMM IN VARCHAR2
                                                                                           ,AS_TO_YYYYMM IN VARCHAR2 
                                                                                           ,AS_DEPT_CD IN VARCHAR2
                                                                                           ,AS_SAWON_ID IN VARCHAR2                                                                                           
                                                                                           ,AS_INPUT_USER IN VARCHAR2 )IS
        /*------------------------------------------------------------------
        CHOE 20130319
        판매현황 : 부서-사원번호-거래처-판매처-품목 으로 하위 구성됩니다.      
        전체 영업사원의 거래처에 따른 매출처 기준으로 자료를 생성한다.
        부분 생성이 가능하도록 설계하였다
     
        AS_FROM_YYYYMM : 조회 시작 날짜 이면서 병원판매현황 시작일
        AS_TO_YYYYMM     : 조회 종료 날짜 이면서 병원판매현황 종료일 
        AS_DEPT_CD          : 해당 부서만 생성 가능 하도록 
        AS_SAWON_ID       : 해당 사원만 생성 가능 하도록    
        AS_INPUT_USER     : 생성 버튼을 누가 눌렀는지 기록한다.  
        
        중요 구성방법
        1. 거점도매 data 
             data windows 처리 : table - SALE0003_POINT
             거래처 명 "거점도매" 설정
                          
        2. 직납처 
            병원과 약국에 대한 상하위 거래처 설정 
            사원에 대해 hostory를 적용
            간납처 자료는 모두 배제 (cust_id = rcust_id )
            거래처명 앞에 "병원" 추가
                                   
            
        3. 간납처(도매) 
           병원 또는 약국과 관계에서 sale0203 : 거래처 - rcust_id , 매출처 - cust_id로 설정한다.
          사원에 대해 hostory를 적용
          직납처 자료는 모두 배제 ( cust_id <> rcust_id
          거래처명 앞에 "도매" 추가
                  
        ------------------------------------------------------------------*/
        V_CURR_ERROR        VARCHAR2(1000) ;
        USER_ERR                EXCEPTION; 

BEGIN 
        DBMS_OUTPUT.PUT_LINE('--------------------------------- START SALE SELLING BATCH ');
        V_CURR_ERROR := '';                 
        
        /*1. 이전 자료에 등록한 자료가 있다면 지운다 : 같은 DATA 무결성 */
        BEGIN
            DELETE FROM SALE_SELLING_BATCH
            WHERE SELLING_YM BETWEEN AS_FROM_YYYYMM AND AS_TO_YYYYMM
            AND SAWON_ID LIKE NVL(AS_SAWON_ID, '%')
            AND DEPT_CD LIKE NVL(AS_DEPT_CD, '%');   
        EXCEPTION  WHEN OTHERS THEN 
            V_CURR_ERROR := 'ERR DELETE : '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
            RAISE USER_ERR;
        END;
              
        COMMIT;     
                    
        /* 2. DATA INSERT  */
        BEGIN
            DBMS_OUTPUT.PUT_LINE('NOW INSERT JOB');         
            INSERT INTO SALE_SELLING_BATCH (  CUST_ID ,CUST_NM ,RCUST_ID ,RCUST_NM ,SAWON_ID 
                                                                  ,SAWON_NM ,DEPT_CD ,DEPT_NM ,ITEM_ID ,ITEM_NM
                                                                  ,SELLING_YM, AMT ,QTY ,FROM_YYYYMM ,TO_YYYYMM                 
                                                                  ,INPUT_USER ,EMPTY_1 ,EMPTY_2 )
              SELECT CUST_ID
                         ,CUST_NM
                         ,RCUST_ID
                         ,RCUST_NM 
                         ,SAWON_ID
                         ,SAWON_NM
                         ,DEPT_CD
                         ,DEPT_NM
                         ,ITEM_ID
                         ,ITEM_NM
                         ,SELLING_YM
                         ,AMT
                         ,QTY
                         ,TO_NUMBER(AS_FROM_YYYYMM) AS YM_FROM_YYYYMM  
                        ,TO_NUMBER(AS_TO_YYYYMM) AS YM_TO_YYYYMM
                        ,AS_INPUT_USER AS INPUT_USER
                        ,'' 
                        ,GUMAE_NO                         
              FROM (         
                               SELECT  C.CUST_ID AS CUST_ID
                                                ,C.CUST_NM AS CUST_NM--*/,'병원 - '||C.CUST_NM AS CUST_NM  --병원 구분 빼달라고
                                                ,C.RCUST_ID AS RCUST_ID
                                                ,C.RCUST_NM AS RCUST_NM 
                                                ,C.SAWON_ID AS SAWON_ID 
                                                ,C.SAWON_NM AS SAWON_NM 
                                                ,C.DEPT_CD AS DEPT_CD
                                                ,C.DEPT_NM AS DEPT_NM
                                                ,C.ITEM_ID AS ITEM_ID           
                                                ,C.ITEM_NM AS ITEM_NM
                                                ,TO_CHAR(C.YMD, 'YYYYMM') AS SELLING_YM                    
                                                ,SUM(NVL(C.AMT ,0)) AS AMT 
                                                ,SUM(NVL(C.QTY ,0)) AS QTY
                                                ,C.GUMAE_NO AS GUMAE_NO  
                                    FROM (  
                                                SELECT CUST.PARENTS_CUST_ID AS PARENTS_CUST_ID
                                                                 ,DECODE(CUST.PARENTS_CUST_ID ,'0000000', CUST.CUST_ID, CUST.PARENTS_CUST_ID) AS CUST_ID
                                                                 ,DECODE(CUST.PARENTS_CUST_ID ,'0000000' ,CUST.CUST_NM  ,F_GET_NAME('SALE0003', CUST.PARENTS_CUST_ID, '')) AS CUST_NM
                                                                 ,CUST.CUST_ID AS RCUST_ID                                                       
                                                                 --,DECODE(CUST.PARENTS_CUST_ID ,'0000000', '병원 - '||CUST.CUST_NM ,'약국 - '||CUST.CUST_NM  ) AS RCUST_NM  --병원 약국 빼 달라고
                                                                 ,DECODE(CUST.PARENTS_CUST_ID ,'0000000', CUST.CUST_NM ,CUST.CUST_NM  ) AS RCUST_NM                                      
                                                                 ,EMP.SIL_SAWON_ID AS SAWON_ID --,CUST.SAWON_ID AS SAWON_ID   -- 묶음 사번으로 DATA를 만든다.
                                                                 ,EMP.SAWON_NM AS SAWON_NM   
                                                                 ,EMP.DEPT_CD AS DEPT_CD
                                                                 ,F_GET_NAME('SALE0008', EMP.DEPT_CD, '') AS DEPT_NM 
                                                                 ,A.ITEM_ID AS ITEM_ID 
                                                                 ,A.ITEM_NM AS ITEM_NM
                                                                 ,A.AMT AS AMT
                                                                 ,A.QTY AS QTY
                                                                 ,A.GUMAE_NO AS GUMAE_NO
                                                                 ,A.YMD AS YMD                                                                         
                                                FROM (
                                                            SELECT MA.CUST_ID AS CUST_ID
                                                                               ,F_GET_NAME('SALE0003', MA.CUST_ID, '') AS CUST_NM
                                                                               ,MA.RCUST_ID AS RCUST_ID   
                                                                               ,F_GET_NAME('SALE0003', MA.RCUST_ID, '') AS RCUST_NM
                                                                               ,F_GET_SALE0405_SAWONIDH(MA.GUMAE_NO, MA.CUST_ID, MA.RCUST_ID, SL.ITEM_ID, MA.YMD) AS SAWON_IDH
                                                                               ,MA.SAWON_ID AS SAWON_ID
                                                                               ,MA.RSAWON_ID AS RSAWON_ID
                                                                               ,MA.YMD AS YMD
                                                                               ,SL.ITEM_ID AS ITEM_ID
                                                                               ,F_GET_NAME('SALE0004', SL.ITEM_ID, '') AS ITEM_NM
                                                                               ,SL.AMT - DEAL.DC_AMT AS AMT
                                                                               ,SL.QTY AS QTY  
                                                                               ,MA.GUMAE_NO AS GUMAE_NO                           
                                                                    FROM SALE0203 MA
                                                                             ,SALE0204 SL
                                                                             ,SALE0208 DEAL 
                                                                    WHERE MA.GUMAE_NO BETWEEN AS_FROM_YYYYMM||'010001' AND to_char(last_day(to_date(AS_TO_YYYYMM||'01','yyyymmdd')),'yyyymmdd')||'9999'
                                                                    AND MA.CUST_ID = MA.RCUST_ID   --직납인 경우
                                                                    AND MA.GUMAE_NO = SL.GUMAE_NO 
                                                                    AND MA.YMD = SL.YMD 
                                                                    AND SL.GUMAE_NO = DEAL. DEAL_NO
                                                                    AND SL.YMD = DEAL.YMD
                                                                    AND SL.INPUT_SEQ = DEAL.INPUT_SEQ
                                                                    AND SL.ITEM_ID = DEAL.ITEM_ID 
                                                            )A
                                                            ,(
                                                                        SELECT  PARENTS_CUST_ID
                                                                                     ,CUST_ID
                                                                                     ,CUST_NM
                                                                                     ,SAWON_ID                                                                
                                                                        FROM SALE0003
                                                                        WHERE CUST_ID <> '0000000'  
                                                                ) CUST
                                                                ,(
                                                                         SELECT OUS.SAWON_ID
                                                                                    ,OUS.SAWON_NM
                                                                                    ,OUS.SIL_SAWON_ID
                                                                                    ,( SELECT INS.DEPT_CD FROM SALE0007 INS WHERE INS.SAWON_ID = OUS.SIL_SAWON_ID ) AS DEPT_CD                                                               
                                                                         FROM SALE0007 OUS
                                                                         WHERE SIL_SAWON_ID LIKE NVL(AS_SAWON_ID, '%')     
                                                                         AND DEPT_CD LIKE NVL(AS_DEPT_CD, '%')
                                                                 )EMP 
                                                    WHERE A.SAWON_IDH = EMP.SAWON_ID
                                                    AND A.RCUST_ID = CUST.CUST_ID                                                                                                                                  
                                              ) C                 
                                    GROUP BY C.CUST_ID 
                                                    ,C.CUST_NM--*/,'병원 - '||C.CUST_NM --병원 빼 달라고 
                                                    ,C.RCUST_ID
                                                    ,C.RCUST_NM
                                                    ,C.SAWON_ID 
                                                    ,C.SAWON_NM 
                                                    ,C.DEPT_CD
                                                    ,C.DEPT_NM 
                                                    ,C.ITEM_ID           
                                                    ,C.ITEM_NM
                                                    ,TO_CHAR(C.YMD, 'YYYYMM')
                                                    ,C.GUMAE_NO
                                    UNION                                
                                    SELECT  A.RCUST_ID AS CUST_ID
                                                ,A.RCUST_NM AS CUST_NM --,'도매 - '||A.RCUST_NM AS CUST_NM  -- CHOE CUST_ID 와 RCUST_ID가 바뀐이유는 병원기준 자료를 뽑으려고
                                                ,A.CUST_ID AS RCUST_ID
                                                ,A.CUST_NM AS RCUST_NM 
                                                ,C.SIL_SAWON_ID AS SAWON_ID --,C.SAWON_ID AS SAWON_ID  : CHOE 20130322 아래 코드로 반영 요청                           
                                                ,C.SAWON_NM AS SAWON_NM                          
                                                ,C.DEPT_CD AS DEPT_CD
                                                ,F_GET_NAME('SALE0008', C.DEPT_CD, '') AS DEPT_NM
                                                ,A.ITEM_ID AS ITEM_ID           
                                                ,A.ITEM_NM AS ITEM_NM
                                                ,TO_CHAR(A.YMD, 'YYYYMM') AS SELLING_YM                    
                                                ,SUM(NVL(A.AMT ,0)) AS AMT 
                                                ,SUM(NVL(A.QTY ,0)) AS QTY
                                                ,A.GUMAE_NO AS GUMAE_NO   
                                    FROM (
                                                    SELECT MA.CUST_ID AS CUST_ID
                                                               ,F_GET_NAME('SALE0003', MA.CUST_ID, '') AS CUST_NM
                                                               ,MA.RCUST_ID AS RCUST_ID   
                                                               ,F_GET_NAME('SALE0003', MA.RCUST_ID, '') AS RCUST_NM
                                                               ,F_GET_SALE0405_SAWONIDH(MA.GUMAE_NO, MA.CUST_ID, MA.RCUST_ID, SL.ITEM_ID, MA.YMD) AS SAWON_IDH
                                                               ,MA.SAWON_ID AS SAWON_ID
                                                               ,MA.RSAWON_ID AS RSAWON_ID
                                                               ,MA.YMD AS YMD
                                                               ,SL.ITEM_ID AS ITEM_ID
                                                               ,F_GET_NAME('SALE0004', SL.ITEM_ID, '') AS ITEM_NM
                                                               ,SL.AMT - DEAL.DC_AMT AS AMT
                                                               ,SL.QTY AS QTY  
                                                               ,MA.GUMAE_NO AS GUMAE_NO                           
                                                    FROM SALE0203 MA
                                                             ,SALE0204 SL
                                                             ,SALE0208 DEAL 
                                                    WHERE MA.GUMAE_NO BETWEEN AS_FROM_YYYYMM||'010001' AND to_char(last_day(to_date(AS_TO_YYYYMM||'01','yyyymmdd')),'yyyymmdd')||'9999'
                                                    AND MA.CUST_ID <> MA.RCUST_ID   --간납인 경우
                                                    AND MA.GUMAE_NO = SL.GUMAE_NO 
                                                    AND MA.YMD = SL.YMD 
                                                    AND SL.GUMAE_NO = DEAL. DEAL_NO
                                                    AND SL.YMD = DEAL.YMD
                                                    AND SL.INPUT_SEQ = DEAL.INPUT_SEQ
                                                    AND SL.ITEM_ID = DEAL.ITEM_ID                                 
                                             ) A                      
                                            ,(
                                                     SELECT OUS.SAWON_ID
                                                                ,OUS.SAWON_NM
                                                                ,OUS.SIL_SAWON_ID
                                                                ,( SELECT INS.DEPT_CD FROM SALE0007 INS WHERE INS.SAWON_ID = OUS.SIL_SAWON_ID ) AS DEPT_CD -- 최신사번 부서 묶음
                                                     FROM SALE0007 OUS
                                                     WHERE SIL_SAWON_ID LIKE NVL(AS_SAWON_ID, '%')     
                                                     AND DEPT_CD LIKE NVL(AS_DEPT_CD, '%')                                                                                                                                     
                                              ) C   
                                    WHERE A.SAWON_IDH = C.SAWON_ID             
                                    GROUP BY A.RCUST_ID 
                                                    ,A.RCUST_NM --,'도매 - '||A.RCUST_NM
                                                    ,A.CUST_ID
                                                    ,A.CUST_NM
                                                    ,C.SIL_SAWON_ID 
                                                    ,C.SAWON_NM 
                                                    ,C.DEPT_CD
                                                    ,F_GET_NAME('SALE0008', C.DEPT_CD, '') 
                                                    ,A.ITEM_ID           
                                                    ,A.ITEM_NM
                                                    ,TO_CHAR(A.YMD, 'YYYYMM')
                                                    ,A.GUMAE_NO                                                                  
                 )   
                WHERE LENGTH( CUST_ID ) = 7  --자리수가 안 맞는 것이 있음    
                AND LENGTH( SAWON_ID ) > 0  --자리수가 안 맞는 것이 있음
                ORDER BY DEPT_NM
                               ,SAWON_NM
                               ,CUST_NM
                               ,RCUST_NM ;
                                                                 
        EXCEPTION WHEN OTHERS THEN
            V_CURR_ERROR := 'ERR 01 INSERT '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
            RAISE USER_ERR;
        END;                  
                   
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('--------------------------------- END SALE SELLING BATCH');     
  
EXCEPTION
    WHEN USER_ERR THEN
            RAISE_APPLICATION_ERROR(-20001, V_CURR_ERROR);             
            ROLLBACK;
             /* ERR 처리 결과 저장 */
            INSERT INTO SALE_SELLING_BATCH (CUST_ID, RCUST_ID, SAWON_ID, DEPT_CD, ITEM_ID, AMT, INPUT_USER, EMPTY_1) 
            SELECT '0000000' ,'0000000' ,'ERROR' ,'0000' ,'00000' ,0 ,AS_INPUT_USER ,'eXCEPTION USER ERR'
             FROM DUAL ;
            COMMIT; 
            RETURN;
    WHEN OTHERS THEN
            V_CURR_ERROR := 'ERR OTHERS ' || TO_CHAR(SQLCODE)|| '-'|| substr(sqlerrm, 1, 90);
            DBMS_OUTPUT.PUT_LINE(V_CURR_ERROR);
            ROLLBACK;
            /* ERR 처리 결과 저장 */
            INSERT INTO SALE_SELLING_BATCH (CUST_ID, RCUST_ID, SAWON_ID, DEPT_CD, ITEM_ID, AMT, INPUT_USER, EMPTY_1) 
            SELECT '0000000' ,'0000000' ,'ERROR' ,'0000' ,'00000' ,0 ,AS_INPUT_USER ,V_CURR_ERROR
             FROM DUAL ;
            COMMIT; 
            RETURN;
    
END P_SALE_SELLING_BATCH;

/
