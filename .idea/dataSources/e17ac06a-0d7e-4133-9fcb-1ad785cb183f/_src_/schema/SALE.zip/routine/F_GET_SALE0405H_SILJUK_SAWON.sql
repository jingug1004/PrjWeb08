CREATE function      F_GET_SALE0405H_SILJUK_SAWON
        ( A_CUST_ID      VARCHAR2, -- 직납처
          A_RCUST_ID     VARCHAR2, -- 간납처
          A_ITEM_ID      VARCHAR2, -- 제품코드
          A_YMD          DATE,      -- 전표일자 
          A_REQ_GB      VARCHAR2 -- 요청구분
        )
   RETURN VARCHAR2
AS
   ERROR_1       exception  ;  
   ERROR_2       exception  ;  
   v_siljuk_sawon_id varchar2(10);
   v_siljuk_sawon_nm varchar2(20);
   v_siljuk_dept_cd varchar2(10);
   v_siljuk_dept_nm varchar2(30);
   v_siljuk_rcust_nm varchar2(50);
   n_rtn_value    VARCHAR2(250);
   v_curr_error   VARCHAR2(250);

/*----------------------------------------------------------------
  이력관리적용부터 사용되는 평션 (2010.01.01 일부터 유효) 
    ==============================================================
   <주의사항> - RETURN갑시이 정상적이 않을을 처리하기 위한 방법  
      1.사원코드등록에 (00000)미지정으로 사원코드들 등록한다.
      2.부서코드등록에 (Z0)미지정으로 부서코들 등록한다.
      3.사원코드등록에서 '00000'코드에 부서코드'Z0'를 지정한다.
    ==============================================================
  생성일 : 2016.06.07 
  생성자 : 김태안
  설  명 : 거래처별 매출처별 제품별 단가이력에서 당시의 실적사원을 가져온다. 실적사원가져오는 함수가 몇개 되는데 이 함수로 통합하려고 만들어 본다.
           
  변경기록:2016.06.07 - 주문일자는 시행종료일자가 아니면 미지정  
    
  호출위치: d_sale01r01_new_02_01  
        d_sale01r01_new_06_01
        d_sale01r01_new_06_02
               
----------------------------------------------------------------*/
BEGIN
     
    /*
     담당자변경시 실적은 1일자 기준으로 모두 넘겨 주므로 실적사원은 매출처별제품단가이력 에서 가져올때
     적용시작일과 시행종료일자를 기준으로 가져와야 함 
    */
    BEGIN
        SELECT /*+ index_desc(A SALE0405H_PK) */
               a.sawon_id
          into v_siljuk_sawon_id     
          FROM SALE0405H A
         WHERE CUST_ID     = A_CUST_ID
           AND RCUST_ID    = A_RCUST_ID
           AND ITEM_ID     = A_ITEM_ID                   
           AND APPL_DATE   = (  SELECT /*+ index_desc(A SALE0405H_01) */ 
                                       APPL_DATE
                                  FROM SALE0405H A
                                 WHERE CUST_ID     = A_CUST_ID
                                   AND RCUST_ID    = A_RCUST_ID
                                   AND ITEM_ID     = A_ITEM_ID                   
                                   AND YMD        >= A_YMD                       
                                   AND APPL_DATE  <= TO_CHAR(A_YMD, 'YYYYMMDD')    
                                   AND ROWNUM      = 1
                              ) 
           AND ROWNUM = 1;
    
    EXCEPTION  
         WHEN NO_DATA_FOUND THEN
            RAISE ERROR_1; 
         WHEN OTHERS THEN
            RAISE ERROR_2; 
    END;
    
    IF A_REQ_GB = 'S' THEN  --사원코드
       n_rtn_value := v_siljuk_sawon_id;
       
    ELSIF A_REQ_GB = 'SM' THEN  --사원명
       SELECT sawon_nm into v_siljuk_sawon_nm from SALE0007H A where sawon_id =  v_siljuk_sawon_id and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1;
       n_rtn_value := v_siljuk_sawon_nm;
       
    ELSIF A_REQ_GB = 'D' THEN  --부서코드
       SELECT /*+ index_desc(A IE_SALE0007H_02) */ dept_cd into v_siljuk_dept_cd from SALE0007H A where sawon_id =  v_siljuk_sawon_id and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1;
       n_rtn_value := v_siljuk_dept_cd;
       
    ELSIF A_REQ_GB = 'DM' THEN --부서명
       SELECT /*+ index_desc(A IE_SALE0007H_02) */ F_GET_NAME('SALE0008',dept_cd,'') into v_siljuk_dept_nm from SALE0007H A where sawon_id =  v_siljuk_sawon_id and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1;
       n_rtn_value := v_siljuk_dept_nm;
               
    ELSIF A_REQ_GB = 'SMDM' THEN --사원명_부서명
       SELECT sawon_nm into v_siljuk_sawon_nm from SALE0007H A where sawon_id =  v_siljuk_sawon_id and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1;
       SELECT /*+ index_desc(A IE_SALE0007H_02) */ F_GET_NAME('SALE0008',dept_cd,'') into v_siljuk_dept_nm from SALE0007H A where sawon_id =  v_siljuk_sawon_id and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1;
       n_rtn_value := v_siljuk_sawon_nm||' '||v_siljuk_dept_nm;
       
    ELSIF A_REQ_GB = 'CMSMDM' THEN  --거래처명_사원명_부서명
       SELECT /*+ index_desc(A PK_SALE0003H) */ F_GET_NAME('SALE0003',cust_id,'') into v_siljuk_rcust_nm   from SALE0003H A where cust_id = A_CUST_ID and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1; 
       SELECT sawon_nm into v_siljuk_sawon_nm from SALE0007H A where sawon_id =  v_siljuk_sawon_id and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1;
       SELECT /*+ index_desc(A IE_SALE0007H_02) */ F_GET_NAME('SALE0008',dept_cd,'') into v_siljuk_dept_nm from SALE0007H A where sawon_id =  v_siljuk_sawon_id and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1;
       n_rtn_value := v_siljuk_rcust_nm ||' '||v_siljuk_sawon_nm||' '||v_siljuk_dept_nm;

    ELSIF A_REQ_GB = 'RCMSMDM' THEN  --매출처명_사원명_부서명
       SELECT /*+ index_desc(A PK_SALE0003H) */ F_GET_NAME('SALE0003',cust_id,'') into v_siljuk_rcust_nm   from SALE0003H A where cust_id = A_RCUST_ID and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1; 
       SELECT sawon_nm into v_siljuk_sawon_nm from SALE0007H A where sawon_id =  v_siljuk_sawon_id and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1;
       SELECT /*+ index_desc(A IE_SALE0007H_02) */ F_GET_NAME('SALE0008',dept_cd,'') into v_siljuk_dept_nm from SALE0007H A where sawon_id =  v_siljuk_sawon_id and appl_date <= TO_CHAR(A_YMD, 'YYYYMMDD') and rownum = 1;
       n_rtn_value := v_siljuk_rcust_nm ||' '||v_siljuk_sawon_nm||' '||v_siljuk_dept_nm;
       
    END IF;
    
    RETURN n_rtn_value;
    
            
EXCEPTION  
     WHEN ERROR_1 THEN
          RETURN '미지정';   
     WHEN ERROR_2 THEN
          RAISE_APPLICATION_ERROR(-20002, substrb(A_CUST_ID||'-'||A_RCUST_ID||'-'||A_ITEM_ID||'-'||SQLERRM,1,250));
END;
/
