CREATE FUNCTION      F_TEAMWON_GB  
(
    in_SAWON_ID  IN  VARCHAR2
) 
RETURN VARCHAR2 IS

    v_temp     VARCHAR2(5);
    v_return   VARCHAR2(20);
    
--사원코드받아서 팀장이면 'D' 아니면 'P'
    
BEGIN

   SELECT ASSGN_CD
     INTO v_temp
     FROM hr_hc_empbas_0 
    WHERE EMP_NO = (SELECT INSA_SAWON_ID FROM SALE0007 WHERE SAWON_ID = in_SAWON_ID );
   
   if  v_temp = '27040' then  --팀원
       v_return := 'P';
   else
       v_return := 'D';   
   end if;
     
        
   RETURN v_return;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;
/
