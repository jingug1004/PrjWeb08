CREATE PROCEDURE      SP_SFA_OFFICE_10_UPDATE_105
(
    in_CARD_NO           IN VARCHAR2,      -- 카드번호
    in_USE_DT            IN VARCHAR2,      -- 사용일자
    in_USE_TM            IN VARCHAR2,      -- 사용시간
    in_CARD_OK_NO        IN VARCHAR2,      -- 카드승인번호
    in_USE_GUBUN         IN VARCHAR2,      -- 사용구분(03:매입, 04:매입취소)
    in_PHOTO             IN BLOB,          -- 영수증 사진(처리방식:앱에서 서버 사진 업로드, 서버에서 BLOB UPDATE처리)
    in_PHOTO_NM          IN VARCHAR2,      -- 영수증 사진명
    in_GONGJAE_YN        IN VARCHAR2,      -- 공제여부 (1:선택안함, 2:공제, 3:비공제)
    in_USE_DETAIL        IN VARCHAR2,      -- 사용내용 상세
    in_GAEJUNG_CD        IN VARCHAR2,      -- 계정코드
    in_DEDUCTION_YN_CD   IN VARCHAR2,      -- 부가세공제불가항목코드 
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2 
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 정산관리_사진저장  
 호출프로그램 :110 버전으로 대체됨        
 ---------------------------------------------------------------------------*/    


    v_num                NUMBER;
    v_num1               NUMBER;
    v_case               VARCHAR2(100);
    
    CARD_NO_NULL         EXCEPTION;
    USE_DT_NULL          EXCEPTION;
    USE_TM_NULL          EXCEPTION;
    CARD_OK_NO_NULL      EXCEPTION;
    USE_GUBUN_NULL       EXCEPTION;
    PHOTO_NULL           EXCEPTION;
    PHOTO_NM_NULL        EXCEPTION;
    GONGJAE_YN_NULL      EXCEPTION;
    GAEJUNG_CD_NULL      EXCEPTION;

BEGIN 
    
    --insert into SFA_SP_CALLED_HIST   values ('SP_SFA_OFFICE_10_UPDATE_105','1',sysdate,'in_CARD_NO:'||in_CARD_NO||'/in_GONGJAE_YN:'||in_GONGJAE_YN);
    --COMMIT;

    CASE
        WHEN in_CARD_NO    IS NULL THEN RAISE CARD_NO_NULL;
        WHEN in_USE_DT     IS NULL THEN RAISE USE_DT_NULL;
        WHEN in_USE_TM     IS NULL THEN RAISE USE_TM_NULL;
        WHEN in_CARD_OK_NO IS NULL THEN RAISE CARD_OK_NO_NULL;
        WHEN in_PHOTO      IS NULL THEN RAISE PHOTO_NULL;
        WHEN in_PHOTO_NM   IS NULL THEN RAISE PHOTO_NM_NULL;
        ELSE v_case := 'NULL 체크 이상없음';
    END CASE;
     
    v_num := 0;
   SELECT COUNT(*) 
     INTO v_num
     FROM SALE0601
    WHERE CARD_NO     = in_CARD_NO
      AND USE_DT      = in_USE_DT
      AND USE_TM      = in_USE_TM
      AND CARD_OK_NO  = in_CARD_OK_NO
      AND USE_GUBUN   = in_USE_GUBUN;
       
    --out_COUNT := v_num;
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '정보가 존재하지 않습니다.'; 
     
    ELSIF (v_num = 1) THEN
        out_CODE := 0;
        out_MSG := '정보 확인완료';
        
        -- 사진 정보 테이블에 ROW 존재유무 체크
        SELECT COUNT(*)
          INTO v_num1
          FROM SALE0603
         WHERE CARD_NO    = in_CARD_NO
           AND USE_DT     = in_USE_DT
           AND USE_TM     = in_USE_TM
           AND CARD_OK_NO = in_CARD_OK_NO;
        
        IF v_num1 = 0 THEN   -- ROW 가 존재하지 않은 경우 INSERT
            INSERT INTO SALE0603(CARD_NO, USE_DT, USE_TM, CARD_OK_NO, PHOTO1_NM, PHOTO1)
                        VALUES(in_CARD_NO, in_USE_DT, in_USE_TM, in_CARD_OK_NO, in_PHOTO_NM, in_PHOTO);
             
        END IF;
         
           
 
        -- 사진 , 사진 파일명 등록. 사진 BLOB은 웹서버에서 자동 처리. (APP 파일 서버 등록 시 자동 BLOB 처리)
        UPDATE SALE0603
           SET PHOTO1      = in_PHOTO
             , PHOTO1_NM   = in_PHOTO_NM  -- PHOTO1      = utl_raw.cast_to_raw(in_PHOTO)  -- select할때는 utl_raw.cast_to_varchar2(col)
         WHERE CARD_NO     = in_CARD_NO
             AND USE_DT      = in_USE_DT
             AND USE_TM      = in_USE_TM
           AND CARD_OK_NO  = in_CARD_OK_NO;  
                   
        -- 정산 테이블 수정. in_GONGJAE_YN = '999' 인경우 'Y', 그외 'N'
        UPDATE SALE0601
           SET GONGJAE_YN        = decode(in_GONGJAE_YN,'1',null,'2','Y','3','N')
             , USE_DETAIL        = in_USE_DETAIL
             , JUKYO             = in_USE_DETAIL
             , GAEJUNG_CD        = in_GAEJUNG_CD
             , TEAMJANG_CONF_YN  = 'Y'
             , DEDUCTION_YN_CD   = in_DEDUCTION_YN_CD
         WHERE CARD_NO     = in_CARD_NO
            AND USE_DT      = in_USE_DT
            AND USE_TM      = in_USE_TM
            AND CARD_OK_NO  = in_CARD_OK_NO
            AND USE_GUBUN   = in_USE_GUBUN;
        
        out_CODE := 0;
        out_MSG := '정산처리가 완료되었습니다.';
    END IF;
  
EXCEPTION
WHEN CARD_NO_NULL THEN
   out_CODE := 101;
   out_MSG := '카드번호가 누락되었습니다.';  
WHEN USE_DT_NULL THEN
   out_CODE := 102;
   out_MSG := '카드 사용일자가 누락되었습니다.';  
WHEN USE_TM_NULL THEN
   out_CODE := 103;
   out_MSG := '카드 사용시간이 누락되었습니다.';  
WHEN CARD_OK_NO_NULL THEN
   out_CODE := 104;
   out_MSG := '카드 승인번호가 누락되었습니다.';     
WHEN USE_GUBUN_NULL THEN
   out_CODE := 105;
   out_MSG := '카드 사용구분이 누락되었습니다.';   
WHEN PHOTO_NULL THEN
   out_CODE := 106;
   out_MSG := '증빙사진이 누락되었습니다.';  
WHEN PHOTO_NM_NULL THEN
   out_CODE := 107;
   out_MSG := '증빙사진명이 누락되었습니다.';  
WHEN GONGJAE_YN_NULL THEN
   out_CODE := 108;
   out_MSG := '공제여부가 누락되었습니다.';  
WHEN GAEJUNG_CD_NULL THEN
   out_CODE := 109;
   out_MSG := '계정과목이 누락되었습니다.';       
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
   DBMS_OUTPUT.PUT_LINE('out_MSG'||out_MSG  );
END;

/
