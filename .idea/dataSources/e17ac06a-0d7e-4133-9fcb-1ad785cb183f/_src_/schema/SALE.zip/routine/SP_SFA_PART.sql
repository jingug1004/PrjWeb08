CREATE PROCEDURE      SP_SFA_PART
(
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
BEGIN
 /*---------------------------------------------------------------------------
 프로그램명   : PART 검색
 호출프로그램 :  실적현황OPEN시      
   2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    

    
    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.CMDEPTM
     WHERE LEVEL = 2
       AND useyn = 'Y'
   CONNECT BY PRIOR deptcode = predeptcode
     START WITH  plantcode = '1000' and  deptcode = '0023'  --영업부 ‘0023’     
     ORDER BY seq;
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT deptcode       AS out_PART_CD    -- PART 번호
             , deptname       AS out_PART_NM    -- PART 명
          FROM ORAGMP.CMDEPTM
         WHERE LEVEL = 2
           AND useyn = 'Y'
       CONNECT BY PRIOR deptcode = predeptcode
         START WITH  plantcode = '1000' and  deptcode = '0023'  --영업부 ‘0023’     
         ORDER BY seq;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
