CREATE PROCEDURE      SP_X_MYPL_PLITEMCNT
(
    in_ITEM_KIND1 IN VARCHAR2,
    in_ITEM_KIND2 IN VARCHAR2,
    in_ITEM_NAME  IN VARCHAR2,
    out_CNT      OUT NUMBER,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_MYPL_PLITEMCNT
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명   : P/L 용 전체 목록 수 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    SELECT count(*) INTO out_CNT
		  FROM SALE.SFA_OFFICE_ITEMDOC A,
		  	   SALE.SALE0001 B
    	 WHERE B.CODE1 = A.ITEM_KIND2
    	   AND B.CODE_GB = '0071'
		   AND A.ITEM_KIND1 = in_ITEM_KIND1
 		   AND A.ITEM_KIND2 = in_ITEM_KIND2
	  	   AND A.ITEM_NAME LIKE '%' ||in_ITEM_NAME|| '%';
			
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
