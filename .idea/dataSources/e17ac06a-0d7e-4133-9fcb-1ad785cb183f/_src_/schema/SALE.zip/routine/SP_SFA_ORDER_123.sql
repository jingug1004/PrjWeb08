CREATE PROCEDURE      SP_SFA_ORDER_123 (
        in_FLAG               IN VARCHAR2 DEFAULT NULL,
        in_YMD                IN date,
        in_GUMAE_NO           IN VARCHAR2 default NULL,
        in_SAWON_ID           IN VARCHAR2 default NULL, --로그인사번
        in_CUST_ID            IN VARCHAR2 default NULL,
        in_RSAWON_ID          IN VARCHAR2 default NULL,
        in_RCUST_ID           IN VARCHAR2 default NULL,
        in_BAESONJI           IN VARCHAR2 DEFAULT NULL,
        in_AMT_SUM            IN VARCHAR2 default NULL,
        in_VAT_SUM            IN VARCHAR2 default NULL,
        in_BIGO               IN VARCHAR2 default NULL,
        in_WIBAN_KIND         IN VARCHAR2 default NULL,
        in_COUNT              IN NUMBER,
        in_DATASET            IN VARCHAR2 default NULL,
        out_CODE              OUT NUMBER,
        out_MSG               OUT VARCHAR2       
        )
IS
    /*---------------------------------------------------------------------------
    프로그램명   : 주문등록(주문마스터와 주문상세를 모두 이곳에서 처리)
    호출프로그램 : 주문서등록의 등록버튼,       
    수정기록     :
    2013.01.30/ 김태안/ 주문프로세서 재정리에 따라 로직 수정함(윤홍주차장요청)
        <개요>신규처도 수량체크,회전일180초과시주문불가,월평균판매량,월평균판매금액적용.
          
        -SFA 주문등록 화면에서 회전일이 180일을 넘는 거래처는 주문불가 하도록 처리함.
        -신규처 개월수 = 0 일때 해당월판매량이 20개이상이면 return
        개월수 <>0 일때 해당월판매량20개이상이면 월평균판매량의1.5배이상일때 return
        해당월판매량20개이하이면 월평균판매량의1.5배이상일때 월평균판매금액의1.5배이상일때 return
        -기존처:해당월판매량20개이상이면 월평균판매량의1.5배이상일때 return
        해당월판매량20개이하이면 월평균판매량의1.5배이상일때 월평균판매금액의1.5배이상일때 return
        2.2013.03.04/김태안/거래처회전일을 위한 에이징이 전달로 생성이 안되어있으면 주문불가      
        3.2014.04.03/김태안/주문위반(회전일,수량) 주문을 할수 있도록 로직추가함.
        - in_BIGO는 사용하지 않으므로  를 위반약속내용 용도로 사용하고 PBIGO 컬럼에 넣는다.
        4.2015.01.30/김태안/적용율추가  거래처별단가에 있음.  
        5.2016.05.04/김태안/주문합계금액이 0인경우 주문불가체크 추가
        6.2017.04.03/김태안/사업장101 을 100 으로 변경하면서 100 에 대한 로직 추가함.다른사업장의 제품제어부분 수정         
        7. CHOE 20170727 위반 주문 등록시 본부장인 직접 주문을 넣은 경우 승인 된 것으로 처리         
        8.2017.09.19/김태안/비급여품목인경우 매출처별단가등록에 단가등록되어있지 않으면 주문불가처리   
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼 
    2017.11.28 YMB - 배송지순번 컬럼추가
   ---------------------------------------------------------------------------*/
        v_empcode   VARCHAR2(10);  --거래처담당사번
        v_eempcode  VARCHAR2(10);  --간납처담당사번
        v_deptcode  VARCHAR2(4);   --거래처담당사번의 소속부서
        v_edeptcode VARCHAR2(4);   --간납처담당사번의 소속부서 
        v_orderno   VARCHAR2(14);  --채번한 주문번호

        ll_loop     NUMBER := 0;  
        v_ITEM_ID   VARCHAR2(10);
        v_QTY       VARCHAR2(13);
        v_DANGA     VARCHAR2(13);
        v_AMT       VARCHAR2(13);
        v_VAT       VARCHAR2(13); 
        
        --사업장이다른 제품 섞여있는지 체크용
        v_mplantcode VARCHAR2(4);  --사업장        
        v_cnt_1001   NUMBER;
        v_cnt_1002   NUMBER;
        v_cnt_2001   NUMBER;
        v_cnt_2002   NUMBER;
        
        --주문마스터와상세의 금액합계 비교용
        v_amt_sumadd NUMBER; 
         
        v_wiban_order_conf_status VARCHAR2(1);
        v_wiban_order_conf_dtm DATE;
        v_classdiv  VARCHAR2(13); 
        
        --에러처리    
        ERROR_RAISE EXCEPTION; 
    
        v_retmsg VARCHAR2(400);  
        
        --거래처체크
        SLORDCHECK_CURSOR    oragmp.types.DataSet;
        p_creditck                VARCHAR2(30);
        p_sagock                  VARCHAR2(30);
        p_loanlmtck               VARCHAR2(30);
        p_balancelmtck            VARCHAR2(30);
        p_nocollmtck              VARCHAR2(30);
        p_securitylmtck           VARCHAR2(30);
        p_turnlmtck               VARCHAR2(30); 
    
BEGIN

        ----------------------------------------------------------------------------
        --주문마스터 시작 : 주문서의 삭제 수정은 SFA 에서는 불가함
        ----------------------------------------------------------------------------
        IF in_FLAG = 'I' THEN         

                
            --주문일자와 시스템일자 체크 
            IF TO_CHAR(in_YMD, 'YYYYMMDD') <> TO_CHAR(SYSDATE, 'YYYYMMDD') THEN
               out_MSG := '주문일자가 다릅니다. 확인 후 다시 주문등록해 주시기 바랍니다.';
               RAISE ERROR_RAISE;    
            END IF; 

            --주문거래처의 담당사번및소속부서
            select empcode,deptcode into v_empcode,v_deptcode from ORAGMP.CMCUSTM where plantcode = '1000' and custcode = in_CUST_ID;
                
            --판매처의 담당사번및소속부서
            select empcode,deptcode into v_eempcode,v_edeptcode from ORAGMP.CMCUSTM where plantcode = '1000' and custcode = in_RCUST_ID;
            
            --로그인사번의 직책및 소속부서                 
            select classdiv,deptcode into v_classdiv,v_deptcode from ORAGMP.CMEMPM  where empcode = in_SAWON_ID;    
            
            --로그인 사원이 팀원아니면 위반승인인경우 자동승인                
            v_wiban_order_conf_status := '0';  -- 0-대기,1-승인,2-반려 지점장이 처리
            IF  in_WIBAN_KIND <> '0' THEN   --0-정상,1-회전일,2-수량                                            
                IF v_classdiv  = '27040' THEN  --팀원이면
                   v_wiban_order_conf_status := '0';  
                ELSE
                   v_wiban_order_conf_status := '1';  
                   v_wiban_order_conf_dtm    := SYSDATE;--to_char(sysdate,'yyyymmddhh24miss');                   
                END IF; 
            END IF;     
            
            --주문번호채번 
            SELECT MAX(ORDERNO) into v_orderno from ORAGMP.SLORDM where plantcode = '1000' and orderdate = to_char(in_YMD,'YYYY-MM-DD');
            IF SQLCODE <> 0 THEN
               out_CODE := 10610;
               out_MSG := '주문번호 채번오류';
               RAISE ERROR_RAISE;
            ELSE
               IF v_orderno is null THEN
                  v_orderno := trim(to_char(to_number(to_char(in_YMD,'YYYYMMDD')))||'0001');
               ELSE
                  v_orderno := trim(to_char(to_number(v_orderno) + 1,'000000000000'));
               END IF;
            END IF;
            
            
            --주문전 체크 -------------------------------------------------------------- 
            
            --거래처코두 3번 4번 대 거래처만 주문허용- kta 2016.09.08 
            if Not(substr(in_CUST_ID,1,1) = '3' or substr(in_CUST_ID,1,1) = '4') then
                out_CODE := 101;
                out_MSG := '직거래처만 거래처로 선택하셔야 합니다';
                RAISE ERROR_RAISE;
            end if;         
    
            
            --거래처체크   
            OPEN SLORDCHECK_CURSOR FOR  
            SELECT * FROM TABLE(ORAGMP.fnSLordCheck('1000', to_char(in_YMD,'YYYY-MM-DD'), to_char(in_YMD,'YYYY-MM'), in_CUST_ID, 'SFA')); 
            LOOP
                FETCH SLORDCHECK_CURSOR INTO p_creditck,p_sagock,p_loanlmtck,p_balancelmtck,p_nocollmtck,p_securitylmtck,p_turnlmtck;
                EXIT WHEN SLORDCHECK_CURSOR%NOTFOUND ;   
                --balancelmtck    - 잔고 한도 체크 
                --nocollmtck    - 무수금한도 체크 
                --securitylmtck    - 담보가치한도 체크 
                --turnlmtck    - 회전일한도 체크 
                
                if p_creditck = '*' then  --creditck      - 신용불량 체크
                    out_CODE := 101;
                    out_MSG := '신용불량 거래처 입니다.';
                    RAISE ERROR_RAISE;
                elsif p_sagock = '*' then  --sagock      - 사고처 체크                    
                    out_CODE := 101;
                    out_MSG := '사고 거래처 입니다.';
                    RAISE ERROR_RAISE;
                elsif p_loanlmtck = '*' then   --loanlmtck    - 여신한도 체크
                    out_CODE := 101;
                    out_MSG := '여신한도 초과 거래처 입니다.';
                    RAISE ERROR_RAISE;
                else                  
                    out_CODE := 1;     --0이면 out_MSG 가 client에 넘어가지 않음.
                    out_MSG := '정상'; --이곳을 타면 수량은 정상임..                
                end if;   
                
            END LOOP;
            CLOSE SLORDCHECK_CURSOR;              
             
            --주문마스터 INSERT
            BEGIN 
                    INSERT INTO ORAGMP.SLORDM(
                               PLANTCODE            --사업장                                                              
                              ,ORDERNO              --주문번호                                                            
                              ,ORDERDATE            --주문일자                                                            
                              ,ORDERSEQ             --주문일련번호                                                        
                              ,SALDIV               --영업구분      A01:판매                                              
                              ,DATADIV              --자료구분      11:직납,12:간납                                       
                              ,ORDERDIV             --영업영역      3:간납, 4:직납                                        
                              ,OUTPUTDIV            --출하구분      1:택배, 9:직배                                        
                              ,TRANSFERDIV          --배송구분      1:거래선착                                            
                              ,CUSTCODE             --거래처                                                              
                              ,DEPTCODE             --부서코드                                                            
                              ,EMPCODE              --담당자코드                                                          
                              ,ECUSTCODE            --간납처코드                                                          
                              ,EDEPTCODE            --영업소(간납)                                                        
                              ,EEMPCODE             --담당자(간납)                                                        
                              ,UTDIV                --거래처유통구분                                                      
                              ,EUTDIV               --간납처유통구분                                                      
                              ,BNORDERNO            --상계주문번호(출하번호)                                              
                              ,TAXDATE              --세금계산서 발행일자                                                 
                              ,TRADEDATE            --거래명세서 발행일자                                                 
                              ,TAXMANAGEDATE        --세금계산서 발행일자                                                 
                              ,TRADEMANAGEDATE      --거래명세서 발행일자                                                 
                              ,FIXDATE              --주문확정일자                                                        
                              ,FIXSEQ               --주문확정차수                                                        
                              ,CREDITCK             --신용불량                                                            
                              ,SAGOCK               --사고처                                                              
                              ,LOANLMTCK            --여신한도                                                            
                              ,BALANCELMTCK         --잔고한도                                                            
                              ,NOCOLLMTCK           --무수금한도                                                          
                              ,SECURITYLMTCK        --담보가치한도                                                        
                              ,AVGAMTLMTCK          --평균판매금액한도                                                    
                              ,SAMPCK               --샘플출고체크                                                        
                              ,TURNLMTCK            --회전일한도                                                          
                              ,APPDATE              --출고일자                                                            
                              ,YYMM                 --출고년월                                                            
                              ,STATEDIV             --상태구분  01-입력 03-채권불량 09-매출확정 99-반려                   
                              ,REMARK               --비고                                                                
                              ,BIGO                 --비고2                                                               
                              ,WAREHOUSE            --창고구분                                                            
                              ,APPRSTATUS           --진행상태  00-등록 01-상신                                           
                              ,INSERTDT             --입력일자                                                            
                              ,IEMPCODE             --입력사번                                                            
                              ,UPDATEDT             --수정일자                                                            
                              ,UEMPCODE             --수정사번       
                              ,ADDRSEQ              --배송지 순번                                                       
                              ,ORDERKIND            --주문종류              10:온라인 20:SFA 30:ERP     
                              ,CLEANDATE            --매출할인일자                                                        
                              ,CLEANSEQ             --매출할인일자작업순번                                                
                              ,THREEAVGCK           --3개월 주문수량 위반여부                                             
                              ,WIBANORDERREQYN      --위반오더요청여부:주문사원이 요청함                                  
                              ,WIBANORDERCONFSTATUS --위반오더승인상태      0-대기,1-승인,2-반려 지점장이 처리            
                              ,WIBANKIND            --위반유형              0-정상,1-회전일,2-수량                        
                              ,WIBANCONFDTM         --위반오더 지점장승인일시                                                                                              
                           )
                    VALUES (
                         '1000'                                                                 --PLANTCODE            --사업장     
                         ,v_orderno                                                             --ORDERNO              --주문번호      
                         ,TO_CHAR(in_YMD,'YYYY-MM-DD')                                          --ORDERDATE            --주문일자  
                         ,SUBSTR(v_orderno,9,4)                                                 --ORDERSEQ             --주문일련번호  
                         ,'A01'                                                                 --SALDIV               --영업구분      A01:판매
                         ,CASE WHEN in_CUST_ID = in_RCUST_ID THEN '11' ELSE '12' END            --DATADIV              --자료구분      11:직납,12:간납 
                         ,CASE WHEN in_CUST_ID = in_RCUST_ID THEN '4'  ELSE '4'  END            --ORDERDIV             --영업영역      3:간납, 4:직납
                         ,'1'                                                                   --OUTPUTDIV            --출하구분      1:택배, 9:직배
                         ,'1'                                                                   --TRANSFERDIV          --배송구분      1:거래선착
                         ,in_CUST_ID                                                            --CUSTCODE             --거래처  
                         ,v_deptcode                                                            --DEPTCODE             --부서코드  
                         ,v_empcode                                                             --EMPCODE              --담당자코드  
                         ,in_RCUST_ID                                                           --ECUSTCODE            --간납처코드  
                         ,v_edeptcode                                                           --EDEPTCODE            --영업소(간납)  
                         ,v_eempcode                                                            --EEMPCODE             --담당자(간납)  
                         ,''                                                                    --UTDIV                --거래처유통구분   
                         ,''                                                                    --EUTDIV               --간납처유통구분  
                         ,''                                                                    --BNORDERNO            --상계주문번호(출하번호)  
                         ,''                                                                    --TAXDATE              --세금계산서 발행일자  
                         ,''                                                                    --TRADEDATE            --거래명세서 발행일자  
                         ,''                                                                    --TAXMANAGEDATE        --세금계산서 발행일자  
                         ,''                                                                    --TRADEMANAGEDATE      --거래명세서 발행일자  
                         ,''                                                                    --FIXDATE              --주문확정일자 
                         ,''                                                                    --FIXSEQ               --주문확정차수 
                         ,'N'                                                                   --CREDITCK             --신용불량 
                         ,'N'                                                                   --SAGOCK               --사고처 
                         ,'N'                                                                   --LOANLMTCK            --여신한도 
                         ,'N'                                                                   --BALANCELMTCK         --잔고한도 
                         ,'N'                                                                   --NOCOLLMTCK           --무수금한도 
                         ,'N'                                                                   --SECURITYLMTCK        --담보가치한도 
                         ,'N'                                                                   --AVGAMTLMTCK          --평균판매금액한도 
                         ,'N'                                                                   --SAMPCK               --샘플출고체크 
                         ,'N'                                                                   --TURNLMTCK            --회전일한도 
                         ,''                                                                    --APPDATE              --출고일자  
                         ,''                                                                    --YYMM                 --출고년월 
                         ,DECODE(in_BIGO,null,'88','03')                                        --STATEDIV             --상태구분  01-입력 03-채권불량 09-매출확정 99-반려
                         ,in_BIGO                                                               --REMARK               --비고 
                         ,''                                                                    --BIGO                 --비고2
                         ,'001'                                                                 --WAREHOUSE            --창고구분 
                         ,'01'                                                                  --APPRSTATUS           --진행상태  00-등록 01-상신
                         ,SYSDATE                                                               --INSERTDT             --입력일자 
                         ,in_SAWON_ID                                                           --IEMPCODE             --입력사번 
                         ,SYSDATE                                                               --UPDATEDT             --수정일자
                         ,in_SAWON_ID                                                           --UEMPCODE             --수정사번
                         ,in_BAESONJI                                                           --ADDRSEQ              --배송지 순번
                         ,'20'                                                                  --ORDERKIND            --주문종류              10:온라인 20:SFA 30:ERP
                         ,''                                                                    --CLEANDATE            --매출할인일자 
                         ,0                                                                     --CLEANSEQ             --매출할인일자작업순번 
                         ,'?'                                                                   --THREEAVGCK           --3개월 주문수량 위반여부
                         ,DECODE(in_BIGO,null,'N','Y')                                          --WIBANORDERREQYN      --위반오더요청여부:주문사원이 요청함
                         ,v_wiban_order_conf_status                                             --WIBANORDERCONFSTATUS --위반오더승인상태      0-대기,1-승인,2-반려 지점장이 처리
                         ,NVL(in_WIBAN_KIND,'0')                                                --WIBANKIND            --위반유형           0-정상,1-회전일,2-수량
                         ,v_wiban_order_conf_dtm                                                --WIBANCONFDTM         --위반오더 지점장승인일시 
                    );
                                         
            EXCEPTION 
                    WHEN OTHERS THEN  
                    out_CODE := 109;
                    out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM||'- v_orderno:'||v_orderno);
                    RAISE ERROR_RAISE;         
            END; 



            --------------------------------------------------------------------------
            --주문상세 시작
            --------------------------------------------------------------------------
            v_cnt_1001 := 0;
            v_cnt_1002 := 0;
            v_cnt_2001 := 0;
            v_cnt_2002 := 0;   
            v_amt_sumadd := 0;  
       
            -- 사업장이 석여있는 제품이 들어오면 허용불가..
            --client 에서 제조사업장이 다른 제품이 들어오는것은 막았는데 아직 업그레이드 하지 않아서...
            FOR ll_loop IN 1.. in_COUNT LOOP 

                v_ITEM_ID  := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 1 +61*(ll_loop -1),  10)); --v_ITEM_ID
                v_QTY      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 11+61*(ll_loop -1),  12)); --v_QTY
                v_DANGA    := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 23+61*(ll_loop -1),  13)); --v_DANGA
                v_AMT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 36+61*(ll_loop -1),  13)); --v_AMT
                v_VAT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 49+61*(ll_loop -1),  13)); --v_VAT
            
                v_mplantcode := '';
                SELECT a.mplantcode INTO v_mplantcode FROM ORAGMP.CMITEMM A WHERE a.itemcode  = v_ITEM_ID;
            
                if v_mplantcode = '2001' then  --하길마약,일반
                      v_cnt_2001 := 1;
                elsif v_mplantcode = '1001' then --도매지점
                      v_cnt_1001 := 1;
                elsif v_mplantcode = '1002' then --도매향정
                      v_cnt_1002 := 1;
                elsif v_mplantcode = '2002' then --하길향정
                      v_cnt_2002 := 1;
                end if;
            
                --제품금액누적
                v_amt_sumadd := v_amt_sumadd + v_AMT;

            END LOOP;
        
            if  v_cnt_2001 + v_cnt_1001 + v_cnt_1002 + v_cnt_2002 > 1 then
                    out_CODE := -20000;
                    out_MSG := '동일사업장이 아닌 제품이 섞여 있습니다.주문을 분리하십시오.';
                    RAISE ERROR_RAISE;            
            end if;                       
 
            if  TO_NUMBER(in_AMT_SUM) = 0 then
                    out_CODE := -20000;
                    out_MSG := '주문금액 0원은 주문불가 합니다';
                    RAISE ERROR_RAISE;            
            end if;                    
 
            if  TO_NUMBER(in_AMT_SUM)  <> v_amt_sumadd then
                    out_CODE := -20000;
                    out_MSG := '주문금액과 제품합계금액이 틀립니다.확인하십시오.';
                    RAISE ERROR_RAISE;            
            end if;                 
            
            FOR ll_loop IN 1.. in_COUNT LOOP 

                v_ITEM_ID  := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 1 +61*(ll_loop -1),  10)); --v_ITEM_ID
                v_QTY      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 11+61*(ll_loop -1),  12)); --v_QTY
                v_DANGA    := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 23+61*(ll_loop -1),  13)); --v_DANGA
                v_AMT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 36+61*(ll_loop -1),  13)); --v_AMT
                v_VAT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 49+61*(ll_loop -1),  13)); --v_VAT     

                --수량이 0이 아닌 경우만 처리
                if v_QTY is not null or v_QTY <> '' then  

                   
                   --제품체크 수량체크 ::이 체크로직은 SFA에서는 두곳에서 체크됨 : SP_Z_ORDER_CHECK 와 SP_Z_ORDR_123 
                    SELECT ORAGMP.fnSLordItemCheck('1000', to_char(in_ymd,'YYYYMMDD'), in_CUST_ID, in_CUST_ID, v_ITEM_ID, to_number(v_QTY), 'SFA', to_number(v_DANGA))
                      INTO v_retmsg
                      FROM DUAL; 
                        
                    IF SUBSTR(v_retmsg,1,1) = '0' THEN                     
                        out_CODE := 1;     --0이면 out_MSG 가 client에 넘어가지 않음.
                        out_MSG := '정상'; --이곳을 타면 수량은 정상임..
                    ELSIF SUBSTR(v_retmsg,1,2) = '10' THEN   
                        out_CODE := 2;     --0이면 out_MSG 가 client에 넘어가지 않음.
                        out_MSG := v_retmsg ||' - 주문은 가능합니다' ; --이곳을 타면 수량위반  
                    ELSE 
                        out_CODE := 3; 
                        out_MSG := v_retmsg; 
                    END IF;                      
                   
                    --사전할인율 계산
                    --비급여아닌경우 100 -(단가테이블 판매가/기준가 *100) 
                    --비급여인경우 100-
                    --기준단가 
                   
                    
                    --주문상세 INSERT
                    BEGIN
                       INSERT INTO ORAGMP.SLORDD (
                                ORDERNO     --주문번호
                               ,PLANTCODE   --사업장
                               ,SEQ         --일련번호
                               ,ORDERDATE   --주문일자
                               ,ORDERSEQ    --주문순번
                               ,ITEMCODE    --제품코드
                               ,SALQTY      --판매수량
                               ,GIVQTY      --증품(할증)수량
                               ,BONUSQTY    --추가증품수량
                               ,DRUGPRC     --기준가
                               ,DRUGAMT     --기준금액
                               ,MAKINGCOST  --제조원가
                               ,EXRTPRC
                               ,EXRTAMT
                               ,SALPRC      --단가
                               ,SALAMT      --매출액
                               ,SALVAT      --부가세
                               ,TOTAMT      --매출합계
                               ,BEFAMT      --사전
                               ,AFTAMT      --사후
                               ,INCAMT      --수수료
                               ,TOTDISCOUNT --총할인
                               ,GIVRATE     --할증비율
                               ,BEFRATE     --사전비율
                               ,AFTRATE     --사후비율
                               ,INCRATE     --수수료비율
                               ,SALPRC1     --출하단가1
                               ,SALAMT1     --공급가액1
                               ,SALVAT1     --부가세1
                               ,TOTAMT1     --총금액1
                               ,CUSTPRTYN   --거래장출력여부
                               ,OUTPUTQTY   --출하수량
                               ,RECALLDIV   --반품유형
                               ,ABSYN       --품절여부
                               ,PIECEYN     --낱알여부
                               ,ENURIYN     --매출할인정리구분
                               ,JUORDNO
                               ,BPQTY
                               ,LOTNO       --제조번호
                               ,EXPDATE     --유효기간
                               ,INSERTDT    --입력일자
                               ,IEMPCODE    --입력자 사번
                               ,UPDATEDT    --수정일자
                               ,UEMPCODE    --수정자 사번
                               ,AVGQTY      --평균수량
                               ,AVGQTYLMTCK
                               ,LOTDATE     --제조일자
                               ,PIECEQTY
                               ,REALOUTQTY
                               ,SUPPLYDIV   --공급구분
                               ,EMPCODE     --담당자 사번
                               ,ORDQTYBSUNIT--주문수량배수단위
                               ,OUTPROTYN   --퇴장방지여부
                               ,MPLANTCODE  --관리사업장
                               ,PAIDYN      --급여/비급여구분
                               ,REQQTY      --요청수량
                               ,THREEAVGCK  --
                              )
                       VALUES (
                                v_orderno                                                             --ORDERNO     --주문번호
                               ,'1000'                                                                --PLANTCODE   --사업장
                               ,ll_loop                                                               --SEQ         --일련번호
                               ,TO_CHAR(in_YMD,'YYYY-MM-DD')                                          --ORDERDATE   --주문일자
                               ,SUBSTR(v_orderno,9,4)                                                 --ORDERSEQ    --주문순번
                               ,v_ITEM_ID                                                             --ITEMCODE    --제품코드
                               ,v_QTY                                                                 --SALQTY      --판매수량
                               ,0                                                                     --GIVQTY      --증품(할증)수량
                               ,0                                                                     --BONUSQTY    --추가증품수량
                               ,0                                                                     --DRUGPRC     --기준가 
                               ,0                                                                     --DRUGAMT     --기준금액   
                               ,0                                                                     --MAKINGCOST  --제조원가
                               ,0                                                                     --EXRTPRC     
                               ,0                                                                     --EXRTAMT     
                               ,v_DANGA                                                               --SALPRC      --단가
                               ,v_AMT                                                                 --SALAMT      --매출액
                               ,v_VAT                                                                 --SALVAT      --부가세
                               ,v_AMT + v_VAT                                                         --TOTAMT      --매출합계
                               ,0                                                                     --BEFAMT      --사전
                               ,0                                                                     --AFTAMT      --사후
                               ,0                                                                     --INCAMT      --수수료
                               ,0                                                                     --TOTDISCOUNT --총할인
                               ,0                                                                     --GIVRATE     --할증비율
                               ,0                                                               --BEFRATE     --사전비율
                               ,0                                                                     --AFTRATE     --사후비율
                               ,0                                                                     --INCRATE     --수수료비율
                               ,0                                                                     --SALPRC1     --출하단가1
                               ,0                                                                     --SALAMT1     --공급가액1
                               ,0                                                                     --SALVAT1     --부가세1
                               ,0                                                                     --TOTAMT1     --총금액1
                               ,'Y'                                                                   --CUSTPRTYN   --거래장출력여부
                               ,v_QTY                                                                 --OUTPUTQTY   --출하수량
                               ,''                                                                    --RECALLDIV   --반품유형
                               ,'N'                                                                   --ABSYN       --품절여부
                               ,'N'                                                                   --PIECEYN     --낱알여부
                               ,''                                                                    --ENURIYN     --매출할인정리구분
                               ,''                                                                    --JUORDNO     
                               ,''                                                                    --BPQTY       
                               ,''                                                                    --LOTNO       --제조번호
                               ,''                                                                    --EXPDATE     --유효기간
                               ,SYSDATE                                                               --INSERTDT    --입력일자
                               ,in_SAWON_ID                                                           --IEMPCODE    --입력자 사번
                               ,SYSDATE                                                               --UPDATEDT    --수정일자 
                               ,in_SAWON_ID                                                           --UEMPCODE    --수정자 사번
                               ,0                                                                     --AVGQTY      --평균수량
                               ,''                                                                    --AVGQTYLMTCK 
                               ,''                                                                    --LOTDATE     --제조일자
                               ,0                                                                     --PIECEQTY    
                               ,''                                                                    --REALOUTQTY  
                               ,''                                                                    --SUPPLYDIV   --공급구분
                               ,''                                                                    --EMPCODE     --담당자 사번
                               ,0                                                                     --ORDQTYBSUNIT--주문수량배수단위
                               ,'N'                                                                   --OUTPROTYN   --퇴장방지여부
                               ,''                                                                    --MPLANTCODE  --관리사업장
                               ,'N'                                                                   --PAIDYN      --급여/비급여구분
                               ,v_QTY                                                                 --REQQTY      --요청수량
                               ,''                                                                    --THREEAVGCK  --급여/비급여구분
                       );
                    EXCEPTION 
                       WHEN OTHERS THEN
                            out_CODE := SQLCODE;
                            out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                            RAISE ERROR_RAISE;
                    END;  
 

                END IF;

            END LOOP ; 
             
            
            out_CODE  := 0;
            out_MSG := '저장 완료'; --CHOE 20130624 SFA에서 완료 저장 완료 MSG를 받으면 주문 초기화 되도록 설정              
                    
        END IF;  
         
--                insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDER_123',TO_CHAR(ll_loop),sysdate,'v_ITEM_ID'||v_ITEM_ID);
--                commit; 
         
        
EXCEPTION
        WHEN ERROR_RAISE THEN 
            ROLLBACK; 

        WHEN OTHERS THEN
            out_CODE := SQLCODE;
            out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 
            ROLLBACK; 

end;
/
