CREATE PROCEDURE P_Rate_Day_060430
              ( I_YM_F     IN     VARCHAR2 )
                
IS
          T_JANGO_BEFORE       NUMBER;
		  T_JANGO              NUMBER;
		  T_CNT                NUMBER;
		  T_MM1                NUMBER;
		  T_MM2                NUMBER;
		  T_MM3                NUMBER;
		  T_MM4                NUMBER;
		  T_MM5                NUMBER;
		  T_MM6                NUMBER;
		  T_MM7                NUMBER;
		  T_MM8                NUMBER;
		  T_MM9                NUMBER;
		  T_MM10               NUMBER;
		  T_MM11               NUMBER;
		  T_MM12               NUMBER;
		  T_MM13               NUMBER;	
		  T_RATE_DATE_SU       NUMBER; 
		  T_CUST               VARCHAR2(10);
		  T_RATE_DATE          DATE;
		  T_DATE_BEFORE        DATE;
		  T_TEMP_DATE          DATE;
		  

       CURSOR C1  IS
            SELECT A.YMD YMD,
                   SUM(A.MISU_AMT - A.BANPUM) MISU_AMT
	          FROM  (	   
					   SELECT YMD        YMD,
							  MISU_AMT   MISU_AMT,
							  0          BANPUM
						 FROM SALE0306 
						WHERE CUST_ID = T_CUST  
						  AND YMD    <= TO_DATE(I_YM_F || '01','YYYYMMDD')
					 UNION ALL
					   SELECT TO_DATE(TO_CHAR(YMD,'yyyymm') || '01','yyyymmdd') YMD,
						      0,
						      AMT_SUM+VAT_SUM  
						 FROM SALE0207 
					    WHERE DEAL_GB LIKE  '1' || '%'
						  AND CUST_ID = T_CUST	
					 	  AND YMD    <= TO_DATE(I_YM_F || '01','YYYYMMDD')
	          ) A
	        GROUP BY YMD 	
	        ORDER BY YMD DESC;		  
				  
			  
		CURSOR C2 IS	  
			  SELECT B.YMD                     YMD,
			         SUM(B.AMT) + SUM(B.VAT) - SUM(B.DC_AMT)  AMT
			    FROM SALE0203 A,
				     SALE0204 B
			   WHERE A.YMD      = B.YMD
			     AND A.GUMAE_NO = B.GUMAE_NO
			     AND A.CUST_ID  = T_CUST
				 AND A.GUMAE_NO LIKE TO_CHAR(T_RATE_DATE,'YYYYMM') || '%'
				 GROUP BY B.YMD
			    ORDER BY B.YMD DESC;		
	/*			 
		CURSOR C3 IS	  
			  SELECT B.YMD                     YMD,
			         B.AMT + B.VAT - B.DC_AMT  AMT
			    FROM SALE0203 A,
				     SALE0204 B
			   WHERE A.YMD      = B.YMD
			     AND A.GUMAE_NO = B.GUMAE_NO
			     AND A.CUST_ID  = T_CUST
				 AND A.GUMAE_NO LIKE TO_CHAR(ADD_MONTHS(T_RATE_DATE,1),'YYYYMM') || '%'; */
				 
		CURSOR C3 IS	  
			  SELECT B.YMD                     YMD,
			         SUM(B.AMT) + SUM(B.VAT) - SUM(B.DC_AMT)  AMT
			    FROM SALE0203 A,
				     SALE0204 B
			   WHERE A.YMD      = B.YMD
			     AND A.GUMAE_NO = B.GUMAE_NO
			     AND A.CUST_ID  = T_CUST
				 AND A.GUMAE_NO LIKE TO_CHAR(T_RATE_DATE,'YYYYMM') || '%' 
			  GROUP  BY B.YMD
		    ORDER BY B.YMD DESC;		  
				 		 		 
		
		CURSOR C4 IS	  
			
			 SELECT CUST_ID  CUST_ID,
			        MM_1     MM1,
					MM_2	 MM2,
					MM_3     MM3,
					MM_4     MM4,
     				MM_5     MM5,
					MM_6     MM6,
					MM_7     MM7,
					MM_8     MM8,
					MM_9     MM9,
					MM_10    MM10,
				    MM_11    MM11,
					MM_12    MM12,
					MM_13    MM13												       
			   FROM EIJING 
			  WHERE YM_F = I_YM_F	
			    AND    cust_id = '3200252'
			  ORDER BY 1;
				 			   

      BEGIN
	  
	  FOR A4 IN C4 LOOP    
	  
		      T_JANGO        := 0;
		      T_JANGO_BEFORE := 0;
			  T_CNT          := 1 ;
			  T_CUST         := A4.CUST_ID;
			  T_RATE_DATE_SU := 0;
			  
			  T_MM1 := A4.MM1;
  			  T_MM2 := A4.MM2;
			  T_MM3 := A4.MM3;
			  T_MM4 := A4.MM4;
			  T_MM5 := A4.MM5;
			  T_MM6 := A4.MM6;
			  T_MM7 := A4.MM7;
			  T_MM8 := A4.MM8;
			  T_MM9 := A4.MM9;
			  T_MM10:= A4.MM10;
			  T_MM11:= A4.MM11;
			  T_MM12:= A4.MM12;
			  T_MM13:= A4.MM13;
			  
			  
			
			  -- 금월잔고 구함			 
		       SELECT A.JANGO    JANGO 
			     INTO T_JANGO
			     FROM EIJING A
				WHERE A.CUST_ID  = T_CUST
				  AND A.YM_F     = I_YM_F;  
			  
			    -- 금월잔고가 0 이하 일때 회전일 0이 된다
			  	IF T_JANGO <= 0 THEN
				   T_RATE_DATE_SU := 0 ;
				   GOTO label1 ;

				END IF;		
			
				  
	            FOR A1 IN C1 LOOP
				
				   T_RATE_DATE     := A1.YMD;
				   T_JANGO_BEFORE  := T_JANGO;				   
				   
				   -- 금월잔고에서 최근달 부터 매출을 빼나간다.
	               -- EX) 8월 조회시 8,7,6 ... 이런식으로 순수매출을 빼나간다. 
			       T_JANGO := T_JANGO - A1.MISU_AMT;              
				   
				
				   
				   -- 뺀 잔고가 0 일때	
				   -- 구매의뢰 테이블에서(일자별) 잔고가 0 이 되는 일자를 구한다			   
				   
				   IF T_JANGO = 0 THEN
				   				   
				       IF T_CNT = 1 THEN 				       
						 T_MM1  := T_MM1;
						 T_MM2  := 0;
					     T_MM3  := 0;
					     T_MM4  := 0;
					     T_MM5  := 0;
					     T_MM6  := 0;
					     T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;			   
					   ELSIF T_CNT = 2 THEN
						 T_MM2  := T_MM2;
						 T_MM3  := 0;
					     T_MM4  := 0;
					     T_MM5  := 0;
					     T_MM6  := 0;
					     T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;
					   ELSIF T_CNT = 3 THEN
	   					 T_MM3  := T_MM3;
					     T_MM4  := 0;
					     T_MM5  := 0;
					     T_MM6  := 0;
					     T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;					   
					   ELSIF T_CNT = 4 THEN
	   					 T_MM4  := T_MM4;
					     T_MM5  := 0;
					     T_MM6  := 0;
					     T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;	
					   ELSIF T_CNT = 5 THEN
	   					 T_MM5  := T_MM5;
						 T_MM6  := 0;
					     T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;
					   ELSIF T_CNT = 6 THEN
	  					 T_MM6  := T_MM6;
						 T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;
					   ELSIF T_CNT = 7 THEN
	  					 T_MM7  := T_MM7;
						 T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;
					   ELSIF T_CNT = 8 THEN
	   					 T_MM8  := T_MM8;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;
	 				   ELSIF T_CNT = 9 THEN				   
	   					 T_MM9  := T_MM9;
                         T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;						 				   
					   ELSIF T_CNT = 10 THEN				   
	   					 T_MM10  := T_MM10;
						 T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;						 
					   ELSIF T_CNT = 11 THEN				   
	   					 T_MM11  := T_MM11;
					     T_MM12 := 0;
					     T_MM13 := 0;						 		   
	   				   ELSIF T_CNT = 12 THEN				   
	   					 T_MM12  := T_MM12;
					     T_MM13 := 0;	
				       ELSIF T_CNT = 13 THEN				   
	   					 T_MM13  := T_JANGO;
					   END IF;				   
				   	
				      FOR A2 IN C2 LOOP					  
					  	        
						   -- 상세 내역 테이블 로 들어가서 
						   -- 일자별로 날짜를 구한다
						   T_JANGO_BEFORE := T_JANGO_BEFORE - A2.AMT;
						   
						   IF T_JANGO_BEFORE = 0 THEN
						      T_RATE_DATE_SU := LAST_DAY(I_YM_F||'15') - A2.YMD;	
		  				      GOTO label1 ;		   
						   ELSIF T_JANGO_BEFORE < 0 THEN
						      T_RATE_DATE_SU := LAST_DAY(I_YM_F||'15') - NVL(T_DATE_BEFORE,A2.YMD);
		  				      GOTO label1 ;	
						   END IF;					    
				           
						   T_DATE_BEFORE := A2.YMD;
						   
					   END LOOP;     
											       
	               -- 뺀 잔고가 0 미만 일때	
				   -- 전달 구매의뢰 테이블에서(일자별) 잔고가 0 이 되는 일자를 구한다 	
					ELSIF T_JANGO < 0 THEN				   
					  
					    IF T_CNT = 1 THEN 				       
						 T_MM1  := T_JANGO_BEFORE;	
					     T_MM2  := 0;
					     T_MM3  := 0;
					     T_MM4  := 0;
					     T_MM5  := 0;
					     T_MM6  := 0;
					     T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;	   
					   ELSIF T_CNT = 2 THEN
						 T_MM2  := T_JANGO_BEFORE;
						  T_MM3  := 0;
					     T_MM4  := 0;
					     T_MM5  := 0;
					     T_MM6  := 0;
					     T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;
					   ELSIF T_CNT = 3 THEN
	   					 T_MM3  := T_JANGO_BEFORE;
						  T_MM4  := 0;
					     T_MM5  := 0;
					     T_MM6  := 0;
					     T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;				   
					   ELSIF T_CNT = 4 THEN
	   					 T_MM4  := T_JANGO_BEFORE;
						 T_MM5  := 0;
					     T_MM6  := 0;
					     T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;	 
					   ELSIF T_CNT = 5 THEN
	   					 T_MM5  := T_JANGO_BEFORE;
						 T_MM6  := 0;
					     T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;	 
					   ELSIF T_CNT = 6 THEN
	  					 T_MM6  := T_JANGO_BEFORE;
						 T_MM7  := 0;
					     T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;	
					   ELSIF T_CNT = 7 THEN
	  					 T_MM7  := T_JANGO_BEFORE;
						 T_MM8  := 0;
					     T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;	
					   ELSIF T_CNT = 8 THEN
	   					 T_MM8  := T_JANGO_BEFORE;
						 T_MM9  := 0;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;	
	 				   ELSIF T_CNT = 9 THEN				   
	   					 T_MM9  := T_JANGO_BEFORE;
					     T_MM10 := 0;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;					   
					   ELSIF T_CNT = 10 THEN				   
	   					 T_MM10  := T_JANGO_BEFORE;
					     T_MM11 := 0;
					     T_MM12 := 0;
					     T_MM13 := 0;
					   ELSIF T_CNT = 11 THEN				   
	   					 T_MM11  := T_JANGO_BEFORE;
						 T_MM12 := 0;
					     T_MM13 := 0; 		   
	   				   ELSIF T_CNT = 12 THEN				   
	   					 T_MM12  := T_JANGO_BEFORE;
						 T_MM13 := 0;	
				       ELSIF T_CNT = 13 THEN				   
	   					 T_MM13  := T_JANGO_BEFORE;
					   END IF;				
	              
					
					   FOR A3 IN C3 LOOP
					   
					       T_JANGO_BEFORE := T_JANGO_BEFORE - A3.AMT;
						   
						   IF T_JANGO_BEFORE = 0 THEN
						      T_RATE_DATE_SU := LAST_DAY(I_YM_F||'15') - A3.YMD;
			  				   GOTO label1 ;	
						   ELSIF T_JANGO_BEFORE < 0 THEN
						      IF T_DATE_BEFORE IS NULL THEN
							     T_DATE_BEFORE := A3.YMD;  
							  END IF;
						      T_RATE_DATE_SU := LAST_DAY(I_YM_F||'15') - T_DATE_BEFORE;
			  				   GOTO label1 ;			
						   END IF;
						   T_DATE_BEFORE := A3.YMD;				       
					   
					   END LOOP;
					   	  
				    END IF;
					
					
				 
				    T_CNT  := T_CNT +  1; -- 달 증가
						
						
				      IF T_CNT = 1 THEN 				       
						 T_MM1  := T_MM1;		   
					   ELSIF T_CNT = 2 THEN
						 T_MM2  := T_MM2;
					   ELSIF T_CNT = 3 THEN
	   					 T_MM3  := T_MM3;				   
					   ELSIF T_CNT = 4 THEN
	   					 T_MM4  := T_MM4;
					   ELSIF T_CNT = 5 THEN
	   					 T_MM5  := T_MM5;
					   ELSIF T_CNT = 6 THEN
	  					 T_MM6  := T_MM6;
					   ELSIF T_CNT = 7 THEN
	  					 T_MM7  := T_MM7;
					   ELSIF T_CNT = 8 THEN
	   					 T_MM8  := T_MM8;
	 				   ELSIF T_CNT = 9 THEN				   
	   					 T_MM9  := T_MM9;				   
					   ELSIF T_CNT = 10 THEN				   
	   					 T_MM10  := T_MM10;
					   ELSIF T_CNT = 11 THEN				   
	   					 T_MM11  := T_MM11;		   
	   				   ELSIF T_CNT = 12 THEN				   
	   					 T_MM12  := T_MM12;	
				       ELSIF T_CNT = 13 THEN				   
	   					 T_MM13  := T_JANGO;
					   END IF;				
						
									
	            END LOOP;
				
				
				IF T_RATE_DATE_SU = 0 THEN
				   T_RATE_DATE_SU := LAST_DAY(I_YM_F||'15') - T_RATE_DATE;
				END IF;
				
				<< label1 >>
								
				UPDATE EIJING A
				   SET A.MM_1     = T_MM1,
				       A.MM_2     = T_MM2,
					   A.MM_3     = T_MM3,
					   A.MM_4     = T_MM4,
					   A.MM_5     = T_MM5,
					   A.MM_6     = T_MM6,
					   A.MM_7     = T_MM7,
					   A.MM_8     = T_MM8,
					   A.MM_9     = T_MM9,
					   A.MM_10    = T_MM10,
					   A.MM_11    = T_MM11,
					   A.MM_12    = T_MM12,
					   A.MM_13    = T_MM13,
					   A.RATEDAY = T_RATE_DATE_SU
				 WHERE A.CUST_ID = T_CUST
				   AND A.YM_F    = I_YM_F;	               
				
			  COMMIT;		  
			
				T_RATE_DATE_SU := 0;
				T_JANGO        := 0;
				T_RATE_DATE    := NULL;
				T_JANGO_BEFORE := 0;
				T_DATE_BEFORE  := NULL;
				T_JANGO_BEFORE := 0;
				
	  END LOOP;			

           
       EXCEPTION
          WHEN OTHERS THEN
               ROLLBACK;
               RAISE_APPLICATION_ERROR(-20099, 'F_RATE_DAY '||SUBSTRB('오류!'||SQLCODE||'/'||SQLERRM,1,250)) ;

      END  P_Rate_Day_060430;


/
