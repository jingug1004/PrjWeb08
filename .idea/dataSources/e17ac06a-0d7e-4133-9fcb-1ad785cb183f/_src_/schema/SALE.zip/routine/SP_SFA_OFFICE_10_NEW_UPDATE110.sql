CREATE PROCEDURE      SP_SFA_OFFICE_10_NEW_UPDATE110
(
    in_CARD_NO           IN VARCHAR2,      -- 카드번호
    in_USE_DT            IN VARCHAR2,      -- 사용일자
    in_USE_TM            IN VARCHAR2,      -- 사용시간
    in_CARD_OK_NO        IN VARCHAR2,      -- 카드승인번호
    in_USE_GUBUN         IN VARCHAR2,      -- 사용구분(03:매입, 04:매입취소)
    in_GONGJAE_YN        IN VARCHAR2,      -- 공제여부 (1:선택안함, 2:공제, 3:비공제)
    in_USE_DETAIL        IN VARCHAR2,      -- 사용내용 상세
    in_GAEJUNG_CD        IN VARCHAR2,      -- 계정코드
    in_DEDUCTION_YN_CD   IN VARCHAR2,      -- 부가세공제불가항목코드 
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 정산관리-계정,사용내역등수정
 호출프로그램 : 오피스 > 정산관리
          2017.11.01  KTA - NEW ERP메 맞게 컨버전        
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_num1               NUMBER;
    v_case               VARCHAR2(100);
    
    v_salecamp_conf_yn  VARCHAR2(1);   --영업관리부 승인
    V_TEAMJANG_CONF_YN   VARCHAR2(1);   --사용자 입력 완료 여부   

    CARD_NO_NULL         EXCEPTION;
    USE_DT_NULL          EXCEPTION;
    USE_TM_NULL          EXCEPTION;
    CARD_OK_NO_NULL      EXCEPTION;
    USE_GUBUN_NULL       EXCEPTION;
    GAEJUNG_CD_NULL      EXCEPTION;
    

BEGIN

--insert into SFA_SP_CALLED_HIST   values ('SP_SFA_OFFICE_10_NEW_UPDATE105','1',sysdate,'in_CARD_NO:'||in_CARD_NO||'/in_GONGJAE_YN:'||in_GONGJAE_YN);
--COMMIT; 


    CASE
        WHEN in_CARD_NO    IS NULL THEN RAISE CARD_NO_NULL;
        WHEN in_USE_DT     IS NULL THEN RAISE USE_DT_NULL;
        WHEN in_USE_TM     IS NULL THEN RAISE USE_TM_NULL;
        WHEN in_CARD_OK_NO IS NULL THEN RAISE CARD_OK_NO_NULL;
        WHEN in_GAEJUNG_CD IS NULL THEN RAISE GAEJUNG_CD_NULL;
        ELSE v_case := 'NULL 체크 이상없음';
    END CASE;

   SELECT COUNT(*) , max(SALECAMP_CONF_YN)
     INTO v_num ,v_salecamp_conf_yn 
     FROM ORAGMP.IBK_ACQUIRE_DATA
    WHERE card_no     = in_CARD_NO
      AND use_dt      = in_USE_DT
      AND use_tm      = in_USE_TM
      AND card_ok_no  = in_CARD_OK_NO
      AND use_gubun   = in_USE_GUBUN;

    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '정보가 존재하지 않습니다.';
    ELSIF (v_num = 1) THEN
        out_CODE := 0;
        out_MSG := '정보 확인완료';

        /*CHOE 20130320 정산관리 내역중 관리부 승인이 난 경우에는 영업사원은 수정할 수 없다.*/
        IF v_salecamp_conf_yn <> 1 THEN
           out_CODE := 1;
           out_MSG := '관리부 승인으로 해당 정보는 수정 할 수 없습니다. 수정이 필요한 경우 담당 직원에게 문의 바랍니다.';
        ELSE
            /*CHOE 20130320 사용자가 2가지 항목을 모두 등록하는 경우 : 사용 완료*/
            IF LENGTH(TRIM(in_USE_DETAIL)) = 0 OR  LENGTH(TRIM(in_GAEJUNG_CD)) = 0 OR NVL(TRIM(in_USE_DETAIL), '0') = '0' OR NVL(TRIM(in_GAEJUNG_CD), '0') = '0' THEN
               V_TEAMJANG_CONF_YN := 'N';
            ELSE
               V_TEAMJANG_CONF_YN := 'Y';
            END IF;
                        
            -- 정산 테이블 수정. in_GONGJAE_YN = '999' 인경우 'Y', 그외 'N'
            UPDATE ORAGMP.IBK_ACQUIRE_DATA
               SET use_detail        = in_USE_DETAIL
                 , jukyo             = in_USE_DETAIL  --상세내역을 적요에 그대로 적용 
                 , gaejung_cd        = in_GAEJUNG_CD
                 , teamjang_conf_yn  = V_TEAMJANG_CONF_YN
                 , deduction_yn_cd = in_DEDUCTION_YN_CD
            WHERE card_no     = in_CARD_NO
              AND use_dt      = in_USE_DT
              AND use_tm      = in_USE_TM
              AND card_ok_no  = in_CARD_OK_NO
              AND use_gubun   = in_USE_GUBUN;

            COMMIT;

            out_CODE := 0;
            out_MSG := '정산처리가 완료되었습니다.';
        END IF;
    END IF;

EXCEPTION
WHEN CARD_NO_NULL THEN
   out_CODE := 101;
   out_MSG := '카드번호가 누락되었습니다.';
WHEN USE_DT_NULL THEN
   out_CODE := 102;
   out_MSG := '카드 사용일자가 누락되었습니다.';
WHEN USE_TM_NULL THEN
   out_CODE := 103;
   out_MSG := '카드 사용시간이 누락되었습니다.';
WHEN CARD_OK_NO_NULL THEN
   out_CODE := 104;
   out_MSG := '카드 승인번호가 누락되었습니다.';
WHEN USE_GUBUN_NULL THEN
   out_CODE := 105;
   out_MSG := '카드 사용구분이 누락되었습니다.'; 
WHEN GAEJUNG_CD_NULL THEN
   out_CODE := 109;
   out_MSG := '계정과목이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
