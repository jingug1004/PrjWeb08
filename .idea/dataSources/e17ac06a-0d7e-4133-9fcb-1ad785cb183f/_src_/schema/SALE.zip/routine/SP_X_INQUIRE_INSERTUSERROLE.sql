CREATE PROCEDURE      SP_X_INQUIRE_INSERTUSERROLE
(
    in_PGM_NO     IN VARCHAR2,
    in_SIDX       IN VARCHAR2,
    in_SORD       IN VARCHAR2,
    out_RESULT   OUT TYPES.CURSOR_TYPE,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INQUIRE_INSERTUSERROLE
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
	    SELECT * FROM (
          SELECT     ''  AS DEPT_CODE
                    ,''        AS DEPT_NAME
                    ,A.CUSTCODE AS EMP_CODE    
                    ,A.CUSTNAME AS EMP_NAME
           FROM      ORAGMP.CMCUSTM  A
                    ,SALE_ON.PF_PGM_ROLE_DEV C
                    ,SALE_ON.PF_USERROLE_DEV D
          WHERE     C.ROLE_NO  = D.ROLE_NO
            AND     A.CUSTCODE = D.EMP_CODE
            AND     A.CUSTCODE LIKE '11%' 
            AND     A.SAGODIV <> '2'  
            AND     C.PGM_NO  = in_PGM_NO
          UNION
          SELECT DEPT_CODE, DEPT_NAME, EMP_CODE, EMP_NAME
          FROM (SELECT B.EMPCODE AS EMP_CODE,
                       B.EMPNAME AS EMP_NAME, B.DEPTCODE
                  FROM ORAGMP.CMEMPM B, SALE_ON.PF_PGM_ROLE_DEV C ,SALE_ON.PF_USERROLE_DEV D 
                 WHERE B.OUTYN = 'Y'     -- 재직구분
                   AND C.ROLE_NO = D.ROLE_NO
                   AND B.EMPCODE = D.EMP_CODE
                   AND C.PGM_NO  = in_PGM_NO) AA,
               (SELECT DEPTCODE AS DEPT_CODE, DEPTNAME AS DEPT_NAME
                  FROM  ORAGMP.CMDEPTM
                 WHERE USEYN='Y') BB
         WHERE AA.DEPTCODE = BB.DEPT_CODE(+))
		 ORDER BY in_SIDX||' '||in_SORD;
		 
	    out_CODE := 0;
        out_MSG := '데이터 저장';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;
END ;
/
