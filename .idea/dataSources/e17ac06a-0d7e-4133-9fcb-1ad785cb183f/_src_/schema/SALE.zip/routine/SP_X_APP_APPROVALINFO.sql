CREATE PROCEDURE      SP_X_APP_APPROVALINFO
(
    in_GUMAE_NO  IN VARCHAR2,
    in_YMD       IN VARCHAR2,
    out_RESULT  OUT TYPES.CURSOR_TYPE,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_APPROVALINFO
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  주문승인 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
          SELECT A.GUMAE_NO        GUMAE_NO, 
		         A.GUMAE_GB        GUMAE_GB, 
		         A.YMD             YMD,   
		         A.SAWON_ID        SAWON_ID,
		         G.DEPT_NM 		   DEPT_NM,
		         A.RSAWON_ID       RSAWON_ID,
		         H.DEPT_NM 		   RDEPT_NM,
		         A.CUST_ID         CUST_ID,   
		         B.CUST_GB1        CUST_GB1,
		         A.RCUST_ID        RCUST_ID,   
		         D.CUST_GB1        RCUST_GB1,
		         (SELECT CODE1_NM FROM SALE.SALE0001 WHERE CODE_GB = '0020' AND CODE1 = D.CUST_GB1) RCUST_GBNM,
		         A.AMT_SUM         AMT_SUM,   
		         A.VAT_SUM         VAT_SUM,   
		         A.BIGO            BIGO,
		         A.GYULJAE_GB      GYULJAE_GB,   
		         A.TAX_TYPE        TAX_TYPE,   
		         A.DECIMAL_PROC    DECIMAL_PROC,   
		         A.CHAMJO_NM       CHAMJO_NM,   
		         A.CHAMJO_RANK     CHAMJO_RANK,   
		         B.CUST_NM         CUST_NM,
		         D.CUST_NM         RCUST_NM,
		         C.SAWON_NM        SAWON_NM,
		         E.SAWON_NM        RSAWON_NM,
		         A.GUBUN           GUBUN,
		         A.ACCEPT_YN       ACCEPT_YN,
		         NVL(A.LIMIT_YN,'N')  LIMIT_YN,
		         CASE WHEN A.LIMIT_YN = 'Y' THEN '여신초과' 
		              WHEN A.LIMIT_YN = 'N' THEN '여신이내' ELSE '담보예외' END   LIMIT_DESC,
		         A.INPUT_YMD       INPUT_YMD,
		         A.INPUT_ID        INPUT_ID,       
		         F.SAWON_NM        ISAWON_NM,
		         sale.F_RATE_DAY_BEFOREMONTH(to_char(add_months(sysdate,-1),'yyyymm'),A.CUST_ID) AS CONTROL_RATE_DAY,
		         A.SLIP_GB ,
		         A.WIBAN_CONF_DTM
		    FROM SALE_ON.SALE0203 A , 
		         SALE.SALE0003 B, 
		         SALE.SALE0007 C, 
		         SALE.SALE0003 D, 
		         SALE.SALE0007 E, 
		         SALE.SALE0007 F,
		         SALE.SALE0008 G,
         		 SALE.SALE0008 H
		   WHERE A.CUST_ID   = B.CUST_ID
		     AND A.SAWON_ID  = C.SAWON_ID
		     AND A.RCUST_ID  = D.CUST_ID(+)
		     AND A.RSAWON_ID = E.SAWON_ID(+)
		     AND A.INPUT_ID  = F.SAWON_ID(+)
		     AND A.GUMAE_NO = in_GUMAE_NO
		     AND A.YMD      = TO_DATE(in_YMD)
		     AND C.DEPT_CD = G.DEPT_CD
     		 AND E.DEPT_CD = H.DEPT_CD;
     		 
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        
END ;
/
