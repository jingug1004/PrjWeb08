CREATE PROCEDURE      SP_X_APP_PROMISEGRIDTOTALCOUNT
(
    in_CUST_ID       IN VARCHAR2,
    in_FR_DATETIME   IN VARCHAR2,
    in_TO_DATETIME   IN VARCHAR2,
    in_FR_DATE       IN VARCHAR2,
    in_TO_DATE       IN VARCHAR2,
    out_TOTAL_CNT   OUT NUMBER,
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_PROMISEGRIDTOTALCOUNT
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  담보약속 카운터 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	SELECT COUNT(*) INTO out_TOTAL_CNT
		  FROM
				(SELECT TO_CHAR(TO_DATE(A.YMD),'YYYY-MM-DD') REQ_DATE, 
				       TO_CHAR(TO_DATE(A.PDATE),'YYYY-MM-DD') PROMISE_DATE, 
				       CASE WHEN A.RECEIPT_GB = '1' THEN '접수'
				            WHEN A.RECEIPT_GB = '2' THEN '승인'
				            WHEN A.RECEIPT_GB = '3' THEN '반려' ELSE '    ' END AS STATUS, 
				       A.PBIGO PROMISE_BIGO,
				       A.RETURN_DESC RETURN_DESC
				  FROM SALE_ON.SALE0203 A
				 WHERE A.CUST_ID = in_CUST_ID
				   AND TO_CHAR(A.INPUT_YMD, 'YYYYMMDDHH24MI') BETWEEN in_FR_DATETIME AND in_TO_DATETIME
				   AND A.YMD BETWEEN TO_DATE(in_FR_DATE) AND TO_DATE(in_TO_DATE)
				   AND (A.PDATE IS NOT NULL OR A.WIBAN_ORDER_REQ_YN = 'Y')
				   AND A.WIBAN_ORDER_CONF_YN = '1');

    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
