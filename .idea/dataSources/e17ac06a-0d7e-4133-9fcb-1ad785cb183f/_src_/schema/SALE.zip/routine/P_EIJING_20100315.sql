CREATE PROCEDURE      P_Eijing_20100315
              ( AS_YM_F     IN     VARCHAR2 )
                
IS
 /* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
 /* ******************************************************************************* */
 /*   TITLE        :  에이징차트 임시테이블에 저장                                  */
 /*   PROJECT      :  채권관리부                                                    */
 /*   AUTHOR       :                                                                */
 /*   PROGRAM_ID   :  EIJING                                                        */
 /*   HISTORY      :  2006.11.31(목)                                                */
 /*   PROCESS      :  항목별로 데이타 넣는다                                        */
 /* ******************************************************************************* */
 
     T_SU_AMT     NUMBER;
     T_MM01       NUMBER;
     T_MM02       NUMBER;
     T_MM03       NUMBER;
     T_MM04       NUMBER;
     T_MM05       NUMBER;
     T_MM06       NUMBER;
     T_MM07       NUMBER;
     T_MM08       NUMBER;
     T_MM09       NUMBER;
     T_MM10       NUMBER;
     T_MM11       NUMBER;
     T_MM12       NUMBER;
     T_MM13       NUMBER;
     T_JAN        NUMBER;
     T_MM01_TMP   NUMBER;
     T_MM02_TMP   NUMBER;
     T_MM03_TMP   NUMBER;
     T_MM04_TMP   NUMBER;
     T_MM05_TMP   NUMBER;
     T_MM06_TMP   NUMBER;
     T_MM07_TMP   NUMBER;
     T_MM08_TMP   NUMBER;
     T_MM09_TMP   NUMBER;
     T_MM10_TMP   NUMBER;
     T_MM11_TMP   NUMBER;
     T_MM12_TMP   NUMBER;
     T_MM13_TMP   NUMBER;
     T_CNT        NUMBER;
     T_SU_TOT     NUMBER;
     T_DAY_CNT    NUMBER;
     T_CUST       VARCHAR2(10);
     T_FLAG       VARCHAR2(1);
     T_CUST_ID_TMP VARCHAR2(10);
     T_DAY        DATE;    
     
         
 
 BEGIN
    
        -- 에이징 기초데이타를 넣은다  
  INSERT INTO EIJING ( CUST_ID   , YM_F             , BEFORE_AMT, SALE   , BANPUM    , SIL_SALE   ,
                       CASH_CARD , BILL   , SU_AMT  , HALIN     , JANGO  , MIDORA_JA , MIDORA_CHA ,NET ,
                       MM_1      , MM_2   , MM_3    , MM_4      , MM_5   , MM_6      , MM_7       ,
                       MM_8      , MM_9   , MM_10   , MM_11     , MM_12  , MM_13     , MM_TOT     ,
                       DAMBO     , MANGI  , B_BEFORE_AMT        ,B_B_BEFORE_AMT)
 SELECT  A.CUST_ID                                            CUST_ID,        /* 거래처 코드 */
         AS_YM_F                                              YM_F,           /* 년월 From */
         SUM(A.BEFORE_AMT)                                    BEFORE_AMT,     /* 전월잔고 */
         SUM(A.SALE_AMT)            -  SUM(A.BANPUM_01)         SALE_AMT,       /* 판매     */
         SUM(A.BANPUM_01)                                    BANPUM_SUM,     /* 반품 */
         SUM(A.SALE_AMT)                SIL_SALE,       /* 실판매 */
         SUM(A.CASH_AMT)    +  NVL(SUM(A.CARD_AMT),0)         CASH_CARD_AMT , /* 카드 + 현금 */
         SUM(A.BILL_AMT)    -  NVL(SUM(A.CARD_AMT),0)         BILL_AMT,       /* 어음 */                        
         SUM(A.CASH_AMT)    +  SUM(A.BILL_AMT)                SU_TOT,         /*수금계 */                        
         SUM(A.DC_AMT)                                        DC_AMT,         /*매출할인 */
         SUM(A.BEFORE_AMT)  + SUM(A.MISU_AMT) - SUM(A.SU_AMT) TODAY_JAN,      /*금월잔고 */
         SUM(A.MIDORAE_JA)                                    MIDORAE_JA,     /*미도래어음(자수) */
         SUM(A.MIDORAE_CHA)                                   MIDORAE_CHA,    /*미도래어음(타수) */
         SUM(A.BEFORE_AMT)  + SUM(A.MISU_AMT) - SUM(A.SU_AMT) 
                            + SUM(A.MIDORAE_JA)+ SUM(A.MIDORAE_CHA) NET ,          /* NET잔고 */        
         SUM(A.MM_01)                       MM_01,         /* 1~30 */ 
         SUM(A.MM_02)                       MM_02,         /*  31~60     */                
         SUM(A.MM_03)                       MM_03,         /*  61~90     */
         SUM(A.MM_04)                       MM_04,         /*  91~120     */
         SUM(A.MM_05)                        MM_05,         /* 121~150     */
         SUM(A.MM_06)                       MM_06,         /* 151~180     */
         SUM(A.MM_07)                       MM_07,         /* 181~210     */
         SUM(A.MM_08)                       MM_08,         /* 211~240     */
         SUM(A.MM_09)                      MM_09,         /* 241~270     */ 
         SUM(A.MM_10)                      MM_10,         /* 271~300     */
         SUM(A.MM_11)                      MM_11,         /* 301~330     */
         SUM(A.MM_12)                       MM_12,         /* 331~360     */
         SUM(A.MM_13)                      MM_13,         /* 361초과     */
         0   TOT,
         DECODE(SUM(A.BEFORE_AMT) +  SUM(A.MISU_AMT) - SUM(A.SU_AMT) + NVL(SUM(A.MIDORAE_JA),0),0,0, /* 담보확보율 */
               ROUND( (( NVL(SUM(A.DAMBO_1),0) + NVL(SUM(A.DAMBO_2),0) + NVL(SUM(A.DAMBO_3),0) ) 
                     / ( SUM(A.BEFORE_AMT) +  SUM(A.MISU_AMT) - SUM(A.SU_AMT) + NVL(SUM(A.MIDORAE_JA),0) ) * 100),2))  YUL,
         SUM(A.MANGI)                                             MANGI,
         SUM(A.B_BEFORE_AMT)                                         B_BEFORE_AMT,
         SUM(A.B_B_BEFORE_AMT)                                            B_B_BEFORE_AMT                                                                                                        
 FROM (
     SELECT CUST_ID     CUST_ID,    /* 거래처 코드 */
            SU_AMT      SU_AMT ,    /* 수금 금액 */
             MISU_AMT    MISU_AMT,   /* 미수금   */
            BEFORE_AMT  BEFORE_AMT, /* 전월잔고 */
             0           SALE_AMT  , /* 판매     */
             0           BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0           BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */            
             0           CASH_AMT,   /* 현금 */
             0           BILL_AMT,   /* 어음 */
             0           CARD_AMT,   /* 카드 */
             0           DC_AMT,     /*매출할인 */
             0           MIDORAE_JA, /*미도래어음(자수) */
             0           MIDORAE_CHA,/*미도래어음(타수) */
             0           DAMBO_1,    /* 약어,약어(신보),어음 */    
             0           DAMBO_2,    /* 가수, 당좌 */
             0              DAMBO_3,   /*'약어','약어(신보)','어음','가수','당좌'*/
             0           BILL   ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,  /* 361초과     */
             0           MANGI,
             0           B_BEFORE_AMT, /*전전월 잔고 */
             0           B_B_BEFORE_AMT /*전전전월 잔고 */
       FROM SALE0306 
       WHERE YMD     = TO_DATE(SUBSTR(AS_YM_F,1,6)||'01','YYYYMMDD')       

UNION ALL
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,
            0      ,                
            0      ,
            MISU_AMT,  /* 판매     */
              0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
            0       , 
            0      ,               
            0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0      ,
            0      ,
            0      , 
            0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,  /* 361초과     */
             0           MANGI,
             0     ,

            0     
      FROM SALE0306 
        WHERE YMD     = TO_DATE(AS_YM_F||'01','YYYYMMDD')   
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
            AMT_SUM+VAT_SUM           BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0           BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN TO_DATE(AS_YM_F || '01','YYYYMMDD') AND LAST_DAY(AS_YM_F || '01')
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             AMT_SUM+VAT_SUM           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0           BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-1) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-1))
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             AMT_SUM+VAT_SUM           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0           BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-2) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-2))                       
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             AMT_SUM+VAT_SUM           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0           BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-3) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-3))                       
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             AMT_SUM+VAT_SUM     BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0           BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-4) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-4))                       
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             AMT_SUM+VAT_SUM           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0           BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-5) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-5))                        
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             AMT_SUM+VAT_SUM           BANPUM_07, /* 반품 */
             0           BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-6) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-6))
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             AMT_SUM+VAT_SUM     BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI    ,
             0     ,
             0      
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-7) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-7))
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0     BANPUM_08, /* 반품 */
             AMT_SUM+VAT_SUM           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-8) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-8))
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0     BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             AMT_SUM+VAT_SUM           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-9) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-9))     
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0     BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             AMT_SUM+VAT_SUM           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-10) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-10))
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0     BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0          BANPUM_11, /* 반품 */
             AMT_SUM+VAT_SUM            BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     BETWEEN ADD_MONTHS(AS_YM_F || '01',-11) AND LAST_DAY(ADD_MONTHS(AS_YM_F || '01',-11))
 UNION ALL       
     SELECT CUST_ID,    /* 거래처 코드 */
            0      ,                
            0      ,
            0      ,
            0      ,
             0          BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0     BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0          BANPUM_11, /* 반품 */
             0            BANPUM_12, /* 반품 */
             AMT_SUM+VAT_SUM           BANPUM_13, /* 반품 */
             0      ,
            0      ,
            0      ,
            0      ,
            0         ,
            0         ,
            0      ,
            0      ,
            0      ,  
            0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0          
       FROM SALE0207 
      WHERE DEAL_GB LIKE  '1' || '%'     
        AND YMD     <= ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-12)    
 

UNION ALL
    SELECT CUST_ID ,
           0       ,                
           0       ,
           0       ,  
              0       ,
                             0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
           CASH_AMT, /* 현금 */
           BILL_AMT,  /* 어음 */
           0       ,        
           0       ,
           0       ,
           0       ,
           0       ,
           0       ,
           0       , 
           0       ,
              0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,

            0     
      FROM SALE0401 
     WHERE YMD       BETWEEN TO_DATE(AS_YM_F || '01','YYYYMMDD') AND LAST_DAY(AS_YM_F || '01')               
 UNION ALL 
    SELECT A.CUST_ID ,
           0      ,                
           0      ,
             0      ,
           0      ,   
               0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
           0      , 
           0      ,
           B.AMT  , /* 카드 */
           0      ,
           0      ,
           0      , 
           0      ,
           0      ,
           0      , 
           0      ,
              0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,

            0     
      FROM SALE0401 A ,SALE0402 B
     WHERE A.YMD       BETWEEN TO_DATE(AS_YM_F || '01','YYYYMMDD') AND LAST_DAY(AS_YM_F||'01')
       AND B.BILL_GB   = '100'
       AND A.YMD       = B.YMD
       AND A.JUNPYO_NO = B.JUNPYO_NO      
  UNION ALL        
    SELECT A.CUST_ID ,
           0      ,                
           0      ,
           0      ,
           0      ,
                        0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
           0           ,   
           0      , 
           0      ,
           B.DC_AMT,  /*매출할인 */
           0      ,  
           0      ,
           0      ,
           0      , 
           0      ,
           0      ,
              0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,  /* 361초과     */
             0           MANGI,
             0     ,

            0     
      FROM SALE0207 A, SALE0208 B
     WHERE A.YMD = B.YMD 
       AND A.DEAL_NO = B.DEAL_NO
        AND A.YMD       BETWEEN TO_DATE(AS_YM_F || '01','YYYYMMDD') AND LAST_DAY(AS_YM_F || '01') 
 UNION ALL 
     SELECT X.CUST_ID        CUST_ID ,
            0      ,                
            0      ,
            0      ,
            0      ,
          0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
            0      ,   
            0      , 
            0      ,
            0      ,
             NVL(SUM(DECODE(Y.BILL_GB,'010',Y.AMT)),0) 
                +  NVL(SUM(DECODE(Y.BILL_GB,'020',Y.AMT)),0)
                +  NVL(SUM(DECODE(Y.BILL_GB,'030',Y.AMT)),0)  
                +  NVL(SUM(DECODE(Y.BILL_GB,'900',Y.AMT)),0)  MIDORAE_JA,                
             NVL(SUM(DECODE(Y.BILL_GB,'025',Y.AMT)),0)  
                +  NVL(SUM(DECODE(Y.BILL_GB,'035',Y.AMT)),0)  
                +  NVL(SUM(DECODE(Y.BILL_GB,'040',Y.AMT)),0)  MIDORAE_CHA,           
             0      , 
            0      ,
            0      ,
            0      ,
               0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,  /* 361초과     */
             0           MANGI,
             0     ,
             0      
      FROM SALE0401 X ,
            SALE0402 Y
      WHERE X.YMD       = Y.YMD
        AND X.JUNPYO_NO = Y.JUNPYO_NO 
        AND Y.END_YMD  > LAST_DAY(AS_YM_F || '01')
     GROUP BY X.CUST_ID

UNION ALL
     SELECT CUST_ID   CUST_ID,
            0      ,                
            0      ,
            0      ,
            0      ,
                 0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
            0      ,   
            0      , 
            0      ,
            0      ,
            0      ,    
           0       ,
           SALE_DAMBO_AMT,  /* 약어,약어(신보),어음 */
             0      ,
            0      ,
            0      ,
               0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,

            0     
      FROM SALE0404
     WHERE BILL_GB IN ('약어','약어(신보)','어음')      

UNION ALL
    SELECT CUST_ID   CUST_ID,
            0      ,                
            0      ,
            0      ,
            0      ,
                         0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
            0      ,   
            0      , 
            0      ,
            0      ,
            0      , 
           0      ,
           0 ,
            SALE_DAMBO_AMT,   /* 가수, 당좌 */
             0      ,    
            0      ,
              0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,

            0     
       FROM SALE0404
      WHERE BILL_GB IN ('가수','당좌')      

UNION ALL
     SELECT CUST_ID   CUST_ID,
            0      ,                
            0      ,
            0      ,
            0      ,
                         0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
            0      ,   
            0      , 
            0      ,
            0      ,
            0      , 
            0      ,    
            0      ,
            0      ,
            SALE_DAMBO_AMT, /*'약어','약어(신보)','어음','가수','당좌'*/
             0      ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,
             0      
       FROM SALE0404
      WHERE BILL_GB NOT IN ('약어','약어(신보)','어음','가수','당좌')       

UNION ALL
     SELECT X.CUST_ID       ,
            0      ,                
            0      ,
            0      ,
            0      ,
                         0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
            0      ,   
            0      , 
            0      ,
            0      ,
            0     , 
            0      ,    
            0      ,
            0      ,
             0      ,
            NVL(Y.AMT,0)    BILL_AMT,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,   /* 361초과     */
             0           MANGI,
             0     ,

            0     
       FROM SALE0401 X ,
            SALE0402 Y
      WHERE X.YMD       = Y.YMD
        AND X.JUNPYO_NO = Y.JUNPYO_NO 
        AND Y.END_YMD  > LAST_DAY(AS_YM_F||'01' )
        AND Y.BILL_GB  NOT IN ('025','035','040')
     UNION ALL   
    SELECT A.CUST_ID, /* 거래처 코드 */
           0      ,                
            0      ,
           0      ,
            0      ,
            0     , /* 반품  */
            0      , /* 반품 */
            0      , /* 반품 */
            0      , /* 반품 */
            0      , /* 반품 */
            0      , /* 반품 */
            0      , /* 반품 */
            0      , /* 반품 */
            0      , /* 반품 */
            0      , /* 반품 */
            0      , /* 반품 */
            0      , /* 반품 */
            0      , /* 반품 */
            0      ,   
            0      , 
            0      ,
            0      ,
            0      , 
            0      ,    
           0      ,
           0      ,
           0      ,
            0     ,
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),AS_YM_F,                                                   SUM(B.AMT + B.VAT) , 0) MM_01,  /*   1~30     */ 
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-1),'YYYYMM'),  SUM(B.AMT + B.VAT) , 0) MM_02,  /*  31~60     */                
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-2),'YYYYMM'),  SUM(B.AMT + B.VAT) , 0) MM_03,  /*  61~90     */           
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-3),'YYYYMM'),  SUM(B.AMT + B.VAT) , 0) MM_04,  /*  91~120     */             
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-4),'YYYYMM'),  SUM(B.AMT + B.VAT) , 0) MM_05,  /* 121~150     */       
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-5),'YYYYMM'),  SUM(B.AMT + B.VAT) , 0) MM_06,  /* 151~180     */              
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-6),'YYYYMM'),  SUM(B.AMT + B.VAT) , 0) MM_07,  /* 181~210     */           
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-7),'YYYYMM'),  SUM(B.AMT + B.VAT) , 0) MM_08,  /* 211~240     */             
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-8),'YYYYMM'),  SUM(B.AMT + B.VAT) , 0) MM_09,  /* 241~270     */             
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-9),'YYYYMM'),  SUM(B.AMT + B.VAT) , 0) MM_10,  /* 271~300     */   
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-10),'YYYYMM'), SUM(B.AMT + B.VAT) , 0) MM_11,  /* 301~360     */            
           DECODE(TO_CHAR(B.YMD,'YYYYMM'),TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-11),'YYYYMM'), SUM(B.AMT + B.VAT) , 0) MM_12,  /* 361초과     */             
            0 MM_13,  /* 361초과     */
            0 MANGI,
            0,
            0          
       FROM SALE0207 A, SALE0208 B
     WHERE A.DEAL_NO = B.DEAL_NO
       AND A.YMD     = B.YMD
       AND A.DEAL_GB LIKE '0%'
     GROUP BY A.CUST_ID, TO_CHAR(B.YMD,'YYYYMM')
  UNION ALL
    SELECT CUST_ID,        /* 거래처 코드 */
           0      ,                
           0      ,
           0      ,
           0      ,
                        0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
           0      ,   
           0      , 
           0      ,
           0      ,
           0      , 
           0      ,    
           0      ,
           0      ,
           0      ,
           0      ,
           0               MM_01,  /*   1~30     */
           0               MM_02,  /*  31~60     */                
           0               MM_03,  /*  61~90     */
           0               MM_04,  /*  91~120     */
           0               MM_05,  /* 121~150     */
           0               MM_06,  /* 151~180     */
           0                  MM_07,  /* 181~210     */
           0               MM_08,  /* 211~240     */
           0               MM_09,  /* 241~270     */ 
           0               MM_10,  /* 271~300     */
           0               MM_11,  /* 301~360     */
           0               MM_12,  /* 301~360     */
         SUM(MISU_AMT)     MM_13,  /* 361초과     */
         0           MANGI,

        0     ,
             0          
     FROM SALE0306 
    WHERE YMD  <= ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-12)       
    GROUP BY CUST_ID  
    UNION ALL
    SELECT A.CUST_ID,        /* 거래처 코드 */
           0      ,                
           0      ,
           0      ,
           0      ,
                        0     , /* 반품  */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
             0      , /* 반품 */
           0      ,   
           0      , 
           0      ,
           0      ,
           0      , 
           0      ,    
           0      ,
           0      ,
           0      ,
           0      ,
           0               MM_01,  /*   1~30     */
           0               MM_02,  /*  31~60     */                
           0               MM_03,  /*  61~90     */
           0               MM_04,  /*  91~120     */
           0               MM_05,  /* 121~150     */
           0               MM_06,  /* 151~180     */
           0                  MM_07,  /* 181~210     */
           0               MM_08,  /* 211~240     */
           0               MM_09,  /* 241~270     */ 
           0               MM_10,  /* 271~300     */
           0               MM_11,  /* 301~360     */
           0               MM_12,  /* 301~360     */
           0               MM_13,  /* 361초과     */
          MAX(B.END_YMD) - TO_DATE(AS_YM_F||'15','YYYYMMDD')   MANGI    ,
          0     ,
             0      
      FROM SALE0401 A ,SALE0402 B
     WHERE B.END_YMD  > LAST_DAY(AS_YM_F || '01')
       AND B.BILL_GB   IN ( '010','020','025','030','035','040')
       AND A.YMD       = B.YMD
       AND A.JUNPYO_NO = B.JUNPYO_NO      
       GROUP BY A.CUST_ID  
   UNION ALL
   SELECT CUST_ID     CUST_ID,    /* 거래처 코드 */
             0        SU_AMT ,    /* 수금 금액 */
             0        MISU_AMT,   /* 미수금   */
             0                , /* 전월잔고 */
             0           SALE_AMT  , /* 판매     */
             0           BANPUM_01, /* 반품  */
             0           BANPUM_02, /* 반품 */
             0           BANPUM_03, /* 반품 */
             0           BANPUM_04, /* 반품 */
             0           BANPUM_05, /* 반품 */
             0           BANPUM_06, /* 반품 */
             0           BANPUM_07, /* 반품 */
             0           BANPUM_08, /* 반품 */
             0           BANPUM_09, /* 반품 */
             0           BANPUM_10, /* 반품 */
             0           BANPUM_11, /* 반품 */
             0           BANPUM_12, /* 반품 */
             0           BANPUM_13, /* 반품 */            
             0           CASH_AMT,   /* 현금 */
             0           BILL_AMT,   /* 어음 */
             0           CARD_AMT,   /* 카드 */
             0           DC_AMT,     /*매출할인 */
             0           MIDORAE_JA, /*미도래어음(자수) */
             0           MIDORAE_CHA,/*미도래어음(타수) */
             0           DAMBO_1,    /* 약어,약어(신보),어음 */    
             0           DAMBO_2,    /* 가수, 당좌 */
             0              DAMBO_3,   /*'약어','약어(신보)','어음','가수','당좌'*/
             0           BILL   ,
             0           MM_01,  /*   1~30     */
             0           MM_02,  /*  31~60     */                
             0           MM_03,  /*  61~90     */
             0           MM_04,  /*  91~120     */
             0           MM_05,  /* 121~150     */
             0           MM_06,  /* 151~180     */
             0            MM_07,  /* 181~210     */
             0           MM_08,  /* 211~240     */
             0           MM_09,  /* 241~270     */ 
             0           MM_10,  /* 271~300     */
             0           MM_11,  /* 301~360     */
             0           MM_12,  /* 301~360     */
             0           MM_13,  /* 361초과     */
             0           MANGI,
             BEFORE_AMT + MISU_AMT - SU_AMT B_BEFORE_AMT, /*전전월 잔고 */
             BEFORE_AMT  B_B_BEFORE_AMT /*전전전월 잔고 */
       FROM SALE0306 
       WHERE YMD     = ADD_MONTHS(TO_DATE(AS_YM_F||'01' ),-2)        
         ) A    ,
      SALE0003 B
     WHERE A.CUST_ID = B.CUST_ID
       AND SUBSTR(A.CUST_ID,1,1) <> '9' 
       AND B.USE_YN  = 'Y'      
    GROUP BY A.CUST_ID;      
 
    COMMIT;
    
   -- 회전일 구함 
  /*
         UPDATE EIJING C 
            SET C.RATEDAY = (    SELECT TO_DATE(AS_YM_F||'01') - F_RATE_DAY(AS_YM_F,C.CUST_ID) 
                                   FROM DUAL ); */                  
                                   
             
    EXCEPTION
       WHEN OTHERS THEN
          ROLLBACK;
          RAISE_APPLICATION_ERROR(-20099, SUBSTRB('오류!'||SQLCODE||'/'||SQLERRM,1,250)) ;
   
    END P_Eijing_20100315;

/
