CREATE PROCEDURE      SP_X_APP_DETAILGRIDTOTALCOUNT
(
    in_CUST_ID       IN VARCHAR2,
    in_RCUST_ID      IN VARCHAR2,
    in_YMD           IN VARCHAR2,
    in_AVG_MONTH     IN VARCHAR2,
    in_GUMAE_NO      IN VARCHAR2,
    in_SIDX          IN VARCHAR2,
    in_SORD          IN VARCHAR2,
    out_RESULT      OUT TYPES.CURSOR_TYPE,
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_DETAILGRIDTOTALCOUNT
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 

	OPEN out_RESULT FOR
        SELECT COUNT(*) total_cnt, SUM(AMT) total_amt, SUM(VAT) total_vat, SUM(TOT_AMT) total_tot_amt
		  FROM (SELECT   A.YMD          YMD,
				         A.GUMAE_NO     GUMAE_NO,
				         A.ITEM_ID      ITEM_ID,
				         B.ITEM_NM      ITEM_NM,
				         A.QTY          QTY,   
				         A.DANGA        DANGA,   
				         A.AMT          AMT,   
				         A.VAT          VAT,
				         A.AMT + A.VAT  TOT_AMT,   
				         A.RATE         RATE,   
				         A.DC_DANGA     DC_DANGA,
				         A.DC_AMT       DC_AMT,
				         A.DC_QTY       DC_QTY,   
				         B.STANDARD     STANDARD,
				         B.UNIT         UNIT,
				         NVL2(B.COLOR,'R','B') COLOR, 
				         C.MAVG_QTY,
				         C.MQTY,
				         C.PSB_QTY,
				         (select /*+ index_desc(z SYS_C0017312) */ sale.f_sawon_nm(sawon_id) from sale.sale0405 z where z.cust_id = in_CUST_ID and z.rcust_id = in_RCUST_ID and z.item_id = a.item_id and rownum =1) as sawon_nm,
				         A.REQ_QTY REQ_QTY
				    FROM SALE_ON.SALE0204 A, 
				         SALE.SALE0004 B,
				         (
				            SELECT E.ITEM_ID,
				                   ROUND(A.QTY * B.JLIMIT)                                   MAVG_QTY,
				                   NVL(C.MQTY,0) + NVL(D.MQTY,0)                             MQTY,
				                   ROUND(A.QTY * B.JLIMIT) - (NVL(C.MQTY,0) + NVL(D.MQTY,0)) PSB_QTY
				              FROM (
				                    SELECT B.ITEM_ID
				                      FROM SALE.SALE0203 A, SALE.SALE0204 B
				                     WHERE A.CUST_ID  = in_CUST_ID
				                       AND A.RCUST_ID = in_RCUST_ID
				                       AND A.YMD      < TO_DATE(SUBSTR(in_YMD,1,6)||'01') 
				                       AND A.YMD      >= ADD_MONTHS(TO_DATE(SUBSTR(in_YMD,1,6)||'01') ,-3)
				                       AND A.GUMAE_NO = B.GUMAE_NO 
				                    UNION
				                    SELECT B.ITEM_ID
				                      FROM SALE.SALE0203 A, SALE.SALE0204 B
				                     WHERE A.CUST_ID  = in_CUST_ID
				                       AND A.RCUST_ID = in_RCUST_ID
				                       AND A.YMD      >= TO_DATE(SUBSTR(in_YMD,1,6)||'01')  
				                       AND A.YMD      <= LAST_DAY(SUBSTR(in_YMD,1,6)||'01') 
				                       AND A.GUMAE_NO = B.GUMAE_NO 
				                    UNION
				                    SELECT B.ITEM_ID
				                      FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
				                     WHERE A.CUST_ID  = in_CUST_ID
				                       AND A.RCUST_ID = in_RCUST_ID
				                       AND A.YMD      >= TO_DATE(SUBSTR(in_YMD,1,6)||'01')  
				                       AND A.YMD      <= LAST_DAY(SUBSTR(in_YMD,1,6)||'01') 
				                       AND A.GUMAE_NO = B.GUMAE_NO 
				                       AND A.RECEIPT_GB = '1' /*접수*/
				                   ) E,
				                   (
				                    SELECT B.ITEM_ID,
				                           ROUND((NVL(SUM(B.QTY),0)/sale.f_cust_gaip_months(TO_DATE(in_YMD,'YYYYMMDD'),in_CUST_ID))) QTY
				                      FROM SALE.SALE0203 A, SALE.SALE0204 B
				                     WHERE A.CUST_ID  = in_CUST_ID
				                       AND A.RCUST_ID = in_RCUST_ID
				                       AND A.YMD      < TO_DATE(SUBSTR(in_YMD,1,6)||'01') 
				                       AND A.YMD      >= ADD_MONTHS(TO_DATE(SUBSTR(in_YMD,1,6)||'01') ,-3)
				                       AND A.GUMAE_NO = B.GUMAE_NO 
				                     GROUP BY B.ITEM_ID
				                   ) A,
				                   (
				                    SELECT (JUMUN_LIMIT /100) JLIMIT FROM SALE.SALE0003 WHERE CUST_ID = in_CUST_ID
				                   ) B,
				                   (
				                    SELECT B.ITEM_ID,
				                           NVL(SUM(B.QTY),0) MQTY
				                      FROM SALE.SALE0203 A, SALE.SALE0204 B
				                     WHERE A.CUST_ID  = in_CUST_ID
				                       AND A.RCUST_ID = in_RCUST_ID
				                       AND A.YMD      >= TO_DATE(SUBSTR(in_AVG_MONTH,1,6)||'01')  
				                       AND A.YMD      <= LAST_DAY(SUBSTR(in_AVG_MONTH,1,6)||'01') 
				                       AND A.GUMAE_NO = B.GUMAE_NO 
				                     GROUP BY B.ITEM_ID
				                   ) C,
				                   (
				                    SELECT B.ITEM_ID,
				                           NVL(SUM(B.QTY),0) MQTY
				                      FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
				                     WHERE A.CUST_ID  = in_CUST_ID
				                       AND A.RCUST_ID = in_RCUST_ID
				                       AND A.YMD      >= TO_DATE(SUBSTR(in_AVG_MONTH,1,6)||'01')  
				                       AND A.YMD      <= LAST_DAY(SUBSTR(in_AVG_MONTH,1,6)||'01') 
				                       AND A.GUMAE_NO = B.GUMAE_NO 
				                       AND A.RECEIPT_GB = '1' /*접수*/
				                       AND A.WIBAN_ORDER_CONF_YN    <> '2' /*위반주문 지점장 반려한것빼고 */ 
				                     GROUP BY B.ITEM_ID
				                   ) D
				             WHERE E.ITEM_ID = A.ITEM_ID(+)
				               AND E.ITEM_ID = C.ITEM_ID(+)
				               AND E.ITEM_ID = D.ITEM_ID(+)         
				         ) C
				   WHERE A.ITEM_ID  = B.ITEM_ID
				     AND A.GUMAE_NO = in_GUMAE_NO
				     AND A.YMD      = TO_DATE(in_YMD)
				     AND A.ITEM_ID  = C.ITEM_ID(+));
				     
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
