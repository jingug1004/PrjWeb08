CREATE PROCEDURE      P_SALEPART_20130322
            ( I_PRT_GB              IN   VARCHAR2,
              AS_YMD_F              IN   VARCHAR2,
              AS_YMD_T              IN   VARCHAR2,
              AS_PART_GB_F          IN   VARCHAR2,
              AS_PART_GB_T          IN   VARCHAR2,
              AS_DEPT_CD_F          IN   VARCHAR2,
              AS_DEPT_CD_T          IN   VARCHAR2,
              AS_SAWON_ID_F         IN   VARCHAR2,
              AS_SAWON_ID_T         IN   VARCHAR2,
              AL_SILJUKYUL_IN       IN   NUMBER,
              AL_SILJUKYUL_OUT      IN   NUMBER,
              AL_SILJUKYUL_IN_SU    IN   NUMBER,
              AL_SILJUKYUL_OUT_SU   IN   NUMBER,
              AL_SILJUKYUL_BYUNG    IN   NUMBER,
              AL_SILJUKYUL_BYUNG_SU IN   NUMBER
) IS
----------------------------------------------------------------------------
/*   설명: 파트별전체실적 조회를 위하여 출력용 테이블에 생성한다.
   1.2010.02.22 수정: 영업지점별 전체실절에 파트, 부서별로 구분하여 생성
   2.2010.02.23 수정: 영업지점별 전체실절에 파트, 부서별로 소계를 빼고 생성, 팝업용으로 사용하기 위해서...(거래구분 포함(22), 제외(23))
   3.2010.03.24 수정: 파트별 전체실절에서 판매금액을 주문과, 반품으로 구분하여 보여준다.
   4.2010.04.30 수정: 파트별 전체실절에서 반품을 반품과 매출할인외로 구분하여 보여준다.
   5.2012.08.09 수정:-P_SALEPART_BATCH를 생성하면서 사용하지 않던 프로시져 정리하면서 P_SALEPART5 를 P_SALEPART 로 바꿈.
                     -ERP에서는 P_SALEPART 와 P_SALEPART_BATCH를 모두 사용하도록 하고SALEON 과 SFA에서는 P_SALEPART_BATCH 만 사용하도록 함.
                     -사원별전체실적의 SQL 을 파트별전체실적의 SQL과 싱크시킴(서로 다른 내용으로 조회하였던 것임).
  
  호출위치:sale01r07.pbl(w_sale01r07_part)
  
---------------------------------------------------------------------------- */

O_MSG varchar2(100);

BEGIN

   IF    I_PRT_GB = '10' THEN   --파트별 + 실거래포함
        INSERT INTO SALE.SALEPART (
               RPT_GB, DATEF, DATET,
               SILJUKYUL_IN, SILJUKYUL_OUT, SILJUKYUL_IN_SU,
               SILJUKYUL_OUT_SU, SILJUKYUL_BYUNG, SILJUKYUL_BYUNG_SU,
               RORDER, COL1, COL2,
               COL3, COL4, SALE_AMT,
               SALE_AMT_SILJUK_IN, SALE_AMT_SILJUK_IN_LOCAL, SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02, SALE_AMT_SILJUK_IN_03, SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05, SALE_AMT_SILJUK_OUT, SALE_AMT_SILJUK_BYUNG,
               SALE_AMT_SILJUK_MBYUNG, SALE_AMT_BANPUM,
               SALE_AMT_HALIN, SALE_AMT_HALINS01, SALE_AMT_HALINS02,
               SALE_AMT_SILJUK, SALE_PERCENT,
               IN_AMT, IN_AMT_SILJUK_IN, IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01, IN_AMT_SILJUK_IN_02, IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04, IN_AMT_SILJUK_IN_05, IN_AMT_SILJUK_OUT,
               IN_AMT_SILJUK_BYUNG, IN_AMT_SILJUK_MBYUNG, IN_AMT_SILJUK,
               IN_PERCENT
               )
        SELECT '10',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               NULL,
               DECODE(B.CODE2_NM, NULL, ' ', B.CODE2)                  CODE2,
               NVL(B.CODE2_NM, ' ')                                    CODE2_NM,
               DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1)           CODE1,
               NVL(B.CODE1_NM, A.SAWON_NM)                             CODE1_NM,
               SUM(X.sale_amt)                                                                         sale_amt,
               SUM(X.sale_amt_siljuk_in) * nvl(al_siljukyul_in,100) * 0.01                             sale_amt_siljuk_in,
               SUM(X.sale_amt_siljuk_in_LOCAL) * nvl(al_siljukyul_in,100) * 0.01                       sale_amt_siljuk_in_LOCAL,
               SUM(X.SALE_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_01,
               SUM(X.SALE_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_02,
               SUM(X.SALE_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_03,
               SUM(X.SALE_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_04,
               SUM(X.SALE_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_05,
               SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100) * 0.01                         sale_amt_siljuk_out,
               SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_byung,
               SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_mbyung,
               SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_banpum,
               SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_HALIN,
               SUM(X.SALE_AMT_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS01,
               SUM(X.SALE_AMT_HALINS02)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS02,
               (SUM(X.sale_amt_siljuk_in)    * nvl(al_siljukyul_in,   100) * 0.01) +
               (SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,  100) * 0.01) +
               (SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01)                     sale_amt_siljuk,
               DECODE(SUM(NVL(X.sale_amt,0)),0, 0,
                      ROUND(((SUM(X.sale_amt_siljuk_in)     * nvl(al_siljukyul_in,   100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_out)    * nvl(al_siljukyul_out,  100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_byung)  * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALINS01)      * nvl(al_siljukyul_byung,100) * 0.01)) / SUM(X.sale_amt) * 100,2)) sale_percent,
               SUM(X.in_amt)                                                                           in_amt,
               SUM(X.in_amt_siljuk_in) * nvl(al_siljukyul_in_su,100) * 0.01                            in_amt_siljuk_in,
               SUM(X.IN_AMT_SILJUK_IN_LOCAL) * nvl(al_siljukyul_in_su,100) * 0.01                      IN_AMT_SILJUK_IN_LOCAL,
               SUM(X.IN_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_01,
               SUM(X.IN_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_02,
               SUM(X.IN_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_03,
               SUM(X.IN_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_04,
               SUM(X.IN_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_05,
               SUM(X.in_amt_siljuk_out) * nvl(al_siljukyul_out_su,100) * 0.01                          in_amt_siljuk_out,
               SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01                      in_amt_siljuk_byung,
               SUM(X.in_amt_siljuk_mbyung) * nvl(al_siljukyul_byung_su,100) * 0.01                     in_amt_siljuk_mbyung,
               (SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
               (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
               (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
               (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)                    in_amt_siljuk,
               DECODE(SUM(NVL(X.in_amt,0)),0, 0,
                      ROUND(((SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
                             (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(X.in_amt) * 100,2)) in_percent
            FROM SALE0007 A,
                 (select code1, code1_nm, code2, code2_nm from SALE0001 where code_gb = '0013') B,
                 (
                 select sawon_id                          sawon_id,
                            SUM(sale_amt)                 sale_amt,
                            SUM(sale_amt_siljuk_in)       sale_amt_siljuk_in,
                            SUM(sale_amt_siljuk_in_LOCAL) sale_amt_siljuk_in_LOCAL,
                            SUM(SALE_AMT_SILJUK_IN_01)    SALE_AMT_SILJUK_IN_01,
                            SUM(SALE_AMT_SILJUK_IN_02)    SALE_AMT_SILJUK_IN_02,
                            SUM(SALE_AMT_SILJUK_IN_03)    SALE_AMT_SILJUK_IN_03,
                            SUM(SALE_AMT_SILJUK_IN_04)    SALE_AMT_SILJUK_IN_04,
                            SUM(SALE_AMT_SILJUK_IN_05)    SALE_AMT_SILJUK_IN_05,
                            SUM(sale_amt_siljuk_out)      sale_amt_siljuk_out,
                            SUM(sale_amt_banpum)          sale_amt_banpum,
                            SUM(sale_amt_HALIN)           sale_amt_HALIN,
                            SUM(SALE_AMT_HALINS01)        SALE_AMT_HALINS01,
                            SUM(SALE_AMT_HALINS02)        SALE_AMT_HALINS02,
                            SUM(in_amt)                   in_amt,
                            SUM(in_amt_siljuk_in)         in_amt_siljuk_in,
                            SUM(IN_AMT_SILJUK_IN_LOCAL)   IN_AMT_SILJUK_IN_LOCAL,
                            SUM(IN_AMT_SILJUK_IN_01)      IN_AMT_SILJUK_IN_01,
                            SUM(IN_AMT_SILJUK_IN_02)      IN_AMT_SILJUK_IN_02,
                            SUM(IN_AMT_SILJUK_IN_03)      IN_AMT_SILJUK_IN_03,
                            SUM(IN_AMT_SILJUK_IN_04)      IN_AMT_SILJUK_IN_04,
                            SUM(IN_AMT_SILJUK_IN_05)      IN_AMT_SILJUK_IN_05,
                            SUM(in_amt_siljuk_out)        in_amt_siljuk_out,
                            SUM(sale_amt_siljuk_byung)    sale_amt_siljuk_byung,
                            SUM(in_amt_siljuk_byung)      in_amt_siljuk_byung,
                            SUM(sale_amt_siljuk_mbyung)   sale_amt_siljuk_mbyung,
                            SUM(in_amt_siljuk_mbyung)     in_amt_siljuk_mbyung
                      from
                            (select sawon_id,
                                    NVL(sale_amt,0) sale_amt,                 --판매목표
                                    0               sale_amt_siljuk_in,       --매출:간납합계
                                    0               sale_amt_siljuk_in_LOCAL, --매출:도매로컬
                                    0               SALE_AMT_SILJUK_IN_01,    --매출:의원
                                    0               SALE_AMT_SILJUK_IN_02,    --매출:일반간납
                                    0               SALE_AMT_SILJUK_IN_03,    --매출:턴키
                                    0               SALE_AMT_SILJUK_IN_04,    --매출:입찰
                                    0               SALE_AMT_SILJUK_IN_05,    --매출:기타
                                    0               sale_amt_siljuk_out,      --매출:약국
                                    0               sale_amt_banpum,          --매출:반품
                                    0               sale_amt_HALIN,           --매출:매출할인외
                                    0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                    0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                    NVL(in_amt,0)   in_amt,                   --수금목표
                                    0               in_amt_siljuk_in,         --수금:간납합계
                                    0               IN_AMT_SILJUK_IN_LOCAL,   --수금:도매로컬
                                    0               IN_AMT_SILJUK_IN_01,      --수금:의원
                                    0               IN_AMT_SILJUK_IN_02,      --수금:일반간납
                                    0               IN_AMT_SILJUK_IN_03,      --수금:턴키
                                    0               IN_AMT_SILJUK_IN_04,      --수금:입찰
                                    0               IN_AMT_SILJUK_IN_05,      --수금:기타
                                    0               in_amt_siljuk_out,        --수금:약국
                                    0               sale_amt_siljuk_byung,    --매출:종합병원
                                    0               in_amt_siljuk_byung,      --수금:종합병원
                                    0               sale_amt_siljuk_mbyung,   --매출:준종합병원
                                    0               in_amt_siljuk_mbyung      --수금:준종합병원
                               from SALE0403
                              where YMD BETWEEN to_date(substrb(NVL(as_ymd_f,'190001'),1,6)||'01','yyyymmdd')
                                AND last_day(to_date(substrb(NVL(as_ymd_t,'290001'),1,6),'yyyymm'))
                             union all
                             select F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',DECODE(SUBSTR(GEORAE.RCUST_ID,1,1),'4',NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',DECODE(LEAST('6'||' ',SUBSTR(GEORAE.RCUST_ID,1,1)),'6'||' ', NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(substr(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),0)),
                                    sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                              '12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)), --매출할인
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0)), --수금할인(일반)
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0)),        --수금할인(조건)
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0
                               from SALE0207 GEORAE, SALE0208 GEORAE_D
                              where GEORAE.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                                AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                and GEORAE.deal_no  = GEORAE_D.deal_no
                                and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                              group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD)
                             union all
                             SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                     END SAWON_ID,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0               sale_amt_HALIN,           --매출:매출할인외
                                     0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                     0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUM.cash_amt,0),0)),
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)),
                                     0,
                                     0,
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUM.cash_amt,0),0))
                                from SALE0401 SUGUM
                               where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                 and SUGUM.JUNPYO_GB       LIKE '0%'
                                 and NVL(SUGUM.cash_amt,0) <> 0
                               GROUP BY CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                        END
                            union all
                            select CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD IS NULL
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            select CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD') AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6))
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END
                            union all
                            select CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd < to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6) AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6))
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                        )
                 group by sawon_id
                 ) X
          WHERE A.SAWON_ID =  X.SAWON_ID
            AND A.PART_GB  =  B.CODE1(+)
            AND NVL(A.PART_GB,  '0') BETWEEN AS_PART_GB_F  AND AS_PART_GB_T
            AND NVL(A.DEPT_CD,  '0') BETWEEN AS_DEPT_CD_F  AND AS_DEPT_CD_T
            AND NVL(A.SAWON_ID, '0') BETWEEN AS_SAWON_ID_F AND AS_SAWON_ID_T
          GROUP BY DECODE(B.CODE2_NM, NULL, ' ', B.CODE2),
                   NVL(B.CODE2_NM, ' '),
                   DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1),
                   NVL(B.CODE1_NM, A.SAWON_NM);





   ELSIF I_PRT_GB = '11' THEN   --파트별 + 실거래제외
        INSERT INTO SALE.SALEPART (
               RPT_GB, DATEF, DATET,
               SILJUKYUL_IN, SILJUKYUL_OUT, SILJUKYUL_IN_SU,
               SILJUKYUL_OUT_SU, SILJUKYUL_BYUNG, SILJUKYUL_BYUNG_SU,
               RORDER, COL1, COL2,
               COL3, COL4, SALE_AMT,
               SALE_AMT_SILJUK_IN, SALE_AMT_SILJUK_IN_LOCAL, SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02, SALE_AMT_SILJUK_IN_03, SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05, SALE_AMT_SILJUK_OUT, SALE_AMT_SILJUK_BYUNG,
               SALE_AMT_SILJUK_MBYUNG, SALE_AMT_BANPUM,
               SALE_AMT_HALIN, SALE_AMT_HALINS01, SALE_AMT_HALINS02,
               SALE_AMT_SILJUK, SALE_PERCENT,
               IN_AMT, IN_AMT_SILJUK_IN, IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01, IN_AMT_SILJUK_IN_02, IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04, IN_AMT_SILJUK_IN_05, IN_AMT_SILJUK_OUT,
               IN_AMT_SILJUK_BYUNG, IN_AMT_SILJUK_MBYUNG, IN_AMT_SILJUK,
               IN_PERCENT
               )
        SELECT '11',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               NULL,
               DECODE(B.CODE2_NM, NULL, ' ', B.CODE2)                  CODE2,
               NVL(B.CODE2_NM, ' ')                                    CODE2_NM,
               DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1)           CODE1,
               NVL(B.CODE1_NM, A.SAWON_NM)                             CODE1_NM,
               SUM(X.sale_amt)                                                                          sale_amt,
               SUM(X.sale_amt_siljuk_in) * nvl(al_siljukyul_in,100) * 0.01                             sale_amt_siljuk_in,
               SUM(X.sale_amt_siljuk_in_LOCAL) * nvl(al_siljukyul_in,100) * 0.01                       sale_amt_siljuk_in_LOCAL,
               SUM(X.SALE_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_01,
               SUM(X.SALE_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_02,
               SUM(X.SALE_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_03,
               SUM(X.SALE_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_04,
               SUM(X.SALE_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_05,
               SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100) * 0.01                         sale_amt_siljuk_out,
               SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_byung,
               SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_mbyung,
               SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_banpum,
               SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_HALIN,
               SUM(X.SALE_AMT_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS01,
               SUM(X.SALE_AMT_HALINS02)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS02,
               (SUM(X.sale_amt_siljuk_in)    * nvl(al_siljukyul_in,   100) * 0.01) +
               (SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,  100) * 0.01) +
               (SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALINs01)     * nvl(al_siljukyul_byung,100) * 0.01)                     sale_amt_siljuk,
               DECODE(SUM(NVL(X.sale_amt,0)),0, 0,
                      ROUND(((SUM(X.sale_amt_siljuk_in)     * nvl(al_siljukyul_in,   100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_out)    * nvl(al_siljukyul_out,  100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_byung)  * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALINs01)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(X.sale_amt) * 100,2)) sale_percent,
               SUM(X.in_amt)                                                                            in_amt,
               SUM(X.in_amt_siljuk_in) * nvl(al_siljukyul_in_su,100) * 0.01                            in_amt_siljuk_in,
               SUM(X.IN_AMT_SILJUK_IN_LOCAL) * nvl(al_siljukyul_in_su,100) * 0.01                      IN_AMT_SILJUK_IN_LOCAL,
               SUM(X.IN_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_01,
               SUM(X.IN_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_02,
               SUM(X.IN_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_03,
               SUM(X.IN_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_04,
               SUM(X.IN_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_05,
               SUM(X.in_amt_siljuk_out) * nvl(al_siljukyul_out_su,100) * 0.01                          in_amt_siljuk_out,
               SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01                      in_amt_siljuk_byung,
               SUM(X.in_amt_siljuk_mbyung) * nvl(al_siljukyul_byung_su,100) * 0.01                     in_amt_siljuk_mbyung,
               (SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
               (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
               (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
               (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)                    in_amt_siljuk,
               DECODE(SUM(NVL(X.in_amt,0)),0, 0,
                      ROUND(((SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
                             (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(X.in_amt) * 100,2)) in_percent
            FROM SALE0007 A,
                 (select code1, code1_nm, code2, code2_nm from SALE0001 where code_gb = '0013') B,
                 (
                 select sawon_id                          sawon_id,
                            SUM(sale_amt)                 sale_amt,
                            SUM(sale_amt_siljuk_in)       sale_amt_siljuk_in,
                            SUM(sale_amt_siljuk_in_LOCAL) sale_amt_siljuk_in_LOCAL,
                            SUM(SALE_AMT_SILJUK_IN_01)    SALE_AMT_SILJUK_IN_01,
                            SUM(SALE_AMT_SILJUK_IN_02)    SALE_AMT_SILJUK_IN_02,
                            SUM(SALE_AMT_SILJUK_IN_03)    SALE_AMT_SILJUK_IN_03,
                            SUM(SALE_AMT_SILJUK_IN_04)    SALE_AMT_SILJUK_IN_04,
                            SUM(SALE_AMT_SILJUK_IN_05)    SALE_AMT_SILJUK_IN_05,
                            SUM(sale_amt_siljuk_out)      sale_amt_siljuk_out,
                            SUM(sale_amt_banpum)          sale_amt_banpum,
                            SUM(sale_amt_HALIN)           sale_amt_HALIN,
                            SUM(SALE_AMT_HALINS01)        SALE_AMT_HALINS01,
                            SUM(SALE_AMT_HALINS02)        SALE_AMT_HALINS02,
                            SUM(in_amt)                   in_amt,
                            SUM(in_amt_siljuk_in)         in_amt_siljuk_in,
                            SUM(IN_AMT_SILJUK_IN_LOCAL)   IN_AMT_SILJUK_IN_LOCAL,
                            SUM(IN_AMT_SILJUK_IN_01)      IN_AMT_SILJUK_IN_01,
                            SUM(IN_AMT_SILJUK_IN_02)      IN_AMT_SILJUK_IN_02,
                            SUM(IN_AMT_SILJUK_IN_03)      IN_AMT_SILJUK_IN_03,
                            SUM(IN_AMT_SILJUK_IN_04)      IN_AMT_SILJUK_IN_04,
                            SUM(IN_AMT_SILJUK_IN_05)      IN_AMT_SILJUK_IN_05,
                            SUM(in_amt_siljuk_out)        in_amt_siljuk_out,
                            SUM(sale_amt_siljuk_byung)    sale_amt_siljuk_byung,
                            SUM(in_amt_siljuk_byung)      in_amt_siljuk_byung,
                            SUM(sale_amt_siljuk_mbyung)   sale_amt_siljuk_mbyung,
                            SUM(in_amt_siljuk_mbyung)     in_amt_siljuk_mbyung
                      from
                            (select sawon_id,
                                    NVL(sale_amt,0) sale_amt,                 --판매목표
                                    0               sale_amt_siljuk_in,       --매출:간납합계
                                    0               sale_amt_siljuk_in_LOCAL, --매출:도매로컬
                                    0               SALE_AMT_SILJUK_IN_01,    --매출:의원
                                    0               SALE_AMT_SILJUK_IN_02,    --매출:일반간납
                                    0               SALE_AMT_SILJUK_IN_03,    --매출:턴키
                                    0               SALE_AMT_SILJUK_IN_04,    --매출:입찰
                                    0               SALE_AMT_SILJUK_IN_05,    --매출:기타
                                    0               sale_amt_siljuk_out,      --매출:약국
                                    0               sale_amt_banpum,          --매출:반품
                                    0               sale_amt_HALIN,           --매출:매출할인외
                                    0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                    0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                    NVL(in_amt,0)   in_amt,                   --수금목표
                                    0               in_amt_siljuk_in,         --수금:간납합계
                                    0               IN_AMT_SILJUK_IN_LOCAL,   --수금:도매로컬
                                    0               IN_AMT_SILJUK_IN_01,      --수금:의원
                                    0               IN_AMT_SILJUK_IN_02,      --수금:일반간납
                                    0               IN_AMT_SILJUK_IN_03,      --수금:턴키
                                    0               IN_AMT_SILJUK_IN_04,      --수금:입찰
                                    0               IN_AMT_SILJUK_IN_05,      --수금:기타
                                    0               in_amt_siljuk_out,        --수금:약국
                                    0               sale_amt_siljuk_byung,    --매출:종합병원
                                    0               in_amt_siljuk_byung,      --수금:종합병원
                                    0               sale_amt_siljuk_mbyung,   --매출:준종합병원
                                    0               in_amt_siljuk_mbyung      --수금:준종합병원
                               from SALE0403
                              where YMD BETWEEN to_date(substrb(NVL(as_ymd_f,'190001'),1,6)||'01','yyyymmdd')
                                AND last_day(to_date(substrb(NVL(as_ymd_t,'290001'),1,6),'yyyymm'))
                             union all
                             select F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(CUST.cust_gb1,'10',DECODE(SUBSTR(GEORAE.RCUST_ID,1,1),'4',NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(CUST.cust_gb1,'10',DECODE(LEAST('6'||' ',SUBSTR(GEORAE.RCUST_ID,1,1)),'6'||' ', NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(SUBSTR(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),0)),
                                    sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                              '12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)), --매출할인
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0)), --수금할인(일반)
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0)),        --수금할인(조건)
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0
                               from SALE0207 GEORAE, SALE0208 GEORAE_D, SALE0003 CUST
                              where GEORAE.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                                AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                and GEORAE.deal_no  = GEORAE_D.deal_no
                                and GEORAE.rcust_id = CUST.cust_id
                                and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                              group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD)
                             union all
                             SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                     END SAWON_ID,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0               sale_amt_HALIN,           --매출:매출할인외
                                     0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                     0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                     0,
                                     sum(decode(CUST.cust_gb1,'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'05', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(CUST.cust_gb1,'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'05', NVL(SUGUM.cash_amt,0),0)),
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)),
                                     0,
                                     0,
                                     0,
                                     sum(decode(CUST.cust_gb1,'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(CUST.cust_gb1,'20',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(CUST.cust_gb1,'60',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(CUST.cust_gb1,'80',NVL(SUGUM.cash_amt,0),0))
                                from SALE0401 SUGUM, SALE0003 CUST
                               where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                 and SUGUM.rcust_id        = CUST.cust_id
                                 and SUGUM.JUNPYO_GB       LIKE '0%'
                                 and NVL(SUGUM.cash_amt,0) <> 0
                               GROUP BY CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                        END
                            union all
                            SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                         THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                         ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                    END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD IS NULL
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                         THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                         ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                    END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD') AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD'),6))
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                         THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                         ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                    END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd < to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD'),6) AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD'),6))
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                        )
                 group by sawon_id
                 ) X
          WHERE A.SAWON_ID =  X.SAWON_ID
            AND A.PART_GB  =  B.CODE1(+)
            AND NVL(A.PART_GB,  '0') BETWEEN AS_PART_GB_F  AND AS_PART_GB_T
            AND NVL(A.DEPT_CD,  '0') BETWEEN AS_DEPT_CD_F  AND AS_DEPT_CD_T
            AND NVL(A.SAWON_ID, '0') BETWEEN AS_SAWON_ID_F AND AS_SAWON_ID_T
          GROUP BY DECODE(B.CODE2_NM, NULL, ' ', B.CODE2),
                   NVL(B.CODE2_NM, ' '),
                   DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1),
                   NVL(B.CODE1_NM, A.SAWON_NM);

   ELSIF I_PRT_GB = '20' THEN  --지점별 + 실거래포함
        INSERT INTO SALE.SALEPART (
               RPT_GB, DATEF, DATET,
               SILJUKYUL_IN, SILJUKYUL_OUT, SILJUKYUL_IN_SU,
               SILJUKYUL_OUT_SU, SILJUKYUL_BYUNG, SILJUKYUL_BYUNG_SU,
               RORDER, COL1, COL2,
               COL3, COL4, SALE_AMT,
               SALE_AMT_SILJUK_IN, SALE_AMT_SILJUK_IN_LOCAL, SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02, SALE_AMT_SILJUK_IN_03, SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05, SALE_AMT_SILJUK_OUT, SALE_AMT_SILJUK_BYUNG,
               SALE_AMT_SILJUK_MBYUNG, SALE_AMT_BANPUM,
               SALE_AMT_HALIN, SALE_AMT_HALINS01, SALE_AMT_HALINS02,
               SALE_AMT_SILJUK, SALE_PERCENT,
               IN_AMT, IN_AMT_SILJUK_IN, IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01, IN_AMT_SILJUK_IN_02, IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04, IN_AMT_SILJUK_IN_05, IN_AMT_SILJUK_OUT,
               IN_AMT_SILJUK_BYUNG, IN_AMT_SILJUK_MBYUNG, IN_AMT_SILJUK,
               IN_PERCENT
               )
        WITH LIST AS (
        SELECT NVL(C.RORDER, 9999)                                     RORDER,
               DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1)           CODE1,
               NVL(B.CODE1_NM, A.SAWON_NM)                             CODE1_NM,
               DECODE(C.DEPT_NM, NULL, X.SAWON_ID, C.DEPT_CD)          DEPT_CD,
               NVL(C.DEPT_NM, A.SAWON_NM)                              DEPT_NM,
               SUM(X.sale_amt)                                                                         sale_amt,
               SUM(X.sale_amt_siljuk_in) * nvl(al_siljukyul_in,100) * 0.01                             sale_amt_siljuk_in,
               SUM(X.sale_amt_siljuk_in_LOCAL) * nvl(al_siljukyul_in,100) * 0.01                       sale_amt_siljuk_in_LOCAL,
               SUM(X.SALE_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_01,
               SUM(X.SALE_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_02,
               SUM(X.SALE_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_03,
               SUM(X.SALE_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_04,
               SUM(X.SALE_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_05,
               SUM(X.sale_amt_siljuk_out) * nvl(al_siljukyul_out,100) * 0.01                           sale_amt_siljuk_out,
               SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_byung,
               SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01                      sale_amt_siljuk_mbyung,
               SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_banpum,
               SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_HALIN,
               SUM(X.SALE_AMT_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS01,
               SUM(X.SALE_AMT_HALINS02)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS02,               
               (SUM(X.sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
               (SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
               (SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01)                       sale_amt_siljuk,
               DECODE(SUM(NVL(X.sale_amt,0)),0, 0,
                      ROUND(((SUM(X.sale_amt_siljuk_in)     * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(X.sale_amt_siljuk_out)    * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(X.sale_amt_siljuk_byung)  * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALINS01)      * nvl(al_siljukyul_byung,100) * 0.01)) / SUM(X.sale_amt) * 100,2)) sale_percent,
               SUM(X.in_amt)                                                                            in_amt,
               SUM(X.in_amt_siljuk_in) * nvl(al_siljukyul_in_su,100) * 0.01                            in_amt_siljuk_in,
               SUM(X.IN_AMT_SILJUK_IN_LOCAL) * nvl(al_siljukyul_in_su,100) * 0.01                      IN_AMT_SILJUK_IN_LOCAL,
               SUM(X.IN_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_01,
               SUM(X.IN_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_02,
               SUM(X.IN_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_03,
               SUM(X.IN_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_04,
               SUM(X.IN_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_05,
               SUM(X.in_amt_siljuk_out) * nvl(al_siljukyul_out_su,100) * 0.01                          in_amt_siljuk_out,
               SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01                      in_amt_siljuk_byung,
               SUM(X.in_amt_siljuk_mbyung) * nvl(al_siljukyul_byung_su,100) * 0.01                     in_amt_siljuk_mbyung,
               (SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
               (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
               (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
               (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)                    in_amt_siljuk,
               DECODE(SUM(NVL(X.in_amt,0)),0, 0,
                      ROUND(((SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
                             (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(X.in_amt) * 100,2)) in_percent
            FROM SALE0007 A,
                 (select code1, code1_nm, code2, code2_nm from SALE0001 where code_gb = '0013') B,
                 SALE0008 C,
                 (
                 select sawon_id                          sawon_id,
                            SUM(sale_amt)                 sale_amt,
                            SUM(sale_amt_siljuk_in)       sale_amt_siljuk_in,
                            SUM(sale_amt_siljuk_in_LOCAL) sale_amt_siljuk_in_LOCAL,
                            SUM(SALE_AMT_SILJUK_IN_01)    SALE_AMT_SILJUK_IN_01,
                            SUM(SALE_AMT_SILJUK_IN_02)    SALE_AMT_SILJUK_IN_02,
                            SUM(SALE_AMT_SILJUK_IN_03)    SALE_AMT_SILJUK_IN_03,
                            SUM(SALE_AMT_SILJUK_IN_04)    SALE_AMT_SILJUK_IN_04,
                            SUM(SALE_AMT_SILJUK_IN_05)    SALE_AMT_SILJUK_IN_05,
                            SUM(sale_amt_siljuk_out)      sale_amt_siljuk_out,
                            SUM(sale_amt_banpum)          sale_amt_banpum,
                            SUM(sale_amt_HALIN)           sale_amt_HALIN,
                            SUM(SALE_AMT_HALINS01)        SALE_AMT_HALINS01,
                            SUM(SALE_AMT_HALINS02)        SALE_AMT_HALINS02,
                            SUM(in_amt)                   in_amt,
                            SUM(in_amt_siljuk_in)         in_amt_siljuk_in,
                            SUM(IN_AMT_SILJUK_IN_LOCAL)   IN_AMT_SILJUK_IN_LOCAL,
                            SUM(IN_AMT_SILJUK_IN_01)      IN_AMT_SILJUK_IN_01,
                            SUM(IN_AMT_SILJUK_IN_02)      IN_AMT_SILJUK_IN_02,
                            SUM(IN_AMT_SILJUK_IN_03)      IN_AMT_SILJUK_IN_03,
                            SUM(IN_AMT_SILJUK_IN_04)      IN_AMT_SILJUK_IN_04,
                            SUM(IN_AMT_SILJUK_IN_05)      IN_AMT_SILJUK_IN_05,
                            SUM(in_amt_siljuk_out)        in_amt_siljuk_out,
                            SUM(sale_amt_siljuk_byung)    sale_amt_siljuk_byung,
                            SUM(in_amt_siljuk_byung)      in_amt_siljuk_byung,
                            SUM(sale_amt_siljuk_mbyung)   sale_amt_siljuk_mbyung,
                            SUM(in_amt_siljuk_mbyung)     in_amt_siljuk_mbyung
                      from
                            (select sawon_id,
                                    NVL(sale_amt,0) sale_amt,                 --판매목표
                                    0               sale_amt_siljuk_in,       --매출:간납합계
                                    0               sale_amt_siljuk_in_LOCAL, --매출:도매로컬
                                    0               SALE_AMT_SILJUK_IN_01,    --매출:의원
                                    0               SALE_AMT_SILJUK_IN_02,    --매출:일반간납
                                    0               SALE_AMT_SILJUK_IN_03,    --매출:턴키
                                    0               SALE_AMT_SILJUK_IN_04,    --매출:입찰
                                    0               SALE_AMT_SILJUK_IN_05,    --매출:기타
                                    0               sale_amt_siljuk_out,      --매출:약국
                                    0               sale_amt_banpum,          --매출:반품
                                    0               sale_amt_HALIN,           --매출:매출할인외
                                    0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                    0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                    NVL(in_amt,0)   in_amt,                   --수금목표
                                    0               in_amt_siljuk_in,         --수금:간납합계
                                    0               IN_AMT_SILJUK_IN_LOCAL,   --수금:도매로컬
                                    0               IN_AMT_SILJUK_IN_01,      --수금:의원
                                    0               IN_AMT_SILJUK_IN_02,      --수금:일반간납
                                    0               IN_AMT_SILJUK_IN_03,      --수금:턴키
                                    0               IN_AMT_SILJUK_IN_04,      --수금:입찰
                                    0               IN_AMT_SILJUK_IN_05,      --수금:기타
                                    0               in_amt_siljuk_out,        --수금:약국
                                    0               sale_amt_siljuk_byung,    --매출:종합병원
                                    0               in_amt_siljuk_byung,      --수금:종합병원
                                    0               sale_amt_siljuk_mbyung,   --매출:준종합병원
                                    0               in_amt_siljuk_mbyung      --수금:준종합병원
                               from SALE0403
                              where YMD BETWEEN to_date(substrb(NVL(as_ymd_f,'190001'),1,6)||'01','yyyymmdd')
                                AND last_day(to_date(substrb(NVL(as_ymd_t,'290001'),1,6),'yyyymm'))
                             union all
                             select F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',DECODE(SUBSTR(GEORAE.RCUST_ID,1,1),'4',NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',DECODE(LEAST('6'||' ',SUBSTR(GEORAE.RCUST_ID,1,1)),'6'||' ', NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(substr(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),0)),
                                    sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                              '12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)), --매출할인
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0)), --수금할인(일반)
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0)),        --수금할인(조건)
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0
                               from SALE0207 GEORAE, SALE0208 GEORAE_D
                              where GEORAE.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                                AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                and GEORAE.deal_no  = GEORAE_D.deal_no
                                and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                              group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD)
                             union all
                             SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                     END SAWON_ID,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0               sale_amt_HALIN,           --매출:매출할인외
                                     0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                     0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUM.cash_amt,0),0)),
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)),
                                     0,
                                     0,
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUM.cash_amt,0),0))
                                from SALE0401 SUGUM
                               where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                 and SUGUM.JUNPYO_GB       LIKE '0%'
                                 and NVL(SUGUM.cash_amt,0) <> 0
                               GROUP BY CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                        END
                            union all
                            select CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD IS NULL
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            select CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD') AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6))
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END
                            union all
                            select CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd < to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6) AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6))
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                        )
                 group by sawon_id
                 ) X
          WHERE A.SAWON_ID = X.SAWON_ID
            AND A.PART_GB  = B.CODE1(+)
            AND A.DEPT_CD  = C.DEPT_CD(+)
            AND NVL(A.PART_GB,  '0') BETWEEN '01' AND '07' --영업부계내역만
            AND NVL(A.PART_GB,  '0') BETWEEN AS_PART_GB_F  AND AS_PART_GB_T
            AND NVL(A.DEPT_CD,  '0') BETWEEN AS_DEPT_CD_F  AND AS_DEPT_CD_T
            AND NVL(A.SAWON_ID, '0') BETWEEN AS_SAWON_ID_F AND AS_SAWON_ID_T
          GROUP BY NVL(C.RORDER, 9999),
                   DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1),
                   NVL(B.CODE1_NM, A.SAWON_NM),
                   DECODE(C.DEPT_NM, NULL, X.SAWON_ID, C.DEPT_CD),
                   NVL(C.DEPT_NM, A.SAWON_NM)
        )
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               RORDER,
               CODE1,
               CODE1_NM,
               DEPT_CD,
               DEPT_NM,
               sale_amt,
               sale_amt_siljuk_in,
               sale_amt_siljuk_in_LOCAL,
               SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02,
               SALE_AMT_SILJUK_IN_03,
               SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05,
               sale_amt_siljuk_out,
               sale_amt_siljuk_byung,
               sale_amt_siljuk_mbyung,
               sale_amt_banpum,  
               sale_amt_HALIN,   
               SALE_AMT_HALINS01,
               SALE_AMT_HALINS02,
               sale_amt_siljuk,
               sale_percent,
               in_amt,
               in_amt_siljuk_in,
               IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01,
               IN_AMT_SILJUK_IN_02,
               IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04,
               IN_AMT_SILJUK_IN_05,
               in_amt_siljuk_out,
               in_amt_siljuk_byung,
               in_amt_siljuk_mbyung,
               in_amt_siljuk,
               in_percent
          FROM LIST
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               49                RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울로컬1계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 10 AND 48
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               78                RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울로컬2계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 50 AND 77
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               79                RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울로컬 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 10 AND 77
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               119               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울종병 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 80 AND 118
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               138               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울세미 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 120 AND 137
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               139               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 10 AND 137
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               159               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<대전로컬 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 140 AND 158
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               179               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<대전   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 140 AND 178
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               180               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<청주   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 180 AND 188
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               219               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<전주   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 190 AND 218
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               239               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<광주로컬 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 220 AND 238
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               259               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<광주   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 220 AND 258
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               289               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<부산로컬 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 260 AND 288
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               309               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<부산   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 260 AND 308
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               329               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<울산   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 310 AND 328
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               349               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<대구로컬 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 330 AND 348
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               369               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<대구   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 330 AND 368
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               399               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<창원   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 370 AND 398
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               419               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<원주   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 400 AND 418
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               439               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<인천   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 420 AND 438
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               449               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<수원   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 440 AND 448
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               459               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<경인   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 450 AND 458
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               469                RORDER,
               NULL,
               NULL,
               'ZZ'               DEPT_CD,
               '<<도매부  소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 460 AND 468
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               479               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<O1 소계>>'  DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 470 AND 478
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               489               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<제주   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 480 AND 488
        UNION ALL
        SELECT '20',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               609               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<도매로컬 소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 490 AND 608 ;

   ELSIF I_PRT_GB = '21' THEN    --지점별 + 실거래제외
        INSERT INTO SALE.SALEPART (
               RPT_GB, DATEF, DATET,
               SILJUKYUL_IN, SILJUKYUL_OUT, SILJUKYUL_IN_SU,
               SILJUKYUL_OUT_SU, SILJUKYUL_BYUNG, SILJUKYUL_BYUNG_SU,
               RORDER, COL1, COL2,
               COL3, COL4, SALE_AMT,
               SALE_AMT_SILJUK_IN, SALE_AMT_SILJUK_IN_LOCAL, SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02, SALE_AMT_SILJUK_IN_03, SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05, SALE_AMT_SILJUK_OUT, SALE_AMT_SILJUK_BYUNG,
               SALE_AMT_SILJUK_MBYUNG, SALE_AMT_BANPUM,
               SALE_AMT_HALIN, SALE_AMT_HALINS01, SALE_AMT_HALINS02,
               SALE_AMT_SILJUK, SALE_PERCENT,
               IN_AMT, IN_AMT_SILJUK_IN, IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01, IN_AMT_SILJUK_IN_02, IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04, IN_AMT_SILJUK_IN_05, IN_AMT_SILJUK_OUT,
               IN_AMT_SILJUK_BYUNG, IN_AMT_SILJUK_MBYUNG, IN_AMT_SILJUK,
               IN_PERCENT
               )
        WITH LIST AS (
        SELECT NVL(C.RORDER, 9999)                                     RORDER,
               DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1)           CODE1,
               NVL(B.CODE1_NM, A.SAWON_NM)                             CODE1_NM,
               DECODE(C.DEPT_NM, NULL, X.SAWON_ID, C.DEPT_CD)          DEPT_CD,
               NVL(C.DEPT_NM, A.SAWON_NM)                              DEPT_NM,
               SUM(X.sale_amt)                                                                         sale_amt,
               SUM(X.sale_amt_siljuk_in) * nvl(al_siljukyul_in,100) * 0.01                             sale_amt_siljuk_in,
               SUM(X.sale_amt_siljuk_in_LOCAL) * nvl(al_siljukyul_in,100) * 0.01                       sale_amt_siljuk_in_LOCAL,
               SUM(X.SALE_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_01,
               SUM(X.SALE_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_02,
               SUM(X.SALE_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_03,
               SUM(X.SALE_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_04,
               SUM(X.SALE_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_05,
               SUM(X.sale_amt_siljuk_out) * nvl(al_siljukyul_out,100) * 0.01                           sale_amt_siljuk_out,
               SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_byung,
               SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01                      sale_amt_siljuk_mbyung,
               SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_banpum,
               SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_HALIN,
               SUM(X.SALE_AMT_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS01,
               SUM(X.SALE_AMT_HALINS02)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS02,
               (SUM(X.sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
               (SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
               (SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01)                     sale_amt_siljuk,  --영업관리부의 요청으로 sale_amt_HALINS02 빠짐
               DECODE(SUM(NVL(X.sale_amt,0)),0, 0,
                      ROUND(((SUM(X.sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01)) / SUM(X.sale_amt) * 100,2)) sale_percent,
               SUM(X.in_amt)                                                                            in_amt,
               SUM(X.in_amt_siljuk_in) * nvl(al_siljukyul_in_su,100) * 0.01                            in_amt_siljuk_in,
               SUM(X.IN_AMT_SILJUK_IN_LOCAL) * nvl(al_siljukyul_in_su,100) * 0.01                      IN_AMT_SILJUK_IN_LOCAL,
               SUM(X.IN_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_01,
               SUM(X.IN_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_02,
               SUM(X.IN_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_03,
               SUM(X.IN_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_04,
               SUM(X.IN_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_05,
               SUM(X.in_amt_siljuk_out) * nvl(al_siljukyul_out_su,100) * 0.01                          in_amt_siljuk_out,
               SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01                      in_amt_siljuk_byung,
               SUM(X.in_amt_siljuk_mbyung) * nvl(al_siljukyul_byung_su,100) * 0.01                     in_amt_siljuk_mbyung,
               (SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
               (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
               (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
               (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)                    in_amt_siljuk,
               DECODE(SUM(NVL(X.in_amt,0)),0, 0,
                      ROUND(((SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
                             (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(X.sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALINS01)      * nvl(al_siljukyul_byung,100) * 0.01)) / SUM(X.in_amt) * 100,2)) in_percent
            FROM SALE0007 A,
                 (select code1, code1_nm, code2, code2_nm from SALE0001 where code_gb = '0013') B,
                 SALE0008 C,
                 (
                 select sawon_id                          sawon_id,
                            SUM(sale_amt)                 sale_amt,
                            SUM(sale_amt_siljuk_in)       sale_amt_siljuk_in,
                            SUM(sale_amt_siljuk_in_LOCAL) sale_amt_siljuk_in_LOCAL,
                            SUM(SALE_AMT_SILJUK_IN_01)    SALE_AMT_SILJUK_IN_01,
                            SUM(SALE_AMT_SILJUK_IN_02)    SALE_AMT_SILJUK_IN_02,
                            SUM(SALE_AMT_SILJUK_IN_03)    SALE_AMT_SILJUK_IN_03,
                            SUM(SALE_AMT_SILJUK_IN_04)    SALE_AMT_SILJUK_IN_04,
                            SUM(SALE_AMT_SILJUK_IN_05)    SALE_AMT_SILJUK_IN_05,
                            SUM(sale_amt_siljuk_out)      sale_amt_siljuk_out,
                            SUM(sale_amt_banpum)          sale_amt_banpum,
                            SUM(sale_amt_HALIN)           sale_amt_HALIN,
                            SUM(SALE_AMT_HALINS01)        SALE_AMT_HALINS01,
                            SUM(SALE_AMT_HALINS02)        SALE_AMT_HALINS02,
                            SUM(in_amt)                   in_amt,
                            SUM(in_amt_siljuk_in)         in_amt_siljuk_in,
                            SUM(IN_AMT_SILJUK_IN_LOCAL)   IN_AMT_SILJUK_IN_LOCAL,
                            SUM(IN_AMT_SILJUK_IN_01)      IN_AMT_SILJUK_IN_01,
                            SUM(IN_AMT_SILJUK_IN_02)      IN_AMT_SILJUK_IN_02,
                            SUM(IN_AMT_SILJUK_IN_03)      IN_AMT_SILJUK_IN_03,
                            SUM(IN_AMT_SILJUK_IN_04)      IN_AMT_SILJUK_IN_04,
                            SUM(IN_AMT_SILJUK_IN_05)      IN_AMT_SILJUK_IN_05,
                            SUM(in_amt_siljuk_out)        in_amt_siljuk_out,
                            SUM(sale_amt_siljuk_byung)    sale_amt_siljuk_byung,
                            SUM(in_amt_siljuk_byung)      in_amt_siljuk_byung,
                            SUM(sale_amt_siljuk_mbyung)   sale_amt_siljuk_mbyung,
                            SUM(in_amt_siljuk_mbyung)     in_amt_siljuk_mbyung
                      from
                            (select sawon_id,
                                    NVL(sale_amt,0) sale_amt,                 --판매목표
                                    0               sale_amt_siljuk_in,       --매출:간납합계
                                    0               sale_amt_siljuk_in_LOCAL, --매출:도매로컬
                                    0               SALE_AMT_SILJUK_IN_01,    --매출:의원
                                    0               SALE_AMT_SILJUK_IN_02,    --매출:일반간납
                                    0               SALE_AMT_SILJUK_IN_03,    --매출:턴키
                                    0               SALE_AMT_SILJUK_IN_04,    --매출:입찰
                                    0               SALE_AMT_SILJUK_IN_05,    --매출:기타
                                    0               sale_amt_siljuk_out,      --매출:약국
                                    0               sale_amt_banpum,          --매출:반품
                                    0               sale_amt_HALIN,           --매출:매출할인외
                                    0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                    0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                    NVL(in_amt,0)   in_amt,                   --수금목표
                                    0               in_amt_siljuk_in,         --수금:간납합계
                                    0               IN_AMT_SILJUK_IN_LOCAL,   --수금:도매로컬
                                    0               IN_AMT_SILJUK_IN_01,      --수금:의원
                                    0               IN_AMT_SILJUK_IN_02,      --수금:일반간납
                                    0               IN_AMT_SILJUK_IN_03,      --수금:턴키
                                    0               IN_AMT_SILJUK_IN_04,      --수금:입찰
                                    0               IN_AMT_SILJUK_IN_05,      --수금:기타
                                    0               in_amt_siljuk_out,        --수금:약국
                                    0               sale_amt_siljuk_byung,    --매출:종합병원
                                    0               in_amt_siljuk_byung,      --수금:종합병원
                                    0               sale_amt_siljuk_mbyung,   --매출:준종합병원
                                    0               in_amt_siljuk_mbyung      --수금:준종합병원
                               from SALE0403
                              where YMD BETWEEN to_date(substrb(NVL(as_ymd_f,'190001'),1,6)||'01','yyyymmdd')
                                AND last_day(to_date(substrb(NVL(as_ymd_t,'290001'),1,6),'yyyymm'))
                             union all
                             select F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(CUST.cust_gb1,'10',DECODE(SUBSTR(GEORAE.RCUST_ID,1,1),'4',NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(CUST.cust_gb1,'10',DECODE(LEAST('6'||' ',SUBSTR(GEORAE.RCUST_ID,1,1)),'6'||' ', NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(SUBSTR(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),0)),
                                    sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                              '12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)), --매출할인
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0)), --수금할인(일반)
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0)),        --수금할인(조건)
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0
                               from SALE0207 GEORAE, SALE0208 GEORAE_D, SALE0003 CUST
                              where GEORAE.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                                AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                and GEORAE.deal_no  = GEORAE_D.deal_no
                                and GEORAE.rcust_id = CUST.cust_id
                                and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                              group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD)
                             union all
                             SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                     END SAWON_ID,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0               sale_amt_HALIN,           --매출:매출할인외
                                     0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                     0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                     0,
                                     sum(decode(CUST.cust_gb1,'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'05', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(CUST.cust_gb1,'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'05', NVL(SUGUM.cash_amt,0),0)),
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)),
                                     0,
                                     0,
                                     0,
                                     sum(decode(CUST.cust_gb1,'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(CUST.cust_gb1,'20',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(CUST.cust_gb1,'60',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(CUST.cust_gb1,'80',NVL(SUGUM.cash_amt,0),0))
                                from SALE0401 SUGUM, SALE0003 CUST
                               where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                 and SUGUM.rcust_id        = CUST.cust_id
                                 and SUGUM.JUNPYO_GB       LIKE '0%'
                                 and NVL(SUGUM.cash_amt,0) <> 0
                               GROUP BY CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                        END
                            union all
                            SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                         THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                         ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                    END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD IS NULL
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                         THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                         ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                    END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD') AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD'),6))
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                         THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                         ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                    END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd < to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD'),6) AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD'),6))
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                        )
                 group by sawon_id
                 ) X
          WHERE A.SAWON_ID = X.SAWON_ID
            AND A.PART_GB  = B.CODE1(+)
            AND A.DEPT_CD  = C.DEPT_CD(+)
            AND NVL(A.PART_GB,  '0') BETWEEN '01' AND '07' --영업부계내역만
            AND NVL(A.PART_GB,  '0') BETWEEN AS_PART_GB_F  AND AS_PART_GB_T
            AND NVL(A.DEPT_CD,  '0') BETWEEN AS_DEPT_CD_F  AND AS_DEPT_CD_T
            AND NVL(A.SAWON_ID, '0') BETWEEN AS_SAWON_ID_F AND AS_SAWON_ID_T
          GROUP BY NVL(C.RORDER, 9999),
                   DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1),
                   NVL(B.CODE1_NM, A.SAWON_NM),
                   DECODE(C.DEPT_NM, NULL, X.SAWON_ID, C.DEPT_CD),
                   NVL(C.DEPT_NM, A.SAWON_NM)
        )
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               RORDER,
               CODE1,
               CODE1_NM,
               DEPT_CD,
               DEPT_NM,
               sale_amt,
               sale_amt_siljuk_in,
               sale_amt_siljuk_in_LOCAL,
               SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02,
               SALE_AMT_SILJUK_IN_03,
               SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05,
               sale_amt_siljuk_out,
               sale_amt_siljuk_byung,
               sale_amt_siljuk_mbyung,
               sale_amt_banpum,  
               sale_amt_HALIN,   
               SALE_AMT_HALINS01,
               SALE_AMT_HALINS02,
               sale_amt_siljuk,
               sale_percent,
               in_amt,
               in_amt_siljuk_in,
               IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01,
               IN_AMT_SILJUK_IN_02,
               IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04,
               IN_AMT_SILJUK_IN_05,
               in_amt_siljuk_out,
               in_amt_siljuk_byung,
               in_amt_siljuk_mbyung,
               in_amt_siljuk,
               in_percent
          FROM LIST
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               49                RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울로컬1계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 10 AND 48
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               78                RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울로컬2계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 50 AND 77
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               79                RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울로컬 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 10 AND 77
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               119               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울종병 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 80 AND 118
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               138               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울세미 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 120 AND 137
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               139               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<서울   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 10 AND 137
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               159               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<대전로컬 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 140 AND 158
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               179               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<대전   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 140 AND 178
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               180               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<청주   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 180 AND 188
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               219               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<전주   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 190 AND 218
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               239               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<광주로컬 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 220 AND 238
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               259               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<광주   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 220 AND 258
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               289               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<부산로컬 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 260 AND 288
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               309               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<부산   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 260 AND 308
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               329               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<울산   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 310 AND 328
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               349               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<대구로컬 계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 330 AND 348
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               369               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<대구   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 330 AND 368
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               399               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<창원   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 370 AND 398
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               419               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<원주   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 400 AND 418
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               439               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<인천   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 420 AND 438
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               449               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<수원   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 440 AND 448
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               459               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<경인   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 450 AND 458
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               469                RORDER,
               NULL,
               NULL,
               'ZZ'               DEPT_CD,
               '<<도매부  소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 460 AND 468
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               479               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<O1 소계>>'  DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 470 AND 478
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               489               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<제주   소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)     * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)    * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung)  * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 480 AND 488
        UNION ALL
        SELECT '21',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               609               RORDER,
               NULL,
               NULL,
               'ZZ'              DEPT_CD,
               '<<도매로컬 소계>>' DEPT_NM,
               SUM(sale_amt),
               SUM(sale_amt_siljuk_in),
               SUM(sale_amt_siljuk_in_LOCAL),
               SUM(SALE_AMT_SILJUK_IN_01),
               SUM(SALE_AMT_SILJUK_IN_02),
               SUM(SALE_AMT_SILJUK_IN_03),
               SUM(SALE_AMT_SILJUK_IN_04),
               SUM(SALE_AMT_SILJUK_IN_05),
               SUM(sale_amt_siljuk_out),
               SUM(sale_amt_siljuk_byung),
               SUM(sale_amt_siljuk_mbyung),
               SUM(sale_amt_banpum),  
               SUM(sale_amt_HALIN),   
               SUM(SALE_AMT_HALINS01),
               SUM(SALE_AMT_HALINS02),
               SUM(sale_amt_siljuk),
               DECODE(SUM(sale_amt),0, 0,
                      ROUND(((SUM(sale_amt_siljuk_in)     * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(sale_amt_siljuk_out)    * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(sale_amt_siljuk_byung)  * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(sale_amt) * 100,2)) sale_percent,
               SUM(in_amt),
               SUM(in_amt_siljuk_in),
               SUM(IN_AMT_SILJUK_IN_LOCAL),
               SUM(IN_AMT_SILJUK_IN_01),
               SUM(IN_AMT_SILJUK_IN_02),
               SUM(IN_AMT_SILJUK_IN_03),
               SUM(IN_AMT_SILJUK_IN_04),
               SUM(IN_AMT_SILJUK_IN_05),
               SUM(in_amt_siljuk_out),
               SUM(in_amt_siljuk_byung),
               SUM(in_amt_siljuk_mbyung),
               SUM(in_amt_siljuk),
               DECODE(SUM(in_amt),0, 0,
                      ROUND(((SUM(in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
                             (SUM(in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(in_amt) * 100,2)) in_percent
          FROM LIST
         WHERE RORDER BETWEEN 490 AND 608 ;

   ELSIF I_PRT_GB = '22' THEN  --지점원별 + 실거래포함 + 파트별화면에서 더블클릭시 
        INSERT INTO SALE.SALEPART (
               RPT_GB, DATEF, DATET,
               SILJUKYUL_IN, SILJUKYUL_OUT, SILJUKYUL_IN_SU,
               SILJUKYUL_OUT_SU, SILJUKYUL_BYUNG, SILJUKYUL_BYUNG_SU,
               RORDER, COL1, COL2,
               COL3, COL4, SALE_AMT,
               SALE_AMT_SILJUK_IN, SALE_AMT_SILJUK_IN_LOCAL, SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02, SALE_AMT_SILJUK_IN_03, SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05, SALE_AMT_SILJUK_OUT, SALE_AMT_SILJUK_BYUNG,
               SALE_AMT_SILJUK_MBYUNG, SALE_AMT_BANPUM,
               SALE_AMT_HALIN, SALE_AMT_HALINS01, SALE_AMT_HALINS02,
               SALE_AMT_SILJUK, SALE_PERCENT,
               IN_AMT, IN_AMT_SILJUK_IN, IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01, IN_AMT_SILJUK_IN_02, IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04, IN_AMT_SILJUK_IN_05, IN_AMT_SILJUK_OUT,
               IN_AMT_SILJUK_BYUNG, IN_AMT_SILJUK_MBYUNG, IN_AMT_SILJUK,
               IN_PERCENT
               )
        WITH LIST AS (
        SELECT NVL(C.RORDER, 9999)                                     RORDER,
               DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1)           CODE1,
               NVL(B.CODE1_NM, A.SAWON_NM)                             CODE1_NM,
               DECODE(C.DEPT_NM, NULL, X.SAWON_ID, C.DEPT_CD)          DEPT_CD,
               NVL(C.DEPT_NM, A.SAWON_NM)                              DEPT_NM,
               SUM(X.sale_amt)                                                                         sale_amt,
               SUM(X.sale_amt_siljuk_in) * nvl(al_siljukyul_in,100) * 0.01                             sale_amt_siljuk_in,
               SUM(X.sale_amt_siljuk_in_LOCAL) * nvl(al_siljukyul_in,100) * 0.01                       sale_amt_siljuk_in_LOCAL,
               SUM(X.SALE_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_01,
               SUM(X.SALE_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_02,
               SUM(X.SALE_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_03,
               SUM(X.SALE_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_04,
               SUM(X.SALE_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_05,
               SUM(X.sale_amt_siljuk_out) * nvl(al_siljukyul_out,100) * 0.01                           sale_amt_siljuk_out,
               SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_byung,
               SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01                      sale_amt_siljuk_mbyung,
               SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_banpum,
               SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_HALIN,
               SUM(X.SALE_AMT_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS01,
               SUM(X.SALE_AMT_HALINS02)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS02,
               (SUM(X.sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
               (SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
               (SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALINs01)     * nvl(al_siljukyul_byung,100) * 0.01)                      sale_amt_siljuk,  --영업관리부의 요청으로 sale_amt_HALINS02 빠짐
               DECODE(SUM(NVL(X.sale_amt,0)),0, 0,
                      ROUND(((SUM(X.sale_amt_siljuk_in)     * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(X.sale_amt_siljuk_out)    * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(X.sale_amt_siljuk_byung)  * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALINs01)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(X.sale_amt) * 100,2)) sale_percent,
               SUM(X.in_amt)                                                                            in_amt,
               SUM(X.in_amt_siljuk_in) * nvl(al_siljukyul_in_su,100) * 0.01                            in_amt_siljuk_in,
               SUM(X.IN_AMT_SILJUK_IN_LOCAL) * nvl(al_siljukyul_in_su,100) * 0.01                      IN_AMT_SILJUK_IN_LOCAL,
               SUM(X.IN_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_01,
               SUM(X.IN_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_02,
               SUM(X.IN_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_03,
               SUM(X.IN_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_04,
               SUM(X.IN_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_05,
               SUM(X.in_amt_siljuk_out) * nvl(al_siljukyul_out_su,100) * 0.01                          in_amt_siljuk_out,
               SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01                      in_amt_siljuk_byung,
               SUM(X.in_amt_siljuk_mbyung) * nvl(al_siljukyul_byung_su,100) * 0.01                     in_amt_siljuk_mbyung,
               (SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
               (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
               (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
               (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)                    in_amt_siljuk,
               DECODE(SUM(NVL(X.in_amt,0)),0, 0,
                      ROUND(((SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
                             (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(X.in_amt) * 100,2)) in_percent
            FROM SALE0007 A,
                 (select code1, code1_nm, code2, code2_nm from SALE0001 where code_gb = '0013') B,
                 SALE0008 C,
                 (
                 select sawon_id                          sawon_id,
                            SUM(sale_amt)                 sale_amt,
                            SUM(sale_amt_siljuk_in)       sale_amt_siljuk_in,
                            SUM(sale_amt_siljuk_in_LOCAL) sale_amt_siljuk_in_LOCAL,
                            SUM(SALE_AMT_SILJUK_IN_01)    SALE_AMT_SILJUK_IN_01,
                            SUM(SALE_AMT_SILJUK_IN_02)    SALE_AMT_SILJUK_IN_02,
                            SUM(SALE_AMT_SILJUK_IN_03)    SALE_AMT_SILJUK_IN_03,
                            SUM(SALE_AMT_SILJUK_IN_04)    SALE_AMT_SILJUK_IN_04,
                            SUM(SALE_AMT_SILJUK_IN_05)    SALE_AMT_SILJUK_IN_05,
                            SUM(sale_amt_siljuk_out)      sale_amt_siljuk_out,
                            SUM(sale_amt_banpum)          sale_amt_banpum,
                            SUM(sale_amt_HALIN)           sale_amt_HALIN,
                            SUM(SALE_AMT_HALINS01)        SALE_AMT_HALINS01,
                            SUM(SALE_AMT_HALINS02)        SALE_AMT_HALINS02,
                            SUM(in_amt)                   in_amt,
                            SUM(in_amt_siljuk_in)         in_amt_siljuk_in,
                            SUM(IN_AMT_SILJUK_IN_LOCAL)   IN_AMT_SILJUK_IN_LOCAL,
                            SUM(IN_AMT_SILJUK_IN_01)      IN_AMT_SILJUK_IN_01,
                            SUM(IN_AMT_SILJUK_IN_02)      IN_AMT_SILJUK_IN_02,
                            SUM(IN_AMT_SILJUK_IN_03)      IN_AMT_SILJUK_IN_03,
                            SUM(IN_AMT_SILJUK_IN_04)      IN_AMT_SILJUK_IN_04,
                            SUM(IN_AMT_SILJUK_IN_05)      IN_AMT_SILJUK_IN_05,
                            SUM(in_amt_siljuk_out)        in_amt_siljuk_out,
                            SUM(sale_amt_siljuk_byung)    sale_amt_siljuk_byung,
                            SUM(in_amt_siljuk_byung)      in_amt_siljuk_byung,
                            SUM(sale_amt_siljuk_mbyung)   sale_amt_siljuk_mbyung,
                            SUM(in_amt_siljuk_mbyung)     in_amt_siljuk_mbyung
                      from
                            (select sawon_id,
                                    NVL(sale_amt,0) sale_amt,                 --판매목표
                                    0               sale_amt_siljuk_in,       --매출:간납합계
                                    0               sale_amt_siljuk_in_LOCAL, --매출:도매로컬
                                    0               SALE_AMT_SILJUK_IN_01,    --매출:의원
                                    0               SALE_AMT_SILJUK_IN_02,    --매출:일반간납
                                    0               SALE_AMT_SILJUK_IN_03,    --매출:턴키
                                    0               SALE_AMT_SILJUK_IN_04,    --매출:입찰
                                    0               SALE_AMT_SILJUK_IN_05,    --매출:기타
                                    0               sale_amt_siljuk_out,      --매출:약국
                                    0               sale_amt_banpum,          --매출:반품
                                    0               sale_amt_HALIN,           --매출:매출할인외
                                    0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                    0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                    NVL(in_amt,0)   in_amt,                   --수금목표
                                    0               in_amt_siljuk_in,         --수금:간납합계
                                    0               IN_AMT_SILJUK_IN_LOCAL,   --수금:도매로컬
                                    0               IN_AMT_SILJUK_IN_01,      --수금:의원
                                    0               IN_AMT_SILJUK_IN_02,      --수금:일반간납
                                    0               IN_AMT_SILJUK_IN_03,      --수금:턴키
                                    0               IN_AMT_SILJUK_IN_04,      --수금:입찰
                                    0               IN_AMT_SILJUK_IN_05,      --수금:기타
                                    0               in_amt_siljuk_out,        --수금:약국
                                    0               sale_amt_siljuk_byung,    --매출:종합병원
                                    0               in_amt_siljuk_byung,      --수금:종합병원
                                    0               sale_amt_siljuk_mbyung,   --매출:준종합병원
                                    0               in_amt_siljuk_mbyung      --수금:준종합병원
                               from SALE0403
                              where YMD BETWEEN to_date(substrb(NVL(as_ymd_f,'190001'),1,6)||'01','yyyymmdd')
                                AND last_day(to_date(substrb(NVL(as_ymd_t,'290001'),1,6),'yyyymm'))
                             union all
                             select F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',DECODE(SUBSTR(GEORAE.RCUST_ID,1,1),'4',NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',DECODE(LEAST('6'||' ',SUBSTR(GEORAE.RCUST_ID,1,1)),'6'||' ', NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(substr(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),0)),
                                    sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                              '12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)), --매출할인
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0)), --수금할인(일반)
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0)),        --수금할인(조건)
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0
                               from SALE0207 GEORAE, SALE0208 GEORAE_D
                              where GEORAE.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                                AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                and GEORAE.deal_no  = GEORAE_D.deal_no
                                and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                              group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD)
                             union all
                             SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                     END SAWON_ID,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0               sale_amt_HALIN,           --매출:매출할인외
                                     0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                     0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUM.cash_amt,0),0)),
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)),
                                     0,
                                     0,
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUM.cash_amt,0),0))
                                from SALE0401 SUGUM
                               where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                 and SUGUM.JUNPYO_GB       LIKE '0%'
                                 and NVL(SUGUM.cash_amt,0) <> 0
                               GROUP BY CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                        END
                            union all
                            select CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD IS NULL
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            select CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD') AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6))
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END
                            union all
                            select CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd < to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6) AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6))
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                        )
                 group by sawon_id
                 ) X
          WHERE A.SAWON_ID = X.SAWON_ID
            AND A.PART_GB  = B.CODE1(+)
            AND A.DEPT_CD  = C.DEPT_CD(+)
            AND NVL(A.PART_GB,  '0') BETWEEN '01' AND '07' --영업부계내역만
            AND NVL(A.PART_GB,  '0') BETWEEN AS_PART_GB_F  AND AS_PART_GB_T
            AND NVL(A.DEPT_CD,  '0') BETWEEN AS_DEPT_CD_F  AND AS_DEPT_CD_T
            AND NVL(A.SAWON_ID, '0') BETWEEN AS_SAWON_ID_F AND AS_SAWON_ID_T
          GROUP BY NVL(C.RORDER, 9999),
                   DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1),
                   NVL(B.CODE1_NM, A.SAWON_NM),
                   DECODE(C.DEPT_NM, NULL, X.SAWON_ID, C.DEPT_CD),
                   NVL(C.DEPT_NM, A.SAWON_NM)
        )
        SELECT '22',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               RORDER,
               CODE1,
               CODE1_NM,
               DEPT_CD,
               DEPT_NM,
               sale_amt,
               sale_amt_siljuk_in,
               sale_amt_siljuk_in_LOCAL,
               SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02,
               SALE_AMT_SILJUK_IN_03,
               SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05,
               sale_amt_siljuk_out,
               sale_amt_siljuk_byung,
               sale_amt_siljuk_mbyung,
               sale_amt_banpum,  
               sale_amt_HALIN,   
               SALE_AMT_HALINS01,
               SALE_AMT_HALINS02,
               sale_amt_siljuk,
               sale_percent,
               in_amt,
               in_amt_siljuk_in,
               IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01,
               IN_AMT_SILJUK_IN_02,
               IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04,
               IN_AMT_SILJUK_IN_05,
               in_amt_siljuk_out,
               in_amt_siljuk_byung,
               in_amt_siljuk_mbyung,
               in_amt_siljuk,
               in_percent
          FROM LIST ;

   ELSIF I_PRT_GB = '23' THEN  --지점원별 + 실거래제외 + 파트별화면에서 더블클릭시
        INSERT INTO SALE.SALEPART (
               RPT_GB, DATEF, DATET,
               SILJUKYUL_IN, SILJUKYUL_OUT, SILJUKYUL_IN_SU,
               SILJUKYUL_OUT_SU, SILJUKYUL_BYUNG, SILJUKYUL_BYUNG_SU,
               RORDER, COL1, COL2,
               COL3, COL4, SALE_AMT,
               SALE_AMT_SILJUK_IN, SALE_AMT_SILJUK_IN_LOCAL, SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02, SALE_AMT_SILJUK_IN_03, SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05, SALE_AMT_SILJUK_OUT, SALE_AMT_SILJUK_BYUNG,
               SALE_AMT_SILJUK_MBYUNG, SALE_AMT_BANPUM,
               SALE_AMT_HALIN, SALE_AMT_HALINS01, SALE_AMT_HALINS02,
               SALE_AMT_SILJUK, SALE_PERCENT,
               IN_AMT, IN_AMT_SILJUK_IN, IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01, IN_AMT_SILJUK_IN_02, IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04, IN_AMT_SILJUK_IN_05, IN_AMT_SILJUK_OUT,
               IN_AMT_SILJUK_BYUNG, IN_AMT_SILJUK_MBYUNG, IN_AMT_SILJUK,
               IN_PERCENT
               )
        WITH LIST AS (
        SELECT NVL(C.RORDER, 9999)                                     RORDER,
               DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1)           CODE1,
               NVL(B.CODE1_NM, A.SAWON_NM)                             CODE1_NM,
               DECODE(C.DEPT_NM, NULL, X.SAWON_ID, C.DEPT_CD)          DEPT_CD,
               NVL(C.DEPT_NM, A.SAWON_NM)                              DEPT_NM,
               SUM(X.sale_amt)                                                                         sale_amt,
               SUM(X.sale_amt_siljuk_in) * nvl(al_siljukyul_in,100) * 0.01                             sale_amt_siljuk_in,
               SUM(X.sale_amt_siljuk_in_LOCAL) * nvl(al_siljukyul_in,100) * 0.01                       sale_amt_siljuk_in_LOCAL,
               SUM(X.SALE_AMT_SILJUK_IN_01)  * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_01,
               SUM(X.SALE_AMT_SILJUK_IN_02)  * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_02,
               SUM(X.SALE_AMT_SILJUK_IN_03)  * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_03,
               SUM(X.SALE_AMT_SILJUK_IN_04)  * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_04,
               SUM(X.SALE_AMT_SILJUK_IN_05)  * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_05,
               SUM(X.sale_amt_siljuk_out)    * nvl(al_siljukyul_out,100) * 0.01                           sale_amt_siljuk_out,
               SUM(X.sale_amt_siljuk_byung)  * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_byung,
               SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01                      sale_amt_siljuk_mbyung,
               SUM(X.sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_banpum,
               SUM(X.sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_HALIN,
               SUM(X.SALE_AMT_HALINS01)      * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS01,
               SUM(X.SALE_AMT_HALINS02)      * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS02,
               (SUM(X.sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
               (SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
               (SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALINs01)     * nvl(al_siljukyul_byung,100) * 0.01)                     sale_amt_siljuk, --영업관리부의 요청으로 sale_amt_HALINS02 빠짐
               DECODE(SUM(NVL(X.sale_amt,0)),0, 0,
                      ROUND(((SUM(X.sale_amt_siljuk_in)     * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(X.sale_amt_siljuk_out)    * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(X.sale_amt_siljuk_byung)  * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALINs01)      * nvl(al_siljukyul_byung,100) * 0.01) ) / SUM(X.sale_amt) * 100,2)) sale_percent,
               SUM(X.in_amt)                                                                            in_amt,
               SUM(X.in_amt_siljuk_in) * nvl(al_siljukyul_in_su,100) * 0.01                            in_amt_siljuk_in,
               SUM(X.IN_AMT_SILJUK_IN_LOCAL) * nvl(al_siljukyul_in_su,100) * 0.01                      IN_AMT_SILJUK_IN_LOCAL,
               SUM(X.IN_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_01,
               SUM(X.IN_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_02,
               SUM(X.IN_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_03,
               SUM(X.IN_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_04,
               SUM(X.IN_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_05,
               SUM(X.in_amt_siljuk_out) * nvl(al_siljukyul_out_su,100) * 0.01                          in_amt_siljuk_out,
               SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01                      in_amt_siljuk_byung,
               SUM(X.in_amt_siljuk_mbyung) * nvl(al_siljukyul_byung_su,100) * 0.01                     in_amt_siljuk_mbyung,
               (SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
               (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
               (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
               (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)                    in_amt_siljuk,
               DECODE(SUM(NVL(X.in_amt,0)),0, 0,
                      ROUND(((SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
                             (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(X.in_amt) * 100,2)) in_percent
            FROM SALE0007 A,
             (select code1, code1_nm, code2, code2_nm from SALE0001 where code_gb = '0013') B,
                 SALE0008 C,
                 (
                 select sawon_id                          sawon_id,
                            SUM(sale_amt)                 sale_amt,
                            SUM(sale_amt_siljuk_in)       sale_amt_siljuk_in,
                            SUM(sale_amt_siljuk_in_LOCAL) sale_amt_siljuk_in_LOCAL,
                            SUM(SALE_AMT_SILJUK_IN_01)    SALE_AMT_SILJUK_IN_01,
                            SUM(SALE_AMT_SILJUK_IN_02)    SALE_AMT_SILJUK_IN_02,
                            SUM(SALE_AMT_SILJUK_IN_03)    SALE_AMT_SILJUK_IN_03,
                            SUM(SALE_AMT_SILJUK_IN_04)    SALE_AMT_SILJUK_IN_04,
                            SUM(SALE_AMT_SILJUK_IN_05)    SALE_AMT_SILJUK_IN_05,
                            SUM(sale_amt_siljuk_out)      sale_amt_siljuk_out,
                            SUM(sale_amt_banpum)          sale_amt_banpum,
                            SUM(sale_amt_HALIN)           sale_amt_HALIN,
                            SUM(SALE_AMT_HALINS01)        SALE_AMT_HALINS01,
                            SUM(SALE_AMT_HALINS02)        SALE_AMT_HALINS02,
                            SUM(in_amt)                   in_amt,
                            SUM(in_amt_siljuk_in)         in_amt_siljuk_in,
                            SUM(IN_AMT_SILJUK_IN_LOCAL)   IN_AMT_SILJUK_IN_LOCAL,
                            SUM(IN_AMT_SILJUK_IN_01)      IN_AMT_SILJUK_IN_01,
                            SUM(IN_AMT_SILJUK_IN_02)      IN_AMT_SILJUK_IN_02,
                            SUM(IN_AMT_SILJUK_IN_03)      IN_AMT_SILJUK_IN_03,
                            SUM(IN_AMT_SILJUK_IN_04)      IN_AMT_SILJUK_IN_04,
                            SUM(IN_AMT_SILJUK_IN_05)      IN_AMT_SILJUK_IN_05,
                            SUM(in_amt_siljuk_out)        in_amt_siljuk_out,
                            SUM(sale_amt_siljuk_byung)    sale_amt_siljuk_byung,
                            SUM(in_amt_siljuk_byung)      in_amt_siljuk_byung,
                            SUM(sale_amt_siljuk_mbyung)   sale_amt_siljuk_mbyung,
                            SUM(in_amt_siljuk_mbyung)     in_amt_siljuk_mbyung
                      from
                            (select sawon_id,
                                    NVL(sale_amt,0) sale_amt,                 --판매목표
                                    0               sale_amt_siljuk_in,       --매출:간납합계
                                    0               sale_amt_siljuk_in_LOCAL, --매출:도매로컬
                                    0               SALE_AMT_SILJUK_IN_01,    --매출:의원
                                    0               SALE_AMT_SILJUK_IN_02,    --매출:일반간납
                                    0               SALE_AMT_SILJUK_IN_03,    --매출:턴키
                                    0               SALE_AMT_SILJUK_IN_04,    --매출:입찰
                                    0               SALE_AMT_SILJUK_IN_05,    --매출:기타
                                    0               sale_amt_siljuk_out,      --매출:약국
                                    0               sale_amt_banpum,          --매출:반품
                                    0               sale_amt_HALIN,           --매출:매출할인외
                                    0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                    0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                    NVL(in_amt,0)   in_amt,                   --수금목표
                                    0               in_amt_siljuk_in,         --수금:간납합계
                                    0               IN_AMT_SILJUK_IN_LOCAL,   --수금:도매로컬
                                    0               IN_AMT_SILJUK_IN_01,      --수금:의원
                                    0               IN_AMT_SILJUK_IN_02,      --수금:일반간납
                                    0               IN_AMT_SILJUK_IN_03,      --수금:턴키
                                    0               IN_AMT_SILJUK_IN_04,      --수금:입찰
                                    0               IN_AMT_SILJUK_IN_05,      --수금:기타
                                    0               in_amt_siljuk_out,        --수금:약국
                                    0               sale_amt_siljuk_byung,    --매출:종합병원
                                    0               in_amt_siljuk_byung,      --수금:종합병원
                                    0               sale_amt_siljuk_mbyung,   --매출:준종합병원
                                    0               in_amt_siljuk_mbyung      --수금:준종합병원
                               from SALE0403
                              where YMD BETWEEN to_date(substrb(NVL(as_ymd_f,'190001'),1,6)||'01','yyyymmdd')
                                AND last_day(to_date(substrb(NVL(as_ymd_t,'290001'),1,6),'yyyymm'))
                             union all
                             select F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(CUST.cust_gb1,'10',DECODE(SUBSTR(GEORAE.RCUST_ID,1,1),'4',NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(CUST.cust_gb1,'10',DECODE(LEAST('6'||' ',SUBSTR(GEORAE.RCUST_ID,1,1)),'6'||' ', NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(SUBSTR(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),0)),
                                    sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                              '12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)), --매출할인
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0)), --수금할인(일반)
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0)),        --수금할인(조건)
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0
                               from SALE0207 GEORAE, SALE0208 GEORAE_D, SALE0003 CUST
                              where GEORAE.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                                AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                and GEORAE.deal_no  = GEORAE_D.deal_no
                                and GEORAE.rcust_id = CUST.cust_id
                                and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                              group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD)
                             union all
                             SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                     END SAWON_ID,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0               sale_amt_HALIN,           --매출:매출할인외
                                     0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                     0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                     0,
                                     sum(decode(CUST.cust_gb1,'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'05', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(CUST.cust_gb1,'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'05', NVL(SUGUM.cash_amt,0),0)),
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)),
                                     0,
                                     0,
                                     0,
                                     sum(decode(CUST.cust_gb1,'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(CUST.cust_gb1,'20',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(CUST.cust_gb1,'60',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(CUST.cust_gb1,'80',NVL(SUGUM.cash_amt,0),0))
                                from SALE0401 SUGUM, SALE0003 CUST
                               where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                 and SUGUM.rcust_id        = CUST.cust_id
                                 and SUGUM.JUNPYO_GB       LIKE '0%'
                                 and NVL(SUGUM.cash_amt,0) <> 0
                               GROUP BY CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                        END
                            union all
                            SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                         THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                         ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                    END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD IS NULL
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                         THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                         ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                    END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD') AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD'),6))
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                         THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                         ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                    END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd < to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD'),6) AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01', 'YYYYMMDD'),6))
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                        )
                 group by sawon_id
                 ) X
          WHERE A.SAWON_ID = X.SAWON_ID
            AND A.PART_GB  = B.CODE1(+)
            AND A.DEPT_CD  = C.DEPT_CD(+)
            AND NVL(A.PART_GB,  '0') BETWEEN '01' AND '07' --영업부계내역만
            AND NVL(A.PART_GB,  '0') BETWEEN AS_PART_GB_F  AND AS_PART_GB_T
            AND NVL(A.DEPT_CD,  '0') BETWEEN AS_DEPT_CD_F  AND AS_DEPT_CD_T
            AND NVL(A.SAWON_ID, '0') BETWEEN AS_SAWON_ID_F AND AS_SAWON_ID_T
          GROUP BY NVL(C.RORDER, 9999),
                   DECODE(B.CODE1_NM, NULL, X.SAWON_ID, B.CODE1),
                   NVL(B.CODE1_NM, A.SAWON_NM),
                   DECODE(C.DEPT_NM, NULL, X.SAWON_ID, C.DEPT_CD),
                   NVL(C.DEPT_NM, A.SAWON_NM)
        )
        SELECT '23',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               RORDER,
               CODE1,
               CODE1_NM,
               DEPT_CD,
               DEPT_NM,
               sale_amt,
               sale_amt_siljuk_in,
               sale_amt_siljuk_in_LOCAL,
               SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02,
               SALE_AMT_SILJUK_IN_03,
               SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05,
               sale_amt_siljuk_out,
               sale_amt_siljuk_byung,
               sale_amt_siljuk_mbyung,
               sale_amt_banpum,  
               sale_amt_HALIN,   
               SALE_AMT_HALINS01,
               SALE_AMT_HALINS02,
               sale_amt_siljuk,
               sale_percent,
               in_amt,
               in_amt_siljuk_in,
               IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01,
               IN_AMT_SILJUK_IN_02,
               IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04,
               IN_AMT_SILJUK_IN_05,
               in_amt_siljuk_out,
               in_amt_siljuk_byung,
               in_amt_siljuk_mbyung,
               in_amt_siljuk,
               in_percent
          FROM LIST ;

   ELSIF I_PRT_GB = '30' THEN  --사원별 + 실거래포함
        INSERT INTO SALE.SALEPART (
               RPT_GB, DATEF, DATET,
               SILJUKYUL_IN, SILJUKYUL_OUT, SILJUKYUL_IN_SU,
               SILJUKYUL_OUT_SU, SILJUKYUL_BYUNG, SILJUKYUL_BYUNG_SU,
               RORDER, COL1, COL2,
               COL3, COL4, SALE_AMT,
               SALE_AMT_SILJUK_IN, SALE_AMT_SILJUK_IN_LOCAL, SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02, SALE_AMT_SILJUK_IN_03, SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05, SALE_AMT_SILJUK_OUT, SALE_AMT_SILJUK_BYUNG,
               SALE_AMT_SILJUK_MBYUNG,
               SALE_AMT_BANPUM, SALE_AMT_HALIN, SALE_AMT_HALINS01, SALE_AMT_HALINS02,
               SALE_AMT_SILJUK, SALE_PERCENT,
               IN_AMT, IN_AMT_SILJUK_IN, IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01, IN_AMT_SILJUK_IN_02, IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04, IN_AMT_SILJUK_IN_05, IN_AMT_SILJUK_OUT,
               IN_AMT_SILJUK_BYUNG, IN_AMT_SILJUK_MBYUNG, IN_AMT_SILJUK,
               IN_PERCENT
               )
        SELECT '30',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               NVL(C.RORDER, 9999)                                     RORDER,
               DECODE(C.DEPT_NM, NULL, ' ', C.DEPT_CD)                 DEPT_CD,
               NVL(C.DEPT_NM, ' ')                                     DEPT_NM,
               A.SAWON_ID                                              SAWON_ID,
               A.SAWON_NM                                              SAWON_NM,
               SUM(X.sale_amt)                                                                         sale_amt,                            --판매목표
               SUM(X.sale_amt_siljuk_in) * nvl(al_siljukyul_in,100) * 0.01                             sale_amt_siljuk_in,                  --판매간납계
               SUM(X.sale_amt_siljuk_in_LOCAL) * nvl(al_siljukyul_in,100) * 0.01                       sale_amt_siljuk_in_LOCAL,            --도매로컬
               SUM(X.SALE_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_01,               --의원
               SUM(X.SALE_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_02,               --일반간납
               SUM(X.SALE_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_03,               --T
               SUM(X.SALE_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_04,               --입찰
               SUM(X.SALE_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_05,               --기타
               SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100) * 0.01                         sale_amt_siljuk_out,                 --약국
               SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_byung,               --종병
               SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_mbyung,              --준종병
               SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_banpum,                     --반품
               SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_HALIN,                      --매출할인
               SUM(X.SALE_AMT_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS01,                   --수금할인(일반)
               SUM(X.SALE_AMT_HALINS02)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS02,                   --수금할인(조건)
               (SUM(X.sale_amt_siljuk_in)    * nvl(al_siljukyul_in,   100) * 0.01) +
               (SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,  100) * 0.01) +
               (SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01)                     sale_amt_siljuk,                     --판매계
               DECODE(SUM(NVL(X.sale_amt,0)),0, 0,
                      ROUND(((SUM(X.sale_amt_siljuk_in)     * nvl(al_siljukyul_in,   100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_out)    * nvl(al_siljukyul_out,  100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_byung)  * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALINS01)      * nvl(al_siljukyul_byung,100) * 0.01)) / SUM(X.sale_amt) * 100,2)) sale_percent,
               SUM(X.in_amt)                                                                           in_amt,
               SUM(X.in_amt_siljuk_in) * nvl(al_siljukyul_in_su,100) * 0.01                            in_amt_siljuk_in,
               SUM(X.IN_AMT_SILJUK_IN_LOCAL) * nvl(al_siljukyul_in_su,100) * 0.01                      IN_AMT_SILJUK_IN_LOCAL,
               SUM(X.IN_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_01,
               SUM(X.IN_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_02,
               SUM(X.IN_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_03,
               SUM(X.IN_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_04,
               SUM(X.IN_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_05,
               SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100) * 0.01                        in_amt_siljuk_out,
               SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01                      in_amt_siljuk_byung,
               SUM(X.in_amt_siljuk_mbyung) * nvl(al_siljukyul_byung_su,100) * 0.01                     in_amt_siljuk_mbyung,
               (SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
               (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
               (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
               (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)                    in_amt_siljuk,
               DECODE(SUM(NVL(X.in_amt,0)),0, 0,
                      ROUND(((SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
                             (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(X.in_amt) * 100,2)) in_percent
            FROM SALE0007 A,
                 SALE0008 C,
                 (
                 select sawon_id                          sawon_id,
                            SUM(sale_amt)                 sale_amt,
                            SUM(sale_amt_siljuk_in)       sale_amt_siljuk_in,
                            SUM(sale_amt_siljuk_in_LOCAL) sale_amt_siljuk_in_LOCAL,
                            SUM(SALE_AMT_SILJUK_IN_01)    SALE_AMT_SILJUK_IN_01,
                            SUM(SALE_AMT_SILJUK_IN_02)    SALE_AMT_SILJUK_IN_02,
                            SUM(SALE_AMT_SILJUK_IN_03)    SALE_AMT_SILJUK_IN_03,
                            SUM(SALE_AMT_SILJUK_IN_04)    SALE_AMT_SILJUK_IN_04,
                            SUM(SALE_AMT_SILJUK_IN_05)    SALE_AMT_SILJUK_IN_05,
                            SUM(sale_amt_siljuk_out)      sale_amt_siljuk_out,
                            SUM(sale_amt_banpum)          sale_amt_banpum,
                            SUM(sale_amt_HALIN)           sale_amt_HALIN,
                            SUM(SALE_AMT_HALINS01)        SALE_AMT_HALINS01,
                            SUM(SALE_AMT_HALINS02)        SALE_AMT_HALINS02,
                            SUM(in_amt)                   in_amt,
                            SUM(in_amt_siljuk_in)         in_amt_siljuk_in,
                            SUM(IN_AMT_SILJUK_IN_LOCAL)   IN_AMT_SILJUK_IN_LOCAL,
                            SUM(IN_AMT_SILJUK_IN_01)      IN_AMT_SILJUK_IN_01,
                            SUM(IN_AMT_SILJUK_IN_02)      IN_AMT_SILJUK_IN_02,
                            SUM(IN_AMT_SILJUK_IN_03)      IN_AMT_SILJUK_IN_03,
                            SUM(IN_AMT_SILJUK_IN_04)      IN_AMT_SILJUK_IN_04,
                            SUM(IN_AMT_SILJUK_IN_05)      IN_AMT_SILJUK_IN_05,
                            SUM(in_amt_siljuk_out)        in_amt_siljuk_out,
                            SUM(sale_amt_siljuk_byung)    sale_amt_siljuk_byung,
                            SUM(in_amt_siljuk_byung)      in_amt_siljuk_byung,
                            SUM(sale_amt_siljuk_mbyung)   sale_amt_siljuk_mbyung,
                            SUM(in_amt_siljuk_mbyung)     in_amt_siljuk_mbyung
                      from
                            (select sawon_id,
                                    NVL(sale_amt,0) sale_amt,                 --판매목표
                                    0               sale_amt_siljuk_in,       --매출:간납합계
                                    0               sale_amt_siljuk_in_LOCAL, --매출:도매로컬
                                    0               SALE_AMT_SILJUK_IN_01,    --매출:의원
                                    0               SALE_AMT_SILJUK_IN_02,    --매출:일반간납
                                    0               SALE_AMT_SILJUK_IN_03,    --매출:턴키
                                    0               SALE_AMT_SILJUK_IN_04,    --매출:입찰
                                    0               SALE_AMT_SILJUK_IN_05,    --매출:기타
                                    0               sale_amt_siljuk_out,      --매출:약국
                                    0               sale_amt_banpum,          --매출:반품
                                    0               sale_amt_HALIN,           --매출:매출할인외
                                    0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                    0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                    NVL(in_amt,0)   in_amt,                   --수금목표
                                    0               in_amt_siljuk_in,         --수금:간납합계
                                    0               IN_AMT_SILJUK_IN_LOCAL,   --수금:도매로컬
                                    0               IN_AMT_SILJUK_IN_01,      --수금:의원
                                    0               IN_AMT_SILJUK_IN_02,      --수금:일반간납
                                    0               IN_AMT_SILJUK_IN_03,      --수금:턴키
                                    0               IN_AMT_SILJUK_IN_04,      --수금:입찰
                                    0               IN_AMT_SILJUK_IN_05,      --수금:기타
                                    0               in_amt_siljuk_out,        --수금:약국
                                    0               sale_amt_siljuk_byung,    --매출:종합병원
                                    0               in_amt_siljuk_byung,      --수금:종합병원
                                    0               sale_amt_siljuk_mbyung,   --매출:준종합병원
                                    0               in_amt_siljuk_mbyung      --수금:준종합병원
                               from SALE0403
                              where YMD BETWEEN to_date(substrb(NVL(as_ymd_f,'190001'),1,6)||'01','yyyymmdd')
                                AND last_day(to_date(substrb(NVL(as_ymd_t,'290001'),1,6),'yyyymm'))
                             union all
                             select F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',DECODE(SUBSTR(GEORAE.RCUST_ID,1,1),'4',NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',DECODE(LEAST('6'||' ',SUBSTR(GEORAE.RCUST_ID,1,1)),'6'||' ', NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    sum(decode(substr(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),0)),
                                    sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                              '12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)), --매출할인
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0)), --수금할인(일반)
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                                      '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0)),        --수금할인(조건)
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0
                               from SALE0207 GEORAE, SALE0208 GEORAE_D
                              where GEORAE.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                                AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                and GEORAE.deal_no  = GEORAE_D.deal_no
                                and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                              group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD)
                             union all
                             SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                     END SAWON_ID,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0               sale_amt_HALIN,           --매출:매출할인외
                                     0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                     0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUM.cash_amt,0),0)),
                                     SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)),
                                     0,
                                     0,
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUM.cash_amt,0),0))
                                from SALE0401 SUGUM
                               where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                 and SUGUM.JUNPYO_GB       LIKE '0%'
                                 and NVL(SUGUM.cash_amt,0) <> 0
                               GROUP BY CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                        END
                            union all
                            SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                        THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                        ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD IS NULL
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                        THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                        ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD') AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6))
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END
                            union all
                            SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                        THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                        ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0402 SUGUMD
                             where SUGUM.ymd < to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6) AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6))
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                        )
                 group by sawon_id
                 ) X
          WHERE A.SAWON_ID = X.SAWON_ID
            AND A.DEPT_CD  = C.DEPT_CD(+)
            AND NVL(A.PART_GB,  '0') BETWEEN '01' AND '07' --영업부계내역만
            AND NVL(A.PART_GB,  '0') BETWEEN AS_PART_GB_F  AND AS_PART_GB_T
            AND NVL(A.DEPT_CD,  '0') BETWEEN AS_DEPT_CD_F  AND AS_DEPT_CD_T
            AND NVL(A.SAWON_ID, '0') BETWEEN AS_SAWON_ID_F AND AS_SAWON_ID_T
          GROUP BY NVL(C.RORDER, 9999),
                   DECODE(C.DEPT_NM, NULL, ' ', C.DEPT_CD),
                   NVL(C.DEPT_NM, ' '),
                   A.SAWON_ID,
                   A.SAWON_NM ;

   ELSIF I_PRT_GB = '31' THEN  --사원별 + 실거래제외
        INSERT INTO SALE.SALEPART (
               RPT_GB, DATEF, DATET,
               SILJUKYUL_IN, SILJUKYUL_OUT, SILJUKYUL_IN_SU,
               SILJUKYUL_OUT_SU, SILJUKYUL_BYUNG, SILJUKYUL_BYUNG_SU,
               RORDER, COL1, COL2,
               COL3, COL4, SALE_AMT,
               SALE_AMT_SILJUK_IN, SALE_AMT_SILJUK_IN_LOCAL, SALE_AMT_SILJUK_IN_01,
               SALE_AMT_SILJUK_IN_02, SALE_AMT_SILJUK_IN_03, SALE_AMT_SILJUK_IN_04,
               SALE_AMT_SILJUK_IN_05, SALE_AMT_SILJUK_OUT, SALE_AMT_SILJUK_BYUNG,
               SALE_AMT_SILJUK_MBYUNG,
               SALE_AMT_BANPUM, SALE_AMT_HALIN, SALE_AMT_HALINS01, SALE_AMT_HALINS02,
               SALE_AMT_SILJUK, SALE_PERCENT,
               IN_AMT, IN_AMT_SILJUK_IN, IN_AMT_SILJUK_IN_LOCAL,
               IN_AMT_SILJUK_IN_01, IN_AMT_SILJUK_IN_02, IN_AMT_SILJUK_IN_03,
               IN_AMT_SILJUK_IN_04, IN_AMT_SILJUK_IN_05, IN_AMT_SILJUK_OUT,
               IN_AMT_SILJUK_BYUNG, IN_AMT_SILJUK_MBYUNG, IN_AMT_SILJUK,
               IN_PERCENT
               )
        SELECT '31',
               AS_YMD_F,
               AS_YMD_T,
               AL_SILJUKYUL_IN,
               AL_SILJUKYUL_OUT,
               AL_SILJUKYUL_IN_SU,
               AL_SILJUKYUL_OUT_SU,
               AL_SILJUKYUL_BYUNG,
               AL_SILJUKYUL_BYUNG_SU,
               NVL(C.RORDER, 9999)                                     RORDER,
               DECODE(C.DEPT_NM, NULL, ' ', C.DEPT_CD)                 DEPT_CD,
               NVL(C.DEPT_NM, ' ')                                     DEPT_NM,
               A.SAWON_ID                                              SAWON_ID,
               A.SAWON_NM                                              SAWON_NM,
               SUM(X.sale_amt)                                                                         sale_amt,                            --판매목표
               SUM(X.sale_amt_siljuk_in) * nvl(al_siljukyul_in,100) * 0.01                             sale_amt_siljuk_in,                  --판매간납계
               SUM(X.sale_amt_siljuk_in_LOCAL) * nvl(al_siljukyul_in,100) * 0.01                       sale_amt_siljuk_in_LOCAL,            --도매로컬
               SUM(X.SALE_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_01,               --의원
               SUM(X.SALE_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_02,               --일반간납
               SUM(X.SALE_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_03,               --T
               SUM(X.SALE_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_04,               --입찰
               SUM(X.SALE_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN,100) * 0.01                          SALE_AMT_SILJUK_IN_05,               --기타
               SUM(X.sale_amt_siljuk_out) * nvl(al_siljukyul_out,100) * 0.01                           sale_amt_siljuk_out,                 --약국
               SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_siljuk_byung,               --종병
               SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01                      sale_amt_siljuk_mbyung,              --준종병
               SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_banpum,                     --반품
               SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01                       sale_amt_HALIN,                      --매출할인
               SUM(X.SALE_AMT_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS01,                   --수금할인(일반)
               SUM(X.SALE_AMT_HALINS02)     * nvl(al_siljukyul_byung,100) * 0.01                       SALE_AMT_HALINS02,                   --수금할인(조건)
               (SUM(X.sale_amt_siljuk_in)    * nvl(al_siljukyul_in,100)    * 0.01) +
               (SUM(X.sale_amt_siljuk_out)   * nvl(al_siljukyul_out,100)   * 0.01) +
               (SUM(X.sale_amt_siljuk_byung) * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_siljuk_mbyung)* nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_banpum)       * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALIN)        * nvl(al_siljukyul_byung,100) * 0.01) +
               (SUM(X.sale_amt_HALINS01)     * nvl(al_siljukyul_byung,100) * 0.01)                     sale_amt_siljuk,                     --판매계
               DECODE(SUM(NVL(X.sale_amt,0)),0, 0,
                      ROUND(((SUM(X.sale_amt_siljuk_in)     * nvl(al_siljukyul_in,100)    * 0.01) +
                             (SUM(X.sale_amt_siljuk_out)    * nvl(al_siljukyul_out,100)   * 0.01) +
                             (SUM(X.sale_amt_siljuk_byung)  * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_siljuk_mbyung) * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_banpum)        * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALIN)         * nvl(al_siljukyul_byung,100) * 0.01) +
                             (SUM(X.sale_amt_HALINS01)      * nvl(al_siljukyul_byung,100) * 0.01)) / SUM(X.sale_amt) * 100,2)) sale_percent,
               SUM(X.in_amt)                                                                           in_amt,
               SUM(X.in_amt_siljuk_in) * nvl(al_siljukyul_in_su,100) * 0.01                            in_amt_siljuk_in,
               SUM(X.IN_AMT_SILJUK_IN_LOCAL) * nvl(al_siljukyul_in_su,100) * 0.01                      IN_AMT_SILJUK_IN_LOCAL,
               SUM(X.IN_AMT_SILJUK_IN_01) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_01,
               SUM(X.IN_AMT_SILJUK_IN_02) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_02,
               SUM(X.IN_AMT_SILJUK_IN_03) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_03,
               SUM(X.IN_AMT_SILJUK_IN_04) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_04,
               SUM(X.IN_AMT_SILJUK_IN_05) * NVL(AL_SILJUKYUL_IN_SU,100) * 0.01                         IN_AMT_SILJUK_IN_05,
               SUM(X.in_amt_siljuk_out) * nvl(al_siljukyul_out_su,100) * 0.01                          in_amt_siljuk_out,
               SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01                      in_amt_siljuk_byung,
               SUM(X.in_amt_siljuk_mbyung) * nvl(al_siljukyul_byung_su,100) * 0.01                     in_amt_siljuk_mbyung,
               (SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
               (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
               (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
               (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)                    in_amt_siljuk,
               DECODE(SUM(NVL(X.in_amt,0)),0, 0,
                      ROUND(((SUM(X.in_amt_siljuk_in)    * nvl(al_siljukyul_in_su,100)    * 0.01) +
                             (SUM(X.in_amt_siljuk_out)   * nvl(al_siljukyul_out_su,100)   * 0.01) +
                             (SUM(X.in_amt_siljuk_byung) * nvl(al_siljukyul_byung_su,100) * 0.01) +
                             (SUM(X.in_amt_siljuk_mbyung)* nvl(al_siljukyul_byung_su,100) * 0.01)) / SUM(X.in_amt) * 100,2)) in_percent
            FROM SALE0007 A,
                 SALE0008 C,
                 (
                 select sawon_id                          sawon_id,
                            SUM(sale_amt)                 sale_amt,
                            SUM(sale_amt_siljuk_in)       sale_amt_siljuk_in,
                            SUM(sale_amt_siljuk_in_LOCAL) sale_amt_siljuk_in_LOCAL,
                            SUM(SALE_AMT_SILJUK_IN_01)    SALE_AMT_SILJUK_IN_01,
                            SUM(SALE_AMT_SILJUK_IN_02)    SALE_AMT_SILJUK_IN_02,
                            SUM(SALE_AMT_SILJUK_IN_03)    SALE_AMT_SILJUK_IN_03,
                            SUM(SALE_AMT_SILJUK_IN_04)    SALE_AMT_SILJUK_IN_04,
                            SUM(SALE_AMT_SILJUK_IN_05)    SALE_AMT_SILJUK_IN_05,
                            SUM(sale_amt_siljuk_out)      sale_amt_siljuk_out,
                            SUM(sale_amt_banpum)          sale_amt_banpum,
                            SUM(sale_amt_HALIN)           sale_amt_HALIN,
                            SUM(SALE_AMT_HALINS01)        SALE_AMT_HALINS01,
                            SUM(SALE_AMT_HALINS02)        SALE_AMT_HALINS02,
                            SUM(in_amt)                   in_amt,
                            SUM(in_amt_siljuk_in)         in_amt_siljuk_in,
                            SUM(IN_AMT_SILJUK_IN_LOCAL)   IN_AMT_SILJUK_IN_LOCAL,
                            SUM(IN_AMT_SILJUK_IN_01)      IN_AMT_SILJUK_IN_01,
                            SUM(IN_AMT_SILJUK_IN_02)      IN_AMT_SILJUK_IN_02,
                            SUM(IN_AMT_SILJUK_IN_03)      IN_AMT_SILJUK_IN_03,
                            SUM(IN_AMT_SILJUK_IN_04)      IN_AMT_SILJUK_IN_04,
                            SUM(IN_AMT_SILJUK_IN_05)      IN_AMT_SILJUK_IN_05,
                            SUM(in_amt_siljuk_out)        in_amt_siljuk_out,
                            SUM(sale_amt_siljuk_byung)    sale_amt_siljuk_byung,
                            SUM(in_amt_siljuk_byung)      in_amt_siljuk_byung,
                            SUM(sale_amt_siljuk_mbyung)   sale_amt_siljuk_mbyung,
                            SUM(in_amt_siljuk_mbyung)     in_amt_siljuk_mbyung
                      from
                            (select sawon_id,
                                    NVL(sale_amt,0) sale_amt,                 --판매목표
                                    0               sale_amt_siljuk_in,       --매출:간납합계
                                    0               sale_amt_siljuk_in_LOCAL, --매출:도매로컬
                                    0               SALE_AMT_SILJUK_IN_01,    --매출:의원
                                    0               SALE_AMT_SILJUK_IN_02,    --매출:일반간납
                                    0               SALE_AMT_SILJUK_IN_03,    --매출:턴키
                                    0               SALE_AMT_SILJUK_IN_04,    --매출:입찰
                                    0               SALE_AMT_SILJUK_IN_05,    --매출:기타
                                    0               sale_amt_siljuk_out,      --매출:약국
                                    0               sale_amt_banpum,          --매출:반품
                                    0               sale_amt_HALIN,           --매출:매출할인외
                                    0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                    0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                    NVL(in_amt,0)   in_amt,                   --수금목표
                                    0               in_amt_siljuk_in,         --수금:간납합계
                                    0               IN_AMT_SILJUK_IN_LOCAL,   --수금:도매로컬
                                    0               IN_AMT_SILJUK_IN_01,      --수금:의원
                                    0               IN_AMT_SILJUK_IN_02,      --수금:일반간납
                                    0               IN_AMT_SILJUK_IN_03,      --수금:턴키
                                    0               IN_AMT_SILJUK_IN_04,      --수금:입찰
                                    0               IN_AMT_SILJUK_IN_05,      --수금:기타
                                    0               in_amt_siljuk_out,        --수금:약국
                                    0               sale_amt_siljuk_byung,    --매출:종합병원
                                    0               in_amt_siljuk_byung,      --수금:종합병원
                                    0               sale_amt_siljuk_mbyung,   --매출:준종합병원
                                    0               in_amt_siljuk_mbyung      --수금:준종합병원
                               from SALE0403
                              where YMD BETWEEN to_date(substrb(NVL(as_ymd_f,'190001'),1,6)||'01','yyyymmdd')
                                AND last_day(to_date(substrb(NVL(as_ymd_t,'290001'),1,6),'yyyymm'))
                             union all
                             select F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                    0,         --판매목표
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))), --매출:간납합계
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))), --매출:도매로컬
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(CUST.CUST_GB1,'10',DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) , --매출:의원
                                    SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(CUST.CUST_GB1,'10',DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ',NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) ,--매출:일반간납
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))), --매출:턴키
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))), --매출:입찰
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))), --매출:기타
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))), --매출:약국
                                    sum(decode(SUBSTR(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),0)), --매출:반품
                                    sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                              '12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)), --매출할인
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0)), --수금할인(일반)
                                    sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),'4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),
                                                              '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),'4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0)),        --수금할인(조건)
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0,
                                    sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(CUST.cust_gb1,'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                    0
                               from SALE0207 GEORAE, SALE0208 GEORAE_D, SALE0003 CUST
                              where GEORAE.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                                AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                and GEORAE.deal_no  = GEORAE_D.deal_no
                                and GEORAE.rcust_id = CUST.cust_id
                                and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                              group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD)
                             union all
                             SELECT  CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                     END SAWON_ID,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0,
                                     0               sale_amt_HALIN,           --매출:매출할인외
                                     0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                     0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                     0,
                                     sum(decode(CUST.cust_gb1,'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'05', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(CUST.cust_gb1,'40', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'70', NVL(SUGUM.cash_amt,0),0)) +
                                     sum(decode(CUST.cust_gb1,'90', NVL(SUGUM.cash_amt,0),0)) +
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                     sum(decode(CUST.cust_gb1,'05', NVL(SUGUM.cash_amt,0),0)),
                                     SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)),
                                     0,
                                     0,
                                     0,
                                     sum(decode(CUST.cust_gb1,'99',NVL(SUGUM.cash_amt,0),0)),
                                     sum(decode(CUST.cust_gb1,'20',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(CUST.cust_gb1,'60',NVL(SUGUM.cash_amt,0),0)),
                                     0,
                                     sum(decode(CUST.cust_gb1,'80',NVL(SUGUM.cash_amt,0),0))
                                from SALE0401 SUGUM, SALE0003 CUST
                               where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                                 and SUGUM.rcust_id        = CUST.cust_id
                                 and SUGUM.JUNPYO_GB       LIKE '0%'
                                 and NVL(SUGUM.cash_amt,0) <> 0
                               GROUP BY CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                        END
                            union all
                            SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                        THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                        ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD IS NULL
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                            union all
                            SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                        THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                        ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd BETWEEN to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd') AND to_date(NVl(as_ymd_t,'29000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD') AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6))
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END
                            union all
                            SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                        THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                        ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                   END SAWON_ID,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0,
                                   0               sale_amt_HALIN,           --매출:매출할인외
                                   0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                   0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                   0,
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'40', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'70', NVL(SUGUMD.AMT,0),0)) +
                                   sum(decode(CUST.cust_gb1,'90', NVL(SUGUMD.AMT,0),0)) +
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(LEAST('6'||' ',SUBSTR(CUST.CUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                   sum(decode(CUST.cust_gb1,'05', NVL(SUGUMD.AMT,0),0)),
                                   SUM(DECODE(CUST.CUST_GB1,'10', DECODE(SUBSTR(CUST.CUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                   0,
                                   0,
                                   0,
                                   sum(decode(CUST.cust_gb1,'99',NVL(SUGUMD.AMT,0),0)),
                                   sum(decode(CUST.cust_gb1,'20',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'60',NVL(SUGUMD.AMT,0),0)),
                                   0,
                                   sum(decode(CUST.cust_gb1,'80',NVL(SUGUMD.AMT,0),0))
                              from SALE0401 SUGUM, SALE0003 CUST, SALE0402 SUGUMD
                             where SUGUM.ymd < to_date(NVl(as_ymd_f,'19000101'),'yyyymmdd')
                               and SUGUM.rcust_id  = CUST.cust_id
                               and SUGUM.JUNPYO_GB LIKE '0%'
                               AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                               AND SUGUMD.END_YMD  IS NOT NULL
                               AND SUGUMD.END_YMD  BETWEEN ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6) AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(as_ymd_f,1,6)||'01','YYYYMMDD'),6))
                               and NVL(SUGUMD.AMT,0) <> 0
                             group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010'
                                          THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)
                                          ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD)
                                      END
                        )
                 group by sawon_id
                 ) X
          WHERE A.SAWON_ID = X.SAWON_ID
            AND A.DEPT_CD  = C.DEPT_CD(+)
            AND NVL(A.PART_GB,  '0') BETWEEN '01' AND '07' --영업부계내역만
            AND NVL(A.PART_GB,  '0') BETWEEN AS_PART_GB_F  AND AS_PART_GB_T
            AND NVL(A.DEPT_CD,  '0') BETWEEN AS_DEPT_CD_F  AND AS_DEPT_CD_T
            AND NVL(A.SAWON_ID, '0') BETWEEN AS_SAWON_ID_F AND AS_SAWON_ID_T
          GROUP BY NVL(C.RORDER, 9999),
                   DECODE(C.DEPT_NM, NULL, ' ', C.DEPT_CD),
                   NVL(C.DEPT_NM, ' '),
                   A.SAWON_ID,
                   A.SAWON_NM ;

   END IF;

END  P_SALEPART_20130322 ;

/
