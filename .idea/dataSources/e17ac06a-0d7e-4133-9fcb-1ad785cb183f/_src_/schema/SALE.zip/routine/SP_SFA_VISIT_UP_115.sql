CREATE PROCEDURE      SP_SFA_VISIT_UP_115
(
    in_PROCESS_TYPE      IN  VARCHAR2,     -- Action Type 
    in_SALES_PLAN_NO     IN  VARCHAR2,     -- 방문일자 Key
    in_EMP_NO            IN  VARCHAR2,     -- 담당자 사번
    in_DETAIL_PLAN_NO    IN  VARCHAR2,     -- 방문순번 
    in_PARAM_1           IN  VARCHAR2,     
    in_PARAM_2           IN  VARCHAR2,     
    in_PARAM_3           IN  VARCHAR2,     
    in_PARAM_4           IN  VARCHAR2,     
    in_PARAM_5           IN  VARCHAR2,     
    in_PARAM_6           IN  VARCHAR2,      -- 한글   
    in_PARAM_7           IN  VARCHAR2,      -- 한글
    in_PARAM_8           IN  VARCHAR2,      -- 한글
    in_PARAM_9           IN  VARCHAR2,      -- 한글
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 일일방문수행  
 호출프로그램 : VisitActivity  bizVisit_UP     
 수정내용   : 2014.01.03 바로앞콜이 시작이면  5분체크 하지 않음
          2015.01.14 kta 현위치주소 못찾는체크 하지 않음
          2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    
    v_num           NUMBER;
    v_CALL_TERM     NUMBER;
    v_SFA_SALES_SEQ VARCHAR2(10);

BEGIN      
        -- 팀장이 방문승인/반려를 한다.
        IF in_PROCESS_TYPE = '1' THEN 
            SELECT COUNT(*)
              INTO v_num
              FROM SFA_VISIT_PLANACT A
             WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
               AND A.EMP_NO           = in_EMP_NO  
               AND A.DETAIL_PLAN_NO   = in_DETAIL_PLAN_NO
            ;
                       
            IF v_num = 0 THEN
                out_COUNT := v_num;  
                out_CODE := 1;
                out_MSG  := '등록된 자료가 자료가 없습니다.';           
            ELSE
                out_CODE := 0;
                out_MSG  := '정보수정 완료';
                UPDATE SFA_VISIT_PLANACT A
                   SET A.APPLY_YN    = in_PARAM_1  -- 승인,반려값이 들어간다.
                      ,A.REJECT_DESC = in_PARAM_6
                      ,A.CALL_ADDR    = in_PARAM_7        --CHOE 20121214 CALL 찍힌 주소를 저장한다.          
                WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
                  AND A.EMP_NO         = in_EMP_NO
                  AND A.DETAIL_PLAN_NO = in_DETAIL_PLAN_NO
                ;                   
            END IF; 
        END IF;
         
        
        -- 일일방문에서 콜한경우 Update 한다.
        IF in_PROCESS_TYPE = '2' THEN  
           
            --CHOE 2017.01.23 과거 방문 계획을 수행하는 경우에 이곳에서 저지 한다.
            --당일 방문을 진행하는 것이 원칙임
            IF in_SALES_PLAN_NO <> TO_CHAR(SYSDATE, 'YYYYMMDD') THEN
                out_COUNT := 0;  
                out_CODE := 1;
                out_MSG  := '하나제약 서버일자와 SFA단말기의 일자가 다릅니다. SFA단말기의 일자를 확인하십시오.';
            ELSE         
                v_num := 0;
                SELECT COUNT(*)
                  INTO v_num
                  FROM SFA_VISIT_PLANACT A
                 WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
                   AND A.EMP_NO         = in_EMP_NO          
                   AND A.CALL_YN        = 'Y'
                 ;        
                        
                IF v_num > 0 THEN  --당일 본인의 콜이 있어야하므로 
                    
                   --업무종료콜이 있으면 방문콜 불가 처리  
                    v_num := 0;
                    SELECT COUNT(*)
                      INTO v_num
                      FROM SFA_VISIT_PLANACT A
                     WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
                       AND A.EMP_NO      = in_EMP_NO
                       AND CALL_YN       = 'Y'  
                       AND SFA_SALES_SEQ = 3 --퇴근지                       
                    ;
                    IF v_num = 1 THEN  --업무종료콜 있으면
                        out_CODE := 1;
                        out_MSG := '업무종료콜이 있으면 방문콜을 수행 할수 없습니다.';           
                        RETURN;
                    END IF;          
                        
                    --앞콜이 시작이면 5분체크 하지 않음  
                    --바로앞콜이 시작 인지 체크
                    SELECT  /*+ INDEX_DESC(A IDX_SFA_VISIT_PLANACT_01) */
                           hiracode
                      INTO v_SFA_SALES_SEQ
                      FROM SFA_VISIT_PLANACT A
                     WHERE A.SALES_PLAN_NO = in_SALES_PLAN_NO
                       AND A.EMP_NO        = in_EMP_NO
                       AND A.CALL_YN       = 'Y'
                       AND A.EMP_CALL_DTM > ' '   --인덱스를 사용하려면 반드시 있어야 함.
                       AND ROWNUM = 1      --콜시간을 인덱스역순으로 잡았으므로 1개만 가져오면 최종콜한 시간임.      
                    ;
                                
                    IF v_SFA_SALES_SEQ <> '1' THEN
                                                    
                        --앞콜이 시작이 아니면
                        --바로 앞의 콜시간과 5분이 지나지 않으면 콜불가 하도록 처리  
                        v_CALL_TERM := 0;                  
                        SELECT  /*+ INDEX_DESC(A IDX_SFA_VISIT_PLANACT_01) */
                               (SYSDATE - TO_DATE(EMP_CALL_DTM,'YYYYMMDDHH24MISS')) * 24 * 60 * 60
                          INTO v_CALL_TERM
                          FROM SFA_VISIT_PLANACT A
                         WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
                           AND A.EMP_NO         = in_EMP_NO
                           AND A.CALL_YN        = 'Y'
                           AND A.EMP_CALL_DTM   > ' '   --인덱스를 사용하려면 반드시 있어야 함.
                           AND A.HIRACODE <> '1'                
                           AND ROWNUM = 1      --콜시간을 인덱스역순으로 잡았으므로 1개만 가져오면 최종콜한 시간임.                   
                        ;
                        IF v_CALL_TERM < 300 THEN  --초로 넘어옴
                            out_CODE := 1;
                            out_MSG  := '바로 이전 콜과 5분이 지나야 콜이 가능합니다.';           
                            RETURN;
                        END IF;                                               
                    END IF;
                END IF;
                    
                --insert into SFA_SP_CALLED_HIST values ('SP_SFA_VISIT_UP_115',in_EMP_NO,sysdate,'in_DETAIL_PLAN_NO: '||in_DETAIL_PLAN_NO );      
                v_num := 0;
                SELECT COUNT(*)
                  INTO v_num
                  FROM SFA_VISIT_PLANACT A
                 WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
                   AND A.EMP_NO         = in_EMP_NO
                   AND A.DETAIL_PLAN_NO = in_DETAIL_PLAN_NO
                ;
                               
                IF v_num = 0 THEN
                        out_COUNT := v_num;  
                        out_CODE := 1;
                        out_MSG  := '등록된 자료가 자료가 없습니다.';
                ELSE                
                        out_CODE := 0;
                        out_MSG  := '정보수정 완료';
                        UPDATE SFA_VISIT_PLANACT A
                        SET A.EMP_CALL_DTM   = TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS')  
                        ,A.GPS_NUM1       = in_PARAM_2
                        ,A.GPS_NUM2       = in_PARAM_3
                        ,A.CALL_YN        = 'Y'
                        ,A.CALL_ADDR      = in_PARAM_7        --CHOE 20121214 CALL 찍힌 주소를 저장한다. 
                        WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
                        AND A.EMP_NO           = in_EMP_NO
                        AND A.DETAIL_PLAN_NO   = in_DETAIL_PLAN_NO
                        ;                   
                END IF; 
            END IF;
        END IF;



        -- 방문활동내역 Update 한다.
        IF in_PROCESS_TYPE = '3' THEN 
                SELECT COUNT(*)
                INTO v_num
                FROM SFA_VISIT_PLANACT A
                WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
                AND A.EMP_NO         = in_EMP_NO
                AND A.DETAIL_PLAN_NO = in_DETAIL_PLAN_NO
                ;
                       
                IF v_num = 0 THEN
                        out_COUNT := v_num;  
                        out_CODE := 1;
                        out_MSG  := '등록된 자료가 자료가 없습니다.';
                ELSE 
                        out_CODE := 0;
                        out_MSG  := '정보수정 완료';
                        UPDATE SFA_VISIT_PLANACT A
                        SET A.ACTIVITY_CODE    = in_PARAM_1,  
                            A.MAIN_ITEM1       = in_PARAM_2,
                            A.MAIN_ITEM2       = in_PARAM_3,
                            A.ACTIVITY_DESC    = in_PARAM_6,
                            A.VISIT            = 'Y',
                            A.ACTIVITY_YN      = 'Y',
                            A.CALL_ADDR        = in_PARAM_7        --CHOE 20121214 CALL 찍힌 주소를 저장한다. 
                        WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
                        AND A.EMP_NO         = in_EMP_NO
                        AND A.DETAIL_PLAN_NO = in_DETAIL_PLAN_NO
                        ;                   
                END IF; 
        END IF;
             
            
        -- 방문활동내역 삭제한다.
        IF in_PROCESS_TYPE = '9' THEN 
                SELECT COUNT(*)
                INTO v_num
                FROM SFA_VISIT_PLANACT A
                WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
                AND A.EMP_NO           = in_EMP_NO
                AND A.DETAIL_PLAN_NO = in_DETAIL_PLAN_NO
                ;
                               
                IF v_num = 0 THEN
                        out_COUNT := v_num;  
                        out_CODE := 1;
                        out_MSG  := '등록된 자료가 자료가 없습니다.';
                ELSE
                        out_CODE := 0;
                        out_MSG  := '삭제처리 되었습니다.';
                        DELETE FROM SFA_VISIT_PLANACT A
                        WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
                        AND A.EMP_NO           = in_EMP_NO
                        AND A.DETAIL_PLAN_NO = in_DETAIL_PLAN_NO;
                END IF; 
        END IF;
         
        
EXCEPTION
WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
