CREATE PROCEDURE      SP_X_COLLECTION_GRIDLIST
(
    in_FRDATE     IN VARCHAR2,
    in_TODATE     IN VARCHAR2,
    in_ASSGNCODE  IN VARCHAR2,
    in_FRCUST     IN VARCHAR2,
    in_DEPT_CD    IN VARCHAR2,
    in_EMP_CD     IN VARCHAR2,
    in_SIDX       IN VARCHAR2,
    in_SORD       IN VARCHAR2,
    out_RESULT   OUT TYPES.CURSOR_TYPE,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_COLLECTION_GRIDLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 수금현황 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	 OPEN out_RESULT FOR
         SELECT a.ym, a.ymd, a.item_id, a.cust_id, a.cust_nm, a.vou_no, a.rcust_id,
                   a.rcust_nm, a.sawon_id, a.sawon_nm, a.dept_cd, a.dept_nm, a.sawon_idh,
                   b.sawon_nm sawon_nmh, b.dept_cd dept_cdh, c.dept_nm dept_cmh, a.sukum,
                   a.tot, a.bill_no, a.end_ymd, a.cust_gb1, a.rcust_gb1, a.rcust_gb1h,
                   a.balhang
              FROM (SELECT TO_CHAR (a.ymd, 'YYYYMM') ym, TO_CHAR (a.ymd, 'YYYY-MM-DD') ymd,
                           DECODE (a.junpyo_gb,
                                   '01', '현금',
                                   '10', '매출할인',
                                   '20', '부실채권',
                                   '30', '거래이관',
                                   '35', '대손상각',
                                   '기타수금'
                                  ) item_id,
                           a.cust_id cust_id, d.cust_nm cust_nm, d.vou_no vou_no,
                           a.rcust_id rcust_id, e.cust_nm rcust_nm, a.sawon_id sawon_id,
                           c.sawon_nm sawon_nm, c.dept_cd dept_cd, f.dept_nm dept_nm,
                           sale.f_get_sale0401_sawonidh (a.rcust_id, a.ymd) sawon_idh,
                           cash_amt sukum, NVL (- (cash_amt), 0) tot, '' bill_no,
                           '' end_ymd, d.cust_gb1 cust_gb1, e.cust_gb1 rcust_gb1,
                           sale.f_get_sale0003h_custgb1 (a.rcust_id, a.ymd) rcust_gb1h,
                           '' balhang
                      FROM (select z.*
                                  ,sale.F_GET_SALE0401_SAWONIDH(z.CUST_ID,  z.YMD) as siljuk_sawon_id
                              from sale.SALE0401 z
                           ) a,
                           sale.sale0007 c,
                           sale.sale0003 d,
                           sale.sale0003 e,
                           sale.sale0008 f
                     WHERE a.siljuk_sawon_id = c.sawon_id(+)
                       AND c.dept_cd = f.dept_cd(+)
                       AND a.cust_id = d.cust_id
                       AND a.rcust_id = e.cust_id
                       AND a.junpyo_gb <> '30'
                       AND a.ymd BETWEEN in_FRDATE AND in_TODATE
            AND a.cust_id = in_FRCUST
               AND a.siljuk_sawon_id IN ( select sawon_id
                                              from sale0007
                                             where dept_cd IN  ( select sale_dept_cd
                                                                   from hr_co_depart_0
                                                                connect by prior dept_cd = up_dept_cd
                                                                  start with dept_cd = (    select dept_cd
                                                                                              from hr_co_depart_0
                                                                                             where level = 2
                                                                                           connect by  dept_cd = prior up_dept_cd
                                                                                             start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no in (select insa_sawon_id from sale0007 where sawon_id = in_EMP_CD) )
                                                                                        )
                                                                )
                                               and gubun = 'Y'
                                               and in_ASSGNCODE in ('27000','27010','27020','27025')
                                             union all
                                             select sawon_id
                                               from sale0007
                                              where dept_cd = in_DEPT_CD
                                                and in_ASSGNCODE in ('27027','27030','27035')
                                             union all
                                             select sawon_id
                                               from sale0007
                                              where sawon_id = in_EMP_CD
                                                and in_ASSGNCODE in ('27040','27050')
                                         )
               AND cash_amt <> 0
            UNION ALL
            SELECT TO_CHAR (a.ymd, 'YYYYMM') ym, TO_CHAR (a.ymd, 'YYYY-MM-DD') ymd,
                   DECODE (a.junpyo_gb,
                           '01', DECODE (b.bill_gb, '100', '신용카드', '어음'),
                           '10', '매출할인',
                           '20', '부실채권',
                           '30', '거래이관',
                           '35', '대손상각',
                           '기타수금'
                          ) item_id,
                   a.cust_id cust_id, d.cust_nm cust_nm, d.vou_no vou_no,
                   a.rcust_id rcust_id, e.cust_nm rcust_nm, a.sawon_id sawon_id,
                   c.sawon_nm sawon_nm, c.dept_cd dept_cd, f.dept_nm dept_nm,
                   sale.f_get_sale0401_sawonidh (a.rcust_id, a.ymd) sawon_idh,
                   amt sukum, NVL (- (amt), 0) tot, b.bill_no bill_no,
                   TO_CHAR (b.end_ymd, 'YYYY-MM-DD') end_ymd, d.cust_gb1 cust_gb1,
                   e.cust_gb1 rcust_gb1,
                   sale.f_get_sale0003h_custgb1 (a.rcust_id, a.ymd) rcust_gb1h,
                   b.balhang balhang
              FROM (select z.*
                          ,sale.F_GET_SALE0401_SAWONIDH(z.CUST_ID,  z.YMD) as siljuk_sawon_id
                      from sale.SALE0401 z
                   ) a,
                   sale.sale0402 b,
                   sale.sale0007 c,
                   sale.sale0003 d,
                   sale.sale0003 e,
                   sale.sale0008 f
             WHERE a.siljuk_sawon_id = c.sawon_id
               AND c.dept_cd = f.dept_cd(+)
               AND a.cust_id = d.cust_id
               AND a.rcust_id = e.cust_id
               AND a.junpyo_gb <> '30'
               AND a.ymd BETWEEN in_FRDATE AND in_TODATE
               AND a.junpyo_no = b.junpyo_no
            AND a.cust_id = in_FRCUST
               AND a.siljuk_sawon_id IN ( select sawon_id
                                              from sale0007
                                             where dept_cd IN  ( select sale_dept_cd
                                                                   from hr_co_depart_0
                                                                connect by prior dept_cd = up_dept_cd
                                                                  start with dept_cd = (    select dept_cd
                                                                                              from hr_co_depart_0
                                                                                             where level = 2
                                                                                           connect by  dept_cd = prior up_dept_cd
                                                                                             start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no in (select insa_sawon_id from sale0007 where sawon_id = in_EMP_CD) )
                                                                                        )
                                                                )
                                               and gubun = 'Y'
                                               and in_ASSGNCODE in ('27000','27010','27020','27025')
                                             union all
                                             select sawon_id
                                               from sale0007
                                              where dept_cd = in_DEPT_CD
                                                and in_ASSGNCODE in ('27027','27030','27035')
                                             union all
                                             select sawon_id
                                               from sale0007
                                              where sawon_id = in_EMP_CD
                                                and in_ASSGNCODE in ('27040','27050')
                                         )
						                   ) a,
						       sale.sale0007 b,
						       sale.sale0008 c
						 WHERE a.sawon_idh = b.sawon_id(+) AND b.dept_cd = c.dept_cd(+)
            ORDER BY in_SIDX||' '||in_SORD;
            
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
