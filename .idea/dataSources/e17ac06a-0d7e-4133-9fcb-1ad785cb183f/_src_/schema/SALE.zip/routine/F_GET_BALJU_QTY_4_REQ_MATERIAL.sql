CREATE function F_GET_BALJU_QTY_4_REQ_MATERIAL
        ( a_req_no      VARCHAR2, -- 청구번호
          a_material_id VARCHAR2  -- 원부자재 코드
        )
   RETURN number
AS
   user_err     exception   ;
   v_curr_jakup varchar2(100) ;
   v_curr_error varchar2(100) ;
   v_message    varchar2(250) ;

   n_rtn_value   varchar2(50) ;
   
   v_req_no      varchar2(10) ;
   v_material_id varchar2(10) ;
   v_count       Number ;
   v_dummy       varchar2(20) ;
BEGIN
  
    Begin
        v_curr_jakup  := '조건 확인: ' ;
        n_rtn_value   := ' ' ;
        v_req_no      := LTRIM(RTRIM(a_req_no)) ;
        v_material_id := LTRIM(RTRIM(a_material_id)) ;

        If NVL(v_req_no, ' ') = ' ' or NVL(v_material_id, ' ') = ' ' Then
           goto the_end;
        End if ;
        
        v_curr_jakup  := '발주수량/최초발주일 구하기: ' ;
        SELECT NVL(SUM(A.qty),0)
          INTO n_rtn_value
          FROM BUY0402 A, -- 구매발주 Detail
               BUY0401 B  -- 구매발주 Master
         WHERE A.req_no      = v_req_no
           AND A.material_id = v_material_id
           AND A.balju_no    = B.balju_no  ;
           
        <<the_end>>
        RETURN n_rtn_value;

    EXCEPTION WHEN user_err THEN
                   RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_jakup||v_curr_error,1,250));
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_jakup||v_curr_error||SQLERRM,1,250));
    END ;
    
END;



/
