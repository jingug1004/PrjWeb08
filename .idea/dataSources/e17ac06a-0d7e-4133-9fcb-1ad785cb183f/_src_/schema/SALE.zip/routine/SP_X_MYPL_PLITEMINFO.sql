CREATE PROCEDURE      SP_X_MYPL_PLITEMINFO
(
    in_ITEM_ID    IN VARCHAR2,
    out_RESULT   OUT TYPES.CURSOR_TYPE,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_MYPL_PLITEMINFO
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  제품 상세 정보 조회 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
	    SELECT ITEM_CODE AS ITEM_ID, ITEM_NAME ITEM_NM, ITEM_EFFECT, ITEM_USE_DOES, ITEM_PHOTO,
		       ITEM_KIND1, ITEM_PHOTO, ITEM_KD_NO, ITEM_MAIN_SOURCE, ITEM_POJANG_UNIT,
		       ITEM_OUT_DANGA, ITEM_KIND2, FONTSIZE_EFFECT, FONTSIZE_USE_DOES, USE_YN
		  FROM SALE.SFA_OFFICE_ITEMDOC
		 WHERE ITEM_CODE = in_ITEM_ID;

    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
