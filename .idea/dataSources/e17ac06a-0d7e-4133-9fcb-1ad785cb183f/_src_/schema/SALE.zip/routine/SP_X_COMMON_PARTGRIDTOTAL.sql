CREATE PROCEDURE      SP_X_COMMON_PARTGRIDTOTAL
(
    in_KEYWORD      IN VARCHAR2,
    out_TOTAL_CNT  OUT VARCHAR2,
    out_CODE       OUT NUMBER,
    out_MSG        OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_COMMON_PARTGRIDTOTAL
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 파트 총수 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	SELECT count(*) INTO out_TOTAL_CNT
		  FROM SALE.SALE0001 A
		 WHERE A.CODE_GB = '0013'
	   	   AND A.CODE1||A.CODE1_NM LIKE '%'||in_KEYWORD||'%';
	   	   
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
