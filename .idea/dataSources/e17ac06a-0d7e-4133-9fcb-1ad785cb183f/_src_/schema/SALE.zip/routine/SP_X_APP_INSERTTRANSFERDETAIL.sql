CREATE PROCEDURE      SP_X_APP_INSERTTRANSFERDETAIL
(
    in_APP_DATE  IN VARCHAR2,
    in_APP_NO    IN VARCHAR2,
    in_REQ_DATE  IN VARCHAR2,
    in_GUMAE_NO  IN VARCHAR2,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_INSERTTRANSFERDETAIL
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  ERP 주문 디테일 이관 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	INSERT INTO SALE.SALE0204(YMD, GUMAE_NO, INPUT_SEQ, ITEM_ID, QTY, DANGA, AMT, VAT, RATE, DC_AMT, BIGO, DEAL_NO, 
								  DEAL_SEQ, SALE_NO, SALE_SEQ, BALJU_YN, CHULGO_YN, OLD_DANGA, DC_QTY, DC_DANGA)
			SELECT in_APP_DATE, in_APP_NO, INPUT_SEQ, ITEM_ID, QTY, DANGA, AMT, VAT, RATE, DC_AMT, BIGO, DEAL_NO, 
					DEAL_SEQ, SALE_NO, SALE_SEQ, BALJU_YN, CHULGO_YN, OLD_DANGA, DC_QTY, DC_DANGA 
			  FROM SALE_ON.SALE0204 
			 WHERE YMD = in_REQ_DATE AND GUMAE_NO = in_GUMAE_NO AND QTY > 0;

    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 INSERT ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 저장';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;
END ;
/
