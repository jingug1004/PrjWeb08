CREATE PROCEDURE      SP_SFA_CUST_04_LIST_110
(
    in_SAWON_ID          IN  VARCHAR2,     -- 사용자 ID
    in_SFA_SALES_SEQ     IN  VARCHAR2,     -- HIRA 거래처 코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 고객 상세 하단 리스트
 호출프로그램 :
 수정내역   : 20130115-출신학교,전공과목,취미,친밀도 항목추가        
          진료과명 코드와 이름으로 분리 110 생성
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼    
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_client_no          NUMBER;
    v_main_client        NUMBER;

    CUST_CD_NULL         EXCEPTION;

BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_04_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SFA_SALES_SEQ,sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN||'/in_CLIENT_NO '||in_CLIENT_NO );
--commit;
 
    IF in_SFA_SALES_SEQ IS NULL OR TRIM(in_SFA_SALES_SEQ) = '' THEN
        RAISE CUST_CD_NULL;
    END IF;

    SELECT COUNT(*) 
      INTO v_num
      FROM SALE.SFA_HIRA_CUSTOMER a
          ,ORAGMP.CMHIRAM b
     WHERE b.plantcode = '1000' and a.hiracode  = b.hiracode AND NVL(a.del_yn, 'N') = 'N' AND a.hiracode  = in_SFA_SALES_SEQ; 

    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '고객 정보가 존재하지 않습니다.';
    ELSIF (v_num >= 1) THEN
        out_COUNT := v_num;
        out_CODE := 0;
        out_MSG := '고객 정보 확인완료';

        OPEN out_RESULT FOR
            SELECT a.hiracode           AS out_SFA_SALES_SEQ   --거래처키값
                 , a.hiracode           AS out_CUST_CD --sfa거래처코드
                 , b.hiraname           AS out_CUST_NM --sfa거래처명    
                 , a.SFA_CLIENT_NO      AS out_CLIENT_NO     --고객번호
                 , a.CLIENT_GUBUN       AS out_CLIENT_GUBUN  --고객구분(01:대표,02:의사,03:약사, 04:사무장, 05:일반)
                 , a.CLIENT_DEPT        AS out_CLIENT_DEPT   --고객소속
                 , a.POSITION_NAME      AS out_POSITION_NM   --직책
                 , a.CLIENT_NAME        AS out_CLIENT_NM     --고객명
                 , a.MALE               AS out_MALE          --성별
                 , a.TEL_NO             AS out_TEL_NO        --전화번호
                 , a.HP_NO              AS out_HP_NO         --휴대폰번호
                 , a.EMAIL              AS out_EMAIL         --이메일
                 , a.BIRTHDAY           AS out_BIRTHDAY      --생년월일
                 , a.BIRTHDAY_GUBUN     AS out_BIRTHDAY_GUBUN --생일구분(음/양)
                 , a.ZIP_CODE           AS out_ZIP_CODE       --우편번호
                 , a.DETAIL_ADDR1       AS out_DETAIL_ADDR1   --주소
                 , a.DETAIL_ADDR2       AS out_DETAIL_ADDR2   --상세주소
                 , a.MARRY_YN           AS out_MARRY_YN       --결혼여부
                 , a.MARRY_DAY          AS out_MARRY_DAY      --결혼일 
                 , oragmp.fncommonnm('comm','SL30',a.client_gubun)  AS out_CLIENT_GUBUNNM --고객구분명 
                 , oragmp.fncommonnm('comm','SL05',a.client_dept)   AS out_CLIENT_DEPTNM  --진료과명
                 , a.LASTSCHOOLNM       AS out_LASTSCHOOLNM    --출신학교     
                 , a.MAJORSUBJECT       AS out_MAJORSUBJECT   --전공학과
                 , a.HOBBY              AS out_HOBBY          --취미     
                 , a.FRIENDSHIP         AS out_FRIENDSHIP     --고객과친밀도    
              FROM SALE.SFA_HIRA_CUSTOMER a
                  ,ORAGMP.CMHIRAM b
             WHERE b.plantcode = '1000' and a.hiracode  = b.hiracode AND NVL(a.del_yn, 'N') = 'N' AND a.hiracode  = in_SFA_SALES_SEQ
             ORDER BY a.SFA_CLIENT_NO;
             
    END IF;

EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG := '거래처코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
