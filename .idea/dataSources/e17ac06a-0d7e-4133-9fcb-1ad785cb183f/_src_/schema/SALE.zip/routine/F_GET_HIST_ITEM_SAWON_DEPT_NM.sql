CREATE function      F_GET_HIST_ITEM_SAWON_DEPT_NM
        ( A_CUST_ID      VARCHAR2,  --거래처
          A_RCUST_ID      VARCHAR2, --매출처   
          A_YMD          DATE,
          A_ITEM_ID      VARCHAR2       
        )
   RETURN VARCHAR2
AS
   user_err       exception   ;
   A_SYMD         VARCHAR2(8);
   
   V_TRAN_YMD_CD  VARCHAR2(14);
   V_TRAN_YMD_CD2  VARCHAR2(14); 
   V_SYMD         VARCHAR2(8);
   V_SYMD2         VARCHAR2(8);
   V_CUST_NM      VARCHAR2(50);
   V_SAWON_ID     VARCHAR2(7);
   V_SAWON_NM     VARCHAR2(20);
   n_rtn_value    VARCHAR2(250);
   v_curr_error   VARCHAR2(250);

/*----------------------------------------------------------------
 개요  :주문정보(거래처,매출처,주문일자,주문제품)를 받아서
        거래처별매출처별제품별 단가이력정보에서  
        해당시점의 거래처명_ 사원명_부서명 리턴
 작성일:2014.01.20
 작성자:김태안 
 
----------------------------------------------------------------*/
BEGIN
       A_SYMD := TO_CHAR(A_YMD, 'YYYYMMDD');  

      -- 거래처에 해당제품의 담당사원을 찾는다. -----------------------------------------------------------
    SELECT /*+ index_desc(A SALE0405H_PK) */
           a.sawon_id  
      INTO V_SAWON_ID   
      FROM SALE0405H A
     WHERE CUST_ID     = A_CUST_ID
       AND RCUST_ID    = A_RCUST_ID
       AND ITEM_ID     = A_ITEM_ID               
       AND APPL_DATE   = (  SELECT /*+ index_desc(A SALE0405H_01) */ 
                                   APPL_DATE
                              FROM SALE0405H A
                             WHERE CUST_ID     = A_CUST_ID
                               AND RCUST_ID    = A_RCUST_ID
                               AND ITEM_ID     = A_ITEM_ID               
                               AND APPL_DATE  <= A_SYMD
                               AND ROWNUM      = 1
                          )
       AND ROWNUM = 1;
        

      --사원의 부서이력을 찾는다.--------------------------------------------------------------
      SELECT MAX(APPL_DATE) --적용일자 
         INTO V_SYMD2
         FROM SALE0007H
        WHERE SAWON_ID   =  V_SAWON_ID AND APPL_DATE <= A_SYMD; --넘어온 날짜

       SELECT MAX(TRAN_YMD_CD) --사원변경일자 
         INTO V_TRAN_YMD_CD2
         FROM SALE0007H
        WHERE SAWON_ID  = V_SAWON_ID AND APPL_DATE = V_SYMD2;  --적용일자 
                 
        SELECT (select z.cust_nm from sale0003 z where z.cust_id = A_RCUST_ID)||'-'||SAWON_NM||'-'||(select z.dept_nm from sale0008 z where z.dept_cd = A.DEPT_CD)
          INTO n_rtn_value
          FROM SALE0007H A
         WHERE A.SAWON_ID    = V_SAWON_ID
           AND A.TRAN_YMD_CD = V_TRAN_YMD_CD2
           AND A.APPL_DATE   = V_SYMD2;  
           
           
        RETURN n_rtn_value;

EXCEPTION 
  WHEN user_err THEN
       RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
  WHEN OTHERS THEN
       RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;
/
