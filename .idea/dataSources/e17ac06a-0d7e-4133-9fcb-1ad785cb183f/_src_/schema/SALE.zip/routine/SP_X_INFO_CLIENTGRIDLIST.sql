CREATE PROCEDURE      SP_X_INFO_CLIENTGRIDLIST
(
    in_CUST_ID     IN VARCHAR2,
    in_SIDX        IN VARCHAR2,
    in_SORD        IN VARCHAR2,
    out_RESULT    OUT TYPES.CURSOR_TYPE,
    out_CODE      OUT NUMBER,
    out_MSG       OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INFO_CLIENTGRIDLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
		SELECT CUST_ID, CUSTOMER_ID, CUSTOMER_NM, SEX, MARRY_YN,
								   NVL2(BIRTH_DAY, SUBSTR(BIRTH_DAY, 1, 4)||'-'||SUBSTR(BIRTH_DAY, 5, 2)||'-'||SUBSTR(BIRTH_DAY, 7, 2), NULL) BIRTH_DAY,
								   NVL2(ACT_BIRTH_DAY, SUBSTR(ACT_BIRTH_DAY, 1, 4)||'-'||SUBSTR(ACT_BIRTH_DAY, 5, 2)||'-'||SUBSTR(ACT_BIRTH_DAY, 7, 2), NULL) ACT_BIRTH_DAY,
								   NVL2(MARRY_DAY ,SUBSTR(MARRY_DAY, 1, 4)||'-'||SUBSTR(MARRY_DAY, 5, 2)||'-'||SUBSTR(MARRY_DAY, 7, 2), NULL) MARRY_DAY,
								   CHILD_KIND, DISPOSITION, RELIGION,
								   HIGHSCHOOL, UNIVERSITY, ZIP, ADDRESS1, ADDRESS2, TEL, MOBILE, 
							       FAX, EMAIL, CAR_NO, CAR_COLOR, FOREIGN_STUDY_YN, RANK, 
							       LESSON, HOSPITAL, MAJOR, MAIN_BUYING, HUMAN_REL, HOBBY, 
							       TABOO_LIST, GITA
							  FROM SALE.CRM_MASTER
							 WHERE CUST_ID = in_CUST_ID
						ORDER BY  in_SIDX||' '||in_SORD;
						
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
