CREATE PROCEDURE      SP_SFA_ITEM_01
(
    in_ITEM_CD           IN  VARCHAR2,   -- 제품코드
    in_ITEM_NM           IN  VARCHAR2,   -- 제품 명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 제품검색 
 호출프로그램 : product.ProductList        
          2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
   --insert into SFA_SP_CALLED_HIST values ('SP_SFA_ITEM_01','4',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_DEVICEID:'||in_DEVICEID);
   -- commit;
    
    
    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.CMITEMM a
     WHERE a.plantcode = '2000'   --하길     
       AND a.itemdiv   = '04'     --완제품            
       AND a.itemcode LIKE NVL(in_ITEM_CD, '%')||'%'
       AND a.itemname LIKE '%'||NVL(in_ITEM_NM, '%')||'%';
   
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT a.itemcode           AS out_ITEM_ID,        -- 제품코드
               --case a.mplantcode when '1001' then '[도매지점]' when '1002' then '[도매향정]' when '2001' then '[하길향정]' when '2002' then '[하길마약]' end||a.itemname      AS out_ITEM_NM,        -- 제품명
               a.itemname           AS out_ITEM_NM,        -- 제품명
               a.unit               AS out_UNIT,           -- 단위
               a.drugprc            AS out_DANGA,          -- 단가(공급단가) 기준약가
               a.itemunit           AS out_STANDARD        -- 규격
          FROM ORAGMP.CMITEMM a
         WHERE a.plantcode = '2000'   --하길     
           AND a.itemdiv   = '04'     --완제품            
           AND a.itemcode LIKE NVL(in_ITEM_CD, '%')||'%'
           AND a.itemname LIKE '%'||NVL(in_ITEM_NM, '%')||'%'
         ORDER BY out_ITEM_NM;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
