CREATE PROCEDURE      SP_X_CARDMGMT_GAEJUNGCODE
(
    out_RESULT  OUT TYPES.CURSOR_TYPE,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_CARDMGMT_GAEJUNGCODE
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  법인카드관리 IBK 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
       select a.gaejung_cd,a.gaejung_nm,a.bigo
		  from (
		        select gaejung_cd,gaejung_nm,'식당,술집'								as bigo from account.faca03c where gaejung_nm like '%복리후생비%'  union all
		        select gaejung_cd,gaejung_nm,'주유소,차수리,교통카드충전,하이패스'		as bigo from account.faca03c where gaejung_nm like '%차량유지비%'  union all
		        select gaejung_cd,gaejung_nm,'교통비(버스,기차,비행기),숙박비,주차비'	as bigo from account.faca03c where gaejung_nm like '%여비교통비%'  union all
		        select gaejung_cd,gaejung_nm,'가전제품매장,철물점 등'					as bigo from account.faca03c where gaejung_nm like '%소모품비%'    union all
		        select gaejung_cd,gaejung_nm,''										as bigo from account.faca03c where gaejung_nm like '%회의비%'      union all
		        select gaejung_cd,gaejung_nm,''										as bigo from account.faca03c where gaejung_nm like '%교육훈련비%'  union all
		        select gaejung_cd,gaejung_nm,''										as bigo from account.faca03c where gaejung_nm like '%도서인쇄비%'  union all
		        select gaejung_cd,gaejung_nm,''										as bigo from account.faca03c where gaejung_nm like '%운반비%'      union all
		        select gaejung_cd,gaejung_nm,'철도청,반환수수료'						as bigo from account.faca03c where gaejung_nm like '%지급수수료%'  union all
		        select gaejung_cd,gaejung_nm,''										as bigo from account.faca03c where gaejung_nm like '%집기비품%'    union all
		        select gaejung_cd,gaejung_nm,''										as bigo from account.faca03c where gaejung_nm like '%판매촉진비%'  union all
		        select gaejung_cd,gaejung_nm,''										as bigo from account.faca03c where gaejung_nm like '%통신비%'      union all
		        select gaejung_cd,gaejung_nm,''										as bigo from account.faca03c where gaejung_nm like '%광고선전비%'
		       ) a, account.faca03c b
		 where b.gaejung_cd = a.gaejung_cd
		   and b.junpyo_yn = 'Y'
		   and b.sayong_yn = 'Y'
		   and b.gaejung_cd in ('81050AA','81110AB','81230AA','81060AA','81170AA','81050AA','81210AA');
    
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
