CREATE PROCEDURE P_INV_MAGAM_IWOL
            (  ai_gubun        IN      VARCHAR2,  -- 마감구분(01 일월계 집계 및 출고가 확정, 02 년이월)
               ai_yyyymm_f     IN      VARCHAR2,  -- 마감년월기간 from
               ai_yyyymm_t     IN      VARCHAR2,  -- 마감년월기간 to
               ai_yyyy         IN      VARCHAR2,  -- 년이월시 해당년도
               ao_msg          IN OUT  VARCHAR2   -- 메시지(리턴값, 성공시는 SUCCESS)
            )
IS
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ******************************************************************************* */
/*   TITLE        :  마감작업(01 일월계 집계 및 출고가 확정, 02 년이월)              */
/*   PROJECT      :  하나제약 원부자재 관리                                          */
/*   AUTHOR       :  이 원 선                                                       */
/*   PROGRAM_ID   :  P_INV_MAGAM_IWOL                                               */
/*   HISTORY      :  2000.12.11 (화)                                                */
/* ******************************************************************************** */
/*   PROCESS      :  1. 일월계 집계 및 출고가 확정                                    */
/*                      입출고전표 작성시 자동(트리거)으로 일월계 테이블에 누적하나     */
/*                      트리거가 죽거나 예상치 못한 현상으로 누적 안될 경우를 대비하여  */
/*                      수작업으로 돌릴 수 있도록 프로시저를 생성함.                   */
/*                      아울러, 출고가를 총평균법으로 셋팅함.(해당년도 01-종료월 까지)  */
/*                   2. 년이월                                                       */
/*                      - 입출고전표에 의한 잔고를 차년도로 이월함.                    */
/*                      - 입력한 년도의 원부자재별 입고-출고 자료를                    */
/*                        차년도 01월, 이월여부 'Y'로 하여 입력함.                    */
/* ******************************************************************************** */
   v_count      number := 0 ;
   v_curr_jakup varchar2(100) ;
   v_curr_error varchar2(100) ;
   v_message    varchar2(250) := 'FAIL' ;
   
   user_err     exception     ;
   
   v_gubun      varchar2(2) ;
   v_yyyymm_f   varchar2(6) ;
   v_yyyymm_t   varchar2(6) ;
   v_yyyy       varchar2(4) ;
   v_yyyy_next  varchar2(4) ;
   
   v_cd         varchar2(20) ;
   v_nm         varchar2(100) ;
   v_dummy      varchar2(100) ;

BEGIN
   /* ############### 01 일계,월계 집계 및 출고가 확정 작업 ############### */
   IF ai_gubun != '01' THEN
      GOTO year_iwol ;
   END IF ;
   
   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '작업조건 확인: ';  
   v_yyyymm_f := LTRIM(RTRIM(ai_yyyymm_f))  ;
   v_yyyymm_t := LTRIM(RTRIM(ai_yyyymm_t))  ;
   
   if NVL(v_yyyymm_f, ' ') = ' ' or NVL(v_yyyymm_t, ' ') = ' ' then
      v_curr_error := '년월일 기간 조건 중 시작월 또는 종료월 값이 없음. => '||v_yyyymm_f||'/'||v_yyyymm_t ;
      RAISE user_err ;
   end if ;

   IF F_CHECK_DATE('YYYYMM', v_yyyymm_f) = 'FALSE' THEN
      v_curr_error := '년월일 기간 조건 중 시작월 값이 올바르지 않음.=> '||v_yyyymm_f ;
      RAISE user_err ;
   END IF ;
   IF F_CHECK_DATE('YYYYMM', v_yyyymm_t) = 'FALSE' THEN
      v_curr_error := '년월일 기간 조건 중 종료월 값이 올바르지 않음.=> '||v_yyyymm_t ;
      RAISE user_err ;
   END IF ;
   
   IF SUBSTRB(v_yyyymm_f,1,4) != SUBSTRB(v_yyyymm_t,1,4) THEN
      v_curr_error := '년월일 기간의 시작년도와 종료년도는 일치해야 함.=> '||v_yyyymm_f||'/'||v_yyyymm_t ;
      RAISE user_err ;
   END IF ;
-- ???????????????
   /* ********************************************************************************* */
   /* 해당기간내에 집계할 원부자재 입출고 전표가 없을 경우 일/월계 테이블에 0인 상태의      */
   /* 기존 자료는 일단 삭제하기 위해 commit을 수행함.      */
   /* ********************************************************************************* */
--   commit ;
   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '입출고전표Detail의 자료 존재여부 확인: ';  
   SELECT COUNT(*)
     INTO v_count
     FROM INV0302 -- 입출고전표Detail
    WHERE YMD         >= v_yyyymm_f||'01'
      AND YMD         <= v_yyyymm_t||'31'
      AND ROWNUM < 2 ;

   if v_count = 0 then
      v_curr_error := '해당기간내 존재하지 않음.=> '||v_yyyymm_f||'~'||v_yyyymm_t ;
      RAISE user_err ;
   end if ;

   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '입출고 전표 Detail 중 마스터가 없는 자료 확인: ';  
   SELECT COUNT(*), MIN(ymd||'-'||slip_no)
     INTO v_count, v_dummy
     FROM INV0302
    WHERE YMD    >= v_yyyymm_f||'01'
      AND YMD    <= v_yyyymm_t||'31'
      AND NOT EXISTS (SELECT * 
                        FROM INV0301
                       WHERE ymd     = INV0302.ymd
                         AND slip_no = INV0302.slip_no)
      AND ROWNUM < 2 ;
   if v_count > 0 then
      v_curr_error := '마스터 없는 자료가 존재함. 관리자에게 문의바람.=>전표일자/번호 '||v_dummy ;
      RAISE user_err ;
   end if ;    
   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '입출고전표Detail의 전표구분코드 확인: ';  
   SELECT COUNT(*), MIN(INV0302.ymd||INV0302.slip_no)
     INTO v_count, v_dummy
     FROM INV0302 -- 입출고전표Detail
    WHERE INV0302.YMD         >= v_yyyymm_f||'01'
      AND INV0302.YMD         <= v_yyyymm_t||'31'
      AND 0 = (SELECT COUNT(*)
                 FROM INV0001 -- 전표구분코드
                WHERE INV0001.junpyogb_cd = INV0302.junpyogb_cd) 
      AND ROWNUM < 3 ;

   if v_count > 0 then
      v_curr_error := '해당기간 자료중 잘못된 전표구분코드가 존재함. 작성일/번호=> '||v_dummy ;
      RAISE user_err ;
   end if ;

   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '입출고전표-일계 기존자료 삭제: ';  
   DELETE FROM INV0402
    WHERE ymd >= v_yyyymm_f||'01'
      AND ymd <= v_yyyymm_t||'31' ;
   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '입출고전표-일계 누적: ';  
   INSERT INTO INV0402
                (ymd, material_id, ipgo_qty, ipgo_amt, chulgo_qty, chulgo_amt, bigo) 
          SELECT INV0302.ymd, INV0302.material_id, 
                 NVL(SUM(decode(INV0001.ipchul_gb, '1', qty)), 0), -- 1 입고, 2 출고
                 NVL(SUM(decode(INV0001.ipchul_gb, '1', qty * danga)), 0),
                 NVL(SUM(decode(INV0001.ipchul_gb, '2', qty)), 0), 0, 
                 '작업일: '||to_char(sysdate,'yyyymmdd')
            FROM INV0302, INV0001 -- 입출고전표Detail, 전표구분코드
           WHERE INV0302.YMD         >= v_yyyymm_f||'01'
             AND INV0302.YMD         <= v_yyyymm_t||'31'
             AND INV0302.junpyogb_cd =  INV0001.junpyogb_cd 
           GROUP BY INV0302.ymd, INV0302.material_id ;

   v_curr_jakup := '생성완료된 일계 집계자료 중 수량,금액이 모두 ZERO인 자료 삭제: ';  
   DELETE FROM INV0402
    WHERE ymd >= v_yyyymm_f||'01'
      AND ymd <= v_yyyymm_t||'31' 
      AND ipgo_qty   = 0
      AND ipgo_amt   = 0 
      AND chulgo_qty = 0
      AND chulgo_amt = 0 ;
             
   /* ------------------------------------------------------------------------------------- */
   /* - 출고가를 일계 테이블을 사용할까 또는 입출고전표Detail에서 사용할까 ????????????????? - */
   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '입출고전표-일계 누적(출고가 처리): ';  
   FOR cur1 IN ( select substrb(ymd,1,6) yyyymm, count(*) cnt
                   from INV0402
                  where ymd >= v_yyyymm_f||'01'
                    and ymd <= v_yyyymm_t||'31'
                    and chulgo_qty != 0 
                  group by substrb(ymd,1,6)
               )
    LOOP
       if cur1.cnt = 0 then
          goto NOTHING ;
       end if ;

       UPDATE INV0402
          SET chulgo_danga
                  = (select decode(NVL(SUM(SUB.ipgo_qty),0), 0, 0
                                             , ROUND(NVL(SUM(SUB.ipgo_amt),0) / NVL(SUM(SUB.ipgo_qty),0),2)
                                  )
                       from INV0402 SUB
                      where SUB.ymd        >= substrb(cur1.yyyymm,1,4)||'0101'
                        and SUB.ymd        <= cur1.yyyymm||'31'
                        and SUB.material_id =  INV0402.material_id)
       WHERE ymd >= cur1.yyyymm||'01'
         AND ymd <= cur1.yyyymm||'31' ;
         
       << NOTHING >>
       NULL ;
    END LOOP ;

   UPDATE INV0402
      SET chulgo_amt = ROUND(chulgo_qty * chulgo_danga, 2)
    WHERE ymd >= v_yyyymm_f||'01'
      AND ymd <= v_yyyymm_t||'31' ;
      
   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '입출고전표-월계 기존자료 삭제: ';  
   DELETE FROM INV0403
    WHERE yyyymm > substrb(v_yyyymm_f,1,4)||'00' -- 이월자료는 '년도00'
      AND yyyymm >= v_yyyymm_f
      AND yyyymm <= v_yyyymm_t ;
   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '입출고전표-월계 누적: ';  
   INSERT INTO INV0403
                (yyyymm, material_id, 
                 ipgo_qty, ipgo_amt, chulgo_qty, chulgo_amt, bigo)
          SELECT SUBSTRB(INV0402.ymd,1,6),  INV0402.material_id,
                 NVL(SUM(INV0402.ipgo_qty), 0),  NVL(SUM(INV0402.ipgo_amt), 0),
                 NVL(SUM(INV0402.chulgo_qty),0), NVL(SUM(INV0402.chulgo_amt),0), 
                 '작업일: '||to_char(sysdate,'yyyymmdd')
            FROM INV0402 -- 입출고전표-일계
           WHERE INV0402.ymd         >= v_yyyymm_f||'01'
             AND INV0402.ymd         <= v_yyyymm_t||'31'
           GROUP BY SUBSTRB(INV0402.ymd,1,6), INV0402.material_id ;

   v_curr_jakup := '생성완료된 월계 집계자료 중 수량,금액이 모두 ZERO인 자료 삭제: ';  
   DELETE FROM INV0403
    WHERE yyyymm > substrb(v_yyyymm_f,1,4)||'00' -- 이월자료는 '년도00'
      AND yyyymm >= v_yyyymm_f
      AND yyyymm <= v_yyyymm_t
      AND ipgo_qty   = 0
      AND ipgo_amt   = 0 
      AND chulgo_qty = 0
      AND chulgo_amt = 0 ;
   
   /* ############### 02 년이월 ############### */
   <<year_iwol>>
   IF ai_gubun != '02' THEN
      GOTO the_end ;
   END IF ;

   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '년이월 작업조건 확인: ';  
   v_yyyy := LTRIM(RTRIM(ai_yyyy))  ;
   
   if NVL(v_yyyy, ' ') = ' ' OR F_CHECK_DATE('YYYY', v_yyyy) = 'FALSE' then
      v_curr_error := '이월할 년도 조건 값이 없거나 오류임. => '||v_yyyy ;
      RAISE user_err ;
   end if ;

   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '입출고전표-월계 기존자료 삭제(이월자료): ';  
   v_yyyy_next := ltrim(to_char(to_number(v_yyyy)+1)) ;
   DELETE FROM INV0403
    WHERE yyyymm = v_yyyy_next||'00' -- 이월자료는 '년도00'
    ;
   /* ********************************************************************************* */
   /* 해당기간내에 집계할 원부자재 입출고 전표가 없을 경우 일/월계 테이블에 0인 상태의      */
   /* 기존 자료는 일단 삭제하기 위해 commit을 수행함.      */
   /* ********************************************************************************* */
   commit ;
   /* ------------------------------------------------------------------------------------- */
   v_curr_jakup := '입출고전표-월계 이월자료 존재여부 확인: ';  
   SELECT COUNT(*)
     INTO v_count
     FROM INV0403 -- 입출고전표-월계
    WHERE YYYYMM      >= v_yyyy||'01'
      AND YYYYMM      <= v_yyyy||'12'
      AND ROWNUM      < 2 ;

   if v_count = 0 then
      v_curr_error := '해당기간내 존재하지 않음.=> '||v_yyyy||'01'||'~'||v_yyyy||'12' ;
      RAISE user_err ;
   end if ;

   /* ********************************************************************************* */
   /* 입력한 년도의 원부자재별 입고-출고 자료를 차년도 01월, 이월여부 'Y'로 하여 입력함.    */
   /* ********************************************************************************* */
   v_curr_jakup := '입출고전표-월계 누적(이월자료): ';  
   INSERT INTO INV0403
                (yyyymm, material_id,
                 ipgo_qty, ipgo_amt, chulgo_qty, chulgo_amt, bigo)
          SELECT v_yyyy_next||'00', INV0403.material_id,
                 NVL(SUM(INV0403.ipgo_qty), 0) - NVL(SUM(INV0403.chulgo_qty),0),
                 NVL(SUM(INV0403.ipgo_amt), 0) - NVL(SUM(INV0403.chulgo_amt),0),
                 0, 0,
                 '작업일: '   ||to_char(sysdate,'yyyymmdd')||
                 '/입고수량: '||to_char(NVL(SUM(INV0403.ipgo_qty), 0))||
                 '/출고수량: '||to_char(NVL(SUM(INV0403.chulgo_qty), 0))||
                 '/입고금액: '||to_char(NVL(SUM(INV0403.ipgo_amt), 0))||
                 '/출고금액: '||to_char(NVL(SUM(INV0403.chulgo_amt), 0))
            FROM INV0403
           WHERE INV0403.yyyymm      >= v_yyyy||'00'
             AND INV0403.yyyymm      <= v_yyyy||'12'
           GROUP BY INV0403.material_id ;

   v_curr_jakup := '생성완료된 이월자료 중 이월수량 또는 금액이 ZERO인 자료 삭제: ';  
   DELETE FROM INV0403
    WHERE yyyymm  = v_yyyy_next||'00'
      AND ipgo_qty = 0
      AND ipgo_amt = 0 ;
   
   <<the_end>>
   v_message := 'SUCCESS' ;
   ao_msg    := v_message ;
   commit ;
      
   EXCEPTION
      WHEN user_err THEN
         v_message := substrb(v_curr_jakup||v_curr_error,1,250) ;
         ao_msg    := v_message ;
         Rollback ;
         RAISE_APPLICATION_ERROR(-20001, v_message);
      WHEN OTHERS THEN
         v_message := substrb(v_curr_jakup||v_curr_error||SQLERRM,1,250) ;
         ao_msg    := v_message ;
         Rollback ;
         RAISE_APPLICATION_ERROR(-20002, v_message);
END;


/
