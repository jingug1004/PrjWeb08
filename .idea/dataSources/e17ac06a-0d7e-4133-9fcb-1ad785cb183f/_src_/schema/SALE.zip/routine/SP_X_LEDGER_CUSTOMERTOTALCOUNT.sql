CREATE PROCEDURE      SP_X_LEDGER_CUSTOMERTOTALCOUNT
(
    in_FR_DATE    IN VARCHAR2,
    in_TO_DATE    IN VARCHAR2,
    in_FR_CUST    IN VARCHAR2,
    in_ASSGNCODE  IN VARCHAR2,
    in_DEPT_CD    IN VARCHAR2,
    in_EMP_CD     IN VARCHAR2,
    in_SIDX       IN VARCHAR2,
    in_SORD       IN VARCHAR2,
    out_TOTAL_CNT OUT NUMBER,
    out_CODE      OUT NUMBER,
    out_MSG       OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_LEDGER_CUSTOMERTOTALCOUNT
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 거래처 목록 총수 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	SELECT COUNT(DISTINCT(C.CUST_ID)) INTO out_TOTAL_CNT
		  FROM (SELECT 1                             SEQ,
		               A.CUST_ID                     CUST_ID,
		               (NVL(B.AMT,0) + NVL(B.VAT,0)) TOT
		          FROM SALE.SALE0207 A, 
		               SALE.SALE0208 B, 
		               SALE.SALE0004 D,
		               SALE.SALE0203 E
		         WHERE A.DEAL_NO = B.DEAL_NO
		           AND A.YMD     = B.YMD
		           AND B.ITEM_ID = D.ITEM_ID
		           AND A.YMD BETWEEN in_FR_DATE AND in_TO_DATE
				   AND A.CUST_ID = in_FR_CUST
		           AND A.GUMAE_NO = E.GUMAE_NO(+)
		        UNION ALL /*  수금(할인) 내역 */
		        SELECT 2                             SEQ,
		               A.CUST_ID                     CUST_ID,
		               NVL(-(CASH_AMT),0)            TOT
		          FROM SALE.SALE0401  A
		         WHERE A.YMD         BETWEEN in_FR_DATE AND in_TO_DATE
				   AND A.CUST_ID = in_FR_CUST
		           AND A.CASH_AMT      <> 0
		        UNION ALL
		        SELECT 2                             SEQ,
		               A.CUST_ID                     CUST_ID,
		               NVL(-(AMT),0)                 TOT
		          FROM SALE.SALE0402  B,
		               SALE.SALE0401  A,
		               (SELECT CODE1, CODE1_NM FROM  SALE.SALE0001 WHERE CODE_GB = '0007') C
		         WHERE A.YMD         BETWEEN in_FR_DATE AND in_TO_DATE
		           AND A.JUNPYO_NO   = B.JUNPYO_NO
				   AND A.CUST_ID = in_FR_CUST
		           AND B.BILL_GB = C.CODE1(+))  A,
		       (SELECT CUST_ID                  CUST_ID,
		               NVL(SUM(BEFORE_AMT),0)   BEFORE_AMT
		          FROM (SELECT CUST_ID,                   /*전월 잔액 */
		                       BEFORE_AMT      BEFORE_AMT
		                  FROM SALE.SALE0306
		                 WHERE YMD         = TO_DATE(SUBSTR(in_FR_DATE, 1, 7) || '-01','YYYY/MM/DD')
						   AND CUST_ID = in_FR_CUST
		                 UNION ALL
		                SELECT CUST_ID,                  /*금월의 조회조건 기간까지의 잔액*/
		                       NVL(A.AMT,0) + NVL(A.VAT,0)  
		                       BEFORE_AMT
		                  FROM SALE.SALE0207  B,
		                       SALE.SALE0208  A
		                 WHERE A.DEAL_NO    = B.DEAL_NO
		                   AND A.YMD        = B.YMD
						   AND B.CUST_ID = in_FR_CUST
		                   AND A.YMD        >= TO_DATE(SUBSTR(in_FR_DATE, 1, 7) || '-01','YYYY/MM/DD')
		                   AND A.YMD        <  in_FR_DATE
		                     UNION all
		                SELECT CUST_ID,     
		                       (NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1  
		                       BEFORE_AMT
		                  FROM SALE.SALE0401  A
		                 WHERE A.YMD        >= TO_DATE(SUBSTR(in_FR_DATE, 1, 7) || '-01','YYYY/MM/DD')
		                   AND A.YMD        <  in_FR_DATE
						   AND A.CUST_ID = in_FR_CUST
		                   )
		         GROUP BY CUST_ID          )  B,
		      SALE.SALE0003 C
		WHERE C.CUST_ID    = A.CUST_ID(+)
		  AND C.CUST_ID    = B.CUST_ID(+)
		  AND C.CUST_ID = in_FR_CUST
		  AND (in_ASSGNCODE IN ('27020', '27025')
		      AND C.SAWON_ID IN (SELECT SAWON_ID 
							   FROM SALE.SALE0007 
						      WHERE DEPT_CD IN (
								                select sale_dept_cd 
                                                  from hr_co_depart_0 
                                                  connect by prior dept_cd = up_dept_cd
                                                  start with dept_cd = (    select dept_cd 
                                                                              from hr_co_depart_0 
                                                                             where level = 2
                                                                              connect by  dept_cd = prior up_dept_cd
                                                                              start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no in (select insa_sawon_id from sale0007 where sawon_id = in_EMP_CD))
                                                                       )
									             )													 
				            ))
	       AND (in_ASSGNCODE IN ('27027', '27030', '27035')
		       AND C.SAWON_ID IN (SELECT SAWON_ID FROM SALE.SALE0007 WHERE DEPT_CD = in_DEPT_CD))
		   AND (in_ASSGNCODE IN ('27040', '27050')
		       AND C.SAWON_ID = in_EMP_CD)
		  AND (NVL(A.TOT,0) <> 0 OR NVL(B.BEFORE_AMT,0) <> 0);

    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
