CREATE FUNCTION      f_sp_sfa_collect_05_sum (
    in_SAWON_ID VARCHAR
   ,in_DEPT_CD VARCHAR
   ,in_CUST_CD VARCHAR
   ,in_DT_FR VARCHAR    
   ,in_DT_TO VARCHAR    
) 
   RETURN VARCHAR
AS
   out_sum   VARCHAR(30); 
 
BEGIN
  
        SELECT TRIM(to_char(SUM(NVL(AMT,0) + NVL(VAT,0)),'999,999,999,999,999'))||'/'||TRIM(to_char(SUM(NVL(SUKUM,0)),'999,999,999,999,999'))
          INTO out_sum
          FROM (SELECT 1                             SEQ,
                       A.YMD                         YMD,
                       A.CUST_ID                     CUST_ID,
                       A.RCUST_ID                    RCUST_ID,
                       B.ITEM_ID                     ITEM_ID,
                       D.ITEM_NM                     ITEM_NM,
                       D.STANDARD                    STANDARD,
                       B.QTY                         QTY,
                       B.DANGA                       DANGA,
                       B.AMT                         AMT,
                       B.VAT                         VAT,
                       B.DC_AMT                      DC_AMT,
                       B.DC_QTY                      DC_QTY,
                       B.DC_EN_YN                    DC_EN_YN,
                       0                             SUKUM,
                       (NVL(B.AMT,0) + NVL(B.VAT,0)) TOT,
                       A.DEAL_NO                     DEAL_NO,
                       DECODE(E.GUMAE_GB,'12',E.BIGO,'13',E.BIGO,'') BIGO,
                       B.INPUT_SEQ                    INPUT_SEQ
                  FROM SALE0207 A, 
                       SALE0208 B, 
                       SALE0004 D,
                       SALE0203 E
                 WHERE A.DEAL_NO = B.DEAL_NO
                   AND A.YMD     = B.YMD
                   AND B.ITEM_ID = D.ITEM_ID
                   AND A.YMD BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                   AND A.CUST_ID = in_CUST_CD 
                   AND A.GUMAE_NO = E.GUMAE_NO(+)
                UNION ALL /*  수금(할인) 내역 */
                SELECT 2                             SEQ,
                       A.YMD                         YMD,
                       A.CUST_ID                     CUST_ID,
                       A.RCUST_ID                    RCUST_ID,
                       DECODE(A.JUNPYO_GB,'01','현금','10','매출할인','20','부실채권','30','거래이관','35','대손상각','40','잡수익','45','손실정리'
                                         ,'50','부도어음대체','55','폐업상품입고','기타수금')
                                                     ITEM_ID,
                       BIGO                          ITEM_NM,
                       ''                            STANDARD,
                       0                             QTY,
                       0                             DANGA,
                       0                             AMT,
                       0                             VAT,
                       0                             DC_AMT,
                       0                             DC_QTY,
                       ''                            DC_EN_YN,
                       CASH_AMT                      SUKUM,
                       NVL(-(CASH_AMT),0)            TOT,
                       ''                            DEAL_NO,
                       ''                            BIGO,
                       ''                            INPUT_SEQ
                  FROM SALE0401  A
                 WHERE A.YMD         BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                   AND A.CUST_ID     = in_CUST_CD  
                     AND A.CASH_AMT      <> 0
                UNION ALL
                SELECT 2                             SEQ,
                       A.YMD                         YMD,
                       A.CUST_ID                     CUST_ID,
                       A.RCUST_ID                    RCUST_ID,
                       C.CODE1_NM                    ITEM_ID,                                             
                       B.BILL_NO                     ITEM_NM,
                       ''                            STANDARD,
                       0                             QTY,
                       0                             DANGA,
                       0                             AMT,
                       0                             VAT,
                       0                             DC_AMT,
                       0                             DC_QTY,
                       ''                            DC_EN_YN,
                       AMT                           SUKUM,
                       NVL(-(AMT),0)                 TOT,
                       ''                            DEAL_NO,
                       DECODE(C.CODE1,'100','',TO_CHAR(B.END_YMD,'YYYYMMDD')) BIGO,
                       ''                            INPUT_SEQ
                  FROM SALE0402  B,
                       SALE0401  A,
                       (SELECT CODE1, CODE1_NM FROM  SALE0001 WHERE CODE_GB = '0007') C
                 WHERE A.YMD         BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                   AND A.JUNPYO_NO   = B.JUNPYO_NO
                   AND A.CUST_ID     = in_CUST_CD 
                   AND B.BILL_GB = C.CODE1(+))  A,
               (SELECT CUST_ID                  CUST_ID,
                       NVL(SUM(BEFORE_AMT),0)   BEFORE_AMT
                  FROM (SELECT CUST_ID,                   /*전월 잔액 */
                               BEFORE_AMT      BEFORE_AMT
                          FROM SALE0306
                         WHERE CUST_ID     = in_CUST_CD 
                           AND YMD         = TO_DATE(SUBSTR(in_DT_FR,1,6)||'01', 'YYYY/MM/DD')
                         UNION ALL
                        SELECT CUST_ID,                  --금월의 조회조건 기간까지의 잔액
                               NVL(A.AMT,0) + NVL(A.VAT,0)  
                               BEFORE_AMT
                          FROM SALE0207  B,
                               SALE0208  A
                         WHERE A.DEAL_NO    = B.DEAL_NO
                           AND A.YMD        = B.YMD
                           AND B.CUST_ID    = in_CUST_CD  --IN (SELECT CUST_ID FROM SALE0003 WHERE CUST_NM LIKE '%'||NVL(in_CUST_NM, '%')||'%')
                           AND A.YMD        >= TO_DATE(SUBSTR(in_DT_FR,1, 6)||'01', 'YYYY/MM/DD')--TO_DATE(TO_CHAR(in_DT_FR,'YYYY/MM')||'/01','YYYY/MM/DD')
                           AND A.YMD        <  TO_DATE(in_DT_FR)
                             UNION all
                        SELECT CUST_ID,     
                               (NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1  
                               BEFORE_AMT
                          FROM SALE0401  A
                         WHERE A.CUST_ID    = in_CUST_CD  --IN (SELECT CUST_ID FROM SALE0003 WHERE CUST_NM LIKE '%'||NVL(in_CUST_NM, '%')||'%')
                           AND A.YMD        >= TO_DATE(SUBSTR(in_DT_FR,1, 6)||'01', 'YYYY/MM/DD')--TO_DATE(TO_CHAR(in_DT_FR,'YYYY/MM')||'/01','YYYY/MM/DD')
                           AND A.YMD        <  TO_DATE(in_DT_FR)
                      )
                 GROUP BY CUST_ID          )  B,
               SALE0003                       C,
               SALE0003                       D,
              (SELECT B.SAWON_ID, B.SAWON_NM, B.DEPT_CD, C.DEPT_NM 
                 FROM SALE0007 B, SALE0008 C  
                WHERE B.DEPT_CD = C.DEPT_CD)  E
         WHERE C.CUST_ID     = in_CUST_CD 
           AND C.CUST_ID    = A.CUST_ID(+)
           AND C.CUST_ID    = B.CUST_ID(+)
           AND A.RCUST_ID   = D.CUST_ID(+)
           AND C.SAWON_ID   = E.SAWON_ID(+)
           --AND (E.DEPT_CD IN   (SELECT PART_CD FROM SALE0008D WHERE DEPT_CD = in_DEPT_CD) OR E.DEPT_CD LIKE (SELECT PART_CD FROM SALE0008D WHERE DEPT_CD = in_DEPT_CD AND PART_CD = '%'))
           AND (NVL(A.TOT,0) <> 0 OR NVL(B.BEFORE_AMT,0) <> 0);


   RETURN out_sum;
END;
/
