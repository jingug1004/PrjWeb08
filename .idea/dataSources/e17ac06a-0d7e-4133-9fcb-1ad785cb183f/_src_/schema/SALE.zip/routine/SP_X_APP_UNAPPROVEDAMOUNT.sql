CREATE PROCEDURE      SP_X_APP_UNAPPROVEDAMOUNT
(
    in_FR_DATETIME   IN VARCHAR2,
    in_TO_DATETIME   IN VARCHAR2,
    in_FR_DATE       IN VARCHAR2,
    in_TO_DATE       IN VARCHAR2,
    in_CUST_ID       IN VARCHAR2,
    in_SLIP_GB       IN VARCHAR2, 
    out_REAMT       OUT NUMBER,
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_UNAPPROVEDAMOUNT
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  미승인금액 (실조건아님) 구하는 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	SELECT (SUM(B.AMT) + SUM(B.VAT)) INTO out_REAMT
		  FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
		 WHERE A.GUMAE_NO    = B.GUMAE_NO
		   AND A.RECEIPT_GB = '1'
		   AND TO_CHAR(A.INPUT_YMD, 'YYYYMMDDHH24MI') BETWEEN in_FR_DATETIME AND in_TO_DATETIME
		   AND A.YMD BETWEEN TO_DATE(in_FR_DATE) AND TO_DATE(in_TO_DATE)
		   AND A.CUST_ID    LIKE '%'||in_CUST_ID||'%'
		   AND A.SLIP_GB    = in_SLIP_GB   
		   AND DECODE (A.SLIP_GB, '2', DECODE(A.WIBAN_KIND,'0','1',A.WIBAN_ORDER_CONF_YN),'1') = '1';
		   
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
