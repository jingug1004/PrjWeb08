CREATE FUNCTION      F_DEPT_NM1  --부서코드로  부서명  가져오기
(
    in_DEPT_CD  IN  VARCHAR2
) 
RETURN VARCHAR2 IS

    v_dept_nm   VARCHAR2(30);
    
BEGIN

    SELECT DEPT_NM
      INTO v_dept_nm
      FROM SALE0008
     WHERE DEPT_CD    = in_DEPT_CD;
        
    RETURN v_dept_nm;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;
/
