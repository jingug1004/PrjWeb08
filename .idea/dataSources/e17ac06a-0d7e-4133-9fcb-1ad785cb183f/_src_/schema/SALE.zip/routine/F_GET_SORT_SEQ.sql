CREATE FUNCTION      F_GET_SORT_SEQ(V_CUST_ID IN STRING)
  RETURN VARCHAR2 IS
  
  V_CUST_NM_SORT VARCHAR2(240); 

 V_PARENTS_CUST_ID    SALE0003_DEVELOP_CHOE.PARENTS_CUST_ID%TYPE;
 V_CUST_NM   SALE0003_DEVELOP_CHOE.CUST_NM%TYPE;
 V_PARENTS_CUST_NM   SALE0003_DEVELOP_CHOE.CUST_NM%TYPE;
  
   /* INITIAL CHOE 20120530
  
   CUST_ID를 넘겨 받으면 PARENTS_CUST_ID를 확인 한다. 가장이 누구인지 확인하는 기능
   
      A. 앞 1자리 - PARENTS_CUST_ID 가 있는지 여부
         1. 0000000 이면         :  내이름을 두번 새김 - 나 자신이  가장 우선 순위 1 
         2. 아버지가 있으면  :  아버지 이름 다음 내 이름 새김  
    
   */  
  
BEGIN
   
   /* 변수 초기화 */
   V_CUST_NM_SORT := '';
   V_CUST_NM  := '';
   V_PARENTS_CUST_ID  := '';
   V_PARENTS_CUST_NM  := '';
   
   /* 거래처번호에 따른 부보거래처 코드 OR  본인 이름을 가져옴 */
    SELECT PARENTS_CUST_ID, CUST_ID||CUST_NM
       INTO V_PARENTS_CUST_ID, V_CUST_NM
      --FROM SALE0003_DEVELOP_CHOE
      FROM SALE0003
    WHERE CUST_ID = V_CUST_ID;
        --AND USE_YN = 'Y';   /*사용중인 거래처  */
        
     /* 아버지 거래처번호에 따른  아버지 이름 */
    SELECT CUST_ID||CUST_NM
       INTO  V_PARENTS_CUST_NM
      --FROM SALE0003_DEVELOP_CHOE
      FROM SALE0003
    WHERE CUST_ID = V_PARENTS_CUST_ID;
        --AND USE_YN = 'Y';   /*사용중인 거래처  */        
    
     /* A 1자리*/
        IF V_PARENTS_CUST_ID = '0000000'  THEN
            V_CUST_NM_SORT := V_CUST_NM;
        ELSE
            V_CUST_NM_SORT := V_PARENTS_CUST_NM/*||' '||V_CUST_NM*/;
        END IF;   
  
  DBMS_OUTPUT.PUT_LINE('  V_CUST_NM_SORT:'||TO_CHAR(V_CUST_NM_SORT));
  RETURN V_CUST_NM_SORT;
  
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    IF V_CUST_NM_SORT IS NULL THEN
      V_CUST_NM_SORT := '1';
    END IF;
    DBMS_OUTPUT.PUT_LINE('  V_CUST_NM_SORT:'||TO_CHAR(V_CUST_NM_SORT));
    RETURN V_CUST_NM_SORT;
END;

/
