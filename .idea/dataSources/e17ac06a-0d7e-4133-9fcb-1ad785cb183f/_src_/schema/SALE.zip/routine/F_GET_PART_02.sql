CREATE FUNCTION      F_GET_PART_02
(
    in_CUST_ID  IN  VARCHAR2,
    in_RCUST_ID  IN  VARCHAR2,
    in_ITEM_ID  IN  VARCHAR2
) 

/*-----------------------------------
직납처,간납처,제품을 입력받아 담당자의 소속파트를 RETURN 
IN  : CUST_ID,RCUST_ID,ITEM_ID
OUT : PART_CD : 도매면 1 아니면 2 를 return 
------------------------------------*/
RETURN VARCHAR2 IS

    v_part_gb   VARCHAR2(5);
    
BEGIN

    SELECT decode(b.part_cd,'01','1','2')  --도매면 1 아니면 2
      INTO v_part_gb
      FROM SALE0007 a
          ,SALE0008 b
     WHERE a.dept_cd = b.dept_cd
       AND a.sawon_id = (select sawon_id from sale0405 where cust_id = in_CUST_ID and rcust_id = in_RCUST_ID and item_id = in_ITEM_ID);
        
    RETURN v_part_gb;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;

/
