CREATE PROCEDURE      SP_SFA_STATUS_07_115
(
    in_DEPT_CD           IN  VARCHAR2,    -- 부서코드
    in_SAWON_ID          IN  VARCHAR2,    -- 사원코드
    in_DT_FR             IN  VARCHAR2,    -- 기간 FROM
    in_DT_TO             IN  VARCHAR2,    -- 기간 TO
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 출퇴근현황 
 호출프로그램 :       
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    DEPT_CD_NULL         EXCEPTION;
    SAWON_ID_NULL        EXCEPTION;
    DT_NULL              EXCEPTION;
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_STATUS_07_115',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_DEPT_CD,sysdate,'in_DEPT_CD:'||in_DEPT_CD||'/in_PART_CD '||in_PART_CD );
--commit;


    IF in_DEPT_CD IS NULL THEN
        RAISE DEPT_CD_NULL;
    END IF;
    
    IF in_SAWON_ID IS NULL THEN
        RAISE SAWON_ID_NULL;
    END IF;
    
    IF in_DT_FR IS NULL OR in_DT_TO IS NULL THEN
        RAISE DT_NULL;
    END IF;
    
     
     SELECT COUNT(*)
      INTO v_num   
      FROM (
            SELECT a.emp_no
                 , oragmp.fncommonnm('dept',a.dept_no,'')    
                 , oragmp.fncommonnm('emp',a.emp_no,'')    
                 , a.sales_plan_no 
                 , SUBSTR(MIN(a.emp_call_dtm),9,14)
                 , SUBSTR(MAX(a.emp_call_dtm),9,14) 
              FROM SALE.SFA_VISIT_PLANACT a
             WHERE a.sales_plan_no BETWEEN in_DT_FR AND in_DT_TO
               AND a.emp_no = in_SAWON_ID               
             GROUP BY a.emp_no,oragmp.fncommonnm('dept',a.dept_no,''),oragmp.fncommonnm('emp',a.emp_no,'') , a.sales_plan_no   
            );
   
          
             
                 
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
          
        OPEN out_RESULT FOR
        
        SELECT a.emp_no                                AS out_SAWON_ID    -- 사원ID
             , oragmp.fncommonnm('dept',a.dept_no,'')  AS out_DEPT_NM     -- 부서명  
             , oragmp.fncommonnm('emp',a.emp_no,'')    AS out_SAWON_NM    -- 사원명
             , a.sales_plan_no 
               ||'  ('||case to_char(to_date(SALES_PLAN_NO,'yyyymmdd'),'d') 
                       when '1' then '일' when '2' then '월'  when '3' then '화' when '4' then '수' 
                       when '5' then '목' when '6' then '금'  when '7' then '토' end ||')' 
                                                       AS out_DT          -- 근무일
             , SUBSTR(MIN(a.emp_call_dtm),9,14)        AS out_START_TIME  -- 일과시작시간
             , SUBSTR(MAX(a.emp_call_dtm),9,14)        AS out_END_TIME    -- 일과종료시간
          FROM SALE.SFA_VISIT_PLANACT a
         WHERE a.sales_plan_no BETWEEN in_DT_FR AND in_DT_TO
           AND a.emp_no = in_SAWON_ID               
         GROUP BY a.emp_no,oragmp.fncommonnm('dept',a.dept_no,''),oragmp.fncommonnm('emp',a.emp_no,'') , a.sales_plan_no   
         ORDER BY a.sales_plan_no                          
         ;
         
    END IF;
    
    
EXCEPTION
WHEN DEPT_CD_NULL THEN
   out_CODE := 102;
   out_MSG  := '부서코드가 누락되었습니다.';
WHEN SAWON_ID_NULL THEN
   out_CODE := 103;
   out_MSG  := '사원번호가 누락되었습니다.';
WHEN DT_NULL THEN
   out_CODE := 104;
   out_MSG  := '기간입력이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
