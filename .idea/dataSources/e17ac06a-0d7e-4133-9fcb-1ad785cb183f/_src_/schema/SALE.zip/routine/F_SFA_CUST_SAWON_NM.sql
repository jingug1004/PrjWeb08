CREATE FUNCTION      F_SFA_CUST_SAWON_NM  --거래처코드를 받아서 주문 또는 활동 사원명을 RETURN
(
    in_SAWON_ID       IN  VARCHAR2, --영업사번
    in_SFA_SALES_SEQ  IN  NUMBER    --SFA거래처키컬럼
) 
RETURN VARCHAR2 IS

    v_sawon_nm      VARCHAR2(20);  --담당사번명 
    v_sawon_id      VARCHAR2(20);  --담당사번
    v_insa_sawon_id VARCHAR2(7);
    v_insa_dept_cd  VARCHAR2(4);
    v_assgn_cd      VARCHAR2(5);
    
    v_cnt           NUMBER;
    v_rtn_nm        VARCHAR2(10); --활,주
    
BEGIN

    --1.거래처의 담당자명을 찾는다.
    /*-----------------------------------------------------------------------------------------------------------*/
    --거래처검색창에서 팀장이나 본부장이 검색했을때 누구의 주문,활동거래처인지 확인위해 만듬
    --하나의 병원을  여러명이서 활동거래처로 등록했다면 자기 예하직원의 이름만 보이도록 함.
    --SP_SFA_COMMON_02 에서 호출.


    --로그인사원의 인사사번   
    select insa_sawon_id into v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID and gubun = 'Y';
    
    --로그인사원이 팀원인지,팀원이아닌 본부장,팀장인지 파악
    select assgn_cd into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    
    --본부장이면 한레벨 상위부서코드를 찾고 팀장이면 자기부서를 찾는다.
    v_insa_dept_cd := '';
    if v_assgn_cd = '27010' then --본부장
        select dept_cd
          into v_insa_dept_cd  
          from hr_co_depart_0 
         where use_yn = 'Y' and level = 2
       connect by dept_cd = prior up_dept_cd start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id);
                       
    elsif v_assgn_cd = '27030' then --팀장
        select dept_cd into v_insa_dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    end if;        
  
    SELECT TRIM(SUBSTR(REGEXP_REPLACE(XMLAGG(XMLELEMENT(C,EMP_NO)).GETSTRINGVAL(), '<[C/]+>', ' '),1,6))
      INTO v_sawon_nm
      FROM (
            SELECT SUBSTR(F_INSA_ASSGN_CD(NVL(B.EMP_NO,A.EMP_NO)),4,1)||F_SAWON_NM(NVL(B.EMP_NO,A.EMP_NO)) AS EMP_NO
              FROM SFA_SALES_CODE A
                  ,(SELECT SFA_SALES_SEQ,EMP_NO
                      FROM SFA_SALES_CODE_SAWON 
                     WHERE REQ_GB  = '1' AND OK_STAT = '2' 
                       AND EMP_NO IN (select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                        from sale0007 
                                       where insa_sawon_id in (select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                   connect by prior dept_cd = up_dept_cd
                                                                                     start with dept_cd = v_insa_dept_cd
                                                                                  )
                                                                  and ENGAG_DIV in ('70010','70030') --재직,휴직                                                      
                                                              )
                                         -- and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                     )                                          --: 팀장과 팀원이 활동 거래처로만 연결된 경우 팀장이름의 활동 거래처를 위로 올려 보여줌    
                    ORDER BY F_INSA_ASSGN_CD(EMP_NO)  --CHOE 20130313 팀장권한에 따른 전체 조회시  옆 코드 한줄은  절대 빼지마 !!                   
                   ) B
             WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ(+)
               AND A.SFA_SALES_SEQ = in_SFA_SALES_SEQ
               AND v_assgn_cd <> '27040' --팀원이 아닐때
          UNION ALL
           SELECT SUBSTR(F_INSA_ASSGN_CD(NVL(B.EMP_NO,A.EMP_NO)),4,1)||F_SAWON_NM(NVL(B.EMP_NO,A.EMP_NO)) AS EMP_NO
              FROM SFA_SALES_CODE A
                  ,(SELECT SFA_SALES_SEQ,EMP_NO
                      FROM SFA_SALES_CODE_SAWON 
                     WHERE REQ_GB  = '1' AND OK_STAT = '2' 
                       AND EMP_NO  = in_SAWON_ID          
                   ) B
             WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ(+)
               AND A.SFA_SALES_SEQ = in_SFA_SALES_SEQ
               AND v_assgn_cd = '27040' --팀원일때
          )
          ; 
    
    --1.담당자의 활동거래처인지 주문거래처인지 찾는다.
    /*-----------------------------------------------------------------------------------------------------------*/
     if v_assgn_cd = '27040' then --팀원
     
        v_cnt := 0;
        --SFA거래처 테이블에 주문거래처로 등록된 사원이면 이 거래처는 이 사원의 주문거래처임.
        SELECT count(*) 
          INTO v_cnt
          FROM SFA_SALES_CODE A 
         WHERE A.SFA_SALES_SEQ = in_SFA_SALES_SEQ  --거래처키      
           AND A.EMP_NO        = in_SAWON_ID       --로그인사번
           AND A.CUST_STAT_GB  = '01';             --주문거래처 
           
        IF v_cnt > 0 THEN
           v_rtn_nm := '주'; 
           
        ELSE
           --활동_주문거래처요청에서 최종적으로 승인받은 상태가 거래처에 대한 로그인 사원의 거래처상태임.    
           --인덱스는 최종자료 가져오기 위해 사용한 것이므로 지우지 말것.
            BEGIN
                SELECT /*+ INDEX_DESC(A  SFA_SALES_CODE_SAWON_KEY) */ 
                       DECODE(REQ_GB,'1','활','2','주') 
                      ,1   --이 sql에 row가 있는지 없는지 체크위한  
                  INTO v_rtn_nm
                      ,v_cnt            
                  FROM SFA_SALES_CODE_SAWON A
                 WHERE A.SFA_SALES_SEQ = in_SFA_SALES_SEQ     
                   AND A.EMP_NO        = in_SAWON_ID
                   AND A.OK_STAT = '2'  --승인   
                   AND ROWNUM = 1;                 
            EXCEPTION 
                WHEN OTHERS THEN 
                DBMS_OUTPUT.put_line('오라클에러:'||TO_CHAR(SQLCODE) ||'-'|| SQLERRM );   
            END;
               
        END IF;
        
        
        
     else                          --팀원이 아니면 
        v_cnt := 0;
        --SFA거래처 테이블에 주문거래처로 등록된 사원이면 이 거래처는 이 사원의 주문거래처임.
        SELECT count(*) 
          INTO v_cnt
          FROM SFA_SALES_CODE A 
         WHERE A.SFA_SALES_SEQ = in_SFA_SALES_SEQ --거래처키    
           AND A.EMP_NO        = in_SAWON_ID      --로그인사번
           AND A.CUST_STAT_GB  = '01';            --주문거래처 
           
        IF v_cnt > 0 THEN
           v_rtn_nm := '주'; 
           
        ELSE
           --활동_주문거래처요청에서 최종적으로 승인받은 상태가 거래처에 대한 로그인 사원의 거래처상태임.    
           --인덱스는 최종자료 가져오기 위해 사용한 것이므로 지우지 말것.
            BEGIN
                SELECT /*+ INDEX_DESC(A  SFA_SALES_CODE_SAWON_KEY) */ 
                       DECODE(REQ_GB,'1','활','2','주') 
                      ,1   --이 sql에 row가 있는지 없는지 체크위한  
                  INTO v_rtn_nm
                      ,v_cnt            
                  FROM SFA_SALES_CODE_SAWON A
                 WHERE A.SFA_SALES_SEQ = in_SFA_SALES_SEQ     
                   AND A.EMP_NO        = in_SAWON_ID
                   AND A.OK_STAT = '2'  --승인   
                   AND ROWNUM = 1;  
            EXCEPTION 
                WHEN OTHERS THEN 
                DBMS_OUTPUT.put_line('오라클에러:'||TO_CHAR(SQLCODE) ||'-'|| SQLERRM );   
            END;
               
            IF v_cnt = 0 THEN  
            
               --여기까지 오면 팀원들의 거래처임 
               --팀원의 주문이면 [팀원명-주] 로 표시하고
               --팀원의 활동이면 팀원이 한명일때는 [팀원명-활] 여러명일때는 [여러명-활] 로 표시 
               BEGIN
                   --SFA거래처에서 찾는다. 주문거래처로 1명등록될것이므로 있으면 주문거래처임 
                   SELECT '주' 
                     INTO v_rtn_nm
                     FROM DUAL
                    WHERE EXISTS ( 
                                   SELECT 'X'
                                     FROM SFA_SALES_CODE A
                                    WHERE A.SFA_SALES_SEQ = in_SFA_SALES_SEQ
                                      AND A.CUST_STAT_GB  = '01'            --주문거래처
                                      AND A.EMP_NO IS NOT NULL
                                 );
               
               EXCEPTION  WHEN NO_DATA_FOUND THEN
                                    
                    --SFA거래처요청에서 찾는다.
                    BEGIN
                        SELECT EMP_NO
                          INTO v_sawon_id 
                          FROM SFA_SALES_CODE_SAWON 
                         WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ   
                           AND EMP_NO IN (select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                            from sale0007 
                                           where insa_sawon_id in (select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                    where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                       connect by prior dept_cd = up_dept_cd
                                                                                         start with dept_cd = v_insa_dept_cd
                                                                                      )
                                                                          and ENGAG_DIV in ('70010','70030') --재직,휴직                                                      
                                                                  )
                                         )
                          AND REQ_GB  = '1' AND OK_STAT = '2'; --활동승인받은
                    EXCEPTION WHEN OTHERS THEN   
                                   v_sawon_nm := '9여러명';
                                   v_rtn_nm   := '활';
                    END;
                    
                    BEGIN
                        SELECT /*+ INDEX_DESC(A  SFA_SALES_CODE_SAWON_KEY) */ 
                               DECODE(REQ_GB,'1','활','2','주') 
                              ,1   --이 sql에 row가 있는지 없는지 체크위한  
                          INTO v_rtn_nm
                              ,v_cnt            
                          FROM SFA_SALES_CODE_SAWON A
                         WHERE A.SFA_SALES_SEQ = in_SFA_SALES_SEQ     
                           AND A.EMP_NO        = v_sawon_id       --담당사번
                           AND A.OK_STAT = '2'  --승인   
                           AND ROWNUM = 1;  
                    EXCEPTION 
                        WHEN OTHERS THEN 
                        DBMS_OUTPUT.put_line('오라클에러:'||TO_CHAR(SQLCODE) ||'-'|| SQLERRM );   
                    END;                                     
                    
                      
               END;   
            
            END IF;   
        END IF;           
     
     end if;  
    
   
 --   DBMS_OUTPUT.put_line('v_sawon_nm:'||v_sawon_nm||'-'||v_rtn_nm );
    
    DBMS_OUTPUT.put_line('RETURN result :'||v_sawon_nm||'-'||v_rtn_nm||' ,v_insa_dept_cd: '||v_insa_dept_cd||' ,in_SFA_SALES_SEQ: '||in_SFA_SALES_SEQ||' ,in_SAWON_ID: '||in_SAWON_ID);
    RETURN v_sawon_nm||'-'||v_rtn_nm;
    
EXCEPTION 
WHEN OTHERS THEN 
   --DBMS_OUTPUT.put_line('오라클에러:'||TO_CHAR(SQLCODE) ||'-'|| SQLERRM );
   RETURN '';
END;

/
