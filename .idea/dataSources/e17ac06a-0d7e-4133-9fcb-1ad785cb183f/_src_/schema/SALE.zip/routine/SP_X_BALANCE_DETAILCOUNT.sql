CREATE PROCEDURE      SP_X_BALANCE_DETAILCOUNT
(
    in_CUST_ID   IN VARCHAR2,
    out_TCNT    OUT NUMBER,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_BALANCE_DETAILCOUNT
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  잔고담보현황 목록 총수 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	SELECT COUNT(*) totalCnt INTO out_TCNT
	  FROM SALE.SALE0404 A, SALE.SALE0003 B
	 WHERE A.CUST_ID = B.CUST_ID AND A.CUST_ID = in_CUST_ID;

    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
