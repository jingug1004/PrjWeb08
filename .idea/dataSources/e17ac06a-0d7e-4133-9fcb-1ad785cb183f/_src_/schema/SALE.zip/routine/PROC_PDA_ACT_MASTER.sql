CREATE PROCEDURE      PROC_PDA_ACT_MASTER
  (IN_FLAG   IN VARCHAR2 DEFAULT NULL,
   IN_YMD    IN VARCHAR2 DEFAULT NULL,
   IN_ACT_NO IN VARCHAR2 DEFAULT NULL,
   IN_SABUN  IN VARCHAR2 DEFAULT NULL,
   IN_TEAM   IN VARCHAR2 DEFAULT NULL,
   IN_USERNM IN VARCHAR2 DEFAULT NULL,
   IN_PLANTIME IN VARCHAR2 DEFAULT NULL,
   IN_CUSTCD   IN VARCHAR2 DEFAULT NULL,
   IN_CUSTNM   IN VARCHAR2 DEFAULT NULL,
   IN_CLIENTCD IN VARCHAR2 DEFAULT NULL,
   IN_CLIENTNM IN VARCHAR2 DEFAULT NULL,
   IN_COURSENM IN VARCHAR2 DEFAULT NULL,
   IN_ACTPLANCD IN VARCHAR2 DEFAULT NULL,
   IN_ACTITEMCD IN VARCHAR2 DEFAULT NULL,
   IN_ACTITEMNAME IN VARCHAR2 DEFAULT NULL
        )
IS
    ll_max number;
    V_act_no VARCHAR2(20);
BEGIN
--raise_application_error (-20000,'통제 여신 규정을 위반 하였습니다.');
if in_flag = 'I' or in_flag = '' then

    SP_SYS100C_MAX_VALUE('SALEACT', sysdate, null,null, null, null, ll_max );
    dbms_output.put_line(ll_max  );

     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패 SP_SYS100C_MAX_VALUE');
            ROLLBACK;
            return;
     END IF;

--    V_act_no:= TO_CHAR(in_YMD,'YYYYMMDD')||TRIM(TO_CHAR(ll_max,'0000'));

    dbms_output.put_line( V_act_no  );
    /*IINSERT INTO SALE.SALEACT (
   ACTDT, SABUN, SEQ,
   TEAM, USERNM, PLANTIME,
   CUSTCD, CUSTNM, CLIENTCD,
   CLIENTNM, COURSENM, ACTPLANCD,
   ACTITEMCD, ACTITEMNAME, CREATED,
   CREATEDBY)
VALUES ( )

--체크항목
.SEQ컬럼
 - SALE.SP_SYS100C_MAX_VALUE('SALEACT', [활동일자], NULL, NULL, NULL, NULL, LV_MAX)
 - SEQ := LV_MAX

.CREATED = SYSDATE

.CREATEDBY = 로그인한 ID
   */

    INSERT INTO SALE.SALEACT (
   ACTDT, SABUN, SEQ,
   TEAM, USERNM, PLANTIME,
   CUSTCD, CUSTNM, CLIENTCD,
   CLIENTNM, COURSENM, ACTPLANCD,
   ACTITEMCD, ACTITEMNAME, CREATED,
   CREATEDBY, status )
   VALUES ( in_ymd, in_sabun, ll_max,
   in_team,in_usernm, in_plantime,
   in_custcd, in_custnm, in_clientcd,
   in_clientnm, in_coursenm, in_actplancd,
   in_actitemcd, in_actitemname, sysdate, in_sabun ,'1' );

     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패  INSERT INTO SALE.SALE0401');
            ROLLBACK;
            return;
     END IF;
elsIF in_flag = 'D' then

    delete from sale.saleact where actdt = in_ymd and  sabun = in_sabun and seq = in_act_no ;

     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패  DELETE ');
            ROLLBACK;
            return;
     END IF;

end if;


end;

/
