CREATE PROCEDURE      SP_SFA_GW_SAWON    
(    
    in_GW_DEPT_CD        IN  VARCHAR2,  -- 부서코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   :그룹웨어 사원 조회 
 호출프로그램 :  
          사용하지 않음      
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM hanagw.TCMORG_R A, hanagw.TCMUSR B
     WHERE A.UNO = B.UNO
       AND A.ORGNO = in_GW_DEPT_CD;
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT A.ORGNO                      AS out_ORG_NO          -- 그룹웨어 부서코드
             , A.UNO                        AS out_UNO             -- 그룹웨어 사원코드
             , B.USR_NM                     AS out_USR_NM           -- 사원명
             , C.SAWON_ID                   AS out_SAWON_ID         -- 영업(SFA) 사원코드
          FROM hanagw.TCMORG_R A, hanagw.TCMUSR B,
               V_SAWON_ID_MAP   C
         WHERE A.UNO = B.UNO
           AND A.UNO = C.UNO
           AND A.ORGNO = in_GW_DEPT_CD;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
