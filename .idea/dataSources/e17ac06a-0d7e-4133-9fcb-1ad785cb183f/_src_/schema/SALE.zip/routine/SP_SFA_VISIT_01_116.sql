CREATE PROCEDURE      SP_SFA_VISIT_01_116
(
    in_PROCESS_TYPE      IN  VARCHAR2,     -- 1:일일방문, 2:방문승인,3:사번,날짜,순번으로 1건조회,4:계획복사를 위한 조회
    in_SALES_PLAN_NO     IN  VARCHAR2,     -- 방문일자 Key
    in_EMP_NO            IN  VARCHAR2,     -- 로그인사번
    in_DETAIL_PLAN_NO    IN  VARCHAR2,     -- 방문순번 
    in_DT                IN  VARCHAR2,     -- 검색조건 입력일자 
    in_DEPT_CD           IN  VARCHAR2,     -- 소속부서:105버전부터  사용하지 않음: 총괄팀장,팀장에 따라 달라져서 사용못함. 
    in_GUBUN             IN  VARCHAR2,     -- 방문승인에서 사용 조회 기준 --방문계획승인여부(Y-승인,N-대기,R-보류,NULL-출퇴경유)
     
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 일일방문리스트 
 호출프로그램 : VisitDaily   spVisitDailyList       
 수정내용 
          2013.03.05 kta 승인시 서버시각으로 승인일시 제어하기 위해 in_PROCESS_TYPE 요청시  서버시각 out 에 추가
                        out_CALL_DIST 는 사용하지 않던 컬럼이므로 대신사용함.        
          2013.12.17 kta 일일방문화면 열릴때 간납처주문내역확인 팝업화면이 뜨도록 하면서 이곳에서 체크함.( in_PROCESS_TYPE = '1')
          2014.03.13 kta 일일방문화면 열릴때 회전일위반주문승인 팝업화면이 뜨도록 하면서 이곳에서 체크함.( in_PROCESS_TYPE = '1')      
          2014.07.01 csh 일일방문화면 열릴때 반품입고내역       팝업화면이 뜨도록 하면서 이곳에서 체크함.( in_PROCESS_TYPE = '1')                 
          2015.04.15 kta 총괄지점장은 위반주문승인이 하위지점들 모두의 것이 보이도록 처리함.
                         (김민진 차장이 중부총괄지점장과 원주팀장을 겸직하면서 위반주문승인해줘야 해서) 
                         총괄지점장인경우 하위에 팀장없는 부서가 있으면 그 부서의 방문계획리스트를 보여주도록 함. 
         2015.05.13 kta  sfa 에서  팝업을 연달아 띄우면 sfa가 중지되는 문제때문에 팝업을 한개씩만 띄우게 하려고 
                        위반주문리스트 없으면 간납체크,간납리스트 없으면 입고체크 하도록 처리함.    
         2015.06.08 KTA  - 임시팀장 직책코드 추가관련 수정
         2016.06.04 CHOE - 고객소속을 진료과명으로 변경하여 집계를 진행한다. 기획실 인형진 요청 영업부 표우학 상무님 지시     
         2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
    v_deptcode           VARCHAR2(4); -- 부서 
    v_query_deptcode     VARCHAR2(4); -- 조회부서
    v_assgn_cd           VARCHAR2(5); -- 직책
    v_cnt                NUMBER;
    v_rorder_view_yn     VARCHAR2(1); -- 간납처주문 보여주기 여부      
    v_wibanorder_view_yn     VARCHAR2(1); --회전일위반주문 보여주기 여부 
    
    v_stock_view_yn VARCHAR2(1); --입고현황을 보여주기 위한 CHOE 20140624
    v_sale0705_2_num NUMBER; --입고현황 입력된 수
    v_sale0705_3_num NUMBER; --영업사원이 입고현황 확인 한 수 
                
    
BEGIN 
                
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    select classdiv,deptcode into v_assgn_cd,v_deptcode from ORAGMP.CMEMPM  where empcode = in_EMP_NO;
                
    -- 조회부서:: 로그인 직책에따라 상위부서를 찾거나 본인부서를 찾는다.
    if v_assgn_cd = '27010' or v_assgn_cd = '27020' or v_assgn_cd = '27025' or v_assgn_cd = '27018' or v_assgn_cd = '27026' then   --본부장관리이사,, 총괄지점장 부본부장 선임지점장
       select deptcode 
         into v_query_deptcode 
         from ORAGMP.CMDEPTM 
        where useyn = 'Y' and level = 2 connect by deptcode = prior predeptcode start with plantcode = '1000' and deptcode = v_deptcode;
                                   
    elsif (v_assgn_cd = '27027' or v_assgn_cd = '27030' or v_assgn_cd = '27035' ) then --팀장,임시팀장 
        v_query_deptcode := v_deptcode;        
    end if;


    /*-------------------------------------------------------------------------
    1:일일방문  JSON.spVisitDailyList
        CustomerVisitHistory.java     방문활동내역 화면의 조회
        VisitDaily.java             달력의날짜클릭하여 조회
        VisitPlan.java              방문계획화면 의 조회
    -------------------------------------------------------------------------*/
    --    insert into SFA_SP_CALLED_HIST values ('SP_SFA_VISIT_01_116','1',sysdate,'in_EMP_NO:'||in_EMP_NO||'/in_SALES_PLAN_NO:'||in_SALES_PLAN_NO);
    --     COMMIT;
         
         
    IF in_PROCESS_TYPE = '1' THEN  
    

            
       v_rorder_view_yn := 'N';
       v_wibanorder_view_yn := 'N';
       v_stock_view_yn := 'N';        

       -- 로그인 직책에 따라 위반주문여부 판단   
       IF v_assgn_cd in ('27025','27027','27030','27035','27018','27026') THEN   --총괄지점장,팀장,임시팀장 부본부장 선임지점장
           select DECODE(SIGN(count(*)),1,'Y','N') 
             into v_wibanorder_view_yn
             from ORAGMP.SLORDM a
            where a.plantcode = '1000' 
              and a.orderdate >= to_char(sysdate - 30,'yyyy-mm-dd')
              and a.wibanorderreqyn  = 'Y'  --요청여부
              and a.wibanorderconfstatus = '0'  --승인여부:0-대기,1-승인,2-반려
              and a.empcode in ( 
                                  select empcode from ORAGMP.CMEMPM --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                   where plantcode = '1000' 
                                     and deptcode in (   select deptcode from ORAGMP.CMDEPTM
                                                       connect by prior deptcode = predeptcode
                                                         start with plantcode = '1000' and deptcode = v_query_deptcode
                                                     )
                                     and outyn = 'N' --재직
                                 ) ;    
       END IF;        
       
       --kta 2015.05.13 sfa 에서  팝업을 연달아 띄우면 sfa가 중지되는 문제때문에 팝업을 한개씩만 띄우게 하려고 ...  
       if v_wibanorder_view_yn = 'N' then 
            --간납처주문리스트 있는지 체크  xxx 
            select DECODE(SIGN(count(*)),1,'Y','N')
              into v_rorder_view_yn
              from ORAGMP.SLORDM a
                  ,ORAGMP.SLORDD b
             where a.plantcode = b.plantcode
               and A.orderno   = b.orderno
               and a.plantcode = '1000'
               and a.custcode  <> a.ecustcode
               and a.orderdate >= to_char(ADD_MONTHS(SYSDATE, -3),'yyyy-mm-dd')
               and (a.empcode = in_EMP_NO or a.eempcode =  in_EMP_NO)
               and decode(a.empcode ,in_EMP_NO,a.confirm_sawon_yn,a.confirm_rsawon_yn) = 'N' 
           ;
       end if;

       --kta 2015.05.13 sfa 에서  팝업을 연달아 띄우면 sfa가 중지되는 문제때문에 팝업을 한개씩만 띄우게 하려고 ...  
       if v_wibanorder_view_yn='N' and v_rorder_view_yn = 'N' then 
            --입고내역 있는지 체크 xxx
            SELECT DECODE(SIGN(count(*)),1,'Y','N')
              INTO v_stock_view_yn
              FROM SALE0705_2 a
             WHERE not exists (select 'x' from SALE0705_3 where item_id = a.item_id and reg_date = a.reg_date and sawon_id = in_EMP_NO);  
        end if;
          
         
       --방문계획 내역조회   
        SELECT count(*)
          INTO v_num
          FROM SFA_VISIT_PLANACT A 
              ,ORAGMP.CMHIRAM    B 
              ,ORAGMP.CMEMPM     C 
         WHERE a.hiracode       = b.hiracode           
           AND a.emp_no         = c.empcode             
           AND a.emp_no         = in_EMP_NO               
           AND a.sales_plan_no  = in_DT
        ;         
       
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := v_rorder_view_yn||v_wibanorder_view_yn||v_stock_view_yn||'조회한 내역이 존재하지 않습니다.' || in_EMP_NO||'/'||in_DT;
        ELSE
            out_CODE := 0;
            out_MSG := v_rorder_view_yn||v_wibanorder_view_yn||v_stock_view_yn||'검색 완료';    
         
            OPEN out_RESULT FOR
            SELECT 
                   a.hiracode                                                                            AS out_CUST_KEY,        -- 거래처코드Key
                   a.hiracode                                                                            AS out_CUST_CD,         -- 거래처코드
                   '['||SUBSTR(a.emp_call_dtm,9,2)||':'||SUBSTR(a.emp_call_dtm,11,2)||'] '||b.hiraname   AS out_CUST_NM,         -- 거래처명
                   a.sfa_client_no                                                                       AS out_CLIENT_NO,       -- 고객코드
                   F_Z_CLIENT_NM(a.hiracode, a.sfa_client_no)                                            AS out_CLIENT_NM,      -- 고객명
                   a.detail_plan_no                                                                      AS out_DETAIL_PLAN_NO,  -- 방문순번
                   a.dept_no                                                                             AS out_DEPT,            -- 사번의부서 <- 소속(전문과)
                   case 
                       when (a.visit_kind = '2')                                         then a.description --경유지일경우 비고
                       when (a.visit_kind = '1' and a.call_yn ='Y' and A.VISIT ='Y')     then '방문완료'    -- 추가방문
                       when (a.visit_kind = '1' and a.call_yn ='Y')                      then 'Call완료'    -- 추가방문
                       when (a.visit_kind = '1' and a.call_yn ='N')                      then 'Call대기'    -- 추가방문                    
                       when (a.visit_kind = '0' and a.apply_yn = 'Y' and a.call_yn ='Y' and A.VISIT ='Y') then '방문완료' 
                       when (a.visit_kind = '0' and a.apply_yn = 'Y' and a.call_yn ='Y') then 'Call완료' 
                       when (a.visit_kind = '0' and a.apply_yn = 'Y')                    then 'Call대기' 
                       when (a.visit_kind = '0' and a.apply_yn = 'N')                    then '승인대기' 
                       when (a.visit_kind = '0' and a.apply_yn = 'R')                    then '반려'                     
                       else '' end                                                                       AS out_VISIT_STATUS,    --방문상태 
                   a.call_yn                                                                             AS out_CALL_YN,         --CALL 여부 
                   a.apply_yn                                                                            AS out_APPLY_YN,        -- 승인여부
                   case 
                       when (a.visit_kind = '0' and a.apply_yn = 'N')     then '대기'      -- 계획승인대기
                       when (a.visit_kind = '0' and a.apply_yn = 'Y')     then '승인'      -- 방문계획승인
                       when (a.visit_kind = '0' and a.apply_yn = 'R')     then '반려'      -- 방문계획반려                    
                       when (a.visit_kind = '1'                     )     then '필요없음'  -- 추가승인대기                    
                       when (a.visit_kind = '2'                     )     then '필요없음'  -- 일과시작/일과종료/경유                                        
                       else '' end                                                                       AS out_APPLY_NM,        -- 승인상태
                   a.together_yn                                                                         AS out_TOGETHER_YN,     -- 동행여부
                   a.sales_plan_no                                                                       AS out_SALES_PLAN_NO,   -- 방문일자
                   a.visit                                                                               AS out_VISIT,           -- 방문완료여부 Y/N
                   a.description                                                                         AS out_DESCRIPTION,     -- 방문목적
                   a.reject_desc                                                                         AS out_REJECT_DESC,     -- 반려사유
                   a.visit_kind                                                                          AS out_VISIT_KIND,      -- 방문유형
                   F_Z_SFA_CODE_NM('VISIT_KIND',a.visit_kind)                                            AS out_VISIT_KIND_NM,   -- 방문유형
                   a.emp_no                                                                              AS out_EMP_NO,          -- 방문자사번
                   c.empname                                                                             AS out_EMP_NM,          -- 방문자이름   
                   b.hiraaddr                                                                            AS out_CUST_ADDR,       -- 거래처주소
                   b.latitude                                                                            AS out_CUST_GPS_NUM1,   -- 거래처 경도
                   b.longitude                                                                           AS out_CUST_GPS_NUM2,   -- 거래처 위도                   
                   decode(a.activity_code,'00','',a.activity_code)                                       AS out_ACTIVITY_CODE,   -- 활동황목코드
                   a.activity_desc                                                                       AS out_ACTIVITY_DESC,   -- 방문활동
                   a.main_item1                                                                          AS out_ITEM1_CD,        -- 주품목명1
                   (select itemname from ORAGMP.CMITEMM where itemcode = a.main_item1)                   AS out_MAIN_ITEM_DESC1, -- 주품목명1
                   a.main_item2                                                                          AS out_ITEM2_CD,        -- 주품목명1
                   (select itemname from ORAGMP.CMITEMM where itemcode = a.main_item2)                   AS out_MAIN_ITEM_DESC2, -- 주품목명2
                   a.activity_yn                                                                         AS out_ACTIVITY_YN,     -- 방문활동여부 Y/N
                   (select filter1 from ORAGMP.CMCOMMONM where cmmcode = 'CM15' and divcode = b.utdiv )           AS out_CALL_DIST,       --CALL오차인정거리
                   F_Z_CLIENT_DEPT(a.sfa_sales_seq, a.sfa_client_no)                                     AS out_CLIENT_DEPT      -- 고객 진료과명
              FROM SFA_VISIT_PLANACT A 
                  ,ORAGMP.CMHIRAM    B 
                  ,ORAGMP.CMEMPM     C 
             WHERE a.hiracode       = b.hiracode           
               AND a.emp_no         = c.empcode             
               AND a.emp_no         = in_EMP_NO               
               AND a.sales_plan_no  = in_DT
             ORDER BY a.sales_plan_no,a.emp_call_dtm, a.detail_plan_no;           
        END IF;
    END IF;  





    /*-------------------------------------------------------------------------
    2:방문승인 
      VisitPlanAccept.java    방문계획승인 화면 - 팀장인경우 방문승인 메뉴보임 - 사용하고 있지 않음 - 방문계획시 바로 승인처리되고 있음
    -------------------------------------------------------------------------*/
    /*
    2017.11.09 KTA 신규ERP에 맞게 수정 - 사용하지 않으므로 컨버젼하지 않음
    IF in_PROCESS_TYPE = '2' THEN  
       --총괄팀장은 팀장들의 방문계획리스트 조회 
       --팀장은 팀원들의 방문계획리스트 조회  
    END IF;    
    */ 
    
    
    /*-------------------------------------------------------------------------
    3:사번,날짜,순번으로 1건조회 
      VisitCallAccept.java   방문승인 화면의 조회     -- 사용하지 않음
      VisitCallInfo.java     일일방문수행 팝업의 조회
    -------------------------------------------------------------------------*/ 
    
    IF in_PROCESS_TYPE = '3' THEN 
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_VISIT_PLANACT A 
              ,ORAGMP.CMHIRAM  B 
              ,ORAGMP.CMEMPM     C
         WHERE a.hiracode       = b.hiracode          
           AND a.emp_no         = c.empcode  
           AND a.emp_no         LIKE  NVL(in_EMP_NO, '%')
           AND a.sales_plan_no  = in_SALES_PLAN_NO
           AND a.detail_plan_no = in_DETAIL_PLAN_NO;
       
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
         
            OPEN out_RESULT FOR
            SELECT 
                   a.hiracode                                                                            AS out_CUST_KEY,       -- 거래처코드Key
                   a.hiracode                                                                            AS out_CUST_CD,        -- 거래처코드
                   '['||SUBSTR(a.emp_call_dtm,9,2)||':'||SUBSTR(a.emp_call_dtm,11,2)||'] '||b.hiraname   AS out_CUST_NM,        -- 거래처명
                   a.sfa_client_no                                                                       AS out_CLIENT_NO,      -- 고객코드
                   F_Z_CLIENT_NM(a.hiracode, a.sfa_client_no)                                            AS out_CLIENT_NM,      -- 고객명
                   a.detail_plan_no                                                                      AS out_DETAIL_PLAN_NO,  -- 방문순번
                   a.dept_no                                                                             AS out_DEPT,            -- 사번의부서 <- 소속(전문과)
                   case 
                       when (a.visit_kind = '2')                                         then a.description --경유지일경우 비고
                       when (a.visit_kind = '1' and a.call_yn ='Y' and A.VISIT ='Y')     then '방문완료'    -- 추가방문
                       when (a.visit_kind = '1' and a.call_yn ='Y')                      then 'Call완료'    -- 추가방문
                       when (a.visit_kind = '1' and a.call_yn ='N')                      then 'Call대기'    -- 추가방문                    
                       when (a.visit_kind = '0' and a.apply_yn = 'Y' and a.call_yn ='Y' and A.VISIT ='Y') then '방문완료' 
                       when (a.visit_kind = '0' and a.apply_yn = 'Y' and a.call_yn ='Y') then 'Call완료' 
                       when (a.visit_kind = '0' and a.apply_yn = 'Y')                    then 'Call대기' 
                       when (a.visit_kind = '0' and a.apply_yn = 'N')                    then '승인대기' 
                       when (a.visit_kind = '0' and a.apply_yn = 'R')                    then '반려'                     
                       else '' end                                                                       AS out_VISIT_STATUS,    --방문상태 
                   a.call_yn                                                                             AS out_CALL_YN,         --CALL 여부 
                   a.apply_yn                                                                            AS out_APPLY_YN,        -- 승인여부
                   case 
                       when (a.visit_kind = '0' and a.apply_yn = 'N')     then '대기'      -- 계획승인대기
                       when (a.visit_kind = '0' and a.apply_yn = 'Y')     then '승인'      -- 방문계획승인
                       when (a.visit_kind = '0' and a.apply_yn = 'R')     then '반려'      -- 방문계획반려                    
                       when (a.visit_kind = '1'                     )     then '필요없음'  -- 추가승인대기                    
                       when (a.visit_kind = '2'                     )     then '필요없음'  -- 일과시작/일과종료/경유                                        
                       else '' end                                                                       AS out_APPLY_NM,        -- 승인상태
                   a.together_yn                                                                         AS out_TOGETHER_YN,     -- 동행여부
                   a.sales_plan_no                                                                       AS out_SALES_PLAN_NO,   -- 방문일자
                   a.visit                                                                               AS out_VISIT,           -- 방문완료여부 Y/N
                   a.description                                                                         AS out_DESCRIPTION,     -- 방문목적
                   a.reject_desc                                                                         AS out_REJECT_DESC,     -- 반려사유
                   a.visit_kind                                                                          AS out_VISIT_KIND,      -- 방문유형
                   F_Z_SFA_CODE_NM('VISIT_KIND',a.visit_kind)                                            AS out_VISIT_KIND_NM,   -- 방문유형
                   a.emp_no                                                                              AS out_EMP_NO,          -- 방문자사번
                   c.empname                                                                             AS out_EMP_NM,          -- 방문자이름   
                   b.hiraaddr                                                                            AS out_CUST_ADDR,       -- 거래처주소
                   b.latitude                                                                            AS out_CUST_GPS_NUM1,   -- 거래처 경도
                   b.longitude                                                                           AS out_CUST_GPS_NUM2,   -- 거래처 위도                   
                   decode(a.activity_code,'00','',a.activity_code)                                       AS out_ACTIVITY_CODE,   -- 활동황목코드
                   a.activity_desc                                                                       AS out_ACTIVITY_DESC,   -- 방문활동
                   a.main_item1                                                                          AS out_ITEM1_CD,        -- 주품목명1
                   (select itemname from ORAGMP.CMITEMM where itemcode = a.main_item1)                   AS out_MAIN_ITEM_DESC1, -- 주품목명1
                   a.main_item2                                                                          AS out_ITEM2_CD,        -- 주품목명1
                   (select itemname from ORAGMP.CMITEMM where itemcode = a.main_item2)                   AS out_MAIN_ITEM_DESC2, -- 주품목명2
                   a.activity_yn                                                                         AS out_ACTIVITY_YN,     -- 방문활동여부 Y/N
                   TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS')                                                   AS out_CALL_DIST, --CALL_DIST 는 사용하지 않던 컬럼이므로 시스템일시로 대체함.
                   F_Z_CLIENT_DEPT(a.sfa_sales_seq, a.sfa_client_no)                                     AS out_CLIENT_DEPT      -- 고객 진료과명
              FROM SFA_VISIT_PLANACT A 
                  ,ORAGMP.CMHIRAM  B 
                  ,ORAGMP.CMEMPM     C
             WHERE a.hiracode       = b.hiracode          
               AND a.emp_no         = c.empcode  
               AND a.emp_no         LIKE  NVL(in_EMP_NO, '%')
               AND a.sales_plan_no  = in_SALES_PLAN_NO
               AND a.detail_plan_no = in_DETAIL_PLAN_NO
             order by a.sales_plan_no, a.detail_plan_no;
        END IF;
    END IF; 
    
    
 
    
    
    /*-------------------------------------------------------------------------
    4:계획복사를 위한 조회
      VisitPlanCopyPop.java 
    -------------------------------------------------------------------------*/    

    -- 계획복사화면의 조회 : 일과시작 ,일과종료 경유는 제외하고 조회
    IF in_PROCESS_TYPE = '4' THEN
    
        --insert into SFA_SP_CALLED_HIST values ('SP_SFA_VISIT_01_105','4',sysdate,'in_EMP_NO:'||in_EMP_NO||'/in_DT:'||in_DT);
             
        SELECT COUNT(*)
          INTO v_num   
          FROM SFA_VISIT_PLANACT A 
              ,ORAGMP.CMHIRAM  B 
              ,ORAGMP.CMEMPM     C
         WHERE a.hiracode       = b.hiracode          
           AND a.emp_no         = c.empcode  
           AND a.emp_no         LIKE  NVL(in_EMP_NO, '%')
           AND a.sales_plan_no  = in_DT  --계획일자
           AND a.visit_kind = '0' --방문종류(0-계획방법,1-추가방문,2-출퇴경유)
         ;
       
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '이 날짜에 계획방문한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
         
            OPEN out_RESULT FOR
            SELECT 
                   a.hiracode                                                                            AS out_CUST_KEY,       -- 거래처코드Key
                   a.hiracode                                                                            AS out_CUST_CD,        -- 거래처코드
                   '['||SUBSTR(a.emp_call_dtm,9,2)||':'||SUBSTR(a.emp_call_dtm,11,2)||'] '||b.hiraname   AS out_CUST_NM,        -- 거래처명
                   a.sfa_client_no                                                                       AS out_CLIENT_NO,      -- 고객코드
                   F_Z_CLIENT_NM(a.hiracode, a.sfa_client_no)                                            AS out_CLIENT_NM,      -- 고객명
                   a.detail_plan_no                                                                      AS out_DETAIL_PLAN_NO,  -- 방문순번
                   a.dept_no                                                                             AS out_DEPT,            -- 사번의부서 <- 소속(전문과)
                   case 
                       when (a.visit_kind = '2')                                         then a.description --경유지일경우 비고
                       when (a.visit_kind = '1' and a.call_yn ='Y' and A.VISIT ='Y')     then '방문완료'    -- 추가방문
                       when (a.visit_kind = '1' and a.call_yn ='Y')                      then 'Call완료'    -- 추가방문
                       when (a.visit_kind = '1' and a.call_yn ='N')                      then 'Call대기'    -- 추가방문                    
                       when (a.visit_kind = '0' and a.apply_yn = 'Y' and a.call_yn ='Y' and A.VISIT ='Y') then '방문완료' 
                       when (a.visit_kind = '0' and a.apply_yn = 'Y' and a.call_yn ='Y') then 'Call완료' 
                       when (a.visit_kind = '0' and a.apply_yn = 'Y')                    then 'Call대기' 
                       when (a.visit_kind = '0' and a.apply_yn = 'N')                    then '승인대기' 
                       when (a.visit_kind = '0' and a.apply_yn = 'R')                    then '반려'                     
                       else '' end                                                                       AS out_VISIT_STATUS,    --방문상태 
                   a.call_yn                                                                             AS out_CALL_YN,         --CALL 여부 
                   a.apply_yn                                                                            AS out_APPLY_YN,        -- 승인여부
                   case 
                       when (a.visit_kind = '0' and a.apply_yn = 'N')     then '대기'      -- 계획승인대기
                       when (a.visit_kind = '0' and a.apply_yn = 'Y')     then '승인'      -- 방문계획승인
                       when (a.visit_kind = '0' and a.apply_yn = 'R')     then '반려'      -- 방문계획반려                    
                       when (a.visit_kind = '1'                     )     then '필요없음'  -- 추가승인대기                    
                       when (a.visit_kind = '2'                     )     then '필요없음'  -- 일과시작/일과종료/경유                                        
                       else '' end                                                                       AS out_APPLY_NM,        -- 승인상태
                   a.together_yn                                                                         AS out_TOGETHER_YN,     -- 동행여부
                   a.sales_plan_no                                                                       AS out_SALES_PLAN_NO,   -- 방문일자
                   a.visit                                                                               AS out_VISIT,           -- 방문완료여부 Y/N
                   a.description                                                                         AS out_DESCRIPTION,     -- 방문목적
                   a.reject_desc                                                                         AS out_REJECT_DESC,     -- 반려사유
                   a.visit_kind                                                                          AS out_VISIT_KIND,      -- 방문유형
                   F_Z_SFA_CODE_NM('VISIT_KIND',a.visit_kind)                                            AS out_VISIT_KIND_NM,   -- 방문유형
                   a.emp_no                                                                              AS out_EMP_NO,          -- 방문자사번
                   c.empname                                                                             AS out_EMP_NM,          -- 방문자이름   
                   b.hiraaddr                                                                            AS out_CUST_ADDR,       -- 거래처주소
                   b.latitude                                                                            AS out_CUST_GPS_NUM1,   -- 거래처 경도
                   b.longitude                                                                           AS out_CUST_GPS_NUM2,   -- 거래처 위도                   
                   decode(a.activity_code,'00','',a.activity_code)                                       AS out_ACTIVITY_CODE,   -- 활동황목코드
                   a.activity_desc                                                                       AS out_ACTIVITY_DESC,   -- 방문활동
                   a.main_item1                                                                          AS out_ITEM1_CD,        -- 주품목명1
                   (select itemname from ORAGMP.CMITEMM where itemcode = a.main_item1)                   AS out_MAIN_ITEM_DESC1, -- 주품목명1
                   a.main_item2                                                                          AS out_ITEM2_CD,        -- 주품목명1
                   (select itemname from ORAGMP.CMITEMM where itemcode = a.main_item2)                   AS out_MAIN_ITEM_DESC2, -- 주품목명2
                   a.activity_yn                                                                         AS out_ACTIVITY_YN,     -- 방문활동여부 Y/N
                   ''                                                                                    AS out_CALL_DIST,       --CALL_DIST 는 사용하지 않음
                   F_Z_CLIENT_DEPT(a.sfa_sales_seq, a.sfa_client_no)                                     AS out_CLIENT_DEPT      -- 고객 진료과명
              FROM SFA_VISIT_PLANACT A 
                  ,ORAGMP.CMHIRAM  B 
                  ,ORAGMP.CMEMPM     C
             WHERE a.hiracode       = b.hiracode          
               AND a.emp_no         = c.empcode  
               AND a.emp_no         LIKE  NVL(in_EMP_NO, '%')
               AND a.sales_plan_no  = in_DT  --계획일자
               AND a.visit_kind = '0' --방문종류(0-계획방법,1-추가방문,2-출퇴경유)
             order by a.sales_plan_no, a.detail_plan_no;
         
        END IF;
    END IF; 
 
   
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
