CREATE PROCEDURE      SP_X_APP_DELETEORDERDETAIL
(
    in_APP_DATE  IN VARCHAR2,
    in_APP_NO    IN VARCHAR2,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_DELETEORDERDETAIL
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  디테일 이관자료 삭제 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	DELETE FROM SALE.SALE0204 
	      WHERE YMD = TO_DATE(in_APP_DATE) 
	        AND GUMAE_NO = in_APP_NO;
	
    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 DELETE ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 삭제';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;
END ;
/
