CREATE PROCEDURE      SP_X_APP_CUSTOMERINFO
(
    in_CUST_ID     IN VARCHAR2,
    out_RESULT    OUT TYPES.CURSOR_TYPE,
    out_CODE      OUT NUMBER,
    out_MSG       OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_CUSTOMERINFO
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  주문승인 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    OPEN out_RESULT FOR	
	    SELECT A.CREDIT_LIMIT_AMT,
		 		NVL(F.BEFORE_AMT,0)          BEFORE_AMT,
		        NVL(F.MISU_AMT,0)            SALE_AMT,
		        NVL(F.BEFORE_AMT,0) + NVL(F.MISU_AMT,0) - NVL(F.SU_AMT,0)  CUR_AMT,
		        NVL(F.SU_AMT,0)              SU_AMT,
		        NVL(I.CASH_AMT,0)             CASH_AMT,
		        NVL(L.BILL_010_AMT,0) + NVL(L.BILL_020_AMT,0) + NVL(L.BILL_025_AMT,0) + NVL(L.BILL_030_AMT,0) + NVL(L.BILL_035_AMT,0) + NVL(L.BILL_040_AMT,0) + NVL(L.BILL_100_AMT,0) + NVL(L.BILL_900_AMT,0)   BILL_AMT,
		        NVL(L.BILL_010_AMT,0) + NVL(L.BILL_020_AMT,0) + NVL(L.BILL_030_AMT,0) + NVL(L.BILL_100_AMT,0) + NVL(L.BILL_900_AMT,0)               JASU_AMT,
		        NVL(L.BILL_025_AMT,0) + NVL(L.BILL_035_AMT,0) + NVL(L.BILL_040_AMT,0)                                                               TASU_AMT,
		        NVL(H.SALE_DAMBO_AMT,0)      SALE_DAMBO_AMT,
		        NVL(K.JUMUN_AMT,0)           JUMUN_AMT,
		        NVL(K.JUMUN_AMT,0)           JUMUN_AMT_O ,
		        NVL(A.YEONDAE_3,'N')         YEONDAE_3,
		        NVL(A.YEONDAE_2,'N')         YEONDAE_2,
		        CASE A.YEONDAE_2 WHEN 'Y' THEN (SELECT TO_NUMBER(BIGO)
		                                          FROM SALE.SALE0001
		                                         WHERE CODE_GB = '4001' 
		                                           AND CODE1 = '04') ELSE 0 END      DAMBO,
		        H.BILL_CNT                   BILL_CNT,
		        H.BILL_KIND                  BILL_KIND
		   FROM SALE.SALE0003 A,
		        ( SELECT CUST_ID , 
		                 SUM(BEFORE_AMT)  BEFORE_AMT,
		                 SUM(MISU_AMT)    MISU_AMT,
		                 SUM(SU_AMT)      SU_AMT
		            FROM SALE.SALE0306
		           WHERE YMD        = TO_DATE(TO_CHAR(SYSDATE,'YYYY/MM')||'/01','YYYY/MM/DD')
		             AND CUST_ID    = in_CUST_ID
		           GROUP BY CUST_ID
		        ) F,
		        ( SELECT X.CUST_ID, NVL(SUM(X.SALE_DAMBO_AMT),0) SALE_DAMBO_AMT, COUNT(BILL_GB) BILL_CNT,
		                 (SELECT (SELECT CODE1_NM FROM SALE.SALE0001 WHERE CODE_GB = '0022' AND CODE1 = X.BILL_GB ) BILL_GB
		                    FROM SALE.SALE0404 X
		                   WHERE X.CUST_ID    = in_CUST_ID
		                     AND NVL(X.CHULGO_YMD,TO_DATE('2999/01/01','YYYY/MM/DD')) = TO_DATE('2999/01/01','YYYY/MM/DD')
		                     AND X.DAM_BOYU_STAT = 'Y'
		                     AND ROWNUM = 1)  BILL_KIND
		            FROM SALE.SALE0404 X
		           WHERE X.CUST_ID    = in_CUST_ID
		             AND NVL(X.CHULGO_YMD,TO_DATE('2999/01/01','YYYY/MM/DD')) = TO_DATE('2999/01/01','YYYY/MM/DD')
		             AND X.DAM_BOYU_STAT = 'Y'
		           GROUP BY X.CUST_ID 
		        ) H,
		        ( SELECT X.CUST_ID , NVL(SUM(CASH_AMT),0) + NVL(SUM(BILL_AMT),0) CASH_AMT
		            FROM SALE.SALE0401 X
		           WHERE X.CUST_ID = in_CUST_ID
		             AND X.YMD BETWEEN TO_DATE(TO_CHAR(SYSDATE,'YYYY/MM')||'/01','YYYY/MM/DD')
		                           AND LAST_DAY(SYSDATE)
		           GROUP BY X.CUST_ID 
		        ) I,
		        ( SELECT X.CUST_ID , SUM(NVL(X.AMT_SUM,0) + NVL(X.VAT_SUM,0))  JUMUN_AMT
		            FROM SALE_ON.SALE0203 X
		           WHERE X.CUST_ID = in_CUST_ID
		             AND X.YMD BETWEEN TO_DATE(TO_CHAR(SYSDATE,'YYYY/MM')||'/01','YYYY/MM/DD')
		                           AND LAST_DAY(SYSDATE)
		           GROUP BY X.CUST_ID 
		        ) K,
		        (
		             SELECT X.CUST_ID        CUST_ID ,
		                   NVL(SUM(DECODE(Y.BILL_GB,'010',Y.AMT)),0)  BILL_010_AMT,
		                 NVL(SUM(DECODE(Y.BILL_GB,'020',Y.AMT)),0)  BILL_020_AMT,
		                 NVL(SUM(DECODE(Y.BILL_GB,'025',Y.AMT)),0)  BILL_025_AMT,
		                 NVL(SUM(DECODE(Y.BILL_GB,'030',Y.AMT)),0)  BILL_030_AMT,
		                 NVL(SUM(DECODE(Y.BILL_GB,'035',Y.AMT)),0)  BILL_035_AMT,
		                 NVL(SUM(DECODE(Y.BILL_GB,'040',Y.AMT)),0)  BILL_040_AMT,
		                 NVL(SUM(DECODE(Y.BILL_GB,'100',Y.AMT)),0)  BILL_100_AMT,
		                 NVL(SUM(DECODE(Y.BILL_GB,'900',Y.AMT)),0)  BILL_900_AMT
		            FROM SALE.SALE0401 X ,
		                    SALE.SALE0402 Y
		           WHERE X.YMD       = Y.YMD
		             AND X.JUNPYO_NO = Y.JUNPYO_NO 
		             AND Y.END_YMD  >= SYSDATE
		           GROUP BY X.CUST_ID
		          ) L
		  WHERE A.CUST_ID    = in_CUST_ID
		    AND A.CUST_ID    = F.CUST_ID(+)
		    AND A.CUST_ID    = H.CUST_ID(+)
		    AND A.CUST_ID    = I.CUST_ID(+)
		    AND A.CUST_ID    = K.CUST_ID(+)
		    AND A.CUST_ID    = L.CUST_ID(+);

    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
