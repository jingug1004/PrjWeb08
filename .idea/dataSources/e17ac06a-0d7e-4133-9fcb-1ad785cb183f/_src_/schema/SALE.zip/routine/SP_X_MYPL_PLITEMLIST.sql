CREATE PROCEDURE      SP_X_MYPL_PLITEMLIST
(
    in_SAWON_ID  IN VARCHAR2,
    in_PLGRP_NO  IN VARCHAR2,
    in_SIDX      IN VARCHAR2,
    in_SORD      IN VARCHAR2,
    out_RESULT  OUT TYPES.CURSOR_TYPE,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_MYPL_PLITEMLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : P/L그룹에 등록되지 않은 P/L 제품조회 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    OPEN out_RESULT FOR
		SELECT A.SAWON_ID, A.PLGRP_NO, A.ITEM_ID, A.SORT_SEQ, C.ITEM_NAME AS ITEM_NM,
		       C.ITEM_OUT_DANGA, C.ITEM_EFFECT, C.ITEM_USE_DOES, C.ITEM_KIND1,
		       C.ITEM_KIND2 ITEM_KIND, D.CODE1_NM ITEM_KIND_NM, C.ITEM_KD_NO,
		          C.ITEM_MAIN_SOURCE
		       || ''
		       || C.ITEM_MAIN_SOURCE_SIZE AS ITEM_MAIN_SOURCE_SIZE,
		       C.ITEM_POJANG_UNIT, '' AS CHECK01, '' AS CHECK02, NVL(LENGTH(C.ITEM_PHOTO), 0) AS CNT
		  FROM SALE.SFA_MYPL_01 A, SALE.SFA_OFFICE_ITEMDOC C, SALE.SALE0001 D
		 WHERE A.ITEM_ID = C.ITEM_CODE
		   AND D.CODE1 = C.ITEM_KIND2
		   AND D.CODE_GB = '0071'
		   AND A.SAWON_ID = in_SAWON_ID
		   AND A.PLGRP_NO = in_PLGRP_NO
			ORDER BY in_SIDX||' '||in_SORD;
			
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
