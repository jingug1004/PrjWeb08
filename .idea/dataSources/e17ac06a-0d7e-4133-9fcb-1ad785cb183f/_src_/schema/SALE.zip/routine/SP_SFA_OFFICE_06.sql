CREATE PROCEDURE      SP_SFA_OFFICE_06
(
    in_BRUSH_NM          IN  VARCHAR2,  
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 제품브로셔조회
 호출프로그램 : 제품> 브로셔       
          2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_BRUSHER
     WHERE brush_nm LIKE '%'||NVL(in_BRUSH_NM, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT brush_cd             AS out_BRUSH_CD,        -- 브로셔 CD
               brush_seq            AS out_BRUSH_SEQ,       -- 브로셔 SEQ
               brush_nm             AS out_BRUSH_NM,        -- 브로셔 명
               brush_yn             AS out_BRUSH_YN,        -- 브로셔 사용여부
               item_path            AS out_ITEM_PATH,       -- FILE PATH
               item_name            AS out_ITEM_NAME,        -- FILE 명
               save_item_name            AS out_ITEM_SAVE        -- 실질적인 파일명
          FROM SFA_OFFICE_BRUSHER
     WHERE brush_nm LIKE '%'||NVL(in_BRUSH_NM, '%')||'%'
     ORDER BY brush_nm;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
