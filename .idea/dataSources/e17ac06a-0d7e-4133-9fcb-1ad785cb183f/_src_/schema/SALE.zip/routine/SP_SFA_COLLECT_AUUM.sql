CREATE PROCEDURE      SP_SFA_COLLECT_AUUM
   (in_FLAG         IN VARCHAR2 DEFAULT NULL,  --처리구분    
    in_CUST_ID      IN VARCHAR2 DEFAULT NULL,  --거래처코드
    in_RCUST_ID     IN VARCHAR2 DEFAULT NULL,  --간납처코드
    in_AMT          IN VARCHAR2 DEFAULT NULL,  --금액
    in_SAWON_ID     IN VARCHAR2 DEFAULT NULL,  --로그인사번
    in_BIGO         IN VARCHAR2 DEFAULT NULL,  --비고          
    in_BILL_GB      IN VARCHAR2 DEFAULT NULL,  --어음구분    
    in_BILL_NO      IN VARCHAR2 DEFAULT NULL,  --어음번호   
    in_BALHANG      IN VARCHAR2 DEFAULT NULL,  --발행처     
    in_JIGEUB       IN VARCHAR2 DEFAULT NULL,  --지급처(은행지점코드)    
    in_START_YMD    IN VARCHAR2 DEFAULT NULL,  --발행일
    in_END_YMD      IN VARCHAR2 DEFAULT NULL,  --만기일    
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2 
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 어음수금  
 호출프로그램 : CollectAuum           
 수정기록 : 
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼   
 ---------------------------------------------------------------------------*/    
 
    ll_count number := 0;
    
    v_sawon_id     VARCHAR2(20);  --거래처담당사원                     
    v_dept_cd      VARCHAR2(4);  --거래처담당사원소속부서
    v_colno        VARCHAR2(20);  --수금전표번호 
 
    ERROR_EXCEPTION     EXCEPTION;
    
BEGIN    
 
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_AUUM',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate,'in_SAWON_ID:'||in_SAWON_ID);
--commit;
                                          
    IF in_CUST_ID IS NULL OR TRIM(in_CUST_ID) = '' THEN
        out_CODE := 1;
        out_MSG := '<거래처를 반드시 선택해야 합니다.>'; 
        RAISE ERROR_EXCEPTION;
    END IF;
    
   -- 담당사원체크
    BEGIN
        select empcode,deptcode
        into v_sawon_id,v_dept_cd
        from ORAGMP.CMCUSTM
        where plantcode = '1000'
          and custcode = in_CUST_ID ; 
        IF v_sawon_id IS NULL OR TRIM(v_sawon_id) = ''  THEN
            out_CODE := SQLCODE;
            out_MSG  := '<이거래처로 담당자가 지정되어 있지 않습니다.관리부로 연락하십시오. >';
            RAISE ERROR_EXCEPTION;           
        END IF;
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '<이거래처로 담당자가 지정되어 있지 않습니다.관리부로 연락하십시오. >';
        RAISE ERROR_EXCEPTION;
    END;      

   --중지거래처  통제(다른거래처에 수금입력 오류방지)   
    SELECT COUNT(*) INTO ll_count  FROM ORAGMP.CMCUSTM WHERE custcode = in_CUST_ID AND useyn = 'N';
    IF ll_count > 0 THEN
        out_CODE := 1;
        out_MSG := '<중지된 거래처입니다. 관리부로 연락하십시오.>'; 
        RAISE ERROR_EXCEPTION;
    END IF; 
       
    v_colno := 0; 
            
    --수금번호채번 
    SELECT MAX(colno) into v_colno from ORAGMP.SLCOLM where plantcode = '1000' and coldate = to_char(SYSDATE,'YYYY-MM-DD');
    IF SQLCODE <> 0 THEN
        out_CODE := 1;
        out_MSG := '<수금번호채번 오류입니다. 관리부로 연락하십시오.>'; 
        RAISE ERROR_EXCEPTION;
    ELSE
        IF v_colno is null THEN
           v_colno := trim(to_char(to_number(to_char(SYSDATE,'YYYYMMDD')))||'0001');
        ELSE
           v_colno := trim(to_char(to_number(v_colno) + 1,'000000000000'));
        END IF;
    END IF;
        
    BEGIN
        
        INSERT INTO ORAGMP.SLCOLM (
                plantcode      --사업장
               ,colno          --수금번호
               ,coldate        --수금일자
               ,coldiv         --수금구분 01-현금 21-카드
               ,orderdiv       --영업영역 3-간납 4직납
               ,custcode       --수금처코드
               ,deptcode       --수금담당부서코드;
               ,empcode        --수금담당코드;
               ,ecustcode      --수금처코드
               ,edeptcode      --수금담당부서코드
               ,eempcode       --수금담당코드
               ,colamt         --수금액
               ,colvat         --판매대행수수료(부가세)
               ,tasooyn        --자수타수구분(N:자수,Y:타수)
               ,billno         --어음번호
               ,issdate        --발행일자
               ,expdate        --만기일
               ,paybank        --발행은행
               ,paybankbr      --지급은행
               ,remark         --비고
               ,apprstatus     --상태구분  00:저장  01:입력  09:수금확정  99:반려
               ,insertdt       --입력일
               ,iempcode       --입력사번
               ,updatedt       --수정일
               ,uempcode       --수정사번
               )
        VALUES (     
               '1000'                                             --plantcode  사업장 
               ,v_colno                                           --colno      수금번호
               ,TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')   --coldate    수금일자
               ,'21'                                              --coldiv     수금구분 01-현금 21-카드
               ,'4'                                               --orderdiv   영업영역 3-간납 4직납
               ,in_CUST_ID                                        --custcode   수금처코드
               ,v_dept_cd                                         --deptcode   수금담당부서코드;
               ,v_sawon_id                                        --empcode    수금담당코드;
               ,in_RCUST_ID                                       --ecustcode  수금처코드
               ,v_dept_cd                                         --edeptcode  수금담당부서코드
               ,v_sawon_id                                        --eempcode   수금담당코드
               ,decode( NVL(in_AMT, ''),'','0',to_number(in_AMT)) --colamt     수금액
               ,0                                                 --colvat     판매대행수수료(부가세)
               ,in_BILL_GB                                        --tasooyn    자수타수구분(N:자수,Y:타수)
               ,in_BILL_NO                                        --billno     어음번호
               ,in_START_YMD                                      --issdate    발행일자
               ,in_END_YMD                                        --expdate    만기일
               ,in_BALHANG                                        --paybank    발행은행
               ,in_JIGEUB                                         --paybankbr  지급은행
               ,'101'                                             --remark     비고
               ,'00'                                              --apprstatus 상태구분  00:저장    01:입력  09:수금확정    99:반려
               ,sysdate                                           --insertdt   입력일
               ,in_SAWON_ID                                       --iempcode   입력사번
               ,sysdate                                           --updatedt   수정일
               ,in_SAWON_ID                                       --uempcode   수정사번
               ); 
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :='수금마스터 저장실패:'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
        RAISE ERROR_EXCEPTION;
    END;
     

    out_CODE := 0;
    out_MSG := '어음수금 정상 처리';
     
EXCEPTION
WHEN ERROR_EXCEPTION THEN
   out_CODE := SQLCODE;
   out_MSG  := '어음수금 저장오류 : '||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  := '어음수금 저장오류 : '||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
