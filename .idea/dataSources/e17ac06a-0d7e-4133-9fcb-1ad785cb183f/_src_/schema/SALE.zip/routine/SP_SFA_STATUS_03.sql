CREATE PROCEDURE      SP_SFA_STATUS_03
(
    in_CUST_CD           IN  VARCHAR2,    -- 거래처코드
    in_DT                IN  VARCHAR2,    -- 기간
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 거래처회전일 
 호출프로그램 : 거래처> 거래처현황       
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼    
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    CUST_CD_NULL         EXCEPTION;
    DT_NULL              EXCEPTION;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_04_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SFA_SALES_SEQ,sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN||'/in_CLIENT_NO '||in_CLIENT_NO );
--commit;
    
    IF in_CUST_CD IS NULL THEN
        RAISE CUST_CD_NULL;
    END IF;
    
    IF in_DT IS NULL THEN
        RAISE DT_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
           (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
              FROM SALE0401
             WHERE JUNPYO_GB = '30'
               AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
           ) E
     WHERE A.YM_F    = in_DT
       AND A.CUST_ID = in_CUST_CD
       AND A.CUST_ID  = B.CUST_ID
       AND B.SAWON_ID = C.SAWON_ID(+)
       AND C.DEPT_CD  = D.DEPT_CD(+)
       AND A.CUST_ID  = E.CUST_ID(+)
     ORDER BY B.CUST_NM;
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT '전월잔고'                                             AS out_ITEM_NM
             , TO_CHAR(A.BEFORE_AMT, '999,999,999,999,999,999')       AS out_ITEM_DATA  /* 전월잔고    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '판매'                                                 AS out_ITEM_NM
             , TO_CHAR(A.SALE, '999,999,999,999,999,999')             AS out_ITEM_DATA  /* 판매    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '반품'                                                 AS out_ITEM_NM
             , TO_CHAR(A.BANPUM, '999,999,999,999,999,999')           AS out_ITEM_DATA  /* 전월잔고    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '실판매'                                               AS out_ITEM_NM
             , TO_CHAR(A.SIL_SALE, '999,999,999,999,999,999')         AS out_ITEM_DATA  /* 실판매    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '현금+카드'                                             AS out_ITEM_NM
             , TO_CHAR(A.CASH_CARD, '999,999,999,999,999,999')         AS out_ITEM_DATA  /* 현금+카드    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '어음'                                                 AS out_ITEM_NM
             , TO_CHAR(A.BILL, '999,999,999,999,999,999')             AS out_ITEM_DATA  /* 어음    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '수금계'                                               AS out_ITEM_NM
             , TO_CHAR(A.SU_AMT, '999,999,999,999,999,999')           AS out_ITEM_DATA  /* 수금계    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '매출할인'                                             AS out_ITEM_NM
             , TO_CHAR(A.HALIN, '999,999,999,999,999,999')            AS out_ITEM_DATA  /* 매출할인    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '금월잔고'                                             AS out_ITEM_NM
             , TO_CHAR(A.JANGO, '999,999,999,999,999,999')            AS out_ITEM_DATA  /* 금월잔고    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '미결어음(자수)'                                       AS out_ITEM_NM
             , TO_CHAR(A.MIDORA_JA, '999,999,999,999,999,999')        AS out_ITEM_DATA  /* 미결어음(자수)    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '미결어음(타수)'                                       AS out_ITEM_NM
             , TO_CHAR(A.MIDORA_CHA, '999,999,999,999,999,999')       AS out_ITEM_DATA  /* 미결어음(타수)    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT 'NET잔고'                                              AS out_ITEM_NM
             , TO_CHAR(A.NET, '999,999,999,999,999,999')              AS out_ITEM_DATA  /* NET잔고    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '1개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_1, '999,999,999,999,999,999')            AS out_ITEM_DATA 
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '2개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_2, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '3개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_3, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '4개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_4, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '5개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_5, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '6개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_6, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '7개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_7, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '8개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_8, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '9개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_9, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '10개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_10, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '11개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_11, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '12개월전 판매금액'                                              AS out_ITEM_NM
             , TO_CHAR(A.MM_12, '999,999,999,999,999,999')            AS out_ITEM_DATA  
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '수금회전일'                                           AS out_ITEM_NM
             , DECODE(NVL(A.RATEDAY,0), 0, '', DECODE(A.RATEDAY,0,'', TO_CHAR(A.RATEDAY)||'일이내'))       AS out_ITEM_DATA  /* 수금회전일    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        UNION ALL 
        SELECT '담보'                                                 AS out_ITEM_NM
             , TO_CHAR(A.DAMBO, '999,999,999,999,999,999')            AS out_ITEM_DATA  /* 담보    */
          FROM EIJING A, SALE0003 B, SALE0007 C, SALE0008 D,
               (SELECT DISTINCT CUST_ID, 'TR' IGWAN_GB
                  FROM SALE0401
                 WHERE JUNPYO_GB = '30'
                   AND YMD BETWEEN ADD_MONTHS(TO_DATE(in_DT||'01'),-11) AND TO_DATE(in_DT||'01')
               ) E
         WHERE A.YM_F    = in_DT
           AND A.CUST_ID = in_CUST_CD
           AND A.CUST_ID  = B.CUST_ID
           AND B.SAWON_ID = C.SAWON_ID(+)
           AND C.DEPT_CD  = D.DEPT_CD(+)
           AND A.CUST_ID  = E.CUST_ID(+)
        ;
         
    END IF;
    
EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '거래처 코드가 누락되었습니다.';
WHEN DT_NULL THEN
   out_CODE := 102;
   out_MSG  := '조회 년월이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
