CREATE PROCEDURE      SP_X_APP_UPDATEDETAILQTY
(
    in_QTY             IN VARCHAR2,
    in_AMT             IN VARCHAR2,
    in_VAT             IN VARCHAR2,
    in_DC_AMT          IN VARCHAR2,
    in_YMD             IN VARCHAR2,
    in_DETAIL_GUMAE_NO IN VARCHAR2,
    in_INPUT_SEQ       IN VARCHAR2,
    out_CODE          OUT NUMBER,
    out_MSG           OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_UPDATEDETAILQTY
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 승인된 주문일 경우만 수량 수정 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
        UPDATE SALE_ON.sale0204
		   SET qty = in_QTY,
		   	   amt = in_AMT,
		   	   vat = in_VAT,
		   	   dc_amt = in_DC_AMT
		 WHERE ymd = in_YMD
		   AND gumae_no = in_DETAIL_GUMAE_NO
		   AND input_seq = in_INPUT_SEQ;
		   
 IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 UPDATE ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 수정';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;
        
END ;
/
