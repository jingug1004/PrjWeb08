CREATE PROCEDURE      SP_X_INQUIRE_USERPGMLIST
(
    in_EMPCODE   IN VARCHAR2,
    in_TOPCODE   IN VARCHAR2,
    out_RESULT  OUT TYPES.CURSOR_TYPE,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INQUIRE_USERPGMLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 사용자별 사용프로그램 조회 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
	    SELECT
		        *
		FROM
		(SELECT DISTINCT A.PGM_NO              
		        ,A.PGM_ID
		        ,A.PGM_NAME
		        ,A.PGM_KIND_CODE
		        ,A.PICTURE
		        ,A.SELECT_PICTURE
		        ,A.SORT_ORDER
		        ,A.PARENT_PGM
		FROM  SALE_ON.PF_PGM_MST_DEV     A, 
		      SALE_ON.PF_PGM_ROLE_DEV    B,
		      SALE_ON.PF_USERROLE_DEV    C
		WHERE C.EMP_CODE            = in_EMPCODE
		    AND B.ROLE_NO           = C.ROLE_NO
		    AND A.PGM_USE_YN        = 'Y'
		    AND A.PGM_NO            = B.PGM_NO
		    AND A.PGM_KIND_CODE IN('P','M')
		) A
		CONNECT BY PRIOR A.PGM_NO = DECODE(A.PGM_NO, A.PARENT_PGM, NULL, A.PARENT_PGM)
		START WITH A.PARENT_PGM     = in_TOPCODE
		ORDER SIBLINGS BY A.PARENT_PGM ASC, A.SORT_ORDER ASC;
		
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
