CREATE PROCEDURE      SP_SFA_RORDER_CONFIRMLIST   
(
    in_SAWON_ID          IN  VARCHAR2,    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    /*---------------------------------------------------------------------------
    프로그램명   : 간납처 주문내역 관련자 확인용 리스트조회
    호출프로그램 : spROrderListConfirmPop1
    
         2015.05.13 CHOE 추가 변경 사항 간납처 주문내역 이 100건 이상인 경우 과거 자료 부터 보이도록 해 준다.과거 자료 부터 개인이 등록 처리를 하고 최근 날짜로 등록 하도록 한다.      
         2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
    ---------------------------------------------------------------------------*/    

    v_num         NUMBER;
    v_SILSAWON_ID VARCHAR2(7);
    
BEGIN 
         
 
    -- 로그인한 사원의 납품처에 납품된 제품중 거래처별단가테이블에서 담당제품으로 주문된것들.
    select COUNT(*)
      into v_num
      from ORAGMP.SLORDM a
          ,ORAGMP.SLORDD b
     where a.plantcode = b.plantcode
       and A.orderno   = b.orderno
       and a.plantcode = '1000'
       and a.custcode  <> a.ecustcode
       and a.orderdate >= to_char(ADD_MONTHS(SYSDATE, -3),'yyyy-mm-dd')
       and (a.empcode = in_SAWON_ID or a.eempcode =  in_SAWON_ID)
       and decode(a.empcode ,in_SAWON_ID,a.confirm_sawon_yn,a.confirm_rsawon_yn) = 'N' 
   ;
         
 
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
       
    ELSIF  v_num > 50 THEN  --CHOE 20150415 확인 하지 않은 간납처 내역이 너무 많은 경우 시스템이 다운되는 것을 막는다.
        /*out_CODE := 1;
        out_MSG := '간납처 주문 내역이 너무 많아 표시 할수 없습니다. 본사로 연락해 주시기 바랍니다.';*/
        out_CODE := 0;
        out_MSG := '검색 완료 1';
        
        
        OPEN out_RESULT FOR        
        select a.orderno                    AS out_GUMAE_NO
              ,replace(a.orderdate,'-','')  AS out_ORDER_DATE
              ,(select custname from ORAGMP.CMCUSTM where custcode = a.custcode)  AS out_CUST_NM
              ,(select custname from ORAGMP.CMCUSTM where custcode = a.ecustcode)  AS out_RCUST_NM
              ,(select itemname from ORAGMP.CMITEMM where itemcode = b.itemcode)  AS out_ITEM_NM
              ,b.salqty                     AS out_QTY
              ,b.salamt + b.salvat          AS out_AMOUNT
          from ORAGMP.SLORDM a
              ,ORAGMP.SLORDD b
          where a.plantcode = b.plantcode
           and A.orderno   = b.orderno
           and a.plantcode = '1000'
           and a.custcode  <> a.ecustcode
           and a.orderdate >= to_char(ADD_MONTHS(SYSDATE, -3),'yyyy-mm-dd')
           and (a.empcode = in_SAWON_ID or a.eempcode =  in_SAWON_ID)
           and decode(a.empcode ,in_SAWON_ID,a.confirm_sawon_yn,a.confirm_rsawon_yn) = 'N' 
           and ROWNUM < 100   
           order by a.orderno 
         ;                
    ELSE     
        out_CODE := 0;
        out_MSG := '검색 완료 2';    
    
        OPEN out_RESULT FOR        
        select a.orderno                    AS out_GUMAE_NO
              ,replace(a.orderdate,'-','')  AS out_ORDER_DATE
              ,(select custname from ORAGMP.CMCUSTM where custcode = a.custcode)  AS out_CUST_NM
              ,(select custname from ORAGMP.CMCUSTM where custcode = a.ecustcode)  AS out_RCUST_NM
              ,(select itemname from ORAGMP.CMITEMM where itemcode = b.itemcode)  AS out_ITEM_NM
              ,b.salqty                     AS out_QTY
              ,b.salamt + b.salvat          AS out_AMOUNT
          from ORAGMP.SLORDM a
              ,ORAGMP.SLORDD b
          where a.plantcode = b.plantcode
           and A.orderno   = b.orderno
           and a.plantcode = '1000'
           and a.custcode  <> a.ecustcode
           and a.orderdate >= to_char(ADD_MONTHS(SYSDATE, -3),'yyyy-mm-dd')
           and (a.empcode = in_SAWON_ID or a.eempcode =  in_SAWON_ID)
           and decode(a.empcode ,in_SAWON_ID,a.confirm_sawon_yn,a.confirm_rsawon_yn) = 'N' 
           order by a.orderno 
         ;        
           
       
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
