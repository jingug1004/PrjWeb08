CREATE PROCEDURE      SP_X_MEMBER_INSERTHISPASSWORD
(
    in_EMPCODE    IN VARCHAR2,
    in_NEWPASSWD  IN VARCHAR2,
    in_LASTEMPNO  IN VARCHAR2,
    in_LASTIP     IN VARCHAR2,
    in_SEQ        IN VARCHAR2,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_MEMBER_INSERTHISPASSWORD
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 패스워드 히스토리 프로시저이다.
-- ---------------------------------------------------------------
    MAX_SEQ    NUMBER;
BEGIN 
	
        SELECT NVL(MAX (SEQ), 0) + 1 INTO MAX_SEQ
          FROM HANACOMM.CO_US_PASSWORD_HISTORY
         WHERE EMP_NO = (SELECT A.INSA_SAWON_ID
                           FROM SALE.SALE0007 A, HANACOMM.CO_US_MEMBER_0 B
                          WHERE A.GUBUN = 'Y'
                            AND B.USE_YN = 'Y'
                            AND A.INSA_SAWON_ID = B.EMP_NO
                            AND A.SAWON_ID = in_EMPCODE);
        
        INSERT INTO HANACOMM.CO_US_PASSWORD_HISTORY VALUES
               (in_EMPCODE
               ,MAX_SEQ
               ,''
               ,in_NEWPASSWD
               ,''
               ,''
               ,in_LASTEMPNO
               ,''
               ,in_LASTIP
        );
        
    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 INSERT ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 저장';
        COMMIT;
	END IF; 
	
  
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;

END ;
/
