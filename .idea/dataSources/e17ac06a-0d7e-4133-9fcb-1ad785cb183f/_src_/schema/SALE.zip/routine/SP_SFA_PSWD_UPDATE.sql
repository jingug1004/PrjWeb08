CREATE PROCEDURE      SP_SFA_PSWD_UPDATE
(
    in_SAWON_ID          IN VARCHAR2, --영업사번 
    in_SAWON_PSWD_OLD    IN VARCHAR2,
    in_SAWON_PSWD_NEW    IN VARCHAR2,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2
)
IS
 
 /*---------------------------------------------------------------------------
 프로그램명  : 비밀번호변경
 호출프로그램 : 설정>비밀번호변경       
 ---------------------------------------------------------------------------
 프로그램설명 : in_SAWON_ID 이 영업사번이므로 인사사번을 찾아서
                HANACOM.CO_US_MEMBER_0 테이블에 PASS_WORD 컬럼을 수정한다.
 ---------------------------------------------------------------------------
 수정기록   : 2014.06.10 KTA - 비밀번호 변경규칙로직 및 통합비번로직  추가 
          2015.06.04 KTA - 비밀번호 암호화 처리
          2017.11.01  KTA - NEW ERP메 맞게 컨버전   
                                  
 ---------------------------------------------------------------------------*/    

    v_emp_no             VARCHAR2(20);
    v_sawon_pswd         VARCHAR2(20);
    v_retir_dt           VARCHAR2(8);

    v_cnt                NUMBER;
    v_out_code           NUMBER;
    v_out_msg            VARCHAR2(100);
    v_out_count          NUMBER;
    
BEGIN  
     
    v_emp_no := in_SAWON_ID;
    
    --kta 2015.06.02 비밀번호 암호화하여 저장된것 암호화하여 비교....
    v_cnt := 0;
    select count(*)  into v_cnt from ORAGMP.ELECTRONICSIGN where empcode = v_emp_no and pwd = hanacomm.hanacryptpass(in_SAWON_PSWD_OLD);    
    if v_cnt = 0 then
        out_CODE := 1;
        out_MSG := '현재 비밀번호가 틀립니다.';
        RETURN;
    end if;
        
    --현재비번과 새비번 같으면 안됨        
    IF in_SAWON_PSWD_OLD = in_SAWON_PSWD_NEW THEN
        out_CODE := 1;
        out_MSG := '현재 비밀번호와 새 비밀번호는 달라야 합니다.';
        RETURN;
    END IF;    
        
     --비밀번호변경규칙 프로시져---------------------------------------------------------------------------
    HANACOMM.SP_PASSWORD_VALIDATE(v_emp_no,in_SAWON_PSWD_NEW,v_out_code,v_out_msg,v_out_count); 
    IF v_out_code <> 0 THEN 
        out_CODE := v_out_code;
        out_MSG := v_out_msg;
        RETURN; 
    END IF; 

    --비밀번호통합 프로시져---------------------------------------------------------------------------
    HANACOMM.SP_PASSWORD_ACCORD(v_emp_no,in_SAWON_PSWD_NEW,v_out_code,v_out_msg,v_out_count); --세번째아규는 오라클계정임.  
    out_CODE := 0;
    out_MSG := '비밀번호 변경이 완료되었습니다.'; 
   

EXCEPTION  
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
