CREATE PROCEDURE      SP_SFA_ITEM_03
(
    in_ITEM_NM           IN  VARCHAR2,  
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 제품정보상세설명 
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_ITEMDOC
     WHERE ITEM_NAME LIKE '%'||NVL(in_ITEM_NM, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT ITEM_CODE              AS out_ITEM_ID        -- 제품코드
             , ITEM_NAME              AS out_ITEM_NM        -- 제품명
             , ITEM_POINT             AS out_POINT          -- 특장점
             , ITEM_EFFECT            AS out_EFFECT         -- 효능효과
             , ITEM_USE_DOES          AS out_ITEM_USE_DOES  -- 용량용법
             , ITEM_ATTENTION         AS out_ITEM_ATTENTION -- 주의사항
             , ITEM_PHOTO             AS out_PHOTO          -- 이미지
          FROM SFA_OFFICE_ITEMDOC
         WHERE ITEM_NAME LIKE '%'||NVL(in_ITEM_NM, '%')||'%'
         ORDER BY ITEM_NAME;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
