CREATE PROCEDURE      SP_X_APP_DANGAQTYAMTERR
(
    in_GUMAE_NO        IN VARCHAR2,
    out_AMT_ERRVALUE  OUT VARCHAR2,
    out_CODE          OUT NUMBER,
    out_MSG           OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_DANGAQTYAMTERR
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    SELECT a.item_id||' '||B.ITEM_NM INTO out_AMT_ERRVALUE
	      FROM (
				select a.item_id 
				  from sale0204 a,sale0203 b
				 where a.gumae_no = b.gumae_no 
				   and a.gumae_no = in_GUMAE_NO
				   and a.qty * a.danga <> a.amt
				   and b.cust_id like '11%'
				   and rownum = 1
				union     
				select  a.item_id 
				  from sale0204 a,sale0203 b
				 where a.gumae_no = b.gumae_no 
				   and a.gumae_no = in_GUMAE_NO
				   and a.qty * a.danga <> a.amt + a.vat
				   and substr(b.cust_id,1,1) in ('3','4')
				   and rownum = 1
              )	A, SALE.SALE0004 B
           WHERE A.ITEM_ID = B.ITEM_ID;
	
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
