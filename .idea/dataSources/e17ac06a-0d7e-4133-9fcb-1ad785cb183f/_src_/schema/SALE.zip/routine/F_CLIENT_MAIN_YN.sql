CREATE FUNCTION      F_CLIENT_MAIN_YN  -- 대표고객여부 가져오기
(
    in_CUST_CD    IN  NUMBER    -- 거래처
,   in_CLIENT_NO  IN  NUMBER  -- 고객
) 
RETURN VARCHAR2 IS

    v_main_yn   CHAR(1);
    v_num       NUMBER;
    
BEGIN

    SELECT COUNT(*)
      INTO v_num
        FROM SFA_SALES_CODE  A LEFT OUTER JOIN SFA_CUSTOMER    B
                                 ON A.SFA_SALES_NO = B.SFA_SALES_NO
                                AND A.SFA_CLIENT_NO = B.SFA_CLIENT_NO
                                AND NVL(A.DEL_YN,'N')  = 'N'
                                AND A.SFA_SALES_NO  = in_CUST_CD
                                AND A.SFA_CLIENT_NO = in_CLIENT_NO;
      
      IF v_num > 0 THEN   -- 대표고객
          v_main_yn := 'Y';
        RETURN v_main_yn;
    ELSE
        v_main_yn := 'N';
        RETURN v_main_yn;
    END IF;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;

/
