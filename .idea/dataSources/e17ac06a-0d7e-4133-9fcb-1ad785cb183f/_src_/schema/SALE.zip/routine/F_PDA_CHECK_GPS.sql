CREATE FUNCTION      f_pda_check_GPS (FROM_LAT NUMBER,FROM_LONG NUMBER,
TO_LAT NUMBER,TO_LONG NUMBER)
RETURN VARCHAR2 IS
    v_ret  VARCHAR2(250);
BEGIN

    select case when SALE.F_PDA_GPS_DISTANCE(FROM_LAT ,FROM_LONG ,TO_LAT ,TO_LONG) < 1000 
    then '적합' else '부적합' end
    into v_ret
    from dual;

    return  v_ret;

END;

/
