CREATE PROCEDURE      SP_X_MEMBER_GETLOGINFOR
(
    in_EMPCODE  IN VARCHAR2,
    out_RESULT  OUT TYPES.CURSOR_TYPE,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_MEMBER_GETLOGINFOR
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 로그인 관리 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    OPEN out_RESULT FOR
        SELECT EMP_CODE, SAWON_ID, EMP_NAME, DEPT_CODE, PASSWORD, EMP_GB, PART_GB, GRADE_NAME, DEPT_NAME, PART_NAME, DEPT_CD,
          ASSGN_CD,ASSGN_NAME
          FROM (
            SELECT OraEle.EMPCODE AS EMP_CODE, OraEle.ID AS SAWON_ID, OraEmp.EMPNAME AS EMP_NAME, OraEmp.DEPTCODE AS DEPT_CODE,
              OraEle.PWD AS PASSWORD, OraDep.DEPTDIV AS EMP_GB, OraEmp.WORKDIV AS PART_GB, '' AS GRADE_NAME,
              (SELECT ORAGMP.CMDEPTM.DEPTNAME FROM ORAGMP.CMDEPTM LEFT JOIN ORAGMP.CMEMPM
                  ON ORAGMP.CMDEPTM.DEPTCODE = ORAGMP.CMEMPM.DEPTCODE
              WHERE ORAGMP.CMEMPM.EMPCODE = in_EMPCODE) AS DEPT_NAME, '' AS PART_NAME, OraEmp.DEPTCODE AS DEPT_CD, '' AS ASSGN_CD, '' AS ASSGN_NAME
           FROM ORAGMP.CMDEPTM OraDep, ORAGMP.CMEMPM OraEmp, ORAGMP.ELECTRONICSIGN OraEle, ORAGMP.CMCUSTM OraCus
            WHERE OraEle.EMPCODE = OraEmp.EMPCODE
            AND OraEle.EMPCODE = in_EMPCODE
            AND OraEle.EXITYN = 'N')
        WHERE ROWNUM = 1;

EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);         
        
END ;
/
