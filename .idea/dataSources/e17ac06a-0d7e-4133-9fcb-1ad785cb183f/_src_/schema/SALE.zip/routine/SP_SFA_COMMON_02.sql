CREATE PROCEDURE      SP_SFA_COMMON_02
(
    in_GUBUN             IN  NUMBER,    -- 1:코드, 2:거래처명
    in_ITEM              IN  VARCHAR2,  -- 거래처 코드/명
    in_DEPT_CD           IN  VARCHAR2,  -- 부서코드
    in_SAWON_ID          IN  VARCHAR2,  -- 사원코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처 검색 팝업
 호출프로그램 : 
 수정기록     : 105 버전으로대체   
 ---------------------------------------------------------------------------*/    
 
    v_num                NUMBER;
    v_insa_sawon_id     VARCHAR2(7);
    v_insa_dept_cd      VARCHAR2(4);
    v_assgn_cd          VARCHAR2(5);
    
    GUBUN_NULL           EXCEPTION;
BEGIN

    
    IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
        RAISE GUBUN_NULL;
    END IF;    
     
    --로그인사원의 인사사번   
    select insa_sawon_id into v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID and gubun = 'Y';
    
    --로그인사원이 팀원인지,팀원이아닌 본부장,팀장인지 파악
    select assgn_cd into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    
    --본부장이면 한레벨 상위부서코드를 찾고 팀장이면 자기부서를 찾는다.
    if v_assgn_cd = '27010' then --본부장  부본부장
        select dept_cd
          into v_insa_dept_cd  
          from hr_co_depart_0 
         where use_yn = 'Y' and level = 2
       connect by dept_cd = prior up_dept_cd start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id);
                       
    elsif v_assgn_cd = '27030' then --팀장 선임지점장
        select dept_cd into v_insa_dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    end if;    
     
    SELECT COUNT(*)
      INTO v_num
      FROM (SELECT *
              FROM (SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE    
                     WHERE EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                          from sale0007 
                                         where insa_sawon_id in (
                                                                select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                 where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                    connect by prior dept_cd = up_dept_cd
                                                                                      start with dept_cd = v_insa_dept_cd
                                                                                  )
                                                                   and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                )
                                          and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                     )
                       AND DECODE(in_GUBUN, 1, TO_CHAR(SFA_SALES_NO), TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                    UNION
                     SELECT A.SFA_SALES_SEQ
                      FROM SFA_SALES_CODE_SAWON A
                          ,SFA_SALES_CODE B
                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                       AND A.EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                          from sale0007 
                                         where insa_sawon_id in (
                                                                select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                 where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                    connect by prior dept_cd = up_dept_cd
                                                                                      start with dept_cd = v_insa_dept_cd
                                                                                   )
                                                                   and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                )
                                          and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                     )
                       AND DECODE(in_GUBUN, 1, TO_CHAR(B.SFA_SALES_NO), B.TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                       AND A.REQ_GB  = '1'  --활동거래처
                       AND A.OK_STAT = '2'  --승인
                   )
             WHERE v_assgn_cd <> '27040' --팀원아니고 팀장 또는 본부장이면
            UNION ALL
            SELECT *
              FROM (SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE    
                     WHERE EMP_NO      = in_SAWON_ID
                       AND DECODE(in_GUBUN, 1, TO_CHAR(SFA_SALES_NO), TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                    UNION
                     SELECT A.SFA_SALES_SEQ
                      FROM SFA_SALES_CODE_SAWON A
                          ,SFA_SALES_CODE B
                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                       AND A.EMP_NO LIKE  NVL(in_SAWON_ID, '%')
                       AND DECODE(in_GUBUN, 1, TO_CHAR(B.SFA_SALES_NO), B.TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                       AND A.REQ_GB  = '1'  --활동거래처
                       AND A.OK_STAT = '2'  --승인
                   ) 
             WHERE v_assgn_cd = '27040' --팀원이면
          );
    
-- insert into SFA_SP_CALLED_HIST values ('SP_SFA_COMMON_02','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||' / v_num:'||to_char(v_num));
 
    out_COUNT := v_num;
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT SFA_SALES_NO                                   AS out_CUST_CD,    -- 거래처코드
               TRADE_NAME                                     AS out_CUST_NM,    -- 거래처명
               COMPANY_ADDR1||' '||BUNJI1                     AS out_ADDRESS,    -- 거래처 주소
               '['||F_SFA_CODE_NM('CUST_STAT_GB',CUST_STAT_GB)||'-'||SUBSTR(F_SFA_CUST_SAWON_NM(in_SAWON_ID,SFA_SALES_SEQ),2)||']'  AS out_MANAGER_NM  -- 거래처담당사원명 1인이상이면 외몇명
               --MANAGER_NAME  AS out_MANAGER_NM  -- 대표자명
          FROM SFA_SALES_CODE
         WHERE SFA_SALES_SEQ IN (   SELECT SFA_SALES_SEQ
                                      FROM (SELECT SFA_SALES_SEQ
                                              FROM SFA_SALES_CODE    
                                             WHERE EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                                                  from sale0007 
                                                                 where insa_sawon_id in (
                                                                                        select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                                         where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                                            connect by prior dept_cd = up_dept_cd
                                                                                                              start with dept_cd = v_insa_dept_cd)
                                                                                                                and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                                        )
                                                                  and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                                             )
                                               AND DECODE(in_GUBUN, 1, TO_CHAR(SFA_SALES_NO), TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                            UNION
                                             SELECT A.SFA_SALES_SEQ
                                              FROM SFA_SALES_CODE_SAWON A
                                                  ,SFA_SALES_CODE B
                                             WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                               AND A.EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                                                  from sale0007 
                                                                 where insa_sawon_id in (
                                                                                        select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                                         where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                                            connect by prior dept_cd = up_dept_cd
                                                                                                              start with dept_cd = v_insa_dept_cd)
                                                                                                                and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                                        )
                                                                  and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                                             )
                                               AND DECODE(in_GUBUN, 1, TO_CHAR(B.SFA_SALES_NO), B.TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                               AND A.REQ_GB  = '1'  --활동거래처
                                               AND A.OK_STAT = '2'  --승인
                                           )
                                     WHERE v_assgn_cd <> '27040' --팀원아니고 팀장 또는 본부장이면
                                    UNION ALL
                                    SELECT SFA_SALES_SEQ
                                      FROM (SELECT SFA_SALES_SEQ
                                              FROM SFA_SALES_CODE    
                                             WHERE EMP_NO      = in_SAWON_ID
                                               AND DECODE(in_GUBUN, 1, TO_CHAR(SFA_SALES_NO), TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                            UNION
                                             SELECT A.SFA_SALES_SEQ
                                              FROM SFA_SALES_CODE_SAWON A
                                                  ,SFA_SALES_CODE B
                                             WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                               AND A.EMP_NO LIKE  NVL(in_SAWON_ID, '%')
                                               AND DECODE(in_GUBUN, 1, TO_CHAR(B.SFA_SALES_NO), B.TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                               AND A.REQ_GB  = '1'  --활동거래처
                                               AND A.OK_STAT = '2'  --승인
                                           ) 
                                     WHERE v_assgn_cd = '27040' --팀원이면
                                 )
         ORDER BY  F_SFA_CUST_SAWON_NM(in_SAWON_ID,SFA_SALES_SEQ) ASC ,out_MANAGER_NM;
         
         
    END IF;
    
EXCEPTION
WHEN GUBUN_NULL THEN
   out_CODE := 101;
   out_MSG  := '검색 구분코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
