CREATE PROCEDURE      SP_X_INFO_UPDATEINSTITUTE
(
    in_HAKHEO_NM    IN VARCHAR2,
    in_DATEF        IN VARCHAR2,
    in_DATET        IN VARCHAR2,
    in_JIWI         IN VARCHAR2,
    in_GWANSIMDO    IN VARCHAR2,
    in_GITA         IN VARCHAR2,
    in_CUST_ID      IN VARCHAR2,
    in_CUSTOMER_ID  IN VARCHAR2,
    in_SEQ          IN VARCHAR2,
    out_CODE       OUT NUMBER,
    out_MSG        OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INFO_UPDATEINSTITUTE
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 소속학회 수정 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    	UPDATE SALE.CRM_HAKHEO
		   SET HAKHEO_NM   = in_HAKHEO_NM,
		       DATEF       = in_DATEF,
		       DATET       = in_DATET,
		       JIWI        = in_JIWI,
		       GWANSIMDO   = in_GWANSIMDO,
		       GITA        = in_GITA
		 WHERE CUST_ID     = in_CUST_ID
		   AND CUSTOMER_ID = in_CUSTOMER_ID
		   AND SEQ         = in_SEQ;
	
 IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 UPDATE ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 수정';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;
	 
END ;
/
