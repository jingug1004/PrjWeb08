CREATE PROCEDURE P_GET_MAX_SEQ
              ( ai_seq_gb1   IN     VARCHAR2,
                ai_seq_gb2   IN     VARCHAR2,
                ao_seq       IN OUT NUMBER )
IS
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ******************************************************************************* */
/*   TITLE        :  자동으로 순번 정하기                                           */
/*   PROJECT      :  하나제약 원부자재관리                                          */
/*   AUTHOR       :  이 원 선                                                      */
/*   PROGRAM_ID   :  P_GET_MAX_SEQ                                                    */
/*   HISTORY      :  2001.12.12(수)                                                */
/*   PROCESS      :  1. 코드 중 일련번호로 관리할 경우 BAS0201 테이블에 MAX 값을     */
/*                      관리함. (동시 입력시 PK DUPLICATE 때문)                     */
/*                   예) ai_seq_gb1 = INV_SLIP_NO                                  */
/*                       ai_seq_gb2 = 20011212                                     */
/* ******************************************************************************* */
   v_count  number ;
   v_seq    number := 0 ;
BEGIN
   
   SELECT count(*), nvl(max(seq), 0) + 1
     INTO v_count, v_seq
     FROM BAS0201 -- 채번 테이블
    WHERE seq_gb1 = LOWER(ai_seq_gb1)
      AND seq_gb2 = ai_seq_gb2 
      AND rownum < 2 ;

   IF v_count > 0 THEN 
      UPDATE BAS0201
         SET seq = v_seq
       WHERE seq_gb1 = LOWER(ai_seq_gb1)
         AND seq_gb2 = ai_seq_gb2 ;
   ELSE
      INSERT INTO BAS0201 (seq_gb1, seq_gb2, seq, bigo)
                  VALUES  (LOWER(ai_seq_gb1), ai_seq_gb2, v_seq, ai_seq_gb1||' '||ai_seq_gb2) ;
   END IF ;
   
   ao_seq := v_seq ;
   COMMIT;
   
   EXCEPTION
      WHEN OTHERS THEN
         ao_seq := -1 ;
         ROLLBACK;
         RAISE_APPLICATION_ERROR(-20099, substrb('오류!'||SQLCODE||'/'||SQLERRM,1,250)) ;
END P_GET_MAX_SEQ;



/
