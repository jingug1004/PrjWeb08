CREATE FUNCTION      F_GET_STOP_CUST_YN 
(
    in_CUST_ID  IN  VARCHAR2
) 
RETURN VARCHAR2 IS
 /*---------------------------------------------------------------------------
 프로그램내용 :ERP거래처 테이블에서 중지된 거래처인지 Y/N 로 RETURN
 호출프로그램 :SP_SFA_CUST_01_105 
 ---------------------------------------------------------------------------*/    


    v_RETURN   VARCHAR2(1);
    
BEGIN
    
    SELECT USE_YN
      INTO v_RETURN
      FROM SALE0003
     WHERE CUST_ID = in_CUST_ID;
    
        
    RETURN v_RETURN;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;

/
