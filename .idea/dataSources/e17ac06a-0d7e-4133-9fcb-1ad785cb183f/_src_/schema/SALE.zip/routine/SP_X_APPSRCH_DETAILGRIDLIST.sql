CREATE PROCEDURE      SP_X_APPSRCH_DETAILGRIDLIST
(
    in_GUMAE_NO   IN VARCHAR2,
    in_YMD        IN VARCHAR2,
    in_SIDX       IN VARCHAR2,
    in_SORD       IN VARCHAR2,
    out_RESULT   OUT TYPES.CURSOR_TYPE,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APPSRCH_DETAILGRIDLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  주문/승인 조회 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	  OPEN out_RESULT FOR
		SELECT   A.GUMAE_NO     GUMAE_NO,
			         A.ITEM_ID      ITEM_ID,
			         B.ITEM_NM      ITEM_NM,
					 A.REQ_QTY      REQ_QTY,
					 A.QTY          QTY,   
			         A.DANGA        DANGA,   
			         A.AMT          AMT,   
			         A.VAT          VAT,
			         A.AMT + A.VAT  TOT_AMT,   
			         A.RATE         RATE,   
			         A.DC_DANGA     DC_DANGA,
			         A.DC_AMT       DC_AMT,
			         A.DC_QTY       DC_QTY,   
			         B.STANDARD     STANDARD,
			         B.UNIT         UNIT,
			         NVL2(B.COLOR,'R','B')        COLOR
			    FROM SALE_ON.SALE0204 A, 
			         SALE.SALE0004 B
			   WHERE A.ITEM_ID     = B.ITEM_ID
			     AND A.GUMAE_NO    = in_GUMAE_NO
			     AND A.YMD         = in_YMD
		ORDER BY in_SIDX||' '||in_SORD;
						
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
