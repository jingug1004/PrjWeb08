CREATE PROCEDURE      SP_X_APPSRCH_APPROVALGRIDLIST
(
    in_FR_DATETIME   IN VARCHAR2,
    in_TO_DATETIME   IN VARCHAR2,
    in_FR_DATE       IN VARCHAR2,
    in_TO_DATE       IN VARCHAR2,
    in_CUST_ID       IN VARCHAR2,
    in_LIMIT_YN      IN VARCHAR2,
    in_AVG_MONTH     IN VARCHAR2,
    in_RECEIPT_GB    IN VARCHAR2,
    in_PSB_GB        IN VARCHAR2,
    in_SLIP_GB       IN VARCHAR2,
    in_WIBAN_KIND    IN VARCHAR2,
    in_PRE_DEPOSIT   IN VARCHAR2,
    in_SEARCHTYPE    IN VARCHAR2,
    in_PART_GB       IN VARCHAR2,
    in_SIDX          IN VARCHAR2,
    in_SORD          IN VARCHAR2,
    out_RESULT       OUT TYPES.CURSOR_TYPE,
    out_CODE         OUT NUMBER,
    out_MSG          OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APPSRCH_APPROVALGRIDLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  주문승인 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
	    SELECT COUNT(*) OVER() as TOTAL_CNT,
								   '' TCHK,
							       '' CHK,
							       A.CUST_ID, 
							       A.RCUST_ID, 
							       B.CUST_NM CUST_NM, 
							       C.CUST_NM RCUST_NM, 
							       A.GUMAE_NO,
							       TO_CHAR(A.YMD, 'YYYY-MM-DD') YMD, 
							       A.INPUT_YMD AS REQ_TIME, 
							       A.GUMAE_NOT AS APP_NO, 
							       A.BIGO, 
							       A.PBIGO, 
							       A.RECEIPT_GB,
							       A.SLIP_GB, 
							       A.WIBAN_ORDER_REQ_YN, 
							       A.WIBAN_ORDER_CONF_YN,
							       A.WIBAN_KIND, 
							       D.PSB_QTY,
							       D.PART_GB,
							       SALE.F_RATE_DAY_BEFOREMONTH(to_char(add_months(sysdate,-1),'yyyymm'),A.CUST_ID) AS rate_day,
							       (select SALE.F_GET_NAME('SALE0007',SAWON_ID,'') from SALE.sale0003 where cust_id = a.cust_id) AS  SAWON_NM,
							       SALE.F_DEPT_NM2(A.SAWON_ID) AS  DEPT_NM,
							       (SELECT SUM(BEFORE_AMT) + SUM(MISU_AMT) - SUM(SU_AMT)  FROM SALE.SALE0306 WHERE YMD  = TO_DATE(TO_CHAR(A.YMD,'YYYY/MM')||'/01','YYYY/MM/DD') AND CUST_ID = A.CUST_ID GROUP BY CUST_ID)  AS  CUR_AMT,
							       TO_CHAR(A.YMDT, 'YYYY-MM-DD') YMDT,
							       TO_CHAR(TO_DATE(A.ADATE, 'YYYYMMDDHH24MISS'), 'YYYY-MM-DD HH24:MI:SS') ADATE,
							       E.CODE1_NM rcust_gb1,
							       SALE.F_GET_NAME('SALE0007',ASAWON_ID,'') AS ASAWON_NM,
							       SALE_ON.f_getDangaQtyAmtErrJumun(a.gumae_no,'') AS ERROR_GB
							  FROM SALE_ON.SALE0203 A, SALE.SALE0003 B, SALE.SALE0003 C, SALE.SALE0001 E,
							       (  SELECT *
							            FROM (
									          SELECT A.GUMAE_NO,
									                 MIN(C.PSB_QTY) PSB_QTY,
									                 TO_CHAR(SIGN(SUM(decode(A.PART_GB,'01',0,1)))) AS PART_GB
									            FROM (            
									                   SELECT A.GUMAE_NO,
									                          A.CUST_ID,
									                          B.ITEM_ID,
									                          SALE.F_GET_PART_01(A.CUST_ID,A.RCUST_ID,B.ITEM_ID) AS PART_GB
									                     FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
									                    WHERE A.GUMAE_NO   = B.GUMAE_NO
									                      AND A.RECEIPT_GB IN (in_RECEIPT_GB)
									                      AND (in_SEARCHTYPE = 'order'
									                            AND TO_CHAR(A.INPUT_YMD, 'YYYYMMDDHH24MI') BETWEEN in_FR_DATETIME AND in_TO_DATETIME
									                      		AND A.YMD BETWEEN TO_DATE(in_FR_DATE) AND TO_DATE(in_TO_DATE)) -- 주문일
														  AND (in_SEARCHTYPE = 'approval'
                                              		   		AND A.ADATE BETWEEN in_FR_DATETIME||'00' AND in_TO_DATETIME||'59') -- 승인일 
												          AND A.CUST_ID    LIKE '%'||in_CUST_ID||'%'
									                      AND A.SLIP_GB    = in_SLIP_GB
									                      AND NVL(A.LIMIT_YN,'N')    IN (in_LIMIT_YN)
									                 ) A,
									                 (
									                    SELECT A.CUST_ID, E.ITEM_ID,
									                           ROUND(A.QTY * E.JLIMIT)                                   MAVG_QTY,
									                           NVL(C.MQTY,0) + NVL(D.MQTY,0)                             MQTY,
									                           ROUND(A.QTY * E.JLIMIT) - (NVL(C.MQTY,0) + NVL(D.MQTY,0)) PSB_QTY
									                      FROM (
									                            SELECT /*+ USE_NL(A B C)*/ A.CUST_ID, B.ITEM_ID, (C.JUMUN_LIMIT /100) JLIMIT
									                              FROM SALE.SALE0203 A, SALE.SALE0204 B, SALE.SALE0003 C
									                             WHERE A.YMD      < TO_DATE(in_AVG_MONTH||'01') 
									                               AND A.YMD      >= ADD_MONTHS(TO_DATE(in_AVG_MONTH||'01') ,-3)
									                               AND A.GUMAE_NO = B.GUMAE_NO 
									                               AND A.CUST_ID  = C.CUST_ID(+)
									                               AND A.CUST_ID    LIKE '%'||in_CUST_ID||'%'
									                            UNION
									                            SELECT /*+ USE_NL(A B C)*/ A.CUST_ID, B.ITEM_ID, (C.JUMUN_LIMIT /100) JLIMIT
									                              FROM SALE.SALE0203 A, SALE.SALE0204 B, SALE.SALE0003 C
									                             WHERE A.YMD      >= TO_DATE(in_AVG_MONTH||'01')  
									                               AND A.YMD      <= LAST_DAY(in_AVG_MONTH||'01') 
									                               AND A.GUMAE_NO = B.GUMAE_NO 
									                               AND A.CUST_ID  = C.CUST_ID(+)
									                               AND A.CUST_ID    LIKE '%'||in_CUST_ID||'%'
									                            UNION
									                            SELECT A.CUST_ID, B.ITEM_ID, (C.JUMUN_LIMIT /100) JLIMIT
									                              FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B, SALE.SALE0003 C
									                             WHERE A.YMD      >= TO_DATE(in_AVG_MONTH||'01')  
									                               AND A.YMD      <= LAST_DAY(in_AVG_MONTH||'01') 
									                               AND A.GUMAE_NO = B.GUMAE_NO 
									                               AND A.RECEIPT_GB IN (in_RECEIPT_GB)
									                               AND A.CUST_ID  = C.CUST_ID(+)
									                               AND A.CUST_ID    LIKE '%'||in_CUST_ID||'%'
									                           ) E,
									                           (
									                            SELECT /*+ USE_NL(A B)*/ A.CUST_ID, B.ITEM_ID,
									                                   ROUND((NVL(SUM(B.QTY),0)/3)) QTY
									                              FROM SALE.SALE0203 A, SALE.SALE0204 B
									                             WHERE A.YMD      < TO_DATE(in_AVG_MONTH||'01') 
									                               AND A.YMD      >= ADD_MONTHS(TO_DATE(in_AVG_MONTH||'01') ,-3)
									                               AND A.GUMAE_NO = B.GUMAE_NO 
									                               AND A.CUST_ID    LIKE '%'||in_CUST_ID||'%'
									                             GROUP BY A.CUST_ID, B.ITEM_ID
									                           ) A,
									                           (
									                            SELECT A.CUST_ID, B.ITEM_ID,
									                                   NVL(SUM(B.QTY),0) MQTY
									                              FROM SALE.SALE0203 A, SALE.SALE0204 B
									                             WHERE A.YMD      >= TO_DATE(in_AVG_MONTH||'01')  
									                               AND A.YMD      <= LAST_DAY(in_AVG_MONTH||'01') 
									                               AND A.GUMAE_NO = B.GUMAE_NO 
									                               AND A.CUST_ID    LIKE '%'||in_CUST_ID||'%'
									                             GROUP BY A.CUST_ID, B.ITEM_ID
									                           ) C,
									                           (
									                            SELECT A.CUST_ID, B.ITEM_ID,
									                                   NVL(SUM(B.QTY),0) MQTY
									                              FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
									                             WHERE A.YMD      >= TO_DATE(in_AVG_MONTH||'01')  
									                               AND A.YMD      <= LAST_DAY(in_AVG_MONTH||'01') 
									                               AND A.GUMAE_NO = B.GUMAE_NO 
									                               AND A.RECEIPT_GB IN (in_RECEIPT_GB)
									                               AND A.CUST_ID    LIKE '%'||in_CUST_ID||'%'
									                             GROUP BY A.CUST_ID, B.ITEM_ID
									                           ) D
									                     WHERE E.CUST_ID = A.CUST_ID(+)
									                       AND E.ITEM_ID = A.ITEM_ID(+)
									                       AND E.CUST_ID = C.CUST_ID(+)
									                       AND E.ITEM_ID = C.ITEM_ID(+)
									                       AND E.CUST_ID = D.CUST_ID(+)
									                       AND E.ITEM_ID = D.ITEM_ID(+)                                
									                 ) C
									           WHERE A.CUST_ID  = C.CUST_ID(+)
									             AND A.ITEM_ID  = C.ITEM_ID(+)             
									           GROUP BY A.GUMAE_NO           
									       )
							         WHERE SIGN(NVL(PSB_QTY,0)) IN (DECODE(in_PSB_GB,'0', 0,'1',0,'2',-1),
							                                        DECODE(in_PSB_GB,'0', 1,'1',1),
							                                        DECODE(in_PSB_GB,'0',-1))
							    
							       ) D 
							 WHERE A.CUST_ID              = B.CUST_ID
							   AND A.RCUST_ID             = C.CUST_ID
							   AND A.RECEIPT_GB           IN (in_RECEIPT_GB)
							   AND (in_SEARCHTYPE = 'order'  
		                       		AND TO_CHAR(A.INPUT_YMD, 'YYYYMMDDHH24MI') BETWEEN in_FR_DATETIME AND in_TO_DATETIME
		                      		AND A.YMD BETWEEN TO_DATE(in_FR_DATE) AND TO_DATE(in_TO_DATE) ) -- 주문일
							   AND (in_SEARCHTYPE = 'approval' 		
							        AND A.ADATE BETWEEN in_FR_DATETIME||'00' AND in_TO_DATETIME||'59') -- 승인일 
							   AND A.CUST_ID              LIKE '%'||in_CUST_ID||'%'
							   AND A.SLIP_GB              = in_SLIP_GB
							   AND NVL(A.LIMIT_YN,'N')    IN (in_LIMIT_YN)
							   AND A.WIBAN_KIND  LIKE in_WIBAN_KIND
							   AND DECODE(A.WIBAN_ORDER_REQ_YN,'Y',A.WIBAN_ORDER_CONF_YN,'9') IN DECODE(A.WIBAN_ORDER_REQ_YN,'Y','1','9')
							   AND B.PRE_DEPOSIT LIKE in_PRE_DEPOSIT
							   AND A.GUMAE_NO             = D.GUMAE_NO(+)
							   AND (in_PART_GB = '1' AND C.CUST_GB1 = '05') -- 약국분
							   AND (in_PART_GB = '0' AND C.CUST_GB1 != '05') -- 일반
							   AND C.CUST_GB1 = E.CODE1
							   AND E.CODE_GB = '0020'
						ORDER BY in_SIDX||' '||in_SORD;

    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
