CREATE PROCEDURE      SP_SFA_OFFICE_10_ACCOUNT
(
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 정산관리-계정과목조회
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM (SELECT GAEJUNG_CD,GAEJUNG_NM,'식당,술집'                              AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%복리후생비%'  UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'주유소,차수리,교통카드충전,하이패스'    AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%차량유지비%'  UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'교통비(버스,기차,비행기),숙박비,주차비' AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%여비교통비%'  UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'가전제품매장,철물점 등'                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%소모품비%'    UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'회의비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%회의비%'      UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'교육훈련비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%교육훈련비%'  UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'도서인쇄비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%도서인쇄비%'  UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'운반비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%운반비%'      UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'철도청,반환수수료'                      AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%지급수수료%'  UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'지급수수료'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%집기비품%'    UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'판매촉진비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%판매촉진비%'  UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'통신비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%통신비%'      UNION ALL
            SELECT GAEJUNG_CD,GAEJUNG_NM,'광고선전비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%광고선전비%'
            )                A,            
            ACCOUNT.FACA03C  B
      WHERE B.GAEJUNG_CD = A.GAEJUNG_CD
        AND B.JUNPYO_YN = 'Y'
        AND B.SAYONG_YN = 'Y'
        AND B.GAEJUNG_CD IN ('81050AA','81110AB','81230AA','81060AA','81170AA','81050AA','81210AA');
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
     
        OPEN out_RESULT FOR
        SELECT A.GAEJUNG_CD                                                                               AS out_GAEJUNG_CD           -- 계정과목
             , A.GAEJUNG_NM                                                                               AS out_GAEJUNG_NM           -- 사용과목명
             , A.BIGO                                                                                     AS out_BIGO                 -- 비고
          FROM (SELECT GAEJUNG_CD,GAEJUNG_NM,'식당,술집'                              AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%복리후생비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'주유소,차수리,교통카드충전,하이패스'    AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%차량유지비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'교통비(버스,기차,비행기),숙박비,주차비' AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%여비교통비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'가전제품매장,철물점 등'                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%소모품비%'    UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'회의비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%회의비%'      UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'교육훈련비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%교육훈련비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'도서인쇄비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%도서인쇄비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'운반비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%운반비%'      UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'철도청,반환수수료'                      AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%지급수수료%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'지급수수료'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%집기비품%'    UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'판매촉진비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%판매촉진비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'통신비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%통신비%'      UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'광고선전비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%광고선전비%'
                )                A,            
                ACCOUNT.FACA03C  B
          WHERE B.GAEJUNG_CD = A.GAEJUNG_CD
            AND B.JUNPYO_YN = 'Y'
            AND B.SAYONG_YN = 'Y'
            AND B.GAEJUNG_CD IN ('81050AA','81110AB','81230AA','81060AA','81170AA','81050AA','81210AA');
        
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
