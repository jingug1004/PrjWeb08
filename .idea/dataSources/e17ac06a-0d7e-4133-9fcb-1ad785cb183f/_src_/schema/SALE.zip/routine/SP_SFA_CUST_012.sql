CREATE PROCEDURE      SP_SFA_CUST_012
(
    in_SAWON_ID          IN  VARCHAR2,    -- 사원 ID
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 거래요청결과 조회
 호출프로그램 :거래처>거래처요청결과         
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼     
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
    SAWON_ID_NULL        EXCEPTION;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_04_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SFA_SALES_SEQ,sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN||'/in_CLIENT_NO '||in_CLIENT_NO );
--commit; 
    
    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
        RAISE SAWON_ID_NULL;
    END IF;
    
    
    SELECT COUNT(*)
      INTO v_num
      FROM SALE.SFA_HIRA_CODE_SAWON a
          ,ORAGMP.CMHIRAM b
     WHERE a.hiracode  = b.hiracode
       AND a.emp_no    = in_SAWON_ID
    ;

    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT a.hiracode                              AS out_CUST_KEY 
             , b.hiraname                              AS out_CUST_NM   
             , decode(a.req_gb,'1','활동','주문')         AS out_REQ_GB 
             , a.req_dt                                AS out_REQ_DT                 
             , case 
                when (a.ok_stat = '1')    then '대기' 
                when (a.ok_stat = '2')    then '승인' 
                when (a.ok_stat = '3')    then '불가' 
                else '' end                             AS out_OK_STAT
             , a.ok_dt                                  AS out_OK_DT     
             , a.no_reason                              AS out_NO_REASON                  
          FROM SALE.SFA_HIRA_CODE_SAWON a
              ,ORAGMP.CMHIRAM b
          WHERE a.hiracode  = b.hiracode
            AND a.emp_no    = in_SAWON_ID
       ORDER BY a.req_dt DESC;
    END IF;
    
EXCEPTION
WHEN SAWON_ID_NULL THEN
   out_CODE := 102;
   out_MSG  := '사원 ID가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
