CREATE TRIGGER TB_PRD00032_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON PRD00032
FOR EACH ROW
  DECLARE
     T_UPDATE_CHK   NUMBER;
	 V_USER_ID      VARCHAR2(10);
	 V_YMD          VARCHAR2(8);
	 V_ll_slip_no   NUMBER;
	 V_lS_slip_no   VARCHAR2(3);
	 V_JUNPYOGB_CD  VARCHAR2(3);
	 VS_SEQ         VARCHAR2(3);
BEGIN

   /* ---------------------------------------------------------------------------- */
   /* 수정 되었을 경우                                                             */
   /* 원부자재출고테이블(INV0301,INV0302) 테이블에 수량을 INSERT OR UPDATE         */
   /* 처리한다.                                                                    */
   /* ---------------------------------------------------------------------------- */
   IF UPDATING('CON_QTY') THEN
      IF :OLD.YMD IS NULL THEN --INSERT
	     --전표일자
	     SELECT TO_CHAR(WORK_DTF,'YYYYMMDD'), NVL(USER_ID,'ADMIN2'), NVL(JUNPYOGB_CD,'112')
		   INTO V_YMD, V_USER_ID, V_JUNPYOGB_CD
		   FROM PRD0003
		  WHERE PROD_SEQ = :OLD.PROD_SEQ
		    AND WSEQ      = :OLD.WSEQ
		    AND PROCESS_CD = :OLD.PROCESS_CD;

	      --이전 출고일자,출고번호을 찾는다.
		  BEGIN
			  SELECT SLIP_NO
			    INTO V_lS_slip_no
			    FROM INV0301
			   WHERE YMD         = V_YMD
			     AND JUNPYOGB_CD = V_JUNPYOGB_CD
				 AND PROD_SEQ    = :OLD.PROD_SEQ
				 AND PROCESS_CD  = :OLD.PROCESS_CD
				 AND SAWON_ID    = V_USER_ID;

			   EXCEPTION
	                WHEN OTHERS THEN
				         V_lS_slip_no := NULL;
	            --       RAISE_APPLICATION_ERROR( -20001, 'XXXXX' ) ;
		  END;

		  IF V_lS_slip_no IS NULL THEN --INSERT
			 --전표번호
		     BEGIN
			   select SEQ + 1
			     into V_ll_slip_no
			     from bas0201
			    where SEQ_GB1 = 'inv_slip_no'
			      AND SEQ_GB2 = V_YMD ;
			   EXCEPTION
	                WHEN OTHERS THEN
				         V_ll_slip_no := NULL;
	            --       RAISE_APPLICATION_ERROR( -20001, 'XXXXX' ) ;
		     END;

			 IF V_ll_slip_no IS NULL THEN
			    V_lS_slip_no := '001';
		        INSERT INTO BAS0201 (SEQ_GB1, SEQ_GB2, SEQ, BIGO)
		 		             VALUES ('inv_slip_no',V_YMD,1,'원/부자재입출고');
			 ELSE
			    V_lS_slip_no := trim(TO_CHAR(V_ll_slip_no,'000'));
				UPDATE BAS0201 SET SEQ = V_ll_slip_no
				             WHERE SEQ_GB1 = 'inv_slip_no'
	 		                   AND SEQ_GB2 = V_YMD ;
			 END IF;
			 VS_SEQ := '001';

		     --원부자재출고 테이블
		     INSERT INTO INV0301(YMD, SLIP_NO, JUNPYOGB_CD, PROD_SEQ, PROCESS_CD, SAWON_ID, STORE_LOC, BIGO)
			             VALUES (V_YMD,V_lS_slip_no, V_JUNPYOGB_CD, :OLD.PROD_SEQ, :OLD.PROCESS_CD, V_USER_ID, '01', '칭량실적' );
		  ELSE
		     SELECT TRIM(TO_CHAR(TO_NUMBER(MAX(SEQ)) + 1,'000'))
			   INTO VS_SEQ
			   FROM INV0302
			  WHERE YMD = V_YMD
			    AND SLIP_NO = V_lS_slip_no ;
		  END IF;

	     --원부자재출고 테이블

	     INSERT INTO INV0302(YMD, SLIP_NO, SEQ, JUNPYOGB_CD, MATERIAL_ID, QTY)
		             VALUES (V_YMD,V_lS_slip_no, VS_SEQ, V_JUNPYOGB_CD, :OLD.MATRIAL_CD, :NEW.CON_QTY );

	     :NEW.YMD     := V_YMD;
	     :NEW.SLIP_NO := V_lS_slip_no;
	     :NEW.SEQ     := VS_SEQ;

	  ELSE --UPDATE
	      UPDATE INV0302 SET QTY = :NEW.CON_QTY
		               WHERE YMD     = :OLD.YMD
					     AND SLIP_NO = :OLD.SLIP_NO
						 AND SEQ     = :OLD.SEQ;

      END IF;

--      RAISE_APPLICATION_ERROR( -20001, :NEW.MATRIAL_CD||','||:OLD.MATRIAL_CD||','||:NEW.CON_QTY||','||:OLD.CON_QTY||'--'||'TRIGGER TEST' ) ;

   END IF;

END TB_SALE0003_IUD;
/
