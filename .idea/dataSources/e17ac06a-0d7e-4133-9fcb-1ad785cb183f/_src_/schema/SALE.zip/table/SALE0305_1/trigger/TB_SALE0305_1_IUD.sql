CREATE TRIGGER TB_SALE0305_1_IUD
AFTER INSERT OR UPDATE OR DELETE
  ON SALE0305_1
FOR EACH ROW
  DECLARE  T_MSG        VARCHAR2(100) ;  
         V_CNT        NUMBER;
BEGIN
   /* ------------------------------------------------------------------------ */
   /* 수정 되었을 경우                                                         */
   /* ------------------------------------------------------------------------ */
   IF UPDATING('ipgo_qtys')   OR 
      UPDATING('banpum_qtys') OR
      UPDATING('chulgo_qtys') THEN 
      
      IF NVL(:NEW.ipgo_qtys,0) + NVL(:NEW.banpum_qtys,0) - NVL(:NEW.chulgo_qtys,0) = 0 THEN
         
         SELECT COUNT(*)
           INTO V_CNT
           FROM SALE0305_2
          WHERE store_loc  = :NEW.store_loc
            AND item_id    = :NEW.item_id
            AND prod_no    = :NEW.prod_no;
         --이미 존재하면 SKIP :: 잠시동안만 이렇게 처리함 김태안    
         IF V_CNT = 0 THEN
         
              BEGIN 
              --재고현황_제조번호별 소진일 -kta-  
              INSERT INTO SALE0305_2(STORE_LOC    ,ITEM_ID     ,PROD_NO, ZERO_YMD  )
                             VALUES (:NEW.store_loc,:NEW.item_id,:NEW.prod_no,:NEW.deal_ymd ) ;          
              
              EXCEPTION WHEN OTHERS THEN raise_application_error( -20001, sqlerrm ) ;
              END;    
         END IF;
           
      ELSE
           BEGIN 
             DELETE SALE0305_2 --재고현황_제조번호별 소진일 -kta- 
              WHERE store_loc  = :NEW.store_loc
                AND item_id    = :NEW.item_id
                AND prod_no    = :NEW.prod_no;
            
           EXCEPTION WHEN OTHERS THEN raise_application_error( -20001, sqlerrm ) ;
           END;    
           
      END IF;            
      
      
   END IF;

END TB_SALE0305_1_IUD;
/
