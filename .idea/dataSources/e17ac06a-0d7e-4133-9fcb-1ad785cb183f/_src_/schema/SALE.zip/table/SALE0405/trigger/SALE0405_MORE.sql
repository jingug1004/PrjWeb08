CREATE TRIGGER SALE0405_MORE
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0405
FOR EACH ROW
  DECLARE 메시지        varchar2(1000) ;
        T_CNT_CHK     NUMBER;
        T_TRAN_YMD_CD varchar2(14) ;
        T_temp number;
        T_BEF_YMD     varchar2(8) ;
        T_TMP_YMD     DATE ;
        
BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      메시지 := '매출처별단가관리(SALE0405H) 추가 불가 !!  ' ;
   ELSIF UPDATING THEN
      메시지 := '매출처별단가관리(SALE0405H) 수정 불가 !!  ' ;
   ELSE
      메시지 := '매출처별단가관리(SALE0405H) 삭제 불가 !!  ' ;
   END IF ;

   /*--------------------------------------------------------------------------------
    수정이력
    2013.07.17  CHOE 
        다음 개발에는 반드시 적은 내용을 확인하길 바랍니다.
        INSERTING  -  :NEW.INPUT_SEQ ex) cust_id = '4410324' and rcust_id = '4410324' and item_id = '43218' : INPUT_SEQ 값이 모두 같음                
        따라서 UPADTING이 일어날때 WHERE 조건이 같은 4~5개의 DATA가 동시에 INPUT_USERID (변경한사람), INPUT_DATE(변경한날짜) 모두 바뀐다.        
        INSERTING 최초의 값이 SEQ 번호를 갖도록 수정하는 것이 맞지만 이미 사용되고 있는 DATA가 너무 많기 때문에  UPDATING 할때 T_TRAN_YMD_CD의 조건을 추가하여 마지막 DATA만 UPDATE  되도록 수정하였다.
    2017.02.21 kta   
       1. 수정막음 : 파워빌더에서 datawindow 의 update 속성을 delete 후 insert 로 설정했기때문에 updating 은 발생하지 않음
       2. 마지막이력을 찾을때  조건제거함   AND YMD       >= TO_DATE(SYSDATE)    
       3. 이력insert 믄의 ymd 가 적용일자보다 작으면 적용일자를 셋팅하도록 하였음 DECODE( SIGN( TO_DATE(TO_CHAR(SYSDATE, 'YYYYMM')||'01','YYYYMMDD') - :NEW.YMD), -1 ,:NEW.YMD, TO_CHAR(SYSDATE, 'YYYYMM')||'01')
       4. ymd_org 컬럼을 추가하여 원래 ymd 가 무엇이었는지 알수 있도록 하였음. 
   -------------------------------------------------------------------------*/  
   
   
   /* ********************************************************************* */
   /* 수정될때     수정막음 : 파워빌더에서 datawindow 의 update 속성을 delete 후 insert 로 설정했기때문에 updating 은 발생하지 않음 */
   /* ********************************************************************* 
   IF UPDATING('RCUST_ID') OR
      UPDATING('ITEM_ID')  THEN
      BEGIN 
            SELECT MAX(TRAN_YMD_CD)
              INTO T_TRAN_YMD_CD
              FROM SALE0405H
             WHERE CUST_ID  = :OLD.CUST_ID
               AND RCUST_ID = :OLD.RCUST_ID
               AND ITEM_ID  = :OLD.ITEM_ID;  
      
            UPDATE SALE0405H
               SET RCUST_ID     = :NEW.RCUST_ID,
                   ITEM_ID      = :NEW.ITEM_ID,
                   INPUT_USERID = :NEW.INPUT_USERID, 
                   INPUT_DATE   = :NEW.INPUT_DATE    
                   ,ymd_org = sysdate + 100
             WHERE CUST_ID     = :OLD.CUST_ID
               AND RCUST_ID    = :OLD.RCUST_ID
               AND INPUT_SEQ   = :OLD.INPUT_SEQ
               AND TRAN_YMD_CD = T_TRAN_YMD_CD;    
            EXCEPTION
                 WHEN OTHERS THEN
                     raise_application_error( -20671, 메시지 ||
                          '매출처별단가이력관리(SALE0405H),제품 수정시 ERROR 발생.' ) ;
            END ;
    
   END IF ;
   ********************************************************************* */
   
   
   /* ********************************************************************* */
   /* 추가될때                                                              */
   /* ********************************************************************* */
   IF INSERTING            OR
      UPDATING('BAS_AMT')  OR
      UPDATING('BAL_AMT')  OR
      UPDATING('YAK_AMT')  OR
      UPDATING('AMT_YUL')  OR
      UPDATING('QTY_YUL')  OR
      UPDATING('YMD')      OR
      UPDATING('C')        OR
      UPDATING('GC')       OR
      UPDATING('ETC')      OR
      UPDATING('BIGO')     OR
      UPDATING('SAWON_ID') THEN
      -- ---------------------------------------------------------------------
      -- 내용 :   해당 데이타를 매출처별단가이력관리(SALE0405H) 테이블에 등록한다.
      -- ---------------------------------------------------------------------
      -- 레코드의 시행종료일자를 수정한다.      
      
      -- 이전 이력의 시행종료일자를 수정한다.
      -- 지금 생성된 이력의 시행일자 바로 전날을 이전이력의 시행종료일로 한다.
      -- 그리고 이전이력의 적용일자가 이전이력의 시행종료일자보다 큰경우 이전이력의 적용일자를 이전이력의 시행종료일자와 같게 한다.
      -- SIGN 값이 마이너스나 0 이면  정상적인 데이터로 볼수 있다. 2016.03.01 - 2016.03.31 => -30     
        
      T_TMP_YMD := TO_DATE(TO_CHAR(SYSDATE,'YYYYMM')||'01','YYYYMMDD'); --변경월의 1일      
      T_BEF_YMD := TO_CHAR(T_TMP_YMD -1,'YYYYMMDD'); --전달말일 - 이전이력의 시행종료일을 위함         
      
        SELECT MAX(TRAN_YMD_CD)
          INTO T_TRAN_YMD_CD
          FROM SALE0405H
         WHERE CUST_ID   =  :NEW.CUST_ID
           AND RCUST_ID  =  :NEW.RCUST_ID
           AND ITEM_ID   =  :NEW.ITEM_ID 
       --    AND YMD       >= TO_DATE(SYSDATE)  --2017.02.21 kta 
       ;
      BEGIN
          
        IF T_TRAN_YMD_CD IS NOT NULL THEN
           UPDATE SALE0405H
              SET YMD  = TO_DATE(T_BEF_YMD,'YYYYMMDD')
                 ,APPL_DATE = DECODE( SIGN( TO_DATE(APPL_DATE,'YYYYMMDD') - TO_DATE(T_BEF_YMD,'YYYYMMDD')), -1 ,APPL_DATE, T_BEF_YMD)
            WHERE CUST_ID     = :NEW.CUST_ID
              AND RCUST_ID    = :NEW.RCUST_ID
              AND ITEM_ID     = :NEW.ITEM_ID 
              AND TRAN_YMD_CD = T_TRAN_YMD_CD;
        END IF;
      
         EXCEPTION
            WHEN OTHERS THEN
                 raise_application_error( -20671, 메시지 ||
                      '매출처별단가이력관리(SALE0405H),제품 수정시 ERROR 발생.' ) ;
      END ;

      -- 레코드를 추가한다.
      BEGIN
         INSERT
           INTO SALE0405H ( CUST_ID, RCUST_ID, INPUT_SEQ, TRAN_YMD_CD,TRAN_DATE, APPL_DATE, ITEM_ID,BAS_AMT, BAL_AMT, YAK_AMT,AMT_YUL, QTY_YUL, YMD,INPUT_YMD, C, GC,ETC, BIGO, SAWON_ID,INPUT_USERID, INPUT_DATE,YMD_ORG )
         VALUES( :NEW.CUST_ID
                ,:NEW.RCUST_ID
                ,:NEW.INPUT_SEQ
                ,TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')
                ,TO_CHAR(SYSDATE, 'YYYYMMDD')
                ,TO_CHAR(SYSDATE, 'YYYYMM')||'01'
                ,:NEW.ITEM_ID
                ,:NEW.BAS_AMT
                ,:NEW.BAL_AMT
                ,:NEW.YAK_AMT
                ,:NEW.AMT_YUL
                ,:NEW.QTY_YUL
                , DECODE( SIGN( TO_DATE(TO_CHAR(SYSDATE, 'YYYYMM')||'01','YYYYMMDD') - :NEW.YMD), -1 ,:NEW.YMD, TO_CHAR(SYSDATE, 'YYYYMM')||'01')                
                , SYSDATE
                ,:NEW.C
                ,:NEW.GC
                ,:NEW.ETC
                ,:NEW.BIGO
                ,:NEW.SAWON_ID
                ,:NEW.INPUT_USERID
                ,:NEW.INPUT_DATE
                ,:NEW.YMD
                );
         EXCEPTION
            -- 이미 존재하는 경우에는 에러를 발생시킨다.
            WHEN DUP_VAL_ON_INDEX THEN
                 raise_application_error( -20671, 메시지 ||
                      '중복된 자료가 이미 존재하므로 추가가 불가능함1. CUST_ID : '||:NEW.CUST_ID||' RCUST_ID : '||:NEW.RCUST_ID||' INPUT_SEQ : '||:NEW.INPUT_SEQ 
                      ||' TRAN_YMD : '||TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')) ;
      END ;

   /* ********************************************************************* */
   /* 삭제될 때                                                             */
   /* ********************************************************************* */
   ELSIF DELETING THEN
      -- ---------------------------------------------------------------------
      -- 내용 : 작업
      --        거래처코드에 대응하는 모든 이력정보를 삭제한다.
      -- ---------------------------------------------------------------------
      BEGIN
         DELETE SALE0405H
          WHERE CUST_ID   = :OLD.CUST_ID
            AND RCUST_ID  = :OLD.RCUST_ID
            AND INPUT_SEQ = :OLD.INPUT_SEQ ;
      END ;
   END IF;
END ;
/
