CREATE TRIGGER TR_SALE0204_IU
AFTER INSERT OR UPDATE OR DELETE
  ON SALE0204
FOR EACH ROW
  declare     
   ln_ret number := 0;     ls_gumae_no     VARCHAR2(14);     ls_cust_id      VARCHAR2(10);                 ls_cust_comp_no VARCHAR2(10);                     ls_cust_nm      VARCHAR2(50);               ln_cnt          NUMBER(5); 

BEGIN
                                                                   
  IF (:NEW.ITEM_ID = '60703' ) THEN                        
      IF INSERTING THEN           ls_gumae_no := NVL(:NEW.GUMAE_NO,:OLD.GUMAE_NO);           
         BEGIN              
            SELECT count(*) INTO ln_cnt                
              FROM SALE.BHCO_ORDER_M_LNK               
             WHERE LNK_ORDER_NO = ls_gumae_no;              ln_cnt := nvl(ln_cnt, 0);           
         EXCEPTION WHEN OTHERS THEN              ln_cnt := 0;           
         END;           
         
         BEGIN              
            SELECT CUST_ID  INTO ls_cust_id                
              FROM SALE0203               
             WHERE GUMAE_NO = ls_gumae_no;              ls_cust_id := nvl(ls_cust_id, '0000000000');           
         EXCEPTION WHEN OTHERS THEN              ls_cust_id := '0000000000';           
         END;                                                     
         
         IF ls_cust_id = '1100223' OR ls_cust_id = '1100007' THEN              
            BEGIN                 
               SELECT VOU_NO, SUBSTR(CUST_NM,1,50)                   INTO ls_cust_comp_no, ls_cust_nm                   
               FROM SALE0003                  
               WHERE CUST_ID = ls_cust_id;                 ls_cust_comp_no := nvl(ls_cust_comp_no,'NULL');                 ls_cust_nm      := nvl(ls_cust_nm,'NULL');              
            EXCEPTION WHEN OTHERS THEN                 ls_cust_comp_no := '0000000000';                 ls_cust_nm      := '오류발생';              
            END;              
            
            IF ls_cust_id <> '0000000000' THEN                 
               IF ln_cnt = 0 THEN                    
                  INSERT INTO SALE.BHCO_ORDER_M_LNK                          (LNK_ORDER_NO, LNK_CMP_NO, IO_GBN    , ORDER_DT, IO_CMP_NO,                           ORDER_QTY   , IO_DT     , ORDER_STAT, COMP_NO , COMP_NM  ,                           INPUT_NM    , INPUT_DT  , STAT)                    
                  SELECT ls_gumae_no , '61142'   , '02'      
                       , to_char(YMD,'YYYYMMDD')     
                       , ls_cust_id,                           0           
                       , NVL(to_char(NAPGI_YMD,'YYYYMMDD'), to_char(YMD,'YYYYMMDD')) , '01'      , ls_cust_comp_no, ls_cust_nm,                           INPUT_ID    , to_char(INPUT_YMD,'YYYYMMDDHH24MISS') , '02'                      
                    FROM SALE0203                     
                   WHERE GUMAE_NO = ls_gumae_no;                    
                   
                   INSERT INTO SALE.BHCO_ORDER_D_LNK                           (LNK_ORDER_NO, ORDER_SEQ, LNK_DRUG_NO, ORDER_QTY, UNIT,                            INPUT_NM    , INPUT_DT  , STAT)                    
                   VALUES (ls_gumae_no , :NEW.INPUT_SEQ, :NEW.ITEM_ID, :NEW.QTY, '02',                            ''          , ''        , '02');                 
                   
               ELSE                    
                   UPDATE SALE.BHCO_ORDER_M_LNK                       
                      SET IO_CMP_NO = ls_cust_id,                           COMP_NO   = ls_cust_comp_no,                           COMP_NM   = ls_cust_nm,                           STAT      = '02'                     
                    WHERE LNK_ORDER_NO = ls_gumae_no;                    
                    
                   UPDATE SALE.BHCO_ORDER_D_LNK                       
                      SET ORDER_QTY = :NEW.QTY,                           STAT      = '02'                     
                    WHERE LNK_ORDER_NO = ls_gumae_no                       AND ORDER_SEQ    = :NEW.INPUT_SEQ;                 
               END IF;              
            END IF;           
         END IF;        
         
      ELSIF  UPDATING THEN           
         
         UPDATE SALE.BHCO_ORDER_M_LNK              
            SET STAT      = '02'            
          WHERE LNK_ORDER_NO = :NEW.GUMAE_NO;           
         
         UPDATE SALE.BHCO_ORDER_D_LNK              
            SET ORDER_QTY = :NEW.QTY,                  STAT      = '02'            
          WHERE LNK_ORDER_NO = :NEW.GUMAE_NO              
            AND ORDER_SEQ    = :NEW.INPUT_SEQ;
                          
      END IF;
           
  END IF;  
            
EXCEPTION WHEN NO_DATA_FOUND THEN     NULL;  
END;
/
