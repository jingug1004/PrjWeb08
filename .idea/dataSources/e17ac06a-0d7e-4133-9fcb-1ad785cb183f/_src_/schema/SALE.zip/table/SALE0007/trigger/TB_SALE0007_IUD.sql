CREATE TRIGGER TB_SALE0007_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0007
FOR EACH ROW
  DECLARE
     T_UPDATE_CHK   NUMBER;
     메시지         varchar2(1000) ;
     
BEGIN
   /* 메시지 처리 준비 */
   if INSERTING then
      메시지 := '사원관리(SALE0007H) 추가 불가 !!  ' ;
   elsif UPDATING then
      메시지 := '사원관리(SALE0007H) 수정 불가 !!  ' ;
   else
      메시지 := '사원관리(SALE0007H) 삭제 불가 !!  ' ;
   end if ;

   /* ********************************************************************* */
   /* 수정될때                                                              */
   /* ********************************************************************* */
   if UPDATING('SAWON_NM')     or
      UPDATING('SAWON_YN')     or
      UPDATING('PDA_AUTH')     or
      UPDATING('SAWON_PSWD')   or
      UPDATING('ZIP')          or
      UPDATING('USER_GRUP')    or
      UPDATING('ADDR1')        or
      UPDATING('ADDR2')        or
      UPDATING('TEL')          or
      UPDATING('HP')           or
      UPDATING('FAX')          or
      UPDATING('EMAIL')        or
      UPDATING('SIL_SAWON_ID') or
      UPDATING('GUBUN')        or
      UPDATING('PDA_ID')       or
      UPDATING('BIGO')         then
      begin
         update SALE0007H
            set SAWON_NM     = :NEW.SAWON_NM,
                SAWON_YN     = :NEW.SAWON_YN,
                PDA_AUTH     = :NEW.PDA_AUTH,
                SAWON_PSWD   = :NEW.SAWON_PSWD,
                ZIP          = :NEW.ZIP,
                USER_GRUP    = :NEW.USER_GRUP,
                ADDR1        = :NEW.ADDR1,
                ADDR2        = :NEW.ADDR2,
                TEL          = :NEW.TEL,
                HP           = :NEW.HP,
                FAX          = :NEW.FAX,
                EMAIL        = :NEW.EMAIL,
                SIL_SAWON_ID = :NEW.SIL_SAWON_ID,
                GUBUN        = :NEW.GUBUN,
                PDA_ID       = :NEW.PDA_ID,
                BIGO         = :NEW.BIGO
          where SAWON_ID = :OLD.SAWON_ID ;
         exception
            when OTHERS then
                 raise_application_error( -20671, 메시지 ||
                      '사원(SALE0007H) 수정시 ERROR 발생.' ) ;
      end ;
   end if ;

   /* ********************************************************************* */
   /* 추가/수정될때                                                         */
   /* ********************************************************************* */
   if INSERTING           or
      UPDATING('DEPT_CD') or
      UPDATING('PART_GB') then
      -- ---------------------------------------------------------------------
      -- 내용 : 작업
      --        해당 데이타를 사원등록이력(SALE0007H) 테이블에 등록한다.
      -- ---------------------------------------------------------------------
      -- 레코드를 추가한다.
      begin
         insert
           into SALE0007H ( SAWON_ID, TRAN_YMD_CD, TRAN_DATE, 
                            APPL_DATE, SAWON_NM, DEPT_CD, 
                            JIKGEUB, ZIP, ADDR1, 
                            ADDR2, TEL, HP, 
                            FAX, EMAIL, BIGO, 
                            USER_ID, INPUT_YMD, SAWON_PSWD, 
                            USER_GRUP, SIL_SAWON_ID, GUBUN, 
                            SAWON_YN, PDA_ID, PDA_AUTH, 
                            PART_GB )
         values( :NEW.SAWON_ID, TO_CHAR(SYSDATE, 'YYYYMMDDHHMISS'), TO_CHAR(SYSDATE, 'YYYYMMDD'), 
                  TO_CHAR(SYSDATE, 'YYYYMM')||'01', :NEW.SAWON_NM, :NEW.DEPT_CD, 
                 :NEW.JIKGEUB, :NEW.ZIP, :NEW.ADDR1, 
                 :NEW.ADDR2, :NEW.TEL, :NEW.HP, 
                 :NEW.FAX, :NEW.EMAIL, :NEW.BIGO, 
                 :NEW.USER_ID, :NEW.INPUT_YMD, :NEW.SAWON_PSWD, 
                 :NEW.USER_GRUP, :NEW.SIL_SAWON_ID, :NEW.GUBUN, 
                 :NEW.SAWON_YN, :NEW.PDA_ID, :NEW.PDA_AUTH, 
                 :NEW.PART_GB ) ;
         exception
            -- 이미 존재하는 경우에는 에러를 발생시킨다.
            when DUP_VAL_ON_INDEX then
                 raise_application_error( -20671, 메시지 ||
                      '중복된 자료가 이미 존재하므로 추가가 불가능함.' ) ;
      end ;
      
   /* ********************************************************************* */
   /* 삭제될 때                                                             */
   /* ********************************************************************* */
   elsif DELETING then
      -- ---------------------------------------------------------------------
      -- 내용 : 작업
      --        거래처코드에 대응하는 모든 이력정보를 삭제한다.
      -- ---------------------------------------------------------------------
      begin
         delete SALE0007H
          where SAWON_ID = :OLD.SAWON_ID ;
      end ;
   end if;

END TB_SALE0007_IUD;
/
