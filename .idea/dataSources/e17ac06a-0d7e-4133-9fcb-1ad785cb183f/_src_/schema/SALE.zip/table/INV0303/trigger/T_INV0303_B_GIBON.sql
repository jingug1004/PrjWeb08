CREATE TRIGGER T_INV0303_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON INV0303
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : INV0303                                                      */
/*  테이블명 : 제조번호                                                      */
/*  트리거명 : T_INV0303_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2001.12.12(수)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 제조번호별로 제조일,제품코드,수량,완료일을 관리하는 테이블    */
/*               일자형태, 코드 존재여부 확인                                 */
/*  수정내역 : 2002.02.19(화) 외주가공인 경우 제조일은 필수가 아님.            */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(200) ;
   v_message    VARCHAR2(250) ;

   user_err     EXCEPTION     ;
   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'INV0303 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'INV0303 수정 불가 !! ' ;
   ELSE
      v_message := 'INV0303 삭제 불가 !! ' ;
   END IF ;

   IF UPDATING('PROD_SEQ') OR UPDATING('PROD_NO') OR UPDATING('ITEM_ID') OR UPDATING('QTY') OR
      DELETING THEN
      SELECT COUNT(*), MIN(ymd||'-'||slip_no)
        INTO v_count, v_dummy
        FROM INV0301
       WHERE prod_seq  = :OLD.prod_seq
         AND ROWNUM < 3 ;
      IF v_count > 0 THEN
         v_curr_error := '해당 제조번호의 입출고전표 자료가 존재하므로 작업이 불가함. 관리자에게 문의바람.=> OLD'||
                         '제조번호 '||:OLD.PROD_NO||' /전표일자-번호 '||v_dummy ;
         RAISE user_err ;
      END IF ;
      SELECT COUNT(*), MIN(req_no)
        INTO v_count, v_dummy
        FROM INV0304
       WHERE prod_seq  = :OLD.prod_seq
         AND ROWNUM < 3 ;
      IF v_count > 0 THEN
         v_curr_error := '해당 제조번호의 시험의뢰 자료가 존재하므로 작업이 불가함. 관리자에게 문의바람.=> OLD'||
                         '제조번호 '||:OLD.PROD_NO||' /시험의뢰번호 '||v_dummy ;
         RAISE user_err ;
      END IF ;
   END IF;

   IF INSERTING OR
      UPDATING('ITEM_ID')  OR
      UPDATING('PROD_YMD') OR UPDATING('PRODORD_YMD') OR
      UPDATING('START_YMD') OR UPDATING('FINISH_YMD')  THEN

      :NEW.item_id     := LTRIM(RTRIM(:NEW.item_id));
      :NEW.PROD_YMD    := LTRIM(RTRIM(:NEW.PROD_YMD));
      :NEW.FINISH_YMD  := LTRIM(RTRIM(:NEW.FINISH_YMD));

      v_curr_jakup := '일자 확인: ' ;
      IF F_CHECK_DATE('YMD', :NEW.prodord_ymd) = 'FALSE' THEN
         v_curr_error := '제조지시일자값 오류임.=> '||:NEW.prodord_ymd ;
         RAISE user_err ;
      END IF ;
      IF F_CHECK_DATE('YMD', :NEW.prod_ymd) = 'FALSE' THEN
         v_curr_error := '제조일자값 오류임.=> '||:NEW.prod_ymd ;
         RAISE user_err ;
      END IF ;

      IF F_CHECK_DATE('YMD', :NEW.start_ymd) = 'FALSE' THEN
         v_curr_error := '제조지시일자값 오류임.=> '||:NEW.start_ymd ;
         RAISE user_err ;
      END IF ;
      IF F_CHECK_DATE('YMD', :NEW.FINISH_YMD) = 'FALSE' THEN
         v_curr_error := '완료일자값 오류임.=> '||:NEW.FINISH_YMD ;
         RAISE user_err ;
      END IF ;

      v_curr_jakup := '입력값 확인: ' ;
      SELECT COUNT(*)
        INTO v_count
        FROM SALE0004
       WHERE item_id = NVL(:NEW.item_id,' ')
         AND use_yn  = 'Y'
         AND ROWNUM < 3 ;
      IF v_count = 0 THEN
         v_curr_error := '해당 제품코드가 존재하지 않거나 사용중지된 코드임.=> '||:NEW.item_id ;
         RAISE user_err ;
      END IF ;

   END IF ;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
