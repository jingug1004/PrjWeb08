CREATE TRIGGER TB_SALE0304_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0304
FOR EACH ROW
  DECLARE  T_MSG        VARCHAR2(100) ;
         T_YMD        SALE0304.ymd%TYPE ;
         T_IPCHUL_GB  SALE0304.ipchul_gb%TYPE ;
         T_STORE_LOC  SALE0303.store_loc%TYPE ;
         T_CUST_ID    SALE0303.cust_id%TYPE ;
         T_IPCHUL_NO  SALE0303.ipchul_no%TYPE ;
         T_SAWON_ID   SALE0303.sawon_id%TYPE ;

BEGIN

   /* ------------------------------------------------------------------------ */
   /* 신규입력일 경우                                                          */
   /* ------------------------------------------------------------------------ */
   IF INSERTING THEN

      SELECT store_loc, ymd, cust_id, sawon_id INTO T_STORE_LOC, T_YMD, T_CUST_ID, T_SAWON_ID
        FROM SALE0303
       WHERE ipchul_no = :NEW.ipchul_no
         AND ymd       = :NEW.ymd;

      T_YMD := TO_DATE(TO_CHAR(T_YMD ,'yyyy/mm')||'/01','yyyy/mm/dd');

      /* ------------------------------------------------------------------- */
      /* ipchul_gb 의 내용                                                   */
      /*    01 - 제품입고, 04 - 반품입고                                     */
      /*    10 - 제품출고, 11 - 폐기                                         */
      /* ------------------------------------------------------------------- */
                
        IF SUBSTR(:NEW.ipchul_gb,1,1) = '1' THEN 
           --출고관련처리
        
           IF :NEW.ipchul_gb = '11' THEN --폐기
               begin    
                   UPDATE SALE0305 --재고현황
                      SET chulgo_qty  = NVL(chulgo_qty,0)  + NVL(:NEW.qty,0),
                          chulgo_amt  = NVL(chulgo_amt,0)  + NVL(:NEW.amt,0),
                          chulgo_vat  = NVL(chulgo_vat,0)  + NVL(:NEW.vat,0)
                    WHERE store_loc  = :NEW.store_loc
                      AND item_id    = :NEW.item_id
                      AND ymd        = T_YMD ;
                   IF SQL%NOTFOUND THEN
                       INSERT INTO SALE0305(STORE_LOC     ,YMD  ,ITEM_ID     ,CHULGO_QTY,CHULGO_AMT,CHULGO_VAT)
                                    VALUES (:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.qty  ,:NEW.amt  ,:NEW.vat  ) ;
                   END IF ;

               exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
               end;
               
               begin                   
                   UPDATE SALE0305_1 --재고현황_제조번호별
                      SET chulgo_qty  = NVL(chulgo_qty,0)  + NVL(:NEW.qty,0),
                          chulgo_amt  = NVL(chulgo_amt,0)  + NVL(:NEW.amt,0),
                          chulgo_vat  = NVL(chulgo_vat,0)  + NVL(:NEW.vat,0)
                    WHERE store_loc  = :NEW.store_loc
                      AND item_id    = :NEW.item_id
                      AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo) 
                      AND prod_no    = :NEW.bigo;
                   IF SQL%NOTFOUND THEN
                       INSERT INTO SALE0305_1 (STORE_LOC   ,YMD   ,ITEM_ID     ,PROD_NO  ,CHULGO_QTY ,CHULGO_AMT ,CHULGO_VAT)
                                     VALUES (:NEW.store_loc,T_YMD ,:NEW.item_id,:NEW.bigo,:NEW.qty   ,:NEW.amt   ,:NEW.vat  ) ;
                   END IF ;
               exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
               end;
               
           ELSE  -- 폐기 외의 경우
               begin 
                   UPDATE SALE0305 --재고현황
                      SET chulgo_qty  = NVL(chulgo_qty,0)  + NVL(:NEW.qty,0),
                          chulgo_qtys = NVL(chulgo_qtys,0) + NVL(:NEW.qty,0),
                          chulgo_amt  = NVL(chulgo_amt,0)  + NVL(:NEW.amt,0),
                          chulgo_vat  = NVL(chulgo_vat,0)  + NVL(:NEW.vat,0)
                    WHERE store_loc  = :NEW.store_loc
                      AND item_id    = :NEW.item_id
                      AND ymd        = T_YMD ;
                   IF SQL%NOTFOUND THEN
                       INSERT INTO SALE0305 (STORE_LOC     ,YMD  ,ITEM_ID     ,CHULGO_QTY,CHULGO_AMT,CHULGO_VAT,CHULGO_QTYS  )
                                     VALUES (:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.qty  ,:NEW.amt  ,:NEW.vat  ,:NEW.qty     ) ;
               END IF ;
             
               exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
               end;
               
               begin  
                   UPDATE SALE0305_1 --재고현황_제조번호별
                      SET chulgo_qty  = NVL(chulgo_qty,0)  + NVL(:NEW.qty,0),
                          chulgo_qtys = NVL(chulgo_qtys,0) + NVL(:NEW.qty,0),
                          chulgo_amt  = NVL(chulgo_amt,0)  + NVL(:NEW.amt,0),
                          chulgo_vat  = NVL(chulgo_vat,0)  + NVL(:NEW.vat,0)
                    WHERE store_loc  = :NEW.store_loc
                      AND item_id    = :NEW.item_id
                      AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo) 
                      AND prod_no    = :NEW.bigo;
                   IF SQL%NOTFOUND THEN
                       INSERT INTO SALE0305_1 (STORE_LOC     ,YMD  ,ITEM_ID     ,PROD_NO  ,CHULGO_QTY,CHULGO_AMT,CHULGO_VAT,CHULGO_QTYS  )
                                       VALUES (:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.bigo,:NEW.qty  ,:NEW.amt  ,:NEW.vat  ,:NEW.qty     ) ;
                   END IF ;
                
               exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
               end;               
                             
           END IF;

        ELSE
           --입고관련처리
           
           IF :NEW.ipchul_gb = '04' THEN --반품입고
           
               
               begin
                 UPDATE SALE0305 --재고현황
                   SET banpum_qtys  = NVL(banpum_qtys,0) + NVL(:NEW.qty,0)
                 WHERE store_loc  = :NEW.store_loc
                   AND item_id    = :NEW.item_id
                   AND ymd        = T_YMD ;

                 IF SQL%NOTFOUND THEN -- tt
                   INSERT INTO SALE0305 (STORE_LOC     ,YMD  ,ITEM_ID     ,BANPUM_QTYS )
                                 VALUES (:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.qty);
                 END IF ;
                 
              exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
              end;             
     
              begin          
                 UPDATE SALE0305_1 --재고현황_제조번호별
                   SET banpum_qtys  = NVL(banpum_qtys,0) + NVL(:NEW.qty,0)
                 WHERE store_loc  = :NEW.store_loc
                   AND item_id    = :NEW.item_id
                   AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo) 
                   AND prod_no    = :NEW.bigo;

                 IF SQL%NOTFOUND THEN -- tt
                   INSERT INTO SALE0305_1 (STORE_LOC    ,YMD  ,ITEM_ID     ,PROD_NO  ,BANPUM_QTYS )
                                VALUES (:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.bigo,:NEW.qty);
                 END IF ;

              exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
              end;
              
           ELSE --반품입고가 아닌 입고 
            
               begin
                 UPDATE SALE0305 --재고현황
                   SET ipgo_qty  = NVL(ipgo_qty,0)  + NVL(:NEW.qty,0),
                       ipgo_qtys = NVL(ipgo_qtys,0) + NVL(:NEW.qty,0),
                       ipgo_amt  = NVL(ipgo_amt,0)  + NVL(:NEW.amt,0),
                       ipgo_vat  = NVL(ipgo_vat,0)  + NVL(:NEW.vat,0)
                 WHERE store_loc  = :NEW.store_loc
                   AND item_id    = :NEW.item_id
                   AND ymd        = T_YMD ;

                 IF SQL%NOTFOUND THEN -- tt
                   INSERT INTO SALE0305 (STORE_LOC    ,YMD  ,ITEM_ID     ,IPGO_AMT,IPGO_VAT,IPGO_QTY,IPGO_QTYS )
                                VALUES (:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.amt,:NEW.vat,:NEW.qty,:NEW.qty);
                 END IF ;
                 
              exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
              end;             
     
              begin          
                 UPDATE SALE0305_1 --재고현황_제조번호별
                   SET ipgo_qty  = NVL(ipgo_qty,0)  + NVL(:NEW.qty,0),
                       ipgo_qtys = NVL(ipgo_qtys,0) + NVL(:NEW.qty,0),
                       ipgo_amt  = NVL(ipgo_amt,0)  + NVL(:NEW.amt,0),
                       ipgo_vat  = NVL(ipgo_vat,0)  + NVL(:NEW.vat,0)
                 WHERE store_loc  = :NEW.store_loc
                   AND item_id    = :NEW.item_id
                   AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo) 
                   AND prod_no    = :NEW.bigo;

                 IF SQL%NOTFOUND THEN -- tt
                   INSERT INTO SALE0305_1 (STORE_LOC    ,YMD  ,ITEM_ID     ,PROD_NO  ,IPGO_AMT,IPGO_VAT,IPGO_QTY,IPGO_QTYS )
                                VALUES (:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.bigo,:NEW.amt,:NEW.vat,:NEW.qty,:NEW.qty);
                 END IF ;

              exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
              end;            
            
            END IF;
              

         END IF ;

   END IF ;


   /* ------------------------------------------------------------------------ */
   /* 수정이 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF UPDATING THEN

      SELECT store_loc, ymd, cust_id, sawon_id INTO T_STORE_LOC, T_YMD, T_CUST_ID, T_SAWON_ID
        FROM SALE0303
       WHERE ipchul_no = :NEW.ipchul_no
         AND ymd       = :NEW.ymd;

      T_YMD := TO_DATE(TO_CHAR(T_YMD ,'yyyy/mm')||'/01','yyyy/mm/dd');

      /* ------------------------------------------------------------------- */
      /* ipchul_gb 의 내용                                                   */
      /*    01 - 제품입고, 04 - 반품입고                                     */
      /*    10 - 제품출고, 11 - 폐기                                         */
      /* ------------------------------------------------------------------- */

       IF (:NEW.item_id = :OLD.item_id) THEN -- 수량이나 금액이 바뀐 경우
            IF SUBSTR(:NEW.ipchul_gb,1,1) = '1' THEN 
              --출고관련
               IF :NEW.ipchul_gb = '11' THEN --폐기
                  begin 
                      UPDATE SALE0305
                                SET chulgo_qty  = (NVL(chulgo_qty,0)  - NVL(:OLD.qty,0)) + NVL(:NEW.qty,0),
                                    chulgo_amt  = NVL(chulgo_amt,0)   - NVL(:OLD.amt,0)  + NVL(:NEW.amt,0),
                                    chulgo_vat  = NVL(chulgo_vat,0)   - NVL(:OLD.vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = T_STORE_LOC
                         AND item_id    = :NEW.item_id
                         AND ymd        = T_YMD;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;
                  
                  
                  begin 
                      UPDATE SALE0305_1
                                SET chulgo_qty  = (NVL(chulgo_qty,0)  - NVL(:OLD.qty,0)) + NVL(:NEW.qty,0),
                                    chulgo_amt  = NVL(chulgo_amt,0)   - NVL(:OLD.amt,0)  + NVL(:NEW.amt,0),
                                    chulgo_vat  = NVL(chulgo_vat,0)   - NVL(:OLD.vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = T_STORE_LOC
                         AND item_id    = :NEW.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = T_STORE_LOC AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo)
                         AND prod_no    = :NEW.bigo;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;
                     
               ELSE  --폐기외의 출고
                  begin
                      UPDATE SALE0305
                                SET chulgo_qty  = (NVL(chulgo_qty,0)  - NVL(:OLD.qty,0)) + NVL(:NEW.qty,0),
                                    chulgo_qtyS = (NVL(chulgo_qtyS,0) - NVL(:OLD.qty,0)) + NVL(:NEW.qty,0),
                                    chulgo_amt  = NVL(chulgo_amt,0)   - NVL(:OLD.amt,0)  + NVL(:NEW.amt,0),
                                    chulgo_vat  = NVL(chulgo_vat,0)   - NVL(:OLD.vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = T_STORE_LOC
                         AND item_id    = :NEW.item_id
                         AND ymd        = T_YMD;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;
                  
                  begin
                      UPDATE SALE0305_1
                                SET chulgo_qty  = (NVL(chulgo_qty,0)  - NVL(:OLD.qty,0)) + NVL(:NEW.qty,0),
                                    chulgo_qtyS = (NVL(chulgo_qtyS,0) - NVL(:OLD.qty,0)) + NVL(:NEW.qty,0),
                                    chulgo_amt  = NVL(chulgo_amt,0)   - NVL(:OLD.amt,0)  + NVL(:NEW.amt,0),
                                    chulgo_vat  = NVL(chulgo_vat,0)   - NVL(:OLD.vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = T_STORE_LOC
                         AND item_id    = :NEW.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = T_STORE_LOC AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo)
                         AND prod_no    = :NEW.bigo;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;
                  
               END IF;
               
            ELSE  
              --입고관련
               IF :NEW.ipchul_gb = '04' THEN --반품입고
               
                  begin
                      UPDATE SALE0305
                         SET banpum_qtys   = banpum_qtys - NVL(:OLD.qty,0) + NVL(:NEW.qty,0)
                       WHERE store_loc  = T_STORE_LOC
                         AND item_id    = :NEW.item_id
                         AND ymd        = T_YMD;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;
                  
                  begin
                      UPDATE SALE0305_1
                         SET banpum_qtys   = banpum_qtys - NVL(:OLD.qty,0) + NVL(:NEW.qty,0)
                       WHERE store_loc  = T_STORE_LOC
                         AND item_id    = :NEW.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = T_STORE_LOC AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo)
                         AND prod_no    = :NEW.bigo;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;              
              
               ELSE   --반품입고 아닌 경우 
              
                  begin
                      UPDATE SALE0305
                         SET ipgo_qty   = (NVL(ipgo_qty,0)  - NVL(:OLD.qty,0)) + NVL(:NEW.qty,0),
                             ipgo_qtys  = (NVL(ipgo_qtys,0) - NVL(:OLD.qty,0)) + NVL(:NEW.qty,0),
                             ipgo_amt   = NVL(ipgo_amt,0)   - NVL(:OLD.amt,0)  + NVL(:NEW.amt,0),
                             ipgo_vat   = NVL(ipgo_vat,0)   - NVL(:OLD.vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = T_STORE_LOC
                         AND item_id    = :NEW.item_id
                         AND ymd        = T_YMD;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;
                  
                  begin
                      UPDATE SALE0305_1
                         SET ipgo_qty   = (NVL(ipgo_qty,0)  - NVL(:OLD.qty,0)) + NVL(:NEW.qty,0),
                             ipgo_qtys  = (NVL(ipgo_qtys,0) - NVL(:OLD.qty,0)) + NVL(:NEW.qty,0),
                             ipgo_amt   = NVL(ipgo_amt,0)   - NVL(:OLD.amt,0)  + NVL(:NEW.amt,0),
                             ipgo_vat   = NVL(ipgo_vat,0)   - NVL(:OLD.vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = T_STORE_LOC
                         AND item_id    = :NEW.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = T_STORE_LOC AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo)
                         AND prod_no    = :NEW.bigo;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;
              
               END IF;
            END IF;
            
       ELSE  -- 품목이 바뀐 경우
           IF SUBSTR(:NEW.ipchul_gb,1,1) = '1' THEN
              --출고관련 
              IF :NEW.ipchul_gb = '11' THEN --폐기
                 begin 
                      UPDATE SALE0305
                         SET chulgo_qty  = NVL(chulgo_qty,0)  - NVL(:OLD.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  - NVL(:OLD.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = :OLD.ymd;
                 exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                 end;
                 
                 begin
                      UPDATE SALE0305
                         SET chulgo_qty  = NVL(chulgo_qty,0)  + NVL(:NEW.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  + NVL(:NEW.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :NEW.item_id
                         AND ymd        = :NEW.ymd;
                      IF SQL%NOTFOUND THEN
                         INSERT INTO SALE0305 (STORE_LOC     ,YMD  ,ITEM_ID     ,CHULGO_QTY,CHULGO_AMT,CHULGO_VAT )
                                       VALUES (:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.qty  ,:NEW.amt  ,:NEW.vat ) ;
                      END IF ;
                 exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                 end;
                 
                 
                 begin 
                      UPDATE SALE0305_1
                         SET chulgo_qty  = NVL(chulgo_qty,0)  - NVL(:OLD.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  - NVL(:OLD.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :OLD.item_id AND prod_no    = :OLD.bigo)
                         AND prod_no    = :OLD.bigo;
                 exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                 end;
                 
                 begin
                      UPDATE SALE0305_1
                         SET chulgo_qty  = NVL(chulgo_qty,0)  + NVL(:NEW.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  + NVL(:NEW.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :NEW.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo)
                         AND prod_no    = :NEW.bigo;
                      IF SQL%NOTFOUND THEN
                         INSERT INTO SALE0305_1 (STORE_LOC   ,YMD  ,ITEM_ID     ,prod_no  ,CHULGO_QTY,CHULGO_AMT,CHULGO_VAT )
                                       VALUES (:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.bigo,:NEW.qty  ,:NEW.amt  ,:NEW.vat ) ;
                      END IF ;
                 exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                 end;
                  
              ELSE --폐기 외의경우
                
                 begin
                      UPDATE SALE0305
                         SET chulgo_qty  = NVL(chulgo_qty,0)  - NVL(:OLD.qty,0),
                             chulgo_qtyS = NVL(chulgo_qtyS,0) - NVL(:OLD.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  - NVL(:OLD.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = :OLD.ymd;           
                 exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                 end;
                 
                 begin
                      UPDATE SALE0305
                         SET chulgo_qty  = NVL(chulgo_qty,0)  + NVL(:NEW.qty,0),
                             chulgo_qtyS = NVL(chulgo_qtyS,0) + NVL(:NEW.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  + NVL(:NEW.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :NEW.item_id
                         AND ymd        = :NEW.ymd;
                      IF SQL%NOTFOUND THEN
                         INSERT INTO SALE0305(STORE_LOC     ,YMD  ,ITEM_ID     ,CHULGO_QTY ,    CHULGO_AMT , CHULGO_VAT,CHULGO_QTYS  )
                                       VALUES(:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.qty,       :NEW.amt ,   :NEW.vat,:NEW.qty     ) ;
                      END IF ;                      
                 exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                 end;
                 
                 begin
                      UPDATE SALE0305_1
                         SET chulgo_qty  = NVL(chulgo_qty,0)  - NVL(:OLD.qty,0),
                             chulgo_qtyS = NVL(chulgo_qtyS,0) - NVL(:OLD.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  - NVL(:OLD.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :OLD.item_id AND prod_no    = :OLD.bigo)  
                         AND prod_no    = :OLD.bigo;           
                 exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                 end;
                 
                 begin
                      UPDATE SALE0305_1
                         SET chulgo_qty  = NVL(chulgo_qty,0)  + NVL(:NEW.qty,0),
                             chulgo_qtyS = NVL(chulgo_qtyS,0) + NVL(:NEW.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  + NVL(:NEW.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :NEW.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo)
                         AND prod_no    = :NEW.bigo; 
                      IF SQL%NOTFOUND THEN
                         INSERT INTO SALE0305_1(STORE_LOC    ,YMD  ,ITEM_ID     ,PROD_NO  ,CHULGO_QTY ,    CHULGO_AMT , CHULGO_VAT,CHULGO_QTYS  )
                                       VALUES (:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.bigo,:NEW.qty,       :NEW.amt ,   :NEW.vat,:NEW.qty     ) ;
                      END IF ;                      
                 exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                 end;

                 
              END IF;
              
           ELSE
              --입고관련 
              IF :NEW.ipchul_gb = '04' THEN --반품입고
              
                  begin
                      UPDATE SALE0305 --재고현황
                         SET banpum_qtys  = NVL(banpum_qtys,0)  - NVL(:OLD.qty,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = :OLD.ymd;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end; 
                 
                  begin
                      UPDATE SALE0305--재고현황
                         SET banpum_qtys  = NVL(banpum_qtys,0)  + NVL(:NEW.qty,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :NEW.item_id
                         AND ymd        = :NEW.ymd;

                      IF SQL%NOTFOUND THEN 
                          INSERT INTO SALE0305(STORE_LOC     ,YMD  ,ITEM_ID     ,BANPUM_QTYS )
                                        VALUES(:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.qty);
                      END IF ;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end; 
                  

                  begin
                      UPDATE SALE0305_1 --재고현황_제조번호별
                         SET banpum_qtys  = NVL(banpum_qtys,0)  - NVL(:OLD.qty,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :OLD.item_id AND prod_no    = :OLD.bigo)
                         AND prod_no    = :OLD.bigo;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end; 
                 
                  begin
                      UPDATE SALE0305_1 --재고현황_제조번호별
                         SET banpum_qtys  = NVL(banpum_qtys,0)  + NVL(:NEW.qty,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :NEW.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo)
                         AND prod_no    = :NEW.bigo;

                      IF SQL%NOTFOUND THEN 
                          INSERT INTO SALE0305_1(STORE_LOC     ,YMD  ,ITEM_ID     ,prod_no  ,BANPUM_QTYS )
                                          VALUES(:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.bigo,:NEW.qty);
                      END IF ;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;                    
              
              
              
              ELSE  --반품입고가 아닌 경우 
              
                  begin
                      UPDATE SALE0305 --재고현황
                         SET ipgo_qty  = NVL(ipgo_qty,0)  - NVL(:OLD.qty,0),
                             ipgo_qtys = NVL(ipgo_qtys,0) - NVL(:OLD.qty,0),
                             ipgo_amt  = NVL(ipgo_amt,0)  - NVL(:OLD.amt,0),
                             ipgo_vat = NVL(ipgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = :OLD.ymd;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end; 
                 
                  begin
                      UPDATE SALE0305--재고현황
                         SET ipgo_qty  = NVL(ipgo_qty,0)  + NVL(:NEW.qty,0),
                             ipgo_qtys = NVL(ipgo_qtys,0) + NVL(:NEW.qty,0),
                             ipgo_amt  = NVL(ipgo_amt,0)  + NVL(:NEW.amt,0),
                             ipgo_vat  = NVL(ipgo_vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :NEW.item_id
                         AND ymd        = :NEW.ymd;

                      IF SQL%NOTFOUND THEN 
                          INSERT INTO SALE0305(STORE_LOC     ,YMD  ,ITEM_ID     ,IPGO_AMT,IPGO_VAT,IPGO_QTY,IPGO_QTYS )
                                        VALUES(:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.amt,:NEW.vat,:NEW.qty,:NEW.qty);
                      END IF ;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end; 
                  

                  begin
                      UPDATE SALE0305_1 --재고현황_제조번호별
                         SET ipgo_qty  = NVL(ipgo_qty,0)  - NVL(:OLD.qty,0),
                             ipgo_qtys = NVL(ipgo_qtys,0) - NVL(:OLD.qty,0),
                             ipgo_amt  = NVL(ipgo_amt,0)  - NVL(:OLD.amt,0),
                             ipgo_vat  = NVL(ipgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :OLD.item_id AND prod_no    = :OLD.bigo)
                         AND prod_no    = :OLD.bigo;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end; 
                 
                  begin
                      UPDATE SALE0305_1 --재고현황_제조번호별
                         SET ipgo_qty  = NVL(ipgo_qty,0)  + NVL(:NEW.qty,0),
                             ipgo_qtys = NVL(ipgo_qtys,0) + NVL(:NEW.qty,0),
                             ipgo_amt  = NVL(ipgo_amt,0)  + NVL(:NEW.amt,0),
                             ipgo_vat  = NVL(ipgo_vat,0)  + NVL(:NEW.vat,0)
                       WHERE store_loc  = :NEW.store_loc
                         AND item_id    = :NEW.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :NEW.store_loc AND item_id    = :NEW.item_id AND prod_no    = :NEW.bigo)
                         AND prod_no    = :NEW.bigo;

                      IF SQL%NOTFOUND THEN 
                          INSERT INTO SALE0305_1(STORE_LOC   ,YMD  ,ITEM_ID     ,prod_no  ,IPGO_AMT,IPGO_VAT,IPGO_QTY,IPGO_QTYS )
                                        VALUES(:NEW.store_loc,T_YMD,:NEW.item_id,:NEW.bigo,:NEW.amt,:NEW.vat,:NEW.qty,:NEW.qty);
                      END IF ;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;        
                         
              END IF;
              
           END IF;
       END IF ; 

    END IF ;


   /* ------------------------------------------------------------------------ */
   /* 삭제가 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF DELETING THEN
      
        FOR c1 IN (SELECT store_loc, ymd, cust_id, sawon_id
                     FROM SALE0303
                    WHERE ipchul_no = :OLD.ipchul_no
                      AND ymd       = :OLD.ymd )
        LOOP
            T_STORE_LOC := c1.store_loc;
            T_YMD       := c1.ymd;
            T_CUST_ID   := c1.cust_id;
            T_SAWON_ID  := c1.sawon_id;

            T_YMD := TO_DATE(TO_CHAR(T_YMD ,'yyyy/mm')||'/01','yyyy/mm/dd');

            /* ------------------------------------------------------------------- */
            /* ipchul_gb 의 내용                                                   */
            /*    01 - 제품입고, 04 - 반품입고                                     */
            /*    10 - 제품출고, 11 - 폐기                                         */
            /* ------------------------------------------------------------------- */
            IF SUBSTR(:OLD.ipchul_gb,1,1) = '1' THEN 
            
              --출고관련
               IF :OLD.ipchul_gb = '11' THEN --폐기 
                  begin
                      UPDATE SALE0305 --제고현황
                         SET chulgo_qty  = NVL(chulgo_qty,0)  - NVL(:OLD.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  - NVL(:OLD.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :OLD.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = T_YMD;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;

                  begin
                      UPDATE SALE0305_1 --제고현황_제조번호별 
                         SET chulgo_qty  = NVL(chulgo_qty,0)  - NVL(:OLD.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  - NVL(:OLD.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :OLD.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :OLD.store_loc AND item_id    = :OLD.item_id AND prod_no    = :OLD.bigo)
                         AND prod_no    = :OLD.bigo;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;
                     
               ELSE --폐기외의 경우
                  begin
                      UPDATE SALE0305 --제고현황
                         SET chulgo_qty  = NVL(chulgo_qty,0)  - NVL(:OLD.qty,0),
                             chulgo_qtyS = NVL(chulgo_qtyS,0) - NVL(:OLD.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  - NVL(:OLD.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :OLD.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = T_YMD;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;
                  
                  begin
                      UPDATE SALE0305_1 --제고현황_제조번호별 
                         SET chulgo_qty  = NVL(chulgo_qty,0)  - NVL(:OLD.qty,0),
                             chulgo_qtyS = NVL(chulgo_qtyS,0) - NVL(:OLD.qty,0),
                             chulgo_amt  = NVL(chulgo_amt,0)  - NVL(:OLD.amt,0),
                             chulgo_vat  = NVL(chulgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :OLD.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :OLD.store_loc AND item_id    = :OLD.item_id AND prod_no    = :OLD.bigo)
                         AND prod_no    = :OLD.bigo;
                  exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                  end;
                  
               END IF;

            ELSIF SUBSTR(:OLD.ipchul_gb,1,1) = '0' THEN
            
               --입고관련
               IF :OLD.ipchul_gb = '04' THEN --반품입고        
                   begin
                      UPDATE SALE0305 --제고현황
                         SET banpum_qtys  = NVL(banpum_qtys,0)  - NVL(:OLD.qty,0)
                       WHERE store_loc  = :OLD.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = T_YMD;
                   exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                   end;               
                   
                   begin
                      UPDATE SALE0305_1 --제고현황_제조번호별 
                         SET banpum_qtys  = NVL(banpum_qtys,0)  - NVL(:OLD.qty,0)
                       WHERE store_loc  = :OLD.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :OLD.store_loc AND item_id    = :OLD.item_id AND prod_no    = :OLD.bigo)
                         AND prod_no    = :OLD.bigo;
                   exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                   end;
               
               
               ELSE          --반품입고가 아닌 경우      
                   begin
                      UPDATE SALE0305 --제고현황
                         SET ipgo_qty  = NVL(ipgo_qty,0)  - NVL(:OLD.qty,0),
                             ipgo_qtys = NVL(ipgo_qtys,0) - NVL(:OLD.qty,0),
                             ipgo_amt  = NVL(ipgo_amt,0)  - NVL(:OLD.amt,0),
                             ipgo_vat  = NVL(ipgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :OLD.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = T_YMD;
                   exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                   end;               
                   
                   begin
                      UPDATE SALE0305_1 --제고현황_제조번호별 
                         SET ipgo_qty  = NVL(ipgo_qty,0)  - NVL(:OLD.qty,0),
                             ipgo_qtys = NVL(ipgo_qtys,0) - NVL(:OLD.qty,0),
                             ipgo_amt  = NVL(ipgo_amt,0)  - NVL(:OLD.amt,0),
                             ipgo_vat  = NVL(ipgo_vat,0)  - NVL(:OLD.vat,0)
                       WHERE store_loc  = :OLD.store_loc
                         AND item_id    = :OLD.item_id
                         AND ymd        = (select min(ymd) from sale0305_1 where store_loc  = :OLD.store_loc AND item_id    = :OLD.item_id AND prod_no    = :OLD.bigo)
                         AND prod_no    = :OLD.bigo;
                   exception when OTHERS then raise_application_error( -20001, sqlerrm ) ;
                   end;

               END IF;

            END IF;
            
        END LOOP; 
      
   END IF ;

END TB_SALE0304_IUD;
/
