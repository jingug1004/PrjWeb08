CREATE TRIGGER T_INV0304_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON INV0304
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : INV0304                                                      */
/*  테이블명 : QC관리                                                        */
/*  트리거명 : T_INV0304_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2002.02.04(월)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 제조번호는 내부 또는 외부 둘 중 하나만 입력하게 함.          */
/*             2. 일자형, 코드 존재여부 확인                                  */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(100) ;
   v_message    VARCHAR2(250) ;
   v_value      VARCHAR2(50) ;
   user_err     EXCEPTION     ;

   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'INV0304 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'INV0304 수정 불가 !! ' ;
   ELSE
      v_message := 'INV0304 삭제 불가 !! ' ;
   END IF ;

   IF (UPDATING('QC_NO') OR DELETING) AND
      NVL(LTRIM(RTRIM(:OLD.QC_NO)),' ') = ' ' THEN
      SELECT COUNT(*), NVL(MIN(ymd||'-'||slip_no),' ')
        INTO v_count, v_dummy
        FROM INV0302
       WHERE qc_no = :OLD.qc_no
         AND ROWNUM < 3 ;
      IF v_count > 0 THEN
         v_curr_error := '해당 QC번호에 대한 원부자재입출고 전표 자료가 있어 작업 불가함. 전표번호=>'||v_dummy ;
         RAISE user_err ;
      END IF ;
   END IF;

   /* ********** 시험의뢰 관련 ********** */
   IF INSERTING OR
      UPDATING('qc_gb') OR UPDATING('BUY_YMD') OR UPDATING('REQ_YMD') OR
      UPDATING('PROD_SEQ') OR UPDATING('MATERIAL_ID') OR UPDATING('PROCESS_CD') OR
      UPDATING('REQ_SAWON_ID') OR UPDATING('REQ_DEPT_CD') THEN

      :NEW.qc_gb        := LTRIM(RTRIM(:NEW.qc_gb));
      :NEW.BUY_YMD      := LTRIM(RTRIM(:NEW.BUY_YMD));
      :NEW.REQ_YMD      := LTRIM(RTRIM(:NEW.REQ_YMD));
      :NEW.REQ_SAWON_ID := LTRIM(RTRIM(:NEW.REQ_SAWON_ID));
      :NEW.REQ_DEPT_CD  := LTRIM(RTRIM(:NEW.REQ_DEPT_CD));
      :NEW.prod_seq     := LTRIM(RTRIM(:NEW.prod_seq));
      :NEW.out_prod_no  := LTRIM(RTRIM(:NEW.out_prod_no));
      :NEW.MATERIAL_ID  := LTRIM(RTRIM(:NEW.MATERIAL_ID));
      :NEW.PROCESS_CD   := LTRIM(RTRIM(:NEW.PROCESS_CD));

      v_curr_jakup := '일자 확인: ' ;
      IF NVL(:NEW.BUY_YMD,' ') > ' ' AND F_CHECK_DATE('YMD', :NEW.BUY_YMD) = 'FALSE' THEN
         v_curr_error := '구매일자값 오류임.=> '||:NEW.BUY_YMD ;
         RAISE user_err ;
      END IF ;
      IF NVL(:NEW.REQ_YMD,' ') > ' ' AND F_CHECK_DATE('YMD', :NEW.REQ_YMD) = 'FALSE' THEN
         v_curr_error := '의뢰일자값 오류임.=> '||:NEW.REQ_YMD ;
         RAISE user_err ;
      END IF ;

      v_curr_jakup := '입력값 확인: ' ;
      -- 시험의뢰구분(qc_gb): 1.입고QC, 2.공정QC, 3.완제품QC, 4.합성QC
      IF :NEW.qc_gb = '1' THEN
         v_dummy := '1.입고QC' ;
      ELSIF :NEW.qc_gb = '2' THEN
         v_dummy := '2.공정QC' ;
      ELSIF :NEW.qc_gb = '3' THEN
         v_dummy := '3.완제품QC' ;
      ELSIF :NEW.qc_gb = '4' THEN
         v_dummy := '4.합성공정QC' ;
      ELSE
         v_dummy := '5.합성완제품QC' ;
      END IF ;
      IF :NEW.qc_gb = '1' THEN
         IF NVL(:NEW.material_id, ' ') = ' ' THEN
            v_curr_error := '해당 시험의뢰는 원부자재 코드를 반드시 입력해야 함.=> '||v_dummy ;
            RAISE user_err ;
         END IF ;
         IF NVL(:NEW.prod_seq, ' ') > ' ' OR NVL(:NEW.process_cd, ' ') > ' ' THEN
            v_curr_error := '해당 시험의뢰는 내부 제조번호, 공정코드를 입력하지 못함.=> '||v_dummy ;
            RAISE user_err ;
         END IF ;    
         
      ELSIF :NEW.qc_gb = '4' THEN
         IF NVL(:NEW.material_id, ' ') = ' ' THEN
            v_curr_error := '해당 시험의뢰는 원부자재 코드를 반드시 입력해야 함.=> '||v_dummy ;
            RAISE user_err ;
         END IF ;
         IF NVL(:NEW.prod_seq, ' ') > ' ' OR NVL(:NEW.process_cd, ' ') > ' ' THEN
            v_curr_error := '해당 시험의뢰는 내부 제조번호, 공정코드를 입력하지 못함.=> '||v_dummy ;
            RAISE user_err ;
         END IF ;    
      ELSIF :NEW.qc_gb = '5' THEN
         IF NVL(:NEW.material_id, ' ') = ' ' THEN
            v_curr_error := '해당 시험의뢰는 원부자재 코드를 반드시 입력해야 함.=> '||v_dummy ;
            RAISE user_err ;
         END IF ;
         IF NVL(:NEW.prod_seq, ' ') > ' ' OR NVL(:NEW.process_cd, ' ') > ' ' THEN
            v_curr_error := '해당 시험의뢰는 내부 제조번호, 공정코드를 입력하지 못함.=> '||v_dummy ;
            RAISE user_err ;
         END IF ;       
      ELSE /* *** IF :NEW.qc_gb = '2' or :NEW.qc_gb = '3' THEN *** */
         IF NVL(:NEW.prod_seq, ' ') = ' ' OR NVL(:NEW.process_cd, ' ') = ' ' THEN
            v_curr_error := '해당 시험의뢰는 내부 제조번호, 공정코드를 반드시 입력해야 함.=> '||v_dummy ;
            RAISE user_err ;
         END IF ;
         IF NVL(:NEW.out_prod_no, ' ') > ' ' OR NVL(:NEW.material_id, ' ') > ' ' THEN
            v_curr_error := '해당 시험의뢰는 외부 제조번호, 원부자재코드를 입력하지 못함.=> '||v_dummy ;
            RAISE user_err ;
         END IF ;
      END IF ;

      IF NVL(:NEW.process_cd,' ') > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM INV0002
          WHERE process_cd = :NEW.process_cd
            AND use_yn  = 'Y'
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 공정코드는 존재하지 않거나 사용중지된 코드임.=> '||:NEW.process_cd ;
            RAISE user_err ;
         END IF ;
      END IF ;
      IF NVL(:NEW.material_id,' ') > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM INV0003
          WHERE material_id = :NEW.material_id
            AND use_yn  = 'Y'
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 원부자재코드는 존재하지 않거나 사용중지된 코드임.=> '||:NEW.material_id ;
            RAISE user_err ;
         END IF ;
      END IF ;
      IF NVL(:NEW.prod_seq,' ') > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM INV0303
          WHERE prod_seq = :NEW.prod_seq
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 제조번호PK는 존재하지 않거나 사용중지된 코드임.=> '||:NEW.prod_seq ;
            RAISE user_err ;
         END IF ;
      END IF ;
      IF NVL(:NEW.req_dept_cd,' ') > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM SALE0008
          WHERE dept_cd = :NEW.req_dept_cd
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 부서코드는 존재하지 않음.=> '||:NEW.req_dept_cd ;
            RAISE user_err ;
         END IF ;
      END IF ;

      IF :NEW.REQ_SAWON_ID > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM SALE0007
          WHERE sawon_id = :NEW.REQ_SAWON_ID
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 의뢰사원은 등록되지 않음. => '||:NEW.REQ_SAWON_ID ;
            RAISE user_err ;
         END IF ;
      END IF ;
   END IF ;
   /* ********** QC 결과 관련 ********** */
   IF INSERTING OR
      UPDATING('QC_JUBSU_YMD') OR UPDATING('QC_YMD') OR
      UPDATING('QC_JUB_SAWON_ID') OR UPDATING('QC_SAWON_ID') THEN

      :NEW.QC_JUBSU_YMD := LTRIM(RTRIM(:NEW.QC_JUBSU_YMD));
      :NEW.QC_YMD       := LTRIM(RTRIM(:NEW.QC_YMD));
      :NEW.QC_JUB_SAWON_ID := LTRIM(RTRIM(:NEW.QC_JUB_SAWON_ID));
      :NEW.QC_SAWON_ID  := LTRIM(RTRIM(:NEW.QC_SAWON_ID));

      v_curr_jakup := '일자 확인: ' ;
      IF NVL(:NEW.QC_JUBSU_YMD,' ') > ' ' AND F_CHECK_DATE('YMD', :NEW.QC_JUBSU_YMD) = 'FALSE' THEN
         v_curr_error := 'QC접수일자값 오류임.=> '||:NEW.QC_JUBSU_YMD ;
         RAISE user_err ;
      END IF ;
      IF NVL(:NEW.QC_YMD,' ') > ' ' AND F_CHECK_DATE('YMD', :NEW.QC_YMD) = 'FALSE' THEN
         v_curr_error := 'QC일자값 오류임.=> '||:NEW.QC_YMD ;
         RAISE user_err ;
      END IF ;

      v_curr_jakup := '입력값 확인: ' ;
      IF :NEW.QC_JUB_SAWON_ID > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM SALE0007
          WHERE sawon_id = :NEW.QC_JUB_SAWON_ID
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 QC접수사원은 등록되지 않음. => '||:NEW.QC_JUB_SAWON_ID ;
            RAISE user_err ;
         END IF ;
      END IF ;

      IF :NEW.qc_sawon_id > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM SALE0007
          WHERE sawon_id = :NEW.qc_sawon_id
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 QC사원은 등록되지 않음. => '||:NEW.qc_sawon_id ;
            RAISE user_err ;
         END IF ;
      END IF ;
   END IF ;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
