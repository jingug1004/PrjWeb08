CREATE TRIGGER TB_SALE0306_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0306
FOR EACH ROW
  DECLARE
     T_UPDATE_CHK NUMBER;
     V_CNT NUMBER;
BEGIN

    /* ----------------------------------------------------------------
    변경된 내용이 있는가 ?
    
    20132018 오후 2시 이후부터 자료 수집 
    ----------------------------------------------------------------*/
    SELECT COUNT(*) + 1
    INTO V_CNT
    FROM SFA_SP_CALLED_HIST
    WHERE sp_nm = 'tb_sale0306_iud' ;

  
    IF UPDATING THEN
        
       if :new.su_amt > 0 and :NEW.CUST_ID = '4900635' then
            --insert into SFA_SP_CALLED_HIST values ( 'tb_sale0306_iud' , TO_CHAR(V_CNT) , sysdate , 'UP-YMD: '||:NEW.YMD||' ,CUST_ID: '||:NEW.CUST_ID||' ,RCUST_ID: '||:NEW.RCUST_ID||' ,SAWON_ID: '||:NEW.SAWON_ID||' ,SU_AMT: '||:NEW.SU_AMT||' ,BEFORE_AMT: '||:NEW.BEFORE_AMT );
            
--            IF :NEW.CUST_ID = '4004022' THEN
               RAISE_APPLICATION_ERROR( -20001, SQLERRM||' ORACLE Critical Error ,CUST_ID: '||:NEW.CUST_ID||' ,RCUST_ID: '||:NEW.RCUST_ID||'new_su_amt: '||:new.su_amt||'old_su_amt: '||:old.su_amt) ;
--            END IF;
            
       end if;        
    
    END IF;

END TB_SALE0306_IUD;
/
