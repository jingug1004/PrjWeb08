CREATE TRIGGER TB_SALE0402_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0402
FOR EACH ROW
  DECLARE
     T_UPDATE_CHK   VARCHAR2(1);
     T_CUST_ID      SALE0401.CUST_ID%TYPE ;
     T_RCUST_ID     SALE0401.RCUST_ID%TYPE ;
     T_BILL_GB_NM   SALE0409.BILL_GB_NM%TYPE;
BEGIN

   /* ----------------------------------------------------------------*/
   /* 하나제약                                                        */
   /* 어음 수금분에 대해 통장명세서 테이블에 CRUD처리한다             */
   /* 현금 수금분은 Master(SALE0401)에서 CRUD처리한다.                */
   /* ----------------------------------------------------------------*/

   IF INSERTING THEN
      /* 거래명세서 Detail 저장 */
      BEGIN
            SELECT A.CUST_ID   CUST_ID,
                   A.RCUST_ID  RCUST_ID
              INTO T_CUST_ID,  T_RCUST_ID
              FROM SALE0401 A
             WHERE A.JUNPYO_NO   = :NEW.JUNPYO_NO;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                 RAISE_APPLICATION_ERROR( -20001, '수금 마스터가 저장되어 있지 않습니다.['||:NEW.JUNPYO_NO||']'||SQLERRM ) ;
            WHEN OTHERS THEN
                 RAISE_APPLICATION_ERROR( -20001, '수금 마스터 조회 Err:'||SQLERRM ) ;
      END;

      BEGIN
            SELECT A.CODE1_NM      BILL_GB_NM
              INTO T_BILL_GB_NM
              FROM SALE0001 A
             WHERE A.CODE_GB  = '0007'
               AND A.CODE1    = :NEW.BILL_GB ;
      EXCEPTION
             WHEN NO_DATA_FOUND THEN
                  T_BILL_GB_NM := '';
             WHEN OTHERS THEN
                  RAISE_APPLICATION_ERROR( -20001, '어음구분 조회 Err:'||SQLERRM ) ;
      END;

      BEGIN

            INSERT INTO SALE0409 (
                     ISSU_NO  ,CUST_ID  ,TRAN_YMD ,GUBUN     ,REMARK   ,
                     AMT      ,VAT      ,SUKUM_AMT,GON_NO    ,PAGE_NO  ,
                     LINE_NO  ,ISSU_DATE,SALE_NO  ,JUNPYO_NO ,INPUT_SEQ,
                     ADD_SIGN ,RCUST_ID ,BILL_NO  ,BILL_GB_NM,END_YMD)
             VALUES( ISSU_NO_SEQ.NEXTVAL,
                     T_CUST_ID,
                     TO_CHAR(:NEW.YMD,'YYYYMMDD'),               --TRAN_YMD
                     '5',                                        --GUBUN
                     '어 음',
                     0,                                          --AMT
                     0,                                          --VAT
                     :NEW.AMT,                                   --SUKUM_AMT
                     NULL,                                       --GON_NO
                     NULL,                                       --PAGE_NO
                     NULL,                                       --LINE_NO
                     NULL,                                       --ISSU_DATE
                     NULL,                                       --SALE_NO
                     :NEW.JUNPYO_NO,                             --JUNPYO_NO
                     :NEW.INPUT_SEQ,                             --INPUT_SEQ
                     '-',                                        --ADD_SIGN
                     T_RCUST_ID,                                 --RCUST_ID
                     :NEW.BILL_NO,
                     T_BILL_GB_NM,
                     :NEW.END_YMD);
      EXCEPTION
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, '어음수금 통장명세 INS Err:'||SQLERRM ) ;
      END;

      -- 거래처 코드와 매출처 코드가 틀리면 즉. 도매상을 통해 약국으로 납품되는 경우
      -- 거래처 코드로 통장을 발행 하고 매출처로도 통장을 발행한다.
      IF T_CUST_ID <> T_RCUST_ID THEN
           BEGIN
              INSERT INTO SALE0409 (
                     ISSU_NO  ,CUST_ID  ,TRAN_YMD ,GUBUN     ,REMARK   ,
                     AMT      ,VAT      ,SUKUM_AMT,GON_NO    ,PAGE_NO  ,
                     LINE_NO  ,ISSU_DATE,SALE_NO  ,JUNPYO_NO ,INPUT_SEQ,
                     ADD_SIGN ,RCUST_ID ,BILL_NO  ,BILL_GB_NM,END_YMD)
              VALUES (  ISSU_NO_SEQ.NEXTVAL,
                        T_CUST_ID,
                        TO_CHAR(:NEW.YMD,'YYYYMMDD'),               --TRAN_YMD
                        '5',                                        --GUBUN
                        '어 음',
                        0,                                          --AMT
                        0,                                          --VAT
                        :NEW.AMT,                                   --SUKUM_AMT
                        NULL,                                       --GON_NO
                        NULL,                                       --PAGE_NO
                        NULL,                                       --LINE_NO
                        NULL,                                       --ISSU_DATE
                        NULL,                                       --SALE_NO
                        :NEW.JUNPYO_NO,                             --JUNPYO_NO
                        :NEW.INPUT_SEQ,                             --INPUT_SEQ
                        '-',                                        --ADD_SIGN
                        T_CUST_ID,                                   --RCUST_ID
                        :NEW.BILL_NO,
                        T_BILL_GB_NM,
                        :NEW.END_YMD);
           EXCEPTION
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, '어음수금 통장명세 INS Err(2):'||SQLERRM ) ;
           END;
      END IF;

   END IF;

   /* ------------------------------------------------------------------------ */
   /* 수정이 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF UPDATING THEN
         --통장명세서 UPDATE
         -- CUST_ID의 수정은 세금계산서/거래명세서/재고 등에 영향을 줌으로 Client에서
         -- 수정하지 못하도록 처리한다.
         IF    :NEW.AMT     <> :OLD.AMT
            OR NVL(:NEW.BILL_NO,'') <> NVL(:OLD.BILL_NO,'')
            OR :NEW.END_YMD         <> :OLD.END_YMD
            OR NVL(:NEW.BILL_GB,'') <> NVL(:OLD.BILL_GB,'') THEN

              UPDATE SALE0409 A SET
                     SUKUM_AMT  = :NEW.AMT,
                     REMARK     = '어 음',
                     BILL_NO    = :NEW.BILL_NO,
                     END_YMD    = :NEW.END_YMD,
                     BILL_GB_NM = (SELECT CODE1_NM
                                     FROM SALE0001
                                    WHERE CODE_GB = '0007' AND CODE1(+) = :NEW.BILL_GB)
               WHERE A.JUNPYO_NO = :NEW.JUNPYO_NO
                 AND A.INPUT_SEQ = :NEW.INPUT_SEQ;
         END IF;
   END IF;

   /* ------------------------------------------------------------------------ */
   /* 삭제가 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF DELETING THEN

      DELETE FROM SALE0409
            WHERE JUNPYO_NO   = :OLD.JUNPYO_NO
              AND INPUT_SEQ   = :OLD.INPUT_SEQ;

   END IF;

END TB_SALE0402_IUD;
/
