CREATE TRIGGER TB_SALE0004_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0004
FOR EACH ROW
  DECLARE
     T_UPDATE_CHK   NUMBER;
BEGIN

   /* ---------------------------------------------------------------------------- */
   /* 수정/삭제 되었을 경우                                                        */
   /* ---------------------------------------------------------------------------- */
   /* 잔고 통계테이블(SALE0409)에 존재하면 거래처코드를 수정/삭제 할 수 없도록     */
   /* 처리한다.                                                                    */
   /* ---------------------------------------------------------------------------- */
   IF INSERTING THEN
	  INSERT INTO SALE0005(YAK_ID, YAK_NM, YAK_NM1, STANDARD, AMT)
	                VALUES(:NEW.ITEM_ID, :NEW.ITEM_NM, :NEW.ITEM_NM1, :NEW.STANDARD, :NEW.OUT_DANGA);   
   END IF;
   
   IF DELETING THEN

       SELECT COUNT(*)
         INTO T_UPDATE_CHK
         FROM DUAL
        WHERE EXISTS (SELECT 'Y'
                        FROM SALE0204
                       WHERE ITEM_ID = :OLD.ITEM_ID);

       IF T_UPDATE_CHK > 0 THEN
           RAISE_APPLICATION_ERROR( -20001, '주문서 테이블에 해당품목이 존재 함으로 삭제할 수 없습니다.' ) ;
       END IF;
	   
	   DELETE FROM SALE0005 WHERE YAK_ID = :OLD.ITEM_ID;

   END IF;


   IF UPDATING AND :NEW.ITEM_ID <> :OLD.ITEM_ID THEN
       SELECT COUNT(*)
         INTO T_UPDATE_CHK
         FROM DUAL
        WHERE EXISTS (SELECT 'Y'
                        FROM SALE0204
                         WHERE ITEM_ID = :OLD.ITEM_ID);

       IF T_UPDATE_CHK > 0 THEN
           RAISE_APPLICATION_ERROR( -20001, '주문서 테이블에 해당품목이 존재 함으로 수정할 수 없습니다.' ) ;
       END IF;
   END IF;

   /*
      2006.02.15
	  품목등록의 종료일자를 입력하면 매출처별 단가등록에서 시행종료일자를 종료일자로 업데이트 한다
	  이때 품목등록에서 입력한 날짜 보다 큰것들만 수정한다
   */
   IF   UPDATING('END_YMD')  THEN
		UPDATE SALE0405
		   SET YMD     = TO_DATE(:NEW.END_YMD,'YYYYMMDD')
		 WHERE ITEM_ID = :NEW.ITEM_ID
		   AND YMD    >= TO_DATE(:NEW.END_YMD,'YYYYMMDD');
   END IF;

   IF   UPDATING('ITEM_NM') OR UPDATING('ITEM_NM1') OR UPDATING('STANDARD') OR UPDATING('OUT_DANGA') THEN
		UPDATE SALE0005
		   SET YAK_NM   = :NEW.ITEM_NM,
		       YAK_NM1  = :NEW.ITEM_NM1,
		       STANDARD = :NEW.STANDARD,
		       AMT      = :NEW.OUT_DANGA
		 WHERE YAK_ID = :OLD.ITEM_ID;
   END IF;

END TB_SALE0004_IUD;
/
