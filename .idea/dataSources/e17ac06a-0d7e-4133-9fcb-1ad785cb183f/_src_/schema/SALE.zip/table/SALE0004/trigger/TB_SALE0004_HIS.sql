CREATE TRIGGER TB_SALE0004_HIS
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0004
FOR EACH ROW
  DECLARE
     T_UPDATE_CHK   NUMBER;
     메시지         varchar2(1000) ;
     
BEGIN
   /* 메시지 처리 준비 */
   if INSERTING then
      메시지 := '제품이력관리(SALE0004H) 추가 불가 !!  ' ;
   elsif UPDATING then
      메시지 := '제품이력관리(SALE0004H) 수정 불가 !!  ' ;
   else
      메시지 := '제품이력관리(SALE0004H) 삭제 불가 !!  ' ;
   end if ;

   /* ********************************************************************* */
   /* 수정될때                                                              */
   /* ********************************************************************* */
   if UPDATING('ITEM_NM')      or
      UPDATING('ITEM_NM1')     or
      UPDATING('ITEM_GB1')     or
      UPDATING('ITEM_GB2')     or
      UPDATING('ITEM_GB3')     or
      UPDATING('ITEM_GB4')     or
      UPDATING('STANDARD')     or
      UPDATING('STANDARD_CD')  or
      UPDATING('UNIT')         or
      UPDATING('DANGA')        or
      UPDATING('IN_DANGA')     or
      UPDATING('DC_DANGA')     or
      UPDATING('DC_RATE')      or
      UPDATING('DC_QTY_RATE')  or
      UPDATING('DC_DANGA2')    or   
      UPDATING('DC_RATE2')     or   
      UPDATING('DC_QTY_RATE2') or   
      UPDATING('USE_YN')       or   
      UPDATING('CHUL_YN')      or   
      UPDATING('VIEW_TXT')     or   
      UPDATING('COLOR')        then
      begin
      
            UPDATE SALE0004H
            SET    ITEM_NM      = :NEW.ITEM_NM,
                   ITEM_NM1     = :NEW.ITEM_NM1,
                   ITEM_GB1     = :NEW.ITEM_GB1,
                   ITEM_GB2     = :NEW.ITEM_GB2,
                   ITEM_GB3     = :NEW.ITEM_GB3,
                   ITEM_GB4     = :NEW.ITEM_GB4,
                   STANDARD     = :NEW.STANDARD,
                   STANDARD_CD  = :NEW.STANDARD_CD,
                   UNIT         = :NEW.UNIT,
                   SAUPJANG_CD  = :NEW.SAUPJANG_CD,
                   DANGA        = :NEW.DANGA,
                   IN_DANGA     = :NEW.IN_DANGA,
                   DC_DANGA     = :NEW.DC_DANGA,
                   DC_RATE      = :NEW.DC_RATE,
                   DC_QTY_RATE  = :NEW.DC_QTY_RATE,
                   DC_DANGA2    = :NEW.DC_DANGA2,
                   DC_RATE2     = :NEW.DC_RATE2,
                   DC_QTY_RATE2 = :NEW.DC_QTY_RATE2,
                   USE_YN       = :NEW.USE_YN,
                   CHUL_YN      = :NEW.CHUL_YN,
                   VIEW_TXT     = :NEW.VIEW_TXT,
                   COLOR        = :NEW.COLOR
            WHERE  ITEM_ID      = :OLD.ITEM_ID ;
      
         exception
            when OTHERS then
                 raise_application_error( -20671, 메시지 ||
                      '사원(SALE0007H) 수정시 ERROR 발생.' ) ;
      end ;
   end if ;

   /* ********************************************************************* */
   /* 추가/수정될때                                                         */
   /* ********************************************************************* */
   if INSERTING               or
      UPDATING('SAUPJANG_CD') or
      UPDATING('OUT_DANGA')   or
      UPDATING('C')           or
      UPDATING('GC')          or
      UPDATING('ETC')         or
      UPDATING('END_YMD')     or
      UPDATING('ITEM_GB1')    or
      UPDATING('STANDARD_CD') or
      UPDATING('END_YMD')     then
      -- ---------------------------------------------------------------------
      -- 내용 : 작업
      --        해당 데이타를 제품이력(SALE0004H) 테이블에 등록한다.
      -- ---------------------------------------------------------------------
      -- 레코드를 추가한다.
      begin
            INSERT INTO SALE0004H ( ITEM_ID, TRAN_YMD_CD, TRAN_DATE, 
                                    APPL_DATE, ITEM_NM, ITEM_NM1, 
                                    PRDT_COMP, STANDARD, UNIT, 
                                    DANGA, IN_DANGA, OUT_DANGA, 
                                    DC_RATE, CUST_ID, PHOTO_PATH, 
                                    ITEM_GB1, ITEM_GB2, ITEM_GB3, 
                                    ITEM_GB4, USE_YN, BIGO, 
                                    BOHEOM_SUGA, YAK_CD, USER_ID, 
                                    INPUT_YMD, DC_DANGA, DC_QTY_RATE, 
                                    VIEW_TXT, DC_DANGA2, DC_RATE2, 
                                    DC_QTY_RATE2, END_YMD, STANDARD_CD, 
                                    SAUPJANG_CD, C, GC, 
                                    ETC, COLOR, CHUL_YN ) 
                           VALUES ( :NEW.ITEM_ID, TO_CHAR(SYSDATE, 'YYYYMMDDHHMISS'), TO_CHAR(SYSDATE, 'YYYYMMDD'),
                                    TO_CHAR(SYSDATE, 'YYYYMMDD'), :NEW.ITEM_NM, :NEW.ITEM_NM1, 
                                   :NEW.PRDT_COMP, :NEW.STANDARD, :NEW.UNIT, 
                                   :NEW.DANGA, :NEW.IN_DANGA, :NEW.OUT_DANGA, 
                                   :NEW.DC_RATE, :NEW.CUST_ID, :NEW.PHOTO_PATH, 
                                   :NEW.ITEM_GB1, :NEW.ITEM_GB2, :NEW.ITEM_GB3, 
                                   :NEW.ITEM_GB4, :NEW.USE_YN, :NEW.BIGO, 
                                   :NEW.BOHEOM_SUGA, :NEW.YAK_CD, :NEW.USER_ID, 
                                   :NEW.INPUT_YMD, :NEW.DC_DANGA, :NEW.DC_QTY_RATE, 
                                   :NEW.VIEW_TXT, :NEW.DC_DANGA2, :NEW.DC_RATE2, 
                                   :NEW.DC_QTY_RATE2, :NEW.END_YMD, :NEW.STANDARD_CD, 
                                   :NEW.SAUPJANG_CD, :NEW.C, :NEW.GC, 
                                   :NEW.ETC, :NEW.COLOR, :NEW.CHUL_YN ) ;        

         exception
            -- 이미 존재하는 경우에는 에러를 발생시킨다.
            when DUP_VAL_ON_INDEX then
                 raise_application_error( -20671, 메시지 ||
                      '중복된 자료가 이미 존재하므로 추가가 불가능함.' ) ;
      end ;

   if UPDATING('OUT_DANGA') then
      BEGIN
      
        UPDATE SALE0405 SET BAS_AMT = :NEW.OUT_DANGA,
                            BAL_AMT = decode(BAL_AMT,0,:NEW.OUT_DANGA,:NEW.OUT_DANGA * (BAL_AMT/BAS_AMT)),
                            YAK_AMT = decode(YAK_AMT,0,:NEW.OUT_DANGA,:NEW.OUT_DANGA * (YAK_AMT/BAS_AMT))
         WHERE ITEM_ID = :OLD.ITEM_ID;
      
         exception
            -- 이미 존재하는 경우에는 에러를 발생시킨다.
            when DUP_VAL_ON_INDEX then
                 raise_application_error( -20671, 메시지 ||
                      '중복된 자료가 이미 존재하므로 추가가 불가능함.' ) ;
      END;
   end if;
      
   /* ********************************************************************* */
   /* 삭제될 때                                                             */
   /* ********************************************************************* */
   elsif DELETING then
      -- ---------------------------------------------------------------------
      -- 내용 : 작업
      --        거래처코드에 대응하는 모든 이력정보를 삭제한다.
      -- ---------------------------------------------------------------------
      begin
         delete SALE0004H
          where ITEM_ID = :OLD.ITEM_ID ;
      end ;
   end if;

END tb_sale0004_HIS;
/
