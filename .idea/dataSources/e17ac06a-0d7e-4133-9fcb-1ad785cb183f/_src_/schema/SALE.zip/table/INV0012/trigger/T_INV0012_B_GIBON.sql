CREATE TRIGGER T_INV0012_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON INV0012
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : INV0012                                                      */
/*  테이블명 : 구매거래처코드                                                */
/*  트리거명 : T_INV0012_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2002.01.16(수)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 수정/삭제시 참조된 자료 존재여부 확인                        */
/*            2. 2002.01.14(월) 구매거래처를 회계팀 통해 회계시스템에 등록하고 */
/*                              추가정보를 동 테이블에서 관리함.              */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(200) ;
   v_message    VARCHAR2(250) ;

   user_err     EXCEPTION     ;
   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'INV0012 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'INV0012 수정 불가 !! ' ;
   ELSE
      v_message := 'INV0012 삭제 불가 !! ' ;
   END IF ;

   IF UPDATING('cust_id') OR DELETING THEN
      v_curr_jakup := '전표 존재여부 확인: ' ;
      SELECT COUNT(*), NVL(MIN(ymd||'-'||slip_no),' ')
        INTO v_count, v_dummy
        FROM INV0301
       WHERE cust_id  = :OLD.cust_id
         AND ROWNUM < 3 ;
      IF v_count > 0 THEN
         v_curr_jakup := '회계거래처 존재여부 확인: ' ;
         SELECT COUNT(*), NVL(MIN(cust_nm),' ')
           INTO v_count, v_nm
           FROM INV0011
          WHERE cust_id  = :OLD.cust_id
            AND ROWNUM < 3 ;

         v_curr_error := '해당 거래처의 입출고전표 자료가 존재하므로 작업이 불가함. 관리자에게 문의바람.=> OLD'||
                         '거래처코드 '||:OLD.cust_id||' '||v_nm||' /전표일자-번호 '||v_dummy ;
         RAISE user_err ;
      END IF ;
   END IF;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
