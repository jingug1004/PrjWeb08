CREATE PROCEDURE          SP_GetBaesongjiGridList 
(
  searchKeyword  in VARCHAR2,
  sidx           in VARCHAR2,
  sord           in VARCHAR2,
  as_cust_id     in VARCHAR2,
  p_rc      out sys_refcursor
)
IS
BEGIN
   OPEN p_rc FOR
     SELECT TO_CHAR(A.SEQ) AS seq
            ,A.ADDRNAME  AS addrname
            ,A.RCVRNAME  AS rcvrname
            ,A.ADDR1     AS addr1
            ,A.TELNO     AS telno
        FROM
       ( SELECT SEQ,ADDRNAME,RCVRNAME,POST,ADDR1,ADDR2,TELNO,USEYN
           FROM oragmp.CMADDRESSM
          WHERE USEYN='Y' AND PLANTCODE ='1000' AND CUSTCODE  = as_cust_id
          UNION ALL
         SELECT 0 AS SEQ,'기본배송지' AS ADDRNAME,'기본배송지' AS RCVRNAME
               ,POST,ADDR1,ADDR2,TELNO,'Y'
           FROM oragmp.CMCUSTM
          WHERE PLANTCODE = '1000' AND CUSTCODE  = as_cust_id
        ) A 
        WHERE A.ADDRNAME LIKE '%'||searchKeyword||'%'
	     ORDER BY sidx||' '||sord
	 ;

  
END SP_GetBaesongjiGridList;
/
