CREATE PROCEDURE          SP_X_UpdateMember_MGMT
( 
  in_custid       in VARCHAR2,
  in_custnm       in VARCHAR2,
  in_yn           in VARCHAR2,
  in_pwd          in VARCHAR2,
  out_CODE       out NUMBER,
  out_MSG        out VARCHAR2
)
IS
    CUST_ID_NULL   EXCEPTION;
BEGIN
    IF in_custid IS NULL OR TRIM(in_custid) = '' THEN
        RAISE CUST_ID_NULL;
    END IF;   

        MERGE INTO ORAGMP.CMCUSTM                           
		   USING DUAL                  
		   ON (CUSTCODE = in_custid)                                  
		   WHEN MATCHED THEN
		      UPDATE
		         SET CUSTNAME = in_custnm
		   WHEN NOT MATCHED THEN
		      INSERT (CUSTCODE, CUSTNAME, SAGODIV)
		      VALUES (in_custid, in_custnm, in_yn);
		            	      
		MERGE INTO ORAGMP.ELECTRONICSIGN                          
		   USING DUAL                  
		   ON (EMPCODE = in_custid)                                  
		   WHEN MATCHED THEN
		      UPDATE
		         SET PWD = in_pwd
		   WHEN NOT MATCHED THEN
		      INSERT (EMPCODE, PWD)
		      VALUES (in_custid, in_pwd);  
		       
    EXCEPTION
    WHEN CUST_ID_NULL THEN
        out_CODE := 102;
        out_MSG := '사원 ID가 누락되었습니다.';
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
    
END;
/
