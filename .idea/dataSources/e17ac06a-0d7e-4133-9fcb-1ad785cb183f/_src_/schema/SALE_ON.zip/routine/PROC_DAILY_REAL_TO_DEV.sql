CREATE PROCEDURE         PROC_DAILY_REAL_TO_DEV IS

       /*-------------------------------------------------------------------
       DESCRIPTION
       변경일자 - 20171201 CHOE
       2번 db를 13번 db와 싱크하기 위한 프로시져
       
       TRADEDATA_TBL 
       
       동기화 진행                    
      -------------------------------------------------------------------*/
        V_CNT1 NUMBER;
        V_CNT2 NUMBER;     

BEGIN 
 
   --TRADEDATA_TBL
   BEGIN  
       insert into TRADEDATA_TBL   
       select * from SALE_ON.TRADEDATA_TBL@REAL_SALE.HANA.CO.KR a
        where tran_date  > to_char(sysdate - 7,'yyyymmdd')
          and not exists (select 'x' from TRADEDATA_TBL where tran_date = a.tran_date and tran_time = a.tran_time and seq_no = a.seq_no)
       ;

   EXCEPTION WHEN OTHERS THEN
       ROLLBACK;       
       insert into RFID_USER.ZPROC_DAILY_COPY_HIST values (TO_CHAR(SYSDATE,'YYYYMMDD'),'SALE_ON','TRADEDATA_TBL',sysdate,'');
       commit;        
       return;
   END;       
    
    
EXCEPTION   
        WHEN OTHERS THEN
            ROLLBACK;        
END  PROC_DAILY_REAL_TO_DEV;
/
