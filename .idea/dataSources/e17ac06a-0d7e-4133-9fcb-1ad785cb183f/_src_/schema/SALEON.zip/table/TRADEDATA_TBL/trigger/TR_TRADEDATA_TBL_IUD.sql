CREATE TRIGGER TR_TRADEDATA_TBL_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON TRADEDATA_TBL
FOR EACH ROW
  DECLARE
     T_MAX          NUMBER;
     T_CNT          NUMBER;
     T_JUNPYO_NO    VARCHAR2(14);
     T_CUST_ID      VARCHAR2(10);
     T_SAWON_ID     VARCHAR2(8);

BEGIN

   /* -------------------------------------------------------------------------
     가상계좌에 자료가 들어오면 실시간으로 수금등록마스터( gmpit.slcolm )에  현금으로 자동입력처리한다.                                         
     -------------------------------------------------------------------------*/ 


   /*------------------------------------------------------------------------  
     신규입력일 경우                                                  
    ------------------------------------------------------------------------ */
   IF INSERTING THEN
      BEGIN      
      
         SELECT LPAD(NVL(MAX(colseq),0)+1,'4','0') INTO T_MAX
           FROM oragmp.SLCOLM A
          WHERE a.coldate = :NEW.DEAL_STAR_DATE;           

         IF T_MAX = 0 THEN
            T_MAX := T_MAX + 1;
         END IF;
         T_JUNPYO_NO := :NEW.DEAL_STAR_DATE||TRIM(TO_CHAR(T_MAX,'0000'));
         
         --거래처코드
         SELECT COUNT(*) INTO T_CNT FROM oragmp.cmcustm WHERE VIRTUALACCOUNT = TRIM(:NEW.CMS_NO);
         IF T_CNT = 0 THEN
            T_CUST_ID := '0000000';
         ELSE
            SELECT custcode INTO T_CUST_ID FROM oragmp.cmcustm WHERE VIRTUALACCOUNT = TRIM(:NEW.CMS_NO);
         END IF;
        
         --담당사원
         SELECT COUNT(*) INTO T_CNT FROM oragmp.cmcustm WHERE custcode = T_CUST_ID;         
         IF T_CNT = 0 THEN
            T_SAWON_ID := '00000';
         ELSE
            SELECT empcode INTO T_SAWON_ID FROM oragmp.cmcustm WHERE custcode = T_CUST_ID;         
         END IF;
         
         INSERT INTO oragmp.slcolm ( colno,plantcode,coldate,colseq,custcode,empcode,ecustcode,colamt)
                            VALUES ( T_JUNPYO_NO
                                    ,'1000'
                                    ,:NEW.DEAL_STAR_DATE
                                    ,TRIM(TO_CHAR(T_MAX,'0000'))
                                    ,T_CUST_ID
                                    ,T_SAWON_ID
                                    ,T_CUST_ID
                                    ,TO_NUMBER(:NEW.TOTAL_AMT)
                                    ) ;                  
                                     
         :NEW.JUNPYO_NO := T_JUNPYO_NO; --수금테이블에 연동된 전표번호를 기록한다.                                       
                           
      EXCEPTION
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, '가상계좌내역 현금수금 자동입금시 INS Err:'||SQLERRM ) ;
      END;
   END IF;

END TR_TRADEDATA_TBL_IUD;
/
