CREATE TRIGGER TR_SALE0203_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0203
FOR EACH ROW
  DECLARE

     T_CNT          NUMBER; 
     T_MAX          NUMBER; 
     T_ORAGMP_ORDERNO    VARCHAR2(14); 

BEGIN

   /* -------------------------------------------------------------------------
     oragmp.slordm 주문마스터 에 insert                                       
     -------------------------------------------------------------------------*/ 


   /*------------------------------------------------------------------------  
     신규                                              
  -------------------------------------------------------------------------- */
   IF INSERTING THEN
         
       
      -- 위반주문+위반주문승인 안된경우 oragmp 주문 마스터에 insert 하면 안됨
      IF :NEW.WIBAN_ORDER_REQ_YN = 'Y' and :NEW.WIBAN_ORDER_CONF_YN <> '1'THEN  
         RETURN;
      END IF;
         
      T_ORAGMP_ORDERNO := '';
      T_MAX := 0;
      
      --주문번호채번  
      SELECT COUNT(*) INTO T_CNT FROM oragmp.slordm A WHERE a.orderdate = to_char(:NEW.ymd,'yyyy-mm-dd');        
      IF T_CNT > 0 THEN 
         SELECT to_number(MAX(SUBSTR(orderno,9,4)))  INTO T_MAX FROM oragmp.slordm A WHERE a.orderdate = to_char(:NEW.ymd,'yyyy-mm-dd');         
      END IF;      
      T_MAX := T_MAX + 1;    
      T_ORAGMP_ORDERNO := to_char(:NEW.ymd,'yyyymmdd')||TRIM(TO_CHAR(T_MAX,'0000'));   
      
      --주문마스터 저장
      BEGIN    
         INSERT INTO oragmp.slordm 
                   (PLANTCODE
                   ,ORDERNO
                   ,ORDERDATE
                   ,ORDERSEQ
                   ,SALDIV
                   ,DATADIV
                   ,ORDERDIV
                   ,OUTPUTDIV
                   ,TRANSFERDIV
                   ,CUSTCODE
                   ,DEPTCODE
                   ,EMPCODE
                   ,ECUSTCODE
                   ,EDEPTCODE
                   ,EEMPCODE
                   ,UTDIV
                   ,EUTDIV
                   ,BNORDERNO
                   ,TAXDATE
                   ,TRADEDATE
                   ,TAXMANAGEDATE
                   ,TRADEMANAGEDATE
                   ,FIXDATE
                   ,FIXSEQ
                   ,CREDITCK
                   ,SAGOCK
                   ,LOANLMTCK
                   ,BALANCELMTCK
                   ,NOCOLLMTCK
                   ,SECURITYLMTCK
                   ,AVGAMTLMTCK
                   ,SAMPCK
                   ,TURNLMTCK
                   ,APPDATE
                   ,YYMM
                   ,STATEDIV
                   ,REMARK
                   ,BIGO
                   ,PDA
                   ,WAREHOUSE
                   ,APPRSTATUS
                   ,MONEYCODE
                   ,EXRTRATE
                   ,INSERTDT
                   ,IEMPCODE
                   ,UPDATEDT
                   ,UEMPCODE
                   ,RECHK
                   ,SENDDT
                   ,SENDEMP
                   ,SENDSEQ
                   ,SENDYN
                   ,SUPPLYDIV
                   ,TRANADDR1
                   ,TRANADDR2
                   ,TRANADDRB1
                   ,TRANADDRB2
                   ,TRANPOST
                   ,TRANPOSTB
                   ,EMAILSENDYN
                   ,ADDRSEQ
                   ,OFFERNO
                   ,EXDOCUNO
                   ,LCNO
                   ,BLNO
                   ,ORDERKIND
                   ,CLEANDATE
                   ,CLEANSEQ
                   ,DOMAEOUTGB
                   ) 
           VALUES (
                    '1000'                                                                --PLANTCODE         사업장
                   ,T_ORAGMP_ORDERNO                                                           --ORDERNO           주문번호
                   ,TO_CHAR(TO_DATE(SUBSTR(T_ORAGMP_ORDERNO,1,8),'YYYYMMDD'),'YYYY-MM-DD')     --ORDERDATE         주문일자
                   ,SUBSTR(T_ORAGMP_ORDERNO,9,4)                                               --ORDERSEQ          주문일련번호                   
                   ,'A01'                                                                 --SALDIV            영업구분 A01 판매
                   ,CASE WHEN :NEW.CUST_ID = :NEW.RCUST_ID THEN '11' ELSE '12' END        --DATADIV           자료구분 11:직납,12:간납 
                   ,CASE WHEN :NEW.CUST_ID = :NEW.RCUST_ID THEN '4'  ELSE '4'  END        --ORDERDIV          영업영역 3:간납,4:직납
                   ,'1'                                                                   --OUTPUTDIV         출하구분 1:택배 2:직배
                   ,'1'                                                                   --TRANSFERDIV       배송구분 1:거래선착
                   ,:NEW.CUST_ID                                                          --CUSTCODE          거래처코드
                   ,(select deptcode from oragmp.cmempm where plantcode = '1000' and empcode = :NEW.SAWON_ID ) --DEPTCODE          담당자부서코드
                   ,:NEW.SAWON_ID                                                         --EMPCODE           담당자사번
                   ,:NEW.RCUST_ID                                                         --ECUSTCODE         간납처코드
                   ,(select deptcode from oragmp.cmempm where plantcode = '1000' and empcode = :NEW.RSAWON_ID ) --EDEPTCODE         영업소(간납) 
                   ,:NEW.RSAWON_ID                                                        --EEMPCODE          담당자(간납) 
                   ,''                                                                    --UTDIV             거래처유통구분
                   ,''                                                                    --EUTDIV            간납처유통구분
                   ,''                                                                    --BNORDERNO         상계주문번호(출하번호)
                   ,TO_CHAR(:NEW.YMD)                                                     --TAXDATE           세금계산서 발행일자
                   ,''                                                                    --TRADEDATE         거래명세서 발행일자
                   ,''                                                                    --TAXMANAGEDATE     세금계산서 ..일자
                   ,''                                                                    --TRADEMANAGEDATE   세금계산서 ..일자
                   ,TO_CHAR(TO_DATE(SUBSTR(:NEW.GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM-DD')  --FIXDATE           주문확정일자
                   ,SUBSTR(:NEW.GUMAE_NOT,9,4)                                            --FIXSEQ            주문확정차수
                   ,'N'                                                                   --CREDITCK          신용불량
                   ,'N'                                                                   --SAGOCK            사고처
                   ,'N'                                                                   --LOANLMTCK         여신한도
                   ,'N'                                                                   --BALANCELMTCK      잔고한다
                   ,'N'                                                                   --NOCOLLMTCK        무수금한도
                   ,'N'                                                                   --SECURITYLMTCK     담보가치한도
                   ,'N'                                                                   --AVGAMTLMTCK       평균만패금한도
                   ,'N'                                                                   --SAMPCK            샘플출고체크
                   ,'N'                                                                   --TURNLMTCK         회전일한도
                   ,TO_CHAR(TO_DATE(SUBSTR(:NEW.GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM-DD')  --APPDATE           출고일자
                   ,TO_CHAR(TO_DATE(SUBSTR(:NEW.GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM')     --YYMM              출고년월
                   ,CASE :NEW.SLIP_GB WHEN '1' THEN '01' WHEN '2' THEN '20' END           --STATEDIV          주문서확정구분  01:정상,03:채권불량,09:매출확정
                   ,:NEW.BIGO                                                             --REMARK            비고1
                   ,''                                                                    --BIGO              비고2
                   ,''                                                                    --PDA               PDA여부
                   ,'001'                                                                 --WAREHOUSE         창고구분
                   ,'01'                                                                  --APPRSTATUS        진행상태 01:입력
                   ,''                                                                    --MONEYCODE         화폐구분
                   ,''                                                                    --EXRTRATE          
                   ,:NEW.INPUT_YMD                                                        --INSERTDT          입력일자
                   ,:NEW.INPUT_ID                                                         --IEMPCODE          입력사번
                   ,''                                                                    --UPDATEDT          변경일자
                   ,''                                                                    --UEMPCODE          변경사번
                   ,''                                                                    --RECHK             
                   ,''                                                                    --SENDDT            
                   ,''                                                                    --SENDEMP           
                   ,''                                                                    --SENDSEQ           
                   ,''                                                                    --SENDYN            BTS자료전송여부        
                   ,''                                                                    --SUPPLYDIV         공급구분
                   ,''                                                                    --TRANADDR1         
                   ,''                                                                    --TRANADDR2         
                   ,''                                                                    --TRANADDRB1        
                   ,''                                                                    --TRANADDRB2        
                   ,''                                                                    --TRANPOST          
                   ,''                                                                    --TRANPOSTB         
                   ,''                                                                    --EMAILSENDYN       
                   ,''                                                                    --ADDRSEQ           배송지선택번호
                   ,''                                                                    --OFFERNO           Offer번호
                   ,''                                                                    --EXDOCUNO          수출전표번호
                   ,''                                                                    --LCNO              LC번호
                   ,''                                                                    --BLNO              BL번호
                   ,CASE :NEW.SLIP_GB WHEN '1' THEN '10' WHEN '2' THEN '20' END           --ORDERKIND         주문매체종류   10:온라인 20:SFA 30:ERP
                   ,''                                                                    --CLEANDATE         매출할인일자
                   ,0                                                                     --CLEANSEQ          매출할인일자작업순번
                   ,''                                                                    --DOMAEOUTGB        도매구분                      
                                               
                   ) ;                                   
                                     
         :NEW.ORDERNO := T_ORAGMP_ORDERNO; --주문 테이블에 연동된 전표번호를 기록한다.                                       
                           
      EXCEPTION
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, 'SALEON 주문마스터 신규 트리거 oragmp.slordm insert: '||T_ORAGMP_ORDERNO||'/'||SQLERRM ) ;
      END;
   END IF;
   
   
   
   /*------------------------------------------------------------------------  
     수정                                              
  -------------------------------------------------------------------------- */
   IF UPDATING THEN
      
      --oragmp 에 주문서 생성되어 있으면 update
      IF :NEW.ORDERNO IS NOT NULL THEN      
          
          BEGIN
              UPDATE oragmp.slordm 
                 SET BIGO = BIGO
               WHERE PLANTCODE = '1000'
                 AND ORDERNO   = :NEW.ORDERNO;                                   
                           
          EXCEPTION
                  WHEN OTHERS THEN
                       RAISE_APPLICATION_ERROR( -20001, 'SALEON 주문마스터 수정 트리거 oragmp.slordm update: '||:NEW.ORDERNO||'/'||SQLERRM ) ;
          END;
          
      
      ELSE
      
          --위반주문 인데 승인이 안된경우 주문생성되면 안됨.
          IF :NEW.WIBAN_ORDER_REQ_YN = 'Y' and :NEW.WIBAN_ORDER_CONF_YN <> '1'THEN  
             RETURN;
          END IF;
           
          T_ORAGMP_ORDERNO := '';
          T_MAX := 0;
          --주문번호채번  
          SELECT COUNT(*) INTO T_CNT FROM oragmp.slordm A WHERE a.orderdate = to_char(:NEW.ymd,'yyyy-mm-dd');        
          IF T_CNT > 0 THEN 
             SELECT to_number(MAX(SUBSTR(orderno,9,4)))  INTO T_MAX FROM oragmp.slordm A WHERE a.orderdate = to_char(:NEW.ymd,'yyyy-mm-dd');                 
          END IF;        
         T_MAX := T_MAX + 1;    
         T_ORAGMP_ORDERNO := to_char(:NEW.ymd,'yyyymmdd')||TRIM(TO_CHAR(T_MAX,'0000'));   
                  
          --주문마스터 저장
          BEGIN    
             INSERT INTO oragmp.slordm 
                       (PLANTCODE
                       ,ORDERNO
                       ,ORDERDATE
                       ,ORDERSEQ
                       ,SALDIV
                       ,DATADIV
                       ,ORDERDIV
                       ,OUTPUTDIV
                       ,TRANSFERDIV
                       ,CUSTCODE
                       ,DEPTCODE
                       ,EMPCODE
                       ,ECUSTCODE
                       ,EDEPTCODE
                       ,EEMPCODE
                       ,UTDIV
                       ,EUTDIV
                       ,BNORDERNO
                       ,TAXDATE
                       ,TRADEDATE
                       ,TAXMANAGEDATE
                       ,TRADEMANAGEDATE
                       ,FIXDATE
                       ,FIXSEQ
                       ,CREDITCK
                       ,SAGOCK
                       ,LOANLMTCK
                       ,BALANCELMTCK
                       ,NOCOLLMTCK
                       ,SECURITYLMTCK
                       ,AVGAMTLMTCK
                       ,SAMPCK
                       ,TURNLMTCK
                       ,APPDATE
                       ,YYMM
                       ,STATEDIV
                       ,REMARK
                       ,BIGO
                       ,PDA
                       ,WAREHOUSE
                       ,APPRSTATUS
                       ,MONEYCODE
                       ,EXRTRATE
                       ,INSERTDT
                       ,IEMPCODE
                       ,UPDATEDT
                       ,UEMPCODE
                       ,RECHK
                       ,SENDDT
                       ,SENDEMP
                       ,SENDSEQ
                       ,SENDYN
                       ,SUPPLYDIV
                       ,TRANADDR1
                       ,TRANADDR2
                       ,TRANADDRB1
                       ,TRANADDRB2
                       ,TRANPOST
                       ,TRANPOSTB
                       ,EMAILSENDYN
                       ,ADDRSEQ
                       ,OFFERNO
                       ,EXDOCUNO
                       ,LCNO
                       ,BLNO
                       ,ORDERKIND
                       ,CLEANDATE
                       ,CLEANSEQ
                       ,DOMAEOUTGB
                       ) 
               VALUES (
                        '1000'                                                                --PLANTCODE         사업장
                       ,T_ORAGMP_ORDERNO                                                           --ORDERNO           주문번호
                       ,TO_CHAR(TO_DATE(SUBSTR(T_ORAGMP_ORDERNO,1,8),'YYYYMMDD'),'YYYY-MM-DD')     --ORDERDATE         주문일자
                       ,SUBSTR(T_ORAGMP_ORDERNO,9,4)                                               --ORDERSEQ          주문일련번호                   
                       ,'A01'                                                                 --SALDIV            영업구분 A01 판매
                       ,CASE WHEN :NEW.CUST_ID = :NEW.RCUST_ID THEN '11' ELSE '12' END        --DATADIV           자료구분 11:직납,12:간납 
                       ,CASE WHEN :NEW.CUST_ID = :NEW.RCUST_ID THEN '4'  ELSE '4'  END        --ORDERDIV          영업영역 3:간납,4:직납
                       ,'1'                                                                   --OUTPUTDIV         출하구분 1:택배 2:직배
                       ,'1'                                                                   --TRANSFERDIV       배송구분 1:거래선착
                       ,:NEW.CUST_ID                                                          --CUSTCODE          거래처코드
                       ,(select deptcode from oragmp.cmempm where plantcode = '1000' and empcode = :NEW.SAWON_ID ) --DEPTCODE          담당자부서코드
                       ,:NEW.SAWON_ID                                                         --EMPCODE           담당자사번
                       ,:NEW.RCUST_ID                                                         --ECUSTCODE         간납처코드
                       ,(select deptcode from oragmp.cmempm where plantcode = '1000' and empcode = :NEW.RSAWON_ID ) --EDEPTCODE         영업소(간납) 
                       ,:NEW.RSAWON_ID                                                        --EEMPCODE          담당자(간납) 
                       ,''                                                                    --UTDIV             거래처유통구분
                       ,''                                                                    --EUTDIV            간납처유통구분
                       ,''                                                                    --BNORDERNO         상계주문번호(출하번호)
                       ,TO_CHAR(:NEW.YMD)                                                     --TAXDATE           세금계산서 발행일자
                       ,''                                                                    --TRADEDATE         거래명세서 발행일자
                       ,''                                                                    --TAXMANAGEDATE     세금계산서 ..일자
                       ,''                                                                    --TRADEMANAGEDATE   세금계산서 ..일자
                       ,TO_CHAR(TO_DATE(SUBSTR(:NEW.GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM-DD')  --FIXDATE           주문확정일자
                       ,SUBSTR(:NEW.GUMAE_NOT,9,4)                                            --FIXSEQ            주문확정차수
                       ,'N'                                                                   --CREDITCK          신용불량
                       ,'N'                                                                   --SAGOCK            사고처
                       ,'N'                                                                   --LOANLMTCK         여신한도
                       ,'N'                                                                   --BALANCELMTCK      잔고한다
                       ,'N'                                                                   --NOCOLLMTCK        무수금한도
                       ,'N'                                                                   --SECURITYLMTCK     담보가치한도
                       ,'N'                                                                   --AVGAMTLMTCK       평균만패금한도
                       ,'N'                                                                   --SAMPCK            샘플출고체크
                       ,'N'                                                                   --TURNLMTCK         회전일한도
                       ,TO_CHAR(TO_DATE(SUBSTR(:NEW.GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM-DD')  --APPDATE           출고일자
                       ,TO_CHAR(TO_DATE(SUBSTR(:NEW.GUMAE_NOT,1,8),'YYYYMMDD'),'YYYY-MM')     --YYMM              출고년월
                       ,CASE :NEW.SLIP_GB WHEN '1' THEN '01' WHEN '2' THEN '20' END           --STATEDIV          주문서확정구분  01:정상,03:채권불량,09:매출확정
                       ,:NEW.BIGO                                                             --REMARK            비고1
                       ,''                                                                    --BIGO              비고2
                       ,''                                                                    --PDA               PDA여부
                       ,'001'                                                                 --WAREHOUSE         창고구분
                       ,'01'                                                                  --APPRSTATUS        진행상태 01:입력
                       ,''                                                                    --MONEYCODE         화폐구분
                       ,''                                                                    --EXRTRATE          
                       ,:NEW.INPUT_YMD                                                        --INSERTDT          입력일자
                       ,:NEW.INPUT_ID                                                         --IEMPCODE          입력사번
                       ,''                                                                    --UPDATEDT          변경일자
                       ,''                                                                    --UEMPCODE          변경사번
                       ,''                                                                    --RECHK             
                       ,''                                                                    --SENDDT            
                       ,''                                                                    --SENDEMP           
                       ,''                                                                    --SENDSEQ           
                       ,''                                                                    --SENDYN            BTS자료전송여부        
                       ,''                                                                    --SUPPLYDIV         공급구분
                       ,''                                                                    --TRANADDR1         
                       ,''                                                                    --TRANADDR2         
                       ,''                                                                    --TRANADDRB1        
                       ,''                                                                    --TRANADDRB2        
                       ,''                                                                    --TRANPOST          
                       ,''                                                                    --TRANPOSTB         
                       ,''                                                                    --EMAILSENDYN       
                       ,''                                                                    --ADDRSEQ           배송지선택번호
                       ,''                                                                    --OFFERNO           Offer번호
                       ,''                                                                    --EXDOCUNO          수출전표번호
                       ,''                                                                    --LCNO              LC번호
                       ,''                                                                    --BLNO              BL번호
                       ,CASE :NEW.SLIP_GB WHEN '1' THEN '10' WHEN '2' THEN '20' END           --ORDERKIND         주문매체종류   10:온라인 20:SFA 30:ERP
                       ,''                                                                    --CLEANDATE         매출할인일자
                       ,0                                                                     --CLEANSEQ          매출할인일자작업순번
                       ,''                                                                    --DOMAEOUTGB        도매구분                      
                                                           
                       ) ;      
                               
            :NEW.ORDERNO := T_ORAGMP_ORDERNO; --주문 테이블에 연동된 전표번호를 기록한다.   
                                   
          EXCEPTION WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR( -20001, 'SALEON 주문마스터 수정 트리거 oragmp.slordm insert: '||T_ORAGMP_ORDERNO||'/'||SQLERRM ) ;
          END;
                  

          --주문상세 저장
          BEGIN
                 
              INSERT INTO ORAGMP.SLORDD
                       (ORDERNO
                       ,PLANTCODE
                       ,SEQ
                       ,ORDERDATE
                       ,ORDERSEQ
                       ,ITEMCODE
                       ,SALQTY
                       ,GIVQTY
                       ,BONUSQTY
                       ,DRUGPRC
                       ,DRUGAMT
                       ,MAKINGCOST
                       ,EXRTPRC
                       ,EXRTAMT
                       ,SALPRC
                       ,SALAMT
                       ,SALVAT
                       ,TOTAMT
                       ,BEFAMT
                       ,AFTAMT
                       ,INCAMT
                       ,TOTDISCOUNT
                       ,GIVRATE
                       ,BEFRATE
                       ,AFTRATE
                       ,INCRATE
                       ,SALPRC1
                       ,SALAMT1
                       ,SALVAT1
                       ,TOTAMT1
                       ,CUSTPRTYN
                       ,OUTPUTQTY
                       ,RECALLDIV
                       ,ABSYN
                       ,PIECEYN
                       ,ENURIYN
                       ,JUORDNO
                       ,BPQTY
                       ,LOTNO
                       ,EXPDATE
                       ,INSERTDT
                       ,IEMPCODE
                       ,UPDATEDT
                       ,UEMPCODE
                       ,AVGQTY
                       ,AVGQTYLMTCK
                       ,LOTDATE
                       ,PIECEQTY
                       ,REALOUTQTY
                       ,SUPPLYDIV
                       ,EMPCODE
                       ,ORDQTYBSUNIT
                       ,OUTPROTYN
                       ,MPLANTCODE
                       ,UNITDIV
                       ,PAIDYN
                       )          
             SELECT 
                    T_ORAGMP_ORDERNO                                                           --ORDERNO              주문번호
                   ,'1000'                                                                      --PLANTCODE            사업장
                   ,TO_NUMBER(INPUT_SEQ)                                                        --SEQ                  일련번호
                   ,TO_CHAR(TO_DATE(SUBSTR(T_ORAGMP_ORDERNO,1,8),'YYYYMMDD'),'YYYY-MM-DD')     --ORDERDATE            주문일자
                   ,SUBSTR(T_ORAGMP_ORDERNO,9.4)                                               --ORDERSEQ             주문일련번호
                   ,ITEM_ID                                                                     --ITEMCODE             제품코드
                   ,QTY                                                                         --SALQTY               매수량
                   ,DC_QTY                                                                      --GIVQTY               증품(할증)수량
                   ,0                                                                           --BONUSQTY             추가증품수량
                   ,0                                                                           --DRUGPRC              기준가
                   ,0                                                                           --DRUGAMT              기준금액
                   ,0                                                                           --MAKINGCOST           제조원가
                   ,0                                                                           --EXRTPRC              -
                   ,0                                                                           --EXRTAMT              -
                   ,DANGA                                                                       --SALPRC               단가
                   ,AMT                                                                         --SALAMT               매출액
                   ,VAT                                                                         --SALVAT               부가세
                   ,AMT + VAT                                                                   --TOTAMT               매출합계
                   ,0                                                                           --BEFAMT               사전
                   ,0                                                                           --AFTAMT               사후
                   ,0                                                                           --INCAMT               수수료
                   ,0                                                                           --TOTDISCOUNT          총할인
                   ,DC_DANGA                                                                    --GIVRATE              할증비율
                   ,0                                                                           --BEFRATE              사전비율
                   ,0                                                                           --AFTRATE              사후비율
                   ,0                                                                           --INCRATE              수수료비율
                   ,0                                                                           --SALPRC1              출하단가1
                   ,0                                                                           --SALAMT1              공급가액1
                   ,0                                                                           --SALVAT1              부가세1
                   ,0                                                                           --TOTAMT1              총금액1
                   ,'Y'                                                                         --CUSTPRTYN            거래장출력여부
                   ,QTY                                                                         --OUTPUTQTY            출하수량
                   ,''                                                                          --RECALLDIV            반품유형
                   ,'N'                                                                         --ABSYN                품절여부
                   ,'N'                                                                         --PIECEYN              낱알여부
                   ,''                                                                          --ENURIYN              매출할인정리구분
                   ,''                                                                          --JUORDNO              -
                   ,''                                                                          --BPQTY                -
                   ,''                                                                          --LOTNO                제조번호
                   ,''                                                                          --EXPDATE              유효기간
                   ,SYSDATE                                                                     --INSERTDT             입력일자
                   ,'cvs'                                                                       --IEMPCODE             입력자 사번
                   ,''                                                                          --UPDATEDT             수정일자
                   ,''                                                                          --UEMPCODE             수정자 사번
                   ,0                                                                           --AVGQTY               평균수량
                   ,''                                                                          --AVGQTYLMTCK
                   ,''                                                                          --LOTDATE              제조일자
                   ,0                                                                           --PIECEQTY
                   ,''                                                                          --REALOUTQTY
                   ,''                                                                          --SUPPLYDIV            공급구분
                   ,''                                                                          --EMPCODE              담당자 사번
                   ,0                                                                           --ORDQTYBSUNIT         주문수량배수단위
                   ,'N'                                                                         --OUTPROTYN            퇴장방지여부
                   ,''                                                                          --MPLANTCODE           관리사업장
                   ,''                                                                          --UNITDIV              수출품목단위
                   ,'N'                                                                         --PAIDYN               급여/비급여구분
              FROM SALEON.SALE0204
             WHERE GUMAE_NO = :NEW.GUMAE_NO; 
          
          EXCEPTION WHEN OTHERS THEN
                    RAISE_APPLICATION_ERROR( -20001, 'SALEON 주문마스터 수정 트리거 oragmp.slordd insert: '||T_ORAGMP_ORDERNO||'/'||SQLERRM ) ;
          END;

                  
      END IF;     
                  
   END IF;   
   
   
   /*------------------------------------------------------------------------  
     삭제                                              
  -------------------------------------------------------------------------- */
   IF DELETING THEN
      
      --oragmp 에 주문서 생성되어 있으면 update
      IF :OLD.ORDERNO IS NOT NULL THEN      
          
          BEGIN
              DELETE oragmp.slordm
               WHERE PLANTCODE = '1000'
                 AND ORDERNO   = :OLD.ORDERNO;                  
                           
          EXCEPTION
                  WHEN OTHERS THEN
                       RAISE_APPLICATION_ERROR( -20001, 'SALEON 주문마스터 삭제 트리거 oragmp.slordm delete: '||T_ORAGMP_ORDERNO||'/'||SQLERRM ) ;
          END;
          
      
      END IF;

   END IF;

END tr_sale0203_IUD;
/
