CREATE TRIGGER TR_SALE0204_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0204
FOR EACH ROW
  DECLARE 
     T_ORAGMP_ORDERNO VARCHAR2(20);

BEGIN

   /* -------------------------------------------------------------------------
     oragmp.slordm 주문마스터 에 insert                                       
     -------------------------------------------------------------------------*/ 


   /*------------------------------------------------------------------------  
     신규                                               
  -------------------------------------------------------------------------- */
   IF INSERTING THEN
      
      --oragmp 주문번호를 찾는다.
      SELECT ORDERNO INTO T_ORAGMP_ORDERNO FROM SALEON.SALE0203 WHERE GUMAE_NO = :NEW.GUMAE_NO; 
      IF T_ORAGMP_ORDERNO IS NULL THEN
         RETURN;
      END IF; 
      
      BEGIN        
      
          INSERT INTO ORAGMP.SLORDD
                   (ORDERNO
                   ,PLANTCODE
                   ,SEQ
                   ,ORDERDATE
                   ,ORDERSEQ
                   ,ITEMCODE
                   ,SALQTY
                   ,GIVQTY
                   ,BONUSQTY
                   ,DRUGPRC
                   ,DRUGAMT
                   ,MAKINGCOST
                   ,EXRTPRC
                   ,EXRTAMT
                   ,SALPRC
                   ,SALAMT
                   ,SALVAT
                   ,TOTAMT
                   ,BEFAMT
                   ,AFTAMT
                   ,INCAMT
                   ,TOTDISCOUNT
                   ,GIVRATE
                   ,BEFRATE
                   ,AFTRATE
                   ,INCRATE
                   ,SALPRC1
                   ,SALAMT1
                   ,SALVAT1
                   ,TOTAMT1
                   ,CUSTPRTYN
                   ,OUTPUTQTY
                   ,RECALLDIV
                   ,ABSYN
                   ,PIECEYN
                   ,ENURIYN
                   ,JUORDNO
                   ,BPQTY
                   ,LOTNO
                   ,EXPDATE
                   ,INSERTDT
                   ,IEMPCODE
                   ,UPDATEDT
                   ,UEMPCODE
                   ,AVGQTY
                   ,AVGQTYLMTCK
                   ,LOTDATE
                   ,PIECEQTY
                   ,REALOUTQTY
                   ,SUPPLYDIV
                   ,EMPCODE
                   ,ORDQTYBSUNIT
                   ,OUTPROTYN
                   ,MPLANTCODE
                   ,UNITDIV
                   ,PAIDYN
                   )
           VALUES (
                     T_ORAGMP_ORDERNO                                                           --ORDERNO              주문번호
                   ,'1000'                                                                      --PLANTCODE            사업장
                   ,TO_NUMBER(:NEW.INPUT_SEQ)                                                   --SEQ                  일련번호
                   ,TO_CHAR(TO_DATE(SUBSTR(T_ORAGMP_ORDERNO,1,8),'YYYYMMDD'),'YYYY-MM-DD')      --ORDERDATE            주문일자
                   ,SUBSTR(T_ORAGMP_ORDERNO,9.4)                                                --ORDERSEQ             주문일련번호
                   ,:NEW.ITEM_ID                                                                --ITEMCODE             제품코드
                   ,:NEW.QTY                                                                    --SALQTY               매수량
                   ,:NEW.DC_QTY                                                                 --GIVQTY               증품(할증)수량
                   ,0                                                                           --BONUSQTY             추가증품수량
                   ,0                                                                           --DRUGPRC              기준가
                   ,0                                                                           --DRUGAMT              기준금액
                   ,0                                                                           --MAKINGCOST           제조원가
                   ,0                                                                           --EXRTPRC              -
                   ,0                                                                           --EXRTAMT              -
                   ,:NEW.DANGA                                                                  --SALPRC               단가
                   ,:NEW.AMT                                                                    --SALAMT               매출액
                   ,:NEW.VAT                                                                    --SALVAT               부가세
                   ,:NEW.AMT + :NEW.VAT                                                         --TOTAMT               매출합계
                   ,0                                                                           --BEFAMT               사전
                   ,0                                                                           --AFTAMT               사후
                   ,0                                                                           --INCAMT               수수료
                   ,0                                                                           --TOTDISCOUNT          총할인
                   ,:NEW.DC_DANGA                                                               --GIVRATE              할증비율
                   ,0                                                                           --BEFRATE              사전비율
                   ,0                                                                           --AFTRATE              사후비율
                   ,0                                                                           --INCRATE              수수료비율
                   ,0                                                                           --SALPRC1              출하단가1
                   ,0                                                                           --SALAMT1              공급가액1
                   ,0                                                                           --SALVAT1              부가세1
                   ,0                                                                           --TOTAMT1              총금액1
                   ,'Y'                                                                         --CUSTPRTYN            거래장출력여부
                   ,:NEW.QTY                                                                    --OUTPUTQTY            출하수량
                   ,''                                                                          --RECALLDIV            반품유형
                   ,'N'                                                                         --ABSYN                품절여부
                   ,'N'                                                                         --PIECEYN              낱알여부
                   ,''                                                                          --ENURIYN              매출할인정리구분
                   ,''                                                                          --JUORDNO              -
                   ,''                                                                          --BPQTY                -
                   ,''                                                                          --LOTNO                제조번호
                   ,''                                                                          --EXPDATE              유효기간
                   ,SYSDATE                                                                     --INSERTDT             입력일자
                   ,'cvs'                                                                       --IEMPCODE             입력자 사번
                   ,''                                                                          --UPDATEDT             수정일자
                   ,''                                                                          --UEMPCODE             수정자 사번
                   ,0                                                                           --AVGQTY               평균수량
                   ,''                                                                          --AVGQTYLMTCK
                   ,''                                                                          --LOTDATE              제조일자
                   ,0                                                                           --PIECEQTY
                   ,''                                                                          --REALOUTQTY
                   ,''                                                                          --SUPPLYDIV            공급구분
                   ,''                                                                          --EMPCODE              담당자 사번
                   ,0                                                                           --ORDQTYBSUNIT         주문수량배수단위
                   ,'N'                                                                         --OUTPROTYN            퇴장방지여부
                   ,''                                                                          --MPLANTCODE           관리사업장
                   ,''                                                                          --UNITDIV              수출품목단위
                   ,'N'                                                                         --PAIDYN               급여/비급여구분
                 );
                           
      EXCEPTION
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, 'SALEON 주문상세 신규 트리거 oragmp.slordd insert: '||T_ORAGMP_ORDERNO||'/'||SQLERRM ) ;
      END;
   END IF;
   
   
   
   /*------------------------------------------------------------------------  
    수정                                                  
  -------------------------------------------------------------------------- */
   IF UPDATING THEN      
      
      --oragmp 주문번호를 찾는다.
      SELECT ORDERNO INTO T_ORAGMP_ORDERNO FROM SALEON.SALE0203 WHERE GUMAE_NO = :NEW.GUMAE_NO; 
      IF T_ORAGMP_ORDERNO IS NULL THEN
         RETURN;
      ELSE
      
          BEGIN        
             UPDATE ORAGMP.SLORDD
                SET ITEMCODE = :NEW.ITEM_ID
                   ,SALQTY   = :NEW.QTY
                   ,GIVQTY   = :NEW.DC_QTY 
              WHERE PLANTCODE = '1000'
                AND ORDERNO   = T_ORAGMP_ORDERNO
                AND SEQ       = TO_NUMBER(:NEW.INPUT_SEQ) ;
     
          EXCEPTION
                  WHEN OTHERS THEN
                       RAISE_APPLICATION_ERROR( -20001, 'SALEON 주문상세 수정 트리거 oragmp.slordd update: '||T_ORAGMP_ORDERNO||'/'||SQLERRM ) ;
          END;
          
      END IF;      
          
   END IF;   


   
   
   
   /*------------------------------------------------------------------------  
     삭제                                              
  -------------------------------------------------------------------------- */
   IF DELETING THEN 

      --oragmp 주문번호를 찾는다.
      SELECT ORDERNO INTO T_ORAGMP_ORDERNO FROM SALEON.SALE0203 WHERE GUMAE_NO = :OLD.GUMAE_NO; 
      IF T_ORAGMP_ORDERNO IS NULL THEN
         RETURN;
      ELSE
      
          BEGIN        
             DELETE FROM ORAGMP.SLORDD
              WHERE PLANTCODE = '1000'
                AND ORDERNO   = T_ORAGMP_ORDERNO
                AND SEQ       = TO_NUMBER(:OLD.INPUT_SEQ) ;
     
          EXCEPTION
                  WHEN OTHERS THEN
                       RAISE_APPLICATION_ERROR( -20001, 'SALEON 주문상세 삭제 트리거 oragmp.slordd delete: '||T_ORAGMP_ORDERNO||'/'||SQLERRM ) ;
          END;
          
      END IF;      
        
          
   END IF;              

END tr_sale0204_IUD;
/
