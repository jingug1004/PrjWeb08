CREATE PROCEDURE          SP_X_CustOrderTotal
( 
  ls_ymdFr        in VARCHAR2,
  ls_ymdTo        in VARCHAR2,
  ls_custId       in VARCHAR2,
  p_rc           out sys_refcursor
)
IS
BEGIN
   
   OPEN p_rc FOR
     SELECT  MAX(YMD) YMD, '99' MONTH, SUM(AMT_SUM + VAT_SUM) AS TOTAL_AMT
     	FROM SALE.SALE0207 A                                                            
    	WHERE YMD BETWEEN ls_ymdFr AND ls_ymdTo                                     
      	AND CUST_ID = ls_custId 
        ;
END;
/
