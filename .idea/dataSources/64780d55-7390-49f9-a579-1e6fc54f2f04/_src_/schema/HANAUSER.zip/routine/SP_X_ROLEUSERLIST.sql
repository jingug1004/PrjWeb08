CREATE PROCEDURE          SP_X_RoleUserList
(
  ls_roleNo       in VARCHAR2,
  sidx            in VARCHAR2,
  sord            in VARCHAR2,
  p_rc           out sys_refcursor
)
IS
BEGIN
      
    OPEN p_rc FOR 
    SELECT   A.ROLE_NO AS ROLE_NO, '' AS DEPT_CODE, '' AS DEPT_NAME,
             A.EMP_CODE AS EMP_CODE, B.CUSTNAME AS EMP_NAME
            FROM SALE_ON.PF_USERROLE_DEV A, ORAGMP.CMCUSTM B
           WHERE A.EMP_CODE = B.CUSTCODE
             AND A.ROLE_NO = ls_roleNo 
             AND B.CUSTCODE LIKE '11%' 
             AND B.SAGODIV <> '2'
         UNION 
 		SELECT ROLE_NO, DEPT_CODE, DEPT_NAME, EMP_CODE, EMP_NAME
          FROM (SELECT C.ROLE_NO, B.EMPCODE AS EMP_CODE,
                       B.EMPNAME AS EMP_NAME, B.DEPTCODE AS DEPT_CD
                  FROM ORAGMP.CMEMPM B, SALE_ON.PF_USERROLE_DEV C 
                 WHERE B.OUTYN = 'Y'
                   AND B.EMPCODE = C.EMP_CODE
                   AND C.ROLE_NO = ls_roleNo ) AA,
               (SELECT DEPTCODE AS DEPT_CODE, DEPTNAME AS DEPT_NAME
                  FROM ORAGMP.CMDEPTM
                 WHERE USEYN='Y') BB
            WHERE AA.DEPT_CD = BB.DEPT_CODE(+)   
      --  ORDER BY sidx||' '||sord
        ;
        
END;
/
