CREATE PROCEDURE          SP_X_PartResultYear
( 
  as_siljukyul_yn    in VARCHAR2,
  as_siljukyul_in_su in VARCHAR2,
  ls_year            in VARCHAR2,
  ls_partcd          in VARCHAR2,
  p_rc              out sys_refcursor
)
IS
BEGIN
   
   OPEN p_rc FOR
        SELECT 
			  SUBSTR(DATE_TIME,5,2) AS MONTH,
	          SUM(SALE_AMT) AS SALE_GOAL_AMT,  
	          ROUND((SUM(SALE_AMT_SILJUK) + SUM(SALE_AMT_HALINS02))  * (NVL(as_siljukyul_yn, 100) * 0.01) ,0)  AS SALE_RESULT_AMT,  
	          AVG(SALE_PERCENT) AS SALE_PERCENT,
	          SUM(IN_AMT) AS IN_SALE_GOAL_AMT,  
	          ROUND(SUM(IN_AMT_SILJUK) * ( NVL(as_siljukyul_in_su,100) * 0.01), 0) AS IN_SALE_RESULT_AMT,
	          SUM(IN_PERCENT) AS IN_PERCENT   
	     FROM SALE.SALEPART_BATCH2
	    WHERE SUBSTR(DATE_TIME,1,4) = ls_year 
	      AND PART_CD = ls_partcd
	    GROUP BY SUBSTR(DATE_TIME,5,2) 
	    ORDER BY MONTH 
        ;
END;
/
