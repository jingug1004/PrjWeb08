CREATE FUNCTION          fnGetStoreGridList 
(
  searchKeyword  in VARCHAR2,
  sidx           in VARCHAR2,
  sord           in VARCHAR2,
  as_cust_id     in varchar2
) RETURN sys_refcursor
AS
  F_rc  sys_refcursor;
  V_SQL  VARCHAR2(1000);
BEGIN
   
   
 V_SQL := 
    'SELECT A.CUST_ID CUST_ID, A.CUST_NM CUST_NM, 
            A.VOU_NO VOU_NO, A.PRESIDENT PRESIDENT
	    FROM SALE.SALE0003 A,
		       ( SELECT A.RCUST_ID
		           FROM SALE.SALE0405 A,SALE.SALE0004 B
                  WHERE A.ITEM_ID = B.ITEM_ID
                    AND B.JUMUN_VIEW_YN = ''Y''
                    AND A.CUST_ID = '||as_cust_id||'
                    AND A.ITEM_ID NOT IN (''86001'', ''86002'')
		            AND A.YMD >= TRUNC (SYSDATE) 
		          GROUP BY A.RCUST_ID
		        ) B
		 WHERE A.CUST_ID = B.RCUST_ID
		   AND A.CUST_GB1 <> ''40''
           AND A.CUST_ID || A.CUST_NM LIKE ''%' ||searchKeyword|| '%''
	     ORDER BY '||sidx||' '||sord;

   dbms_output.put_line(V_SQL); 

   OPEN F_rc FOR V_SQL;
   RETURN F_RC;
 
END;
/
