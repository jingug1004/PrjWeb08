CREATE PROCEDURE      SP_X_ONLINE_STOREGRIDLIST
(
    in_KEYWORD     in VARCHAR2,
    in_SIDX        in VARCHAR2,
    in_SORD        in VARCHAR2,
    in_CUST_ID     in varchar2,
    out_RESULT    OUT TYPES.CURSOR_TYPE,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_ONLINE_STOREGRIDLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 를 관리하는 프로시저이다.
-- ---------------------------------------------------------------
    V_SQL  VARCHAR2(1000);
BEGIN 

    V_SQL := 
    'SELECT A.CUST_ID CUST_ID, A.CUST_NM CUST_NM, 
            A.VOU_NO VOU_NO, A.PRESIDENT PRESIDENT
	    FROM SALE.SALE0003 A,
		       ( SELECT A.RCUST_ID
		           FROM SALE.SALE0405 A,SALE.SALE0004 B
                  WHERE A.ITEM_ID = B.ITEM_ID
                    AND B.JUMUN_VIEW_YN = ''Y''
                    AND A.CUST_ID = '||in_CUST_ID||'
                    AND A.ITEM_ID NOT IN (''86001'', ''86002'')
		            AND A.YMD >= TRUNC (SYSDATE) 
		          GROUP BY A.RCUST_ID
		        ) B
		 WHERE A.CUST_ID = B.RCUST_ID
		   AND A.CUST_GB1 <> ''40''
           AND A.CUST_ID || A.CUST_NM LIKE ''%' ||in_KEYWORD|| '%''
	     ORDER BY '||in_SIDX||' '||in_SORD;

   dbms_output.put_line(V_SQL); 

   OPEN out_RESULT FOR V_SQL;

EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	   
   
END ;
/
