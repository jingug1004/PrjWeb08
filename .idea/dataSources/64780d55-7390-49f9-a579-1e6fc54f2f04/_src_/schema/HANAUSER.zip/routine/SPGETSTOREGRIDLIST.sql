CREATE FUNCTION          spGetStoreGridList 
(
  searchKeyword  in VARCHAR2,
  sidx           in VARCHAR2,
  sord           in VARCHAR2,
  as_cust_id     in varchar2
) RETURN CHAR
IS
  F_RC   VARCHAR2(1000);

BEGIN
   
   
   SELECT A.VOU_NO VOU_NO INTO F_RC
	    FROM SALE.SALE0003 A,
		       ( SELECT A.RCUST_ID
		           FROM SALE.SALE0405 A,SALE.SALE0004 B
                  WHERE A.ITEM_ID = B.ITEM_ID
                    AND B.JUMUN_VIEW_YN = 'Y'
                    AND A.CUST_ID = as_cust_id
                    AND A.ITEM_ID NOT IN ('86001', '86002')
		            AND A.YMD >= TRUNC (SYSDATE) 
		          GROUP BY A.RCUST_ID
		        ) B
		 WHERE A.CUST_ID = B.RCUST_ID
		   AND A.CUST_GB1 <> '40'
           AND A.CUST_ID || A.CUST_NM LIKE '%' ||searchKeyword|| '%'
           AND ROWNUM = 1
	     ORDER BY sidx||' '||sord
;
   
   RETURN (F_RC);
 
END spGetStoreGridList;
/
