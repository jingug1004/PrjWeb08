CREATE PROCEDURE          SP_DBUSER_PASS
(
    in_ORAUSER           IN VARCHAR2,   -- DB USER
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE 
)
IS
    v_num                NUMBER; 

BEGIN

 /*---------------------------------------------------------------------------
 프로그램명   : DB CONNECT 을 위한 DB USER 의 비밀번호 가져오는 로직 
 호출프로그램 : 
 ---------------------------------------------------------------------------*/     
  
 
     SELECT COUNT(*)
       INTO v_num
       FROM hanauser.tb_orauser_info
      WHERE orauser = in_ORAUSER;          
    
    out_COUNT := v_num;

    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';        
               
        OPEN out_RESULT FOR
        SELECT orauser_pass    AS out_ORAUSER_PASS  --비밀번호
          FROM hanauser.tb_orauser_info 
         WHERE orauser = in_ORAUSER;  
    END IF;
         
    out_CODE := 0;
    out_MSG := ''; 

EXCEPTION 
        WHEN OTHERS THEN
           out_CODE := SQLCODE;
           out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
           dbms_output.put_line('out_CODE  '||to_char(out_CODE)||'out_MSG : '||out_MSG);
END;
/
