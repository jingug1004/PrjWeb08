CREATE PROCEDURE          SP_X_CustOrderPresentCondition
( 
  ls_ymdFr        in VARCHAR2,
  ls_ymdTo        in VARCHAR2,
  ls_custId       in VARCHAR2,
  p_rc           out sys_refcursor
)
IS
BEGIN
   
   OPEN p_rc FOR
     SELECT   MAX(YMD) YMD, TO_CHAR(YMD,'mm') MONTH                                                       
	         ,SUM(AMT_SUM + VAT_SUM) AS MONTH_AMT
	     FROM SALE.SALE0207 A                                                            
	    WHERE YMD BETWEEN ls_ymdFr AND ls_ymdTo                               
	      AND CUST_ID = ls_custId                                            
	    GROUP BY TO_CHAR(YMD,'mm')
	    ORDER BY 1
        ;
END;
/
