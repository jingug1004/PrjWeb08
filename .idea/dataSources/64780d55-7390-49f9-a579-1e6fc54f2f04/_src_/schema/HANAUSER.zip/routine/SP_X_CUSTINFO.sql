CREATE PROCEDURE          SP_X_CustInfo
( 
  ls_custid       in VARCHAR2,
  p_rc           out sys_refcursor
)
IS
BEGIN
   
   OPEN p_rc FOR
        SELECT 
			CUSTCODE, CUSTNAME, BUSINESSNO, ADDR1||' '||ADDR2 AS ADDR, 
			CEONAME, EMAIL 
		FROM ORAGMP.CMCUSTM 
		WHERE CUSTCODE = ls_custid
        ;
END;
/
