CREATE PACKAGE BODY        IDENTIFICATIONCHECK_PKG
AS
PROCEDURE SPIDENTIFICATIONCHECK (p_div           IN     VARCHAR2 := '',
                                p_id            IN     VARCHAR2 := '',
                                p_pwd           IN     VARCHAR2 := '',
                                p_signtype      IN     VARCHAR2 := '',
                                p_failed               NUMBER   := 0,
                                p_programcode   IN     VARCHAR2 := '',
                                p_empcode       IN     VARCHAR2 := '',
                                p_empname       IN     VARCHAR2 := '',
                                p_personid      IN     VARCHAR2 := '',
                                p_userid        IN     VARCHAR2 := '',
                                p_reasondiv     IN     VARCHAR2 := '',
                                p_reasontext    IN     VARCHAR2 := '',
                                MESSAGE         IN OUT VARCHAR2,
                                IO_CURSOR       IN OUT TYPES.DATASET
)
IS
  --V_CURSOR              TYPES.DATASET;

  v_Signperiod          INT;
  v_YandN               CHAR (1);
  v_ESignperiod         INT;
  v_ESignFailedNum      VARCHAR2 (20);
  v_MessengerMsgCycle   INT;
  v_MultiAccess         VARCHAR2 (1);
  v_empcode             VARCHAR2 (20);
  v_id                  VARCHAR2 (20);
  v_cnt                 INT := 0;
  v_recv                VARCHAR2 (20);
  
   BEGIN
      MESSAGE := '데이터베이스 성공';

      IF (p_div = 'S1')
      THEN
         SELECT value1
           INTO v_Signperiod
           FROM Parametermanage
          WHERE parametercode = 'SignPeriod';

         SELECT value1
           INTO v_ESignperiod
           FROM Parametermanage
          WHERE parametercode = 'ESignPeriod';

         SELECT value1
           INTO v_ESignFailedNum
           FROM Parametermanage
          WHERE parametercode = 'ESignFailedNum';

         SELECT value1
           INTO v_MessengerMsgCycle
           FROM Parametermanage
          WHERE parametercode = 'MessengerMsgCycle';

         SELECT value1
           INTO v_MultiAccess
           FROM Parametermanage
          WHERE parametercode = 'MultiAccess';

         SELECT 'u' INTO v_YandN FROM DUAL;

         OPEN IO_CURSOR FOR
            SELECT b.pwd,
                   b.failednum,
                   b.tempsignyn,
                   NVL (b.changedate, b.inputdate) AS diffdate,
                   v_YandN AS period,
                   CASE WHEN NVL(b.changepwdt, TO_CHAR(b.inputdate, 'YYYY-MM-DD')) < TO_CHAR(SYSDATE, 'YYYY-MM-DD') THEN 'Y' ELSE 'u' END pwperiod,
                   a.empcode,
                   a.empname,
                   a.deptcode,
                   c.deptname,
                   d.plantcode,
                   d.plantname,
                   a.responsibilitydiv,
                   NVL (f.divname, '') AS responsibilitydivnm,
                   a.classdiv,
                   NVL (a.salpower, '') AS salpower,
                   NVL (E.deptname, '') AS salpowernm,
                   NVL (a.workdiv, '') AS workcode,
                   NVL (G.divname, '') AS workname,
                   NVL (a.salediv, '') AS salediv,
                   NVL (h.divname, '') AS saledivnm,
                   NVL (cm.compcode, '') AS compcode,
                   NVL (cm.compname, '') AS compname,
                   b.fixidyn,
                   a.email,
                   CASE
                      WHEN b.failednum >= v_ESignFailedNum THEN 'Y'
                      ELSE 'u'
                   END
                      AS lockyn,
                   CASE
                      WHEN     v_MultiAccess = 'N'
                           AND M.loginstat = 'O'
                           AND DATEDIFF ('MINUTE', logdt, SYSDATE) <=
                                  v_MessengerMsgCycle
                      THEN
                         'O'
                      ELSE
                         'X'
                   END
                      AS loginstat,
                   CASE WHEN a.empcode = 'gmpit' THEN 'Y' ELSE 'u' END
                      AS adminyn,
                     1
                   + v_MessengerMsgCycle
                   - DATEDIFF ('MINUTE', logdt, SYSDATE)
                      AS waitingterm
                      ,a.factorycode
              FROM cmempm a
                   JOIN electronicsign b ON a.empcode = b.empcode
                   LEFT OUTER JOIN cmdeptm c ON a.deptcode = c.deptcode
                   JOIN cmplantm d ON d.plantcode like a.plantcode--a.plantcode = d.plantcode
                   LEFT OUTER JOIN cmdeptm E
                      ON NVL (a.salpower, '') = E.deptcode
                   LEFT JOIN
                   cmcommonm f
                      ON     a.responsibilitydiv = f.divcode
                         AND f.cmmcode = 'PS07'
                   LEFT JOIN CMCOMMONM G
                      ON a.workdiv = G.divcode AND G.cmmcode = 'PS26'
                   LEFT JOIN CMCOMMONM h
                      ON a.salediv = h.divcode AND h.cmmcode = 'PS45'
                   LEFT JOIN CMCOMPM cm ON d.compcode = cm.compcode
                   LEFT JOIN Messenger M ON a.empcode = M.empcode
             WHERE b.ID = p_id AND NVL (b.exityn, 'u') != 'Y';
      ELSIF (p_div = 'S2')
      THEN
         -- erp데이터로 수정
         OPEN IO_CURSOR FOR
            SELECT a.empcode AS scode,
                   a.empname AS sname,
                   a.deptcode AS dcode,
                   c.deptname AS dname,
                   a.factorycode AS factorycode
              FROM cmempm a
                   JOIN electronicsign b ON a.empcode = b.empcode
                   LEFT OUTER JOIN cmdeptm c ON a.deptcode = c.deptcode
             WHERE b.ID = p_id;
      ELSIF (p_div = 'UF')
      THEN
         UPDATE ElectronicSign
            SET failednum = failednum + 1
          WHERE ID = p_id;


         SELECT empcode
           INTO v_empcode
           FROM ElectronicSign
          WHERE ID = p_id;

         INSERT INTO LoginAccess (loginid,
                                  empcode,
                                  locationno,
                                  logindt,
                                  logoutdt,
                                  hostname,
                                  netaddress,
                                  ipaddress,
                                  successyn)
            SELECT LoginAccess_SEQ.NEXTVAL,
                   v_empcode,
                   '',
                   SYSDATE,
                   SYSDATE,
                   '' AS hostname,
                   '' AS address,
                   '' AS client_net_address,
                   'u' AS successyn
              FROM DUAL;

         SELECT failednum
           INTO MESSAGE
           FROM ElectronicSign
          WHERE ID = p_id;
      ELSIF (p_div = 'S3')
      THEN
         SELECT ID
           INTO v_id
           FROM ElectronicSign
          WHERE empcode = p_empcode AND p_empname = p_empname;

         SELECT CASE
                   WHEN v_id IS NULL
                   THEN
                      '※ 등록되지 않은 사용자입니다'
                   ELSE
                      '※ 아이디는 < ' || v_id || ' > 입니다'
                END
           INTO MESSAGE
           FROM DUAL;
      ELSIF (p_div = 'S4')
      THEN
         SELECT COUNT (a.ID)
           INTO v_cnt
           FROM ElectronicSign a INNER JOIN CMEMPM b ON a.empcode = b.empcode
          WHERE     a.empcode = p_empcode
                AND a.ID = p_id
                AND b.personid = p_personid;

         IF (v_cnt > 0)
         THEN
            RAISE_APPLICATION_ERROR (
               -20001,
               '해당 사용자를 찾을 수 없습니다.');
         END IF;

         --exec spAccountManage @div = 'I', @id  =

         SELECT value1
           INTO v_recv
           FROM ParameterManage
          WHERE parametercode = 'UserAccount';

         INSERT INTO MessengerMsgBox (sender,
                                      recv,
                                      msg,
                                      senddt,
                                      readyn,
                                      sdelete,
                                      rdelete,
                                      priority)
              VALUES (
                        p_empcode,
                        v_recv,
                          '[ 사번 : '
                        || p_empcode
                        || ' ] 임시계정 발행을 요청합니다.',
                        SYSDATE,
                        'u',
                        'N',
                        'u',
                        'A');
      --현장 프로그램의 권한여부 조회
      ELSIF (p_div = 'POP')
      THEN
         OPEN IO_CURSOR FOR
            SELECT DISTINCT a.empcode,
                            searchck AS S,
                            modifyck AS M,
                            insertck AS I,
                            deleteck AS D,
                            printck AS P,
                            convertck AS C
              FROM UserAccessAuthority a
                   INNER JOIN (SELECT empcode, ID FROM ElectronicSign) b
                      ON a.empcode = b.empcode
                   INNER JOIN Programmanage c
                      ON a.programcode = c.programcode
             WHERE b.ID = p_id AND a.programcode = p_programcode;
             
      ELSIF (p_div = 'S9')
      THEN
         SELECT value1
           INTO v_Signperiod
           FROM Parametermanage
          WHERE parametercode = 'SignPeriod';

         SELECT value1
           INTO v_ESignperiod
           FROM Parametermanage
          WHERE parametercode = 'ESignPeriod';

         SELECT value1
           INTO v_ESignFailedNum
           FROM Parametermanage
          WHERE parametercode = 'ESignFailedNum';

         SELECT value1
           INTO v_MessengerMsgCycle
           FROM Parametermanage
          WHERE parametercode = 'MessengerMsgCycle';

         SELECT value1
           INTO v_MultiAccess
           FROM Parametermanage
          WHERE parametercode = 'MultiAccess';

         SELECT 'u' INTO v_YandN FROM DUAL;

         OPEN IO_CURSOR FOR
            SELECT utl_i18n.raw_to_char(b.pwd ,'AL32UTF8') pwd,
                   b.failednum,
                   b.tempsignyn,
                   NVL (b.changedate, b.inputdate) AS diffdate,
                   v_YandN AS period,
                   a.empcode,
                   a.empname,
                   a.deptcode,
                   c.deptname,
                   d.plantcode,
                   d.plantname,
                   a.responsibilitydiv,
                   NVL (f.divname, '') AS responsibilitydivnm,
                   a.classdiv,
                   NVL (a.salpower, '') AS salpower,
                   NVL (E.deptname, '') AS salpowernm,
                   NVL (a.workdiv, '') AS workcode,
                   NVL (G.divname, '') AS workname,
                   NVL (a.salediv, '') AS salediv,
                   NVL (h.divname, '') AS saledivnm,
                   NVL (cm.compcode, '') AS compcode,
                   NVL (cm.compname, '') AS compname,
                   b.fixidyn,
                   a.email,
                   CASE
                      WHEN b.failednum >= v_ESignFailedNum THEN 'Y'
                      ELSE 'u'
                   END
                      AS lockyn,
                   CASE
                      WHEN     v_MultiAccess = 'N'
                           AND M.loginstat = 'O'
                           AND DATEDIFF ('MINUTE', logdt, SYSDATE) <=
                                  v_MessengerMsgCycle
                      THEN
                         'O'
                      ELSE
                         'X'
                   END
                      AS loginstat,
                   CASE WHEN a.empcode = 'gmpit' THEN 'Y' ELSE 'u' END
                      AS adminyn,
                     1
                   + v_MessengerMsgCycle
                   - DATEDIFF ('MINUTE', logdt, SYSDATE)
                      AS waitingterm
                      ,a.factorycode
              FROM cmempm a
                   JOIN electronicsign b ON a.empcode = b.empcode
                   LEFT OUTER JOIN cmdeptm c ON a.deptcode = c.deptcode
                   JOIN cmplantm d ON d.plantcode like a.plantcode--a.plantcode = d.plantcode
                   LEFT OUTER JOIN cmdeptm E
                      ON NVL (a.salpower, '') = E.deptcode
                   LEFT JOIN
                   cmcommonm f
                      ON     a.responsibilitydiv = f.divcode
                         AND f.cmmcode = 'PS07'
                   LEFT JOIN CMCOMMONM G
                      ON a.workdiv = G.divcode AND G.cmmcode = 'PS26'
                   LEFT JOIN CMCOMMONM h
                      ON a.salediv = h.divcode AND h.cmmcode = 'PS45'
                   LEFT JOIN CMCOMPM cm ON d.compcode = cm.compcode
                   LEFT JOIN Messenger M ON a.empcode = M.empcode
             WHERE b.ID = p_id AND NVL (b.exityn, 'u') != 'Y';
             
      END IF;

      IF (IO_CURSOR IS NULL)
      THEN
         OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
      END IF;

      IO_CURSOR := IO_CURSOR;
      
   END SPIDENTIFICATIONCHECK;
END IDENTIFICATIONCHECK_PKG;
/
