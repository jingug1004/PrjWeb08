CREATE PACKAGE BODY        GETCOMMON_PKG
AS
	PROCEDURE SPGETCOMMON(
		P_DIV			IN	   VARCHAR2 := NULL -- 구분
	   ,P_DIFF			IN	   VARCHAR2 := NULL -- 조회 시 구분자 값인지, 화면 display값인지 구분한다.("A":조회시 전체 값, "B",공백 값, "N"은 값만조회)
	   ,P_STRWHERE		IN	   VARCHAR2 := NULL -- 조회조건
	   ,P_STRWHERE2 	IN	   VARCHAR2 := '' -- 조회조건2
	   ,P_USERID		IN	   VARCHAR2 := NULL
	   ,P_REASONDIV 	IN	   VARCHAR2 := NULL
	   ,P_REASONTEXT	IN	   VARCHAR2 := NULL
	   ,MESSAGE 		   OUT VARCHAR2
	   ,IO_CURSOR		   OUT TYPES.DATASET
	)
	IS
		P_CNT1		   NUMBER := 0;
		IP_STRWHERE    VARCHAR2(4000) := P_STRWHERE;
	BEGIN
		MESSAGE := '데이터 확인';

		-- EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_MASTERBASE_DUAL';

		EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_MASTERBASE_DUAL';


		IF (P_DIFF = 'A')
		THEN
			INSERT INTO VGT.TT_MASTERBASE_DUAL(DIFF, KEYFIELD, DISPLAYFIELD, VIEWRANK)
				 VALUES ('A', '%', '전체', 0);
		ELSIF (P_DIFF = 'B')
		THEN
			INSERT INTO VGT.TT_MASTERBASE_DUAL(DIFF, KEYFIELD, DISPLAYFIELD, VIEWRANK)
				 VALUES ('B', '', '', 0);
		END IF;

		--IF (P_DIV = '공통코드' OR P_DIV = '공통코드구분명')
		IF (P_DIV = '공통코드'
			OR P_DIV = '공통코드구분명')
		THEN
			IF (UPPER(P_STRWHERE) = 'PS12')
			THEN
				OPEN IO_CURSOR FOR
					SELECT KEYFIELD
						  ,DISPLAYFIELD
                          ,VIEWRANK
					  FROM VGT.TT_MASTERBASE_DUAL
					 WHERE DIFF = P_DIFF
					UNION ALL
					SELECT DIVCODE AS KEYFIELD
						  ,DIVNAME AS DISPLAYFIELD
                          ,VIEWRANK
					  FROM CMCOMMONM
					 WHERE UPPER(CMMCODE) = UPPER(P_STRWHERE)
						   AND NVL(FILTER1, ' ') LIKE UPPER(P_STRWHERE2) || '%'
						   AND USEDIV = 'Y'
                    ORDER BY VIEWRANK;
			ELSIF (UPPER(P_STRWHERE) = 'SL10')
			THEN --영업구분 조회 컨트롤 사용시 구분처리
				OPEN IO_CURSOR FOR
					SELECT KEYFIELD
						  ,DISPLAYFIELD
                          ,VIEWRANK
					  FROM VGT.TT_MASTERBASE_DUAL
					 WHERE DIFF = P_DIFF
					UNION ALL
					SELECT DIVCODE AS KEYFIELD
						  ,DIVNAME AS DISPLAYFIELD
                          ,VIEWRANK
					  FROM CMCOMMONM
					 WHERE CMMCODE = P_STRWHERE
						   AND (P_STRWHERE2 = 'A'
								AND SUBSTR(DIVCODE, 1, 1) LIKE P_STRWHERE2 || '%'
								OR P_STRWHERE2 = 'A1'
								   AND DIVCODE IN ('A21', 'A22')
								OR --로컬수출, 직수출만 조회
								  P_STRWHERE2 = 'B'
								   AND SUBSTR(DIVCODE, 1, 1) LIKE P_STRWHERE2 || '%'
								   AND UPPER(FILTER1) = 'SALE'
								OR P_STRWHERE2 = 'B1'
								   AND DIVCODE IN ('B01', 'B03')
								OR --반품, 이기반품만 조회(거래명세서 출력 관련 추가 20140226:이세민).
								  P_STRWHERE2 = 'C')
						   AND USEDIV = 'Y'
                    ORDER BY VIEWRANK                           
                           ;
			ELSIF (UPPER(P_STRWHERE) = 'SL17')
			THEN --진행상태
				OPEN IO_CURSOR FOR
					SELECT KEYFIELD
						  ,DISPLAYFIELD
                          ,VIEWRANK
					  FROM VGT.TT_MASTERBASE_DUAL
					 WHERE DIFF = P_DIFF
					UNION ALL
					SELECT DIVCODE AS KEYFIELD
						  ,DIVNAME AS DISPLAYFIELD
                          ,VIEWRANK
					  FROM CMCOMMONM
					 WHERE CMMCODE = P_STRWHERE
						   AND ((NVL(P_STRWHERE2, ' ') = 'S'
								 AND DIVCODE NOT IN ('00', '03', '07')) --입력, 매출확정(승인), 반려 만 조
								OR (NVL(P_STRWHERE2, ' ') <> 'S'))
						   AND USEDIV = 'Y'
                     ORDER BY VIEWRANK;
			ELSIF (UPPER(P_STRWHERE) = 'SL18C')
			THEN --수금 구분 처리값
				OPEN IO_CURSOR FOR
					SELECT KEYFIELD
						  ,DISPLAYFIELD
                          ,VIEWRANK
					  FROM VGT.TT_MASTERBASE_DUAL
					 WHERE DIFF = P_DIFF
					UNION ALL
					SELECT DIVCODE AS KEYFIELD
						  ,DIVNAME AS DISPLAYFIELD
                          ,VIEWRANK
					  FROM CMCOMMONM
					 WHERE CMMCODE = 'SL18'
						   AND NVL(FILTER1, ' ') LIKE P_STRWHERE2 || '%'
						   AND FILTER2 = 'Y'
						   AND USEDIV = 'Y'
                  ORDER BY VIEWRANK;
			ELSIF (UPPER(P_STRWHERE) = 'SL16')
			THEN --반품유형 Lookup 순서 변경 160427 추가
				OPEN IO_CURSOR FOR
					SELECT KEYFIELD
						  ,DISPLAYFIELD
						  ,'' AS DRACCCODE
                          ,VIEWRANK
					  FROM VGT.TT_MASTERBASE_DUAL
					 WHERE DIFF = P_DIFF
					UNION ALL
					SELECT DIVCODE AS KEYFIELD
						  ,DIVNAME AS DISPLAYFIELD
						  ,DRACCCODE
                          ,VIEWRANK
					  FROM CMCOMMONM
					 WHERE UPPER(CMMCODE) = UPPER(P_STRWHERE)
						   AND NVL(FILTER1, ' ') LIKE P_STRWHERE2 || '%'
						   AND USEDIV = 'Y'
					ORDER BY VIEWRANK, DRACCCODE;
			ELSIF P_STRWHERE = 'AC03'
			THEN
				OPEN IO_CURSOR FOR
					SELECT KEYFIELD
						  ,DISPLAYFIELD
                          ,VIEWRANK
					  FROM VGT.TT_MASTERBASE_DUAL
					 WHERE DIFF = P_DIFF
					UNION ALL
					SELECT DIVCODE AS KEYFIELD
						  ,DIVNAME AS DISPLAYFIELD
                          ,VIEWRANK
					  FROM CMCOMMONM
					 WHERE UPPER(CMMCODE) = UPPER(P_STRWHERE)
						   AND NVL(FILTER1, ' ') LIKE P_STRWHERE2 || '%' --추가.강현철.
						   AND USEDIV = 'Y'
					ORDER BY VIEWRANK, KEYFIELD DESC NULLS FIRST;
			ELSE
				OPEN IO_CURSOR FOR
					SELECT KEYFIELD
						  ,DISPLAYFIELD
                          ,VIEWRANK
					  FROM VGT.TT_MASTERBASE_DUAL
					 WHERE DIFF = P_DIFF
					UNION ALL
					SELECT DIVCODE AS KEYFIELD
						  ,DIVNAME AS DISPLAYFIELD
                          ,VIEWRANK
					  FROM CMCOMMONM
					 WHERE UPPER(CMMCODE) = UPPER(P_STRWHERE)
						   AND NVL(FILTER1, ' ') LIKE P_STRWHERE2 || '%' --추가.강현철.
						   AND USEDIV = 'Y'
					ORDER BY VIEWRANK, KEYFIELD NULLS FIRST;
			END IF;
		ELSIF (UPPER(P_DIV) = '공통코드F2')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND NVL(FILTER2, ' ') LIKE NVL(P_STRWHERE2, '%') || '%'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK;
		ELSIF (P_DIV = '공통코드전체')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND NVL(FILTER1, ' ') LIKE P_STRWHERE2 || '%'
              ORDER BY VIEWRANK      
                  ;
		ELSIF (P_DIV = '공통코드3')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE > P_STRWHERE2
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK
                 ;
		ELSIF (P_DIV = '공통코드2')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE IN ('02', '03', '10')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK;
		ELSIF (UPPER(P_DIV) = '공통코드FROM')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND (P_STRWHERE2 > ' '
							AND DIVCODE >= P_STRWHERE2
							OR P_STRWHERE2 IS NULL)
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK      
                 ;
		ELSIF (UPPER(P_DIV) = '공통코드TO')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND (P_STRWHERE2 > ' '
							AND DIVCODE <= P_STRWHERE2
							OR P_STRWHERE2 IS NULL)
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK
                ;
		ELSIF (UPPER(P_DIV) = '공통코드SL36')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND USEDIV = 'Y'
					   AND DIVCODE IN ('01', '03')
              ORDER BY VIEWRANK
                       ;
		ELSIF (P_DIV = '공통코드36')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND USEDIV = 'Y'
					   AND DIVCODE IN ('01', '02') 
              ORDER BY VIEWRANK       
                       ;
		--  ELSIF (P_DIV = '공통코드36')
		--  THEN
		--   OPEN IO_CURSOR FOR
		--    SELECT TO_NUMBER (FILTER2) AS KEYFIELD,
		--        DIVNAME AS DISPLAYFIELD
		--      FROM CMCOMMONM
		--     WHERE CMMCODE = 'SL40' AND USEDIV = 'Y';



		ELSIF (P_DIV = '미송구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND UPPER(FILTER1) <> 'N'
					   AND SUBSTR(UPPER(DIVCODE), 1, 1) = 'A'
					   AND NVL(FILTER2, ' ') LIKE P_STRWHERE2 || '%'
					   AND UPPER(USEDIV) = 'Y'
              ORDER BY VIEWRANK        
                       ;
		ELSIF (P_DIV = '반품구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND DIVCODE NOT IN ('BM')
					   AND UPPER(USEDIV) = 'Y'
              ORDER BY VIEWRANK  
                ;
		ELSIF (P_DIV = '주문구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND USEDIV = 'Y'
					   AND UPPER(FILTER2) = 'SALE'
              ORDER BY VIEWRANK         
               ;
		ELSIF (P_DIV = '비용계정')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND USEDIV = 'Y'
					   AND FILTER1 LIKE P_STRWHERE2
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '수출코드')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE IN ('A21', 'A22')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK          
                       ;
		ELSIF (P_DIV = '계산서구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND SUBSTR(DIVCODE, LENGTH(DIVCODE) - 1, LENGTH(DIVCODE)) < '50'
					   AND DIVCODE <> 'C01'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK            
                       ;
		ELSIF (P_DIV = '계산서구분1')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE IN ('B51', 'B52')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK          
                       ;
		ELSIF (P_DIV = '명세서구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE NOT IN ('A51', 'B51', 'B55')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '기타입고구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND SUBSTR(DIVCODE, 1, 1) IN ('I') --입고(정상입고,기타입고)
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '기타출고구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND SUBSTR(DIVCODE, 1, 1) IN ('O') --입고(정상출고,기타출고)
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK       
                       ;
		ELSIF (P_DIV = '급호관리')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND FILTER1 = 'Y'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK            
                       ;
		ELSIF (P_DIV = '카드코드')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,CASE WHEN TRIM(FILTER2) IS NULL THEN NVL(DIVNAME, '') ELSE NVL(DIVNAME, '') || ' : ' || NVL(FILTER2, '') END AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'AC17'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK       
                       ;
		ELSIF (P_DIV = '전체구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM01'
					   AND FILTER1 IN ('01', '02', '07', '08')
					   AND USEDIV = 'Y'
				UNION ALL
				SELECT CASE DIVCODE WHEN '02' THEN '04' ELSE DIVCODE END AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM54'
					   AND FILTER1 IN ('02', '03')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK                
                       ;
		ELSIF (P_DIV = '청정도정보')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT MAJORNAME AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'LMM58'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK        
                       ;
		ELSIF (P_DIV = '통화코드')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'TR01'
					   AND DIVCODE <> '00'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '원자채구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM01'
					   AND FILTER1 IN ('01', '02')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '원자재분류')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT MAJORNAME AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM09'
					   AND NVL(FILTER1, ' ') LIKE P_STRWHERE || '%'
					   AND USEDIV = 'Y'
					   AND REMARK LIKE P_STRWHERE2 || '%'
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '원료자재분류')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT MAJORNAME AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM09'
					   AND NVL(FILTER1, ' ') LIKE P_STRWHERE || '%'
					   AND USEDIV = 'Y'
					   AND REMARK LIKE P_STRWHERE2 || '%'
					   AND TRIM(REMARK) IS NOT NULL
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '반품분류구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM18'
              ORDER BY VIEWRANK   
                 ;
		ELSIF (P_DIV = '근무처')
		THEN
			OPEN IO_CURSOR FOR
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'PS26'
					   AND DIVCODE = P_STRWHERE2
					   AND USEDIV = 'Y'
				UNION
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'PS26'
					   AND DIVCODE = '03'
					   AND USEDIV = 'Y'
					   AND P_USERID = 'gmpit'
              ORDER BY VIEWRANK          
                       ;
		--        ELSIF (P_DIV = '근무처')
		--        THEN
		--            OPEN IO_CURSOR FOR
		--                SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD
		--                  FROM CMCOMMONM
		--                 WHERE       CMMCODE = 'PS26'
		--                AND DIVCODE = P_STRWHERE2
		--                AND USEDIV = 'Y'
		--                UNION
		--                SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD
		--                  FROM CMCOMMONM
		--                 WHERE       CMMCODE = 'PS26'
		--                AND DIVCODE = '03'
		--                AND USEDIV = 'Y'
		--                AND P_USERID = 'gmpit';
        ELSIF (P_DIV = '근무처본사')
            THEN
                OPEN IO_CURSOR FOR
                    SELECT KEYFIELD
                            ,DISPLAYFIELD
                            ,VIEWRANK
                      FROM VGT.TT_MASTERBASE_DUAL
                     WHERE DIFF = P_DIFF
                    UNION
                    SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD, VIEWRANK
                      FROM CMCOMMONM
                     WHERE       CMMCODE = 'PS26'
                    AND DIVCODE = P_STRWHERE2
                    AND USEDIV = 'Y'
                    UNION
                    SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD, VIEWRANK
                      FROM CMCOMMONM
                     WHERE       CMMCODE = 'PS26'
                    AND DIVCODE in('01','03','05')
                    AND USEDIV = 'Y'
                    AND P_USERID = 'gmpit'
               ORDER BY VIEWRANK   
                    ;
        ELSIF (P_DIV = '근무처공장')
            THEN
                OPEN IO_CURSOR FOR
                    SELECT KEYFIELD
                            ,DISPLAYFIELD
                            ,VIEWRANK
                      FROM VGT.TT_MASTERBASE_DUAL
                     WHERE DIFF = P_DIFF
                    UNION
                    SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD, VIEWRANK
                      FROM CMCOMMONM
                     WHERE       CMMCODE = 'PS26'
                    AND DIVCODE = P_STRWHERE2
                    AND USEDIV = 'Y'
                    UNION
                    SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD, VIEWRANK
                      FROM CMCOMMONM
                     WHERE       CMMCODE = 'PS26'
                    AND DIVCODE in('02','2000','3000')
                    AND USEDIV = 'Y'
                    AND P_USERID = 'gmpit'
               ORDER BY VIEWRANK   
                    ;
		ELSIF (P_DIV = '소속회사')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT COMPCODE AS KEYFIELD
					  ,COMPNAME AS DISPLAYFIELD
				  FROM CMCOMPM
                  ;
		ELSIF (P_DIV = 'Dll모듈')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT DISTINCT DLLPATH AS KEYFIELD
							   ,DLLPATH AS DISPLAYFIELD
				  FROM PROGRAMMANAGE;
		ELSIF (P_DIV = '모듈조회')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				  SELECT MAJORNAME AS KEYFIELD
						,MAJORNAME AS DISPLAYFIELD
					FROM CMCOMMONM
				   WHERE TRIM(MAJORNAME) IS NOT NULL
				GROUP BY MAJORNAME;
		--  ELSIF (P_DIV = '모듈조회')
		--  THEN
		--   OPEN IO_CURSOR FOR
		--    SELECT KEYFIELD, DISPLAYFIELD
		--      FROM VGT.TT_MASTERBASE_DUAL
		--     WHERE DIFF = P_DIFF
		--    UNION ALL
		--      SELECT MAJORNAME AS KEYFIELD, MAJORNAME AS DISPLAYFIELD
		--     FROM CMCOMMONM
		--       WHERE NVL (MAJORNAME, '') <> ''
		--    GROUP BY MAJORNAME;
		ELSIF (P_DIV = '매출구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK          
                       ;
		--  ELSIF (P_DIV = '매출구분')
		--  THEN
		--   OPEN IO_CURSOR FOR
		--    SELECT KEYFIELD, DISPLAYFIELD
		--      FROM VGT.TT_MASTERBASE_DUAL
		--     WHERE DIFF = P_DIFF
		--    UNION ALL
		--    SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD
		--      FROM CMCOMMONM
		--     WHERE    CMMCODE = P_STRWHERE
		--    AND DIVCODE LIKE P_STRWHERE2 || '%'
		--    AND DIVCODE NOT IN ('B51')        --매출할인
		--    AND USEDIV = 'Y';
		ELSIF (P_DIV = '영업구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND UPPER(FILTER1) = UPPER('sale')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK        
                       ;
		--  ELSIF (P_DIV = '영업구분')
		--  THEN
		--   OPEN IO_CURSOR FOR
		--    SELECT KEYFIELD, DISPLAYFIELD
		--      FROM VGT.TT_MASTERBASE_DUAL
		--     WHERE DIFF = P_DIFF
		--    UNION ALL
		--    SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD
		--      FROM CMCOMMONM
		--     WHERE    CMMCODE = P_STRWHERE
		--    AND DIVCODE LIKE P_STRWHERE2 || '%'
		--    AND FILTER1 = 'sale'
		--    AND USEDIV = 'Y';
		ELSIF (P_DIV = '입고구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND SUBSTR(DIVCODE, 1, 1) IN ('1', 'I')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK           
                       ;
		ELSIF (P_DIV = '입고구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND SUBSTR(DIVCODE, 1, 1) IN ('1', 'I')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK           
                       ; --입고(정상입고,기타입고)
		ELSIF (P_DIV = '출고구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND SUBSTR(DIVCODE, 1, 1) IN ('2', 'O')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK        
                       ; --입고(정상출고,기타출고)
		--  ELSIF (P_DIV = '출고구분')
		--  THEN
		--   OPEN IO_CURSOR FOR
		--    SELECT KEYFIELD, DISPLAYFIELD
		--      FROM VGT.TT_MASTERBASE_DUAL
		--     WHERE DIFF = P_DIFF
		--    UNION ALL
		--    SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD
		--      FROM CMCOMMONM
		--     WHERE    CMMCODE = P_STRWHERE
		--    AND DIVCODE LIKE P_STRWHERE2 || '%'
		--    AND SUBSTR (DIVCODE, 1, 1) IN ('2', 'O')    --입고(정상출고,기타출고)
		--    AND USEDIV = 'Y';
		ELSIF (P_DIV = '기타수불')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK        
                       ;
		--  ELSIF (P_DIV = '기타수불')
		--  THEN
		--   OPEN IO_CURSOR FOR
		--    SELECT KEYFIELD, DISPLAYFIELD
		--      FROM VGT.TT_MASTERBASE_DUAL
		--     WHERE DIFF = P_DIFF
		--    UNION ALL
		--    SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD
		--      FROM CMCOMMONM
		--     WHERE    CMMCODE = P_STRWHERE
		--    AND DIVCODE LIKE P_STRWHERE2 || '%'
		--    AND USEDIV = 'Y';
		ELSIF (P_DIV = '사업장')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT PLANTCODE AS KEYFIELD
					  ,PLANTNAME AS DISPLAYFIELD
				  FROM CMPLANTM
                 WHERE PLANTCODE NOT IN ('9999') 
                  ; --권한없음 제외
                  
        ELSIF (P_DIV = '사업장(영업)')
        THEN
            OPEN IO_CURSOR FOR
                SELECT KEYFIELD
                      ,DISPLAYFIELD
                  FROM VGT.TT_MASTERBASE_DUAL
                 WHERE DIFF = P_DIFF
                UNION ALL
                SELECT PLANTCODE AS KEYFIELD
                      ,PLANTNAME AS DISPLAYFIELD
                  FROM CMPLANTM
                  WHERE PLANTCODE NOT IN ('1000', '2000', '3000', '9999'); --하나제약, 하길공장, 상신공장, 권한없음 제외

    elsif (p_div = '원가사업장')
    then
        open IO_CURSOR for
        select  keyfield
                ,displayfield
        from    VGT.TT_MASTERBASE_DUAL
        where   diff = p_diff
        union all
        select  divcode as keyfield
                ,divname as displayfield
        from    CMCOMMONM
        where   cmmcode = 'CS11'
                and usediv = 'Y'
        order by keyfield;

		ELSIF (P_DIV = '사업장(공장)')
		THEN
				OPEN IO_CURSOR FOR					
					SELECT PLANTCODE AS KEYFIELD
						  ,PLANTNAME AS DISPLAYFIELD
					  FROM CMPLANTM
					 WHERE plantcode IN ('2000', '3000') --하길공장, 상신공장
                     ORDER BY KEYFIELD;

      ELSIF (P_DIV = '공장구분')
		THEN
			IF (P_DIFF = 'A')
			THEN
				OPEN IO_CURSOR FOR
--					SELECT KEYFIELD
--						  ,DISPLAYFIELD
--					  FROM VGT.TT_MASTERBASE_DUAL
--					 WHERE DIFF = P_DIFF
--					UNION ALL
					SELECT PLANTCODE AS KEYFIELD
						  ,PLANTNAME AS DISPLAYFIELD
					  FROM CMPLANTM
					 WHERE plantcode IN ('2000', '3000', '9999') --하길공장, 상신공장, N/A 조회
                     ORDER BY KEYFIELD;
			ELSIF (P_DIFF = 'B'
				   AND P_STRWHERE != ' ')
			THEN
				OPEN IO_CURSOR FOR
					--                    SELECT KEYFIELD,
					--                           DISPLAYFIELD
					--                    FROM   VGT.TT_MASTERBASE_DUAL
					--                    WHERE  DIFF = P_DIFF
					--                    UNION ALL
					SELECT A.PLANTCODE AS KEYFIELD
						  ,CASE WHEN A.PLANTCODE = '9999' THEN '' ELSE A.PLANTNAME END AS DISPLAYFIELD
					  FROM CMPLANTM A
						   JOIN CMEMPM B ON A.PLANTCODE LIKE B.FACTORYCODE
						   JOIN ELECTRONICSIGN C ON B.EMPCODE = C.EMPCODE
					 WHERE A.plantcode IN ('2000', '3000', '9999') --하길공장, 상신공장 조회
						   AND C.id = P_STRWHERE;
			END IF;
      
      
		ELSIF (P_DIV = '파라미터')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT PARAMETERCODE AS KEYFIELD
					  ,VALUE1 AS DISPLAYFIELD
				  FROM PARAMETERMANAGE
				 WHERE PARAMETERCODE = P_STRWHERE
					   AND PARAMETERDIV = 'S';
		ELSIF (P_DIV = '프로그램')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT A.PROGRAMCODE AS KEYFIELD
					  ,B.PROGRAMNAME AS DISPLAYFIELD
				  FROM MENUPROGRAMMANAGE A INNER JOIN PROGRAMMANAGE B ON A.PROGRAMCODE = B.PROGRAMCODE;
		ELSIF (P_DIV = '즐겨찾기')
		THEN
			OPEN IO_CURSOR FOR
				  SELECT PARENTMENU || A.MENUCODE AS ORD
						,PARENTMENU || A.MENUCODE AS KEYFIELD
						,CASE WHEN MENULEVEL = 0 THEN ' 1 - ' || MENUNAME WHEN MENULEVEL = 1 THEN '   2 - ' || MENUNAME END AS DISPLAYFIELD
					FROM MENUF A
				   WHERE EMPCODE = P_STRWHERE
						 AND PLANTCODE = P_STRWHERE2
						 AND MENUDIV = 'M'
				--and menulevel = 0

				ORDER BY ORD, MENUSEQ, MENULEVEL;
		--  ELSIF (P_DIV = '공통코드전체')
		--  THEN
		--   OPEN IO_CURSOR FOR
		--    SELECT KEYFIELD, DISPLAYFIELD
		--      FROM VGT.TT_MASTERBASE_DUAL
		--     WHERE DIFF = P_DIFF
		--    UNION ALL
		--    SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD
		--      FROM COMMONMASTER
		--     WHERE    CMMCODE = P_STRWHERE
		--    AND NVL (MANAGECODE, '') LIKE P_STRWHERE2 || '%';
		ELSIF (P_DIV = '입고상태구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'SL70'
					   AND DIVCODE != '01'
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '생산입고구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'SL25'
					   AND DIVCODE IN ('1B', '1E', '1F', '1G', 'I90')
              ORDER BY VIEWRANK        
                       ;
		ELSIF (P_DIV = '영업형태')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'제조' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT '2' AS KEYFIELD
					  ,'수입' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT '3' AS KEYFIELD
					  ,'도매' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT '4' AS KEYFIELD
					  ,'제조||수입' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT '5' AS KEYFIELD
					  ,'제조||도매' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT '6' AS KEYFIELD
					  ,'수입||도매' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT '7' AS KEYFIELD
					  ,'제조||수입||도매' AS DISPLAYFIELD
				  FROM DUAL;
		ELSIF (P_DIV = '계약구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'수의계약(기부,폐기포함)' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '2'
					  ,'경쟁입찰'
				  FROM DUAL;
		ELSIF (P_DIV = '공급구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'출고' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '2'
					  ,'반품'
				  FROM DUAL
				UNION
				SELECT '3'
					  ,'폐기'
				  FROM DUAL
				UNION
				SELECT '4'
					  ,'오류수정'
				  FROM DUAL
				UNION
				SELECT '5'
					  ,'취소'
				  FROM DUAL;
		ELSIF (P_DIV = '공급형태')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'수출용' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '2'
					  ,'기부용'
				  FROM DUAL
				UNION
				SELECT '3'
					  ,'군납용'
				  FROM DUAL
				UNION
				SELECT '4'
					  ,'개인용'
				  FROM DUAL
				UNION
				SELECT '5'
					  ,'요양기관공급'
				  FROM DUAL
				UNION
				SELECT '6'
					  ,'의약품공급업체공급'
				  FROM DUAL
				UNION
				SELECT '7'
					  ,'견본품'
				  FROM DUAL
				UNION
				SELECT '8'
					  ,'안전상비의약품 판매처'
				  FROM DUAL
				UNION
				SELECT '9'
					  ,'특수의료시설,학술기관 등 공급'
				  FROM DUAL;
		ELSIF (P_DIV = '일련번호구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT '0' AS KEYFIELD
					  ,'미존재' AS DISPLAYFIELD --int 인식 불가로 string으로 처리
				  FROM DUAL
				UNION
				SELECT '1'
					  ,'존재'
				  FROM DUAL
				UNION
				SELECT '2'
					  ,'일부존재'
				  FROM DUAL;
		ELSIF (P_DIV = '회사구분')
		THEN
			OPEN IO_CURSOR FOR
				/*
                    select  'ORCL;orcl;gmpit;admin12##' as keyfield
                            ,'하나제약' as displayfield
                */
				SELECT 'HANA_QA;ORCL;oragmp;oragmp' AS KEYFIELD
					  ,'하나제약(DEV테스트)' AS DISPLAYFIELD
				  FROM DUAL;
		--        ELSIF (P_DIV = '공장구분')
		--  THEN
		--   OPEN IO_CURSOR FOR
		--    SELECT plantcode AS KEYFIELD,
		--        plantname AS DISPLAYFIELD
		--    FROM   cmplantm;
		ELSIF (P_DIV = '창고')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT WAREHOUSE AS KEYFIELD
					  ,WHNAME AS DISPLAYFIELD
				  FROM SLSTOREHOUSEM;
		--WHERE  WORKDIV LIKE P_STRWHERE || '%';
		-- 추가 시작 --------------------------------------------------------------
		ELSIF (UPPER(P_DIV) = 'CMMSL40')
		THEN
			OPEN IO_CURSOR FOR
				SELECT TO_NUMBER(FILTER2) AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'SL40'
					   AND USEDIV = 'Y';
		ELSIF (P_DIV = '원자재구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM01'
					   AND FILTER1 IN ('01', '02')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK       
                       ;
		ELSIF (P_DIV = '원자재재시험분류')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM09'
					   AND NVL(FILTER1, ' ') NOT IN ('C')
					   AND DIVCODE <> '10' -- and NVL(filter1,'') not in ('B', 'C') and divcode <> '10'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '원자재재시험분류')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM01'
					   AND FILTER1 = '05'
					   AND USEDIV = 'Y'
				UNION
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM09'
					   AND FILTER1 = 'B'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		--filter1 = B | 09:수입반제품 || itemdiv = '05'
		ELSIF (P_DIV = '발주품목분류')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT '03' AS KEYFIELD
					  ,'위탁제품' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM01'
					   AND FILTER1 = '05'
					   AND USEDIV = 'Y'
				UNION
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM09'
					   AND FILTER1 IN ('A', 'B', 'C')
					   AND USEDIV = 'Y';
		ELSIF (P_DIV = '폐기분류')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM09'
					   AND DIVCODE <> '10'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK        
                       ;
		--filter1 = A | 01:주원료, 02:부원료, 03:포장자재, 04:표시자재, 10:수입기타
		--filter1 = C | 08:위탁반제품
		--filter1 = B | 09:수입반제품
		ELSIF (P_DIV = '구매요청상태')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM04'
					   AND SUBSTR(FILTER1, 0, 1) = '1'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK        
                       ;
		ELSIF (P_DIV = '구매발주상태')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM04'
					   AND SUBSTR(FILTER1, 2, 1) = '2'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK       
                       ;
		ELSIF (P_DIV = '반품분류구분2')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM18'
					   AND DIVCODE IN ('02', '03', '05')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '반품판정구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM18'
					   AND FILTER1 = '11'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK          
                       ;
		ELSIF (P_DIV = '반품기타출고구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM28'
					   AND NVL(FILTER1, ' ') <> '01'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK        
                       ;
		ELSIF (P_DIV = '포장단위조회')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND FILTER1 = 'MTU'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK          
                       ;
		ELSIF (P_DIV = '제품구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM01'
					   AND DIVCODE IN ('03', '04', '09')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK        
                       ;
		ELSIF (P_DIV = '원부자재불출구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM34'
					   AND FILTER1 = P_STRWHERE
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF (P_DIV = '입고상태')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'MPM04'
					   AND SUBSTR(FILTER1, 3, 1) = '3'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK          
                       ;
		ELSIF (P_DIV = '서명주석')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,'문서 ' || SUBSTR(DIVNAME, 0, 2) || '완료' AS DISPLAYFIELD
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM14'
					   AND USEDIV = 'Y'
				UNION ALL
				SELECT 'R' || DIVCODE AS KEYFIELD
					  ,'문서 ' || SUBSTR(DIVNAME, 0, 2) || '반려' AS DISPLAYFIELD
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM14'
					   AND USEDIV = 'Y'
				UNION ALL
				SELECT 'C' || DIVCODE AS KEYFIELD
					  ,'문서 ' || SUBSTR(DIVNAME, 0, 2) || '취소' AS DISPLAYFIELD
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM14'
					   AND USEDIV = 'Y';
		ELSIF P_DIV = '자료구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM23'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK          
                       ;
		--ELSIF(P_div = '일탈처리')

		--    THEN

		--        SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL

		--        union all

		--        select        divcode as keyfield, divname as displayfield

		--        from        CMCOMMONM

		--        where        cmmcode = 'MEM46'
		--                    and usediv = 'Y'

		--    ;


		ELSIF (P_DIV = '사용여부')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM45'
					   AND TRIM(FILTER1) IS NOT NULL
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF P_DIV = '제조구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM55'
					   AND USEDIV = 'Y'
					   AND NVL(REMARK, ' ') LIKE P_STRWHERE || '%'
					   AND NVL(FILTER1, ' ') LIKE P_STRWHERE2 || '%'
              ORDER BY VIEWRANK         
                       ;
		ELSIF P_DIV = '포장구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM55'
					   AND USEDIV = 'Y'
					   AND REMARK LIKE P_STRWHERE || '%'
					   AND NVL(FILTER1, ' ') LIKE P_STRWHERE2 || '%'
					   AND DIVCODE <> '08'
              ORDER BY VIEWRANK        
                       ;
		ELSIF P_DIV = '단위중량단위'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT LOWER(DIVCODE) AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM02'
					   AND USEDIV = 'Y'
				--  AND DIVCODE IN ('kg', 'mg', 'ml', 'g', 'gm', 'EA') -- 하길공장 테스트로 인한 주석처리 by 김만수 2017.07.07
  		ORDER BY VIEWRANK, KEYFIELD DESC;
      
		ELSIF P_DIV = '원자재단위'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM02'
					   AND USEDIV = 'Y'
				--	   AND DIVCODE IN ('V', 'mL', 'kg', 'g', 'mg', 'A', 'Set', 'EA', 'Btl', 'R/L', 'Tube', 'T', 'PTP', 'BOU', 'm', 'L')
				ORDER BY VIEWRANK, DISPLAYFIELD;
		--ELSIF(P_div = '배양결과')

		--    THEN OPEN IO_CURSOR FOR

		--        SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL

		--        union all

		--        select        divcode as keyfield, divname as displayfield

		--        from         CMCOMMONM

		--        where         cmmcode = 'LMM71'

		--        order by    displayfield
		--    ;

		ELSIF P_DIV = '공통코드필터'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE LIKE P_STRWHERE2 || '%'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF P_DIV = '공통코드결산구분' --20101216 민승기추가
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND DIVCODE IN ('A', 'F', 'K')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK        
                       ;
		ELSIF P_DIV = '유통구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK          
                        --and    divcode < '50'
									   --union all

									   --select        '99' as keyfield
									   --            ,'기타' as displayfield

			;
		ELSIF P_DIV = 'SFA_과정보'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVCODE || '(' || DIVNAME || ')' AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'SH01'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK           
                       ;
		--2013-09-30 : 이세민 영업영역 적용(경보제약)


		ELSIF P_DIV = '영업영역조회'
		THEN
			OPEN IO_CURSOR FOR
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND ((P_STRWHERE2 = 'A'
							 AND DIVCODE NOT IN ('3', '4'))
							OR --ETC/OTC/거점
							  (P_STRWHERE2 = 'B'
							   AND DIVCODE IN ('3'))
							OR --간납
							  (P_STRWHERE2 = 'C')
							OR --ETC/OTC/간납/직납/거점
							  (P_STRWHERE2 = 'D'
							   AND DIVCODE IN ('4'))
							OR --직납
							  (P_STRWHERE2 = 'E'
							   AND DIVCODE IN ('3', '4'))) --간납/직납
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK          
                       ;
		ELSIF P_DIV = '공통코드선택'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = P_STRWHERE
					   AND NVL(FILTER1, ' ') IN (SELECT CODES FROM TABLE(FNSPLIT(P_STRWHERE2, '-')))
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF P_DIV = '서명직위'
		THEN
			OPEN IO_CURSOR FOR
				SELECT '0' AS KEYFIELD
					  ,'N/A' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT FILTER1
					  ,DIVNAME
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CMM27'
					   AND USEDIV = 'Y';
		ELSIF P_DIV = '분류'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'CM39'
				ORDER BY VIEWRANK, DISPLAYFIELD;
		ELSIF (P_DIV = '평가등급')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'ACC04'
              ORDER BY VIEWRANK  
                 ;
		ELSIF P_DIV = '제조부서'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 --2017-01-24 :rOYkANG : 데이터가 안나와서 주석처리 하고 아래와 같이 수정 함
				 --WHERE  CMMCODE = 'CMM61' AND USEDIV = 'Y' AND ((P_STRWHERE2 = 'A' AND FILTER1 IN ('A', 'I')) OR (P_STRWHERE2 = 'M' AND FILTER1 IN ('M')) OR (P_STRWHERE2 = ''));
				 WHERE CMMCODE = 'CMM61'
					   AND USEDIV = 'Y'
--					   AND FILTER1 = 'M'
					   AND FILTER2 IS NULL
              ORDER BY VIEWRANK          
                       ;
		ELSIF P_DIV = '시약시험규격'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'LMM06'
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'LMM82'
              ORDER BY VIEWRANK    
                 ;
		ELSIF (P_DIV = '관리항목')
		THEN
			OPEN IO_CURSOR FOR
				  SELECT *
					FROM (SELECT KEYFIELD
								,DISPLAYFIELD
                                ,VIEWRANK
							FROM VGT.TT_MASTERBASE_DUAL
						  UNION ALL
						  SELECT A.DIVCODE || NVL(B.MNGCLUCODE, '') AS KEYFIELD
								,NVL(B.MNGCLUNAME, A.DIVNAME) AS DISPLAYFIELD
                                ,VIEWRANK
							FROM CMCOMMONM A
								 LEFT JOIN ACMNGM B
									 ON B.CODEHELP = 'S200'
										AND A.DIVCODE = B.CODEHELP
						   WHERE A.CMMCODE = 'CMHL'
						  ORDER BY DISPLAYFIELD)
				ORDER BY VIEWRANK, CONVERT(DISPLAYFIELD, 'ISO2022-KR');
		ELSIF P_DIV = '공정코드'
		THEN
			OPEN IO_CURSOR FOR
				  SELECT *
					FROM (SELECT KEYFIELD
								,DISPLAYFIELD
							FROM VGT.TT_MASTERBASE_DUAL
						  UNION ALL
						  SELECT PROCESSCODE AS KEYFIELD
								,PROCESSNAME AS DISPLAYFIELD
							FROM PROCESSMASTER)
				ORDER BY CONVERT(DISPLAYFIELD, 'ISO2022-KR');
		ELSIF P_DIV = '기준금항목'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT REGCODE AS KEYFIELD
					  ,REGNAME AS DISPLAYFIELD
				  FROM PSREGIONAMTM
				 WHERE USEYN = 'Y'
                 ;
		ELSIF P_DIV = '창고'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT WAREHOUSE AS KEYFIELD
					  ,WHNAME AS DISPLAYFIELD
				  FROM SLSTOREHOUSEM;
		--select        workroomcode as keyfield
		--            ,workroomname as displayfield

		--from        WorkroomMaster

		----where        workdiv like P_strwhere || '%'
		--where        workroomcode in ('524','525','526','527','528')

		ELSIF P_DIV = '사업장창고'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT WAREHOUSE AS KEYFIELD
					  ,WHNAME AS DISPLAYFIELD
				  FROM SLSTOREHOUSEM
				 WHERE PLANTCODE LIKE P_STRWHERE || '%';
		ELSIF P_DIV = '근무지사업장'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DISTINCT A.PLANTCODE AS KEYFIELD
							   ,B.PLANTNAME AS DISPLAYFIELD
				  FROM SLSTOREHOUSEM A JOIN CMPLANTM B ON A.PLANTCODE = B.PLANTCODE
				 WHERE WORKDIV LIKE P_STRWHERE || '%'
                 ;
		ELSIF P_DIV = '창고위치'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DISTINCT WORKDIV AS KEYFIELD
							   ,B.DIVNAME AS DISPLAYFIELD
				  FROM SLSTOREHOUSEM A
					   LEFT JOIN CMCOMMONM B
						   ON A.WORKDIV = B.DIVCODE
							  AND B.CMMCODE = 'PS26';
		ELSIF P_DIV = '출하창고'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT WAREHOUSE AS KEYFIELD
					  ,WHNAME AS DISPLAYFIELD
				  FROM SLSTOREHOUSEM
				 WHERE WORKDIV LIKE P_STRWHERE || '%'
					   AND OUTYN = 'Y';
		ELSIF P_DIV = '사업장' --080929추가
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT PLANTCODE AS KEYFIELD
					  ,PLANTNAME AS DISPLAYFIELD
				  FROM CMPLANTM;
		ELSIF P_DIV = '사업장1'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM MASTERBASE
				 WHERE ((P_STRWHERE2 = '1000'
						 AND KEYFIELD IS NOT NULL)
						OR (P_STRWHERE2 = '2000'
							AND KEYFIELD NOT IN ('%'))
						OR (P_STRWHERE2 = '3000'
							AND KEYFIELD NOT IN ('%')))
				UNION ALL
				SELECT PLANTCODE
					  ,PLANTNAME
				  FROM CMPLANTM
				 WHERE ((P_STRWHERE2 = '1000'
						 AND PLANTCODE IS NOT NULL)
						OR (P_STRWHERE2 = '2000'
							AND PLANTCODE IN ('2000'))
						OR (P_STRWHERE2 = '3000'
							AND PLANTCODE IN ('3000')));
		--  ELSIF P_DIV = '파라미터'         -- 파라미터의 값을 가져옴
		--  THEN
		--   OPEN IO_CURSOR FOR
		--    SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL
		--    UNION ALL
		--    SELECT PARAMETERCODE AS KEYFIELD, VALUE1 AS DISPLAYFIELD
		--      FROM SYSPARAMETERMANAGE
		--     WHERE PARAMETERCODE = P_STRWHERE AND PARAMETERDIV = 'S';
		ELSIF P_DIV = '프로그램'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT PROGRAMCODE AS KEYFIELD
					  ,PROGRAMNAME AS DISPLAYFIELD
				  FROM SYSPROGRAMMANAGE;
		ELSIF P_DIV = '수당공제구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT SUGOCODE AS KEYFIELD
					  ,SUGONAME AS DISPLAYFIELD
				  FROM PSSUGOITEMM
				 WHERE SUGODIV = P_STRWHERE
					   AND USEYN = 'Y'
					   AND FIXYN LIKE P_STRWHERE2 || '%'        
                       ;
        ELSIF P_DIV = '고정수당'
        THEN
            OPEN IO_CURSOR FOR
                SELECT KEYFIELD
                      ,DISPLAYFIELD
                  FROM VGT.TT_MASTERBASE_DUAL
                UNION ALL
                SELECT SUGOCODE AS KEYFIELD
                      ,SUGONAME AS DISPLAYFIELD
                  FROM PSSUGOITEMM
                 WHERE SUGODIV = P_STRWHERE
                       AND USEYN = 'Y'
                       AND SUGOCODE in('020','160')
                       AND FIXYN LIKE P_STRWHERE2 || '%';
		ELSIF P_DIV = '수당공제합'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT SUGODIV AS KEYFIELD
					  ,SUGONAME AS DISPLAYFIELD
				  FROM (SELECT SUGODIV || SUGOCODE AS SUGODIV
							  ,SUGONAME
						  FROM PSSUGOITEMM) A
				 WHERE SUGODIV LIKE P_STRWHERE || '%';
		ELSIF P_DIV = '인스톨폴더'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT '.' AS KEYFIELD
					  ,'시스템루트' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT 'Intro' AS KEYFIELD
					  ,'Intro' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT 'Skin' AS KEYFIELD
					  ,'Skin' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT 'Fonts' AS KEYFIELD
					  ,'Fonts' AS DISPLAYFIELD
				  FROM DUAL;
		--    --강현철. 직접 Lookup등록시 사용
		--    ELSIF(P_div = '등록')
		--    THEN OPEN IO_CURSOR FOR
		----        declare P_strwhere varchar(2000)
		----        set P_strwhere = 'M0906040245;M0906040246;M0906040165;M0906040166;M0906040001;M0906040002;M0906040004;'

		--        declare P_cnt int
		--        set P_cnt = 0

		--        declare P_LookupTable table
		--        (
		--            divcode        varchar(20)
		--            ,divname        varchar(50)
		--        )

		--        while charindex(';' , P_strwhere) <> 0

		--            THEN OPEN IO_CURSOR FOR

		--                insert into P_LookupTable
		--                select replace(str(P_cnt,2),'','0'), SUBSTR(P_strwhere, 1, charindex(';', P_strwhere) -1)

		--                set P_strwhere = SUBSTR(P_strwhere, charindex(';', P_strwhere) || 1, len(P_strwhere))
		--                set P_cnt = P_cnt||1

		--            end

		--        if(P_strwhere2 = '1')
		--            THEN OPEN IO_CURSOR FOR
		--                SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL
		--                union all
		--                select        right(divcode,1) as keyfield, divname as displayfield
		--                from        P_LookupTable
		--            end
		--            else
		--            THEN OPEN IO_CURSOR FOR
		--                SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL
		--                union all
		--                select        divcode as keyfield, divname as displayfield
		--                from        P_LookupTable
		--            end

		--    end



		--  ELSIF (P_DIV = '회사구분')
		--  THEN
		--   OPEN IO_CURSOR FOR SELECT '106.250.174.234;VTPMS;sa;admin12#' AS KEYFIELD, 'VTPMs ERP(MS-SQL)' AS DISPLAYFIELD FROM DUAL;
		ELSIF (P_DIV = '즐겨찾기')
		THEN
			OPEN IO_CURSOR FOR
				  SELECT PARENTMENU || A.MENUCODE AS ORD
						,PARENTMENU || A.MENUCODE AS KEYFIELD
						,CASE WHEN MENULEVEL = 0 THEN ' 1 - ' || MENUNAME WHEN MENULEVEL = 1 THEN '   2 - ' || MENUNAME END AS DISPLAYFIELD
					FROM SYSFAVMENUF A
				   WHERE EMPCODE = P_STRWHERE
						 AND PLANTCODE = P_STRWHERE2
						 AND MENUDIV = 'M'
				--and menulevel = 0

				ORDER BY ORD, MENUSEQ, MENULEVEL;
		ELSIF P_DIV = '작업실'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT WORKROOMCODE AS KEYFIELD
					  ,WORKROOMNAME AS DISPLAYFIELD
				  FROM WORKROOMMASTER
                 WHERE PLANTCODE LIKE P_STRWHERE2 || '%';
		ELSIF UPPER(P_DIV) = 'WAREHOUSEMASTER'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT WORKROOMCODE AS KEYFIELD
					  ,WORKROOMNAME AS DISPLAYFIELD
				  FROM WORKROOMMASTER
				 WHERE WORKROOMDIV = '02';
		ELSIF P_DIV = '작업실그룹' --청정도 시험스케줄 사용
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL; --union all
		--select         workroomgroupcode as keyfield, workroomgroupname as displayfield

		--from        workroomgroupmaster

		--where        useyn = 'Y'
		-- VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음PDEQUIPMENTM
		ELSIF P_DIV = '설비정보'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT EQUIPMENTCODE AS KEYFIELD
					  ,EQUIPMENTKORNAME AS DISPLAYFIELD
				  FROM PDEQUIPMENTM -- equipmentmaster
				 WHERE WORKROOMCODE LIKE P_STRWHERE || '%';
		-- VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음 VIEW 없음PDEQUIPMENTM


		ELSIF P_DIV = '시험기기정보'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT EQUIPMENTCODE AS KEYFIELD
					  ,EQUIPMENTKORNAME AS DISPLAYFIELD
				  FROM TESTEQUIPMENTMASTER
				 WHERE WORKROOMCODE LIKE P_STRWHERE || '%';
		ELSIF P_DIV = '공정정보'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT PROCESSCODE AS KEYFIELD
					  ,PROCESSNAME AS DISPLAYFIELD
				  FROM PROCESSMASTER -- processmaster
                 WHERE PLANTCODE LIKE P_STRWHERE2 || '%'
              ORDER BY KEYFIELD;
		ELSIF P_DIV = '세부공정'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL --union all
											 --select        detailprocesscode as keyfield, detailprocessname as displayfield

											 --from          detailprocessmaster

			;
		ELSIF P_DIV = '공정별세부공정'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL;
		--union all

		--select        a.detailprocesscode as keyfield, a.detailprocessname as displayfield

		--from          detailprocessmaster a
		--            inner join workflowdetail b
		--                on a.detailprocesscode = b.detailprocesscode

		--where        b.workflowid = P_strwhere


		ELSIF P_DIV = '은행코드'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT BANKCODE AS KEYFIELD
					  ,NVL(BANKNAME, '') || ' ' || NVL(BRANCHNAME, '') AS DISPLAYFIELD
				  FROM CMBANKM;
		--ELSIF P_div ='제조용수'
		--    THEN OPEN IO_CURSOR FOR

		--        SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL

		--        --union all

		--        --select        itemcode as keyfield, itemname as displayfield

		--        --from          watermaster

		--        --where        testcheck = 'Y'        --사용하는 제조용수만 조회

		--    end

		--ELSIF P_div ='제조용수포인트'
		--    THEN OPEN IO_CURSOR FOR

		--        SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL

		--        --union all

		--        --select        waterpointcode as keyfield, waterpointname as displayfield

		--        --from          waterpointmanage

		--        --where        itemcode like P_strwhere || '%'

		--    end
		ELSIF P_DIV = '공정포인트' -- 시험규격관리에서 공정과 제조용수 포인트를 동시에 관리하기 위함
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				--union all

				--select        waterpointcode as keyfield, waterpointname as displayfield

				--from          waterpointmanage

				UNION ALL
				SELECT PROCESSCODE AS KEYFIELD
					  ,PROCESSNAME AS DISPLAYFIELD
				  FROM PROCESSMASTER -- processmaster
									;
		--ELSIF P_div ='배지마스터'
		--    THEN OPEN IO_CURSOR FOR

		--        SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL

		--        union all

		----        --수정함 080407(조제된 배지정보조회 조제번호만 조회함)
		----        select        distinct compoundno as keyfield
		----                    ,compoundno as disfield
		----
		----        from        cultureuse
		----
		----        where        cultureuser is not null
		----                    and cultureconfirmor is not null

		--        select        culturecode as keyfield, culturenameeng as displayfield
		--        from        LSCULTUREM -- culturemaster
		--        where        culturediv like P_strwhere || '%'

		--    ;

		--ELSIF P_div ='성능시험법'
		--    THEN OPEN IO_CURSOR FOR

		--        SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL

		--        --union all

		--        --select        methodcode as keyfield, methodkorname as displayfield
		--        --from        performancemethodmanage

		--    ;
		-- LSMARKMATERIALM 테이블 없음 LSMARKMATERIALM 테이블 없음 LSMARKMATERIALM 테이블 없음 LSMARKMATERIALM 테이블 없음 LSMARKMATERIALM 테이블 없음
		--ELSIF P_DIV = '표시자재번호'
		--        THEN
		--            UPDATE LSMARKMATERIALM
		--               SET USEDIV = 'N'
		--             WHERE BULLETINENDDATE < TO_CHAR (SYSDATE, 'YYYY-MM-DD');
		--
		--            SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL
		--            UNION ALL
		--            SELECT A.ITEMCHILDCODE || '-' || A.INHERENTNO AS KEYFIELD,
		--            '(' || A.ITEMCHILDCODE || '-' || A.INHERENTNO || ')' || B.
		--            ITEMKORNAME
		--                AS DISPLAYFIELD
		--              FROM LSMARKMATERIALM A
		--            INNER JOIN MATERIALSMASTER B ON A.ITEMCHILDCODE = B.ITEMCODE
		--             WHERE       A.ITEMCHILDCODE = P_STRWHERE
		--            AND A.USEDIV LIKE P_STRWHERE2 || '%';
		--LSMARKMATERIALM 테이블 없음 LSMARKMATERIALM 테이블 없음 LSMARKMATERIALM 테이블 없음 LSMARKMATERIALM 테이블 없음 LSMARKMATERIALM 테이블 없음 LSMARKMATERIALM 테이블 없음
		ELSIF P_DIV = '결재라인'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL; --union all
		--    select        approvallinecode as keyfield, approvallinename as displayfield

		--    from          approvelinemanage

		--    where        NVL(usediv,'') = 'Y'

		ELSIF P_DIV = '비용정보'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT COSTCODE AS KEYFIELD
					  ,COSTNAME AS DISPLAYFIELD
				  FROM PDCOSTM -- costmaster
							  ;
		ELSIF P_DIV = '원자재지정제조처'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
                SELECT  A.MANUFACTURECODE AS KEYFIELD
                 ,       B.CUSTNAME       AS DISPLAYFIELD                        
                 FROM MaterialManufacture A
                        JOIN CMCUSTM B
                            ON A.MANUFACTURECODE = B.CUSTCODE
                 WHERE A.ITEMCODE = P_STRWHERE
                   AND A.PLANTCODE LIKE P_STRWHERE2 || '%';
              --BOM기준이 아닌 원료제조처관리에서 등록한 제조처 조회로 인해 주석처리 BY 김만
--				SELECT DISTINCT A.MANUFACTURECODE AS KEYFIELD
--							   ,C.CUSTNAME AS DISPLAYFIELD
--				  --FROM   PDPMANUFACTUREM A -- PrescriptionManufacture a
--
--				  FROM PrescriptionManufacture a
--					   INNER JOIN MATERIALSMASTER B ON A.ITEMCHILDCODE = B.ITEMCODE
--					   INNER JOIN CUSTOMERMASTER C ON A.MANUFACTURECODE = C.CUSTCODE
--				 WHERE A.ITEMCHILDCODE = P_STRWHERE;
		ELSIF P_DIV = '제조포장제품'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				  SELECT ITEMCODE AS KEYFIELD
						, --,itemcode || ' - ' || max(itemkorname) || ' (' || max(packingunitqtyname) || ')'as displayfield
						 ITEMCODE || ' - ' || MAX(ITEMKORNAME) || ' (' || MAX(NVL(PACKINGUNITQTYNAME, ITEMUNIT)) || ')' AS DISPLAYFIELD
					FROM VNGPITEMMASTER
				   WHERE MANAGECODE = '04'
						 AND USEDIV LIKE P_STRWHERE2 || '%'
						 AND TYPICALITEMCODE = P_STRWHERE
				GROUP BY ITEMCODE;
		ELSIF P_DIV = '재포장제품'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				  SELECT ITEMCODE AS KEYFIELD
						,ITEMCODE || ' - ' || MAX(ITEMKORNAME) || ' (' || MAX(PACKINGUNITQTYNAME) || ')' AS DISPLAYFIELD
					FROM VNGPITEMMASTER
				   WHERE USEDIV LIKE P_STRWHERE2 || '%'
						 AND TYPICALITEMCODE = P_STRWHERE
				GROUP BY ITEMCODE;
		ELSIF P_DIV = '공정선택정보'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT PROCESSCODE AS KEYFIELD
					  ,PROCESSNAME AS DISPLAYFIELD
				  FROM PROCESSMASTER -- processmaster
				 WHERE NVL(PROCESSDIV, ' ') LIKE P_STRWHERE || '%'
					   AND NVL(PRODUCTIONDIV, ' ') LIKE P_STRWHERE2 || '%';
		ELSIF UPPER(P_DIV) = 'DLL모듈'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DISTINCT DLLPATH AS KEYFIELD
							   ,DLLPATH AS DISPLAYFIELD
				  FROM SYSPROGRAMMANAGE;
		ELSIF P_DIV = '레벨'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DISTINCT TO_CHAR(LEVELSEQ) AS KEYFIELD
							   ,TO_CHAR(LEVELSEQ) AS DISPLAYFIELD
				  FROM LEVELINDEX
				 WHERE LEVELSEQ <= P_STRWHERE
				ORDER BY KEYFIELD;
		ELSIF P_DIV = '표준운영절차관리번호'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				--select         distinct
				--            sopmanageno as keyfield
				--            ,sopmanageno  -- || case NVL(usediv,'N') when 'Y' THEN OPEN IO_CURSOR FOR ' : 사용승인' else '' end
				--                as displayfield

				--from        PDSOPPROCESSRM
				SELECT DISTINCT REVISIONNO AS KEYFIELD
							   ,REVISIONNO -- || case NVL(usediv,'N') when 'Y' THEN OPEN IO_CURSOR FOR ' : 사용승인' else '' end
										  AS DISPLAYFIELD
				  FROM SOPREVISIONMANAGE
				 WHERE ITEMCODE = P_STRWHERE;
		--ELSIF(P_div = '균주')

		--    THEN OPEN IO_CURSOR FOR

		--        SELECT KEYFIELD, DISPLAYFIELD FROM VGT.TT_MASTERBASE_DUAL

		--        union all

		--        select        bacteriacode as keyfield, bacterianame as displayfield

		--        from        LSBACM   -- BacteriaMaster

		--    ;

		ELSIF (P_DIV = '입력권한사원')
		THEN
			OPEN IO_CURSOR FOR
				SELECT A.EMPCODE AS KEYFIELD
					  ,A.EMPNAME AS DISPLAYFIELD
				  FROM VNEMPLOYEEMASTER A
					   INNER JOIN SYSUSERACCESSAUTHORITY B
						   ON A.EMPCODE = B.EMPCODE
							  AND (B.INSERTCK = 'Y'
								   OR B.MODIFYCK = 'Y')
				 WHERE B.PROGRAMCODE = P_STRWHERE;
		ELSIF (P_DIV = '계산서조회')
		THEN
			OPEN IO_CURSOR FOR
				SELECT TAXDATE AS KEYFIELD
					  ,TAXNO AS DISPLAYFIELD
				  FROM ACTAXM
				 WHERE COMPCODE = SUBSTR(P_STRWHERE, 1, 3)
					   AND PLANTCODE = SUBSTR(P_STRWHERE, 4, 4)
					   AND TAXDATE = P_STRWHERE2;
		ELSIF P_DIV = '소속회사' --20100825추가
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT COMPCODE AS KEYFIELD
					  ,COMPNAME AS DISPLAYFIELD
				  FROM CMCOMPM;
		ELSIF (P_DIV = '영업소') --SFA 사용
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DEPTCODE
					  ,DEPTNAME
				  FROM CMDEPTM
				 WHERE DEPTCODE LIKE 'M%'
					   AND DEPTLEVEL = 3
					   AND DEPTCODE != 'M001010';
		ELSIF (P_DIV = '사원') --SFA 사용
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT EMPCODE AS KEYFIELD
					  ,EMPNAME AS DISPLAYFIELD
				  FROM CMEMPM A
					   INNER JOIN (SELECT DEPTCODE
										 ,DEPTNAME
									 FROM CMDEPTM
									WHERE DEPTCODE LIKE 'M%'
										  AND DEPTLEVEL = 3) B
						   ON A.DEPTCODE = B.DEPTCODE
				 WHERE A.DEPTCODE != 'M107010'
					   AND A.DEPTCODE LIKE P_STRWHERE || '%'
					   AND TRIM(A.RETIREDT) IS NULL
				ORDER BY DISPLAYFIELD;
		ELSIF (P_DIV = '제품') --SFA 사용
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT ITEMCODE AS KEYFIELD
					  ,ITEMNAME || ' ' || ITEMUNIT AS DISPLAYFIELD
				  FROM CMITEMM
				 WHERE ITEMDIV = '04'
					   AND PRODUCTDIV != '90'
				ORDER BY DISPLAYFIELD;
		ELSIF P_DIV = '자금코드'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT FUNDCODE AS KEYFIELD
					  ,FUNDNAME AS DISPLAYFIELD
				  FROM ACFUNDM
				 WHERE INOUTDIV LIKE P_STRWHERE || '%';
		--캠페인 리스트 조회 추가 2015-06-24:이세민(이글벳 특화)
		ELSIF P_DIV = 'CAMPAIGN'
		THEN
			OPEN IO_CURSOR FOR
				SELECT CAMPAIGNMANAGEID AS KEYFIELD
					  ,CAMPAIGNTITLE AS DISPLAYFIELD
				  FROM SLCAMPAIGNM --(nolock)
				 WHERE SDATE BETWEEN P_STRWHERE || '-01-01' AND P_STRWHERE || '-12-31';
		ELSIF P_DIV = '대상구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT A.WORKROOMCODE AS KEYFILED
					  ,A.WORKROOMNAME AS DISPLAYFIELD
				  FROM WORKROOMMASTER A
					   LEFT JOIN CMCOMMONM D
						   ON A.WORKROOMDIV = D.DIVCODE
							  AND D.CMMCODE = 'MEM35'
				 WHERE D.FILTER1 = 'W'
				UNION ALL
				SELECT B.EQUIPMENTCODE AS KEYFILED
					  ,B.EQUIPMENTKORNAME AS DISPLAYFIELD
				  FROM EQUIPMENTMASTER B
					   INNER JOIN WORKROOMMASTER C ON B.WORKROOMCODE = C.WORKROOMCODE
					   LEFT JOIN CMCOMMONM D
						   ON C.WORKROOMDIV = D.DIVCODE
							  AND D.CMMCODE = 'MEM35'
				 WHERE D.FILTER1 = 'W';
		ELSIF P_DIV = '제품창고'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT A.WAREHOUSE AS KEYFIELD
					  ,A.WHNAME AS DISPLAYFIELD
				  FROM SLSTOREHOUSEM A
					   INNER JOIN CMCOMMONM B
						   ON A.WHDIV = B.DIVCODE
							  AND B.CMMCODE = 'ST01'
							  AND B.DIVCODE = '04';
		ELSIF (P_DIV = '등록')
		THEN
			P_CNT1 := 0;

			EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_GETCOMMON_LOOKUPTABLE';

			WHILE INSTR(IP_STRWHERE, ';') <> 0
			LOOP
				INSERT INTO VGT.TT_GETCOMMON_LOOKUPTABLE
					(SELECT TRIM(TO_CHAR(P_CNT1, '00'))
						   ,SUBSTR(IP_STRWHERE, 1, INSTR(IP_STRWHERE, ';') - 1)
					   FROM DUAL);

				IP_STRWHERE := SUBSTR(IP_STRWHERE, INSTR(IP_STRWHERE, ';') + 1, LENGTH(IP_STRWHERE));

				P_CNT1 := P_CNT1 + 1;
			END LOOP;


			IF (P_STRWHERE2 = '1')
			THEN
				OPEN IO_CURSOR FOR
					SELECT KEYFIELD
						  ,DISPLAYFIELD
					  FROM VGT.TT_MASTERBASE_DUAL
					UNION ALL
					SELECT SUBSTR(DIVCODE, -1) AS KEYFIELD
						  ,DIVNAME AS DISPLAYFIELD
					  FROM VGT.TT_GETCOMMON_LOOKUPTABLE;
			ELSE
				OPEN IO_CURSOR FOR
					SELECT KEYFIELD
						  ,DISPLAYFIELD
					  FROM VGT.TT_MASTERBASE_DUAL
					UNION ALL
					SELECT DIVCODE AS KEYFIELD
						  ,DIVNAME AS DISPLAYFIELD
					  FROM VGT.TT_GETCOMMON_LOOKUPTABLE;
			END IF;
		ELSIF P_DIV = '시험항목'
		THEN
			OPEN IO_CURSOR FOR
				  SELECT DISTINCT B.TESTITEMCODE AS KEYFIELD
								 ,C.TESTITEMNAME AS DISPLAYFIELD
								 ,SEARCHSEQ
					FROM VNTESTSTANDARDMASTER AA
						 LEFT JOIN TESTSTANDARDREVISION A ON AA.TESTSTANDARDREVISIONID = A.TESTSTANDARDREVISIONID
						 LEFT JOIN TESTSTANDARDMASTER B ON A.TESTSTANDARDREVISIONID = B.TESTSTANDARDREVISIONID
						 LEFT JOIN TESTITEMMASTER C ON B.TESTITEMCODE = C.TESTITEMCODE
				   WHERE A.ITEMCODE = P_STRWHERE
						 AND A.PROCESSCODE = CASE WHEN TRIM(P_STRWHERE2) IS NULL THEN A.PROCESSCODE ELSE P_STRWHERE2 END --and a.plantcode = '1002'
						 AND B.RESULTDATADIV = 'c'
				ORDER BY TO_NUMBER(SEARCHSEQ);
		ELSIF P_DIV = '공정선택'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT PROCESSCODE AS KEYFIELD
					  ,PROCESSNAME AS DISPLAYFIELD
				  FROM PROCESSMASTER
				 WHERE NVL(PROCESSDIV, '') = P_STRWHERE
                   AND PLANTCODE LIKE P_STRWHERE2 || '%';
		--              신규 제조부서 등록시 구분자2 값을 입력하지 않을 경우 공정 조회안되는 문제로 인해
		--              제조부서에 따른 공정 조회 로직 주석 처리 by 김만수 (2017.07.12)
		--    SELECT KEYFIELD,
		--        DISPLAYFIELD
		--    FROM   VGT.TT_MASTERBASE_DUAL
		--    UNION ALL
		--    SELECT PROCESSCODE AS KEYFIELD,
		--        PROCESSNAME AS DISPLAYFIELD
		--    FROM   PROCESSMASTER
		--    WHERE  (P_STRWHERE2 = 'A'
		--      AND (P_STRWHERE = '01'
		--        AND SUBSTR(PROCESSCODE, 0, 1) = 'A'))
		--        OR (P_STRWHERE2 = 'I'
		--         AND (P_STRWHERE = '01'
		--        AND SUBSTR(PROCESSCODE, 0, 1) <> 'A'))
		--        OR (P_STRWHERE2 = 'M'
		--         AND ((SUBSTR(PROCESSCODE, 0, 1) <> 'A'
		--         AND NVL(PROCESSDIV, '') = P_STRWHERE)
		--        OR (SUBSTR(PROCESSCODE, 0, 1) <> 'A'
		--         AND NVL(PROCESSDIV, '') = P_STRWHERE)));
		ELSIF P_DIV = '원가원부자재구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'원자재' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT '2' AS KEYFIELD
					  ,'부자재' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT '9' AS KEYFIELD
					  ,'원료상품' AS DISPLAYFIELD
				  FROM SYSPARAMETERMANAGE
				 WHERE PARAMETERCODE = 'calmaterial'
					   AND VALUE2 = 'Y';
		ELSIF P_DIV = '원가제상품구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'제품' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT '2' AS KEYFIELD
					  ,'상품' AS DISPLAYFIELD
				  FROM DUAL
				UNION ALL
				SELECT '9' AS KEYFIELD
					  ,'재공' AS DISPLAYFIELD
				  FROM DUAL;
		ELSIF P_DIV = '영업형태'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'제조' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '2' AS KEYFIELD
					  ,'수입' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '3' AS KEYFIELD
					  ,'도매' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '4' AS KEYFIELD
					  ,'제조||수입' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '5' AS KEYFIELD
					  ,'재조||도매' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '6' AS KEYFIELD
					  ,'수입||도매' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '7' AS KEYFIELD
					  ,'제조||수입||도매' AS DISPLAYFIELD
				  FROM DUAL;
		ELSIF P_DIV = '영업형태'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'제조' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '2' AS KEYFIELD
					  ,'수입' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '3' AS KEYFIELD
					  ,'도매' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '4' AS KEYFIELD
					  ,'제조||수입' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '5' AS KEYFIELD
					  ,'재조||도매' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '6' AS KEYFIELD
					  ,'수입||도매' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '7' AS KEYFIELD
					  ,'제조||수입||도매' AS DISPLAYFIELD
				  FROM DUAL;
		ELSIF P_DIV = '계약구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'수의계약(기부,폐기포함)' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '2'
					  ,'경쟁입찰'
				  FROM DUAL;
		ELSIF P_DIV = '공급구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'출고' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '2'
					  ,'반품'
				  FROM DUAL
				UNION
				SELECT '3'
					  ,'폐기'
				  FROM DUAL
				UNION
				SELECT '4'
					  ,'오류수정'
				  FROM DUAL
				UNION
				SELECT '5'
					  ,'취소'
				  FROM DUAL;
		ELSIF P_DIV = '공급형태'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT '1' AS KEYFIELD
					  ,'수출용' AS DISPLAYFIELD
				  FROM DUAL
				UNION
				SELECT '2'
					  ,'기부용'
				  FROM DUAL
				UNION
				SELECT '3'
					  ,'군납용'
				  FROM DUAL
				UNION
				SELECT '4'
					  ,'개인용'
				  FROM DUAL
				UNION
				SELECT '5'
					  ,'요양기관공급'
				  FROM DUAL
				UNION
				SELECT '6'
					  ,'의약품공급업체공급'
				  FROM DUAL
				UNION
				SELECT '7'
					  ,'견본품'
				  FROM DUAL
				UNION
				SELECT '8'
					  ,'안전상비의약품 판매처'
				  FROM DUAL
				UNION
				SELECT '9'
					  ,'특수의료시설,학술기관 등 공급'
				  FROM DUAL;
		ELSIF P_DIV = '일련번호구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT '0' AS KEYFIELD
					  ,'미존재' AS DISPLAYFIELD
				  FROM DUAL --int 인식 불가로 string으로 처리
				UNION
				SELECT '1'
					  ,'존재'
				  FROM DUAL
				UNION
				SELECT '2'
					  ,'일부존재'
				  FROM DUAL;
		ELSIF P_DIV = '수입상품분류' -- 원료/자재
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT divcode AS keyfield
					  ,divname AS displayfield
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE cmmcode = 'CMM01'
					   AND filter1 = '05'
					   AND usediv = 'Y'
				UNION
				SELECT divcode AS keyfield
					  ,divname AS displayfield
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE cmmcode = 'MPM09'
					   AND filter1 = 'B'
					   AND usediv = 'Y'
              ORDER BY VIEWRANK           
                       ;
		--filter1 = B | 09:수입반제품 + itemdiv = '05'
		ELSIF P_DIV = '정규직구분'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'PS41'
					   AND DIVCODE IN ('01', '03')
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK       
                       ;
		ELSIF P_DIV = '통화코드2'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				 WHERE DIFF = P_DIFF
				UNION ALL
				SELECT divcode AS KEYFIELD
					  ,divcode AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE CMMCODE = 'TR01'
					   AND USEDIV = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF p_div = '인도조건'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT divcode AS keyfield
					  ,divname AS displayfield
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE cmmcode = 'TR05'
					   AND usediv = 'Y'
              ORDER BY VIEWRANK        
                       ;
		ELSIF p_div = '은행코드2'
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT divcode AS keyfield
					  ,divname AS displayfield
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE UPPER(cmmcode) = 'TR42'
					   AND usediv = 'Y'
              ORDER BY VIEWRANK         
                       ;
		ELSIF (p_div = '영업구분2')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
                      ,VIEWRANK
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT DIVCODE AS KEYFIELD
					  ,DIVNAME AS DISPLAYFIELD
                      ,VIEWRANK
				  FROM CMCOMMONM
				 WHERE cmmcode = 'AS02'
					   AND NVL(filter1, ' ') LIKE p_strwhere2 || '%'
					   AND usediv = 'Y'
					   AND DIVCODE NOT IN ('50')
              ORDER BY VIEWRANK       
                       ;
		ELSIF (p_div = '일반자재창고정보')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL
				SELECT location keyfield
					  ,locname displayfield
				  FROM GMLOCATIONM
				ORDER BY keyfield;
		ELSIF (p_div = '업무구분')
		THEN
			OPEN IO_CURSOR FOR
				SELECT KEYFIELD
					  ,DISPLAYFIELD
				  FROM VGT.TT_MASTERBASE_DUAL
				UNION ALL 
				SELECT seq keyfield
					  ,workdiv displayfield
				  FROM PSWORKDIV
				 WHERE deptcode = P_STRWHERE
					   AND useyn = 'Y'
				ORDER BY keyfield;
        
        --환율정보
        ELSIF (p_div = 'EXRATE')
		THEN
        	FOR REC IN(
            	SELECT NVL(BASIC_RATE, 0) AS EXCHGRATE
                  FROM COM_EXHG_OTHERBANK@REAL_SALE.HANA.CO.KR
                 WHERE BANK_CD    = '10000081'
                   AND BASIC_SEQ  = 1
                   AND BASIC_DATE = P_STRWHERE 
                   AND CURR_CD    = P_STRWHERE2
            )
            LOOP
            	IP_STRWHERE := REC.EXCHGRATE;
            END LOOP;
			
               
            MESSAGE := IP_STRWHERE;
            
        ELSIF (p_div = 'EXRATE_EXPORT')
        THEN
            FOR REC IN(
                SELECT NVL(BASIC_RATE, 0) AS EXCHGRATE
                  FROM COM_EXHG_OTHERBANK@REAL_SALE.HANA.CO.KR
                 WHERE BANK_CD    = '10000081'
                   AND BASIC_SEQ  = 1
                   AND BASIC_DATE = replace(P_STRWHERE,'-','')
                   AND CURR_CD    = P_STRWHERE2
            )
            LOOP
                IP_STRWHERE := REC.EXCHGRATE;
            END LOOP;
            
            IF (IP_STRWHERE = P_STRWHERE)
            THEN
                IP_STRWHERE := 0;
            END IF;
               
            MESSAGE := IP_STRWHERE;
            
        ELSIF P_DIV = '계약서구분'
        THEN
            OPEN IO_CURSOR FOR
                    SELECT KEYFIELD, DISPLAYFIELD, VIEWRANK
                      FROM VGT.TT_MASTERBASE_DUAL
                     WHERE DIFF = P_DIFF
                    UNION ALL
                    SELECT DIVCODE AS KEYFIELD, DIVNAME AS DISPLAYFIELD, VIEWRANK
                      FROM CMCOMMONM
                     WHERE CMMCODE = 'PS58' 
                      AND DIVCODE in('01','02')
                      AND USEDIV = 'Y'
                 ORDER BY VIEWRANK    
                      ;
                      
        ELSIF P_DIV = '반제품구분'
        THEN
            OPEN IO_CURSOR FOR
                    SELECT KEYFIELD, DISPLAYFIELD, VIEWRANK
                      FROM VGT.TT_MASTERBASE_DUAL
                     WHERE DIFF = P_DIFF
                    UNION ALL
                    SELECT DIVCODE AS KEYFIELD
                    ,      REPLACE(DIVNAME, '시험', '') AS DISPLAYFIELD
                    ,      VIEWRANK
                      FROM CMCOMMONM
                     WHERE CMMCODE = 'LMM04' 
                      AND DIVCODE in('03','04')
                      AND USEDIV = 'Y'
                 ORDER BY VIEWRANK    
                      ;
                      
        ELSIF P_DIV = '출고차수'
        THEN
            OPEN IO_CURSOR FOR
                SELECT KEYFIELD
                      ,DISPLAYFIELD
                  FROM VGT.TT_MASTERBASE_DUAL
            
                UNION ALL
            
                SELECT distinct TO_CHAR(fixseq) AS KEYFIELD,
                                TO_CHAR(fixseq) AS DISPLAYFIELD
                  FROM   SLORDM a
                       JOIN SLSTOREHOUSEM b
                             ON a.warehouse = b.warehouse
                 WHERE  orderdate = P_STRWHERE
              ORDER BY  KEYFIELD;
        
        ELSIF P_DIV = '제조단위'
        THEN
            OPEN IO_CURSOR FOR
                    
                    SELECT DISTINCT
                           KEYFIELD
                    ,      DISPLAYFIELD
                    FROM   (                           
                                SELECT manufactureqty KEYFIELD
                                ,REGEXP_REPLACE(REVERSE(REGEXP_REPLACE( REVERSE(TO_CHAR(manufactureqty)), '([0-9]{3})','\1,')), '^,','') DISPLAYFIELD                                       
                                FROM   MakingOrders
                                WHERE  orderno = p_strwhere2
                                
                                UNION ALL
                                SELECT   a.batchsize KEYFIELD,
                                         REGEXP_REPLACE(REVERSE(REGEXP_REPLACE( REVERSE(TO_CHAR(a.batchsize)), '([0-9]{3})','\1,')), '^,','') DISPLAYFIELD
                                FROM     prescriptionrevisionmanage a
                                         INNER JOIN CMITEMM b
                                            ON a.itemcode = b.itemcode
                                         INNER JOIN GoodsStandardRevision c
                                            ON a.itemcode = c.itemcode
                                            and a.revisionno = c.revisionno
                                            and c.usediv = 'Y'
                                WHERE     a.itemcode = p_strwhere 
--                                SELECT   a.batchsize KEYFIELD
--                                ,        REGEXP_REPLACE(REVERSE(REGEXP_REPLACE( REVERSE(TO_CHAR(a.batchsize)), '([0-9]{3})','\1,')), '^,','') DISPLAYFIELD
--                                FROM     prescriptionrevisionmanage a
--                                         INNER JOIN CMITEMM b
--                                            ON a.itemcode = b.itemcode
--                                WHERE     a.itemcode = p_strwhere
                            );
        ELSIF P_DIV = '기타시험종류'
        THEN
            OPEN IO_CURSOR FOR
                SELECT KEYFIELD
                      ,DISPLAYFIELD
                      ,VIEWRANK
                  FROM VGT.TT_MASTERBASE_DUAL
            
                UNION ALL
            
                SELECT  DIVCODE AS KEYFIELD,
                        DIVNAME AS DISPLAYFIELD,
                        VIEWRANK
                  FROM  CMCOMMONM  
                 WHERE  CMMCODE = 'LMM04'
                   AND  DIVCODE NOT IN ('01', '02', '03', '04' ,'05', '11')
                   AND  USEDIV = 'Y'
              ORDER BY  VIEWRANK, KEYFIELD;        
              
        ELSIF ( P_DIV = 'CMCUSTM' ) THEN 		        
        
			        SELECT custname 
              INTO   MESSAGE
              FROM   CMCUSTM
              WHERE  custcode = p_strwhere;
              
        ELSIF P_DIV = '제조오퍼처'
        THEN
            OPEN IO_CURSOR FOR

                SELECT  DIVCODE AS KEYFIELD,
                        DIVNAME AS DISPLAYFIELD
                  FROM  CMCOMMONM  
                 WHERE  CMMCODE = 'CM11'
                   AND  DIVCODE IN ('5', '7')
                   AND  USEDIV = 'Y'
              ORDER BY  VIEWRANK, KEYFIELD;   
		                    
		END IF;

		IF (IO_CURSOR IS NULL)
		THEN
			OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
		END IF;
	END SPGETCOMMON;
END GETCOMMON_PKG;
/
