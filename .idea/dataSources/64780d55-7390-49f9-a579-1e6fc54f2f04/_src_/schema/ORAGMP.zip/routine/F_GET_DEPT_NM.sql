CREATE FUNCTION        F_GET_DEPT_NM(
        I_DEPT_CD IN STRING
)
        RETURN VARCHAR2 IS
        V_DEPTNAME ORAGMP.CMDEPTM.DEPTNAME%TYPE;
        -- 부서명칭 가져오기 ( 한글 )
BEGIN
        SELECT DEPTNAME
        INTO V_DEPTNAME
        FROM ORAGMP.CMDEPTM DEPT
        WHERE DEPTCODE = I_DEPT_CD;
        
        IF SQLCODE <> 0 THEN
                V_DEPTNAME := ' ';
        END IF;
        
        RETURN V_DEPTNAME;
EXCEPTION
        WHEN NO_DATA_FOUND THEN
        
        IF V_DEPTNAME IS NULL THEN
                V_DEPTNAME := ' ';
        END IF;
        
        RETURN V_DEPTNAME;
END;
/
