CREATE PROCEDURE        SPACACC0900NP(
-- ---------------------------------------------------------------
-- 프로시저명    : spACacc0900NP
-- 작 성 자      : 최용석
-- 작성일자      : 2012-08-22
-- 수정내역      : 2011-01-19 이영재 집계,현금처리 수정
-- 수 정 자      : 노영래
-- E-Mail        : 0rae0926@gmail.com
-- 수정일자      : 2016-12-20
-- ---------------------------------------------------------------
-- 프로시저 설명 : 수입비용회계로드
-- ---------------------------------------------------------------
    p_div             IN  VARCHAR2 DEFAULT '',

    p_compcode        IN  VARCHAR2 DEFAULT '', --법인코드
    p_plantcode       IN  VARCHAR2 DEFAULT '',
    p_sdt             IN  VARCHAR2 DEFAULT '',
    p_edt             IN  VARCHAR2 DEFAULT '',
    p_loadstatus      IN  VARCHAR2 DEFAULT '',
    p_custcode        IN  VARCHAR2 DEFAULT '',
    p_importshtno     IN  VARCHAR2 DEFAULT '',
    p_iempcode        IN  VARCHAR2 DEFAULT '',

    p_taxno           IN  VARCHAR2 DEFAULT '',
    p_buydiv          IN  VARCHAR2 DEFAULT '',
    p_custname        IN  VARCHAR2 DEFAULT '',
    p_businessno      IN  VARCHAR2 DEFAULT '',
    p_taxamt1         IN  FLOAT    DEFAULT 0,
    p_taxamt2         IN  FLOAT    DEFAULT 0,
    p_taxamt3         IN  FLOAT    DEFAULT 0,
    p_itemnm          IN  VARCHAR2 DEFAULT '', --매입 적요와 상품명(세금계산서)
    p_deptcode        IN  VARCHAR2 DEFAULT '',
    p_actrnstate      IN  VARCHAR2 DEFAULT '',
    p_acatrulecode    IN  VARCHAR2 DEFAULT '',
    p_agencode        IN  VARCHAR2 DEFAULT '',
    p_expamt1         IN  FLOAT    DEFAULT 0,
    p_expamt2         IN  FLOAT    DEFAULT 0,
    p_expamt3         IN  FLOAT    DEFAULT 0,
    p_expamt4         IN  FLOAT    DEFAULT 0,
    p_expamt5         IN  FLOAT    DEFAULT 0,
    p_expamt6         IN  FLOAT    DEFAULT 0,
    p_expamt          IN  FLOAT    DEFAULT 0,
    p_expvat          IN  FLOAT    DEFAULT 0,
    p_electaxyn       IN  VARCHAR2 DEFAULT '',
    p_lccode          IN  VARCHAR2 DEFAULT '',
    p_lcname          IN  VARCHAR2 DEFAULT '',

    p_slipindate      IN  VARCHAR2 DEFAULT '',
    p_slipinseq       IN  NUMBER   DEFAULT 0,

    p_userid          IN  VARCHAR2 DEFAULT '',
    p_reasondiv       IN  VARCHAR2 DEFAULT '',
    p_reasontext      IN  VARCHAR2 DEFAULT '',
    MESSAGE           OUT VARCHAR2,
    IO_CURSOR         OUT TYPES.DATASET
)
AS
    v_temp                NUMBER       := 0;
    p_slipno              VARCHAR2(20) := '';
    p_slipinno            VARCHAR2(20) := '';
    ip_taxno              VARCHAR2(20) := p_taxno;
    p_chktaxno            VARCHAR2(20) := '';
BEGIN
    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    for rec in (
        select  count(compcode) as cnt
        from    CMCLOSEM
        where   compcode = p_compcode
                and closeym between substr(p_sdt, 1, 7) and substr(p_edt, 1, 7)
                and accdiv = 'N'
                and apprcloseyn = 'Y')
    loop
        v_temp := rec.cnt;
    end loop ;

    if v_temp > 0 then
        goto last;
    end if;

    execute immediate 'delete from VGT.TT_ACACC0900NP_PDCOSTM';
    insert into VGT.TT_ACACC0900NP_PDCOSTM
    select  row_number() over(order by a.acccode) as ord
            ,a.acccode
            ,b.accname
    from (
        select  dracccode as acccode from PDCOSTM
        union
        select  dracccode2 from PDCOSTM
        union
        select  cracccode from PDCOSTM
        union
        select  cracccode2 from PDCOSTM
    ) a
            join ACACCM b on
                a.acccode = b.acccode;

    execute immediate 'delete from VGT.TT_ACACC0900NP_ACACC0900NP';
    if (p_div = 'T') then
        open IO_CURSOR for
        select  acccode
                ,accname
        from    VGT.TT_ACACC0900NP_PDCOSTM
        order by acccode;

    elsif(p_div = 'S') then
        -- 기본 세금계산서 자료 조회
        insert into VGT.TT_ACACC0900NP_ACACC0900NP
        select  p_compcode                      -- 회사코드
                ,nvl(b.plantcode, a.plantcode)  -- 사업장코드
                ,nvl(c.plantname, '')           -- 사업장명
                ,'N' chkyn                      -- 선택
                ,a.taxdate                      -- 발행일자
                ,a.taxseq                       -- 발행순번
                ,a.custcode                     -- 거래처코드
                ,nvl(d.custname, '')            -- 거래처명
                ,a.agencode                     -- 대행처코드
                ,nvl(j.custname, '')            -- 대행처명
                ,nvl(a.buydiv, '04')            -- 매입구분
                ,nvl(e.divname, '')             -- 매입구분명
                ,nvl(f.deptcode, '')            -- 부서코드
                ,nvl(g.deptname, '')            -- 부서명
                ,case when trim(a.buydiv) is null then a.importshtno || a.costseq else a.taxno end -- 계산서번호,
                ,a.importshtno
                ,nvl(k.lccode, '')
                ,nvl(k.lcname, '')
                ,to_number(nvl(a.expamt1, 0))
                ,to_number(nvl(a.expamt2, 0))
                ,to_number(nvl(a.expamt3, 0))
                ,to_number(nvl(a.expamt4, 0))
                ,to_number(nvl(a.expamt5, 0))
                ,to_number(nvl(a.expamt6, 0))
                ,to_number(nvl(a.amt, 0))
                ,to_number(nvl(a.vat, 0))
                ,nvl(k.lcname, '') || nvl(' / ' || a.costname, '')
                ,nvl(d.businessno, '')          -- 사업자번호
                ,a.icntitem                     -- 품목건수
                ,nvl(nullif(b.importsdate, null), p_sdt) -- 시작일
                ,nvl(nullif(b.importedate, null), p_edt) -- 종료일
                ,case when length(rtrim(c.businessno)) = 12 then '01' else '02' end -- 사업자구분
                ,nvl(a.itemname, '') || case when a.icntitem > 1 then + ' 외' || to_char(a.icntitem - 1) || '건' else '' end || ' 수입비용' -- 적요
                ,'N010' || nvl(a.buydiv, '04')  -- 자동분계코드
                ,case when trim(h.acatno) is null then '1'
                      when trim(h.slipinno) is null then '2'
                      when i.slipinno is null or (select sum(creamt) from ACORDD where compcode = i.compcode and slipinno = i.slipinno) - a.expamt1 <> 0 then '3'
                      else '2' end              -- 전표자료상태
                ,case when h.acatno is null then '신규로드전송전'
                      when h.slipinno is null then '로드완료전표처리전'
                      when i.slipinno is null or ( select sum(creamt) from ACORDD where compcode = i.compcode and slipinno = i.slipinno ) - a.expamt1 <> 0 and i.slipinstate <> '4' then '회계전표재전송'
                      when ( select sum(creamt) from ACORDD where compcode = i.compcode and slipinno = i.slipinno ) - a.expamt1 <> 0 and i.slipinstate = '4' then '회계전표재전송(승인)'
                      when i.slipinstate = '4' then '전표처리완료(승인)'
                      else '전표처리완료' end    -- 전표자료상태명
                ,h.slipinno
                ,case when trim(a.buydiv) is null then '4'
                      when trim(a.taxno) is null then '1'
                      when b.taxno is null or a.vat - b.vat <> 0 then '3'
                      else '2' end              -- 계산서자료상태
                ,case when trim(a.buydiv) is null then '계산서미전송'
                      when trim(a.taxno) is null then '신규로드전송전'
                      when b.taxno is null or a.vat - b.vat <> 0 then '계산서재전송'
                      else '계산서처리완료' end  -- 계산서자료상태명
                ,case when h.slipinno is null then 'N' when i.slipinno is null then 'Y' else 'N' end -- 전표처리여부
                ,nvl(a.electaxyn, 'N')
        from (
            select  b.plantcode -- 사업장코드
                    ,a.custcost as custcode -- 거래처코드
                    ,a.accountday as taxdate -- 세금계산서일자
                    ,nvl(a.accountseq, 0) as taxseq -- 세금계산서순번
                    ,nvl(a.accountno, '') as taxno -- 세금계산서번호
                    ,max(a.importshtno) as importshtno -- 수입전표번호
                    ,max(c.lccode) as lccode -- lc코드
                    ,max(e.costname) as costname -- 비용명
                    ,min('-' || substr('00' || to_char(a.costseq), -2, 2)) as costseq -- 수입일련번호
                    ,max(a.custcode) as agencode -- 대행처
                    ,max(case when a.accountyn = 'Y' then a.accountdiv end) as buydiv -- 매입구분(MPM17) 01:과세 02:면세 03:영세율
                    ,max(case when a.accountyn = 'Y' then a.elcaccount end) as electaxyn -- 전자세금계산서여부
                    ,sum(case when d.grp = 1 and f.ord = 1 then a.costamt
                              when d.grp = 2 and g.ord = 1 then a.costamt + a.vat
                              else 0 end ) as expamt1
                    ,sum(case when d.grp = 1 and f.ord = 2 then a.costamt
                              when d.grp = 2 and g.ord = 2 then a.costamt + a.vat
                              else 0 end ) as expamt2
                    ,sum(case when d.grp = 1 and f.ord = 3 then a.costamt
                              when d.grp = 2 and g.ord = 3 then a.costamt + a.vat
                              else 0 end ) as expamt3
                    ,sum(case when d.grp = 1 and f.ord = 4 then a.costamt
                              when d.grp = 2 and g.ord = 4 then a.costamt + a.vat
                              else 0 end ) as expamt4
                    ,sum(case when d.grp = 1 and f.ord = 5 then a.costamt
                              when d.grp = 2 and g.ord = 5 then a.costamt + a.vat
                              else 0 end ) as expamt5
                    ,sum(case when d.grp = 1 and f.ord = 6 then a.costamt
                              when d.grp = 2 and g.ord = 6 then a.costamt + a.vat
                              else 0 end ) as expamt6
                    ,sum(case when a.accountyn = 'Y' then a.costamt else 0 end) / 2 as amt -- 경비금액
                    ,sum(case when a.accountyn = 'Y' then a.vat else 0 end) / 2 as vat -- 부가세
                    ,max(nvl(h.itemname, '')) as itemname -- 품목명
                    ,max(nvl(b.icntitem, 1)) as icntitem -- 품목건수
                    ,max(nvl(a.accountcheck, '')) as accountcheck -- 회계전표 연결 확인
                    ,min(a.remark) || case when min(a.remark) <> max(a.remark) then ', ' || max(a.remark) else '' end as remark
            from    PDIMPORTCOSTM a
                    join (
                        select  a.importshtno
                                ,max(c.plantcode) as plantcode
                                ,max(c.itemcode) as itemcode
                                ,max(c.purchaseorderdiv) as purchaseorderdiv
                                ,count(distinct c.orderno) as icntitem
                        from    PDIMPORTCOSTM a
                                join PDIMPORTSHEETD b
                                    on a.importshtno = b.importshtno
                                left join PDPURCHASEORDERM c
                                    on b.requestno = c.orderno
                                    and b.itemcode = c.itemcode
                        where   a.accountday between p_sdt and p_edt
                        group by a.importshtno
                    ) b on a.importshtno = b.importshtno
                    join PDIMPORTSHEETM c
                        on a.importshtno = c.importshtno
                    join (
                        select 1 grp from DUAL
                        union
                        select 2 from DUAL
                    ) d on 1 = 1
                    join PDCOSTM e
                        on a.costcode = e.costcode
                    left join VGT.TT_ACACC0900NP_PDCOSTM f
                        on case when b.purchaseorderdiv = '01' then e.dracccode else e.dracccode2 end = f.acccode
                    left join VGT.TT_ACACC0900NP_PDCOSTM g
                        on case when b.purchaseorderdiv = '01' then e.cracccode else e.cracccode2 end = g.acccode
                    left join CMITEMM h
                        on b.itemcode = h.itemcode
            where   nvl(a.importshtno, ' ') like p_importshtno || '%'
                    and a.accountday between p_sdt and p_edt
            group by b.plantcode, a.custcost, a.accountday, nvl(a.accountseq, 0), nvl(a.accountno, '')
        ) a
                left join ACTAXM b
                    on b.compcode = p_compcode
                    and a.taxno = b.taxno
                left join CMPLANTM c
                    on nvl(b.plantcode, a.plantcode) = c.plantcode
                left join CMCUSTM d
                    on a.custcode = d.custcode
                left join CMCOMMONM e
                    on e.cmmcode = 'MPM17'
                    and nvl(a.buydiv, '04') = e.divcode
                left join CMEMPM f
                    on f.empcode = p_iempcode
                left join CMDEPTM g
                    on f.deptcode = g.deptcode
                left join ACAUTOORDT h
                    on h.compcode = p_compcode
                    and h.acatrulecode = 'N010' || nvl(a.buydiv, '04')
                    and case when trim(a.buydiv) is null then a.importshtno || a.costseq else a.taxno end = h.acatno
                left join ACORDM i
                    on h.compcode = i.compcode
                    and h.slipinno = i.slipinno
                left join CMCUSTM j
                    on a.agencode = j.custcode
                left join ACLCM k
                    on a.lccode = k.lccode
        order by a.custcode;

        -- 삭제 상태 확인
        insert into VGT.TT_ACACC0900NP_ACACC0900NP
        select  nvl(a.compcode, '') as compcode
                ,nvl(a.plantcode, '') as plantcode
                ,nvl(c.plantname, '') as plantname
                ,'N' as chkyn
                ,nvl(a.slipindate, '') as slipindate
                ,1 as slipinseq
                ,nvl(a.custcode, '') as custcode
                ,nvl(a.userdef6code, '') as custname
                ,nvl(a.userdef1code, '') as agencode
                ,nvl(a.userdef7code, '') as agenname
                ,g.divcode as buydiv
                ,g.divname as buydivname
                ,nvl(a.deptcode, '') as deptcode
                ,nvl(a.userdef4code, '') as deptname
                ,nvl(a.taxno, '') as taxno
                ,nvl(a.billno, '') as importshtno
                ,nvl(a.userdef9code, '') as lccode
                ,nvl(a.userdef10code, '') as lcname
                ,nvl(a.trn1amt, 0) as expamt1
                ,nvl(a.trn2amt, 0) as expamt2
                ,nvl(a.trn3amt, 0) as expamt3
                ,nvl(a.trn4amt, 0) as expamt4
                ,nvl(a.trn5amt, 0) as expamt5
                ,nvl(a.trn6amt, 0) as expamt6
                ,nvl(a.trn11amt, 0) as expamt
                ,nvl(a.trn12amt, 0) as expvat
                ,a.remark || '[삭제]' as remark
                ,d.businessno as businessno
                ,0 as icntitem
                ,nvl(e.importsdate, '') as sdt
                ,nvl(e.importedate, '') as edt
                ,case when length(rtrim(d.businessno)) = 12 then '01' else '02' end -- 사업자구분
                ,a.remark || '[삭제]' as itemnm
                ,nvl(a.acatrulecode, '') as autorulecode
                ,case when trim(f.slipinno) is not null then '4' else '2' end as acctrnchk
                ,case when trim(f.slipinno) is not null then '전표삭제전송필요' else '' end as acctrnchk2
                ,f.slipinno
                ,case when trim(e.taxno) is not null then '4' else '2' end as taxloadyn
                ,case when trim(e.taxno) is not null then '계산서삭제전송필요' else '' end as taxloadtatus
                ,'N' as newchk
                ,nvl(e.electaxyn, 'N') as electaxyn
        from    ACAUTOORDT a
                left join VGT.TT_ACACC0900NP_ACACC0900NP b
                    on a.acatno = b.taxno
                left join CMPLANTM c
                    on a.plantcode = c.plantcode
                left join CMCUSTM d
                    on a.custcode = d.custcode
                left join ACTAXM e
                    on a.compcode = e.compcode
                    and a.taxno = e.taxno
                left join ACORDM f
                    on a.compcode = f.compcode
                    and a.slipinno = f.slipinno
                left join CMCOMMONM g
                    on g.cmmcode = 'MPM17'
                    and substr(a.acatrulecode, -2, 2) = g.divcode
        where   a.compcode = p_compcode
                and a.acattype = 'N'
                and a.acatrulecode like 'N010%'
                and a.slipindate between p_sdt and p_edt
                and b.taxno is null
                and trim(p_importshtno) is null;

        if (p_loadstatus = '1' or p_loadstatus = '2' or p_loadstatus = '3') then  --로드 상태를 선택
            delete
            from    VGT.TT_ACACC0900NP_ACACC0900NP
            where   actrnstate not in ( select  filter1
                                        from    CMCOMMONM
                                        where   cmmcode = 'AC082'
                                                and divcode = p_loadstatus
                                        union
                                        select  filter2
                                        from    CMCOMMONM
                                        where   cmmcode = 'AC082'
                                                and divcode = p_loadstatus);
        end if;

        if (p_plantcode <> '%') then
            delete
            from    VGT.TT_ACACC0900NP_ACACC0900NP
            where   plantcode <> p_plantcode;
        end if;

        if (p_custcode is not null) then
            delete
            from    VGT.TT_ACACC0900NP_ACACC0900NP
            where   custcode <> p_custcode;
        end if;

        open IO_CURSOR for
        select  a.*
                ,a.expamt + a.expvat as expsum
        from    VGT.TT_ACACC0900NP_ACACC0900NP a
        order by plantcode, custcode, slipindate, slipinseq;

    elsif (p_div = 'SD') then
        --상세 내용 정보 확인
        open IO_CURSOR for
        select  nvl(a.importshtno, '') as importshtno
                ,nvl(a.costcode, '') as costcode
                ,nvl(d.costname, '') as costname
                ,nvl(a.costamt, 0) as costamt
                ,nvl(a.vat, 0) as vat
                ,nvl(a.costamt, 0) + nvl(a.vat, 0) as sumamt
                ,nvl(b.orderno, '') as orderno
                ,nvl(b.itemcode, '') as itemcode
                ,nvl(c.itemname, '') as itemname
                ,nvl(c.itemdiv, '') as itemdiv
                ,nvl(e.divname, '') as itemdivname
        from    PDIMPORTCOSTM a
                left join (
                    select  a.importshtno
                            ,max(b.orderno) as orderno
                            ,max(b.itemcode) as itemcode
                    from    PDIMPORTCOSTM a
                            join PDPURCHASEORDERM b
                                on a.importshtno = b.importshtno
                    where   b.plantcode = p_plantcode
                            and a.custcost = p_custcode
                            and a.accountday = p_slipindate
                            and nvl(a.accountseq, 0) = p_slipinseq
                    group by a.importshtno
                ) b on a.importshtno = b.importshtno
                left join CMITEMM c
                    on b.itemcode = c.itemcode
                left join PDCOSTM d
                    on a.costcode = d.costcode
                left join CMCOMMONM e
                    on e.cmmcode = 'CMM01'
                    and c.itemdiv = e.divcode
        where   a.custcost = p_custcode
                and a.accountday = p_slipindate
                and nvl(a.accountseq, 0) = p_slipinseq;

    elsif (p_div = 'ctax') then --세금계산서 존재확인. 매입로드에서 사용
        p_chktaxno := '';

        for rec in (
            select  nvl(taxno, '') as taxno
            from    ACTAXM
            where   compcode = p_compcode
                    and taxno = p_taxno)
        loop
            p_chktaxno := rec.taxno;
        end loop;

        if p_chktaxno is null or trim(p_chktaxno) = '' then
            MESSAGE := 'No';
        else
            MESSAGE := 'Yes';
        end if;

    elsif (p_div = 'itax') then
        --세금계산서 생성.
        ip_taxno := substr(replace(p_slipindate, '-', ''), 0, 6) || '05'; --매입구분 수입비용자동생성구분

        for rec in (
            select  ip_taxno || substr('00000' || to_char((nvl(substr(max(taxno), -5, 5), 0) + 1)), -5, 5) as taxno
            from    ACTAXM
            where   compcode = p_compcode
                    and taxno like ip_taxno || '%'
                    and length(taxno) = 13
                    and iotaxdiv = '01'
                    and saleinyn = 'Y')
        loop
            ip_taxno := rec.taxno; --수입비용 구분 매입세금계산서
        end loop;

        insert into ACTAXM
            (
                compcode
                ,plantcode
                ,taxno -- yyyymm03nnnnn
                ,taxdiv --계산서 구분(  select * from CMCOMMONM where cmmcode = 'ac60'  )
                ,iotaxdiv --매입매출구분( select * from CMCOMMONM where cmmcode = 'ac61'  )
                ,sdeptcode
                ,taxdate
                ,custcode
                ,custname
                ,businessno
                ,biznotype --사업자구분( select * from CMCOMMONM where cmmcode = 'ac65'  )
                ,blankcnt
                ,amt
                ,vat
                ,vatamt
                ,purposediv --영수청구구분(  select * from CMCOMMONM where cmmcode = 'ac62'   )
                ,credittot
                ,importsdate
                ,importedate
                ,electaxyn --전자세금계산서여부
                ,purdiv
                ,saleinyn --수입자동생성여부
                ,insertdt
                ,iempcode
            )
        values
            (
                p_compcode
                ,p_plantcode
                ,ip_taxno -- yyyymm03nnnnn  번호 생성
                ,case when p_buydiv = '01' then '201' --매입-과세 계산서 구분(  select * from CMCOMMONM where cmmcode = 'ac60'  )
                      when p_buydiv = '02' then '203' --매입-계산서 계산서 구분(  select * from CMCOMMONM where cmmcode = 'ac60'  )
                      when p_buydiv = '03' then '202' --매입-영세 계산서 구분(  select * from CMCOMMONM where cmmcode = 'ac60'  )
                      else '201' end --계산서 구분(  select * from CMCOMMONM where cmmcode = 'ac60'  )
                ,'01' --매입매출구분( select * from CMCOMMONM where cmmcode = 'ac61'  )
                ,''
                ,p_slipindate
                ,p_custcode
                ,p_custname
                ,p_businessno
                ,'01' --사업자구분( select * from CMCOMMONM where cmmcode = 'ac65'  )
                ,0
                ,case when p_taxamt1 = 0 and p_buydiv = '01' then p_taxamt2 * 10 else p_taxamt1 end
                ,p_taxamt2
                ,case when p_taxamt1 = 0 and p_buydiv = '01' then p_taxamt2 * 10 + p_taxamt2 else p_taxamt3 end
                ,'02' --영수청구구분(  select * from CMCOMMONM where cmmcode = 'ac62'   )
                ,p_taxamt3
                ,p_slipindate
                ,p_slipindate
                ,p_electaxyn --전자세금계산서여부
                ,'0'
                ,'Y' --수입자동생성여부
                ,sysdate
                ,p_iempcode
            );

        insert into ACTAXD
            (
                compcode
                ,plantcode
                ,taxno -- yyyymm03nnnnn
                ,seq
                ,itemnm -- item
                ,amt
                ,vat
                ,vatamt
                ,insertdt
                ,iempcode
            )
        values
            (
                p_compcode
                ,p_plantcode
                ,ip_taxno -- yyyymm03nnnnn  번호 생성
                ,1
                ,p_itemnm -- + ' 외'
                ,case when p_taxamt1 = 0 and p_buydiv = '01' then p_taxamt2 * 10 else p_taxamt1 end
                ,p_taxamt2
                ,case when p_taxamt1 = 0 and p_buydiv = '01' then p_taxamt2 * 10 + p_taxamt2 else p_taxamt3 end
                ,sysdate
                ,p_iempcode
            );

        merge into PDIMPORTCOSTM a
        using (
            select  a.importshtno
                    ,a.costseq
            from    PDIMPORTCOSTM a
                    left join PDPURCHASEORDERM b
                        on a.importshtno = b.importshtno
            where   b.plantcode = p_plantcode
                    and a.custcost = p_custcode
                    and a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.importshtno = src.importshtno
                  and a.costseq = src.costseq )
        when matched then
            update set a.accountno = ip_taxno;

    elsif (p_div = 'utax') then --세금계산서 수정.
        merge into ACTAXM a
        using (
            select  a.compcode
                    ,a.plantcode
                    ,a.taxno
                    ,case when p_buydiv = '01' then '201' --매입-과세 계산서 구분(  select * from CMCOMMONM where cmmcode = 'ac60'  )
                          when p_buydiv = '02' then '203' --매입-계산서 계산서 구분(  select * from CMCOMMONM where cmmcode = 'ac60'  )
                          when p_buydiv = '03' then '202' --매입-영세 계산서 구분(  select * from CMCOMMONM where cmmcode = 'ac60'  )
                          else '201' end as pos_2
                    ,case when p_taxamt1 = 0 and p_buydiv = '01' then p_taxamt2 * 10 else p_taxamt1 end as pos_10
                    ,case when p_taxamt1 = 0 and p_buydiv = '01' then p_taxamt2 * 10 + p_taxamt2 else p_taxamt3 end as pos_12
            from    ACTAXM a
                    left join CMCUSTM c
                        on c.custcode = p_custcode
            where   a.compcode = p_compcode
                    and a.taxno = ip_taxno
        ) src on (a.compcode = src.compcode
                  and a.plantcode = src.plantcode
                  and a.taxno = src.taxno)
        when matched then
            update set  a.taxdiv = pos_2
                        ,a.iotaxdiv = '01' --매입매출구분( select * from CMCOMMONM where cmmcode = 'ac61'  )
                        ,a.sdeptcode = p_deptcode
                        ,a.taxdate = p_slipindate --회계처리일자
                        ,a.custcode = p_custcode
                        ,a.custname = p_custname
                        ,a.businessno = p_businessno
                        ,a.biznotype = '01' -- 사업자등록번호 사업자구분( select * from CMCOMMONM where cmmcode = 'ac65'  )
                        ,a.amt = pos_10
                        ,a.vat = p_taxamt2
                        ,a.vatamt = pos_12
                        ,a.purposediv = '02' --영수청구구분(  select * from CMCOMMONM where cmmcode = 'ac62'   )
                        ,a.electaxyn = p_electaxyn --전자세금계산서여부
                        ,a.saleinyn = 'Y' --수입 자동생성여부
                        ,a.purdiv = '0'
                        ,a.updatedt = sysdate
                        ,a.uempcode = p_iempcode
                        ,a.importsdate = p_slipindate
                        ,a.importedate = p_slipindate ;

        update  ACTAXD
        set     itemnm = p_itemnm
                ,gyugeok = ''
                ,qty = 0
                ,prc = 0
                ,amt = case when p_taxamt1 = 0 and p_buydiv = '01' then p_taxamt2 * 10 else p_taxamt1 end
                ,vat = p_taxamt2
                ,vatamt = case when p_taxamt1 = 0 and p_buydiv = '01' then p_taxamt2 * 10 + p_taxamt2 else p_taxamt3 end
                ,remark = ''
                ,updatedt = sysdate
                ,uempcode = p_iempcode
        where   compcode = p_compcode
                and taxno = ip_taxno
                and seq = 1;

        merge into PDIMPORTCOSTM a
        using (
            select  a.importshtno
                    ,a.costseq
            from    PDIMPORTCOSTM a
                    join PDPURCHASEORDERM b
                        on a.importshtno = b.importshtno
            where   b.plantcode = p_plantcode
                    and a.custcost = p_custcode
                    and a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.importshtno = src.importshtno
                  and a.costseq = src.costseq)
        when matched then
            update set a.accountno = ip_taxno;

    elsif (p_div = 'dtax' or p_div = 'dtaxno') then --세금계산서 삭제.
        -- 회계전표 삭제
        for rec in (
            select  b.slipno, b.slipinno
            from    ACAUTOORDT a
                    join ACORDM b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
            where   a.compcode = p_compcode
                    and a.acattype = 'N'
                    and a.acatno = ip_taxno)
        loop
            p_slipno := rec.slipno;
            p_slipinno := rec.slipinno;
        end loop;

        if trim(p_slipno) is not null or p_slipno = '' then
            SPACORD0000MM('B'
                          ,p_compcode
                          ,p_slipno
                          ,''
                          ,''
                          ,''
                          ,p_userid
                          ,p_reasondiv
                          ,p_reasontext
                          ,MESSAGE
                          ,IO_CURSOR) ;
        end if;

        delete
        from    ACORDS
        where   compcode = p_compcode
                and slipinno = p_slipinno;

        delete
        from    ACORDD
        where   compcode = p_compcode
                and slipinno = p_slipinno;

        delete
        from    ACORDM
        where   compcode = p_compcode
                and slipinno = p_slipinno;

        -- 자동분개 삭제
        delete
        from    ACAUTOORDT
        where   compcode = p_compcode
                and acattype = 'N'
                and acatno = ip_taxno;

        -- 세금계산서 삭제
        delete
        from    ACTAXD
        where   compcode = p_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno;

        delete
        from    ACTAXM
        where   compcode = p_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno;

        merge into PDIMPORTCOSTM a
        using (
            select  a.importshtno
                    ,a.costseq
            from    PDIMPORTCOSTM a
                    join PDPURCHASEORDERM b
                        on a.importshtno = b.importshtno
            where   b.plantcode = p_plantcode
                    and nvl(a.custcost, ' ') = p_custcode
                    and a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.importshtno = src.importshtno
                  and a.costseq = src.costseq)
        when matched then
            update set a.accountno = '',
                       a.accountcheck = '';

    elsif (p_div = 'load')
    then
        if p_actrnstate = '1' then --신규 생성
            -- 기간동안의 모든 전표를 생성한다.
            insert into ACAUTOORDT
                (
                    compcode --회사코드
                    ,acattype --전표유형(n)
                    ,acatno --taxno
                    ,slipindate --발의일자(세금계산서일자)
                    ,acatrulecode --분개률코드(N01001)
                    ,deptcode --부서
                    ,plantcode --사업장
                    ,empcode --발의사원코드
                    ,remark
                    ,custcode --거래처코드
                    ,taxno --계산서번호
                    ,billno --수입전표번호
                    ,trn1amt --비용금액1
                    ,trn2amt --비용금액2
                    ,trn3amt --비용금액3
                    ,trn4amt --비용금액4
                    ,trn5amt --비용금액5
                    ,trn6amt --비용금액6
                    ,trn11amt --비용금액
                    ,trn12amt --부가세
                    ,actrnstate --실행상태
                    ,userdef1code --대행처코드
                    ,userdef3code --사업장명
                    ,userdef4code --부서명
                    ,userdef5code --발의사원명
                    ,userdef6code --거래처명
                    ,userdef7code --대행처명
                    ,userdef9code --lc코드
                    ,userdef10code --lc명
                    ,insertdt --입력일자
                    ,iempcode --입력사원
                )
            select  p_compcode --회사코드
                    ,'N' --전표유형(n)
                    ,ip_taxno --적요@itemnm
                    ,p_slipindate --발의일자(세금계산서일자)
                    ,p_acatrulecode --분개률코드(N01001)
                    ,(select deptcode from CMEMPM where empcode = p_iempcode) --부서
                    ,'1000'/*p_plantcode*/ --사업장
                    ,p_iempcode --발의사원코드
                    ,p_itemnm --적요
                    ,p_custcode --거래처코드
                    ,case when p_acatrulecode <> 'N01004' then ip_taxno else '' end --계산서번호
                    ,p_importshtno --수입전표번호
                    ,p_expamt1 --비용금액1
                    ,p_expamt2 --비용금액2
                    ,p_expamt3 --비용금액3
                    ,p_expamt4 --비용금액4
                    ,p_expamt5 --비용금액5
                    ,p_expamt6 --비용금액6
                    ,p_expamt --비용금액
                    ,p_expvat --부가세
                    ,'1' --실행상태 신규
                    ,p_agencode --대행처코드
                    ,(select plantname from CMPLANTM where plantcode = '1000'/*p_plantcode*/) --사업장명
                    ,(select d.deptname from CMEMPM e join CMDEPTM d on d.deptcode = e.deptcode where e.empcode = p_iempcode) --부서명
                    ,(select e.empname from CMEMPM e where e.empcode = p_iempcode) --발의사원명
                    ,(select custname from CMCUSTM  where custcode = p_custcode) --거래처명
                    ,(select custname from CMCUSTM  where custcode = p_agencode) --대행처명
                    ,p_lccode --lc코드
                    ,p_lcname --lc명
                    ,sysdate --입력일자
                    ,p_iempcode --입력사원
            from    DUAL;

            merge into PDIMPORTCOSTM a
            using (
                select  a.importshtno
                        ,a.costseq
                from    PDIMPORTCOSTM a
                        join PDPURCHASEORDERM b
                            on a.importshtno = b.importshtno
                where   b.plantcode = p_plantcode
                        and a.custcost = p_custcode
                        and a.accountno = ip_taxno
            ) src on (a.importshtno = src.importshtno
                      and a.costseq = src.costseq)
            when matched then
                update set a.accountcheck = 'Y';

            merge into PDIMPORTCOSTM a
            using (
                select  a.importshtno
                        ,a.costseq
                from    PDIMPORTCOSTM a
                        join PDPURCHASEORDERM b
                            on a.importshtno = b.importshtno
                where   b.plantcode = p_plantcode
                        and a.custcost = p_custcode
                        and trim(a.accountno) is null
                        and a.importshtno = ip_taxno
            ) src on (a.importshtno = src.importshtno
                      and a.costseq = src.costseq)
            when matched then
                update set a.accountcheck = 'Y',
                           a.accountno = ip_taxno;
        elsif (p_actrnstate = '3') then
            update  ACAUTOORDT b
            set     b.slipindate = p_slipindate
                    ,b.acatrulecode = p_acatrulecode --분개률코드(N01001)
                    ,b.deptcode = (select deptcode from CMEMPM where empcode = p_iempcode) --부서
                    ,b.plantcode = '1000'/*p_plantcode*/ --사업장
                    ,b.empcode = p_iempcode --발의사원코드
                    ,b.remark = p_itemnm
                    ,b.custcode = p_custcode --거래처코드
                    ,b.taxno = case when p_acatrulecode <> 'N01004' then ip_taxno else '' end --계산서번호
                    ,b.billno = p_importshtno --수입전표번호
                    ,b.trn1amt = p_expamt1 --비용금액1
                    ,b.trn2amt = p_expamt2 --비용금액2
                    ,b.trn3amt = p_expamt3 --비용금액3
                    ,b.trn4amt = p_expamt4 --비용금액4
                    ,b.trn5amt = p_expamt5 --비용금액5
                    ,b.trn6amt = p_expamt6 --비용금액6
                    ,b.trn11amt = p_expamt --비용금액
                    ,b.trn12amt = p_expvat --부가세
                    ,b.actrnstate = p_actrnstate --실행상태
                    ,b.userdef1code = p_agencode --대행처코드
                    ,b.userdef3code = (select plantname  from CMPLANTM where plantcode = '1000'/*p_plantcode*/) --사업장명
                    ,b.userdef4code = (select d.deptname from CMEMPM e left join CMDEPTM d on d.deptcode = e.deptcode where e.empcode = p_iempcode) --부서명
                    ,b.userdef5code = (select e.empname from CMEMPM e where e.empcode = p_iempcode) --사원명
                    ,b.userdef6code = (select custname  from CMCUSTM  where custcode = p_custcode) --거래처명
                    ,b.userdef7code = (select custname  from CMCUSTM  where custcode = p_agencode) --대행처명
                    ,b.userdef9code = p_lccode --lc코드
                    ,b.userdef10code = p_lcname --lc명
                    ,b.updatedt = sysdate --입력일자
                    ,b.uempcode = p_iempcode
            where   b.compcode = p_compcode
                    and b.acattype = 'N'
                    and b.acatno = ip_taxno;
        elsif (p_actrnstate = '4') then
            update  ACAUTOORDT b
            set     b.actrnstate = p_actrnstate --실행상태
                    ,b.remark = p_itemnm
                    ,b.updatedt = sysdate --입력일자
                    ,b.uempcode = p_iempcode
            where   b.compcode = p_compcode
                    and b.acattype = 'N'
                    and b.acatno = ip_taxno;
        end if;

    end if;

   <<last>>
    if (IO_CURSOR is null)
    then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;
END;
/
