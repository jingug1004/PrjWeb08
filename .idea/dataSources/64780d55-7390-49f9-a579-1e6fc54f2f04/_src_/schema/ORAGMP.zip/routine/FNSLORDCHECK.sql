CREATE FUNCTION        fnSLordCheck
-- --------------------------------------------------------------------
 -- 함 수 명		  : fnSLordCheck
 -- 작 성 자         : 김만수
 -- 작성일자         : 2017-11-15
 -- -------------------------------------------------------------------
 -- 함수설명	     : 주문등록시 거래처 채권에 대한 제한내역을 체크하는 함수
 -- -------------------------------------------------------------------
(
    p_plantcode                IN    VARCHAR2 DEFAULT '',    --사업장
    p_orderdate                IN    VARCHAR2 DEFAULT '',    --주문일자
    p_yearmonth                IN    VARCHAR2 DEFAULT '',    --주문년월
    p_custcode                 IN    VARCHAR2 DEFAULT ''     --거래처코드
)

RETURN FN_SLORDCHECK_TABLE
AS
   v_nocollmt                 FLOAT   (53);           --무수금개월 
   v_securitylmt              FLOAT   (53);           --담보가치한도
   v_c_utdiv                  VARCHAR2(05);           --유통구분
   v_c_credityn               VARCHAR2(01);           --신용불량구분
   v_c_sagodiv                VARCHAR2(05);           --사고처구분
   v_c_creditlmt              FLOAT   (53);           --여신한도액
   v_c_balancelmt             FLOAT   (53);           --잔고한도액
   v_c_nocollmt               FLOAT   (53);           --무수금개월
   v_c_securitylmt            FLOAT   (53);           --담보가치한도
   v_c_turnlmt                FLOAT   (53);           --회전일한도
   v_c_useyn                  VARCHAR2(01);           --채권한도사용구분
   v_c_securityexyn            VARCHAR2(01);           --담보예외처 구분
   v_c_email                  VARCHAR(50);           --이메일
   v_c_medicalcode             VARCHAR(20);           --요양기관번호
   v_c_orderctrlyn             VARCHAR(5);            --주문제한처여부
   
   v_balance                  FLOAT   (53);           --잔고
   v_pendbillcol              FLOAT   (53);           --미결어음
   v_totbalance               FLOAT   (53);           --총대차
   v_turncnt                  FLOAT   (53);           --회전일
   v_beforedt                 VARCHAR2(10);           --개월이전일
   v_scrtamt                  FLOAT   (53);           --담보가치
   
   v_creditck                 VARCHAR2(5);       --신용한도체크      
   v_sagock                   VARCHAR2(5);       --사고처체크  
   v_loanlmtck                VARCHAR2(5);       --여신한도체크  
   v_balancelmtck             VARCHAR2(5);        -- 잔고한도체크
   v_nocollmtck               VARCHAR2(5);        --무수금한도체크  
   v_securitylmtck            VARCHAR2(5);       --담보가치한도체크
   v_turnlmtck                VARCHAR2(5);       --회전일한도 체크
   v_orderctrlyn              VARCHAR2(5);     --주문제한처 체크 
   v_stopdiv                 VARCHAR2(5);        --중지거래처 체크 
   v_custdivchk               VARCHAR2(5);      --직거래처여부
   v_emailchk                VARCHAR2(5);        --이메일존재여부
   v_medicalcodechk           VARCHAR2(5);    --요양기관번호 존재여부 
   
   --함수내에서 변수 저장용 변수 초기화
   SLORDCHECKLISTRECODE FN_SLORDCHECK_TABLE := FN_SLORDCHECK_TABLE(); 
BEGIN


   --거래처마스터
   FOR rec IN ( SELECT UTDIV      ,      --유통구분
                      CREDITYN   ,      --
                      SAGODIV    ,
                      CREDITLMT  ,
                      BALANCELMT ,
                      NOCOLLMT   ,
                      SECURITYLMT,
                      TURNLMT    ,
                      USEYN     ,
                      SECURITYEXYN,
                      EMAIL      ,
                      MEDICALCODE ,
                      ORDERCTRLYN
                 FROM CMCUSTM
                WHERE CUSTCODE = p_custcode)
   LOOP
      v_c_utdiv       := rec.utdiv      ;
      v_c_credityn    := rec.credityn   ;
      v_c_sagodiv     := rec.sagodiv    ;
      v_c_creditlmt   := rec.creditlmt  ;
      v_c_balancelmt  := rec.balancelmt ;
      v_c_nocollmt    := rec.nocollmt   ;
      v_c_securitylmt := rec.securitylmt;
      v_c_turnlmt     := rec.turnlmt    ;
      v_c_useyn       := rec.useyn      ;
      v_c_securityexyn := rec.securityexyn;
      v_c_email       := rec.email;    
      v_c_medicalcode  := rec.medicalcode;
      v_c_orderctrlyn  := rec.orderctrlyn;
   END LOOP;

   --사용 항목의 초기화 체크
   IF (NVL (v_c_utdiv      , ' ') = ' ') THEN v_c_utdiv       := ' '; END IF;          --유통구분
   IF (NVL (v_c_credityn   , ' ') = ' ') THEN v_c_credityn    := 'N'; END IF;          --신용불량구분
   IF (NVL (v_c_sagodiv    , ' ') = ' ') THEN v_c_sagodiv     := 'N'; END IF;          --거래처상태
   IF (NVL (v_c_creditlmt  , 0  ) = 0  ) THEN v_c_creditlmt   := 0;   END IF;          --채권체크관리정보_여신한도액
   IF (NVL (v_c_balancelmt , 0  ) = 0  ) THEN v_c_balancelmt  := 0;   END IF;          --채권체크관리정보_잔고한도액
   IF (NVL (v_c_nocollmt   , 0  ) = 0  ) THEN v_c_nocollmt    := 0;   END IF;          --채권체크관리정보_무수금한도개월
   IF (NVL (v_c_securitylmt, 0  ) = 0  ) THEN v_c_securitylmt := 0;   END IF;          --채권체크관리정보_담보가치한도
   IF (NVL (v_c_turnlmt    , 0  ) = 0  ) THEN v_c_turnlmt     := 0;   END IF;          --채권체크관리정보_회전일한도
   IF (NVL (v_c_useyn      , ' ') = ' ') THEN v_c_useyn       := 'N'; END IF;          --채권체크관리정보_사용여부
   IF (NVL (v_c_securityexyn   , 'N') = 'N')THEN v_c_securityexyn := 'N'; END IF;      --담보예외처 여부
   
   IF (NVL (v_c_email   , ' ') = ' ')THEN v_c_email := 'N'; END IF;                 --이메일  
   IF (NVL (v_c_medicalcode   , ' ') = ' ')THEN v_c_medicalcode := 'N'; END IF;      --요양기관번호
   IF (NVL (v_c_orderctrlyn   , 'N') = 'N')THEN v_c_orderctrlyn := 'N'; END IF;      --주문제한여부   
   
   --마감테이블(
   FOR rec IN (SELECT SUM(balance)       AS alias1,                  --잔고
                      SUM(pendbillcol)   AS alias2,                  --미도래어음
                      SUM(balance) + SUM(pendbillcol) AS alias3      --총잔고
                 FROM SLRESULTM
                WHERE custcode  = p_custcode
                  AND yearmonth = p_yearmonth)
   LOOP
      v_balance     := rec.alias1;
      v_pendbillcol := rec.alias2;
      v_totbalance  := rec.alias3;
   END LOOP;


   -- 거래처 회전일
   FOR rec IN (SELECT turncnt
                 FROM SLTURNCUSTM
                WHERE custcode = p_custcode
                  AND yearmonth = p_yearmonth)
   LOOP
      v_turncnt := rec.turncnt;
   END LOOP;
   
   --사용 항목의 초기화 체크
   IF (NVL (v_balance   , 0) = 0) THEN v_balance    := 0; END IF;
   IF (NVL (v_totbalance, 0) = 0) THEN v_totbalance := 0; END IF;
   IF (NVL (v_turncnt   , 0) = 0) THEN v_turncnt    := 0; END IF;
   IF (NVL (v_scrtamt   , 0) = 0) THEN v_scrtamt    := 0; END IF;

   v_creditck      := 'N';   
   v_sagock        := 'N';
   v_loanlmtck     := 'N';
   v_balancelmtck  := 'N';
   v_nocollmtck    := 'N';
   v_securitylmtck := 'N';
   v_turnlmtck     := 'N';
   v_orderctrlyn   := 'N';
   v_stopdiv       := 'N';
   v_custdivchk    := 'N';
   v_emailchk      := 'N';
   v_medicalcodechk := 'N';


   IF (NVL (v_c_credityn, 'N') = 'Y' ) THEN v_creditck := '*'; END IF;                                   --신용불량
   IF (NVL (v_c_sagodiv , 'N') = '6') THEN v_sagock   := '*'; END IF;                                   --사고거래처 체크 (6:사고거래처)
   IF (NVL (v_c_sagodiv , 'N') = '2') THEN v_stopdiv := '*'; END IF;                                     --중지거래처 체크 ( 2: 중지거래처 )  
   IF (NVL(v_c_orderctrlyn, 'N') = 'Y') THEN v_orderctrlyn := '*'; END IF;                                  --주문제한처 체크                          

   IF ( (v_totbalance > 0) AND (v_c_creditlmt < v_totbalance) AND (v_c_creditlmt != 0 AND v_c_securityexyn = 'N')) THEN  v_loanlmtck    := '*'; END IF;   --여신한도  여신한도 0이거나 담보예외처인 경우 체크 제외 
   IF ( (v_balance    > 0) AND (v_c_balancelmt < v_balance) AND (v_c_creditlmt != 0 AND v_c_securityexyn = 'N'))   THEN  v_balancelmtck := '*'; END IF;   --잔고한도  여신한도 0이거나 담보예외처인 경우 체크 제외
      
   -- 이메일 체크
   FOR rec IN (SELECT COUNT(*) AS CNT
                 FROM DUAL
                WHERE REGEXP_LIKE (v_c_email, '^[a-zA-Z0-9!#$%''\*\+-/=\?^_`\{|\}~]+@[a-zA-Z0-9._%-]+\.[a-zA-Z]{2,4}$'))
   LOOP
      IF(rec.CNT = 0)
      THEN
          v_emailchk := '*';
      END IF;
   END LOOP;
   
   -- 직거래처 체크 (거래처코드 첫자리가 3, 4가 아닌 경우 직거래처 아님)
   IF(SUBSTR(p_custcode, 1, 1) NOT IN ('3', '4'))
   THEN
       v_custdivchk := '*';
   END IF;
   
   -- 요양기관번호 체크 
   IF(v_c_medicalcode = 'N')
   THEN
       v_medicalcodechk := '*';
   END IF;
         
   IF(v_c_securitylmt = 0) --담보가치금액이 0인 경우 담보내역 합계 금액 
   THEN
       --거래처담보내역(담보금액)
       --반환여부(returnyn)는 No 인 자료
       FOR rec IN (SELECT NVL (SUM (scrtamt), 0) AS alias1
                     FROM CMCUSTSCRTD
                    WHERE custcode = p_custcode
                      AND NVL(returnyn, 'N') <> 'Y')
       LOOP
         v_c_securitylmt := rec.alias1;
       END LOOP;
   END IF;
      
   --거래처담보내역(담보가치한도금액 혹은 담보내역 합계)
   v_scrtamt := v_c_securitylmt;

   IF ( (v_scrtamt > 0) AND (v_totbalance > v_scrtamt) AND (v_c_creditlmt != 0 AND v_c_securityexyn = 'N')) THEN v_securitylmtck := '*'; END IF;          --담보가치한도 여신한도 0이거나 담보예외처인 경우 체크 제외
   IF ( (v_turncnt > 0) AND (v_c_turnlmt  < v_turncnt)) THEN v_turnlmtck     := '*'; END IF;          --회전한도

   --무수금처 산출
   IF (v_balance > 0) THEN

      v_beforedt := TO_CHAR (ADD_MONTHS (TO_DATE (SUBSTR(p_orderdate,1,10), 'YYYY-MM-DD'), -v_c_nocollmt), 'YYYY-MM-DD');

      FOR rec IN (SELECT (CASE WHEN (DECODE (a.opendate, '', TO_CHAR (SYSDATE, 'YYYY') || '-' || SUBSTR (TO_CHAR (SYSDATE, 'MM'), 1, 1)) <>
                                     DECODE (SUBSTR(p_orderdate,1,10), '', TO_CHAR (SYSDATE, 'YYYY') || '-' || SUBSTR (TO_CHAR (SYSDATE, 'MM'), 1, 1)))
                                AND (v_c_nocollmt > 0)
                                AND (a.col_dt1 < v_beforedt)
                               THEN '*'
                               ELSE 'N'
                          END) AS alias1
                    FROM (SELECT a.custcode,
                                 a.opendate,
                                 last_col_dt,
                                 CASE WHEN last_col_dt IS NOT NULL
                                      THEN last_col_dt
                                      ELSE opendate
                                 END
                                 col_dt1
                            FROM CMCUSTM a
                       LEFT JOIN (SELECT custcode,
                                         MAX (CASE SUBSTR (saldiv, 0, 1) WHEN 'C'
                                                                          THEN orderdate
                                                                          ELSE NULL
                                              END) last_col_dt
                                    FROM vnSalesEnd                 --주문수금VIEW
                                   WHERE orderdate <= SUBSTR(p_orderdate,1,10)
                                    AND SUBSTR (saldiv, 0, 1) = 'C'
                               GROUP BY custcode
                                ) b
                              ON a.custcode = b.custcode
                        WHERE a.custcode = p_custcode
                        ) a)
     LOOP
        v_nocollmtck := rec.alias1;
     END LOOP;

  END IF;

   SLORDCHECKLISTRECODE.EXTEND;
   SLORDCHECKLISTRECODE(1) := FN_SLORDCHECK_VARIABLE2(v_creditck, v_sagock, v_loanlmtck, v_balancelmtck, v_nocollmtck, v_securitylmtck, v_turnlmtck, v_orderctrlyn, v_stopdiv, v_custdivchk, v_emailchk, v_medicalcodechk);
   
   RETURN (SLORDCHECKLISTRECODE);

EXCEPTION WHEN OTHERS THEN RETURN (SLORDCHECKLISTRECODE);
END;
/
