CREATE PROCEDURE        COL_SAL_spSLcol0099P
   -- ---------------------------------------------------------------
   -- 프로시저명       : 
   -- 작 성 자         :
   -- 작성일자         :
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 카드수금건에 대한 수금테이블(SLCOLM) 상신,결재 처리하는 프로시저이다.
   -- ---------------------------------------------------------------
 (
   p_div                IN    VARCHAR2 DEFAULT '', 
   p_plantcode          IN    VARCHAR2 DEFAULT '',
   p_coldate            IN    VARCHAR2 DEFAULT '',
   p_coldate1           IN    VARCHAR2 DEFAULT '',
   p_colseq             IN    VARCHAR2 DEFAULT '',
   p_saldiv             IN    VARCHAR2 DEFAULT '',
   p_coldiv             IN    VARCHAR2 DEFAULT '',
   p_orderdiv           IN    VARCHAR2 DEFAULT '',
   p_tasooyn            IN    VARCHAR2 DEFAULT '',
   p_custcode           IN    VARCHAR2 DEFAULT '',
   p_deptcode           IN    VARCHAR2 DEFAULT '',
   p_empcode            IN    VARCHAR2 DEFAULT '',
   p_ecustcode          IN    VARCHAR2 DEFAULT '',
   p_edeptcode          IN    VARCHAR2 DEFAULT '',
   p_eempcode           IN    VARCHAR2 DEFAULT '',
   p_utdiv              IN    VARCHAR2 DEFAULT '',
   p_eutdiv             IN    VARCHAR2 DEFAULT '',
   p_colamt             IN    FLOAT    DEFAULT 0,
   p_colvat             IN    FLOAT    DEFAULT 0,
   p_moneycode          IN    VARCHAR2 DEFAULT '',
   p_exrtrate           IN    FLOAT    DEFAULT 0,
   p_exrtamt            IN    FLOAT    DEFAULT 0,
   p_accountno          IN    VARCHAR2 DEFAULT '',
   p_billno             IN    VARCHAR2 DEFAULT '',
   p_issdate            IN    VARCHAR2 DEFAULT '',
   p_expdate            IN    VARCHAR2 DEFAULT '',
   p_paybank            IN    VARCHAR2 DEFAULT '',
   p_paybankbr          IN    VARCHAR2 DEFAULT '',
   p_issempnm           IN    VARCHAR2 DEFAULT '',
   p_baeseo             IN    VARCHAR2 DEFAULT '',
   p_cardcomp           IN    VARCHAR2 DEFAULT '',
   p_cardno             IN    VARCHAR2 DEFAULT '',
   p_cardokno           IN    VARCHAR2 DEFAULT '',
   p_carddate           IN    VARCHAR2 DEFAULT '',
   p_autoyn             IN    VARCHAR2 DEFAULT '',
   p_divmonth           IN    FLOAT    DEFAULT 0,
   p_enuriyn            IN    VARCHAR2 DEFAULT '',
   p_appdate            IN    VARCHAR2 DEFAULT '',
   p_discntdate         IN    VARCHAR2 DEFAULT '',
   p_custprtyn          IN    VARCHAR2 DEFAULT '',
   p_bigo               IN    VARCHAR2 DEFAULT '',
   p_remark             IN    VARCHAR2 DEFAULT '',
   p_statediv           IN    VARCHAR2 DEFAULT '',
   p_iempcode           IN    VARCHAR2 DEFAULT '',
   p_uempcode           IN    VARCHAR2 DEFAULT '',
   p_salpower           IN    VARCHAR2 DEFAULT '',
   p_colno              IN    VARCHAR2 DEFAULT '',
   p_apprstatus         IN    VARCHAR2 DEFAULT '',
   p_coldtldiv          IN    VARCHAR2 DEFAULT '',
   p_apprclassdiv       IN    VARCHAR2 DEFAULT '',
   p_yearmonth          IN    VARCHAR2 DEFAULT '',

   p_userid             IN    VARCHAR2 DEFAULT '',
   p_reasondiv          IN    VARCHAR2 DEFAULT '',
   p_reasontext         IN    VARCHAR2 DEFAULT ''

)
AS
   ip_colno                   VARCHAR2(100) := '';
   ip_colseq                  VARCHAR2(100) := '';
   ip_utdiv                   VARCHAR2(100) := '';
   ip_eutdiv                  VARCHAR2(100) := '';
   ip_appdate                 VARCHAR2(100) := '';

   ip_paybank                 VARCHAR2(100) := '';
   ip_paybankbr               VARCHAR2(100) := '';
   ip_issempnm                VARCHAR2(100) := '';
   ip_baeseo                  VARCHAR2(100) := '';
   ip_cardcomp                VARCHAR2(100) := '';
   ip_cardno                  VARCHAR2(100) := '';

   v_spSLSALERESULT_N_param   VARCHAR2(256);

BEGIN
 
      
   EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

   INSERT INTO ATINFO
         (USERID  , REASONDIV  , REASONTEXT  )
   VALUES(p_userid, p_reasondiv, p_reasontext);

   SELECT LPAD(NVL(MAX(COLSEQ),0)+1,'4','0')
     INTO ip_colseq
     FROM SLCOLM
    WHERE REPLACE(COLDATE,'-','') = REPLACE(p_coldate,'-','');

--   MESSAGE := ip_colseq;

   --거래처유통과 간납처유통코드 찾기
   FOR rec IN
      (SELECT UTDIV
         FROM CMCUSTM
        WHERE CUSTCODE = p_custcode
   )
   LOOP
      ip_utdiv := rec.utdiv;
   END LOOP;

   IF p_ecustcode IS NOT NULL THEN
   
       FOR rec IN
          (SELECT UTDIV
             FROM CMCUSTM
            WHERE CUSTCODE = p_ecustcode
       )
       LOOP
          ip_eutdiv := rec.utdiv;
       END LOOP;
       
   END IF;
   
   ip_appdate := p_carddate;
   ip_colno   := REPLACE(p_coldate,'-','') || ip_colseq;

   ip_paybank   := p_paybank  ;
   ip_paybankbr := p_paybankbr;
   ip_issempnm  := p_issempnm ;
   ip_baeseo    := p_baeseo   ;
   ip_cardcomp  := p_cardcomp ;
   ip_cardno    := p_cardno   ;
   
   --가상계좌테이블에 전표번호 Update
   IF p_iempcode = 'TRADEDATA_TBL' THEN

      UPDATE SALE_ON.TRADEDATA_TBL
         SET JUNPYO_NO = REPLACE(p_coldate, '-', '') || ip_colseq
       WHERE BANK_CD   = ip_paybank
         AND COMP_CODE = ip_paybankbr
         AND SEQ_NO    = ip_issempnm
         AND TRAN_DATE = ip_baeseo
         AND TRAN_TIME = ip_cardcomp
         AND DEAL_SELE = ip_cardno;

      ip_paybank   := '';
      ip_paybankbr := '';
      ip_issempnm  := '';
      ip_baeseo    := '';
      ip_cardcomp  := '';
      ip_cardno    := '';
         
   END IF; 

   INSERT INTO SLCOLM
         (plantcode     ,        -- p_plantcode   ,
          coldate       ,        -- p_coldate     ,   --입력일자 yyyy-MM-dd 형식으로 들어옴
          colseq        ,        -- ip_colseq     ,
          colno         ,        -- ip_colno      ,
          saldiv        ,        -- 'C01'         ,
          coldiv        ,        -- p_coldiv      ,
          orderdiv      ,        -- p_orderdiv    ,
          tasooyn       ,        -- p_tasooyn     ,
          custcode      ,        -- p_custcode    ,
          deptcode      ,        -- p_deptcode    ,
          empcode       ,        -- p_empcode     ,
          ecustcode     ,        -- p_ecustcode   ,
          edeptcode     ,        -- p_edeptcode   ,
          eempcode      ,        -- p_eempcode    ,
          utdiv         ,        -- ip_utdiv      ,
          eutdiv        ,        -- ip_eutdiv     ,
          colamt        ,        -- p_colamt      ,
          colvat        ,        -- p_colvat      ,
          moneycode     ,        -- p_moneycode   ,
          exrtrate      ,        -- p_exrtrate    ,
          exrtamt       ,        -- p_exrtamt     ,
          accountno     ,        -- p_accountno   ,
          billno        ,        -- p_billno      ,
          issdate       ,        -- p_issdate     ,
          expdate       ,        -- p_expdate     ,
          paybank       ,        -- p_paybank     ,
          issempnm      ,        -- p_issempnm    ,
          cardcomp      ,        -- p_cardcomp    ,
          cardno        ,        -- p_cardno      ,
          cardokno      ,        -- p_cardokno    ,
          divmonth      ,        -- p_divmonth    ,
          enuriyn       ,        -- 'N'           ,
          appdate       ,        -- p_carddate    ,
          discntdate    ,        -- p_discntdate  ,
          custprtyn     ,        -- p_custprtyn   ,
          statediv      ,        -- '00'          ,   --'09', 결재 후 매출 확정되도록 변경
          insertdt      ,        -- SYSDATE       ,
          iempcode      ,        -- p_iempcode    ,
          bigo          ,
          remark        ,        -- p_remark      ,
          pda           ,        -- 'N'           ,
          paybankbr     ,        -- p_paybankbr   ,
          baeseo        ,        -- p_baeseo      ,
          carddate      ,        -- p_carddate    ,
          autoyn        ,        -- p_autoyn      ,
          apprstatus    ,        -- p_apprstatus  ,
          coldtldiv     ,        -- p_coldtldiv   ,
          iftranyn               -- 'N'
         )
   VALUES(p_plantcode   ,
          p_coldate     ,
          ip_colseq     ,
          ip_colno      ,
          'C01'         ,
          p_coldiv      ,
          p_orderdiv    ,
          p_tasooyn     ,
          p_custcode    ,
          p_deptcode    ,
          p_empcode     ,
          p_ecustcode   ,
          p_edeptcode   ,
          p_eempcode    ,
          ip_utdiv      ,
          ip_eutdiv     ,
          p_colamt      ,
          p_colvat      ,
          p_moneycode   ,
          p_exrtrate    ,
          p_exrtamt     ,
          p_accountno   ,
          p_billno      ,
          p_issdate     ,
          p_expdate     ,
          ip_paybank    ,
          ip_issempnm   ,
          ip_cardcomp   ,
          ip_cardno     ,
          p_cardokno    ,
          p_divmonth    ,
          'N'           ,
          p_coldate    ,
          p_discntdate  ,
          p_custprtyn   ,
          '00'          ,
          SYSDATE       ,
          p_iempcode    ,
          p_bigo        ,
          p_remark      ,
          'N'           ,
          p_paybankbr   ,
          ip_baeseo     ,
          p_carddate    ,
          p_autoyn      ,
          p_apprstatus  ,
          p_coldtldiv   ,
          'N'
          );

   --등록 후 마감 테이블 적용
   v_spSLSALERESULT_N_param := 'N';
   ORAGMP.COL_SAL_spSLSALERESULT_N (p_div         => 'M'            ,
                            p_plantcode   => p_plantcode    ,
                            p_orderdate   => ip_appdate     ,
                            p_iempcode    => p_iempcode     ,
                            p_custcode    => p_custcode     ,
                            p_ecustcode   => p_ecustcode    ,
                            p_userid      => ''             ,
                            p_reasondiv   => ''             ,
                            p_reasontext  => ''             );

   --결재완료 처리
   v_spSLSALERESULT_N_param := 'N';
   ORAGMP.COL_SAL_SPSLAPP0020P     (p_div          => 'AC'           ,
                            p_plantcode    => p_plantcode    ,
                            p_custcode     => p_custcode     ,
                            p_orderdiv     => p_orderdiv     ,
                            p_ecustcode    => p_ecustcode    ,
                            p_coldate      => p_coldate      ,
                            p_colseq       => ip_colseq      ,
                            p_colno        => ip_colno       ,
                            p_apprseq      => 0              ,
                            p_apprlastseq  => 0              ,
                            p_apprremark   => ''             ,
                            p_appdate      => ip_appdate     ,
                            p_iempcode     => p_empcode      ,
                            p_userid       => ''             ,
                            p_reasondiv    => ''             ,
                            p_reasontext   => ''             
                           );

--      --위의 프로시져 수행 후 2개이 값이 변경 됨.
--      UPDATE SLCOLM
--        SET statediv   = '09',
--            apprstatus = '03'
--      WHERE coldate = p_coldate
--        AND colseq  = p_colseq;

--    ORAGMP.spSLSALERESULT_N 수행
       
END;
/
