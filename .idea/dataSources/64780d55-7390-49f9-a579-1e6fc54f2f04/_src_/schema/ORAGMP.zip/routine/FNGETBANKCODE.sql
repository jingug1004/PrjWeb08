CREATE FUNCTION        fnGetBankCode(
	p_paybank IN VARCHAR2 DEFAULT ''
)
	RETURN VARCHAR2
AS
	p_bankcode	 VARCHAR2(20) := '';
BEGIN
	FOR rec IN (SELECT divcode
				FROM   CMCOMMONM
				WHERE  cmmcode = 'PS88'
					   AND p_paybank LIKE '%' || filter1 || '%'
					   AND filter1 <> ' '
					   AND usediv = 'Y')
	LOOP
		p_bankcode := rec.divcode;
	END LOOP;

	IF NVL(TRIM(p_bankcode),'') IS NULL THEN
		p_bankcode := CASE 	WHEN p_paybank LIKE '%의료%' THEN '999' 
        					WHEN p_paybank LIKE '%자가%' THEN '999' 
                            WHEN p_paybank LIKE '%씨티%' THEN '999' 
                            ELSE p_paybank 
                       END;
	END IF;

	RETURN p_bankcode;
    
EXCEPTION WHEN OTHERS THEN RETURN p_bankcode;
END;
/
