CREATE FUNCTION        fnCalcAvoidDay
-- ---------------------------------------------------------------
 -- 함 수 명			: fnCalcAvoidDay
 -- 작 성 자         : 강현철
 -- 작성일자         : 2010-04-15
 -- ---------------------------------------------------------------
 -- 함수설명			: 휴일을 피하여 전날을 계산한다
 -- ---------------------------------------------------------------

(
  p_date IN VARCHAR2
)
RETURN VARCHAR2
AS
   p_tostring VARCHAR2(10) :='';

BEGIN
   
    SELECT  MAX(date_) date_  
    INTO    p_tostring
    FROM    CompanyCalenderMaster 
    WHERE   date_ <= p_date
            AND daydiv != 'H';

    RETURN p_tostring;

EXCEPTION WHEN OTHERS THEN RETURN p_tostring;
END;
/
