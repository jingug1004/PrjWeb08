CREATE FUNCTION        F_GET_ITEM_QTY(
        I_ITEM_NO IN STRING
)
        RETURN VARCHAR2 IS
        V_QTY NUMBER;
        /*
        CHOE 20171113
        현재고를 가져오기 위한 FUNC
        */
BEGIN
        
        V_QTY := 0;
        SELECT A.QTY - NVL (B.REALQTY ,0) - NVL(C.CONTROLQTY ,0)  AS REALQTY
        INTO V_QTY
        FROM (
                SELECT NVL (A.WAREHOUSE, '') AS WAREHOUSE
                ,NVL (A.ITEMCODE , '') AS ITEMCODE
                ,NVL (SUM(A.QTY) ,0) AS QTY
                FROM ORAGMP.SLWAREHOUSEM A 
                WHERE A.STOPYN = 'N'  --제조번호단위 출하중지 여부 체
                GROUP BY A.ITEMCODE ,A.WAREHOUSE                
        ) A  --현재고
        ,(
                SELECT SL_D.ITEMCODE AS ITEMCODE
                ,SL_M.WAREHOUSE AS WAREHOUSE
                ,SUM (SL_D.SALQTY + SL_D.GIVQTY + SL_D.BONUSQTY - SL_D.OUTPUTQTY ) AS REALQTY
                FROM ORAGMP.SLORDM SL_M
                ,ORAGMP.SLORDD SL_D
                WHERE SL_M.PLANTCODE = SL_M.PLANTCODE
                AND SL_M.ORDERNO = SL_D.ORDERNO
                AND SL_M.SALDIV LIKE 'A%'
                AND SL_M.SALDIV NOT IN ('A03', 'A07', 'A25', 'A40', 'A51', 'A53')
                AND SL_M.STATEDIV NOT IN ('99')        
                AND SL_D.SALQTY + SL_D.GIVQTY + SL_D.BONUSQTY > SL_D.OUTPUTQTY        
                GROUP BY SL_D.ITEMCODE, SL_M.WAREHOUSE       
        ) B  --품절방지수량
        ,ORAGMP.CMITEMM C  --유통기한 재고 빠짐 
        WHERE A.WAREHOUSE = B.WAREHOUSE(+)
        AND A.ITEMCODE = B.ITEMCODE(+)
        AND A.ITEMCODE = C.ITEMCODE(+)
        AND A.ITEMCODE = I_ITEM_NO
        ;
        
        IF SQLCODE <> 0 THEN
                V_QTY := ' ';
        END IF;
        
        RETURN V_QTY;
EXCEPTION
        WHEN NO_DATA_FOUND THEN
        
        IF V_QTY IS NULL THEN
                V_QTY := ' ';
        END IF;
        
        RETURN V_QTY;
END;
/
