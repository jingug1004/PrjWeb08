CREATE PROCEDURE        spACacc0000PR(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0000PR
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-05-07
	-- 수정일자       :   노영래
	-- E-mail       :   0rae0926@gmail.com
	-- 수정일자       :   2016-12-13
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계전표반제내역 테이블 (ACORDRPYP)을 등록,수정,삭제하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_slipinno		IN	   VARCHAR2 DEFAULT '',
	p_slipinseq 	IN	   NUMBER DEFAULT 0,
	p_slipinnoR 	IN	   VARCHAR2 DEFAULT '',
	p_slipinseqR	IN	   NUMBER DEFAULT 0,
	p_repayamt		IN	   FLOAT DEFAULT 0,
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	v_temp	  NUMBER(1, 0) := 0;
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);

	IF (UPPER(P_DIV) = 'I')
	THEN
		v_temp := 0;

		-- 회계전표관리항목내역 등록
		INSERT INTO ACORDRPYP
			(SELECT p_compcode,
					p_slipinnoR,
					p_slipinseqR,
					p_slipinno,
					p_slipinseq,
					p_repayamt
			 FROM	DUAL);


		SELECT COUNT(*)
		INTO   v_temp
		FROM   ACORDRPYR
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinnoR
			   AND slipinseq = p_slipinseqR;


		IF v_temp <> 0
		THEN
			MERGE INTO ACORDRPYR a
			USING	   (SELECT A.COMPCODE,
							   A.SLIPINNO,
							   A.SLIPINSEQ,
							   b.repayamt
						FROM   ACORDRPYR a
							   JOIN (SELECT SUM(repayamt) repayamt
									 FROM	ACORDRPYP
									 WHERE	ACORDRPYP.compcode = p_compcode
											AND ACORDRPYP.slipinno = p_slipinnoR
											AND ACORDRPYP.slipinseq = p_slipinseqR) b
								   ON 1 = 1
						WHERE  a.compcode = p_compcode
							   AND a.slipinno = p_slipinnoR
							   AND a.slipinseq = p_slipinseqR) src
			ON		   (A.COMPCODE = SRC.COMPCODE
						AND A.SLIPINNO = SRC.SLIPINNO
						AND A.SLIPINSEQ = SRC.SLIPINSEQ)
			WHEN MATCHED
			THEN
				UPDATE SET a.repayamt = src.repayamt;
		ELSE
			INSERT INTO ACORDRPYR
				(SELECT compcode,
						slipinno,
						slipinseq,
						debamt + creamt,
						p_repayamt
				 FROM	ACORDD
				 WHERE	compcode = p_compcode
						AND slipinno = p_slipinnoR
						AND slipinseq = p_slipinseqR);
		END IF;
	ELSIF (UPPER(P_DIV) = 'U')
	THEN
		v_temp := 0;

		-- 회계전표관리항목내역 수정
		UPDATE ACORDRPYP a
		SET    a.repayamt = p_repayamt
		WHERE  a.compcode = p_compcode
			   AND slipinno = p_slipinnoR
			   AND slipinseq = p_slipinseqR
			   AND a.rpyslipinno = p_slipinno
			   AND a.rpyslipinseq = p_slipinseq;

		SELECT COUNT(*)
		INTO   v_temp
		FROM   ACORDRPYR
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinnoR
			   AND slipinseq = p_slipinseqR;



		IF v_temp <> 0
		THEN
			MERGE INTO ACORDRPYR a
			USING	   (SELECT A.COMPCODE,
							   A.SLIPINNO,
							   A.SLIPINSEQ,
							   b.repayamt
						FROM   ACORDRPYR a
							   JOIN (SELECT SUM(repayamt) repayamt
									 FROM	ACORDRPYP
									 WHERE	ACORDRPYP.compcode = p_compcode
											AND ACORDRPYP.slipinno = p_slipinnoR
											AND ACORDRPYP.slipinseq = p_slipinseqR) b
								   ON 1 = 1
						WHERE  a.compcode = p_compcode
							   AND a.slipinno = p_slipinnoR
							   AND a.slipinseq = p_slipinseqR) src
			ON		   (A.COMPCODE = SRC.COMPCODE
						AND A.SLIPINNO = SRC.SLIPINNO
						AND A.SLIPINSEQ = SRC.SLIPINSEQ)
			WHEN MATCHED
			THEN
				UPDATE SET a.repayamt = src.repayamt;
		ELSE
			INSERT INTO ACORDRPYR
				(SELECT compcode,
						slipinno,
						slipinseq,
						debamt + creamt,
						p_repayamt
				 FROM	ACORDD
				 WHERE	compcode = p_compcode
						AND slipinno = p_slipinnoR
						AND slipinseq = p_slipinseqR);
		END IF;
	ELSIF (UPPER(P_DIV) = 'D')
	THEN
		v_temp := 0;

		-- 회계전표관리항목내역 삭제
		FOR REC IN (SELECT A.COMPCODE,
						   A.SLIPINNO,
						   A.SLIPINSEQ,
						   A.RPYSLIPINNO,
						   A.RPYSLIPINSEQ
					FROM   ACORDRPYP a
					WHERE  a.compcode = p_compcode
						   AND slipinno = p_slipinnoR
						   AND slipinseq = p_slipinseqR
						   AND a.rpyslipinno = p_slipinno
						   AND a.rpyslipinseq = p_slipinseq)
		LOOP
			DELETE FROM ACORDRPYP A
			WHERE		A.COMPCODE = REC.COMPCODE
						AND A.SLIPINNO = REC.SLIPINNO
						AND A.SLIPINSEQ = REC.SLIPINSEQ
						AND A.RPYSLIPINNO = REC.RPYSLIPINNO
						AND A.RPYSLIPINSEQ = REC.RPYSLIPINSEQ;
		END LOOP;



		SELECT COUNT(*)
		INTO   v_temp
		FROM   ACORDRPYR
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinnoR
			   AND slipinseq = p_slipinseqR;

		IF v_temp <> 0
		THEN
			MERGE INTO ACORDRPYR a
			USING	   (SELECT A.COMPCODE,
							   A.SLIPINNO,
							   A.SLIPINSEQ,
							   NVL(b.repayamt, 0) AS repayamt
						FROM   ACORDRPYR a
							   LEFT JOIN (SELECT SUM(repayamt) repayamt
										  FROM	 ACORDRPYP
										  WHERE  ACORDRPYP.compcode = p_compcode
												 AND ACORDRPYP.slipinno = p_slipinnoR
												 AND ACORDRPYP.slipinseq = p_slipinseqR) b
								   ON 1 = 1
						WHERE  a.compcode = p_compcode
							   AND a.slipinno = p_slipinnoR
							   AND a.slipinseq = p_slipinseqR) src
			ON		   (A.COMPCODE = SRC.COMPCODE
						AND A.SLIPINNO = SRC.SLIPINNO
						AND A.SLIPINSEQ = SRC.SLIPINSEQ)
			WHEN MATCHED
			THEN
				UPDATE SET a.repayamt = src.repayamt;


			FOR REC IN (SELECT A.COMPCODE,
							   A.SLIPINNO,
							   A.SLIPINSEQ
						FROM   ACORDRPYR a
						WHERE  a.compcode = p_compcode
							   AND a.slipinno = p_slipinnoR
							   AND a.slipinseq = p_slipinseqR
							   AND a.repayamt = 0)
			LOOP
				DELETE FROM ACORDRPYR A
				WHERE		A.COMPCODE = REC.COMPCODE
							AND A.SLIPINNO = REC.SLIPINNO
							AND A.SLIPINSEQ = REC.SLIPINSEQ;
			END LOOP;
		END IF;
	END IF;

	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
