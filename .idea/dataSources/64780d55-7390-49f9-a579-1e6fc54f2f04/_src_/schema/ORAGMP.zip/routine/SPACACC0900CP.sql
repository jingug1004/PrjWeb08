CREATE PROCEDURE        spACacc0900CP(
  -- ---------------------------------------------------------------
  -- 프로시저명       : spACacc0900CP
  -- 작 성 자         : 최용석
  -- 작성일자         : 2011-12-15
  -- 수 정 자     : 노영래
  -- E-Mail       : 0rae0926@gmail.com
  -- 수정일자      : 2016-12-19
  -- ---------------------------------------------------------------
  -- 프로시저 설명    : 수금전표로드
  -- ---------------------------------------------------------------
    p_div           IN  VARCHAR2 DEFAULT '',

    p_compcode      IN  VARCHAR2 DEFAULT '',
    p_plantcode     IN  VARCHAR2 DEFAULT '',
    p_sdt           IN  VARCHAR2 DEFAULT '',
    p_edt           IN  VARCHAR2 DEFAULT '',
    p_coldiv        IN  VARCHAR2 DEFAULT '',
    p_loadstatus    IN  VARCHAR2 DEFAULT '',
    p_custcode      IN  VARCHAR2 DEFAULT '',
    p_seldiv        IN  VARCHAR2 DEFAULT 'N',
    p_printdiv      IN  VARCHAR2 DEFAULT '%',
    p_orderno       IN  VARCHAR2 DEFAULT '%',
    p_crtord        IN  NUMBER   DEFAULT 0,
    p_iempcode      IN  VARCHAR2 DEFAULT '',

    p_userid        IN  VARCHAR2 DEFAULT '',
    p_reasondiv     IN  VARCHAR2 DEFAULT '',
    p_reasontext    IN  VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DATASET
)
AS
    v_temp              NUMBER := 0;
    -- 이-글벳 부서구분
    p_deptcode          VARCHAR2(20);

    p_setplant          VARCHAR2(4);
    p_crtdate           VARCHAR2(8);
    p_crttime           VARCHAR2(8);
    p_crtseq            NUMBER;
    p_crttyp            VARCHAR2(8);
    p_colno             VARCHAR2(20);

    p_tempno            VARCHAR2(20);
    p_taxno             VARCHAR2(20);
    p_appdate           VARCHAR2(10);
    p_actrnstate        VARCHAR2(10);
BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    SELECT COUNT(*)
    INTO   v_temp
    FROM   DUAL
    WHERE  EXISTS
               (SELECT *
                FROM   CMCLOSEM
                WHERE  compcode = p_compcode
                       AND closeym BETWEEN SUBSTR(p_sdt, 0, 7) AND SUBSTR(p_edt, 0, 7)
                       AND accdiv = 'C'
                       AND apprcloseyn = 'Y');


    IF v_temp = 1
    THEN
        IF (IO_CURSOR IS NULL)
        THEN
             OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
        END IF;

        RETURN;
    END IF;

--    IF (p_div = 'S') THEN
--        spInterfaceDownload(p_div => 'E_CUSTMASTER');
--
--        FOR rec IN (
--            SELECT  MIN(plantcode) AS alias1
--            FROM    CMPLANTM
--        )
--        LOOP
--            p_setplant := rec.alias1;
--        END LOOP;
--
--        FOR REC IN(
--            SELECT     crtdate D1,
--                     crttime D2,
--                     crtseq D3,
--                     crttyp D4,
--                     colno || SUBSTR('000' || TO_CHAR(colseq), -4, 4) D5
--            FROM     E_SLCOLM
--            WHERE     UPPER(STATUS) = 'N'
--            ORDER BY crtdate, crttime, crtseq
--        )
--        LOOP
--            p_crtdate := REC.D1;
--            p_crttime := REC.D2;
--            p_crtseq := REC.D3;
--            p_crttyp := REC.D4;
--            p_colno := REC.D5;
--
--            SELECT COUNT(*)
--            INTO   v_temp
--            FROM   DUAL
--            WHERE  EXISTS ( SELECT  *
--                            FROM    SLCOLM
--                            WHERE   colno = p_colno);
--
--            IF v_temp = 1 THEN
--
--                p_crttyp := 'U';
--
--            END IF;
--
--            IF p_crttyp = 'I' THEN
--                -- 처리상태가 'I'인데 이미 수금가 존재하는 경우
--                MERGE INTO E_SLCOLM A
--                USING (
--                        SELECT  --COMPARE DATA
--                                A.CRTDATE
--                                , A.CRTTIME
--                                , A.CRTSEQ
--                        FROM    E_SLCOLM A
--                                JOIN SLCOLM b ON b.plantcode = p_setplant
--                                                 AND A.colno || SUBSTR('000' || TO_CHAR(A.colseq), -4, 4) = b.colno
--                        WHERE   A.crtdate = p_crtdate
--                                AND A.crttime = p_crttime
--                                AND A.crtseq = p_crtseq
--                ) SRC ON (  A.CRTDATE = SRC.CRTDATE
--                            AND A.CRTTIME = SRC.CRTTIME
--                            AND A.CRTSEQ = SRC.CRTSEQ )
--                WHEN MATCHED THEN UPDATE SET    STATUS = 'E'
--                                                , remarks = '수금번호 중복' ;
--
--                IF SQL%ROWCOUNT = 0 THEN
--
--                    INSERT INTO SLCOLM(colno,
--                                       plantcode,
--                                       coldate,
--                                       colseq,
--                                       saldiv,
--                                       coldiv,
--                                       coldtldiv,
--                                       orderdiv,
--                                       tasooyn,
--                                       custcode,
--                                       deptcode,
--                                       empcode,
--                                       ecustcode,
--                                       edeptcode,
--                                       eempcode,
--                                       utdiv,
--                                       eutdiv,
--                                       colamt,
--                                       colvat,
--                                       accountno,
--                                       billno,
--                                       issdate,
--                                       expdate,
--                                       paybank,
--                                       paybankbr,
--                                       issempnm,
--                                       baeseo,
--                                       cardcomp,
--                                       cardno,
--                                       cardokno,
--                                       divmonth,
--                                       carddate,
--                                       autoyn,
--                                       enuriyn,
--                                       appdate,
--                                       discntdate,
--                                       custprtyn,
--                                       bigo,
--                                       remark,
--                                       statediv,
--                                       pda,
--                                       colnolink,
--                                       apprstatus,
--                                       iftranyn,
--                                       moneycode,
--                                       exrtrate,
--                                       exrtamt,
--                                       insertdt,
--                                       iempcode)
--                        (SELECT A.COLNO || SUBSTR('000' || TO_CHAR(A.COLSEQ), -4, 4),
--                                p_setplant,
--                                FNSTUFF(FNSTUFF(A.COLDATE, 5, 0, '-'), 8, 0, '-'),
--                                SUBSTR('000' || TO_CHAR(A.COLSEQ), -4, 4),
--                                'C01',
--                                COALESCE(A.BILLDIV, c.divcode, '01'),
--                                '',
--                                '4',
--                                CASE WHEN NVL(A.TASOOYN, ' ') = '1' THEN 'Y' ELSE 'N' END col,
--                                A.CUSTCODE,
--                                NVL(f.deptcode, ''),
--                                NVL(E.EMPCODE, ''),
--                                A.CUSTCODE,
--                                NVL(f.deptcode, ''),
--                                NVL(E.EMPCODE, ''),
--                                NVL(D.utdiv, '99'),
--                                NVL(D.utdiv, '99'),
--                                A.COLAMT,
--                                0,
--                                A.ACCOUNTNO,
--                                fnGetKSPBillno(A.BILLNO, FNSTUFF(FNSTUFF(NVL(A.ISSDATE, A.COLDATE), 5, 0, '-'), 8, 0, '-')),
--                                FNSTUFF(FNSTUFF(NVL(A.ISSDATE, A.COLDATE), 5, 0, '-'), 8, 0, '-'),
--                                NVL(FNSTUFF(FNSTUFF(A.EXPDATE, 5, 0, '-'), 8, 0, '-'), ''),
--                                fnGetBankCode(A.PAYBANK),
--                                A.PAYBANKBR,
--                                A.ISSEMPNM,
--                                '',
--                                fnGetCardCode(A.CARDCOMP),
--                                A.CARDNO,
--                                A.CARDOKNO,
--                                0,
--                                '',
--                                '',
--                                '',
--                                FNSTUFF(FNSTUFF(NVL(A.APPDATE, A.COLDATE), 5, 0, '-'), 8, 0, '-'),
--                                '',
--                                '',
--                                '',
--                                '',
--                                '09',
--                                '',
--                                '',
--                                '',
--                                '',
--                                '',
--                                0,
--                                0,
--                                SYSDATE,
--                                p_iempcode
--                         FROM    E_SLCOLM A
--                                LEFT JOIN CMCOMMONM c ON c.cmmcode = 'SL18'
--                                                         AND A.COLDIV = c.filter2
--                                LEFT JOIN CMCUSTM D ON A.CUSTCODE = D.custcode
--                                LEFT JOIN SATM1060 E ON A.EMPCODE = E.SM_CD
--                                LEFT JOIN CMEMPM f ON E.EMPCODE = f.empcode
--                         WHERE    A.CRTDATE = p_crtdate
--                                AND A.CRTTIME = p_crttime
--                                AND A.CRTSEQ = p_crtseq);
--
--
--                    UPDATE E_SLCOLM A
--                    SET    STATUS = 'Y'
--                    WHERE  A.crtdate = p_crtdate
--                           AND A.crttime = p_crttime
--                           AND A.crtseq = p_crtseq;
--
--                END IF;
--
--
--            ELSIF p_crttyp = 'U' THEN
--
--                -- 처리상태가 'U' 인데 수금가 존재하는 않는경우
--                MERGE INTO E_SLCOLM A
--                USING (
--                        SELECT  A.CRTDATE
--                                , A.CRTTIME
--                                , A.CRTSEQ
--                        FROM    E_SLCOLM A
--                                LEFT JOIN SLCOLM b ON b.plantcode = p_setplant
--                                                      AND A.colno || SUBSTR('000' || TO_CHAR(A.colseq), -4, 4) = b.colno
--                        WHERE   A.crtdate = p_crtdate
--                                AND A.crttime = p_crttime
--                                AND A.crtseq = p_crtseq
--                                AND NVL(TRIM(b.colno), '') IS NULL
--                ) SRC ON (  A.CRTDATE = SRC.CRTDATE
--                            AND A.CRTTIME = SRC.CRTTIME
--                            AND A.CRTSEQ = SRC.CRTSEQ )
--                WHEN MATCHED THEN UPDATE SET    A.STATUS = 'E'
--                                                , A.remarks = '수금번호 없음' ;
--
--
--                IF SQL%ROWCOUNT = 0 THEN
--
--                    MERGE INTO SLCOLM b
--                    USING (
--                            SELECT B.COLNO,
--                                   B.PLANTCODE,
--                                   A.colno || SUBSTR('000' || TO_CHAR(A.colseq), -4, 4) colno_A,
--                                   FNSTUFF(FNSTUFF(A.coldate, 5, 0, '-'), 8, 0, '-') AS pos_2,
--                                   COALESCE(A.billdiv, c.divcode, '01') AS pos_3,
--                                   CASE WHEN NVL(TRIM(A.tasooyn), ' ') = '1' THEN 'Y' ELSE 'N' END AS pos_4,
--                                   f.deptcode AS pos_6,
--                                   E.empcode AS pos_7,
--                                   A.custcode,
--                                   f.deptcode AS pos_9,
--                                   E.empcode AS pos_10,
--                                   NVL(D.utdiv, '99') AS pos_11,
--                                   NVL(D.utdiv, '99') AS pos_12,
--                                   A.colamt,
--                                   A.accountno AS pos_14,
--                                   CASE WHEN b.billno LIKE NVL(A.billno, '') || '%' THEN b.billno ELSE fnGetKSPBillno(NVL(A.billno, ''), FNSTUFF(FNSTUFF(NVL(A.issdate, A.coldate), 5, 0, '-'), 8, 0, '-')) END AS pos_15,
--                                   FNSTUFF(FNSTUFF(NVL(A.issdate, A.coldate), 5, 0, '-'), 8, 0, '-') AS pos_16,
--                                   NVL(FNSTUFF(FNSTUFF(A.expdate, 5, 0, '-'), 8, 0, '-'), '') AS pos_17,
--                                   fnGetBankCode(A.paybank) AS pos_18,
--                                   A.paybankbr AS pos_19,
--                                   NVL(A.issempnm, '') AS pos_20,
--                                   fnGetCardCode(A.cardcomp) AS pos_21,
--                                   A.cardno AS pos_22,
--                                   A.cardokno AS pos_23,
--                                   FNSTUFF(FNSTUFF(NVL(A.appdate, A.coldate), 5, 0, '-'), 8, 0, '-') AS pos_24
--                            FROM   E_SLCOLM A
--                                   JOIN SLCOLM b ON b.plantcode = p_setplant
--                                                    AND A.colno || SUBSTR('000' || TO_CHAR(A.colseq), -4, 4) = b.colno
--                                   LEFT JOIN CMCOMMONM c ON UPPER(c.cmmcode) = 'SL18'
--                                                            AND A.coldiv = c.filter2
--                                   LEFT JOIN CMCUSTM D ON A.custcode = D.custcode
--                                   LEFT JOIN SATM1060 E ON A.empcode = E.sm_cd
--                                   LEFT JOIN CMEMPM f ON E.empcode = f.empcode
--                            WHERE  A.crtdate = p_crtdate
--                                   AND A.crttime = p_crttime
--                                   AND A.crtseq = p_crtseq
--                    ) SRC ON ( B.COLNO = SRC.colno_A
--                                AND B.PLANTCODE = p_setplant )
--                    WHEN MATCHED
--                    THEN
--                        UPDATE SET b.coldate = src.pos_2,
--                                   b.coldiv = src.pos_3,
--                                   b.tasooyn = src.pos_4,
--                                   b.custcode = src.custcode,
--                                   b.deptcode = src.pos_6,
--                                   b.empcode = src.pos_7,
--                                   b.ecustcode = src.custcode,
--                                   b.edeptcode = src.pos_9,
--                                   b.eempcode = src.pos_10,
--                                   b.utdiv = src.pos_11,
--                                   b.eutdiv = src.pos_12,
--                                   b.colamt = src.colamt,
--                                   b.accountno = src.pos_14,
--                                   b.billno = src.pos_15,
--                                   b.issdate = src.pos_16,
--                                   b.expdate = src.pos_17,
--                                   b.paybank = src.pos_18,
--                                   b.paybankbr = src.pos_19,
--                                   b.issempnm = src.pos_20,
--                                   b.cardcomp = src.pos_21,
--                                   b.cardno = src.pos_22,
--                                   b.cardokno = src.pos_23,
--                                   b.appdate = src.pos_24,
--                                   b.updatedt = SYSDATE,
--                                   b.uempcode = p_iempcode ;
--
--
--
--                    UPDATE  E_SLCOLM A
--                    SET     STATUS = 'Y'
--                    WHERE   A.crtdate = p_crtdate
--                            AND A.crttime = p_crttime
--                            AND A.crtseq = p_crtseq ;
--
--                END IF;
--
--
--            ELSIF p_crttyp = 'D' THEN
--
--
--                -- 처리상태가 'D' 인데 수금가 존재하는 않는경우
--                MERGE INTO E_SLCOLM A
--                USING (
--                        SELECT  A.CRTDATE
--                                , A.CRTTIME
--                                , A.CRTSEQ
--                        FROM    E_SLCOLM A
--                                LEFT JOIN SLCOLM b ON b.plantcode = p_setplant
--                                                      AND A.colno || SUBSTR('000' || TO_CHAR(A.colseq), -4, 4) = b.colno
--                        WHERE   A.crtdate = p_crtdate
--                                AND A.crttime = p_crttime
--                                AND A.crtseq = p_crtseq
--                                AND b.colno IS NULL
--                ) SRC ON ( A.CRTDATE = SRC.CRTDATE
--                           AND A.CRTTIME = SRC.CRTTIME
--                           AND A.CRTSEQ = SRC.CRTSEQ )
--                WHEN MATCHED THEN UPDATE SET    A.STATUS = 'E'
--                                                , A.remarks = '수금번호 없음' ;
--
--
--                IF SQL%ROWCOUNT = 0
--                THEN
--                    FOR REC IN (SELECT B.COLNO
--                                       , B.PLANTCODE
--                                FROM   E_SLCOLM A
--                                       JOIN SLCOLM b
--                                           ON b.plantcode = p_setplant
--                                              AND A.colno || SUBSTR('000' || TO_CHAR(A.colseq), -4, 4) = b.colno
--                                WHERE  A.crtdate = p_crtdate
--                                       AND A.crttime = p_crttime
--                                       AND A.crtseq = p_crtseq)
--                    LOOP
--
--                        DELETE FROM SLCOLM B
--                        WHERE        B.COLNO = REC.COLNO
--                                    AND B.PLANTCODE = REC.PLANTCODE ;
--
--                    END LOOP;
--
--
--
--                    UPDATE E_SLCOLM A
--                    SET    STATUS = 'Y'
--                    WHERE  A.crtdate = p_crtdate
--                           AND A.crttime = p_crttime
--                           AND A.crtseq = p_crtseq;
--
--                END IF;
--
--            END IF;
--
--        END LOOP;
--
--    END IF;

    EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0900CP_DUAL ';

    FOR rec IN (SELECT fnGetColDeptCode(deptcode) AS alias1
                FROM   CMEMPM
                WHERE  empcode = p_iempcode)
    LOOP
        p_deptcode := rec.alias1;
    END LOOP;

    INSERT INTO VGT.TT_ACACC0900CP_DUAL (

         SELECT p_compcode compcode,
                p_seldiv chk,
                NVL(plantcode, '') plantcode,
                NVL(appdate, '') appdate,
                NVL(orderdate, '') orderdate,
                NVL(orderseq, '') orderseq,
                NVL(orderno, '') orderno,
                NVL(saldivnm, '') saldivnm,
                NVL(custcode, '') custcode,
                NVL(custname, '') custname,
                NVL(ecustcode, '') ecustcode,
                NVL(ecustname, '') ecustname,
                NVL(deptcode, '') deptcode,
                NVL(deptname, '') deptname,
                NVL(empcode, '') empcode,
                NVL(empname, '') empname,
                NVL(edeptcode, '') edeptcode,
                NVL(edeptname, '') edeptname,
                NVL(eempcode, '') eempcode,
                NVL(eempname, '') eempname,
                NVL(utdivnm, '') utdivnm,
                NVL(colamt, 0) colamt,
                NVL(feeamt, 0) feeamt,
                NVL(colamt, 0) - NVL(feeamt, 0) difamt,
                NVL(custprtyn, '') custprtyn,
                '',
                NVL(billno, '') billno,
                NVL(accountno, '') accountno,
                NVL(accremark, '') accremark,
                NVL(cardno, '') cardno,
                NVL(cardokno, '') cardokno,
                nvl(autoyn, 'Y') autoyn,
                NVL(issdate, '') issdate,
                NVL(expdate, '') expdate,
                NVL(gubun, '') gubun,
                NVL(coldiv, ' ') coldiv,
                NVL(orderdiv, '') orderdiv,
                NVL(pda, '') pda,
                '1' actrnstate, --1신규, 2완료 3수정, 4삭제
                NVL(SL181.filter1, '') autorulecode,
                CASE WHEN SUBSTR(coldiv, 0, 1) = '3' THEN '1' ELSE '' END billcls,
                NVL(paybank, '') paybank,
                NVL(cardcomp, '') cardcomp,
                NVL(cardcompnm, '') cardcompnm,
                concustcode concustcode,
                concustname concustname,
                NVL(saldivnm, '') || ' 수금' || CASE WHEN coldiv = '10' THEN NVL('(' || accremark || ')', '') ELSE '' END remark,
                '신규로드전송전' acctrnchk,
                '' slipinno,
                'N' newchk --재신규 전표 변경 참고
         FROM    (SELECT A.plantcode,
                        A.appdate,
                        NVL(A.coldate, '') orderdate,
                        NVL(A.colseq, '') orderseq,
                        NVL(A.colno, '') orderno,
                        CASE WHEN NVL(A.tasooyn, 'N') = 'Y' THEN NVL(SL18.divname, '') || '(타)-' || b.custname
                             ELSE NVL(SL18.divname, '') || '-' || b.custname
                        END saldivnm,
                        A.colnolink colnolink,
                        CASE WHEN A.coldiv IN ('55', '56') THEN (   SELECT  S.custcode
                                                                     FROM    SLCOLM S
                                                                     WHERE    S.plantcode = A.plantcode
                                                                            AND S.colno = A.colnolink
                                                                            AND S.appdate BETWEEN p_sdt AND p_edt
                                                                            AND S.saldiv = 'C01'
                                                                            AND S.statediv = '09' )
                             ELSE A.custcode
                        END custcode ,
                        CASE WHEN A.coldiv IN ('55', '56') THEN (   SELECT  T.custname
                                                                     FROM    SLCOLM S
                                                                            LEFT JOIN CMCUSTM T ON S.custcode = T.custcode
                                                                     WHERE    S.plantcode = A.plantcode
                                                                            AND S.colno = A.colnolink
                                                                            AND S.appdate BETWEEN p_sdt AND p_edt
                                                                            AND S.saldiv = 'C01'
                                                                            AND S.statediv = '09' )
                             ELSE NVL(b.custname, '')
                        END custname,
                        NVL(A.ecustcode, '') ecustcode,
                        NVL(c.custname, '') ecustname,
                        NVL(D.deptcode, '') deptcode,
                        NVL(D.deptname, '') deptname,
                        NVL(E.empcode, '') empcode,
                        NVL(E.empname, '') empname,
                        NVL(f.deptcode, '') edeptcode,
                        NVL(f.deptname, '') edeptname,
                        NVL(G.empcode, '') eempcode,
                        NVL(G.empname, '') eempname,
                        NVL(CM15.divname, '') utdivnm,
                        CASE WHEN A.coldiv = '57' THEN CASE WHEN A.colamt >= 0 THEN A.colamt
                                                            ELSE 0
                                                       END
                             ELSE A.colamt * CASE WHEN A.coldiv IN ('55', '56') THEN -1
                                                  ELSE 1
                                             END
                        END colamt,
                        CASE
                            WHEN A.coldiv = '57'
                            THEN
                                CASE WHEN A.colamt < 0 THEN A.colamt ELSE 0 END
                            WHEN A.coldiv = '21'
                            THEN
                                DECODE(DECODE(TAC17.rtype, '0', 0, 1), 0, TRUNC(A.colamt * TAC17.rate / 100 + DECODE(TAC17.rtype, '2', POWER(0.1000000, TAC17.digit + 1) * 9, 0)), ROUND(A.colamt * TAC17.rate / 100 + DECODE(TAC17.rtype, '2', POWER(0.1000000, TAC17.digit + 1) * 9, 0), TAC17.digit))
                            WHEN A.coldiv = '53'
                            THEN
                                0
                            ELSE
                                0
                        END feeamt,
                        NVL(A.custprtyn, '') custprtyn,
                        NVL(A.billno, '') billno,
                        NVL(A.accountno, '') accountno,
                        NVL(h.accremark, '') accremark,
                        NVL(A.cardno, '') cardno,
                        NVL(A.cardokno, '') cardokno,
                        case when a.coldiv = '21' then NVL(A.autoyn, 'Y') else '' end as autoyn,
                        NVL(A.issdate, '') issdate,
                        NVL(A.expdate, '') expdate,
                        CASE WHEN A.coldiv LIKE '3%' THEN NVL(PS32.divname, '') --지급은행
                             WHEN SUBSTR(A.coldiv, 0, 1) = '1' THEN NVL(h.accremark, '') --계좌은행
                             WHEN SUBSTR(A.coldiv, 0, 1) = '2'
                                  AND NVL(A.divmonth, 0) = 0   THEN NVL(AC17.divname, '') --카드사
                             WHEN SUBSTR(A.coldiv, 0, 1) = '2'
                                  AND NVL(A.divmonth, 0) > 0   THEN NVL(AC17.divname, '') || ' ' || TO_CHAR(divmonth) || '개월' --카드사
                             ELSE ''
                        END gubun,
                        NVL(A.coldiv, '') coldiv,
                        NVL(A.orderdiv, '') orderdiv,
                        NVL(A.pda, '') pda,
                        NVL(A.paybank, '') paybank,
                        NVL(A.cardcomp, '') cardcomp,
                        NVL(AC17.divname, '') cardcompnm,
                        CASE WHEN A.coldiv IN ('55', '56') THEN NVL(A.custcode, '') ELSE '' END concustcode, -- 거래처이관 거래처
                        CASE WHEN A.coldiv IN ('55', '56') THEN NVL(b.custname, '') ELSE '' END concustname -- 거래처이관 거래처명
                 FROM    SLCOLM A
                        LEFT JOIN CMCUSTM b ON A.custcode = b.custcode
                        LEFT JOIN CMCUSTM c ON A.ecustcode = c.custcode
                        LEFT JOIN CMEMPM E ON NVL(NULLIF(A.empcode, ''), p_iempcode) = E.empcode
                        LEFT JOIN CMDEPTM D ON NVL(NULLIF(A.deptcode, ''), E.deptcode) = D.deptcode
                        LEFT JOIN CMEMPM G ON NVL(NULLIF(A.eempcode, ''), p_iempcode) = G.empcode
                        LEFT JOIN CMDEPTM f ON NVL(NULLIF(A.edeptcode, ''), G.deptcode) = f.deptcode
                        LEFT JOIN CMACCOUNTM h ON A.accountno = h.accountno
                        LEFT JOIN CMCOMMONM AC17 ON A.cardcomp = AC17.divcode
                                                    AND AC17.cmmcode = 'AC17'
                        LEFT JOIN CMCOMMONM CM15 ON A.utdiv = CM15.divcode
                                                    AND CM15.cmmcode = 'CM15'
                        LEFT JOIN CMCOMMONM PS32 ON A.paybank = PS32.divcode
                                                    AND PS32.cmmcode = 'PS32'
                        LEFT JOIN CMCOMMONM SL18 ON A.coldiv = SL18.divcode
                                                    AND SL18.cmmcode = 'SL18'
                        LEFT JOIN (SELECT   divcode
                                            , SUBSTR(filter1, 0, INSTR(filter1, ',') - 1) rate
                                            , SUBSTR(filter1, INSTR(filter1, ',') || 1, INSTR(filter1, ',', INSTR(filter1, ',') || 1) - INSTR(filter1, ',') - 1) digit
                                            , SUBSTR(filter1, -1, 1) rtype
                                   FROM     CMCOMMONM
                                   WHERE    cmmcode = 'AC171'
                                            AND usediv = 'Y'
                                            AND LENGTH(filter1) > 5 ) TAC17
                            ON A.cardcomp = TAC17.divcode
                 WHERE    A.plantcode LIKE p_plantcode
                        AND A.appdate BETWEEN p_sdt AND p_edt
                        AND A.saldiv = 'C01' --영업구분SL10
                        AND A.statediv = '09' --확정구분SL17
                        AND (A.coldiv IN ('55', '56') AND NVL(TRIM(A.colnolink),'') IS NOT NULL OR A.coldiv NOT IN ('55', '56'))
                        AND A.colno LIKE p_orderno ) A
                left JOIN CMCOMMONM SL181
                    ON SL181.cmmcode = 'SL181'
                       AND SL181.divcode = A.coldiv
             AND SL181.filter1 is not null
         WHERE    NVL(fnGetColDeptCode(A.deptcode), ' ') = NVL(p_deptcode, ' ')
    );


    OPEN IO_CURSOR FOR
        SELECT    *
        FROM    VGT.TT_ACACC0900CP_DUAL;

    -- 전송완료상태 데이터 확인
    MERGE INTO VGT.TT_ACACC0900CP_DUAL A
    USING (
            SELECT  --COMARE DATA
                    A.compcode , -- 기존자료
                    A.appdate ,
                    A.orderno ,
                    --UDPATE DATA
                    CASE WHEN b.actrnstate = '1' OR TRIM(b.slipinno) IS NULL THEN '로드완료전표처리전'
                         WHEN TRIM(b.slipinno) IS NOT NULL AND b.slipinno = c.slipinno THEN '회계처리완료'
                         WHEN TRIM(b.slipinno) IS NOT NULL AND TRIM(c.slipinno) IS NULL THEN '신규:회계전표삭제재전송'
                         ELSE '회계처리완료'
                    END AS acctrnchk,

                    CASE WHEN b.actrnstate = '1' OR TRIM(b.slipinno) IS NULL THEN '3'
                         WHEN TRIM(b.slipinno) IS NOT NULL AND b.slipinno = c.slipinno THEN '2'
                         WHEN TRIM(b.slipinno) IS NOT NULL AND TRIM(c.slipinno) IS NULL THEN '3'
                         ELSE '2'
                    END AS actrnstate,

                    NVL(b.slipinno, '') AS slipinno,

                    CASE WHEN TRIM(b.slipinno) IS NOT NULL AND TRIM(c.slipinno) IS NULL THEN 'Y'
                         ELSE 'N'
                    END AS newchk --신규회계로드의 경우

            FROM    VGT.TT_ACACC0900CP_DUAL A
                    JOIN ACAUTOORDT b ON A.compcode = b.compcode -- 기존자료
                                         AND b.acattype = 'C'
                                         AND A.appdate = b.slipindate
                                         AND A.orderno = b.acatno
                    LEFT JOIN ACORDM c ON b.compcode = c.compcode -- 회계전표
                                          AND b.slipinno = c.slipinno
    ) SRC ON ( NVL(A.compcode, ' ')    = NVL(SRC.compcode, ' ')
               AND NVL(A.appdate, ' ') = NVL(SRC.appdate, ' ')
               AND NVL(A.orderno, ' ') = NVL(SRC.orderno, ' ') )
    WHEN MATCHED THEN UPDATE SET    A.acctrnchk    = SRC.acctrnchk
                                    , A.actrnstate = SRC.actrnstate
                                    , A.slipinno   = SRC.slipinno
                                    , A.newchk     = SRC.newchk ;

    -- 수정 데이터 확인
    MERGE INTO VGT.TT_ACACC0900CP_DUAL A
    USING (
            SELECT  --compare data
                    A.compcode ,
                    A.orderno ,
                    --update data
                    '3' AS actrnstate,
                    CASE WHEN TRIM(b.slipinno) IS NOT NULL AND TRIM(c.slipinno) IS NULL THEN '수정:회계전표삭제재전송'
                         ELSE '수정전송필요'
                    END AS acctrnchk,
                    NVL(b.slipinno, '') AS slipinno
            FROM    VGT.TT_ACACC0900CP_DUAL A
                    JOIN ACAUTOORDT b  ON A.compcode = b.compcode -- 기존자료
                                          AND b.acattype = 'C'
                                          AND A.orderno = b.acatno
                    LEFT JOIN ACORDM c ON b.compcode = c.compcode -- 회계전표
                                          AND b.slipinno = c.slipinno
            WHERE   A.plantcode <> b.plantcode
                    OR NVL(A.appdate, ' ') <> NVL(b.slipindate, ' ')
                    OR NVL(A.orderno, ' ') <> NVL(b.acatno, ' ')
                    OR NVL(A.autorulecode, ' ') <> NVL(b.acatrulecode, ' ')
                    OR NVL(b.acattype, ' ') <> 'C'
                    OR (A.coldiv IN ('55', '56')
                    AND NVL(A.concustcode, ' ') <> NVL(b.custcode, ' ')
                    OR A.coldiv NOT IN ('55', '56')
                    AND NVL(A.custcode, ' ') <> NVL(b.custcode, ' '))
                    OR NVL(A.billno, ' ') <> NVL(b.billno, ' ')
                    OR NVL(A.billcls, ' ') <> NVL(b.billcls, ' ')
                    OR NVL(A.issdate, ' ') <> NVL(b.issdate, ' ')
                    OR NVL(A.expdate, ' ') <> NVL(b.expdate, ' ')
                    OR NVL(A.paybank, ' ') <> NVL(b.paybank, ' ')
                    OR NVL(A.cardno, ' ') <> NVL(b.cardno, ' ')
                    OR NVL(A.cardokno, ' ') <> NVL(b.cardokno, ' ')
                    OR NVL(A.cardcomp, ' ') <> NVL(b.cardcomp, ' ')
                    OR NVL(A.colamt, 0) <> NVL(b.trn1amt, 0)
                    OR NVL(A.feeamt, 0) <> NVL(b.trn2amt, 0)
                    OR NVL(A.orderno, ' ') <> NVL(b.userdef2code, ' ')
                    OR NVL(A.remark, ' ') <> NVL(b.remark, ' ')
                    OR (A.coldiv IN ('55', '56') AND NVL(A.custcode, ' ') <> NVL(b.userdef1code, ' ') OR
                        A.coldiv NOT IN ('55', '56') AND NVL(A.accountno, ' ') <> NVL(b.userdef1code, ' ') )
    ) SRC ON (  NVL(A.COMPCODE,' ') = NVL(SRC.COMPCODE,' ')
                AND NVL(A.ORDERNO,' ') = NVL(SRC.ORDERNO,' ') )
    WHEN MATCHED THEN UPDATE SET    A.actrnstate = '3'
                                    , A.acctrnchk = src.acctrnchk
                                    , A.slipinno = src.slipinno ;






    --,remark = b.remark --+ '(수정)'
    -- 삭제 상태 확인
    INSERT INTO VGT.TT_ACACC0900CP_DUAL
        (SELECT A.compcode,
                p_seldiv chk,
                NVL(A.plantcode, '') plantcode,
                NVL(A.slipindate, '') appdate, --승인일자
                '' orderdate, --수금일자
                '' orderseq, --순번
                NVL(A.userdef2code, '') orderno, --수금번호
                NVL(c.divname, '') saldivnm, --수금구분명
                CASE WHEN c.divcode IN ('55', '56') THEN NVL(A.userdef1code, '') ELSE NVL(A.custcode, '') END custcode,
                CASE WHEN c.divcode IN ('55', '56') THEN NVL(A.userdef7code, '') ELSE NVL(A.userdef6code, '') END custname, --거래처명
                '' ecustcode,
                '' ecustname,
                NVL(A.deptcode, '') deptcode,
                NVL(A.userdef4code, '') deptname,
                NVL(A.empcode, '') empcode,
                NVL(A.userdef5code, '') empname,
                '' edeptcode,
                '' edeptname,
                '' eempcode,
                '' eempname,
                '' utdivnm,
                A.trn1amt colamt, --수금액
                A.trn2amt feeamt, --수수료
                A.trn3amt difamt, --차액
                '' custprtyn,
                NVL(A.taxno, '') taxno,
                NVL(A.billno, '') billno,
                CASE WHEN c.divcode IN ('55', '56') THEN '' ELSE NVL(A.userdef1code, '') END accountno, --계좌번호
                NVL(A.userdef8code, '') accremark,
                NVL(A.cardno, '') cardno,
                NVL(A.cardokno, '') cardokno,
                '' autoyn,
                NVL(A.issdate, '') issdate,
                NVL(A.expdate, '') expdate,
                '' gubun, -- 구분 : 내용
                NVL(c.divcode, ' ') coldiv, -- 수금구분코드
                '' orderdiv, --주문서구분
                '' pda, --PDA
                '4' actrnstate, --1신규, 2완료 3수정, 4삭제
                NVL(A.acatrulecode, '') autorulecode,
                A.billcls billcls,
                NVL(A.paybank, '') paybank,
                NVL(A.cardcomp, '') cardcomp,
                NVL(A.userdef10code, '') cardcompnm,
                CASE WHEN c.divcode IN ('55', '56') THEN A.custcode ELSE '' END concustcode,
                CASE WHEN c.divcode IN ('55', '56') THEN A.userdef6code ELSE '' END concustname,
                A.remark remark,
                '삭제전송필요' acctrnchk,
                A.slipinno slipinno,
                'N' newchk
         FROM    ACAUTOORDT A
                LEFT JOIN VGT.TT_ACACC0900CP_DUAL b ON A.slipindate = b.appdate
                                                       AND A.acatno = b.orderno
                LEFT JOIN CMCOMMONM c ON c.cmmcode = 'SL181'
                                         AND UPPER(A.acatrulecode) = UPPER(c.filter1)
         WHERE    A.compcode = p_compcode
                AND UPPER(A.acattype) = 'C'
                AND A.slipindate BETWEEN p_sdt AND p_edt
                AND b.orderno IS NULL
                AND A.acatno LIKE p_orderno
                AND NVL(TRIM(fnGetColDeptCode(A.deptcode)), ' ') = NVL(TRIM(p_deptcode), ' ') );

    IF (p_loadstatus = '1' OR p_loadstatus = '2' OR p_loadstatus = '3')
    THEN
      --로드 상태를 선택
      DELETE FROM VGT.TT_ACACC0900CP_DUAL
          WHERE ACTRNSTATE NOT IN
                        (SELECT FILTER1
                           FROM CMCOMMONM
                          WHERE CMMCODE = 'AC082' AND DIVCODE = P_LOADSTATUS
                         UNION ALL
                         SELECT FILTER2
                           FROM CMCOMMONM
                          WHERE CMMCODE = 'AC082' AND DIVCODE = P_LOADSTATUS);
    END IF;

    IF (p_plantcode <> '%')
    THEN
      DELETE FROM VGT.TT_ACACC0900CP_DUAL
          WHERE plantcode <> p_plantcode;
    END IF;

    IF (p_coldiv <> '%')
    THEN
      DELETE FROM VGT.TT_ACACC0900CP_DUAL
          WHERE coldiv <> p_coldiv;
    END IF;

    IF (TRIM(p_custcode) IS NOT NULL)
    THEN
      DELETE FROM VGT.TT_ACACC0900CP_DUAL
          WHERE custcode <> p_custcode;
    END IF;

    IF (p_printdiv <> '%')
    THEN
        FOR REC IN (SELECT a.COMPCODE,
                           a.PLANTCODE,
                           a.ORDERNO
                    FROM   VGT.TT_ACACC0900CP_DUAL a
                           LEFT JOIN ACORDM b -- 회계전표
                               ON b.compcode = p_compcode
                                  AND a.slipinno = b.slipinno
                    WHERE  b.slipinno IS NULL
               OR p_printdiv = '01'
                              AND TRIM(b.printdate) IS NULL
                           OR p_printdiv = '02'
                              AND TRIM(b.printdate) IS NOT NULL)
        LOOP
            DELETE FROM VGT.TT_ACACC0900CP_DUAL A
            WHERE        A.COMPCODE = REC.COMPCODE
                        AND A.PLANTCODE = REC.PLANTCODE
                        AND A.ORDERNO = REC.ORDERNO;
        END LOOP;
    END IF;

    IF (p_div = 'S') THEN

        OPEN IO_CURSOR FOR

            SELECT     A.*,
                     NVL(b.iempcode, '') iempcode,
                     NVL(c.empname, '') iempname,
                     b.insertdt insertdt,
                     NVL(b.uempcode, '') uempcode,
                     NVL(D.empname, '') uempname,
                     b.updatedt updatedt,
                     NVL(E.slipinstate, '') slipinstate,
                     0 crtord
            FROM     VGT.TT_ACACC0900CP_DUAL A
                     LEFT JOIN SLCOLM b ON b.colno = A.orderno
                     LEFT JOIN CMEMPM c ON NVL(b.iempcode, ' ') = c.empcode
                     LEFT JOIN CMEMPM D ON NVL(b.uempcode, ' ') = D.empcode
                     LEFT JOIN ACORDM E ON NVL(A.slipinno, ' ') = E.slipinno
            --ORDER BY A.compcode, A.plantcode, A.orderno;
            ORDER BY A.orderno, A.compcode, A.plantcode ;

    ELSIF (UPPER(p_div) = UPPER('loadall') ) THEN-- 전체 선택 일반 로드 처리

            FOR REC IN(
                SELECT     A.orderno D1,
                         A.appdate D2,
                         A.actrnstate D3,
                         b.taxno D4
                FROM     VGT.TT_ACACC0900CP_DUAL A
                         LEFT JOIN ACAUTOORDT b
                             ON A.compcode = b.compcode
                                AND UPPER(b.acattype) = 'C'
                                AND A.orderno = b.acatno
                WHERE     UPPER(A.coldiv) = '53X'
                ORDER BY A.orderno
            )
            LOOP
                p_tempno := REC.D1;
                p_appdate := REC.D2;
                p_actrnstate := REC.D3;
                p_taxno := REC.D4;

                IF TRIM(p_taxno) IS NULL AND NVL(p_actrnstate, ' ') <> '4' THEN

                    p_taxno := SUBSTR(REPLACE(p_appdate, '-', ''), 0, 6) || '21';

                    FOR rec IN (SELECT p_taxno || SUBSTR('00000' || TO_CHAR((NVL(SUBSTR(MAX(taxno), -5, 5), 0) + 1)), -5, 5) AS alias1
                                FROM   ACTAXM
                                WHERE  compcode = p_compcode
                                       AND NVL(taxno, ' ') LIKE p_taxno || '%'
                                       AND LENGTH(taxno) = 13
                                       AND iotaxdiv = '01'
                                       AND saleinyn = 'Y')
                    LOOP
                        p_taxno := rec.alias1;
                    END LOOP;

                    INSERT INTO ACTAXM(compcode,
                                       plantcode,
                                       taxno, --yyyy1xnnnnn
                                       taxdiv, --계산서 구분( select * from cmcommonm where cmmcode = 'AC60' )
                                       iotaxdiv, --매입매출구분( select * from cmcommonm where cmmcode = 'AC61' )
                                       sdeptcode,
                                       taxdate,
                                       custcode,
                                       custname,
                                       businessno,
                                       biznotype, --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
                                       blankcnt,
                                       amt,
                                       vat,
                                       vatamt,
                                       recogno,
                                       purposediv, --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
                                       importsdate,
                                       importedate,
                                       electaxyn, --전자세금계산서여부
                                       saleinyn, --영업자동생성여부
                                       purdiv,
                                       insertdt,
                                       iempcode)
                        (SELECT A.compcode,
                                A.plantcode,
                                p_taxno, -- yyyy21nnnnn  번호 생성
                                '201', --매입-과세(  select * from cmcommonm where cmmcode = 'AC60' )
                                '01', --매입매출구분( select * from cmcommonm where cmmcode = 'AC61' )
                                A.deptcode,
                                A.appdate,
                                A.custcode,
                                b.custname,
                                b.businessno,
                                '01', --사업자구분( select * from cmcommonm where cmmcode = 'AC65' )
                                0,
                                A.difamt,
                                A.feeamt,
                                A.colamt,
                                A.cardokno,
                                '01', --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62' )
                                A.appdate,
                                A.appdate,
                                'Y', --전자세금계산서여부
                                'Y', --영업자동생성여부
                                '0',
                                SYSDATE,
                                p_iempcode
                         FROM    VGT.TT_ACACC0900CP_DUAL A LEFT JOIN CMCUSTM b ON A.custcode = b.custcode
                         WHERE    A.orderno = p_tempno);

                    INSERT INTO ACTAXD(compcode,
                                       plantcode,
                                       taxno, -- yyyy11nnnnn
                                       seq,
                                       itemnm, -- ITEM
                                       amt,
                                       vat,
                                       vatamt,
                                       insertdt,
                                       iempcode)
                        (SELECT A.compcode,
                                A.plantcode,
                                p_taxno, -- yyyy21nnnnn  번호 생성
                                1,
                                A.saldivnm,
                                A.difamt,
                                A.feeamt,
                                A.colamt,
                                SYSDATE,
                                p_iempcode
                         FROM    VGT.TT_ACACC0900CP_DUAL A LEFT JOIN CMCUSTM b ON A.custcode = b.custcode
                         WHERE    A.orderno = p_tempno);

                    UPDATE VGT.TT_ACACC0900CP_DUAL A
                    SET    A.taxno = p_taxno
                    WHERE  A.orderno = p_tempno;



                ELSIF TRIM(p_taxno) IS NULL AND p_actrnstate <> '4' THEN

                    MERGE INTO ACTAXM A
                    USING       (SELECT A.COMPCODE,
                                       A.PLANTCODE,
                                       A.TAXNO,
                                       b.deptcode,
                                       b.appdate,
                                       b.custcode,
                                       c.custname,
                                       c.businessno,
                                       b.difamt,
                                       b.feeamt,
                                       b.colamt,
                                       b.cardokno
                                FROM   ACTAXM A
                                       JOIN VGT.TT_ACACC0900CP_DUAL b
                                           ON A.compcode = b.compcode
                                              AND b.orderno = p_tempno
                                       LEFT JOIN CMCUSTM c ON c.custcode = p_custcode
                                WHERE  A.taxno = p_taxno) src
                    ON           (A.COMPCODE = SRC.COMPCODE
                                AND A.PLANTCODE = SRC.PLANTCODE
                                AND A.TAXNO = SRC.TAXNO)
                    WHEN MATCHED
                    THEN
                        UPDATE SET A.sdeptcode = src.deptcode,
                                   A.taxdate = src.appdate,
                                   A.custcode = src.custcode,
                                   A.custname = src.custname,
                                   A.businessno = src.businessno,
                                   A.amt = src.difamt,
                                   A.vat = src.feeamt,
                                   A.vatamt = src.colamt,
                                   A.recogno = src.cardokno,
                                   A.importsdate = src.appdate,
                                   A.importedate = src.appdate,
                                   A.updatedt = SYSDATE,
                                   A.uempcode = p_iempcode;

                    MERGE INTO ACTAXD A
                    USING       (SELECT A.COMPCODE,
                                       A.PLANTCODE,
                                       A.TAXNO,
                                       A.SEQ,
                                       b.saldivnm,
                                       b.difamt,
                                       b.feeamt,
                                       b.colamt
                                FROM   ACTAXD A
                                       JOIN VGT.TT_ACACC0900CP_DUAL b
                                           ON A.compcode = b.compcode
                                              AND b.orderno = p_tempno
                                WHERE  A.taxno = p_taxno
                                       AND A.seq = 1) src
                    ON           (A.COMPCODE = SRC.COMPCODE
                                AND A.PLANTCODE = SRC.PLANTCODE
                                AND A.TAXNO = SRC.TAXNO
                                AND A.SEQ = SRC.SEQ)
                    WHEN MATCHED
                    THEN
                        UPDATE SET A.itemnm = src.saldivnm,
                                   A.gyugeok = '',
                                   A.qty = 0,
                                   A.prc = 0,
                                   A.amt = src.difamt,
                                   A.vat = src.feeamt,
                                   A.vatamt = src.colamt,
                                   A.remark = '',
                                   A.updatedt = SYSDATE,
                                   A.uempcode = p_iempcode;

                ELSE

                    FOR REC IN (SELECT B.COMPCODE, B.PLANTCODE, B.TAXNO, B.SEQ
                                FROM   VGT.TT_ACACC0900CP_DUAL A
                                       JOIN ACTAXD b
                                           ON A.compcode = b.compcode
                                              AND A.taxno = b.taxno
                                WHERE  A.orderno = p_tempno)
                    LOOP
                        DELETE FROM ACTAXD b
                        WHERE        B.COMPCODE = REC.COMPCODE
                                    AND B.PLANTCODE = REC.PLANTCODE
                                    AND B.TAXNO = REC.TAXNO
                                    AND B.SEQ = REC.SEQ;
                    END LOOP;

                    FOR REC IN (SELECT B.COMPCODE, B.PLANTCODE, B.TAXNO
                                FROM   VGT.TT_ACACC0900CP_DUAL A
                                       JOIN ACTAXM b
                                           ON A.compcode = b.compcode
                                              AND A.taxno = b.taxno
                                WHERE  A.orderno = p_tempno)
                    LOOP
                        DELETE FROM ACTAXM b
                        WHERE        B.COMPCODE = REC.COMPCODE
                                    AND B.PLANTCODE = REC.PLANTCODE
                                    AND B.TAXNO = REC.TAXNO;
                    END LOOP;

                END IF;

            END LOOP;

            INSERT INTO ACAUTOORDT(compcode, --회사코드
                                   acattype, --전표유형(C)
                                   acatno, --전표번호
                                   acatrulecode, --분개률코드
                                   actrnstate, --실행상태
                                   slipindate, --발의일자(수금일자)
                                   deptcode, --영업부서
                                   plantcode, --사업장
                                   empcode, --영업사원
                                   remark, --비고
                                   remark2, --비고2
                                   custcode, --거래처
                                   taxno, --계산서번호
                                   billno, --어음번호
                                   billcls, --어음구분AC32
                                   issdate, --발행일자
                                   expdate, --만기일자
                                   paybank, --지급은행
                                   issempnm, --발행인
                                   cardcomp, --카드사
                                   cardno, --카드번호
                                   cardokno, --카드승인번호
                                   divmonth, --할부기간
                                   trn1amt, --수금액
                                   trn2amt, --수수료
                                   trn3amt, --차액
                                   trn30amt, --순번
                                   userdef1code, --사용자정의1(계좌번호, 이월거래처코드)
                                   userdef2code, --사용자정의2(수금번호)
                                   userdef3code, --사업장명
                                   userdef4code, --부서명
                                   userdef5code, --발의사원명
                                   userdef6code, --거래처명
                                   userdef7code, --거래처명
                                   userdef8code, --계좌명
                                   userdef9code, --카드사
                                   userdef10code, --카드사명
                                   userdef11code, --상계처
                                   userdef12code, --상계처명
                                   insertdt, --입력일자
                                   iempcode) --입력사원
                (SELECT compcode, --회사코드
                        'C', --전표유형(C)
                        orderno, --수금번호
                        autorulecode, --분개률코드
                        actrnstate, --실행상태
                        appdate, --발의일자(수금일자)
                        deptcode, --영업부서
                        plantcode, --사업장
                        empcode, --영업사원
                        remark, --비고
                        '', --비고2
                        CASE WHEN coldiv IN ('55', '56') THEN concustcode ELSE custcode END col, --거래처
                        taxno, --계산서번호
                        billno, --어음번호
                        billcls, --어음구분AC32
                        issdate, --발행일자
                        expdate, --만기일자
                        paybank, --지급은행
                        '', --발행인
                        cardcomp, --카드사
                        cardno, --카드번호
                        cardokno, --카드승인번호
                        '', --할부기간
                        colamt, --수금액
                        feeamt, --수수료
                        difamt, --차액
                        p_crtord, --순번
                        CASE WHEN coldiv IN ('55', '56') THEN custcode ELSE accountno END col, --사용자정의1(계좌번호, 이월거래처코드)
                        orderno, --사용자정의2(수금번호)
                        '', --사업장명
                        deptname, --부서명
                        empname, --사원명
                        CASE WHEN coldiv IN ('55', '56') THEN concustname ELSE custname END col, --이월거래처명/거래처명
                        CASE WHEN coldiv IN ('55', '56') THEN custname ELSE '' END col, --거래처명
                        accremark, --계좌명
                        cardcomp, --카드사
                        cardcompnm, --카드사명
                        ecustcode, --상계처
                        ecustname, --상계처명
                        SYSDATE,
                        --입력일자
                        p_iempcode --입력사원
                 FROM    VGT.TT_ACACC0900CP_DUAL
                 WHERE    actrnstate = '1');



            -- 수정,삭제 처리전에 메타에 있는 내용을 이력테이블에 저장한다.
            INSERT INTO ACAUTOORDH
                SELECT     b.*
                FROM     VGT.TT_ACACC0900CP_DUAL A
                         LEFT JOIN ACAUTOORDT b
                             ON A.compcode = b.compcode
                                AND b.acattype = 'C'
                                AND A.orderno = b.acatno
                WHERE     A.actrnstate IN ('3', '4')
                         OR A.newchk = 'Y'
                ORDER BY A.orderno;



            --메타 테이블 저장
            MERGE INTO ACAUTOORDT b
            USING       (SELECT B.COMPCODE,
                               B.ACATTYPE,
                               B.ACATNO,
                               A.autorulecode, --분개코드
                               CASE WHEN b.actrnstate = '1' THEN b.actrnstate ELSE A.actrnstate END AS pos_3,
                               A.appdate, --발의일자(수금일자)
                               A.deptcode, --영업부서
                               A.plantcode, --사업장
                               A.empcode, --영업사원
                               A.remark, --비고
                               '' AS pos_9,
                               CASE WHEN A.coldiv IN ('55', '56') THEN A.concustcode ELSE A.custcode END AS pos_10,
                               A.taxno, --계산서번호
                               A.billno, --어음번호
                               A.billcls, --어음구분AC32
                               A.issdate, --발행일자
                               A.expdate, --만기일자
                               A.paybank, --지급은행
                               A.cardcomp, --카드사
                               A.cardno, --카드번호
                               A.cardokno, --카드승인번호
                               A.colamt, --수금액
                               A.feeamt, --수수료
                               A.difamt, --차액
                               --p_crtord, --순번
                               CASE WHEN A.coldiv IN ('55', '56') THEN A.custcode ELSE A.accountno END AS pos_24,
                               A.orderno, --수금번호
                               '' AS pos_26,
                               A.deptname, --부서명
                               A.empname, --사원명
                               CASE WHEN A.coldiv IN ('55', '56') THEN A.concustname ELSE A.custname END AS pos_29,
                               CASE WHEN A.coldiv IN ('55', '56') THEN A.custname ELSE '' END AS pos_30,
                               A.accremark, --계좌명
                               --, a.cardcomp --카드사
                               A.cardcompnm, --카드사명
                               A.ecustcode, --상계처
                               A.ecustname --상계처명
                        FROM   VGT.TT_ACACC0900CP_DUAL A
                               JOIN ACAUTOORDT b
                                   ON A.compcode = b.compcode
                                      AND b.acattype = 'C'
                                      AND A.orderno = b.acatno
                        WHERE  A.actrnstate IN ('3', '4')) src
            ON           (B.COMPCODE = SRC.COMPCODE
                        AND B.ACATTYPE = SRC.ACATTYPE
                        AND B.ACATNO = SRC.ACATNO)
            WHEN MATCHED
            THEN
                UPDATE SET acatrulecode = src.autorulecode,
                           actrnstate = pos_3, --자료상태
                           slipindate = src.appdate,
                           deptcode = src.deptcode,
                           plantcode = src.plantcode,
                           empcode = src.empcode,
                           remark = src.remark,
                           remark2 = pos_9, --비고2
                           custcode = pos_10, --거래처
                           taxno = src.taxno,
                           billno = src.billno,
                           billcls = src.billcls,
                           issdate = src.issdate,
                           expdate = src.expdate,
                           paybank = src.paybank,
                           cardcomp = src.cardcomp,
                           cardno = src.cardno,
                           cardokno = src.cardokno,
                           trn1amt = src.colamt,
                           trn2amt = src.feeamt,
                           trn3amt = src.difamt,
                           trn30amt = p_crtord,
                           userdef1code = pos_24, --이월거래처코드/계좌번호
                           userdef2code = src.orderno,
                           userdef3code = pos_26, --사업장명
                           userdef4code = src.deptname,
                           userdef5code = src.empname,
                           userdef6code = pos_29, --이월거래처명/거래처명
                           userdef7code = pos_30, --거래처명
                           userdef8code = src.accremark,
                           userdef9code = src.cardcomp,
                           userdef10code = src.cardcompnm,
                           userdef11code = src.ecustcode,
                           userdef12code = src.ecustname,
                           updatedt = SYSDATE, --수정일자
                           uempcode = p_iempcode;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
