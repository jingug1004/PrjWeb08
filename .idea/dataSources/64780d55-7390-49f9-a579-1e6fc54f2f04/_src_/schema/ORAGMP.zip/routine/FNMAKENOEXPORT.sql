CREATE FUNCTION        fnMakeNoExport
-- ---------------------------------------------------------------
-- 함 수 명            : fnMakeNoExport
-- 작 성 자         : 이욱주    
-- 작성일자         : 2015-06-09
-- 수정자         : 강현호
-- E-mail         : roykang0722@gmail.com
-- 수정일자       : 2017-07-31
-- ---------------------------------------------------------------
-- 함수설명            : 일련번호 생성
-- ---------------------------------------------------------------
(   p_div       IN  VARCHAR2    DEFAULT '' , 
    p_yymmdd    IN  VARCHAR2    DEFAULT ''
)
    RETURN VARCHAR2
AS
    p_exportno  VARCHAR2(20);
BEGIN

    IF( p_div = 'SLOFFERM') THEN 
    

        SELECT  'OF' || SUBSTR(REPLACE(p_yymmdd,'-',''), -6, 6) || NVL(SUBSTR('00' || (SUBSTR(MAX(offerno), -3, 3) + 1), -3, 3), '001')
        INTO    p_exportno
        FROM    SLOFFERM
        WHERE   SUBSTR(offerno, 0, 8) = 'OF' || SUBSTR(REPLACE(p_yymmdd, '-',''), -6, 6) ;

    ELSIF( p_div = 'SLLETTERM')  THEN 
    
        SELECT  'LC' || SUBSTR(REPLACE(p_yymmdd,'-',''), -6, 6) || NVL(SUBSTR('00' || (SUBSTR(MAX(lcno), -3, 3) + 1), -3, 3), '001')
        INTO    p_exportno
        FROM    SLLETTERM
        WHERE   SUBSTR(lcno, 0, 8) = 'LC' || SUBSTR(REPLACE(p_yymmdd, '-',''), -6, 6) ;

    ELSIF( p_div = 'SLINVOICEM')  THEN 
    
        SELECT  'IC' || SUBSTR(REPLACE(p_yymmdd,'-',''), -6, 6) || NVL(SUBSTR('00' || (SUBSTR(MAX(invoiceno), -3, 3) + 1), -3, 3), '001')
        INTO    p_exportno
        FROM    SLINVOICEM
        WHERE   SUBSTR(invoiceno, 0, 8) = 'IC' || SUBSTR(REPLACE(p_yymmdd, '-',''), -6, 6) ;

    ELSIF( p_div = 'SLSHIPMENTM')  THEN 
   
        SELECT  'BL' || SUBSTR(REPLACE(p_yymmdd,'-',''), -6, 6) ||  NVL(SUBSTR('00' || (SUBSTR(MAX(blno), -3, 3) + 1), -3, 3), '001')
        INTO    p_exportno
        FROM    SLSHIPMENTM
        WHERE   SUBSTR(blno, 0, 8) = 'BL' || SUBSTR(REPLACE(p_yymmdd, '-',''), -6, 6) ;

    ELSIF( p_div = 'SLEXPENSESM')  THEN 
    
        SELECT  'EX' || SUBSTR(REPLACE(p_yymmdd,'-',''), -6, 6) || NVL(SUBSTR('00' || (SUBSTR(MAX(expensesno), -3, 3) + 1), -3, 3), '001')
        INTO    p_exportno
        FROM    SLEXPENSESM
        WHERE   SUBSTR(expensesno, 0, 8) = 'EX' || SUBSTR(REPLACE(p_yymmdd, '-',''), -6, 6) ;

    ELSIF( p_div = 'SLNEGOM')  THEN 
        
        SELECT  'NG' || SUBSTR(REPLACE(p_yymmdd,'-',''), -6, 6) || NVL(SUBSTR('00' || (SUBSTR(MAX(negono), -3, 3) + 1), -3, 3), '001')
        INTO    p_exportno
        FROM    SLNEGOM
        WHERE   SUBSTR(negono, 0, 8) = 'NG' || SUBSTR(REPLACE(p_yymmdd, '-',''), -6, 6) ;
        
    END IF ;

    RETURN (p_exportno);
    
END;
/
