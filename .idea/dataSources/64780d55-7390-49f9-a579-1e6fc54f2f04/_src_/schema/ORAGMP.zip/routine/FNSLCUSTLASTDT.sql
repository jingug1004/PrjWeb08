CREATE FUNCTION        fnSLcustLASTDT( 
	-- ---------------------------------------------------------------
    -- 함 수 명     : [dbo].[fnSLcustLASTDT]
    -- 작 성 자           : 민승기
    -- 작성일자           : 2014-01-13
    -- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926p_gmail.com
	-- 수정일자      : 2017-02-14
    -- ---------------------------------------------------------------
    -- 함수설명     : 지정일자기준의 거래처 최종판매일,수금일을
    --       계산하여 테이블로 리턴
    -- ---------------------------------------------------------------
    -- select * from TABLE(fnSLcustLASTDT('1002','2000000228','%','%','2013-12-20'))

    p_plantcode 	IN 	VARCHAR2	DEFAULT NULL, 
    p_custcode 		IN 	VARCHAR2	DEFAULT NULL, -- 전체는 '%'
    p_utdiv 		IN 	VARCHAR2	DEFAULT NULL, -- 전체는 '%'
    p_orderdiv 		IN 	VARCHAR2	DEFAULT NULL, -- 전체는 '%'
    p_orderdate 	IN 	VARCHAR2	DEFAULT NULL
)
	RETURN FN_SLCUSTLASTDT_TABLE
AS
	PRAGMA AUTONOMOUS_TRANSACTION;
	i			  NUMBER := 1;
	listRecode	  FN_SLCUSTLASTDT_TABLE := FN_SLCUSTLASTDT_TABLE();
BEGIN
	-- 대상거래처 목록 ======================================================


	EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_FNSLCUSTLASTDT_CUSTCODELIST';


	INSERT INTO VGT.TT_FNSLCUSTLASTDT_CUSTCODELIST
		(SELECT c.custcode,
				c.plantcode,
				c.opendate,
				c.stopdate
		 FROM	CMCUSTM c
		 WHERE	c.plantcode LIKE p_plantcode
				AND (p_custcode = '%'
					 OR c.custcode = p_custcode)
				AND (p_utdiv = '%'
					 OR c.utdiv = p_utdiv));


	EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_FNSLCUSTLASTDT_LASTSALDATE';

	-- 거래처 최종 판매일 ===================================================
	INSERT INTO VGT.TT_FNSLCUSTLASTDT_LASTSALDATE
		(SELECT   a.custcode,
				  a.plantcode,
				  MAX(a.appdate) lastsaldate
		 FROM	  SLORDM a
				  JOIN VGT.TT_FNSLCUSTLASTDT_CUSTCODELIST c
					  ON a.custcode = c.custcode
						 AND a.plantcode = c.plantcode
		 WHERE	  a.appdate <= p_orderdate
				  AND a.plantcode LIKE p_plantcode
				  AND a.orderdiv LIKE p_orderdiv
				  AND a.saldiv IN (SELECT divcode FROM SLCONDRESULT)
				  AND a.saldiv LIKE 'A%'
				  AND a.statediv = '09'
		 GROUP BY a.custcode, a.plantcode);


	EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_FNSLCUSTLASTDT_LASTCOLDATE';

	-- 거래처 최종 판매일 ===================================================
	INSERT INTO VGT.TT_FNSLCUSTLASTDT_LASTCOLDATE
		(SELECT   a.custcode,
				  a.plantcode,
				  MAX(a.appdate) lastcoldate
		 FROM	  SLCOLM a
				  JOIN VGT.TT_FNSLCUSTLASTDT_CUSTCODELIST c
					  ON a.custcode = c.custcode
						 AND a.plantcode = c.plantcode
		 WHERE	  a.appdate <= p_orderdate
				  AND a.plantcode LIKE p_plantcode
				  AND a.orderdiv LIKE p_orderdiv
				  AND a.coldiv IN (SELECT divcode FROM SLCONDRESULT)
				  AND a.statediv = '09'
		 GROUP BY a.custcode, a.plantcode);


	EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_FNSLCUSTLASTDT_TABLE';

	-- 거래처 최종 거래일 ===================================================
	INSERT INTO VGT.TT_FNSLCUSTLASTDT_TABLE(custcode,
											plantcode,
											lastsaldate,
											lastcoldate,
											lasttotdate,
											opendate,
											stopdate)
		(SELECT c.custcode,
				c.plantcode,
				a.lastsaldate,
				S.lastcoldate,
				(CASE WHEN S.lastcoldate > a.lastsaldate THEN S.lastcoldate ELSE a.lastsaldate END) lasttotdate,
				c.opendate,
				c.stopdate
		 FROM	VGT.TT_FNSLCUSTLASTDT_CUSTCODELIST c
				LEFT JOIN VGT.TT_FNSLCUSTLASTDT_LASTSALDATE a
					ON a.custcode = c.custcode
					   AND a.plantcode = c.plantcode
				LEFT JOIN VGT.TT_FNSLCUSTLASTDT_LASTCOLDATE S
					ON S.custcode = c.custcode
					   AND a.plantcode = c.plantcode);

	COMMIT;

	FOR rec IN (SELECT custcode C1,
					   plantcode C2,
					   lastsaldate C3,
					   lastcoldate C4,
					   lasttotdate C5,
					   opendate C6,
					   stopdate C7
				FROM   VGT.TT_FNSLCUSTLASTDT_TABLE)
	LOOP
		listRecode.EXTEND;
		listRecode(i) :=
			FN_SLCUSTLASTDT_VARIABLE(rec.C1,
									 rec.C2,
									 rec.C3,
									 rec.C4,
									 rec.C5,
									 rec.C6,
									 rec.C7);
		i := i + 1;
	END LOOP;

	RETURN listRecode;
END;
/
