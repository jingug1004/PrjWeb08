CREATE FUNCTION fnGetCommonName
-- ---------------------------------------------------------------
-- 함 수 명   : fnGetCommonName
-- 작 성 자   : 이종석
-- 작성일자   :
-- 수정자     :
-- ---------------------------------------------------------------
-- 함수설명   : 공통코드명 가져오는 함수
-- ---------------------------------------------------------------
(
   p_div      IN VARCHAR2 DEFAULT ''
,  p_cmmcode  IN VARCHAR2 DEFAULT ''
,  p_divcode  IN VARCHAR2 DEFAULT ''
)
   RETURN VARCHAR2

AS
   v_return VARCHAR2(50) := NULL;
BEGIN

    IF (UPPER(p_div) = 'COMM') THEN

        SELECT divname
        INTO   v_return
        FROM   CMCOMMONM
        WHERE  cmmcode = p_cmmcode
        AND    divcode = p_divcode;

    ELSIF(UPPER(p_div) = 'EMP') THEN

        SELECT empname
        INTO   v_return
        FROM   CMEMPM
        WHERE  empcode = p_cmmcode;

    ELSIF(UPPER(p_div) = 'DEPT') THEN

        SELECT deptname
        INTO   v_return
        FROM   CMDEPTM
        WHERE  deptcode = p_cmmcode;

    ELSIF(UPPER(p_div) = 'CUST') THEN

        SELECT custname
        INTO   v_return
        FROM   CMCUSTM
        WHERE  custcode = p_cmmcode;
        
    ELSIF(UPPER(p_div) = 'PARAMETER') THEN
    
       SELECT value1
       INTO   v_return
			 FROM   parametermanage
			 WHERE  UPPER(parametercode) = UPPER(p_cmmcode) ;
                

    END IF;

    RETURN (v_return);

    EXCEPTION WHEN OTHERS THEN RETURN (v_return);

END;








/
