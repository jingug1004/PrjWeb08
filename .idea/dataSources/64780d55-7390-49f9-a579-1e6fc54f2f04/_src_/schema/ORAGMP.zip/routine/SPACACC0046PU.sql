CREATE PROCEDURE        spACacc0046PU(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0046PU
	-- 작 성 자         : 민승기
	-- 작성일자         : 2010-11-23
	-- 수정일자      :   노영래
	-- E-mail      :   0rae0926@gmail.com
	-- 수정일자      :   2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계전표를 승인하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			 IN 	VARCHAR2 DEFAULT '',
	p_compcode		 IN 	VARCHAR2 DEFAULT '',
	p_plantcode 	 IN 	VARCHAR2 DEFAULT '',
	p_slipdiv		 IN 	VARCHAR2 DEFAULT '',
	p_slipinstate	 IN 	VARCHAR2 DEFAULT '',
	p_slipinno		 IN 	VARCHAR2 DEFAULT '',
	p_slipindate	 IN 	VARCHAR2 DEFAULT '',
	p_slipdatechk	 IN 	VARCHAR2 DEFAULT '',
	p_slipdate		 IN 	VARCHAR2 DEFAULT '',
	p_state 		 IN 	VARCHAR2 DEFAULT '',
	p_slipremark	 IN 	VARCHAR2 DEFAULT '',
	p_acccode		 IN 	VARCHAR2 DEFAULT '',
	p_slipinseq 	 IN 	NUMBER DEFAULT 0,
	p_iempcode		 IN 	VARCHAR2 DEFAULT '',
	p_userid		 IN 	VARCHAR2 DEFAULT '',
	p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
	p_reasontext	 IN 	VARCHAR2 DEFAULT '',
	MESSAGE 			OUT VARCHAR2,
	IO_CURSOR			OUT TYPES.DATASET
)
AS
	ip_slipdate   VARCHAR2(10) := p_slipdate;
	ip_slipdiv	  VARCHAR2(5) := p_slipdiv;
	p_bdgcalc	  VARCHAR2(50);
	p_cmmcode	  VARCHAR2(50);
	p_chkdebamt   FLOAT(53);
	p_chkcreamt   FLOAT(53);
	v_temp		  NUMBER(1, 0) := 0;
	p_slipnum	  VARCHAR2(5);
	p_slipno	  VARCHAR2(20);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);



	p_bdgcalc := '2';
	p_cmmcode := '';

	FOR rec IN (SELECT value1, value2
				FROM   SYSPARAMETERMANAGE
				WHERE  UPPER(parametercode) = 'ACCSLIPBDGCALC')
	LOOP
		p_bdgcalc := rec.value1;
		p_cmmcode := rec.value2;
	END LOOP;

	IF (UPPER(P_DIV) = 'UCCHK') THEN
		-- 회계전표내역 결재승인
		FOR rec IN (SELECT NVL(SUM(debamt), 0) AS alias1, NVL(SUM(creamt), 0) AS alias2
					FROM   ACORDD
					WHERE  compcode = p_compcode
						   AND slipinno = p_slipinno
						   AND dcdiv IN ('1', '2'))
		LOOP
			p_chkdebamt := rec.alias1;
			p_chkcreamt := rec.alias2;
		END LOOP;

        SELECT COUNT(*)
        INTO   v_temp
        FROM   ACORDM
        WHERE  compcode = p_compcode
               AND slipinno = p_slipinno
               AND slipinstate = p_slipinstate;

		IF v_temp <> 0 THEN
			IF (p_chkdebamt = p_chkcreamt) THEN
				MESSAGE := 'OK';
			END IF;
		ELSE
			MESSAGE := 'STATE';
		END IF;
	ELSIF (UPPER(P_DIV) = 'UC') THEN
		-- 회계전표내역 결재승인
		-- 결의일자기준으로 회계일자 승인 또는 자동분개전표
		ip_slipdate :=
			CASE
				WHEN p_slipdatechk = 'Y' OR ip_slipdiv NOT IN ('C', 'R')
				THEN p_slipindate
				ELSE ip_slipdate
			END;

		FOR rec IN (SELECT NVL(MAX(filter2), ip_slipdiv) AS alias1
					FROM   CMCOMMONM
					WHERE  cmmcode = p_cmmcode
						   AND divcode = ip_slipdiv)
		LOOP
			ip_slipdiv := rec.alias1;
		END LOOP;

		FOR rec
			IN (SELECT REPLACE(ip_slipdate, '-', '') || RTRIM(ip_slipdiv) || LPAD(MAX(TO_NUMBER(SUBSTR(a.num, 10, 4))) + 1, 4, 0) AS alias1,
					   RTRIM(ip_slipdiv) || LPAD(MAX(TO_NUMBER(SUBSTR(a.num, 10, 4))) + 1, 4,'0') AS alias2
				FROM   (SELECT MAX(slipno) num
						FROM   ACORDM
						WHERE  compcode = p_compcode
							   AND NVL(slipno,' ') LIKE NVL(REPLACE(ip_slipdate, '-', '') || RTRIM(ip_slipdiv), '%') || '%'
						UNION ALL
						SELECT REPLACE(ip_slipdate, '-', '') || RTRIM(ip_slipdiv) || '0000' FROM DUAL) a)
		LOOP
			p_slipno := rec.alias1;
			p_slipnum := rec.alias2;
		END LOOP;

		-- 전표마스터 승인상태 등록
		UPDATE ACORDM
		SET    slipinstate = p_state,
			   slipdate = ip_slipdate,
			   slipno = p_slipno,
			   slipnum = p_slipnum,
			   slipempcode = p_iempcode,
			   slipremark = p_slipremark,
			   updatedt = SYSDATE,
			   uempcode = p_iempcode
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinstate = p_slipinstate;

		-- 전표상세 승인번호 등록
		MERGE INTO ACORDD b
		USING	   (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ, SYSDATE
					FROM   ACORDD b
						   JOIN ACORDM a
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno
					WHERE  b.compcode = p_compcode
						   AND b.slipinno = p_slipinno
						   AND a.slipinstate = p_state) src
		ON		   (B.COMPCODE = SRC.COMPCODE
        		AND B.SLIPINNO = SRC.SLIPINNO
                AND B.SLIPINSEQ = SRC.SLIPINSEQ)

		WHEN MATCHED THEN
			UPDATE SET b.slipdate = ip_slipdate, b.slipnum = p_slipnum, b.updatedt = SYSDATE, b.uempcode = p_iempcode;

		IF (p_slipinstate = '6' AND p_bdgcalc <> '1') THEN
			-- 회계전표 예산 집계처리
			spACbudg0000MM(p_div => 'AD',
								 p_compcode => p_compcode,																																																											 -- 회사코드
								 p_slipinno => p_slipinno,																																																										   -- 결의전표번호
								 p_userid => p_userid,
								 p_reasondiv => p_reasondiv,
								 p_reasontext => p_reasontext,
                                 MESSAGE => MESSAGE,
                                 IO_CURSOR => IO_CURSOR);
		END IF;

		-- 회계전표 집계처리
		spACord0000MM(P_DIV => 'A',
							p_compcode => p_compcode,																																																												 -- 회사코드
							p_slipno => p_slipno,																																																												   -- 회계전표번호
							p_closediv => '',																																																														 -- 결산구분
							p_userid => p_userid,
							p_reasondiv => p_reasondiv,
							p_reasontext => p_reasontext,
                            MESSAGE => MESSAGE,
                            IO_CURSOR => IO_CURSOR);

		MESSAGE := ip_slipdate || '일자 ' || p_slipnum || '번으로 ';

	ELSIF (UPPER(P_DIV) = 'UD') THEN
		-- 회계전표내역 승인취소/반려
		IF (p_slipinstate = '4') THEN
			-- 회계전표 집계처리
			spACord0000MM(P_DIV => 'B',
								p_compcode => p_compcode,																																																											 -- 회사코드
								p_slipno => p_slipno,																																																											   -- 회계전표번호
								p_closediv => '',																																																													 -- 결산구분
								p_userid => p_userid,
								p_reasondiv => p_reasondiv,
								p_reasontext => p_reasontext,
                                MESSAGE => MESSAGE,
                                IO_CURSOR => IO_CURSOR);
		END IF;

		IF (p_state = '6' AND p_bdgcalc <> '1') THEN
			-- 회계전표 예산 집계처리
			spACbudg0000MM(P_DIV => 'MI',
								 p_compcode => p_compcode,																																																											 -- 회사코드
								 p_slipinno => p_slipinno,																																																										   -- 결의전표번호
								 p_userid => p_userid,
								 p_reasondiv => p_reasondiv,
								 p_reasontext => p_reasontext,
                                 MESSAGE => MESSAGE,
                                 IO_CURSOR => IO_CURSOR);
		END IF;

		-- 전표마스터 승인상태 취소
		UPDATE ACORDM
		SET    slipinstate = p_state,
			   slipdate = '',
			   slipno = '',
			   slipnum = '',
			   slipempcode = p_iempcode,
			   slipremark = p_slipremark,
			   updatedt = SYSDATE,
			   uempcode = p_iempcode
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinstate = p_slipinstate;

		-- 전표상세 승인번호 취소
		MERGE INTO ACORDD b
		USING	   (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ, '' AS pos_2, '' AS pos_3, SYSDATE
					FROM   ACORDD b
						   JOIN ACORDM a
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno
					WHERE  b.compcode = p_compcode
						   AND b.slipinno = p_slipinno
						   AND a.slipinstate = p_state) src
		ON		   (B.COMPCODE = SRC.COMPCODE
        		AND B.SLIPINNO = SRC.SLIPINNO
                AND B.SLIPINSEQ = SRC.SLIPINSEQ)

		WHEN MATCHED THEN
			UPDATE SET b.slipdate = pos_2, b.slipnum = pos_3, b.updatedt = SYSDATE, b.uempcode = p_iempcode;

	ELSIF (UPPER(P_DIV) = 'UA') THEN
		-- 계정코드변경
		UPDATE ACORDD
		SET    acccode = p_acccode, updatedt = SYSDATE, uempcode = p_iempcode
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq;

	ELSIF (UPPER(P_DIV) = 'AUTO') THEN
		-- 전표유형에 대한 콤보셋팅
		OPEN IO_CURSOR FOR
			SELECT '%' keyfield, '전체' displayfield
			FROM   DUAL
			WHERE  ip_slipdiv NOT IN ('A', 'R', 'F', 'K', '%')
			UNION ALL
			SELECT a.acautorcode keyfield, a.acautorname displayfield
			FROM   ACAUTORULE a
			WHERE  ip_slipdiv NOT IN ('A', 'R', 'F', 'K', '%')
				   AND a.accdiv = ip_slipdiv;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
