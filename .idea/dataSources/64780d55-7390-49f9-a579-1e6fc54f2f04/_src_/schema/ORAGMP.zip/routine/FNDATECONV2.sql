CREATE FUNCTION        fnDateConv2(
	ip_convdata 	IN 	VARCHAR2

)
	RETURN VARCHAR2
AS
	p_convdata	 VARCHAR2(10) := ip_convdata;
	p_resultdt	 DATE;
	p_temp		 VARCHAR2(8);
-- 문자일자
BEGIN
	p_convdata := RTRIM(LTRIM(p_convdata));

	IF (NVL(p_convdata, ' ') = ' ') OR (p_convdata = '0')
	THEN
		BEGIN
			p_resultdt := NULL;
			GOTO finishrtn;
		END;
	END IF;

	p_convdata := REPLACE(p_convdata, '-', '');
	p_convdata := REPLACE(p_convdata, '/', '');
	p_convdata := REPLACE(p_convdata, '.', '');

	IF NOT (LENGTH(p_convdata) IN (6, 8))
	THEN
		p_resultdt := TO_DATE('1950-01-01','YYYY-MM-DD');
		GOTO finishrtn;
	END IF;

	IF LENGTH(p_convdata) = 6
	THEN
		IF SUBSTR(p_convdata, 0, 2) < '50'
		THEN
			p_temp := '20' || p_convdata;
		ELSE
			p_temp := '19' || p_convdata;
		END IF;
	ELSE
		p_temp := p_convdata;
	END IF;

	IF SUBSTR(p_temp, 0, 4) < '1950' OR NOT (SUBSTR(p_temp, 5, 2) BETWEEN '01' AND '12')
	THEN
		p_resultdt := TO_DATE('1950-01-01','YYYY-MM-DD');
		GOTO finishrtn;
	END IF;

	IF SUBSTR(p_temp, 7, 2) = '00'
	THEN
		p_resultdt := TO_DATE(SUBSTR(p_temp, 0, 6), 'YYYYMM');
	ELSIF SUBSTR(p_temp,7,2) > TO_CHAR(LAST_DAY(TO_DATE(SUBSTR(p_temp,0,6),'YYYYMM')),'DD')
    THEN
    	p_resultdt := LAST_DAY(TO_DATE(SUBSTR(p_temp,0,6),'YYYYMM'));
	ELSE
		p_resultdt := TO_DATE(p_temp,'YYYYMMDD');
	END IF;

   <<finishrtn>>
	RETURN (TO_CHAR(p_resultdt, 'YYYY-MM-DD'));
EXCEPTION
	WHEN OTHERS
	THEN
		RETURN NULL;
END;
/
