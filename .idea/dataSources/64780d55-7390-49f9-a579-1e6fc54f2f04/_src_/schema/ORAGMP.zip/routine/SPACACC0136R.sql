CREATE PROCEDURE        spACacc0136R
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACacc0136R
   -- 작 성 자         : 최기홍
   -- 작성일자         : 2010-10-08
   --수정자         : 임 정호
   -- 작성일자         : 2016-12-20
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 경비명세서 조회하는 프로시저이다.
   -- ---------------------------------------------------------------
   -- select * from ACORDDMM
   -- exec spACacc0136R 'S','100','%','1','2011-01','2011-03','1', '','','','N'
(

   p_div          IN     VARCHAR2 DEFAULT '',
   p_compcode     IN     VARCHAR2 DEFAULT '',
   p_plantcode    IN     VARCHAR2 DEFAULT '',
   p_divS         IN     VARCHAR2 DEFAULT '',
   p_startdt      IN     VARCHAR2 DEFAULT '',
   p_enddt        IN     VARCHAR2 DEFAULT '',
   p_outputdiv    IN     VARCHAR2 DEFAULT '',
   p_userid       IN     VARCHAR2 DEFAULT '',
   p_reasondiv    IN     VARCHAR2 DEFAULT '',
   p_reasontext   IN     VARCHAR2 DEFAULT '',
   IO_CURSOR         OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2)
AS
   p_odiv      VARCHAR2 (5);
   p_enddate   VARCHAR2 (10);
   p_a         VARCHAR2 (5);
BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);



    SELECT DECODE (p_enddt,NULL, NULL, TO_CHAR(ADD_MONTHS (TO_DATE (p_enddt||'-01','YYYY-MM-DD') , 1 ) -1,'YYYY-MM-DD')) INTO p_enddate
    FROM DUAL;



    IF (p_div = 'S') THEN

        IF (p_outputdiv = '1') THEN
            --K-GAAP
            p_odiv := '20';
        ELSIF (p_outputdiv = '2') THEN
            --IFRS
            p_odiv := '30';
        END IF;

        FOR rec IN
        (
            SELECT filter1
            FROM CMCOMMONM
            WHERE cmmcode = 'AC27' AND divcode = p_divS
        )
        LOOP
            p_a := rec.filter1;
        END LOOP;

        IF (p_divS IN ('2', '4')) THEN
            OPEN IO_CURSOR FOR
              SELECT a.compcode,
                     a.plantcode,
                     p_startdt || '-01' startdt,
                     p_enddate enddt,
                     p_outputdiv outputdiv,
                     a.acccode,
                     b.accname,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '01' THEN NVL (creamt, 0) ELSE 0 END) mon1,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '02' THEN NVL (creamt, 0) ELSE 0 END) mon2,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '03' THEN NVL (creamt, 0) ELSE 0 END) mon3,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '04' THEN NVL (creamt, 0) ELSE 0 END) mon4,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '05' THEN NVL (creamt, 0) ELSE 0 END) mon5,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '06' THEN NVL (creamt, 0) ELSE 0 END) mon6,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '07' THEN NVL (creamt, 0) ELSE 0 END) mon7,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '08' THEN NVL (creamt, 0) ELSE 0 END) mon8,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '09' THEN NVL (creamt, 0) ELSE 0 END) mon9,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '10' THEN NVL (creamt, 0) ELSE 0 END) mon10,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '11' THEN NVL (creamt, 0) ELSE 0 END) mon11,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '12' THEN NVL (creamt, 0) ELSE 0 END) mon12,
                     SUM (creamt) amt
                FROM ACORDDMM a LEFT JOIN ACACCM b ON a.acccode = b.acccode
               WHERE     a.compcode = p_compcode
                     AND a.plantcode LIKE p_plantcode
                     AND SUBSTR (a.acccode, 0, 2) LIKE p_a
                     AND slipym BETWEEN p_startdt AND p_enddt
                     AND (a.closediv = '10' OR a.closediv = p_odiv)  -- 출력구분 [K-GAAP, IFRS
                GROUP BY a.compcode, a.plantcode, a.acccode, b.accname
                ORDER BY a.compcode, a.plantcode, a.acccode, b.accname;
        ELSIF (p_divS IN ('1', '3', '5', '6', '7')) THEN
            OPEN IO_CURSOR FOR
              SELECT a.compcode,
                     a.plantcode,
                     p_startdt || '-01' startdt,
                     p_enddate enddt,
                     p_outputdiv outputdiv,
                     a.acccode,
                     b.accname,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '01' THEN NVL (debamt, 0) ELSE 0 END) mon1,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '02' THEN NVL (debamt, 0) ELSE 0 END) mon2,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '03' THEN NVL (debamt, 0) ELSE 0 END) mon3,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '04' THEN NVL (debamt, 0) ELSE 0 END) mon4,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '05' THEN NVL (debamt, 0) ELSE 0 END) mon5,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '06' THEN NVL (debamt, 0) ELSE 0 END) mon6,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '07' THEN NVL (debamt, 0) ELSE 0 END) mon7,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '08' THEN NVL (debamt, 0) ELSE 0 END) mon8,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '09' THEN NVL (debamt, 0) ELSE 0 END) mon9,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '10' THEN NVL (debamt, 0) ELSE 0 END) mon10,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '11' THEN NVL (debamt, 0) ELSE 0 END) mon11,
                     SUM (CASE WHEN NVL (SUBSTR (slipym, -2), 0) = '12' THEN NVL (debamt, 0) ELSE 0 END) mon12,
                     SUM (debamt) amt
                FROM ACORDDMM a LEFT JOIN ACACCM b ON a.acccode = b.acccode
               WHERE     a.compcode = p_compcode
                     AND a.plantcode LIKE p_plantcode
                     AND SUBSTR (a.acccode, 0, 2) LIKE p_a
                     AND slipym BETWEEN p_startdt AND p_enddt
                     AND (a.closediv = '10' OR a.closediv = p_odiv )-- 출력구분 [K-GAAP, IFRS
            --출력구분 에따른 출력 넣어야함
            GROUP BY a.compcode, a.plantcode, a.acccode, b.accname
            ORDER BY a.compcode, a.plantcode, a.acccode, b.accname;
        END IF;
    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
