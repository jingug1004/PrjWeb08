CREATE PROCEDURE        spACacc0210R
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0210R
-- 작 성 자         : 최기홍
-- 작성일자         : 2010-10-08
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2016-12-21
-- ---------------------------------------------------------------
-- 프로시저 설명    : 매출원가명세서를 조회하는 프로시저이다.
-- ---------------------------------------------------------------
(
	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_rptdiv		IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '',
	p_basisym		IN	   VARCHAR2 DEFAULT '',
	p_viewyn		IN	   VARCHAR2 DEFAULT 'Y',
	p_pretype		IN	   VARCHAR2 DEFAULT '1',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		OUT    VARCHAR2,
	IO_CURSOR		OUT    TYPES.DataSet
)
AS
	p_basisyy	 VARCHAR2(4);
	p_beyymm	 VARCHAR2(7);
	p_yyyy01	 VARCHAR2(7);
	p_beyy01	 VARCHAR2(7);
	p_cashcode	 VARCHAR2(20);

	-- 임시테이블의 calcseq의 최대값을 조회
	p_maxseq	 NUMBER;
	p_curseq	 NUMBER;
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S' OR p_div = 'P') THEN

        -- 기간 설정
        p_yyyy01 := SUBSTR(p_basisym, 0, 4) || '-01';

        FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
                    FROM   ACSESSION
                    WHERE  compcode = p_compcode
                           AND cyear <= SUBSTR(p_basisym, 0, 4))
        LOOP
            p_yyyy01 := rec.alias1;
        END LOOP;


        IF SUBSTR(p_basisym, -2, 2) < SUBSTR(p_yyyy01, -2, 2) THEN
            p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), -12), 'YYYY-') || SUBSTR(p_yyyy01, -2, 2);
        ELSE
            p_yyyy01 := SUBSTR(p_basisym, 0, 5) || SUBSTR(p_yyyy01, -2, 2);
        END IF;


        IF p_pretype = '1' THEN
            p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), -12), 'YYYY-MM');
        ELSIF p_pretype = '2' OR p_pretype = '3' AND SUBSTR(p_basisym, -2, 2) = SUBSTR(p_yyyy01, -2, 2) THEN
            p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01 || '-01', 'YYYY-MM-DD'), -1), 'YYYY-MM');
        ELSE
            p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), -1), 'YYYY-MM');
        END IF;


		IF p_pretype = '3' AND SUBSTR(p_basisym, -2, 2) <> SUBSTR(p_yyyy01, -2, 2)
		THEN
			p_beyy01 := p_yyyy01;
		ELSE
			p_beyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01 || '-01', 'YYYY-MM-DD'), -12), 'YYYY-MM');
		END IF;

		p_cashcode := '11101010';

		FOR rec IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  UPPER(parametercode) = 'ACCCASHCODE')
		LOOP
			p_cashcode := rec.value1;
		END LOOP;

		-- 보고서 조회년도 설정
		FOR rec IN (SELECT MAX(rptyear) AS alias1
					FROM   ACRPTM
					WHERE  compcode = p_compcode
						   AND rptdiv = p_rptdiv
						   AND rptyear <= SUBSTR(p_basisym, 0, 4))
		LOOP
			p_basisyy := rec.alias1;
		END LOOP;


		-- 전표에서 월집계 임시파일을 생성
		EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0210R_ACORDDMM' ;

        INSERT INTO VGT.TT_ACACC0210R_ACORDDMM (
            SELECT  p_compcode compcode,
                    p_plantcode plantcode,
                    p_basisym slipym,
                    CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
                    acccode,
                    SUM(totdebamt) totdebamt,
                    SUM(totcreamt) totcreamt
            FROM (  SELECT  TRIM(b.acccode) acccode
                            , b.debamt totdebamt
                            , b.creamt totcreamt
                    FROM    ACORDM A
                            JOIN ACORDD b ON A.compcode = b.compcode
                                             AND A.slipinno = b.slipinno
                    WHERE   A.compcode = p_compcode
                            AND A.plantcode LIKE p_plantcode
                            AND A.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), 1), 'YYYYMM')
                            AND A.slipinstate = '4'
                            AND (A.slipdiv NOT IN ('K', 'F') OR
                                 p_closediv = '1' AND A.slipdiv = 'K' OR
                                 p_closediv = '2' AND A.slipdiv = 'F' )

                    UNION ALL

                    SELECT  p_cashcode acccode
                            , b.creamt totdebamt
                            , b.debamt totcreamt
                    FROM    ACORDM A
                            JOIN ACORDD b ON A.compcode = b.compcode
                                             AND A.slipinno = b.slipinno
                                             AND b.dcdiv IN ('3', '4')
                    WHERE   A.compcode = p_compcode
                            AND A.plantcode LIKE p_plantcode
                            AND A.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), 1), 'YYYYMM')
                            AND A.slipinstate = '4'
                            AND (NVL(A.slipdiv,' ') NOT IN ('K', 'F') OR
                                 p_closediv = '1' AND A.slipdiv = 'K' OR
                                 p_closediv = '2' AND A.slipdiv = 'F' )
                    UNION ALL
                    SELECT  TRIM(acccode) acccode
                            , bsdebamt totdebamt
                            , bscreamt totcreamt
                    FROM    ACORDDMM
                    WHERE   compcode = p_compcode
                            AND plantcode LIKE p_plantcode
                            AND slipym = p_yyyy01
                            AND (p_closediv = '1' AND closediv IN ('10', '20') OR
                                 p_closediv = '2' AND closediv IN ('10', '30'))
                 ) A
            GROUP BY acccode );

        INSERT INTO VGT.TT_ACACC0210R_ACORDDMM
            (SELECT   p_compcode compcode,
                      p_plantcode plantcode,
                      p_beyymm slipym,
                      CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
                      a.acccode,
                      SUM(a.totdebamt) totdebamt,
                      SUM(a.totcreamt) totcreamt
             FROM	  (SELECT TRIM(acccode) acccode,
                              totdebamt,
                              totcreamt
                       FROM   ACORDDMM
                       WHERE  compcode = p_compcode
                              AND plantcode LIKE p_plantcode
                              AND slipym = p_beyymm
                              AND (p_closediv = '1'
                                   AND closediv IN ('10', '20')
                                   OR p_closediv = '2'
                                      AND closediv IN ('10', '30'))) a
             GROUP BY a.acccode);

        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0210R_ACC210A';

        -- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
        INSERT INTO VGT.TT_ACACC0210R_ACC210A(    seqline,
                                                  acccode,
                                                  accrname,
                                                  acckname,
                                                  lrdiv,
                                                  prtyn,
                                                  prtdiv,
                                                  prtbold,
                                                  sseqline,
                                                  calcseq,
                                                  calcdiv,
                                                  cseqline,
                                                  cgb,
                                                  objdatadiv,
                                                  amt,
                                                  beamt )
        SELECT	 A.seqline,
                 MAX(A.acccode),
                 MAX(A.accrname),
                 MAX(A.acckname),
                 MAX(A.lrdiv),
                 MAX(A.prtyn),
                 MAX(A.prtdiv),
                 MAX(A.prtbold),
                 MAX(A.sseqline),
                 MAX(A.calcseq),
                 MAX(A.calcdiv),
                 MAX(A.cseqline),
                 '1',
                 MAX(A.objdatadiv),
                 NVL(SUM(CASE WHEN c.slipym = p_basisym THEN CASE WHEN A.objdatadiv IN ('D', 'F') THEN c.totdebamt
                                                                  WHEN A.objdatadiv IN ('C', 'E') THEN c.totcreamt
                                                                  WHEN A.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt
                                                                                                    ELSE c.totcreamt - c.totdebamt
                                                                                               END
                                                             END
                         END), 0) amt2,
                 NVL(SUM(CASE WHEN c.slipym = p_beyymm THEN CASE WHEN A.objdatadiv IN ('D', 'F') THEN c.totdebamt
                                                                 WHEN A.objdatadiv IN ('C', 'E') THEN c.totcreamt
                                                                 WHEN A.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt
                                                                                                   ELSE c.totcreamt - c.totdebamt
                                                                                              END
                                                            END
                         END), 0) amt4
        FROM	 ACRPTM A
                 LEFT JOIN ACACCM b ON NVL(A.acccode,' ') = NVL(b.acccode,' ')
                 LEFT JOIN VGT.TT_ACACC0210R_ACORDDMM c ON A.compcode = c.compcode
                                                            AND c.plantcode LIKE p_plantcode
                                                            AND c.slipym IN (p_basisym, p_beyymm)
                                                            AND (p_closediv = '1' AND c.closediv IN ('10', '20') OR
                                                                 p_closediv = '2' AND c.closediv IN ('10', '30'))
                                                            AND NVL(A.acccode,' ') = NVL(c.acccode,' ')
        WHERE	 A.compcode = p_compcode
                 AND A.rptdiv = p_rptdiv
                 AND A.rptyear = p_basisyy
                 AND A.useyn = 'Y'
        GROUP BY A.seqline
        ORDER BY A.seqline;

		-- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
        MERGE INTO VGT.TT_ACACC0210R_ACC210A A
        USING	   (SELECT CASE WHEN A.objdatadiv = 'A' THEN b.amt ELSE A.amt - b.amt END AS amt,
                           CASE WHEN A.objdatadiv = 'A' THEN b.beamt ELSE A.beamt - b.beamt END AS beamt,
                           a.lrdiv,
                           a.prtdiv,
                           a.calcdiv,
                           a.objdatadiv,
                           a.seqline,
                           a.acccode,
                           a.sseqline,
                           a.cseqline,
                           a.accrname,
                           a.acckname,
                           a.prtyn,
                           a.prtbold,
                           a.calcseq,
                           a.cgb,
                           a.calcamt,
                           a.becalcamt
                    FROM   VGT.TT_ACACC0210R_ACC210A A
                           JOIN (SELECT   A.seqline,
                                          NVL(SUM(CASE WHEN c.slipym = p_yyyy01 THEN CASE WHEN A.objdatadiv = 'F' THEN c.bsdebamt WHEN A.objdatadiv = 'E' THEN c.bscreamt WHEN A.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) amt,
                                          NVL(SUM(CASE WHEN c.slipym = p_beyy01 THEN CASE WHEN A.objdatadiv = 'F' THEN c.bsdebamt WHEN A.objdatadiv = 'E' THEN c.bscreamt WHEN A.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) beamt
                                 FROM	  ACRPTM A
                                          LEFT JOIN ACACCM b ON NVL(A.acccode, ' ') = NVL(b.acccode, ' ')
                                          LEFT JOIN ACORDDMM c
                                              ON A.compcode = c.compcode
                                                 AND c.plantcode LIKE p_plantcode
                                                 AND c.slipym IN (p_yyyy01, p_beyy01)
                                                 AND (p_closediv = '1'
                                                      AND c.closediv IN ('10', '20')
                                                      OR p_closediv = '2'
                                                         AND c.closediv IN ('10', '30'))
                                                 AND NVL(A.acccode, ' ') = NVL(c.acccode, ' ')
                                 WHERE	  A.compcode = p_compcode
                                          AND A.rptdiv = p_rptdiv
                                          AND A.rptyear = p_basisyy
                                          AND A.useyn = 'Y'
                                          AND A.objdatadiv IN ('A', 'E', 'F')
                                 GROUP BY A.seqline) b
                               ON A.seqline = b.seqline) src
        ON		   (NVL(a.lrdiv, ' ') = NVL(src.lrdiv, ' ')
                    AND NVL(a.prtdiv, ' ') = NVL(src.prtdiv, ' ')
                    AND NVL(a.calcdiv, ' ') = NVL(src.calcdiv, ' ')
                    AND NVL(a.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
                    AND NVL(a.seqline, ' ') = NVL(src.seqline, ' ')
                    AND NVL(a.acccode, ' ') = NVL(src.acccode, ' ')
                    AND NVL(a.sseqline, ' ') = NVL(src.sseqline, ' ')
                    AND NVL(a.cseqline, ' ') = NVL(src.cseqline, ' ')
                    AND NVL(a.accrname, ' ') = NVL(src.accrname, ' ')
                    AND NVL(a.acckname, ' ') = NVL(src.acckname, ' ')
                    AND NVL(a.prtyn, ' ') = NVL(src.prtyn, ' ')
                    AND NVL(a.prtbold, ' ') = NVL(src.prtbold, ' ')
                    AND NVL(a.calcseq, 0) = NVL(src.calcseq, 0)
                    AND NVL(a.cgb, 0) = NVL(src.cgb, 0)
                    AND NVL(a.calcamt, 0) = NVL(src.calcamt, 0)
                    AND NVL(a.becalcamt, 0) = NVL(src.becalcamt, 0))
        WHEN MATCHED
        THEN
            UPDATE SET A.amt = src.amt, A.beamt = src.beamt;

        -- 임시테이블의 CALCSEQ 의 최대값을 조회
        p_curseq := 0;
        p_maxseq := 0;

		FOR rec IN (    SELECT  MAX(calcseq) AS alias1
                        FROM    VGT.TT_ACACC0210R_ACC210A
        )
		LOOP
			p_maxseq := rec.alias1;
		END LOOP;


        -- 각 레벨별로 sum을하여 update
        WHILE p_curseq <= p_maxseq LOOP
            MERGE INTO VGT.TT_ACACC0210R_ACC210A a
            USING	   (SELECT A.LRDIV,
                               A.PRTDIV,
                               A.CALCDIV,
                               A.OBJDATADIV,
                               A.SEQLINE,
                               A.ACCCODE,
                               A.SSEQLINE,
                               A.CSEQLINE,
                               A.ACCRNAME,
                               A.ACCKNAME,
                               A.PRTYN,
                               A.PRTBOLD,
                               A.CALCSEQ,
                               A.CGB,
                               A.CALCAMT,
                               A.BECALCAMT,
                               a.amt + b.amt amt,
                               a.beamt + b.beamt beamt
                        FROM   VGT.TT_ACACC0210R_ACC210A a
                               JOIN (SELECT   sseqline,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt ELSE -amt END) AS amt,
                                              SUM(CASE WHEN calcdiv = '+' THEN beamt ELSE -beamt END) AS beamt
                                     FROM	  VGT.TT_ACACC0210R_ACC210A
                                     WHERE	  calcseq = p_curseq
                                              AND NVL(sseqline, ' ') <> ' '
                                     GROUP BY sseqline) b
                                   ON a.seqline = b.sseqline) SRC
            ON		   (NVL(a.lrdiv, ' ') = NVL(src.lrdiv, ' ')
                        AND NVL(a.prtdiv, ' ') = NVL(src.prtdiv, ' ')
                        AND NVL(a.calcdiv, ' ') = NVL(src.calcdiv, ' ')
                        AND NVL(a.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
                        AND NVL(a.seqline, ' ') = NVL(src.seqline, ' ')
                        AND NVL(a.acccode, ' ') = NVL(src.acccode, ' ')
                        AND NVL(a.sseqline, ' ') = NVL(src.sseqline, ' ')
                        AND NVL(a.cseqline, ' ') = NVL(src.cseqline, ' ')
                        AND NVL(a.accrname, ' ') = NVL(src.accrname, ' ')
                        AND NVL(a.acckname, ' ') = NVL(src.acckname, ' ')
                        AND NVL(a.prtyn, ' ') = NVL(src.prtyn, ' ')
                        AND NVL(a.prtbold, ' ') = NVL(src.prtbold, ' ')
                        AND NVL(a.calcseq, 0) = NVL(src.calcseq, 0)
                        AND NVL(a.cgb, 0) = NVL(src.cgb, 0)
                        AND NVL(a.calcamt, 0) = NVL(src.calcamt, 0)
                        AND NVL(a.becalcamt, 0) = NVL(src.becalcamt, 0))
            WHEN MATCHED
            THEN
                UPDATE SET a.amt = src.amt, a.beamt = src.beamt;

            p_curseq := p_curseq + 1;

        END LOOP;


        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0210R_ACC210B ';

        INSERT INTO VGT.TT_ACACC0210R_ACC210B
            SELECT	A.cseqline,
                    A.seqline,
                    A.amt,
                    A.beamt,
                    0,
                    0,
                    b.amt,
                    b.beamt,
                    0 ,
                    ROWNUM
            FROM    VGT.TT_ACACC0210R_ACC210A A
                    JOIN VGT.TT_ACACC0210R_ACC210A b ON A.cseqline = b.seqline
            WHERE   (A.amt <> 0 OR A.beamt <> 0)
            ORDER BY A.cseqline, A.seqline DESC;

            MERGE INTO VGT.TT_ACACC0210R_ACC210B A
            USING	   (SELECT a.ord - b.minno + 1 AS num,
                               a.cseqline,
                               a.seqline,
                               a.amt,
                               a.beamt,
                               a.amt3,
                               a.beamt3,
                               a.ord
                        FROM   VGT.TT_ACACC0210R_ACC210B A
                               JOIN (SELECT   A.cseqline,
                                              MIN(A.ord) minNo
                                     FROM	  VGT.TT_ACACC0210R_ACC210B A
                                     GROUP BY A.cseqline) b
                                   ON A.cseqline = b.cseqline) src
            ON		   (NVL(a.cseqline, ' ') = NVL(src.cseqline, ' ')
                        AND NVL(a.seqline, ' ') = NVL(src.seqline, ' ')
                        AND NVL(a.amt, 0) = NVL(src.amt, 0)
                        AND NVL(a.beamt, 0) = NVL(src.beamt, 0)
                        AND NVL(a.amt3, 0) = NVL(src.amt3, 0)
                        AND NVL(a.beamt3, 0) = NVL(src.beamt3, 0)
                        AND NVL(a.ord, 0) = NVL(src.ord, 0))
            WHEN MATCHED
            THEN
                UPDATE SET A.num = src.num, A.amt2 = 0, A.beamt2 = 0;

        MERGE INTO VGT.TT_ACACC0210R_ACC210B A
        USING	   (SELECT b.amt,
                           b.beamt,
                           a.cseqline,
                           a.seqline,
                           a.amt amtA,
                           a.beamt beamtA,
                           a.amt3,
                           a.beamt3,
                           a.num,
                           a.ord
                    FROM   VGT.TT_ACACC0210R_ACC210B A
                           JOIN (SELECT   A.cseqline,
                                          SUM(amt) amt,
                                          SUM(beamt) beamt
                                 FROM	  VGT.TT_ACACC0210R_ACC210B A
                                 GROUP BY A.cseqline) b
                               ON A.cseqline = b.cseqline
                                  AND num = 1) src
        ON		   (NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
                    AND NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
                    AND NVL(A.AMT, 0) = NVL(SRC.amtA, 0)
                    AND NVL(A.BEAMT, 0) = NVL(SRC.beamtA, 0)
                    AND NVL(A.AMT3, 0) = NVL(SRC.AMT3, 0)
                    AND NVL(A.BEAMT3, 0) = NVL(SRC.BEAMT3, 0)
                    AND NVL(A.NUM, 0) = NVL(SRC.NUM, 0)
                    AND NVL(A.ORD, 0) = NVL(SRC.ORD, 0))
        WHEN MATCHED
        THEN
            UPDATE SET amt2 = src.amt, beamt2 = src.beamt;

        MERGE INTO VGT.TT_ACACC0210R_ACC210A A
        USING	   (SELECT A.PRTDIV,
                           A.CALCDIV,
                           A.OBJDATADIV,
                           A.SEQLINE,
                           A.ACCCODE,
                           A.SSEQLINE,
                           A.CSEQLINE,
                           A.ACCRNAME,
                           A.ACCKNAME,
                           A.PRTYN,
                           A.PRTBOLD,
                           A.CALCSEQ,
                           A.CGB,
                           A.AMT,
                           A.CALCAMT,
                           A.BEAMT,
                           A.BECALCAMT
                    FROM   VGT.TT_ACACC0210R_ACC210A A
                           JOIN (SELECT DISTINCT A.cseqline
                                 FROM	VGT.TT_ACACC0210R_ACC210B A
                                 UNION
                                 SELECT b.seqline
                                 FROM	VGT.TT_ACACC0210R_ACC210B b) b
                               ON A.seqline = b.cseqline) src
        ON		   (NVL(a.prtdiv, ' ') = NVL(src.prtdiv, ' ')
                    AND NVL(a.calcdiv, ' ') = NVL(src.calcdiv, ' ')
                    AND NVL(a.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
                    AND NVL(a.seqline, ' ') = NVL(src.seqline, ' ')
                    AND NVL(a.acccode, ' ') = NVL(src.acccode, ' ')
                    AND NVL(a.sseqline, ' ') = NVL(src.sseqline, ' ')
                    AND NVL(a.cseqline, ' ') = NVL(src.cseqline, ' ')
                    AND NVL(a.accrname, ' ') = NVL(src.accrname, ' ')
                    AND NVL(a.acckname, ' ') = NVL(src.acckname, ' ')
                    AND NVL(a.prtyn, ' ') = NVL(src.prtyn, ' ')
                    AND NVL(a.prtbold, ' ') = NVL(src.prtbold, ' ')
                    AND NVL(a.calcseq, 0) = NVL(src.calcseq, 0)
                    AND NVL(a.cgb, 0) = NVL(src.cgb, 0)
                    AND NVL(a.amt, 0) = NVL(src.amt, 0)
                    AND NVL(a.calcamt, 0) = NVL(src.calcamt, 0)
                    AND NVL(a.beamt, 0) = NVL(src.beamt, 0)
                    AND NVL(a.becalcamt, 0) = NVL(src.becalcamt, 0))
        WHEN MATCHED
        THEN
            UPDATE SET A.lrdiv = 'L';

        MERGE INTO VGT.TT_ACACC0210R_ACC210A A
        USING	   (SELECT b.amt3 - amt2 AS calcamt,
                           b.beamt3 - beamt2 AS becalcamt,
                           A.LRDIV,
                           A.PRTDIV,
                           A.CALCDIV,
                           A.OBJDATADIV,
                           A.SEQLINE,
                           A.ACCCODE,
                           A.SSEQLINE,
                           A.CSEQLINE,
                           A.ACCRNAME,
                           A.ACCKNAME,
                           A.PRTYN,
                           A.PRTBOLD,
                           A.CALCSEQ,
                           A.AMT,
                           A.BEAMT
                    FROM   VGT.TT_ACACC0210R_ACC210A A
                           JOIN (SELECT seqline,
                                        amt2,
                                        amt3,
                                        beamt2,
                                        A.beamt3
                                 FROM	VGT.TT_ACACC0210R_ACC210B A
                                 WHERE	A.num = 1) b
                               ON A.seqline = b.seqline) src
        ON		   (NVL(a.lrdiv, ' ') = NVL(src.lrdiv, ' ')
                    AND NVL(a.prtdiv, ' ') = NVL(src.prtdiv, ' ')
                    AND NVL(a.calcdiv, ' ') = NVL(src.calcdiv, ' ')
                    AND NVL(a.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
                    AND NVL(a.seqline, ' ') = NVL(src.seqline, ' ')
                    AND NVL(a.acccode, ' ') = NVL(src.acccode, ' ')
                    AND NVL(a.sseqline, ' ') = NVL(src.sseqline, ' ')
                    AND NVL(a.cseqline, ' ') = NVL(src.cseqline, ' ')
                    AND NVL(a.accrname, ' ') = NVL(src.accrname, ' ')
                    AND NVL(a.acckname, ' ') = NVL(src.acckname, ' ')
                    AND NVL(a.prtyn, ' ') = NVL(src.prtyn, ' ')
                    AND NVL(a.prtbold, ' ') = NVL(src.prtbold, ' ')
                    AND NVL(a.calcseq, 0) = NVL(src.calcseq, 0)
                    AND NVL(a.amt, 0) = NVL(src.amt, 0)
                    AND NVL(a.beamt, 0) = NVL(src.beamt, 0))
        WHEN MATCHED
        THEN
            UPDATE SET A.calcamt = src.calcamt, A.becalcamt = src.becalcamt, A.cgb = '2';


        --최종조회
        IF (p_div = 'P') THEN

            OPEN IO_CURSOR FOR

                SELECT NULLIF(CASE WHEN A.lrdiv = 'L' AND A.prtyn = 'Y' THEN A.amt END, 0) baldramt,
                       NULLIF(CASE WHEN A.cgb = '2' AND A.prtyn = 'Y' THEN A.calcamt
                                   WHEN A.cgb <> '2' AND A.lrdiv = 'R' AND A.prtyn = 'Y' THEN A.amt END, 0) dramt,
                       NULL mondramt,
                       CASE WHEN A.amt >= 0 THEN A.accrname ELSE A.acckname END accname,
                       NULL moncramt,
                       NULLIF(CASE WHEN A.lrdiv = 'L' AND A.prtyn = 'Y'
                                   THEN A.beamt END, 0) cramt,
                       NULLIF(CASE WHEN A.cgb = '2' AND A.prtyn = 'Y' THEN A.becalcamt
                                   WHEN A.cgb <> '2' AND A.lrdiv = 'R' AND A.prtyn = 'Y' THEN A.beamt
                              END, 0) balcramt,
                       A.prtbold,
                       D.session1 || SUBSTR(p_basisym, 0, 4) || '년  ' || SUBSTR(p_basisym, 6, 2) || '월  ' || SUBSTR(TO_CHAR(LAST_DAY(TO_DATE(p_basisym, 'YYYY-MM')), 'YYYY-MM-DD'), -2, 2) || '일  현재' title1,
                       D.session2 || SUBSTR(p_beyymm, 0, 4) || '년  ' || SUBSTR(p_beyymm, 6, 2) || '월  ' || SUBSTR(TO_CHAR(LAST_DAY(TO_DATE(p_beyymm, 'YYYY-MM')), 'YYYY-MM-DD'), -2, 2) || '일  현재' title2,
                       CASE WHEN p_plantcode = '%' THEN '회사명 : ' || b.compname
                            ELSE '사업장명 : ' || NVL(NULLIF(c.plantfullname, NULL), c.plantname)
                       END compname,
                       '(단위 : 원)' prtunit,
                       NULL baldramt2,
                       NULL dramt2,
                       NULL mondramt2,
                       NULL accname2,
                       NULL moncramt2,
                       NULL cramt2,
                       NULL balcramt2
                FROM   VGT.TT_ACACC0210R_ACC210A A
                       LEFT JOIN CMCOMPM b ON b.compcode = p_compcode
                       LEFT JOIN CMPLANTM c ON c.plantcode = p_plantcode
                       LEFT JOIN (SELECT MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_basisym, 0, 4) THEN sseq END) || '기  ') session1,
                                          MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_beyymm, 0, 4) THEN sseq END) || '기  ') session2
                                  FROM     ACSESSION
                                  WHERE  compcode = p_compcode
                                         AND cyear IN (SUBSTR(p_basisym, 0, 4), SUBSTR(p_beyymm, 0, 4))) D
                           ON 1 = 1
                WHERE  A.prtdiv <> 'C'
                       AND (A.amt <> 0
                            OR A.calcamt <> 0
                            OR A.beamt <> 0
                            OR A.becalcamt <> 0
                            OR A.prtdiv = 'A')
                ORDER BY seqline;


        ELSIF (p_viewyn = 'Y') THEN

            OPEN IO_CURSOR FOR

                SELECT CASE WHEN amt >= 0 THEN accrname ELSE acckname END accname,
                       NULLIF(CASE WHEN lrdiv = 'L' AND prtyn = 'Y' THEN amt END, 0) amt1,

                       NULLIF(CASE WHEN cgb = '2' AND prtyn = 'Y' THEN calcamt
                                   WHEN cgb <> '2' AND lrdiv = 'R' AND prtyn = 'Y' THEN amt END, 0) amt2,

                       NULLIF(CASE WHEN lrdiv = 'L' AND prtyn = 'Y' THEN beamt END, 0) amt3,

                       NULLIF(CASE WHEN cgb = '2' AND prtyn = 'Y' THEN becalcamt
                                   WHEN cgb <> '2' AND lrdiv = 'R' AND prtyn = 'Y' THEN beamt END, 0) amt4,

                       p_plantcode plantcode,
                       p_yyyy01 || '-01' strdate,
                       TO_CHAR(LAST_DAY(TO_DATE(p_basisym, 'YYYY-MM')), 'YYYY-MM-DD') enddate,
                       acccode,
                       p_closediv closediv,
                       prtbold

                FROM   VGT.TT_ACACC0210R_ACC210A
                WHERE  prtdiv <> 'C'
                       AND ( amt <> 0 OR calcamt <> 0 OR beamt <> 0 OR becalcamt <> 0 OR prtdiv = 'A' )
                ORDER BY seqline;

        END IF;


        FOR rec IN (SELECT TO_CHAR(TRUNC(NVL(amt, 0))) || ';' || TO_CHAR(TRUNC(NVL(beamt, 0))) AS alias1
                    FROM   VGT.TT_ACACC0210R_ACC210A
                    WHERE  seqline = (SELECT MAX(seqline) FROM VGT.TT_ACACC0210R_ACC210A))
        LOOP
            MESSAGE := rec.alias1;
        END LOOP;



    ELSIF (p_div = 'Y') THEN

        OPEN IO_CURSOR FOR

            SELECT *
            FROM   (SELECT   CASE WHEN cyear = SUBSTR(p_basisym, 0, 4) THEN sseq
                                  ELSE sseq - TO_NUMBER(cyear) + TO_NUMBER(SUBSTR(p_basisym, 0, 4))
                             END sseq
                    FROM     ACSESSION
                    WHERE    compcode = p_compcode
                             AND cyear <= SUBSTR(p_basisym, 0, 4)
                    ORDER BY cyear DESC)
            WHERE  ROWNUM <= 1;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
