CREATE PROCEDURE        spACacc0900SP1
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0900SP1
 -- 작 성 자         : 최용석
 -- 작성일자         : 2011-12-13
 -- 수 정 자         : 임 정호
 -- 작성일자         : 2016-12-19
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 매출전표로드
 -- ---------------------------------------------------------------

(
  p_div IN VARCHAR2 DEFAULT '' ,
  p_compcode IN VARCHAR2 DEFAULT '' ,
  p_plantcode IN VARCHAR2 DEFAULT '' ,
  p_sdt IN VARCHAR2 DEFAULT '' ,
  p_edt IN VARCHAR2 DEFAULT '' ,
  p_loadstatus IN VARCHAR2 DEFAULT '' ,
  p_custcode IN VARCHAR2 DEFAULT '' ,
  p_taxno IN VARCHAR2 DEFAULT '' ,
  p_iempcode IN VARCHAR2 DEFAULT '' ,
  p_userid IN VARCHAR2 DEFAULT '' ,
  p_reasondiv IN VARCHAR2 DEFAULT '' ,
  p_reasontext IN VARCHAR2 DEFAULT '' ,
  IO_CURSOR      OUT TYPES.DataSet,
  message OUT VARCHAR2

)
AS
    v_temp NUMBER(1, 0) := 0;
    ip_taxno VARCHAR2(20) :=p_taxno;
    p_setplant VARCHAR2(4);
    p_crtdate VARCHAR2(8);
    p_crttime VARCHAR2(8);
    p_crtseq NUMBER(10,0);
    p_crttyp VARCHAR2(8);
    p_orderno VARCHAR2(20);
    p_orderseq NUMBER(10,0);
    p_deptcode VARCHAR2(20);
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';
    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    SELECT COUNT(*) INTO v_temp
    FROM DUAL
    WHERE EXISTS (
                    SELECT  *
                    FROM    CMCLOSEM
                    WHERE   compcode = p_compcode
                        AND closeym BETWEEN SUBSTR(p_sdt, 0, 7) AND SUBSTR(p_edt, 0, 7)
                        AND accdiv = 'S'
                        AND apprcloseyn = 'Y'
                );

    IF v_temp = 1 THEN

        IF (IO_CURSOR IS NULL) THEN
          OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
        END IF;

        RETURN;
    END IF;


    IF ( p_div = 'S' OR p_div = 'loadall' ) THEN
        FOR  rec IN
        (
            SELECT  fnGetColDeptCode(deptcode) AS deptcode
            FROM    CMEMPM
            WHERE   empcode = p_iempcode
        )
        LOOP
            p_deptcode := rec.deptcode;
        END LOOP;

        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0900SP_DUAL';
        INSERT INTO VGT.TT_ACACC0900SP_DUAL
        ( SELECT p_compcode compcode  ,
                 'N' chk  ,
                 SUBSTR(b.taxdt, 1, 7) yymm ,-- 처리월
                 A.plantcode ,-- 사업장
                 b.taxdt appdate ,-- 세금계산서 일자
                 b.taxno taxno ,-- 세금계산서 번호
                 CASE
                      WHEN b.taxcode = '3' THEN '102' -- 매출-영세	계산서구분 AC60

                      WHEN b.taxcode = '4' THEN '104' -- 매출-수출
                 ELSE '101'
                    END taxdiv ,-- 매출-과세
                 '02' iotaxdiv ,-- 매입매출구분 AC61
                 b.ordernm ordno ,-- 주문번호
                 b.custcode custcode ,-- 거래처코드
                 NVL(c.custname, '') custname ,-- 거래처명
                 b.businessno businessno ,-- 사업자번호
                 NVL(b.ceoname, '') ceoname ,-- 거래처ceo
                 NVL(b.telno, '') telno ,-- 전화번호
                 NVL(b.post, '') post ,-- 우편번호
                 NVL(b.addr1, '') addr1 ,-- 주소1
                 NVL(b.addr2, '') addr2 ,-- 주소2
                 NVL(b.addr, '') addr ,-- 주소
                 NVL(E.deptcode, '') deptcode ,-- 부서코드
                 NVL(D.deptname, '') deptname ,-- 부서명
                 NVL(E.empcode, '') empcode ,-- 사원
                 NVL(E.empname, '') empname ,-- 사원명
                 b.itemnm itemnm ,-- 제품명
                 A.amt1 salamt1 ,-- 제품공급가액/매출할인
                 A.amt2 salamt2 ,-- 상품공급가액
                 A.amt1 + A.amt2 salamt ,-- 공급가액
                 A.vat salvat ,-- 부가세액
                 A.totamt totamt ,-- 합계금액
                 b.loadyn loadyn ,-- 전자세금계산서
                 '1' actrnstate ,-- 로드상태코드 1신규, 2완료 3수정, 4삭제
                 CASE
                      WHEN b.taxcode = '3' THEN 'S01003' -- 로컬수출
                      WHEN b.taxcode = '4' THEN 'S01004' -- 직수출
                      WHEN b.saldiv = 'M' THEN 'S01002' -- 매출할인
                      WHEN b.biznodiv <> '01' THEN 'S01005' -- 사원판매
                 ELSE 'S01001'
                    END autorulecode ,-- 일반매출
                 '신규로드전송전' acctrnchk ,-- 로드상태
                 '' slipinno ,-- 전표번호
                 'N' taxloadyn ,-- 계산서생성여부
                 '전송 필요' taxloadtatus ,-- 계산서생성여부명
                 'N' newchk -- 신규생성여부
          FROM ( SELECT A.plantcode ,
                        A.taxno,
                        sum(c.salamt) as amt,
                        SUM(CASE
                                 WHEN NVL(e.filter1, '05') <> '05' THEN NVL(c.salamt, 0)
                            ELSE 0
                               END)  amt1  ,
                        SUM(CASE
                                 WHEN NVL(e.filter1, '05') = '05' THEN NVL(c.salamt, 0)
                            ELSE 0
                               END)  amt2  ,
                        sum(c.salvat)  vat  ,
                        sum(c.salamt) + sum(c.salvat) as totamt
                 FROM   SLTAXM A
                        LEFT JOIN SLORDM b
                            ON a.taxno = b.taxmanagedate
                        LEFT JOIN SLORDD c
                            ON b.plantcode = c.plantcode
                            AND b.orderno = c.orderno
                        LEFT JOIN CMITEMM d
                            ON c.itemcode = d.itemcode
                        LEFT JOIN CMCOMMONM e
                            ON e.cmmcode = 'CMM01'
                                AND d.itemdiv = e.divcode
                  WHERE  A.plantcode LIKE p_plantcode
                    AND  A.taxdt BETWEEN p_sdt AND p_edt
                    GROUP BY A.plantcode,A.taxno
                ) A
                JOIN SLTAXM b
                    ON A.plantcode = b.plantcode
                       AND A.taxno = b.taxno
                LEFT JOIN CMCUSTM c   ON b.custcode = c.custcode
                LEFT JOIN CMEMPM E   ON E.empcode = p_iempcode
                LEFT JOIN CMDEPTM D   ON D.deptcode = E.deptcode
          WHERE  NVL(fnGetColDeptCode(E.deptcode),' ') = NVL(p_deptcode,' ') );

        -- 전송완료상태 데이터 확인
        MERGE INTO VGT.TT_ACACC0900SP_DUAL TG
            USING (
                    SELECT  A.COMPCODE, A.APPDATE, A.TAXNO,
                            CASE
                                WHEN b.actrnstate = '1' OR TRIM(b.slipinno) IS NULL THEN '로드완료전표처리전'
                                WHEN TRIM(b.slipinno) IS NOT NULL AND b.slipinno = c.slipinno THEN '회계처리완료'
                                WHEN TRIM(b.slipinno) IS NOT NULL AND TRIM(c.slipinno) IS NULL THEN '신규:회계전표삭제재전송'
                                ELSE '회계처리완료'
                            END AS pos_2,
                            CASE WHEN b.actrnstate = '1' OR TRIM(b.slipinno)IS NULL THEN '2'
                                 WHEN TRIM(b.slipinno) IS NOT NULL AND b.slipinno = c.slipinno THEN '2'
                                 WHEN TRIM(b.slipinno) IS NOT NULL AND TRIM(c.slipinno) IS NULL THEN '3'
                                 ELSE '2'
                            END AS pos_3,
                            TRIM(b.slipinno) AS pos_4,
                            CASE WHEN TRIM(b.slipinno) IS NOT NULL AND TRIM(c.slipinno) IS NULL  THEN 'Y'
                                 ELSE 'N'
                            END AS pos_5
                    FROM    VGT.TT_ACACC0900SP_DUAL A
                        JOIN ACAUTOORDT b -- 기존자료
                            ON      A.compcode = b.compcode
                                AND b.acattype = 'S'
                                AND A.appdate = b.slipindate
                                AND A.taxno = b.acatno
                        LEFT JOIN ACORDM c -- 회계전표
                            ON      b.compcode = c.compcode
                                AND b.slipinno = c.slipinno ) SRC
                ON (TG.COMPCODE=SRC.COMPCODE AND TG.APPDATE=SRC.APPDATE AND TG.TAXNO=SRC.TAXNO)
        WHEN MATCHED THEN UPDATE
                SET TG.ACCTRNCHK    = POS_2,
                    TG.ACTRNSTATE   = POS_3,
                    TG.SLIPINNO     = POS_4,
                    TG.NEWCHK       = POS_5;

        -- 수정 데이터 확인
        MERGE INTO VGT.TT_ACACC0900SP_DUAL TG
        USING (
                SELECT  A.COMPCODE,  A.APPDATE ,A.TAXNO,
                        '3',
                        'N',
                        CASE
                            WHEN TRIM(B.SLIPINNO) IS NOT NULL AND TRIM(C.SLIPINNO) IS NULL  THEN '수정:회계전표삭제재전송'
                            ELSE '수정전송필요'
                        END AS POS_4,
                        TRIM (B.SLIPINNO) AS POS_5
                FROM    VGT.TT_ACACC0900SP_DUAL A
                        JOIN    ACAUTOORDT B -- 기존자료
                            ON      A.COMPCODE = B.COMPCODE
                                AND B.ACATTYPE = 'S'
                                AND A.APPDATE = B.SLIPINDATE
                                AND A.TAXNO = B.ACATNO
                        LEFT JOIN ACORDM C -- 회계전표
                            ON      B.COMPCODE = C.COMPCODE
                                AND B.SLIPINNO = C.SLIPINNO
                WHERE   A.PLANTCODE <> B.PLANTCODE
                            OR A.AUTORULECODE <> B.ACATRULECODE
                            OR A.CUSTCODE <> B.CUSTCODE
                            OR A.SALAMT1 <> B.TRN1AMT
                            OR A.SALAMT2 <> B.TRN2AMT
                            OR A.SALVAT <> B.TRN3AMT
                            OR A.TOTAMT <> B.TRN4AMT) SRC
                ON ( TG.COMPCODE=SRC.COMPCODE AND TG.APPDATE=SRC.APPDATE AND TG.TAXNO=SRC.TAXNO )
        WHEN MATCHED THEN UPDATE
        SET TG.ACTRNSTATE = '3',
            TG.CHK = 'N',
            TG.ACCTRNCHK = POS_4,
            TG.SLIPINNO = POS_5;

      -- 삭제 상태 확인
        INSERT INTO VGT.TT_ACACC0900SP_DUAL
        (
            SELECT  p_compcode compcode  ,
                    'N' chk  ,
                    SUBSTR(A.slipindate, 0, 4) yymm  ,
                    A.plantcode ,
                    A.slipindate appdate  ,
                    A.taxno taxno  ,
                    CASE
                        WHEN A.acatrulecode = 'S01003' THEN '102'
                        WHEN A.acatrulecode = 'S01004' THEN '104'
                        ELSE '101'
                    END taxdiv  ,
                    '02' iotaxdiv  ,
                    '삭제됨' ordno  ,
                    NVL(A.custcode, '') custcode  ,
                    NVL(A.userdef6code, '') custname  ,
                    c.businessno businessno  ,
                    c.ceoname ceoname  ,
                    c.telno telno  ,
                    c.post post  ,
                    c.addr1 addr1  ,
                    c.addr2 addr2  ,
                    c.addre addr  ,
                    NVL(A.deptcode, '') deptcode  ,
                    NVL(A.userdef4code, '') deptname  ,
                    NVL(A.empcode, '') empcode  ,
                    NVL(A.userdef5code, '') empname  ,
                    A.remark itemnm  ,
                    A.trn1amt salamt1  ,
                    A.trn2amt salamt2  ,
                    A.trn1amt + A.trn2amt salamt  ,
                    A.trn3amt salvat  ,
                    A.trn4amt totamt  ,
                    '' loadyn  ,
                    '4' actrnstate  ,
                    A.acatrulecode ,
                    '삭제전송필요' acctrnchk  ,
                    A.slipinno slipinno  ,
                    'N' taxloadyn  ,
                    '' taxloadtatus  ,
                    'N' newchk
            FROM    ACAUTOORDT A
                    LEFT JOIN VGT.TT_ACACC0900SP_DUAL b
                        ON      A.compcode = b.compcode
                            AND A.slipindate = b.appdate
                            AND A.acatno = b.taxno
                    LEFT JOIN CMCUSTM c
                        ON A.custcode = c.custcode
            WHERE   A.compcode = p_compcode
                AND A.acattype = 'S'
                AND A.slipindate BETWEEN p_sdt AND p_edt
                AND b.taxno IS NULL
                AND NVL(fnGetColDeptCode(A.deptcode),' ') = NVL(p_deptcode, ' ') );


        IF ( p_loadstatus = '1' OR p_loadstatus = '2' OR p_loadstatus = '3' ) THEN
       --로드 상태를 선택
            DELETE FROM  VGT.TT_ACACC0900SP_DUAL
            WHERE   ACTRNSTATE NOT IN  (
                                            SELECT  FILTER1
                                            FROM    CMCOMMONM
                                            WHERE   CMMCODE = 'AC082'
                                                AND DIVCODE = P_LOADSTATUS
                                            UNION ALL
                                            SELECT  FILTER2
                                            FROM    CMCOMMONM
                                            WHERE   CMMCODE = 'AC082'
                                                AND DIVCODE = P_LOADSTATUS
                                        );

        END IF;

        IF ( p_plantcode <> '%' ) THEN
            DELETE  FROM VGT.TT_ACACC0900SP_DUAL
            WHERE   plantcode <> p_plantcode;
        END IF;

        IF ( TRIM(p_custcode) IS NOT NULL ) THEN
          DELETE FROM VGT.TT_ACACC0900SP_DUAL
          WHERE custcode <> p_custcode;
        END IF;

        --세금계산서 작업 확인
        MERGE INTO VGT.TT_ACACC0900SP_DUAL TG
        USING (
                SELECT  A.compcode , A.plantcode, A.taxno,
                        CASE
                            WHEN (TRIM(A.taxno) IS NOT NULL  AND TRIM(b.taxno) IS NULL ) OR (A.custcode <> b.custcode) OR (A.salamt <> b.amt) OR (A.salvat <> b.vat) THEN 'N'
                            ELSE 'Y'
                        END AS pos_2,   CASE  WHEN TRIM(A.taxno) IS NOT NULL  AND TRIM(b.taxno) IS NULL THEN '전송 필요'
                                              WHEN A.custcode <> b.custcode OR A.salamt <> b.amt OR A.salvat <> b.vat THEN '재전송 필요'
                                              ELSE '전송 완료'
                                        END AS pos_3
                FROM    VGT.TT_ACACC0900SP_DUAL A
                        LEFT JOIN ACTAXM b
                            ON      A.compcode = b.compcode
                                AND A.plantcode = b.plantcode
                                AND A.taxno = b.taxno ) src
            ON ( TG.COMPCODE=SRC.COMpCODE AND TG.PLANTCODE=SRC.PLANTCODE AND TG.TAXNO=SRC.TAXNO )
        WHEN MATCHED THEN
        UPDATE SET  TG.TAXLOADYN     = POS_2,
                    TG.TAXLOADTATUS  = POS_3;


        IF ( p_div = 'S' ) THEN

            OPEN  IO_CURSOR FOR
            SELECT  A.* ,
                    NVL(b.slipdate, '') accslipdate  ,
                    NVL(b.slipnum, '') accslipnum
            FROM    VGT.TT_ACACC0900SP_DUAL A
                    LEFT JOIN ACORDM b
                        ON      b.compcode = A.compcode
                            AND b.slipinno = A.slipinno
            ORDER BY A.compcode, A.plantcode, A.taxno ;

        ELSIF ( p_div = 'loadall' ) THEN

                -- 신규 작업
            INSERT INTO ACAUTOORDT
                                    ( compcode --회사코드
                                        , acattype --전표유형(S)
                                        , acatno --전표번호
                                        , acatrulecode --분개률코드
                                        , actrnstate --실행상태
                                        , slipindate --발의일자(세금계산서일자)
                                        , deptcode --영업부서
                                        , plantcode --사업장
                                        , empcode --영업사원
                                        , remark --비고
                                        , remark2 --비고2
                                        , custcode --거래처
                                        , taxno --세금계산서번호
                                        , trn1amt --제품공급가액/매출할인
                                        , trn2amt --상품공급가액
                                        , trn3amt --부가세
                                        , trn4amt --합계액
                                        , userdef4code --부서명
                                        , userdef5code --발의사원명
                                        , userdef6code --거래처명
                                        , insertdt --입력일자
                                        , iempcode --입력사원
                                    )
                            ( SELECT    compcode ,--회사
                                        'S' ,--전표유형
                                        taxno ,--세금계산서번호
                                        autorulecode ,--분개률코드
                                        actrnstate ,--실행상태
                                        appdate ,--발의일자(세금계산서일자)
                                        deptcode ,--영업부서
                                        plantcode ,--사업장
                                        empcode ,--영업사원
                                        itemnm ,--비고
                                        '' ,--비고2
                                        custcode ,--거래처
                                        taxno ,--세금계산서번호
                                        salamt1 ,--제품공급가액/매출할인
                                        salamt2 ,--상품공급가액
                                        salvat ,--부가세
                                        totamt ,--합계액
                                        deptname ,--부서명
                                        empname ,--발의사원명
                                        custname ,--거래처명
                                        SYSDATE , --입력일자
                                        p_iempcode --입력사원
                                FROM    VGT.TT_ACACC0900SP_DUAL
                                WHERE   actrnstate = '1' );
                -- 신규 세금계산서 작업
            DELETE FROM ACTAXD
            WHERE (COMPCODE,PLANTCODE,TAXNO,SEQ) IN  (
                                                        SELECT  B.COMPCODE, B.PLANTCODE, B.TAXNO, B.SEQ
                                                        FROM    VGT.TT_ACACC0900SP_DUAL A
                                                                JOIN ACTAXD b   ON A.taxno = b.taxno
                                                        WHERE    A.taxloadyn = 'N'
                                                     );
            DELETE FROM ACTAXM
            WHERE (COMPCODE,PLANTCODE,TAXNO) IN
                                                    (
                                                        SELECT  B.COMPCODE,B.PLANTCODE,B.TAXNO
                                                        FROM    VGT.TT_ACACC0900SP_DUAL A
                                                                JOIN ACTAXM b   ON A.taxno = b.taxno
                                                        WHERE   A.taxloadyn = 'N'
                                                    );
            INSERT INTO ACTAXM
                                (   compcode, plantcode, taxno, taxdiv --계산서 구분(  select * from cmcommonm where cmmcode = 'AC60'  )
                                  , iotaxdiv --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
                                  , sdeptcode, taxdate, custcode, custname, businessno, biznotype --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
                                  , blankcnt, amt, vat, vatamt, purposediv --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
                                  , credittot, electaxyn --전자세금계산서여부
                                  , saleinyn --영업자동생성여부
                                  , insertdt, iempcode, updatedt, uempcode )
                        ( SELECT    compcode ,
                                    plantcode ,
                                    taxno ,
                                    taxdiv ,
                                    '02' ,
                                    deptcode ,
                                    appdate ,
                                    custcode ,
                                    custname ,
                                    businessno ,
                                    CASE
                                        WHEN autorulecode = 'S01005' THEN '02'
                                    ELSE '01'
                                      END col  ,
                                    0 ,
                                    salamt ,
                                    salvat ,
                                    totamt ,
                                    '02' ,
                                    totamt ,
                                    loadyn ,
                                    'Y' ,
                                    SYSDATE ,
                                    p_iempcode ,
                                    SYSDATE ,
                                    p_iempcode
                            FROM    VGT.TT_ACACC0900SP_DUAL
                            WHERE   taxloadyn = 'N' );

            INSERT INTO ACTAXD
                                (   compcode,   plantcode,  taxno,      seq,        itemnm,
                                    gyugeok,    qty,        prc,        amt,        vat,        vatamt,
                                    remark,     insertdt,   iempcode,   updatedt,   uempcode            )
                    ( SELECT        p_compcode ,
                                    plantcode ,
                                    taxno ,
                                    1 ,
                                    itemnm ,
                                    NULL ,
                                    0 ,
                                    0 ,
                                    salamt ,
                                    salvat ,
                                    totamt ,
                                    NULL ,
                                    SYSDATE ,
                                    p_iempcode ,
                                    SYSDATE ,
                                    p_iempcode
                        FROM        VGT.TT_ACACC0900SP_DUAL
                        WHERE       taxloadyn = 'N' );
                -- 수정,삭제 처리전에 메타에 있는 내용을 이력테이블에 저장한다.ACAUTOORDH
            INSERT INTO ACAUTOORDH
                    (       SELECT  b.*
                            FROM    VGT.TT_ACACC0900SP_DUAL A
                                    LEFT JOIN ACAUTOORDT b
                                        ON      A.compcode = b.compcode
                                            AND b.acattype = 'S'
                                            AND A.taxno = b.acatno
                            WHERE   A.actrnstate IN ( '3','4' ) OR A.newchk = 'Y' );
                --메타 테이블 저장
            MERGE INTO ACAUTOORDT TG
            USING   (
                        SELECT  B.COMPCODE, B.ACATTYPE, B.ACATNO,
                                A.autorulecode,
                                CASE
                                    WHEN b.actrnstate = '1' THEN b.actrnstate
                                    ELSE A.actrnstate
                                END AS pos_3,
                                A.appdate,
                                A.deptcode,
                                A.plantcode,
                                A.empcode,
                                NULL AS pos_8,
                                NULL AS pos_9,
                                A.custcode,
                                A.taxno,
                                A.salamt1,
                                A.salamt2,
                                A.salvat,
                                A.totamt,
                                A.deptname,
                                A.empname,
                                A.custname,
                                SYSDATE,
                                p_iempcode AS IEMPCODE
                        FROM    VGT.TT_ACACC0900SP_DUAL  A
                                LEFT JOIN ACAUTOORDT b
                                    ON      b.compcode = p_compcode
                                        AND b.acattype = 'S'
                                        AND b.acatno = A.taxno
                        WHERE   A.actrnstate IN ( '3','4' )
                    ) src
                ON ( TG.COMPCODE=SRC.COMPCODE AND TG.ACATTYPE=SRC.ACATTYPE AND TG.ACATNO=SRC.ACATNO)
            WHEN MATCHED THEN
                UPDATE SET  TG.ACATRULECODE = SRC.AUTORULECODE,
                            TG.ACTRNSTATE = POS_3,
                            TG.SLIPINDATE = SRC.APPDATE,
                            TG.DEPTCODE = SRC.DEPTCODE,
                            TG.PLANTCODE = SRC.PLANTCODE,
                            TG.EMPCODE = SRC.EMPCODE,
                            TG.REMARK = POS_8,
                            TG.REMARK2 = POS_9,
                            TG.CUSTCODE = SRC.CUSTCODE,
                            TG.TAXNO = SRC.TAXNO,
                            TG.TRN1AMT = SRC.SALAMT1,
                            TG.TRN2AMT = SRC.SALAMT2,
                            TG.TRN3AMT = SRC.SALVAT,
                            TG.TRN4AMT = SRC.TOTAMT,
                            TG.USERDEF4CODE = SRC.DEPTNAME,
                            TG.USERDEF5CODE = SRC.EMPNAME,
                            TG.USERDEF6CODE = SRC.CUSTNAME,
                            TG.UPDATEDT = SYSDATE,
                            TG.UEMPCODE = SRC.IEMPCODE;

            MERGE INTO ACTAXM TG
            USING   (
                        SELECT  B.COMPCODE, B.PLANTCODE, B.TAXNO,
                                A.taxdiv, '02', A.deptcode, A.appdate,
                                A.custcode, A.custname, A.businessno,
                                CASE
                                        WHEN A.autorulecode = 'S01005' THEN '02'
                                        ELSE '01'
                                END AS pos_9,

                                A.salamt, A.salvat, A.totamt, A.loadyn,  SYSDATE, p_iempcode AS iempcode
                        FROM    VGT.TT_ACACC0900SP_DUAL A
                                LEFT JOIN ACTAXM b
                                    ON      A.compcode = b.compcode
                                        AND A.plantcode = b.plantcode
                                        AND A.taxno = b.taxno
                        WHERE   A.actrnstate IN ( '3','4' )
                            AND A.taxloadyn = 'Y') src
                ON ( TG.COMPCODE = SRC.COMPCODE AND TG.PLANTCODE=SRC.PLANTCODE AND TG.TAXNO=SRC.TAXNO )
            WHEN MATCHED THEN
                UPDATE SET  TG.TAXDIV       = SRC.TAXDIV,
                            TG.IOTAXDIV     = '02',
                            TG.SDEPTCODE    = SRC.DEPTCODE,
                            TG.TAXDATE      = SRC.APPDATE,
                            TG.CUSTCODE     = SRC.CUSTCODE,
                            TG.CUSTNAME     = SRC.CUSTNAME,
                            TG.BUSINESSNO   = SRC.BUSINESSNO,
                            TG.BIZNOTYPE    = SRC.POS_9,
                            TG.BLANKCNT     = 0,
                            TG.AMT          = SRC.SALAMT,
                            TG.VAT          = SRC.SALVAT,
                            TG.VATAMT       = SRC.TOTAMT,
                            TG.PURPOSEDIV   = '02',
                            TG.ELECTAXYN    = SRC.LOADYN,
                            TG.SALEINYN     = 'Y',
                            TG.UPDATEDT     = SYSDATE,
                            TG.UEMPCODE     = src.IEMPCODE;

            MERGE INTO ACTAXD TG
            USING (
                        SELECT  B.COMPCODE, B.PLANTCODE, B.TAXNO,B.SEQ,
                                A.itemnm, NULL AS pos_3,  A.salamt, A.salvat, A.totamt, NULL AS pos_9, SYSDATE
                        FROM    VGT.TT_ACACC0900SP_DUAL A
                                LEFT JOIN ACTAXD b
                                    ON      A.compcode = b.compcode
                                        AND A.plantcode = b.plantcode
                                        AND A.taxno = b.taxno
                                        AND b.seq = 1
                        WHERE A.actrnstate IN ( '3','4' )
                            AND A.taxloadyn = 'Y') src
                ON ( TG.COMPCODE = SRC.COMPCODE AND TG.PLANTCODE=SRC.PLANTCODE AND TG.TAXNO=SRC.TAXNO AND TG.SEQ=SRC.SEQ )
            WHEN MATCHED THEN
                UPDATE SET   TG.itemnm = src.itemnm,
                             TG.gyugeok = pos_3,
                             TG.qty = 0,
                             TG.prc = 0,
                             TG.amt = src.salamt,
                             TG.vat = src.salvat,
                             TG.vatamt = src.totamt,
                             TG.remark = pos_9,
                             TG.updatedt = SYSDATE,
                             TG.uempcode = p_iempcode;

            DELETE FROM ACTAXD
            WHERE  ( COMPCODE,PLANTCODE, TAXNO,SEQ ) IN
                                                        (   SELECT  B.COMPCODE, B.PLANTCODE, B.TAXNO,B.SEQ
                                                            FROM    VGT.TT_ACACC0900SP_DUAL A
                                                                    LEFT JOIN ACTAXD b
                                                                        ON      A.compcode = b.compcode
                                                                            AND A.plantcode = b.plantcode
                                                                            AND A.taxno = b.taxno
                                                            WHERE   A.actrnstate = '4'
                                                                AND A.taxloadyn = 'Y' );
            DELETE FROM ACTAXM
            WHERE   (COMPCODE,PLANTCODE, TAXNO) IN  (
                                                        SELECT  B.COMPCODE,B.PLANTCODE, B.TAXNO
                                                        FROM    VGT.TT_ACACC0900SP_DUAL A
                                                                LEFT JOIN ACTAXM b
                                                                    ON      A.compcode = b.compcode
                                                                        AND A.plantcode = b.plantcode
                                                                        AND A.taxno = b.taxno
                                                        WHERE  A.actrnstate = '4'
                                                        AND A.taxloadyn = 'Y' );

        END IF;

    ELSIF ( p_div = 'taxdtl' ) THEN

       --영업 회계로드에서 세금계산서별 상세 매출 내역 확인

        OPEN  IO_CURSOR FOR
        SELECT  A.taxno taxno  ,
                FNstuff(FNstuff(SUBSTR(c.orderno, 0, 8), 5, 0, '-'), 8, 0, '-') orderdate  ,
                c.orderno orderno  ,
                c.orderseq orderseq  ,
                c.itemcode itemcode  ,
                d.itemname itemname  ,
                c.salqty salqty  ,
                c.salprc salprc  ,
                c.salamt salamt  ,
                CASE
                    WHEN NVL(e.filter1, '05') <> '05' THEN c.salamt
                ELSE 0
                  END amt1  ,
                CASE
                    WHEN NVL(e.filter1, '05') = '05' THEN c.salamt
                ELSE 0
                  END amt2  ,
                c.salvat salvat  ,
                c.salamt + c.salvat totamt
        FROM    SLTAXM a
                LEFT JOIN SLORDM b
                    ON a.taxno = b.taxmanagedate
                LEFT JOIN SLORDD c
                    ON b.plantcode = c.plantcode
                    AND b.orderno = c.orderno
                LEFT JOIN CMITEMM d
                    ON c.itemcode = d.itemcode
                LEFT JOIN CMCOMMONM e
                    ON e.cmmcode = 'CMM01'
                    AND d.itemdiv = e.divcode
        WHERE  A.plantcode LIKE p_plantcode
            AND A.taxdt BETWEEN p_sdt AND p_edt
            AND NVL(A.taxno, ' ') = p_taxno 
        ORDER BY  FNstuff(FNstuff(SUBSTR(c.orderno, 0, 8), 5, 0, '-'), 8, 0, '-') , c.orderno, c.orderseq
            ;
    END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
