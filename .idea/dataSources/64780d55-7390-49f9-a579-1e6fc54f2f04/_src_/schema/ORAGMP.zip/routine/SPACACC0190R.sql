CREATE PROCEDURE        spACacc0190R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0190R
 -- 작 성 자         : 최용석
 -- 작성일자         : 2015-08-14
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-12
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 어음발행 리스트 쿼리.
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '%' ,
    p_stddate       IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,

    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    IF ( p_div = 'S' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  b.businessno ,
                    c.bankname ,
                    b.accountno ,
                    CASE WHEN NVL(TRIM(D.custcode), '') IS NOT NULL THEN 'P' ELSE '' END orderdiv  ,
                    a.billamt ,
                    a.expdate ,
                    b.custname ,
                    '발행일자 : ' || p_stddate title

            FROM    ACBILLM a
                    LEFT JOIN CMCUSTM b   ON a.custcode = b.custcode
                    LEFT JOIN CMBANKM c   ON a.paybank = c.bankcode
                    LEFT JOIN ACPURCHASEPAY D   ON a.compcode = D.compcode
                                                   AND a.custcode = D.custcode
                                                   AND a.issdate = D.issdate
            WHERE   a.billcls = '2'
                    AND a.issdate = p_stddate
            ORDER BY a.billamt, a.custcode ;


    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
