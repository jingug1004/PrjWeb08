CREATE FUNCTION fnuseqtycalctext
-- ---------------------------------------------------------------
 -- 함 수 명			: useqtycalctext
 -- 작 성 자         : 이종석
 -- 작성일자         : 2017-10-10
 -- ---------------------------------------------------------------
 -- 함수설명			: 불출지시 사용량계산식 함수
 -- ---------------------------------------------------------------
(
    p_orderqty          IN NUMBER DEFAULT 0       --  기준량
,   p_reviserate        IN NUMBER DEFAULT 0       --  과량비율
,   p_gravityrate       IN NUMBER DEFAULT 0       --  비중
,   p_outqty            IN NUMBER DEFAULT 0       --  사용량
,   p_cjrateA           IN NUMBER DEFAULT 0       --  함량
,   p_usercalcrate      IN NUMBER DEFAULT 0       --  역가함수
,   p_itemunit          IN VARCHAR2 DEFAULT ''
)

RETURN VARCHAR2
AS
    v_useqtycalctext  VARCHAR2(255);
    v_orderqtytext    VARCHAR2(255);
    v_reviseratetext  VARCHAR2(255);
    v_stockqtytext    VARCHAR2(255);  
    v_gravityrate     VARCHAR2(255);
    v_cjratetxt       VARCHAR2(255);
    v_return          VARCHAR2(255);  
    
BEGIN
    
    --  기준량
    v_orderqtytext := CASE WHEN p_reviserate = 1
                           THEN '' 
                           ELSE fnNumericToString(p_orderqty,'S') || p_itemunit
                      END;
                      
    --  함량
    v_cjratetxt    := CASE WHEN p_cjrateA = 0                                                        
                           THEN '' 
                           ELSE ' X (100 / (100 - 함량:' || fnNumericToString(p_cjrateA, 'S') || '%))'
                      END;
                      
    --  역가함수
    v_useqtycalctext := CASE WHEN p_usercalcrate = 0                                                        
                             THEN '' 
                             ELSE '% - 기준:' || fnNumericToString(p_usercalcrate, 'S') || '%)))'
                        END;         
                                     
    
    --  과량                                          
    v_reviseratetext := CASE WHEN p_reviserate = 1
                             THEN '' 
                             ELSE ' X (과량: ' || fnNumericToString(p_reviserate * 100.0,'S') || '% / 100)'
                        END;
    
    --  비중                    
    v_gravityrate    := CASE WHEN p_gravityrate = 1
                             THEN '' 
                             ELSE ' X (비중: ' || fnNumericToString(p_gravityrate * 100.0,'S') || '% / 100)'
                        END;    
                                                                        
    --  불출량                                             
    v_stockqtytext := ' = ' || fnNumericToString(p_outqty,'S') || p_itemunit;
    
    
    v_return :=  v_orderqtytext || v_cjratetxt || v_useqtycalctext || v_reviseratetext || v_gravityrate || v_stockqtytext;
   
    RETURN (v_return);

    EXCEPTION WHEN OTHERS THEN RETURN (v_return);
END;
/
