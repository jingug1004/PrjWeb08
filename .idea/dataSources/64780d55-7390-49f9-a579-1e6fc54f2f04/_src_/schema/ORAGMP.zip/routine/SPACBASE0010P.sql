CREATE PROCEDURE        spACbase0010P
 -- ---------------------------------------------------------------
 -- 프로시저명       : spACbase0010P
 -- 작 성 자         : 홍지은
 -- 작성일자         : 2015-03-23
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : LC코드마스터정보를 관리하는 프로시저이다.
 -- ---------------------------------------------------------------
(
   p_div             IN     VARCHAR2 DEFAULT '',

   p_compcode        IN     VARCHAR2 DEFAULT '',
   p_lccode          IN     VARCHAR2 DEFAULT '',
   p_lcname          IN     VARCHAR2 DEFAULT '',
   p_remark          IN     VARCHAR2 DEFAULT '',
   p_empcode         IN     VARCHAR2 DEFAULT '',

   p_userid          IN     VARCHAR2 DEFAULT '',
   p_reasondiv       IN     VARCHAR2 DEFAULT '',
   p_reasontext      IN     VARCHAR2 DEFAULT '',
   MESSAGE           OUT    VARCHAR2,
   IO_CURSOR         OUT    TYPES.DataSet
)
AS
BEGIN
  MESSAGE := '데이터 확인';
  
  execute immediate 'delete from ATINFO';
  
  insert into ATINFO (userid, reasondiv, reasontext)
  values (p_userid, p_reasondiv, p_reasontext);

  if (p_div = 'S') then
      open IO_CURSOR for
      select   compcode       --사업장코드
              ,lccode					--LC코드
              ,lcname					--LC명
              ,remark					--비고

      from    ACLCM 

      where   compcode = p_compcode
              and lccode like p_lccode || '%'

      order by	compcode, lccode desc;

  elsif (p_div = 'SC') then
      for rec in (
          select  count(lccode) as lccnt
          from    ACLCM
          where   compcode = p_compcode
                  and lccode = p_lccode
      )
      loop
          MESSAGE := rec.lccnt;
      end loop ;

  elsif (p_div = 'I') then
      insert into ACLCM
          (
              compcode
              ,lccode
              ,lcname
              ,remark
              ,insertdt
              ,iempcode
          )
      values
          (
              p_compcode
              ,p_lccode
              ,p_lcname
              ,p_remark
              ,sysdate
              ,p_empcode
          );

  elsif (p_div = 'I') then
      update  ACLCM
      set			lcname = p_lcname
              ,remark = p_remark
              ,updatedt = sysdate
              ,uempcode = p_empcode
      where   compcode = p_compcode
              and lccode = p_lccode;

  elsif (p_div = 'I') then
      delete
      from    ACLCM
      where   compcode = p_compcode
              and lccode = p_lccode;

  end if;

  if (IO_CURSOR is null) then
      open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
  end if;

END;
/
