CREATE FUNCTION        fnSLcustBalance
-- ---------------------------------------------------------------
-- 함 수 명     : [dbo].[fnSLcustBalance]
-- 작 성 자           : 이세민
-- 작성일자           : 2014-06-17
-- ---------------------------------------------------------------
-- 함수설명     : 지정일자기준의 거래처 잔고 정보를
--       계산하여 테이블로 리턴
-- ---------------------------------------------------------------
-- select * from [dbo].[fnSLcustBalance]('1002','2000000190','%','%','2014-08-06',0)
/*

select empcode, deptcode, *
from cmcustm
where custcode = '2000000131'

*/
(
	p_plantcode    IN VARCHAR2,
	p_custcode	   IN VARCHAR2, -- 전체는 '%'
	p_utdiv 	   IN VARCHAR2, -- 전체는 '%'
	p_orderdiv	   IN VARCHAR2, -- 전체는 '%'
	p_orderdate    IN VARCHAR2,
	p_amount	   IN FLOAT
)
    RETURN FN_SLCUSTBALANCE_TABLE
AS
    
    i NUMBER := 1;
    
    --함수내에서 변수 저장용 변수 초기화
    slCustBalanceListRecode FN_SLCUSTBALANCE_TABLE := FN_SLCUSTBALANCE_TABLE(); 
        
    p_startdate VARCHAR2(10); -- 작업일자 당월   1일 '2013-01-01'			   
	p_tomorrow  VARCHAR2(10); -- 작업일자 다음날짜 '2013-01-21'			  
	p_firstdate VARCHAR2(10); -- 작업일자 5년전 당일 '2008-01-20'
	p_yearmonth VARCHAR2(7);  -- 작업일자 당월  '2013-01'			   
	p_magamyymm VARCHAR2(7);
    
    /*---------------------------------------------
    ▼▼▼▼  함수에서 DML 문장을 수행 하지 위한 트랜젝션 옵션 설정  ▼▼▼▼
    ---------------------------------------------*/
    PRAGMA AUTONOMOUS_TRANSACTION;    

BEGIN
	
    p_startdate := SUBSTR(p_orderdate, 0, 7) || '-01' ;
	p_tomorrow  := TO_CHAR(TO_DATE(p_orderdate, 'YYYY-MM-DD') + 1, 'YYYY-MM-DD') ;
	p_firstdate := TO_CHAR(ADD_MONTHS(TO_DATE(p_orderdate, 'YYYY-MM-DD'), -12 * 5), 'YYYY-MM-DD') ;
	p_yearmonth := SUBSTR(p_orderdate, 0, 7);



    EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_FNSLCUSTBALANCE_CUSTLIST';

	-- 대상거래처 목록 ======================================================
	INSERT INTO VGT.TT_FNSLCUSTBALANCE_CUSTLIST (
		 SELECT c.custcode,
				c.plantcode,
				0 balance,
				0 balancebill,
				NULL
		 FROM	CMCUSTM c
		 WHERE	NVL(TRIM(c.plantcode), ' ') LIKE p_plantcode
				AND (p_custcode = '%' OR c.custcode = p_custcode)
				AND (p_utdiv = '%' OR c.utdiv = p_utdiv)
    ) ;

    COMMIT;



	-- 거래처 잔고및 미결어음 ===============================================
	FOR rec IN (
        SELECT  MAX(A.yearmonth) AS alias1
        FROM    SLRESULTM A
                JOIN VGT.TT_FNSLCUSTBALANCE_CUSTLIST c ON A.custcode = c.custcode
                                                          AND A.plantcode = c.plantcode
        WHERE   A.yearmonth < p_yearmonth
    )
	LOOP
		p_magamyymm := rec.alias1;
	END LOOP;



	IF (NVL(TRIM(p_magamyymm), '') IS NULL) THEN
		
        p_magamyymm := '2009-12'; -- 시작일자를 체크하여야 한다.
		
	END IF;



    FOR rec IN (
        SELECT  --UPDATE DATA
                NVL(A.balance, 0)     AS balance,
                NVL(A.pendbillcol, 0) AS pendbillcol,
                A.yearmonth
                --COMPARE DATA
                , A.custcode
                , A.plantcode 
        FROM    (   SELECT  c.custcode,
                            c.plantcode,
                            SUM(A.balance) balance,
                            SUM(A.pendbillcol) pendbillcol,
                            p_magamyymm yearmonth
                    FROM    SLRESULTM A
                            JOIN VGT.TT_FNSLCUSTBALANCE_CUSTLIST c ON A.custcode = c.custcode
                                                                      AND A.plantcode = c.plantcode
                            LEFT JOIN SLTURNCUSTM D ON A.yearmonth = D.yearmonth
                                                       AND A.custcode = D.custcode
                                                       AND A.plantcode = D.plantcode
                            LEFT JOIN CMCUSTM d1    ON A.custcode = d1.custcode
                                                       AND A.plantcode = d1.plantcode
                    WHERE   A.yearmonth = p_magamyymm
                            AND NVL(TRIM(A.orderdiv), ' ') LIKE p_orderdiv
                    GROUP BY c.custcode, c.plantcode ) A
                JOIN VGT.TT_FNSLCUSTBALANCE_CUSTLIST c ON A.custcode = c.custcode
                                                          AND A.plantcode = c.plantcode
        WHERE  1 = 1
    )
    LOOP

        UPDATE  VGT.TT_FNSLCUSTBALANCE_CUSTLIST TG
        SET     TG.balance = rec.balance
                 , TG.pendbillcol = rec.pendbillcol
                 , TG.yearmonth = rec.yearmonth
        WHERE   TG.custcode = rec.custcode 
                AND TG.plantcode = rec.plantcode ;
     
    END LOOP ;    
    



    FOR rec IN (
        SELECT  --UPDATE DATA
                c.balance + NVL(A.maechul, 0)    AS balance,
                c.pendbillcol + NVL(A.bilcol, 0) AS pendbillcol
                --COMPARE DATA
                , A.custcode
                , A.plantcode         
        FROM    (   SELECT  A.custcode,
                            A.plantcode,
                            SUM(A.maechul) maechul,
                            SUM(A.bilcol) bilcol
                    FROM    (   SELECT  c.custcode,
                                        c.plantcode,
                                        (CASE WHEN NVL(TRIM(A.saldiv), ' ') LIKE 'A%' THEN b.totamt 
                                              WHEN NVL(TRIM(A.saldiv), ' ') LIKE 'B%' THEN -b.totamt 
                                              ELSE 0 
                                        END) maechul,
                                        0 bilcol
                                FROM    SLORDM A
                                        JOIN SLORDD b ON A.orderno = b.orderno
                                                         AND A.plantcode = b.plantcode
                                        JOIN VGT.TT_FNSLCUSTBALANCE_CUSTLIST c ON A.custcode = c.custcode
                                                                                  AND A.plantcode = c.plantcode
                                WHERE   A.appdate >= TO_CHAR(ADD_MONTHS(TO_DATE(p_magamyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
                                        AND A.appdate < p_tomorrow
                                        AND NVL(TRIM(A.orderdiv), ' ') LIKE p_orderdiv
                                        AND A.statediv = '09'
                                        AND A.saldiv IN (SELECT divcode FROM SLCONDRESULT)
                                        
                                UNION ALL
                                        
                                SELECT  c.custcode,
                                        c.plantcode,
                                        -A.colamt,
                                        (CASE WHEN (NVL(TRIM(A.expdate), '') IS NULL OR A.coldiv = '38' OR A.coldiv NOT LIKE '3%') THEN 0 
                                              ELSE A.colamt 
                                         END) bilcol
                                FROM    SLCOLM A
                                        JOIN VGT.TT_FNSLCUSTBALANCE_CUSTLIST c ON A.custcode = c.custcode
                                                                                  AND A.plantcode = c.plantcode
                                WHERE   A.appdate >= TO_CHAR(ADD_MONTHS(TO_DATE(p_magamyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
                                        AND A.appdate < p_tomorrow
                                        AND NVL(TRIM(A.orderdiv), ' ') LIKE p_orderdiv
                                        AND A.statediv = '09'

                                UNION ALL

                                SELECT  c.custcode,
                                        c.plantcode,
                                        0 colamt,
                                        -A.colamt bilcol
                                FROM    SLCOLM A
                                        JOIN VGT.TT_FNSLCUSTBALANCE_CUSTLIST c ON A.custcode = c.custcode
                                                                                  AND A.plantcode = c.plantcode
                                WHERE   A.expdate >= TO_CHAR(ADD_MONTHS(TO_DATE(p_magamyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
                                        AND A.expdate < p_tomorrow
                                        AND NVL(TRIM(A.orderdiv), ' ') LIKE p_orderdiv
                                        AND A.statediv = '09'
                                        AND NVL(TRIM(A.coldiv), ' ') LIKE '3%'
                                        AND A.coldiv <> '38' ) A
                    WHERE   1 = 1
                    GROUP BY A.custcode, A.plantcode ) A
            JOIN VGT.TT_FNSLCUSTBALANCE_CUSTLIST c ON A.custcode = c.custcode
                                                      AND A.plantcode = c.plantcode
        WHERE   1 = 1 
    )
    LOOP

        UPDATE  VGT.TT_FNSLCUSTBALANCE_CUSTLIST TG
        SET     TG.balance = rec.balance
                , TG.pendbillcol = rec.pendbillcol
        WHERE   TG.custcode = rec.custcode 
                AND TG.plantcode = rec.plantcode ;

    END LOOP ;




	-- 거래처 회전일 계산
    FOR rec IN (
        SELECT  ts.custcode,
                ts.plantcode,
                ts.balance,
                ts.pendbillcol,
                (ts.balance + ts.pendbillcol) totbalance
        FROM	VGT.TT_FNSLCUSTBALANCE_CUSTLIST ts
    )
    LOOP

        slCustBalanceListRecode.EXTEND;
        slCustBalanceListRecode(i) := FN_SLCUSTBALANCE_VARIABLE( rec.custcode, rec.plantcode, rec.balance, rec.pendbillcol, rec.totbalance );
        i := i+1; 

    END LOOP ; 
    -- ======================================================================

    COMMIT ;
    
    RETURN slCustBalanceListRecode;

END;
/
