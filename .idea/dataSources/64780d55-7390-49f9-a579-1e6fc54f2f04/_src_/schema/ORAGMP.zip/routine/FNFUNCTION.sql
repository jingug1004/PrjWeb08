CREATE FUNCTION        fnFunction
-- ---------------------------------------------------------------
 -- 함 수 명            : fnFunction
 -- 작 성 자         : 조성희
 -- 작성일자         : 2009-02-01
 -- ---------------------------------------------------------------
 -- 함수설명            :    필요자료 가져오기
 --                        salpower : 영업권한 가져오기
 --                        preyymm : 전월가져오기
 -- ---------------------------------------------------------------
 --  select dbo.fnFunction('lastdate', '2009-07-19', '2009-01')

(
  p_gb      IN VARCHAR2 DEFAULT '' ,
  p_string1 IN VARCHAR2 DEFAULT '' ,
  p_string2 IN VARCHAR2 DEFAULT '' 
)
RETURN VARCHAR2
AS
    p_tostring VARCHAR2(20);
    p_iint NUMBER(10,0);

BEGIN
    IF ( UPPER(p_gb) = UPPER('salpower') ) THEN
       
        p_tostring := '' ;
        
        FOR  rec IN 
        ( 
            SELECT  salpower  AS alias1  
            FROM    CMEMPM A
            WHERE   plantcode = p_string1
                    AND empcode = p_string2
        ) 
        
        LOOP
            p_tostring := rec.alias1 ;
        END LOOP;
       

    ELSIF ( UPPER(p_gb) = UPPER('preyy') ) THEN
        
        p_tostring := '' ;
        p_tostring := TO_CHAR(ADD_MONTHS (TO_DATE(p_string1,'yyyy-mm-dd'),-12),'YYYY');
          
    ELSIF ( UPPER(p_gb) = UPPER('preyymm') ) THEN
             
        p_tostring := '' ;
        p_tostring := TO_CHAR(ADD_MONTHS (TO_DATE(p_string1,'yyyy-mm-dd'),-1),'YYYY-MM');
             
    ELSIF ( UPPER(p_gb) = UPPER('preyymmdd') ) THEN
                 
        p_tostring := '' ;
        p_tostring := TO_CHAR(TO_DATE(p_string1,'yyyy-mm-dd') -1,'yyyy-mm-dd');
               
    ELSIF ( p_gb = 'calpreyymm' ) THEN
                                     
        p_tostring := '' ;
        p_iint := (-1) * TO_NUMBER(p_string2) ;
        
        p_tostring := TO_CHAR(ADD_MONTHS (TO_DATE(p_string1,'yyyy-mm-dd'), p_iint),'YYYY') || '-' || 
                      TO_CHAR(ADD_MONTHS (TO_DATE(p_string1,'yyyy-mm-dd'), p_iint),'MM');
                   
    ELSIF ( UPPER(p_gb) = 'LASTDATE' ) THEN
                     
        p_tostring := '' ;
        
        IF ( NVL(TRIM(p_string1), '') IS NULL ) THEN        
            p_tostring := '1900-01-31';            
        ELSE        
            p_tostring := TO_CHAR(LAST_DAY(TO_DATE(p_string1,'YYYY-MM-DD')),'YYYY-MM-DD');        
        END IF ;
                     
    ELSIF ( UPPER(p_gb) = 'FIRSTDATE' ) THEN
                        
        p_tostring := '' ;
        
        IF ( NVL(TRIM(p_string1), '') IS NULL ) THEN                               
            p_tostring := '1900-01-01';
        ELSE 
            p_tostring := TO_CHAR(TO_DATE(p_string1,'YYYY-MM-DD'),'yyyy-mm') || '-01';
        END IF;                                                              
                
    END IF;
    
    RETURN (p_tostring);

END;
/
