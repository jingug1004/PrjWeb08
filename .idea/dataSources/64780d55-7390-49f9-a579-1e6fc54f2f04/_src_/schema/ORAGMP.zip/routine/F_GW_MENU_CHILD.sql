CREATE FUNCTION        F_GW_MENU_CHILD (
        I_MENU_CHILD IN VARCHAR2
        ,I_EMP_NO IN VARCHAR2
) 
RETURN VARCHAR2 IS
        
        V_RETURN VARCHAR2(10);  --결과값 전달
        V_CNT NUMBER;  --결과값 전달

BEGIN
       /*-------------------------------------------------------------------
       DESCRIPTION
       변경일자 - 20171214
       
       그룹웨어 lnb 자료를 넣고자 할때 사용 
       EX) 내가받은문서에 읽지 않은 문서가 있는 경우 이곳에서 TEXT를 전달한다. 없는 경우 '' 공백을 넘긴다.
       
       -------------------------------------------------------------------*/
        
       V_RETURN := '';  --초기값
       V_CNT := 0;
        IF I_MENU_CHILD = '0203' THEN  --전자결재 - 내가 받은 문서
        
                /*CHOE 20150723 설명 
                그룹웨어 sqlmap - recive.xml - getReceiveList 사용 
                (그룹웨어 변경 사항이 있는 경우 아래 sql도 수정되어야 한다.)
                조건 중 기간(2달) ,사원번호만 그대로 사용하고 나머지는 무시하였다                 
                */                
                SELECT COUNT(*)
                INTO V_CNT
                 FROM (
                                SELECT TC.EMP_NO
                                ,TC.APPROVAL_SEQ
                                ,TC.STATE
                                ,ROW_NUMBER () OVER (PARTITION BY TC.APPROVAL_SEQ ORDER BY TC.ORDERING) AS ROW_NUMBER                                       
                                FROM HANAGROUPWARE.GW_EA_APPROVAL TC
                                ,HANAGROUPWARE.GW_EA_APPROVAL_MASTER TD
                                WHERE TC.APPROVAL_SEQ = TD.APPROVAL_SEQ
                                AND TD.STATE IN ('E02002','E02003')
                                AND TC.APPROVAL_DT IS NULL
                                AND REQ_DT BETWEEN SYSDATE - 60 AND SYSDATE
                        ) TE
                WHERE ROW_NUMBER = '1' 
                AND TE.EMP_NO = I_EMP_NO
                ;
           
                IF V_CNT > 0 THEN        
                        V_RETURN := 'New';
                END IF;                
        ELSIF I_MENU_CHILD = '020701' THEN  --전자결재 - 시행문서조회 - 결재중
                /*CHOE 20150723 설명 
                그룹웨어  implement.xml - getImplementCount 사용
                */        
                SELECT COUNT(*)
                INTO V_CNT
                FROM ORAGMP.CMEMPM EMP
                ,HANAGROUPWARE.GW_EA_APPROVAL_MASTER MASTER
                ,HANAGROUPWARE.GW_EA_DOCU DOCU
                ,HANAGROUPWARE.GW_EA_IMPL_DEPT_EMP IMPL 
                WHERE MASTER.DOCU_SEQ = DOCU.DOCU_SEQ
                AND MASTER.CREATE_NO = EMP.EMPCODE 
                AND MASTER.APPROVAL_SEQ = IMPL.APPROVAL_SEQ               
                AND MASTER.DELETE_YN = 'N'
                AND IMPL.EMP_NO = I_EMP_NO
                AND IMPL.READ_YN = 'N'     --그룹웨어와 다른 부분 읽지 않는 내용에 대해서만 표시 한다.
                AND MASTER.STATE IN ('E02002', 'E02003')   --요청 ,진행중
                AND REQ_DT BETWEEN SYSDATE - 60 AND SYSDATE
                ;
               
                IF V_CNT > 0 THEN        
                        V_RETURN := 'New';
                END IF;                          
        ELSIF I_MENU_CHILD = '020702' THEN  --전자결재 - 시행문서조회 - 결재완료
                /*CHOE 20150723 설명 
                그룹웨어  implement.xml - getImplementCount 사용
                */
                SELECT COUNT(*)
                INTO V_CNT
                FROM ORAGMP.CMEMPM EMP
                ,HANAGROUPWARE.GW_EA_APPROVAL_MASTER MASTER
                ,HANAGROUPWARE.GW_EA_DOCU DOCU
                ,HANAGROUPWARE.GW_EA_IMPL_DEPT_EMP IMPL 
                WHERE MASTER.DOCU_SEQ = DOCU.DOCU_SEQ
                AND MASTER.CREATE_NO = EMP.EMPCODE 
                AND MASTER.APPROVAL_SEQ = IMPL.APPROVAL_SEQ               
                AND MASTER.DELETE_YN = 'N'
                AND IMPL.EMP_NO = I_EMP_NO
                AND IMPL.READ_YN = 'N'     --그룹웨어와 다른 부분 읽지 않는 내용에 대해서만 표시 한다.
                AND MASTER.STATE IN ('E02004')   --완료 문서
                AND REQ_DT BETWEEN SYSDATE - 60 AND SYSDATE
                ;
                
                IF V_CNT > 0 THEN        
                        V_RETURN := 'New';
                END IF;           
        ELSIF I_MENU_CHILD = '0206' THEN  --전자결재 - 공유문서
                /*CHOE 20150723 설명
                위에 시행부서SQL를 이용하여 공유문서 조회 SQL을 만들었음 그룹웨어는 없는 쿼리임
                */
                SELECT COUNT(*)
                INTO V_CNT
                FROM ORAGMP.CMEMPM EMP
                ,HANAGROUPWARE.GW_EA_APPROVAL_MASTER MASTER
                ,HANAGROUPWARE.GW_EA_DOCU DOCU
                ,HANAGROUPWARE.GW_EA_SHARE_TARGET TAR 
                WHERE MASTER.DOCU_SEQ = DOCU.DOCU_SEQ
                AND MASTER.CREATE_NO = EMP.EMPCODE 
                AND MASTER.APPROVAL_SEQ = TAR.APPROVAL_SEQ               
                AND MASTER.DELETE_YN = 'N'
                AND TAR.EMP_NO = I_EMP_NO
                AND TAR.READ_YN = 'N'     --그룹웨어와 다른 부분 읽지 않는 내용에 대해서만 표시 한다.              
                AND REQ_DT BETWEEN SYSDATE - 60 AND SYSDATE
                ;
                IF V_CNT > 0 THEN        
                        V_RETURN := 'New';
                END IF;          
        END IF;
        
        RETURN(V_RETURN);
EXCEPTION
        WHEN NO_DATA_FOUND THEN
                V_RETURN := '';
                RETURN V_RETURN;
        WHEN OTHERS THEN
                V_RETURN := '';
                RETURN V_RETURN;       
END F_GW_MENU_CHILD;
/
