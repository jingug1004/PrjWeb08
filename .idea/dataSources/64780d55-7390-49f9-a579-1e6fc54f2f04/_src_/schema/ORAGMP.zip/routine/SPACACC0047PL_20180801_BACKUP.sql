CREATE PROCEDURE        spACacc0047PL_20180801_backup(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0047PL
	-- 작 성 자         : 최용석
	-- 작성일자         : 2011-02-22
	-- 수정일자      :   노영래
	-- E-mail      :   0rae0926@gmail.com
	-- 수정일자      :   2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 자동분개 불러오기를 처리하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_slipdiv		IN	   VARCHAR2 DEFAULT '',
	p_program		IN	   VARCHAR2 DEFAULT '',
	p_iempcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		OUT VARCHAR2,
	IO_CURSOR		OUT TYPES.DATASET
)
AS
	v_temp		   NUMBER(10, 0) := 0;
	---- 트랜젝션을 건다.
	--begin Tran
	p_acccode1	   VARCHAR2(20);
	p_acccode2	   VARCHAR2(20);
	p_acccode3	   VARCHAR2(20);
	p_acccode4	   VARCHAR2(20);
	p_acccode5	   VARCHAR2(20); -- 선급금
	p_strartym	   VARCHAR2(7);
	p_endym 	   VARCHAR2(7);
	p_slipinno	   VARCHAR2(20);
	p_ideptcode    VARCHAR2(20);
	p_insertdt	   DATE;
	p_proccnt	   NUMBER(10, 0);
	p_salload	   VARCHAR2(30);
	p_colload	   VARCHAR2(30);
	p_colseq	   VARCHAR2(30);
	p_expload	   VARCHAR2(30);
	p_salecust	   VARCHAR2(1);
	p_colcust	   VARCHAR2(1);

	SPACC_CURSOR   SYS_REFCURSOR;
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);
	-- 로드전표를 확인한다.

	v_temp := 0;


	SELECT COUNT(*)
	INTO   v_temp
	FROM   DUAL
	WHERE  NOT EXISTS
			   (SELECT *
				FROM   ACAUTOORDT
				WHERE  compcode = p_compcode
					   AND actrnstate IN ('1', '3', '4')
					   AND acattype LIKE p_slipdiv
					   AND acattype NOT IN (SELECT CASE b.grp WHEN 1 THEN A.value1 WHEN 2 THEN A.value2 ELSE A.value3 END VALUE
											FROM   SYSPARAMETERMANAGE A
												   JOIN (SELECT 1 grp FROM DUAL
														 UNION
														 SELECT 2 FROM DUAL
														 UNION
														 SELECT 3 FROM DUAL) b
													   ON 1 = 1
											WHERE  UPPER(parametercode) = 'ACCOTHERLOAD'
												   AND TRIM(p_program) IS NULL)
					   AND acattype NOT IN (SELECT CASE b.grp WHEN 1 THEN A.value1 WHEN 2 THEN A.value2 ELSE A.value3 END VALUE
											FROM   SYSPARAMETERMANAGE A
												   JOIN (SELECT 1 grp FROM DUAL
														 UNION
														 SELECT 2 FROM DUAL
														 UNION
														 SELECT 3 FROM DUAL) b
													   ON 1 = 1
											WHERE  UPPER(parametercode) = 'ACCOTHERLOAD2'
												   AND TRIM(p_program) IS NULL));

	IF v_temp <> 0
	THEN
		MESSAGE := '0';
		GOTO LASTLINE;
	END IF;

	p_acccode1 := '11120020';

	FOR rec IN (SELECT filter1
				FROM   CMCOMMONM
				WHERE  UPPER(cmmcode) = 'AC261'
					   AND divcode = '11120020')
	LOOP
		p_acccode1 := rec.filter1;
	END LOOP;

	p_acccode2 := '11135';

	FOR rec IN (SELECT filter1
				FROM   CMCOMMONM
				WHERE  UPPER(cmmcode) = 'AC261'
					   AND divcode = '11135')
	LOOP
		p_acccode2 := rec.filter1;
	END LOOP;

	p_acccode3 := '21050';

	FOR rec IN (SELECT filter1
				FROM   CMCOMMONM
				WHERE  UPPER(cmmcode) = 'AC261'
					   AND divcode = '21050')
	LOOP
		p_acccode3 := rec.filter1;
	END LOOP;

	p_acccode4 := '21030200';

	FOR rec IN (SELECT filter1
				FROM   CMCOMMONM
				WHERE  UPPER(cmmcode) = 'AC261'
					   AND divcode = '21030200')
	LOOP
		p_acccode4 := rec.filter1;
	END LOOP;

	p_acccode5 := '11131000';

	FOR rec IN (SELECT filter1
				FROM   CMCOMMONM
				WHERE  UPPER(cmmcode) = 'AC261'
					   AND divcode = '11131000')
	LOOP
		p_acccode5 := rec.filter1;
	END LOOP;

	-- 예산집계를 위한 일자범위 지정
	FOR rec IN (SELECT MIN(SUBSTR(slipindate, 1, 7)) AS alias1, TO_CHAR(SYSDATE, 'YYYY-MM') AS alias2
				FROM   ACAUTOORDT
				WHERE  compcode = p_compcode
					   AND actrnstate IN ('1', '3', '4') -- 1신규, 2완료 3수정, 4삭제
					   AND NVL(TRIM(acattype), ' ') LIKE NVL(p_slipdiv, ' '))
	LOOP
		p_strartym := rec.alias1;
		p_endym := rec.alias2;
	END LOOP;

	FOR rec IN (SELECT deptcode
				FROM   CMEMPM
				WHERE  empcode = p_iempcode)
	LOOP
		p_ideptcode := rec.deptcode;
	END LOOP;

	p_insertdt := SYSDATE;

	FOR rec IN (SELECT value2
				FROM   SYSPARAMETERMANAGE
				WHERE  UPPER(parametercode) = 'ACCSALLOAD')
	LOOP
		p_salload := rec.value2;
	END LOOP;

	FOR rec IN (SELECT value2, value3
				FROM   SYSPARAMETERMANAGE
				WHERE  UPPER(parametercode) = 'ACCCOLLOAD')
	LOOP
		p_colload := rec.value2;
		p_colseq := rec.value3;
	END LOOP;

	FOR rec IN (SELECT value2
				FROM   SYSPARAMETERMANAGE
				WHERE  UPPER(parametercode) = 'ACCEXPLOAD')
	LOOP
		p_expload := rec.value2;
	END LOOP;

	-- 부문별 자료가 변경,삭제된 경우 기존자료(동일전표번호)를 수정으로 변경
	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3'
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.slipinno
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate IN ('3', '4')
							   AND A.acattype LIKE p_slipdiv) A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.slipinno = b.slipinno
							  AND b.actrnstate = '2') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3';

	-- 매출 자료가 변경,삭제된 경우 신규자료(일자,사원)를 수정으로 변경
	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3'
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.empcode
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate = '1'
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'S'
							   AND UPPER(p_salload) = 'EMPCODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.empcode = b.empcode
							  AND b.actrnstate = '2') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3';

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3', A.slipinno
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.empcode, A.slipinno
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate IN ('3', '4')
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'S'
							   AND UPPER(p_salload) = 'EMPCODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.empcode = b.empcode
							  AND b.actrnstate = '1') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3', b.slipinno = src.slipinno;

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3'
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.iempcode
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate = '1'
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'S'
							   AND UPPER(p_salload) = 'IEMPCODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.iempcode = b.iempcode
							  AND b.actrnstate = '2') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3';

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3', A.slipinno
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.iempcode, A.slipinno
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate IN ('3', '4')
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'S'
							   AND UPPER(p_salload) = 'IEMPCODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.iempcode = b.iempcode
							  AND b.actrnstate = '1') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3', b.slipinno = src.slipinno;

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3'
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.acatrulecode, A.iempcode
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate = '1'
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'S'
							   AND UPPER(p_salload) = 'ACATRULECODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.acatrulecode = b.acatrulecode
							  AND A.iempcode = b.iempcode
							  AND b.actrnstate = '2') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3';

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3', A.slipinno
				FROM   (SELECT DISTINCT A.compcode,
										A.acattype,
										A.slipindate,
										A.acatrulecode,
										A.iempcode,
										A.slipinno
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate IN ('3', '4')
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'S'
							   AND UPPER(p_salload) = 'ACATRULECODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.acatrulecode = b.acatrulecode
							  AND A.iempcode = b.iempcode
							  AND b.actrnstate = '1') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3', b.slipinno = src.slipinno;

	-- 수금 자료가 변경,삭제된 경우 신규자료(일자,사원)를 수정으로 변경
	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3'
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.empcode
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate = '1'
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'C'
							   AND UPPER(p_colload) = 'EMPCODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.empcode = b.empcode
							  AND b.actrnstate = '2') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3';

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3', A.slipinno
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.empcode, A.slipinno
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate IN ('3', '4')
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'C'
							   AND UPPER(p_colload) = 'EMPCODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.empcode = b.empcode
							  AND b.actrnstate = '1') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3', b.slipinno = src.slipinno;

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3'
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.iempcode
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate = '1'
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'C'
							   AND UPPER(p_colload) = 'IEMPCODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.iempcode = b.iempcode
							  AND b.actrnstate = '2') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3';

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3', A.slipinno
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.iempcode, A.slipinno
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate IN ('3', '4')
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'C'
							   AND UPPER(p_colload) = 'IEMPCODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.iempcode = b.iempcode
							  AND b.actrnstate = '1') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3', b.slipinno = src.slipinno;

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3'
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.slipindate, A.acatrulecode, A.iempcode
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate = '1'
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'C'
							   AND UPPER(p_colload) = 'ACATRULECODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.acatrulecode = b.acatrulecode
							  AND A.iempcode = b.iempcode
							  AND b.actrnstate = '2') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3';

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3', A.slipinno
				FROM   (SELECT DISTINCT A.compcode,
										A.acattype,
										A.slipindate,
										A.acatrulecode,
										A.iempcode,
										A.slipinno
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate IN ('3', '4')
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'C'
							   AND UPPER(p_colload) = 'ACATRULECODE') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.acatrulecode = b.acatrulecode
							  AND A.iempcode = b.iempcode
							  AND b.actrnstate = '1') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3', b.slipinno = src.slipinno;

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE, B.ACATTYPE, B.ACATNO, '3'
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.billno, A.slipindate
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate = '1'
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'N'
							   AND UPPER(p_expload) = 'IMPORTSHTNO') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.billno = b.billno
							  AND b.actrnstate = '2') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3';

	MERGE INTO ACAUTOORDT b
	USING	   (SELECT B.COMPCODE,
					   B.ACATTYPE,
					   B.ACATNO,
					   '3',
					   A.slipindate,
					   A.slipinno
				FROM   (SELECT DISTINCT A.compcode, A.acattype, A.billno, A.slipindate, A.slipinno
						FROM   ACAUTOORDT A
							   JOIN ACAUTORULE b
								   ON A.acatrulecode = b.acautorcode
									  AND b.crtdiv = '1'
						WHERE  A.compcode = p_compcode
							   AND A.actrnstate IN ('3', '4')
							   AND A.acattype LIKE p_slipdiv
							   AND A.acattype = 'N'
							   AND UPPER(p_expload) = 'IMPORTSHTNO') A
					   JOIN ACAUTOORDT b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.billno = b.billno
							  AND b.actrnstate = '1') src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.ACATTYPE = SRC.ACATTYPE
				AND B.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET b.actrnstate = '3', b.slipindate = src.slipindate, b.slipinno = src.slipinno;

	----------------------------------------------------------------------------------------------------------------------------------------------
	-- 관리항목삭제
	-- 수금전표 삭제시 어음삭제

	FOR rec IN (SELECT C.COMPCODE, C.SLIPINNO, C.SLIPINSEQ
				FROM   ACAUTOORDT A
					   JOIN ACORDS b
						   ON A.compcode = b.compcode
							  AND A.slipinno = b.slipinno
							  AND b.mngclucode = 'S110'
					   JOIN ACORDD c
						   ON b.compcode = c.compcode
							  AND b.slipinno = c.slipinno
							  AND b.slipinseq = c.slipinseq
					   JOIN ACBILLM D
						   ON b.mngcluval = D.billno
							  AND c.debamt = D.billamt
				WHERE  A.compcode = p_compcode
					   AND A.actrnstate IN ('3', '4')
					   AND A.acattype LIKE p_slipdiv
					   AND A.acatrulecode LIKE 'C03%')
	LOOP
		DELETE FROM ACORDD A
		WHERE		A.COMPCODE = rec.COMPCODE
					AND A.SLIPINNO = rec.SLIPINNO
					AND A.SLIPINSEQ = rec.SLIPINSEQ;
	END LOOP;



	MERGE INTO ACBILLM D
	USING	   (SELECT D.COMPCODE, D.BILLNO, D.billamt - c.debamt AS billamt
				FROM   ACAUTOORDT A
					   JOIN ACORDS b
						   ON A.compcode = b.compcode
							  AND A.slipinno = b.slipinno
							  AND b.mngclucode = 'S110'
					   JOIN ACORDD c
						   ON b.compcode = c.compcode
							  AND b.slipinno = c.slipinno
							  AND b.slipinseq = c.slipinseq
					   JOIN ACBILLM D ON b.mngcluval = D.billno
				WHERE  A.compcode = p_compcode
					   AND A.actrnstate IN ('3', '4')
					   AND A.acattype LIKE p_slipdiv
					   AND A.acatrulecode LIKE 'C03%') src
	ON		   (D.COMPCODE = SRC.COMPCODE
				AND D.BILLNO = SRC.BILLNO)
	WHEN MATCHED
	THEN
		UPDATE SET D.billamt = src.billamt;


	FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ, B.MNGCLUCODE
				FROM   ACAUTOORDT A
					   JOIN ACORDS b
						   ON A.compcode = b.compcode
							  AND A.slipinno = b.slipinno
				WHERE  A.compcode = p_compcode
					   AND A.actrnstate IN ('3', '4')
					   AND A.acattype LIKE p_slipdiv)
	LOOP
		DELETE FROM ACORDS B
		WHERE		B.COMPCODE = REC.COMPCODE
					AND B.SLIPINNO = REC.SLIPINNO
					AND B.SLIPINSEQ = REC.SLIPINSEQ
					AND B.MNGCLUCODE = REC.MNGCLUCODE;
	END LOOP;

	-- 전표상세삭제
	FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ
				FROM   ACAUTOORDT A
					   JOIN ACORDD b
						   ON A.compcode = b.compcode
							  AND A.slipinno = b.slipinno
				WHERE  A.compcode = p_compcode
					   AND A.actrnstate IN ('3', '4')
					   AND A.acattype LIKE p_slipdiv)
	LOOP
		DELETE FROM ACORDD B
		WHERE		B.COMPCODE = REC.COMPCODE
					AND B.SLIPINNO = REC.SLIPINNO
					AND B.SLIPINSEQ = REC.SLIPINSEQ;
	END LOOP;

	-- 회계전표삭제
	FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO
				FROM   ACAUTOORDT A
					   JOIN ACORDM b
						   ON A.compcode = b.compcode
							  AND A.slipinno = b.slipinno
				WHERE  A.compcode = p_compcode
					   AND A.actrnstate IN ('3', '4')
					   AND A.acattype LIKE p_slipdiv)
	LOOP
		DELETE FROM ACORDM B
		WHERE		B.COMPCODE = REC.COMPCODE
					AND B.SLIPINNO = REC.SLIPINNO;
	END LOOP;


	-- 무역전표 마지막일자 생성을 위해 일자변경
	MERGE INTO ACAUTOORDT A
	USING	   (SELECT A.COMPCODE, A.ACATTYPE, A.ACATNO, b.slipindate
				FROM   ACAUTOORDT A
					   JOIN (SELECT   A.compcode, A.acattype, A.billno, MAX(A.slipindate) slipindate
							 FROM	  ACAUTOORDT A
									  JOIN ACAUTORULE b
										  ON A.acatrulecode = b.acautorcode
											 AND b.crtdiv = '1'
							 WHERE	  A.compcode = p_compcode
									  AND A.actrnstate IN ('1', '3')
									  AND A.acattype LIKE p_slipdiv
									  AND A.acattype = 'N'
									  AND UPPER(p_expload) = 'IMPORTSHTNO'
							 GROUP BY A.compcode, A.acattype, A.billno) b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.billno = b.billno
				WHERE  A.compcode = p_compcode
					   AND A.actrnstate IN ('1', '3')
					   AND A.acattype LIKE p_slipdiv
					   AND A.acattype = 'N'
					   AND UPPER(p_expload) = 'IMPORTSHTNO') src
	ON		   (A.COMPCODE = SRC.COMPCODE
				AND A.ACATTYPE = SRC.ACATTYPE
				AND A.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET A.slipindate = src.slipindate;



	-- 수금전표 승인일 변경 시 신규로 처리
	UPDATE ACAUTOORDT A
	SET    actrnstate = '1', slipinno = NULL
	WHERE  A.acattype = 'C'
		   AND A.actrnstate = '3'
		   AND SUBSTR(NVL(A.slipinno,' '), 0, 8) <> REPLACE(A.slipindate, '-', '');

	-- 무역전표 승인일 변경 시 신규로 처리
	UPDATE ACAUTOORDT A
	SET    actrnstate = '1', slipinno = NULL
	WHERE  A.acattype = 'N'
		   AND A.actrnstate = '3'
		   AND SUBSTR(NVL(A.slipinno,' '), 0, 8) <> REPLACE(A.slipindate, '-', '');

	-- 자동분개 회계전표 생성
	-- 해당일자의 전표유형에 해당하는 회계전표 마지막번호를 검색
	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACORDM01 ';

	INSERT INTO VGT.TT_ACACC0047PL_ACORDM01
		(SELECT   compcode, slipindate, acattype, NVL(TO_NUMBER(SUBSTR(MAX(slipinno), -4, 4)), 0) slipinnum
		 FROM	  ACAUTOORDT A
		 WHERE	  A.compcode = p_compcode
				  AND A.actrnstate IN (2, 3)
				  AND A.acattype LIKE p_slipdiv
		 GROUP BY compcode, slipindate, acattype);

	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACORDM02 ';

	INSERT INTO VGT.TT_ACACC0047PL_ACORDM02
		(SELECT   A.compcode, A.slipindate, A.acattype, NVL(TO_NUMBER(SUBSTR(MAX(b.slipinnum), -4, 4)), 0) slipinnum
		 FROM	  ACAUTOORDT A
				  LEFT JOIN ACORDM b
					  ON A.compcode = b.compcode
						 AND A.slipindate = b.slipindate
						 AND A.acattype = b.slipdiv
		 WHERE	  A.compcode = p_compcode
				  AND A.actrnstate = '1'
				  AND A.acattype LIKE p_slipdiv
		 GROUP BY A.compcode, A.slipindate, A.acattype);

	MERGE INTO VGT.TT_ACACC0047PL_ACORDM01 A
	USING	   (SELECT A.COMPCODE, A.SLIPINDATE, A.ACATTYPE, A.SLIPINNUM, b.slipinnum AS B_slipinnum
				FROM   VGT.TT_ACACC0047PL_ACORDM01 A
					   JOIN VGT.TT_ACACC0047PL_ACORDM02 b
						   ON A.compcode = b.compcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND A.slipinnum < b.slipinnum) src
	ON		   (NVL(A.COMPCODE, ' ') = NVL(SRC.COMPCODE, ' ')
				AND NVL(A.SLIPINDATE, ' ') = NVL(SRC.SLIPINDATE, ' ')
				AND NVL(A.ACATTYPE, ' ') = NVL(SRC.ACATTYPE, ' '))
	WHEN MATCHED
	THEN
		UPDATE SET A.slipinnum = src.B_slipinnum;


	INSERT INTO VGT.TT_ACACC0047PL_ACORDM01
		(SELECT   A.compcode, A.slipindate, A.acattype, NVL(MAX(A.slipinnum), 0) slipinnum
		 FROM	  VGT.TT_ACACC0047PL_ACORDM02 A
				  LEFT JOIN VGT.TT_ACACC0047PL_ACORDM01 b
					  ON A.compcode = b.compcode
						 AND A.acattype = b.acattype
						 AND A.slipindate = b.slipindate
		 WHERE	  b.slipinnum IS NULL
		 GROUP BY A.compcode, A.slipindate, A.acattype);



	-- 부문별은 분개기준(acatrulecode)으로 전표순번을 정함(신규)
	-- @salload, @colload이 empcode인 경우는 사원으로 전표순번을 정함
	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACAUTOORDT01 ';

	INSERT INTO VGT.TT_ACACC0047PL_ACAUTOORDT01
		SELECT A.compcode,
			   A.plantcode,
			   A.acattype,
			   A.slipindate,
			   A.acatrulecode,
			   A.acautorname,
			   A.remark1,
			   A.remark2,
			   SUBSTR('000' || TO_CHAR(ROW_NUMBER() OVER (PARTITION BY A.compcode, A.slipindate, A.acattype ORDER BY A.acatrulecode) + b.slipinnum), -4, 4) slipinnum
		FROM   (SELECT DISTINCT A.compcode,
								A.plantcode,
								A.acattype,
								A.slipindate,
								CASE
									WHEN UPPER(p_salload) = 'EMPCODE'
										 AND A.acattype = 'S'
									THEN
										A.empcode
									WHEN UPPER(p_salload) = 'IEMPCODE'
										 AND A.acattype = 'S'
									THEN
										A.iempcode
									WHEN UPPER(p_salload) = 'NEWLOAD'
										 AND A.acattype = 'S'
									THEN
										A.iempcode
									WHEN UPPER(p_salload) = 'ACATRULECODE'
										 AND A.acattype = 'S'
									THEN
										A.acatrulecode || A.IEMPCODE
									WHEN UPPER(p_colload) = 'EMPCODE'
										 AND A.acattype = 'C'
									THEN
										A.empcode
									WHEN UPPER(p_colload) = 'IEMPCODE'
										 AND A.acattype = 'C'
									THEN
										A.iempcode
									WHEN UPPER(p_colload) = 'NEWLOAD'
										 AND A.acattype = 'C'
									THEN
										A.iempcode
									WHEN UPPER(p_colload) = 'ACATRULECODE'
										 AND A.acattype = 'C'
									THEN
										A.acatrulecode || A.iempcode
									WHEN UPPER(p_expload) = 'IMPORTSHTNO'
										 AND A.acattype = 'N'
									THEN
										A.billno
									WHEN A.acattype = 'H'
									THEN
										A.plantcode
									ELSE
										A.acatrulecode
								END
									acatrulecode,
								CASE
									WHEN UPPER(p_salload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
										 AND A.acattype = 'S'
									THEN
										'영업매출-자동분개'
									WHEN UPPER(p_colload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
										 AND A.acattype = 'C'
									THEN
										'영업수금-자동분개'
									WHEN UPPER(p_expload) = 'IMPORTSHTNO'
										 AND A.acattype = 'N'
									THEN
										A.billno || ' 수입비용-자동분개'
									WHEN A.acattype = 'H'
									THEN
										'급상여-자동분개'
									ELSE
										b.acautorname
								END
									acautorname,
								CASE
									WHEN UPPER(p_salload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
										 AND A.acattype = 'S'
									THEN
										'영업매출-자동분개'
									WHEN UPPER(p_colload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
										 AND A.acattype = 'C'
									THEN
										'영업수금-자동분개'
									WHEN UPPER(p_expload) = 'IMPORTSHTNO'
										 AND A.acattype = 'N'
									THEN
										A.billno || ' 수입비용-자동분개'
									WHEN A.acattype = 'H'
									THEN
										'급상여-자동분개'
									ELSE
										b.remark1
								END
									remark1,
								CASE
									WHEN UPPER(p_salload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
										 AND A.acattype = 'S'
									THEN
										'영업매출-자동분개'
									WHEN UPPER(p_colload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
										 AND A.acattype = 'C'
									THEN
										'영업수금-자동분개'
									WHEN UPPER(p_expload) = 'IMPORTSHTNO'
										 AND A.acattype = 'N'
									THEN
										A.billno || ' 수입비용-자동분개'
									WHEN A.acattype = 'H'
									THEN
										'급상여-자동분개'
									ELSE
										b.remark2
								END
									remark2
				FROM   ACAUTOORDT A
					   JOIN ACAUTORULE b
						   ON A.acatrulecode = b.acautorcode
							  AND b.crtdiv = '1'
				WHERE  A.compcode = p_compcode
					   AND A.actrnstate = '1'
					   AND A.acattype LIKE p_slipdiv) A
			   JOIN VGT.TT_ACACC0047PL_ACORDM01 b
				   ON A.compcode = b.compcode
					  AND A.slipindate = b.slipindate
					  AND A.acattype = b.acattype;

	-- 기존 부문별자료의 전표순번 추가
	INSERT INTO VGT.TT_ACACC0047PL_ACAUTOORDT01
		(SELECT DISTINCT A.compcode,
						 A.plantcode,
						 A.acattype,
						 A.slipindate,
						 CASE
							 WHEN UPPER(p_salload) = 'EMPCODE'
								  AND A.acattype = 'S'
							 THEN
								 A.empcode
							 WHEN UPPER(p_salload) = 'IEMPCODE'
								  AND A.acattype = 'S'
							 THEN
								 A.iempcode
							 WHEN UPPER(p_salload) = 'NEWLOAD'
								  AND A.acattype = 'S'
							 THEN
								 A.iempcode
							 WHEN UPPER(p_salload) = 'ACATRULECODE'
								  AND A.acattype = 'S'
							 THEN
								 A.acatrulecode || A.iempcode
							 WHEN UPPER(p_colload) = 'EMPCODE'
								  AND A.acattype = 'C'
							 THEN
								 A.empcode
							 WHEN UPPER(p_colload) = 'IEMPCODE'
								  AND A.acattype = 'C'
							 THEN
								 A.iempcode
							 WHEN UPPER(p_colload) = 'NEWLOAD'
								  AND A.acattype = 'C'
							 THEN
								 A.iempcode
							 WHEN UPPER(p_colload) = 'ACATRULECODE'
								  AND A.acattype = 'C'
							 THEN
								 A.acatrulecode || A.iempcode
							 WHEN UPPER(p_expload) = 'IMPORTSHTNO'
								  AND A.acattype = 'N'
							 THEN
								 A.billno
							 WHEN A.acattype = 'H'
							 THEN
								 A.plantcode
							 ELSE
								 A.acatrulecode
						 END
							 acatrulecode,
						 CASE
							 WHEN UPPER(p_salload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
								  AND A.acattype = 'S'
							 THEN
								 '영업매출-자동분개'
							 WHEN UPPER(p_colload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
								  AND A.acattype = 'C'
							 THEN
								 '영업수금-자동분개'
							 WHEN UPPER(p_expload) = 'IMPORTSHTNO'
								  AND A.acattype = 'N'
							 THEN
								 A.billno || ' 수입비용-자동분개'
							 WHEN A.acattype = 'H'
							 THEN
								 '급상여-자동분개'
							 ELSE
								 b.acautorname
						 END
							 acautorname,
						 CASE
							 WHEN UPPER(p_salload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
								  AND A.acattype = 'S'
							 THEN
								 '영업매출-자동분개'
							 WHEN UPPER(p_colload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
								  AND A.acattype = 'C'
							 THEN
								 '영업수금-자동분개'
							 WHEN UPPER(p_expload) = 'IMPORTSHTNO'
								  AND A.acattype = 'N'
							 THEN
								 A.billno || ' 수입비용-자동분개'
							 WHEN A.acattype = 'H'
							 THEN
								 '급상여-자동분개'
							 ELSE
								 b.remark1
						 END
							 remark1,
						 CASE
							 WHEN UPPER(p_salload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
								  AND A.acattype = 'S'
							 THEN
								 '영업매출-자동분개'
							 WHEN UPPER(p_colload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
								  AND A.acattype = 'C'
							 THEN
								 '영업수금-자동분개'
							 WHEN UPPER(p_expload) = 'IMPORTSHTNO'
								  AND A.acattype = 'N'
							 THEN
								 A.billno || ' 수입비용-자동분개'
							 WHEN A.acattype = 'H'
							 THEN
								 '급상여-자동분개'
							 ELSE
								 b.remark2
						 END
							 remark2,
						 SUBSTR(A.slipinno, -4, 4) slipinnum
		 FROM	ACAUTOORDT A
				JOIN ACAUTORULE b
					ON A.acatrulecode = b.acautorcode
					   AND b.crtdiv = '1'
		 WHERE	A.compcode = p_compcode
				AND A.actrnstate = '3'
				AND A.acattype LIKE p_slipdiv);



	-- 일자별 전표번호 최대값 갱신
	MERGE INTO VGT.TT_ACACC0047PL_ACORDM01 A
	USING	   (SELECT A.COMPCODE, A.SLIPINDATE, A.ACATTYPE, A.SLIPINNUM, b.slipinnum AS B_slipinnum
				FROM   VGT.TT_ACACC0047PL_ACORDM01 A
					   JOIN (SELECT   compcode, slipindate, acattype, MAX(slipinnum) slipinnum
							 FROM	  VGT.TT_ACACC0047PL_ACAUTOORDT01
							 GROUP BY compcode, slipindate, acattype) b
						   ON A.compcode = b.compcode
							  AND A.slipindate = b.slipindate
							  AND A.acattype = b.acattype
							  AND A.slipinnum < b.slipinnum) src
	ON		   (NVL(A.COMPCODE, ' ') = NVL(SRC.COMPCODE, ' ')
				AND NVL(A.SLIPINDATE, ' ') = NVL(SRC.SLIPINDATE, ' ')
				AND NVL(A.ACATTYPE, ' ') = NVL(SRC.ACATTYPE, ' '))
	WHEN MATCHED
	THEN
		UPDATE SET A.slipinnum = src.B_slipinnum;

	-- 개별은 전표번호(acatno)으로 전표순번을 정함(신규)
	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACAUTOORDT02 ';

	INSERT INTO VGT.TT_ACACC0047PL_ACAUTOORDT02
		(SELECT A.compcode,
				A.acattype,
				A.slipindate,
				A.acatno,
				c.acautorname,
				c.remark1,
				c.remark2,
				SUBSTR('000' || TO_CHAR(ROW_NUMBER() OVER (PARTITION BY A.compcode, A.slipindate, A.acattype ORDER BY A.acatno) + b.slipinnum), -4, 4) slipinnum
		 FROM	ACAUTOORDT A
				JOIN VGT.TT_ACACC0047PL_ACORDM01 b
					ON A.compcode = b.compcode
					   AND A.slipindate = b.slipindate
					   AND A.acattype = b.acattype
				JOIN ACAUTORULE c
					ON A.acatrulecode = c.acautorcode
					   AND c.crtdiv = '2'
		 WHERE	A.compcode = p_compcode
				AND A.actrnstate = '1'
				AND A.acattype LIKE p_slipdiv);

	-- 기존 개별자료의 전표순번 추가
	INSERT INTO VGT.TT_ACACC0047PL_ACAUTOORDT02
		(SELECT DISTINCT A.compcode,
						 A.acattype,
						 A.slipindate,
						 A.acatno,
						 b.acautorname,
						 b.remark1,
						 b.remark2,
						 SUBSTR(A.slipinno, -4, 4) slipinnum
		 FROM	ACAUTOORDT A
				JOIN ACAUTORULE b
					ON A.acatrulecode = b.acautorcode
					   AND b.crtdiv = '2'
		 WHERE	A.compcode = p_compcode
				AND A.actrnstate = '3'
				AND A.acattype LIKE p_slipdiv);

	-- 회계전표생성(부문,개별)
	INSERT INTO ACORDM(compcode,
					   slipinno,
					   slipdiv,
					   slipindate,
					   slipinnum,
					   deptcode,
					   plantcode,
					   empcode,
					   eviddiv,
					   slipinremark,
					   slipno,
					   slipdate,
					   slipnum,
					   slipdeptcode,
					   slipempcode,
					   skreqyn,
					   skreqdiv,
					   skreqdate,
					   skreqdeptcode,
					   skreqempcode,
					   accountno,
					   slipinstate,
					   slipremark,
					   acautorcode,
					   insertdt,
					   iempcode)
		(SELECT DISTINCT A.compcode,
						 REPLACE(A.slipindate, '-', '') || A.acattype || NVL(b.slipinnum, c.slipinnum),
						 A.acattype,
						 A.slipindate,
						 A.acattype || NVL(b.slipinnum, c.slipinnum),
						 CASE
							 WHEN b.slipinnum IS NULL
								  OR UPPER(p_salload) = 'EMPCODE'
									 AND A.acattype = 'S'
								  OR UPPER(p_colload) = 'EMPCODE'
									 AND A.acattype = 'C'
							 THEN
								 A.deptcode
							 WHEN UPPER(p_salload) IN ('IEMPCODE', 'NEWLOAD', 'ACATRULECODE')
								  AND A.acattype = 'S'
								  OR UPPER(p_colload) IN ('IEMPCODE', 'NEWLOAD', 'ACATRULECODE')
									 AND A.acattype = 'C'
								  OR UPPER(p_expload) = 'IMPORTSHTNO'
									 AND A.acattype = 'N'
							 THEN
								 f.deptcode
							 ELSE
								 p_ideptcode
						 END
							 col,
						 NVL(D.plantcode, A.plantcode),
						 CASE
							 WHEN b.slipinnum IS NULL
								  OR UPPER(p_salload) = 'EMPCODE'
									 AND A.acattype = 'S'
								  OR UPPER(p_colload) = 'EMPCODE'
									 AND A.acattype = 'C'
							 THEN
								 A.empcode
							 WHEN UPPER(p_salload) IN ('IEMPCODE', 'NEWLOAD', 'ACATRULECODE')
								  AND A.acattype = 'S'
								  OR UPPER(p_colload) IN ('IEMPCODE', 'NEWLOAD', 'ACATRULECODE')
									 AND A.acattype = 'C'
								  OR UPPER(p_expload) = 'IMPORTSHTNO'
									 AND A.acattype = 'N'
							 THEN
								 A.iempcode
							 ELSE
								 p_iempcode
						 END
							 col,
						 '99',
						 NVL(b.acautorname, c.acautorname),
						 CASE WHEN E.condition1 = '1' THEN REPLACE(A.slipindate, '-', '') || A.acattype || NVL(b.slipinnum, c.slipinnum) ELSE '' END col,
						 CASE WHEN E.condition1 = '1' THEN A.slipindate ELSE '' END col,
						 CASE WHEN E.condition1 = '1' THEN A.acattype || NVL(b.slipinnum, c.slipinnum) ELSE '' END col,
						 A.slipdeptcode,
						 CASE WHEN E.condition1 = '1' THEN p_iempcode ELSE A.slipempcode END col,
						 A.skreqyn,
						 A.skreqdiv,
						 A.skreqdate,
						 A.skreqdeptcode,
						 A.skreqempcode,
						 A.accountno,
						 CASE WHEN E.condition1 = '1' THEN '4' ELSE '2' END col,
						 '',
						 CASE
							 WHEN UPPER(p_salload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
								  AND A.acattype = 'S'
								  OR UPPER(p_colload) IN ('EMPCODE', 'IEMPCODE', 'NEWLOAD')
									 AND A.acattype = 'C'
								  OR UPPER(p_expload) = 'IMPORTSHTNO'
									 AND A.acattype = 'N'
								  OR A.acattype = 'H'
							 THEN
								 A.acattype
							 ELSE
								 A.acatrulecode
						 END
							 col,
						 p_insertdt,
						 p_iempcode
		 FROM	ACAUTOORDT A
				LEFT JOIN VGT.TT_ACACC0047PL_ACAUTOORDT01 b
					ON A.compcode = b.compcode
					   AND A.plantcode = b.plantcode
					   AND A.acattype = b.acattype
					   AND A.slipindate = b.slipindate
					   AND CASE
							   WHEN UPPER(p_salload) = 'EMPCODE'
									AND A.acattype = 'S'
							   THEN
								   A.empcode
							   WHEN UPPER(p_salload) = 'IEMPCODE'
									AND A.acattype = 'S'
							   THEN
								   A.iempcode
							   WHEN UPPER(p_salload) = 'NEWLOAD'
									AND A.acattype = 'S'
							   THEN
								   A.iempcode
							   WHEN UPPER(p_salload) = 'ACATRULECODE'
									AND A.acattype = 'S'
							   THEN
								   A.acatrulecode || A.iempcode
							   WHEN UPPER(p_colload) = 'EMPCODE'
									AND A.acattype = 'C'
							   THEN
								   A.empcode
							   WHEN UPPER(p_colload) = 'IEMPCODE'
									AND A.acattype = 'C'
							   THEN
								   A.iempcode
							   WHEN UPPER(p_colload) = 'NEWLOAD'
									AND A.acattype = 'C'
							   THEN
								   A.iempcode
							   WHEN UPPER(p_colload) = 'ACATRULECODE'
									AND A.acattype = 'C'
							   THEN
								   A.acatrulecode || A.iempcode
							   WHEN UPPER(p_expload) = 'IMPORTSHTNO'
									AND A.acattype = 'N'
							   THEN
								   A.billno
							   WHEN A.acattype = 'H'
							   THEN
								   A.plantcode
							   ELSE
								   A.acatrulecode
						   END = b.acatrulecode
				LEFT JOIN VGT.TT_ACACC0047PL_ACAUTOORDT02 c
					ON A.compcode = c.compcode
					   AND A.acattype = c.acattype
					   AND A.slipindate = c.slipindate
					   AND A.acatno = c.acatno
				LEFT JOIN (SELECT A.divcode, b.plantcode
						   FROM   CMCOMMONM A JOIN CMPLANTM b ON A.filter2 = b.plantcode
						   WHERE  A.cmmcode = 'AC201') D
					ON A.acattype = D.divcode
				LEFT JOIN ACAUTORULE E ON A.acatrulecode = E.acautorcode
				LEFT JOIN CMEMPM f ON A.iempcode = f.empcode
		 WHERE	A.compcode = p_compcode
				AND A.actrnstate IN ('1', '3')
				AND A.acattype LIKE p_slipdiv);



	p_proccnt := SQL%ROWCOUNT;



	-- 전표상세임시파일생성(부문)
	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACORDD01 ';

	INSERT INTO VGT.TT_ACACC0047PL_ACORDD01
		(SELECT A.compcode,
				REPLACE(A.slipindate, '-', '') || A.acattype || b.slipinnum slipinno,
				c.acautoseq,
				c.dcdiv,
				   c.acacccode
				|| CASE
					   WHEN c.acautorcode LIKE 'H%'
							AND c.accamtdiv IN ('10', '11')
					   THEN
						   '1'
					   ELSE
						   ''
				   END
					acccode,
				NVL(D.plantcode, A.plantcode) plantcode,
				CASE
					WHEN c.dcdiv IN ('1', '4')
					THEN -- 차변,출금
						fnAcAutoORDamt(c.amtdiv,
									   c.accamtdiv,
									   c.acccalcdiv,
									   c.accsamtdiv,
									   A.trn1amt,
									   A.trn2amt,
									   A.trn3amt,
									   A.trn4amt,
									   A.trn5amt,
									   A.trn6amt,
									   A.trn7amt,
									   A.trn8amt,
									   A.trn9amt,
									   A.trn10amt,
									   A.trn11amt,
									   A.trn12amt,
									   A.trn13amt,
									   A.trn14amt,
									   A.trn15amt,
									   A.trn16amt,
									   A.trn17amt,
									   A.trn18amt,
									   A.trn19amt,
									   A.trn20amt,
									   A.trn21amt,
									   A.trn22amt,
									   A.trn23amt,
									   A.trn24amt,
									   A.trn25amt,
									   A.trn26amt,
									   A.trn27amt,
									   A.trn28amt,
									   A.trn29amt,
									   A.trn30amt)
					ELSE
						0
				END
					debamt,
				CASE
					WHEN c.dcdiv IN ('2', '3')
					THEN -- 대변,입금
						fnAcAutoORDamt(c.amtdiv,
									   c.accamtdiv,
									   c.acccalcdiv,
									   c.accsamtdiv,
									   A.trn1amt,
									   A.trn2amt,
									   A.trn3amt,
									   A.trn4amt,
									   A.trn5amt,
									   A.trn6amt,
									   A.trn7amt,
									   A.trn8amt,
									   A.trn9amt,
									   A.trn10amt,
									   A.trn11amt,
									   A.trn12amt,
									   A.trn13amt,
									   A.trn14amt,
									   A.trn15amt,
									   A.trn16amt,
									   A.trn17amt,
									   A.trn18amt,
									   A.trn19amt,
									   A.trn20amt,
									   A.trn21amt,
									   A.trn22amt,
									   A.trn23amt,
									   A.trn24amt,
									   A.trn25amt,
									   A.trn26amt,
									   A.trn27amt,
									   A.trn28amt,
									   A.trn29amt,
									   A.trn30amt)
					ELSE
						0
				END
					creamt,
				CASE
					WHEN A.acattype = 'H'
					THEN
						CASE
							WHEN c.accamtdiv IN ('01', '02', '03', '04', '20')
							THEN
								SUBSTR(A.remark, 0, 4) || '분 급여'
							WHEN c.accamtdiv = '05'
							THEN
								SUBSTR(A.remark, 0, 4) || '분 근로소득세'
							WHEN c.accamtdiv = '06'
							THEN
								SUBSTR(A.remark, 0, 4) || '분 근로주민세'
							WHEN c.accamtdiv = '12'
							THEN
								SUBSTR(A.remark, 0, 4) || '분 농특세'
							WHEN c.accamtdiv = '07'
							THEN
								SUBSTR(A.remark, 0, 4) || '분 국민연금 본인부담금'
							WHEN c.accamtdiv = '08'
							THEN
								SUBSTR(A.remark, 0, 4) || '분 건강보험 본인부담금'
							WHEN c.accamtdiv = '09'
							THEN
								SUBSTR(A.remark, 0, 4) || '분 고용보험 본인부담금'
							WHEN c.accamtdiv = '13'
							THEN
								SUBSTR(A.remark, 0, 4) || '분 기타'
							ELSE
								NVL(A.remark, b.remark1)
						END
					ELSE
						NVL(A.remark, b.remark1)
				END
					remark1,
				--,isnull(nullif(a.remark, ''), b.remark1) as remark1
				NVL(A.remark2, b.remark2) remark2,
				A.taxno,
				A.acatno
		 FROM	ACAUTOORDT A
				JOIN VGT.TT_ACACC0047PL_ACAUTOORDT01 b
					ON A.compcode = b.compcode
					   AND A.plantcode = b.plantcode
					   AND A.acattype = b.acattype
					   AND A.slipindate = b.slipindate
					   AND CASE WHEN A.acattype = 'H' THEN A.plantcode ELSE '' END = b.acatrulecode
				JOIN ACAUTORULESM c ON A.acatrulecode = c.acautorcode
				LEFT JOIN (SELECT A.divcode, b.plantcode
						   FROM   CMCOMMONM A JOIN CMPLANTM b ON A.filter2 = b.plantcode
						   WHERE  A.cmmcode = 'AC201') D
					ON A.acattype = D.divcode
		 WHERE	A.compcode = p_compcode
				AND A.actrnstate IN ('1', '3')
				AND A.acattype LIKE p_slipdiv);

	-- 관리항목임시파일생성(부문)
	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACORDS02 ';

	INSERT INTO VGT.TT_ACACC0047PL_ACORDS02
		(SELECT A.compcode,
				REPLACE(A.slipindate, '-', '') || A.acattype || b.slipinnum slipinno,
				c.acautoseq,
				D.mngclucode,
				E.seq,
				fnAcAutoORDval(D.mngcluvaldiv,
							   A.userdef1code,
							   A.userdef2code,
							   A.userdef3code,
							   A.userdef4code,
							   A.userdef5code,
							   A.userdef6code,
							   A.userdef7code,
							   A.userdef8code,
							   A.userdef9code,
							   A.userdef10code,
							   A.userdef11code,
							   A.userdef12code,
							   A.userdef13code,
							   A.userdef14code,
							   A.userdef15code,
							   A.userdef16code,
							   A.userdef17code,
							   A.userdef18code,
							   A.userdef19code,
							   A.userdef20code,
							   A.userdef21code,
							   A.userdef22code,
							   A.userdef23code,
							   A.userdef24code,
							   A.userdef25code,
							   A.userdef26code,
							   A.userdef27code,
							   A.userdef28code,
							   A.userdef29code,
							   A.userdef30code,
							   A.deptcode,
							   A.custcode,
							   A.taxno,
							   A.billno,
							   A.issdate,
							   A.expdate,
							   A.cardno,
							   A.empcode,
							   A.cardokno)
					mngcluval,
				fnAcAutoORDval(D.mngcludecdiv,
							   A.userdef1code,
							   A.userdef2code,
							   A.userdef3code,
							   A.userdef4code,
							   A.userdef5code,
							   A.userdef6code,
							   A.userdef7code,
							   A.userdef8code,
							   A.userdef9code,
							   A.userdef10code,
							   A.userdef11code,
							   A.userdef12code,
							   A.userdef13code,
							   A.userdef14code,
							   A.userdef15code,
							   A.userdef16code,
							   A.userdef17code,
							   A.userdef18code,
							   A.userdef19code,
							   A.userdef20code,
							   A.userdef21code,
							   A.userdef22code,
							   A.userdef23code,
							   A.userdef24code,
							   A.userdef25code,
							   A.userdef26code,
							   A.userdef27code,
							   A.userdef28code,
							   A.userdef29code,
							   A.userdef30code,
							   A.deptcode,
							   A.custcode,
							   A.taxno,
							   A.billno,
							   A.issdate,
							   A.expdate,
							   A.cardno,
							   A.empcode,
							   A.cardokno)
					mngcludec,
				A.acatno
		 FROM	ACAUTOORDT A
				JOIN VGT.TT_ACACC0047PL_ACAUTOORDT01 b
					ON A.compcode = b.compcode
					   AND A.plantcode = b.plantcode
					   AND A.acattype = b.acattype
					   AND A.slipindate = b.slipindate
					   AND CASE WHEN A.acattype = 'H' THEN A.plantcode ELSE A.acatrulecode END = b.acatrulecode
				JOIN ACAUTORULESM c ON A.acatrulecode = c.acautorcode
				JOIN ACAUTORULEDS D
					ON c.acautorcode = D.acautorcode
					   AND c.acautoseq = D.acautoseq
				JOIN ACACCMNGM E
					ON c.acacccode = E.acccode
					   AND E.dcdiv = CASE WHEN c.dcdiv IN ('1', '4') THEN '1' ELSE '2' END
					   AND D.mngclucode = E.mngclucode
		 WHERE	A.compcode = p_compcode
				AND A.actrnstate IN ('1', '3')
				AND A.acattype LIKE p_slipdiv);

	-- 급여 이체포멧메 맞게 변경
	DELETE VGT.TT_ACACC0047PL_ACORDD01
	WHERE  NVL(slipinno, ' ') LIKE '%H%'
		   AND NVL(debamt,0) = 0
		   AND NVL(creamt,0) = 0;

	MERGE INTO VGT.TT_ACACC0047PL_ACORDS02 A
	USING	   (SELECT A.COMPCODE,
					   A.SLIPINNO,
					   A.ACAUTOSEQ,
					   A.MNGCLUCODE,
					   A.SEQ,
					   A.MNGCLUVAL,
					   A.MNGCLUDEC,
					   A.ACATNO,
					   CASE WHEN c.accamtdiv = '05' THEN '' WHEN c.accamtdiv = '06' THEN '' WHEN c.accamtdiv = '12' THEN '' WHEN c.accamtdiv = '07' THEN '' WHEN c.accamtdiv = '08' THEN '' WHEN c.accamtdiv = '09' THEN '' WHEN c.accamtdiv = '13' THEN '' WHEN c.accamtdiv = '20' THEN '' ELSE '' END
						   AS pos_2,
					   CASE
						   WHEN c.accamtdiv = '05'
						   THEN
							   '청주세무서'
						   WHEN c.accamtdiv = '06'
						   THEN
							   '청원군'
						   WHEN c.accamtdiv = '12'
						   THEN
							   '청주세무서'
						   WHEN c.accamtdiv = '07'
						   THEN
							   '국민연금관리공단'
						   WHEN c.accamtdiv = '08'
						   THEN
							   '국민건강보험공단'
						   WHEN c.accamtdiv = '09'
						   THEN
							   '근로복지공단'
						   WHEN c.accamtdiv = '13'
						   THEN
							   ''
						   WHEN c.accamtdiv = '20'
						   THEN
							   ''
						   ELSE
							   ''
					   END
						   AS pos_3
				FROM   VGT.TT_ACACC0047PL_ACORDS02 A
					   JOIN VGT.TT_ACACC0047PL_ACORDD01 b
						   ON A.slipinno = b.slipinno
							  AND A.acautoseq = b.acautoseq
							  AND A.acatno = b.acatno
					   JOIN ACAUTORULESM c
						   ON c.acautorcode = 'H01001'
							  AND b.acautoseq = c.acautoseq
				WHERE  NVL(TRIM(A.slipinno), ' ') LIKE '%H%'
					   AND A.mngclucode = 'S010') src
	ON		   (NVL(A.COMPCODE, ' ') = NVL(SRC.COMPCODE, ' ')
				AND NVL(A.SLIPINNO, ' ') = NVL(SRC.SLIPINNO, ' ')
				AND NVL(A.ACAUTOSEQ, 0) = NVL(SRC.ACAUTOSEQ, 0)
				AND NVL(A.MNGCLUCODE, ' ') = NVL(SRC.MNGCLUCODE, ' ')
				AND NVL(A.SEQ, 0) = NVL(SRC.SEQ, 0)
				AND NVL(A.ACATNO, ' ') = NVL(SRC.ACATNO, ' '))
	WHEN MATCHED
	THEN
		UPDATE SET A.mngcluval = pos_2, A.mngcludec = pos_3;

	-- 영업거래처 대표거래처로 변경
	FOR rec IN (SELECT value1, value2
				FROM   SYSPARAMETERMANAGE
				WHERE  UPPER(parametercode) = 'ACCSALESCUSTLOAD')
	LOOP
		p_salecust := rec.value1;
		p_colcust := rec.value2;
	END LOOP;

	MERGE INTO VGT.TT_ACACC0047PL_ACORDS02 A
	USING	   (SELECT A.COMPCODE,
					   A.SLIPINNO,
					   A.ACAUTOSEQ,
					   A.MNGCLUCODE,
					   A.SEQ,
					   A.MNGCLUVAL,
					   A.MNGCLUDEC,
					   A.ACATNO,
					   NVL(c.custcode, A.mngcluval) AS pos_2,
					   NVL(c.custname, A.mngcludec) AS pos_3
				FROM   VGT.TT_ACACC0047PL_ACORDS02 A
					   JOIN CMCUSTM b ON A.mngcluval = b.custcode
					   JOIN CMCUSTM c ON b.custmajorcode = c.custcode
				WHERE  A.mngclucode = 'S010'
					   AND (p_salecust = 'Y'
							AND A.slipinno LIKE '%S%'
							OR p_colcust = 'Y'
							   AND A.slipinno LIKE '%C%')) src
	ON		   (NVL(A.COMPCODE, ' ') = NVL(SRC.COMPCODE, ' ')
				AND NVL(A.SLIPINNO, ' ') = NVL(SRC.SLIPINNO, ' ')
				AND NVL(A.ACAUTOSEQ, 0) = NVL(SRC.ACAUTOSEQ, 0)
				AND NVL(A.MNGCLUCODE, ' ') = NVL(SRC.MNGCLUCODE, ' ')
				AND NVL(A.SEQ, 0) = NVL(SRC.SEQ, 0)
				AND NVL(A.ACATNO, ' ') = NVL(SRC.ACATNO, ' '))
	WHEN MATCHED
	THEN
		UPDATE SET A.mngcluval = pos_2, A.mngcludec = pos_3;

	-- 부문별합계 임시파일 생성
	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACORDDS01 ';

	INSERT INTO VGT.TT_ACACC0047PL_ACORDDS01
		SELECT	 compcode,
				 slipinno,
				 ROW_NUMBER() OVER (PARTITION BY compcode, slipinno ORDER BY MIN(acautoseq), MIN(acatno)) slipinseq,
				 dcdiv,
				 acccode,
				 MAX(plantcode) plantcode,
				 SUM(debamt) debamt,
				 SUM(creamt) creamt,
				 remark1 remark1,
				 MAX(remark2) remark2,
				 MAX(taxno) taxno,
				 nvl(mngclucode1,' '),
				 nvl(mngclucode2,' '),
				 nvl(mngclucode3,' '),
				 nvl(mngclucode4,' '),
				 nvl(mngclucode5,' '),
				 nvl(mngclucode6,' '),
				 mngcluval1,
				 mngcluval2,
				 mngcluval3,
				 mngcluval4,
				 mngcluval5,
				 mngcluval6,
				 MAX(mngcludec1) mngcludec1,
				 MAX(mngcludec2) mngcludec2,
				 MAX(mngcludec3) mngcludec3,
				 MAX(mngcludec4) mngcludec4,
				 MAX(mngcludec5) mngcludec5,
				 MAX(mngcludec6) mngcludec6
		FROM	 (SELECT   A.compcode,
						   A.slipinno,
						   A.acautoseq,
						   A.dcdiv,
						   A.acccode,
						   A.plantcode,
						   A.taxno,
						   MAX(A.debamt) debamt,
						   MAX(A.creamt) creamt,
						   A.remark1,
						   A.remark2,
						   A.acatno,
						   MAX(CASE WHEN seq = 1 THEN mngclucode ELSE '' END) mngclucode1,
						   MAX(CASE WHEN seq = 2 THEN mngclucode ELSE '' END) mngclucode2,
						   MAX(CASE WHEN seq = 3 THEN mngclucode ELSE '' END) mngclucode3,
						   MAX(CASE WHEN seq = 4 THEN mngclucode ELSE '' END) mngclucode4,
						   MAX(CASE WHEN seq = 5 THEN mngclucode ELSE '' END) mngclucode5,
						   MAX(CASE WHEN seq = 6 THEN mngclucode ELSE '' END) mngclucode6,
						   MAX(CASE WHEN seq = 1 THEN mngcluval ELSE '' END) mngcluval1,
						   MAX(CASE WHEN seq = 2 THEN mngcluval ELSE '' END) mngcluval2,
						   MAX(CASE WHEN seq = 3 THEN mngcluval ELSE '' END) mngcluval3,
						   MAX(CASE WHEN seq = 4 THEN mngcluval ELSE '' END) mngcluval4,
						   MAX(CASE WHEN seq = 5 THEN mngcluval ELSE '' END) mngcluval5,
						   MAX(CASE WHEN seq = 6 THEN mngcluval ELSE '' END) mngcluval6,
						   MAX(CASE WHEN seq = 1 THEN mngcludec ELSE '' END) mngcludec1,
						   MAX(CASE WHEN seq = 2 THEN mngcludec ELSE '' END) mngcludec2,
						   MAX(CASE WHEN seq = 3 THEN mngcludec ELSE '' END) mngcludec3,
						   MAX(CASE WHEN seq = 4 THEN mngcludec ELSE '' END) mngcludec4,
						   MAX(CASE WHEN seq = 5 THEN mngcludec ELSE '' END) mngcludec5,
						   MAX(CASE WHEN seq = 6 THEN mngcludec ELSE '' END) mngcludec6
				  FROM	   VGT.TT_ACACC0047PL_ACORDD01 A
						   LEFT JOIN VGT.TT_ACACC0047PL_ACORDS02 b
							   ON A.slipinno = b.slipinno
								  AND A.acautoseq = b.acautoseq
								  AND A.acatno = b.acatno
				  GROUP BY A.compcode,
						   A.slipinno,
						   A.acautoseq,
						   A.dcdiv,
						   A.taxno,
						   A.acccode,
						   A.plantcode,
						   A.remark1,
						   A.remark2,
						   A.acatno
				  HAVING   SUM(A.debamt) <> 0
						   OR SUM(A.creamt) <> 0) A
		GROUP BY compcode,
				 slipinno,
				 dcdiv,
				 acccode,
				 remark1,
				 mngclucode1,
				 mngclucode2,
				 mngclucode3,
				 mngclucode4,
				 mngclucode5,
				 mngclucode6,
				 mngcluval1,
				 mngcluval2,
				 mngcluval3,
				 mngcluval4,
				 mngcluval5,
				 mngcluval6
		HAVING	 SUM(debamt) <> 0
				 OR SUM(creamt) <> 0;


	-- 부문별자료 생성
	MERGE INTO VGT.TT_ACACC0047PL_ACORDDS01 A
	USING	   (SELECT A.COMPCODE,
					   A.SLIPINNO,
					   A.SLIPINSEQ,
					   A.DCDIV,
					   A.ACCCODE,
					   A.PLANTCODE,
					   A.DEBAMT,
					   A.CREAMT,
					   A.REMARK1,
					   A.REMARK2,
					   A.TAXNO,
					   A.MNGCLUCODE1,
					   A.MNGCLUCODE2,
					   A.MNGCLUCODE3,
					   A.MNGCLUCODE4,
					   A.MNGCLUCODE5,
					   A.MNGCLUCODE6,
					   A.MNGCLUVAL1,
					   A.MNGCLUVAL2,
					   A.MNGCLUVAL3,
					   A.MNGCLUVAL4,
					   A.MNGCLUVAL5,
					   A.MNGCLUVAL6,
					   A.MNGCLUDEC1,
					   A.MNGCLUDEC2,
					   A.MNGCLUDEC3,
					   A.MNGCLUDEC4,
					   A.MNGCLUDEC5,
					   A.MNGCLUDEC6,
					   CASE
						   WHEN A.mngclucode1 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptcode
						   ELSE
							   A.mngcluval1
					   END
						   AS pos_2,
					   CASE
						   WHEN A.mngclucode2 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptcode
						   ELSE
							   A.mngcluval2
					   END
						   AS pos_3,
					   CASE
						   WHEN A.mngclucode3 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptcode
						   ELSE
							   A.mngcluval3
					   END
						   AS pos_4,
					   CASE
						   WHEN A.mngclucode4 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptcode
						   ELSE
							   A.mngcluval4
					   END
						   AS pos_5,
					   CASE
						   WHEN A.mngclucode5 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptcode
						   ELSE
							   A.mngcluval5
					   END
						   AS pos_6,
					   CASE
						   WHEN A.mngclucode6 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptcode
						   ELSE
							   A.mngcluval6
					   END
						   AS pos_7,
					   CASE
						   WHEN A.mngclucode1 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptname
						   ELSE
							   A.mngcludec1
					   END
						   AS pos_8,
					   CASE
						   WHEN A.mngclucode2 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptname
						   ELSE
							   A.mngcludec2
					   END
						   AS pos_9,
					   CASE
						   WHEN A.mngclucode3 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptname
						   ELSE
							   A.mngcludec3
					   END
						   AS pos_10,
					   CASE
						   WHEN A.mngclucode4 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptname
						   ELSE
							   A.mngcludec4
					   END
						   AS pos_11,
					   CASE
						   WHEN A.mngclucode5 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptname
						   ELSE
							   A.mngcludec5
					   END
						   AS pos_12,
					   CASE
						   WHEN A.mngclucode6 = 'S040'
								AND TRIM(c.deptcode) IS NOT NULL
						   THEN
							   c.deptname
						   ELSE
							   A.mngcludec6
					   END
						   AS pos_13
				FROM   VGT.TT_ACACC0047PL_ACORDDS01 A
					   JOIN SYSPARAMETERMANAGE b
						   ON UPPER(b.parametercode) = 'ACCPAYLOADDEPT'
							  AND b.usediv = 'Y'
					   JOIN CMDEPTM c ON b.value1 = c.deptcode
				WHERE  p_slipdiv = 'H') src
	ON		   (NVL(A.COMPCODE, ' ') = NVL(SRC.COMPCODE, ' ')
				AND NVL(A.SLIPINNO, ' ') = NVL(SRC.SLIPINNO, ' ')
				AND NVL(A.SLIPINSEQ, ' ') = NVL(SRC.SLIPINSEQ, ' ')
				AND NVL(A.DCDIV, ' ') = NVL(SRC.DCDIV, ' ')
				AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
				AND NVL(A.PLANTCODE, ' ') = NVL(SRC.PLANTCODE, ' ')
				AND NVL(A.DEBAMT, ' ') = NVL(SRC.DEBAMT, ' ')
				AND NVL(A.CREAMT, ' ') = NVL(SRC.CREAMT, ' ')
				AND NVL(A.REMARK1, ' ') = NVL(SRC.REMARK1, ' ')
				AND NVL(A.REMARK2, ' ') = NVL(SRC.REMARK2, ' ')
				AND NVL(A.TAXNO, ' ') = NVL(SRC.TAXNO, ' ')
				AND NVL(A.MNGCLUCODE1, ' ') = NVL(SRC.MNGCLUCODE1, ' ')
				AND NVL(A.MNGCLUCODE2, ' ') = NVL(SRC.MNGCLUCODE2, ' ')
				AND NVL(A.MNGCLUCODE3, ' ') = NVL(SRC.MNGCLUCODE3, ' ')
				AND NVL(A.MNGCLUCODE4, ' ') = NVL(SRC.MNGCLUCODE4, ' ')
				AND NVL(A.MNGCLUCODE5, ' ') = NVL(SRC.MNGCLUCODE5, ' ')
				AND NVL(A.MNGCLUCODE6, ' ') = NVL(SRC.MNGCLUCODE6, ' '))
	WHEN MATCHED
	THEN
		UPDATE SET A.mngcluval1 = pos_2,
				   A.mngcluval2 = pos_3,
				   A.mngcluval3 = pos_4,
				   A.mngcluval4 = pos_5,
				   A.mngcluval5 = pos_6,
				   A.mngcluval6 = pos_7,
				   A.mngcludec1 = pos_8,
				   A.mngcludec2 = pos_9,
				   A.mngcludec3 = pos_10,
				   A.mngcludec4 = pos_11,
				   A.mngcludec5 = pos_12,
				   A.mngcludec6 = pos_13;



	INSERT INTO ACORDD(compcode,
					   slipinno,
					   slipinseq,
					   dcdiv,
					   acccode,
					   plantcode,
					   debamt,
					   creamt,
					   slipdate,
					   slipnum,
					   remark1,
					   remark2,
					   taxno,
					   datadiv,
					   rptseq,
					   insertdt,
					   iempcode)
		(SELECT A.compcode,
				A.slipinno,
				A.slipinseq,
				A.dcdiv,
				SUBSTR(A.acccode, 0, 8),
				A.plantcode,
				A.debamt,
				A.creamt,
				b.slipdate,
				b.slipnum,
				A.remark1,
				A.remark2,
				CASE
					WHEN NVL(A.acccode, ' ') LIKE NVL(p_acccode2, '%') || '%'
						 OR NVL(A.acccode, ' ') LIKE NVL(p_acccode3, '%') || '%'
					THEN
						NVL(A.taxno, '')
					ELSE
						''
				END
					col,
				'',
				A.slipinseq,
				SYSDATE,
				p_iempcode
		 FROM	VGT.TT_ACACC0047PL_ACORDDS01 A JOIN ACORDM b ON A.slipinno = b.slipinno);

	INSERT INTO ACORDS(compcode,
					   slipinno,
					   slipinseq,
					   mngclucode,
					   seq,
					   mngcluval,
					   mngcludec,
					   insertdt,
					   iempcode)
		(SELECT compcode,
				slipinno,
				slipinseq,
				nvl(mngclucode1, ' '),
				1,
				mngcluval1,
				mngcludec1,
				SYSDATE,
				p_iempcode
		 FROM	VGT.TT_ACACC0047PL_ACORDDS01
		 WHERE	TRIM(mngclucode1) IS NOT NULL);

	INSERT INTO ACORDS(compcode,
					   slipinno,
					   slipinseq,
					   mngclucode,
					   seq,
					   mngcluval,
					   mngcludec,
					   insertdt,
					   iempcode)
		(SELECT compcode,
				slipinno,
				slipinseq,
				nvl(mngclucode2,' '),
				2,
				mngcluval2,
				mngcludec2,
				SYSDATE,
				p_iempcode
		 FROM	VGT.TT_ACACC0047PL_ACORDDS01
		 WHERE	TRIM(mngclucode2) IS NOT NULL);

	INSERT INTO ACORDS(compcode,
					   slipinno,
					   slipinseq,
					   mngclucode,
					   seq,
					   mngcluval,
					   mngcludec,
					   insertdt,
					   iempcode)
		(SELECT compcode,
				slipinno,
				slipinseq,
				nvl(mngclucode3, ' '),
				3,
				mngcluval3,
				mngcludec3,
				SYSDATE,
				p_iempcode
		 FROM	VGT.TT_ACACC0047PL_ACORDDS01
		 WHERE	TRIM(mngclucode3) IS NOT NULL);

	INSERT INTO ACORDS(compcode,
					   slipinno,
					   slipinseq,
					   mngclucode,
					   seq,
					   mngcluval,
					   mngcludec,
					   insertdt,
					   iempcode)
		(SELECT compcode,
				slipinno,
				slipinseq,
				nvl(mngclucode4, ' '),
				4,
				mngcluval4,
				mngcludec4,
				SYSDATE,
				p_iempcode
		 FROM	VGT.TT_ACACC0047PL_ACORDDS01
		 WHERE	TRIM(mngclucode4) IS NOT NULL);

	INSERT INTO ACORDS(compcode,
					   slipinno,
					   slipinseq,
					   mngclucode,
					   seq,
					   mngcluval,
					   mngcludec,
					   insertdt,
					   iempcode)
		(SELECT compcode,
				slipinno,
				slipinseq,
				nvl(mngclucode5,' '),
				5,
				mngcluval5,
				mngcludec5,
				SYSDATE,
				p_iempcode
		 FROM	VGT.TT_ACACC0047PL_ACORDDS01
		 WHERE	TRIM(mngclucode5) IS NOT NULL);

	INSERT INTO ACORDS(compcode,
					   slipinno,
					   slipinseq,
					   mngclucode,
					   seq,
					   mngcluval,
					   mngcludec,
					   insertdt,
					   iempcode)
		(SELECT compcode,
				slipinno,
				slipinseq,
				nvl(mngclucode6,' '),
				6,
				mngcluval6,
				mngcludec6,
				SYSDATE,
				p_iempcode
		 FROM	VGT.TT_ACACC0047PL_ACORDDS01
		 WHERE	TRIM(mngclucode6) IS NOT NULL);



	-- 전표상세임시파일생성(개별)
	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACORDD02 ';

	INSERT INTO VGT.TT_ACACC0047PL_ACORDD02
		(SELECT A.compcode,
				REPLACE(A.slipindate, '-', '') || A.acattype || b.slipinnum slipinno,
				c.acautoseq,
				c.dcdiv,
				c.acacccode acccode,
				NVL(D.plantcode, A.plantcode) plantcode,
				CASE
					WHEN c.dcdiv IN ('1', '4')
					THEN -- 차변,출금
						fnAcAutoORDamt(c.amtdiv,
									   c.accamtdiv,
									   c.acccalcdiv,
									   c.accsamtdiv,
									   A.trn1amt,
									   A.trn2amt,
									   A.trn3amt,
									   A.trn4amt,
									   A.trn5amt,
									   A.trn6amt,
									   A.trn7amt,
									   A.trn8amt,
									   A.trn9amt,
									   A.trn10amt,
									   A.trn11amt,
									   A.trn12amt,
									   A.trn13amt,
									   A.trn14amt,
									   A.trn15amt,
									   A.trn16amt,
									   A.trn17amt,
									   A.trn18amt,
									   A.trn19amt,
									   A.trn20amt,
									   A.trn21amt,
									   A.trn22amt,
									   A.trn23amt,
									   A.trn24amt,
									   A.trn25amt,
									   A.trn26amt,
									   A.trn27amt,
									   A.trn28amt,
									   A.trn29amt,
									   A.trn30amt)
					ELSE
						0
				END
					debamt,
				CASE
					WHEN c.dcdiv IN ('2', '3')
					THEN -- 대변,입금
						fnAcAutoORDamt(c.amtdiv,
									   c.accamtdiv,
									   c.acccalcdiv,
									   c.accsamtdiv,
									   A.trn1amt,
									   A.trn2amt,
									   A.trn3amt,
									   A.trn4amt,
									   A.trn5amt,
									   A.trn6amt,
									   A.trn7amt,
									   A.trn8amt,
									   A.trn9amt,
									   A.trn10amt,
									   A.trn11amt,
									   A.trn12amt,
									   A.trn13amt,
									   A.trn14amt,
									   A.trn15amt,
									   A.trn16amt,
									   A.trn17amt,
									   A.trn18amt,
									   A.trn19amt,
									   A.trn20amt,
									   A.trn21amt,
									   A.trn22amt,
									   A.trn23amt,
									   A.trn24amt,
									   A.trn25amt,
									   A.trn26amt,
									   A.trn27amt,
									   A.trn28amt,
									   A.trn29amt,
									   A.trn30amt)
					ELSE
						0
				END
					creamt,
				NVL(A.remark, b.remark1) remark1,
				NVL(A.remark2, b.remark2) remark2,
				A.taxno,
				CASE WHEN p_colseq = 'Y' THEN A.trn30amt ELSE 0 END crtord
		 FROM	ACAUTOORDT A
				JOIN VGT.TT_ACACC0047PL_ACAUTOORDT02 b
					ON A.compcode = b.compcode
					   AND A.acattype = b.acattype
					   AND A.slipindate = b.slipindate
					   AND A.acatno = b.acatno
				JOIN ACAUTORULESM c ON A.acatrulecode = c.acautorcode
				LEFT JOIN (SELECT A.divcode, b.plantcode
						   FROM   CMCOMMONM A JOIN CMPLANTM b ON A.filter2 = b.plantcode
						   WHERE  A.cmmcode = 'AC201') D
					ON A.acattype = D.divcode
		 WHERE	A.compcode = p_compcode
				AND A.actrnstate IN ('1', '3')
				AND A.acattype LIKE p_slipdiv);

	-- 관리항목임시파일생성(개별)
	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACORDS03 ';

	INSERT INTO VGT.TT_ACACC0047PL_ACORDS03
		(SELECT A.compcode,
				REPLACE(A.slipindate, '-', '') || A.acattype || b.slipinnum slipinno,
				c.acautoseq,
				D.mngclucode,
				E.seq,
				fnAcAutoORDval(D.mngcluvaldiv,
							   A.userdef1code,
							   A.userdef2code,
							   A.userdef3code,
							   A.userdef4code,
							   A.userdef5code,
							   A.userdef6code,
							   A.userdef7code,
							   A.userdef8code,
							   A.userdef9code,
							   A.userdef10code,
							   A.userdef11code,
							   A.userdef12code,
							   A.userdef13code,
							   A.userdef14code,
							   A.userdef15code,
							   A.userdef16code,
							   A.userdef17code,
							   A.userdef18code,
							   A.userdef19code,
							   A.userdef20code,
							   A.userdef21code,
							   A.userdef22code,
							   A.userdef23code,
							   A.userdef24code,
							   A.userdef25code,
							   A.userdef26code,
							   A.userdef27code,
							   A.userdef28code,
							   A.userdef29code,
							   A.userdef30code,
							   A.deptcode,
							   NVL(G.custcode, A.custcode),
							   A.taxno,
							   A.billno,
							   A.issdate,
							   A.expdate,
							   A.cardno,
							   A.empcode,
							   A.cardokno)
					mngcluval,
				fnAcAutoORDval(D.mngcludecdiv,
							   A.userdef1code,
							   A.userdef2code,
							   A.userdef3code,
							   A.userdef4code,
							   A.userdef5code,
							   NVL(G.custname, A.userdef6code),
							   A.userdef7code,
							   A.userdef8code,
							   A.userdef9code,
							   A.userdef10code,
							   A.userdef11code,
							   A.userdef12code,
							   A.userdef13code,
							   A.userdef14code,
							   A.userdef15code,
							   A.userdef16code,
							   A.userdef17code,
							   A.userdef18code,
							   A.userdef19code,
							   A.userdef20code,
							   A.userdef21code,
							   A.userdef22code,
							   A.userdef23code,
							   A.userdef24code,
							   A.userdef25code,
							   A.userdef26code,
							   A.userdef27code,
							   A.userdef28code,
							   A.userdef29code,
							   A.userdef30code,
							   A.deptcode,
							   A.custcode,
							   A.taxno,
							   A.billno,
							   A.issdate,
							   A.expdate,
							   A.cardno,
							   A.empcode,
							   A.cardokno)
					mngcludec
		 FROM	ACAUTOORDT A
				JOIN VGT.TT_ACACC0047PL_ACAUTOORDT02 b
					ON A.compcode = b.compcode
					   AND A.acattype = b.acattype
					   AND A.slipindate = b.slipindate
					   AND A.acatno = b.acatno
				JOIN ACAUTORULESM c ON A.acatrulecode = c.acautorcode
				JOIN ACAUTORULEDS D
					ON c.acautorcode = D.acautorcode
					   AND c.acautoseq = D.acautoseq
				JOIN ACACCMNGM E
					ON c.acacccode = E.acccode
					   AND E.dcdiv = CASE WHEN c.dcdiv IN ('1', '4') THEN '1' ELSE '2' END
					   AND D.mngclucode = E.mngclucode
				-- 카드수금인경우 미수금의 거래처를 연결거래처로 변경

				LEFT JOIN CMCOMMONM f
					ON A.acatrulecode = 'C01002'
					   AND c.acacccode = p_acccode1
					   AND f.cmmcode = 'AC17'
					   AND A.cardcomp = f.divcode
				LEFT JOIN CMCUSTM G
					ON A.acatrulecode = 'C01002'
					   AND c.acacccode = p_acccode1
					   AND NVL(TRIM(f.remark), ' ') = G.custcode
		 WHERE	A.compcode = p_compcode
				AND A.actrnstate IN ('1', '3')
				AND A.acattype LIKE p_slipdiv);

	-- 전표상세임시파일생성(부문:수금)
	INSERT INTO VGT.TT_ACACC0047PL_ACORDD02
		SELECT A.compcode,
			   REPLACE(A.slipindate, '-', '') || A.acattype || b.slipinnum slipinno,
			   ROW_NUMBER() OVER (PARTITION BY A.slipindate || A.acattype || b.slipinnum ORDER BY A.acatno, c.acautoseq),
			   c.dcdiv,
			   c.acacccode acccode,
			   NVL(D.plantcode, A.plantcode) plantcode,
			   CASE
				   WHEN c.dcdiv IN ('1', '4')
				   THEN -- 차변,출금
					   fnAcAutoORDamt(c.amtdiv,
									  c.accamtdiv,
									  c.acccalcdiv,
									  c.accsamtdiv,
									  A.trn1amt,
									  A.trn2amt,
									  A.trn3amt,
									  A.trn4amt,
									  A.trn5amt,
									  A.trn6amt,
									  A.trn7amt,
									  A.trn8amt,
									  A.trn9amt,
									  A.trn10amt,
									  A.trn11amt,
									  A.trn12amt,
									  A.trn13amt,
									  A.trn14amt,
									  A.trn15amt,
									  A.trn16amt,
									  A.trn17amt,
									  A.trn18amt,
									  A.trn19amt,
									  A.trn20amt,
									  A.trn21amt,
									  A.trn22amt,
									  A.trn23amt,
									  A.trn24amt,
									  A.trn25amt,
									  A.trn26amt,
									  A.trn27amt,
									  A.trn28amt,
									  A.trn29amt,
									  A.trn30amt)
				   ELSE
					   0
			   END
				   debamt,
			   CASE
				   WHEN c.dcdiv IN ('2', '3')
				   THEN -- 대변,입금
					   fnAcAutoORDamt(c.amtdiv,
									  c.accamtdiv,
									  c.acccalcdiv,
									  c.accsamtdiv,
									  A.trn1amt,
									  A.trn2amt,
									  A.trn3amt,
									  A.trn4amt,
									  A.trn5amt,
									  A.trn6amt,
									  A.trn7amt,
									  A.trn8amt,
									  A.trn9amt,
									  A.trn10amt,
									  A.trn11amt,
									  A.trn12amt,
									  A.trn13amt,
									  A.trn14amt,
									  A.trn15amt,
									  A.trn16amt,
									  A.trn17amt,
									  A.trn18amt,
									  A.trn19amt,
									  A.trn20amt,
									  A.trn21amt,
									  A.trn22amt,
									  A.trn23amt,
									  A.trn24amt,
									  A.trn25amt,
									  A.trn26amt,
									  A.trn27amt,
									  A.trn28amt,
									  A.trn29amt,
									  A.trn30amt)
				   ELSE
					   0
			   END
				   creamt,
			   CASE WHEN c.acacccode = p_acccode5 THEN A.userdef10code ELSE NVL(A.remark, b.remark1) END remark1,
			   NVL(A.remark2, b.remark2) remark2,
			   A.taxno,
			   CASE WHEN p_colseq = 'Y' THEN A.trn30amt ELSE 0 END crtord
		FROM   ACAUTOORDT A
			   JOIN VGT.TT_ACACC0047PL_ACAUTOORDT01 b
				   ON A.compcode = b.compcode
					  AND A.plantcode = b.plantcode
					  AND A.acattype = b.acattype
					  AND A.slipindate = b.slipindate
					  AND CASE
							  WHEN UPPER(p_salload) = 'EMPCODE'
								   AND A.acattype = 'S'
							  THEN
								  A.empcode
							  WHEN UPPER(p_salload) = 'IEMPCODE'
								   AND A.acattype = 'S'
							  THEN
								  A.iempcode
							  WHEN UPPER(p_salload) = 'NEWLOAD'
								   AND A.acattype = 'S'
							  THEN
								  A.iempcode
							  WHEN UPPER(p_salload) = 'ACATRULECODE'
								   AND A.acattype = 'S'
							  THEN
								  A.acatrulecode || A.iempcode
							  WHEN UPPER(p_colload) = 'EMPCODE'
								   AND A.acattype = 'C'
							  THEN
								  A.empcode
							  WHEN UPPER(p_colload) = 'IEMPCODE'
								   AND A.acattype = 'C'
							  THEN
								  A.iempcode
							  WHEN UPPER(p_colload) = 'NEWLOAD'
								   AND A.acattype = 'C'
							  THEN
								  A.iempcode
							  WHEN UPPER(p_colload) = 'ACATRULECODE'
								   AND A.acattype = 'C'
							  THEN
								  A.ACATRULECODE || A.iempcode
							  WHEN UPPER(p_expload) = 'IMPORTSHTNO'
								   AND A.acattype = 'N'
							  THEN
								  A.billno
							  ELSE
								  ''
						  END = b.acatrulecode
			   JOIN ACAUTORULESM c ON A.acatrulecode = c.acautorcode
			   LEFT JOIN (SELECT A.divcode, b.plantcode
						  FROM	 CMCOMMONM A JOIN CMPLANTM b ON A.filter2 = b.plantcode
						  WHERE  A.cmmcode = 'AC201') D
				   ON A.acattype = D.divcode
		WHERE  A.compcode = p_compcode
			   AND A.actrnstate IN ('1', '3')
			   AND A.acattype LIKE p_slipdiv
			   AND (TRIM(p_salload) IS NOT NULL
					OR TRIM(p_colload) IS NOT NULL
					OR TRIM(p_expload) IS NOT NULL);

	-- 관리항목임시파일생성(부문:수금)
	INSERT INTO VGT.TT_ACACC0047PL_ACORDS03
		SELECT A.compcode,
			   A.slipinno2,
			   A.slipinseq2,
			   b.mngclucode,
			   D.seq,
			   fnAcAutoORDval(b.mngcluvaldiv,
							  A.userdef1code,
							  A.userdef2code,
							  A.userdef3code,
							  A.userdef4code,
							  A.userdef5code,
							  A.userdef6code,
							  A.userdef7code,
							  A.userdef8code,
							  A.userdef9code,
							  A.userdef10code,
							  A.userdef11code,
							  A.userdef12code,
							  A.userdef13code,
							  A.userdef14code,
							  A.userdef15code,
							  A.userdef16code,
							  A.userdef17code,
							  A.userdef18code,
							  A.userdef19code,
							  A.userdef20code,
							  A.userdef21code,
							  A.userdef22code,
							  A.userdef23code,
							  A.userdef24code,
							  A.userdef25code,
							  A.userdef26code,
							  A.userdef27code,
							  A.userdef28code,
							  A.userdef29code,
							  A.userdef30code,
							  A.deptcode,
							  A.custcode,
							  A.taxno,
							  A.billno,
							  A.issdate,
							  A.expdate,
							  A.cardno,
							  A.empcode,
							  A.cardokno)
				   mngcluval,
			   fnAcAutoORDval(b.mngcludecdiv,
							  A.userdef1code,
							  A.userdef2code,
							  A.userdef3code,
							  A.userdef4code,
							  A.userdef5code,
							  A.userdef6code,
							  A.userdef7code,
							  A.userdef8code,
							  A.userdef9code,
							  A.userdef10code,
							  A.userdef11code,
							  A.userdef12code,
							  A.userdef13code,
							  A.userdef14code,
							  A.userdef15code,
							  A.userdef16code,
							  A.userdef17code,
							  A.userdef18code,
							  A.userdef19code,
							  A.userdef20code,
							  A.userdef21code,
							  A.userdef22code,
							  A.userdef23code,
							  A.userdef24code,
							  A.userdef25code,
							  A.userdef26code,
							  A.userdef27code,
							  A.userdef28code,
							  A.userdef29code,
							  A.userdef30code,
							  A.deptcode,
							  A.custcode,
							  A.taxno,
							  A.billno,
							  A.issdate,
							  A.expdate,
							  A.cardno,
							  A.empcode,
							  A.cardokno)
				   mngcludec
		FROM   (SELECT A.*,
					   REPLACE(A.slipindate, '-', '') || A.acattype || b.slipinnum slipinno2,
					   ROW_NUMBER() OVER (PARTITION BY A.slipindate || A.acattype || b.slipinnum ORDER BY A.acatno, c.acautoseq) slipinseq2,
					   c.acautorcode,
					   c.acautoseq,
					   c.acacccode,
					   c.dcdiv
				FROM   ACAUTOORDT A
					   JOIN VGT.TT_ACACC0047PL_ACAUTOORDT01 b
						   ON A.compcode = b.compcode
							  AND A.plantcode = b.plantcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND CASE
									  WHEN UPPER(p_salload) = 'EMPCODE'
										   AND A.acattype = 'S'
									  THEN
										  A.empcode
									  WHEN UPPER(p_salload) = 'IEMPCODE'
										   AND A.acattype = 'S'
									  THEN
										  A.iempcode
									  WHEN UPPER(p_salload) = 'NEWLOAD'
										   AND A.acattype = 'S'
									  THEN
										  A.iempcode
									  WHEN UPPER(p_salload) = 'ACATRULECODE'
										   AND A.acattype = 'S'
									  THEN
										  A.acatrulecode || A.iempcode
									  WHEN UPPER(p_colload) = 'EMPCODE'
										   AND A.acattype = 'C'
									  THEN
										  A.empcode
									  WHEN UPPER(p_colload) = 'IEMPCODE'
										   AND A.acattype = 'C'
									  THEN
										  A.IEMPCODE
									  WHEN UPPER(p_colload) = 'NEWLOAD'
										   AND A.acattype = 'C'
									  THEN
										  A.iempcode
									  WHEN UPPER(p_colload) = 'ACATRULECODE'
										   AND A.acattype = 'C'
									  THEN
										  A.acatrulecode || A.iempcode
									  WHEN UPPER(p_expload) = 'IMPORTSHTNO'
										   AND A.acattype = 'N'
									  THEN
										  A.billno
									  ELSE
										  ''
								  END = b.acatrulecode
					   JOIN ACAUTORULESM c ON A.acatrulecode = c.acautorcode
				WHERE  A.compcode = p_compcode
					   AND A.actrnstate IN ('1', '3')
					   AND A.acattype LIKE p_slipdiv
					   AND (TRIM(p_salload) IS NOT NULL
							OR TRIM(p_colload) IS NOT NULL
							OR TRIM(p_expload) IS NOT NULL)) A
			   JOIN ACAUTORULEDS b
				   ON A.acautorcode = b.acautorcode
					  AND A.acautoseq = b.acautoseq
			   JOIN ACACCMNGM D
				   ON A.acacccode = D.acccode
					  AND D.dcdiv = CASE WHEN A.dcdiv IN ('1', '4') THEN '1' ELSE '2' END
					  AND b.mngclucode = D.mngclucode;

	FOR REC IN (SELECT b.compcode,
					   b.slipinno,
					   b.acautoseq,
					   b.mngclucode,
					   b.seq,
					   b.mngcluval,
					   b.mngcludec
				FROM   VGT.TT_ACACC0047PL_ACORDD02 A
					   JOIN VGT.TT_ACACC0047PL_ACORDS03 b
						   ON A.compcode = b.compcode
							  AND A.slipinno = b.slipinno
							  AND A.acautoseq = b.acautoseq
					   LEFT JOIN CMCOMMONM c
						   ON c.cmmcode = 'AC251'
							  AND c.hdivcode IN ('04', '12')
							  AND A.acccode = c.filter1
				WHERE  A.debamt = 0
					   AND A.creamt = 0
					   AND c.cmmcode IS NULL)
	LOOP
        DELETE FROM VGT.TT_ACACC0047PL_ACORDS03 A
        WHERE		NVL(a.compcode, ' ') = NVL(rec.compcode, ' ')
                    AND NVL(a.slipinno, ' ') = NVL(rec.slipinno, ' ')
                    AND NVL(a.acautoseq, 0) = NVL(rec.acautoseq, 0)
                    AND NVL(a.mngclucode, ' ') = NVL(rec.mngclucode, ' ')
                    AND NVL(a.seq, 0) = NVL(rec.seq, 0)
                    AND NVL(a.mngcluval, ' ') = NVL(rec.mngcluval, ' ')
                    AND NVL(a.mngcludec, ' ') = NVL(rec.mngcludec, ' ');
	END LOOP;


	-- 차/대변 금액이 0인것은 삭제
	FOR REC IN (SELECT A.COMPCODE,
					   A.SLIPINNO,
					   A.ACAUTOSEQ,
					   A.DCDIV,
					   A.ACCCODE,
					   A.PLANTCODE,
					   A.DEBAMT,
					   A.CREAMT,
					   A.REMARK1,
					   A.REMARK2,
					   A.TAXNO,
					   A.CRTORD
				FROM   VGT.TT_ACACC0047PL_ACORDD02 A
					   LEFT JOIN CMCOMMONM c
						   ON c.cmmcode = 'AC251'
							  AND c.hdivcode IN ('04', '12')
							  AND A.acccode = c.filter1
				WHERE  A.debamt = 0
					   AND A.creamt = 0
					   AND c.cmmcode IS NULL)
	LOOP
        DELETE FROM VGT.TT_ACACC0047PL_ACORDD02 A
        WHERE		NVL(a.compcode, ' ') = NVL(rec.compcode, ' ')
                    AND NVL(a.slipinno, ' ') = NVL(rec.slipinno, ' ')
                    AND NVL(a.dcdiv, ' ') = NVL(rec.dcdiv, ' ')
                    AND NVL(a.acccode, ' ') = NVL(rec.acccode, ' ')
                    AND NVL(a.plantcode, ' ') = NVL(rec.plantcode, ' ')
                    AND NVL(a.remark1, ' ') = NVL(rec.remark1, ' ')
                    AND NVL(a.remark2, ' ') = NVL(rec.remark2, ' ')
                    AND NVL(a.taxno, ' ') = NVL(rec.taxno, ' ')
                    AND NVL(a.acautoseq, 0) = NVL(rec.acautoseq, 0)
                    AND NVL(a.debamt, 0) = NVL(rec.debamt, 0)
                    AND NVL(a.creamt, 0) = NVL(rec.creamt, 0)
                    AND NVL(a.crtord, 0) = NVL(rec.crtord, 0);
	END LOOP;

	-- 영업거래처 대표거래처로 변경
	MERGE INTO VGT.TT_ACACC0047PL_ACORDS03 A
	USING	   (SELECT A.COMPCODE,
					   A.SLIPINNO,
					   A.ACAUTOSEQ,
					   A.MNGCLUCODE,
					   A.SEQ,
					   A.MNGCLUVAL,
					   A.MNGCLUDEC,
					   NVL(c.custcode, A.mngcluval) AS pos_2,
					   NVL(c.custname, A.mngcludec) AS pos_3
				FROM   VGT.TT_ACACC0047PL_ACORDS03 A
					   JOIN CMCUSTM b ON A.mngcluval = b.custcode
					   JOIN CMCUSTM c ON b.custmajorcode = c.custcode
				WHERE  A.mngclucode = 'S010'
					   AND (p_salecust = 'Y'
							AND A.slipinno LIKE '%S%'
							OR p_colcust = 'Y'
							   AND A.slipinno LIKE '%C%')) src
	ON		   (NVL(A.COMPCODE, ' ') = NVL(SRC.COMPCODE, ' ')
				AND NVL(A.SLIPINNO, ' ') = NVL(SRC.SLIPINNO, ' ')
				AND NVL(A.ACAUTOSEQ, 0) = NVL(SRC.ACAUTOSEQ, 0)
				AND NVL(A.MNGCLUCODE, ' ') = NVL(SRC.MNGCLUCODE, ' ')
				AND NVL(A.SEQ, 0) = NVL(SRC.SEQ, 0))
	WHEN MATCHED
	THEN
		UPDATE SET A.mngcluval = pos_2, A.mngcludec = pos_3;

	-- 전표상세일련번호재생성(개별)
	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACORDD03 ';

	INSERT INTO VGT.TT_ACACC0047PL_ACORDD03
		SELECT compcode,
			   slipinno,
			   ROW_NUMBER() OVER (PARTITION BY compcode, slipinno ORDER BY crtord, acautoseq) slipinseq,
			   dcdiv,
			   acccode,
			   plantcode,
			   debamt,
			   creamt,
			   remark1,
			   remark2,
			   taxno,
			   acautoseq
		FROM   VGT.TT_ACACC0047PL_ACORDD02;

	-- 전표상세생성(개별)
	INSERT INTO ACORDD(compcode,
					   slipinno,
					   slipinseq,
					   dcdiv,
					   acccode,
					   plantcode,
					   debamt,
					   creamt,
					   slipdate,
					   slipnum,
					   remark1,
					   remark2,
					   taxno,
					   datadiv,
					   rptseq,
					   insertdt,
					   iempcode)
		(SELECT A.compcode,
				A.slipinno,
				A.slipinseq,
				A.dcdiv,
				A.acccode,
				A.plantcode,
				A.debamt,
				A.creamt,
				b.slipdate,
				b.slipnum,
				A.remark1,
				A.remark2,
				CASE
					WHEN NVL(A.acccode, ' ') LIKE NVL(p_acccode2, '%') || '%'
						 OR NVL(A.acccode, ' ') LIKE NVL(p_acccode3, '%') || '%'
					THEN
						NVL(A.taxno, '')
					ELSE
						''
				END
					col,
				'',
				A.slipinseq,
				p_insertdt,
				p_iempcode
		 FROM	VGT.TT_ACACC0047PL_ACORDD03 A JOIN ACORDM b ON A.slipinno = b.slipinno);

	-- 전표관리생성(개별)
	INSERT INTO ACORDS(compcode,
					   slipinno,
					   slipinseq,
					   mngclucode,
					   seq,
					   mngcluval,
					   mngcludec,
					   insertdt,
					   iempcode)
		(SELECT A.compcode,
				A.slipinno,
				b.slipinseq,
				A.mngclucode,
				A.seq,
				A.mngcluval,
				A.mngcludec,
				p_insertdt,
				p_iempcode
		 FROM	VGT.TT_ACACC0047PL_ACORDS03 A
				JOIN VGT.TT_ACACC0047PL_ACORDD03 b
					ON A.compcode = b.compcode
					   AND A.slipinno = b.slipinno
					   AND A.acautoseq = b.acautoseq);



	--  회계 자동전표 처리 모니터링 변경
	MERGE INTO ACAUSLIPM b
	USING	   (SELECT B.COMPCODE,
					   B.SLIPINDATE,
					   B.ACCDIV,
					   B.ACAUTORCODE,
					   A.iempcode,
					   TO_CHAR(A.insertdt, 'YYYY-MM-DD') AS pos_3,
					   TO_CHAR(SYSDATE, 'YYYY-MM-DD') AS pos_5,
					   SYSDATE
				FROM   (SELECT	 compcode,
								 slipindate,
								 acattype,
								 acatrulecode,
								 MAX(iempcode) iempcode,
								 MAX(insertdt) insertdt
						FROM	 ACAUTOORDT
						WHERE	 ACAUTOORDT.compcode = p_compcode
								 AND ACAUTOORDT.actrnstate IN ('1', '3', '4')
								 AND ACAUTOORDT.acattype LIKE p_slipdiv
						GROUP BY ACAUTOORDT.compcode, ACAUTOORDT.slipindate, ACAUTOORDT.acattype, ACAUTOORDT.acatrulecode) A
					   JOIN ACAUSLIPM b
						   ON A.compcode = b.compcode
							  AND A.slipindate = b.slipindate
							  AND A.acattype = b.accdiv
							  AND A.acatrulecode = b.acautorcode) src
	ON		   (B.COMPCODE = SRC.COMPCODE
				AND B.SLIPINDATE = SRC.SLIPINDATE
				AND B.ACCDIV = SRC.ACCDIV
				AND B.ACAUTORCODE = SRC.ACAUTORCODE)
	WHEN MATCHED
	THEN
		UPDATE SET b.sndempcode = src.iempcode,
				   b.snddate = pos_3,
				   b.trnempcode = p_iempcode,
				   b.trndate = pos_5,
				   b.updatedt = SYSDATE,
				   b.uempcode = p_iempcode;

	-- 회계 자동전표 처리 모니터링 입력
	INSERT INTO ACAUSLIPM(compcode,
						  slipindate,
						  accdiv,
						  acautorcode,
						  sndempcode,
						  snddate,
						  trnempcode,
						  trndate,
						  insertdt,
						  iempcode)
		(SELECT A.compcode,
				A.slipindate,
				A.acattype,
				A.acatrulecode,
				A.iempcode,
				TO_CHAR(A.insertdt, 'YYYY-MM-DD'),
				p_iempcode,
				TO_CHAR(SYSDATE, 'YYYY-MM-DD'),
				SYSDATE,
				p_iempcode
		 FROM	(SELECT   compcode,
						  slipindate,
						  acattype,
						  acatrulecode,
						  MAX(iempcode) iempcode,
						  MAX(insertdt) insertdt
				 FROM	  ACAUTOORDT
				 WHERE	  compcode = p_compcode
						  AND actrnstate IN ('1', '3', '4')
						  AND acattype LIKE p_slipdiv
				 GROUP BY compcode, slipindate, acattype, acatrulecode) A
				LEFT JOIN ACAUSLIPM b
					ON A.compcode = b.compcode
					   AND A.slipindate = b.slipindate
					   AND A.acattype = b.accdiv
					   AND A.acatrulecode = b.acautorcode
		 WHERE	b.compcode IS NULL);

	OPEN SPACC_CURSOR FOR
		SELECT	 DISTINCT REPLACE(A.slipindate, '-', '') || A.acattype || NVL(b.slipinnum, c.slipinnum) slipinno
		FROM	 ACAUTOORDT A
				 LEFT JOIN VGT.TT_ACACC0047PL_ACAUTOORDT01 b
					 ON A.compcode = b.compcode
						AND A.plantcode = b.plantcode
						AND A.acattype = b.acattype
						AND A.slipindate = b.slipindate
						AND CASE
								WHEN p_salload = 'empcode'
									 AND A.acattype = 'S'
								THEN
									A.empcode
								WHEN p_salload = 'iempcode'
									 AND A.acattype = 'S'
								THEN
									A.iempcode
								WHEN p_salload = 'newload'
									 AND A.acattype = 'S'
								THEN
									A.iempcode
								WHEN p_salload = 'acatrulecode'
									 AND A.acattype = 'S'
								THEN
									A.acatrulecode || A.iempcode
								WHEN p_colload = 'empcode'
									 AND A.acattype = 'C'
								THEN
									A.empcode
								WHEN p_colload = 'iempcode'
									 AND A.acattype = 'C'
								THEN
									A.iempcode
								WHEN p_colload = 'newload'
									 AND A.acattype = 'C'
								THEN
									A.iempcode
								WHEN p_colload = 'acatrulecode'
									 AND A.acattype = 'C'
								THEN
									A.acatrulecode || A.iempcode
								WHEN p_expload = 'importshtno'
									 AND A.acattype = 'N'
								THEN
									A.billno
								WHEN A.acattype = 'H'
								THEN
									A.plantcode
								ELSE
									''
							END = b.acatrulecode
				 LEFT JOIN VGT.TT_ACACC0047PL_ACAUTOORDT02 c
					 ON A.compcode = c.compcode
						AND A.acattype = c.acattype
						AND A.slipindate = c.slipindate
						AND A.acatno = c.acatno
		WHERE	 A.compcode = p_compcode
				 AND A.actrnstate IN ('1', '3')
				 AND A.acattype LIKE p_slipdiv
				 AND A.acattype = 'N'
				 AND TRIM(p_expload) IS NOT NULL
		ORDER BY slipinno;

	LOOP
		FETCH SPACC_CURSOR INTO p_slipinno;

		EXIT WHEN SPACC_CURSOR%NOTFOUND;
		spACfund0021P(p_div => 'C2',
							p_compcode => p_compcode,
							p_slipinno => p_slipinno,
							p_iempcode => p_iempcode,
							p_userid => p_userid,
							p_reasondiv => p_reasondiv,
							p_reasontext => p_reasontext,
							MESSAGE => MESSAGE,
							IO_CURSOR => IO_CURSOR);
	END LOOP;

	CLOSE SPACC_CURSOR;


	-- 수금전표 생성시 어음생성
	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0047PL_ACBILLM ';

	INSERT INTO VGT.TT_ACACC0047PL_ACBILLM
		(SELECT   A.compcode,
				  A.billno,
				  MAX(b.coldiv) billdiv,
				  MIN(b.issdate) issdate,
				  MIN(b.coldate) coldate,
				  MAX(b.expdate) expdate,
				  SUM(b.colamt) billamt,
				  MIN(b.custcode) custcode,
				  MAX(b.issempnm) issempnm,
				  MAX(b.paybank) paybank,
				  MAX(b.deptcode) deptcode,
				  MAX(b.plantcode) plantcode,
				  MAX(b.tasooyn) tasooyn
		 FROM	  ACAUTOORDT A
				  JOIN SLCOLM b
					  ON A.acatno = b.colno
						 AND b.coldiv LIKE '3%'
		 WHERE	  A.compcode = p_compcode
				  AND A.acattype LIKE p_slipdiv
				  AND A.acattype = 'C'
				  AND A.actrnstate = '1'
				  AND TRIM(A.billno) IS NOT NULL
		 GROUP BY A.compcode, A.billno);

	MERGE INTO ACBILLM A
	USING	   (SELECT A.COMPCODE, A.BILLNO, b.billamt, SYSDATE
				FROM   ACBILLM A
					   JOIN (SELECT   A.billno, SUM(b.colamt) billamt
							 FROM	  VGT.TT_ACACC0047PL_ACBILLM A JOIN SLCOLM b ON A.billno = b.billno
							 GROUP BY A.billno) b
						   ON A.billno = b.billno) src
	ON		   (A.COMPCODE = SRC.COMPCODE
				AND A.BILLNO = SRC.BILLNO)
	WHEN MATCHED
	THEN
		UPDATE SET A.billamt = src.billamt, A.updatedt = SYSDATE, A.uempcode = p_iempcode;

	INSERT INTO ACBILLM(compcode,
						billno,
						billcls, --어음구분 AC32
						billdiv, --어음종류 SL18
						billtype,
						issdate, --발행일자
						coldate, --수취일자
						expdate, --만기일자
						billamt, --금액
						custcode,
						issempnm,
						bankcode,
						paybank,
						deptcode,
						plantcode,
						tasooyn,
						issdiv, --발행구분 AC31
						billstate, --어음상태 AC53
						accountno,
						billremark,
						insertdt,
						iempcode)
		(SELECT A.compcode,
				A.billno,
				'1',
				A.billdiv,
				'',
				A.issdate,
				A.coldate,
				A.expdate,
				A.billamt,
				A.custcode,
				A.issempnm,
				A.paybank,
				'',
				A.deptcode,
				A.plantcode,
				A.tasooyn,
				'A',
				'1',
				'',
				'',
				SYSDATE,
				p_iempcode
		 FROM	VGT.TT_ACACC0047PL_ACBILLM A LEFT JOIN ACBILLM b ON A.billno = b.billno
		 WHERE	b.billno IS NULL);



	-- 해당일자 회계전표유형(신규,수정)을 모두 완료로 변경한다.
	MERGE INTO ACAUTOORDT A
	USING	   (SELECT A.COMPCODE, A.ACATTYPE, A.ACATNO, '2', REPLACE(A.slipindate, '-', '') || A.acattype || NVL(b.slipinnum, c.slipinnum) AS pos_3
				FROM   ACAUTOORDT A
					   LEFT JOIN VGT.TT_ACACC0047PL_ACAUTOORDT01 b
						   ON A.compcode = b.compcode
							  AND A.plantcode = b.plantcode
							  AND A.acattype = b.acattype
							  AND A.slipindate = b.slipindate
							  AND CASE
									  WHEN UPPER(p_salload) = 'EMPCODE'
										   AND A.acattype = 'S'
									  THEN
										  A.empcode
									  WHEN UPPER(p_salload) = 'IEMPCODE'
										   AND A.acattype = 'S'
									  THEN
										  A.iempcode
									  WHEN UPPER(p_salload) = 'NEWLOAD'
										   AND A.acattype = 'S'
									  THEN
										  A.iempcode
									  WHEN UPPER(p_salload) = 'ACATRULECODE'
										   AND A.acattype = 'S'
									  THEN
										  A.acatrulecode || A.iempcode
									  WHEN UPPER(p_colload) = 'EMPCODE'
										   AND A.acattype = 'C'
									  THEN
										  A.empcode
									  WHEN UPPER(p_colload) = 'IEMPCODE'
										   AND A.acattype = 'C'
									  THEN
										  A.iempcode
									  WHEN UPPER(p_colload) = 'NEWLOAD'
										   AND A.acattype = 'C'
									  THEN
										  A.iempcode
									  WHEN UPPER(p_colload) = 'ACATRULECODE'
										   AND A.acattype = 'C'
									  THEN
										  A.acatrulecode || A.iempcode
									  WHEN UPPER(p_expload) = 'IMPORTSHTNO'
										   AND A.acattype = 'N'
									  THEN
										  A.billno
									  WHEN A.acattype = 'H'
									  THEN
										  A.plantcode
									  ELSE
										  ''
								  END = b.acatrulecode
					   LEFT JOIN VGT.TT_ACACC0047PL_ACAUTOORDT02 c
						   ON A.compcode = c.compcode
							  AND A.acattype = c.acattype
							  AND A.slipindate = c.slipindate
							  AND A.acatno = c.acatno
				WHERE  A.compcode = p_compcode
					   AND A.actrnstate IN ('1', '3')
					   AND A.acattype LIKE p_slipdiv) src
	ON		   (A.COMPCODE = SRC.COMPCODE
				AND A.ACATTYPE = SRC.ACATTYPE
				AND A.ACATNO = SRC.ACATNO)
	WHEN MATCHED
	THEN
		UPDATE SET A.actrnstate = '2', A.slipinno = pos_3;

	-- 해당일자 회계전표유형(삭제)을 삭제한다.
	FOR REC IN (SELECT A.COMPCODE, A.ACATTYPE, A.ACATNO
				FROM   ACAUTOORDT A
				WHERE  A.compcode = p_compcode
					   AND A.actrnstate = '4'
					   AND A.acattype LIKE p_slipdiv)
	LOOP
		DELETE FROM ACAUTOORDT A
		WHERE		A.COMPCODE = REC.COMPCODE
					AND A.ACATTYPE = REC.ACATTYPE
					AND A.ACATNO = REC.ACATNO;
	END LOOP;


	-- 회계전표 잔액 집계처리
	spACord0000MM(  p_div => 'T',
                    p_compcode => p_compcode, -- 회사코드
                    p_closediv => '10', -- 결산구분(운영)
                    p_strslipym => p_strartym, -- 결의전표번호
                    p_endslipym => p_endym, -- 결의전표번호
                    p_userid => p_userid,
                    p_reasondiv => p_reasondiv,
                    p_reasontext => p_reasontext,
                    MESSAGE => MESSAGE,
                    IO_CURSOR => IO_CURSOR);
	-- 회계전표 예산 집계처리
	spACbudg0000MM(  p_div => 'TO',
                     p_compcode => p_compcode, -- 회사코드
                     p_strbudgym => p_strartym, -- 결의전표번호
                     p_endbudgym => p_endym, -- 결의전표번호
                     p_userid => p_userid,
                     p_reasondiv => p_reasondiv,
                     p_reasontext => p_reasontext,
                     MESSAGE => MESSAGE,
                     IO_CURSOR => IO_CURSOR);

	IF(TRIM(p_strartym) IS NULL) THEN
    	p_strartym := '0000-00';
    END IF;
	---- 트랜젝션을 승인한다.
    
	--Rollback Tran
	MESSAGE := p_strartym || '-01' || TO_CHAR(LAST_DAY(TO_DATE(p_endym || '-01', 'YYYY-MM-DD')), 'YYYY-MM-DD') || TO_CHAR(p_proccnt);

   <<LASTLINE>>
    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
