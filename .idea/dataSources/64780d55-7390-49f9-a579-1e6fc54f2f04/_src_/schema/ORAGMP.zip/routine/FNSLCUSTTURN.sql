CREATE FUNCTION        fnSLcustTURN
-- ---------------------------------------------------------------
-- 함 수 명              : [dbo].[fnSLcustTURN]
-- 작 성 자           : 민승기
-- 작성일자           : 2014-01-13

-- 수정내용              : turncnt - 여신회전일 , turndccnt - 잔고회전일 임 (KB Pharm 여신회전일이 주이다.
-- ---------------------------------------------------------------
-- 함수설명              : 지정일자기준의 거래처 회전일을
--                            계산하여 테이블로 리턴
--        수 정 일      : 2014-02-14
--                        영업영역 파라메터 추가
--                        잔고,미결어음,총잔고 추가
--                        회전일 변화 계산 추가
-- ---------------------------------------------------------------
-- select * from [dbo].[fnSLcustTURN]('1002','%','%','%','2014-05-31',0)
/*

select    empcode, deptcode, *
    from    cmcustm 
        where    custcode = '2000000131'

*/

(
    p_plantcode IN VARCHAR2,
    p_custcode IN VARCHAR2,-- 전체는 '%'
    p_utdiv     IN VARCHAR2,-- 전체는 '%'
    p_orderdiv  IN VARCHAR2,-- 전체는 '%'
    p_orderdate IN VARCHAR2,
    p_amount    IN FLOAT
)
RETURN FN_SLCUSTTURNE_TABLE

AS
    
    PRAGMA AUTONOMOUS_TRANSACTION;
    
    p_startdate VARCHAR2(10); -- 작업일자 당월   1일    '2013-01-01'
    p_tomorrow  VARCHAR2(10); -- 작업일자 다음날짜        '2013-01-21'
    p_firstdate VARCHAR2(10); -- 작업일자 5년전 당일    '2008-01-20'
    p_yearmonth VARCHAR2(7);  -- 작업일자 당월        '2013-01'
    p_magamyymm VARCHAR2(7);
    
    ip_custcode        VARCHAR2(20) := '';
    ip_plantcode       VARCHAR2(4)  := '';
    ip_appdate         VARCHAR2(10) := '';
    ip_acramt          NUMBER := 0;
    ip_balance         NUMBER := 0;
    ip_pendbillcol     NUMBER := 0;
    ip_totbalance      NUMBER := 0;
    
    

    i NUMBER := 1;
    
    --함수내에서 변수 저장용 변수 초기화
    slcustTurneListRecode FN_SLCUSTTURNE_TABLE := FN_SLCUSTTURNE_TABLE(); 

BEGIN

    p_startdate := SUBSTR(p_orderdate, 1, 7) || '-01' ;
    p_tomorrow  := TO_CHAR(TO_DATE(p_orderdate, 'YYYY-MM-DD')+1, 'YYYY-MM-DD') ;
       
    p_firstdate := TO_CHAR(ADD_MONTHS(TO_DATE(p_orderdate, 'YYYY-MM-DD'), -12*5), 'YYYY-MM-DD') ;
    p_yearmonth := SUBSTR(p_orderdate, 1, 7) ;


    -- 대상거래처 목록 ======================================================
    EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_FNSLCUSTTURNE_DUAL';
    
    INSERT INTO VGT.TT_FNSLCUSTTURNE_DUAL ( 
        SELECT  c.custcode 
                , c.plantcode 
                , 0 AS balance  
                , 0 AS balancebill
                , NULL AS yearmonth
        FROM    CMCUSTM c
        WHERE   c.plantcode LIKE p_plantcode
                AND ( p_custcode = '%' OR c.custcode = p_custcode )
                AND ( p_utdiv = '%' OR c.utdiv = p_utdiv ) 
    ) ;
    
    
    
                 
    -- 거래처 잔고및 미결어음 ===============================================
    FOR  rec IN ( 
        SELECT  NVL(MAX(A.yearmonth), '') AS alias1  
        FROM    SLRESULTM A
                JOIN VGT.TT_FNSLCUSTTURNE_DUAL c ON A.custcode = c.custcode
                                                    AND A.plantcode = c.plantcode
        WHERE   A.yearmonth < p_yearmonth
    )
    LOOP
        p_magamyymm := rec.alias1 ;
    END LOOP;
    
    IF ( p_magamyymm IS NULL ) THEN
        
        p_magamyymm := '2009-12' ;-- 시작일자를 체크하여야 한다.
       
    END IF;
   

   
    MERGE INTO VGT.TT_FNSLCUSTTURNE_DUAL TG
    USING (   
            SELECT  --UPDATE DATA
                    NVL(A.balance, 0) AS balance
                    , NVL(A.pendbillcol, 0) AS pendbillcol
                    --COMPARE DATA
                    , c.custcode
                    , c.plantcode
                    , A.yearmonth
            FROM    (   SELECT    c.custcode 
                                , c.plantcode 
                                , SUM(A.balance)      AS balance  
                                , SUM(A.pendbillcol)  AS pendbillcol  
                                , p_magamyymm         AS yearmonth
                        FROM    SLRESULTM A
                                JOIN VGT.TT_FNSLCUSTTURNE_DUAL c ON A.custcode = c.custcode
                                                                    AND A.plantcode = c.plantcode
                        WHERE   A.yearmonth = p_magamyymm
                                AND A.orderdiv LIKE p_orderdiv
                        GROUP BY c.custcode,c.plantcode ) A
                    JOIN VGT.TT_FNSLCUSTTURNE_DUAL c ON A.custcode = c.custcode
                                                        AND A.plantcode = c.plantcode
                    LEFT OUTER JOIN SLTURNCUSTM d ON A.yearmonth = d.yearmonth
                                                     AND    A.custcode = d.custcode
                                                     AND A.plantcode = d.plantcode
                    LEFT OUTER JOIN CMCUSTM d1 ON A.custcode = d1.custcode
                                                  AND A.plantcode = d1.plantcode                                                                                                                
    ) SRC ON (TG.custcode = SRC.custcode AND TG.plantcode = SRC.plantcode  )
    WHEN MATCHED THEN UPDATE SET    TG.balance = SRC.balance
                                    , TG.pendbillcol = src.pendbillcol 
                                    , TG.yearmonth = src.yearmonth ;
 
    
                                
    MERGE INTO VGT.TT_FNSLCUSTTURNE_DUAL TG
    USING (
            SELECT  --UPDATE DATA
                    c.balance + NVL(A.maechul, 0)      AS balance
                    , c.pendbillcol + NVL(A.bilcol, 0) AS pendbillcol
                    --COMPARE DATA
                    , A.custcode
                    , A.plantcode
            FROM    (   SELECT  A.custcode ,
                                A.plantcode ,
                                SUM(A.maechul) AS maechul  ,
                                SUM(A.bilcol)  AS bilcol  
                        FROM    (   SELECT  c.custcode ,
                                            c.plantcode ,
                                            (   CASE WHEN A.saldiv LIKE 'A%' THEN b.totamt
                                                     WHEN A.saldiv LIKE 'B%' THEN -b.totamt
                                                     ELSE 0
                                                 END) maechul  ,
                                            0 bilcol  
                                    FROM    SLORDM A
                                            JOIN SLORDD b ON A.orderno = b.orderno
                                                                   AND A.plantcode = b.plantcode
                                            JOIN VGT.TT_FNSLCUSTTURNE_DUAL c ON A.custcode = c.custcode
--                                                                                AND A.plantcode = c.plantcode
                                    WHERE   A.appdate >= TO_CHAR(ADD_MONTHS(TO_DATE(p_magamyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
                                            AND A.appdate < p_tomorrow
                                            AND A.orderdiv LIKE p_orderdiv
                                            AND A.statediv = '09'
                                            AND A.saldiv IN ( SELECT divcode FROM SLCONDRESULT  )

                        UNION ALL
                         
                        SELECT  c.custcode ,
                                c.plantcode ,
                                -A.colamt ,
                                (   CASE WHEN (NVL(TRIM(A.expdate), '') IS NULL OR A.coldiv = '38' OR A.coldiv NOT LIKE '3%' ) THEN 0 ELSE A.colamt END) bilcol  
                        FROM    SLCOLM A
                                JOIN VGT.TT_FNSLCUSTTURNE_DUAL c ON A.custcode = c.custcode
--                                                                    AND A.plantcode = c.plantcode
                        WHERE   A.appdate >= TO_CHAR(ADD_MONTHS(TO_DATE(p_magamyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
                                AND A.appdate < p_tomorrow
                                AND A.orderdiv LIKE p_orderdiv
                                AND A.statediv = '09'

                        UNION ALL
             
                        SELECT  c.custcode ,
                                c.plantcode ,
                                0 colamt  ,
                                -A.colamt bilcol  
                        FROM    SLCOLM A
                                JOIN VGT.TT_FNSLCUSTTURNE_DUAL c ON A.custcode = c.custcode
--                                                                    AND A.plantcode = c.plantcode
                        WHERE   A.expdate >= TO_CHAR(ADD_MONTHS(TO_DATE(p_magamyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
                                AND A.expdate < p_tomorrow
                                AND A.orderdiv LIKE p_orderdiv
                                AND A.statediv = '09'
                                AND A.coldiv LIKE '3%'
                                AND A.coldiv <> '38' ) A
            WHERE  1 = 1
            GROUP BY A.custcode,A.plantcode ) A
            JOIN VGT.TT_FNSLCUSTTURNE_DUAL c ON A.custcode = c.custcode
                                                AND A.plantcode = c.plantcode 
            WHERE 1 = 1

    ) SRC ON ( TG.custcode = SRC.custcode AND TG.plantcode = SRC.plantcode )
    WHEN MATCHED THEN UPDATE SET    TG.balance = SRC.balance
                                    , TG.pendbillcol = SRC.pendbillcol ;
                                


                               
   -- 거래처 회전일 계산 ===================================================
   -- 매출일자
   -- 거래처
   -- 합계금액
   -- 누적금액
   -- 잔    고
   -- 미결어음
   -- 총 잔 고
   -- 일자별 자료생성  
    EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_FNSLCUSTTURNE_CUSTAL';
   
    INSERT INTO VGT.TT_FNSLCUSTTURNE_CUSTAL ( 
        SELECT  A.appdate ,
                A.custcode ,
                A.plantcode ,
                SUM(A.totamt)  totamt ,
                0 acramt ,     -- 누적금액
                0 balance ,    -- 잔고
                0 pendbillcol ,-- 미결어음
                0 totbalance   -- 총 잔 고                
        FROM    (   SELECT  A.appdate ,
                            c.custcode ,
                            c.plantcode ,
                            ( CASE WHEN A.saldiv LIKE 'A%' THEN b.totamt
                                   WHEN A.saldiv LIKE 'B%' THEN -b.totamt
                                   ELSE 0
                            END) totamt  
                    FROM    SLORDM A
                            JOIN SLORDD b ON A.orderno = b.orderno
                                                    AND A.plantcode = b.plantcode
                            JOIN VGT.TT_FNSLCUSTTURNE_DUAL c ON A.custcode = c.custcode
--                                                                AND A.plantcode = c.plantcode
                    WHERE   A.appdate >= p_firstdate
                            AND A.appdate < p_tomorrow
                            AND A.orderdiv LIKE p_orderdiv
                            AND A.saldiv IN ( SELECT divcode FROM SLCONDRESULT ) -- 주문은 실적분만
                            AND A.statediv = '09' -- (SL17) 매출확정
                            AND A.saldiv LIKE 'A%' -- 판매만 적용

                    UNION ALL
         
                    SELECT  A.appdate ,
                            c.custcode ,
                            c.plantcode ,
                            -A.colamt     -- 잔고이기는 매출로 본다.                      
                    FROM    SLCOLM A
                            JOIN VGT.TT_FNSLCUSTTURNE_DUAL c ON A.custcode = c.custcode
--                                                                AND A.plantcode = c.plantcode
                    WHERE   A.appdate >= p_firstdate
                            AND A.appdate < p_tomorrow
                            AND A.orderdiv LIKE p_orderdiv
                            AND A.statediv = '09' -- (SL17) 매출확정
                            AND A.coldiv IN ( '55' ) -- 잔고이기

                    ) A
        GROUP BY A.appdate, A.custcode, A.plantcode 
    ) ;

    -- ======================================================================
   
    --    거래처 일자별 누적    
    FOR rec IN (

        SELECT  --UPDATE DATA            
                ( SELECT  SUM(st.totamt) 
                  FROM    VGT.TT_FNSLCUSTTURNE_CUSTAL st
                  WHERE   ts.custcode = st.custcode
                          AND ts.plantcode = st.plantcode
                          AND ts.appdate <= st.appdate ) AS acramt
                , c.balance
                , c.pendbillcol
                , (c.balance + c.pendbillcol) AS totbalance
                --COMPARE DATA
                , ts.custcode
                , ts.plantcode
                , ts.appdate
        FROM    VGT.TT_FNSLCUSTTURNE_CUSTAL ts
                JOIN VGT.TT_FNSLCUSTTURNE_DUAL c ON ts.custcode = c.custcode
                                                    AND ts.plantcode = c.plantcode 
        WHERE 1 = 1
        
    )
    LOOP
        
        --UPDATE DATA
        ip_acramt       := rec.acramt ;
        ip_balance      := rec.balance ;
        ip_pendbillcol  := rec.pendbillcol ; 
        ip_totbalance   := rec.totbalance ;

        --COMPARE DATA
        ip_custcode     := rec.custcode ;
        ip_plantcode    := rec.plantcode ; 
        ip_appdate      := rec.appdate ;



        UPDATE  VGT.TT_FNSLCUSTTURNE_CUSTAL A
        SET     A.acramt        = ip_acramt
                , A.balance     = ip_balance
                , A.pendbillcol = ip_pendbillcol
                , A.totbalance  = ip_totbalance
        WHERE   A.custcode      = ip_custcode
                AND A.plantcode = ip_plantcode
                AND A.appdate   = ip_appdate ;

    END LOOP ;



    -- 거래처 회전일 계산
    FOR rec IN (     
        SELECT  ts.custcode ,
                ts.plantcode ,
                ( CASE WHEN ((ts.balance + ts.pendbillcol) - p_amount) <= 0 THEN 0
                       ELSE datediff('DAY', COALESCE(bt.appdate, p_firstdate), p_orderdate)
                END) turncnt  ,
                ( CASE WHEN (ts.balance - p_amount) <= 0 THEN 0
                       ELSE datediff('DAY', COALESCE(st.appdate, p_firstdate), p_orderdate)
                END) turndccnt  ,
                ts.balance ,
                ts.pendbillcol ,
                (ts.balance + ts.pendbillcol) totbalance  
        FROM    VGT.TT_FNSLCUSTTURNE_DUAL ts
                LEFT JOIN ( SELECT  custcode 
                                    , plantcode 
                                    , MAX(appdate)  appdate  
                                    , MAX(balance)  balance  
                            FROM    VGT.TT_FNSLCUSTTURNE_CUSTAL 
                            WHERE   acramt >= (balance - p_amount )
                            GROUP BY custcode,plantcode ) st ON ts.custcode = st.custcode
                                                                AND ts.plantcode = st.plantcode
                LEFT JOIN ( SELECT  custcode 
                                    , plantcode 
                                    , MAX(appdate)  appdate  
                                    , MAX(totbalance)  totbalance  
                            FROM    VGT.TT_FNSLCUSTTURNE_CUSTAL 
                            WHERE   acramt >= (totbalance - p_amount)
                            GROUP BY custcode,plantcode ) bt ON ts.custcode = bt.custcode
                                                                AND ts.plantcode = bt.plantcode 
    )
    LOOP

        slcustTurneListRecode.EXTEND;
        slcustTurneListRecode(i) := FN_SLCUSTTURNE_VARIABLE(rec.custcode, rec.plantcode, rec.turncnt, rec.turndccnt, rec.balance, rec.pendbillcol, rec.totbalance );
        i := i+1; 

    END LOOP ;              
              
    -- ======================================================================
    COMMIT;
    
    RETURN slcustTurneListRecode;              
    
END;
/
