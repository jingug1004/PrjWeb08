CREATE FUNCTION        fnGetKSPBillno(p_billno IN VARCHAR2, p_issdate IN VARCHAR2)
	RETURN VARCHAR2
AS
	p_newbillno   VARCHAR2(50);
	v_temp		  NUMBER(1, 0) := 0;
BEGIN

	SELECT COUNT(*)
	INTO   v_temp
	FROM   DUAL
	WHERE  EXISTS
			   (SELECT *
				FROM   ACBILLM
				WHERE  billno = p_billno);


	IF v_temp = 1 THEN
		FOR rec IN (SELECT CASE WHEN billcls = '1' AND issdate = p_issdate
							    THEN billno
						   END AS alias1
					FROM   ACBILLM
					WHERE  billno = p_billno)
		LOOP
			p_newbillno := rec.alias1;
		END LOOP;

		IF p_newbillno IS NULL
		THEN
			FOR rec IN (SELECT p_billno || '-' || TO_CHAR(NVL(MAX(SUBSTR(billno, -1, 1) || 1), 1)) AS alias1
						FROM   ACBILLM
						WHERE  billno LIKE p_billno || '-%')
			LOOP
				p_newbillno := rec.alias1;
			END LOOP;
		END IF;
	ELSE
		p_newbillno := p_billno;
	END IF;

	RETURN p_newbillno;
    
EXCEPTION
	WHEN OTHERS
	THEN
		p_newbillno := '';
END;
/
