CREATE PROCEDURE       SPACACC0220R_BACKUP (
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0220R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-05-03
	-- 수 정 자      : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자       : 2016-12-21
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 기간별 손익계산서를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_rptdiv		IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '',
	p_startym		IN	   VARCHAR2 DEFAULT '',
	p_endym 		IN	   VARCHAR2 DEFAULT '',
	p_pretype		IN	   VARCHAR2 DEFAULT '1',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	ip_startym	 VARCHAR2(7) := p_startym;

	p_basisyy	 VARCHAR2(4);
	p_beyymm	 VARCHAR2(7);
	p_yyyy01	 VARCHAR2(7);
	p_beyy01	 VARCHAR2(7);
	p_cashcode	 VARCHAR2(20);
	p_strym 	 VARCHAR2(7);

    -- 시작월의 손익계산서 생성
    p_beyymm_p   VARCHAR2(7);
    p_yyyy01_p   VARCHAR2(7);
    p_beyy01_p   VARCHAR2(7);

    -- 임시테이블의 calcseq의 최대값을 조회
    p_maxseq_p   NUMBER(10, 0);
    p_curseq_p   NUMBER(10, 0);

	-- 임시테이블의 calcseq의 최대값을 조회
	p_maxseq	 NUMBER;
	p_curseq	 NUMBER;

BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S' OR p_div = 'P') THEN

        p_strym := ip_startym;

		IF SUBSTR(ip_startym, -2, 2) = '01' AND p_pretype <> '3' THEN

			spACacc0206R(p_div,
							   p_compcode,
							   p_plantcode,
							   p_rptdiv,
							   p_closediv,
							   p_endym,
							   'Y',
							   p_pretype,
							   p_userid,
							   p_reasondiv,
							   p_reasontext,
							   MESSAGE,
							   IO_CURSOR => IO_CURSOR);

            IF (IO_CURSOR IS NULL) THEN
                OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
            END IF;

            RETURN ;

		END IF;


        ip_startym := TO_CHAR(ADD_MONTHS(TO_DATE(ip_startym, 'YYYY-MM'), -1), 'YYYY-MM');


		-- 종료월의 손익계산서 생성
		-- 기간 설정
		p_yyyy01 := SUBSTR(p_endym, 0, 4) || '-01';

		FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
					FROM   ACSESSION
					WHERE  compcode = p_compcode
						   AND cyear <= SUBSTR(p_endym, 0, 4))
		LOOP
			p_yyyy01 := rec.alias1;
		END LOOP;


		IF SUBSTR(p_endym, -2, 2) < SUBSTR(p_yyyy01, -2, 2) THEN

            p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_endym, 'YYYY-MM'), -12), 'YYYY-') || SUBSTR(p_yyyy01, -2, 2);

		ELSE

            p_yyyy01 := SUBSTR(p_endym, 0, 5) || SUBSTR(p_yyyy01, -2, 2);

		END IF;


		IF p_pretype = '1' THEN

			p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_endym, 'YYYY-MM'), -12), 'YYYY-MM');

		ELSE

            IF p_pretype = '2' THEN

				p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01, 'YYYY-MM'), -1), 'YYYY-MM');

			ELSE

                p_beyymm := p_endym;

			END IF;

		END IF;


		IF p_pretype = '3' THEN

            p_beyy01 := p_yyyy01;

		ELSE
			p_beyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01, 'YYYY-MM'), -12), 'YYYY-MM');
		END IF;


		p_cashcode := '11101010';


		FOR rec IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  UPPER(parametercode) = UPPER('acccashcode') 
        )
		LOOP
			p_cashcode := rec.value1;
		END LOOP;


		-- 보고서 조회년도 설정
		FOR rec IN (SELECT MAX(rptyear) AS alias1
					FROM   ACRPTM
					WHERE  compcode = p_compcode
						   AND rptdiv = p_rptdiv
						   AND rptyear <= SUBSTR(p_endym, 0, 4))
		LOOP
			p_basisyy := rec.alias1;
		END LOOP;





        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0220R_ACORDDMM';

        -- 전표에서 월집계 임시파일을 생성
        INSERT INTO VGT.TT_ACACC0220R_ACORDDMM (
             SELECT   p_compcode compcode,
                      p_plantcode plantcode,
                      p_endym slipym,
                      CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
                      acccode,
                      SUM(totdebamt) totdebamt,
                      SUM(totcreamt) totcreamt
             FROM	  (SELECT b.acccode,
                              b.debamt totdebamt,
                              b.creamt totcreamt
                       FROM   ACORDM A
                              JOIN ACORDD b
                                  ON A.compcode = b.compcode
                                     AND A.slipinno = b.slipinno
                       WHERE  A.compcode = p_compcode
                              AND A.plantcode LIKE p_plantcode
                              AND A.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_endym, 'YYYY-MM'), 1), 'YYYYMM')
                              AND A.slipinstate = '4'
                              AND (A.slipdiv NOT IN ('K', 'F')
                                   OR p_closediv = '1'
                                      AND A.slipdiv = 'K'
                                   OR p_closediv = '2'
                                      AND A.slipdiv = 'F')
                       UNION ALL
                       SELECT p_cashcode acccode,
                              b.creamt totdebamt,
                              b.debamt totcreamt
                       FROM   ACORDM A
                              JOIN ACORDD b
                                  ON A.compcode = b.compcode
                                     AND A.slipinno = b.slipinno
                                     AND b.dcdiv IN ('3', '4')
                       WHERE  A.compcode = p_compcode
                              AND A.plantcode LIKE p_plantcode
                              AND A.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_endym, 'YYYY-MM'), 1), 'YYYYMM')
                              AND A.slipinstate = '4'
                              AND (A.slipdiv NOT IN ('K', 'F')
                                   OR p_closediv = '1'
                                      AND A.slipdiv = 'K'
                                   OR p_closediv = '2'
                                      AND A.slipdiv = 'F')
                       UNION ALL
                       SELECT acccode,
                              bsdebamt totdebamt,
                              bscreamt totcreamt
                       FROM   ACORDDMM
                       WHERE  compcode = p_compcode
                              AND plantcode LIKE p_plantcode
                              AND slipym = p_yyyy01
                              AND (p_closediv = '1'
                                   AND closediv IN ('10', '20')
                                   OR p_closediv = '2'
                                      AND closediv IN ('10', '30'))) A
             GROUP BY acccode
        ) ;




		INSERT INTO VGT.TT_ACACC0220R_ACORDDMM (
			 SELECT   p_compcode compcode,
					  p_plantcode plantcode,
					  p_beyymm slipym,
					  CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
					  acccode,
					  SUM(totdebamt) totdebamt,
					  SUM(totcreamt) totcreamt
			 FROM	  ACORDDMM
			 WHERE	  compcode = p_compcode
					  AND plantcode LIKE p_plantcode
					  AND slipym = p_beyymm
					  AND p_endym <> p_beyymm
					  AND (p_closediv = '1'
						   AND closediv IN ('10', '20')
						   OR p_closediv = '2'
							  AND closediv IN ('10', '30'))
			 GROUP BY acccode
        ) ;





		EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0220R_ACC220A';

        -- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
		INSERT INTO VGT.TT_ACACC0220R_ACC220A(
            seqline,
            acccode,
            accrname,
            acckname,
            lrdiv,
            prtyn,
            prtdiv,
            prtbold,
            sseqline,
            calcseq,
            calcdiv,
            cseqline,
            cgb,
            objdatadiv,
            amt,
            beamt )
			SELECT	 A.seqline,
					 MAX(A.acccode),
					 MAX(A.accrname),
					 MAX(A.acckname),
					 MAX(A.lrdiv),
					 MAX(A.prtyn),
					 MAX(A.prtdiv),
					 MAX(A.prtbold),
					 MAX(A.sseqline),
					 MAX(A.calcseq),
					 MAX(A.calcdiv),
					 MAX(A.cseqline),
					 '1',
					 MAX(A.objdatadiv),
					 NVL(SUM(CASE WHEN c.slipym = p_endym THEN CASE WHEN A.objdatadiv IN ('D', 'F') THEN c.totdebamt 
                                                                    WHEN A.objdatadiv IN ('C', 'E') THEN c.totcreamt 
                                                                    WHEN A.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt 
                                                                                                      ELSE c.totcreamt - c.totdebamt 
                                                                                                 END 
                                                               END 
                             END), 0) amt2,
					 NVL(SUM(CASE WHEN c.slipym = p_beyymm THEN CASE WHEN A.objdatadiv IN ('D', 'F') THEN c.totdebamt 
                                                                     WHEN A.objdatadiv IN ('C', 'E') THEN c.totcreamt 
                                                                     WHEN A.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt 
                                                                                                       ELSE c.totcreamt - c.totdebamt 
                                                                                                  END 
                                                                END 
                             END), 0) amt4
			FROM	 ACRPTM A
					 LEFT JOIN ACACCM b ON A.acccode = b.acccode
					 LEFT JOIN VGT.TT_ACACC0220R_ACORDDMM c ON A.compcode = c.compcode
							                                    AND c.plantcode LIKE p_plantcode
							                                    AND c.slipym IN (p_endym, p_beyymm)
							                                    AND (p_closediv = '1' AND c.closediv IN ('10', '20') OR 
                                                                     p_closediv = '2' AND c.closediv IN ('10', '30'))
							                                    AND A.acccode = c.acccode
			WHERE	 A.compcode = p_compcode
					 AND A.rptdiv = p_rptdiv
					 AND A.rptyear = p_basisyy
					 AND A.useyn = 'Y'
			GROUP BY A.seqline
			ORDER BY A.seqline;





        -- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
        MERGE INTO VGT.TT_ACACC0220R_ACC220A A
        USING (
        SELECT  -- COMPARE DATA
                A.SEQLINE,
                A.ACCCODE,
                A.ACCRNAME,
                A.ACCKNAME,
                A.LRDIV,
                A.PRTYN,
                A.PRTDIV,
                A.PRTBOLD,
                A.SSEQLINE,
                A.CALCSEQ,
                A.CALCDIV,
                A.CSEQLINE,
                A.CGB,
                A.OBJDATADIV,
                A.CALCAMT,
                A.BECALCAMT,
                -- UPDATE DATA
                CASE WHEN A.objdatadiv = 'A' THEN b.amt   ELSE A.amt - b.amt     END AS amt,
                CASE WHEN A.objdatadiv = 'A' THEN b.beamt ELSE A.beamt - b.beamt END AS beamt
        FROM    VGT.TT_ACACC0220R_ACC220A A
                JOIN (  SELECT  A.seqline,
                                NVL(SUM(CASE WHEN c.slipym = p_yyyy01 THEN CASE WHEN A.objdatadiv = 'F' THEN c.bsdebamt 
                                                                                WHEN A.objdatadiv = 'E' THEN c.bscreamt 
                                                                                WHEN A.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt 
                                                                                                                  ELSE c.bscreamt - c.bsdebamt 
                                                                                                             END 
                                                                           END 
                                        END), 0) amt,
                                NVL(SUM(CASE WHEN c.slipym = p_beyy01 THEN CASE WHEN A.objdatadiv = 'F' THEN c.bsdebamt 
                                                                                WHEN A.objdatadiv = 'E' THEN c.bscreamt 
                                                                                WHEN A.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt 
                                                                                                                  ELSE c.bscreamt - c.bsdebamt 
                                                                                                             END 
                                                                           END 
                                        END), 0) beamt
                        FROM	ACRPTM A
                                LEFT JOIN ACACCM b   ON A.acccode = b.acccode
                                LEFT JOIN ACORDDMM c ON A.compcode = c.compcode
                                                        AND c.plantcode LIKE p_plantcode
                                                        AND c.slipym IN (p_yyyy01, p_beyy01)
                                                        AND (p_closediv = '1' AND c.closediv IN ('10', '20') OR 
                                                             p_closediv = '2' AND c.closediv IN ('10', '30'))
                                                        AND A.acccode = c.acccode
                        WHERE   A.compcode = p_compcode
                                AND A.rptdiv = p_rptdiv
                                AND A.rptyear = p_basisyy
                                AND A.useyn = 'Y'
                                AND A.objdatadiv IN ('A', 'E', 'F')
                        GROUP BY A.seqline ) b ON A.seqline = b.seqline
        ) SRC ON(   A.SEQLINE = SRC.SEQLINE
                    AND A.ACCCODE = SRC.ACCCODE
                    AND A.ACCRNAME = SRC.ACCRNAME
                    AND A.ACCKNAME = SRC.ACCKNAME
                    AND A.LRDIV = SRC.LRDIV
                    AND A.PRTYN = SRC.PRTYN
                    AND A.PRTDIV = SRC.PRTDIV
                    AND A.PRTBOLD = SRC.PRTBOLD
                    AND A.SSEQLINE = SRC.SSEQLINE
                    AND A.CALCSEQ = SRC.CALCSEQ
                    AND A.CALCDIV = SRC.CALCDIV
                    AND A.CSEQLINE = SRC.CSEQLINE
                    AND A.CGB = SRC.CGB
                    AND A.OBJDATADIV = SRC.OBJDATADIV
                    AND A.CALCAMT = SRC.CALCAMT
                    AND A.BECALCAMT = SRC.BECALCAMT )
        WHEN MATCHED THEN UPDATE SET    A.amt = SRC.amt
                                        , A.beamt = SRC.beamt ;






		-- 당기제품제조원가를 구함
		spACacc0208R(p_div => 'S',
						   p_compcode  => p_compcode,
						   p_plantcode => p_plantcode,
						   p_rptdiv    => '9',
						   p_closediv  => p_closediv,
						   p_basisym   => p_endym,
						   p_viewyn    => 'N',
						   MESSAGE     => MESSAGE,
						   IO_CURSOR   => IO_CURSOR);





		IF MESSAGE <> '데이터 확인' THEN

            MERGE INTO VGT.TT_ACACC0220R_ACC220A A
            USING (
                SELECT  -- COMPARE DATA
                        A.SEQLINE,
                        A.ACCCODE,
                        A.ACCRNAME,
                        A.ACCKNAME,
                        A.LRDIV,
                        A.PRTYN,
                        A.PRTDIV,
                        A.PRTBOLD,
                        A.SSEQLINE,
                        A.CALCSEQ,
                        A.CALCDIV,
                        A.CSEQLINE,
                        A.CGB,
                        A.OBJDATADIV,
                        A.CALCAMT,
                        A.BECALCAMT,
                        -- UPDATE DATA
                        TO_NUMBER(SUBSTR(MESSAGE, 0, INSTR(MESSAGE, ';') - 1)) AS amt,
                        TO_NUMBER(SUBSTR(MESSAGE, INSTR(MESSAGE, ';') + 1, LENGTH(MESSAGE))) AS beamt
                FROM    VGT.TT_ACACC0220R_ACC220A A
                        JOIN ACRPTM b ON b.compcode = p_compcode
                                         AND b.rptdiv = p_rptdiv
                                         AND b.rptyear = p_basisyy
                                         AND A.seqline = b.seqline
                WHERE   b.remark = '당기제품제조원가'
            ) SRC ON (  A.SEQLINE = SRC.SEQLINE
                        AND A.ACCCODE = SRC.ACCCODE
                        AND A.ACCRNAME = SRC.ACCRNAME
                        AND A.ACCKNAME = SRC.ACCKNAME
                        AND A.LRDIV = SRC.LRDIV
                        AND A.PRTYN = SRC.PRTYN
                        AND A.PRTDIV = SRC.PRTDIV
                        AND A.PRTBOLD = SRC.PRTBOLD
                        AND A.SSEQLINE = SRC.SSEQLINE
                        AND A.CALCSEQ = SRC.CALCSEQ
                        AND A.CALCDIV = SRC.CALCDIV
                        AND A.CSEQLINE = SRC.CSEQLINE
                        AND A.CGB = SRC.CGB
                        AND A.OBJDATADIV = SRC.OBJDATADIV
                        AND A.CALCAMT = SRC.CALCAMT
                        AND A.BECALCAMT = SRC.BECALCAMT )
            WHEN MATCHED
            THEN
            UPDATE SET A.amt = SRC.amt, A.beamt = SRC.beamt ;

		END IF;


		p_curseq := 0;


		FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0220R_ACC220A)
		LOOP
			p_maxseq := rec.alias1;
		END LOOP;

		-- 각 레벨별로 sum을하여 update
		WHILE p_curseq <= p_maxseq
		LOOP
			MERGE INTO VGT.TT_ACACC0220R_ACC220A A
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.PRTBOLD,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.CSEQLINE,
							   A.CGB,
							   A.OBJDATADIV,
							   A.CALCAMT,
							   A.BECALCAMT,
							   A.amt + b.amt AS pos_2,
							   A.beamt + b.beamt AS pos_3
						FROM   VGT.TT_ACACC0220R_ACC220A A
							   JOIN (SELECT   sseqline, SUM(CASE WHEN calcdiv = '+' THEN amt ELSE -amt END) amt, SUM(CASE WHEN calcdiv = '+' THEN beamt ELSE -beamt END) beamt
									 FROM	  VGT.TT_ACACC0220R_ACC220A
									 WHERE	  calcseq = p_curseq
											  AND TRIM(sseqline) IS NOT NULL
									 GROUP BY sseqline) b
								   ON A.seqline = b.sseqline) src
			ON		   (A.SEQLINE = SRC.SEQLINE
						AND A.ACCCODE = SRC.ACCCODE
						AND A.ACCRNAME = SRC.ACCRNAME
						AND A.ACCKNAME = SRC.ACCKNAME
						AND A.LRDIV = SRC.LRDIV
						AND A.PRTYN = SRC.PRTYN
						AND A.PRTDIV = SRC.PRTDIV
						AND A.PRTBOLD = SRC.PRTBOLD
						AND A.SSEQLINE = SRC.SSEQLINE
						AND A.CALCSEQ = SRC.CALCSEQ
						AND A.CALCDIV = SRC.CALCDIV
						AND A.CSEQLINE = SRC.CSEQLINE
						AND A.CGB = SRC.CGB
						AND A.OBJDATADIV = SRC.OBJDATADIV
						AND A.CALCAMT = SRC.CALCAMT
						AND A.BECALCAMT = SRC.BECALCAMT)
			WHEN MATCHED
			THEN
				UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;

			p_curseq := p_curseq + 1;
		END LOOP;


		INSERT INTO VGT.TT_ACACC0220R_ACC220B
			SELECT	 A.cseqline,
					 A.seqline,
					 A.amt,
					 A.beamt,
					 0,
					 0,
					 b.amt,
					 b.beamt,
					 0,
					 ROWNUM
			FROM	 VGT.TT_ACACC0220R_ACC220A A JOIN VGT.TT_ACACC0220R_ACC220A b ON A.cseqline = b.seqline
			WHERE	 A.amt <> 0
					 OR A.beamt <> 0
			ORDER BY A.cseqline, A.seqline DESC;

		MERGE INTO VGT.TT_ACACC0220R_ACC220B A
		USING	   (SELECT A.ORD, A.ord - b.minNo + 1 AS pos_2
					FROM   VGT.TT_ACACC0220R_ACC220B A
						   JOIN (SELECT   cseqline, MIN(ord) minNo
								 FROM	  VGT.TT_ACACC0220R_ACC220B
								 GROUP BY VGT.TT_ACACC0220R_ACC220B.cseqline) b
							   ON A.cseqline = b.cseqline) src
		ON		   (A.ORD = src.ORD)
		WHEN MATCHED
		THEN
			UPDATE SET A.num = SRC.pos_2, A.amt2 = 0, A.beamt2 = 0;


		MERGE INTO VGT.TT_ACACC0220R_ACC220B A
		USING	   (SELECT A.ORD, b.amt, b.beamt
					FROM   VGT.TT_ACACC0220R_ACC220B A
						   JOIN (SELECT   cseqline, SUM(amt) amt, SUM(beamt) beamt
								 FROM	  VGT.TT_ACACC0220R_ACC220B
								 GROUP BY VGT.TT_ACACC0220R_ACC220B.cseqline) b
							   ON A.cseqline = b.cseqline
								  AND num = 1) src
		ON		   (A.ORD = src.ORD)
		WHEN MATCHED
		THEN
			UPDATE SET A.amt2 = src.amt, beamt2 = src.beamt;


		MERGE INTO VGT.TT_ACACC0220R_ACC220A A
		USING	   (SELECT A.SEQLINE,
						   A.ACCCODE,
						   A.ACCRNAME,
						   A.ACCKNAME,
						   A.PRTYN,
						   A.PRTDIV,
						   A.PRTBOLD,
						   A.SSEQLINE,
						   A.CALCSEQ,
						   A.CALCDIV,
						   A.CSEQLINE,
						   A.CGB,
						   A.OBJDATADIV,
						   A.AMT,
						   A.CALCAMT,
						   A.BEAMT,
						   A.BECALCAMT
					FROM   VGT.TT_ACACC0220R_ACC220A A
						   JOIN (SELECT DISTINCT cseqline FROM VGT.TT_ACACC0220R_ACC220B
								 UNION
								 SELECT seqline FROM VGT.TT_ACACC0220R_ACC220B) b
							   ON A.seqline = b.cseqline) src
		ON		   (A.SEQLINE = SRC.SEQLINE
					AND A.ACCCODE = SRC.ACCCODE
					AND A.ACCRNAME = SRC.ACCRNAME
					AND A.ACCKNAME = SRC.ACCKNAME
					AND A.PRTYN = SRC.PRTYN
					AND A.PRTDIV = SRC.PRTDIV
					AND A.PRTBOLD = SRC.PRTBOLD
					AND A.SSEQLINE = SRC.SSEQLINE
					AND A.CALCSEQ = SRC.CALCSEQ
					AND A.CALCDIV = SRC.CALCDIV
					AND A.CSEQLINE = SRC.CSEQLINE
					AND A.CGB = SRC.CGB
					AND A.OBJDATADIV = SRC.OBJDATADIV
					AND A.AMT = SRC.AMT
					AND A.CALCAMT = SRC.CALCAMT
					AND A.BEAMT = SRC.BEAMT
					AND A.BECALCAMT = SRC.BECALCAMT)
		WHEN MATCHED
		THEN
			UPDATE SET A.lrdiv = 'L';


		MERGE INTO VGT.TT_ACACC0220R_ACC220A A
		USING	   (SELECT A.SEQLINE,
						   A.ACCCODE,
						   A.ACCRNAME,
						   A.ACCKNAME,
						   A.LRDIV,
						   A.PRTYN,
						   A.PRTDIV,
						   A.PRTBOLD,
						   A.SSEQLINE,
						   A.CALCSEQ,
						   A.CALCDIV,
						   A.CSEQLINE,
						   A.OBJDATADIV,
						   A.AMT,
						   A.BEAMT,
						   b.amt3 - amt2 AS pos_2,
						   b.beamt3 - beamt2 AS pos_3
					FROM   VGT.TT_ACACC0220R_ACC220A A
						   JOIN (SELECT seqline, amt2, amt3, beamt2, beamt3
								 FROM	VGT.TT_ACACC0220R_ACC220B
								 WHERE	num = 1) b
							   ON A.seqline = b.seqline) src
		ON		   (A.SEQLINE = SRC.SEQLINE
					AND A.ACCCODE = SRC.ACCCODE
					AND A.ACCRNAME = SRC.ACCRNAME
					AND A.ACCKNAME = SRC.ACCKNAME
					AND A.LRDIV = SRC.LRDIV
					AND A.PRTYN = SRC.PRTYN
					AND A.PRTDIV = SRC.PRTDIV
					AND A.PRTBOLD = SRC.PRTBOLD
					AND A.SSEQLINE = SRC.SSEQLINE
					AND A.CALCSEQ = SRC.CALCSEQ
					AND A.CALCDIV = SRC.CALCDIV
					AND A.CSEQLINE = SRC.CSEQLINE
					AND A.OBJDATADIV = SRC.OBJDATADIV
					AND A.AMT = SRC.AMT
					AND A.BEAMT = SRC.BEAMT)
		WHEN MATCHED
		THEN
			UPDATE SET A.calcamt = SRC.pos_2, A.becalcamt = SRC.pos_3, A.cgb = '2';


		IF p_yyyy01 < p_strym THEN


            -- 기간 설정
            p_yyyy01_p := SUBSTR(ip_startym, 0, 4) || '-01';

            FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
                        FROM   ACSESSION
                        WHERE  compcode = p_compcode
                               AND cyear <= SUBSTR(ip_startym, 0, 4))
            LOOP
                p_yyyy01_p := rec.alias1;
            END LOOP;

            IF SUBSTR(ip_startym, -2, 2) < SUBSTR(p_yyyy01_p, -2, 2)
            THEN
                p_yyyy01_p := TO_CHAR(ADD_MONTHS(TO_DATE(ip_startym, 'YYYY-MM'), -12), 'YYYY-') || SUBSTR(p_yyyy01_p, -2, 2);
            ELSE
                p_yyyy01_p := SUBSTR(ip_startym, 0, 5) || SUBSTR(p_yyyy01_p, -2, 2);
            END IF;

            IF p_pretype = '1'
            THEN
                p_beyymm_p := TO_CHAR(ADD_MONTHS(TO_DATE(ip_startym, 'YYYY-MM'), -12), 'YYYY-MM');
            ELSE
                p_beyymm_p := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01_p, 'YYYY-MM'), -1), 'YYYY-MM');
            END IF;

            p_beyy01_p := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01_p, 'YYYY-MM'), -12), 'YYYY-MM');


            -- 전표에서 월집계 임시파일을 생성
            EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0220R_ACORDDMMP ';

            INSERT INTO VGT.TT_ACACC0220R_ACORDDMMP (
                 SELECT   p_compcode compcode,
                          p_plantcode plantcode,
                          ip_startym slipym,
                          CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
                          acccode,
                          SUM(totdebamt) totdebamt,
                          SUM(totcreamt) totcreamt
                 FROM	  (SELECT b.acccode, b.debamt totdebamt, b.creamt totcreamt
                           FROM   ACORDM A
                                  JOIN ACORDD b
                                      ON A.compcode = b.compcode
                                         AND A.slipinno = b.slipinno
                           WHERE  A.compcode = p_compcode
                                  AND A.plantcode LIKE p_plantcode
                                  AND A.slipno BETWEEN REPLACE(p_yyyy01_p, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(ip_startym, 'YYYY-MM'), 1), 'YYYYMM')
                                  AND A.slipinstate = '4'
                                  AND (A.slipdiv NOT IN ('K', 'F')
                                       OR p_closediv = '1'
                                          AND A.slipdiv = 'K'
                                       OR p_closediv = '2'
                                          AND A.slipdiv = 'F')
                           UNION ALL
                           SELECT p_cashcode acccode, b.creamt totdebamt, b.debamt totcreamt
                           FROM   ACORDM A
                                  JOIN ACORDD b
                                      ON A.compcode = b.compcode
                                         AND A.slipinno = b.slipinno
                                         AND b.dcdiv IN ('3', '4')
                           WHERE  A.compcode = p_compcode
                                  AND A.plantcode LIKE p_plantcode
                                  AND A.slipno BETWEEN REPLACE(p_yyyy01_p, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(ip_startym, 'YYYY-MM'), 1), 'YYYYMM')
                                  AND A.slipinstate = '4'
                                  AND (A.slipdiv NOT IN ('K', 'F')
                                       OR p_closediv = '1'
                                          AND A.slipdiv = 'K'
                                       OR p_closediv = '2'
                                          AND A.slipdiv = 'F')
                           UNION ALL
                           SELECT acccode, bsdebamt totdebamt, bscreamt totcreamt
                           FROM   ACORDDMM
                           WHERE  compcode = p_compcode
                                  AND plantcode LIKE p_plantcode
                                  AND slipym = p_yyyy01_p
                                  AND (p_closediv = '1'
                                       AND closediv IN ('10', '20')
                                       OR p_closediv = '2'
                                          AND closediv IN ('10', '30'))) A
                 GROUP BY acccode
             );


            INSERT INTO VGT.TT_ACACC0220R_ACORDDMMP (
                 SELECT   p_compcode compcode,
                          p_plantcode plantcode,
                          p_beyymm_p slipym,
                          CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
                          acccode,
                          SUM(totdebamt) totdebamt,
                          SUM(totcreamt) totcreamt
                 FROM	  ACORDDMM
                 WHERE	  compcode = p_compcode
                          AND plantcode LIKE p_plantcode
                          AND slipym = p_beyymm_p
                          AND (p_closediv = '1'
                               AND closediv IN ('10', '20')
                               OR p_closediv = '2'
                                  AND closediv IN ('10', '30'))
                 GROUP BY acccode
            ) ;



            EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0220R_ACC220AP ';

            -- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
            INSERT INTO VGT.TT_ACACC0220R_ACC220AP(seqline,
                                                   acccode,
                                                   accrname,
                                                   acckname,
                                                   lrdiv,
                                                   prtyn,
                                                   prtdiv,
                                                   sseqline,
                                                   calcseq,
                                                   calcdiv,
                                                   cseqline,
                                                   cgb,
                                                   objdatadiv,
                                                   amt,
                                                   beamt)
                SELECT	 A.seqline,
                         MAX(A.acccode),
                         MAX(A.accrname),
                         MAX(A.acckname),
                         MAX(A.lrdiv),
                         MAX(A.prtyn),
                         MAX(A.prtdiv),
                         MAX(A.sseqline),
                         MAX(A.calcseq),
                         MAX(A.calcdiv),
                         MAX(A.cseqline),
                         '1',
                         MAX(A.objdatadiv),
                         NVL(
                             SUM(
                                 CASE
                                     WHEN c.slipym = ip_startym
                                     THEN
                                         CASE WHEN A.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN A.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN A.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END
                                 END),
                             0)
                             amt2,
                         NVL(
                             SUM(
                                 CASE
                                     WHEN c.slipym = p_beyymm_p
                                     THEN
                                         CASE WHEN A.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN A.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN A.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END
                                 END),
                             0)
                             amt4
                FROM	 ACRPTM A
                         LEFT JOIN ACACCM b ON A.acccode = b.acccode
                         LEFT JOIN VGT.TT_ACACC0220R_ACORDDMMP c
                             ON A.compcode = c.compcode
                                AND c.plantcode LIKE p_plantcode
                                AND c.slipym IN (ip_startym, p_beyymm_p)
                                AND (p_closediv = '1'
                                     AND c.closediv IN ('10', '20')
                                     OR p_closediv = '2'
                                        AND c.closediv IN ('10', '30'))
                                AND A.acccode = c.acccode
                WHERE	 A.compcode = p_compcode
                         AND A.rptdiv = p_rptdiv
                         AND A.rptyear = p_basisyy
                         AND A.useyn = 'Y'
                GROUP BY A.seqline
                ORDER BY A.seqline;



            -- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
            MERGE INTO VGT.TT_ACACC0220R_ACC220AP A
            USING	   (SELECT A.SEQLINE,
                               A.ACCCODE,
                               A.ACCRNAME,
                               A.ACCKNAME,
                               A.LRDIV,
                               A.PRTYN,
                               A.PRTDIV,
                               A.SSEQLINE,
                               A.CALCSEQ,
                               A.CALCDIV,
                               A.CSEQLINE,
                               A.CGB,
                               A.OBJDATADIV,
                               A.CALCAMT,
                               A.BECALCAMT,
                               CASE WHEN A.objdatadiv = 'A' THEN b.amt ELSE A.amt - b.amt END AS pos_2,
                               CASE WHEN A.objdatadiv = 'A' THEN b.beamt ELSE A.beamt - b.beamt END AS pos_3
                        FROM   VGT.TT_ACACC0220R_ACC220AP A
                               JOIN
                               (SELECT	 A.seqline,
                                         NVL(SUM(CASE WHEN c.slipym = p_yyyy01_p THEN CASE WHEN A.objdatadiv = 'F' THEN c.bsdebamt WHEN A.objdatadiv = 'E' THEN c.bscreamt WHEN A.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END),
                                             0)
                                             amt,
                                         NVL(SUM(CASE WHEN c.slipym = p_beyy01_p THEN CASE WHEN A.objdatadiv = 'F' THEN c.bsdebamt WHEN A.objdatadiv = 'E' THEN c.bscreamt WHEN A.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END),
                                             0)
                                             beamt
                                FROM	 ACRPTM A
                                         LEFT JOIN ACACCM b ON A.acccode = b.acccode
                                         LEFT JOIN ACORDDMM c
                                             ON A.compcode = c.compcode
                                                AND c.plantcode LIKE p_plantcode
                                                AND c.slipym IN (p_yyyy01_p, p_beyy01_p)
                                                AND (p_closediv = '1'
                                                     AND c.closediv IN ('10', '20')
                                                     OR p_closediv = '2'
                                                        AND c.closediv IN ('10', '30'))
                                                AND A.acccode = c.acccode
                                WHERE	 A.compcode = p_compcode
                                         AND A.rptdiv = p_rptdiv
                                         AND A.rptyear = p_basisyy
                                         AND A.useyn = 'Y'
                                         AND A.objdatadiv IN ('A', 'E', 'F')
                                GROUP BY A.seqline) b
                                   ON A.seqline = b.seqline) src
            ON		   (A.SEQLINE = SRC.SEQLINE
                        AND A.ACCCODE = SRC.ACCCODE
                        AND A.ACCRNAME = SRC.ACCRNAME
                        AND A.ACCKNAME = SRC.ACCKNAME
                        AND A.LRDIV = SRC.LRDIV
                        AND A.PRTYN = SRC.PRTYN
                        AND A.PRTDIV = SRC.PRTDIV
                        AND A.SSEQLINE = SRC.SSEQLINE
                        AND A.CALCSEQ = SRC.CALCSEQ
                        AND A.CALCDIV = SRC.CALCDIV
                        AND A.CSEQLINE = SRC.CSEQLINE
                        AND A.CGB = SRC.CGB
                        AND A.OBJDATADIV = SRC.OBJDATADIV
                        AND A.CALCAMT = SRC.CALCAMT
                        AND A.BECALCAMT = SRC.BECALCAMT)
            WHEN MATCHED
            THEN
                UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;



            -- 당기제품제조원가를 구함
            spACacc0208R(p_div => 'S',
                               p_compcode => p_compcode,
                               p_plantcode => p_plantcode,
                               p_rptdiv => '9',
                               p_closediv => p_closediv,
                               p_basisym => ip_startym,
                               p_viewyn => 'N',
                               MESSAGE => MESSAGE,
                               IO_CURSOR => IO_CURSOR);



            IF MESSAGE <> '데이터 확인'
            THEN
                MERGE INTO VGT.TT_ACACC0220R_ACC220AP A
                USING	   (SELECT A.SEQLINE,
                                   A.ACCCODE,
                                   A.ACCRNAME,
                                   A.ACCKNAME,
                                   A.LRDIV,
                                   A.PRTYN,
                                   A.PRTDIV,
                                   A.SSEQLINE,
                                   A.CALCSEQ,
                                   A.CALCDIV,
                                   A.CSEQLINE,
                                   A.CGB,
                                   A.OBJDATADIV,
                                   A.CALCAMT,
                                   A.BECALCAMT,
                                   TO_NUMBER(SUBSTR(MESSAGE, 0, INSTR(MESSAGE, ';') - 1)) AS pos_2,
                                   TO_NUMBER(SUBSTR(MESSAGE, INSTR(MESSAGE, ';') + 1, LENGTH(MESSAGE))) AS pos_3
                            FROM   VGT.TT_ACACC0220R_ACC220AP A
                                   JOIN ACRPTM b
                                       ON b.compcode = p_compcode
                                          AND b.rptdiv = p_rptdiv
                                          AND b.rptyear = p_basisyy
                                          AND A.seqline = b.seqline
                            WHERE  b.remark = '당기제품제조원가') src
                ON		   (A.SEQLINE = SRC.SEQLINE
                            AND A.ACCCODE = SRC.ACCCODE
                            AND A.ACCRNAME = SRC.ACCRNAME
                            AND A.ACCKNAME = SRC.ACCKNAME
                            AND A.LRDIV = SRC.LRDIV
                            AND A.PRTYN = SRC.PRTYN
                            AND A.PRTDIV = SRC.PRTDIV
                            AND A.SSEQLINE = SRC.SSEQLINE
                            AND A.CALCSEQ = SRC.CALCSEQ
                            AND A.CALCDIV = SRC.CALCDIV
                            AND A.CSEQLINE = SRC.CSEQLINE
                            AND A.CGB = SRC.CGB
                            AND A.OBJDATADIV = SRC.OBJDATADIV
                            AND A.CALCAMT = SRC.CALCAMT
                            AND A.BECALCAMT = SRC.BECALCAMT)
                WHEN MATCHED
                THEN
                    UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;
            END IF;

            p_curseq_p := 0;

            FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0220R_ACC220AP)
            LOOP
                p_maxseq_p := rec.alias1;
            END LOOP;

            -- 각 레벨별로 sum을하여 update
            WHILE p_curseq_p <= p_maxseq_p
            LOOP
                MERGE INTO VGT.TT_ACACC0220R_ACC220AP A
                USING	   (SELECT A.SEQLINE,
                                   A.ACCCODE,
                                   A.ACCRNAME,
                                   A.ACCKNAME,
                                   A.LRDIV,
                                   A.PRTYN,
                                   A.PRTDIV,
                                   A.SSEQLINE,
                                   A.CALCSEQ,
                                   A.CALCDIV,
                                   A.CSEQLINE,
                                   A.CGB,
                                   A.OBJDATADIV,
                                   A.CALCAMT,
                                   A.BECALCAMT,
                                   A.amt + b.amt AS pos_2,
                                   A.beamt + b.beamt AS pos_3
                            FROM   VGT.TT_ACACC0220R_ACC220AP A
                                   JOIN (SELECT   sseqline, SUM(CASE WHEN calcdiv = '+' THEN amt ELSE -amt END) amt, SUM(CASE WHEN calcdiv = '+' THEN beamt ELSE -beamt END) beamt
                                         FROM	  VGT.TT_ACACC0220R_ACC220AP
                                         WHERE	  calcseq = p_curseq_p
                                                  AND TRIM(sseqline) IS NOT NULL
                                         GROUP BY sseqline) b
                                       ON A.seqline = b.sseqline) src
                ON		   (A.SEQLINE = SRC.SEQLINE
                            AND A.ACCCODE = SRC.ACCCODE
                            AND A.ACCRNAME = SRC.ACCRNAME
                            AND A.ACCKNAME = SRC.ACCKNAME
                            AND A.LRDIV = SRC.LRDIV
                            AND A.PRTYN = SRC.PRTYN
                            AND A.PRTDIV = SRC.PRTDIV
                            AND A.SSEQLINE = SRC.SSEQLINE
                            AND A.CALCSEQ = SRC.CALCSEQ
                            AND A.CALCDIV = SRC.CALCDIV
                            AND A.CSEQLINE = SRC.CSEQLINE
                            AND A.CGB = SRC.CGB
                            AND A.OBJDATADIV = SRC.OBJDATADIV
                            AND A.CALCAMT = SRC.CALCAMT
                            AND A.BECALCAMT = SRC.BECALCAMT)
                WHEN MATCHED
                THEN
                    UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;

                p_curseq_p := p_curseq_p + 1;
            END LOOP;


            INSERT INTO VGT.TT_ACACC0220R_ACC220BP
                SELECT	 A.cseqline,
                         A.seqline,
                         A.amt,
                         A.beamt,
                         0,
                         0,
                         b.amt,
                         b.beamt,
                         0,
                         ROWNUM
                FROM	 VGT.TT_ACACC0220R_ACC220AP A JOIN VGT.TT_ACACC0220R_ACC220AP b ON A.cseqline = b.seqline
                WHERE	 A.amt <> 0
                         OR A.beamt <> 0
                ORDER BY A.cseqline, A.seqline DESC;



            MERGE INTO VGT.TT_ACACC0220R_ACC220BP A
            USING	   (SELECT A.ORD, A.ord - b.minNo + 1 AS pos_2
                        FROM   VGT.TT_ACACC0220R_ACC220BP A
                               JOIN (SELECT   cseqline, MIN(ord) minNo
                                     FROM	  VGT.TT_ACACC0220R_ACC220BP
                                     GROUP BY cseqline) b
                                   ON A.cseqline = b.cseqline) src
            ON		   (A.ORD = SRC.ORD)
            WHEN MATCHED
            THEN
                UPDATE SET A.num = pos_2, A.amt2 = 0, A.beamt2 = 0;



            MERGE INTO VGT.TT_ACACC0220R_ACC220BP A
            USING	   (SELECT A.ORD, b.amt, b.beamt
                        FROM   VGT.TT_ACACC0220R_ACC220BP A
                               JOIN (SELECT   cseqline, SUM(amt) amt, SUM(beamt) beamt
                                     FROM	  VGT.TT_ACACC0220R_ACC220BP
                                     GROUP BY cseqline) b
                                   ON A.cseqline = b.cseqline
                                      AND num = 1) src
            ON		   (A.ORD = SRC.ORD)
            WHEN MATCHED
            THEN
                UPDATE SET amt2 = src.amt, beamt2 = src.beamt;



            MERGE INTO VGT.TT_ACACC0220R_ACC220AP A
            USING	   (SELECT A.SEQLINE,
                               A.ACCCODE,
                               A.ACCRNAME,
                               A.ACCKNAME,
                               A.PRTYN,
                               A.PRTDIV,
                               A.SSEQLINE,
                               A.CALCSEQ,
                               A.CALCDIV,
                               A.CSEQLINE,
                               A.CGB,
                               A.OBJDATADIV,
                               A.AMT,
                               A.CALCAMT,
                               A.BEAMT,
                               A.BECALCAMT
                        FROM   VGT.TT_ACACC0220R_ACC220AP A
                               JOIN (SELECT DISTINCT VGT.TT_ACACC0220R_ACC220BP.cseqline FROM VGT.TT_ACACC0220R_ACC220BP
                                     UNION
                                     SELECT VGT.TT_ACACC0220R_ACC220BP.seqline FROM VGT.TT_ACACC0220R_ACC220BP) b
                                   ON A.seqline = b.cseqline) src
            ON		   (A.SEQLINE = SRC.SEQLINE
                        AND A.ACCCODE = SRC.ACCCODE
                        AND A.ACCRNAME = SRC.ACCRNAME
                        AND A.ACCKNAME = SRC.ACCKNAME
                        AND A.PRTYN = SRC.PRTYN
                        AND A.PRTDIV = SRC.PRTDIV
                        AND A.SSEQLINE = SRC.SSEQLINE
                        AND A.CALCSEQ = SRC.CALCSEQ
                        AND A.CALCDIV = SRC.CALCDIV
                        AND A.CSEQLINE = SRC.CSEQLINE
                        AND A.CGB = SRC.CGB
                        AND A.OBJDATADIV = SRC.OBJDATADIV
                        AND A.AMT = SRC.AMT
                        AND A.CALCAMT = SRC.CALCAMT
                        AND A.BEAMT = SRC.BEAMT
                        AND A.BECALCAMT = SRC.BECALCAMT)
            WHEN MATCHED
            THEN
                UPDATE SET lrdiv = 'L';



            MERGE INTO VGT.TT_ACACC0220R_ACC220AP A
            USING	   (SELECT A.SEQLINE,
                               A.ACCCODE,
                               A.ACCRNAME,
                               A.ACCKNAME,
                               A.LRDIV,
                               A.PRTYN,
                               A.PRTDIV,
                               A.SSEQLINE,
                               A.CALCSEQ,
                               A.CALCDIV,
                               A.CSEQLINE,
                               A.OBJDATADIV,
                               A.AMT,
                               A.BEAMT,
                               b.amt3 - amt2 AS pos_2,
                               b.beamt3 - beamt2 AS pos_3
                        FROM   VGT.TT_ACACC0220R_ACC220AP A
                               JOIN (SELECT seqline, amt2, amt3, beamt2, beamt3
                                     FROM	VGT.TT_ACACC0220R_ACC220BP
                                     WHERE	num = 1) b
                                   ON A.seqline = b.seqline) src
            ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
                        AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
                        AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
                        AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
                        AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
                        AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
                        AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
                        AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
                        AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
                        AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
                        AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
                        AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
                        AND NVL(A.AMT, 0) = NVL(SRC.AMT, 0)
                        AND NVL(A.BEAMT, 0) = NVL(SRC.BEAMT, 0))
            WHEN MATCHED
            THEN
                UPDATE SET A.calcamt = SRC.pos_2, A.becalcamt = SRC.pos_3, A.cgb = '2';



            FOR REC IN (SELECT A.SEQLINE,
                               A.ACCCODE,
                               A.ACCRNAME,
                               A.ACCKNAME,
                               A.LRDIV,
                               A.PRTYN,
                               A.PRTDIV,
                               A.PRTBOLD,
                               A.SSEQLINE,
                               A.CALCSEQ,
                               A.CALCDIV,
                               A.CSEQLINE,
                               A.CGB,
                               A.OBJDATADIV,
                               NULLIF(A.amt - NVL(c.amt, 0), 0) AS pos_2,
                               NULLIF(A.calcamt - NVL(c.calcamt, 0), 0) AS pos_3,
                               CASE WHEN p_pretype = 1 THEN NULLIF(A.beamt - NVL(c.beamt, 0), 0) ELSE A.beamt END AS pos_4,
                               CASE WHEN p_pretype = 1 THEN NULLIF(A.becalcamt - NVL(c.becalcamt, 0), 0) ELSE A.becalcamt END AS pos_5
                        FROM   VGT.TT_ACACC0220R_ACC220A A
                               JOIN ACRPTM b
                                   ON b.compcode = p_compcode
                                      AND b.rptdiv = p_rptdiv
                                      AND b.rptyear = p_basisyy
                                      AND A.seqline = b.seqline
                               LEFT JOIN VGT.TT_ACACC0220R_ACC220AP c ON b.seqline = c.seqline
                               LEFT JOIN ACRPTM D
                                   ON D.compcode = p_compcode
                                      AND D.rptdiv = p_rptdiv
                                      AND D.rptyear = p_basisyy
                                      AND b.remark = D.seqline
                        WHERE  NVL(D.seqline, ' ') = ' ')
            LOOP
                -- 종료월에서 시작월자료를 감함
                UPDATE VGT.TT_ACACC0220R_ACC220A A
                SET    A.amt = REC.pos_2, A.calcamt = REC.pos_3, A.beamt = REC.pos_4, A.becalcamt = REC.pos_5
                WHERE  NVL(A.SEQLINE, ' ') = NVL(REC.SEQLINE, ' ')
                       AND NVL(A.ACCCODE, ' ') = NVL(REC.ACCCODE, ' ')
                       AND NVL(A.ACCRNAME, ' ') = NVL(REC.ACCRNAME, ' ')
                       AND NVL(A.ACCKNAME, ' ') = NVL(REC.ACCKNAME, ' ')
                       AND NVL(A.LRDIV, ' ') = NVL(REC.LRDIV, ' ')
                       AND NVL(A.PRTYN, ' ') = NVL(REC.PRTYN, ' ')
                       AND NVL(A.PRTDIV, ' ') = NVL(REC.PRTDIV, ' ')
                       AND NVL(A.PRTBOLD, ' ') = NVL(REC.PRTBOLD, ' ')
                       AND NVL(A.SSEQLINE, ' ') = NVL(REC.SSEQLINE, ' ')
                       AND NVL(A.CALCSEQ, 0) = NVL(REC.CALCSEQ, 0)
                       AND NVL(A.CALCDIV, ' ') = NVL(REC.CALCDIV, ' ')
                       AND NVL(A.CSEQLINE, ' ') = NVL(REC.CSEQLINE, ' ')
                       AND NVL(A.CGB, 0) = NVL(REC.CGB, 0)
                       AND NVL(A.OBJDATADIV, ' ') = NVL(REC.OBJDATADIV, ' ');
            END LOOP;


            -- 시작월의 기말재고를 종료월의 기초재고로 설정
            MERGE INTO VGT.TT_ACACC0220R_ACC220A A
            USING	   (SELECT A.SEQLINE,
                               A.ACCCODE,
                               A.ACCRNAME,
                               A.ACCKNAME,
                               A.LRDIV,
                               A.PRTYN,
                               A.PRTDIV,
                               A.PRTBOLD,
                               A.SSEQLINE,
                               A.CALCSEQ,
                               A.CALCDIV,
                               A.CSEQLINE,
                               A.CGB,
                               A.OBJDATADIV,
                               c.amt,
                               c.calcamt,
                               CASE WHEN p_pretype = 1 THEN c.beamt ELSE A.beamt END AS pos_4,
                               CASE WHEN p_pretype = 1 THEN c.becalcamt ELSE A.becalcamt END AS pos_5
                        FROM   VGT.TT_ACACC0220R_ACC220A A
                               JOIN ACRPTM b
                                   ON b.compcode = p_compcode
                                      AND b.rptdiv = p_rptdiv
                                      AND b.rptyear = p_basisyy
                                      AND A.seqline = b.seqline
                                      AND b.seqline <> b.remark
                               JOIN VGT.TT_ACACC0220R_ACC220AP c ON b.remark = c.seqline) src
            ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
                        AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
                        AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
                        AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
                        AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
                        AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
                        AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
                        AND NVL(A.PRTBOLD, ' ') = NVL(SRC.PRTBOLD, ' ')
                        AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
                        AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
                        AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
                        AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
                        AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
                        AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' '))
            WHEN MATCHED
            THEN
                UPDATE SET A.amt = src.amt, A.calcamt = src.calcamt, A.beamt = SRC.pos_4, A.becalcamt = SRC.pos_5;


		END IF;

		IF (p_div = 'P') THEN

			OPEN IO_CURSOR FOR

				SELECT NULLIF(CASE
								  WHEN A.lrdiv = 'L'
									   AND A.prtyn = 'Y'
								  THEN
									  A.amt
							  END,
							  0)
						   baldramt,
					   NULLIF(CASE
								  WHEN A.cgb = '2'
									   AND A.prtyn = 'Y'
								  THEN
									  A.calcamt
								  WHEN A.cgb <> '2'
									   AND A.lrdiv = 'R'
									   AND A.prtyn = 'Y'
								  THEN
									  A.amt
							  END,
							  0)
						   dramt,
					   NULL mondramt,
					   CASE WHEN A.amt >= 0 THEN A.accrname ELSE A.acckname END accname,
					   NULL moncramt,
					   NULLIF(CASE
								  WHEN A.lrdiv = 'L'
									   AND A.prtyn = 'Y'
								  THEN
									  A.beamt
							  END,
							  0)
						   cramt,
					   NULLIF(CASE
								  WHEN A.cgb = '2'
									   AND A.prtyn = 'Y'
								  THEN
									  A.becalcamt
								  WHEN A.cgb <> '2'
									   AND A.lrdiv = 'R'
									   AND A.prtyn = 'Y'
								  THEN
									  A.beamt
							  END,
							  0)
						   balcramt,
					   A.prtbold,
					   D.session1 || SUBSTR(p_strym, 0, 4) || '년  ' || SUBSTR(p_strym, 6, 2) || '월부터  ' || SUBSTR(p_endym, 6, 2) || '월까지' title1,
					   D.session2 || SUBSTR(p_beyy01, 0, 4) || '년  ' || SUBSTR(CASE WHEN p_pretype = '1' THEN p_strym ELSE p_beyy01 END, 6, 2) || '월부터  ' || SUBSTR(p_beyymm, 6, 2) || '월까지' title2,
					   --d.session1 + left(@endym,4) + '년  ' + substring(@endym,6,2) + '월  ' +
					   --right(convert(nvarchar(10), dateadd(month, 1, @endym+'-01')-1, 120), 2) + '일  현재' as title1,
					   --d.session2 + left(@beyymm,4) + '년  ' + substring(@beyymm,6,2) + '월  ' +
					   --right(convert(nvarchar(10), dateadd(month, 1, @beyymm+'-01')-1, 120), 2) + '일  현재' as title2,
					   CASE WHEN p_plantcode = '%' THEN '회사명 : ' || b.compname ELSE '사업장명 : ' || NVL(c.plantfullname, c.plantname) END compname,
					   '(단위 : 원)' prtunit,
					   NULL baldramt2,
					   NULL dramt2,
					   NULL mondramt2,
					   NULL accname2,
					   NULL moncramt2,
					   NULL cramt2,
					   NULL balcramt2
				FROM   VGT.TT_ACACC0220R_ACC220A A
					   LEFT JOIN CMCOMPM b ON b.compcode = p_compcode
					   LEFT JOIN CMPLANTM c ON c.plantcode = p_plantcode
					   LEFT JOIN (SELECT MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_endym, 0, 4) THEN sseq END) || '기  ') session1, MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_beyymm, 0, 4) THEN sseq END) || '기  ') session2
								  FROM	 ACSESSION
								  WHERE  compcode = p_compcode
										 AND cyear IN (SUBSTR(p_endym, 0, 4), SUBSTR(p_beyymm, 0, 4))) D
						   ON 1 = 1
				WHERE  A.prtdiv <> 'C'
					   AND (A.amt <> 0
							OR A.calcamt <> 0
							OR A.beamt <> 0
							OR A.becalcamt <> 0
							OR A.prtdiv = 'A');
		ELSE

			OPEN IO_CURSOR FOR

				SELECT CASE WHEN amt >= 0 THEN accrname ELSE acckname END accname,
					   NULLIF(CASE
								  WHEN lrdiv = 'L'
									   AND prtyn = 'Y'
								  THEN
									  amt
							  END,
							  0)
						   amt1,
					   NULLIF(CASE
								  WHEN cgb = '2'
									   AND prtyn = 'Y'
								  THEN
									  calcamt
								  WHEN cgb <> '2'
									   AND lrdiv = 'R'
									   AND prtyn = 'Y'
								  THEN
									  amt
							  END,
							  0)
						   amt2,
					   NULLIF(CASE
								  WHEN lrdiv = 'L'
									   AND prtyn = 'Y'
								  THEN
									  beamt
							  END,
							  0)
						   amt3,
					   NULLIF(CASE
								  WHEN cgb = '2'
									   AND prtyn = 'Y'
								  THEN
									  becalcamt
								  WHEN cgb <> '2'
									   AND lrdiv = 'R'
									   AND prtyn = 'Y'
								  THEN
									  beamt
							  END,
							  0)
						   amt4,
					   p_plantcode plantcode,
					   p_strym || '-01' strdate,
					   TO_CHAR(LAST_DAY(TO_DATE(p_endym, 'YYYY-MM')), 'YYYY-MM-DD') enddate,
					   acccode,
					   p_closediv closediv,
					   prtbold
				FROM   VGT.TT_ACACC0220R_ACC220A
				WHERE  prtdiv <> 'C'
					   AND (NVL(amt, 0) <> 0
							OR NVL(calcamt, 0) <> 0
							OR NVL(beamt, 0) <> 0
							OR NVL(becalcamt, 0) <> 0
							OR NVL(prtdiv, ' ') = 'A');
		END IF;

	ELSIF (p_div = 'Y') THEN

		OPEN IO_CURSOR FOR
			SELECT *
			FROM   (SELECT	 CASE WHEN cyear = SUBSTR(p_endym, 0, 4) THEN sseq ELSE sseq - cyear + TO_NUMBER(SUBSTR(p_endym, 0, 4)) END sseq, curstrdate
					FROM	 ACSESSION
					WHERE	 compcode = p_compcode
							 AND cyear <= SUBSTR(p_endym, 0, 4)
					ORDER BY cyear DESC)
			WHERE  ROWNUM <= 1;

	END IF;

   <<LAST>>
    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
