CREATE FUNCTION        fnSplit
-- ---------------------------------------------------------------
 -- 함 수 명              : fnSplit
 -- 작 성 자           : 강현철
 -- 작성일자           : 2007-10-26
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2016-11-23 
 -- ---------------------------------------------------------------
 -- 함수설명            : SPLIT 전용함수
 -- ---------------------------------------------------------------
(
    p_StrValue  IN VARCHAR2,-- 분리할 문자열
    p_SplitChar IN VARCHAR2 -- 구분할 문자  
)
--2017-02-06 :수정으로 인한 주석
--RETURN FN_SPLIT_TABLE PIPELINED
    
RETURN FN_SPLIT_TABLE
AS

    --자른거잿수?
    totalSplitCnt NUMBER := 0;
    
    --순번
    p_seq NUMBER := 1;
    
    --fetch
    p_split_data VARCHAR(1000) := '';

    --2017-02-06 :수정으로 인한 주석
    --함수내에서 변수 저장용 변수 초기화
    --splitRecode FN_SPLIT_VARIABLE := FN_SPLIT_VARIABLE(NULL, NULL); 

    --함수내에서 변수 저장용 변수 초기화
    splitRecode FN_SPLIT_TABLE := FN_SPLIT_TABLE(); 


    
    CURSOR splitCursor IS
        
        SELECT      REGEXP_SUBSTR(ORG_DATA, '[^'|| p_SplitChar ||']+', 1, LEVEL) sdata
        FROM        (SELECT p_StrValue AS ORG_DATA FROM DUAL)
        CONNECT BY  INSTR(ORG_DATA, p_SplitChar, 1, LEVEL - 1) > 0; 
    
BEGIN


    SELECT      COUNT(REGEXP_SUBSTR(ORG_DATA, '[^'|| p_SplitChar ||']+', 1, LEVEL)) totalSplitCnt
    INTO        totalSplitCnt
    FROM        (SELECT p_StrValue AS ORG_DATA FROM DUAL)
    CONNECT BY  INSTR(ORG_DATA, p_SplitChar, 1, LEVEL - 1) > 0;

    IF ( totalSplitCnt = 0 ) THEN

        --2017-02-06 :수정으로 인한 주석
        --변수 저장    
        --splitRecode.seq := 1;
        --splitRecode.codes := p_SplitChar;            
        -- TABLE에 데이터 담기
        --PIPE ROW(splitRecode);
        
            splitRecode.EXTEND;
            splitRecode( p_seq ) := FN_SPLIT_VARIABLE( 1, p_SplitChar );
                        
    ELSE
    
        OPEN splitCursor;
                           
        LOOP
            FETCH splitCursor INTO p_split_data;
            
                EXIT WHEN splitCursor%NOTFOUND;
            
                --2017-02-06 :수정으로 인한 주석
                --변수 저장    
                --splitRecode.seq := p_seq;
                --splitRecode.codes := p_split_data;                    
                -- TABLE에 데이터 담기
                --PIPE ROW(splitRecode);                
                
                splitRecode.EXTEND;
                splitRecode(p_seq) := FN_SPLIT_VARIABLE( p_seq, p_split_data );                
                                
                p_seq := p_seq + 1;
                                                                                 
        END LOOP;
        
        CLOSE splitCursor;
        
    END IF;
          
                    
    --리턴
    RETURN splitRecode ;

END;
/
