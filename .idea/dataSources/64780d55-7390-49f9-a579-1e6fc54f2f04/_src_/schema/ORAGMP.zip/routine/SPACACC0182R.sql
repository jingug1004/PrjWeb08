CREATE PROCEDURE        spACacc0182R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0182R
 -- 작 성 자         : 최용석
 -- 작성일자         : 2014-03-19
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-21
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 월별채권현황
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '%' ,
    p_slipym        IN VARCHAR2 DEFAULT '' ,
    p_acccode       IN VARCHAR2 DEFAULT '' ,
    p_custcode      IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,

    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_acccode1 VARCHAR2(20); -- 현금등가물
    p_acccode2 VARCHAR2(20); -- 받을어음
    p_acccode3 VARCHAR2(20); -- 지급어음
    p_acccode4 VARCHAR2(20); -- 외상매입금
    p_acccode5 VARCHAR2(20); -- 미지급금(거래처)
    p_strdate  VARCHAR2(10);
    p_enddate  VARCHAR2(10);
BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    IF ( p_div = 'S' ) THEN

        p_acccode1 := '11101' ;
        FOR  rec IN ( SELECT filter1
                      FROM   CMCOMMONM
                      WHERE  cmmcode = 'AC261'
                             AND divcode = '11101' )
        LOOP
            p_acccode1 := rec.filter1 ;
        END LOOP;

        p_acccode2 := '1110806' ;
        FOR  rec IN ( SELECT filter1
                      FROM   CMCOMMONM
                      WHERE  cmmcode = 'AC261'
                             AND divcode = '1110806' )
        LOOP
            p_acccode2 := rec.filter1 ;
        END LOOP;

        p_acccode3 := '21010200' ;
        FOR  rec IN ( SELECT filter1
                      FROM   CMCOMMONM
                      WHERE  cmmcode = 'AC261'
                             AND divcode = '21010200' )
        LOOP
            p_acccode3 := rec.filter1 ;
        END LOOP;

        p_acccode4 := '21010100' ;
        FOR  rec IN ( SELECT filter1
                      FROM   CMCOMMONM
                      WHERE  cmmcode = 'AC261'
                             AND divcode = '21010100' )
        LOOP
            p_acccode4 := rec.filter1 ;
        END LOOP;

        p_acccode5 := '21030200' ;
        FOR  rec IN ( SELECT filter1
                      FROM   CMCOMMONM
                      WHERE  cmmcode = 'AC261'
                             AND divcode = '21030200' )
        LOOP
            p_acccode5 := rec.filter1 ;
        END LOOP;

        p_strdate := SUBSTR(p_slipym, 0, 5) || '01-01' ;
        p_enddate := TO_CHAR(ADD_MONTHS(TO_DATE(p_slipym || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD') ;



        -- 1. 거래처별 잔액구하기
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0182R_ACORDSMM';

        INSERT INTO VGT.TT_ACACC0182R_ACORDSMM (
            SELECT  a.custcode ,
            MAX(b.dcdiv)  dcdiv  ,
            SUM(CASE WHEN b.dcdiv = '1' THEN a.bsdebamt - a.bscreamt
                     ELSE a.bscreamt - a.bsdebamt
                END)  restamt
            FROM ( SELECT   a.mngcluval custcode  ,
                            a.bsdebamt ,
                            a.bscreamt
                    FROM    ACORDSMM a
                    WHERE   a.compcode = p_compcode
                            AND a.plantcode LIKE p_plantcode
                            AND a.slipym = SUBSTR(p_slipym, 0, 5) || '01'
                            AND a.closediv IN ( '10','20' )
                            AND ( p_acccode IS NOT NULL AND a.acccode IN ( p_acccode4, p_acccode5 ) OR p_acccode IS NOT NULL AND a.acccode = p_acccode )
                            AND a.mngclucode = 'S010'
                            AND a.mngcluval LIKE p_custcode || '%'
                            AND a.mngcluval IS NOT NULL

                    UNION ALL
                    SELECT  b.mngcluval custcode  ,
                            a.debamt ,
                            a.creamt
                    FROM    ACORDD a
                            JOIN ACORDS b   ON a.compcode = b.compcode
                                               AND a.slipinno = b.slipinno
                                               AND a.slipinseq = b.slipinseq
                                               AND b.mngclucode = 'S010'
                                               AND b.mngcluval LIKE p_custcode || '%'
                                               AND b.mngcluval IS NOT NULL
                            JOIN ACORDM c   ON a.compcode = c.compcode
                                               AND a.slipinno = c.slipinno
                                               AND c.slipdiv <> 'F'
                    WHERE   a.compcode = p_compcode
                            AND a.plantcode LIKE p_plantcode
                            AND ( p_acccode IS NULL AND a.acccode IN ( p_acccode4,p_acccode5 ) OR p_acccode IS NOT NULL AND a.acccode = p_acccode )
                            AND a.slipdate BETWEEN p_strdate AND p_enddate
                 ) a
            JOIN ACACCM b ON p_acccode IS NULL
                             AND b.acccode = p_acccode4 OR p_acccode IS NOT NULL
                             AND b.acccode = p_acccode
            GROUP BY a.custcode

            HAVING SUM(CASE WHEN b.dcdiv = '1' THEN a.bsdebamt - a.bscreamt ELSE a.bscreamt - a.bsdebamt END)  <> 0 );



        -- 2. 거래처별 발생구하기

        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0182R_ACORDD';

        INSERT INTO VGT.TT_ACACC0182R_ACORDD
            SELECT  custcode ,
                    ROW_NUMBER() OVER ( PARTITION BY custcode ORDER BY slipno DESC, slipinseq DESC  ) seq  ,
                    slipdate ,
                    slipno ,
                    slipinseq ,
                    slipamt ,
                    0 sumamt
            FROM ( SELECT   b.custcode ,
                            SUBSTR(p_slipym, 0, 5) || '00-00' slipdate  ,
                            '' slipno  ,
                            0 slipinseq  ,
                            CASE WHEN b.dcdiv = '1' THEN a.bsdebamt - a.bscreamt ELSE a.bscreamt - a.bsdebamt END slipamt
                   FROM     ACORDSMM a
                            JOIN VGT.TT_ACACC0182R_ACORDSMM b   ON a.mngcluval = b.custcode
                                                                    AND b.restamt > 0
                   WHERE    a.compcode = p_compcode
                            AND a.plantcode LIKE p_plantcode
                            AND a.slipym = SUBSTR(p_slipym, 0, 5) || '01'
                            AND a.closediv IN ( '10','20' )
                            AND ( p_acccode IS NULL AND a.acccode IN ( p_acccode4,p_acccode5 ) OR p_acccode IS NOT NULL AND a.acccode = p_acccode )
                            AND a.mngclucode = 'S010'
                            AND a.mngcluval LIKE p_custcode || '%'
                            AND a.mngcluval IS NOT NULL
                            AND a.bsdebamt <> a.bscreamt
                   UNION ALL
                   SELECT  D.custcode ,
                           a.slipdate ,
                           a.slipno ,
                           b.slipinseq ,
                           b.debamt + b.creamt slipamt
                   FROM    ACORDM a
                           JOIN ACORDD b   ON a.compcode = b.compcode
                                              AND a.slipinno = b.slipinno
                                              AND ( p_acccode IS NULL AND b.acccode IN ( p_acccode4,p_acccode5 ) OR p_acccode IS NOT NULL AND b.acccode = p_acccode )
                                              AND b.slipdate BETWEEN p_strdate AND p_enddate
                           JOIN ACORDS c   ON b.compcode = c.compcode
                                              AND b.slipinno = c.slipinno
                                              AND b.slipinseq = c.slipinseq
                                              AND c.mngclucode = 'S010'
                           JOIN VGT.TT_ACACC0182R_ACORDSMM D   ON c.mngcluval = D.custcode
                                                                   AND ( D.dcdiv = '1'
                                                                         AND b.dcdiv IN ( '1','4' )
                                                                         AND b.debamt > 0 OR D.dcdiv = '2'
                                                                         AND b.dcdiv IN ( '2','3' )
                                                                         AND b.creamt > 0 )
                                                                   AND D.restamt > 0
                 ) a;



        MERGE INTO VGT.TT_ACACC0182R_ACORDD a
        USING (
                SELECT  NVL(b.sumamt, 0) AS sumamt
                        , a.custcode
                        , a.seq
                FROM    VGT.TT_ACACC0182R_ACORDD a
                        JOIN ( SELECT   a.custcode ,
                                        a.seq ,
                                        SUM(b.slipamt)  sumamt
                                FROM    VGT.TT_ACACC0182R_ACORDD a
                                        LEFT JOIN VGT.TT_ACACC0182R_ACORDD b ON a.custcode = b.custcode
                                                                                AND a.seq > b.seq
                                        GROUP BY a.custcode,a.seq ) b ON a.custcode = b.custcode
                                                                         AND a.seq = b.seq
        ) b ON ( a.custcode = b.custcode AND a.seq = b.seq )
        WHEN MATCHED THEN UPDATE SET a.sumamt = b.sumamt;



        DELETE FROM VGT.TT_ACACC0182R_ACORDD a
        WHERE  ( a.custcode, a.seq ) IN  (   SELECT  a.custcode
                                                    , a.seq
                                            FROM    VGT.TT_ACACC0182R_ACORDD a
                                                    JOIN ( SELECT   a.custcode ,
                                                                    MIN(a.seq)  seq
                                                            FROM    VGT.TT_ACACC0182R_ACORDD a
                                                                    JOIN VGT.TT_ACACC0182R_ACORDSMM b ON a.custcode = b.custcode
                                                                                                         AND a.sumamt >= b.restamt
                                                            GROUP BY a.custcode ) b ON a.custcode = b.custcode AND a.seq >= b.seq
                                         ) ;



        MERGE INTO VGT.TT_ACACC0182R_ACORDD a
        USING (
                SELECT  CASE WHEN b.restamt - a.sumamt >= a.slipamt THEN a.slipamt
                             ELSE b.restamt - a.sumamt
                        END AS slipamt
                        , a.custcode
                        , a.seq
                FROM    VGT.TT_ACACC0182R_ACORDD a
                        JOIN ( SELECT   a.custcode ,
                                        MAX(a.restamt)  restamt  ,
                                        MAX(b.seq)  seq
                                FROM    VGT.TT_ACACC0182R_ACORDSMM a
                                        JOIN VGT.TT_ACACC0182R_ACORDD b ON a.custcode = b.custcode
                                WHERE   a.restamt > 0
                                GROUP BY a.custcode ) b ON a.custcode = b.custcode
                                                           AND a.seq = b.seq
        ) b ON ( a.custcode = b.custcode AND a.seq >= b.seq )
        WHEN MATCHED THEN UPDATE SET a.slipamt = b.slipamt ;



        -- 3. 거래처별 지급구하기

        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0182R_ACORDD2';

        INSERT INTO VGT.TT_ACACC0182R_ACORDD2 (

            SELECT  D.custcode ,
                    a.slipinno ,
                    SUM(b.debamt + b.creamt)  slipamt
            FROM    ACORDM a
                    JOIN ACORDD b ON a.compcode = b.compcode
                                     AND a.slipinno = b.slipinno
                                     AND ( p_acccode IS NULL AND b.acccode IN ( p_acccode4,p_acccode5 ) OR p_acccode IS NOT NULL AND b.acccode = p_acccode )
                                     AND b.slipdate LIKE p_slipym || '%'
                    JOIN ACORDS c ON b.compcode = c.compcode
                                     AND b.slipinno = c.slipinno
                                     AND b.slipinseq = c.slipinseq
                                     AND c.mngclucode = 'S010'
            JOIN VGT.TT_ACACC0182R_ACORDSMM D ON c.mngcluval = D.custcode
                                                 AND ( D.dcdiv = '2' AND b.dcdiv IN ( '1','4' ) AND b.debamt > 0 OR
                                                       D.dcdiv = '1' AND b.dcdiv IN ( '2','3' ) AND b.creamt > 0 )
                                                 AND D.restamt > 0
            GROUP BY D.custcode,a.slipinno  );



        OPEN  IO_CURSOR FOR
            SELECT  a.custcode ,
                    MAX(c.custname)  custname  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '00' THEN a.slipamt ELSE 0 END)  bsamt  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '01' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt01  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '02' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt02  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '03' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt03  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '04' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt04  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '05' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt05  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '06' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt06  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '07' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt07  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '08' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt08  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '09' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt09  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '10' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt10  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '11' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt11  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 6, 2) = '12' AND SUBSTR(a.slipdate, 0, 7) <> p_slipym THEN a.slipamt ELSE 0 END)  inamt12  ,
                    SUM(CASE WHEN SUBSTR(a.slipdate, 0, 7) = p_slipym THEN a.slipamt ELSE 0 END)  inamtym  ,
                    MAX(b.restamt)  restamt  ,
                    NVL(MAX(D.paymethod) , '') paymethod  ,
                    NVL(MAX(D.payamt) , 0) payamt  ,
                    NVL(MAX(c.vatrate) , 0) vatrate

            FROM    VGT.TT_ACACC0182R_ACORDD a
                    JOIN VGT.TT_ACACC0182R_ACORDSMM b ON a.custcode = b.custcode
                    JOIN CMCUSTM c ON a.custcode = c.custcode
                                      AND c.vatrate > 0
                    LEFT JOIN ( SELECT  a.custcode ,
                                        MAX(slipamt)  payamt  ,
                                        MAX(CASE WHEN b.acccode LIKE p_acccode1 || '%' THEN '(현)' ELSE '' END)
                                            || MAX(CASE WHEN b.acccode LIKE p_acccode2 || '%' THEN '(받어)' ELSE '' END)
                                            || MAX(CASE WHEN b.acccode LIKE p_acccode3 || '%' THEN '(지어)' ELSE '' END)  paymethod
                                FROM    VGT.TT_ACACC0182R_ACORDD2 a
                                        JOIN ACORDD b ON b.compcode = p_compcode
                                                         AND a.slipinno = b.slipinno
                                        JOIN VGT.TT_ACACC0182R_ACORDSMM c ON a.custcode = c.custcode
                                                                             AND ( c.dcdiv = '1' AND b.dcdiv IN ( '1','4' ) AND b.debamt > 0 OR
                                                                                   c.dcdiv = '2' AND b.dcdiv IN ( '2','3' ) AND b.creamt > 0 )
                                GROUP BY a.custcode ) D ON a.custcode = D.custcode
            GROUP BY a.custcode
            UNION ALL
            SELECT  a.custcode ,
                    b.custname ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    a.restamt ,
                    a.restamt ,
                    '' ,
                    0 ,
                    b.vatrate
            FROM    VGT.TT_ACACC0182R_ACORDSMM a
                    JOIN CMCUSTM b   ON a.custcode = b.custcode
                                        AND b.vatrate > 0
            WHERE   a.restamt < 0
            ORDER BY vatrate, custcode;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
