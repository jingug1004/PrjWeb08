CREATE FUNCTION        F_GET_SORT_SEQ 
(
        V_EMPCODE  IN STRING
)
RETURN VARCHAR2
AS

        /*
        CHOE 20171109 
        HANAHR의 FUNC을 옮겨옴
        ORAGMP USER에 맞게 일부 내용 수정 함
        DEC 사번에 대해 우선 순위를 부여한다. 10자리 구성     
        A. 앞 1자리 - HR_CO_CLASCD_0 임원 여부 확인
                1. 임원 1  우선순위1 
                2. 그외 2         
        
        B. 2번째 자리 내근직우선
        1. 임원 0
        2. 서울사무소 1
        3. 상신 2      => 생산본부 CHOE 20160713
        4. 하길 3      =>연구본부
        5. 영업부 4
                  
        C. 3번째 ~ 6번째 부서간에 따른 순서 배정 (5자리) 
        영업부에 따른 detail 항목 1자리 + DERT_CD 그냥 붙여줌
                   
                    
        D. 8번째 ~ 10번째 자리 - HR_CO_CLASCD_0 임원에 따른 우선 순위 배정 (3자리)
        1. 임원 간의 우선 순위 배정 (ex 회장님 1번)
        2. 내근직 1번 하길 2번 상신 3번 영업부 4번 배정   
        */
        V_PAY_SORT_NO VARCHAR2(10);
        V_DEPT_SORT_NO VARCHAR2(1);
        V_DEPT_SORT_NO_D VARCHAR2(1);
        
        /*
         이부분은 해당 파리미터의 변수형 TYPE을 가져와요 
         WHY? 변수형이 변경된 경우 이렇게 선언한곳은 변경할 필요가 없어요
         ORAGMP.  USER 명을 꼭 써주세요 현재 ORAGMPQA 2가지 유저가 있어서 지정 필요
         
         REMARK에 임시로 임원 여부를 넣어 놨어요 !!!
        */        
        V_GRADEDIV ORAGMP.CMEMPM.GRADEDIV%TYPE; 
        V_DEPTCODE ORAGMP.CMEMPM.DEPTCODE%TYPE;
        V_REMARK ORAGMP.CMCOMMONM.REMARK%TYPE;         
        V_DIVCODE ORAGMP.CMCOMMONM.DIVCODE%TYPE;            

        
BEGIN

        IF V_EMPCODE = 'HANAPH' THEN                     --사원코드
                V_PAY_SORT_NO := '1000000000';          --SORTING 번호
                RETURN V_PAY_SORT_NO;
        END IF;
  
        /* 변수 초기화 */
        V_PAY_SORT_NO := '';
        V_DEPT_SORT_NO := '';
        V_DEPT_SORT_NO_D := '';
   
        /* 사번에 따른 직급&부서코드 가져옴 */
        SELECT NVL(GRADEDIV,'') ,NVL(DEPTCODE,'')
        INTO V_GRADEDIV ,V_DEPTCODE
        FROM ORAGMP.CMEMPM
        WHERE EMPCODE = V_EMPCODE
        AND GRADEDIV IS NOT NULL AND DEPTCODE IS NOT NULL;
    
        /* 부서코드에 따른 내근직/상신/하길/영업부 순으로 분리
        SELECT MIN(DECODE(DEPT_CD,'0001','1','0021','2','0020','3','0023','4','9'))   CHOE 20160713 BAK 
        */
        
        
        /* 부서코드에 따른 내근직/생산본부/영업본부/영업부 순으로 분리 */
        SELECT MIN(DECODE(DEPTCODE,'0001','1','0412','2','0437','3','0023','4','9'))
        INTO V_DEPT_SORT_NO
        FROM ORAGMP.CMDEPTM
        WHERE USEYN = 'Y'
        CONNECT BY  DEPTCODE = PRIOR PREDEPTCODE
        START WITH  DEPTCODE = V_DEPTCODE;    
   
        /* 부서코드에 따른 영업부 detail 종병/로컬/세미/도매  순으로 분리 */ 
        SELECT MIN(DECODE(DEPTCODE,'0040','1','0041','2','0042','3','0111','4','9'))
        INTO V_DEPT_SORT_NO_D
        FROM ORAGMP.CMDEPTM
        WHERE USEYN = 'Y'
        CONNECT BY  DEPTCODE = PRIOR PREDEPTCODE
        START WITH  DEPTCODE = V_DEPTCODE;
    
    
        /* 직급코드에 따른 임원여부&직급순서 가져옴 */
        SELECT REMARK ,DIVCODE
        INTO V_REMARK, V_DIVCODE               --V_REMARK 은 임원인 경우 먼저 표기하려고 한거에요
        FROM ORAGMP.CMCOMMONM                --직급 commonm form
        WHERE DIVCODE = V_GRADEDIV
        AND CMMCODE = 'PS01'
        AND USEDIV   = 'Y';
    

        /* A 1자리*/
        IF V_REMARK = 'Y' THEN
                V_PAY_SORT_NO := V_PAY_SORT_NO||'1';
        ELSE
                V_PAY_SORT_NO := V_PAY_SORT_NO||'2';
        END IF;
   
        /* B 1자리*/
        IF V_REMARK = 'Y' THEN
                V_PAY_SORT_NO := V_PAY_SORT_NO||'0';
        ELSE    
                V_PAY_SORT_NO := V_PAY_SORT_NO||V_DEPT_SORT_NO;      
        END IF;
   
        /* C 5자리*/ 
        IF V_REMARK = 'Y' THEN
                V_PAY_SORT_NO := V_PAY_SORT_NO||'00000';
        ELSE 
                IF V_DEPTCODE = '0012' THEN  /*총무부인 경우*/
                        IF V_DEPT_SORT_NO_D = '9' THEN /*상단에서 9를 가져옴*/
                                V_DEPT_SORT_NO_D := '1';
                        END IF;   
                END IF;
                V_PAY_SORT_NO := V_PAY_SORT_NO||V_DEPT_SORT_NO_D;     
                V_PAY_SORT_NO := V_PAY_SORT_NO||V_DEPTCODE;
        END IF;    

        /* D. 직급 코드를 뒤에 5자리를 붙여서 순서 정함*/
        V_PAY_SORT_NO := V_PAY_SORT_NO||SUBSTR(V_DIVCODE ,3 ,3);
        /*IF LENGTH(V_DIVCODE) = 1 THEN
                V_PAY_SORT_NO := V_PAY_SORT_NO||'00'||V_DIVCODE;
        END IF;
           
        IF LENGTH(V_DIVCODE) = 2 THEN
                V_PAY_SORT_NO := V_PAY_SORT_NO||'0'||V_DIVCODE;
        END IF;
           
        IF LENGTH(V_DIVCODE) = 3 THEN
                V_PAY_SORT_NO := V_PAY_SORT_NO||V_DIVCODE;
        END IF;*/
  
        DBMS_OUTPUT.PUT_LINE(' V_PAY_SORT_NO:'||V_PAY_SORT_NO);
        RETURN V_PAY_SORT_NO;
  
EXCEPTION
        WHEN NO_DATA_FOUND THEN
                IF V_PAY_SORT_NO IS NULL THEN
                        V_PAY_SORT_NO := '99999';
                END IF;
        RETURN V_PAY_SORT_NO;
END;
/
