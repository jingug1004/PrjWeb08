CREATE PROCEDURE        spACacc0900PP6
-- ---------------------------------------------------------------
 -- 프로시저명   : spACacc0900PP6
 -- 작 성 자   : 최용석
 -- 작성일자    : 2017-12-01
 -- ---------------------------------------------------------------
 -- 프로시저 설명 : 구매회계로드
 -- ---------------------------------------------------------------
(
    p_div               IN VARCHAR2 DEFAULT '',
    
    p_compcode          IN VARCHAR2 DEFAULT '',
    p_plantcode         IN VARCHAR2 DEFAULT '',
    p_sdt               IN VARCHAR2 DEFAULT '',
    p_edt               IN VARCHAR2 DEFAULT '',
    p_loadstatus        IN VARCHAR2 DEFAULT '',
    p_custcode          IN VARCHAR2 DEFAULT '',
    p_iempcode          IN VARCHAR2 DEFAULT '',
    
    p_userid            IN VARCHAR2 DEFAULT '',
    p_reasondiv         IN VARCHAR2 DEFAULT '',
    p_reasontext        IN VARCHAR2 DEFAULT '',

    MESSAGE             OUT VARCHAR2,
    IO_CURSOR           OUT TYPES.DataSet
)
AS
    v_closecnt          NUMBER := 0;
BEGIN

    message := '데이터 확인' ;

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    for rec in (  select  count(*) as closecnt
                  from    dual
                  where   exists (  select  *
                                    from    CMCLOSEM
                                    where   compcode = p_compcode
                                            and closeym between substr(p_sdt,0,7) and substr(p_edt,0,7)
                                            and accdiv = 'P'
                                            and apprcloseyn = 'Y' ) )
    loop
        v_closecnt := rec.closecnt;
    end loop ;

    if v_closecnt > 0 then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;

        return;
    end if;

    execute immediate 'delete from VGT.TT_ACACC0900PP5_PDIMPORTCOSTM';
    insert into VGT.TT_ACACC0900PP5_PDIMPORTCOSTM
    select  a.warehousingno
            ,max(b.lccode) as lccode
            ,max(b.lcname) as lcname
    from (
        select  a.warehousingno
                ,d.lccode
        from    PDWAREHOUSINGM a
                join PDPURCHASEORDERM b
                    on a.orderno = b.orderno
                join PDIMPORTSHEETD c
                    on b.orderno = c.requestno
                    and b.itemcode = c.itemcode
                join PDIMPORTSHEETM d
                    on c.importshtno = d.importshtno
        where   a.plantcode like '%'
                and a.accountday between p_sdt and p_edt
                and nvl(a.custcode,' ') like '%'
                and nvl(a.warehousingremark,' ') <> '기초재고'

        union

        select  a.warehousingreturningno
                ,e.lccode
        from    PDWAREHOUSINGRM a
                join PDWAREHOUSINGM b
                    on a.warehousingdiv = b.warehousingdiv
                    and a.warehousingno = b.warehousingno
                join PDPURCHASEORDERM c
                    on b.orderno = c.orderno
                join PDIMPORTSHEETD d
                    on c.orderno = d.requestno
                    and c.itemcode = d.itemcode
                join PDIMPORTSHEETM e
                    on d.importshtno = e.importshtno
        where   b.plantcode like '%'
                and a.accountday between p_sdt and p_edt
                and nvl(b.custcode,' ') like '%'
                and nvl(a.workdiv,'02') = '02'
    ) a
            left join ACLCM b
                on a.lccode = b.lccode
    group by a.warehousingno;

    execute immediate 'delete from VGT.TT_ACACC0900PP5_PDWAREHOUSINGM';
    insert into VGT.TT_ACACC0900PP5_PDWAREHOUSINGM
    select   a.accountday
            ,a.accountseq
            ,a.accountno
            ,a.accountcheck
            ,a.warehousingno
            ,a.custcode
            ,a.buydiv
            ,nvl(b.ritemcode,a.itemcode) as itemcode
            ,a.warehousingprice
            ,a.warehousingamt
            ,a.finishamt
            ,a.vat
            ,a.warehousingstate
            ,a.plantcode
    from    PDWAREHOUSINGM a
            left join PDITEMRELATION b
                on a.itemcode = b.itemcode
    where   a.plantcode like p_plantcode
                and a.accountday between p_sdt and p_edt
                and nvl(a.warehousingremark,' ') <> '기초재고'
                and nvl(a.changechk,'N') = 'N'
                and trim(a.custcode) is not null;

    insert into VGT.TT_ACACC0900PP5_PDWAREHOUSINGM
    select   a.accountday
            ,a.accountseq
            ,a.accountno
            ,a.discountchk
            ,a.warehousingno
            ,b.custcode
            ,b.buydiv
            ,nvl(c.ritemcode,b.itemcode) as itemcode
            ,case when a.discountdiv = '03' then a.dcpricea - a.dcpriceb else a.dcpriceb - a.dcpricea end as warehousingprice
            ,case when a.discountdiv = '03' then a.discountamt else -a.discountamt end as warehousingamt
            ,case when a.discountdiv = '03' then a.discountamt else -a.discountamt end as finishamt
            ,case when a.discountdiv = '03' then a.discountvat else -a.discountvat end as vat
            ,b.warehousingstate
            ,b.plantcode
    from    PDPURCHASEDC a
            join PDWAREHOUSINGM b
                on a.warehousingno = b.warehousingno
                and b.finishamt <> 0
            left join PDITEMRELATION c
                on b.itemcode = c.itemcode
    where   a.accountday between p_sdt and p_edt
            and b.plantcode like p_plantcode;

    insert into VGT.TT_ACACC0900PP5_PDWAREHOUSINGM
    select   a.accountday 
            ,a.accountseq
            ,a.accountno
            ,a.accountcheck
            ,a.warehousingreturningno
            ,b.custcode
            ,b.buydiv
            ,nvl(c.ritemcode,a.itemcode) as itemcode
            ,-a.warehousingreturningprice
            ,-a.warehousingreturningamt
            ,-a.warehousingreturningamt
            ,-a.vat
            ,b.warehousingstate
            ,a.plantcode
    from    PDWAREHOUSINGRM a
            join PDWAREHOUSINGM b
                on a.plantcode = b.plantcode
                and a.warehousingdiv = b.warehousingdiv
                and a.warehousingno = b.warehousingno
            left join PDITEMRELATION c on a.itemcode = c.itemcode
    where   a.plantcode like p_plantcode
            and a.accountday between p_sdt and p_edt
            and nvl(a.workdiv,'02') = '02';

    execute immediate 'delete from VGT.TT_ACACC0900PP6_DUAL';
    -- 기본 세금계산서 자료 조회
    insert into VGT.TT_ACACC0900PP6_DUAL
    select  p_compcode,                                           -- 회사코드
            nvl(h.plantcode,a.plantcode) plantcode,               -- 사업장코드
            b.plantname,                                          -- 사업장명
            'N' as chkyn,                                         -- 선택
            a.taxdate,                                            -- 발행일자
            a.taxseq,                                             -- 발행순번
            a.custcode,                                           -- 거래처코드
            c.custname,                                           -- 거래처명
            a.buydiv,                                             -- 매입구분
            d.divname,                                            -- 매입구분명
            e.deptcode,                                           -- 부서코드
            f.deptname,                                           -- 부서명
            coalesce(a.taxno,a.warehousingno,'') as taxno,        -- 계산서번호
            a.lccode,
            a.lcname,
            nvl(a.warehousingprice,0),                            -- 입고단가
            nvl(a.warehousingamt,0),                              -- 입고금액
            nvl(a.finishamt,0),                                   -- 확정금액
            nvl(a.finishamt1,0),                                  -- 원재료매입액
            nvl(a.finishamt2,0),                                  -- 부재료매입액
            nvl(a.finishamt3,0),                                  -- 저장품매입액
            nvl(a.finishamt4,0),                                  -- 외주가공비
            nvl(a.finishamt5,0),                                  -- 상품매입액
            nvl(a.finishamt6,0),                                  -- 수입원재료매입액
            nvl(a.finishamt7,0),                                  -- 수입상품매입액
            nvl(a.finishamt8,0),                                  -- 제조복리후생비
            nvl(a.finishamt9,0),                                  -- 제조수선비
            nvl(a.finishamt10,0),                                 -- 제조운반비
            nvl(a.finishamt11,0),                                 -- 제조도서인쇄비
            nvl(a.finishamt12,0),                                 -- 제조포장비
            nvl(a.finishamt13,0),                                 -- 제조소모품비
            nvl(a.finishamt14,0),                                 -- 제조지급수수료
            nvl(a.finishamt15,0),                                 -- 제조시험연구비
            nvl(a.finishamt16,0),                                 -- 경상시험연구비
            nvl(a.vat,0),                                         -- 부가세
            nvl(a.finishamt,0) + nvl(a.vat,0),                    -- 합계금액
            case when a.icntitem > 1
                 then a.remark || ' 외' || to_char(a.icntitem - 1) || '건'
                 else a.remark end,                               -- 비고
            c.businessno,                                         -- 사업자번호
            c.taxdiv,                                             -- 거래처 세금계산서 구분(cm16) 1:월말 2:건별 3:영세 4:면세
            g.divname,                                            -- 거래처 세금계산서 구분명
            a.icntitem,                                           -- 품목건수
            nvl(h.importsdate,p_sdt),                             -- 시작일
            nvl(h.importedate,p_edt),                             -- 종료일
            case when length(rtrim(c.businessno)) = 12 then '01' else '02' end,  -- 사업자구분
            case when a.icntitem > 1
                 then a.remark || ' 외' || to_char(a.icntitem - 1) || '건'
                 else a.remark end,                               -- 적요
            case when a.warehousingno is not null then 'P01011' else 'P010' || a.buydiv end autorulecode, -- 자동분계코드
            case when i.taxno is null then '1'
                 when i.slipinno is null then '2'
                 when j.slipinno is null or ( select  sum(creamt)
                                              from    ACORDD
                                              where   compcode = j.compcode
                                                      and slipinno = j.slipinno ) - a.finishamt - a.vat <> 0 then '3'
                 else '2' end,                                    -- 전표자료상태
            case when i.taxno is null then '신규로드전송전'
                 when i.slipinno is null then '로드완료전표처리전'
                 when j.slipinno is null or ( select  sum(creamt)
                                              from    ACORDD
                                              where   compcode = j.compcode
                                                      and slipinno = j.slipinno ) - a.finishamt - a.vat <> 0 and j.slipinstate <> '4' then '회계전표재전송'
                 when ( select  sum(creamt)
                        from    ACORDD
                        where   compcode = j.compcode
                                and slipinno = j.slipinno ) - a.finishamt - a.vat <> 0 and j.slipinstate = '4' then '회계전표재전송(승인)'
                 when j.slipinstate = '4' then '전표처리완료(승인)'
                 else '전표처리완료' end,                           -- 전표자료상태명
            i.slipinno,
            case when a.warehousingno is not null then '4'
                 when a.taxno is null then '1'
                 when h.taxno is null or a.finishamt - h.amt <> 0 or a.vat - h.vat <> 0 then '3'
                 else '2' end,                                    -- 계산서자료상태
            case when a.warehousingno is not null then '계산서미전송'
                 when a.taxno is null then '신규로드전송전'
                 when h.taxno is null or a.finishamt - h.amt <> 0 or a.vat - h.vat <> 0 then '계산서재전송'
                 else '계산서처리완료' end,                         -- 계산서자료상태명
            case when i.slipinno is null then 'N'
                 when j.slipinno is null then 'Y'
                 else 'N' end                                     -- 전표처리여부
    from (    -- 구매발주표준구분(CMM54) 01:원자재 02:수입상품 03:위탁제품
              -- 품목구분(CMM01) 01: 원료, 02: 자재, 03: 제조제품 04: 완제품 05: 상품 06:제조용수 09:기타
              -- 제품종류(CM41) 01: 제품, 02: 상품, 03: oem 04: 수탁 05:제품(원료) 06:상품(원료) 07:상품(외주)
        select  a.plantcode,                                                                                                          -- 사업장코드
                a.custcode,                                                                                                           -- 거래처코드
                a.accountday as taxdate,                                                                                              -- 세금계산서일자
                nvl(a.accountseq,0) as taxseq,                                                                                        -- 세금계산서순번
                a.accountno as taxno,                                                                                                 -- 세금계산서번호
                nvl(a.buydiv,'01') as buydiv,                                                                                         -- 매입구분(mpm17)    01:과세 02:면세 03:영세율 04:선급 05:의제
                sum(a.warehousingprice) as warehousingprice,                                                                          -- 입고단가 -> 입고 시점 단가
                sum(a.warehousingamt) as warehousingamt,                                                                              -- 입고금액 -> 입고 시점 금액
                sum(a.finishamt) as finishamt,                                                                                        -- 확정금액 -> 입고 후 단가 수정 후 입고금액
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '12080000' then a.finishamt else 0 end) as finishamt1,   -- 원재료매입액
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '12170000' then a.finishamt else 0 end) as finishamt2,   -- 부재료매입액
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '12220000' then a.finishamt else 0 end) as finishamt3,   -- 저장품매입액
                sum(case when b.warehousingno is null and d.itemdiv in ('03','04') then a.finishamt else 0 end) as finishamt4,                -- 외주가공비
                sum(case when b.warehousingno is null and d.itemdiv = '05' then a.finishamt else 0 end) as finishamt5,                        -- 상품매입액
                sum(case when b.warehousingno is not null and d.itemdiv = '01' then a.finishamt else 0 end) as finishamt6,                    -- 수입원재료매입액
                sum(case when b.warehousingno is not null and d.itemdiv = '05' then a.finishamt else 0 end) as finishamt7,                    -- 수입상품매입액
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '43010000' then a.finishamt else 0 end) as finishamt8,   -- 제조복리후생비
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '43100000' then a.finishamt else 0 end) as finishamt9,   -- 제조수선비
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '43140000' then a.finishamt else 0 end) as finishamt10,  -- 제조운반비
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '43160000' then a.finishamt else 0 end) as finishamt11,  -- 제조도서인쇄비
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '43180000' then a.finishamt else 0 end) as finishamt12,  -- 제조포장비
                sum(case when b.warehousingno is null and coalesce(f.filter2,e.filter2,'43200000') = '43200000' then a.finishamt else 0 end) as finishamt13,  -- 제조소모품비
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '43210000' then a.finishamt else 0 end) as finishamt14,  -- 제조지급수수료
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '43240000' then a.finishamt else 0 end) as finishamt15,  -- 제조시험연구비
                sum(case when b.warehousingno is null and nvl(f.filter2,e.filter2) = '73560000' then a.finishamt else 0 end) as finishamt16,  -- 경상시험연구비
                max(d.itemname) as remark,                                                                                            -- 품목명
                count(*) as icntitem,                                                                                                 -- 품목건수
                sum(case when a.buydiv = '04' or b.warehousingno is not null then 0 else a.vat end) as vat,                           -- 부가세
                max(a.accountcheck) as accountcheck,                                                                                  -- 회계전표 연결 확인
                min(nvl(b.warehousingno, case when a.buydiv = '04' then a.warehousingno end)) as warehousingno,
                max(b.lccode) as lccode,
                max(b.lcname) as lcname
        from    VGT.TT_ACACC0900PP5_PDWAREHOUSINGM a
                left join VGT.TT_ACACC0900PP5_PDIMPORTCOSTM b
                    on a.warehousingno = b.warehousingno
                left join CMCOMMONM c
                    on c.cmmcode = 'MPM04'
                    and upper(c.filter2) = upper('Acc')
                    and a.warehousingstate = c.divcode
                left join CMITEMM d
                    on a.itemcode = d.itemcode
                left join CMCOMMONM e
                    on e.cmmcode = 'MPM09'
                    and d.itembranch = e.divcode
                left join CMCOMMONM f
                    on f.cmmcode = 'MPM85'
                    and d.directcostyn = f.divcode
        group by a.plantcode, a.custcode, a.accountday, nvl(a.accountseq,0), nvl(a.buydiv,'01'), a.accountno
    ) a
            left join CMCUSTM c
                on a.custcode = c.custcode
            left join CMCOMMONM d
                on d.cmmcode = 'MPM17'
                and a.buydiv = d.divcode
            left join CMEMPM e
                on e.empcode = p_iempcode
            left join CMDEPTM f
                on e.deptcode = f.deptcode
            left join CMCOMMONM g
                on g.cmmcode = 'CM16'
                and g.divcode = c.taxdiv
            left join ACTAXM h
                on h.compcode = p_compcode
                and a.taxno = h.taxno
            left join CMPLANTM b
                on nvl(h.plantcode,a.plantcode) = b.plantcode
            left join ACAUTOORDT i
                on i.compcode = p_compcode
                and i.acatrulecode like 'P010%'
                and a.taxno = i.acatno
            left join ACORDM j
                on i.compcode = j.compcode
                and i.slipinno = j.slipinno
    order by a.custcode ;

    -- 삭제 상태 확인
    insert into VGT.TT_ACACC0900PP6_DUAL
    select  a.compcode,
            a.plantcode,
            d.plantname,
            'N' as chkyn,
            a.slipindate,
            1 as slipinseq,
            a.custcode,
            a.userdef6code as custname,
            g.divcode as buydiv,
            g.divname as buydivname,
            a.deptcode,
            a.userdef4code as deptname,
            a.taxno,
            a.userdef9code as lccode,
            a.userdef10code as lcname,
            0 as warehousingprice,
            0 as warehousingamt,
            nvl(a.trn1amt,0) + nvl(a.trn2amt,0) + nvl(a.trn3amt,0) + nvl(a.trn4amt,0) + nvl(a.trn5amt,0) as finishamt,
            nvl(a.trn1amt,0) as finishamt1,
            nvl(a.trn2amt,0) as finishamt2,
            nvl(a.trn3amt,0) as finishamt3,
            nvl(a.trn4amt,0) as finishamt4,
            nvl(a.trn5amt,0) as finishamt5,
            nvl(a.trn11amt,0) as finishamt6,
            nvl(a.trn12amt,0) as finishamt7,
            nvl(a.trn13amt,0) as finishamt8,
            nvl(a.trn14amt,0) as finishamt9,
            nvl(a.trn15amt,0) as finishamt10,
            nvl(a.trn16amt,0) as finishamt11,
            nvl(a.trn17amt,0) as finishamt12,
            nvl(a.trn18amt,0) as finishamt13,
            nvl(a.trn19amt,0) as finishamt14,
            nvl(a.trn20amt,0) as finishamt15,
            nvl(a.trn21amt,0) as finishamt16,
            nvl(a.trn9amt,0) as vat,
            nvl(a.trn10amt,0) as sumamt,
            a.remark || '[삭제]' as remark,
            c.businessno,
            e.taxdiv,
            h.divname as taxdivname,
            0 as icntitem,
            e.importsdate as sdt,
            e.importedate as edt,
            case when length(rtrim(c.businessno)) = 12 then '01' else '02' end, -- 사업자구분
            a.remark || '[삭제]' as itemnm,
            a.acatrulecode,
            case when f.slipinno is not null then '4' else '2' end,
            case when f.slipinno is not null then '전표삭제전송필요' else '' end,
            f.slipinno,
            case when e.taxno is not null then '4' else '2' end as taxloadyn,
            case when e.taxno is not null then '계산서삭제전송필요' else '' end as taxloadtatus,
            'N' newchk
    from    ACAUTOORDT a
            left join VGT.TT_ACACC0900PP6_DUAL b
                on a.acatno = b.taxno
            left join CMCUSTM c
                on a.custcode = c.custcode
            left join CMPLANTM d
                on a.plantcode = d.plantcode
            left join ACTAXM e
                on a.compcode = e.compcode
                and a.taxno = e.taxno
            left join ACORDM f
                on a.compcode = f.compcode
                and a.slipinno = f.slipinno
            left join CMCOMMONM g
                on g.cmmcode = 'MPM17'
                and substr(a.acatrulecode,-2) = g.divcode
            left join CMCOMMONM h
                on h.cmmcode = 'CM16'
                and e.taxdiv = h.divcode
    where   a.compcode = p_compcode
            and a.acattype = 'P'
            and a.acatrulecode like 'P010%'
            and a.slipindate between p_sdt and p_edt
            and b.taxno is null;

    if ( p_loadstatus = '1' or p_loadstatus = '2' or p_loadstatus = '3' ) then --로드 상태를 선택
        delete
        from   VGT.TT_ACACC0900PP6_DUAL
        where  actrnstate not in ( ( select  filter1
                                     from    CMCOMMONM
                                     where   cmmcode = 'AC082'
                                             and divcode = p_loadstatus )

                                 , ( select  filter2
                                     from    CMCOMMONM
                                     where   cmmcode = 'AC082'
                                             and divcode = p_loadstatus ) );
    end if;

    if ( p_plantcode <> '%' ) then
        delete
        from    VGT.TT_ACACC0900PP6_DUAL
        where   plantcode <> p_plantcode;
    end if;

    if ( p_custcode is not null ) then
        delete
        from    VGT.TT_ACACC0900PP6_DUAL
        where   custcode <> p_custcode;
    end if;

    if ( p_div = 'S' ) then
        open IO_CURSOR for
        select  *
        from    VGT.TT_ACACC0900PP6_DUAL
        order by plantcode, custcode, slipindate, slipinseq;
    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
