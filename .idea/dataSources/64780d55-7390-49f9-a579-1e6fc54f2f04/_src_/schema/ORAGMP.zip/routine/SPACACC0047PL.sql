CREATE PROCEDURE        SPACACC0047PL(
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0047PL
-- 작 성 자         : 최용석
-- 작성일자         : 2011-02-22
-- 수정일자      :   노영래
-- E-mail      :   0rae0926@gmail.com
-- 수정일자      :   2016-12-12
-- ---------------------------------------------------------------
-- 프로시저 설명    : 자동분개 불러오기를 처리하는 프로시저이다.
-- ---------------------------------------------------------------
    p_div           IN  VARCHAR2 DEFAULT '',

    p_compcode      IN  VARCHAR2 DEFAULT '',
    p_slipdiv       IN  VARCHAR2 DEFAULT '',
    p_program       IN  VARCHAR2 DEFAULT '',
    p_iempcode      IN  VARCHAR2 DEFAULT '',

    p_userid        IN  VARCHAR2 DEFAULT '',
    p_reasondiv     IN  VARCHAR2 DEFAULT '',
    p_reasontext    IN  VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DATASET
)
AS
    v_temp              NUMBER            := 0;
    p_acccode1          VARCHAR2(20 CHAR) := ''; -- 미수금_카드
    p_acccode2          VARCHAR2(20 CHAR) := ''; -- 선급부가세
    p_acccode3          VARCHAR2(20 CHAR) := ''; -- 예수부가세
    p_acccode4          VARCHAR2(20 CHAR) := ''; -- 미지급금(거래처)
    p_acccode5          VARCHAR2(20 CHAR) := ''; -- 선급금
    p_strartym          VARCHAR2(7 CHAR)  := '';
    p_endym             VARCHAR2(7 CHAR)  := '';
    p_ideptcode         VARCHAR2(20 CHAR) := '';
    p_insertdt          DATE              := null;
    p_slipinno          VARCHAR2(20 CHAR) := '';
    p_proccnt           NUMBER            := 0;
    p_salload           VARCHAR2(30 CHAR) := '';
    p_colload           VARCHAR2(30 CHAR) := '';
    p_colseq            VARCHAR2(30)      := '';
    p_expload           VARCHAR2(30 CHAR) := '';
    p_salecust          VARCHAR2(1)       := '';
    p_colcust           VARCHAR2(1)       := '';

    CURSOR SPACC_CURSOR
    is
        select  distinct replace(a.slipindate,'-','') || a.acattype || NVL(b.slipinnum,c.slipinnum) as slipinno
        from    ACAUTOORDT a
                left join VGT.TT_ACACC0047PL_ACAUTOORDT1 b
                    on a.compcode = b.compcode
                    and a.plantcode = b.plantcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and case when p_salload = 'empcode' and a.acattype = 'S' then a.empcode
                             when p_salload = 'iempcode' and a.acattype = 'S' then a.iempcode
                             when p_salload = 'newload' and a.acattype = 'S' then a.iempcode
                             when p_salload = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                             when p_colload = 'empcode' and a.acattype = 'C' then a.empcode
                             when p_colload = 'iempcode' and a.acattype = 'C' then a.iempcode
                             when p_colload = 'newload' and a.acattype = 'C' then a.iempcode
                             when p_colload = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                             when p_colload = 'custcode' and a.acattype = 'C' then a.custcode
                             when p_expload = 'importshtno' and a.acattype = 'N' then a.billno
                             when a.acattype = 'H' then a.plantcode
                             else ''
                             end = b.acatrulecode
                left join VGT.TT_ACACC0047PL_ACAUTOORDT2 c
                    on a.compcode = c.compcode
                    and a.acattype = c.acattype
                    and a.slipindate = c.slipindate
                    and a.acatno = c.acatno
        where   a.compcode = p_compcode
                and a.actrnstate in ('1', '3')
                and a.acattype like p_slipdiv
                and a.acattype = 'N'
                and trim(p_expload) is not null
        order by slipinno ;
BEGIN

    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values(p_userid, p_reasondiv, p_reasontext);

    v_temp := 0;
    select  count(*) into v_temp
    from    DUAL
    where   not exists( select  *
                        from    ACAUTOORDT
                        where   compcode = p_compcode
                                and actrnstate in ('1', '3', '4')
                                and acattype like p_slipdiv
                                and acattype not in ( select  case b.grp when 1 then a.value1 when 2 then a.value2 else a.value3 end as value
                                                      from    SYSPARAMETERMANAGE a
                                                              join (
                                                                  select 1 grp from DUAL
                                                                  union
                                                                  select 2 from DUAL
                                                                  union
                                                                  select 3 from DUAL
                                                              ) b on 1 = 1
                                                      where   parametercode = 'accotherload'
                                                              and trim(p_program) is null)
                                and acattype not in ( select  case b.grp when 1 then a.value1 when 2 then a.value2 else a.value3 end value
                                                      from    SYSPARAMETERMANAGE a
                                                              join (
                                                                  select 1 grp from DUAL
                                                                  union
                                                                  select 2 from DUAL
                                                                  union
                                                                  select 3 from DUAL
                                                              ) b on 1 = 1
                                                      where   parametercode = 'accotherload2'
                                                              and trim(p_program) is null));

    if v_temp <> 0
    then
        MESSAGE := '0';
        goto LASTLINE;
    end if;

    p_acccode1 := '11120020';
    for rec in (
        select  filter1
        from    CMCOMMONM
        where   cmmcode = 'AC261'
                and divcode = '11120020')
    loop
        p_acccode1 := rec.filter1;
    end loop;

    p_acccode2 := '11135';
    for rec in (
        select  filter1
        from    CMCOMMONM
        where   cmmcode = 'AC261'
                and divcode = '11135')
    loop
        p_acccode2 := rec.filter1;
    end loop;

    p_acccode3 := '21050';
    for rec in (
        select  filter1
        from    CMCOMMONM
        where   cmmcode = 'AC261'
                and divcode = '21050')
    loop
        p_acccode3 := rec.filter1;
    end loop;

    p_acccode4 := '21030200';
    for rec in (
        select  filter1
        from    CMCOMMONM
        where   cmmcode = 'AC261'
                and divcode = '21030200')
    loop
        p_acccode4 := rec.filter1;
    end loop;

    p_acccode5 := '11131000';
    for rec in (
        select  filter1
        from    CMCOMMONM
        where   cmmcode = 'AC261'
                and divcode = '11131000')
    loop
        p_acccode5 := rec.filter1;
    end loop;

    -- 예산집계를 위한 일자범위 지정
    for rec in (
        select  min(substr(slipindate, 1, 7)) as strartym
                ,to_char(sysdate, 'yyyy-MM') as endym
        from    ACAUTOORDT
        where   compcode = p_compcode
                and actrnstate in ('1', '3', '4') -- 1신규, 2완료 3수정, 4삭제
                and acattype like p_slipdiv)
    loop
        p_strartym := rec.strartym;
        p_endym    := rec.endym;
    end loop;

    for rec in (
        select  deptcode
        from    CMEMPM
        where   empcode = p_iempcode)
    loop
        p_ideptcode := rec.deptcode;
    end loop;

    p_insertdt := sysdate;

    for rec in (
        select  value2
        from    SYSPARAMETERMANAGE
        where   parametercode = 'accsalload')
    loop
        p_salload := rec.value2;
    end loop;

    for rec in (
        select  value2, value3
        from    SYSPARAMETERMANAGE
        where   parametercode = 'acccolload')
    loop
        p_colload := rec.value2;
        p_colseq := rec.value3;
    end loop;

    for rec in (
        select  value2
        from    SYSPARAMETERMANAGE
        where   parametercode = 'accexpload')
    loop
        p_expload := rec.value2;
    end loop;

    -- 부문별 자료가 변경,삭제된 경우 기존자료(동일전표번호)를 수정으로 변경
    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.slipinno
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate in ('3', '4')
                    and a.acattype like p_slipdiv
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.slipinno = b.slipinno
                    and b.actrnstate = '2'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3';

    -- 매출 자료가 변경,삭제된 경우 신규자료(일자,사원)를 수정으로 변경
    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.empcode
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate = '1'
                    and a.acattype like p_slipdiv
                    and a.acattype = 'S'
                    and p_salload = 'empcode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.empcode = b.empcode
                    and b.actrnstate = '2'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3';

    merge into ACAUTOORDT b
    using (
        select b.compcode, b.acattype, b.acatno, a.slipinno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.empcode, a.slipinno
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate in ('3', '4')
                    and a.acattype like p_slipdiv
                    and a.acattype = 'S'
                    and p_salload = 'empcode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.empcode = b.empcode
                    and b.actrnstate = '1'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3',
                   b.slipinno = src.slipinno;

    merge into ACAUTOORDT b
    using (
        select b.compcode, b.acattype, b.acatno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.iempcode
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate = '1'
                    and a.acattype like p_slipdiv
                    and a.acattype = 'S'
                    and p_salload = 'iempcode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.iempcode = b.iempcode
                    and b.actrnstate = '2'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3';

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno, a.slipinno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.iempcode, a.slipinno
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
        where   a.compcode = p_compcode
                and a.actrnstate in ('3', '4')
                and a.acattype like p_slipdiv
                and a.acattype = 'S'
                and p_salload = 'iempcode'
    ) a
            join ACAUTOORDT b
                on a.compcode = b.compcode
                and a.acattype = b.acattype
                and a.slipindate = b.slipindate
                and a.iempcode = b.iempcode
                and b.actrnstate = '1'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3',
                   b.slipinno = src.slipinno;

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.acatrulecode, a.iempcode
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate = '1'
                    and a.acattype like p_slipdiv
                    and a.acattype = 'S'
                    and p_salload = 'acatrulecode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.acatrulecode = b.acatrulecode
                    and a.iempcode = b.iempcode
                    and b.actrnstate = '2'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3';

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno, a.slipinno
        from (
            select  distinct a.compcode,
                    a.acattype,
                    a.slipindate,
                    a.acatrulecode,
                    a.iempcode,
                    a.slipinno
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate in ('3', '4')
                    and a.acattype like p_slipdiv
                    and a.acattype = 'S'
                    and p_salload = 'acatrulecode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.acatrulecode = b.acatrulecode
                    and a.iempcode = b.iempcode
                    and b.actrnstate = '1'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3',
                   b.slipinno = src.slipinno;

    -- 수금 자료가 변경,삭제된 경우 신규자료(일자,사원)를 수정으로 변경
    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.empcode
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate = '1'
                    and a.acattype like p_slipdiv
                    and a.acattype = 'C'
                    and p_colload = 'empcode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.empcode = b.empcode
                    and b.actrnstate = '2'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3';

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno, a.slipinno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.empcode, a.slipinno
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate in ('3', '4')
                    and a.acattype like p_slipdiv
                    and a.acattype = 'C'
                    and p_colload = 'empcode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.empcode = b.empcode
                    and b.actrnstate = '1'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3',
                   b.slipinno = src.slipinno;

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.iempcode
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate = '1'
                    and a.acattype like p_slipdiv
                    and a.acattype = 'C'
                    and p_colload = 'iempcode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.iempcode = b.iempcode
                    and b.actrnstate = '2'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3';

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno, a.slipinno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.iempcode, a.slipinno
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate in ('3', '4')
                    and a.acattype like p_slipdiv
                    and a.acattype = 'C'
                    and p_colload = 'iempcode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.iempcode = b.iempcode
                    and b.actrnstate = '1'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3',
                   b.slipinno = src.slipinno;

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.acatrulecode, a.iempcode
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate = '1'
                    and a.acattype like p_slipdiv
                    and a.acattype = 'C'
                    and p_colload = 'acatrulecode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.acatrulecode = b.acatrulecode
                    and a.iempcode = b.iempcode
                    and b.actrnstate = '2'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3';

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno, a.slipinno
        from (
            select  distinct a.compcode,
                    a.acattype,
                    a.slipindate,
                    a.acatrulecode,
                    a.iempcode,
                    a.slipinno
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate in ('3', '4')
                    and a.acattype like p_slipdiv
                    and a.acattype = 'C'
                    and p_colload = 'acatrulecode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.acatrulecode = b.acatrulecode
                    and a.iempcode = b.iempcode
                    and b.actrnstate = '1'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3',
                   b.slipinno = src.slipinno;

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno
        from (
            select  distinct a.compcode, a.acattype, a.slipindate, a.custcode, a.iempcode
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate = '1'
                    and a.acattype like p_slipdiv
                    and a.acattype = 'C'
                    and p_colload = 'custcode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.custcode = b.custcode
                    and b.actrnstate = '2'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3';

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno, a.slipinno
        from (
            select  distinct a.compcode,
                    a.acattype,
                    a.slipindate,
                    a.custcode,
                    a.slipinno
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate in ('3', '4')
                    and a.acattype like p_slipdiv
                    and a.acattype = 'C'
                    and p_colload = 'custcode'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.custcode = b.custcode
                    and b.actrnstate = '1'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3',
                   b.slipinno = src.slipinno;

    merge into ACAUTOORDT b
    using (
        select  b.compcode, b.acattype, b.acatno
        from (
            select  distinct a.compcode, a.acattype, a.billno, a.slipindate
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate = '1'
                    and a.acattype like p_slipdiv
                    and a.acattype = 'N'
                    and p_expload = 'importshtno'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.billno = b.billno
                    and b.actrnstate = '2'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3';

    merge into ACAUTOORDT b
    using (
        select  b.compcode,
                b.acattype,
                b.acatno,
                a.slipindate,
                a.slipinno
        from (
            select  distinct a.compcode, a.acattype, a.billno, a.slipindate, a.slipinno
            from    ACAUTOORDT a
                    join ACAUTORULE b
                        on a.acatrulecode = b.acautorcode
                        and b.crtdiv = '1'
            where   a.compcode = p_compcode
                    and a.actrnstate in ('3', '4')
                    and a.acattype like p_slipdiv
                    and a.acattype = 'N'
                    and p_expload = 'importshtno'
        ) a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.billno = b.billno
                    and b.actrnstate = '1'
    ) src on (b.compcode = src.compcode
              and b.acattype = src.acattype
              and b.acatno = src.acatno)
    when matched
    then
        update set b.actrnstate = '3',
                   b.slipindate = src.slipindate,
                   b.slipinno = src.slipinno;

    -- 관리항목삭제
    delete
    from    ACORDS
    where   (compcode, slipinno) in ( select  compcode, slipinno
                                      from    ACAUTOORDT
                                      where   compcode = p_compcode
                                              and actrnstate in ('3','4')
                                              and acattype like p_slipdiv);

    -- 전표상세삭제
    delete
    from    ACORDD
    where   (compcode, slipinno) in ( select  compcode, slipinno
                                      from    ACAUTOORDT
                                      where   compcode = p_compcode
                                              and actrnstate in ('3','4')
                                              and acattype like p_slipdiv);

    -- 회계전표삭제
    delete
    from    ACORDM
    where   (compcode, slipinno) in ( select  compcode, slipinno
                                      from    ACAUTOORDT
                                      where   compcode = p_compcode
                                              and actrnstate in ('3','4')
                                              and acattype like p_slipdiv);

    -- 무역전표 마지막일자 생성을 위해 일자변경
    merge into ACAUTOORDT a
    using (
        select  a.compcode
                ,a.acattype
                ,a.acatno
                ,b.slipindate
        from    ACAUTOORDT a
                join (
                    select  a.compcode
                            ,a.acattype
                            ,a.billno
                            ,max(a.slipindate) as slipindate
                    from    ACAUTOORDT a
                            join ACAUTORULE b
                                on a.acatrulecode = b.acautorcode
                                and b.crtdiv = '1'
                    where   a.compcode = p_compcode
                            and a.actrnstate in ('1', '3')
                            and a.acattype like p_slipdiv
                            and a.acattype = 'N'
                            and p_expload = 'importshtno'
                    group by a.compcode, a.acattype, a.billno
                ) b on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.billno = b.billno
        where   a.compcode = p_compcode
                and a.actrnstate in ('1', '3')
                and a.acattype like p_slipdiv
                and a.acattype = 'N'
                and p_expload = 'importshtno'
    ) src on (a.compcode = src.compcode
              and a.acattype = src.acattype
              and a.acatno = src.acatno)
    when matched then
        update set a.slipindate = src.slipindate;

    -- 수금전표 승인일 변경 시 신규로 처리
    update  ACAUTOORDT a
    set     a.actrnstate = '1'
            ,a.slipinno = null
    where   a.acattype = 'C'
            and a.actrnstate = '3'
            and substr(a.slipinno, 0, 8) <> replace(a.slipindate,'-','');

    -- 무역전표 승인일 변경 시 신규로 처리
    update  ACAUTOORDT a
    set     actrnstate = '1'
            ,slipinno = null
    where   a.acattype = 'N'
            and a.actrnstate = '3'
            and substr(a.slipinno, 0, 8) <> replace(a.slipindate,'-','');

    -- 자동분개 회계전표 생성
    -- 해당일자의 전표유형에 해당하는 회계전표 마지막번호를 검색
    execute immediate 'delete from VGT.TT_ACACC0047PL_ACORDMN';
    insert into VGT.TT_ACACC0047PL_ACORDMN
    select  compcode
            ,slipindate
            ,acattype
            ,nvl(to_number(substr(max(slipinno), -4, 4)), 0) as slipinnum
    from    ACAUTOORDT a
    where   a.compcode = p_compcode
            and a.actrnstate in (2, 3)
            and a.acattype like p_slipdiv
    group by compcode, slipindate, acattype;

    execute immediate 'delete from VGT.TT_ACACC0047PL_ACORDMN2';
    insert into VGT.TT_ACACC0047PL_ACORDMN2
    select  a.compcode
            ,a.slipindate
            ,a.acattype
            ,nvl(to_number(substr(max(b.slipinnum), -4, 4)), 0) as slipinnum
    from    ACAUTOORDT a
            left join ACORDM b
                on a.compcode = b.compcode
                and a.slipindate = b.slipindate
                and a.acattype = b.slipdiv
    where   a.compcode = p_compcode
            and a.actrnstate = '1'
            and a.acattype like p_slipdiv
    group by a.compcode, a.slipindate, a.acattype;

    merge into VGT.TT_ACACC0047PL_ACORDMN a
    using (
        select  a.compcode
                ,a.acattype
                ,a.slipindate
                ,b.slipinnum
        from    VGT.TT_ACACC0047PL_ACORDMN a
                left join VGT.TT_ACACC0047PL_ACORDMN2 b
                    on a.compcode = b.compcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and a.slipinnum < b.slipinnum
    ) src on (a.compcode = src.compcode
              and a.acattype = src.acattype
              and a.slipindate = src.slipindate)
    when matched then
        update set a.slipinnum = src.slipinnum;

    insert into VGT.TT_ACACC0047PL_ACORDMN
    select  a.compcode
            ,a.slipindate
            ,a.acattype
            ,nvl(max(a.slipinnum), 0) as slipinnum
    from    VGT.TT_ACACC0047PL_ACORDMN2 a
            left join VGT.TT_ACACC0047PL_ACORDMN b
                on a.compcode = b.compcode
                and a.acattype = b.acattype
                and a.slipindate = b.slipindate
    where   b.slipinnum is null
    group by a.compcode, a.slipindate, a.acattype;

    -- 부문별은 분개기준(acatrulecode)으로 전표순번을 정함(신규)
    -- @salload, @colload이 empcode인 경우는 사원으로 전표순번을 정함
    execute immediate 'delete from VGT.TT_ACACC0047PL_ACAUTOORDT1';
    insert into VGT.TT_ACACC0047PL_ACAUTOORDT1
    select  a.compcode
            ,a.plantcode
            ,a.acattype
            ,a.slipindate
            ,a.acatrulecode
            ,a.acautorname
            ,a.remark1
            ,a.remark2
            ,substr('000' || to_char(row_number() over(partition by a.compcode, a.slipindate, a.acattype order by a.acatrulecode) || to_char(b.slipinnum)), -4, 4) as slipinnum
    from (
        select  distinct a.compcode
                ,a.plantcode
                ,a.acattype
                ,a.slipindate
                ,case when p_salload = 'empcode'      and a.acattype = 'S' then a.empcode
                      when p_salload = 'iempcode'     and a.acattype = 'S' then a.iempcode
                      when p_salload = 'newload'      and a.acattype = 'S' then a.iempcode
                      when p_salload = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                      when p_colload = 'empcode'      and a.acattype = 'C' then a.empcode
                      when p_colload = 'iempcode'     and a.acattype = 'C' then a.iempcode
                      when p_colload = 'newload'      and a.acattype = 'C' then a.iempcode
                      when p_colload = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                      when p_colload = 'custcode'     and a.acattype = 'C' then a.custcode
                      when p_expload = 'importshtno'  and a.acattype = 'N' then a.billno
                      when a.acattype = 'H' then a.plantcode
                      else a.acatrulecode
                      end as acatrulecode
                ,case when p_salload in ('empcode','iempcode','newload') and a.acattype = 'S' then '영업매출-자동분개'
                      when p_colload in ('empcode','iempcode','newload','custcode') and a.acattype = 'C' then '영업수금-자동분개'
                      when p_expload = 'importshtno' and a.acattype = 'N' then a.billno || ' 수입비용-자동분개'
                      when a.acattype = 'H' then '급상여-자동분개'
                      else b.acautorname
                      end as acautorname
                ,case when p_salload in ('empcode','iempcode','newload') and a.acattype = 'S' then '영업매출-자동분개'
                      when p_colload in ('empcode','iempcode','newload','custcode') and a.acattype = 'C' then '영업수금-자동분개'
                      when p_expload = 'importshtno' and a.acattype = 'N' then a.billno || ' 수입비용-자동분개'
                      when a.acattype = 'H' then '급상여-자동분개'
                      else b.remark1
                      end as remark1
                ,case when p_salload in ('empcode','iempcode','newload') and a.acattype = 'S' then '영업매출-자동분개'
                      when p_colload in ('empcode','iempcode','newload','custcode') and a.acattype = 'C' then '영업수금-자동분개'
                      when p_expload = 'importshtno' and a.acattype = 'N' then a.billno || ' 수입비용-자동분개'
                      when a.acattype = 'H' then '급상여-자동분개'
                      else b.remark2
                      end as remark2
        from    ACAUTOORDT a
                join ACAUTORULE b
                    on a.acatrulecode = b.acautorcode
                    and b.crtdiv = '1'
        where   a.compcode = p_compcode
                and a.actrnstate = '1'
                and a.acattype like p_slipdiv
    ) a
            join VGT.TT_ACACC0047PL_ACORDMN b
                on a.compcode = b.compcode
                and a.slipindate = b.slipindate
                and a.acattype = b.acattype;

    -- 기존 부문별자료의 전표순번 추가
    insert into VGT.TT_ACACC0047PL_ACAUTOORDT1
    select  distinct a.compcode
            ,a.plantcode
            ,a.acattype
            ,a.slipindate
            ,case when p_salload = 'empcode'      and a.acattype = 'S' then a.empcode
                  when p_salload = 'iempcode'     and a.acattype = 'S' then a.iempcode
                  when p_salload = 'newload'      and a.acattype = 'S' then a.iempcode
                  when p_salload = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                  when p_colload = 'empcode'      and a.acattype = 'C' then a.empcode
                  when p_colload = 'iempcode'     and a.acattype = 'C' then a.iempcode
                  when p_colload = 'newload'      and a.acattype = 'C' then a.iempcode
                  when p_colload = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                  when p_colload = 'custcode'     and a.acattype = 'C' then a.custcode
                  when p_expload = 'importshtno'  and a.acattype = 'N' then a.billno
                  when a.acattype = 'H' then a.plantcode
                  else a.acatrulecode
                  end as acatrulecode
            ,case when p_salload in ('empcode','iempcode','newload') and a.acattype = 'S' then '영업매출-자동분개'
                  when p_colload in ('empcode','iempcode','newload','custcode') and a.acattype = 'C' then '영업수금-자동분개'
                  when p_expload = 'importshtno' and a.acattype = 'N' then a.billno || ' 수입비용-자동분개'
                  when a.acattype = 'H' then '급상여-자동분개'
                  else b.acautorname
                  end as acautorname
            ,case when p_salload in ('empcode','iempcode','newload') and a.acattype = 'S' then '영업매출-자동분개'
                  when p_colload in ('empcode','iempcode','newload','custcode') and a.acattype = 'C' then '영업수금-자동분개'
                  when p_expload = 'importshtno' and a.acattype = 'N' then a.billno || ' 수입비용-자동분개'
                  when a.acattype = 'H' then '급상여-자동분개'
                  else b.remark1
                  end as remark1
            ,case when p_salload in ('empcode','iempcode','newload') and a.acattype = 'S' then '영업매출-자동분개'
                  when p_colload in ('empcode','iempcode','newload','custcode') and a.acattype = 'C' then '영업수금-자동분개'
                  when p_expload = 'importshtno' and a.acattype = 'N' then a.billno || ' 수입비용-자동분개'
                  when a.acattype = 'H' then '급상여-자동분개'
                  else b.remark2
                  end as remark2
            ,substr(a.slipinno, -4, 4) as slipinnum
    from    ACAUTOORDT a
            join ACAUTORULE b
                on a.acatrulecode = b.acautorcode
                and b.crtdiv = '1'
    where   a.compcode = p_compcode
            and a.actrnstate = '3'
            and a.acattype like p_slipdiv;

    -- 일자별 전표번호 최대값 갱신
    merge into VGT.TT_ACACC0047PL_ACORDMN a
    using (
        select  a.compcode
                ,a.slipindate
                ,a.acattype
                ,b.slipinnum as slipinnum
        from    VGT.TT_ACACC0047PL_ACORDMN a
                join (
                    select  compcode
                            ,slipindate
                            ,acattype
                            ,max(slipinnum) as slipinnum
                    from    VGT.TT_ACACC0047PL_ACAUTOORDT1
                    group by compcode, slipindate, acattype
                ) b on a.compcode = b.compcode
                    and a.slipindate = b.slipindate
                    and a.acattype = b.acattype
                    and a.slipinnum < b.slipinnum
    ) src on (a.compcode = src.compcode
              and a.slipindate = src.slipindate
              and a.acattype = src.acattype)
    when matched then
        update set a.slipinnum = src.slipinnum;

    -- 개별은 전표번호(acatno)으로 전표순번을 정함(신규)
    execute immediate 'delete from VGT.TT_ACACC0047PL_ACAUTOORDT2';
    insert into VGT.TT_ACACC0047PL_ACAUTOORDT2
    select  a.compcode
            ,a.acattype
            ,a.slipindate
            ,a.acatno
            ,c.acautorname
            ,c.remark1
            ,c.remark2
            ,substr('000' || to_char(row_number() over(partition by a.compcode, a.slipindate, a.acattype order by a.acatno) || to_number(b.slipinnum)), -4, 4) as slipinnum
    from    ACAUTOORDT a
            join VGT.TT_ACACC0047PL_ACORDMN b
                on a.compcode = b.compcode
                and a.slipindate = b.slipindate
                and a.acattype = b.acattype
            join ACAUTORULE c
                on a.acatrulecode = c.acautorcode
                and c.crtdiv = '2'
    where   a.compcode = p_compcode
            and a.actrnstate = '1'
            and a.acattype like p_slipdiv;

    -- 기존 개별자료의 전표순번 추가
    insert into VGT.TT_ACACC0047PL_ACAUTOORDT2
    select  distinct a.compcode
            ,a.acattype
            ,a.slipindate
            ,a.acatno
            ,b.acautorname
            ,b.remark1
            ,b.remark2
            ,substr(a.slipinno, -4, 4) as slipinnum
    from    ACAUTOORDT a
            join ACAUTORULE b
                on a.acatrulecode = b.acautorcode
                and b.crtdiv = '2'
    where   a.compcode = p_compcode
            and a.actrnstate = '3'
            and a.acattype like p_slipdiv;

    -- 회계전표생성(부문,개별)
    insert into ACORDM
        (
            compcode
            ,slipinno
            ,slipdiv
            ,slipindate
            ,slipinnum
            ,deptcode
            ,plantcode
            ,empcode
            ,eviddiv
            ,slipinremark
            ,slipno
            ,slipdate
            ,slipnum
            ,slipdeptcode
            ,slipempcode
            ,skreqyn
            ,skreqdiv
            ,skreqdate
            ,skreqdeptcode
            ,skreqempcode
            ,accountno
            ,slipinstate
            ,slipremark
            ,acautorcode
            ,insertdt
            ,iempcode
        )
    select  distinct a.compcode
            ,replace(a.slipindate,'-','') || a.acattype || nvl(b.slipinnum, c.slipinnum)
            ,a.acattype
            ,a.slipindate
            ,a.acattype || nvl(b.slipinnum, c.slipinnum)
            ,case when b.slipinnum is null or p_salload = 'empcode' and a.acattype = 'S' or p_colload in ('empcode','custcode') and a.acattype = 'C' then a.deptcode
                  when p_salload in ('iempcode','newload','acatrulecode') and a.acattype = 'S' or p_colload in ('iempcode','newload','acatrulecode') and a.acattype = 'C' or p_expload = 'importshtno' and a.acattype = 'N' then f.deptcode
                  else p_ideptcode
                  end
            ,nvl(d.plantcode, a.plantcode)
            ,case when b.slipinnum is null or p_salload = 'empcode' and a.acattype = 'S' or p_colload in ('empcode','custcode') and a.acattype = 'C' then a.empcode
                  when p_salload in ('iempcode','newload','acatrulecode') and a.acattype = 'S' or p_colload in ('iempcode','newload','acatrulecode') and a.acattype = 'C' or p_expload = 'importshtno' and a.acattype = 'N' then a.iempcode
                  else p_iempcode
                  end
            ,'99'
            ,nvl(b.acautorname, c.acautorname)
            ,case when e.condition1 = '1' then replace(a.slipindate,'-','') || a.acattype || nvl(b.slipinnum,c.slipinnum) else '' end
            ,case when e.condition1 = '1' then a.slipindate else '' end
            ,case when e.condition1 = '1' then a.acattype || nvl(b.slipinnum,c.slipinnum) else '' end
            ,a.slipdeptcode
            ,case when e.condition1 = '1' then p_iempcode else a.slipempcode end
            ,a.skreqyn
            ,a.skreqdiv
            ,a.skreqdate
            ,a.skreqdeptcode
            ,a.skreqempcode
            ,a.accountno
            ,case when e.condition1 = '1' then '4' else '2' end
            ,''
            ,case when p_salload in ('empcode','iempcode','newload') and a.acattype = 'S' or
                       p_colload in ('empcode','iempcode','newload','custcode') and a.acattype = 'C' or
                       p_expload = 'importshtno' and a.acattype = 'N' or
                       a.acattype = 'H'
                  then a.acattype
                  else a.acatrulecode end
            ,p_insertdt
            ,p_iempcode
    from    ACAUTOORDT a
            left join VGT.TT_ACACC0047PL_ACAUTOORDT1 b
                on a.compcode = b.compcode
                and a.plantcode = b.plantcode
                and a.acattype = b.acattype
                and a.slipindate = b.slipindate
                and case when p_salload = 'empcode'      and a.acattype = 'S' then a.empcode
                         when p_salload = 'iempcode'     and a.acattype = 'S' then a.iempcode
                         when p_salload = 'newload'      and a.acattype = 'S' then a.iempcode
                         when p_salload = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                         when p_colload = 'empcode'      and a.acattype = 'C' then a.empcode
                         when p_colload = 'iempcode'     and a.acattype = 'C' then a.iempcode
                         when p_colload = 'newload'      and a.acattype = 'C' then a.iempcode
                         when p_colload = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                         when p_colload = 'custcode'     and a.acattype = 'C' then a.custcode
                         when p_expload = 'importshtno'  and a.acattype = 'N' then a.billno
                         when a.acattype = 'H' then a.plantcode
                         else a.acatrulecode
                         end = b.acatrulecode
            left join VGT.TT_ACACC0047PL_ACAUTOORDT2 c
                on a.compcode = c.compcode
                and a.acattype = c.acattype
                and a.slipindate = c.slipindate
                and a.acatno = c.acatno
            left join (
                select  a.divcode
                        ,b.plantcode
                from    CMCOMMONM a
                        join CMPLANTM b
                            on a.filter2 = b.plantcode
                where   a.cmmcode = 'AC201'
            ) d on a.acattype = d.divcode
            left join ACAUTORULE e
                on a.acatrulecode = e.acautorcode
            left join CMEMPM f
                on a.iempcode = f.empcode
    where   a.compcode = p_compcode
            and a.actrnstate in ('1', '3')
            and a.acattype like p_slipdiv;

    p_proccnt := sql%rowcount;

    -- 전표상세임시파일생성(부문)
    execute immediate 'delete from VGT.TT_ACACC0047PL_ACORDD1';
    insert into VGT.TT_ACACC0047PL_ACORDD1
    select  a.compcode
            ,replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno
            ,c.acautoseq
            ,c.dcdiv
            ,c.acacccode
            ,nvl(d.plantcode, a.plantcode) as plantcode
            -- 차변,출금
            ,case when c.dcdiv in ('1','4')
                  then fnacautoordamt (c.amtdiv, c.accamtdiv, c.acccalcdiv, c.accsamtdiv,
                                       a.trn1amt, a.trn2amt, a.trn3amt, a.trn4amt, a.trn5amt,
                                       a.trn6amt, a.trn7amt, a.trn8amt, a.trn9amt, a.trn10amt,
                                       a.trn11amt, a.trn12amt, a.trn13amt, a.trn14amt, a.trn15amt,
                                       a.trn16amt, a.trn17amt, a.trn18amt, a.trn19amt, a.trn20amt,
                                       a.trn21amt, a.trn22amt, a.trn23amt, a.trn24amt, a.trn25amt,
                                       a.trn26amt, a.trn27amt, a.trn28amt, a.trn29amt, a.trn30amt)
                  else 0
                  end as debamt
            -- 대변,입금
            ,case when c.dcdiv in ('2','3')
                  then fnacautoordamt (c.amtdiv, c.accamtdiv, c.acccalcdiv, c.accsamtdiv,
                                       a.trn1amt, a.trn2amt, a.trn3amt, a.trn4amt, a.trn5amt,
                                       a.trn6amt, a.trn7amt, a.trn8amt, a.trn9amt, a.trn10amt,
                                       a.trn11amt, a.trn12amt, a.trn13amt, a.trn14amt, a.trn15amt,
                                       a.trn16amt, a.trn17amt, a.trn18amt, a.trn19amt, a.trn20amt,
                                       a.trn21amt, a.trn22amt, a.trn23amt, a.trn24amt, a.trn25amt,
                                       a.trn26amt, a.trn27amt, a.trn28amt, a.trn29amt, a.trn30amt)
                  else 0
                  end as creamt
            ,case when a.acattype = 'H'
                  then case when c.accamtdiv = '01' and c.acacccode = '73010000' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '본사 급여'
                            when c.accamtdiv = '01' and c.acacccode = '42010000' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '공장 급여(' || case when e.accpaydiv = '66040' then '상신)' else '하길)' end
                            when c.accamtdiv = '01' and c.acacccode = '73560000' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '연구소 급여'
                            when c.accamtdiv = '02' and c.acacccode = '73030000' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '본사 상여'
                            when c.accamtdiv = '02' and c.acacccode = '42030000' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '공장 상여(' || case when e.accpaydiv = '66040' then '상신)' else '하길)' end
                            when c.accamtdiv = '02' and c.acacccode = '73560000' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '연구소 상여'
                            when c.accamtdiv = '03' and c.acacccode = '73030000' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '본사 인센티브'
                            when c.accamtdiv = '03' and c.acacccode = '42030000' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '공장 인센티브(' || case when e.accpaydiv = '66040' then '상신)' else '하길)' end
                            when c.accamtdiv = '03' and c.acacccode = '73560000' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '연구소 인센티브'
                            when c.accamtdiv = '04' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '급여지급시 소득세'
                            when c.accamtdiv = '05' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '급여지급시 연말정산소득세'
                            when c.accamtdiv = '06' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '급여지급시 주민세'
                            when c.accamtdiv = '07' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '급여지급시 연말정산주민세'
                            when c.accamtdiv = '08' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '급여지급시 국민연금'
                            when c.accamtdiv = '09' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '급여지급시 국민연금소급'
                            when c.accamtdiv = '10' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '급여지급시 건강보험'
                            when c.accamtdiv = '11' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '급여지급시 건강보험소급'
                            when c.accamtdiv = '12' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '급여지급시 고용보험'
                            when c.accamtdiv = '13' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '사우회비 이체'
                            when c.accamtdiv = '14' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '사우회비 상환'
                            when c.accamtdiv = '15' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || 'PDA 사용료'
                            when c.accamtdiv = '16' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '보증보험 공제'
                            when c.accamtdiv = '17' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '학자금상환 공제'
                            when c.accamtdiv = '23' then substr(a.acatno,1,4) || '년 ' || substr(a.remark,1,4) || '급여'
                            else nvl(nullif(a.remark, ''), b.remark1)
                            end
                    else nvl(nullif(a.remark, ''), b.remark1)
                    end as remark1
            ,nvl(nullif(a.remark2, ''), b.remark2) as remark2
            ,a.taxno
            ,a.acatno
    from    ACAUTOORDT a
            join VGT.TT_ACACC0047PL_ACAUTOORDT1 b
                on a.compcode = b.compcode
                and a.plantcode = b.plantcode
                and a.acattype = b.acattype
                and a.slipindate = b.slipindate
                and case when a.acattype = 'H' then a.plantcode else '' end = b.acatrulecode
            join ACAUTORULESM c
                on a.acatrulecode = c.acautorcode
            left join (
                select  a.divcode, b.plantcode
                from    CMCOMMONM a
                        join CMPLANTM b on a.filter2 = b.plantcode
                where   a.cmmcode = 'AC201'
            ) d on a.acattype = d.divcode
            left join CMEMPM e
                on a.empcode = e.empcode
    where   a.compcode = p_compcode
            and a.actrnstate in ('1','3')
            and a.acattype like p_slipdiv;

    -- 관리항목임시파일생성(부문)
    execute immediate 'delete from VGT.TT_ACACC0047PL_ACORDS1';
    insert into VGT.TT_ACACC0047PL_ACORDS1
    select  a.compcode
            ,replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno
            ,c.acautoseq
            ,d.mngclucode
            ,e.seq
            ,fnacautoordval(d.mngcluvaldiv,
                            a.userdef1code, a.userdef2code, a.userdef3code, a.userdef4code, a.userdef5code,
                            a.userdef6code, a.userdef7code, a.userdef8code, a.userdef9code, a.userdef10code,
                            a.userdef11code, a.userdef12code, a.userdef13code, a.userdef14code, a.userdef15code,
                            a.userdef16code, a.userdef17code, a.userdef18code, a.userdef19code, a.userdef20code,
                            a.userdef21code, a.userdef22code, a.userdef23code, a.userdef24code, a.userdef25code,
                            a.userdef26code, a.userdef27code, a.userdef28code, a.userdef29code, a.userdef30code,
                            a.deptcode, a.custcode, a.taxno,a.billno, a.issdate, a.expdate, a.cardno, a.empcode, a.cardokno) as mngcluval
            ,fnacautoordval(d.mngcludecdiv,
                            a.userdef1code, a.userdef2code, a.userdef3code, a.userdef4code, a.userdef5code,
                            a.userdef6code, a.userdef7code, a.userdef8code, a.userdef9code, a.userdef10code,
                            a.userdef11code, a.userdef12code, a.userdef13code, a.userdef14code, a.userdef15code,
                            a.userdef16code, a.userdef17code, a.userdef18code, a.userdef19code, a.userdef20code,
                            a.userdef21code, a.userdef22code, a.userdef23code, a.userdef24code, a.userdef25code,
                            a.userdef26code, a.userdef27code, a.userdef28code, a.userdef29code, a.userdef30code,
                            a.deptcode, a.custcode, a.taxno, a.billno, a.issdate, a.expdate, a.cardno, a.empcode, a.cardokno) as mngcludec
            ,a.acatno
    from    ACAUTOORDT a
            join VGT.TT_ACACC0047PL_ACAUTOORDT1 b
                on a.compcode = b.compcode
                and a.plantcode = b.plantcode
                and a.acattype = b.acattype
                and a.slipindate = b.slipindate
                and case when a.acattype = 'H' then a.plantcode else a.acatrulecode end = b.acatrulecode
            join ACAUTORULESM c
                on a.acatrulecode = c.acautorcode
            join ACAUTORULEDS d
                on c.acautorcode = d.acautorcode
                and c.acautoseq = d.acautoseq
            join ACACCMNGM e
                on c.acacccode = e.acccode
                and e.dcdiv = case when c.dcdiv in ('1','4') then '1' else '2' end
                and d.mngclucode = e.mngclucode
    where   a.compcode = p_compcode
            and a.actrnstate in ('1','3')
            and a.acattype like p_slipdiv;

    -- 급여 이체포멧메 맞게 변경
    delete
    from    VGT.TT_ACACC0047PL_ACORDD1 a
    where   a.slipinno like '%H%'
            and a.debamt = 0
            and a.creamt = 0;

    merge into VGT.TT_ACACC0047PL_ACORDS1 a
    using (
        select  a.compcode
                ,a.slipinno
                ,a.acautoseq
                ,a.mngclucode
                ,a.seq
                ,a.acatno
                ,case when c.accamtdiv = '13' then '0000884'
                      when c.accamtdiv = '14' then '0000884'
                      when c.accamtdiv = '23' then '0000884'
                      else ''
                      end as mngcluval
                ,case when c.accamtdiv = '13' then (select custname from CMCUSTM where custcode = '0000884')
                      when c.accamtdiv = '14' then (select custname from CMCUSTM where custcode = '0000884')
                      when c.accamtdiv = '23' then (select custname from CMCUSTM where custcode = '0000884')
                      else ''
                      end as mngcludec
        from    VGT.TT_ACACC0047PL_ACORDS1 a
                join VGT.TT_ACACC0047PL_ACORDD1 b
                    on a.slipinno = b.slipinno
                    and a.acautoseq = b.acautoseq
                    and a.acatno = b.acatno
                join ACAUTORULESM c
                    on c.acautorcode = 'H01001'
                    and b.acautoseq = c.acautoseq
        where   a.slipinno like '%H%'
                and a.mngclucode = 'S010'
    ) src on (a.compcode = src.compcode
              and a.slipinno = src.slipinno
              and a.acautoseq = src.acautoseq
              and a.mngclucode = src.mngclucode
              and a.seq = src.seq
              and a.acatno = src.acatno)
    when matched then
        update set a.mngcluval = src.mngcluval,
                   a.mngcludec = src.mngcludec;

    -- 영업거래처 대표거래처로 변경
    for rec in (
        select  value1
                ,value2
        from    SYSPARAMETERMANAGE
        where   parametercode = 'accsalescustload')
    loop
        p_salecust := rec.value1;
        p_colcust  := rec.value2;
    end loop;

    merge into VGT.TT_ACACC0047PL_ACORDS1 a
    using (
        select  a.acatno
                ,a.acautoseq
                ,a.compcode
                ,a.mngclucode
                ,a.seq
                ,a.slipinno
                ,nvl(c.custcode, a.mngcluval) as mngcluval
                ,nvl(c.custname, a.mngcludec) as mngcludec
        from    VGT.TT_ACACC0047PL_ACORDS1 a
                join CMCUSTM b on a.mngcluval = b.custcode
                join CMCUSTM c on b.custmajorcode = c.custcode
        where   a.mngclucode = 'S010'
                and (p_salecust = 'Y' and a.slipinno like '%S%' or
                     p_colcust = 'Y' and a.slipinno like '%C%')
    ) src on (a.acatno = src.acatno
              and a.acautoseq = src.acautoseq
              and a.compcode = src.compcode
              and a.mngclucode = src.mngclucode
              and a.seq = src.seq
              and a.slipinno = src.slipinno)
    when matched then
        update set a.mngcluval = src.mngcluval,
                   a.mngcludec = src.mngcludec;

    -- 부문별합계 임시파일 생성
    execute immediate 'delete from VGT.TT_ACACC0047PL_ACORDDS';
    insert into VGT.TT_ACACC0047PL_ACORDDS
    select  compcode, slipinno, row_number()over(partition by compcode, slipinno order by min(acautoseq), min(acccode) desc, min(remark1)) as slipinseq,
            dcdiv, acccode, max(plantcode) as plantcode, sum(debamt) as debamt, sum(creamt) as creamt,
            remark1 as remark1, max(remark2) as remark2, max(taxno) as taxno,
            mngclucode1, mngclucode2, mngclucode3, mngclucode4, mngclucode5, mngclucode6,
            mngcluval1, mngcluval2, mngcluval3, mngcluval4, mngcluval5, mngcluval6,
            max(mngcludec1) as mngcludec1, max(mngcludec2) as mngcludec2, max(mngcludec3) as mngcludec3,
            max(mngcludec4) as mngcludec4, max(mngcludec5) as mngcludec5, max(mngcludec6) as mngcludec6
    from (
        select  a.compcode, a.slipinno, a.acautoseq, a.dcdiv, a.acccode, a.plantcode, a.taxno,
                max(a.debamt) as debamt, max(a.creamt) as creamt, a.remark1, a.remark2, a.acatno,
                max(case when seq = 1 then mngclucode else '' end) as mngclucode1,
                max(case when seq = 2 then mngclucode else '' end) as mngclucode2,
                max(case when seq = 3 then mngclucode else '' end) as mngclucode3,
                max(case when seq = 4 then mngclucode else '' end) as mngclucode4,
                max(case when seq = 5 then mngclucode else '' end) as mngclucode5,
                max(case when seq = 6 then mngclucode else '' end) as mngclucode6,
                max(case when seq = 1 then mngcluval else '' end) as mngcluval1,
                max(case when seq = 2 then mngcluval else '' end) as mngcluval2,
                max(case when seq = 3 then mngcluval else '' end) as mngcluval3,
                max(case when seq = 4 then mngcluval else '' end) as mngcluval4,
                max(case when seq = 5 then mngcluval else '' end) as mngcluval5,
                max(case when seq = 6 then mngcluval else '' end) as mngcluval6,
                max(case when seq = 1 then mngcludec else '' end) as mngcludec1,
                max(case when seq = 2 then mngcludec else '' end) as mngcludec2,
                max(case when seq = 3 then mngcludec else '' end) as mngcludec3,
                max(case when seq = 4 then mngcludec else '' end) as mngcludec4,
                max(case when seq = 5 then mngcludec else '' end) as mngcludec5,
                max(case when seq = 6 then mngcludec else '' end) as mngcludec6
        from    VGT.TT_ACACC0047PL_ACORDD1 a
                left join VGT.TT_ACACC0047PL_ACORDS1 b
                    on a.slipinno = b.slipinno
                    and a.acautoseq = b.acautoseq
                    and a.acatno = b.acatno
        group by a.compcode, a.slipinno, a.acautoseq, a.dcdiv, a.taxno,
                 a.acccode, a.plantcode, a.remark1, a.remark2, a.acatno
        having sum(a.debamt) <> 0 or sum(a.creamt) <> 0
    ) a
    group by compcode, slipinno, dcdiv, acccode, remark1, mngclucode1, mngclucode2, mngclucode3, mngclucode4,
             mngclucode5, mngclucode6, mngcluval1, mngcluval2, mngcluval3, mngcluval4, mngcluval5, mngcluval6
    having sum(debamt) <> 0 or sum(creamt) <> 0;

    -- 부문별자료 생성
    merge into VGT.TT_ACACC0047PL_ACORDDS a
    using (
        select  a.slipinseq
                ,a.debamt
                ,a.creamt
                ,a.remark1
                ,a.remark2
                ,a.taxno
                ,a.mngclucode1
                ,a.mngclucode2
                ,a.mngclucode3
                ,a.mngclucode4
                ,a.mngclucode5
                ,a.mngclucode6
                ,a.acccode
                ,a.compcode
                ,a.slipinno
                ,a.plantcode
                ,a.dcdiv
                ,case when a.mngclucode1 = 'S040' and trim(c.deptcode) is not null then c.deptcode else a.mngcluval1 end mngcluval1
                ,case when a.mngclucode2 = 'S040' and trim(c.deptcode) is not null then c.deptcode else a.mngcluval2 end mngcluval2
                ,case when a.mngclucode3 = 'S040' and trim(c.deptcode) is not null then c.deptcode else a.mngcluval3 end mngcluval3
                ,case when a.mngclucode4 = 'S040' and trim(c.deptcode) is not null then c.deptcode else a.mngcluval4 end mngcluval4
                ,case when a.mngclucode5 = 'S040' and trim(c.deptcode) is not null then c.deptcode else a.mngcluval5 end mngcluval5
                ,case when a.mngclucode6 = 'S040' and trim(c.deptcode) is not null then c.deptcode else a.mngcluval6 end mngcluval6
                ,case when a.mngclucode1 = 'S040' and trim(c.deptcode) is not null then c.deptname else a.mngcludec1 end mngcludec1
                ,case when a.mngclucode2 = 'S040' and trim(c.deptcode) is not null then c.deptname else a.mngcludec2 end mngcludec2
                ,case when a.mngclucode3 = 'S040' and trim(c.deptcode) is not null then c.deptname else a.mngcludec3 end mngcludec3
                ,case when a.mngclucode4 = 'S040' and trim(c.deptcode) is not null then c.deptname else a.mngcludec4 end mngcludec4
                ,case when a.mngclucode5 = 'S040' and trim(c.deptcode) is not null then c.deptname else a.mngcludec5 end mngcludec5
                ,case when a.mngclucode6 = 'S040' and trim(c.deptcode) is not null then c.deptname else a.mngcludec6 end mngcludec6
        from    VGT.TT_ACACC0047PL_ACORDDS a
                join SYSPARAMETERMANAGE b
                    on b.parametercode = 'accpayloaddept'
                    and b.usediv = 'Y'
                join CMDEPTM c
                    on b.value1 = c.deptcode
        where   p_slipdiv = 'H'
    ) src on (nvl(a.slipinseq, 0) = nvl(src.slipinseq, 0)
              and nvl(a.debamt, 0) = nvl(src.debamt, 0)
              and nvl(a.creamt, 0) = nvl(src.creamt, 0)
              and nvl(a.remark1, ' ') = nvl(src.remark1, ' ')
              and nvl(a.remark2, ' ') = nvl(src.remark2, ' ')
              and nvl(a.taxno, ' ') = nvl(src.taxno, ' ')
              and nvl(a.mngclucode1, ' ') = nvl(src.mngclucode1, ' ')
              and nvl(a.mngclucode2, ' ') = nvl(src.mngclucode2, ' ')
              and nvl(a.mngclucode3, ' ') = nvl(src.mngclucode3, ' ')
              and nvl(a.mngclucode4, ' ') = nvl(src.mngclucode4, ' ')
              and nvl(a.mngclucode5, ' ') = nvl(src.mngclucode5, ' ')
              and nvl(a.mngclucode6, ' ') = nvl(src.mngclucode6, ' ')
              and nvl(a.acccode, ' ') = nvl(src.acccode, ' ')
              and nvl(a.compcode, ' ') = nvl(src.compcode, ' ')
              and nvl(a.slipinno, ' ') = nvl(src.slipinno, ' ')
              and nvl(a.plantcode, ' ') = nvl(src.plantcode, ' ')
              and nvl(a.dcdiv, ' ') = nvl(src.dcdiv, ' '))
    when matched
    then
        update set a.mngcluval1 = src.mngcluval1
                  ,a.mngcluval2 = src.mngcluval2
                  ,a.mngcluval3 = src.mngcluval3
                  ,a.mngcluval4 = src.mngcluval4
                  ,a.mngcluval5 = src.mngcluval5
                  ,a.mngcluval6 = src.mngcluval6
                  ,a.mngcludec1 = src.mngcludec1
                  ,a.mngcludec2 = src.mngcludec2
                  ,a.mngcludec3 = src.mngcludec3
                  ,a.mngcludec4 = src.mngcludec4
                  ,a.mngcludec5 = src.mngcludec5
                  ,a.mngcludec6 = src.mngcludec6;

    insert into ACORDD
        (
            compcode
           ,slipinno
           ,slipinseq
           ,dcdiv
           ,acccode
           ,plantcode
           ,debamt
           ,creamt
           ,slipdate
           ,slipnum
           ,remark1
           ,remark2
           ,taxno
           ,datadiv
           ,rptseq
           ,insertdt
           ,iempcode
        )
    select  a.compcode
            ,a.slipinno
            ,a.slipinseq
            ,a.dcdiv
            ,substr(a.acccode, 0, 8)
            ,a.plantcode
            ,a.debamt
            ,a.creamt
            ,b.slipdate
            ,b.slipnum
            ,a.remark1
            ,a.remark2
            ,case when a.acccode like p_acccode2 || '%' or a.acccode like p_acccode3 || '%' then nvl(a.taxno,'') else '' end
            ,''
            , a.slipinseq
            , sysdate
            , p_iempcode
    from    VGT.TT_ACACC0047PL_ACORDDS a
            join ACORDM b
                on a.slipinno = b.slipinno;

    insert into ACORDS
        (
            compcode
            ,slipinno
            ,slipinseq
            ,mngclucode
            ,seq
            ,mngcluval
            ,mngcludec
            ,insertdt
            ,iempcode
        )
    select  compcode
            ,slipinno
            ,slipinseq
            ,mngclucode1
            ,1
            ,mngcluval1
            ,mngcludec1
            ,sysdate
            ,p_iempcode
    from    VGT.TT_ACACC0047PL_ACORDDS
    where   trim(mngclucode1) is not null;

    insert into ACORDS
        (
            compcode
            ,slipinno
            ,slipinseq
            ,mngclucode
            ,seq
            ,mngcluval
            ,mngcludec
            ,insertdt
            ,iempcode
        )
    select  compcode
            ,slipinno
            ,slipinseq
            ,mngclucode2
            ,2
            ,mngcluval2
            ,mngcludec2
            ,sysdate
            ,p_iempcode
    from    VGT.TT_ACACC0047PL_ACORDDS
    where   trim(mngclucode2) is not null;

    insert into ACORDS
        (
            compcode
            ,slipinno
            ,slipinseq
            ,mngclucode
            ,seq
            ,mngcluval
            ,mngcludec
            ,insertdt
            ,iempcode
        )
    select  compcode
            ,slipinno
            ,slipinseq
            ,mngclucode3
            ,3
            ,mngcluval3
            ,mngcludec3
            ,sysdate
            ,p_iempcode
    from    VGT.TT_ACACC0047PL_ACORDDS
    where   trim(mngclucode3) is not null;

    insert into ACORDS
        (
            compcode
            ,slipinno
            ,slipinseq
            ,mngclucode
            ,seq
            ,mngcluval
            ,mngcludec
            ,insertdt
            ,iempcode
        )
    select  compcode
            ,slipinno
            ,slipinseq
            ,mngclucode4
            ,4
            ,mngcluval4
            ,mngcludec4
            ,sysdate
            ,p_iempcode
    from    VGT.TT_ACACC0047PL_ACORDDS
    where   trim(mngclucode4) is not null;

    insert into ACORDS
        (
            compcode
            ,slipinno
            ,slipinseq
            ,mngclucode
            ,seq
            ,mngcluval
            ,mngcludec
            ,insertdt
            ,iempcode
        )
    select  compcode
            ,slipinno
            ,slipinseq
            ,mngclucode5
            ,5
            ,mngcluval5
            ,mngcludec5
            ,sysdate
            ,p_iempcode
    from    VGT.TT_ACACC0047PL_ACORDDS
    where   trim(mngclucode5) is not null;

    insert into ACORDS
        (
            compcode
            ,slipinno
            ,slipinseq
            ,mngclucode
            ,seq
            ,mngcluval
            ,mngcludec
            ,insertdt
            ,iempcode
        )
    select  compcode
            ,slipinno
            ,slipinseq
            ,mngclucode6
            ,6
            ,mngcluval6
            ,mngcludec6
            ,sysdate
            ,p_iempcode
    from    VGT.TT_ACACC0047PL_ACORDDS
    where   trim(mngclucode6) is not null;

    -- 전표상세임시파일생성(개별)
    execute immediate 'delete from VGT.TT_ACACC0047PL_ACORDD2';
    insert into VGT.TT_ACACC0047PL_ACORDD2
    select  a.compcode
            ,replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno
            ,c.acautoseq
            ,c.dcdiv
            ,c.acacccode as acccode
            ,nvl(d.plantcode, a.plantcode) as plantcode
            ,case when c.dcdiv in ('1','4')   -- 차변,출금
                  then fnacautoordamt (c.amtdiv, c.accamtdiv, c.acccalcdiv, c.accsamtdiv,
                                       a.trn1amt, a.trn2amt, a.trn3amt, a.trn4amt, a.trn5amt,
                                       a.trn6amt, a.trn7amt, a.trn8amt, a.trn9amt, a.trn10amt,
                                       a.trn11amt, a.trn12amt, a.trn13amt, a.trn14amt, a.trn15amt,
                                       a.trn16amt, a.trn17amt, a.trn18amt, a.trn19amt, a.trn20amt,
                                       a.trn21amt, a.trn22amt, a.trn23amt, a.trn24amt, a.trn25amt,
                                       a.trn26amt, a.trn27amt, a.trn28amt, a.trn29amt, a.trn30amt)
                  else 0 end as debamt
            ,case when c.dcdiv in ('2','3')   -- 대변,입금
                  then fnacautoordamt (c.amtdiv, c.accamtdiv, c.acccalcdiv, c.accsamtdiv,
                                       a.trn1amt, a.trn2amt, a.trn3amt, a.trn4amt, a.trn5amt,
                                       a.trn6amt, a.trn7amt, a.trn8amt, a.trn9amt, a.trn10amt,
                                       a.trn11amt, a.trn12amt, a.trn13amt, a.trn14amt, a.trn15amt,
                                       a.trn16amt, a.trn17amt, a.trn18amt, a.trn19amt, a.trn20amt,
                                       a.trn21amt, a.trn22amt, a.trn23amt, a.trn24amt, a.trn25amt,
                                       a.trn26amt, a.trn27amt, a.trn28amt, a.trn29amt, a.trn30amt)
                  else 0 end as creamt
            ,nvl(nullif(a.remark, ''), b.remark1) as remark1
            ,nvl(nullif(a.remark2, ''), b.remark2) as remark2
            ,a.taxno
            ,case when p_colseq = 'Y' then a.trn30amt else 0 end as crtord
    from    ACAUTOORDT a
            join VGT.TT_ACACC0047PL_ACAUTOORDT2 b
                on a.compcode = b.compcode
                and a.acattype = b.acattype
                and a.slipindate = b.slipindate
                and a.acatno = b.acatno
            join ACAUTORULESM c
                on a.acatrulecode = c.acautorcode
            left join (
                select  a.divcode, b.plantcode
                from    CMCOMMONM a
                        join CMPLANTM b
                            on a.filter2 = b.plantcode
                where   a.cmmcode = 'AC201'
            ) d on a.acattype = d.divcode
    where   a.compcode = p_compcode
            and a.actrnstate in ('1', '3')
            and a.acattype like p_slipdiv;

    -- 관리항목임시파일생성(개별)
    execute immediate 'delete from VGT.TT_ACACC0047PL_ACORDS2';
    insert into VGT.TT_ACACC0047PL_ACORDS2
    select  a.compcode
            ,replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno
            ,c.acautoseq
            ,d.mngclucode
            ,e.seq
            ,fnacautoordval(d.mngcluvaldiv,
                            a.userdef1code, a.userdef2code, a.userdef3code, a.userdef4code, a.userdef5code,
                            a.userdef6code, a.userdef7code, a.userdef8code, a.userdef9code, a.userdef10code,
                            a.userdef11code, a.userdef12code, a.userdef13code, a.userdef14code, a.userdef15code,
                            a.userdef16code, a.userdef17code, a.userdef18code, a.userdef19code, a.userdef20code,
                            a.userdef21code, a.userdef22code, a.userdef23code, a.userdef24code, a.userdef25code,
                            a.userdef26code, a.userdef27code, a.userdef28code, a.userdef29code, a.userdef30code,
                            a.deptcode, nvl(g.custcode, a.custcode), a.taxno, a.billno, a.issdate, a.expdate, a.cardno, a.empcode, a.cardokno) as mngcluval
            ,fnacautoordval(d.mngcludecdiv,
                            a.userdef1code, a.userdef2code, a.userdef3code, a.userdef4code, a.userdef5code,
                            nvl(g.custname, a.userdef6code), a.userdef7code, a.userdef8code, a.userdef9code, a.userdef10code,
                            a.userdef11code, a.userdef12code, a.userdef13code, a.userdef14code, a.userdef15code,
                            a.userdef16code, a.userdef17code, a.userdef18code, a.userdef19code, a.userdef20code,
                            a.userdef21code, a.userdef22code, a.userdef23code, a.userdef24code, a.userdef25code,
                            a.userdef26code, a.userdef27code, a.userdef28code, a.userdef29code, a.userdef30code,
                            a.deptcode, a.custcode, a.taxno, a.billno, a.issdate, a.expdate, a.cardno, a.empcode, a.cardokno) as mngcludec
    from    ACAUTOORDT a
            join VGT.TT_ACACC0047PL_ACAUTOORDT2 b
                on a.compcode = b.compcode
                and a.acattype = b.acattype
                and a.slipindate = b.slipindate
                and a.acatno = b.acatno
            join ACAUTORULESM c
                on a.acatrulecode = c.acautorcode
            join ACAUTORULEDS d
                on c.acautorcode = d.acautorcode
                and c.acautoseq = d.acautoseq
            join ACACCMNGM e
                on c.acacccode = e.acccode
                and e.dcdiv = case when c.dcdiv in ('1',' 4') then '1' else '2' end
                and d.mngclucode = e.mngclucode
            -- 카드수금인경우 미수금의 거래처를 연결거래처로 변경
            left join CMCOMMONM f
                on a.acatrulecode = 'C01002'
                and c.acacccode = p_acccode1
                and f.cmmcode = 'AC17'
                and a.cardcomp = f.divcode
            left join CMCUSTM g
                on a.acatrulecode = 'C01002'
                and c.acacccode = p_acccode1
                and nvl(nullif(f.remark, null),'') = g.custcode
    where   a.compcode = p_compcode
            and a.actrnstate in ('1', '3')
            and a.acattype like p_slipdiv;

    -- 전표상세임시파일생성(부문:수금)
    insert into VGT.TT_ACACC0047PL_ACORDD2
    select  a.compcode
            ,replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno
            ,row_number() over(partition by a.slipindate || a.acattype || b.slipinnum order by a.acatno, c.acautoseq)
            ,c.dcdiv
            ,c.acacccode as acccode
            ,nvl(d.plantcode, a.plantcode) as plantcode
            ,case when c.dcdiv in ('1','4')    -- 차변,출금
                  then fnacautoordamt(c.amtdiv, c.accamtdiv, c.acccalcdiv, c.accsamtdiv,
                                      a.trn1amt, a.trn2amt, a.trn3amt, a.trn4amt, a.trn5amt,
                                      a.trn6amt, a.trn7amt, a.trn8amt, a.trn9amt, a.trn10amt,
                                      a.trn11amt, a.trn12amt, a.trn13amt, a.trn14amt, a.trn15amt,
                                      a.trn16amt, a.trn17amt, a.trn18amt, a.trn19amt, a.trn20amt,
                                      a.trn21amt, a.trn22amt, a.trn23amt, a.trn24amt, a.trn25amt,
                                      a.trn26amt, a.trn27amt, a.trn28amt, a.trn29amt, a.trn30amt)
                  else 0 end as debamt
            ,case when c.dcdiv in ('2','3')    -- 대변,입금
                  then fnacautoordamt(c.amtdiv, c.accamtdiv, c.acccalcdiv, c.accsamtdiv,
                                      a.trn1amt, a.trn2amt, a.trn3amt, a.trn4amt, a.trn5amt,
                                      a.trn6amt, a.trn7amt, a.trn8amt, a.trn9amt, a.trn10amt,
                                      a.trn11amt, a.trn12amt, a.trn13amt, a.trn14amt, a.trn15amt,
                                      a.trn16amt, a.trn17amt, a.trn18amt, a.trn19amt, a.trn20amt,
                                      a.trn21amt, a.trn22amt, a.trn23amt, a.trn24amt, a.trn25amt,
                                      a.trn26amt, a.trn27amt, a.trn28amt, a.trn29amt, a.trn30amt)
                  else 0 end as creamt
            ,case when c.acacccode = p_acccode5 then a.userdef10code else nvl(nullif(a.remark, ''), b.remark1) end as remark1
            ,nvl(nullif(a.remark2, null), b.remark2) as remark2
            ,a.taxno
            ,case when p_colseq = 'Y' then a.trn30amt else 0 end as crtord
    from    ACAUTOORDT a
            join VGT.TT_ACACC0047PL_ACAUTOORDT1 b
                on a.compcode = b.compcode
                and a.plantcode = b.plantcode
                and a.acattype = b.acattype
                and a.slipindate = b.slipindate
                and case when p_salload = 'empcode' and a.acattype = 'S' then a.empcode
                         when p_salload = 'iempcode' and a.acattype = 'S' then a.iempcode
                         when p_salload = 'newload' and a.acattype = 'S' then a.iempcode
                         when p_salload = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                         when p_colload = 'empcode' and a.acattype = 'C' then a.empcode
                         when p_colload = 'iempcode' and a.acattype = 'C' then a.iempcode
                         when p_colload = 'newload' and a.acattype = 'C' then a.iempcode
                         when p_colload = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                         when p_colload = 'custcode' and a.acattype = 'C' then a.custcode
                         when p_expload = 'importshtno' and a.acattype = 'N' then a.billno
                         else '' end = b.acatrulecode
            join ACAUTORULESM c on a.acatrulecode = c.acautorcode
            left join (
                select  a.divcode
                        ,b.plantcode
                from    CMCOMMONM a
                        join CMPLANTM b
                            on a.filter2 = b.plantcode
                where   a.cmmcode = 'AC201'
            ) d on a.acattype = d.divcode
    where   a.compcode = p_compcode
            and a.actrnstate in ('1','3')
            and a.acattype like p_slipdiv
            and (trim(p_salload) is not null or trim(p_colload) is not null or trim(p_expload) is not null);

    -- 관리항목임시파일생성(부문:수금)
    insert into VGT.TT_ACACC0047PL_ACORDS2
    select  a.compcode
            ,a.slipinno2
            ,a.slipinseq2
            ,b.mngclucode
            ,d.seq
            ,fnacautoordval(b.mngcluvaldiv,
                            a.userdef1code, a.userdef2code, a.userdef3code, a.userdef4code, a.userdef5code,
                            a.userdef6code, a.userdef7code, a.userdef8code, a.userdef9code, a.userdef10code,
                            a.userdef11code, a.userdef12code, a.userdef13code, a.userdef14code, a.userdef15code,
                            a.userdef16code, a.userdef17code, a.userdef18code, a.userdef19code, a.userdef20code,
                            a.userdef21code, a.userdef22code, a.userdef23code, a.userdef24code, a.userdef25code,
                            a.userdef26code, a.userdef27code, a.userdef28code, a.userdef29code, a.userdef30code,
                            a.deptcode, a.custcode, a.taxno, a.billno, a.issdate, a.expdate, a.cardno, a.empcode, a.cardokno) as mngcluval
            ,fnacautoordval(b.mngcludecdiv,
                            a.userdef1code, a.userdef2code, a.userdef3code, a.userdef4code, a.userdef5code,
                            a.userdef6code, a.userdef7code, a.userdef8code, a.userdef9code, a.userdef10code,
                            a.userdef11code, a.userdef12code, a.userdef13code, a.userdef14code, a.userdef15code,
                            a.userdef16code, a.userdef17code, a.userdef18code, a.userdef19code, a.userdef20code,
                            a.userdef21code, a.userdef22code, a.userdef23code, a.userdef24code, a.userdef25code,
                            a.userdef26code, a.userdef27code, a.userdef28code, a.userdef29code, a.userdef30code,
                            a.deptcode, a.custcode, a.taxno, a.billno, a.issdate, a.expdate, a.cardno, a.empcode, a.cardokno) as mngcludec
    from (
        select  a.*
                ,replace(a.slipindate,'-','') || a.acattype || b.slipinnum as slipinno2
                ,row_number() over(partition by a.slipindate || a.acattype || b.slipinnum order by a.acatno, c.acautoseq) slipinseq2
                ,c.acautorcode
                ,c.acautoseq
                ,c.acacccode
                ,c.dcdiv
        from    ACAUTOORDT a
                join VGT.TT_ACACC0047PL_ACAUTOORDT1 b
                    on a.compcode = b.compcode
                    and a.plantcode = b.plantcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and case when p_salload = 'empcode' and a.acattype = 'S' then a.empcode
                             when p_salload = 'iempcode' and a.acattype = 'S' then a.iempcode
                             when p_salload = 'newload' and a.acattype = 'S' then a.iempcode
                             when p_salload = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                             when p_colload = 'empcode' and a.acattype = 'C' then a.empcode
                             when p_colload = 'iempcode' and a.acattype = 'C' then a.iempcode
                             when p_colload = 'newload' and a.acattype = 'C' then a.iempcode
                             when p_colload = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                             when p_colload = 'custcode' and a.acattype = 'C' then a.custcode
                             when p_expload = 'importshtno' and a.acattype = 'N' then a.billno
                             else '' end = b.acatrulecode
                join ACAUTORULESM c
                    on a.acatrulecode = c.acautorcode
        where   a.compcode = p_compcode
                and a.actrnstate in ('1', '3')
                and a.acattype like p_slipdiv
                and (trim(p_salload) is not null or trim(p_colload) is not null or trim(p_expload) is not null)
    ) a
            join ACAUTORULEDS b
                on a.acautorcode = b.acautorcode
                and a.acautoseq = b.acautoseq
            join ACACCMNGM d
                on a.acacccode = d.acccode
                and d.dcdiv = case when a.dcdiv in ('1','4') then '1' else '2' end
                and b.mngclucode = d.mngclucode;

    -- 차/대변 금액이 0인것은 삭제
    for rec in (
        select  b.compcode
                ,b.slipinno
                ,b.acautoseq
        from    VGT.TT_ACACC0047PL_ACORDD2 a
                join VGT.TT_ACACC0047PL_ACORDS2 b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                    and a.acautoseq = b.acautoseq
                left join CMCOMMONM c
                    on c.cmmcode = 'AC251'
                    and c.hdivcode in ('04', '12')
                    and a.acccode = c.filter1
        where   a.debamt = 0
                and a.creamt = 0
                and c.cmmcode is null)
    loop
        delete
        from    VGT.TT_ACACC0047PL_ACORDS2 a
        where   a.compcode = rec.compcode
                and a.slipinno = rec.slipinno
                and a.acautoseq = rec.acautoseq;
    end loop;

    for rec in (
        select  a.compcode
                ,a.slipinno
                ,a.acautoseq
        from    VGT.TT_ACACC0047PL_ACORDD2 a
                left join CMCOMMONM c
                    on c.cmmcode = 'AC251'
                    and c.hdivcode in ('04', '12')
                    and a.acccode = c.filter1
        where   a.debamt = 0
                and a.creamt = 0
                and c.cmmcode is null)
    loop
        delete
        from    VGT.TT_ACACC0047PL_ACORDD2 a
        where   a.compcode = rec.compcode
                and a.slipinno = rec.slipinno
                and a.acautoseq = rec.acautoseq;
    end loop;

    -- 영업거래처 대표거래처로 변경
    merge into VGT.TT_ACACC0047PL_ACORDS2 a
    using (
        select  a.compcode
                ,a.slipinno
                ,a.acautoseq
                ,a.mngclucode
                ,a.seq
                ,nvl(c.custcode, a.mngcluval) as mngcluval
                ,nvl(c.custname, a.mngcludec) as mngcludec
        from    VGT.TT_ACACC0047PL_ACORDS2 a
                join CMCUSTM b
                    on a.mngcluval = b.custcode
                join CMCUSTM c
                    on b.custmajorcode = c.custcode
        where   a.mngclucode = 'S010'
                and (p_salecust = 'Y' and a.slipinno like '%S%' or p_colcust = 'Y' and a.slipinno like '%C%')
    ) src on (nvl(a.compcode, ' ') = nvl(src.compcode, ' ')
              and nvl(a.slipinno, ' ') = nvl(src.slipinno, ' ')
              and nvl(a.acautoseq, ' ') = nvl(src.acautoseq, ' ')
              and nvl(a.mngclucode, ' ') = nvl(src.mngclucode, ' ')
              and nvl(a.seq, ' ') = nvl(src.seq, ' '))
    when matched
    then
        update set a.mngcluval = src.mngcluval,
                   a.mngcludec = src.mngcludec;

    -- 전표상세일련번호재생성(개별)
    execute immediate 'delete from VGT.TT_ACACC0047PL_ACORDD22';
    insert into VGT.TT_ACACC0047PL_ACORDD22
    select  compcode
            ,slipinno
            ,row_number() over(partition by compcode, slipinno order by crtord, acautoseq) as slipinseq
            ,dcdiv
            ,acccode
            ,plantcode
            ,debamt
            ,creamt
            ,remark1
            ,remark2
            ,taxno
            ,acautoseq
    from    VGT.TT_ACACC0047PL_ACORDD2;

    -- 전표상세생성(개별)
    insert into ACORDD
        (
            compcode
            ,slipinno
            ,slipinseq
            ,dcdiv
            ,acccode
            ,plantcode
            ,debamt
            ,creamt
            ,slipdate
            ,slipnum
            ,remark1
            ,remark2
            ,taxno
            ,datadiv
            ,rptseq
            ,insertdt
            ,iempcode
        )
    select  a.compcode
            ,a.slipinno
            ,a.slipinseq
            ,a.dcdiv
            ,a.acccode
            ,a.plantcode
            ,a.debamt
            ,a.creamt
            ,b.slipdate
            ,b.slipnum
            ,a.remark1
            ,a.remark2
            ,case when a.acccode like p_acccode2 || '%' or a.acccode like p_acccode3 || '%' then nvl(a.taxno,'') else '' end
            ,''
            ,a.slipinseq
            ,p_insertdt
            ,p_iempcode
    from    VGT.TT_ACACC0047PL_ACORDD22 a
            join ACORDM b
                on a.slipinno = b.slipinno;

    -- 전표관리생성(개별)
    insert into ACORDS
        (
            compcode
            ,slipinno
            ,slipinseq
            ,mngclucode
            ,seq
            ,mngcluval
            ,mngcludec
            ,insertdt
            ,iempcode
        )
    select  a.compcode
            ,a.slipinno
            ,b.slipinseq
            ,a.mngclucode
            ,a.seq
            ,a.mngcluval
            ,a.mngcludec
            ,p_insertdt
            ,p_iempcode
    from    VGT.TT_ACACC0047PL_ACORDS2 a
            join VGT.TT_ACACC0047PL_ACORDD22 b
                on a.compcode = b.compcode
                and a.slipinno = b.slipinno
                and a.acautoseq = b.acautoseq;

    -- 회계 자동전표 처리 모니터링 변경
    merge into ACAUSLIPM a
    using (
        select  b.compcode
                ,b.slipindate
                ,b.accdiv
                ,b.acautorcode
                ,a.iempcode
                ,a.insertdt
        from (
            select  compcode
                    ,slipindate
                    ,acattype
                    ,acatrulecode
                    ,max(iempcode) as iempcode
                    ,max(insertdt) as insertdt
            from    ACAUTOORDT
            where   compcode = p_compcode
                    and actrnstate in ('1','3','4')
                    and acattype like p_slipdiv
            group by compcode, slipindate, acattype, acatrulecode
        ) a
                join ACAUSLIPM b
                    on a.compcode = b.compcode
                    and a.slipindate = b.slipindate
                    and a.acattype = b.accdiv
                    and a.acatrulecode = b.acautorcode
    ) src on (a.compcode = src.compcode
              and a.slipindate = src.slipindate
              and a.accdiv = src.accdiv
              and a.acautorcode = src.acautorcode)
    when matched then
        update set  a.sndempcode = src.iempcode
                    ,a.snddate = to_char(src.insertdt, 'yyyy-MM-dd')
                    ,a.trnempcode = p_iempcode
                    ,a.trndate = to_char(sysdate, 'yyyy-MM-dd')
                    ,a.updatedt = sysdate
                    ,a.uempcode = p_iempcode;

    -- 회계 자동전표 처리 모니터링 입력
    insert into ACAUSLIPM
        (
            compcode
            ,slipindate
            ,accdiv
            ,acautorcode
            ,sndempcode
            ,snddate
            ,trnempcode
            ,trndate
            ,insertdt
            ,iempcode
        )
    select  a.compcode
            ,a.slipindate
            ,a.acattype
            ,a.acatrulecode
            ,a.iempcode
            ,to_char(a.insertdt, 'yyyy-MM-dd')
            ,p_iempcode
            ,to_char(sysdate, 'yyyy-MM-dd')
            ,sysdate
            ,p_iempcode
    from (
        select  compcode
                ,slipindate
                ,acattype
                ,acatrulecode
                ,max(iempcode) as iempcode
                ,max(insertdt) as insertdt
        from    ACAUTOORDT
        where   compcode = p_compcode
                and actrnstate in ('1', '3', '4')
                and acattype like p_slipdiv
        group by compcode, slipindate, acattype, acatrulecode
    ) a
            left join ACAUSLIPM b
                on a.compcode = b.compcode
                and a.slipindate = b.slipindate
                and a.acattype = b.accdiv
                 and a.acatrulecode = b.acautorcode
    where   trim(b.compcode) is null;

    open SPACC_CURSOR;
    loop
        fetch SPACC_CURSOR into p_slipinno;

        exit when SPACC_CURSOR%notfound;

        spacfund0021p(p_div => 'C2'
                      ,p_compcode => p_compcode
                      ,p_slipinno => p_slipinno
                      ,p_iempcode => p_iempcode
                      ,p_userid => p_userid
                      ,p_reasondiv => p_reasondiv
                      ,p_reasontext => p_reasontext
                      ,MESSAGE => MESSAGE
                      ,IO_CURSOR => IO_CURSOR);
    end loop;

    close spacc_cursor;

--    -- 수금전표 생성시 어음생성
--    execute immediate 'delete from VGT.TT_ACACC0047PL_ACBILLM';
--    insert into VGT.TT_ACACC0047PL_ACBILLM
--    select  a.compcode
--            ,a.billno
--            ,max(b.coldiv) as billdiv
--            ,min(b.issdate) as issdate
--            ,min(b.coldate) as coldate
--            ,max(b.expdate) as expdate
--            ,sum(b.colamt) as billamt
--            ,min(b.custcode) as custcode
--            ,max(b.issempnm) as issempnm
--            ,max(b.paybank) as paybank
--            ,max(b.deptcode) as deptcode
--            ,max(b.plantcode) as plantcode
--            ,max(b.tasooyn) as tasooyn
--    from    ACAUTOORDT a
--            join SLCOLM b
--                on a.acatno = b.colno
--                and b.coldiv like '3%'
--    where   a.compcode = p_compcode
--            and a.acattype like p_slipdiv
--            and a.acattype = 'C'
--            and a.actrnstate = '1'
--            and trim(a.billno) is not null
--    group by a.compcode, a.billno;
--
--    merge into ACBILLM a
--    using (
--        select  a.compcode
--                ,a.billno
--                ,b.billamt
--        from    ACBILLM a
--                join (
--                    select  a.billno
--                            ,sum(b.colamt) as billamt
--                    from    VGT.TT_ACACC0047PL_ACBILLM a
--                            join SLCOLM b
--                                on a.billno = b.billno
--                    group by a.billno
--                ) b on a.billno = b.billno
--    ) src on (a.compcode = src.compcode
--              and a.billno = src.billno)
--    when matched then
--        update set  a.billamt = src.billamt
--                    ,a.updatedt = sysdate
--                    ,a.uempcode = p_iempcode;
--
--    insert into ACBILLM
--        (
--            compcode
--            ,billno
--            ,billcls            --어음구분 ac32
--            ,billdiv            --어음종류 sl18
--            ,billtype
--            ,issdate            --발행일자
--            ,coldate            --수취일자
--            ,expdate            --만기일자
--            ,billamt            --금액
--            ,custcode
--            ,issempnm
--            ,bankcode
--            ,paybank
--            ,deptcode
--            ,plantcode
--            ,tasooyn
--            ,issdiv            --발행구분 ac31
--            ,billstate            --어음상태 ac53
--            ,accountno
--            ,billremark
--            ,insertdt
--            ,iempcode
--        )
--    select  a.compcode
--            ,a.billno
--            ,'1'
--            ,a.billdiv
--            ,''
--            ,a.issdate
--            ,a.coldate
--            ,a.expdate
--            ,a.billamt
--            ,a.custcode
--            ,a.issempnm
--            ,''
--            ,a.paybank
--            ,a.deptcode
--            ,a.plantcode
--            ,a.tasooyn
--            ,'A'
--            ,'1'
--            ,''
--            ,''
--            ,sysdate
--            ,p_iempcode
--    from    VGT.TT_ACACC0047PL_ACBILLM a
--            left join ACBILLM b
--                on a.billno = b.billno
--    where   trim(b.billno) is null;

    -- 해당일자 회계전표유형(신규,수정)을 모두 완료로 변경한다.
    merge into ACAUTOORDT a
    using (
        select  a.compcode
                ,a.acattype
                ,a.acatno
                ,replace(a.slipindate,'-','') || a.acattype || nvl(b.slipinnum, c.slipinnum) as slipinno
        from    ACAUTOORDT a
                left join VGT.TT_ACACC0047PL_ACAUTOORDT1 b
                    on a.compcode = b.compcode
                    and a.plantcode = b.plantcode
                    and a.acattype = b.acattype
                    and a.slipindate = b.slipindate
                    and case when p_salload = 'empcode' and a.acattype = 'S' then a.empcode
                             when p_salload = 'iempcode' and a.acattype = 'S' then a.iempcode
                             when p_salload = 'newload' and a.acattype = 'S' then a.iempcode
                             when p_salload = 'acatrulecode' and a.acattype = 'S' then a.acatrulecode || a.iempcode
                             when p_colload = 'empcode' and a.acattype = 'C' then a.empcode
                             when p_colload = 'iempcode' and a.acattype = 'C' then a.iempcode
                             when p_colload = 'newload' and a.acattype = 'C' then a.iempcode
                             when p_colload = 'acatrulecode' and a.acattype = 'C' then a.acatrulecode || a.iempcode
                             when p_colload = 'custcode' and a.acattype = 'C' then a.custcode
                             when p_expload = 'importshtno' and a.acattype = 'N' then a.billno
                             when a.acattype = 'H' then a.plantcode
                             else '' end = b.acatrulecode
                left join VGT.TT_ACACC0047PL_ACAUTOORDT2 c
                    on a.compcode = c.compcode
                    and a.acattype = c.acattype
                    and a.slipindate = c.slipindate
                    and a.acatno = c.acatno
        where   a.compcode = p_compcode
                and a.actrnstate in ('1', '3')
                and a.acattype like p_slipdiv
    ) src on (a.compcode = src.compcode
              and a.acatno = src.acatno)
    when matched then
        update set  a.actrnstate = '2',
                    a.slipinno = src.slipinno;

    -- 해당일자 회계전표유형(삭제)을 삭제한다.
    delete
    from    ACAUTOORDT a
    where   a.compcode = p_compcode
            and a.actrnstate = '4'
            and a.acattype like p_slipdiv;

    -- 회계전표 잔액 집계처리
    SPACORD0000MM(p_div => 'T',
                  p_compcode => p_compcode, -- 회사코드
                  p_closediv => '10', -- 결산구분(운영)
                  p_strslipym => p_strartym, -- 결의전표번호
                  p_endslipym => p_endym, -- 결의전표번호
                  p_userid => p_userid,
                  p_reasondiv => p_reasondiv,
                  p_reasontext => p_reasontext,
                  MESSAGE => MESSAGE,
                  IO_CURSOR => IO_CURSOR);

    -- 회계전표 예산 집계처리
    SPACBUDG0000MM(p_div => 'TO',
                   p_compcode => p_compcode, -- 회사코드
                   p_strbudgym => p_strartym, -- 결의전표번호
                   p_endbudgym => p_endym, -- 결의전표번호
                   p_userid => p_userid,
                   p_reasondiv => p_reasondiv,
                   p_reasontext => p_reasontext,
                   MESSAGE => MESSAGE,
                   IO_CURSOR => IO_CURSOR);

    if(p_strartym is null) then
        p_strartym := '0000-00';
    end if;

    MESSAGE := p_strartym || '-01' || to_char(last_day(to_date(p_endym || '-01', 'yyyy-MM-dd')), 'yyyy-MM-dd') || to_char(p_proccnt);

   <<LASTLINE>>
    if (IO_CURSOR is null) then
        open IO_CURSOR for select code FROM VGT.TT_TABEL_EMPTY;
    end if;

END;
/
