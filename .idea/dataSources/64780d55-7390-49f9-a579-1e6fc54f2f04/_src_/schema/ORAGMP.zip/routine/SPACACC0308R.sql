CREATE PROCEDURE        spACacc0308R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0308R
 -- 작 성 자         : 배종성
 -- 작성일자         : 2011-03-23
 --수정자           : 임 정호
 -- 작성일자         : 2016-12-27

 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 대손충당금설정명세서를 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
 -- select * from CMCUSTM
 -- select * from ACACCM   -- dcdiv (차대구분) 'AC04' 1 - 차변 2- 대변
 -- select * from CMCOMMONM where cmmcode = 'AC02'
 -- select * from CMCOMMONM where cmmcode = 'AC253' - 대손충당금설정명세서 찍을목록
 -- select * from ACORDDMM
 -- select * from ACORDD
 -- spACacc0308R 'S','100','1000','2011-02','1', '','','','N'
 -- spACacc0308R 'S1','100','1000','2011-02','1', '','','','N'

(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '' ,
    p_yymm          IN VARCHAR2 DEFAULT '' ,
    p_outputdiv     IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,
    IO_CURSOR       OUT TYPES.DataSet,
    MESSAGE         OUT VARCHAR2
)
AS
   p_odiv1 VARCHAR2(5);
   p_beforedate VARCHAR2(10);

BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    p_odiv1 := '' ;
    p_beforedate := '' ;

    IF ( p_outputdiv = '1' ) THEN
        --K-GAAP
        p_odiv1 := '20' ;
    END IF;
    --set	@odiv2 = 'F'
    IF ( p_outputdiv = '2' ) THEN
        --IFRS
        p_odiv1 := '30' ;
    END IF;

   --set	@odiv2 = 'K'
   --2011.05.04 1개월전 으로 변경(경남 회계팀 요청)
    p_beforedate :=  TO_CHAR (LAST_DAY (TO_DATE (p_yymm, 'YYYY-MM')-1), 'YYYY-MM-DD');

    IF ( p_div = 'SC' ) THEN

    -- 컬럼이름 바꿀것

        OPEN  IO_CURSOR FOR
        SELECT  p_beforedate prtdateb  ,
                TO_CHAR (LAST_DAY (TO_DATE (p_yymm , 'YYYY-MM')), 'YYYY-MM-DD') prtdate
        FROM DUAL  ;

    ELSIF ( p_div = 'S' ) THEN
        OPEN  IO_CURSOR FOR
        SELECT  p_plantcode plantcode,
                A.* ,
                '' remark
        FROM    (
                    SELECT  '1' seq  ,
                            '1' seq1  ,
                            compcode ,
                            hacccode ,
                            haccname ,
                            acccode ,
                            accname ,
                            totamtb ,-- plant 때문에 sum
                            totamt ,
                            setasideamt ,
                            returnamt
                    FROM    (
                            ----------------------
                                SELECT  p_compcode compcode  ,
                                        MAX(AM.hacccode)  hacccode  ,
                                        MAX(HAM.accname)  haccname  ,
                                        A.acccode ,
                                        MAX(AM.accname)  accname  ,
                                        SUM(NVL(b.totcreamt, 0) - NVL(b.totdebamt, 0))  totamtb ,
                                        SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0))  totamt  ,
                                        CASE
                                            WHEN SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))  >= 0 THEN
                                                SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))
                                            ELSE
                                                0
                                        END setasideamt  ,
                                        CASE
                                            WHEN SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))  < 0 THEN
                                                SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))
                                            ELSE
                                                0
                                        END returnamt
                                FROM    ACORDDMM A
                                        LEFT JOIN CMCOMMONM AC253   ON AC253.cmmcode = 'AC253'
                                        LEFT JOIN ACORDDMM b
                                            ON      b.compcode = A.compcode
                                                AND b.plantcode = A.plantcode
                                                AND b.acccode = A.acccode
                                                AND b.slipym = SUBSTR(p_beforedate, 0, 7)
                                                AND b.closediv = A.closediv
                                        LEFT JOIN ACACCM AM   ON A.acccode = AM.acccode
                                        LEFT JOIN ACACCM HAM   ON AM.hacccode = HAM.acccode
                                WHERE   A.compcode = p_compcode
                                    AND A.plantcode LIKE p_plantcode
                                    AND A.slipym = p_yymm
                                    AND A.acccode = AC253.filter1
                                    AND ( A.totdebamt <> 0 OR A.totcreamt <> 0 )
                                    AND ( A.closediv = '10' OR A.closediv = p_odiv1 ) -- 출력구분 [K-GAAP, IFRS]
                                GROUP BY A.acccode
                            ----------------------
                            )
                    UNION ALL
                    SELECT  '1' seq  ,
                            '2' seq1  ,
                            MAX(compcode)  compcode  ,
                            hacccode ,
                            MAX(haccname)  haccname  ,
                            '' acccode  ,
                            '소계' accname  ,
                            SUM(totamtb)  totamtb ,-- plant 때문에 sum
                            SUM(totamt)  totamt  ,
                            SUM(setasideamt)  addamt  ,
                            SUM(returnamt)  returnamt
                            FROM (
                            -----------------------------
                                    SELECT  p_compcode compcode  ,
                                            MAX(AM.hacccode)  hacccode  ,
                                            MAX(HAM.accname)  haccname  ,
                                            A.acccode ,
                                            MAX(AM.accname)  accname  ,
                                            SUM(NVL(b.totcreamt, 0) - NVL(b.totdebamt, 0))  totamtb ,
                                            SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0))  totamt  ,
                                            CASE
                                                WHEN SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))  >= 0 THEN
                                                    SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))
                                                ELSE
                                                    0
                                            END setasideamt  ,
                                            CASE
                                                WHEN SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))  < 0 THEN
                                                    SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))
                                                ELSE
                                                    0
                                            END returnamt
                                    FROM    ACORDDMM A
                                            LEFT JOIN CMCOMMONM AC253   ON AC253.cmmcode = 'AC253'
                                            LEFT JOIN ACORDDMM b
                                                ON      b.compcode = A.compcode
                                                    AND b.plantcode = A.plantcode
                                                    AND b.acccode = A.acccode
                                                    AND b.slipym = SUBSTR(p_beforedate, 0, 7)
                                                    AND b.closediv = A.closediv
                                            LEFT JOIN ACACCM AM   ON A.acccode = AM.acccode
                                            LEFT JOIN ACACCM HAM   ON AM.hacccode = HAM.acccode
                                    WHERE   A.compcode = p_compcode
                                        AND A.plantcode LIKE p_plantcode
                                        AND A.slipym = p_yymm
                                        AND A.acccode = AC253.filter1
                                        AND ( A.totdebamt <> 0 OR A.totcreamt <> 0 )
                                        AND ( A.closediv = '10' OR A.closediv = p_odiv1 ) -- 출력구분 [K-GAAP, IFRS]
                                    GROUP BY A.acccode
                            -----------------------------
                                 )
                    GROUP BY hacccode
                    UNION ALL
                    SELECT  '2' seq  ,
                            '3' seq1  ,
                            MAX(compcode)  compcode  ,
                            '' hacccode  ,
                            '' haccname  ,
                            '' acccode  ,
                            '합계' accname  ,
                            SUM(totamtb)  totamtb ,-- plant 때문에 sum
                            SUM(totamt)  totamt  ,
                            SUM(setasideamt)  addamt  ,
                            SUM(returnamt)  returnamt
                    FROM (
                          ------------------------------------
                            SELECT  p_compcode compcode  ,
                                    MAX(AM.hacccode)  hacccode  ,
                                    MAX(HAM.accname)  haccname  ,
                                    A.acccode ,
                                    MAX(AM.accname)  accname  ,
                                    SUM(NVL(b.totcreamt, 0) - NVL(b.totdebamt, 0))  totamtb ,
                                    SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0))  totamt  ,
                                    CASE
                                        WHEN SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))  >= 0 THEN
                                            SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))
                                        ELSE
                                            0
                                    END setasideamt  ,
                                    CASE
                                        WHEN SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))  < 0 THEN
                                            SUM(NVL(A.totcreamt, 0) - NVL(A.totdebamt, 0) - NVL(b.totcreamt, 0) + NVL(b.totdebamt, 0))
                                        ELSE 0
                                    END returnamt
                            FROM    ACORDDMM A
                                    LEFT JOIN CMCOMMONM AC253   ON AC253.cmmcode = 'AC253'
                                    LEFT JOIN ACORDDMM b
                                        ON      b.compcode = A.compcode
                                            AND b.plantcode = A.plantcode
                                            AND b.acccode = A.acccode
                                            AND b.slipym = SUBSTR(p_beforedate, 0, 7)
                                            AND b.closediv = A.closediv
                                    LEFT JOIN ACACCM AM   ON A.acccode = AM.acccode
                                    LEFT JOIN ACACCM HAM   ON AM.hacccode = HAM.acccode
                            WHERE   A.compcode = p_compcode
                                AND A.plantcode LIKE p_plantcode
                                AND A.slipym = p_yymm
                                AND A.acccode = AC253.filter1
                                AND ( A.totdebamt <> 0 OR A.totcreamt <> 0 )
                                AND ( A.closediv = '10' OR A.closediv = p_odiv1 ) -- 출력구분 [K-GAAP, IFRS]
                            GROUP BY A.acccode
                          ------------------------------------
                         )
                    GROUP BY compcode ) A
        ORDER BY seq, hacccode, seq1, acccode ;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
