CREATE PROCEDURE        spACbase0090P
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbase00090P
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-09-07
	-- 수    정         : 2011-01-25 이영재(월마감통제 기능 수정)
	--                        -- 회계전표 로드 모니터링 테이블 조회 추가 ACAUSLIPM
    -- 수 정 자     : 강현호
    -- E-Mail       : roykang0722@gmail.com
    -- 수정일자      : 2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 테이블 (CMCLOSEM)을 등록,수정,삭제,조회하는 프로시저이다.
	-- ---------------------------------------------------------------
(
	p_div			   IN	  VARCHAR2 DEFAULT '',
	p_cyear 		   IN	  VARCHAR2 DEFAULT '', 																																																												  --회기년도
	p_compcode		   IN	  VARCHAR2 DEFAULT '',
	p_strym 		   IN	  VARCHAR2 DEFAULT '',
	p_endym 		   IN	  VARCHAR2 DEFAULT '',
	p_closeym		   IN	  VARCHAR2 DEFAULT '', 																																																												  -- 처리월
	p_accdiv		   IN	  VARCHAR2 DEFAULT '',
	p_apprcloseyn	   IN	  VARCHAR2 DEFAULT '',
	p_apprclosedate    IN	  VARCHAR2 DEFAULT '',
	p_apprempcode	   IN	  VARCHAR2 DEFAULT '',
	p_iempcode		   IN	  VARCHAR2 DEFAULT '',
	p_userid		   IN	  VARCHAR2 DEFAULT '',
	p_reasondiv 	   IN	  VARCHAR2 DEFAULT '',
	p_reasontext	   IN	  VARCHAR2 DEFAULT '',

    MESSAGE            OUT    VARCHAR2,
    IO_CURSOR          OUT    TYPES.DataSet
)
AS

    p_countA    NUMBER;
    p_runyymm   VARCHAR2(7);
    p_checkMC   VARCHAR2(5); --마감여부 점검


BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	IF (UPPER(p_div) = UPPER('SESS')) THEN

        -- 회계기수 검색
        FOR rec IN (SELECT a.sseq AS alias1
                    FROM   ACSESSION a
                    WHERE  a.compcode = p_compcode
                           AND a.cyear = p_cyear)
        LOOP
            MESSAGE := rec.alias1;
        END LOOP;

	ELSIF (UPPER(p_div) = UPPER('S')) THEN

        --조회
        OPEN IO_CURSOR FOR

            SELECT	 NVL(a.compcode, '') compcode,
                     NVL(a.closeym, '') closeym,
                     NVL(a.accdiv, '') accdiv,
                     NVL(a.apprclosedate, '') apprclosedate,
                     NVL(a.apprcloseyn, '') apprcloseyn,
                     NVL(a.apprempcode, '') apprempcode,
                     NVL(a.autoruledate, '') autoruledate,
                     NVL(a.autorulestate, '') autorulestate,
                     NVL(b.empname, '') apprempname,
                     NVL(ac20.divname, '') accdivname,
                     CASE WHEN a.apprcloseyn = 'Y' THEN '통제설정됨' ELSE '통제안함' END closepara,
                     NVL(ac201.filter2, '') divseq
            FROM	 CMCLOSEM a
                     LEFT JOIN CMEMPM b ON a.apprempcode = b.empcode
                     LEFT JOIN CMCOMMONM ac20 ON a.accdiv = ac20.divcode
                                                 AND ac20.cmmcode = 'AC20'
                     LEFT JOIN CMCOMMONM ac201 ON a.accdiv = ac201.divcode
                                                  AND ac201.cmmcode = 'AC201'
            WHERE	 a.compcode = p_compcode
                     AND a.closeym BETWEEN p_strym AND p_endym
                     AND a.accdiv LIKE p_accdiv
            ORDER BY a.closeym, a.accdiv;

    ELSIF (UPPER(p_div) = UPPER('SS')) THEN

        --개별조회
        FOR rec IN (SELECT COUNT(*) AS alias1
                    FROM   CMCLOSEM a
                    WHERE  a.compcode = p_compcode
                           AND a.closeym = p_closeym
                           AND a.accdiv = p_accdiv)
        LOOP
            p_countA := rec.alias1;
        END LOOP;

        IF (NVL(p_countA, 0) >= 1) THEN
            MESSAGE := 'YES';
        ELSE
            MESSAGE := 'NO';
        END IF;

    ELSIF (UPPER(p_div) = UPPER('SI')) THEN --입력 조회

        p_runyymm := p_strym;

        --임시 테이블 데이터 삭제
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBASE0090P_CMBASE0090P2';

        -- 한달의 회계전표유형 생성
        WHILE p_runyymm <= p_endym LOOP

            INSERT INTO VGT.TT_ACBASE0090P_CMBASE0090P2(compcode,
                                        closeym,
                                        accdiv,
                                        apprclosedate,
                                        apprcloseyn,
                                        apprempcode,
                                        autoruledate,
                                        autorulestate,
                                        apprempname,
                                        accdivname,
                                        closepara,
                                        divseq)

            (SELECT p_compcode compcode,
                    p_runyymm closeym,
                    NVL(ac20.divcode, '') accdiv,
                    NVL(a.apprclosedate, '') apprclosedate,
                    NVL(a.apprcloseyn, '') apprcloseyn,
                    NVL(a.apprempcode, '') apprempcode,
                    NVL(a.autoruledate, '') autoruledate,
                    NVL(a.autorulestate, '') autorulestate,
                    NVL(b.empname, '') apprempname,
                    NVL(ac20.divname, '') accdivname,
                    CASE WHEN a.apprcloseyn = 'Y' THEN '통제설정됨' ELSE '통제안함' END closepara,
                    NVL(ac201.filter1, '') divseq

             FROM	CMCOMMONM ac20
                    LEFT JOIN CMCLOSEM a ON a.compcode = p_compcode
                                            AND a.closeym = p_runyymm
                                            AND a.accdiv = ac20.divcode
                    LEFT JOIN CMCOMMONM ac201 ON ac201.cmmcode = 'AC201'
                                                 AND ac201.divcode = ac20.divcode
                    LEFT JOIN CMEMPM b ON a.apprempcode = b.empcode

             WHERE	ac20.cmmcode = 'AC20'
                    AND (ac20.divcode = p_accdiv OR p_accdiv IN ('%') OR p_accdiv IS NULL
                         AND ac20.divcode LIKE '%'));

            p_runyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_runyymm|| '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM');

        END LOOP;

        OPEN IO_CURSOR FOR
            SELECT	 *
            FROM	 VGT.TT_ACBASE0090P_CMBASE0090P2
            ORDER BY closeym, accdiv;

    ELSIF (UPPER(p_div) = UPPER('I')) THEN

        INSERT INTO CMCLOSEM(compcode,
                             closeym,
                             accdiv,
                             apprcloseyn,
                             apprclosedate,
                             apprempcode,
                             insertdt,
                             iempcode)
        VALUES		(p_compcode,
                     p_closeym,
                     p_accdiv,
                     --NVL(NULLIF(p_apprcloseyn, ' '), 'N'),
                     NVL( CASE WHEN NVL(TRIM(p_apprcloseyn), '') IS NULL THEN ''
                               ELSE p_apprcloseyn
                          END, 'N'),

                     p_apprclosedate,
                     p_apprempcode,
                     SYSDATE,
                     p_iempcode);

    ELSIF (UPPER(p_div) = UPPER('U')) THEN

        UPDATE CMCLOSEM
        SET    compcode = p_compcode,
               closeym = p_closeym,
               accdiv = p_accdiv,
               apprcloseyn = p_apprcloseyn,
               apprclosedate = p_apprclosedate,
               apprempcode = p_apprempcode,
               updatedt = SYSDATE,
               uempcode = p_iempcode
        WHERE  compcode = p_compcode
               AND closeym = p_closeym
               AND accdiv = p_accdiv;

    ELSIF (UPPER(p_div) = UPPER('D')) THEN

        DELETE CMCLOSEM
        WHERE  compcode = p_compcode
               AND closeym = p_closeym
               AND accdiv = p_accdiv;

    ELSIF (UPPER(p_div) = UPPER('CA')) THEN --마감여부 점검

        MESSAGE := 'OK';

        FOR rec IN (SELECT ac20.filter2 AS alias1
                    FROM   CMCOMMONM ac20
                    WHERE  ac20.cmmcode = 'AC20'
                           AND ac20.divcode = p_accdiv )
        LOOP
            p_checkMC := rec.alias1;
        END LOOP;

        IF (p_checkMC = 'Y') THEN

            p_checkMC := 'N';

            FOR rec IN (SELECT a.apprcloseyn AS alias1
                        FROM   CMCLOSEM a
                        WHERE  a.compcode = p_compcode
                               AND a.closeym = p_closeym
                               AND a.accdiv = p_accdiv)
            LOOP
                p_checkMC := rec.alias1;
            END LOOP;

            IF (p_checkMC = 'Y') THEN
                    MESSAGE := 'NO';
            END IF;

        END IF;


    ELSIF (UPPER(p_div) = UPPER('SDM')) THEN -- 회계 전표 로드 모니터링 테이블 조회

        OPEN IO_CURSOR FOR

            SELECT  a.compcode compcode,
                    a.accdiv accdiv,
                    a.slipindate accymd, 		                                -- 전표 일자
                    '' autostatus,
                    a.sndempcode sndempcode,
                    snd.empname sndempname,		                                -- 전송 사원명
                    ac20.divname accdivname,                                    -- 유형명
                    a.snddate snddate,		                                    -- 전송일자
                    a.trnempcode trnempcode,
                    trn.empname trnempname,
                    a.trndate trndate
            FROM    ACAUSLIPM a
                    LEFT JOIN CMEMPM snd ON a.sndempcode = snd.empcode          -- 전송사원
                    LEFT JOIN CMEMPM trn ON a.trnempcode = trn.empcode          -- 회계로드사원
                    LEFT JOIN CMCOMMONM ac20 ON ac20.divcode = p_accdiv
                                                AND ac20.cmmcode = 'AC20'
            WHERE   a.compcode = p_compcode
                    AND a.slipindate LIKE p_closeym || '%'
                    AND a.accdiv = p_accdiv;


	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
