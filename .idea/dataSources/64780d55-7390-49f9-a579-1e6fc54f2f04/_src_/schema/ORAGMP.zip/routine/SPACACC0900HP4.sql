CREATE PROCEDURE        spACacc0900HP4
-- ---------------------------------------------------------------
 -- 프로시저명   : spACacc0900HP4
 -- 작 성 자   : 최용석
 -- 작성일자    : 2014-05-22
 -- ---------------------------------------------------------------
 -- 프로시저 설명 : 급여회계로드
 -- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '' ,

    p_compcode      IN  VARCHAR2 DEFAULT '' ,--법인코드
    p_plantcode     IN  VARCHAR2 DEFAULT '' ,
    p_sym           IN  VARCHAR2 DEFAULT '' ,--조회년월
    p_sdt           IN  VARCHAR2 DEFAULT '' ,
    p_edt           IN  VARCHAR2 DEFAULT '' ,
    p_loadstatus    IN  VARCHAR2 DEFAULT '' ,
    p_paybonusdiv   IN  VARCHAR2 DEFAULT '' ,
    p_accdate       IN  VARCHAR2 DEFAULT '' ,--회계처리일자
    p_iempcode      IN  VARCHAR2 DEFAULT '' ,

    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    v_temp              NUMBER := 0;
BEGIN
    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values(p_userid, p_reasondiv, p_reasontext);

    for rec in (
        select  count(*) as closecnt
        from    DUAL
        where   exists( select  *
                        from    CMCLOSEM
                        where   compcode = p_compcode
                                and closeym = p_sym
                                and accdiv = 'H'
                                and apprcloseyn = 'Y'))
    loop
        v_temp := rec.closecnt;
    end loop;

    if v_temp = 1 then
        if (IO_CURSOR is null) then
            open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
        end if;

        return;
    end if;

    execute immediate 'delete from VGT.TT_ACACC0900HP4_DUAL';
    insert into VGT.TT_ACACC0900HP4_DUAL
    select  p_compcode,             -- 회사
            a.plantcode,            -- 사업장
            'N',                    -- 선택
            a.yearmonth,            -- 지급년월
            p_accdate,              -- 전표일자
            a.paydate,              -- 급여지급일자
            a.paybonusdiv,          -- 급상여구분
            nvl(c.divname, ''),     -- 급상여구분명(ps53)
            to_char(a.chasoo),      -- 차수
            a.deptcode,             -- 부서코드
            nvl(b.deptname, ''),    -- 부서명
            a.empcode,              -- 사원코드
            a.empname,              -- 사원명
            a.baseamt,              -- 기본급
            a.suamt,                -- 수당
            a.totbaseamt,           -- 총급여액
            a.totpay1,              -- 정기급여
            a.totpay2,              -- 정기상여
            a.totpay3,              -- 인센티브
            a.totpay,               -- 총지급액
            a.incometax,            -- 소득세
            a.resitax,              -- 주민세
            a.pensamt,              -- 국민연금
            a.insuamt,              -- 건강보험
            a.hireamt,              -- 고용보험
            a.etcgoamt,             -- 기타공제
            a.goamt,                -- 공제총액
            a.payamt,               -- 공제지급액
            a.goamt10,              -- 소득세
            a.goamt11,              -- 연말정산소득세
            a.goamt20,              -- 주민세
            a.goamt21,              -- 연말정산주민세
            a.goamt30,              -- 국민연금
            a.goamt31,              -- 국민연금소급
            a.goamt40,              -- 건강보험
            a.goamt41,              -- 건강보험소급
            a.goamt50,              -- 고용보험
            a.goamt60,              -- 사우회비
            a.goamt61,              -- 사우회비상환
            a.goamt70,              -- 기타(PDA)
            a.goamt80,              -- 보증보험
            a.goamt90,              -- 학자금상환액
            substr(a.yearmonth, -2, 2) || '월 ' || nvl(b.deptname, ''),
            '1',                    -- 자료상태(1신규 2완료 3수정 4삭제)
            acatrulecode,           -- 분계룰코드
            '신규로드전송전',         -- 자료상태명
            '',                     -- 전표번호
            'N'                     -- 변경여부
    from (
        select  a.yearmonth,                            -- 지급년월
                a.paydate,                              -- 지급일자
                a.paybonusdiv,                          -- 급상여구분(PS53)
                a.chasoo,                               -- 차수
                a.deptcode,                             -- 부서코드
                a.empcode,                              -- 사원코드
                max(d.empname) as empname,              -- 사원명
                max(a.plantcode) as plantcode,          -- 사업장
                sum(nvl(b.baseamt, 0)) as baseamt,      -- 기본급
                sum(nvl(b.suamt, 0)) as suamt,          -- 수당금액
                sum(nvl(b.salaryamt, 0)) as totbaseamt, -- 급여합
                sum(nvl(b.salaryamt, 0)) as totpay1,    -- 정기급여
                sum(nvl(b.bonusamt, 0)) as totpay2,     -- 정기상여
                sum(nvl(b.insentiveamt, 0)) as totpay3, -- 인센티브
                sum(nvl(b.totpay, 0)) as totpay,        -- 총지급액
                sum(nvl(b.goamt800, 0)) + sum(nvl(b.goamt801, 0)) as incometax, -- 소득세
                sum(nvl(b.goamt805, 0)) + sum(nvl(b.goamt806, 0)) as resitax,   -- 주민세
                sum(nvl(b.goamt010, 0)) + sum(nvl(b.goamt011, 0)) as pensamt,   -- 국민연금
                sum(nvl(b.goamt015, 0)) + sum(nvl(b.goamt016, 0)) as insuamt,   -- 건강보험
                sum(nvl(b.goamt020, 0)) as hireamt,                             -- 고용보험
                sum(nvl(b.goamt055 + b.goamt056 + b.goamt700 + b.goamt815 + b.goamt900, 0)) as etcgoamt,  -- 기타공제
                sum(nvl(b.goamt, 0)) as goamt,                                  -- 공제총액
                sum(nvl(b.totpay, 0))  - sum(nvl(b.goamt, 0)) as payamt,        -- 공제지급액
                max(nvl(g.filter1,'정의오류')) as acatrulecode,                  -- 분계룰코드
                sum(nvl(b.goamt800, 0)) as goamt10,               -- 소득세
                sum(nvl(b.goamt801, 0)) as goamt11,               -- 연말정산소득세
                sum(nvl(b.goamt805, 0)) as goamt20,               -- 주민세
                sum(nvl(b.goamt806, 0)) as goamt21,               -- 연말정산주민세
                sum(nvl(b.goamt010, 0)) as goamt30,               -- 국민연금
                sum(nvl(b.goamt011, 0)) as goamt31,               -- 국민연금소급
                sum(nvl(b.goamt015, 0)) as goamt40,               -- 건강보험
                sum(nvl(b.goamt016, 0)) as goamt41,               -- 건강보험소급
                sum(nvl(b.goamt020, 0)) as goamt50,               -- 고용보험
                sum(nvl(b.goamt055, 0)) as goamt60,               -- 사우회비
                sum(nvl(b.goamt056, 0)) as goamt61,               -- 사우회비상환
                sum(nvl(b.goamt700, 0)) as goamt70,               -- 기타(PDA)
                sum(nvl(b.goamt815, 0)) as goamt80,               -- 보증보험
                sum(nvl(b.goamt900, 0)) as goamt90                -- 학자금상환액
        from    PSPAYM a
                left join (
                    select  a.plantcode,
                            a.yearmonth,
                            a.empcode,
                            a.paybonusdiv,
                            a.chasoo,
                            sum(case when a.sugodiv = 'su' and a.sugocode = '001' then a.amt else 0 end) as baseamt,                        -- 기본급
                            sum(case when a.sugodiv = 'su' and a.sugocode not in ('001','300','305','700') then a.amt else 0 end) as suamt, -- 수당
                            sum(case when a.sugodiv = 'su' and a.sugocode not in ('300','305','700') then a.amt else 0 end) as salaryamt,   -- 급여
                            sum(case when a.sugodiv = 'su' and a.sugocode in ('700') then a.amt else 0 end) as bonusamt,                    -- 상여
                            sum(case when a.sugodiv = 'su' and a.sugocode in ('300','305') then a.amt else 0 end) as insentiveamt,          -- 인센티브
                            sum(case when a.sugodiv = 'su' then a.amt else 0 end) as totpay,                                                -- 총지급액
                            sum(case when a.sugodiv = 'go' and a.sugocode = '800' then a.amt else 0 end) as goamt800,                       -- 소득세
                            sum(case when a.sugodiv = 'go' and a.sugocode in ('801','802') then a.amt else 0 end) as goamt801,              -- 연말정산소득세
                            sum(case when a.sugodiv = 'go' and a.sugocode = '805' then a.amt else 0 end) as goamt805,                       -- 주민세
                            sum(case when a.sugodiv = 'go' and a.sugocode in ('806','807') then a.amt else 0 end) as goamt806,              -- 연말정산주민세
                            sum(case when a.sugodiv = 'go' and a.sugocode = '010' then a.amt else 0 end) as goamt010,                       -- 국민연금
                            sum(case when a.sugodiv = 'go' and a.sugocode = '01x' then a.amt else 0 end) as goamt011,                       -- 국민연금소급
                            sum(case when a.sugodiv = 'go' and a.sugocode = '015' then a.amt else 0 end) as goamt015,                       -- 건강보험
                            sum(case when a.sugodiv = 'go' and a.sugocode = '016' then a.amt else 0 end) as goamt016,                       -- 건강보험소급
                            sum(case when a.sugodiv = 'go' and a.sugocode = '020' then a.amt else 0 end) as goamt020,                       -- 고용보험
                            sum(case when a.sugodiv = 'go' and a.sugocode = '055' then a.amt else 0 end) as goamt055,                       -- 사우회비
                            sum(case when a.sugodiv = 'go' and a.sugocode = '056' then a.amt else 0 end) as goamt056,                       -- 사우회비상환
                            sum(case when a.sugodiv = 'go' and a.sugocode = '700' then a.amt else 0 end) as goamt700,                       -- 기타
                            sum(case when a.sugodiv = 'go' and a.sugocode = '815' then a.amt else 0 end) as goamt815,                       -- 보증보험
                            sum(case when a.sugodiv = 'go' and a.sugocode = '900' then a.amt else 0 end) as goamt900,                       -- 학자금상환액
                            sum(case when a.sugodiv = 'go' then a.amt else 0 end) as goamt                                                  -- 공제총액
                    from    PSPAYD a
                            join PSSUGOITEMM b
                                on a.sugodiv = b.sugodiv
                                and a.sugocode = b.sugocode
                    where   a.plantcode like p_plantcode || '%'
                            and a.yearmonth = p_sym
                    group by a.plantcode, a.yearmonth, a.empcode, a.paybonusdiv, a.chasoo
                ) b on a.plantcode = b.plantcode
                    and a.yearmonth = b.yearmonth
                    and a.empcode = b.empcode
                    and a.paybonusdiv = b.paybonusdiv
                    and a.chasoo = b.chasoo
                left join CMDEPTM c
                    on a.deptcode = c.deptcode
                left join CMEMPM d
                    on a.empcode = d.empcode
                left join CMCOMMONM e
                    on e.cmmcode = 'PS41'
                    and e.divcode = d.empdiv --사원구분 정보
                left join CMCOMMONM f
                    on f.cmmcode = 'PS29'
                    and f.divcode = d.positiondiv --직위분류 정보
                left join CMCOMMONM g
                    on g.cmmcode = 'AC92'
                    and g.divcode = d.accpaydiv --직위분류 정보
        where   a.plantcode like p_plantcode || '%'
                and a.yearmonth = p_sym
                and a.paydate between p_sdt and p_edt
        group by a.yearmonth, a.paydate, a.paybonusdiv, a.chasoo, a.deptcode, a.empcode
    ) a
            left join CMDEPTM b
                on a.deptcode = b.deptcode
            left join CMCOMMONM c
                on c.cmmcode = 'PS53'
                and a.paybonusdiv = c.divcode;
    -- 기본 급여내역 템프테이블 저장 완료

    -- 전송완료상태 데이터 확인
    merge into VGT.TT_ACACC0900HP4_DUAL a
    using (
        select  case when b.actrnstate = '1' or nvl(b.slipinno, '') is null then '로드완료전표처리전'
                     when nvl(trim(b.slipinno), '') is not null and b.slipinno = c.slipinno then '회계처리완료'
                     when nvl(trim(b.slipinno), '') is not null and nvl(c.slipinno, '') is null then '신규:회계전표삭제재전송'
                     else '회계처리완료'
                     end as acctrnchk,
                case when b.actrnstate = '1' or nvl(b.slipinno, '') is null then '3'
                     when nvl(trim(b.slipinno), '') is not null and b.slipinno = c.slipinno then '2'
                     when nvl(trim(b.slipinno), '') is not null and nvl(c.slipinno, '') is null  then '3'
                     else '2'
                     end as actrnstate,
                nvl(b.slipinno, '') as slipinno,
                b.slipindate,
                case when nvl(trim(b.slipinno), '') is not null and nvl(trim(c.slipinno), '') is null then 'Y'
                     else 'N'
                     end as newchk,
                b.compcode,
                b.acattype,
                b.acatno
        from    ACAUTOORDT b -- 기존자료
                left join ACORDM c
                    on b.compcode = c.compcode -- 회계전표
                    and b.slipinno = c.slipinno
    ) b on (a.compcode = b.compcode
            and b.acattype = 'H'
            and a.yearmonth || a.deptcode || a.empcode || a.paybonusdiv || a.chasoo = b.acatno)
    when matched then
        update set  a.acctrnchk = b.acctrnchk,
                    a.actrnstate = b.actrnstate,
                    a.slipinno = b.slipinno,
                    a.accdate = case when a.accdate <> b.slipindate then b.slipindate else a.accdate end,
                    a.newchk = b.newchk;

    -- 수정 데이터 확인
    for rec in (
        select  a.yearmonth,
                a.deptcode,
                a.empcode,
                a.paybonusdiv,
                a.chasoo,
                case when b.slipinno is not null and c.slipinno is null then '수정:회계전표삭제재전송' else '수정전송필요' end as acctrnchk,
                b.slipinno as slipinno
        from    VGT.TT_ACACC0900HP4_DUAL a
                join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and b.acattype = 'H'
                    and a.yearmonth || a.deptcode || a.empcode || a.paybonusdiv || a.chasoo = b.acatno
                left join ACORDM c
                    on b.compcode = c.compcode -- 회계전표
                    and b.slipinno = c.slipinno
        where   nvl(a.plantcode,' ') <> nvl(b.plantcode,' ')
                or nvl(a.accdate,' ') <> nvl(b.slipindate,' ')
                or nvl(a.acatrulecode,' ') <> nvl(b.acatrulecode,' ')
                or nvl(a.deptcode,' ') <> nvl(b.deptcode,' ')
                or nvl(a.empcode,' ') <> nvl(b.empcode,' ')
                or nvl(a.remark,' ') <> nvl(b.remark,' ')
                or nvl(a.totpay1,0) <> nvl(b.trn1amt,0)     -- 정기급여
                or nvl(a.totpay2,0) <> nvl(b.trn2amt,0)     -- 정기상여
                or nvl(a.totpay3,0) <> nvl(b.trn3amt,0)     -- 인센티브
                or nvl(a.goamt1,0) <> nvl(b.trn4amt,0)      -- 소득세
                or nvl(a.goamt2,0) <> nvl(b.trn5amt,0)      -- 연말정산소득세
                or nvl(a.goamt3,0) <> nvl(b.trn6amt,0)      -- 주민세
                or nvl(a.goamt4,0) <> nvl(b.trn7amt,0)      -- 연말정산주민세
                or nvl(a.goamt5,0) <> nvl(b.trn8amt,0)      -- 국민연금
                or nvl(a.goamt6,0) <> nvl(b.trn9amt,0)      -- 국민연금소급
                or nvl(a.goamt7,0) <> nvl(b.trn10amt,0)     -- 건강보험
                or nvl(a.goamt8,0) <> nvl(b.trn11amt,0)     -- 건강보험소급
                or nvl(a.goamt9,0) <> nvl(b.trn12amt,0)     -- 고용보험
                or nvl(a.goamt10,0) <> nvl(b.trn13amt,0)    -- 사우회비
                or nvl(a.goamt11,0) <> nvl(b.trn14amt,0)    -- 사우회비상환
                or nvl(a.goamt12,0) <> nvl(b.trn15amt,0)    -- 기타(PDA)
                or nvl(a.goamt13,0) <> nvl(b.trn16amt,0)    -- 보증보험
                or nvl(a.goamt14,0) <> nvl(b.trn17amt,0))   -- 학자금상환액
    loop
        update  VGT.TT_ACACC0900HP4_DUAL a
        set     actrnstate = '3',
                colchk = 'N',
                acctrnchk = rec.acctrnchk,
                slipinno = rec.slipinno
        where   a.yearmonth = rec.yearmonth
                and a.deptcode = rec.deptcode
                and a.empcode = rec.empcode
                and a.paybonusdiv = rec.paybonusdiv
                and a.chasoo = rec.chasoo;
    end loop;

    -- 삭제 상태 확인
    insert into VGT.TT_ACACC0900HP4_DUAL
    select  a.compcode,               -- 회사
            a.plantcode,              -- 사업장
            'N',                      -- 선택
            substr(a.acatno, 0, 7),   -- 지급년월
            nvl(a.slipindate, ''),    -- 전표일자
            '삭제',                    -- 급여지급일자
            a.userdef21code,          -- 급상여구분
            c.divname,                -- 급상여구분명(ps53)
            a.userdef22code,          -- 급여차수
            a.deptcode,               -- 부서코드
            a.userdef4code,           -- 부서명
            a.empcode,                -- 사원코드
            a.userdef5code,           -- 사원명
            0,                        -- 기본급
            0,                        -- 수당
            a.trn1amt,                -- 총급여액
            a.trn1amt,                -- 정기급여
            a.trn2amt,                -- 정기상여
            a.trn3amt,                -- 인센티브
            a.trn21amt,               -- 총지급액
            a.trn4amt + a.trn5amt,    -- 소득세합
            a.trn6amt + a.trn7amt,    -- 주민세합
            a.trn8amt + a.trn8amt,    -- 국민연금
            a.trn10amt + a.trn11amt,  -- 건강보험
            a.trn12amt,               -- 고용보험
            a.trn13amt + a.trn14amt + a.trn15amt + a.trn16amt + a.trn17amt, -- 기타공제
            a.trn22amt,               -- 공제총액
            a.trn23amt,               -- 공제지급액
            a.trn4amt,                -- 소득세
            a.trn5amt,                -- 연말정산소득세
            a.trn6amt,                -- 주민세
            a.trn7amt,                -- 연말정산주민세
            a.trn8amt,                -- 국민연금
            a.trn9amt,                -- 국민연금소급
            a.trn10amt,               -- 건강보험
            a.trn11amt,               -- 건강보험소급
            a.trn12amt,               -- 고용보험
            a.trn13amt,               -- 사우회비
            a.trn14amt,               -- 사우회비상환
            a.trn15amt,               -- 기타(PDA)
            a.trn16amt,               -- 보증보험
            a.trn17amt,               -- 학자금상환액
            a.remark,-- 적요 (#월 + 급여 + (인원명) + 지급 +[수정,재전송]
            '4',-- 자료상태(1신규, 2완료 3수정, 4삭제)
            a.acatrulecode,-- 분계룰코드
            '삭제전송필요',-- 자료상태명
            a.slipinno,-- 전표번호
            'N' -- 변경여부
    from    ACAUTOORDT a
            left join VGT.TT_ACACC0900HP4_DUAL b
                on a.compcode = b.compcode
                and a.acatno = b.yearmonth || b.deptcode || b.empcode || b.paybonusdiv || b.chasoo
            left join CMCOMMONM c
                on c.cmmcode = 'PS53'
                and a.userdef21code = c.divcode
    where   a.compcode = p_compcode
            and a.acattype = 'H'
            and a.acatno like p_sym || '%'
            and a.issdate between p_sdt and p_edt
            and b.accdate is null;

    if (p_loadstatus = '1' or p_loadstatus = '2' or p_loadstatus = '3') then
        --로드 상태를 선택
        delete
        from    VGT.TT_ACACC0900HP4_DUAL a
        where   a.actrnstate not in ((select  filter1
                                      from    CMCOMMONM
                                      where   cmmcode = 'AC082'
                                              and divcode = p_loadstatus),
                                     (select  filter2
                                      from    CMCOMMONM
                                      where   cmmcode = 'AC082'
                                              and divcode = p_loadstatus));
    end if;

    if ( p_paybonusdiv <> '%') then
        delete
        from    VGT.TT_ACACC0900HP4_DUAL
        where   paybonusdiv <> p_paybonusdiv;
    end if;

    if ( p_div = 'S') then
        open IO_CURSOR for
        select  a.compcode,
                a.plantcode,
                a.colchk,
                a.yearmonth,
                a.accdate,
                a.paydate,
                a.paybonusdiv,
                a.paytypename,
                a.chasoo,
                a.deptcode,
                a.deptname,
                count(*) as cntemp,
                sum(a.baseamt) as baseamt,
                sum(a.suamt) as suamt,
                sum(a.totbaseamt) as totbaseamt,
                sum(a.totpay1) as totpay1,
                sum(a.totpay2) as totpay2,
                sum(a.totpay3) as totpay3,
                sum(a.totpay) as totpay,
                sum(a.incometax) as incometax,
                sum(a.resitax) as resitax,
                sum(a.pensamt) as pensamt,
                sum(a.insuamt) as insuamt,
                sum(a.hireamt) as hireamt,
                sum(a.etcgoamt) as etcgoamt,
                sum(a.goamt) as goamt,
                sum(a.payamt) as payamt,
                sum(a.goamt1) as goamt1,
                sum(a.goamt2) as goamt2,
                sum(a.goamt3) as goamt3,
                sum(a.goamt4) as goamt4,
                sum(a.goamt5) as goamt5,
                sum(a.goamt6) as goamt6,
                sum(a.goamt7) as goamt7,
                sum(a.goamt8) as goamt8,
                sum(a.goamt9) as goamt9,
                sum(a.goamt10) as goamt10,
                sum(a.goamt11) as goamt11,
                sum(a.goamt12) as goamt12,
                sum(a.goamt13) as goamt13,
                sum(a.goamt14) as goamt14,
                max(a.remark) as remark,
                case when min(a.actrnstate) = max(a.actrnstate) then min(a.actrnstate) else '3' end as actrnstate,
                case when min(a.actrnstate) = max(a.actrnstate) then min(a.acctrnchk) else '수정전송필요' end as acctrnchk,
                max(a.slipinno) as slipinno,
                max(a.newchk) as newchk,
                a.acatrulecode,
                max(b.plantname) as plantname,
                sum(a.goamt10) as gorest,
                sum(a.totpay1 + a.totpay2 + a.totpay3 - a.goamt1 - a.goamt2 - a.goamt3 - a.goamt4 - a.goamt5 - a.goamt6 - a.goamt7 - a.goamt8 - a.goamt9 - a.goamt10 - a.goamt11 - a.goamt12 - a.goamt13 - a.goamt14 - a.totpay + a.goamt) as chkamt

        from    VGT.TT_ACACC0900HP4_DUAL a
                left join CMPLANTM b
                    on a.plantcode = b.plantcode

        group by a.compcode, a.plantcode, a.colchk, a.yearmonth, a.accdate, a.paydate, a.paybonusdiv, a.paytypename, a.chasoo, a.deptcode, a.deptname, a.acatrulecode

        order by a.plantcode, a.accdate, a.paydate, a.deptcode;

    elsif ( p_div = 'load') then --일반 로드
        -- 기간동안의 모든 전표를 생성한다.
        insert into ACAUTOORDT
            (
                compcode        --회사코드
                ,acattype       --전표유형(h)
                ,acatno         --급상여년월+부서+급상여구분+계정구분+차수
                ,acatrulecode   --분개률코드
                ,actrnstate     --실행상태
                ,slipindate     --전표일자
                ,deptcode       --부서
                ,plantcode      --사업장
                ,empcode        --사원
                ,remark         --비고
                ,issdate        --지급일
                ,trn1amt        --정기급여
                ,trn2amt        --정기상여
                ,trn3amt        --인센티브
                ,trn4amt        --소득세
                ,trn5amt        --연말정산소득세
                ,trn6amt        --주민세
                ,trn7amt        --연말정산주민세
                ,trn8amt        --국민연금
                ,trn9amt        --국민연금소급
                ,trn10amt       --건강보험
                ,trn11amt       --건강보험소급
                ,trn12amt       --고용보험
                ,trn13amt       --사우회비
                ,trn14amt       --사우회비상환
                ,trn15amt       --기타(PDA)
                ,trn16amt       --보증보험
                ,trn17amt       --학자금상환액
                ,trn21amt       --총지급액
                ,trn22amt       --공제총액
                ,trn23amt       --공제지급액
                ,userdef3code   --사업장명
                ,userdef4code   --부서명
                ,userdef5code   --발의사원명
                ,userdef21code  --급상여구분
                ,userdef22code  --차수
                ,insertdt       --입력일자
                ,iempcode       --입력사원
            )
        select  a.compcode,
                'H',
                a.yearmonth || a.deptcode || a.empcode || a.paybonusdiv || a.chasoo,
                a.acatrulecode,
                a.actrnstate,
                a.accdate,
                a.deptcode,
                a.plantcode,
                a.empcode,
                a.remark,
                a.paydate,
                a.totpay1,
                a.totpay2,
                a.totpay3,
                a.goamt1,
                a.goamt2,
                a.goamt3,
                a.goamt4,
                a.goamt5,
                a.goamt6,
                a.goamt7,
                a.goamt8,
                a.goamt9,
                a.goamt10,
                a.goamt11,
                a.goamt12,
                a.goamt13,
                a.goamt14,
                a.totpay,
                a.goamt,
                a.payamt,
                b.plantname,
                a.deptname,
                a.empname,
                a.paybonusdiv,
                a.chasoo,
                sysdate,
                p_iempcode
        from    VGT.TT_ACACC0900HP4_DUAL a
                left join CMPLANTM b
                    on a.plantcode = b.plantcode
        where   a.actrnstate = '1'
                and a.acatrulecode <> '정의오류';

        -- 수정,삭제 처리전에 메타에 있는 내용을 이력테이블에 저장한다.
        insert into ACAUTOORDH
        select  b.*
        from    VGT.TT_ACACC0900HP4_DUAL a
                left join ACAUTOORDT b
                    on a.compcode = b.compcode
                    and b.acattype = 'H'
                    and a.yearmonth || a.deptcode || a.empcode || a.paybonusdiv || a.chasoo = b.acatno
        where   a.actrnstate in ('3','4')
                or a.newchk = 'Y';

        for rec in (
            select  a.acatrulecode    --분개률코드
                    ,case when b.actrnstate = '1' then b.actrnstate else a.actrnstate end actrnstate   --실행상태
                    ,a.accdate        --전표일자
                    ,a.deptcode       --부서코드
                    ,a.plantcode      --사업장
                    ,a.empcode        --사원코드
                    ,a.remark         --비고
                    ,a.paydate        --지급일
                    ,a.totpay1        --정기급여
                    ,a.totpay2        --정기상여
                    ,a.totpay3        --인센티브
                    ,a.goamt1         --소득세
                    ,a.goamt2         --연말정산소득세
                    ,a.goamt3         --주민세
                    ,a.goamt4         --연말정산주민세
                    ,a.goamt5         --국민연금
                    ,a.goamt6         --국민연금소급
                    ,a.goamt7         --건강보험
                    ,a.goamt8         --건강보험소급
                    ,a.goamt9         --고용보험
                    ,a.goamt10        --사우회비
                    ,a.goamt11        --사우회비상환
                    ,a.goamt12        --기타(PDA)
                    ,a.goamt13        --보증보험
                    ,a.goamt14        --학자금상환액
                    ,a.totpay         --총지급액
                    ,a.goamt          --공제총액
                    ,a.payamt         --공제지급액
                    ,c.plantname      --사업장명
                    ,a.deptname       --부서명
                    ,a.empname        --사원명
                    ,a.paybonusdiv    --급상여구분
                    ,a.chasoo         --차수
                    ,b.compcode
                    ,b.acattype
                    ,b.acatno
            from    VGT.TT_ACACC0900HP4_DUAL a
                    join ACAUTOORDT b
                        on a.compcode = b.compcode
                        and b.acattype = 'H'
                        and a.yearmonth || a.deptcode || a.empcode || a.paybonusdiv || a.chasoo = b.acatno
                    join CMPLANTM c
                        on a.plantcode = c.plantcode
            where   a.actrnstate in ('3', '4'))
        loop
            update  ACAUTOORDT
            set     acatrulecode = rec.acatrulecode   --분개률코드
                    ,actrnstate = rec.actrnstate      --실행상태
                    ,slipindate = rec.accdate         --전표일자
                    ,deptcode = rec.deptcode          --부서코드
                    ,plantcode = rec.plantcode        --사업장
                    ,empcode = rec.empcode            --사원코드
                    ,remark = rec.remark              --비고
                    ,issdate = rec.paydate            --지급일
                    ,trn1amt = rec.totpay1            --정기급여
                    ,trn2amt = rec.totpay2            --정기상여
                    ,trn3amt = rec.totpay3            --인센티브
                    ,trn4amt = rec.goamt1             --소득세
                    ,trn5amt = rec.goamt2             --연말정산소득세
                    ,trn6amt = rec.goamt3             --주민세
                    ,trn7amt = rec.goamt4             --연말정산주민세
                    ,trn8amt = rec.goamt5             --국민연금
                    ,trn9amt = rec.goamt6             --국민연금소급
                    ,trn10amt = rec.goamt7            --건강보험
                    ,trn11amt = rec.goamt8            --건강보험소급
                    ,trn12amt = rec.goamt9            --고용보험
                    ,trn13amt = rec.goamt10           --사우회비
                    ,trn14amt = rec.goamt11           --사우회비상환
                    ,trn15amt = rec.goamt12           --기타(PDA)
                    ,trn16amt = rec.goamt13           --보증보험
                    ,trn17amt = rec.goamt14           --학자금상환액
                    ,trn21amt = rec.totpay            --총지급액
                    ,trn22amt = rec.goamt             --공제총액
                    ,trn23amt = rec.payamt            --공제지급액
                    ,userdef3code = rec.plantname     --사업장명
                    ,userdef4code = rec.deptname      --부서명
                    ,userdef5code = rec.empname       --사원명
                    ,userdef21code = rec.paybonusdiv  --급상여구분
                    ,userdef22code = rec.chasoo       --차수
                    ,updatedt = sysdate               --수정일자
                    ,uempcode = p_iempcode            --수정사원
            where   compcode = rec.compcode
                    and acattype = rec.acattype
                    and acatno = rec.acatno;
        end loop;

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;
END;
/
