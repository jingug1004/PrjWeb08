CREATE PROCEDURE        spACacc0117R
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACacc0117R
   -- 작 성 자         : 최용석
   -- 작성일자         : 2013-01-03
   -- 수정자          : 임정호
   -- 수정일자         : 2016-12-20
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 보조부원장을 조회하는 프로시저이다.
   -- ---------------------------------------------------------------
(

   p_div          IN     VARCHAR2 DEFAULT '',
   p_compcode     IN     VARCHAR2 DEFAULT '',
   p_plantcode    IN     VARCHAR2 DEFAULT '',
   p_strdate      IN     VARCHAR2 DEFAULT '',
   p_enddate      IN     VARCHAR2 DEFAULT '',
   p_stracccode   IN     VARCHAR2 DEFAULT '',
   p_endacccode   IN     VARCHAR2 DEFAULT '',
   p_outputdiv    IN     VARCHAR2 DEFAULT '',
   p_downview     IN     VARCHAR2 DEFAULT '',
   p_userid       IN     VARCHAR2 DEFAULT '',
   p_reasondiv    IN     VARCHAR2 DEFAULT '',
   p_reasontext   IN     VARCHAR2 DEFAULT '',
   IO_CURSOR         OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2
)
AS
    p_colview       VARCHAR2 (1);
    -- 현금계정
    p_acccashcode   VARCHAR2 (20);
    p_odiv1         VARCHAR2 (5);
    p_odiv2         VARCHAR2 (5);

    ip_stracccode   VARCHAR2 (100);
    ip_endacccode   VARCHAR2 (100);
BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);



    IF TRIM(p_stracccode) IS NULL THEN
        ip_stracccode :='';
    ELSE 
        ip_stracccode :=p_stracccode;
    END IF;

    IF TRIM(p_endacccode) IS NULL THEN
        ip_endacccode :='';
    ELSE
        ip_endacccode :=p_endacccode;
    END IF;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO (USERID, REASONDIV, REASONTEXT)
                VALUES (p_userid, p_reasondiv, p_reasontext);

    p_colview := '_';

    FOR rec IN
    (
        SELECT value1
        FROM SYSPARAMETERMANAGE
        WHERE parametercode = 'accldgcolview'
    )
    LOOP
        p_colview := rec.value1;
    END LOOP;

	IF(p_colview = '_') THEN
    	p_colview := '0';
    END IF;

    IF (TRIM(p_div) = 'S') THEN

        FOR rec IN
        (
            SELECT value1
            FROM SYSPARAMETERMANAGE
            WHERE parametercode = 'acccashcode' AND usediv = 'Y'
        )
        LOOP
            p_acccashcode := rec.value1;
        END LOOP;

        IF (p_outputdiv = '1') THEN
            --K-GAAP
            p_odiv1 := '20';
            p_odiv2 := 'F';
         END IF;

        IF (p_outputdiv = '2') THEN
            --IFRS
            p_odiv1 := '30';
            p_odiv2 := 'K';
        END IF;


        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0117R_ACORDD';

        INSERT INTO VGT.TT_ACACC0117R_ACORDD
        (  SELECT NVL (b.grp, 0) grp,
                  CASE
                     WHEN b.grp = 1 THEN
                           A.acccode || A.slipdate || REPLACE (A.slipno, 'C', p_colview) || LPAD (A.slipinseq, 5, '0')
                     WHEN b.grp = 2 THEN
                        A.acccode || SUBSTR (A.slipdate, 1, 7) || '98'
                     WHEN b.grp = 3 THEN
                        A.acccode || SUBSTR (A.slipdate, 1, 7) || '99'
                     ELSE
                        A.acccode
                  END ord,
                  MAX (CASE WHEN b.grp = 1 THEN A.slipinno END) slipinno,
                  MAX (CASE WHEN b.grp = 1 THEN A.slipinseq END) slipinseq,
                  MAX (CASE WHEN b.grp = 1 THEN A.slipindate END) slipindate,
                  MAX (CASE WHEN b.grp = 1 THEN A.slipinnum END) slipinnum,
                  MAX (CASE WHEN b.grp = 1 THEN A.slipno END) slipno,
                  MAX (CASE WHEN b.grp = 1 THEN A.slipdate ELSE SUBSTR (A.slipdate, 0, 7) END) slipdate,
                  MAX (CASE WHEN b.grp = 1 THEN A.slipnum WHEN b.grp = 2 THEN '월계' WHEN b.grp = 3 THEN '누계' ELSE '이월' END) slipnum,
                  A.acccode,
                  MAX (c.accname) accname,
                  MAX (CASE WHEN b.grp = 1 THEN A.remark END) remark,
                  SUM (A.debamt) debamt,
                  SUM (A.creamt) creamt,
                  SUM (CASE WHEN c.dcdiv = '1' THEN A.debamt - A.creamt ELSE A.creamt - A.debamt END) fnamt,
                  MAX (A.acccode || ' : ' || c.accname) acccodename
             FROM (SELECT NULL slipinno,
                          NULL slipinseq,
                          NULL slipindate,
                          NULL slipinnum,
                          NULL slipno,
                          SUBSTR (p_strdate, 1, 7) || '-00' slipdate,
                          NULL slipnum,
                          b.acccode,
                          NULL remark,
                          A.bsdebamt debamt,
                          A.bscreamt creamt
                     FROM ACORDDMM A
                          JOIN (
                                 SELECT A.acccode,
                                        A.accname,
                                        A.dcdiv,
                                        COALESCE (c.acccode, b.acccode, A.acccode) downcode
                                   FROM ACACCM A
                                        LEFT JOIN
                                        ACACCM b
                                           ON     (A.acccode = b.acccode OR A.acccode = b.hacccode)
                                              AND p_downview = 'Y'
                                        LEFT JOIN
                                        ACACCM c
                                           ON     A.acccode <> b.acccode
                                              AND b.acccode = c.hacccode
                                              AND p_downview = 'Y'
                                  WHERE A.acccode BETWEEN NVL(ip_stracccode,' ') AND NVL (trim(ip_endacccode), 'zzzzzzzz')
                               )  b ON A.acccode = b.downcode
                    WHERE     A.compcode = p_compcode
                          AND A.plantcode LIKE p_plantcode
                          AND A.slipym = SUBSTR (p_strdate, 1, 7)
                          AND (closediv = '10' OR closediv = p_odiv1)

                    UNION ALL
                    SELECT A.slipinno,
                          A.slipinseq,
                          b.slipindate,
                          b.slipinnum,
                          b.slipno,
                          CASE
                             WHEN A.slipdate < p_strdate
                             THEN
                                SUBSTR (p_strdate, 1, 7) || '-00'
                             ELSE
                                A.slipdate
                          END slipdate,
                          b.slipnum,
                          c.acccode,
                          A.remark1 remark,
                          A.debamt,
                          A.creamt
                     FROM ACORDD A
                          JOIN
                          ACORDM b
                             ON     A.compcode = b.compcode
                                AND A.slipinno = b.slipinno
                          JOIN (
                                  SELECT A.acccode,
                                        A.accname,
                                        A.dcdiv,
                                        COALESCE (c.acccode, b.acccode, A.acccode) downcode
                                   FROM ACACCM A
                                        LEFT JOIN
                                        ACACCM b
                                           ON     (A.acccode = b.acccode OR A.acccode = b.hacccode)
                                              AND p_downview = 'Y'
                                        LEFT JOIN
                                        ACACCM c
                                           ON     A.acccode <> b.acccode
                                              AND b.acccode = c.hacccode
                                              AND p_downview = 'Y'
                                  WHERE A.acccode BETWEEN NVL(ip_stracccode,' ') AND NVL (trim(ip_endacccode), 'zzzzzzzz')
                               ) c ON A.acccode = c.downcode
                    WHERE     A.compcode = p_compcode
                          AND A.plantcode LIKE p_plantcode
                          AND A.slipdate BETWEEN    SUBSTR (p_strdate, 1, 7) || '-01' AND p_enddate
                          AND b.slipdiv <> p_odiv2
                   UNION ALL
                   SELECT A.slipinno,
                          A.slipinseq,
                          b.slipindate,
                          b.slipinnum,
                          b.slipno,
                          CASE
                             WHEN A.slipdate < p_strdate
                             THEN
                                SUBSTR (p_strdate, 1, 7) || '-00'
                             ELSE
                                A.slipdate
                          END slipdate,
                          b.slipnum,
                          c.acccode,
                          A.remark1 remark,
                          A.creamt,
                          A.debamt
                     FROM ACORDD A
                          JOIN
                          ACORDM b
                             ON     A.compcode = b.compcode
                                AND A.slipinno = b.slipinno
                          JOIN (
                                  SELECT A.acccode,
                                        A.accname,
                                        A.dcdiv,
                                        COALESCE (c.acccode, b.acccode, A.acccode) downcode
                                   FROM ACACCM A
                                        LEFT JOIN
                                        ACACCM b
                                           ON     (   A.acccode = b.acccode
                                                   OR A.acccode = b.hacccode)
                                              AND p_downview = 'Y'
                                        LEFT JOIN
                                        ACACCM c
                                           ON     A.acccode <> b.acccode
                                              AND b.acccode = c.hacccode
                                              AND p_downview = 'Y'
                                  WHERE A.acccode BETWEEN NVL(ip_stracccode,' ') AND NVL (trim(ip_endacccode), 'zzzzzzzz')
                               ) c ON c.acccode = p_acccashcode
                    WHERE     A.compcode = p_compcode
                          AND A.plantcode LIKE p_plantcode
                          AND A.slipdate BETWEEN    SUBSTR (p_strdate,0, 7) || '-01' AND p_enddate
                          AND A.dcdiv IN ('3', '4')
                          AND b.slipdiv <> p_odiv2) A
                  LEFT JOIN (SELECT 1 grp FROM DUAL
                             UNION
                             SELECT 2 FROM DUAL
                             UNION
                             SELECT 3 FROM DUAL) b
                     ON A.slipdate >= p_strdate
                  LEFT JOIN ACACCM c ON A.acccode = c.acccode

            GROUP BY    b.grp,
                        A.acccode,
                        CASE
                            WHEN b.grp = 1 THEN
                                A.acccode || A.slipdate || REPLACE (A.slipno, 'C', p_colview) || LPAD (A.slipinseq, 5, '0')
                            WHEN b.grp = 2 THEN
                                A.acccode || SUBSTR (A.slipdate, 1, 7) || '98'
                         WHEN b.grp = 3 THEN
                                A.acccode || SUBSTR (A.slipdate, 1, 7) || '99'
                         ELSE
                                A.acccode
                        END

        );

        MERGE INTO VGT.TT_ACACC0117R_ACORDD TG
              USING (
                        SELECT  A.ord,
                                A.acccode,
                                CASE WHEN c.dcdiv = '1' THEN b.debamt - b.creamt ELSE b.creamt - b.debamt END AS fnamt
                        FROM    VGT.TT_ACACC0117R_ACORDD A
                                JOIN
                                (
                                    SELECT  A.ord,
                                            SUM (b.debamt) debamt,
                                            SUM (b.creamt) creamt
                                    FROM    VGT.TT_ACACC0117R_ACORDD A
                                            JOIN
                                            VGT.TT_ACACC0117R_ACORDD b
                                                ON     A.acccode = b.acccode
                                                    AND A.ord >= b.ord
                                                    AND b.grp IN (0, 1)
                                    WHERE A.grp = 1
                                    GROUP BY A.ord
                                ) b
                                ON  A.ord = b.ord
                            LEFT JOIN ACACCM c ON A.acccode = c.acccode
                    ) SRC
                 ON (tg.ord=src.ord AND TG.acccode = src.acccode)
         WHEN MATCHED THEN
            UPDATE SET TG.fnamt = src.fnamt;

        MERGE INTO VGT.TT_ACACC0117R_ACORDD TG
              USING (
                        SELECT  A.ord,
                                NVL (b.debamt, A.debamt) AS pos_2,
                                NVL (b.creamt, A.creamt) AS pos_3,
                                b.fnamt
                        FROM    VGT.TT_ACACC0117R_ACORDD  A
                                LEFT JOIN
                                (
                                    SELECT  A.ord,
                                            SUM (b.debamt) debamt,
                                            SUM (b.creamt) creamt,
                                            SUM (b.fnamt) fnamt
                                    FROM    VGT.TT_ACACC0117R_ACORDD  A
                                            JOIN
                                            VGT.TT_ACACC0117R_ACORDD  b
                                                ON      A.acccode = b.acccode
                                                    AND A.ord >= b.ord
                                                    AND b.grp IN (0, 2)
                                    WHERE A.grp = 3
                                    GROUP BY A.ord) b
                                    ON      A.ord = b.ord
                        WHERE   A.grp IN (2, 3)) src
                 ON (TG.ORD = src.ORD)
         WHEN MATCHED THEN
            UPDATE SET
               TG.debamt = SRC.pos_2,
               TG.creamt = SRC.pos_3,
               TG.fnamt  = src.fnamt;

        OPEN IO_CURSOR FOR
        SELECT   A.slipinno,
                 A.slipinseq,
                 A.slipindate,
                 A.slipinnum,
                 A.slipno,
                 A.slipdate,
                 A.slipnum,
                 A.acccode,
                 A.accname,
                 A.remark,
                 A.debamt,
                 A.creamt,
                 A.fnamt,
                 A.acccodename,
                 b.mngcludec1,
                 b.mngcludec2,
                 b.mngcludec3,
                 b.mngcludec4,
                 b.mngcludec5,
                 b.mngcludec6
        FROM     VGT.TT_ACACC0117R_ACORDD A
                 LEFT JOIN
                (
                    SELECT slipinno,
                           slipinseq,
                           MAX ( CASE WHEN seq = 1 THEN mngcludec ELSE '' END) mngcludec1,
                           MAX ( CASE WHEN seq = 2 THEN mngcludec ELSE '' END) mngcludec2,
                           MAX ( CASE WHEN seq = 3 THEN mngcludec ELSE '' END) mngcludec3,
                           MAX ( CASE WHEN seq = 4 THEN mngcludec ELSE '' END) mngcludec4,
                           MAX ( CASE WHEN seq = 5 THEN mngcludec ELSE '' END) mngcludec5,
                           MAX ( CASE WHEN seq = 6 THEN mngcludec ELSE '' END) mngcludec6
                      FROM  (
                                SELECT A.slipinno,
                                       A.slipinseq,
                                       ROW_NUMBER ()
                                       OVER (PARTITION BY A.slipinno, A.slipinseq ORDER BY b.seq) seq,
                                        '[' || NVL (c.mngcluname, '') || ']' || NVL (b.mngcluval, '') || ' : ' || NVL (b.mngcludec, '') || CASE WHEN D.custcode IS NULL THEN '' ELSE ' (' || D.businessno || ')' END mngcludec
                                  FROM VGT.TT_ACACC0117R_ACORDD A
                                       JOIN
                                       ACORDS b
                                          ON     b.compcode = p_compcode
                                             AND A.slipinno = b.slipinno
                                             AND A.slipinseq = b.slipinseq
                                       LEFT JOIN ACMNGM c
                                          ON b.mngclucode = c.mngclucode
                                       LEFT JOIN
                                       CMCUSTM D
                                          ON     b.mngclucode = 'S010'
                                             AND b.mngcluval = D.custcode
                            ) A
                    GROUP BY slipinno, slipinseq
                ) b
                 ON     A.slipinno = b.slipinno
                    AND A.slipinseq = b.slipinseq
        ORDER BY A.acccode, A.ord;

   END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
