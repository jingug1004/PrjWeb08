CREATE PROCEDURE        spACacc0900ZZ(
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0900ZZ
-- 작 성 자         : 이영재
-- 작성일자         : 2010-11-25
-- 수 정 자     : 노영래
-- E-Mail       : 0rae0926@gmail.com
-- 수정일자      : 2016-12-19
-- ---------------------------------------------------------------
-- 프로시저 설명    : 전표로드 공통함수 구성
-- 수정 : 2011-02-09 이영재 영업 매출전표로드 처리를 회계모듈로 변경 작업
--   매입 세금계산서와 회계로드 개별 기능을 실행한다.
-- ---------------------------------------------------------------
    p_div             IN  VARCHAR2 DEFAULT '',

    p_compcode        IN  VARCHAR2 DEFAULT '',
    p_plantcode       IN  VARCHAR2 DEFAULT '',
    p_plantname       IN  VARCHAR2 DEFAULT '',
    p_sdt             IN  VARCHAR2 DEFAULT '',
    p_edt             IN  VARCHAR2 DEFAULT '',
    p_taxno           IN  VARCHAR2 DEFAULT '',
    p_appdate         IN  VARCHAR2 DEFAULT '',
    p_slipindate      IN  VARCHAR2 DEFAULT '',
    p_slipinseq       IN  NUMBER DEFAULT 0,
    p_buydiv          IN  VARCHAR2 DEFAULT '',
    p_deptcode        IN  VARCHAR2 DEFAULT '',
    p_empcode         IN  VARCHAR2 DEFAULT '',
    p_taxamt1         IN  FLOAT DEFAULT 0,
    p_taxamt2         IN  FLOAT DEFAULT 0,
    p_taxamt3         IN  FLOAT DEFAULT 0,
    p_finishamt1      IN  FLOAT DEFAULT 0,
    p_finishamt2      IN  FLOAT DEFAULT 0,
    p_finishamt3      IN  FLOAT DEFAULT 0,
    p_finishamt4      IN  FLOAT DEFAULT 0,
    p_finishamt5      IN  FLOAT DEFAULT 0,
    p_finishamt6      IN  FLOAT DEFAULT 0,
    p_finishamt7      IN  FLOAT DEFAULT 0,
    p_finishamt8      IN  FLOAT DEFAULT 0,
    p_finishamt9      IN  FLOAT DEFAULT 0,
    p_finishamt10     IN  FLOAT DEFAULT 0,
    p_finishamt11     IN  FLOAT DEFAULT 0,
    p_finishamt12     IN  FLOAT DEFAULT 0,
    p_finishamt13     IN  FLOAT DEFAULT 0,
    p_finishamt14     IN  FLOAT DEFAULT 0,
    p_finishamt15     IN  FLOAT DEFAULT 0,
    p_finishamt16     IN  FLOAT DEFAULT 0,
    p_itemnm          IN  VARCHAR2 DEFAULT '', --매입 적요와 상품명(세금계산서)
    p_chk             IN  VARCHAR2 DEFAULT '',
    p_custcode        IN  VARCHAR2 DEFAULT '',
    p_custname        IN  VARCHAR2 DEFAULT '',
    p_businessno      IN  VARCHAR2 DEFAULT '',
    p_iempcode        IN  VARCHAR2 DEFAULT '',
    p_loadstatus      IN  VARCHAR2 DEFAULT '',
    p_actrnstate      IN  VARCHAR2 DEFAULT '',
    p_acatrulecode    IN  VARCHAR2 DEFAULT '',
    p_warehousingno   IN  VARCHAR2 DEFAULT '',
    p_lccode          IN  VARCHAR2 DEFAULT '',
    p_lcname          IN  VARCHAR2 DEFAULT '',

    p_userid          IN  VARCHAR2 DEFAULT '',
    p_reasondiv       IN  VARCHAR2 DEFAULT '',
    p_reasontext      IN  VARCHAR2 DEFAULT '',
    MESSAGE           OUT VARCHAR2,
    IO_CURSOR         OUT TYPES.DATASET
)
AS
    ip_compcode           VARCHAR2(3) := p_compcode;
    ip_taxno              VARCHAR2(40) := p_taxno;
    p_slipno              VARCHAR2(20);
    p_slipinno            VARCHAR2(20);
    p_chktaxno            VARCHAR2(20);
BEGIN
    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values(p_userid, p_reasondiv, p_reasontext);

    for rec in (
        select  compcode -- 법인코드 확인
        from    CMPLANTM
        where   plantcode like p_plantcode || '%'
                and rownum <= 1)
    loop
        ip_compcode := rec.compcode;
    end loop;

    if (p_div = 'taxdtl')
    then
        --영업 회계로드에서 세금계산서별 상세 매출 내역 확인
        open IO_CURSOR for
        select  z.taxno as taxno,
                a.orderdate as orderdate,
                a.orderno as orderno,
                a.orderseq as orderseq,
                a.saldiv as saldiv,
                nvl(SL10.divname, '') as saldivname,
                b.itemcode as itemcode,
                d.itemname as itemname,
                b.salqty as salqty,
                b.salprc as salprc,
                b.salamt * case when substr(a.saldiv, 0, 1) = 'A' then 1 else -1 end as salamt,
                case when nvl(d.itempart, '') not in ('02', '08') then b.salamt * case when substr(a.saldiv, 0, 1) = 'A' then 1 else -1 end else 0 end as amt1,
                case when nvl(d.itempart, '') in ('02', '08') then b.salamt * case when substr(a.saldiv, 0, 1) = 'A' then 1 else -1 end else 0 end as amt2,
                b.salvat * case when substr(a.saldiv, 0, 1) = 'A' then 1 else -1 end as salvat,
                b.totamt * case when substr(a.saldiv, 0, 1) = 'A' then 1 else -1 end as totamt
        from    SLTAXM z
                join SLORDM a
                    on z.taxno = a.taxdate
                join SLORDD b
                    on a.orderno = b.orderno
                join CMITEMM d
                    on b.itemcode = d.itemcode
                left join CMCOMMONM SL10
                    on SL10.cmmcode = 'SL10'
                    and SL10.divcode = a.saldiv
        where   z.plantcode like p_plantcode
                and z.taxdt between p_sdt and p_edt
                and nvl(z.deleteyn, ' ') <> 'Y'
                and nvl(z.taxno, ' ') = nvl(ip_taxno,' ');

    elsif (p_div = 'taxdtl2')
    then
        --영업 회계로드에서 세금계산서별 상세 매출 내역 확인
        open IO_CURSOR for
        select  a.taxdate as taxno,
                a.orderdate as orderdate,
                a.orderno as orderno,
                a.orderseq as orderseq,
                a.saldiv as saldiv,
                nvl(SL10.divname, '') as saldivname,
                b.itemcode as itemcode,
                d.itemname as itemname,
                b.salqty as salqty,
                b.salprc as salprc,
                case when substr(a.saldiv, 0, 1) = 'A' then b.salamt else (-1) * b.salamt end as salamt,
                case when nvl(d.itempart, ' ') not in ('02', '08') then case when substr(a.saldiv, 0, 1) = 'A' then b.salamt else (-1) * b.salamt end else 0 end as amt1,
                case when nvl(d.itempart, ' ') in ('02', '08') then case when substr(a.saldiv, 0, 1) = 'A' then b.salamt else (-1) * b.salamt end else 0 end as amt2,
                case when substr(a.saldiv, 0, 1) = 'A' then b.salvat else (-1) * b.salvat end as salvat,
                case when substr(a.saldiv, 0, 1) = 'A' then b.totamt else (-1) * b.totamt end as totamt
        from    SLORDM a
                join SLORDD b
                    on a.orderno = b.orderno
                join CMITEMM d
                    on b.itemcode = d.itemcode
                left join CMCOMMONM SL10
                    on SL10.cmmcode = 'SL10'
                    and SL10.divcode = a.saldiv
                left join CMCUSTM c
                    on c.custcode = a.custcode
        where   a.plantcode = p_plantcode
                and a.custcode = p_custcode
                and a.appdate between p_sdt and p_edt
                and nvl(a.statediv, ' ') = '09'
                and (p_buydiv = '91' -- 역발행
                     and a.saldiv not in ('A09', 'A21', 'A22', 'A61', 'A63', 'A71', 'A73', 'B51', 'B52', 'B61')
                     and (substr(c.utdiv, 0, 1) = '5' or c.taxdiv = '9')
                     or
                     p_buydiv = '92' -- 사원판매
                     and nvl(a.saldiv, ' ') = 'A09'
                     or
                     p_buydiv = '99' -- 직수출
                     and nvl(a.saldiv, ' ') = 'A22');

    elsif (p_div = 'orddtl')
    then
        --영업 회계로드에서 세금계산서별 상세 매출 내역 확인
        open IO_CURSOR for
        select  b.seq as orderseq,
                b.itemcode as itemcode,
                c.itemname as itemname,
                b.salqty as salqty,
                b.salprc as salprc,
                b.salamt * case when substr(a.saldiv, 0, 1) = 'A' then 1 else -1 end as salamt,
                case when nvl(c.itempart, ' ') not in ('02', '08') then b.salamt * case when substr(a.saldiv, 0, 1) = 'A' then 1 else -1 end else 0 end as amt1,
                case when nvl(c.itempart, ' ') in ('02', '08') then b.salamt * case when substr(a.saldiv, 0, 1) = 'A' then 1 else -1 end else 0 end as amt2,
                b.salvat * case when substr(a.saldiv, 0, 1) = 'A' then 1 else -1 end as salvat,
                b.totamt * case when substr(a.saldiv, 0, 1) = 'A' then 1 else -1 end as totamt
        from    SLORDM a
                join SLORDD b
                    on a.orderno = b.orderno
                join CMITEMM c
                    on b.itemcode = c.itemcode
        where   a.plantcode like p_plantcode
                and a.orderno = ip_taxno;

    elsif (p_div = 'itaxsale')
    then
        --세금계산서 생성.
        ip_taxno := substr(replace(p_slipindate, '-', ''), 0, 6) || '1' || substr(p_buydiv, -1, 1); -- 자동생성구분

        for rec in (
            select  ip_taxno || substr('00000' || to_char((nvl(substr(max(taxno), -5, 5), 0) + 1)), -5, 5) as taxno
            from    ACTAXM
            where   compcode = ip_compcode
                    --and plantcode = @plantcode
                    and taxno like ip_taxno || '%'
                    and length(taxno) = 13
                    and iotaxdiv = '02'
                    and saleinyn = 'Y')
        loop
            ip_taxno := rec.taxno;
        end loop;

        insert into ACTAXM
            (
                compcode,
                plantcode,
                taxno, --yyyy1xnnnnn
                taxdiv, --계산서 구분( select * from CMCOMMONM where cmmcode = 'AC60' )
                iotaxdiv, --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61' )
                sdeptcode,
                taxdate,
                custcode,
                custname,
                businessno,
                biznotype, --사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
                blankcnt,
                amt,
                vat,
                vatamt,
                purposediv, --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
                importsdate,
                importedate,
                electaxyn, --전자세금계산서여부
                saleinyn, --영업자동생성여부
                insertdt,
                iempcode
            )
        values
            (
                ip_compcode,
                p_plantcode,
                ip_taxno, -- yyyy1xnnnnn  번호 생성
                case when p_buydiv = '91' then '115'  --역발행매입구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                     when p_buydiv = '92' then '101'  --매출 - 과세(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                     when p_buydiv = '99' then '106'  --매출 - 수출(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                     else '115' end,                  --계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                '02', --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
                p_deptcode,
                p_slipindate,
                p_custcode,
                p_custname,
                p_businessno,
                case when p_buydiv = '92' then '02' else '01' --사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
                end,
                0,
                p_taxamt1,
                p_taxamt2,
                p_taxamt3,
                case when p_buydiv = '91' then '02' else '01' --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
                end,
                p_sdt,
                p_edt,
                'Y' --전자세금계산서여부
                ,
                'Y' --영업자동생성여부
                ,
                sysdate,
                p_iempcode
            );

        insert into ACTAXD
            (
                compcode,
                plantcode,
                taxno, -- yyyy11nnnnn
                seq,
                itemnm, -- item
                amt,
                vat,
                vatamt,
                insertdt,
                iempcode
            )
        values
            (
                ip_compcode, -- select * from ACTAXM
                p_plantcode,
                ip_taxno, -- yyyy11nnnnn  번호 생성
                1,
                p_itemnm, --+ ' 외'
                p_taxamt1,
                p_taxamt2,
                p_taxamt3,
                sysdate,
                p_iempcode
            );

        -- 영업전표의 세금계산서번호 저장
        merge into SLORDM a
        using (
            select  a.orderno, a.orderdate, a.orderseq
            from    SLORDM a
                    join SLORDD b
                        on a.orderno = b.orderno
                    join CMITEMM d
                        on b.itemcode = d.itemcode
                    left join CMCOMMONM SL10
                        on SL10.cmmcode = 'SL10'
                        and SL10.divcode = a.saldiv
                    join CMCUSTM c
                        on a.custcode = c.custcode
            where   a.plantcode = p_plantcode
                    and a.custcode = p_custcode
                    and a.appdate between p_sdt and p_edt
                    and nvl(a.statediv, ' ') = '09'
                    and (p_buydiv = '91' -- 역발행
                         and a.saldiv not in ('A09', 'A21', 'A22', 'A61', 'A63', 'A71', 'A73', 'B51', 'B52', 'B61')
                         and (substr(c.utdiv, 0, 1) = '5' or c.taxdiv = '9')
                         or
                         p_buydiv = '92' -- 사원판매
                         and nvl(a.saldiv, ' ') = 'A09'
                         or
                         p_buydiv = '99' -- 직수출
                         and nvl(a.saldiv, ' ') = 'A22')
        ) src on (a.orderno = src.orderno
                  and a.orderdate = src.orderdate
                  and a.orderseq = src.orderseq)
        when matched
        then
            update set a.taxdate = ip_taxno;

    elsif (p_div = 'utaxsale')
    then
        --세금계산서 수정.
        merge into ACTAXM a
        using (
            select  a.compcode,
                    a.plantcode,
                    a.taxno,
                    case when p_buydiv = '91' then '115' when p_buydiv = '92' then '101' when p_buydiv = '99' then '106' else '115' end as taxdiv,
                    '02', --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
                    case when p_buydiv = '92' then '02' else '01' end as biznotype,
                    case when p_buydiv = '91' then '02' else '01' end as purposediv,
                    'Y', --전자세금계산서여부
                    'Y' --영업/구매 자동생성여부
            from    ACTAXM a
                    left join CMCUSTM c
                        on c.custcode = p_custcode
            where   a.compcode = ip_compcode
                    and a.plantcode = p_plantcode
                    and a.taxno = ip_taxno
        ) src on (a.compcode = src.compcode
                  and a.plantcode = src.plantcode
                  and a.taxno = src.taxno)
        when matched
        then
            update set a.taxdiv = taxdiv, --매입과세 계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                                          --매출 - 과세(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                                          --매입-계산서 계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                       a.iotaxdiv = '02',
                       a.sdeptcode = p_deptcode,
                       a.taxdate = p_slipindate,
                       a.custcode = p_custcode,
                       a.custname = p_custname,
                       a.businessno = p_businessno,
                       a.biznotype = biznotype, -- 사업자등록번호 사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
                       --,blankcnt =@compcode
                       a.amt = p_taxamt1,
                       a.vat = p_taxamt2,
                       a.vatamt = p_taxamt3,
                       a.purposediv = purposediv, --영수청구구분( select * from CMCOMMONM where cmmcode = 'AC62'   )
                       a.electaxyn = 'Y',
                       a.saleinyn = 'Y',
                       a.updatedt = sysdate,
                       a.uempcode = p_iempcode,
                       a.importsdate = p_sdt,
                       a.importedate = p_edt;

        update  ACTAXD a
        set     a.itemnm = p_itemnm,
                a.gyugeok = '',
                a.qty = 0,
                a.prc = 0,
                a.amt = p_taxamt1,
                a.vat = p_taxamt2,
                a.vatamt = p_taxamt3,
                a.remark = '',
                a.updatedt = sysdate,
                a.uempcode = p_iempcode
        where   compcode = ip_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno
                and seq = 1;

        merge into SLORDM a
        using (
            select  a.orderno, a.orderdate, a.orderseq
            from    SLORDM a
                    join SLORDD b
                        on a.orderno = b.orderno
                    join CMITEMM d
                        on b.itemcode = d.itemcode
                    left join CMCOMMONM SL10
                        on SL10.cmmcode = 'SL10'
                        and SL10.divcode = a.saldiv
                    join CMCUSTM c
                        on a.custcode = c.custcode
            where   a.plantcode = p_plantcode
                    and a.custcode = p_custcode
                    and a.appdate between p_sdt and p_edt
                    and nvl(a.statediv, ' ') = '09'
                    and (p_buydiv = '91' -- 역발행
                         and a.saldiv not in ('A09', 'A21', 'A22', 'A61', 'A63', 'A71', 'A73', 'B51', 'B52', 'B61')
                         and (substr(c.utdiv, 0, 1) = '5' or c.taxdiv = '9')
                         or
                         p_buydiv = '92' -- 사원판매
                         and nvl(a.saldiv, ' ') = 'A09'
                         or
                         p_buydiv = '99' -- 직수출
                         and nvl(a.saldiv, ' ') = 'A22')
        ) src on (a.orderno = src.orderno
                  and a.orderdate = src.orderdate
                  and a.orderseq = src.orderseq)
        when matched
        then
            update set a.taxdate = ip_taxno;

    elsif (p_div = 'dtaxsale')
    then
        --세금계산서 삭제.
        -- 회계전표 삭제
        for rec in (
            select  b.slipno, b.slipinno
            from    ACAUTOORDT a
                    join ACORDM b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
            where   a.compcode = ip_compcode
                    and a.acattype = 'S'
                    and a.acatno = ip_taxno)
        loop
            p_slipno := rec.slipno;
            p_slipinno := rec.slipinno;
        end loop;

        if trim(p_slipno) is not null
        then
            SPACORD0000MM('B',
                          ip_compcode,
                          p_slipno,
                          '',
                          '',
                          '',
                          p_userid,
                          p_reasondiv,
                          p_reasontext,
                          MESSAGE,
                          IO_CURSOR);
        end if;

        -- 회계전표 삭제
        delete
        from    ACORDS
        where   compcode = ip_compcode
                and slipinno = p_slipinno;

        delete
        from    ACORDD
        where   compcode = ip_compcode
                and slipinno = p_slipinno;

        delete
        from    ACORDM
        where   compcode = ip_compcode
                and slipinno = p_slipinno;

        -- 자동분개 삭제
        delete
        from    ACAUTOORDT
        where   compcode = ip_compcode
                and acattype = 'S'
                and acatno = ip_taxno;

        -- 세금계산서 삭제
        delete
        from    ACTAXD
        where   compcode = ip_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno;

        delete
        from    ACTAXM
        where   compcode = ip_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno;

        merge into SLORDM a
        using (
            select  a.orderno, a.orderdate, a.orderseq, '' as taxdate
            from    SLORDM a
                    join SLORDD b
                        on a.orderno = b.orderno
                    join CMCUSTM c
                        on a.custcode = c.custcode
            where   a.custcode = p_custcode
                    --and a.appdate between @sdt and @edt
                    and a.taxdate = ip_taxno
                    and nvl(a.statediv, ' ') = '09'
                    and (p_buydiv = '91' -- 역발행
                         and a.saldiv not in ('A09', 'A21', 'A22', 'A61', 'A63', 'A71', 'A73', 'B51', 'B52', 'B61')
                         and (substr(c.utdiv, 0, 1) = '5' or c.taxdiv = '9')
                         or
                         p_buydiv = '92' -- 사원판매
                         and nvl(a.saldiv, ' ') = 'A09'
                         or
                         p_buydiv = '99' -- 직수출
                         and nvl(a.saldiv, ' ') = 'A22')
        ) src on (a.orderno = src.orderno
                  and a.orderdate = src.orderdate
                  and a.orderseq = src.orderseq)
        when matched
        then
            update set a.taxdate = src.taxdate;

    elsif (p_div = 'ctax')
    then
        --세금계산서 존재확인. 매입로드에서 사용
        begin
            p_chktaxno := '';

            for rec in (
                select  nvl(taxno, '') as taxno
                from    ACTAXM
                where   compcode = ip_compcode
                        --and plantcode = @plantcode
                        and taxno = ip_taxno)
            loop
                p_chktaxno := rec.taxno;
            end loop;

            if p_chktaxno = ''
            then
                MESSAGE := 'No';
            else
                MESSAGE := 'Yes';
            end if;
        end;

    elsif (p_div = 'itax')
    then
        --세금계산서 생성.
        ip_taxno := substr(replace(p_slipindate, '-', ''), 0, 6) || '03'; --매입구분 구매자동생성구분

        for rec in (
            select  ip_taxno || substr('00000' || to_char((nvl(substr(max(taxno), -5, 5), 0) + 1)), -5, 5) as taxno
            from    ACTAXM
            where   compcode = ip_compcode
                    --and plantcode = @plantcode
                    and taxno like ip_taxno || '%'
                    and length(taxno) = 13
                    and iotaxdiv = '01'
                    and saleinyn = 'Y')
        loop
            ip_taxno := rec.taxno;
        end loop; --구매 구분 매입세금계산서

        insert into ACTAXM
            (
                compcode,
                plantcode,
                taxno, -- yyyymm03nnnnn
                taxdiv, --계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                iotaxdiv, --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
                sdeptcode,
                taxdate,
                custcode,
                custname,
                businessno,
                biznotype, --사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
                blankcnt,
                amt,
                vat,
                vatamt,
                purposediv, --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
                credittot,
                importsdate,
                importedate,
                electaxyn, --전자세금계산서여부
                purdiv,
                saleinyn, --영업자동생성여부
                insertdt,
                iempcode
            )
        values
            (
                ip_compcode,
                p_plantcode,
                ip_taxno, -- yyyymm03nnnnn  번호 생성
                case when p_buydiv = '01' then '201' --매입-과세
                     when p_buydiv = '02' then '203' --매입-계산서
                     when p_buydiv = '03' then '202' --매입-영세
                     when p_buydiv = '04' then '201' --매입-과세
                     else '203' end,  --매입-계산서
                '01', --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
                '',
                p_slipindate,
                p_custcode,
                p_custname,
                p_businessno,
                '01', --사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
                0,
                p_taxamt1,
                p_taxamt2,
                p_taxamt3,
                '02', --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
                p_taxamt3,
                p_sdt,
                p_edt,
                'Y', --전자세금계산서여부
                case when p_buydiv = '05' then '2' else '0' end,
                'Y' --구매자동생성여부
                ,
                sysdate,
                p_iempcode
            );

        insert into ACTAXD
            (
                compcode,
                plantcode,
                taxno, -- yyyymm03nnnnn
                seq,
                itemnm, -- item
                amt,
                vat,
                vatamt,
                insertdt,
                iempcode
            )
        values
            (
                ip_compcode,
                p_plantcode,
                ip_taxno, -- yyyymm03nnnnn  번호 생성
                1,
                p_itemnm, -- + ' 외'
                p_taxamt1,
                p_taxamt2,
                p_taxamt3,
                sysdate,
                p_iempcode
            );

        merge into PDWAREHOUSINGM a
        using (
            select  a.warehousingdiv, a.warehousingno, a.plantcode
            from    PDWAREHOUSINGM a
                    left join CMCOMMONM MPM04
                        on MPM04.cmmcode = 'MPM04'
                        and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
            where   nvl(a.plantcode, ' ') like p_plantcode || '%'
                    and substr(a.warehousingdt, 1, 10) between p_sdt and p_edt
                    and nvl(MPM04.filter2, ' ') = 'Acc'
                    and nvl(a.custcode, ' ') = nvl(p_custcode,' ')
        ) src on (a.warehousingdiv = src.warehousingdiv
                  and a.warehousingno = src.warehousingno
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = ip_taxno,
                       a.accountday = p_slipindate;

    elsif (p_div = 'itaxunit')
    then
        --세금계산서 개별생성.
        ip_taxno := substr(replace(p_slipindate, '-', ''), 0, 6) || '03'; --매입구분 구매자동생성구분

        for rec in (
            select  ip_taxno || substr('00000' || to_char((nvl(substr(max(taxno), -5, 5), 0) + 1)), -5, 5) as taxno
            from    ACTAXM
            where   compcode = ip_compcode
                    --and plantcode = @plantcode
                    and taxno like ip_taxno || '%'
                    and length(taxno) = 13
                    and iotaxdiv = '01'
                    and saleinyn = 'Y')
        loop
            ip_taxno := rec.taxno;
        end loop; --구매 구분 매입세금계산서

        insert into ACTAXM
            (
                compcode,
                plantcode,
                taxno, -- yyyy03nnnnn
                taxdiv, --계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                iotaxdiv, --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
                sdeptcode,
                taxdate,
                custcode,
                custname,
                businessno,
                biznotype, --사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
                blankcnt,
                amt,
                vat,
                vatamt,
                purposediv, --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
                credittot,
                importsdate,
                importedate,
                electaxyn, --전자세금계산서여부
                purdiv,
                saleinyn, --영업자동생성여부
                insertdt,
                iempcode
            )
        values
            (
                ip_compcode,
                p_plantcode,
                ip_taxno, -- yyyy03nnnnn  번호 생성
                case when p_buydiv = '01' then '201' --매입-과세
                     when p_buydiv = '02' then '203' --매입-계산서
                     when p_buydiv = '03' then '202' --매입-영세
                     when p_buydiv = '04' then '201' --매입-과세
                     else '203' --매입-계산서
                     end,
                '01', --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
                '',
                p_slipindate,
                p_custcode,
                p_custname,
                p_businessno,
                '01', --사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
                0,
                p_taxamt1,
                p_taxamt2,
                p_taxamt3,
                '02', --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
                p_taxamt3,
                p_sdt,
                p_edt,
                'Y', --전자세금계산서여부
                case when p_buydiv = '05' then '2' else '0' end,
                'Y', --구매자동생성여부
                sysdate,
                p_iempcode
            );

        insert into ACTAXD
            (
                compcode,
                plantcode,
                taxno, -- yyyy03nnnnn
                seq,
                itemnm, -- item
                amt,
                vat,
                vatamt,
                insertdt,
                iempcode
            )
        values
            (
                ip_compcode,
                p_plantcode,
                ip_taxno, -- yyyy0301nnnnn  번호 생성
                1,
                p_itemnm, -- + ' 외'
                p_taxamt1,
                p_taxamt2,
                p_taxamt3,
                sysdate,
                p_iempcode
            );

        merge into PDWAREHOUSINGM a
        using (
            select  a.warehousingdiv, a.warehousingno, a.plantcode
            from    PDWAREHOUSINGM a
                    join (
                        select  codes warehousingno
                        from    table(fnsplit(p_warehousingno, ';'))
                    ) b on a.warehousingno = b.warehousingno
                    left join CMCOMMONM MPM04
                        on MPM04.cmmcode = 'MPM04'
                        and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
            where   nvl(a.plantcode, ' ') like p_plantcode || '%'
                    and substr(a.warehousingdt, 1, 10) between p_sdt and p_edt
                    and nvl(MPM04.filter2, ' ') = 'Acc'
                    and nvl(a.custcode, ' ') = nvl(p_custcode,' ')
        ) src on (a.warehousingdiv = src.warehousingdiv
                  and a.warehousingno = src.warehousingno
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = ip_taxno, a.accountday = p_slipindate;

    elsif (p_div = 'itax2')
    then
        --세금계산서 생성.
        ip_taxno := substr(replace(p_slipindate, '-', ''), 0, 6) || '03'; --매입구분 구매자동생성구분

        for rec in (
            select  ip_taxno || substr('00000' || to_char((nvl(substr(max(taxno), -5, 5), 0) + 1)), -5, 5) as taxno
            from    ACTAXM
            where   compcode = ip_compcode
                    --and plantcode = @plantcode
                    and taxno like ip_taxno || '%'
                    and length(taxno) = 13
                    and iotaxdiv = '01'
                    and saleinyn = 'Y')
        loop
            ip_taxno := rec.taxno;
        end loop; --구매 구분 매입세금계산서

        insert into ACTAXM
            (
                compcode,
                plantcode,
                taxno, -- yyyymm03nnnnn
                taxdiv, --계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                iotaxdiv, --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
                sdeptcode,
                taxdate,
                custcode,
                custname,
                businessno,
                biznotype, --사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
                blankcnt,
                amt,
                vat,
                vatamt,
                purposediv, --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
                credittot,
                importsdate,
                importedate,
                electaxyn, --전자세금계산서여부
                purdiv,
                saleinyn, --영업자동생성여부
                insertdt,
                iempcode
            )
        values
            (
                ip_compcode,
                p_plantcode,
                ip_taxno, -- yyyymm03nnnnn  번호 생성
                case when p_buydiv = '01' then '201' --매입-과세
                     when p_buydiv = '02' then '203' --매입-계산서
                     when p_buydiv = '03' then '202' --매입-영세
                     when p_buydiv = '04' then '201' --매입-과세
                     else '203' --매입-계산서
                     end,
                '01', --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
                '',
                p_slipindate,
                p_custcode,
                p_custname,
                p_businessno,
                '01', --사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
                0,
                p_taxamt1,
                p_taxamt2,
                p_taxamt3,
                '02', --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
                p_taxamt3,
                p_slipindate,
                p_slipindate,
                'Y', --전자세금계산서여부
                case when p_buydiv = '05' then '2' else '0' end,
                'Y', --구매자동생성여부
                sysdate,
                p_iempcode
            );

        insert into ACTAXD
            (
                compcode,
                plantcode,
                taxno, -- yyyymm03nnnnn
                seq,
                itemnm, -- item
                amt,
                vat,
                vatamt,
                insertdt,
                iempcode
            )
        values
            (
                ip_compcode,
                p_plantcode,
                ip_taxno, -- yyyymm03nnnnn  번호 생성
                1,
                p_itemnm, -- + ' 외'
                p_taxamt1,
                p_taxamt2,
                p_taxamt3,
                sysdate,
                p_iempcode
            );

        merge into PDWAREHOUSINGM a
        using (
            select  a.warehousingdiv, a.warehousingno, a.plantcode
            from    PDWAREHOUSINGM a
                    left join CMCOMMONM MPM04
                        on MPM04.cmmcode = 'MPM04'
                        and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
            where   a.plantcode = p_plantcode
                    and a.custcode = p_custcode
                    and a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
                    and MPM04.filter2 = 'Acc'
        ) src on (a.warehousingdiv = src.warehousingdiv
                  and a.warehousingno = src.warehousingno
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = ip_taxno;

        merge into PDWAREHOUSINGRM a
        using (
            select  a.warehousingreturningno, a.warehousingdiv, a.plantcode
            from    PDWAREHOUSINGRM a
                    join PDWAREHOUSINGM b
                        on a.warehousingno = b.warehousingno
                        and b.plantcode = p_plantcode
                        and b.custcode = p_custcode
            where   a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.warehousingreturningno = src.warehousingreturningno
                  and a.warehousingdiv = src.warehousingdiv
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = ip_taxno;

        merge into PDPURCHASEDC a
        using (
            select  a.discountid
            from    PDPURCHASEDC a
                    join PDWAREHOUSINGM b
                        on a.warehousingno = b.warehousingno
                        and b.plantcode = p_plantcode
                        and b.custcode = p_custcode
                        and b.accountday is not null
            where   a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.discountid = src.discountid)
        when matched
        then
            update set a.accountno = ip_taxno;

    elsif (p_div = 'utax')
    then
        --세금계산서 수정.
        merge into ACTAXM a
        using (
            select  a.compcode,
                    a.plantcode,
                    a.taxno,
                    p_custname as custname
                    -- b.custname --거래처명
            from    ACTAXM a
                    left join CMCUSTM b
                        on b.custcode = p_custcode
            where   a.compcode = ip_compcode
                    and a.plantcode = p_plantcode
                    and a.taxno = ip_taxno
        ) src on (a.compcode = src.compcode
                  and a.plantcode = src.plantcode
                  and a.taxno = src.taxno)
        when matched
        then
            update set a.taxdiv = case when p_buydiv = '01' then '201' when p_buydiv = '02' then '203' when p_buydiv = '03' then '202' when p_buydiv = '04' then '201' else '203' end,
                       a.iotaxdiv = '01',
                       a.sdeptcode = p_deptcode,
                       a.taxdate = p_slipindate,
                       a.custcode = p_custcode,
                       a.custname = src.custname,
                       a.businessno = p_businessno,
                       a.biznotype = '01',
                       a.amt = p_taxamt1,
                       a.vat = p_taxamt2,
                       a.vatamt = p_taxamt3,
                       a.purposediv = '02',
                       a.electaxyn = 'Y',
                       a.saleinyn = 'Y',
                       a.purdiv = case when p_buydiv = '05' then '2' else '0' end,
                       a.updatedt = sysdate,
                       a.uempcode = p_iempcode,
                       a.importsdate = p_sdt,
                       a.importedate = p_edt;

        update  ACTAXD
        set     itemnm = p_itemnm,
                gyugeok = '',
                qty = 0,
                prc = 0,
                amt = p_taxamt1,
                vat = p_taxamt2,
                vatamt = p_taxamt3,
                remark = '',
                updatedt = sysdate,
                uempcode = p_iempcode
        where   compcode = ip_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno
                and seq = 1;

    elsif (p_div = 'utax2')
    then
        --세금계산서 수정.
        merge into ACTAXM a
        using (
            select  a.compcode, a.plantcode, a.taxno, p_custname as custname
            from    ACTAXM a
                    left join CMCUSTM b
                        on b.custcode = p_custcode
            where   a.compcode = ip_compcode
                    and a.plantcode = p_plantcode
                    and a.taxno = ip_taxno
        ) src on (a.compcode = src.compcode
                  and a.plantcode = src.plantcode
                  and a.taxno = src.taxno)
        when matched
        then
            update set a.taxdiv = case when p_buydiv = '01' then '201' when p_buydiv = '02' then '203' when p_buydiv = '03' then '202' when p_buydiv = '04' then '201' else '203' end,
                       a.iotaxdiv = '01',
                       a.sdeptcode = p_deptcode,
                       a.taxdate = p_slipindate,
                       a.custcode = p_custcode,
                       a.custname = src.custname,
                       a.businessno = p_businessno,
                       a.biznotype = '01',
                       a.amt = p_taxamt1,
                       a.vat = p_taxamt2,
                       a.vatamt = p_taxamt3,
                       a.purposediv = '02',
                       a.electaxyn = 'Y',
                       a.saleinyn = 'Y',
                       a.purdiv = case when p_buydiv = '05' then '2' else '0' end,
                       a.updatedt = sysdate,
                       a.uempcode = p_iempcode,
                       a.importsdate = p_slipindate,
                       a.importedate = p_slipindate;

        update  ACTAXD
        set     itemnm = p_itemnm,
                gyugeok = '',
                qty = 0,
                prc = 0,
                amt = p_taxamt1,
                vat = p_taxamt2,
                vatamt = p_taxamt3,
                remark = '',
                updatedt = sysdate,
                uempcode = p_iempcode
        where   compcode = ip_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno
                and seq = 1;

        merge into PDWAREHOUSINGM a
        using (
            select  a.warehousingdiv, a.warehousingno, a.plantcode
            from    PDWAREHOUSINGM a
                    left join CMCOMMONM MPM04
                        on MPM04.cmmcode = 'MPM04'
                        and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
            where   a.plantcode = p_plantcode
                    and a.custcode = p_custcode
                    and a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
                    and MPM04.filter2 = 'Acc'
        ) src on (a.warehousingdiv = src.warehousingdiv
                  and a.warehousingno = src.warehousingno
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = ip_taxno;

        merge into PDWAREHOUSINGRM a
        using (
            select  a.warehousingreturningno, a.warehousingdiv, a.plantcode
            from    PDWAREHOUSINGRM a
                    join PDWAREHOUSINGM b
                        on a.warehousingno = b.warehousingno
                        and b.plantcode = p_plantcode
                        and b.custcode = p_custcode
                        --and b.finishamt <> 0
                        --and b.accountday <> ''
            where   a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.warehousingreturningno = src.warehousingreturningno
                  and a.warehousingdiv = src.warehousingdiv
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = ip_taxno;

        merge into PDPURCHASEDC a
        using (
            select  a.discountid
            from    PDPURCHASEDC a
                    join PDWAREHOUSINGM b
                        on a.warehousingno = b.warehousingno
                        and b.plantcode = p_plantcode
                        and b.custcode = p_custcode
                        and b.accountday is not null
            where   a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.discountid = src.discountid)
        when matched
        then
            update set a.accountno = ip_taxno;

    elsif (p_div = 'dtax')
    then
        -- 세금계산서 삭제.
        -- 회계전표 삭제
        for rec in (
            select  b.slipno, b.slipinno
            from    ACAUTOORDT a
                    join ACORDM b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
            where   a.compcode = ip_compcode
                    and a.acattype = 'P'
                    and a.acatno = ip_taxno)
        loop
            p_slipno := rec.slipno;
            p_slipinno := rec.slipinno;
        end loop;

        if p_slipno is not null
        then
            SPACORD0000MM('B',
                          ip_compcode,
                          p_slipno,
                          '',
                          '',
                          '',
                          p_userid,
                          p_reasondiv,
                          p_reasontext,
                          MESSAGE,
                          IO_CURSOR);
        end if;

        delete
        from    ACORDS
        where   compcode = ip_compcode
                and slipinno = p_slipinno;

        delete
        from    ACORDD
        where   compcode = ip_compcode
                and slipinno = p_slipinno;

        delete
        from    ACORDM
        where   compcode = ip_compcode
                and slipinno = p_slipinno;

        -- 자동분개 삭제
        delete
        from    ACAUTOORDT
        where   compcode = ip_compcode
                and acattype = 'P'
                and acatno = ip_taxno;

        -- 세금계산서 삭제
        delete
        from    ACTAXD
        where   compcode = ip_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno;

        delete
        from    ACTAXM
        where   compcode = ip_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno;

        -- 입고전표 갱신
        merge into PDWAREHOUSINGM a
        using (
            select  a.warehousingdiv,
                    a.warehousingno,
                    a.plantcode
            from    PDWAREHOUSINGM a
                    left join CMCOMMONM MPM04
                        on MPM04.cmmcode = 'MPM04'
                        and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
            where   nvl(a.plantcode, ' ') like p_plantcode || '%'
                    and substr(a.warehousingdt, 1, 10) between p_sdt and p_edt
                    and nvl(MPM04.filter2, ' ') = 'Acc'
                    and nvl(a.custcode, ' ') = nvl(p_custcode,' ')
                    and nvl(a.accountday, ' ') = nvl(p_slipindate,' ')
                    and nvl(a.accountno, ' ') = nvl(ip_taxno,' ')
        ) src on (a.warehousingdiv = src.warehousingdiv
                  and a.warehousingno = src.warehousingno
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = '',
                       a.accountday = '',
                       a.accountcheck = '';

    elsif (p_div = 'dtax2' or p_div = 'dtaxno2')
    then
        -- 세금계산서 삭제.
        -- 회계전표 삭제
        for rec in (
            select  b.slipno, b.slipinno
            from    ACAUTOORDT a
                    join ACORDM b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
            where   a.compcode = ip_compcode
                    and a.acattype = 'P'
                    and a.acatno = ip_taxno)
        loop
            p_slipno := rec.slipno;
            p_slipinno := rec.slipinno;
        end loop;

        if p_slipno is not null
        then
            SPACORD0000MM('B',
                          ip_compcode,
                          p_slipno,
                          '',
                          '',
                          '',
                          p_userid,
                          p_reasondiv,
                          p_reasontext,
                          MESSAGE,
                          IO_CURSOR);
        end if;

        delete
        from    ACORDS
        where   compcode = ip_compcode
                and slipinno = p_slipinno;

        delete
        from    ACORDD
        where   compcode = ip_compcode
                and slipinno = p_slipinno;

        delete
        from    ACORDM
        where   compcode = ip_compcode
                and slipinno = p_slipinno;

        -- 자동분개 삭제
        delete
        from    ACAUTOORDT
        where   compcode = ip_compcode
                and acattype = 'P'
                and acatno = ip_taxno;

        -- 세금계산서 삭제
        delete
        from    ACTAXD
        where   compcode = ip_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno;

        delete
        from    ACTAXM
        where   compcode = ip_compcode
                and plantcode = p_plantcode
                and taxno = ip_taxno;

        merge into PDWAREHOUSINGM a
        using (
            select  a.warehousingdiv, a.warehousingno, a.plantcode
            from    PDWAREHOUSINGM a
                    left join CMCOMMONM MPM04
                        on MPM04.cmmcode = 'MPM04'
                        and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
            where   a.plantcode = p_plantcode
                    and a.custcode = p_custcode
                    and a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
                    and MPM04.filter2 = 'Acc'
        ) src on (a.warehousingdiv = src.warehousingdiv
                  and a.warehousingno = src.warehousingno
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = '',
                       a.accountcheck = '';

        merge into PDWAREHOUSINGRM a
        using (
            select  a.warehousingreturningno, a.warehousingdiv, a.plantcode
            from    PDWAREHOUSINGRM a
                    join PDWAREHOUSINGM b
                        on a.warehousingno = b.warehousingno
                        and b.plantcode = p_plantcode
                        and b.custcode = p_custcode
                        --and b.finishamt <> 0
                        --and b.accountday <> ''
            where   a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.warehousingreturningno = src.warehousingreturningno
                  and a.warehousingdiv = src.warehousingdiv
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = '',
                       a.accountcheck = '';

        merge into PDPURCHASEDC a
        using (
            select  a.discountid
            from    PDPURCHASEDC a
                    join PDWAREHOUSINGM b
                        on a.warehousingno = b.warehousingno
                        and b.plantcode = p_plantcode
                        and b.custcode = p_custcode
                        and trim(b.accountday) is not null
            where   a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.discountid = src.discountid)
        when matched
        then
            update set a.accountno = '',
                       a.discountchk = '';

    elsif (p_div = 'dtaxno')
    then
        --세금계산서 번호를 입고테이블에서 수정 .
        merge into PDWAREHOUSINGM a
        using (
            select  a.warehousingdiv,
                    a.warehousingno,
                    a.plantcode
            from    PDWAREHOUSINGM a
                    left join CMCOMMONM MPM04
                        on MPM04.cmmcode = 'MPM04'
                        and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
            where   nvl(a.plantcode, ' ') like p_plantcode || '%'
                    and substr(a.warehousingdt, 1, 10) between p_sdt and p_edt
                    and nvl(MPM04.filter2, ' ') = 'Acc'
                    and nvl(a.custcode, ' ') = nvl(p_custcode,' ')
                    and nvl(a.accountday, ' ') like p_slipindate || '%'
                    and nvl(a.accountno, ' ') like ip_taxno || '%'
        ) src on (a.warehousingdiv = src.warehousingdiv
                  and a.warehousingno = src.warehousingno
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = '',
                       a.accountday = '',
                       a.accountcheck = '';

    elsif (p_div = 'dtaxno2')
    then
        --세금계산서 번호를 입고테이블에서 수정 .
        merge into PDWAREHOUSINGM a
        using (
            select  a.warehousingdiv, a.warehousingno, a.plantcode
            from    PDWAREHOUSINGM a
                    left join CMCOMMONM MPM04
                        on MPM04.cmmcode = 'MPM04'
                        and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
            where   a.plantcode = p_plantcode
                    and a.custcode = p_custcode
                    and a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
                    and MPM04.filter2 = 'Acc'
        ) src on (a.warehousingdiv = src.warehousingdiv
                  and a.warehousingno = src.warehousingno
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = '',
                       a.accountcheck = '';

        merge into PDWAREHOUSINGRM a
        using (
            select  a.warehousingreturningno, a.warehousingdiv, a.plantcode
            from    PDWAREHOUSINGRM a
                    join PDWAREHOUSINGM b
                        on a.warehousingno = b.warehousingno
                        and b.plantcode = p_plantcode
                        and b.custcode = p_custcode
                        --and b.finishamt <> 0
                        --and b.accountday <> ''
            where   a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.warehousingreturningno = src.warehousingreturningno
                  and a.warehousingdiv = src.warehousingdiv
                  and a.plantcode = src.plantcode)
        when matched
        then
            update set a.accountno = '',
                       a.accountcheck = '';

        merge into PDPURCHASEDC a
        using (
            select  a.discountid
            from    PDPURCHASEDC a
                    join PDWAREHOUSINGM b
                        on a.warehousingno = b.warehousingno
                        and b.plantcode = p_plantcode
                        and b.custcode = p_custcode
                        and trim(b.accountday) is not null
            where   a.accountday = p_slipindate
                    and nvl(a.accountseq, 0) = p_slipinseq
        ) src on (a.discountid = src.discountid)
        when matched
        then
            update set a.accountno = '',
                       a.discountchk = '';

    elsif (p_div = 'PPSSD')
    then
        --상세 내용 정보 확인
        open IO_CURSOR for
        select  'N' selyn,
                nvl(a.warehousingno, '') as warehousingno,
                nvl(a.orderno, '') as orderno,
                nvl(a.itemcode, '') as itemcode,
                nvl(m.itemname, '') as itemname,
                nvl(a.lotdate, '') as lotdate,
                nvl(a.lotno, '') as lotno,
                nvl(a.buydiv, '') as buydiv2, -- 세금 구분
                nvl(MPM17.divname, '') as buydivname2,
                nvl(a.warehousingdiv, '') as warehousediv, -- 입고구분
                case when a.warehousingdiv = '01' then '원자재입고' when a.warehousingdiv = '02' then '상품입고' when a.warehousingdiv = '03' then '위탁입고' end as ipgodivname, --입고구분명
                nvl(a.totalwarehousingqty, 0) as totqty,
                nvl(a.warehousingprice, 0) as price,
                nvl(a.warehousingamt, 0) as amount, --lightpink
                nvl(a.finishamt, 0) as finishamt2, --palegoldenrod
                nvl(a.vat, 0) as vat2, --navajowhite
                nvl(a.finishamt, 0) + nvl(a.vat, 0) as sumamt2,
                nvl(m.itemdiv, '') as itemdiv,
                nvl(CMM01.divname, '') as itemdivname,
                nvl(a.warehousingstate, '') as warehousestate2, --입고상태
                nvl(MPM04.divname, '') as instatename, -- 입고 상태 명
                nvl(a.accountno, '') as taxno2,
                nvl(a.accountday, '') as slipindate2
        from    PDWAREHOUSINGM a
                left join CMITEMM m
                    on a.plantcode = m.plantcode
                    and a.itemcode = m.itemcode
                left join CMCOMMONM MPM17
                    on MPM17.cmmcode = 'MPM17'
                    and MPM17.divcode = a.buydiv
                left join CMCOMMONM MPM04
                    on MPM04.cmmcode = 'MPM04'
                    and MPM04.divcode = a.warehousingstate
                left join COMMONMASTER CMM01 --select * from CMCOMMONM where cmmcode = 'CMM01'
                    on CMM01.cmmcode = 'CMM01' --select * from CMCOMMONM where cmmcode = 'CMM01'
                    and CMM01.divcode = m.itemdiv --select * from CMITEMM
        where   nvl(a.plantcode, ' ') like p_plantcode || '%'
                and substr(a.warehousingdt, 1, 10) between p_sdt and p_edt
                and nvl(MPM04.filter2, ' ') = 'Acc'
                and nvl(a.custcode, ' ') = nvl(p_custcode,' ')
                and (ip_taxno = ' ' and trim(a.accountno) is null or
                     trim(ip_taxno) is not null and nvl(a.accountno, ' ') like ip_taxno || '%');

    elsif (p_div = 'PPSSD2')
    then
        --상세 내용 정보 확인
        --set @plantcode = '1000'
        open IO_CURSOR for
        select  nvl(a.warehousingno, '') as warehousingno,
                nvl(a.orderno, '') as orderno,
                nvl(b.ritemcode, a.itemcode) as itemcode,
                nvl(m.itemname, '') as itemname,
                nvl(a.lotdate, '') as lotdate,
                nvl(a.lotno, '') as lotno,
                nvl(a.buydiv, '') as buydiv2, -- 세금 구분
                nvl(MPM17.divname, '') as buydivname2,
                nvl(a.warehousingdiv, '') as warehousediv, -- 입고구분
                case when a.warehousingdiv = '01' then '원자재입고'
                     when a.warehousingdiv = '02' then '상품입고'
                     when a.warehousingdiv = '03' then '위탁입고'
                     when a.warehousingdiv = '90' then '일반자재입고' end as ipgodivname, --입고구분명
                nvl(a.totalwarehousingqty, 0) as totqty,
                nvl(a.warehousingprice, 0) as price,
                nvl(a.warehousingamt, 0) as amount, --lightpink
                nvl(a.finishamt, 0) as finishamt2, --palegoldenrod
                nvl(a.vat, 0) as vat2, --navajowhite
                nvl(a.finishamt, 0) + nvl(a.vat, 0) as sumamt2,
                nvl(m.itemdiv, '') as itemdiv,
                nvl(CMM01.divname, '일반자재') as itemdivname,
                nvl(a.warehousingstate, '') as warehousestate2, --입고상태
                nvl(MPM04.divname, '') as instatename, -- 입고 상태 명
                nvl(a.accountno, '') as taxno2,
                nvl(a.accountday, '') as slipindate2
        from    PDWAREHOUSINGM a
                left join PDITEMRELATION b on a.itemcode = b.itemcode
                left join CMITEMM m on nvl(b.ritemcode, a.itemcode) = m.itemcode
                left join CMCOMMONM MPM17
                    on MPM17.cmmcode = 'MPM17'
                    and MPM17.divcode = a.buydiv
                left join CMCOMMONM MPM04
                    on MPM04.cmmcode = 'MPM04'
                    and MPM04.divcode = a.warehousingstate
                left join COMMONMASTER CMM01
                    on CMM01.cmmcode = 'CMM01'
                    and CMM01.divcode = m.itemdiv
        where   a.plantcode = p_plantcode
                and a.custcode = p_custcode
                and a.accountday = p_slipindate
                and nvl(a.accountseq, 0) = p_slipinseq
                and MPM04.filter2 = 'Acc'
                and nvl(trim(a.changechk), 'N') = 'N'
        union all
        select  nvl(a.warehousingno, '') as warehousingno,
                nvl(b.orderno, '') as orderno,
                nvl(c.ritemcode, b.itemcode) as itemcode,
                nvl(m.itemname, '') as itemname,
                nvl(b.lotdate, '') as lotdate,
                nvl(b.lotno, '') as lotno,
                nvl(b.buydiv, '') as buydiv2, -- 세금 구분
                nvl(MPM17.divname, '') as buydivname2,
                '92' as warehousediv, -- 입고구분
                '상품할인' as ipgodivname, --입고구분명
                nvl(b.totalwarehousingqty, 0) as totqty,
                nvl(case when a.discountdiv = '03' then a.dcpricea - a.dcpriceb else a.dcpriceb - a.dcpricea end, 0) as price,
                nvl(case when a.discountdiv = '03' then a.discountamt else -a.discountamt end, 0) as amount, --lightpink
                nvl(case when a.discountdiv = '03' then a.discountamt else -a.discountamt end, 0) as finishamt2, --palegoldenrod
                nvl(case when a.discountdiv = '03' then a.discountvat else -a.discountvat end, 0) as vat2, --navajowhite
                nvl(case when a.discountdiv = '03' then a.discountamt + a.discountvat else -a.discountamt - a.discountvat end, 0) as sumamt2,
                nvl(m.itemdiv, '') as itemdiv,
                nvl(CMM01.divname, '') as itemdivname,
                nvl(b.warehousingstate, '') as warehousestate2, --입고상태
                nvl(MPM04.divname, '') as instatename, -- 입고 상태 명
                nvl(a.accountno, '') as taxno2,
                nvl(a.accountday, '') as slipindate2
        from    PDPURCHASEDC a
                join PDWAREHOUSINGM b
                    on a.warehousingno = b.warehousingno
                    and trim(b.accountday) is not null
                left join PDITEMRELATION c
                    on b.itemcode = c.itemcode
                left join CMITEMM m
                    on nvl(c.ritemcode, b.itemcode) = m.itemcode
                left join CMCOMMONM MPM17
                    on MPM17.cmmcode = 'MPM17'
                    and MPM17.divcode = b.buydiv
                left join CMCOMMONM MPM04
                    on MPM04.cmmcode = 'MPM04'
                    and MPM04.divcode = b.warehousingstate
                left join COMMONMASTER CMM01
                    on CMM01.cmmcode = 'CMM01'
                    and CMM01.divcode = m.itemdiv
        where   b.plantcode = p_plantcode
                and b.custcode = p_custcode
                and a.accountday = p_slipindate
                and nvl(a.accountseq, 0) = p_slipinseq
                and MPM04.filter2 = 'Acc'
        union all
        select  nvl(a.warehousingno, '') as warehousingno,
                nvl(b.orderno, '') as orderno,
                nvl(c.ritemcode, b.itemcode) as itemcode,
                nvl(m.itemname, '') as itemname,
                nvl(b.lotdate, '') as lotdate,
                nvl(b.lotno, '') as lotno,
                nvl(b.buydiv, '') as buydiv2, -- 세금 구분
                nvl(MPM17.divname, '') as buydivname2,
                case when a.warehousingdiv = '01' then '81'
                     when a.warehousingdiv = '02' then '82'
                     when a.warehousingdiv = '03' then '83'
                     end as warehousediv, -- 입고구분
                case when a.warehousingdiv = '01' then '원자재반품'
                     when a.warehousingdiv = '02' then '상품반품'
                     when a.warehousingdiv = '03' then '위탁반품'
                     when a.warehousingdiv = '90' then '일반자재반품'
                     end as ipgodivname, --입고구분명
                nvl(a.totalwarehousingreturnqty, 0) as totqty,
                nvl(-a.warehousingreturningprice, 0) as price,
                nvl(-a.warehousingreturningamt, 0) as amount, --lightpink
                nvl(-a.warehousingreturningamt, 0) as finishamt2, --palegoldenrod
                nvl(-a.vat, 0) as vat2, --navajowhite
                nvl(-a.warehousingreturningamt, 0) + nvl(-a.vat, 0) as sumamt2,
                nvl(m.itemdiv, '') as itemdiv,
                nvl(CMM01.divname, '일반자재') as itemdivname,
                nvl(b.warehousingstate, '') as warehousestate2, --입고상태
                nvl(MPM04.divname, '') as instatename, -- 입고 상태 명
                nvl(a.accountno, '') as taxno2,
                nvl(a.accountday, '') as slipindate2
        from    PDWAREHOUSINGRM a
                join PDWAREHOUSINGM b
                    on a.plantcode = b.plantcode
                    and a.warehousingdiv = b.warehousingdiv
                    and a.warehousingno = b.warehousingno
                    --and b.finishamt <> 0
                    --and b.accountday <> ''
                left join PDITEMRELATION c
                    on b.itemcode = c.itemcode
                left join CMITEMM m
                    on nvl(c.ritemcode, b.itemcode) = m.itemcode
                    --on b.itemcode = m.itemcode
                left join CMCOMMONM MPM17
                    on MPM17.cmmcode = 'MPM17'
                    and MPM17.divcode = b.buydiv
                left join CMCOMMONM MPM04
                    on MPM04.cmmcode = 'MPM04'
                    and MPM04.divcode = b.warehousingstate
                left join COMMONMASTER CMM01
                    on CMM01.cmmcode = 'CMM01'
                    and CMM01.divcode = m.itemdiv
        where   b.plantcode = p_plantcode
                and b.custcode = p_custcode
                and a.accountday = p_slipindate
                and nvl(a.accountseq, 0) = p_slipinseq
                and MPM04.filter2 = 'Acc'
                and nvl(a.workdiv, '02') = '02'
        order by warehousingno;

    elsif (p_div = 'PPload1')
    then
        if (p_actrnstate = '1')
        then
            --신규 생성
            -- 기간동안의 모든 전표를 생성한다.
            insert into ACAUTOORDT(compcode, --회사코드
                                   acattype, --전표유형(p)
                                   acatno, --taxno
                                   slipindate, --발의일자(세금계산서일자)
                                   acatrulecode, --분개률코드(p01001)
                                   deptcode, --부서
                                   plantcode, --사업장
                                   empcode, --발의사원코드
                                   remark, --
                                   custcode, --거래처코드
                                   taxno, --계산서번호
                                   trn1amt, --원재료매입액
                                   trn2amt, --부재료매입액
                                   trn3amt, --외주가공비
                                   trn4amt, --상품매입액
                                   trn5amt, --부가세
                                   trn6amt, --합계금액
                                   actrnstate, --실행상태
                                   userdef3code, --사업장명
                                   userdef4code, --부서명
                                   userdef5code, --발의사원명
                                   userdef6code, --거래처명
                                   insertdt, --입력일자
                                   iempcode) --입력사원
                (select ip_compcode, --회사코드
                        'P', --전표유형(p)
                        ip_taxno, --적요@itemnm
                        p_slipindate, --발의일자(세금계산서일자)
                        p_acatrulecode, --분개률코드(p01001)
                        (select deptcode
                         from    CMEMPM
                         where    empcode = p_iempcode), --부서
                        p_plantcode, --사업장
                        p_iempcode, --발의사원코드
                        p_itemnm, --적요
                        p_custcode, --거래처코드
                        ip_taxno, --계산서번호
                        p_finishamt1, --원재료금액
                        p_finishamt2, --부재료
                        p_finishamt3, --외주가공
                        p_finishamt4, --상품
                        p_taxamt2, --부가세
                        p_taxamt3, --합계금액
                        '1', --실행상태 신규
                        (select plantname
                         from    CMPLANTM
                         where    plantcode = p_plantcode), --사업장명
                        (select d.deptname
                         from    CMEMPM e join CMDEPTM d on d.deptcode = e.deptcode
                         where    e.empcode = p_iempcode), --부서명
                        (select e.empname
                         from    CMEMPM e
                         where    e.empcode = p_iempcode), --발의사원명
                        (select custname
                         from    CMCUSTM
                         where    custcode = p_custcode), --거래처명
                        sysdate,
                        --입력일자
                        p_iempcode --입력사원
                 from    DUAL);

            merge into PDWAREHOUSINGM a
            using       (select a.warehousingdiv, a.warehousingno, a.plantcode, 'Y'
                        from   PDWAREHOUSINGM a
                               left join CMCOMMONM MPM04
                                   on MPM04.cmmcode = 'MPM04'
                                      and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
                        where  nvl(a.plantcode, ' ') like p_plantcode || '%'
                               and substr(a.warehousingdt, 1, 10) between p_sdt and p_edt
                               and nvl(MPM04.filter2, ' ') = 'Acc'
                               and nvl(a.custcode, ' ') = nvl(p_custcode,' ')
                               and nvl(a.accountday, ' ') = nvl(p_slipindate,' ')
                               and nvl(a.accountno, ' ') = nvl(ip_taxno,' ')) src
            on           (a.warehousingdiv = src.warehousingdiv
                        and a.warehousingno = src.warehousingno
                        and a.plantcode = src.plantcode)
            when matched
            then
                update set a.accountcheck = 'Y';
        elsif (p_actrnstate = '3')
        then
            --수정
            update ACAUTOORDT b
            set    b.slipindate = p_slipindate,
                   b.acatrulecode = p_acatrulecode, --분개률코드(p01001)
                   b.deptcode =
                       (select deptcode
                        from   CMEMPM
                        where  empcode = p_iempcode), --부서
                   b.plantcode = p_plantcode, --사업장
                   b.empcode = p_iempcode, --발의사원코드
                   b.remark = p_itemnm, --
                   b.custcode = p_custcode, --거래처코드
                   b.taxno = ip_taxno, --계산서번호
                   b.trn1amt = p_finishamt1, --원재료매입액
                   b.trn2amt = p_finishamt2, --부재료매입액
                   b.trn3amt = p_finishamt3, --외주가공비
                   b.trn4amt = p_finishamt4, --상품매입액
                   b.trn5amt = p_taxamt2, --부가세
                   b.trn6amt = p_taxamt3, --합계금액
                   b.actrnstate = p_actrnstate, --실행상태
                   b.userdef3code =
                       (select plantname
                        from   CMPLANTM
                        where  plantcode = p_plantcode), --사업장명
                   b.userdef4code =
                       (select d.deptname
                        from   CMEMPM e left join CMDEPTM d on d.deptcode = e.deptcode
                        where  e.empcode = p_iempcode), --부서명
                   b.userdef5code =
                       (select e.empname
                        from   CMEMPM e
                        where  e.empcode = p_iempcode), --사원명
                   b.userdef6code =
                       (select custname
                        from   CMCUSTM
                        where  custcode = p_custcode), --거래처명
                   b.updatedt --입력일자
                              = sysdate,
                   b.uempcode = p_iempcode
            where  b.compcode = ip_compcode
                   and b.acattype = 'P'
                   and b.acatno = ip_taxno;
        elsif (p_actrnstate = '4')
        then
            update ACAUTOORDT b
            set    b.actrnstate = p_actrnstate, b.remark = p_itemnm, b.updatedt = sysdate, b.uempcode = p_iempcode
            where  b.compcode = ip_compcode
                   and b.acattype = 'P'
                   and b.acatno = ip_taxno;
        end if;
    elsif (p_div = 'PPload2')
    then
        if (p_actrnstate = '1')
        then
            --신규 생성
            -- 기간동안의 모든 전표를 생성한다.
            insert into ACAUTOORDT(compcode, --회사코드
                                   acattype, --전표유형(p)
                                   acatno, --taxno
                                   slipindate, --발의일자(세금계산서일자)
                                   acatrulecode, --분개률코드(p01001)
                                   deptcode, --부서
                                   plantcode, --사업장
                                   empcode, --발의사원코드
                                   remark, --
                                   custcode, --거래처코드
                                   taxno, --계산서번호
                                   trn1amt, --원재료매입액
                                   trn2amt, --부재료매입액
                                   trn3amt, --외주가공비
                                   trn4amt, --상품매입액
                                   trn5amt, --부가세
                                   trn6amt, --합계금액
                                   trn11amt, --수입원재료매입액
                                   trn12amt, --수입상품매입액
                                   actrnstate, --실행상태
                                   userdef3code, --사업장명
                                   userdef4code, --부서명
                                   userdef5code, --발의사원명
                                   userdef6code, --거래처명
                                   insertdt, --입력일자
                                   iempcode) --입력사원
                (select ip_compcode, --회사코드
                        'P', --전표유형(p)
                        ip_taxno, --적요@itemnm
                        p_slipindate, --발의일자(세금계산서일자)
                        p_acatrulecode, --분개률코드(p01001)
                        (select deptcode
                         from    CMEMPM
                         where    empcode = p_iempcode), --부서
                        p_plantcode, --사업장
                        p_iempcode, --발의사원코드
                        p_itemnm, --적요
                        p_custcode, --거래처코드
                        ip_taxno, --계산서번호
                        p_finishamt1, --원재료금액
                        p_finishamt2, --부재료
                        p_finishamt3, --외주가공
                        p_finishamt4, --상품
                        p_taxamt2, --부가세
                        p_taxamt3, --합계금액
                        p_finishamt5, --수입원재료매입액
                        p_finishamt6, --수입상품매입액
                        '1', --실행상태 신규
                        (select plantname
                         from    CMPLANTM
                         where    plantcode = p_plantcode), --사업장명
                        (select d.deptname
                         from    CMEMPM e join CMDEPTM d on d.deptcode = e.deptcode
                         where    e.empcode = p_iempcode), --부서명
                        (select e.empname
                         from    CMEMPM e
                         where    e.empcode = p_iempcode), --발의사원명
                        (select custname
                         from    CMCUSTM
                         where    custcode = p_custcode), --거래처명
                        sysdate,
                        --입력일자
                        p_iempcode --입력사원
                 from    DUAL);

            --set @plantcode = '1000'
            merge into PDWAREHOUSINGM a
            using       (select a.warehousingdiv, a.warehousingno, a.plantcode, 'Y'
                        from   PDWAREHOUSINGM a
                               left join CMCOMMONM MPM04
                                   on MPM04.cmmcode = 'MPM04'
                                      and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
                        where  a.plantcode = p_plantcode
                               and a.custcode = p_custcode
                               and a.accountno = ip_taxno
                               and MPM04.filter2 = 'Acc') src
            on           (a.warehousingdiv = src.warehousingdiv
                        and a.warehousingno = src.warehousingno
                        and a.plantcode = src.plantcode)
            when matched
            then
                update set a.accountcheck = 'Y';

            merge into PDWAREHOUSINGRM a
            using       (select a.warehousingreturningno, a.warehousingdiv, a.plantcode, 'Y'
                        from   PDWAREHOUSINGRM a
                               join PDWAREHOUSINGM b
                                   on a.warehousingno = b.warehousingno
                                      and b.plantcode = p_plantcode
                                      and b.custcode = p_custcode
                        --and b.finishamt <> 0
                        --and b.accountday <> ''

                        where  a.accountno = ip_taxno) src
            on           (a.warehousingreturningno = src.warehousingreturningno
                        and a.warehousingdiv = src.warehousingdiv
                        and a.plantcode = src.plantcode)
            when matched
            then
                update set a.accountcheck = 'Y';

            merge into PDPURCHASEDC a
            using       (select a.discountid, 'Y'
                        from   PDPURCHASEDC a
                               join PDWAREHOUSINGM b
                                   on a.warehousingno = b.warehousingno
                                      and b.plantcode = p_plantcode
                                      and b.custcode = p_custcode
                                      and trim(b.accountday) is not null
                        where  a.accountno = ip_taxno) src
            on           (a.discountid = src.discountid)
            when matched
            then
                update set a.discountchk = 'Y';

            merge into PDWAREHOUSINGM a
            using       (select a.warehousingdiv, a.warehousingno, a.plantcode, 'Y'
                        from   PDWAREHOUSINGM a
                               join (select accountday, PDWAREHOUSINGM.accountseq
                                     from    PDWAREHOUSINGM
                                     where    PDWAREHOUSINGM.plantcode = p_plantcode
                                            and PDWAREHOUSINGM.custcode = p_custcode
                                            and PDWAREHOUSINGM.warehousingno = ip_taxno
                                     union
                                     select a.accountday, a.accountseq
                                     from    PDWAREHOUSINGRM a
                                            join PDWAREHOUSINGM b
                                                on a.warehousingno = b.warehousingno
                                                   and b.plantcode = p_plantcode
                                                   and b.custcode = p_custcode
                                     --and b.finishamt <> 0

                                     --and b.accountday <> ''
                                     where    a.warehousingreturningno = ip_taxno) b
                                   on a.accountday = b.accountday
                                      and nvl(a.accountseq, 0) = nvl(b.accountseq, 0)
                               left join CMCOMMONM MPM04
                                   on MPM04.cmmcode = 'MPM04'
                                      and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
                        where  a.plantcode = p_plantcode
                               and a.custcode = p_custcode
                               and MPM04.filter2 = 'Acc') src
            on           (a.warehousingdiv = src.warehousingdiv
                        and a.warehousingno = src.warehousingno
                        and a.plantcode = src.plantcode)
            when matched
            then
                update set a.accountcheck = 'Y', a.accountno = ip_taxno;

            merge into PDWAREHOUSINGRM a
            using       (select a.warehousingreturningno, a.warehousingdiv, a.plantcode, 'Y'
                        from   PDWAREHOUSINGRM a
                               join PDWAREHOUSINGM b
                                   on a.warehousingno = b.warehousingno
                                      and b.plantcode = p_plantcode
                                      and b.custcode = p_custcode
                               join ( --and b.finishamt <> 0
                                     --and b.accountday <> ''
                                     select accountday, PDWAREHOUSINGM.accountseq
                                     from    PDWAREHOUSINGM
                                     where    PDWAREHOUSINGM.plantcode = p_plantcode
                                            and PDWAREHOUSINGM.custcode = p_custcode
                                            and PDWAREHOUSINGM.warehousingno = ip_taxno
                                     union
                                     select a.accountday, a.accountseq
                                     from    PDWAREHOUSINGRM a
                                            join PDWAREHOUSINGM b
                                                on a.warehousingno = b.warehousingno
                                                   and b.plantcode = p_plantcode
                                                   and b.custcode = p_custcode
                                     --and b.finishamt <> 0

                                     --and b.accountday <> ''
                                     where    a.warehousingreturningno = ip_taxno) c
                                   on a.accountday = c.accountday
                                      and nvl(a.accountseq, 0) = nvl(c.accountseq, 0)) src
            on           (a.warehousingreturningno = src.warehousingreturningno
                        and a.warehousingdiv = src.warehousingdiv
                        and a.plantcode = src.plantcode)
            when matched
            then
                update set a.accountcheck = 'Y', a.accountno = ip_taxno;
        elsif (p_actrnstate = '3')
        then
            --수정
            update ACAUTOORDT b
            set    b.slipindate = p_slipindate,
                   b.acatrulecode = p_acatrulecode --분개률코드(p01001)
                                                  ,
                   b.deptcode =
                       (select deptcode
                        from   CMEMPM
                        where  empcode = p_iempcode), --부서
                   b.plantcode = p_plantcode, --사업장
                   b.empcode = p_iempcode, --발의사원코드
                   b.remark = p_itemnm, --
                   b.custcode = p_custcode, --거래처코드
                   b.taxno = ip_taxno, --계산서번호
                   b.trn1amt = p_finishamt1, --원재료매입액
                   b.trn2amt = p_finishamt2, --부재료매입액
                   b.trn3amt = p_finishamt3, --외주가공비
                   b.trn4amt = p_finishamt4, --상품매입액
                   b.trn5amt = p_taxamt2, --부가세
                   b.trn6amt = p_taxamt3, --합계금액
                   b.trn11amt = p_finishamt5, --수입원재료매입액
                   b.trn12amt = p_finishamt6, --수입상품매입액
                   b.actrnstate = p_actrnstate, --실행상태
                   b.userdef3code =
                       (select plantname
                        from   CMPLANTM
                        where  plantcode = p_plantcode), --사업장명
                   b.userdef4code =
                       (select d.deptname
                        from   CMEMPM e left join CMDEPTM d on d.deptcode = e.deptcode
                        where  e.empcode = p_iempcode), --부서명
                   b.userdef5code =
                       (select e.empname
                        from   CMEMPM e
                        where  e.empcode = p_iempcode), --사원명
                   b.userdef6code =
                       (select custname
                        from   CMCUSTM
                        where  custcode = p_custcode), --거래처명
                   b.updatedt = sysdate, --입력일자
                   b.uempcode = p_iempcode
            where  b.compcode = ip_compcode
                   and b.acattype = 'P'
                   and b.acatno = ip_taxno;
        elsif (p_actrnstate = '4')
        then
            update ACAUTOORDT b
            set    b.actrnstate = p_actrnstate, b.remark = p_itemnm, b.updatedt = sysdate, b.uempcode = p_iempcode
            where  b.compcode = ip_compcode
                   and b.acattype = 'P'
                   and b.acatno = ip_taxno;
        end if;

    elsif (p_div = 'PPload3')
    then
        if (p_actrnstate = '1')
        then
            --신규 생성
            -- 기간동안의 모든 전표를 생성한다.
            insert into ACAUTOORDT
                (
                    compcode,         --회사코드
                    acattype,         --전표유형(p)
                    acatno,           --taxno
                    slipindate,       --발의일자(세금계산서일자)
                    acatrulecode,     --분개률코드(p01001)
                    deptcode,         --부서
                    plantcode,        --사업장
                    empcode,          --발의사원코드
                    remark,           --비고
                    custcode,         --거래처코드
                    taxno,            --계산서번호
                    trn1amt,          --원재료매입액
                    trn2amt,          --부재료매입액
                    trn3amt,          --저장품매입액
                    trn4amt,          --외주가공비
                    trn5amt,          --상품매입액
                    trn9amt,          --부가세
                    trn10amt,         --합계금액
                    trn11amt,         --수입원재료매입액
                    trn12amt,         --수입상품매입액
                    trn13amt,         --제조복리후생비
                    trn14amt,         --제조수선비
                    trn15amt,         --제조운반비
                    trn16amt,         --제조도서인쇄비
                    trn17amt,         --제조포장비
                    trn18amt,         --제조소모품비
                    trn19amt,         --제조지급수수료
                    trn20amt,         --제조시험연구비
                    trn21amt,         --경상시험연구비
                    actrnstate,       --실행상태
                    userdef3code,     --사업장명
                    userdef4code,     --부서명
                    userdef5code,     --발의사원명
                    userdef6code,     --거래처명
                    userdef9code,     --lc코드
                    userdef10code,    --lc명
                    insertdt,         --입력일자
                    iempcode          --입력사원
                )
            select  ip_compcode,      --회사코드
                    'P',              --전표유형(p)
                    ip_taxno,         --적요@itemnm
                    p_slipindate,     --발의일자(세금계산서일자)
                    p_acatrulecode,   --분개률코드(p01001)
                    c.deptcode,       --부서
                    b.plantcode,      --사업장
                    p_iempcode,       --발의사원코드
                    p_itemnm,         --적요
                    p_custcode,       --거래처코드
                    ip_taxno,         --계산서번호
                    p_finishamt1,     --원재료매입액
                    p_finishamt2,     --부재료매입액
                    p_finishamt3,     --저장품매입액
                    p_finishamt4,     --외주가공비
                    p_finishamt5,     --상품매입액
                    p_taxamt2,        --부가세
                    p_taxamt3,        --합계금액
                    p_finishamt6,     --수입원재료매입액
                    p_finishamt7,     --수입상품매입액
                    p_finishamt8,     --제조복리후생비
                    p_finishamt9,     --제조수선비
                    p_finishamt10,    --제조운반비
                    p_finishamt11,    --제조도서인쇄비
                    p_finishamt12,    --제조포장비
                    p_finishamt13,    --제조소모품비
                    p_finishamt14,    --제조지급수수료
                    p_finishamt15,    --제조시험연구비
                    p_finishamt16,    --경상시험연구비
                    '1',              --실행상태 신규
                    b.plantname,      --사업장명
                    d.deptname,       --부서명
                    c.empname,        --발의사원명
                    e.custname,       --거래처명
                    p_lccode,         --lc코드
                    p_lcname,         --lc명
                    sysdate,          --입력일자
                    p_iempcode        --입력사원
            from    DUAL a
                    join CMPLANTM b
                        on b.plantcode = '1000'/*p_plantcode*/
                    left join CMEMPM c
                        on c.empcode = p_iempcode
                    left join CMDEPTM d
                        on c.deptcode = d.deptcode
                    left join CMCUSTM e
                        on e.custcode = p_custcode;

            merge into PDWAREHOUSINGM a
            using (
                select  a.warehousingdiv, a.warehousingno, a.plantcode
                from    PDWAREHOUSINGM a
                        left join CMCOMMONM MPM04
                            on MPM04.cmmcode = 'MPM04'
                            and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
                where   a.plantcode = p_plantcode
                        and a.custcode = p_custcode
                        and a.accountno = ip_taxno
                        and MPM04.filter2 = 'Acc'
            ) src on (a.warehousingdiv = src.warehousingdiv
                      and a.warehousingno = src.warehousingno
                      and a.plantcode = src.plantcode)
            when matched
            then
                update set a.accountcheck = 'Y';

            merge into PDWAREHOUSINGRM a
            using (
                select  a.warehousingreturningno, a.warehousingdiv, a.plantcode
                from    PDWAREHOUSINGRM a
                        join PDWAREHOUSINGM b
                            on a.warehousingno = b.warehousingno
                            and b.plantcode = p_plantcode
                            and b.custcode = p_custcode
                            --and b.finishamt <> 0
                            --and b.accountday <> ''
                where   a.accountno = ip_taxno
            ) src on (a.warehousingreturningno = src.warehousingreturningno
                      and a.warehousingdiv = src.warehousingdiv
                      and a.plantcode = src.plantcode)
            when matched
            then
                update set a.accountcheck = 'Y';

            merge into PDPURCHASEDC a
            using (
                select  a.discountid, 'Y'
                from    PDPURCHASEDC a
                        join PDWAREHOUSINGM b
                            on a.warehousingno = b.warehousingno
                            and b.plantcode = p_plantcode
                            and b.custcode = p_custcode
                            and b.accountday is not null
                where   a.accountno = ip_taxno
            ) src on (a.discountid = src.discountid)
            when matched
            then
                update set a.discountchk = 'Y';

            merge into PDWAREHOUSINGM a
            using (
                select  a.warehousingdiv, a.warehousingno, a.plantcode
                from    PDWAREHOUSINGM a
                        join (
                            select  accountday, accountseq
                            from    PDWAREHOUSINGM
                            where   plantcode = p_plantcode
                                    and custcode = p_custcode
                                    and warehousingno = ip_taxno
                            union
                            select  a.accountday, a.accountseq
                            from    PDWAREHOUSINGRM a
                                    join PDWAREHOUSINGM b
                                        on a.warehousingno = b.warehousingno
                                        and b.plantcode = p_plantcode
                                        and b.custcode = p_custcode
                                        --and b.finishamt <> 0
                                        --and b.accountday <> ''
                            where   a.warehousingreturningno = ip_taxno
                        ) b on a.accountday = b.accountday
                            and nvl(a.accountseq, 0) = nvl(b.accountseq, 0)
                        left join CMCOMMONM MPM04
                            on MPM04.cmmcode = 'MPM04'
                            and MPM04.divcode = a.warehousingstate -- 자재입고구분(구분자2 acc값 적용됨.)
                where   a.plantcode = p_plantcode
                        and a.custcode = p_custcode
                        and MPM04.filter2 = 'Acc'
            ) src on (a.warehousingdiv = src.warehousingdiv
                      and a.warehousingno = src.warehousingno
                      and a.plantcode = src.plantcode)
            when matched
            then
                update set a.accountcheck = 'Y',
                           a.accountno = ip_taxno;

            merge into PDWAREHOUSINGRM a
            using (
                select  a.warehousingreturningno, a.warehousingdiv, a.plantcode
                from    PDWAREHOUSINGRM a
                        join PDWAREHOUSINGM b
                            on a.warehousingno = b.warehousingno
                            and b.plantcode = p_plantcode
                            and b.custcode = p_custcode
                            --and b.finishamt <> 0
                            --and b.accountday <> ''
                        join (
                            select  accountday, accountseq
                            from    PDWAREHOUSINGM
                            where   plantcode = p_plantcode
                                    and custcode = p_custcode
                                    and warehousingno = ip_taxno
                            union
                            select  a.accountday, a.accountseq
                            from    PDWAREHOUSINGRM a
                                    join PDWAREHOUSINGM b
                                        on a.warehousingno = b.warehousingno
                                        and b.plantcode = p_plantcode
                                        and b.custcode = p_custcode
                                       --and b.finishamt <> 0
                                       --and b.accountday <> ''
                            where   a.warehousingreturningno = ip_taxno
                        ) c on a.accountday = c.accountday
                            and nvl(a.accountseq, 0) = nvl(c.accountseq, 0)
            ) src on (a.warehousingreturningno = src.warehousingreturningno
                      and a.warehousingdiv = src.warehousingdiv
                      and a.plantcode = src.plantcode)
            when matched
            then
                update set a.accountcheck = 'Y',
                           a.accountno = ip_taxno;
        elsif (p_actrnstate = '3')
        then
            --수정
            update  ACAUTOORDT
            set     slipindate = p_slipindate,
                    acatrulecode = p_acatrulecode,  --분개률코드(p01001)
                    deptcode = (select deptcode from CMEMPM where empcode = p_iempcode), --부서
                    plantcode = '1000'/*p_plantcode*/,        --사업장
                    empcode = p_iempcode,           --발의사원코드
                    remark = p_itemnm,              --비고
                    custcode = p_custcode,          --거래처코드
                    taxno = ip_taxno,               --계산서번호
                    trn1amt = p_finishamt1,         --원재료매입액
                    trn2amt = p_finishamt2,         --부재료매입액
                    trn3amt = p_finishamt3,         --저장품매입액
                    trn4amt = p_finishamt4,         --외주가공비
                    trn5amt = p_finishamt5,         --상품매입액
                    trn9amt = p_taxamt2,            --부가세
                    trn10amt = p_taxamt3,           --합계금액
                    trn11amt = p_finishamt6,        --수입원재료매입액
                    trn12amt = p_finishamt7,        --수입상품매입액
                    trn13amt = p_finishamt8,        --제조복리후생비
                    trn14amt = p_finishamt9,        --제조수선비
                    trn15amt = p_finishamt10,       --제조운반비
                    trn16amt = p_finishamt11,       --제조도서인쇄비
                    trn17amt = p_finishamt12,       --제조포장비
                    trn18amt = p_finishamt13,       --제조소모품비
                    trn19amt = p_finishamt14,       --제조지급수수료
                    trn20amt = p_finishamt15,       --제조시험연구비
                    trn21amt = p_finishamt16,       --경상시험연구비
                    actrnstate = p_actrnstate,      --실행상태
                    userdef3code = (select plantname from CMPLANTM where plantcode = '1000'/*p_plantcode*/), --사업장명
                    userdef4code = (select b.deptname from CMEMPM a join CMDEPTM b on a.deptcode = b.deptcode where a.empcode = p_iempcode), --부서명
                    userdef5code = (select empname from CMEMPM where empcode = p_iempcode), --사원명
                    userdef6code = (select custname from CMCUSTM where custcode = p_custcode), --거래처명
                    userdef9code = p_lccode,        --lc코드
                    userdef10code = p_lcname,       --lc명
                    updatedt = sysdate,             --입력일자
                    uempcode = p_iempcode           --입력사원
            where   compcode = ip_compcode
                    and acattype = 'P'
                    and acatno = ip_taxno;
        elsif (p_actrnstate = '4')
        then
            update  ACAUTOORDT
            set     actrnstate = p_actrnstate,
                    remark = p_itemnm,
                    updatedt = sysdate,
                    uempcode = p_iempcode
            where   compcode = ip_compcode
                    and acattype = 'P'
                    and acatno = ip_taxno;
        end if;

    elsif (p_div = 'head')
    then
        --일괄전송방식의 head레코드 처리 (매입)
        --메타 테이블에 해당일자의 매입 전표 로드 내용 삭제
        delete
        from    ACAUTOORD
        where   slipindate = p_slipindate
                and plantcode like p_plantcode || '%'
                and acattype = 'P';

        -- 기간동안의 모든 개시전표를 생성한다.
        insert into ACAUTOORD
            (
                compcode,     --회사코드
                slipindate,   --발의일자(급여지급일자)
                acatrulecode, --분개룰코드(s01001)
                acattype,     --전표유형(h)
                plantcode,    --사업장
                actrnstate,   --실행상태
                insertdt,     --입력일자
                iempcode      --입력사원
            )
        values
            (
                ip_compcode,
                p_slipindate,
                '',
                'P',
                '',
                '1',
                sysdate,
                p_iempcode
            );
    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;
END;
/
