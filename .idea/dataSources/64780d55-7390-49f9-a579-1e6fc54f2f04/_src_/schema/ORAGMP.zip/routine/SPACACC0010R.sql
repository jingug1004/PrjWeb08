CREATE PROCEDURE        spACacc0010R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0010R
 -- 작 성 자         : 배종성
 -- 작성일자         : 2011-01-07
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-12
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 예산실적전표를 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div             IN VARCHAR2 DEFAULT '' ,
    p_compcode        IN VARCHAR2 DEFAULT '' ,
    p_plantcode       IN VARCHAR2 DEFAULT '' ,
    p_slipsdate       IN VARCHAR2 DEFAULT '' ,
    p_slipedate       IN VARCHAR2 DEFAULT '' ,
    p_deptcode        IN VARCHAR2 DEFAULT '' ,
    p_empcode         IN VARCHAR2 DEFAULT '' ,
    p_slipdiv         IN VARCHAR2 DEFAULT '' ,
    p_slipinstate     IN VARCHAR2 DEFAULT '' ,
    p_stracccode      IN VARCHAR2 DEFAULT '' ,
    p_endacccode      IN VARCHAR2 DEFAULT '' ,
    p_empview         IN VARCHAR2 DEFAULT '' ,
    p_userid          IN VARCHAR2 DEFAULT '' ,
    p_reasondiv       IN VARCHAR2 DEFAULT '' ,
    p_reasontext      IN VARCHAR2 DEFAULT '' ,

    MESSAGE           OUT VARCHAR2,
    IO_CURSOR         OUT TYPES.DataSet
)
AS

    v_temp NUMBER := 0;

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( p_div = 'S' ) THEN

        -- 결의전표내역 검색
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0010R_CMDEPTM';

        INSERT INTO VGT.TT_ACACC0010R_CMDEPTM (
            SELECT  a.deptcode ,
                    a.deptname
            FROM    CMDEPTM a
                    LEFT JOIN ACBDGDPT b ON b.compcode = p_compcode
                                            AND b.budgym = SUBSTR(p_slipsdate, 0, 4) || '-01'
                                            AND a.deptcode = b.deptcode
            WHERE  a.deptcode = p_deptcode OR b.bdgdeptcode = p_deptcode );



        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0010R_ACACCM';

        INSERT INTO VGT.TT_ACACC0010R_ACACCM (
            SELECT DISTINCT a.acccode ,
                            a.accname ,
                            a.dcdiv
            FROM    ACACCM a
                    JOIN (  SELECT  acccode
                            FROM    ACACCM
                            WHERE  ( p_stracccode IS NULL OR p_stracccode IS NOT NULL AND p_stracccode <= acccode )
                                    AND ( p_endacccode IS NULL OR p_endacccode IS NOT NULL AND acccode <= p_endacccode )
                    ) b ON  a.acccode = b.acccode
                            OR p_empview = 'N' AND a.budgcode = b.acccode
                            OR p_empview = 'Y' AND a.ebdgcode = b.acccode );



        FOR rec IN (    SELECT  1 AS alias1
                        FROM    DUAL
                        WHERE NOT EXISTS (  SELECT  *
                                            FROM    CMEMPM a
                                                    JOIN SYSPARAMETERMANAGE b ON b.parametercode = 'acbudgsuperdept'
                                                                                 AND ( a.deptcode = b.value1 OR a.deptcode = b.value2 OR a.deptcode = b.value3 )
                                            WHERE  a.empcode = p_userid ) )
        LOOP

            v_temp := rec.alias1;

        END LOOP;


        IF v_temp = 1 THEN


            FOR rec IN( SELECT  ACCCODE ,
                                ACCNAME ,
                                DCDIV
                        FROM    VGT.TT_ACACC0010R_ACACCM a
                                JOIN SYSPARAMETERMANAGE b ON parametercode = 'acbudgacccode'
                                                             AND ( a.acccode = b.value1 OR a.acccode = b.value2 OR a.acccode = b.value3 ) )
            LOOP

                DELETE FROM VGT.TT_ACACC0010R_ACACCM
                WHERE ACCCODE       =  rec.ACCCODE
                      AND ACCNAME   =  rec.ACCNAME
                      AND DCDIV     =  rec.DCDIV;

            END LOOP;

        END IF;



        OPEN  IO_CURSOR FOR

            SELECT  NVL(a.slipindate, '') slipindate ,              -- 결의일자
                    NVL(a.slipinnum, '') slipinnum ,                -- 결의번호
                    NVL(D.mngcluval, '') deptcode ,                 -- 관리부서
                    NVL(E.deptname, '') deptname ,                  -- 관리부서명
                    COALESCE(f.mngcluval, a.empcode, '') empcode ,  -- 관리사원
                    NVL(G.empname, '') empname ,                    -- 관리사원명
                    NVL(b.acccode, '') acccode ,                    -- 계정코드
                    NVL(c.accname, '') accname ,                    -- 계정명
                    NVL(b.debamt + b.creamt, 0) totamt ,            -- 총금액
                    NVL(b.remark1, '') remark ,                     -- 결의내용
                    NVL(a.skreqdate, '') skreqdate ,                -- 송금의뢰일자
                    NVL(a.slipinstate, '') slipinstate ,            -- 전표상태
                    NVL(ac21.divname, '') slipinstatenm ,           -- 전표상태
                    NVL(a.slipdate, '') slipdate ,                  -- 회계일자
                    NVL(a.slipnum, '') slipnum ,                    -- 회계번호
                    NVL(a.slipempcode, '') slipempcode ,            -- 승인자
                    NVL(h.empname, '') slipempname ,                -- 승인자명
                    NVL(a.slipdiv, '') slipdiv ,                    -- 전표유형구분
                    NVL(ac20.divname, '') slipdivnm ,               -- 전표유형
                    NVL(a.slipremark, '') slipremark ,              -- 처리사유
                    NVL(a.empcode, '') wrempcode ,                  -- 작성자코드
                    NVL(i.empname, '') wrempname                    -- 작성자

            FROM    ACORDM a
                    JOIN ACORDD b ON a.compcode = b.compcode
                                     AND a.slipinno = b.slipinno
                    JOIN VGT.TT_ACACC0010R_ACACCM c ON b.acccode = c.acccode
                                          AND CASE WHEN b.dcdiv IN ( '1','4' ) THEN '1' ELSE '2' END = c.dcdiv
                    JOIN ACORDS D ON b.compcode = D.compcode
                                     AND b.slipinno = D.slipinno
                                     AND b.slipinseq = D.slipinseq
                                     AND D.mngclucode = 'S040'
                    JOIN VGT.TT_ACACC0010R_CMDEPTM E ON D.mngcluval = E.deptcode
                    LEFT JOIN ACORDS f ON b.compcode = f.compcode
                                          AND b.slipinno = f.slipinno
                                          AND b.slipinseq = f.slipinseq
                                          AND f.mngclucode = 'S050'
                    LEFT JOIN CMEMPM G ON NVL(f.mngcluval, a.empcode) = G.empcode
                    LEFT JOIN CMEMPM h ON a.slipempcode = h.empcode
                    LEFT JOIN CMEMPM i ON a.empcode = i.empcode
                    LEFT JOIN CMCOMMONM ac20 ON ac20.cmmcode = 'AC20'
                                                AND a.slipdiv = ac20.divcode
                    LEFT JOIN CMCOMMONM ac21 ON ac21.cmmcode = 'AC21'
                                                AND a.slipinstate = ac21.divcode

            WHERE   a.compcode = p_compcode
                    AND a.plantcode LIKE p_plantcode
                    AND a.slipindate BETWEEN p_slipsdate AND p_slipedate
                    AND a.slipdiv LIKE p_slipdiv
                    AND a.slipinstate LIKE p_slipinstate
                    AND NVL(f.mngcluval, a.empcode) LIKE p_empcode || '%'

            ORDER BY slipindate, slipinnum ;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
