CREATE FUNCTION        FNSLCUSTTURN_MODIFY
-- ---------------------------------------------------------------
-- 함 수 명          : [DBO].[FNSLCUSTTURN]
-- 작 성 자          : 민승기
-- 작성일자          : 2014-01-13
-- 수정내용          : TURNCNT - 여신회전일 , TURNDCCNT - 잔고회전일 임 (KB PHARM 여신회전일이 주이다.
-- ---------------------------------------------------------------
-- 함수설명          : 지정일자기준의 거래처 회전일을 계산하여 테이블로 리턴
-- 수 정 일          : 2014-02-14
--                     영업영역 파라메터 추가
--                     잔고,미결어음,총잔고 추가
--                     회전일 변화 계산 추가
-- ---------------------------------------------------------------
-- SELECT * FROM [DBO].[FNSLCUSTTURN]('1002','%','%','%','2014-05-31',0)
/*
SELECT    EMPCODE, DEPTCODE, *
    FROM    CMCUSTM
        WHERE    CUSTCODE = '2000000131'
*/
(
    p_plantcode               IN    VARCHAR2,
    p_custcode                IN    VARCHAR2,-- 전체는 '%'
    p_utdiv                   IN    VARCHAR2,-- 전체는 '%'
    p_orderdiv                IN    VARCHAR2,-- 전체는 '%'
    p_orderdate               IN    VARCHAR2,
    p_amount                  IN    FLOAT
)
RETURN FN_SLCUSTTURNE_TABLE

AS

   PRAGMA AUTONOMOUS_TRANSACTION;

   p_startdate                VARCHAR2(10); -- 작업일자 당월   1일    '2013-01-01'
   p_tomorrow                 VARCHAR2(10); -- 작업일자 다음날짜      '2013-01-21'
   p_firstdate                VARCHAR2(10); -- 작업일자 5년전 당일    '2008-01-20'
   p_yearmonth                VARCHAR2(7);  -- 작업일자 당월          '2013-01'
   p_magamyymm                VARCHAR2(7);

   ip_custcode                VARCHAR2(20) := '';
   ip_plantcode               VARCHAR2(4)  := '';
   ip_appdate                 VARCHAR2(10) := '';
   ip_acramt                  NUMBER := 0;
   ip_balance                 NUMBER := 0;
   ip_pendbillcol             NUMBER := 0;
   ip_totbalance              NUMBER := 0;

   I NUMBER := 1;

   --함수내에서 변수 저장용 변수 초기화
    SLCUSTTURNELISTRECODE FN_SLCUSTTURNE_TABLE := FN_SLCUSTTURNE_TABLE();

BEGIN

   p_startdate := SUBSTR(p_orderdate, 1, 7) || '-01' ;
   p_tomorrow  := TO_CHAR(TO_DATE(p_orderdate, 'YYYY-MM-DD')+1, 'YYYY-MM-DD') ;

   p_firstdate := TO_CHAR(ADD_MONTHS(TO_DATE(p_orderdate, 'YYYY-MM-DD'), -12*5), 'YYYY-MM-DD') ;
   p_yearmonth := SUBSTR(p_orderdate, 1, 7) ;


   -- 대상거래처 목록 ======================================================
   EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_FNSLCUSTTURNE_DUAL';

   INSERT INTO VGT.TT_FNSLCUSTTURNE_DUAL
         (SELECT C.CUSTCODE            ,
                  C.PLANTCODE          ,
                  0     AS BALANCE     ,
                  0     AS BALANCEBILL ,
                  NULL  AS YEARMONTH
             FROM CMCUSTM C
            WHERE C.PLANTCODE LIKE p_plantcode
              AND (p_custcode = '%'
               OR  C.CUSTCODE = p_custcode )
              AND (p_utdiv = '%'
               OR  C.UTDIV = p_utdiv )
         ) ;


   -- 거래처 잔고및 미결어음 ===============================================
   FOR REC IN (SELECT NVL(MAX(A.YEARMONTH), '') AS ALIAS1
                 FROM SLRESULTM A
                 JOIN VGT.TT_FNSLCUSTTURNE_DUAL C
                   ON A.CUSTCODE = C.CUSTCODE
                  AND A.PLANTCODE = C.PLANTCODE
                WHERE A.YEARMONTH < p_yearmonth
   )
   LOOP
      p_magamyymm := REC.ALIAS1 ;
   END LOOP;

   IF (p_magamyymm IS NULL ) THEN
      p_magamyymm := '2009-12' ;-- 시작일자를 체크하여야 한다.
   END IF;


   MERGE INTO VGT.TT_FNSLCUSTTURNE_DUAL TG
      USING (SELECT NVL(A.BALANCE, 0)     AS BALANCE     ,
                    NVL(A.PENDBILLCOL, 0) AS PENDBILLCOL ,
                    C.CUSTCODE                           ,
                    C.PLANTCODE                          ,
                    A.YEARMONTH
               FROM (SELECT C.CUSTCODE                         ,
                            C.PLANTCODE                        ,
                            SUM(A.BALANCE)      AS BALANCE     ,
                            SUM(A.PENDBILLCOL)  AS PENDBILLCOL ,
                            p_magamyymm         AS YEARMONTH
                       FROM SLRESULTM A
                       JOIN VGT.TT_FNSLCUSTTURNE_DUAL C
                         ON A.CUSTCODE = C.CUSTCODE
                        AND A.PLANTCODE = C.PLANTCODE
                      WHERE A.YEARMONTH = p_magamyymm
                        AND A.ORDERDIV LIKE p_orderdiv
                   GROUP BY C.CUSTCODE,C.PLANTCODE
                    ) A
               JOIN VGT.TT_FNSLCUSTTURNE_DUAL C
                 ON A.CUSTCODE = C.CUSTCODE
                AND A.PLANTCODE = C.PLANTCODE
    LEFT OUTER JOIN SLTURNCUSTM D
                 ON A.YEARMONTH = D.YEARMONTH
                AND A.CUSTCODE  = D.CUSTCODE
                AND A.PLANTCODE = D.PLANTCODE
    LEFT OUTER JOIN CMCUSTM D1
                 ON A.CUSTCODE = D1.CUSTCODE
                AND A.PLANTCODE = D1.PLANTCODE
            ) SRC
        ON (TG.CUSTCODE = SRC.CUSTCODE
       AND  TG.PLANTCODE = SRC.PLANTCODE)
      WHEN MATCHED THEN
         UPDATE SET TG.BALANCE = SRC.BALANCE ,
                    TG.PENDBILLCOL = SRC.PENDBILLCOL,
                    TG.YEARMONTH = SRC.YEARMONTH ;


   MERGE INTO VGT.TT_FNSLCUSTTURNE_DUAL TG
      USING (SELECT C.BALANCE + NVL(A.MAECHUL, 0)    AS BALANCE      ,
                    C.PENDBILLCOL + NVL(A.BILCOL, 0) AS PENDBILLCOL  ,
                    A.CUSTCODE                                       ,
                    A.PLANTCODE
               FROM (SELECT A.CUSTCODE                ,
                            A.PLANTCODE               ,
                            SUM(A.MAECHUL) AS MAECHUL ,
                            SUM(A.BILCOL)  AS BILCOL
                       FROM (SELECT C.CUSTCODE        ,
                                    C.PLANTCODE       ,
                                    (CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT
                                          WHEN A.SALDIV LIKE 'B%' THEN -B.TOTAMT
                                                                  ELSE 0
                                     END) MAECHUL     ,
                                    0     BILCOL
                               FROM SLORDM A
                               JOIN SLORDD B
                                 ON A.ORDERNO = B.ORDERNO
                                AND A.PLANTCODE = B.PLANTCODE
                               JOIN VGT.TT_FNSLCUSTTURNE_DUAL C
                                 ON A.CUSTCODE = C.CUSTCODE
                                AND A.PLANTCODE = C.PLANTCODE
                              WHERE A.APPDATE >= TO_CHAR(ADD_MONTHS(TO_DATE(p_magamyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
                                AND A.APPDATE < p_tomorrow
                                AND A.ORDERDIV LIKE p_orderdiv
                                AND A.STATEDIV = '09'
                                AND A.SALDIV IN ( SELECT DIVCODE FROM SLCONDRESULT  )
                          UNION ALL
                             SELECT C.CUSTCODE  ,
                                    C.PLANTCODE ,
                                    -A.COLAMT   ,
                                    (CASE WHEN (NVL(TRIM(A.EXPDATE), '') IS NULL OR A.COLDIV = '38' OR A.COLDIV NOT LIKE '3%' )
                                          THEN 0
                                          ELSE A.COLAMT
                                     END) BILCOL
                               FROM SLCOLM A
                               JOIN VGT.TT_FNSLCUSTTURNE_DUAL C
                                 ON A.CUSTCODE = C.CUSTCODE
                                AND A.PLANTCODE = C.PLANTCODE
                              WHERE A.APPDATE >= TO_CHAR(ADD_MONTHS(TO_DATE(p_magamyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
                                AND A.APPDATE < p_tomorrow
                                AND A.ORDERDIV LIKE p_orderdiv
                                AND A.STATEDIV = '09'
                          UNION ALL
                             SELECT C.CUSTCODE  ,
                                    C.PLANTCODE ,
                                    0 COLAMT    ,
                                    -A.COLAMT BILCOL
                               FROM SLCOLM A
                                JOIN VGT.TT_FNSLCUSTTURNE_DUAL C
                                  ON A.CUSTCODE = C.CUSTCODE
                                 AND A.PLANTCODE = C.PLANTCODE
                               WHERE A.EXPDATE >= TO_CHAR(ADD_MONTHS(TO_DATE(p_magamyymm || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
                                 AND A.EXPDATE < p_tomorrow
                                 AND A.ORDERDIV LIKE p_orderdiv
                                 AND A.STATEDIV = '09'
                                 AND A.COLDIV LIKE '3%'
                                 AND A.COLDIV <> '38'
                            ) A
                      WHERE 1 = 1
                   GROUP BY A.CUSTCODE,A.PLANTCODE
                    ) A
               JOIN VGT.TT_FNSLCUSTTURNE_DUAL C
                 ON A.CUSTCODE = C.CUSTCODE
                AND A.PLANTCODE = C.PLANTCODE
              WHERE 1 = 1
            ) SRC
         ON (TG.CUSTCODE = SRC.CUSTCODE
        AND  TG.PLANTCODE = SRC.PLANTCODE)
      WHEN MATCHED THEN
         UPDATE SET TG.BALANCE     = SRC.BALANCE,
                    TG.PENDBILLCOL = SRC.PENDBILLCOL ;


   -- 거래처 회전일 계산 ===================================================
   -- 매출일자
   -- 거래처
   -- 합계금액
   -- 누적금액
   -- 잔    고
   -- 미결어음
   -- 총 잔 고

   -- 일자별 자료생성
   EXECUTE IMMEDIATE 'TRUNCATE TABLE VGT.TT_FNSLCUSTTURNE_CUSTAL';

   INSERT INTO VGT.TT_FNSLCUSTTURNE_CUSTAL
         (SELECT A.APPDATE    ,
                 A.CUSTCODE   ,
                 A.PLANTCODE  ,
                 SUM(A.TOTAMT) TOTAMT ,
                 0 ACRAMT     ,     -- 누적금액
                 0 BALANCE    ,     -- 잔고
                 0 PENDBILLCOL,     -- 미결어음
                 0 TOTBALANCE       -- 총 잔 고
            FROM (SELECT A.APPDATE ,
                         C.CUSTCODE ,
                         C.PLANTCODE ,
                         (CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT
                               WHEN A.SALDIV LIKE 'B%' THEN -B.TOTAMT
                                                       ELSE 0
                          END) TOTAMT
                    FROM SLORDM A
                    JOIN SLORDD B
                      ON A.ORDERNO = B.ORDERNO
                     AND A.PLANTCODE = B.PLANTCODE
                    JOIN VGT.TT_FNSLCUSTTURNE_DUAL C
                      ON A.CUSTCODE = C.CUSTCODE
                     AND A.PLANTCODE = C.PLANTCODE
                   WHERE A.APPDATE >= p_firstdate
                     AND A.APPDATE < p_tomorrow
                     AND A.ORDERDIV LIKE p_orderdiv
                     AND A.SALDIV IN ( SELECT DIVCODE FROM SLCONDRESULT )  -- 주문은 실적분만
                     AND A.STATEDIV = '09'                                 -- (SL17) 매출확정
                     AND A.SALDIV LIKE 'A%'                                -- 판매만 적용
               UNION ALL
                  SELECT A.APPDATE     ,
                         C.CUSTCODE    ,
                         C.PLANTCODE   ,
                         -A.COLAMT              -- 잔고이기는 매출로 본다.
                    FROM SLCOLM A
                    JOIN VGT.TT_FNSLCUSTTURNE_DUAL C
                      ON A.CUSTCODE = C.CUSTCODE
                     AND A.PLANTCODE = C.PLANTCODE
                   WHERE A.APPDATE >= p_firstdate
                     AND A.APPDATE < p_tomorrow
                     AND A.ORDERDIV LIKE p_orderdiv
                     AND A.STATEDIV = '09'      -- (SL17) 매출확정
                     AND A.COLDIV IN ( '55' )   -- 잔고이기
                 ) A
        GROUP BY A.APPDATE, A.CUSTCODE, A.PLANTCODE
         ) ;


   --    거래처 일자별 누적
   FOR REC IN (SELECT (SELECT SUM(ST.TOTAMT)
                         FROM VGT.TT_FNSLCUSTTURNE_CUSTAL ST
                        WHERE TS.CUSTCODE = ST.CUSTCODE
                          AND TS.PLANTCODE = ST.PLANTCODE
                          AND TS.APPDATE <= ST.APPDATE
                      ) AS ACRAMT   ,
                      C.BALANCE     ,
                      C.PENDBILLCOL ,
                      (C.BALANCE + C.PENDBILLCOL) AS TOTBALANCE,
                      TS.CUSTCODE   ,
                      TS.PLANTCODE  ,
                      TS.APPDATE
                 FROM VGT.TT_FNSLCUSTTURNE_CUSTAL TS
                 JOIN VGT.TT_FNSLCUSTTURNE_DUAL C
                   ON TS.CUSTCODE = C.CUSTCODE
                  AND TS.PLANTCODE = C.PLANTCODE
                WHERE 1 = 1
   )
   LOOP
      ip_acramt       := REC.ACRAMT ;
      ip_balance      := REC.BALANCE ;
      ip_pendbillcol  := REC.PENDBILLCOL ;
      ip_totbalance   := REC.TOTBALANCE ;

      ip_custcode     := REC.CUSTCODE ;
      ip_plantcode    := REC.PLANTCODE ;
      ip_appdate      := REC.APPDATE ;

      UPDATE VGT.TT_FNSLCUSTTURNE_CUSTAL A
         SET A.ACRAMT      = ip_acramt     ,
             A.BALANCE     = ip_balance    ,
             A.PENDBILLCOL = ip_pendbillcol,
             A.TOTBALANCE  = ip_totbalance
       WHERE A.CUSTCODE  = ip_custcode
         AND A.PLANTCODE = ip_plantcode
         AND A.APPDATE   = ip_appdate ;
   END LOOP ;


   -- 거래처 회전일 계산
   FOR REC IN (SELECT TS.CUSTCODE      ,
                      TS.PLANTCODE     ,
                      (CASE WHEN ((TS.BALANCE + TS.PENDBILLCOL) - p_amount) <= 0
                            THEN 0
                            ELSE DATEDIFF('DAY', COALESCE(BT.APPDATE, p_firstdate), p_orderdate)
                       END) TURNCNT    ,
                      (CASE WHEN (TS.BALANCE - p_amount) <= 0
                            THEN 0
                            ELSE DATEDIFF('DAY', COALESCE(ST.APPDATE, p_firstdate), p_orderdate)
                       END) TURNDCCNT  ,
                      TS.BALANCE       ,
                      TS.PENDBILLCOL   ,
                      (TS.BALANCE + TS.PENDBILLCOL) TOTBALANCE
                 FROM VGT.TT_FNSLCUSTTURNE_DUAL TS
            LEFT JOIN (SELECT CUSTCODE             ,
                              PLANTCODE            ,
                              MAX(APPDATE) APPDATE ,
                              MAX(BALANCE) BALANCE
                         FROM VGT.TT_FNSLCUSTTURNE_CUSTAL
                        WHERE ACRAMT >= (BALANCE - p_amount )
                     GROUP BY CUSTCODE,PLANTCODE
                      ) ST
                   ON TS.CUSTCODE = ST.CUSTCODE
                  AND TS.PLANTCODE = ST.PLANTCODE
            LEFT JOIN (SELECT CUSTCODE             ,
                              PLANTCODE            ,
                              MAX(APPDATE)  APPDATE,
                              MAX(TOTBALANCE) TOTBALANCE
                         FROM VGT.TT_FNSLCUSTTURNE_CUSTAL
                        WHERE ACRAMT >= (TOTBALANCE - p_amount)
                     GROUP BY CUSTCODE,PLANTCODE
                      ) BT
                   ON TS.CUSTCODE = BT.CUSTCODE
                  AND TS.PLANTCODE = BT.PLANTCODE
   )
   LOOP
      SLCUSTTURNELISTRECODE.EXTEND;
      SLCUSTTURNELISTRECODE(I) := FN_SLCUSTTURNE_VARIABLE(REC.CUSTCODE, REC.PLANTCODE, REC.TURNCNT, REC.TURNDCCNT, REC.BALANCE, REC.PENDBILLCOL, REC.TOTBALANCE );
      I := I+1;
   END LOOP ;

   COMMIT;

   RETURN SLCUSTTURNELISTRECODE;

END;
/
