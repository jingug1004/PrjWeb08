CREATE VIEW V_ITEMS AS SELECT itemcode
          ,itemname
          ,unit
          ,itemcodeut hscode
          ,'01' itemtype
          ,itemdiv
          ,customcode casno
      FROM CMITEMM
    UNION ALL
    SELECT itemcode
          ,itemname
          ,unit
          ,hscode
          ,'02' itemtype
          ,stockdiv
          ,casno
      FROM gmitemm
/
