CREATE VIEW NVITEMRM AS SELECT a.itemcode itemcode
		  , --품목코드
		   a.itemdiv itemdiv
		  , --품목구분
		   b.filter1 managecode
		  , --품목구분(시스템)
		   CASE WHEN a.itemdiv IN ('03') THEN '원료의약품' ELSE b.divname END itemdivname
		  , --품목구분명(*)
		   a.itemname itemkorname
		  , --품목명(국문)
		   a.itemsname itemshortname
		  , --품목명(약명)
		   a.itemename itemengname
		  , --품목명(영문)
		   a.standarddiv standarddiv
		  , --시험규격코드
		   c.divname standarddivname
		  , --시험규격(*)
		   NVL(a.validityperiod, 0) validityperiod
		  , --유통기한(월)
		   a.unit itemunit
		  , --단위코드
		   D.divname itemunitname
		  , --단위(*)
		   a.keepingmethod keepingmethod
		  , --보관방법
		   CASE WHEN a.itemdiv IN ('03') THEN '01' ELSE a.itembranch END itembranch
		  , --품목분류코드
		   e.divname itembranchname
		  , --품목분류(*)
		   a.warehouse keepingwarehouse
		  , --보관창고코드
		   f.divname keepingwarehousename
		  , --보관창고(*)
		   NVL(a.internaldiv, '01') internaldiv
		  , --국내외구분코드(원자재/상품)
		   g.divname internaldivname
		  , --국내외구분(*)
		   a.enteringrackdiv enteringrackdiv
		  , --입고랙종류코드(원자재/상품)
		   h.divname enteringrackdivname
		  , --입고랙종류(*)
		   a.enteringrackqty enteringrackqty
		  , --입고랙적재량(원자재/상품)
		   NVL(a.testcheck, 'N') testcheck
		  , --시험여부
		   NVL(a.safeqty, 0) safestockqty
		  , --안전재고량
		   a.properstockqty properstockqty
		  , --적정재고량
		   a.buyperiod buyperiod
		  , --구매기간
		   CASE a.productdiv WHEN '90' THEN 'N' ELSE 'Y' END usediv
		  , --사용여부
		   CASE a.productdiv WHEN '90' THEN '미사용' ELSE '사용중' END usedivname
		  , --사용여부(*)
		   NULL notusediv
		  , --미사용원인코드
		   NULL notusedivname
		  , --미사용원인(*)
		   e.filter1 itemdetaildiv
		  ,CASE e.filter1 WHEN 'A' THEN '01' WHEN 'B' THEN '02' ELSE '03' END itemdetaildiv2
		  ,NVL(a.buyunit, a.unit) buyunit
		  ,a.customcode customcode
		  ,a.orderprice orderprice
		  ,a.exchangeunit exchangeunit
		  ,a.paydiv paydiv
		  ,a.offer offer
		  ,e.remark typemark
		  ,a.plantcode plantcode
		  ,a.costcenter costcenter
		  ,i.divname costcentername
		  , --코스트센터명
		   a.stockwarehousediv stockwarehousediv
		  ,j.divname stockwarehousedivname
		  ,a.testperiod
		  ,NVL(a.requestcheck, 'N') requestcheck
		  ,NVL(a.requestperiod, 0) requestperiod
		  ,NVL(specificgravity, 0) specificgravity
		  ,NVL(a.materialdiv, 'N') materialdiv
		  , --수탁자재구분
		   a.specialnote
		  , --원자재특이사항
		   a.changenote
		  , --부자재변경사항
		   a.supplycode
		  , --제조처
		   k.custname supplyname --제조처명
      , --용도코드(일반자재)
       a.managediv
       , --용도코드명(일반자재)
       m.divname as managedivname
       ,a.informaltest              --약식시험여부
       , a.itemmaker                -- 일반자재 제조처
       , a.productno                -- 일반자재 Product No
       , a.standardtext            -- 일반자재 규격
       , a.remark
	FROM   CMITEMM a
		   LEFT JOIN CMCOMMONM b
			   ON b.cmmcode = 'CMM01'
				  AND b.divcode = a.itemdiv
		   LEFT JOIN CMCOMMONM c
			   ON c.cmmcode = 'LMM06'
				  AND c.divcode = a.standarddiv
		   LEFT JOIN CMCOMMONM D
			   ON D.cmmcode = 'CMM02'
				  AND D.divcode = a.unit
		   LEFT JOIN CMCOMMONM e
			   ON e.cmmcode = 'MPM09'
				  AND e.divcode = CASE WHEN a.itemdiv IN ('03') THEN '01' ELSE a.itembranch END
		   LEFT JOIN CMCOMMONM f
			   ON f.cmmcode = 'MPM11'
				  AND f.divcode = a.warehouse
		   LEFT JOIN CMCOMMONM g
			   ON g.cmmcode = 'MPM15'
				  AND g.divcode = NVL(a.internaldiv, '01')
		   LEFT JOIN CMCOMMONM h
			   ON h.cmmcode = 'MPM08'
				  AND h.divcode = a.enteringrackdiv
		   LEFT JOIN CMCOMMONM i
			   ON i.cmmcode = 'CMM61'
				  AND i.divcode = a.costcenter
		   LEFT JOIN CommonMaster j
			   ON a.stockwarehousediv = j.divcode
				  AND j.cmmcode = 'CMM64'
       LEFT JOIN CMCOMMONM m
			   ON m.cmmcode = 'CMM74'
				  AND m.divcode = a.managediv
		   LEFT JOIN Customermaster k ON a.supplycode = k.custcode
	WHERE  a.itemdiv IN ('01', '02', '90') -- 01:원료, 02:자재, 90:일반자재
/
