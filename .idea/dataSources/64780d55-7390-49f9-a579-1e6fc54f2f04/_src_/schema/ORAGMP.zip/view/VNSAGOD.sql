CREATE VIEW VNSAGOD AS SELECT a.plantcode, -- isnull(a.plantcode, '') as plantcode
		   NVL(a.sagodate, ' ') sagodate,
		   a.custcode, -- isnull(a.custcode,'') as custcode
		   NVL(D.custname, ' ') custname,
		   NVL(e.topdeptcode, ' ') topdeptcode,
		   NVL(e.topdeptname, ' ') topdeptname,
		   NVL(e.predeptcode, ' ') predeptcode,
		   NVL(e.predeptname, ' ') predeptname,
		   NVL(a.deptcode, ' ') deptcode,
		   NVL(e.deptname, ' ') deptname,
		   NVL(e.seqtopdeptcode, ' ') seqtopdeptcode,
		   NVL(e.seqpredeptcode, ' ') seqpredeptcode,
		   NVL(e.seqdeptcode, ' ') seqdeptcode,
		   NVL(e.findname, ' ') findname,
		   NVL(f.positiondiv, ' ') positiondiv,
		   NVL(j.divname, ' ') jikwi,
		   NVL(a.empcode, ' ') empcode,
		   NVL(f.empname, ' ') empname,
		   NVL(a.sagotype, ' ') sagotype,
		   NVL(g.divname, ' ') sagotypenm,
		   NVL(a.sagodiv, ' ') sagodiv,
		   NVL(h.divname, ' ') sagodivnm,
		   NVL(a.flowdiv, ' ') flowdiv,
		   NVL(i.divname, ' ') flowdivnm,
		   NVL(b.seq, 0) seq,
		   NVL(b.processdate, ' ') processdate,
		   NVL(b.processdiv, ' ') processdiv,
		   NVL(c.divname, ' ') processdivnm,
		   NVL(b.processamt, 0) processamt,
		   NVL(b.remark, ' ') remark
	FROM   SLSAGOM a
		   LEFT JOIN SLSAGOD b ON a.custcode = b.custcode
		   LEFT JOIN CMCOMMONM c
			   ON b.processdiv = c.divcode
				  AND c.cmmcode = 'SL34' --사고처 회수구분
		   LEFT JOIN CMCUSTM D ON a.custcode = D.custcode
		   LEFT JOIN vnDEPT e ON a.deptcode = e.deptcode
		   LEFT JOIN CMEMPM f ON a.empcode = f.empcode
		   LEFT JOIN CMCOMMONM g
			   ON a.sagotype = g.divcode
				  AND g.cmmcode = 'SL07' --사고유형
		   LEFT JOIN CMCOMMONM h
			   ON a.sagodiv = h.divcode
				  AND h.cmmcode = 'CM20' --거래처상태
		   LEFT JOIN CMCOMMONM i
			   ON a.flowdiv = i.divcode
				  AND i.cmmcode = 'SL08' --사고진행상태
		   LEFT JOIN CMCOMMONM j
			   ON f.positiondiv = j.divcode
				  AND j.cmmcode = 'PS29'
/
