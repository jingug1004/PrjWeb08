CREATE VIEW B_20170801_VNINOUTORDER AS SELECT a.GB
		  ,a.plantcode
		  ,a.inoutno
		  ,a.inoutdate
		  ,a.inoutdiv
		  ,b.divname inoutdivnm
		  ,a.custcode
		  ,f.custname
		  ,a.warehouse
		  ,G.whname
		  ,a.LOCATION
		  ,a.itemcode
		  ,E.itemname
		  ,E.itemunit unit
		  ,a.lotno
		  ,a.lotdate
		  ,a.expdate
		  ,a.orderqty
		  ,a.inoutstate
		  ,c.divname inoutstatenm
		  ,a.remark
		  ,a.empcd
		  ,D.empname
		  ,G.workdiv
		  ,NVL(h.divname, ' ') workdivnm
		  ,NVL(a.unitchg, ' ') unitchg
		  ,orderno
		  ,E.barcode
		  ,E.invsetyn
	  FROM (SELECT 'out' GB
				  ,plantcode
				  ,outputno inoutno
				  ,outputdate inoutdate
				  ,outputdiv inoutdiv
				  ,custcode
				  ,warehouse
				  ,LOCATION
				  ,itemcode
				  ,lotno
				  ,lotdate
				  ,expdate
				  ,orderqty
				  ,outputstate inoutstate
				  ,remark
				  ,empcd
				  ,'N' unitchg
				  ,' ' orderno
			  FROM SLOUTORDERM
			UNION ALL
			SELECT 'in' GB
				  ,plantcode
				  ,inputno inoutno
				  ,inputdate inoutdate
				  ,inputdiv inoutdiv
				  ,custcode
				  ,warehouse
				  ,' ' LOCATION
				  ,itemcode
				  ,lotno
				  ,lotdate
				  ,expdate
				  ,orderqty
				  ,inputstate inoutstate
				  ,remark
				  ,empcd
				  ,NVL(unitchg, 'N')
				  ,' '
			  FROM SLINORDERM
			UNION
			SELECT 'in' GB
				  ,'1000' plantcode
				  , -- a.plantcode
				   packingorderno inoutno
				  ,TO_CHAR(a.workdt, 'YYYY-MM-DD') packingdate
				  ,'1B' inoutdiv
				  ,' ' custcode
				  ,'01' warehouse
				  ,' ' LOCATION
				  ,NVL(a.itemcode, ' ') itemcode
				  ,a.batchno lotno
				  ,a.lotdate
				  ,a.validityperiod expdate
				  ,NVL(a.warehousepackqty, 0) warehousepackqty
				  ,'02' inoutstate
				  ,' ' remark
				  ,' ' empcd
				  ,'N'
				  ,NVL(a.packingorderno, ' ') orderno
			  FROM vnpackingresults a
			 WHERE a.warehousestate = '01'
			UNION ALL --and a.plantcode = '1000'
			  SELECT 'in' GB
					,'1000' plantcode
					, -- a.plantcode
					 ' ' inoutno
					,a.inputenddate
					, -- 입고승일일자
					 'I05' inputdiv
					, -- 생산구분
					 ' ' custcode
					,'01' warehouse
					,' ' LOCATION
					,NVL(b.ritemcode, ' ') itemcode
					, -- 품목코드
					 a.lotno
					, -- 제조번호
					 a.lotdate
					, -- 제조일자
					 a.validityperiod
					, -- 사용기한
					 SUM(a.inputorderqty) inputorderqty
					, -- 재포장 입고수량
					 '02' inoutstate
					,' ' remark
					,' ' empcd
					,'N'
					,' ' inputorderno
				FROM PDRINPUTORDERM a --재입고(반품재입고:재생산없음)
									 LEFT JOIN PDITEMRELATION b ON a.itemcode = b.itemcode
			   WHERE a.warehousestate = '01'
			GROUP BY b.ritemcode
					,a.inputenddate
					,a.lotno
					,a.lotdate
					,a.validityperiod
					,a.inputorderqty
			UNION ALL
			SELECT 'in' GB
				  ,'1000' plantcode
				  , -- a.plantcode
				   warehousingno inoutno
				  ,TO_CHAR(a.warehousingdt, 'YYYY-MM-DD')
				  , -- 입고일시
				   'I01' inputdiv
				  , -- 생산구분
				   ' ' custcode
				  ,'01' warehouse
				  ,' ' LOCATION
				  ,b.ritemcode
				  , -- 품목코드(상품)
				   a.lotno
				  , -- 제조번호
				   a.lotdate
				  , -- 제조일자
				   a.validityperiod
				  , -- 유통기한
				   NVL(a.totalwarehousingreturnqty, 0) - NVL(samplingpackqty, 0)
				  , -- 총입고수량 - 검체량
				   '02' inoutstate
				  ,' ' remark
				  ,' ' empcd
				  ,'N'
				  ,a.warehousingno -- 입고번호
			  FROM vnProductresults a LEFT JOIN PDITEMRELATION b ON a.itemcode = b.itemcode
			 WHERE warehousestate = '01'
				   AND warehousingdiv IN ('02', '03')) a -- 입고구분(01:원자재, 02:상품, 03:위탁반제품)
		   LEFT JOIN CMCOMMONM b
			   ON a.inoutdiv = b.divcode
				  AND b.cmmcode = 'SL25'
		   LEFT JOIN CMCOMMONM c
			   ON a.inoutstate = c.divcode
				  AND c.cmmcode = 'SL70'
		   LEFT JOIN CMEMPM D ON a.empcd = D.empcode
		   LEFT JOIN CMITEMM E
			   ON a.itemcode = E.itemcode
				  AND a.plantcode = E.plantcode
		   LEFT JOIN CMCUSTM f ON a.custcode = f.custcode
		   LEFT JOIN SLSTOREHOUSEM G ON a.warehouse = G.warehouse
		   LEFT JOIN CMCOMMONM h
			   ON G.workdiv = h.divcode
				  AND h.cmmcode = 'PS26'
/
