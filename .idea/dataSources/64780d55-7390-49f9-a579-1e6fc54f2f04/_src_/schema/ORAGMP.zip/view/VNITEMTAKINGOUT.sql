CREATE VIEW VNITEMTAKINGOUT AS SELECT a.plantcode,                -- isnull(a.plantcode,'') as plantcode
            a.outdate,                      -- isnull(a.outdate,'') as outdate
            MAX (NVL (b.tradedate, ' ')) tradedate,
            a.chasoo,                          -- isnull(a.chasoo,0) as chasoo
            MAX (NVL (a.outseq, 0)) outseq,
            a.orderno,                      -- isnull(a.orderno,'') as orderno
            MAX (b.orderdate) orderdate,
            MAX (b.orderseq) orderseq,
            MAX (b.outputdiv) outputdiv,
            MAX (b.outputdivnm) outputdivnm,
            MAX (b.transferdiv) transferdiv,
            MAX (b.transfernm) transfernm,
            MAX (NVL (b.saldiv, ' ')) saldiv,
            MAX (NVL (b.saldivnm, ' ')) saldivnm,
            MIN (NVL (e.outdiv, ' ')) outdiv,
            b.custcode,                   -- isnull(a.custcode,'') as custcode
            MAX (NVL (b.custname, ' ')) custname,
            b.ecustcode,                -- ISNULL(a.ecustcode,'') as ecustcode
            MAX (NVL (b.ecustname, ' ')) ecustname,
            MAX (NVL (b.empcode, ' ')) empcode,
            MAX (NVL (b.empname, ' ')) empname,
            MAX (NVL (b.positiondiv, ' ')) positiondiv,
            MAX (NVL (b.jikwi, ' ')) jikwi,
            MAX (NVL (b.topdeptcode, ' ')) topdeptcode,
            MAX (NVL (b.topdeptname, ' ')) topdeptname,
            MAX (NVL (b.predeptcode, ' ')) predeptcode,
            MAX (NVL (b.predeptname, ' ')) predeptname,
            MAX (NVL (b.deptcode, ' ')) deptcode,
            MAX (NVL (b.deptname, ' ')) deptname,
            MAX (NVL (b.findname, ' ')) findname,
            MAX (NVL (b.addr1, ' ')) addr1,
            MAX (NVL (b.addr2, ' ')) addr2,
            MAX (NVL (b.addr, ' ')) addr,
            MAX (NVL (b.telno, ' ')) telno,
            MAX (NVL (b.POST, ' ')) POST,
            MAX (NVL (b.eaddr1, ' ')) eaddr1,
            MAX (NVL (b.eaddr2, ' ')) eaddr2,
            MAX (NVL (b.eaddr, ' ')) eaddr,
            MAX (NVL (b.etelno, ' ')) etelno,
            MAX (NVL (b.epost, ' ')) epost,
            a.itemcode,                   -- isnull(a.itemcode,'') as itemcode
            MAX (NVL (b.itemname, ' ')) itemname,
            MAX (NVL (b.unit, ' ')) unit,
            a.lotno,                            -- isnull(a.lotno,'') as lotno
            MAX (NVL (a.lotdate, ' ')) lotdate,
            MAX (NVL (a.expdate, ' ')) expdate,
            SUM (NVL (a.outqty, 0)) outqty,
            b.warehouse,                -- isnull(a.warehouse,'') as warehouse
            MAX (NVL (D.whname, ' ')) warehousenm,
            a.location,                   -- isnull(a.location,'') as location
            MAX (NVL (c.empname, ' ')) iempname,
            NVL (MAX (D.workdiv), ' ') workdiv,
            NVL (MAX (b.fixdate), ' ') fixdate,
            NVL (MAX (b.fixseq), 0) fixseq,
            NVL (MAX (b.remark), ' ') remark,
            NVL (MAX (e.boxcnt), 0) boxcnt,
            NVL (MAX (b.maker), ' ') maker,
            NVL (MAX (b.makername), ' ') makername,
            NVL (b.seq, 0) seq,
            NVL (b.FACTORYCODE, ' ') AS FACTORYCODE
       FROM SLITEMTAKINGOUT a
            LEFT JOIN vnOrderAmt b
               ON     a.orderno = b.bnorderno
                  AND a.itemcode = b.itemcode
                  AND b.saldiv LIKE 'A%'
            LEFT JOIN CMEMPM c
               ON a.iempcode = c.empcode
            LEFT JOIN SLSTOREHOUSEM D
               ON a.warehouse = D.warehouse
            LEFT JOIN SLITEMTAKINGOUTH e
               ON     a.outdate = e.outdate
                  AND a.chasoo = e.chasoo
                  AND a.orderno = e.orderno
   --====================================================================
   GROUP BY a.plantcode,
            a.outdate,
            a.chasoo,
            a.orderno,
            b.seq,
            b.custcode,
            b.ecustcode,
            a.itemcode,
            a.lotno,
            b.warehouse,
            a.location,
            b.FACTORYCODE
/
