CREATE VIEW VNPROMPRC AS SELECT a.custcode, -- isnull(a.custcode,'') as custcode    -- 거래처코드
		   NVL(c.custname, ' ') custname, -- 거래처명
		   a.ecustcode, -- isnull(a.ecustcode,'') as ecustcode   -- 간납거래처코드
		   NVL(D.custname, ' ') ecustname, -- 간납거래처명
		   NVL(a.seq, 0) seq, -- 순번
		   NVL(a.sdate, ' ') sdate, -- 시작일자
		   NVL(a.edate, ' ') edate, -- 종료일자
		   a.itemcode, -- isnull(a.itemcode,'') as itemcode    -- 제품코드
		   NVL(b.itemname, ' ') itemname, -- 제품명
		   NVL(b.itemunit, ' ') itemunit, -- 제품규격
		   NVL(a.prcrateyn, ' ') prcrateyn, -- 단가 / 할인율 구분
		   NVL(a.rounddiv, ' ') rounddiv, -- 올림구분
		   NVL(a.drugprc, 0) drugprc, -- 기준단가
		   NVL(a.befprc, 0) befprc, -- 사전단가
		   NVL(a.aftprc, 0) aftprc, -- 사후단가
		   NVL(a.befrate, 0) befrate, -- 사전단가율
		   NVL(a.aftrate, 0) aftrate, -- 사후단가율
		   NVL(a.remark, ' ') remark, -- 비고
		   NVL(c.stopdate, ' ') stopdate,
		   c.deptcode, -- ISNULL(c.deptcode,'') as deptcode
		   c.empcode, -- ISNULL(c.empcode,'') as empcode
		   NVL(c.custdiv, ' ') custdiv
	FROM   SLPROMPRCM a
		   JOIN CMITEMM b ON a.itemcode = b.itemcode
		   JOIN CMCUSTM c ON a.custcode = c.custcode
		   JOIN CMCUSTM D ON a.ecustcode = D.custcode
--				select * from SLPROMPRCM
/
