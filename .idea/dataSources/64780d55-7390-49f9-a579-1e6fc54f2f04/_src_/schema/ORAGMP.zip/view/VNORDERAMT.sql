CREATE VIEW VNORDERAMT AS SELECT a.plantcode,
          a.orderdate,
          a.orderseq,
          a.orderno,
          a.saldiv saldiv,
          a.yymm yymm,
          D.divname saldivnm,
          a.datadiv datadiv,
          E.divname datadivnm,
          a.orderdiv orderdiv,
          a.outputdiv outputdiv,
          S.divname outputdivnm,
          a.transferdiv transferdiv,
          T.divname transfernm,
          a.custcode,
          b.custname custname,
          b.addr1 addr1,
          b.addr2 addr2,
          LTRIM (b.addr1 || ' ' || b.addr2) addr,
          b.telno telno,
          b.POST POST,
          a.deptcode,
          h.predeptcode predeptcode,
          h.predeptname predeptname,
          h.topdeptcode topdeptcode,
          h.topdeptname topdeptname,
          h.findname findname,
          h.deptname deptname,
          a.empcode,
          i.positiondiv positiondiv,
          Q.divname jikwi,
          i.empname empname,
          a.ecustcode,
          c.custname ecustname,
          c.addr1 eaddr1,
          c.addr2 eaddr2,
          LTRIM (c.addr1 || ' ' || c.addr2) eaddr,
          c.telno etelno,
          c.POST epost,
          a.edeptcode,
          j.predeptcode epredeptcode,
          j.predeptname epredeptname,
          j.topdeptcode etopdeptcode,
          j.topdeptname etopdeptname,
          j.deptname edeptname,
          j.findname efindname,
          a.eempcode,
          K.positiondiv epositiondiv,
          r.divname ejikwi,
          K.empname eempname,
          a.utdiv utdiv,
          o.divname utdivnm,
          a.eutdiv eutdiv,
          P.divname eutdivnm,
          a.remark remark,
          a.seq,
          a.itemcode,
          M.itemname itemname,
          M.mitemcode mitemcode,
          NVL (M.unitqty, 0) unitqty,
          M.itemunit unit,
          a.taxdate taxdate,
          a.tradedate tradedate,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.salqty, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.salqty, 0)
             ELSE 0
          END
             salqty,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.givqty, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.givqty, 0)
             ELSE 0
          END
             givqty,
          NVL (a.drugprc, 0) drugprc,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.drugamt, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.drugamt, 0)
             ELSE 0
          END
             drugamt,
          NVL (a.makingcost, 0) makingcost,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.makingamt, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.makingamt, 0)
             ELSE 0
          END
             makingamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.makinggivamt, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.makinggivamt, 0)
             ELSE 0
          END
             makinggivamt,
          NVL (a.salprc, 0) salprc,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.salamt, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.salamt, 0)
             ELSE 0
          END
             salamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.salvat, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.salvat, 0)
             ELSE 0
          END
             salvat,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.totamt, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.totamt, 0)
             ELSE 0
          END
             totamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.befamt, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.befamt, 0)
             ELSE 0
          END
             befamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.aftamt, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.aftamt, 0)
             ELSE 0
          END
             aftamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.incamt, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.incamt, 0)
             ELSE 0
          END
             incamt,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.totdiscount, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.totdiscount, 0)
             ELSE 0
          END
             totdiscount,
          NVL (a.givrate, 0) givrate,
          NVL (a.befrate, 0) befrate,
          NVL (a.aftrate, 0) aftrate,
          NVL (a.incrate, 0) incrate,
          NVL (a.salprc1, 0) salprc1,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.salamt1, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.salamt1, 0)
             ELSE 0
          END
             salamt1,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.salvat1, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.salvat1, 0)
             ELSE 0
          END
             salvat1,
          CASE
             WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.totamt1, 0)
             WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.totamt1, 0)
             ELSE 0
          END
             totamt1,
          a.custprtyn custprtyn,
          NVL (a.outputqty, 0) outputqty,
          a.pieceyn pieceyn,
          a.enuriyn enuriyn,
          a.statediv,
          z.divname statedivnm,
          a.appdate,
          a.fixdate fixdate,
          a.fixseq fixseq,
          a.pda pda,
          M.itemdiv itemdiv,
          i.retiredt retiredt,
          K.retiredt eretiredt,
          h.deptgroup deptgroup,
          j.deptgroup edeptgroup,
          a.warehouse warehouse,
          i.workdiv workdiv,
          b.stopdate stopdate,
          c.stopdate estopdate,
          b.ascustcheck ascustcheck,
          c.ascustcheck eascustcheck,
          b.opendate opendate,
          SUBSTR (b.opendate, 0, 7) openyymm,
          c.opendate eopendate,
          M.makercode maker,
          uu.custname makername,
          a.lotno lotno,
          a.expdate expdate,
          b.areadiv areadiv,
          QQ.divname areadivnm,
          c.areadiv eareadiv,
          rr.divname eareadivnm,
          b.custdiv,
          h.seqtopdeptcode,
          h.seqpredeptcode,
          h.seqdeptcode,
          j.seqtopdeptcode eseqtopdeptcode,
          j.seqpredeptcode eseqpredeptcode,
          j.seqdeptcode eseqdeptcode,
          SS.divname orderdivnm,                           --필드추가 20131120:이세민
          i.partdiv partdic,
          a.bnorderno,
          m.plantcode as factorycode
     FROM vnOrdersEnd a
          LEFT JOIN CMCUSTM b
             ON a.custcode = b.custcode
          LEFT JOIN CMCUSTM c
             ON a.ecustcode = c.custcode
          LEFT JOIN CMCOMMONM D
             ON a.saldiv = D.divcode AND D.cmmcode = 'SL10'
          LEFT JOIN CMCOMMONM E
             ON a.datadiv = E.divcode AND E.cmmcode = 'SL11'
          LEFT JOIN vnDEPT h
             ON NVL (a.deptcode, ' ') = NVL (h.deptcode, ' ')
          LEFT JOIN CMEMPM i
             ON NVL (a.empcode, ' ') = NVL (i.empcode, ' ')
          LEFT JOIN vnDEPT j
             ON NVL (a.edeptcode, ' ') = NVL (j.deptcode, ' ')
          LEFT JOIN CMEMPM K
             ON NVL (a.eempcode, ' ') = NVL (K.empcode, ' ')
          LEFT JOIN CMITEMM M
             ON NVL (a.itemcode, ' ') = NVL (M.itemcode, ' ')
          LEFT JOIN CMCOMMONM o
             ON a.utdiv = o.divcode AND o.cmmcode = 'CM15'
          LEFT JOIN CMCOMMONM P
             ON a.eutdiv = P.divcode AND P.cmmcode = 'CM15'
          LEFT JOIN CMCOMMONM Q
             ON i.positiondiv = Q.divcode AND Q.cmmcode = 'PS29'
          LEFT JOIN CMCOMMONM r
             ON K.positiondiv = r.divcode AND r.cmmcode = 'PS29'
          LEFT JOIN CMCOMMONM S
             ON a.outputdiv = S.divcode AND S.cmmcode = 'SL12'
          LEFT JOIN CMCOMMONM T
             ON a.transferdiv = T.divcode AND T.cmmcode = 'SL14'
          LEFT JOIN CMCOMMONM z
             ON a.statediv = z.divcode AND z.cmmcode = 'SL17'
          LEFT JOIN CMCUSTM uu
             ON M.makercode = uu.custcode
          LEFT JOIN CMCOMMONM QQ
             ON b.areadiv = QQ.divcode AND QQ.cmmcode = 'CM03'
          LEFT JOIN CMCOMMONM rr
             ON c.areadiv = rr.divcode AND rr.cmmcode = 'CM03'
          LEFT JOIN CMCOMMONM SS
             ON SS.cmmcode = 'SL43' AND a.orderdiv = SS.divcode
/
