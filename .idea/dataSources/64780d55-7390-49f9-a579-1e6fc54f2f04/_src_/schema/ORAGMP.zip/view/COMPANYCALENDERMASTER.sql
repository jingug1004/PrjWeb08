CREATE VIEW COMPANYCALENDERMASTER AS SELECT '01' calendercode,
		   calymd date_,
		   PS06.divname memorialday,
		   CASE (SUBSTR(caldiv, 0, 1)) WHEN '0' THEN 'D' ELSE 'H' END daydiv,
		   AT_.value1 attendancetime, --출근시간
		   lt.value1 leavingtime, --퇴근시간
		   dt.value1 dutytime, --근무시간
		   rt.value1 resttime --휴식시간
	FROM   PSCALM a
		   LEFT JOIN CommonMaster PS06
			   ON a.caldiv = PS06.divcode
				  AND PS06.cmmcode = 'PS06'
				  AND a.caldiv != '01' --평일은 표현하지 않는다
		   LEFT JOIN ParameterManage AT_
			   ON AT_.parametercode = 'Attendancetime'
				  AND SUBSTR(a.caldiv, 0, 1) = '0'
		   LEFT JOIN ParameterManage lt
			   ON lt.parametercode = 'Leavingtime'
				  AND SUBSTR(a.caldiv, 0, 1) = '0'
		   LEFT JOIN ParameterManage dt
			   ON dt.parametercode = 'dutytime'
				  AND SUBSTR(a.caldiv, 0, 1) = '0'
		   LEFT JOIN ParameterManage rt
			   ON rt.parametercode = 'resttime'
				  AND SUBSTR(a.caldiv, 0, 1) = '0'
		   LEFT JOIN ParameterManage hdt
			   ON hdt.parametercode = 'halfduty'
				  AND SUBSTR(a.caldiv, 0, 1) != '0'
		   LEFT JOIN ParameterManage hlt
			   ON hlt.parametercode = 'halfleaving'
				  AND SUBSTR(a.caldiv, 0, 1) != '0'
	WHERE  workdiv = '01'
--daydiv = 7 -- 토
--daydiv = 1 -- 일
/
