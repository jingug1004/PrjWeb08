CREATE VIEW ESTABLISHMENTMASTER AS SELECT plantcode,
		   plantname,
		   businessno,
		   corporationno,
		   owner,
		   businessstatus,
		   businesscategory,
		   postcode,
		   address,
		   detailaddress,
		   telno,
		   faxno,
		   permissiondt,
		   closedt,
		   NULL logo
	FROM   CMPLANTM
/
