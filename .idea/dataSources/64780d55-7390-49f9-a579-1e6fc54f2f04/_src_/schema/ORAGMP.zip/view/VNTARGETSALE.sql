CREATE VIEW VNTARGETSALE AS SELECT a.plantcode,                  -- isnull(a.plantcode,'') as plantcode
          a.yearmonth,                  -- isnull(a.yearmonth,'') as yearmonth
          a.saldiv,                           -- ISNULL(a.saldiv,'') as saldiv
          CASE
             WHEN a.saldiv = 'A' THEN '판매목표'
             ELSE '수금목표'
          END
             saldivnm,
          a.deptcode,                     -- isnull(a.deptcode,'') as deptcode
          NVL (b.seqdeptcode, '') seqdeptcode,
          NVL (b.deptname, '') deptname,
          NVL (b.predeptcode, '') predeptcode,
          NVL (b.seqpredeptcode, '') seqpredeptcode,
          NVL (b.predeptname, '') predeptname,
          NVL (b.topdeptcode, '') topdeptcode,
          NVL (b.seqtopdeptcode, '') seqtopdeptcode,
          NVL (b.topdeptname, '') topdeptname,
          NVL (b.findname, '') findname,
          a.empcode,                        -- isnull(a.empcode,'') as empcode
          NVL (c.empname, '') empname,
          NVL (c.positiondiv, '') positiondiv,
          NVL (D.divname, '') jikwi,
          NVL (a.utdiv, '') utdiv,
          NVL (E.divname, '') utdivnm,
          NVL (a.targetamt, 0) targetamt,
          a.insertdt insertdt,
          NVL (a.iempcode, '') iempcode,
          a.updatedt updatedt,
          NVL (a.uempcode, '') uempcode,
          NVL (c.retiredt, '') retiredt,
          NVL (b.deptgroup, '') deptgroup,
          NVL (C.PARTDIV, '') PARTDIV
     FROM SLTARGETSALEM a
          JOIN vnDEPT b
             ON a.deptcode = b.deptcode
          JOIN CMEMPM c
             ON a.empcode = c.empcode
          LEFT JOIN CMCOMMONM D
             ON c.positiondiv = D.divcode AND D.cmmcode = 'PS29'
          LEFT JOIN CMCOMMONM E
             ON a.utdiv = E.divcode AND E.cmmcode = 'CM15'
/
