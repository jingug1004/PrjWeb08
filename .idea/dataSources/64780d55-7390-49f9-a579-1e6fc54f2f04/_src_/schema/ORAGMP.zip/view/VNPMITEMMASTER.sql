CREATE VIEW VNPMITEMMASTER AS SELECT a.itemcode itemcode, --품목코드
		   a.itemdiv itemdiv, --품목구분
		   b.managecode managecode, --품목구분(시스템)
		   b.divname itemdivname, --품목구분명(*)
		   a.itemkorname itemkorname, --품목명(국문)
		   a.itemshortname itemshortname, --품목명(약명)
		   a.itemengname itemengname, --품목명(영문)
		   a.standarddiv standarddiv, --시험규격코드
		   c.divname standarddivname, --시험규격(*)
		   a.validityperiod validityperiod, --유통기한(월)
		   a.itemunit itemunit, --단위코드
		   D.divname itemunitname, --단위(*)
		   a.keepingmethod keepingmethod, --보관방법
		   a.itembranch itembranch, --품목분류코드
		   e.divname itembranchname, --품목분류(*)
		   a.keepingwarehouse keepingwarehouse, --보관창고코드
		   f.divname keepingwarehousename, --보관창고(*)
		   a.internaldiv internaldiv, --국내외구분코드(원자재/상품)
		   g.divname internaldivname, --국내외구분(*)
		   --,a.enteringrackdiv  as enteringrackdiv  --입고랙종류코드(원자재/상품)
		   --,h.divname    as enteringrackdivname --입고랙종류(*)
		   --,a.enteringrackqty  as enteringrackqty  --입고랙적재량(원자재/상품)
		   a.testcheck testcheck, --시험여부
		   a.safestockqty safestockqty, --안전재고량
		   --,a.properstockqty  as properstockqty  --적정재고량
		   a.buyperiod buyperiod, --구매기간
		   NVL(a.usediv, 'Y') usediv, --사용여부
		   CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
		   a.notusediv notusediv, --미사용원인코드
		   i.usediv notusedivname, --미사용원인(*)
		   e.managecode itemdetaildiv,
           a.plantcode
	FROM   MaterialsMaster a
		   JOIN CommonMaster b
			   ON b.cmmcode = 'CMM01'
				  AND b.divcode = a.itemdiv
		   LEFT JOIN CommonMaster c
			   ON c.cmmcode = 'LMM06'
				  AND c.divcode = a.standarddiv
		   JOIN CommonMaster D
			   ON D.cmmcode = 'CMM02'
				  AND D.divcode = a.itemunit
		   JOIN CommonMaster e
			   ON e.cmmcode = 'MPM09'
				  AND e.divcode = a.itembranch
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'MPM11'
				  AND f.divcode = a.keepingwarehouse
		   JOIN CommonMaster g
			   ON g.cmmcode = 'MPM15'
				  AND g.divcode = a.internaldiv
		   --left join CommonMaster h on h.cmmcode = 'MPM08' and h.divcode = a.enteringrackdiv

		   LEFT JOIN CommonMaster i
			   ON i.cmmcode = 'MPM12'
				  AND i.divcode = a.notusediv
	WHERE  e.managecode = 'B'
	UNION
	--수입상품
	SELECT a.itemcode itemcode, --품목코드
		   a.itemdiv itemdiv, --품목구분
		   b.managecode managecode, --품목구분(시스템)
		   b.divname itemdivname, --품목구분명(*)
		   a.itemkorname itemkorname, --품목명(국문)
		   a.itemshortname itemshortname, --품목명(약명)
		   a.itemengname itemengname, --품목명(영문)
		   a.standarddiv standarddiv, --시험규격코드
		   c.divname standarddivname, --시험규격(*)
		   a.validityperiod validityperiod, --유통기한(월)
		   a.itemunit itemunit, --단위코드
		   fnNumericToString(a.packingcnt, 'S') || NVL(D.divname, ' ') itemunitname, --단위(*)
		   ' ' keepingmethod, --보관방법
		   a.itemdiv itembranch, --품목분류코드
		   b.divname itembranchname, --품목분류(*)
		   a.keepingwarehouse keepingwarehouse, --보관창고코드
		   f.divname keepingwarehousename, --보관창고(*)
		   a.internaldiv internaldiv, --국내외구분코드(원자재/상품)
		   g.divname internaldivname, --국내외구분(*)
		   --,a.enteringrackdiv  as enteringrackdiv  --입고랙종류코드(원자재/상품)
		   --,h.divname    as enteringrackdivname --입고랙종류(*)
		   --,a.enteringrackqty  as enteringrackqty  --입고랙적재량(원자재/상품)
		   a.testcheck testcheck, --시험여부
		   a.safestockqty safestockqty, --안전재고량
		   --,a.properstockqty  as properstockqty  --적정재고량
		   a.buyperiod buyperiod, --구매기간
		   NVL(a.usediv, 'Y') usediv, --사용여부
		   CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
		   ' ' notusediv, --미사용원인코드
		   ' ' notusedivname, --미사용원인(*)
		   'B' itemdetaildiv,
           a.plantcode
	FROM   ProductMaster a
		   JOIN CommonMaster b
			   ON b.cmmcode = 'CMM01'
				  AND b.divcode = a.itemdiv
		   LEFT JOIN CommonMaster c
			   ON c.cmmcode = 'LMM06'
				  AND c.divcode = a.standarddiv
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'CM38'
				  AND D.divcode = a.itemunit
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'MPM11'
				  AND f.divcode = a.keepingwarehouse
		   LEFT JOIN CommonMaster g
			   ON g.cmmcode = 'MPM15'
				  AND g.divcode = a.internaldiv
--left join CommonMaster h on h.cmmcode = 'MPM08' and h.divcode = a.enteringrackdiv
/
