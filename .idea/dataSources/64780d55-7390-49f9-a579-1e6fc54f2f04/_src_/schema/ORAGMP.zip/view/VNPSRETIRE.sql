CREATE VIEW VNPSRETIRE AS SELECT NVL(B.PLANTCODE, ' ') PLANTCODE,
		   XX.PLANTFULLNAME PLANTFULLNAME,
		   XX.BUSINESSNO,
		   --,row_number() OVER (PARTITION BY xx.businessno, retyear, left(a.retiredt,7) ORDER BY xx.businessno, a.empcode) as seq
		   ROW_NUMBER() OVER (PARTITION BY XX.BUSINESSNO, RETYEAR ORDER BY XX.BUSINESSNO, A.EMPCODE) SEQ,
		   NVL(A.RETYEAR, ' ') RETYEAR,
		   NVL(A.EMPCODE, ' ') EMPCODE,
		   CASE WHEN NVL((LIVEYN), 'N') <> 'Y' THEN '1' -- 거주자
													   WHEN NVL((LIVEYN), 'N') = 'Y' THEN '2' -- 비거주자
																							 ELSE '1' END LIVEYN,
		   CASE WHEN NVL((B.NATIONDIV), 'N') <> 'Y' THEN '1' -- 내국인
															WHEN NVL((B.NATIONDIV), 'N') = 'Y' THEN '9' -- 외국인
																									   ELSE '1' END NATIONYN,
		   NVL(A.RETYEAR, ' ') || '-01-01' WORKSDT, -- 귀속년도 시작일
		   CASE WHEN RETCALCDIV = '01' THEN A.RETIREDT WHEN RETCALCDIV = '02' THEN A.RETIREDT END WORKEDT, -- 귀속년도 종료일
		   NVL(B.NATIONCODE, ' ') NATIONCODE,
		   NVL(A.RETCALCDIV, ' ') RETCALCDIV, -- 퇴직정산구분(01:퇴직, 02:중간)
		   NVL(C.DIVNAME, ' ') RETCALCDIVNM,
		   NVL(A.RETDIV, ' ') RETDIV, -- 퇴직사유
		   NVL(D.DIVNAME, ' ') RETDIVNM, -- 퇴직사유
		   NVL(A.ENTERDT, ' ') ENTERDT, -- 입사일자_퇴사계산용
		   NVL(A.RETIREDT, ' ') RETIREDT, -- 퇴사일자_퇴사계산용
		   NVL(B.ENTERDT, ' ') ENTERDT1, -- 입사일자
		   NVL(B.RETIREDT, ' ') RETIREDT1, -- 퇴사일자
		   CASE WHEN NVL(PRETOTRETAMT, 0) > 0 THEN A.ENTERDT ELSE NVL(A.LAWENTERDT, ' ') END VALUEDT, -- 기산일자
		   NVL(B.PERSONID, ' ') PERSONID, -- 주민번호
		   NVL(B.TOPDEPTCODE, ' ') TOPDEPTCODE, -- 부서
		   NVL(B.PREDEPTCODE, ' ') PREDEPTCODE, -- 지점
		   B.DEPTCODE, -- 팀
		   NVL(B.TOPDEPTNAME, ' ') TOPDEPTNAME, -- 부서명
		   NVL(B.PREDEPTNAME, ' ') PREDEPTNAME, -- 지점명
		   NVL(B.DEPTNAME, ' ') DEPTNAME, -- 팀명
		   NVL(B.FINDNAME, ' ') FINDNAME, -- 부서검색
		   B.EMPNAME, -- 사원명
		   B.ADDR ADDR,
		   B.WORKDIV, -- 근무지
		   NVL(B.WORKDIVNM, ' ') WORKDIVNM, -- 근무지명
		   B.SEXDIV, -- 성별
		   NVL(B.SEXDIVNM, ' ') SEXDIVNM,
		   B.EMPDIV, -- 사원구분
		   NVL(B.EMPDIVNM, ' ') EMPDIVNM,
		   B.ENTERDIV, -- 입사구분
		   NVL(B.ENTERDIVNM, ' ') ENTERDIVNM,
		   B.POSITIONDIV, -- 직위
		   NVL(B.JIKWI, ' ') JIKWI,
		   B.GRADEDIV, -- 직급
		   NVL(B.GRADEDIVNM, ' ') GRADEDIVNM,
		   B.EMPSTEP, -- 호봉
		   B.RESPONSIBILITYDIV, -- 직종
		   NVL(B.RESPONSIBILITYDIVNM, ' ') RESPONSIBILITYDIVNM,
		   B.CLASSDIV, -- 직책
		   NVL(B.CLASSDIVNM, ' ') CLASSDIVNM,
		   NVL(A.FIXWORKYY, 0) FIXWORKYY, -- 결정근속년(전종근무처 근속월과 합산)
		   NVL(A.FIXWORKYY12, 0) FIXWORKYY12, -- 결정근속년
		   NVL(A.FIXWORKYY13, 0) FIXWORKYY13, -- 결정근속년
		   NVL(A.PRECOMPCNT, 0) PRECOMPCNT, -- 전종근무처수
		   NVL(A.CALCDATE, ' ') CALCDATE, -- 정산일자
		   NVL(A.MIDCALCDT, ' ') MIDCALCDT, -- 이전중도정산일
		   NVL(A.LAWENTERDT, ' ') LAWENTERDT, -- 법정입사일
		   NVL(A.LAWENTERDTETC, ' ') LAWENTERDTETC, -- 법정외입사일
		   NVL(A.WORKYY, 0) WORKYY, -- 근속년
		   NVL(A.WORKMM, 0) WORKMM, -- 근속월
		   NVL(A.WORKDD, 0) WORKDD, -- 근속일
		   NVL(A.LAWWORKYY, 0) LAWWORKYY, -- 법정근속년
		   --,case when datediff(month,DATEADD(day,1,case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --    else isnull(a.lawenterdt,'') end),DATEADD(day,1,a.retiredt)) / 12.0
		   --  <= floor(datediff(month,DATEADD(day,1,case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --    else isnull(a.lawenterdt,'') end),DATEADD(day,1,a.retiredt)) / 12.0)
		   --  then floor(datediff(month,DATEADD(day,1,case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --    else isnull(a.lawenterdt,'') end),DATEADD(day,1,a.retiredt)) / 12.0)
		   --  else floor(datediff(month,DATEADD(day,1,case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --    else isnull(a.lawenterdt,'') end),DATEADD(day,1,a.retiredt)) / 12.0) + 1 end as lawworkyy
		   NVL(A.LAWWORKMM, 0) LAWWORKMM, -- 법정근속월
		   --,datediff(month,DATEADD(day,1,case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end),DATEADD(day,1,a.retiredt)) as lawworkmm
		   --,case when a.enterdt <= '2012-12-31' then a.enterdt
		   --  else '' end   as enterdt12
		   --,case when a.enterdt >= '2013-01-01' then a.enterdt
		   --  else '2013-01-01' end   as enterdt13
		   --,case when case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end <= '2012-12-31' then case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end else '' end   as valuedt12
		   --,case when case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end <= '2012-12-31' and a.retiredt > '2012-12-31' then '2012-12-31'
		   --  when case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end <= '2012-12-31' then a.retiredt end    as retiredt12
		   --,case when case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end >= '2013-01-01' then case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end else '2013-01-01' end   as valuedt13
		   --,case when a.retiredt >= '2013-01-01' then a.retiredt else '' end  as retiredt13
		   --,case when case when case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end <= '2012-12-31' then case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end else '' end = '' then 0 else datediff(month,DATEADD(day,1,case when case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end <= '2012-12-31' then case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end else '' end),DATEADD(day,1,case when case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end <= '2012-12-31' and a.retiredt > '2012-12-31' then '2012-12-31'
		   --  when case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end <= '2012-12-31' then a.retiredt end)) end as lawworkmm12
		   --,case when case when case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end >= '2013-01-01' then case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end else '2013-01-01' end = '' then 0 else datediff(month,DATEADD(day,1,case when case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end >= '2013-01-01' then case when isnull(pretotretamt,0) > 0 then a.enterdt
		   --  else isnull(a.lawenterdt,'') end else '2013-01-01' end),DATEADD(day,1,case when a.retiredt >= '2013-01-01' then a.retiredt else '' end)) end as lawworkmm13
		   NVL(A.LAWWORKMM12, 0) LAWWORKMM12, -- 법정근속월
		   NVL(A.LAWWORKMM13, 0) LAWWORKMM13, -- 법정근속월
		   NVL(A.LAWWORKDD, 0) LAWWORKDD, -- 법정근속일
		   NVL(A.LAWADDMM, 0) LAWADDMM, -- 법정가산근속월
		   NVL(A.LAWADDMM12, 0) LAWADDMM12, -- 법정가산근속월
		   NVL(A.LAWADDMM13, 0) LAWADDMM13, -- 법정가산근속월
		   NVL(A.EXWORKMM, 0) EXWORKMM, -- 제외근속월
		   NVL(A.EXWORKMM12, 0) EXWORKMM12, -- 제외근속월
		   NVL(A.EXWORKMM13, 0) EXWORKMM13, -- 제외근속월
		   NVL(A.LAWDUPMM, 0) LAWDUPMM,
		   NVL(A.LAWDUPMM12, 0) LAWDUPMM12,
		   NVL(A.LAWDUPMM13, 0) LAWDUPMM13,
		   NVL(A.LAWWORKYYETC, 0) LAWWORKYYETC, -- 법정이외근속년
		   NVL(A.LAWWORKMMETC, 0) LAWWORKMMETC, -- 법정이외근속월
		   NVL(A.LAWWORKDDETC, 0) LAWWORKDDETC, -- 법정이외근속일
		   NVL(A.LAWADDMMETC, 0) LAWADDMMETC, -- 법정이외가산근속월
		   NVL(A.MIDWORKYY, 0) MIDWORKYY, -- 중간정산근속년
		   NVL(A.MIDWORKMM, 0) MIDWORKMM, -- 중간정산근속월
		   NVL(A.PREPAYAMT, 0) PREPAYAMT, -- 기지급금
		   NVL(A.RETAMT, 0) RETAMT, -- 퇴직급여
		   NVL(A.HONORRETAMT, 0) HONORRETAMT, -- 명예퇴직급여
		   NVL(A.TOTRETAMT, 0) TOTRETAMT, -- 총퇴직급여
		   NVL(A.PRETOTRETAMT, 0) PRETOTRETAMT, -- 전종퇴직급여
		   NVL(A.POTTOTRETAMT, 0) POTTOTRETAMT, -- 과세이연 퇴직급여
		   NVL(A.RETSUB, 0) RETSUB, -- 소득공제
		   NVL(A.WORKCNTSUB, 0) WORKCNTSUB, -- 근속년수공제
		   NVL(A.TOTRETSUB, 0) TOTRETSUB, -- 총소득공제
		   NVL(A.STDTAXAMT, 0) STDTAXAMT, -- 과세표준
		   NVL(A.YSTDTAXAMT, 0) YSTDTAXAMT, -- 년평균과세표준
		   NVL(A.X5YSTDTAXAMT, 0) X5YSTDTAXAMT, -- 년평균과세표준
		   NVL(A.X5YCALCTAXAMT, 0) X5YCALCTAXAMT, -- 년평균산출세액
		   NVL(A.YCALCTAXAMT, 0) YCALCTAXAMT, -- 년평균산출세액
		   NVL(A.CALCTAXAMT, 0) CALCTAXAMT, -- 산출세액
		   NVL(A.RETSUBETC, 0) RETSUBETC, -- 법정외소득공제
		   NVL(A.WORKCNTSUBETC, 0) WORKCNTSUBETC, -- 법정외근속년수공제
		   NVL(A.TOTRETSUBETC, 0) TOTRETSUBETC, -- 법정외총소득공제
		   NVL(A.STDTAXAMTETC, 0) STDTAXAMTETC, -- 법정외과세표준
		   NVL(A.YSTDTAXAMTETC, 0) YSTDTAXAMTETC, -- 법정외년평균과세표준
		   NVL(A.YCALCTAXAMTETC, 0) YCALCTAXAMTETC, -- 법정외년평균산출세액
		   NVL(A.CALCTAXAMTETC, 0) CALCTAXAMTETC, -- 법정외산출세액
		   NVL(A.YCALCTAXAMTTOT, 0) YCALCTAXAMTTOT, -- 연평균산출세액계
		   NVL(A.INCOMETAX, 0) INCOMETAX, -- 결정소득세
		   NVL(A.RESITAX, 0) RESITAX, -- 결정주민세
		   NVL(A.POTINCOMETAX, 0) POTINCOMETAX, -- 과세이연 결정소득세
		   NVL(A.POTRESITAX, 0) POTRESITAX, -- 과세이연 결정주민세
		   NVL(A.PAYINCOMETAX, 0) PAYINCOMETAX, -- 기납부소득세
		   NVL(A.PAYRESITAX, 0) PAYRESITAX, -- 기납부주민세
		   NVL(A.SUBINCOMETAX, 0) SUBINCOMETAX, -- 차감소득세
		   NVL(A.SUBRESITAX, 0) SUBRESITAX, -- 차감주민세
		   -----------과세이연------------
		   NVL(A.RETAMT1, 0) RETAMT1, -- 퇴직급여1
		   NVL(A.HONORRETAMT1, 0) HONORRETAMT1, -- 명예퇴직급여1
		   NVL(A.TOTRETAMT1, 0) TOTRETAMT1, -- 총퇴직급여1
		   NVL(A.PRETOTRETAMT1, 0) PRETOTRETAMT1, -- 전종퇴직급여1
		   NVL(A.RETSUB1, 0) RETSUB1, -- 소득공제1
		   NVL(A.WORKCNTSUB1, 0) WORKCNTSUB1, -- 근속년수공제1
		   NVL(A.TOTRETSUB1, 0) TOTRETSUB1, -- 총소득공제1
		   NVL(A.STDTAXAMT1, 0) STDTAXAMT1, -- 과세표준1
		   NVL(A.YSTDTAXAMT1, 0) YSTDTAXAMT1, -- 년평균과세표준1
		   NVL(A.X5YSTDTAXAMT1, 0) X5YSTDTAXAMT1, -- 년평균과세표준
		   NVL(A.X5YCALCTAXAMT1, 0) X5YCALCTAXAMT1, -- 년평균산출세액
		   NVL(A.YCALCTAXAMT1, 0) YCALCTAXAMT1, -- 년평균산출세액1
		   NVL(A.CALCTAXAMT1, 0) CALCTAXAMT1, -- 산출세액1
		   NVL(A.RETSUBETC1, 0) RETSUBETC1, -- 법정외소득공제1
		   NVL(A.WORKCNTSUBETC1, 0) WORKCNTSUBETC1, -- 법정외근속년수공제1
		   NVL(A.TOTRETSUBETC1, 0) TOTRETSUBETC1, -- 법정외총소득공제1
		   NVL(A.STDTAXAMTETC1, 0) STDTAXAMTETC1, -- 법정외과세표준1
		   NVL(A.YSTDTAXAMTETC1, 0) YSTDTAXAMTETC1, -- 법정외년평균과세표준1
		   NVL(A.YCALCTAXAMTETC1, 0) YCALCTAXAMTETC1, -- 법정외년평균산출세액1
		   NVL(A.CALCTAXAMTETC1, 0) CALCTAXAMTETC1, -- 법정외산출세액1
		   NVL(A.YCALCTAXAMTTOT1, 0) YCALCTAXAMTTOT1, -- 연평균산출세액계1
		   NVL(A.INCOMETAX1, 0) INCOMETAX1, -- 결정소득세1
		   NVL(A.RESITAX1, 0) RESITAX1, -- 결정주민세  1
		   NVL(A.PAYINCOMETAX1, 0) PAYINCOMETAX1, -- 기납부소득세1
		   NVL(A.PAYRESITAX1, 0) PAYRESITAX1, -- 기납부주민세1
		   NVL(A.SUBINCOMETAX1, 0) SUBINCOMETAX1, -- 차감소득세1
		   NVL(A.SUBRESITAX1, 0) SUBRESITAX1, -- 차감주민세   1
		   ---------------------------------
		   NVL(A.TOTBONUS, 0) TOTBONUS, -- 총상여금
		   NVL(A.TOTBONUS1, 0) TOTBONUS1,
		   NVL(A.TOTBONUS2, 0) TOTBONUS2,
		   NVL(A.TOTBONUS3, 0) TOTBONUS3,
		   NVL(A.TOTBONUS4, 0) TOTBONUS4,
		   NVL(A.TOTBONUS5, 0) TOTBONUS5,
		   NVL(A.TOTBONUS6, 0) TOTBONUS6,
		   NVL(A.TOTBONUS7, 0) TOTBONUS7,
		   NVL(A.TOTBONUS8, 0) TOTBONUS8,
		   NVL(A.TOTBONUS9, 0) TOTBONUS9,
		   NVL(A.TOTBONUS10, 0) TOTBONUS10,
		   NVL(A.TOTBONUS11, 0) TOTBONUS11,
		   NVL(A.TOTBONUS12, 0) TOTBONUS12,
		   NVL(A.TOTBONUS13, 0) TOTBONUS13,
		   NVL(A.TOTYEARLYAMT, 0) TOTYEARLYAMT, -- 총년차수당
		   NVL(A.STARTDATE1, ' ') STARTDATE1, -- 시작일1
		   NVL(A.ENDDATE1, ' ') ENDDATE1, -- 종료일1
		   NVL(A.WORKDAY1, 0) WORKDAY1, -- 근무일수1
		   NVL(A.BASEAMT1, 0) BASEAMT1, -- 기본급1
		   NVL(A.SUAMT1, 0) SUAMT1, -- 수당1
		   NVL(A.PAYAMT1, 0) PAYAMT1, -- 급여1
		   NVL(A.STARTDATE2, ' ') STARTDATE2,
		   NVL(A.ENDDATE2, ' ') ENDDATE2,
		   NVL(A.WORKDAY2, 0) WORKDAY2,
		   NVL(A.BASEAMT2, 0) BASEAMT2,
		   NVL(A.SUAMT2, 0) SUAMT2,
		   NVL(A.PAYAMT2, 0) PAYAMT2,
		   NVL(A.STARTDATE3, ' ') STARTDATE3,
		   NVL(A.ENDDATE3, ' ') ENDDATE3,
		   NVL(A.WORKDAY3, 0) WORKDAY3,
		   NVL(A.BASEAMT3, 0) BASEAMT3,
		   NVL(A.SUAMT3, 0) SUAMT3,
		   NVL(A.PAYAMT3, 0) PAYAMT3,
		   NVL(A.STARTDATE4, ' ') STARTDATE4,
		   NVL(A.ENDDATE4, ' ') ENDDATE4,
		   NVL(A.WORKDAY4, 0) WORKDAY4,
		   NVL(A.BASEAMT4, 0) BASEAMT4,
		   NVL(A.SUAMT4, 0) SUAMT4,
		   NVL(A.PAYAMT4, 0) PAYAMT4,
		   --,isnull(su1code ,'')  as su1code
		   --,isnull(su1.sugoname,'') as su1name
		   --,isnull(su2code ,'')  as su2code
		   --,isnull(su2.sugoname,'') as su2name
		   --,isnull(su3code ,'')  as su3code
		   --,isnull(su3.sugoname,'') as su3name
		   --,isnull(su4code ,'')  as su4code
		   --,isnull(su4.sugoname,'') as su4name
		   --,isnull(su5code ,'')  as su5code
		   --,isnull(su5.sugoname,'') as su5name
		   --,isnull(su6code ,'')  as su6code
		   --,isnull(su6.sugoname,'') as su6name
		   --,isnull(su7code ,'')  as su7code
		   --,isnull(su7.sugoname,'') as su7name
		   --,isnull(su8code ,'')  as su8code
		   --,isnull(su8.sugoname,'') as su8name
		   --,isnull(su9code ,'')  as su9code
		   --,isnull(su9.sugoname,'') as su9name
		   --,isnull(su10code ,'') as su10code
		   --,isnull(su10.sugoname,'') as su10name
		   --,isnull(su11code ,'') as su11code
		   --,isnull(su11.sugoname,'') as su11name
		   --,isnull(su12code ,'') as su12code
		   --,isnull(su12.sugoname,'') as su12name
		   --,isnull(su13code ,'') as su13code
		   --,isnull(su13.sugoname,'') as su13name
		   --,isnull(su14code ,'') as su14code
		   --,isnull(su14.sugoname,'') as su14name
		   --,isnull(su15code ,'') as su15code
		   --,isnull(su15.sugoname,'') as su15name
		   NVL(SU1CODE, ' ') SU1CODE,
		   NVL(SU2CODE, ' ') SU2CODE,
		   NVL(SU3CODE, ' ') SU3CODE,
		   NVL(SU4CODE, ' ') SU4CODE,
		   NVL(SU5CODE, ' ') SU5CODE,
		   NVL(SU6CODE, ' ') SU6CODE,
		   NVL(SU7CODE, ' ') SU7CODE,
		   NVL(SU8CODE, ' ') SU8CODE,
		   NVL(SU9CODE, ' ') SU9CODE,
		   NVL(SU10CODE, ' ') SU10CODE,
		   NVL(SU11CODE, ' ') SU11CODE,
		   NVL(SU12CODE, ' ') SU12CODE,
		   NVL(SU13CODE, ' ') SU13CODE,
		   NVL(SU14CODE, ' ') SU14CODE,
		   NVL(SU15CODE, ' ') SU15CODE,
		   NVL(SU16CODE, ' ') SU16CODE,
		   NVL(SU17CODE, ' ') SU17CODE,
		   NVL(SU18CODE, ' ') SU18CODE,
		   NVL(SU19CODE, ' ') SU19CODE,
		   NVL(SU20CODE, ' ') SU20CODE,
		   NVL(SU21CODE, ' ') SU21CODE,
		   '직무수당' SU1NAME,
		   '시간외수당' SU2NAME,
		   '능력수당' SU3NAME,
		   '근속수당' SU4NAME,
		   '경력수당' SU5NAME,
		   '차량유지비' SU6NAME,
		   '식대' SU7NAME,
		   '보육수당' SU8NAME,
		   '연구수당' SU9NAME,
		   '성과수당' SU10NAME,
		   '당직수당' SU11NAME,
		   '면허수당' SU12NAME,
		   '야간근로수당' SU13NAME,
		   '인센티브' SU14NAME,
		   '활동비' SU15NAME,
		   '기타수당' SU16NAME,
		   '휴일근로수당' SU17NAME,
		   '휴일연장수당' SU18NAME,
		   '휴일야간수당' SU19NAME,
		   '결근' SU20NAME,
		   '조퇴' SU21NAME,
		   NVL(A.SU1AMT1, 0) SU1AMT1,
		   NVL(A.SU1AMT2, 0) SU1AMT2,
		   NVL(A.SU1AMT3, 0) SU1AMT3,
		   NVL(A.SU1AMT4, 0) SU1AMT4,
		   NVL(A.SU2AMT1, 0) SU2AMT1,
		   NVL(A.SU2AMT2, 0) SU2AMT2,
		   NVL(A.SU2AMT3, 0) SU2AMT3,
		   NVL(A.SU2AMT4, 0) SU2AMT4,
		   NVL(A.SU3AMT1, 0) SU3AMT1,
		   NVL(A.SU3AMT2, 0) SU3AMT2,
		   NVL(A.SU3AMT3, 0) SU3AMT3,
		   NVL(A.SU3AMT4, 0) SU3AMT4,
		   NVL(A.SU4AMT1, 0) SU4AMT1,
		   NVL(A.SU4AMT2, 0) SU4AMT2,
		   NVL(A.SU4AMT3, 0) SU4AMT3,
		   NVL(A.SU4AMT4, 0) SU4AMT4,
		   NVL(A.SU5AMT1, 0) SU5AMT1,
		   NVL(A.SU5AMT2, 0) SU5AMT2,
		   NVL(A.SU5AMT3, 0) SU5AMT3,
		   NVL(A.SU5AMT4, 0) SU5AMT4,
		   NVL(A.SU6AMT1, 0) SU6AMT1,
		   NVL(A.SU6AMT2, 0) SU6AMT2,
		   NVL(A.SU6AMT3, 0) SU6AMT3,
		   NVL(A.SU6AMT4, 0) SU6AMT4,
		   NVL(A.SU7AMT1, 0) SU7AMT1,
		   NVL(A.SU7AMT2, 0) SU7AMT2,
		   NVL(A.SU7AMT3, 0) SU7AMT3,
		   NVL(A.SU7AMT4, 0) SU7AMT4,
		   NVL(A.SU8AMT1, 0) SU8AMT1,
		   NVL(A.SU8AMT2, 0) SU8AMT2,
		   NVL(A.SU8AMT3, 0) SU8AMT3,
		   NVL(A.SU8AMT4, 0) SU8AMT4,
		   NVL(A.SU9AMT1, 0) SU9AMT1,
		   NVL(A.SU9AMT2, 0) SU9AMT2,
		   NVL(A.SU9AMT3, 0) SU9AMT3,
		   NVL(A.SU9AMT4, 0) SU9AMT4,
		   NVL(A.SU10AMT1, 0) SU10AMT1,
		   NVL(A.SU10AMT2, 0) SU10AMT2,
		   NVL(A.SU10AMT3, 0) SU10AMT3,
		   NVL(A.SU10AMT4, 0) SU10AMT4,
		   NVL(A.SU11AMT1, 0) SU11AMT1,
		   NVL(A.SU11AMT2, 0) SU11AMT2,
		   NVL(A.SU11AMT3, 0) SU11AMT3,
		   NVL(A.SU11AMT4, 0) SU11AMT4,
		   NVL(A.SU12AMT1, 0) SU12AMT1,
		   NVL(A.SU12AMT2, 0) SU12AMT2,
		   NVL(A.SU12AMT3, 0) SU12AMT3,
		   NVL(A.SU12AMT4, 0) SU12AMT4,
		   NVL(A.SU13AMT1, 0) SU13AMT1,
		   NVL(A.SU13AMT2, 0) SU13AMT2,
		   NVL(A.SU13AMT3, 0) SU13AMT3,
		   NVL(A.SU13AMT4, 0) SU13AMT4,
		   NVL(A.SU14AMT1, 0) SU14AMT1,
		   NVL(A.SU14AMT2, 0) SU14AMT2,
		   NVL(A.SU14AMT3, 0) SU14AMT3,
		   NVL(A.SU14AMT4, 0) SU14AMT4,
		   NVL(A.SU15AMT1, 0) SU15AMT1,
		   NVL(A.SU15AMT2, 0) SU15AMT2,
		   NVL(A.SU15AMT3, 0) SU15AMT3,
		   NVL(A.SU15AMT4, 0) SU15AMT4,
		   NVL(A.SU16AMT1, 0) SU16AMT1,
		   NVL(A.SU16AMT2, 0) SU16AMT2,
		   NVL(A.SU16AMT3, 0) SU16AMT3,
		   NVL(A.SU16AMT4, 0) SU16AMT4,
		   NVL(A.SU17AMT1, 0) SU17AMT1,
		   NVL(A.SU17AMT2, 0) SU17AMT2,
		   NVL(A.SU17AMT3, 0) SU17AMT3,
		   NVL(A.SU17AMT4, 0) SU17AMT4,
		   NVL(A.SU18AMT1, 0) SU18AMT1,
		   NVL(A.SU18AMT2, 0) SU18AMT2,
		   NVL(A.SU18AMT3, 0) SU18AMT3,
		   NVL(A.SU18AMT4, 0) SU18AMT4,
		   NVL(A.SU19AMT1, 0) SU19AMT1,
		   NVL(A.SU19AMT2, 0) SU19AMT2,
		   NVL(A.SU19AMT3, 0) SU19AMT3,
		   NVL(A.SU19AMT4, 0) SU19AMT4,
		   NVL(A.SU20AMT1, 0) SU20AMT1,
		   NVL(A.SU20AMT2, 0) SU20AMT2,
		   NVL(A.SU20AMT3, 0) SU20AMT3,
		   NVL(A.SU20AMT4, 0) SU20AMT4,
		   NVL(A.SU21AMT1, 0) SU21AMT1,
		   NVL(A.SU21AMT2, 0) SU21AMT2,
		   NVL(A.SU21AMT3, 0) SU21AMT3,
		   NVL(A.SU21AMT4, 0) SU21AMT4,
		   NVL(A.WORKDAY, 0) WORKDAY, -- 근무일계
		   NVL(A.BASEAMT, 0) BASEAMT, -- 기본급계
		   NVL(A.SUAMT, 0) SUAMT, -- 수당계
		   NVL(A.TOTPAY, 0) TOTPAY, -- 총급여
		   NVL(A.BONUSAMT, 0) BONUSAMT, -- 계산상여
		   NVL(A.YEARLYAMT, 0) YEARLYAMT, -- 계산년차
		   NVL(A.PAYAMT, 0) PAYAMT, -- 계산급여
		   NVL(A.AVGPAY, 0) AVGPAY, -- 평균임금
		   NVL(A.RETIREPAY, 0) RETIREPAY, -- 차감지급액
		   NVL(A.STATEDIV, ' ') STATEDIV, -- 상태
		   NVL(E.DIVNAME, ' ') STATEDIVNM, -- 상태명
		   NVL(A.REMARK, ' ') REMARK,
		   NVL(A.POTYN, 'N') POTYN,
		   NVL(A.DIRECTORYN, 'N') DIRECTORYN,
		   NVL(A.DIRECTORRETAMT, 0) DIRECTORRETAMT,
		   NVL(AA.POTPOWNERNM, ' ') POTPOWNERNM,
		   NVL(AA.POTBUSINESSNO, ' ') POTBUSINESSNO,
		   NVL(AA.POTPAYACCNO, ' ') POTPAYACCNO,
		   NVL(AA.POTLIMITDATE, ' ') POTLIMITDATE,
		   NVL(AA.RETPENACCNO, ' ') RETPENACCNO,
		   NVL(AA.RETPENDIV, ' ') RETPENDIV,
		   NVL(AA.PAYACCNO, ' ') PAYACCNO,
		   --,ISNULL(b.restsdt,'') as restsdt
		   --,ISNULL(b.restedt,'') as restedt
		   CASE
			   WHEN NVL(AA.RETPENSYN, 'N') = 'Y'
					AND NVL(RETPENDIV, ' ') = 'DB'
			   THEN
				   NVL(RETPENSSDATE, ' ')
			   ELSE
				   ' '
		   END
			   DBRETPENSSDATE,
		   -- 퇴직연금 사용
		   NVL(A.MIDGIVEDT, ' ') MIDGIVEDT,
		   NVL(AA.PAYBANKDIV, ' ') PAYBANKDIV,
		   NVL(AA.PAYACCEMPNM, ' ') PAYACCEMPNM,
		   --2016.1.1.이후 계산
		   NVL(A.changeamt, 0) changeamt, --환산급여
		   NVL(A.changeamtgo, 0) changeamtgo, --환산급여별공제
		   NVL(A.stdtaxamt16, 0) stdtaxamt16, --퇴직소득과세표준
		   NVL(A.ystdtaxamt16, 0) ystdtaxamt16, --환산산출세액
		   NVL(A.calctaxamt16, 0) calctaxamt16, --산출세액
		   NVL(A.tcalctaxamt, 0) tcalctaxamt --특례적용산출세액
	FROM   PSRETIREM A
		   LEFT JOIN PSEMPPAYBASEM AA ON A.EMPCODE = AA.EMPCODE
		   JOIN VNEMP B ON A.EMPCODE = B.EMPCODE
		   JOIN CMCOMMONM C
			   ON A.RETCALCDIV = C.DIVCODE
				  AND C.CMMCODE = 'PS71'
		   JOIN CMCOMMONM D
			   ON A.RETDIV = D.DIVCODE
				  AND D.CMMCODE = 'PS70'
		   LEFT JOIN CMCOMMONM E
			   ON A.STATEDIV = E.DIVCODE
				  AND E.CMMCODE = 'PS72'
		   JOIN CMPLANTM XX ON A.PLANTCODE = XX.PLANTCODE
--,PSSUGOITEMM
--            su1code
--            ,su2code
--            ,su3code
--            ,su4code
--            ,su5code
--            ,su6code
--            ,su7code
--            ,su8code
--            ,su9code
--            ,su10code
--            ,su11code
--            ,su12code
--            ,su13code
--            ,su14code
--            ,su15code
--    from    PSRETIREM
--)
--left join PSSUGOITEMM as su1
--    on a.su1code = su1.sugocode
--    and su1.sugodiv = 'su'
--left join PSSUGOITEMM as su2
--    on a.su2code = su2.sugocode
--    and su2.sugodiv = 'su'
--left join PSSUGOITEMM as su3
--    on a.su3code = su3.sugocode
--    and su3.sugodiv = 'su'
--left join PSSUGOITEMM as su4
--    on a.su4code = su4.sugocode
--    and su4.sugodiv = 'su'
--left join PSSUGOITEMM as su5
--    on a.su5code = su5.sugocode
--    and su5.sugodiv = 'su'
--left join PSSUGOITEMM as su6
--    on a.su6code = su6.sugocode
--    and su6.sugodiv = 'su'
--left join PSSUGOITEMM as su7
--    on a.su7code = su7.sugocode
--    and su7.sugodiv = 'su'
--left join PSSUGOITEMM as su8
--    on a.su8code = su8.sugocode
--    and su8.sugodiv = 'su'
--left join PSSUGOITEMM as su9
--    on a.su9code = su9.sugocode
--    and su9.sugodiv = 'su'
--left join PSSUGOITEMM as su10
--    on a.su10code = su10.sugocode
--    and su10.sugodiv = 'su'
--left join PSSUGOITEMM as su11
--    on a.su11code = su11.sugocode
--    and su11.sugodiv = 'su'
--left join PSSUGOITEMM as su12
--    on a.su12code = su12.sugocode
--    and su12.sugodiv = 'su'
--left join PSSUGOITEMM as su13
--    on a.su13code = su13.sugocode
--    and su13.sugodiv = 'su'
--left join PSSUGOITEMM as su14
--    on a.su14code = su14.sugocode
--    and su14.sugodiv = 'su'
--left join PSSUGOITEMM as su15
--    on a.su15code = su15.sugocode
--    and su15.sugodiv = 'su'
/
