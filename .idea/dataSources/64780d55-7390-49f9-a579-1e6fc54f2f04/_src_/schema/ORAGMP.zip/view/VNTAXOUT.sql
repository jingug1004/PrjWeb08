CREATE VIEW VNTAXOUT AS SELECT	 a.plantcode,
			 tt.outdate,
			 a.orderdate orderdate,
			 a.orderseq orderseq,
			 a.orderno,
			 a.appdate appdate,
			 NVL(MAX(a.orderdiv), '') orderdiv,
			 CASE WHEN NVL(MAX(a.orderdiv), '') = '1' THEN '급여' ELSE '비급여' END orderdivnm,
			 NVL(MAX(pp.plantfullname), '') plantname,
			 NVL(MAX(pp.businessno), '') pbusinessno,
			 NVL(MAX(pp.owner), '') powner,
			 NVL(MAX(pp.address), '') paddr1,
			 NVL(MAX(pp.detailaddress), '') paddr2,
			 NVL(MAX(pp.telno), '') ptelno,
			 NVL(MAX(pp.postcode), '') ppostcode,
			 SUBSTR(a.orderno, 1, 8) || '-' || SUBSTR(a.orderno, 9, 4) ordno,
			 NVL(MAX(a.saldiv), '') saldiv,
			 NVL(MAX(b.divname), '') saldivnm,
			 NVL(MAX(a.outputdiv), '') outputdiv,
			 NVL(MAX(h.divname), '') outputdivnm,
			 NVL(MAX(a.transferdiv), '') transferdiv,
			 NVL(MAX(i.divname), '') transferdivnm,
			 NVL(MAX(a.custcode), '') custcode,
			 NVL(MAX(c.custname), '') custname,
			 NVL(MAX(c.custcondition), '') custcondition,
			 NVL(MAX(c.custitem), '') custitem,
			 NVL(MAX(c.businessno), '') businessno,
			 NVL(MAX(c.ceoname), '') ceoname,
			 NVL(MAX(c.telno), '') telno,
			 NVL(MAX(c.faxno), '') faxno,
			 NVL(MAX(c.POST), '') POST,
			 NVL(MAX(c.addr1), '') addr1,
			 NVL(MAX(c.addr2), '') addr2,
			 NVL(MAX(c.addr1 || ' ' || c.addr2), '') addr,
			 NVL(MAX(c.custmajorcode), '') custmajorcode,
			 NVL(MAX(a.utdiv), '') utdiv,
			 NVL(MAX(a.ecustcode), '') ecustcode,
			 NVL(MAX(o.custname), '') ecustname,
			 NVL(MAX(o.addr1 || ' ' || o.addr2), '') eaddr,
			 NVL(MAX(M.divname), '') utdivnm,
			 NVL(MAX(a.deptcode), '') deptcode,
			 NVL(MAX(D.deptname), '') deptname,
			 NVL(MAX(E.deptcode), '') predeptcode,
			 NVL(MAX(E.deptname), '') predeptname,
			 NVL(MAX(f.deptcode), '') topdeptcode,
			 NVL(MAX(f.deptname), '') topdeptname,
			 NVL(MAX(G.positiondiv), '') positiondiv,
			 NVL(MAX(a.empcode), '') empcode,
			 NVL(MAX(G.empname), '') empname,
			 NVL(MAX(j.divname), '') jikwi,
			 NVL(MAX(G.phone), '') phone,
			 NVL(MAX(a.statediv), '') statediv,
			 NVL(MAX(K.divname), '') statedivnm,
			 NVL(MAX(z.itemcode), '') itemcode,
			 NVL(MAX(l.itemname), '') itemname,
			 NVL(MAX(L.itemunit), '') unit,
			 NVL(COUNT(z.itemcode), 0) itemcnt,
			 CASE WHEN NVL(COUNT(z.itemcode), 0) = 1 THEN NVL(MAX(l.itemname || ' ' || l.itemunit), '') WHEN NVL(COUNT(z.itemcode), '') > 1 THEN NVL(MAX(l.itemname || ' ' || l.itemunit), '') || ' 외' || TO_CHAR(COUNT(z.itemcode) - 1) || '건' END itemnm,
			 NVL(SUM(z.salamt), 0) salamt,
			 NVL(SUM(z.salvat), 0) salvat,
			 NVL(SUM(z.totamt), 0) totamt,
			 NVL(MAX(a.taxmanagedate), '') taxmanagedate,
			 NVL(MAX(a.trademanagedate), '') trademanagedate,
			 NVL(MAX(a.taxdate), '') taxdate,
			 NVL(MAX(a.tradedate), '') tradedate,
			 CASE WHEN NVL(MAX(a.taxmanagedate), '') IS NULL THEN '미발행' WHEN NVL(MAX(a.taxmanagedate), '') IS NOT NULL THEN '발행' ELSE '미발행' END taxmngprintgb,
			 CASE WHEN NVL(MAX(a.trademanagedate), '') IS NULL THEN '미발행' WHEN NVL(MAX(a.trademanagedate), '') IS NOT NULL THEN '발행' ELSE '미발행' END trademngprintgb,
			 CASE WHEN NVL(MAX(a.taxdate), '') IS NULL THEN '미발행' WHEN NVL(MAX(a.taxdate), '') IS NOT NULL THEN '발행' ELSE '미발행' END taxprintgb,
			 CASE WHEN NVL(MAX(a.tradedate), '') IS NULL THEN '미발행' WHEN NVL(MAX(a.tradedate), '') IS NOT NULL THEN '발행' ELSE '미발행' END tradeprintgb,
			 NVL(SUM(z.salqty + z.givqty), 0) salqty,
			 NVL(SUM(z.outputqty), 0) outputqty,
			 SUBSTR('          ' || TO_CHAR(TO_NUMBER(SUM(z.salamt))), -10, 10) amt_print,
			 SUBSTR('         ' || TO_CHAR(TO_NUMBER(SUM(z.salvat))), -9, 9) vat_print,
			 SUBSTR(MAX(a.appdate), 1, 4) YYYY,
			 SUBSTR(MAX(a.appdate), 1, 2) yy1,
			 SUBSTR(MAX(a.appdate), 3, 2) yy2,
			 SUBSTR(MAX(a.appdate), 6, 2) MM,
			 SUBSTR(MAX(a.appdate), 9, 2) DD,
			 10 - LENGTH(TO_NUMBER(SUM(z.salamt))) blank_cnt,
			 MAX(a.remark) remark,
			 NVL(MAX(a.fixdate), '') fixdate,
			 NVL(MAX(a.fixseq), 0) fixseq,
			 NVL(MAX(a.warehouse), '') warehouse,
			 NVL(MAX(tt.paydiv), '') paydiv,
			 NVL(MAX(QQ.divname), '') paydivnm,
			 tt.chasoo,
             max(l.plantcode) factorycode
	FROM	 SLORDM a
			 LEFT JOIN SLITEMTAKINGOUTH tt ON a.bnorderno = tt.orderno
			 JOIN SLORDD z ON a.orderno = z.orderno
			 LEFT JOIN CMCOMMONM b
				 ON a.saldiv = b.divcode
					AND b.cmmcode = 'SL10'
			 JOIN CMCUSTM c ON a.custcode = c.custcode
			 JOIN CMDEPTM D ON a.deptcode = D.deptcode
			 LEFT JOIN CMDEPTM E ON D.predeptcode = E.deptcode
			 LEFT JOIN CMDEPTM f ON E.predeptcode = f.deptcode
			 JOIN CMEMPM G ON a.empcode = G.empcode
			 LEFT JOIN CMCOMMONM j
				 ON G.positiondiv = j.divcode
					AND j.cmmcode = 'PS29'
			 LEFT JOIN CMCOMMONM h
				 ON a.outputdiv = h.divcode
					AND h.cmmcode = 'SL12'
			 LEFT JOIN CMCOMMONM i
				 ON a.transferdiv = i.divcode
					AND i.cmmcode = 'SL14'
			 LEFT JOIN CMCOMMONM K
				 ON a.statediv = K.divcode
					AND K.cmmcode = 'SL17'
			 LEFT JOIN CMITEMM l ON z.itemcode = l.itemcode
			 LEFT JOIN CMCOMMONM M
				 ON a.utdiv = M.divcode
					AND M.cmmcode = 'CM15'
			 LEFT JOIN CMCUSTM o ON a.ecustcode = o.custcode
			 JOIN CMPLANTM pp ON a.plantcode = pp.plantcode
			 LEFT JOIN CMCOMMONM QQ
				 ON tt.paydiv = QQ.divcode
					AND QQ.cmmcode = 'SL79'
	GROUP BY a.plantcode,
			 tt.outdate,
			 a.orderno,
			 tt.chasoo,
			 a.appdate,
			 a.orderdate,
			 a.orderseq
/
