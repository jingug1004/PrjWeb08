CREATE VIEW VNSLCOLDIS AS SELECT NVL(a.plantcode, ' ') plantcode,
		   NVL(a.colno, ' ') colno,
		   NVL(a.coldiv, ' ') coldiv,
		   NVL(e.divname, ' ') coldivnm,
		   NVL(a.appdate, ' ') appdate,
		   NVL(a.coldate, ' ') coldate,
		   NVL(a.custcode, ' ') custcode,
		   NVL(b.custname, ' ') custname,
		   NVL(c.topdeptcode, ' ') topdeptcode,
		   NVL(c.topdeptname, ' ') topdeptname,
		   NVL(c.predeptcode, ' ') predeptcode,
		   NVL(c.predeptname, ' ') predeptname,
		   NVL(a.deptcode, ' ') deptcode,
		   NVL(c.deptname, ' ') deptname,
		   NVL(c.findname, ' ') findname,
		   NVL(a.empcode, ' ') empcode,
		   NVL(D.empname, ' ') empname,
		   NVL(D.positiondiv, ' ') positiondiv,
		   NVL(D.jikwi, ' ') jikwi,
		   NVL(a.ecustcode, ' ') ecustcode,
		   NVL(f.custname, ' ') ecustname,
		   NVL(g.topdeptcode, ' ') etopdeptcode,
		   NVL(g.topdeptname, ' ') etopdeptname,
		   NVL(g.predeptcode, ' ') epredeptcode,
		   NVL(g.predeptname, ' ') epredeptname,
		   NVL(a.edeptcode, ' ') edeptcode,
		   NVL(g.deptname, ' ') edeptname,
		   NVL(g.findname, ' ') efindname,
		   NVL(a.eempcode, ' ') eempcode,
		   NVL(h.empname, ' ') eempname,
		   NVL(h.positiondiv, ' ') epositiondiv,
		   NVL(h.jikwi, ' ') ejikwi,
		   NVL(a.balance, 0) balance,
		   NVL(a.turncnt, 0) turncnt,
		   NVL(a.colamt, 0) colamt,
		   NVL(a.disamt, 0) disamt,
		   NVL(a.salamt30, 0) salamt30,
		   NVL(a.fixamt30, 0) fixamt30,
		   NVL(a.disamt30, 0) disamt30,
		   NVL(a.salamt60, 0) salamt60,
		   NVL(a.fixamt60, 0) fixamt60,
		   NVL(a.disamt60, 0) disamt60,
		   NVL(a.salamt90, 0) salamt90,
		   NVL(a.fixamt90, 0) fixamt90,
		   NVL(a.disamt90, 0) disamt90,
		   NVL(a.salamt120, 0) salamt120,
		   NVL(a.fixamt120, 0) fixamt120,
		   NVL(a.orderno, ' ') orderno,
		   --NVL(a.insertdt, ' ') insertdt,
		   NVL(a.iempcode, ' ') iempcode,
		  -- NVL(a.updatedt, ' ') updatedt,
		   NVL(a.uempcode, ' ') uempcode
	FROM   SLCOLDISM a
		   LEFT JOIN CMCUSTM b ON a.custcode = b.custcode
		   LEFT JOIN vnDEPT c ON a.deptcode = c.deptcode
		   LEFT JOIN vnEMP D ON a.empcode = D.empcode
		   LEFT JOIN CMCOMMONM e
			   ON e.divcode = a.coldiv
				  AND e.cmmcode = 'SL18'
		   LEFT JOIN CMCUSTM f ON a.ecustcode = f.custcode
		   LEFT JOIN vnDEPT g ON a.edeptcode = g.deptcode
		   LEFT JOIN vnEMP h ON a.eempcode = h.empcode
/
