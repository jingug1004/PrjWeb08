CREATE VIEW NVSTOCKITEMAPI AS SELECT a.itemcode --품목코드
	  ,a.itemkorname --품목명
	  ,a.warehousingdate --입고일자
	  ,a.warehousingno --입고번호
	  ,a.manufacturecode --제조처코드
	  ,a.lotno --제조번호
	  ,a.lotdate --제조일자
	  ,a.validityperiod --유효일자
	  ,a.retestdate --재시험기한
	  ,a.warehousingstate --입고상태
	  ,a.itemunit --단위
	  ,a.itemunitname
	  ,a.testno --시험번호
	  ,a.classifyjudgerate cjrate --시험함량/역가
	  ,a.classifyjudgerateB cjrateB --시험함량/역가B
	  ,a.itemdiv --원부자재구분
	  ,a.itemdivname
	  ,a.itembranch --원부자재분류
	  ,a.itembranchname
	  ,a.testresult --시험결과(Y/N/Blank:적합/부적합/진행)
	  ,a.retestno
	  ,a.totalwarehousingqty inputqty --입고수량
	  ,NVL(b.inputetcqty, 0) inputetcqty --기타입고량
	  ,NVL(c.outqty, 0) + NVL(g.outqty, 0) outqty --일반출고량
	  ,NVL(e.weighinguseqty, 0) weighinguseqty --칭량작업량
	  ,NVL(c.outwaitqty, 0) + NVL(g.outwaitqty, 0) outwaitqty --출고대기량
	  ,NVL(d.outputetcqty, 0) + NVL(f.returnqty, 0) + NVL(h.outqty, 0) -- outputetcqty --기타출고량(폐기포함)
																	  + NVL(it.testqty, 0) outputetcqty --기타출고량(폐기포함)
	  ,NVL(i.unuseqty, 0) unuseqty --불용량
	  ,NVL(gg.orderqty, 0) orderqty --예약량
	  ,a.totalwarehousingqty + NVL(b.inputetcqty, 0) - NVL(c.outqty, 0) - NVL(d.outputetcqty, 0) - NVL(f.returnqty, 0) - NVL(g.outqty, 0) - NVL(h.outqty, 0) - NVL(i.unuseqty, 0) - NVL(it.testqty, 0)
		   asstock --가용재고
	  ,a.totalwarehousingqty + NVL(b.inputetcqty, 0) - NVL(c.outqty, 0) - NVL(d.outputetcqty, 0) - NVL(f.returnqty, 0) - NVL(g.outqty, 0) - NVL(h.outqty, 0) - NVL(it.testqty, 0) nowstock
	  ,  a.totalwarehousingqty
	   + NVL(b.inputetcqty, 0)
	   - NVL(c.outqty, 0)
	   - NVL(d.outputetcqty, 0)
	   - NVL(f.returnqty, 0)
	   - NVL(g.outqty, 0)
	   - NVL(h.outqty, 0)
	   - NVL(i.unuseqty, 0)
	   - NVL(it.testqty, 0)
	   - NVL(gg.orderqty, 0)
		   usestock --가용재고
	  ,a.outrockdiv
	  ,a.testcheck
	  ,a.itemdetaildiv
	  ,a.requestcheck
	  ,a.requestperiod
	  ,NVL(f.returnqty, 0) returnqty --폐기량
	  ,a.custcode
	  ,a.testno2
	  ,a.retestcheck
	  ,a.price
	  ,a.warehousediv
	  ,a.costcenter
  FROM --입고자료(일반)
	  (SELECT a.itemcode --품목코드
			 ,b.itemkorname --품목명
			 ,TO_CHAR(a.warehousingdt, 'YYYY-MM-DD') warehousingdate --입고일자
			 ,a.warehousingno --입고번호
			 ,a.manufacturecode --제조처코드
			 ,a.lotno --제조번호
			 ,a.lotdate --제조일자
			 ,a.validityperiod --유효일자
			 ,a.retestdate
			 ,a.warehousingstate --입고상태
			 ,b.itemunit --단위
			 ,b.itemunitname
			 ,a.testno --시험번호
			 ,a.classifyjudgerate --시험함량/역가
			 ,a.classifyjudgerateB --시험함량/역가B
			 ,a.totalwarehousingqty --입고수량
			 ,b.itemdiv --원부자재구분
			 ,b.itemdivname
			 ,b.itembranch --원부자재분류
			 ,b.itembranchname
			 ,a.testresult --시험결과
			 ,a.retestno
			 ,NVL(a.outrockdiv, 'Y') outrockdiv
			 ,NVL(b.testcheck, 'N') testcheck
			 ,f.remark itemdetaildiv
			 ,NVL(b.requestcheck, 'N') requestcheck
			 ,NVL(b.requestperiod, 0) requestperiod
			 ,NVL(a.custcode, '') custcode
			 ,NVL(a.testno2, '') testno2
			 ,NVL(a.retestcheck, 'N') retestcheck
			 ,NVL(a.warehousingprice, 0) price
			 ,a.warehousediv
			 ,b.costcenter
		 FROM warehousing a
			  INNER JOIN nvItemRM b ON a.itemcode = b.itemcode
			  INNER JOIN CMCOMMONM f
				  ON b.itembranch = f.divcode
					 AND f.cmmcode = 'MPM09'
					 AND b.itemdiv IN ('01', '02')
	   --상품입고
	   UNION
	   SELECT a.itemcode --품목코드
			 ,b.itemkorname --품목명
			 ,TO_CHAR(a.warehousingdt, 'YYYY-MM-DD') warehousingdate --입고일자
			 ,a.warehousingno --입고번호
			 ,a.manufacturecode --제조처코드
			 ,a.lotno --제조번호
			 ,a.lotdate --제조일자
			 ,a.validityperiod --유효일자
			 ,a.retestdate
			 ,a.warehousingstate --입고상태
			 ,b.itemunit --단위
			 ,b.packingunitqtyname itemunitname
			 ,a.testno --시험번호
			 ,a.classifyjudgerate --시험함량/역가
			 ,a.classifyjudgerateB --시험함량/역가B
			 ,a.totalwarehousingqty --입고수량
			 ,b.itemdiv --원부자재구분
			 ,b.itemdivname
			 ,b.itembranch --원부자재분류
			 ,b.itembranchname
			 ,a.testresult --시험결과
			 ,a.retestno
			 ,NVL(a.outrockdiv, 'Y') outrockdiv
			 ,NVL(b.testcheck, 'N') testcheck
			 ,f.remark itemdetaildiv
			 ,'N' requestcheck
			 ,0 requestperiod
			 ,NVL(a.custcode, '') custcode
			 ,NVL(a.testno2, '') testno2
			 ,NVL(a.retestcheck, 'N') retestcheck
			 ,NVL(a.warehousingprice, 0) price
			 ,a.warehousediv
			 ,b.costcenter
		 FROM warehousing a
			  INNER JOIN nvItemGP b ON a.itemcode = b.itemcode
			  INNER JOIN CMCOMMONM f
				  ON b.itembranch = f.divcode
					 AND f.cmmcode = 'MPM09'
					 AND b.itemdiv IN ('05')
	   --제품입고
	   UNION
	   SELECT a.itemcode --품목코드
			 ,b.itemkorname --품목명
			 ,TO_CHAR(a.workdt, 'YYYY-MM-DD') warehousingdate --입고일자
			 ,a.packingorderno warehousingno --입고번호
			 ,'' --제조처코드
			 ,NVL(NVL(d.lotno, c.lotno), a.batchno) lotno --제조번호
			 ,a.lotdate --제조일자
			 ,a.validityperiod --유효일자
			 ,a.validityperiod retestdate
			 ,'90' warehousingstate
			 --입고상태
			 ,b.itemunit --단위
			 ,b.packingunitqtyname itemunitname
			 ,a.goodstestrequestno testno --시험번호
			 ,a.classifyjudgerate classifyjudgerate --시험함량/역가
			 ,a.classifyjudgerateB classifyjudgerateB --시험함량/역가B
			 ,a.warehousepackqty totalwarehousingqty --입고수량
			 ,b.itemdiv --원부자재구분
			 ,b.itemdivname
			 ,b.itembranch --원부자재분류
			 ,b.itembranchname
			 ,a.goodstestresult testresult --시험결과
			 ,'' retestno
			 ,NVL(a.outrockdiv, 'Y') outrockdiv
			 ,'Y' testcheck
			 ,b.searchdetaildiv itemdetaildiv
			 ,'Y' requestcheck
			 ,0 requestperiod
			 ,'' custcode
			 ,'' testno2
			 ,'Y' retestcheck
			 ,b.makingcost price
			 ,a.warehousediv
			 ,b.costcenter
		 FROM PackingResults a
			  INNER JOIN nvItemGP b
				  ON a.itemcode = b.itemcode
					 AND b.searchdiv = 'A'
			  LEFT JOIN MakingOrders c ON a.orderno = c.orderno
			  LEFT JOIN PackingOrders d
				  ON a.packingorderno = d.packingorderno
					 AND a.itemcode = d.itemcode --2011.08.17
	   --Seeding입고
	   UNION
		 SELECT c.itemcode --품목코드
			   ,c.itemkorname --품목명
			   ,a.rowoutdate warehousingdate --입고일자
			   ,a.rowoutorderno warehousingno --입고번호
			   ,'' --제조처코드
			   ,d.batchno lotno --제조번호
			   ,d.lotdate lotdate --제조일자
			   ,d.validityperiod --유효일자
			   ,d.validityperiod retestdate
			   ,'90' warehousingstate
			   --입고상태
			   ,c.itemunit --단위
			   ,c.itemunitname
			   ,b.testno --시험번호
			   ,NULL classifyjudgerate --시험함량/역가
			   ,NULL classifyjudgerateB --시험함량/역가B
			   ,SUM(b.rowoutorderqty) totalwarehousingqty --입고수량
			   ,c.itemdiv --원부자재구분
			   ,c.itemdivname
			   ,c.itembranch --원부자재분류
			   ,c.itembranchname
			   ,d.goodstestresult testresult --시험결과
			   ,'' retestno
			   ,NVL(d.outrockdiv, 'Y') outrockdiv
			   ,'Y' testcheck
			   ,c.searchdetaildiv itemdetaildiv
			   ,'Y' requestcheck
			   ,0 requestperiod
			   ,'' custcode
			   ,'' testno2
			   ,'Y' retestcheck
			   ,c.makingcost price
			   ,d.warehousediv
			   ,c.costcenter
		   FROM TakingOutRow a
				INNER JOIN TakingOutRowDetail b
					ON a.rowoutorderdiv = '05'
					   AND a.rowoutorderno = b.rowoutorderno
				INNER JOIN nvItemGP c
					ON b.itemmakecode = c.itemcode
					   AND c.searchdiv = 'A'
				INNER JOIN PackingResults d ON b.testno = d.goodstestrequestno
	   GROUP BY c.itemcode --품목코드
			   ,c.itemkorname --품목명
			   ,a.rowoutdate
			   ,a.rowoutorderno --제조처코드
			   ,d.batchno
			   ,d.lotdate
			   ,d.validityperiod
			   ,c.itemunit --단위
			   ,c.itemunitname
			   ,b.testno
			   ,c.itemdiv --원부자재구분
			   ,c.itemdivname
			   ,c.itembranch --원부자재분류
			   ,c.itembranchname
			   ,d.goodstestresult
			   ,d.outrockdiv
			   ,c.searchdetaildiv
			   ,c.makingcost
			   ,d.warehousediv
			   ,c.costcenter) a
	   LEFT JOIN --입고자료(기타)
				(  SELECT a.warehousingno
						 ,SUM(a.inputetcqty) inputetcqty --입고수량
					 FROM (SELECT warehousingno warehousingno
								 ,etcinoutnoqty inputetcqty
							 FROM MaterialEtcInOut
							WHERE SUBSTR(inoutdiv, 1, 1) = 'I'
						   UNION ALL
						   SELECT a.packingorderno warehousingno
								 ,ROUND(b.inqty, 4) inputetcqty
							 FROM PackingResults a
								  INNER JOIN SLITEMWAREHOUSING b
									  ON a.itemcode = b.itemcode
										 AND a.batchno = b.lotno
										 AND SUBSTR(b.indiv, 1, 1) = 'O'
						   UNION ALL
						   SELECT a.warehousingno
								 ,ROUND(b.inqty, 4) inputetcqty
							 FROM Warehousing a
								  INNER JOIN SLITEMWAREHOUSING b
									  ON a.itemcode = b.itemcode
										 AND a.lotno = b.lotno
										 AND SUBSTR(b.indiv, 1, 1) = 'O' --판매
																		--          UNION ALL
																		--          SELECT a.packingorderno warehousingno
																		--          ,ROUND(b.returningqty1, 4) inputetcqty
																		--         FROM PackingResults a
																		--           INNER JOIN ReturningClassify b
																		--            ON a.itemcode = b.itemcode
																		--            AND a.batchno = b.lotno
																		--            AND SUBSTR(a.itemcode, 1, 1) = 'A'
						  ) a
				 GROUP BY a.warehousingno) b
		   ON a.warehousingno = b.warehousingno
	   LEFT JOIN --출고자료(일반,출고대기)
				(  SELECT a.warehousingno
						 ,SUM(a.outqty) outqty --출고수량
						 ,SUM(a.outwaitqty) outwaitqty --출고대기수량
					 FROM (SELECT warehousingno
								 ,CASE WHEN rowoutstate = '04' THEN rowoutorderqty ELSE 0 END outqty --출고완료
								 ,CASE WHEN rowoutstate <> '04' THEN rowoutorderqty ELSE 0 END outwaitqty --출고대기
							 FROM TakingOutRowDetail
						   UNION ALL
						   SELECT warehousingno
								 ,CASE WHEN materialoutstate = '04' THEN materialoutorderqty ELSE 0 END outqty
								 ,CASE WHEN materialoutstate <> '04' THEN materialoutorderqty ELSE 0 END outwaitqty
							 FROM TakingOutMaterialDetail) a
				 GROUP BY a.warehousingno) c
		   ON a.warehousingno = c.warehousingno
	   LEFT JOIN --출고자료(기타)
				(  SELECT warehousingno
						 ,SUM(etcinoutnoqty) outputetcqty
					 FROM MaterialEtcInOut
					WHERE SUBSTR(inoutdiv, 1, 1) = 'O'
				 GROUP BY warehousingno) d
		   ON a.warehousingno = d.warehousingno
	   LEFT JOIN --칭량자료(실시간재고)
				(  SELECT a.testno
						 ,SUM(b.subdetailqty) weighinguseqty
					 FROM WeighingWork a LEFT JOIN WeighingSubDetail b ON a.weighingworkid = b.weighingworkid
				 GROUP BY a.testno) e
		   ON a.testno = e.testno
	   LEFT JOIN --폐기자료(기타)
				(  SELECT warehousingno
						 ,SUM(totalwarehousingreturnqty) returnqty
					 FROM WarehousingReturning
				 GROUP BY warehousingno) f
		   ON a.warehousingno = f.warehousingno
	   LEFT JOIN --제품 출고자료(일반,출고대기)
				(  SELECT a.warehousingno
						 ,SUM(a.outqty) outqty --출고수량
						 ,SUM(a.outwaitqty) outwaitqty --출고대기수량
					 FROM (SELECT packingorderno warehousingno
								 ,endqty outqty --출고완료
								 ,0 outwaitqty --출고대기
							 FROM ERPSalesendDetail
						   UNION ALL
						   SELECT a.packingorderno warehousingno
								 ,ROUND(b.outqty, 4) outqty
								 ,0 outwaitqty
							 FROM PackingResults a
								  INNER JOIN SLITEMTAKINGOUT b
									  ON a.itemcode = b.itemcode
										 AND a.batchno = b.lotno
										 AND SUBSTR(b.outdiv, 1, 1) <> 'O' --판매
						   UNION ALL
						   SELECT a.warehousingno
								 ,ROUND(b.outqty, 4) outqty
								 ,0 outwaitqty
							 FROM Warehousing a
								  INNER JOIN SLITEMTAKINGOUT b
									  ON a.itemcode = b.itemcode
										 AND a.lotno = b.lotno
										 AND SUBSTR(b.outdiv, 1, 1) <> 'O' --판매
																		  ) a
				 GROUP BY a.warehousingno) g
		   ON a.warehousingno = g.warehousingno
	   LEFT JOIN --제품 기타 출고자료(일반,출고대기)
				(  SELECT a.warehousingno
						 ,SUM(a.outqty) outqty --출고수량
						 ,SUM(a.outwaitqty) outwaitqty --출고대기수량
					 FROM (SELECT a.packingorderno warehousingno
								 ,ROUND(b.outqty, 4) outqty
								 ,0 outwaitqty
							 FROM PackingResults a
								  INNER JOIN SLITEMTAKINGOUT b
									  ON a.itemcode = b.itemcode
										 AND a.batchno = b.lotno
										 AND SUBSTR(b.outdiv, 1, 1) = 'O'
						   UNION ALL
						   SELECT a.warehousingno
								 ,ROUND(b.outqty, 4) outqty
								 ,0 outwaitqty
							 FROM Warehousing a
								  INNER JOIN SLITEMTAKINGOUT b
									  ON a.itemcode = b.itemcode
										 AND a.lotno = b.lotno
										 AND SUBSTR(b.outdiv, 1, 1) = 'O') a
				 GROUP BY a.warehousingno) h
		   ON a.warehousingno = h.warehousingno
	   LEFT JOIN --불용처리
				(  SELECT warehousingno
						 ,SUM(unuseqty) unuseqty
					 FROM StockUnUse
				 GROUP BY warehousingno) i
		   ON a.warehousingno = i.warehousingno
	   LEFT JOIN --불용처리
				(  SELECT manageno warehousingno
						 ,SUM(NVL(samplingqty, 0) + NVL(samplingqty2, 0) + NVL(samplingqty3, 0)) testqty
					 FROM TestManage
					WHERE SUBSTR(itemcode, 1, 1) = 'S'
				 GROUP BY manageno) it
		   ON a.warehousingno = it.warehousingno
	   LEFT JOIN --예약재고
				(  SELECT a.itemcode
						 ,b.lotno
						 ,SUM(NVL(b.orderqty, 0)) orderqty
					 FROM erpsalesorder a
						  INNER JOIN erpsalesorderdetail b
							  --on a.docentry = b.erporderno   -- 주석처리 by 이종석(2016.11.21)
							  ON a.docentry = SUBSTR(b.erporderno, 1, 16) -- 구문추가 by 이종석(2016.11.21) - 'KB-SO-161014-005-1' 판매오더번호에서 "-1" 삭제하고 조인하도록 수정
								 AND a.orderstatus <> '03'
				 GROUP BY a.itemcode, b.lotno) gg
		   ON a.itemcode = gg.itemcode
			  AND a.lotno = gg.lotno
/
