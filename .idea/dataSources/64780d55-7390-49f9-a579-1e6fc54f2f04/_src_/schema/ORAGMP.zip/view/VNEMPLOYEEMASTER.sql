CREATE VIEW VNEMPLOYEEMASTER AS SELECT empcode,
		   empname,
		   deptcode,
		   deptname,
		   enterdt enteringdate,
		   retiredt retirementdate,
		   CASE sexdiv WHEN '1' THEN 'M' WHEN '2' THEN 'F' END sexdiv,
		   sexdivnm sexdivname,
		   positiondiv,
		   jikwi positiondivname,
		   classdiv responsibilitydiv,
		   classdivnm responsibilitydivname,
		   CASE empdiv WHEN '01' THEN 'R' ELSE 'T' END empdiv,
		   empdivnm empdivname,
		   CASE WHEN NVL(retiredt, ' ') = ' ' THEN 'N' ELSE 'Y' END retireyn,
		   email,
		   plantcode
	FROM   vnEMP
/
