CREATE VIEW VNCUST AS SELECT A.PLANTCODE,
          A.CUSTCODE,
          A.CUSTOLDCODE CUSTOLDCODE,               -- 구거래처코드
          A.CUSTMAJORCODE CUSTMAJORCODE,           -- 대표거래처코드
          O.CUSTNAME CUSTMAJORNAME,                -- 대표거래처명
          A.CUSTNAME CUSTNAME,                     -- 거래처명
          A.CUSTSNAME CUSTSNAME,                   -- 거래처약명
          A.CUSTENAME CUSTENAME,                   -- 영문명
          A.CUSTCONDITION CUSTCONDITION,           -- 업태
          A.CUSTITEM CUSTITEM,                     -- 종목
          A.CUSTDIV CUSTDIV,                       -- 거래처구분
          B.DIVNAME CUSTDIVNM,                     -- 거래처구분명
          A.BUSINESSNO BUSINESSNO,                 -- 사업자등록번호
          A.CORPORATIONNO CORPORATIONNO,           -- 법인등록번호
          A.MEDICALCODE MEDICALCODE,               -- 요양기관번호
          A.CEONAME CEONAME,                       -- 대표자명
          A.CEONO CEONO,                           -- 대표자주민등록번호
          A.TELNO TELNO,                           -- 전화번호
          A.FAXNO FAXNO,                           -- 팩스번호
          A.LICENSENO LICENSENO,                   -- 면허번호
          A.CUSTEMPNAME CUSTEMPNAME,               -- 거래처담당자
          A.EMAIL EMAIL,                           -- 이메일
          A.DOMAIN DOMAIN,                         -- 홈페이지(도메인)
          A.POST POST,                             -- 우편번호
          A.ADDR1 ADDR1,                           -- 주소1
          A.ADDR2 ADDR2,                           -- 주소2
          A.ADDR1 || ' ' || A.ADDR2 ADDR,          --주소
          A.ADDRE ADDRE,                           -- 영문주소
          A.AREADIV AREADIV,                       -- 지역구분
          L.DIVNAME AREADIVNM,                     -- 지역명
          A.OPENDATE OPENDATE,                     -- 거래개시일
          SUBSTR(A.OPENDATE, 0, 7) OPENYYMM,
          A.STOPDATE STOPDATE,                     -- 거래중지일
          C.TOPDEPTCODE TOPDEPTCODE,               -- 부서
          C.TOPDEPTNAME TOPDEPTNAME,               -- 부서명
          C.PREDEPTCODE PREDEPTCODE,               -- 부서
          C.PREDEPTNAME PREDEPTNAME,               -- 부서명
          A.DEPTCODE DEPTCODE,                     -- 영업소
          C.DEPTNAME DEPTNAME,                     -- 영업소명
          C.TOPDEPTNAME || C.PREDEPTNAME || C.DEPTNAME FINDNAME,
          A.EMPCODE EMPCODE,                       -- 담당자
          D.EMPNAME EMPNAME,                       -- 담당자명
          D.POSITIONDIV POSITIONDIV,
          D.ENTERDT ENTERDT,                       -- 입사일자
          J.DIVNAME JIKWI,                         -- 직위
          A.UTDIV UTDIV,                           -- 유통구분
          F.DIVNAME UTDIVNM,                       -- 유통구분명
          A.CUSTCLASS CUSTCLASS,                   -- 사업자구분
          G.DIVNAME CUSTCLASSNM,                   -- 사업자구분명
          A.TAXDIV TAXDIV,                         -- 계산서발행구분
          E.DIVNAME TAXDIVNM,                      -- 계산서발행구분명
          A.CREDITYN CREDITYN,                     -- 신용불량구분
          A.SAGODIV SAGODIV,                       -- 사고처구분(거래처상태)
          H.DIVNAME SAGODIVNM,                     -- 거래처상태명
          A.HINOUTDIV HINOUTDIV,                   -- 원내외구분
          K.DIVNAME HINOUTDIVNM,                   -- 원내외구분명
          A.HOLDDIV HOLDDIV,                       -- 법인구분
          I.DIVNAME HOLDDIVNM,                     -- 법인구분명
          A.LASTSALDATE LASTSALDATE,               -- 최종판매일자
          A.LASTCOLDATE LASTCOLDATE,               -- 최종수금일자
          A.BONDMOVEDATE BONDMOVEDATE,             -- 채권이전일
          NVL(A.TURNCNT, 0) TURNCNT,               -- 회전일
          NVL(A.TURNDCCNT, 0) TURNDCCNT,           -- 총대차회전일
          NVL(A.CREDITLMT, 0) CREDITLMT,           -- 여신한도액
          NVL(A.BALANCELMT, 0) BALANCELMT,         -- 잔고한도액
          NVL(A.NOCOLLMT, 0) NOCOLLMT,             -- 무수금개월한도
          NVL(A.SECURITYLMT, 0) SECURITYLMT,       -- 담보가치한도
          NVL(A.AVGAMT, 0) AVGAMT,                 -- 평균판매금액개월
          NVL(A.SALAMTLMT, 0) SALAMTLMT,           -- 평균판매금액
          NVL(A.TURNLMT, 0) TURNLMT,               -- 회전일한도
          A.USEYN USEYN,                           -- 채권한도사용구분
          NVL(A.PRCEDITDIV, '01') PRCEDITDIV,      -- 단가수정여부 SL55
          NVL(A.GIVEDITDIV, '01') GIVEDITDIV,      -- 할증수정여부 SL56
          A.MEMO1 MEMO1,                           -- 메모1
          A.MEMO2 MEMO2,                           -- 메모2
          D.RETIREDT RETIREDT,                     -- 퇴사일자
          NVL(A.MEDIYN, 'N') MEDIYN,               -- 요양급여 공급내역 신고여부
          A.CUSTEMPTEL CUSTEMPTEL,
          A.CONTRACTDATE CONTRACTDATE,             -- 계약일자
          A.XPOS XPOS,                             -- X좌표
          A.YPOS YPOS,                             -- Y좌표
          A.PAYDIV PAYDIV,                         -- 배송사
          M.DIVNAME PAYDIVNM,                      -- 배송사
          C.DEPTGROUP DEPTGROUP,
          A.ASCUSTCHECK ASCUSTCHECK,               -- 신규처구분
          NVL(A.DRIVINGTERM, 0) DRIVINGTERM,       -- 할인율OTC
          NVL(A.VATRATE, 0) VATRATE,               -- 할인율ETC
          A.REGID REGID,
          C.SEQTOPDEPTCODE,
          C.SEQPREDEPTCODE,
          C.SEQDEPTCODE,
          A.CUSTCODEUT,
          A.CREDITRATINGDIV CREDITRATINGDIV,       -- 신용등급
          N.DIVNAME CREDITRATINGDIVNM,             -- 신용등급명
          A.DVPOST,
          A.DVADDR1,
          A.DVADDR2,
          A.ORDERCTRLYN,
          A.AGENTEMPCODE,
          NVL(A.RERTYN, 'N') RERTYN,               -- 결재반품대상여부(2015-05-29:이세민 이글벳 특화)
          A.PROMDSCDIV PROMDSCDIV,                 -- 약정율구분(2015-06-01:이세민 이글벳 특화)
          A.AREAGROUP AREAGROUP,                   -- 지역그룹구분(2015-06-17:이세민 이글벳 특화)
          A.COUNTRYCODE,                           -- 국가코드 추가(2015-08-10:이세민 기존 있던 필드임)
          A.HIRACODE,                              -- HIRA거래처코드 추가 (2017-07-28: 김만수 하나제약 특화)
          A.VIRTUALACCOUNT,                        -- 가상계좌 추가 (2017-07-28: 김만수)
          A.STEROIDYN,                             -- 경구제 출하여부 추가 (2017-07-28: 김만수 하나제약 특화)
          A.blackyn,                               --블랙거래처 여부 추가 (2017-07-28: 김만수 하나제약 특화)
          A.blackdesignation,                      --블랙거래처 지정사유 추가 (2017-07-28: 김만수 하나제약 특화)
          A.blackclear,                            --블랙거래처 해제사유  추가 (2017-07-28: 김만수 하나제약 특화)
          A.domaeoutgb,                            --도매출하지시번호생성조건 추가 (2017-09-6: 김만수 하나제약 특화)
          A.sunipgumyn,                             --선입금처여부 추가  (2017-09-06: 김만수 하나제약 특화)
          A.ingae_cust_id,                      --이전거래처(인계) 추가 
          P.custname ingae_cust_name,           --이전거래처명(인계) 추가
          A.hangjung,                           --향정취급여부 추가
          A.mayak,                              --마약취급여부 추가
          A.banpum_free_yn,                     --반품시무조건허용여부 추가
          A.parents_cust_id,                    --상위거래처 추가
          Q.custname parents_cust_name,         --상위거래처명 추가
          A.tel_card_sms,                       --수기카드SMS발송번호 추가
          A.jumun_limit,                        --주문수량한도(%) 추가
          A.sugum_halinyul_yn,                  --수금이력발생거래처여부 추가
          A.ceohp,
          A.securityexyn                        --담보예외처여부 추가
    FROM CMCUSTM A
LEFT JOIN CMCOMMONM B
       ON A.CUSTDIV = B.DIVCODE
      AND B.CMMCODE = 'CM11'                       -- 거래처구분
LEFT JOIN VNDEPT C
       ON A.DEPTCODE = C.DEPTCODE
LEFT JOIN CMEMPM D
       ON A.EMPCODE = D.EMPCODE
LEFT JOIN CMCOMMONM E
       ON A.TAXDIV = E.DIVCODE
      AND E.CMMCODE = 'CM16'                       -- 계산서발행구분
LEFT JOIN CMCOMMONM F
       ON A.UTDIV = F.DIVCODE
      AND F.CMMCODE = 'CM15'                       -- 유통구분
LEFT JOIN CMCOMMONM G
       ON A.CUSTCLASS = G.DIVCODE
      AND G.CMMCODE = 'CM46'                       -- 사업자구분(사업자,개인,수출)
LEFT JOIN CMCOMMONM H
       ON A.SAGODIV = H.DIVCODE
      AND H.CMMCODE = 'CM20'                       -- 사고구분(거래처상태)
LEFT JOIN CMCOMMONM I
       ON A.HOLDDIV = I.DIVCODE
      AND I.CMMCODE = 'CM45'                       -- 법인구분
LEFT JOIN CMCOMMONM J
       ON D.POSITIONDIV = J.DIVCODE
      AND J.CMMCODE = 'PS29'                       -- 직위
LEFT JOIN CMCOMMONM K
       ON A.HINOUTDIV = K.DIVCODE
      AND K.CMMCODE = 'CM09'
LEFT JOIN CMCOMMONM L
       ON A.AREADIV = L.DIVCODE
      AND L.CMMCODE = 'CM03'
LEFT JOIN CMCOMMONM M
       ON A.PAYDIV = M.DIVCODE
      AND M.CMMCODE = 'SL79'
LEFT JOIN CMCUSTM O
       ON A.CUSTMAJORCODE = O.CUSTCODE
LEFT JOIN CMCOMMONM N
       ON A.CREDITRATINGDIV = N.DIVCODE
      AND N.CMMCODE = 'SL87'                       -- 신용등급
LEFT JOIN CMCUSTM P 
       ON A.INGAE_CUST_ID = P.CUSTCODE
LEFT JOIN CMCUSTM Q
       ON A.PARENTS_CUST_ID = Q.CUSTCODE
/
