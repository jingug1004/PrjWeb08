CREATE VIEW VNSSCCINFO AS SELECT a.serialno
          ,b1.scbarcode agg1
          ,b2.scbarcode agg2
          ,c.gtin
          ,c.lotno
-- 2017-09-04 아래와 같이 되어 있어서 수정 함
--      FROM tedb.BarcodeSerial a
--           LEFT JOIN tedb.BarcodeBundle b1 ON a.bundle1seq = b1.bundleseq
--           LEFT JOIN tedb.BarcodeBundle b2 ON a.bundle2seq = b2.bundleseq
--           LEFT JOIN tedb.BarcodeFooter c ON a.markseq = c.markseq
      FROM BarcodeSerial a
           LEFT JOIN BarcodeBundle b1 ON a.bundle1seq = b1.bundleseq
           LEFT JOIN BarcodeBundle b2 ON a.bundle2seq = b2.bundleseq
           LEFT JOIN BarcodeFooter c ON a.markseq = c.markseq
     WHERE a.iochk = 'I'
/
