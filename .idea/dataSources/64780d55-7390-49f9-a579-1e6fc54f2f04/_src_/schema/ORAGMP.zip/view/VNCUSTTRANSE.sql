CREATE VIEW VNCUSTTRANSE AS SELECT a.plantcode,
		   a.entryno,
		   b.custcode,
		   c.custname,
		   b.orderdiv,
		   a.entrydate,
		   a.tdeptcode,
		   D.deptname tdeptname,
		   D.predeptname tpredeptname,
		   a.tempcode,
		   e.empname tempname,
		   NVL(g.divname, ' ') tjikwi,
		   a.adeptcode,
		   d1.deptname adeptname,
		   d1.predeptname apredeptname,
		   a.aempcode,
		   e1.empname aempname,
		   NVL(g1.divname, ' ') ajikwi,
		   NVL(b.balance, 0) balance,
		   NVL(b.pendbill, 0) pendbill,
		   NVL(b.custbalance, 0) custbalance,
		   NVL(b.differentamt, 0) differentamt,
		   a.fixyn,
		   a.fixdate,
		   NVL(a.remark, ' ') remark,
		   b.balancedate,
		   a.apprstatus
	FROM   SLTRANSMNGM a
		   LEFT JOIN SLTRANSMNGD b
			   ON a.entryno = b.entryno
				  AND a.plantcode = b.plantcode
		   LEFT JOIN CMCUSTM c ON b.custcode = c.custcode
		   LEFT JOIN vnDEPT D ON a.tdeptcode = D.deptcode
		   LEFT JOIN vnDEPT d1 ON a.adeptcode = d1.deptcode
		   LEFT JOIN CMEMPM e ON a.tempcode = e.empcode
		   LEFT JOIN CMEMPM e1 ON a.aempcode = e1.empcode
		   LEFT JOIN CMCOMMONM g
			   ON e.positiondiv = g.divcode
				  AND g.cmmcode = 'PS29'
		   LEFT JOIN CMCOMMONM g1
			   ON e1.positiondiv = g1.divcode
				  AND g1.cmmcode = 'PS29'
--이전쿼리 주석처리===========================================================
--select      top(100) percent
--			a.plantcode		-- isnull(a.plantcode,'') as plantcode
--                  ,a.entryno		-- isnull(a.entryno,'') as entryno
--                  ,a.custcode		-- isnull(a.custcode,'') as custcode
--			,isnull(b.custname,'') as custname
--                  ,isnull(a.orderdiv,'') as orderdiv
--                  ,isnull(a.entrydate,'') as entrydate
--			,isnull(c.topdeptcode,'') as ttopdeptcode
--			,isnull(c.topdeptname,'') as ttopdeptname
--			,isnull(c.predeptcode,'') as tpredeptcode
--			,isnull(c.predeptname,'') as tpredeptname
--                  ,isnull(a.tdeptcode,'') as tdeptcode
--			,isnull(c.deptname,'') as tdeptname
--                  ,isnull(a.tempcode,'') as tempcode
--			,isnull(d.empname,'') as tempname
--			,isnull(d.positiondiv,'') as tpositiondiv
--			,isnull(g.divname,'') as tjikwi
--			,isnull(e.topdeptcode,'') as atopdeptcode
--			,isnull(e.topdeptname,'') as atopdeptname
--			,isnull(e.predeptcode,'') as apredeptcode
--			,isnull(e.predeptname,'') as apredeptname
--                  ,isnull(a.adeptcode,'') as adeptcode
--			,isnull(e.deptname,'') as adeptname
--                  ,isnull(a.aempcode,'') as aempcode
--			,isnull(f.empname,'') as aempname
--			,isnull(f.positiondiv,'') as apositiondiv
--			,isnull(h.divname,'') as ajikwi
--                  ,isnull(a.balance,0) as balance
--                  ,isnull(a.pendbill,0) as pendbill
--                  ,isnull(a.custbalance,0) as custbalance
--                  ,isnull(a.differentamt,0) as differentamt
--                  ,isnull(a.fixyn,'') as fixyn
--                  ,isnull(a.remark,'') as remark
--      from        SLCUSTTRANSEM (nolock) as a
--			join CMCUSTM (nolock) as b
--				on a.custcode = b.custcode
--			join vndept (nolock) as c
--				on a.tdeptcode = c.deptcode
--			join cmempm (nolock) as d
--				on a.tempcode = d.empcode
--			join vndept (nolock) as e
--				on a.adeptcode = e.deptcode
--			join cmempm (nolock) as f
--				on a.aempcode = f.empcode
--			left join CMCOMMONM (nolock) as g
--				on d.positiondiv = g.divcode
--				and g.cmmcode = 'PS29'
--			left join CMCOMMONM (nolock) as h
--				on f.positiondiv = h.divcode
--				and h.cmmcode = 'PS29'
--===========================================================================
/
