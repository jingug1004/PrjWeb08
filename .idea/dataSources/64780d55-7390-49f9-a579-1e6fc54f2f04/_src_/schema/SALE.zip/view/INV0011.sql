CREATE VIEW INV0011 AS SELECT georae_cd CUST_ID, georae_nm CUST_NM, georae_snm CUST_NM1, georae_enm, 
          georae_gubun georae_gubun, 
          saup_no VOU_NO, bupin_no, zip_cd ZIP, juso ADDR1, uptae, upjong JONGMOK, 
          daepyo_name PRESIDENT, dungrok_ymd INPUT_YMD, dungrok_sabun USER_ID, 
          last_chasu, sayong_yn use_yn
     FROM SYS905C

/
