CREATE VIEW SALE0401_V AS (SELECT YMD       ,
           JUNPYO_GB ,
           JUNPYO_NO ,
           CUST_ID   ,
           RCUST_ID  ,
           SAWON_ID  ,
           SUM(CASH_AMT)  CASH_AMT,
           SUM(BILL_AMT)  BILL_AMT
      FROM (SELECT YMD       ,
                   JUNPYO_GB ,
                   'S'||JUNPYO_NO  JUNPYO_NO,
                   CUST_ID   ,
                   RCUST_ID  ,
                   SAWON_ID  ,
                   CASH_AMT  ,
                   BILL_AMT
              FROM SALE0401)
     GROUP BY YMD , JUNPYO_GB , JUNPYO_NO , CUST_ID , RCUST_ID, SAWON_ID
    )


/
