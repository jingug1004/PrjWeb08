CREATE VIEW SALE0402_V AS (SELECT YMD            ,
           'S'||JUNPYO_NO   JUNPYO_NO   ,
           INPUT_SEQ      ,
           END_YMD        ,
           AMT            ,
           START_YMD      ,
           BALHANG        ,
           JIGEUB         ,
           BILL_NO        ,
           BILL_GB        ,
           GYULJAE_YMD    ,
           BIGO
      FROM SALE0402
 )


/
