CREATE PROCEDURE      SP_SFA_COMMON_071
(
    in_BANK_CD           IN  VARCHAR2,  -- 은행코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 은행별지점검색 팝업
 호출프로그램 :         
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
    BANK_CD_NULL           EXCEPTION;
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_COMMON_071','1',sysdate,'in_BANK_CD:'||in_BANK_CD||'/v_num:'||TO_CHAR(v_num)  );
    
    IF in_BANK_CD IS NULL OR TRIM(in_BANK_CD) = '' THEN
        RAISE BANK_CD_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
     FROM SYS908C   
        WHERE BANK_CD = in_BANK_CD;
    
    out_COUNT := v_num;
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
        
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT JIJUM_CD   as out_JIJUM_CD
              ,JIJUM_NM   as out_JIJUM_NM
        FROM SYS908C   
        WHERE BANK_CD = in_BANK_CD
        ORDER BY JIJUM_NM;
         
    END IF;
    
    
    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_COMMON_071','2',sysdate,'in_BANK_CD:'||in_BANK_CD||'/v_num:'||TO_CHAR(v_num)  );
 
EXCEPTION
WHEN BANK_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '은행코드가 누락되었습니다.';
   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
