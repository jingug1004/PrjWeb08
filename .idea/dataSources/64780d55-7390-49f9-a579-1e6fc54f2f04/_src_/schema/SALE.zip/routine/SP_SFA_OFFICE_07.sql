CREATE PROCEDURE      SP_SFA_OFFICE_07 
(
    in_CAT_CD            IN  VARCHAR2,  -- 카테고리 코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 자료실조회
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    CAT_CD_NULL          EXCEPTION;
BEGIN
    
    IF in_CAT_CD IS NULL THEN
        RAISE CAT_CD_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM hanagw.TGWBDM A   LEFT OUTER JOIN hanagw.TGWBDATCH B
                                              ON  A.BRD_NO         = B.BRD_NO
                                              AND A.BRDWRT_NO      = B.BRDWRT_NO
                                              AND A.BRDWRT_SEQ     = B.BRDWRT_SEQ
     WHERE A.BRD_NO = in_CAT_CD
       AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN A.BRD_STR_DD AND A.BRD_END_DD
       AND A.BRD_NO IN (SELECT BRD_NO FROM hanagw.TGWBDRM WHERE BRD_TYPE = '2') 
       AND NVL(A.DEL_YN, 'N')  = 'N'; -- 자료실 카테고리 체크
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT A.BRDWRT_NO             AS out_BRDWRT_NO      -- 게시글 번호
             , A.BRDWRT_SEQ            AS out_BRDWRT_SEQ     -- 게시글 순번
             , A.DRW_UNO               AS out_DRW_UNO        -- 작성자
             , (SELECT DISTINCT EMP_KO_NM FROM V_SAWON_ID_MAP WHERE UNO = A.DRW_UNO)   AS out_DRW_NM         -- 작성자명
             , A.BRDWRT_TYPE           AS out_BRDWRT_TYPE    -- 게시글 유형
             , A.TITL                  AS out_TITL           -- 제목
             , A.CONT                  AS out_CONT           -- 내용
             , SUBSTR(A.DRW_DTM,1,8)   AS out_DRW_DTM        -- 작성일자
             , TO_CHAR(A.BRD_STR_DD)   AS out_BRD_STR_DD     -- 게시시작일
             , TO_CHAR(A.BRD_END_DD)   AS out_BRD_END_DD     -- 게시종료일     
             , B.FILE_NM               AS out_FILE_NM        -- 첨부파일명 
             , B.USE_APP_PATH          AS out_APP_PATH       -- 폴더저장파일명       
          FROM hanagw.TGWBDM  A   LEFT OUTER JOIN hanagw.TGWBDATCH B
                                                ON  A.BRD_NO         = B.BRD_NO
                                                AND A.BRDWRT_NO      = B.BRDWRT_NO
                                                AND A.BRDWRT_SEQ     = B.BRDWRT_SEQ
         WHERE A.BRD_NO = in_CAT_CD
           AND TO_CHAR(SYSDATE, 'YYYYMMDD') BETWEEN A.BRD_STR_DD AND A.BRD_END_DD
           AND A.BRD_NO IN (SELECT BRD_NO FROM hanagw.TGWBDRM WHERE BRD_TYPE = '2') 
           AND NVL(A.DEL_YN, 'N')  = 'N'-- 자료실 카테고리 체크
         ORDER BY SUBSTR(A.DRW_DTM,1,8) DESC, A.BRDWRT_NO, A.BRDWRT_SEQ;
    END IF;
    
EXCEPTION
WHEN CAT_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '카테고리 선택이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
