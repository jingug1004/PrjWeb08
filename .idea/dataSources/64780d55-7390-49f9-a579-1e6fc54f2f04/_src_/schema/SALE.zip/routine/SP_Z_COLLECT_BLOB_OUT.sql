CREATE PROCEDURE      SP_Z_COLLECT_BLOB_OUT
(       in_JUNPYO_NO    IN VARCHAR2 DEFAULT NULL,
        out_CODE OUT NUMBER,
        out_MSG OUT VARCHAR2,
        out_COUNT OUT NUMBER,
        out_RESULT OUT TYPES.CURSOR_TYPE
)
IS
        /*---------------------------------------------------------------------------
        프로그램명   : 카드수금 저장된 이미지 다시 파일로 만듬 
        호출프로그램 : COLLECTLIST.JAVA
        CHOE 20140930   
         SP_SFA_COLLECT_BLOB 으로 in_SIGN_IMAGE   IN BLOB 전달 저장한 이미지를 다시 파일로 note에 저장    
          2017.11.01  KTA - NEW ERP메 맞게 컨버전   
        ---------------------------------------------------------------------------*/    

        ERROR_EXCEPTION EXCEPTION;   
        v_CNT NUMBER;
        
BEGIN
  
       -- insert into SFA_SP_CALLED_HIST values ('SP_Z_COLLECT_BLOB_OUT','1_'||in_JUNPYO_NO,sysdate,'in_JUNPYO_NO:'||in_JUNPYO_NO );
       -- commit;
 
        v_CNT :=0;
        SELECT COUNT(*)
          INTO v_CNT
          FROM ORAGMP.SLCOLM
         WHERE colno = in_JUNPYO_NO
           AND SIGNIMAGE IS NOT NULL
        ;
        IF v_CNT = 0 THEN       
                out_CODE := 999;
                out_MSG := '수금디테일에 수금사인정보없음';      
                RAISE ERROR_EXCEPTION;
        ELSIF v_CNT > 1 THEN
                out_CODE := 999;
                out_MSG := '수금디테일에 수금사인정보 너무 많음';      
                RAISE ERROR_EXCEPTION;
        ELSE  
            out_COUNT := v_CNT;

            BEGIN
            
               OPEN out_RESULT FOR
                    SELECT SIGNIMAGE AS out_SIGN_IMAGE   
                    FROM ORAGMP.SLCOLM
                    WHERE colno = in_JUNPYO_NO
                    AND SIGNIMAGE IS NOT NULL
                    ;
            EXCEPTION WHEN OTHERS THEN
                    out_CODE := SQLCODE;
                    out_MSG  := '사인로드실패:'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                    RAISE ERROR_EXCEPTION;
            END;   
        
        END IF;
    

        out_CODE := 0;
        out_MSG := '수금 사인 이미지 로딩 완료';


EXCEPTION
        WHEN ERROR_EXCEPTION THEN  
             out_CODE := 99;
        
              --  insert into SFA_SP_CALLED_HIST    values ('SP_SFA_COLLECT_BLOB_OUT' ,in_JUNPYO_NO ,sysdate ,'[out_MSG1:'||out_MSG||']');
              --  commit;
   
        WHEN OTHERS THEN 
             out_CODE := 99;
             --   insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_BLOB_OUT','1_'||in_JUNPYO_NO,sysdate,'[out_MSG1:'||out_MSG||']');
             --   commit;
END;
/
