CREATE FUNCTION      F_Z_FIND_PART  -- 부서를 입력하여 파트를 찾음 
(
    in_DEPTCODE  IN  VARCHAR2 
) 
RETURN VARCHAR2 IS

    v_part   VARCHAR2(4);
    
BEGIN

    select deptcode 
      into v_part 
      from oragmp.cmdeptm
     where deptlevel = 3
     connect by deptcode = prior predeptcode start with deptcode = in_DEPTCODE
     ;
            
    RETURN v_part;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;
/
