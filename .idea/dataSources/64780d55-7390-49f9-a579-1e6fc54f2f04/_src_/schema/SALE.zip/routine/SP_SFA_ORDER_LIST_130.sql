CREATE PROCEDURE      SP_SFA_ORDER_LIST_130   
(
    in_SAWON_ID          IN  VARCHAR2,   
    in_CUST_ID           IN  VARCHAR2,    
    in_RCUST_ID          IN  VARCHAR2,    
    in_CDT_FR            IN  VARCHAR2,    
    in_CDT_TO            IN  VARCHAR2,    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문현황
 호출프로그램 : 
 수정내역
  1.2014.04.08 KTA 위반주문 팀장승인상태를 화면에 보여주도록 수정함.    
  2.2014.12.12 KTA 수정버튼시 주문등록화면으로 넘어가면서 가지고갈 회전일 추가.  
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    SELECT COUNT(*)
      INTO v_num
      FROM SALE_ON.SALE0203 A
     WHERE A.SAWON_ID  in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) 
         /*WHERE A.SAWON_ID  in (select sawon_id from sale0007 where insa_sawon_id in  ( select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                                         where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                                            connect by prior dept_cd = up_dept_cd
                                                                                                              start with dept_cd = :v_insa_dept_cd)
                                                                                    )
                              )*/         
       AND A.CUST_ID Like '%'||NVL(in_CUST_ID, '%')||'%'
      -- AND A.RCUST_ID Like '%'||NVL(in_RCUST_ID, '%')||'%'
       AND A.YMD BETWEEN in_CDT_FR AND in_CDT_TO;
    
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDER_LIST','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||'/in_CUST_ID'||in_CUST_ID||' / v_num:'||to_char(v_num));
--COMMIT
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
    
        OPEN out_RESULT FOR
        SELECT A.GUMAE_NO                       AS out_GUMAE_NO,
               A.YMD                            AS out_ORDER_DATE,
               /*CHOE 20121007
               A.GUBUN AS out_GUBUN, 
               A.ACCEPT_YN                      AS OUT_ACCEPT_YN,*/
               DECODE( A.GUBUN, '01', '출고',  '02', '샘플', '07', '매출할인', '08', '수금할인', '09', '수출', '10', '반품', '11', '수취거부', '12', '매출할인', '13', '수금할인', '14', '판매대행수수료', '15', '수입수수료', '20', '기부출고', A.GUBUN) AS out_GUBUN,
               decode(a.receipt_gb,'3','반려',DECODE( A.ACCEPT_YN, 'Y', '대기','S','승인', '검토')) AS OUT_ACCEPT_YN,
               A.CUST_ID                        AS out_CUST_ID,   
               A.RCUST_ID                       AS out_RCUST_ID,   
               F_CUST_NM(TO_NUMBER(A.CUST_ID))  AS out_CUST_NM,   
               F_CUST_NM(TO_NUMBER(A.RCUST_ID)) AS out_RCUST_NM,   
               A.AMT_SUM                        AS out_AMT_SUM,
               A.VAT_SUM                        AS out_VAT_SUM,
               A.AMT_SUM + A.VAT_SUM            AS out_AMOUNT,
               A.SAWON_ID                       AS out_SAWON_ID,
               A.RSAWON_ID                      AS out_RSAWON_ID,
               F_SAWON_NM(A.SAWON_ID)           AS out_SAWON_NM,
               F_SAWON_NM(A.RSAWON_ID)          AS out_RSAWON_NM,
               DECODE(A.WIBAN_ORDER_CONF_YN,'0','대기','1','승인','반려')            AS out_WIBAN_ORDER_CONF_YN,
               F_RATE_DAY_BEFOREMONTH(to_char(add_months(sysdate,-1),'yyyymm'),A.CUST_ID) AS out_RATE_DAY -- 회전일  
          FROM SALE_ON.SALE0203 A
         WHERE A.SAWON_ID  in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) 
         /*WHERE A.SAWON_ID  in (select sawon_id from sale0007 where insa_sawon_id in  ( select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                                         where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                                            connect by prior dept_cd = up_dept_cd
                                                                                                              start with dept_cd = :v_insa_dept_cd)
                                                                                    )
                              )*/         
           AND A.YMD BETWEEN in_CDT_FR AND in_CDT_TO
           AND A.CUST_ID Like '%'||NVL(in_CUST_ID, '%')||'%'
           --AND A.RCUST_ID Like '%'||NVL(in_RCUST_ID, '%')||'%'
           ORDER BY A.GUMAE_NO DESC;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
