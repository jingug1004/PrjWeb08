CREATE PROCEDURE      SP_X_APP_UPDATEORDERSTOCK
(
    in_JAEGO      IN VARCHAR2,
    in_REQ_DATE   IN VARCHAR2,
    in_GUMAE_NO   IN VARCHAR2,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_UPDATEORDERSTOCK
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	UPDATE SALE.SALE0305 M
		   SET CHULGO_QTYST = NVL(CHULGO_QTYST,0) - (SELECT SUM(REQ_QTY) FROM SALE_ON.SALE0204 WHERE YMD = in_REQ_DATE AND GUMAE_NO = in_GUMAE_NO AND ITEM_ID = M.ITEM_ID) 
		 WHERE YMD = in_JAEGO
		   AND ITEM_ID IN (SELECT ITEM_ID FROM SALE_ON.SALE0204 WHERE YMD = in_REQ_DATE AND GUMAE_NO = in_GUMAE_NO)
		   AND STORE_LOC = '01';
		   
    IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 UPDATE ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 수정';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	
        ROLLBACK;
END ;
/
