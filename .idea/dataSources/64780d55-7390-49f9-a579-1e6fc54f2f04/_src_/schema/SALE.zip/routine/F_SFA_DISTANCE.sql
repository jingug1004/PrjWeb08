CREATE FUNCTION      F_SFA_DISTANCE
(
    in_lati1  IN  NUMBER,
    in_long1  IN  NUMBER,
    in_lati2  IN  NUMBER,
    in_long2  IN  NUMBER
    
) 
RETURN number IS

    v_lati1_inrad   number;
    v_long1_inrad   number;
    v_lati2_inrad   number;
    v_long2_inrad   number;
    
    v_latitude number;
    v_longitude number;
    
    v_a   number;
    v_b   number;
    v_distance number;
    
    
    
/*-------------------------------------------------------
  두좌표사이의 직선거리를 구한다.
-------------------------------------------------------*/    
   
BEGIN
    
    v_lati1_inrad := in_lati1 * (round(acos(-1),5) / 180.0);
    v_lati2_inrad := in_lati2 * (round(acos(-1),5) / 180.0);
    v_long1_inrad := in_long1 * (round(acos(-1),5) / 180.0);
    v_long2_inrad := in_long2 * (round(acos(-1),5) / 180.0);
    
    v_longitude := v_long2_inrad - v_long1_inrad;
    v_latitude := v_lati2_inrad - v_lati1_inrad;
    
    v_a := power(sin(v_latitude / 2.0),2.0) + cos(v_lati1_inrad) * cos(v_lati2_inrad) * power(sin(v_longitude / 2.0),2.0);

    v_b := 2.0 * atan2(sqrt(v_a),sqrt(1.0 - v_a));
        
    v_distance := 6376.5 * v_b;
    
    RETURN v_distance;
    
EXCEPTION WHEN NO_DATA_FOUND THEN
    RETURN '';
END;

/
