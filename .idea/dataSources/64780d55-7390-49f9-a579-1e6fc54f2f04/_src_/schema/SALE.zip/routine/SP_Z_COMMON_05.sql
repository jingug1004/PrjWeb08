CREATE PROCEDURE      SP_Z_COMMON_05
(
    in_GUBUN             IN  NUMBER,    -- 1:코드, 2:품목명
    in_ITEM              IN  VARCHAR2,  -- 코드/품목명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 제품 검색 팝업
 호출프로그램 :  
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼        
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;    
    GUBUN_NULL           EXCEPTION;
BEGIN
 
    IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
        RAISE GUBUN_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.CMITEMM   
     WHERE plantcode = '2000'
       AND itemdiv   = '04'     --완제품
       AND DECODE(in_GUBUN, 1, itemcode, itemname) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%');
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT itemcode                                AS out_ITEM_ID     -- 품목코드
              ,itemname                                AS out_ITEM_NM     -- 품목명
              ,itemunit                                AS out_STANDARD    -- 규격
          FROM ORAGMP.CMITEMM   
         WHERE plantcode = '2000'    
           AND itemdiv   = '04'     --완제품
           AND DECODE(in_GUBUN, 1, itemcode, itemname) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
         ORDER BY itemname;
    END IF;
    
EXCEPTION
WHEN GUBUN_NULL THEN
   out_CODE := 101;
   out_MSG  := '검색 구분코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
