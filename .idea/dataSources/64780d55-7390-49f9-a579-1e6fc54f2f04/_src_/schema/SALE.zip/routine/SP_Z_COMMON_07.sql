CREATE PROCEDURE      SP_Z_COMMON_07
(
    in_BANK_NM           IN  VARCHAR2,  -- 은행명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 은행검색 팝업 
 호출프로그램 :               
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼   
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
BEGIN

   --    insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDERCUST_LIST','1',sysdate,'in_CUST_CD'||in_CUST_CD||' / in_CUST_NM:'||in_CUST_NM||'/in_SAWON_ID:'||in_SAWON_ID);
 

    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.CMCOMMONM   
     WHERE cmmcode = 'PS32'
       AND divname like NVL(in_bank_nm,'')||'%';
    
    out_COUNT := v_num;
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
        
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT divcode   as out_BANK_CD
              ,divname   as out_BANK_NM
          FROM ORAGMP.CMCOMMONM   
         WHERE cmmcode = 'PS32'
           AND divname LIKE NVL(in_bank_nm,'')||'%'
         ORDER BY divname;
         
    END IF; 
    
    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_COMMON_07','1',sysdate,'in_BANK_NM:'||in_BANK_NM||'/v_num:'||TO_CHAR(v_num)  );
 

EXCEPTION   
    WHEN OTHERS THEN
       out_CODE := SQLCODE;
       out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
