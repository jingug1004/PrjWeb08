CREATE PROCEDURE      PROC_PDA_ORDER_MASTER_ON
  (in_flag IN VARCHAR2 DEFAULT NULL,
  in_ymd IN date,
  in_gumae_no IN VARCHAR2 default NULL,
  in_SAWON_ID IN VARCHAR2 default NULL, 
  in_CUST_ID IN VARCHAR2 default NULL, 
  in_RSAWON_ID IN VARCHAR2 default NULL, 
  in_RCUST_ID IN VARCHAR2 default NULL, 
  in_AMT_SUM IN VARCHAR2 default NULL, 
  in_VAT_SUM IN VARCHAR2 default NULL, 
  in_BIGO  IN VARCHAR2 default NULL, 
  out_gumae_no OUT VARCHAR2        )
IS
    ll_max number;
    b_yn boolean;
    
    V_gumae_no VARCHAR2(14);

    is_check_yn VARCHAR2(20);
    is_gicho_yul VARCHAR2(20);
    is_gicho_tot VARCHAR2(20)   ; 
    
    dec_yul VARCHAR2(20);
    ldec_tot VARCHAR2(20);
    is_yeondae_2 VARCHAR2(20);
    is_yeondae_3 VARCHAR2(20)   ; 
    
    is_dambo VARCHAR(20)  ;  
    
    is_BUDONG_YN VARCHAR(20)  ;
    is_USE_YN    VARCHAR(20)  ;
    is_EMAIL     VARCHAR(30)  ;
    is_ROOM_CNT  VARCHAR(30)  ;
    
    V_YEOSIN           NUMBER;
    V_CREDIT_LIMIT_AMT NUMBER;
    
    ll_count number;
    
BEGIN
    b_yn := false;
------잔고 확인 최근 2개월

insert into SFA_SP_CALLED_HIST values ('PROC_PDA_ORDER_MASTER_ON','1',sysdate, 'in_GUMAE_NO'||in_GUMAE_NO);
 
select count(*) as cnt 
into ll_count
from sale.sale0402i
where ymd > add_months(sysdate, -2)
and cust_id = in_CUST_ID and rcust_id = in_CUST_ID;

if ll_count = 0 then
    raise_application_error (-20000,'<2개월간 잔고 확인이 없습니다.>');
end if;

---------------거래처 확인
--order check BUDONG  출하중치처 확인


SELECT BUDONG_YN, USE_YN, EMAIL, ROOM_CNT
into    is_BUDONG_YN ,is_USE_YN, is_EMAIL, is_ROOM_CNT
FROM SALE0003 WHERE CUST_ID = in_cust_id  ;

if is_BUDONG_YN = 'Y' then
    raise_application_error (-20000,'<출하중지처 이므로 관련 부서로 문의 바랍니다>');
end if;

if is_USE_YN != 'Y' then
    raise_application_error (-20000,'<사용중지처 이므로 관련 부서로 문의 바랍니다>');
end if;

if is_EMAIL IS NULL then
    raise_application_error (-20000,'<이메일정보가 없습니다. 관련 부서로 문의 바랍니다>');
end if;

if is_ROOM_CNT IS NULL then
    raise_application_error (-20000,'<요양기관번호가 없습니다. 관련 부서로 문의 바랍니다>');
end if;

--------------거래처 확인 완료

/*-----------------------------------------------------------------------
   주문저장시 여신한도 체크
     --주문저장시 거래처 총여신 <= 거래처정보의 여신한도금액 이면 통과
     --쿼리값이 1이면 '여신초과되었습니다. 관리부에 문의하세요!''메세지를 보여준다.
------------------------------------------------------------------------*/
SELECT NVL(F.BEFORE_AMT,0) + NVL(F.MISU_AMT,0) - NVL(F.SU_AMT,0) + NVL(L.BILL_010_AMT,0) + NVL(L.BILL_020_AMT,0) + NVL(L.BILL_030_AMT,0) + NVL(L.BILL_100_AMT,0) + NVL(L.BILL_900_AMT,0) + NVL(G.GMISU_AMT, 0) YEOSIN,
       NVL(A.CREDIT_LIMIT_AMT,0) CREDIT_LIMIT_AMT
  INTO 
  V_YEOSIN, V_CREDIT_LIMIT_AMT       
  FROM SALE.SALE0003 A,
       ( SELECT CUST_ID , 
                SUM(BEFORE_AMT)  BEFORE_AMT,
                SUM(MISU_AMT)    MISU_AMT,
                SUM(SU_AMT)      SU_AMT
           FROM SALE.SALE0306
          WHERE YMD        = TO_DATE(TO_CHAR(in_ymd,'YYYY/MM')||'/01','YYYY/MM/DD')
            AND CUST_ID    = IN_cust_id
          GROUP BY CUST_ID
       ) F,
       (
         SELECT X.CUST_ID        CUST_ID ,
                NVL(SUM(DECODE(Y.BILL_GB,'010',Y.AMT)),0)  BILL_010_AMT,
                NVL(SUM(DECODE(Y.BILL_GB,'020',Y.AMT)),0)  BILL_020_AMT,
                NVL(SUM(DECODE(Y.BILL_GB,'025',Y.AMT)),0)  BILL_025_AMT,
                NVL(SUM(DECODE(Y.BILL_GB,'030',Y.AMT)),0)  BILL_030_AMT,
                NVL(SUM(DECODE(Y.BILL_GB,'035',Y.AMT)),0)  BILL_035_AMT,
                NVL(SUM(DECODE(Y.BILL_GB,'040',Y.AMT)),0)  BILL_040_AMT,
                NVL(SUM(DECODE(Y.BILL_GB,'100',Y.AMT)),0)  BILL_100_AMT,
                NVL(SUM(DECODE(Y.BILL_GB,'900',Y.AMT)),0)  BILL_900_AMT
           FROM SALE.SALE0401 X ,
                SALE.SALE0402 Y
          WHERE X.YMD       = Y.YMD
            AND X.JUNPYO_NO = Y.JUNPYO_NO 
            AND Y.END_YMD  >= SYSDATE
          GROUP BY X.CUST_ID
         ) L,
         (
           SELECT CUST_ID,
                  SUM(AMT_SUM + VAT_SUM) GMISU_AMT
             FROM SALE_ON.SALE0203
            WHERE RECEIPT_GB = '1'
              AND CUST_ID    = IN_cust_id
            GROUP BY CUST_ID
         ) G
 WHERE A.CUST_ID    = IN_cust_id
   AND A.CUST_ID    = F.CUST_ID(+)
   AND A.CUST_ID    = L.CUST_ID(+)
   AND A.CUST_ID    = G.CUST_ID(+) ;
            
IF (V_CREDIT_LIMIT_AMT <> 0) AND (V_YEOSIN + in_AMT_SUM + in_VAT_SUM - V_CREDIT_LIMIT_AMT) > 0 THEN
    raise_application_error (-20000,'<여신초과되었습니다. 관리부에 문의하세요!>');
END IF       ;


if in_flag = 'I' then
--------------------주문 데이터 확인--------------------------------
--order check 1
    DECLARE CURSOR cur_order_check IS    
          SELECT MAX(A.CHECK_YN) CHECK_YN,  --사용여부
                  MAX(A.YUL)      GICHO_YUL,--확보율
         MAX(A.TOT)      GICHO_TOT          --총여신
      --INTO :is_check_yn,:is_gicho_yul,:is_gicho_tot
        FROM(SELECT DECODE(CODE1,'01',BIGO) CHECK_YN,   
                              DECODE(CODE1,'02',BIGO) YUL,    
                              DECODE(CODE1,'03',BIGO) TOT      
                   FROM SALE0001 
                 WHERE CODE_GB = '4001' ) A  ;
                   
    BEGIN    
        FOR cur IN cur_order_check LOOP 
            is_check_yn := cur.CHECK_YN;
            is_gicho_yul := cur.GICHO_YUL;
            is_gicho_tot := cur.GICHO_TOT;

        END LOOP ;
        
        dbms_output.put_line('check1'  );
        dbms_output.put_line(is_check_yn  );
        dbms_output.put_line(is_gicho_yul  );
        dbms_output.put_line(is_gicho_tot  );
    end;
    
    
    --order check2
        DECLARE CURSOR cur_order_check IS    
          
          SELECT ROUND((NVL(H.SALE_DAMBO_AMT,0)/
        DECODE(((NVL(F.BEFORE_AMT,0) + NVL(F.MISU_AMT,0) -  
          NVL(F.SU_AMT,0))+(NVL(L.BILL_010_AMT,0) + NVL(L.BILL_020_AMT,0) + 
          NVL(L.BILL_030_AMT,0) +  NVL(L.BILL_100_AMT,0) + 
          NVL(L.BILL_900_AMT,0))),0,1,((NVL(F.BEFORE_AMT,0) + 
          NVL(F.MISU_AMT,0) -  NVL(F.SU_AMT,0))+(NVL(L.BILL_010_AMT,0) + 
          NVL(L.BILL_020_AMT,0) +  NVL(L.BILL_030_AMT,0) +   
          NVL(L.BILL_100_AMT,0) + NVL(L.BILL_900_AMT,0))))*100),2) YUL,
          NVL(F.BEFORE_AMT,0) + NVL(F.MISU_AMT,0) - NVL(F.SU_AMT,0) + 
          NVL(L.BILL_010_AMT,0) + NVL(L.BILL_020_AMT,0) + 
          NVL(L.BILL_030_AMT,0) +  NVL(L.BILL_100_AMT,0) +
          NVL(L.BILL_900_AMT,0) TOT,
         A.YEONDAE_2                  YEONDAE_2,
         A.YEONDAE_3                  YEONDAE_3
--INTO :ldec_yul, :ldec_tot,:ls_yeondae_2,:ls_yeondae_3
   FROM SALE0003 A,
        ( SELECT CUST_ID , 
                          SUM(BEFORE_AMT)  BEFORE_AMT,
                          SUM(MISU_AMT)    MISU_AMT,
                          SUM(SU_AMT)      SU_AMT
            FROM SALE0306
           WHERE YMD  = 
                           TO_DATE(TO_CHAR( to_date(in_ymd,'YYYY/MM/DD'),'YYYY/MM')||'/01','YYYY/MM/DD')
                 AND CUST_ID    = in_cust_id
           GROUP BY CUST_ID  ) F,
        ( SELECT X.CUST_ID, NVL(SUM(X.SALE_DAMBO_AMT),0) 
                          SALE_DAMBO_AMT
              FROM SALE0404 X
           WHERE X.CUST_ID    = in_cust_id
              AND NVL(X.CHULGO_YMD,TO_DATE('2999/01/01','YYYY/MM/DD')) = 
                        TO_DATE('2999/01/01','YYYY/MM/DD')
           GROUP BY X.CUST_ID ) H,
        (  SELECT X.CUST_ID        CUST_ID ,
                           NVL(SUM(DECODE(Y.BILL_GB,'010',Y.AMT)),0)  BILL_010_AMT,
                           NVL(SUM(DECODE(Y.BILL_GB,'020',Y.AMT)),0)  BILL_020_AMT,
                           NVL(SUM(DECODE(Y.BILL_GB,'030',Y.AMT)),0)  BILL_030_AMT,
                           NVL(SUM(DECODE(Y.BILL_GB,'100',Y.AMT)),0)  BILL_100_AMT,
                           NVL(SUM(DECODE(Y.BILL_GB,'900',Y.AMT)),0)  BILL_900_AMT
              FROM SALE0401 X ,  SALE0402 Y
           WHERE X.YMD       = Y.YMD
               AND X.JUNPYO_NO = Y.JUNPYO_NO 
               AND Y.END_YMD  >= SYSDATE
           GROUP BY X.CUST_ID ) L
 WHERE A.CUST_ID    = in_cust_id
      AND A.CUST_ID    = F.CUST_ID(+)
      AND A.CUST_ID    = H.CUST_ID(+)
      AND A.CUST_ID    = L.CUST_ID(+);



    BEGIN    
        FOR cur IN cur_order_check LOOP 
            dec_yul := cur.YUL;
            ldec_tot := cur.TOT;
            is_yeondae_2 := cur.YEONDAE_2;
            is_yeondae_3 := cur.YEONDAE_3;

        END LOOP ;
        dbms_output.put_line(dec_yul  );
        dbms_output.put_line(ldec_tot  );
        dbms_output.put_line(is_yeondae_2   );
        dbms_output.put_line(is_yeondae_3  );
        dbms_output.put_line('check2'  );
    end;
       


if is_check_yn = 'Y' then
    if substr(in_cust_id,0,2) = '11' then
        if is_yeondae_2 = 'Y' then
        
            DECLARE CURSOR cur_order_check IS    
              SELECT NVL(BIGO,'0')     DAMBO   --담보
                 --INTO :is_dambo
               FROM SALE0001 
             WHERE CODE_GB = '4001'
                  AND CODE1   = '04';
                  
            BEGIN    
                FOR cur IN cur_order_check LOOP 
                    is_dambo := cur.DAMBO;

                END LOOP ;
                dbms_output.put_line('check DAMBO'  );
                dbms_output.put_line(is_dambo );
            end;
    
        end if;
        
        if ( (ldec_tot > (is_gicho_tot + is_dambo))  and  (dec_yul < is_gicho_yul) ) then
            raise_application_error (-20000,'<통제 여신 규정을 위반 하였습니다.>');
        end if;
        
    end if;
end if;
    
----------------------------잔고 확인 추가 예정

-----------------------------그룹체크
-------------------------------

 
---------------------------주문 확인 완료------------------------------

    --SEQ 주문 번호 가져오기
    sale.SP_SYS100C_MAX_VALUE('SALE0203', TO_CHAR(in_ymd,'YYYYMMDD'), null,null, null, null, ll_max );
    dbms_output.put_line(ll_max  );

     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패 SP_SYS100C_MAX_VALUE');
            ROLLBACK;
            return;
     END IF;
     
--INSERT 
    /*INSERT INTO SALE.SALE0203 (
   GUMAE_NO, GUMAE_GB, YMD, 
   SAWON_ID, CUST_ID, RSAWON_ID, 
   RCUST_ID, GYULJAE_GB, TAX_TYPE, 
   DECIMAL_PROC, 
   AMT_SUM, VAT_SUM, BIGO, 
   GUBUN, ACCEPT_YN) 
VALUES () 
 
--초기값
GUMAE_GB = '01'
GYULJAE_GB = '01' 
TAX_TYPE = '01'
DECIMAL_PROC = '03'
GUBUN = '01'
ACCEPT_YN = 'Y'*/

--SALE_ON.sale0203

    V_gumae_no := TO_CHAR(in_YMD,'YYYYMMDD')||TRIM(TO_CHAR(ll_max,'0000'));

      -- select * from SLAE_ON.SALE0203 where sawon_id = '11'
       
    INSERT INTO SALE_on.SALE0203 (
       GUMAE_NO, GUMAE_GB, YMD, 
       SAWON_ID, CUST_ID, RSAWON_ID, 
       RCUST_ID, GYULJAE_GB, TAX_TYPE, 
       DECIMAL_PROC, 
       GUBUN, ACCEPT_YN
       ,AMT_SUM, VAT_SUM
       ,INPUT_YMD, INPUT_ID
       , slip_gb,RECEIPT_GB)
    VALUES  (
       V_gumae_no, '01', in_YMD, 
       in_SAWON_ID, in_CUST_ID, in_RSAWON_ID, 
       in_RCUST_ID, '01', '01', 
       '03', 
       '01', 'Y'
       ,in_AMT_SUM, in_VAT_SUM
       ,sysdate, in_SAWON_ID
       ,'2','1')  ;
        
     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패  INSERT INTO SALE.SALE0401');
            ROLLBACK;
            return;
     END IF;
        out_gumae_no := V_gumae_no;
/*
else

    --order status check
    DECLARE CURSOR cur_order_status IS    
        select accept_yn from sale0203 where gumae_no = in_gumae_no    
    BEGIN    
        FOR csale0203 IN cur_order_status LOOP 
            if csale0203.accept_yn = 'Y' then
                b_yn := true      
            end if  
        END LOOP 
        dbms_output.put_line(ll_max  )
    end
    
    if b_yn = true then
   dbms_output.put_line('update'  )
        UPDATE SALE.SALE0203
        SET    GUMAE_NO     = in_GUMAE_NO,
               YMD          = in_YMD,
               SAWON_ID     = in_SAWON_ID,
               CUST_ID      = in_CUST_ID,
               RSAWON_ID    = in_RSAWON_ID,
               RCUST_ID     = in_RCUST_ID,
               AMT_SUM      = in_AMT_SUM,
               VAT_SUM      = in_VAT_SUM,
               BIGO         = in_BIGO
        WHERE  YMD          = in_YMD
        AND    CUST_ID      = in_CUST_ID
        AND    SAWON_ID     = in_SAWON_ID
        AND    GUMAE_GB     = '01'
        AND    GUMAE_NO     = in_GUMAE_NO
    
    else raise_application_error (-20000,'확정된 주문 입니다')
    
    end if    
    
    IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패 UPDATE SALE.SALE0203')
            ROLLBACK
            return
    END IF*/
 
end if;
        
end;

/
