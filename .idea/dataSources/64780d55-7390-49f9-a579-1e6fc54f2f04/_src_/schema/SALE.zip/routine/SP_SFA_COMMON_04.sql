CREATE PROCEDURE      SP_SFA_COMMON_04
(
    in_GUBUN             IN  NUMBER,    -- 1:사번, 2:이름
    in_ITEM              IN  VARCHAR2,  -- 사번/이름
    in_SAWON_ID          IN  VARCHAR2,  -- 로그인 사번
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 사원 검색 팝업 -로그인한 사번에 따라 하위사원들을 조회한다.
 호출프로그램 :방문>방문활동내역 담당자 선택버튼
 수정내역     2014.08.18 CHOE - 기획실 인형진 요청 팀장이 아니더라도 부서 권한만 있다면 확인 가능하도록
              2015.04.09 KTA  - 기획실 인형진 확인 임시팀장인 경우는 현재 송민호대리뿐이라 인사에서 지정된 직책으로 하위사원 가져오는 처리해도 된다고 함. 
                              - admin 으로 로그인 했을 경우 전체 사원조회하도록 프로그램 되어있지 않아서 되도록 수정함.
              2015.06.08 KTA  - 임시팀장 직책코드 추가관련 수정
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER; 
    
    v_insa_sawon_id      VARCHAR2(7); --인사사번 
    v_insa_dept_cd       VARCHAR2(4); --인사부서
    v_assgn_cd           VARCHAR2(5); --인사부서
    v_pda_auth          VARCHAR2(1); --영업시스템권한  A:전체,P-개인,D-부서 
    
    GUBUN_NULL           EXCEPTION;
BEGIN

    
    IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
        RAISE GUBUN_NULL;
    END IF;  
 
    --로그인사원의 인사사번       
    --select insa_sawon_id into v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID and gubun = 'Y'; 
    
    select pda_auth,insa_sawon_id into v_pda_auth, v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID --and gubun = 'Y' --CHOE 20130123
    ;
    
    
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    --select assgn_cd into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    
    --CHOE 20140818 기획실 인형진 요청 팀장이 아니더라도 부서 권한만 있다면 확인 가능하도록
    --select decode(v_pda_auth,'D','27030',assgn_cd) into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    
    --KTA 20150409 기획실 인형진 확인 임시팀장인 경우는 현재 송민호대리뿐이라 인사에서 지정된 직책으로 하위사원 가져오는 처리해도 된다고 함.
    select decode(v_pda_auth,'A','27000',assgn_cd) into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    
                
    --인사기본테이블에서 총괄팀장 이면 한레벨 상위부서코드를 찾고 팀장이면 자기부서를 찾는다.
    if v_assgn_cd = '27010' or v_assgn_cd = '27020' or v_assgn_cd = '27025'  or v_assgn_cd = '27018'  or v_assgn_cd = '27026' then --본부장,관리이사,총괄지점장 부본부장 선임지정장
        select dept_cd
          into v_insa_dept_cd  
          from hr_co_depart_0 
         where use_yn = 'Y' and level = 2
       connect by dept_cd = prior up_dept_cd start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id);
                                   
    elsif (v_assgn_cd = '27027' or v_assgn_cd = '27030' or v_assgn_cd = '27035') then --팀장,임시팀장  
        select dept_cd into v_insa_dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    end if;
    
    
    --총괄팀장이면 인사시스템에서 총괄팀장부서 한단계 상위부서코드의 모든 하위부서의 사원가져온다.
    --팀장이면 팀장소속부서의 모든 사원가져온다.
    SELECT COUNT(*)
      INTO v_num
      FROM (SELECT * 
              FROM SALE0007 
             WHERE INSA_SAWON_ID IN (SELECT emp_no 
                                       FROM HR_HC_EMPBAS_0 
                                      WHERE dept_cd IN ( select dept_cd from hr_co_depart_0 connect by prior dept_cd = up_dept_cd start with dept_cd = v_insa_dept_cd)
                                        AND DECODE(in_GUBUN, 1, emp_no, emp_ko_nm ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                    )
               AND GUBUN      = 'Y'     --재직자 
               AND v_assgn_cd in ('27010','27020','27025','27018','27026') --본부장,관리이사,총괄지점장 부본부장 선임지점장
             UNION ALL 
            SELECT *
              FROM SALE0007 
             WHERE INSA_SAWON_ID IN (SELECT emp_no 
                                       FROM HR_HC_EMPBAS_0 
                                      WHERE dept_cd = v_insa_dept_cd 
                                        AND DECODE(in_GUBUN, 1, emp_no, emp_ko_nm ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%') 
                                    )
               AND GUBUN      = 'Y'     --재직자 
               AND v_assgn_cd in ('27027','27030','27035') -- 팀장,임시팀장 
             UNION ALL 
            SELECT *
              FROM SALE0007 
             WHERE INSA_SAWON_ID IN (SELECT emp_no 
                                       FROM HR_HC_EMPBAS_0 
                                      WHERE DECODE(in_GUBUN, 1, emp_no, emp_ko_nm ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                     ) 
               AND GUBUN      = 'Y'     --재직자 
               AND v_assgn_cd = '27000' --Admin 
           ) A
    ; 
                   
                   
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT A.DEPT_CD          AS out_DEPT_CD    -- 부서코드
              ,(select dept_nm from sale0008 where dept_cd = A.dept_cd) AS out_DEPT_NM    -- 부서명
              ,A.SAWON_ID         AS out_SAWON_ID   -- 사원 ID
              ,'  '||A.SAWON_NM||' ('||ASSGN_NM AS out_SAWON_NM    -- 사원명              
          FROM (SELECT a.* 
                      ,(select (select comn_nm from hr_co_common_0 where comn_cd = z.assgn_cd )  ||')' 
                          from hr_hc_empbas_0 z where z.emp_no = a.insa_sawon_id) AS ASSGN_NM
                  FROM SALE0007 a
                 WHERE INSA_SAWON_ID IN (SELECT emp_no 
                                           FROM HR_HC_EMPBAS_0 
                                          WHERE dept_cd IN ( select dept_cd from hr_co_depart_0 connect by prior dept_cd = up_dept_cd start with dept_cd = v_insa_dept_cd)
                                            AND DECODE(in_GUBUN, 1, emp_no, emp_ko_nm) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                        )
                   AND GUBUN      = 'Y'     --재직자 
                   AND v_assgn_cd in ('27010','27020','27025','27018','27026') --본부장,관리이사,총괄지점장 부본부장 선임지점장
                 UNION ALL 
                SELECT a.*
                      ,(select (select comn_nm from hr_co_common_0 where comn_cd = z.assgn_cd ) ||')' 
                          from hr_hc_empbas_0 z where emp_no = a.insa_sawon_id) AS ASSGN_NM
                  FROM SALE0007 a
                 WHERE INSA_SAWON_ID IN (SELECT emp_no 
                                           FROM HR_HC_EMPBAS_0 
                                          WHERE dept_cd = v_insa_dept_cd  
                                            AND DECODE(in_GUBUN, 1, emp_no, emp_ko_nm ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                        ) 
                   AND GUBUN      = 'Y'     --재직자 
                   AND v_assgn_cd in ('27027','27030','27035') -- 팀장,임시팀장 
                 UNION ALL 
                SELECT a.*
                      ,(select (select comn_nm from hr_co_common_0 where comn_cd = z.assgn_cd ) ||')' 
                          from hr_hc_empbas_0 z where emp_no = a.insa_sawon_id) AS ASSGN_NM
                  FROM SALE0007 a
                 WHERE INSA_SAWON_ID IN (SELECT emp_no 
                                           FROM HR_HC_EMPBAS_0 
                                          WHERE DECODE(in_GUBUN, 1, emp_no, emp_ko_nm ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%') 
                                        )
                   AND GUBUN      = 'Y'     --재직자 
                   AND v_assgn_cd = '27000' --Admin
               ) A
         ORDER BY DEPT_CD,SAWON_NM;
         
    END IF;
    
EXCEPTION
WHEN GUBUN_NULL THEN
   out_CODE := 101;
   out_MSG  := '검색 구분코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
