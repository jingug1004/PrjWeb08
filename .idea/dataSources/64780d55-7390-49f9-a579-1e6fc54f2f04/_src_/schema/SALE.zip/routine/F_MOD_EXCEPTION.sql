CREATE function      F_MOD_EXCEPTION
        ( I_BUNJA      NUMBER,
          I_BUNMO      NUMBER)
   RETURN NUMBER
AS
   V_RESULT_NUMBER    Number ;
------------------------------------
--제수가 0일때 에러를 없애는 합수    
------------------------------------
BEGIN
  
  SELECT DECODE(I_BUNMO, 0, 0, NULL, 0, I_BUNJA / I_BUNMO)
    INTO V_RESULT_NUMBER
    FROM DUAL;
 
  RETURN V_RESULT_NUMBER;
  
  EXCEPTION WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(-20002, substrb(SQLERRM,1,250));

END;

/
