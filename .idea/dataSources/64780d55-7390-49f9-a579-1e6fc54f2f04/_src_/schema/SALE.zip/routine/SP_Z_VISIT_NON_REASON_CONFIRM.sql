CREATE PROCEDURE      SP_Z_VISIT_NON_REASON_CONFIRM
 (
    in_SAWON_ID          IN  VARCHAR2,   
    in_CDT               IN  VARCHAR2,    
    in_PROCESS           IN  VARCHAR2,    
    in_COUNT             IN NUMBER,
    in_DATASET            IN VARCHAR2 default NULL,
    out_CODE             out NUMBER,
    out_MSG              out VARCHAR2
  )
IS
 /*---------------------------------------------------------------------------
  select * from SFA_VISIT_NON_REASON;
COMMENT ON TABLE SALE.SFA_VISIT_NON_REASON IS '미방문사유';
COMMENT ON COLUMN SALE.SFA_VISIT_NON_REASON.SALES_PLAN_NO IS '방문일자';
COMMENT ON COLUMN SALE.SFA_VISIT_NON_REASON.EMP_NO IS '사번';
COMMENT ON COLUMN SALE.SFA_VISIT_NON_REASON.REASON_GB1 IS '출근콜인정 0/1';
COMMENT ON COLUMN SALE.SFA_VISIT_NON_REASON.REASON_GB2 IS '퇴근콜인정 0/1';
COMMENT ON COLUMN SALE.SFA_VISIT_NON_REASON.REASON_GB3 IS '황동콜인정 0/1';
COMMENT ON COLUMN SALE.SFA_VISIT_NON_REASON.NONVISIT_REASON IS '미방문사유';
COMMENT ON COLUMN SALE.SFA_VISIT_NON_REASON.SEONGINJA_EMP_NO IS '승인자사번';
COMMENT ON COLUMN SALE.SFA_VISIT_NON_REASON.SEONGINJA_CONF_YN IS '승인자승인여부 0-대기 1-승인 2-반려';
COMMENT ON COLUMN SALE.SFA_VISIT_NON_REASON.COMPANY_CONF_YN IS '기획부승인여부 0-대기 1-승인 2-반려';
 ---------------------------------------------------------------------------*/
 
    v_data    VARCHAR2(25); -- 해당사원
    v_empno   VARCHAR2(12); -- 해당사원
    v_date    VARCHAR2(10);  -- 날자
    
    ERROR_RAISE EXCEPTION;
    
BEGIN      

    FOR ll_loop IN 1.. in_COUNT LOOP  
        v_data  := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 1 + 24*(ll_loop -1),  24));  
        v_date  := TRIM(SUBSTR(v_data, 1 , 12));  
        v_empno  := TRIM(SUBSTR(v_data, 13 , 12));  
        
        update SFA_VISIT_NON_REASON
           set SEONGINJA_CONF_YN = in_PROCESS, 
               SEONGINJA_EMP_NO= in_SAWON_ID 
         where   SALES_PLAN_NO=v_date  
           and EMP_NO=v_empno ;
        commit;
        
    END LOOP; 
         
    out_CODE  := 0;
    out_MSG   := '저장 완료';              
                  


EXCEPTION
     WHEN ERROR_RAISE THEN 
          ROLLBACK; 

     WHEN OTHERS THEN
          out_CODE := SQLCODE;
          out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 

END;
/
