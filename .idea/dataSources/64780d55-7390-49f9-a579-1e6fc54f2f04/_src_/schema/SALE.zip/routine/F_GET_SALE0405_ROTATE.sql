CREATE function      F_GET_SALE0405_ROTATE ( 
        A_CUST_ID VARCHAR2, -- 직납처
        A_RCUST_ID VARCHAR2, -- 간납처
        A_ITEM_ID VARCHAR2, -- 제품코드
        A_YMD DATE,     -- 전표일자
        A_GUBUN VARCHAR2  -- 구분('BAS_AMT','BAL_AMT','YAK_AMT','YAK_AMT1','AMT_YUL','C','GC' ,'ETC','BIGO') 
)
        RETURN VARCHAR2
AS
        user_err exception   ;
        V_TRAN_YMD_CD VARCHAR2(14);
        V_INPUT_SEQ VARCHAR2(14);
        V_YMD DATE ;
        n_rtn_value VARCHAR2(250);
        v_curr_error VARCHAR2(250);

        /*----------------------------------------------------------------
        이력관리적용부터 사용되는 평션 (2010.01.01 일부터 유효)
        호출하는곳 : 영업erp 회전일관리 w_sale03r03_01  
        20170.2.07 kta : 시행종료일자 막음 : 시행종료일은 다음 이력이 생길때 자동으로 적용일전날짜로 변경하므로 시행종료일자를 적용하면 해당주문시점의 이력을 찾을수 없어서 막음
  
        CHOE 2017.04.05 회전일 관리를 위해 F_GET_SALE0405_AMTH 에서 분리 하여 사용 : 쓰지 않는 flag가 있어서 유지 한다.  A_GUBUN = 'C' 
        ----------------------------------------------------------------*/
BEGIN

        v_curr_error := A_CUST_ID||':'||A_RCUST_ID||':'||A_ITEM_ID||':'||to_char(A_YMD,'yyyymmdd')||':'||A_GUBUN||':'||V_TRAN_YMD_CD||':'||V_INPUT_SEQ;
       
        SELECT max(TRAN_YMD_CD)
        INTO V_TRAN_YMD_CD 
        FROM SALE.SALE0405H
        WHERE CUST_ID = A_CUST_ID
        AND RCUST_ID = A_RCUST_ID
        AND ITEM_ID = A_ITEM_ID        
        --AND YMD >= A_YMD
        --AND APPL_DATE <= TO_CHAR(A_YMD,'YYYYMMDD')
        AND TRAN_DATE <= TO_CHAR(A_YMD,'YYYYMMDD')   --- 회전일관리 1에서 는 이 컬럼과 비교하여 이력을 가져 오도록 한다.
        ;
          
        SELECT max(INPUT_SEQ)
        INTO V_INPUT_SEQ
        FROM SALE.SALE0405H
        WHERE CUST_ID = A_CUST_ID
        AND RCUST_ID = A_RCUST_ID      
        AND ITEM_ID = A_ITEM_ID       
        AND TRAN_YMD_CD = V_TRAN_YMD_CD
        ;          
                    
		  
	   IF V_TRAN_YMD_CD IS NULL  THEN
	        RETURN '0';
	   END IF;
	    
	   
	  
        If A_GUBUN = 'BAS_AMT' Then
                BEGIN
                        SELECT TO_CHAR(NVL(BAS_AMT,0))
                        INTO n_rtn_value
                        FROM SALE0405H
                        WHERE CUST_ID     = A_CUST_ID
                        AND RCUST_ID    = A_RCUST_ID
                        AND ITEM_ID     = A_ITEM_ID
                        AND TRAN_YMD_CD = V_TRAN_YMD_CD
                        AND INPUT_SEQ   = V_INPUT_SEQ;
                        
                        IF SQL%NOTFOUND THEN
                                RETURN '0';
                        END IF;
               
                EXCEPTION WHEN OTHERS THEN RETURN 
                        '0';
                END;
        End if ;


        If A_GUBUN = 'BAL_AMT' Then
                BEGIN
                        SELECT TO_CHAR(NVL(BAL_AMT,0))
                        INTO n_rtn_value
                        FROM SALE0405H
                        WHERE CUST_ID = A_CUST_ID
                        AND RCUST_ID = A_RCUST_ID
                        AND ITEM_ID = A_ITEM_ID
                        AND TRAN_YMD_CD = V_TRAN_YMD_CD
                        AND INPUT_SEQ = V_INPUT_SEQ;
                      
                        IF SQL%NOTFOUND THEN
                                RETURN '0';
                        END IF;
                        
                EXCEPTION WHEN OTHERS THEN RETURN 
                        '0';
                END;
        End if ;
        
        
        If A_GUBUN = 'YAK_AMT' Then
                BEGIN
                
                        SELECT TO_CHAR(NVL(YAK_AMT,0))  
                        INTO n_rtn_value
                        FROM SALE0405H
                        WHERE CUST_ID = A_CUST_ID
                        AND RCUST_ID = A_RCUST_ID
                        AND ITEM_ID = A_ITEM_ID
                        AND TRAN_YMD_CD = V_TRAN_YMD_CD
                        AND INPUT_SEQ = V_INPUT_SEQ;
                        
                        IF SQL%NOTFOUND THEN
                                RETURN '0';
                        END IF;
                   
                EXCEPTION WHEN OTHERS THEN RETURN
                        '0';
                END;
        End if ;
        
        
        If A_GUBUN = 'YAK_AMT1' Then
                BEGIN
                
                        SELECT TO_CHAR(NVL((ROUND(TRUNC(YAK_AMT / 1.1) / 10) * 10) * 1.1,0))  
                        INTO n_rtn_value
                        FROM SALE0405H
                        WHERE CUST_ID = A_CUST_ID
                        AND RCUST_ID = A_RCUST_ID
                        AND ITEM_ID = A_ITEM_ID
                        AND TRAN_YMD_CD = V_TRAN_YMD_CD
                        AND INPUT_SEQ = V_INPUT_SEQ;
                
                        IF SQL%NOTFOUND THEN
                                RETURN '0';
                        END IF;
                
                EXCEPTION WHEN OTHERS THEN RETURN 
                        '0';
                END;
        End if ;
        
        
        If A_GUBUN = 'AMT_YUL' Then
                BEGIN
                
                        SELECT TO_CHAR(NVL(AMT_YUL,0))
                        INTO n_rtn_value
                        FROM SALE0405H
                        WHERE CUST_ID = A_CUST_ID
                        AND RCUST_ID = A_RCUST_ID
                        AND ITEM_ID = A_ITEM_ID
                        AND TRAN_YMD_CD = V_TRAN_YMD_CD
                        AND INPUT_SEQ = V_INPUT_SEQ;
                        
                        IF SQL%NOTFOUND THEN
                                RETURN '0';
                        END IF;
                        
                EXCEPTION WHEN OTHERS THEN RETURN '0';
                END;
        End if ;
        
        
        If A_GUBUN = 'C' Then
                BEGIN
                
                        SELECT TO_CHAR(NVL(C,0))
                        INTO n_rtn_value
                        FROM SALE0405H
                        WHERE CUST_ID = A_CUST_ID
                        AND RCUST_ID = A_RCUST_ID
                        AND ITEM_ID = A_ITEM_ID
                        AND TRAN_YMD_CD = V_TRAN_YMD_CD
                        AND INPUT_SEQ = V_INPUT_SEQ;
                        
                        IF SQL%NOTFOUND THEN
                                RETURN '0';
                        END IF;
                        
    	        EXCEPTION WHEN OTHERS THEN RETURN 
                        '0';
                END;
        End if ;
        
        
        If A_GUBUN = 'GC' Then
                BEGIN
                
                        SELECT TO_CHAR(NVL(GC,0))
                        INTO n_rtn_value
                        FROM SALE0405H
                        WHERE CUST_ID = A_CUST_ID
                        AND RCUST_ID = A_RCUST_ID
                        AND ITEM_ID = A_ITEM_ID
                        AND TRAN_YMD_CD = V_TRAN_YMD_CD
                        AND INPUT_SEQ = V_INPUT_SEQ;
                        
                        IF SQL%NOTFOUND THEN
                                RETURN '0';
                        END IF;
                        
                EXCEPTION WHEN OTHERS THEN RETURN 
                        '0';
                END;
        End if ;
       
       
        If A_GUBUN = 'ETC' Then
                BEGIN
                
                        SELECT TO_CHAR(NVL(ETC,0))
                        INTO n_rtn_value
                        FROM SALE0405H
                        WHERE CUST_ID = A_CUST_ID
                        AND RCUST_ID = A_RCUST_ID
                        AND ITEM_ID = A_ITEM_ID
                        AND TRAN_YMD_CD = V_TRAN_YMD_CD
                        AND INPUT_SEQ = V_INPUT_SEQ;
                
                IF SQL%NOTFOUND THEN
                        RETURN '0';
                END IF;
                
                EXCEPTION WHEN OTHERS THEN RETURN 
                        '0';
                END;
        End if ;
       
       
        If A_GUBUN = 'BIGO' Then
                BEGIN
                
                        SELECT BIGO
                        INTO n_rtn_value
                        FROM SALE0405H
                        WHERE CUST_ID = A_CUST_ID
                        AND RCUST_ID = A_RCUST_ID
                        AND ITEM_ID = A_ITEM_ID
                        AND TRAN_YMD_CD = V_TRAN_YMD_CD
                        AND INPUT_SEQ = V_INPUT_SEQ;
                
                        IF SQL%NOTFOUND THEN
                                RETURN '0';
                        END IF;
                
                EXCEPTION WHEN OTHERS THEN RETURN 
                        '0';
                END;
        End if ;
       
        RETURN n_rtn_value;

EXCEPTION WHEN user_err THEN
	                   RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
	              WHEN OTHERS THEN
	                   RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;
/
