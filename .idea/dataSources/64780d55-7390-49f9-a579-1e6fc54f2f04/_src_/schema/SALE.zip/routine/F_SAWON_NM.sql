CREATE FUNCTION      F_SAWON_NM  -- 사원명 가져오기
(
    in_SAWON_ID  IN  VARCHAR2
) 
RETURN VARCHAR2 IS

    v_sawon_nm   VARCHAR2(20);
    
BEGIN

    SELECT SAWON_NM
      INTO v_sawon_nm
      FROM SALE0007
     WHERE SAWON_ID    = in_SAWON_ID;
        
    RETURN v_sawon_nm;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;

/
