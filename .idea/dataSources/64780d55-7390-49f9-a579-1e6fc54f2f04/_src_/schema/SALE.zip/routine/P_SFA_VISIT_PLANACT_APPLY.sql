CREATE PROCEDURE      P_SFA_VISIT_PLANACT_APPLY IS

        /*-------------------------------------------------------------------
        DESCRIPTION
        변경일자 - 20160627         
       
        SFA_VISIT_PLANACT 자동 승인
        일주일에 한번 월요일 오전 8시 30분에 전체 자료를 승인한다고 함        
        -------------------------------------------------------------------*/
        V_CNT NUMBER; --등록된 자료
        V_WEEK VARCHAR2(20) ; 
        V_HH24 VARCHAR2(2) ; 
        
        V_SALES_PLAN_NO_FROM SFA_VISIT_PLANACT.SALES_PLAN_NO%TYPE;
        V_SALES_PLAN_NO_TO SFA_VISIT_PLANACT.SALES_PLAN_NO%TYPE;        
        
        V_CURR_ERROR VARCHAR2(1000) ;
        USER_ERR     EXCEPTION;   

BEGIN   
        --0. 월요일만 실행
        SELECT TO_CHAR(SYSDATE ,'DAY')
        INTO V_WEEK  
        FROM DUAL
        ;
        
        IF V_WEEK <> '월요일' THEN
            RETURN;
        END IF;
        
        --0. 8시 ~9시 사이만 실행   30분 단위로 실행
        SELECT TO_CHAR(SYSDATE ,'HH24') 
        INTO V_HH24         
        FROM DUAL
        ; 
        
        IF V_HH24 <> '08' THEN
            RETURN;
        END IF;
        
        --1. 오늘 날짜 
        V_SALES_PLAN_NO_FROM := TO_CHAR(SYSDATE, 'YYYYMMDD');
        V_SALES_PLAN_NO_TO := TO_CHAR(SYSDATE + 4  , 'YYYYMMDD');
        
        --2. 자료의 생성은 프로그램 화면에서 처리 된다. 생성된 자료가 있다면 (출석여부와 작성완료 여부 N인 경우)
        V_CNT := 0;
        SELECT COUNT(*)
        INTO V_CNT
        FROM SFA_VISIT_PLANACT
        WHERE SALES_PLAN_NO BETWEEN V_SALES_PLAN_NO_FROM AND V_SALES_PLAN_NO_TO
        AND VISIT = 'N'-- 방문대기
        AND APPLY_YN = 'N'  --승인대기 
        ;
        
        --3. 승인 할 DATA가 존재한다.                             
        IF V_CNT >= 1 THEN   
                UPDATE SFA_VISIT_PLANACT SET APPLY_YN = 'Y'                                                         
                WHERE SALES_PLAN_NO BETWEEN V_SALES_PLAN_NO_FROM AND V_SALES_PLAN_NO_TO
                AND VISIT = 'N'-- 방문대기
                AND APPLY_YN = 'N'  --승인대기 
                ;  
        END IF; 


EXCEPTION 
        WHEN USER_ERR THEN
                RAISE_APPLICATION_ERROR(-20001, V_CURR_ERROR);
                ROLLBACK;           
                RETURN;
        WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR(-20001, V_CURR_ERROR);
                ROLLBACK;             
                RETURN;       
END  P_SFA_VISIT_PLANACT_APPLY;
/
