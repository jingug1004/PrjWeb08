CREATE PROCEDURE      SP_SFA_COLLECT_MAX_105
(
    in_GUBUN             IN  VARCHAR2, -- 의미없는 값으로 1들어옴.
    in_CUST_ID           IN  VARCHAR2, 
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 수금전표번호채번
 호출프로그램  : 카드수금화면
            수기카드화면
 수정기록 : 
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    

    ll_max   NUMBER;
    ll_count NUMBER;
    v_SAWON_ID VARCHAR2(7);
    ERROR_EXCEPTION     EXCEPTION;
    
    
BEGIN 

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_MAX_105',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate,'in_CUST_ID:'||in_CUST_ID||'/in_GUBUN '||in_GUBUN );
--commit;

    IF in_CUST_ID IS NULL OR TRIM(in_CUST_ID) = '' THEN
        out_COUNT := 0;
        out_CODE := 1;
        out_MSG := '<거래처를 반드시 선택해야 합니다.>'; 
        RAISE ERROR_EXCEPTION;
    END IF;
    
   -- 담당사원체크
    BEGIN
        select empcode 
        into v_SAWON_ID
        from ORAGMP.CMCUSTM
        where plantcode = '1000'
          and custcode = in_CUST_ID ; 
        IF v_SAWON_ID IS NULL OR TRIM(v_SAWON_ID) = ''  THEN
            out_CODE := SQLCODE;
            out_MSG  := '<이거래처로 담당자가 지정되어 있지 않습니다.관리부로 연락하십시오. >';
            RAISE ERROR_EXCEPTION;           
        END IF;
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '<이거래처로 담당자가 지정되어 있지 않습니다.관리부로 연락하십시오. >';
        RAISE ERROR_EXCEPTION;
    END;      

   --중지거래처  통제(다른거래처에 수금입력 오류방지)   
    SELECT COUNT(*) INTO ll_count  FROM ORAGMP.CMCUSTM WHERE custcode = in_CUST_ID AND useyn = 'N';
    IF ll_count > 0 THEN
        out_COUNT := 0;
        out_CODE := 1;
        out_MSG := '<중지된 거래처입니다. 관리부로 연락하십시오.>'; 
        RAISE ERROR_EXCEPTION;
    END IF; 
     
    ll_max := 0; 
            
    --수금번호채번 
    SELECT MAX(colno) into ll_max from ORAGMP.SLCOLM where plantcode = '1000' and coldate = to_char(SYSDATE,'YYYY-MM-DD');
    IF SQLCODE <> 0 THEN
        out_COUNT := 0;
        out_CODE := 1;
        out_MSG := '<수금번호채번 오류입니다. 관리부로 연락하십시오.>'; 
        RAISE ERROR_EXCEPTION;
    ELSE
       IF ll_max is null THEN
          ll_max := trim(to_char(to_number(to_char(SYSDATE,'YYYYMMDD')))||'0001');
       ELSE
          ll_max := trim(to_char(to_number(ll_max) + 1,'000000000000'));
       END IF;
    END IF;
                

    IF ll_max < 1 THEN
        out_COUNT := 0;
        out_CODE := 1;
        out_MSG := '수금번호 생성 오류'; 
    ELSE
        out_COUNT := 1;
        out_CODE := 0;
        out_MSG := '수금번호 생성완료'; 
    
        OPEN out_RESULT FOR
        SELECT to_char(sysdate, 'yyyyMMdd') || Lpad(to_char(ll_max),4,'0')  AS out_JUNPYO_NO
              ,in_CUST_ID AS out_CUST_ID
          FROM dual; 
    END IF;
    
EXCEPTION
WHEN ERROR_EXCEPTION THEN
   out_CODE := 1;
   ROLLBACK;
WHEN OTHERS THEN 
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
