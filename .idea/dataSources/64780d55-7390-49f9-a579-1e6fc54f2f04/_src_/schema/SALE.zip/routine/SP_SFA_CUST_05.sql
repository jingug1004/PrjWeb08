CREATE PROCEDURE      SP_SFA_CUST_05
(
    in_CLIENT_NM         IN  VARCHAR2,     -- 고객 명 코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 전국 고객 검색
 호출프로그램 :       
 수정내역    : 105버전으로 대체됨               
 ---------------------------------------------------------------------------*/   
    v_num                NUMBER;
    
BEGIN 

    
    SELECT COUNT(*)
      INTO v_num
        FROM SFA_COM_CUSTOMER 
     WHERE CLIENT_NAME  LIKE '%'||NVL(in_CLIENT_NM,'%')||'%';
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 고객이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '고객 검색 완료';    
     
        OPEN out_RESULT FOR
        SELECT  /* CHOE 20121006 
               A.SFA_SALES_NO                                       AS out_CUST_CD             
             , F_CUST_NM(A.SFA_SALES_NO)                            AS out_CUST_NM*/
               (SELECT ERP_SALES_CODE FROM SFA_SALES_CODE Z WHERE Z.SFA_SALES_SEQ = A.SFA_SALES_SEQ ) AS out_CUST_CD
             , (SELECT TRADE_NAME FROM SFA_SALES_CODE Z WHERE Z.SFA_SALES_SEQ = A.SFA_SALES_SEQ) AS out_CUST_NM
             , A.SFA_CLIENT_NO                                      AS out_CLIENT_NO
             , (SELECT CODE1_NM FROM SALE0001
                 WHERE CODE_GB = '0062' AND CODE1 = A.CLIENT_DEPT)  AS out_CLIENT_DEPT
             /* CHOE 20121006
             , A.CLIENT_JIKWI                                       AS out_CLIENT_JIKWI*/
             , '' AS out_CLIENT_JIKWI
             , A.POSITION_NAME                                      AS out_POSITION_NM
             , A.CLIENT_NAME                                        AS out_CLIENT_NM
             , A.DETAIL_ADDR1||' '||A.DETAIL_ADDR2                  AS out_ADDRESS   
             , A.BIRTHDAY                                           AS out_BIRTHDAY
             , A.BIRTHDAY_GUBUN                                     AS out_BIRTHDAY_GUBUN
            FROM SFA_COM_CUSTOMER A
         WHERE A.CLIENT_NAME  LIKE '%'||NVL(in_CLIENT_NM,'%')||'%'
           AND NVL(A.DEL_YN, 'N') = 'N'
         ORDER BY A.CLIENT_NAME;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
