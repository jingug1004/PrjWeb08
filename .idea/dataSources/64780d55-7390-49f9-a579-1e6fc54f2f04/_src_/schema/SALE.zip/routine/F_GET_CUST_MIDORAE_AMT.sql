CREATE function      F_GET_CUST_MIDORAE_AMT
        ( A_CUST_ID      VARCHAR2, -- 거래처코드 
          A_YMD          VARCHAR2, -- 검색 기준일
          A_CALL_GB      VARCHAR2  -- 호츨구분 'JA'-자수 'TA'-타수   
        )
   RETURN NUMBER
AS
   user_err         exception   ; 
   n_rtn_value      NUMBER;
   v_curr_error     VARCHAR2(250);

/*----------------------------------------------------------------
  미도래 어음을 가져온다
----------------------------------------------------------------*/
BEGIN
  
    IF A_CALL_GB = 'JA' THEN
    
       -- 자수 
       SELECT SUM(AMT) 
         INTO n_rtn_value
         FROM SALE0401 X ,
              SALE0402 Y
        WHERE X.YMD       = Y.YMD
          AND X.JUNPYO_NO = Y.JUNPYO_NO
          AND Y.END_YMD  >= TO_DATE(A_YMD)
          AND X.CUST_ID   = A_CUST_ID
          AND NVL(Y.BILL_GB,'*') not IN ('025','035','040');
          
    ELSIF  A_CALL_GB = 'TA' THEN
    
       -- 타수 
       SELECT SUM(AMT) 
         INTO n_rtn_value
         FROM SALE0401 X ,
              SALE0402 Y
        WHERE X.YMD       = Y.YMD
          AND X.JUNPYO_NO = Y.JUNPYO_NO
          AND Y.END_YMD  >= TO_DATE(A_YMD)
          AND X.CUST_ID   = A_CUST_ID
          AND NVL(Y.BILL_GB,'*') IN ('025','035','040');
          
    ELSIF  A_CALL_GB = 'JATA' THEN
    
       -- 자수 + 타수
       SELECT SUM(AMT) 
         INTO n_rtn_value
         FROM SALE0401 X ,
              SALE0402 Y
        WHERE X.YMD       = Y.YMD
          AND X.JUNPYO_NO = Y.JUNPYO_NO
          AND Y.END_YMD  >= TO_DATE(A_YMD)
          AND X.CUST_ID   = A_CUST_ID ;
       
    
    END IF;
                                          
       
    RETURN n_rtn_value;

EXCEPTION WHEN user_err THEN
               RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
          WHEN OTHERS THEN
               RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;
/
