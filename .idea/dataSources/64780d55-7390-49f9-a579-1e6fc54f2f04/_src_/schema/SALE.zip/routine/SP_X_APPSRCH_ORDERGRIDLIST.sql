CREATE PROCEDURE      SP_X_APPSRCH_ORDERGRIDLIST
(
    in_FR_DATE              IN VARCHAR2,
    in_TO_DATE              IN VARCHAR2,
    in_RECEIPT_GB           IN VARCHAR2,
    in_WIBAN_ORDER_REQ_YN   IN VARCHAR2,
    in_WIBAN_ORDER_CONF_YN  IN VARCHAR2,
    in_CUST_ID              IN VARCHAR2,
    in_SLIP_GB              IN VARCHAR2,
    in_LIMIT_YN             IN VARCHAR2,
    in_EMP_CD               IN VARCHAR2,
    in_DEPT_CD              IN VARCHAR2,
    in_SIDX                 IN VARCHAR2,
    in_SORD                 IN VARCHAR2,
    out_RESULT             OUT TYPES.CURSOR_TYPE,
    out_CODE               OUT NUMBER,
    out_MSG                OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APPSRCH_ORDERGRIDLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  주문/승인 조회 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    OPEN out_RESULT FOR	
			SELECT A.CUST_ID, 
			       A.RCUST_ID, 
			       B.CUST_NM CUST_NM, 
			       C.CUST_NM RCUST_NM, 
			       A.GUMAE_NO,
			       TO_CHAR(A.YMD, 'YYYY-MM-DD') YMD, 
			       TO_CHAR(A.INPUT_YMD, 'AM HH12:MI:SS') REQ_TIME, 
			       NVL2(A.GUMAE_GB,'일반매출','        ') AS GUMAE_GB,
			       CASE WHEN A.RECEIPT_GB = '1' THEN '접수'
			            WHEN A.RECEIPT_GB = '2' THEN '승인'
			            WHEN A.RECEIPT_GB = '3' THEN '반려'ELSE '    ' END AS STATUS, 
			       A.YMDT AS APP_YMD, 
			       A.GUMAE_NOT AS APP_NO, 
			       CASE WHEN A.RECEIPT_GB = '1' THEN A.BIGO
			            WHEN A.RECEIPT_GB = '2' THEN A.RETURN_DESC
			            WHEN A.RECEIPT_GB = '3' THEN A.RETURN_DESC ELSE '    ' END AS RETURN_DESC, 
			       A.SLIP_GB,
			       A.WIBAN_ORDER_REQ_YN,
			       A.WIBAN_ORDER_CONF_YN
			  FROM SALE_ON.SALE0203 A, SALE.SALE0003 B, SALE.SALE0003 C
			 WHERE A.CUST_ID = B.CUST_ID
			   AND A.RCUST_ID = C.CUST_ID
			   AND A.YMD BETWEEN in_FR_DATE AND in_TO_DATE
			   AND A.RECEIPT_GB  IN (in_RECEIPT_GB)
			   AND A.WIBAN_ORDER_REQ_YN like in_WIBAN_ORDER_REQ_YN
			   AND A.WIBAN_ORDER_CONF_YN like in_WIBAN_ORDER_CONF_YN
			   AND A.CUST_ID LIKE '%'||in_CUST_ID||'%'
			   AND A.SLIP_GB = in_SLIP_GB
			   AND NVL(A.LIMIT_YN,'N') IN (in_LIMIT_YN)
			   AND B.SAWON_ID IN (SELECT SAWON_ID 
				 						   FROM SALE.SALE0007 
										  WHERE (CASE WHEN 'P' = F_TEAMWON_GB('${in_EMP_CD}') THEN SIL_SAWON_ID ELSE DEPT_CD END) 
											  = (CASE WHEN 'P' = F_TEAMWON_GB('${in_EMP_CD}') THEN in_EMP_CD
											    	  WHEN 'D' = F_TEAMWON_GB('${in_EMP_CD}') THEN in_DEPT_CD ELSE DEPT_CD END ))
		ORDER BY in_SIDX||' '||in_SORD;
						
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
