CREATE PROCEDURE      SP_SFA_COMMON_01
(
    in_GUBUN IN NUMBER,-- 1:우편번호 , 2:도로명
    in_ITEM IN VARCHAR2,  -- 주소명
    out_CODE OUT NUMBER,
    out_MSG OUT VARCHAR2,
    out_COUNT OUT NUMBER,
    out_RESULT OUT TYPES.CURSOR_TYPE
)
IS
/*---------------------------------------------------------------------------
프로그램명   : 주소검색 팝업
호출프로그램 :    
 
수정 - CHOE 20160701 주소 검색 시 구주소만 검색 가능한 형태도로명 주소도 가능하고 관리가 되고 있는 공통 코드 값으로 변경            
     신주소 구주소 검색 에서    도로명과 우편번호 변경   
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
---------------------------------------------------------------------------*/    
        v_num NUMBER;
        v_in_gubun VARCHAR2(1);        
        v_in_item VARCHAR2(30);
    
        GUBUN_NULL           EXCEPTION;
BEGIN

        --파라미터 내용 확인   
        v_in_gubun := '';
        v_in_item := ''; 
        IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
                RAISE GUBUN_NULL;
        ELSE
                v_in_gubun := in_GUBUN;
                v_in_item := in_ITEM;
        END IF;
        
        v_num := 0;
        
        --우편번호경우
        IF v_in_gubun = '1' THEN
                SELECT COUNT(*)
                INTO v_num
                FROM HANACOMM.CO_POSTNO_0 A
                WHERE ZIPCODE LIKE '%'||v_in_item||'%'
                ;
        --도로명 검색인 경우
        ELSIF v_in_gubun = '2' THEN
                SELECT COUNT(*)
                INTO v_num
                FROM HANACOMM.CO_POSTNO_0 A
                WHERE DORO_NM LIKE '%'||v_in_item||'%'
                ;    
               
        END IF;
    
        out_COUNT := v_num;
        IF v_num = 0 THEN
                out_CODE := 1;
                out_MSG := '검색내용이 없습니다.';
        ELSIF v_num >  300 THEN
                out_CODE := 1;
                 IF v_in_gubun = '1' THEN
                        out_MSG := '검색 내용이 너무 많습니다. [ 135814 ] 처럼  5자리 형태로 입력 바랍니다.';
                ELSIF v_in_gubun = '2' THEN                       
                         out_MSG := '검색 내용이 너무 많습니다. [ 강남대로136길 ] 처럼 구체적으로 입력 바랍니다.';
                END IF;  
        ELSE
                out_CODE := 0;
                out_MSG := '검색 확인완료';                
                
                --우편번호 검색
                IF v_in_gubun = '1' THEN
                        OPEN out_RESULT FOR
                        SELECT ZIPCODE AS out_ZIP_CODE -- 우편번호
                        ,SIDO||' '||GUNGU||' '||EUPMYUN||' '||DORO_NM||' '||BLDG_NO1||' '||BLDG_NO2||' '||GUNGU_BLDGNM AS out_ADDRESS        -- 주소
                        FROM HANACOMM.CO_POSTNO_0 A
                        WHERE ZIPCODE LIKE '%'||v_in_item||'%'              
                        ORDER BY ZIPCODE
                        ;                
                
                --도로명 검색
                ELSIF v_in_gubun = '2' THEN                      
                        OPEN out_RESULT FOR
                        SELECT ZIPCODE AS out_ZIP_CODE -- 우편번호
                        ,SIDO||' '||GUNGU||' '||EUPMYUN||' '||DORO_NM||' '||BLDG_NO1||' '||BLDG_NO2||' '||GUNGU_BLDGNM AS out_ADDRESS        -- 주소
                        FROM HANACOMM.CO_POSTNO_0 A
                        WHERE DORO_NM LIKE '%'||v_in_item||'%'               
                        ORDER BY ZIPCODE
                        ;  
                        
                END IF;
        END IF; 
        
EXCEPTION
        WHEN GUBUN_NULL THEN
                out_CODE := 101;
                out_MSG  := '검색 구분코드가 누락되었습니다.';
        WHEN OTHERS THEN
                out_CODE := SQLCODE;
                out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
