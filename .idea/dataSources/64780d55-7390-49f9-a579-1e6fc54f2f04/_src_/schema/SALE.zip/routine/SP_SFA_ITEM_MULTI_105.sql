CREATE PROCEDURE      SP_SFA_ITEM_MULTI_105
(
    in_PROD_NM           IN  VARCHAR2,  -- 제품명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
  /*---------------------------------------------------------------------------
 프로그램명   : 주문 제품 검색 팝업
 호출프로그램 : 주문>제품건건버튼> 제품멀티선택화면>조회버튼     

   SP_SFA_ITEM_MULTI_139 버전으로 대체
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
     
BEGIN 

    
    SELECT COUNT(*)
      INTO v_num
      FROM SALE0004   
     WHERE ITEM_NM LIKE '%'||in_PROD_NM||'%'
       AND SAUPJANG_CD IN (102,103,104) --SFA주문제품선택시는하길은 제외한다.101-하길,102-도매지점,103-도매(향정)지점 
       AND nvl(CHUL_YN,'N') = 'N'
       AND USE_YN = 'Y'
     ; 
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다. (주문제품검색)';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        /*SELECT ITEM_ID                                 AS out_PROD_CD,    -- 품목코드
               ITEM_NM                                 AS out_PROD_NM,    -- 품목명
               STANDARD                                AS out_STANDARD,   -- 규격
               UNIT                                    AS out_UNIT,       -- 단위
               OUT_DANGA                                   AS out_DANGA,      -- 단가(출고단가)             
               SAUPJANG_CD                             AS out_SAUPJANG_CD -- 사업장 
          FROM SALE0004   
         WHERE ITEM_NM LIKE  '%'||in_PROD_NM||'%'
           AND SAUPJANG_CD IN (102,103) --SFA주문제품선택시는하길은 제외한다.101-하길,102-도매지점,103-도매(향정)지점 
           AND nvl(CHUL_YN,'N') = 'N'  --출하중지(Y-중지,N-중지아님)
           AND USE_YN = 'Y'
         ORDER BY ITEM_NM;*/
         SELECT PROD_CD AS out_PROD_CD
            ,PROD_NM AS out_PROD_NM
            ,STANDARD AS out_STANDARD
            ,UNIT AS out_UNIT
            ,DANGA AS out_DANGA
            ,SAUPJANG_CD AS out_SAUPJANG_CD
            FROM (
             SELECT ITEM_ID                                 AS PROD_CD,    -- 품목코드
                           ITEM_NM                                 AS PROD_NM,    -- 품목명
                           STANDARD                                AS STANDARD,   -- 규격
                           UNIT                                    AS UNIT,       -- 단위
                           OUT_DANGA                                   AS DANGA,      -- 단가(출고단가)             
                           SAUPJANG_CD                             AS SAUPJANG_CD -- 사업장 
                      FROM SALE0004   
                     WHERE ITEM_NM LIKE  '%'||in_PROD_NM||'%'
                       AND SAUPJANG_CD IN (102,103,104) --SFA주문제품선택시는하길은 제외한다.101-하길,102-도매지점,103-도매(향정)지점 
                       AND nvl(CHUL_YN,'N') = 'N'  --출하중지(Y-중지,N-중지아님)
                       AND USE_YN = 'Y'
                       AND TRIM(STANDARD) not in ('1A', '1A(PP)', '1C', '1C(P)', '1P', '1T', '1T(B)', '1T(P)', '1V', '1ml', '5ml*1포' )
             UNION
             SELECT ITEM_ID                                 AS PROD_CD,    -- 품목코드
                           ITEM_NM                                 AS PROD_NM,    -- 품목명
                           STANDARD                                AS STANDARD,   -- 규격
                           UNIT                                    AS UNIT,       -- 단위
                           OUT_DANGA                                   AS DANGA,      -- 단가(출고단가)             
                           SAUPJANG_CD                             AS SAUPJANG_CD -- 사업장 
                      FROM SALE0004   
                     WHERE ITEM_NM LIKE  '%'||in_PROD_NM||'%'
                       AND SAUPJANG_CD IN (102,103,104) --SFA주문제품선택시는하길은 제외한다.101-하길,102-도매지점,103-도매(향정)지점 
                       AND nvl(CHUL_YN,'N') = 'N'  --출하중지(Y-중지,N-중지아님)
                       AND USE_YN = 'Y'
                       AND ITEM_ID = '17837' --하니반정1T 짜리는 포함
             )
             ORDER BY out_PROD_NM;
    END IF;
    
EXCEPTION 
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
