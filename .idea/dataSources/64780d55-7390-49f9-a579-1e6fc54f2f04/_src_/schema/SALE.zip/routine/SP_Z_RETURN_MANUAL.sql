CREATE PROCEDURE      SP_Z_RETURN_MANUAL 
(
    in_CUST_ID        IN  VARCHAR2,   
    in_RCUST_ID        IN  VARCHAR2,   
    in_ITEM_CD        IN  VARCHAR2,   -- 반품이유
    in_PRODNO        IN  VARCHAR2,   -- 결재 상태
    in_USEDYMD            IN  VARCHAR2,   -- 승인자 불가사유
    in_DANGA        IN  NUMBER,   
    in_MANUALQTY    IN  NUMBER,   
    in_AMT                IN  NUMBER,   
    in_SAWON_ID            IN  VARCHAR2,   
    in_REASON_CODE    IN  VARCHAR2,   
    out_CODE        out NUMBER,
    out_MSG         out VARCHAR2
)
IS
 /*---------------------------------------------------------------------------
 프로그램명
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_Z_VISIT_NON_REASON_UP',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SAWON_ID,sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_SOLAR '||in_SOLAR );
--commit;
   
     SELECT COUNT(*)
      INTO v_num
     FROM sfa_banpum_reason a
     where a.ymd = to_char(SYSDATE,'YYYYMMDD')
        and CUST_ID = in_CUST_ID
        and RCUST_ID = in_RCUST_ID
        and item_id= in_ITEM_CD
        and prod_no= in_PRODNO;
   
    IF v_num = 0 THEN -- 신규등록
        out_CODE := 0;
        out_MSG := '요청하신 작업이 등록되었습니다.';  
        insert into sfa_banpum_reason(  ymd,            cust_id,        rcust_id,       item_id,        prod_no,
                                        USE_YMD_TO,     DANGA,          MANUAL_QTY,     AMT,            CUST_SAWON_ID,  BANPUM_REASON) 
                                values (to_char(SYSDATE,'YYYYMMDD'),         in_CUST_ID,     in_RCUST_ID,    in_ITEM_CD,     in_PRODNO,
                                        in_USEDYMD,     in_DANGA,       in_MANUALQTY,   in_AMT,         in_SAWON_ID,    in_REASON_CODE) ;
    commit;                
    ELSE    -- 업데이트
        out_CODE := 0;
        out_MSG := '이미 등록된 자료입니다.';      
        
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
