CREATE PROCEDURE      SP_SFA_ORDER_ITEM   
(   
    in_GUMAE_NO          IN VARCHAR2 default NULL,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문상세내역
 호출프로그램 : 주문서등록 OrderNew 에서 호출 
          주문현황 OrderList 에서 호출
          간납처주문현황 ROrderList 에서 호출   
      2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
        
 ---------------------------------------------------------------------------*/    

    v_num NUMBER;
    V_ITEM_CNT NUMBER;   
    V_GUMAE_NO VARCHAR2(20);
        
BEGIN
         
    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.SLORDD A
     WHERE a.orderno  = in_GUMAE_NO
    ;     
         
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
      
        out_COUNT := v_num;
        out_CODE := 0;
        out_MSG := '검색 완료';        
               
        OPEN out_RESULT FOR
        SELECT 
            (select itemname from ORAGMP.CMITEMM where itemcode = a.itemcode) AS out_ITEM_ID                      
           ,999  AS out_QTY --DECODE(NVL(a.salqty,'0') ,NVL(a.reqqty,'0') ,TO_CHAR(a.salqty) ,TO_CHAR(a.salqty)||'/'||TO_CHAR(a.reqqty) ) AS out_QTY   -- CHOE 주문수량과 다른 경우 표시  
           ,a.salprc                 AS out_DANGA   
           ,a.salamt                 AS out_AMT
           ,a.salvat                 AS out_VAT
           ,a.salamt + a.salvat      AS out_AMOUNT
        FROM ORAGMP.SLORDD A
        WHERE a.orderno = in_GUMAE_NO                        
        ORDER BY a.seq DESC
        ;
        END IF;        
    
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
