CREATE PROCEDURE      SP_Z_FORE_COLLECT_UP 
(
    in_CDT              IN  VARCHAR2,   
    in_SAWON_ID         IN  VARCHAR2,   
    in_ASFAMT           IN  VARCHAR2,   
    in_CSFAMT           IN  VARCHAR2,   
    out_CODE            out NUMBER,
    out_MSG             out VARCHAR2
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 미방문사유등록
 ---------------------------------------------------------------------------*/    

    v_num1                NUMBER;
    v_num2                NUMBER;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_Z_VISIT_NON_REASON_UP',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SAWON_ID,sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_SOLAR '||in_SOLAR );
--commit;
   
    SELECT COUNT(*)
        INTO v_num1
    FROM ORAGMP.SLTARGETSALEM A
    WHERE   A.YEARMONTH =in_CDT
        AND A.EMPCODE   = in_SAWON_ID
        AND A.SALDIV   = 'A';
   
    SELECT COUNT(*)
        INTO v_num2
    FROM ORAGMP.SLTARGETSALEM A
    WHERE   A.YEARMONTH =in_CDT
        AND A.EMPCODE   = in_SAWON_ID
        AND A.SALDIV   = 'C';
   
    IF v_num1 = 0 THEN -- 신규등록
        out_CODE := 1;
        out_MSG := '신규 등록은 할수 없습니다.';  
                
    ELSE    -- 업데이트
        out_CODE := 0;
        out_MSG := '요청하신 작업이 수정되었습니다.';      
        update ORAGMP.SLTARGETSALEM set SFAMT = in_ASFAMT
           where       EMPCODE     = in_SAWON_ID
                    AND SALDIV      = 'A'
                    AND YEARMONTH   = in_CDT;   
        COMMIT;                                  
    END IF;
    
   
    IF v_num2 = 0 THEN -- 신규등록
        out_CODE := 1;
        out_MSG := '신규 등록은 할수 없습니다.';  
                
    ELSE    -- 업데이트
        out_CODE := 0;
        out_MSG := '요청하신 작업이 수정되었습니다.';      
        update ORAGMP.SLTARGETSALEM set SFAMT = in_CSFAMT
            where       EMPCODE     = in_SAWON_ID
                    AND SALDIV      = 'C'
                    AND YEARMONTH   = in_CDT;                         
        COMMIT;                                  
    END IF;
    
    
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
