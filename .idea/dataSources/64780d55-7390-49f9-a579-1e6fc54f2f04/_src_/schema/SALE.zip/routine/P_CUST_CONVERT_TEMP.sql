CREATE PROCEDURE P_CUST_CONVERT_temp
IS
BEGIN
      for c1 in (  SELECT NEW_CUST_ID,
                          OLD_CUST_ID,
                          SAWON_ID
                     FROM SALE0098)
      loop
	              -- 잔액테이블변경                 
	      BEGIN
	              UPDATE SALE0306 A SET
	                     A.CUST_ID = c1.NEW_CUST_ID
	               WHERE CUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '잔액테이블변경 Err1:'||sqlerrm ) ;                   
	      END;
	      BEGIN                               
	              UPDATE SALE0306 A SET
	                     A.RCUST_ID = c1.NEW_CUST_ID,
	                     A.SAWON_ID = NVL(c1.SAWON_ID,A.SAWON_ID)
	               WHERE RCUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '잔액테이블변경Err2:'||sqlerrm ) ;                   
	      END;
      end loop;   
END  P_CUST_CONVERT_temp;


/
