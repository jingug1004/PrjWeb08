CREATE function      F_RATE_DAY
                          (I_YM_F           IN  VARCHAR2,     -- 조회월일
                           I_CUST_ID        IN  VARCHAR2      -- 거래처코드
                           )  RETURN DATE   IS  -- 회전일자
						   
          T_JANGO_BEFORE       NUMBER;
		  T_JANGO              NUMBER;
		  T_CNT                NUMBER;
		  T_RATE_DATE          DATE;
		  T_DATE_BEFORE        DATE;
		  T_TEMP_DATE          DATE;

/*----------------------------------------------------------------------------*
 기능:실시간 회전일을 계산하여 회전일을 return
 작성자:
 작성일:
 수정기록
 참고사항: 이 함수는 실시간회전일 계산을 목적으로 작성한것 같은데 윤홍주 차장의견은
           실시간회전일 계산이 불가하므로 사용할수 없다고 함 - 김태안 
 *----------------------------------------------------------------------------*/		  

       CURSOR C1  IS
               SELECT YMD        YMD,
					  MISU_AMT   MISU_AMT
			     FROM SALE0306 
				WHERE CUST_ID = I_CUST_ID  
				  AND YMD    <= TO_DATE(I_YM_F || '01','YYYYMMDD')
			  ORDER BY YMD DESC; 
			  
		CURSOR C2 IS	  
			  SELECT B.YMD                     YMD,
			         B.AMT + B.VAT - B.DC_AMT  AMT
			    FROM SALE0203 A,
				     SALE0204 B
			   WHERE A.YMD      = B.YMD
			     AND A.GUMAE_NO = B.GUMAE_NO
			     AND A.CUST_ID  = I_CUST_ID
				 AND A.GUMAE_NO LIKE TO_CHAR(T_RATE_DATE,'YYYYMM') || '%';	
				 
		CURSOR C3 IS	  
			  SELECT B.YMD                     YMD,
			         B.AMT + B.VAT - B.DC_AMT  AMT
			    FROM SALE0203 A,
				     SALE0204 B
			   WHERE A.YMD      = B.YMD
			     AND A.GUMAE_NO = B.GUMAE_NO
			     AND A.CUST_ID  = I_CUST_ID
				 AND A.GUMAE_NO LIKE TO_CHAR(ADD_MONTHS(T_RATE_DATE,-1),'YYYYMM') || '%';		 		 
				 			   

      BEGIN
	  
	      T_JANGO        := 0;
	      T_JANGO_BEFORE := 0;
		  T_CNT          := 1 ;
		/*  
		  -- 금월잔고 구함			 
	       SELECT A.JANGO    JANGO 
		     INTO T_JANGO
		     FROM EIJING A
			WHERE A.CUST_ID  = I_CUST_ID
			  AND A.YM_F     = I_YM_F;  
		  
		    -- 금월잔고가 0 이하 일때 회전일 0이 된다
		  	IF T_JANGO <= 0 THEN
			   RETURN TO_DATE(I_YM_F);
			END IF;		
			*/
			  
            FOR A1 IN C1 LOOP
			
			   T_RATE_DATE     := A1.YMD;
			   T_JANGO_BEFORE  := T_JANGO;		
			 /*  
			   IF T_CNT = 1 THEN
			       
				  UPDATE EIJING A 
				     SET A.MM_1     = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
			         AND A.YM_F     = I_YM_F;
				             
				   
			   ELSIF T_CNT = 2 THEN
			   
   				  UPDATE EIJING A
				     SET A.MM_2     = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
 		             AND A.YM_F     = I_YM_F; 
			   
			   ELSIF T_CNT = 3 THEN
			   
			     UPDATE EIJING A
				     SET A.MM_3     = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
 		             AND A.YM_F     = I_YM_F; 
			   
			   
			   ELSIF T_CNT = 4 THEN
			   
			      UPDATE EIJING A
				     SET A.MM_4     = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
 		             AND A.YM_F     = I_YM_F; 
			   
			   
			   ELSIF T_CNT = 5 THEN
			   
			    UPDATE EIJING A
				     SET A.MM_5     = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
 		             AND A.YM_F     = I_YM_F;
			   
			   ELSIF T_CNT = 6 THEN
			   
			    UPDATE EIJING A
				     SET A.MM_6     = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
 		             AND A.YM_F     = I_YM_F;
			   
			   ELSIF T_CNT = 7 THEN
			   
			    UPDATE EIJING A
				     SET A.MM_7     = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
 		             AND A.YM_F     = I_YM_F;
			   
			   ELSIF T_CNT = 8 THEN
			   
			    UPDATE EIJING A
				     SET A.MM_8     = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
 		             AND A.YM_F     = I_YM_F;
			   
			   ELSIF T_CNT = 9 THEN
			   
			    UPDATE EIJING A
				     SET A.MM_9     = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
 		             AND A.YM_F     = I_YM_F;
			   
			   ELSIF T_CNT = 10 THEN
			   
			    UPDATE EIJING A
				     SET A.MM_10    = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
 		             AND A.YM_F     = I_YM_F;
			   
			   ELSIF T_CNT = 11 THEN
			   
			    UPDATE EIJING A
				     SET A.MM_11    = T_JANGO
				   WHERE A.CUST_ID  = I_CUST_ID
 		             AND A.YM_F     = I_YM_F;		   
			   	
			   END IF;
			   
			--   COMMIT; */
			   
			   -- 금월잔고에서 최근달 부터 매출을 빼나간다.
               -- EX) 8월 조회시 8,7,6 ... 이런식으로 순수매출을 빼나간다. 
		       T_JANGO := T_JANGO - A1.MISU_AMT;              
			   
			   -- 뺀 잔고가 0 일때	
			   -- 구매의뢰 테이블에서(일자별) 잔고가 0 이 되는 일자를 구한다		   
			   
			   IF T_JANGO = 0 THEN
			   	
			      FOR A2 IN C2 LOOP			        
					   
					   T_JANGO_BEFORE := T_JANGO_BEFORE - A2.AMT;
					   
					   IF T_JANGO_BEFORE = 0 THEN
					      RETURN (A2.YMD);					   
					   ELSIF T_JANGO_BEFORE < 0 THEN
					      RETURN (T_DATE_BEFORE);
					   END IF;					    
			           
					   T_DATE_BEFORE := A2.YMD;
					   
				   END LOOP;     
										       
               -- 뺀 잔고가 0 미만 일때	
			   -- 전달 구매의뢰 테이블에서(일자별) 잔고가 0 이 되는 일자를 구한다 	
				ELSIF T_JANGO < 0 THEN				   
				
				/*
				   IF T_CNT = 1 THEN
			       
				  UPDATE EIJING A 
				     SET A.MM_1     = T_JANGO_BEFORE
				   WHERE A.CUST_ID  = I_CUST_ID
			         AND A.YM_F     = I_YM_F;
				             
				   
				   ELSIF T_CNT = 2 THEN
				   
	   				  UPDATE EIJING A
					     SET A.MM_2     = T_JANGO_BEFORE
					   WHERE A.CUST_ID  = I_CUST_ID
	 		             AND A.YM_F     = I_YM_F; 
				   
				   ELSIF T_CNT = 3 THEN
				   
				     UPDATE EIJING A
					     SET A.MM_3     = T_JANGO_BEFORE
					   WHERE A.CUST_ID  = I_CUST_ID
	 		             AND A.YM_F     = I_YM_F; 
				   
				   
				   ELSIF T_CNT = 4 THEN
				   
				      UPDATE EIJING A
					     SET A.MM_4     = T_JANGO_BEFORE
					   WHERE A.CUST_ID  = I_CUST_ID
	 		             AND A.YM_F     = I_YM_F; 
				   
				   
				   ELSIF T_CNT = 5 THEN
				   
				    UPDATE EIJING A
					     SET A.MM_5     = T_JANGO_BEFORE
					   WHERE A.CUST_ID  = I_CUST_ID
	 		             AND A.YM_F     = I_YM_F;
				   
				   ELSIF T_CNT = 6 THEN
				   
				    UPDATE EIJING A
					     SET A.MM_6     = T_JANGO_BEFORE
					   WHERE A.CUST_ID  = I_CUST_ID
	 		             AND A.YM_F     = I_YM_F;
				   
				   ELSIF T_CNT = 7 THEN
				   
				    UPDATE EIJING A
					     SET A.MM_7     = T_JANGO_BEFORE
					   WHERE A.CUST_ID  = I_CUST_ID
	 		             AND A.YM_F     = I_YM_F;
				   
				   ELSIF T_CNT = 8 THEN
				   
				    UPDATE EIJING A
					     SET A.MM_8     = T_JANGO_BEFORE
					   WHERE A.CUST_ID  = I_CUST_ID
	 		             AND A.YM_F     = I_YM_F;
				   
				   ELSIF T_CNT = 9 THEN
				   
				    UPDATE EIJING A
					     SET A.MM_9     = T_JANGO_BEFORE
					   WHERE A.CUST_ID  = I_CUST_ID
	 		             AND A.YM_F     = I_YM_F;
				   
				   ELSIF T_CNT = 10 THEN
				   
				    UPDATE EIJING A
					     SET A.MM_10    = T_JANGO_BEFORE
					   WHERE A.CUST_ID  = I_CUST_ID
	 		             AND A.YM_F     = I_YM_F;
				   
				   ELSIF T_CNT = 11 THEN
				   
				    UPDATE EIJING A
					     SET A.MM_11    = T_JANGO_BEFORE
					   WHERE A.CUST_ID  = I_CUST_ID
	 		             AND A.YM_F     = I_YM_F;		   
				   	
				   END IF;
				   
		--		   COMMIT; */				
				
				   FOR A3 IN C3 LOOP
				   
				       T_JANGO_BEFORE := T_JANGO_BEFORE - A3.AMT;
					   
					   IF T_JANGO_BEFORE = 0 THEN
					      RETURN (A3.YMD);					   
					   ELSIF T_JANGO_BEFORE < 0 THEN
					      RETURN (T_DATE_BEFORE);
					   END IF;
					   T_DATE_BEFORE := A3.YMD;				       
				   
				   END LOOP;
				   	  
			    END IF;
				
				 T_CNT  := T_CNT +  1; -- 달 증가 
								
            END LOOP;
			
			RETURN (T_RATE_DATE);

           
       EXCEPTION
          WHEN OTHERS THEN
              -- ROLLBACK;
               RAISE_APPLICATION_ERROR(-20099, 'F_RATE_DAY '||substrb('오류!'||SQLCODE||'/'||SQLERRM,1,250)) ;

      END;

/
