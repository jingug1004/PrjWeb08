CREATE PROCEDURE      SP_SFA_OFFICE_01_UPDATE
(   
    in_NTCNO             IN  CHAR,      -- 공지번호
    in_SAWON_ID          IN  VARCHAR2,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 공지읽음저장
 호출프로그램 : 오피스 > 공지사항
          2017.11.01  KTA - NEW ERP메 맞게 컨버전
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_INQ_UNO            VARCHAR2(14);
    NTCNO_NULL           EXCEPTION;
    SAWON_ID_NULL        EXCEPTION;
BEGIN
    
    IF in_NTCNO IS NULL THEN
        RAISE NTCNO_NULL;
    END IF;
    
    IF in_SAWON_ID IS NULL THEN 
        RAISE SAWON_ID_NULL;
    END IF;
    
    SELECT UNO 
      INTO v_INQ_UNO
      FROM V_SAWON_ID_MAP 
     WHERE SAWON_ID = in_SAWON_ID;
     
    SELECT COUNT(*)
      INTO v_num
      FROM hanagw.TGWNTCFM
     WHERE NTCNO     = in_NTCNO
       AND INQ_UNO   = v_INQ_UNO;
       
    IF (v_num >= 1) THEN
        out_CODE := 1;
        out_MSG := '기존에 읽은 공지사항입니다.';
    ELSIF (v_num = 0) THEN
        out_CODE := 0;
        out_MSG := '기존에 안읽은 공지사항입니다.';    
         
        INSERT INTO hanagw.TGWNTCFM(NTCNO, INQ_UNO, CFM_DTM)
               VALUES(in_NTCNO, v_INQ_UNO, TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'));
               
        COMMIT;
         
    END IF;
         
EXCEPTION
WHEN NTCNO_NULL THEN
   out_CODE := 101;
   out_MSG  := '공지사항 번호가 누락되었습니다.';
WHEN SAWON_ID_NULL THEN
   out_CODE := 102;
   out_MSG  := '사원 번호가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
