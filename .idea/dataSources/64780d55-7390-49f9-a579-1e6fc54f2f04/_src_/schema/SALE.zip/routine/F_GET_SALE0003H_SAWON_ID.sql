CREATE function      F_GET_SALE0003H_SAWON_ID
        ( A_CUST_ID      VARCHAR2,  
          A_YMD          DATE       
        )
   RETURN VARCHAR2
AS
   user_err       exception   ;
   A_SYMD         VARCHAR2(8);
   V_TRAN_YMD_CD  VARCHAR2(14);
   V_YMD          DATE ;
   V_SYMD         VARCHAR2(8);
   n_rtn_value    VARCHAR2(250);
   v_curr_error   VARCHAR2(250);

/*----------------------------------------------------------------
 개요  :거래처 와 일자를 받아서 해당시점의 거래처담당사번을 리턴
 작성일:2014.01.09
 작성자:김태안 
----------------------------------------------------------------*/
BEGIN
       A_SYMD := TO_CHAR(A_YMD, 'YYYYMMDD'); 

       SELECT MAX(APPL_DATE1) 
         INTO V_SYMD
         FROM SALE0003H
        WHERE CUST_ID    =  A_CUST_ID
          AND APPL_DATE1 <= A_SYMD;

       SELECT MAX(TRAN_YMD_CD) 
         INTO V_TRAN_YMD_CD
         FROM SALE0003H
        WHERE CUST_ID    = A_CUST_ID
          AND APPL_DATE1 = V_SYMD;
          
       v_curr_error := A_CUST_ID||'/'||A_SYMD||'/'||V_TRAN_YMD_CD||'/'||V_SYMD;

       IF (V_SYMD IS NULL) OR (V_TRAN_YMD_CD IS NULL)  THEN
          RETURN '00'; --미지정거래구분
       END IF;
      
        SELECT A.SAWON_ID
          INTO n_rtn_value
          FROM SALE0003H A
         WHERE A.CUST_ID     = A_CUST_ID
           AND A.TRAN_YMD_CD = V_TRAN_YMD_CD
           AND A.APPL_DATE1  = V_SYMD;

        IF SQL%NOTFOUND THEN
              RETURN '01';
        ELSIF n_rtn_value IS NULL THEN
              RETURN '01';
        END IF;
            
        RETURN n_rtn_value;

        EXCEPTION WHEN user_err THEN
                       RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
                  WHEN OTHERS THEN
                       RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;

/
