CREATE PROCEDURE      SP_X_BALANCE_GRIDLIST
(
    in_CUST_ID    IN VARCHAR2,
    in_SIDX       IN VARCHAR2,
    in_SORD       IN VARCHAR2,
    out_RESULT   OUT TYPES.CURSOR_TYPE,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_BALANCE_GRIDLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  담보/잔고현황 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
        SELECT A.CUST_ID CUST_ID, A.INPUT_SEQ INPUT_SEQ,
			       A.SALE_DAMBO_AMT SALE_DAMBO_AMT, A.BUY_DAMBO_AMT BUY_DAMBO_AMT,
			       TO_CHAR(A.END_YMD,'YYYY-MM-DD') END_YMD, TO_CHAR(A.START_YMD,'YYYY-MM-DD') START_YMD, A.BALHANG BALHANG,
			       A.JIGEUB JIGEUB, A.BILL_NO BILL_NO,
			       (SELECT CODE1_NM
			          FROM SALE.SALE0001
			         WHERE CODE_GB = '0022' AND CODE1 = A.BILL_GB) BILL_GB, A.BIGO BIGO,
			       A.INPUT_YMD INPUT_YMD, TO_CHAR(A.CHULGO_YMD,'YYYY-MM-DD') CHULGO_YMD, B.CUST_NM CUST_NM
			  FROM SALE.SALE0404 A, SALE.SALE0003 B
			 WHERE A.CUST_ID = B.CUST_ID AND A.CUST_ID = in_CUST_ID
				ORDER BY in_SIDX||' '||in_SORD;
			
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
