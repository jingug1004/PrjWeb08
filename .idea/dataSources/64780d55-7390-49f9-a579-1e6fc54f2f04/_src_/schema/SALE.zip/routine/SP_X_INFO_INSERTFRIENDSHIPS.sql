CREATE PROCEDURE      SP_X_INFO_INSERTFRIENDSHIPS
(
    in_CUST_ID      IN VARCHAR2,
    in_CUSTOMER_ID  IN VARCHAR2,
    in_SEQ          IN VARCHAR2,
    in_CORP_NM      IN VARCHAR2,
    in_NAME         IN VARCHAR2,
    in_FRIENDSHIP   IN VARCHAR2,
    in_LESSION      IN VARCHAR2,
    in_GWANSIMDO    IN VARCHAR2,
    out_CODE       OUT NUMBER,
    out_MSG        OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INFO_INSERTFRIENDSHIPS
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 교우관계 저장  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	INSERT INTO SALE.CRM_FRIEND (CUST_ID, CUSTOMER_ID, SEQ, CORP_NM, NAME, RELATION, LESSON, GWANSIMDO) 
		VALUES ( in_CUST_ID      
			   , in_CUSTOMER_ID  
			   , in_SEQ          
			   , in_CORP_NM      
			   , in_NAME         
			   , in_FRIENDSHIP   
			   , in_LESSION      
			   , in_GWANSIMDO    
				);
				
   IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 INSERT ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 저장';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	
        ROLLBACK;
END ;
/
