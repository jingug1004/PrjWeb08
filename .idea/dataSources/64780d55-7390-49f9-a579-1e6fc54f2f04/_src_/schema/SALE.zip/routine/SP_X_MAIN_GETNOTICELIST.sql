CREATE PROCEDURE      SP_X_MAIN_GETNOTICELIST
(
    in_KEYWORD    IN VARCHAR2,
    in_STTDATE    IN VARCHAR2,
    in_ENDDATE    IN VARCHAR2,
    in_NOTICEID   IN VARCHAR2,
    out_RESULT  OUT TYPES.CURSOR_TYPE,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
		SELECT 
				   A.NOTICE_ID, 
			       A.GROUPCD, 
			       A.NOTICE_TITLE, 
			       A.NOTICE_DESC, 
			       TO_CHAR(A.INPUT_DATE, 'YYYY-MM-DD AM HH12:MI:SS') INPUT_DATE, 
			       A.INPUT_USERID,
			       B.SAWON_NM
			  FROM SALE.PDA_NOTICE A, SALE.SALE0007 B
			 WHERE A.INPUT_USERID = B.SAWON_ID(+)
			   AND (in_KEYWORD = 'title' 
			        AND A.NOTICE_TITLE LIKE '%'||in_KEYWORD||'%')
			   AND (in_KEYWORD = 'desc'
			        AND A.NOTICE_DESC LIKE '%'||in_KEYWORD||'%')
			   AND (in_KEYWORD = 'titleDesc'
			        AND A.NOTICE_TITLE LIKE '%'||in_KEYWORD||'%')
			   AND A.NOTICE_DESC LIKE '%'||in_KEYWORD||'%'
			   AND (in_KEYWORD = 'sawonNm'
			        AND B.SAWON_NM LIKE '%'||in_KEYWORD||'%')
			   AND A.INPUT_DATE BETWEEN TO_DATE(in_STTDATE, 'YYYYMMDD') AND TO_DATE(in_ENDDATE, 'YYYYMMDD') + 0.99999
			   AND A.NOTICE_ID = in_NOTICEID
	 		ORDER BY A.NOTICE_ID DESC;
			 		
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
