CREATE FUNCTION      F_CLIENT_NM  -- 거래처명 가져오기
(
    in_SFA_SALES_SEQ  IN  NUMBER,
    in_CLIENT_CD  IN  NUMBER
) 
RETURN VARCHAR2 IS

    v_client_nm   VARCHAR2(75);
    
BEGIN

    SELECT CLIENT_NAME
      INTO v_client_nm
      FROM SFA_COM_CUSTOMER
     WHERE SFA_SALES_SEQ    = in_SFA_SALES_SEQ
       and SFA_CLIENT_NO    = in_CLIENT_CD;
        
    RETURN v_client_nm;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;

/
