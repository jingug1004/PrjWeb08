CREATE PROCEDURE      SP_SFA_COLLECT_110
   (in_FLAG         IN VARCHAR2 DEFAULT NULL,
    in_YMD          IN date,
    in_JUNPYO_NO    IN VARCHAR2 DEFAULT NULL,
    in_CUST_ID      IN VARCHAR2 DEFAULT NULL, 
    in_RCUST_ID     IN VARCHAR2 DEFAULT NULL, 
    in_AMT          IN VARCHAR2 DEFAULT NULL, 
    in_SAWON_ID     IN VARCHAR2 DEFAULT NULL, 
    in_BIGO         IN VARCHAR2 DEFAULT NULL,
    in_BALHANG      IN VARCHAR2 DEFAULT NULL, 
    in_JIGEUB       IN VARCHAR2 DEFAULT NULL, 
    in_BILL_NO      IN VARCHAR2 DEFAULT NULL, 
    in_BILL_GB      IN VARCHAR2 DEFAULT NULL, 
    in_GYULJAE_YMD  IN VARCHAR2 DEFAULT NULL,
    in_SIGN_IMAGE   IN VARCHAR2 DEFAULT NULL, --사인은 여기서 저장하지 않음. apachetomcat서버 측에서 직접 update함.
    in_PDA_RPRT     IN VARCHAR2 DEFAULT NULL,    
    in_CARD_COMP       IN VARCHAR2 DEFAULT NULL,
    in_CARD_NO         IN VARCHAR2 DEFAULT NULL,
    in_CARD_USE_PERIOD IN VARCHAR2 DEFAULT NULL,
    in_CARD_ACCEPT_NO  IN VARCHAR2 DEFAULT NULL,
    in_CARD_BILL_GB    IN VARCHAR2 DEFAULT NULL,
    in_CARD_ALLOTMENT  IN VARCHAR2 DEFAULT NULL,
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2,
    out_COUNT       OUT NUMBER,
    out_RESULT      OUT TYPES.CURSOR_TYPE  
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 카드수금 과 수기카드수금 
 호출프로그램 : 
 수정기록 : 
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    

    ll_count     number := 0;
    v_sawon_id   VARCHAR2(20);
    v_dept_cd    VARCHAR2(4);
    v_colno      VARCHAR2(12);
    ERROR_EXCEPTION     EXCEPTION;
    
BEGIN 

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_JUNPYO_NO,sysdate,'in_CUST_ID:'||in_CUST_ID||'/in_SAWON_ID '||in_SAWON_ID );
--commit;

    IF in_CUST_ID IS NULL OR TRIM(in_CUST_ID) = '' THEN
        out_COUNT := 0;
        out_CODE := 1;
        out_MSG := '<거래처를 반드시 선택해야 합니다.>'; 
        RAISE ERROR_EXCEPTION;
    END IF;
    
   -- 담당사원체크
    BEGIN
        select empcode,deptcode
        into v_sawon_id,v_dept_cd
        from ORAGMP.CMCUSTM
        where plantcode = '1000'
          and custcode = in_CUST_ID ; 
        IF v_sawon_id IS NULL OR TRIM(v_sawon_id) = ''  THEN
            out_CODE := SQLCODE;
            out_MSG  := '<이거래처로 담당자가 지정되어 있지 않습니다.관리부로 연락하십시오. >';
            RAISE ERROR_EXCEPTION;           
        END IF;
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '<이거래처로 담당자가 지정되어 있지 않습니다.관리부로 연락하십시오. >';
        RAISE ERROR_EXCEPTION;
    END;      

   --중지거래처  통제(다른거래처에 수금입력 오류방지)   
    SELECT COUNT(*) INTO ll_count  FROM ORAGMP.CMCUSTM WHERE custcode = in_CUST_ID AND useyn = 'N';
    IF ll_count > 0 THEN
        out_COUNT := 0;
        out_CODE := 1;
        out_MSG := '<중지된 거래처입니다. 관리부로 연락하십시오.>'; 
        RAISE ERROR_EXCEPTION;
    END IF; 
     
    v_colno := 0; 
            
    --수금번호채번 
    IF in_JUNPYO_NO IS NULL OR in_JUNPYO_NO = '' THEN
        SELECT MAX(colno) into v_colno from ORAGMP.SLCOLM where plantcode = '1000' and coldate = to_char(SYSDATE,'YYYY-MM-DD');
        IF SQLCODE <> 0 THEN
            out_COUNT := 0;
            out_CODE := 1;
            out_MSG := '<수금번호채번 오류입니다. 관리부로 연락하십시오.>'; 
            RAISE ERROR_EXCEPTION;
        ELSE
            IF v_colno is null THEN
               v_colno := trim(to_char(to_number(to_char(SYSDATE,'YYYYMMDD')))||'0001');
            ELSE
               v_colno := trim(to_char(to_number(v_colno) + 1,'000000000000'));
            END IF;
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '수금번호 생성완료';         
            OPEN out_RESULT FOR
            SELECT v_colno  AS out_JUNPYO_NO ,in_CUST_ID AS out_CUST_ID FROM dual;            
        END IF;
                  
    ELSE
        v_colno := in_JUNPYO_NO ;    
    END IF;
        
    BEGIN
        
        INSERT INTO ORAGMP.SLCOLM (
                plantcode      --사업장
               ,colno          --수금번호
               ,coldate        --수금일자
               ,coldiv         --수금구분 01-현금 21-카드
               ,orderdiv       --영업영역 3-간납 4직납
               ,tasooyn        --자수타수구분(N:자수,Y:타수)
               ,custcode       --수금처코드
               ,deptcode       --수금담당부서코드;
               ,empcode        --수금담당코드;
               ,ecustcode      --수금처코드
               ,edeptcode      --수금담당부서코드
               ,eempcode       --수금담당코드
               ,colamt         --수금액
               ,colvat         --판매대행수수료(부가세)
               ,cardcomp       --카드사
               ,cardno         --카드번호
               ,cardokno       --카드승인번호
               ,divmonth       --할부개월
               ,carddate       --매출일자(카드)
               ,remark         --비고
               ,apprstatus     --상태구분  00:저장  01:입력  09:수금확정  99:반려
               ,insertdt       --입력일
               ,iempcode       --입력사번
               ,updatedt       --수정일
               ,uempcode       --수정사번
               )
        VALUES (     
               '1000'                                             --plantcode  사업장
               ,v_colno                                           --colno      수금번호 
               ,TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')   --coldate    수금일자
               ,'21'                                              --coldiv     수금구분 01-현금 21-카드
               ,'4'                                               --orderdiv   영업영역 3-간납 4직납
               ,'N'                                               --tasooyn    자수타수구분(N:자수,Y:타수)
               ,in_CUST_ID                                        --custcode   수금처코드
               ,v_dept_cd                                         --deptcode   수금담당부서코드;
               ,v_sawon_id                                        --empcode    수금담당코드;
               ,in_RCUST_ID                                       --ecustcode  수금처코드
               ,v_dept_cd                                         --edeptcode  수금담당부서코드
               ,v_sawon_id                                        --eempcode   수금담당코드
               ,decode( NVL(in_AMT, ''),'','0',to_number(in_AMT)) --colamt     수금액
               ,0                                                 --colvat     판매대행수수료(부가세)
               ,in_CARD_COMP                                      --cardcomp   카드사
               ,in_CARD_NO                                        --cardno     카드번호
               ,in_CARD_ACCEPT_NO                                 --cardokno   카드승인번호
               ,in_CARD_ALLOTMENT                                 --divmonth   할부개월
               ,TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')   --carddate   매출일자(카드) 
               ,'101'                                             --remark     비고
               ,'00'                                              --apprstatus 상태구분  00:저장    01:입력  09:수금확정    99:반려
               ,sysdate                                           --insertdt   입력일
               ,in_SAWON_ID                                       --iempcode   입력사번
               ,sysdate                                           --updatedt   수정일
               ,in_SAWON_ID                                       --uempcode   수정사번
               ); 
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :='수금마스터 저장실패:'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
        RAISE ERROR_EXCEPTION;
    END;
     
    
    out_CODE := 0;
    out_MSG := '카드 수금 정상 처리';
     
EXCEPTION
WHEN ERROR_EXCEPTION THEN
   out_CODE := 1; 
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
