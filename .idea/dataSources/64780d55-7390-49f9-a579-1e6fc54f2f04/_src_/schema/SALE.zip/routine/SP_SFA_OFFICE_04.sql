CREATE PROCEDURE      SP_SFA_OFFICE_04
(
    in_DICT_HANGUL       IN  VARCHAR2,  -- 의학용어(한글)
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 의학용어조회
 호출프로그램 :  제품> 의학용어       
          2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_MEDIDICT
     WHERE dict_hangul LIKE '%'||NVL(in_DICT_HANGUL, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT seq_no               AS out_SEQ_NO,         -- 의학용어 SEQ
               dict_hangul          AS out_DICT_HANGUL,    -- 의학용어명(한글)
               dict_eng             AS out_DICT_ENG,       -- 의학용어명(영어)
               dict_desc            AS out_DICT_DESC,      -- 용어설명
               dict_code            AS out_DICT_CODE       -- 분류코드
          FROM SFA_OFFICE_MEDIDICT
         WHERE dict_hangul LIKE '%'||NVL(in_DICT_HANGUL, '%')||'%'
         ORDER BY dict_hangul, DICT_CODE;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
