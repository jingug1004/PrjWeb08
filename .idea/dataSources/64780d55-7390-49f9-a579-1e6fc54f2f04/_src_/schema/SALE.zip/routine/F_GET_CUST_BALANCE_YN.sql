CREATE FUNCTION      F_GET_CUST_BALANCE_YN 
(
        in_CUST_ID IN VARCHAR2,
        in_FLAG IN VARCHAR2,
        in_YMD IN VARCHAR2
) 
RETURN VARCHAR2 IS
        /*---------------------------------------------------------------------------
        CHOE 20170209
        거래처의 잔고를 확인하는 함수
        중지처를 만들때 해당 함수의 리턴값으로 처리 할 수 있다
         
        in_FLAG
        C - in_CUST_ID 거래처 조회
        R - in_CUST_ID 간납처 조회
        그외는 모두 오류 
        
        V_RETURN 
        잔고가 0인 경우 Y
        잔고가 0이 아닌 경우 N
        ---------------------------------------------------------------------------*/    

        V_RETURN VARCHAR2(100);
        V_CNT NUMBER;
        V_BEFORE_AMT NUMBER;
        V_LAST_YMD VARCHAR2(8);
    
BEGIN
        V_CNT := 0;
        V_RETURN := 'Y';
        V_BEFORE_AMT := 0;
        
        SELECT COUNT(*)
        INTO V_CNT
        FROM SALE0003
        WHERE CUST_ID = in_CUST_ID
        ;
        
        IF V_CNT = 0 THEN
                V_RETURN := '거래처를 확인 할 수 없습니다.';
                RETURN V_RETURN;
        END IF;
                  
        IF in_FLAG = 'C' THEN
                
                --마지말 날짜를 찾아오는 로직을 심는다.
                V_LAST_YMD := '';
                SELECT TO_CHAR(MAX(YMD), 'YYYYMMDD') 
                INTO V_LAST_YMD
                FROM SALE0306 
                WHERE CUST_ID = in_CUST_ID             
                ORDER BY YMD DESC
                ;
        
                SELECT NVL(SUM(BEFORE_AMT),0) 
                INTO V_BEFORE_AMT  
                FROM (
                        SELECT CUST_ID AS CUST_ID                   /*전월 잔액 */
                        ,BEFORE_AMT AS BEFORE_AMT
                        FROM SALE0306
                        WHERE YMD = TO_DATE(SUBSTR(V_LAST_YMD, 1 ,6)||'01' ,'YYYYMMDD')  
                        AND CUST_ID = in_CUST_ID              
                UNION ALL                          
                        SELECT CUST_ID AS CUST_ID                  /*금월의 조회조건 기간까지의 잔액*/
                        ,NVL(A.AMT,0) + NVL(A.VAT,0) AS BEFORE_AMT                   
                        FROM SALE0207 B
                        ,SALE0208 A
                        WHERE A.DEAL_NO = B.DEAL_NO
                        AND A.YMD = B.YMD                   
                        AND A.YMD >= TO_DATE(SUBSTR(V_LAST_YMD, 1 ,6)||'01' ,'YYYYMMDD') 
                        AND A.YMD <= TO_DATE(V_LAST_YMD,'YYYYMMDD')  
                        AND B.CUST_ID = in_CUST_ID      
                UNION ALL                                      
                        SELECT CUST_ID AS CUST_ID    
                        ,(NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1 AS BEFORE_AMT
                        FROM SALE0401 A
                        WHERE A.YMD >= TO_DATE(SUBSTR(V_LAST_YMD, 1 ,6)||'01' ,'YYYYMMDD') 
                        AND A.YMD <= TO_DATE(V_LAST_YMD,'YYYYMMDD')
                        AND A.CUST_ID = in_CUST_ID       
                )
                GROUP BY CUST_ID  
                ;  

        ELSIF in_FLAG = 'R' THEN
                --마지말 날짜를 찾아오는 로직을 심는다.
                V_LAST_YMD := '';
                SELECT TO_CHAR(MAX(YMD), 'YYYYMMDD') 
                INTO V_LAST_YMD
                FROM SALE0306 
                WHERE CUST_ID = in_CUST_ID             
                ORDER BY YMD DESC
                ;
         
                SELECT NVL(SUM(BEFORE_AMT) ,0) 
                INTO V_BEFORE_AMT  
                FROM (                
                        SELECT RCUST_ID AS CUST_ID                   
                        ,BEFORE_AMT AS BEFORE_AMT
                        FROM SALE0306
                        WHERE YMD = TO_DATE(SUBSTR(V_LAST_YMD, 1 ,6)||'01' ,'YYYYMMDD') 
                        AND RCUST_ID = in_CUST_ID                 
                UNION ALL                          
                        SELECT RCUST_ID AS CUST_ID                  
                        ,NVL(A.AMT,0) + NVL(A.VAT,0) AS BEFORE_AMT                   
                        FROM SALE0207 B
                        ,SALE0208 A
                        WHERE A.DEAL_NO = B.DEAL_NO
                        AND A.YMD = B.YMD                   
                        AND A.YMD >= TO_DATE(SUBSTR(V_LAST_YMD, 1 ,6)||'01' ,'YYYYMMDD') 
                        AND A.YMD <= TO_DATE(V_LAST_YMD,'YYYYMMDD')
                        AND B.RCUST_ID = in_CUST_ID       
                UNION ALL                                      
                        SELECT RCUST_ID AS CUST_ID    
                        ,(NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1 AS BEFORE_AMT
                        FROM SALE0401 A
                        WHERE A.YMD >= TO_DATE(SUBSTR(V_LAST_YMD, 1 ,6)||'01' ,'YYYYMMDD') 
                        AND A.YMD <= TO_DATE(V_LAST_YMD,'YYYYMMDD')
                        AND A.RCUST_ID = in_CUST_ID
                 )
                GROUP BY CUST_ID  
                ;
        ELSE
                V_RETURN := '거래처/간납처 구분이 업습니다. 관리자에게 문의 바랍니다.';        
        END IF;        
        
           
        IF V_BEFORE_AMT = 0 THEN
                V_RETURN := 'Y';
        ELSIF V_BEFORE_AMT IS NULL THEN
                V_RETURN := '잔고가 확인 되지 않습니다.';
        ELSIF V_BEFORE_AMT <> 0 THEN
                V_RETURN := 'N1';       
        END IF;
        
        RETURN V_RETURN;
    
EXCEPTION
        WHEN NO_DATA_FOUND THEN
                RETURN '문제가 발생되었습니다.';
END;
/
