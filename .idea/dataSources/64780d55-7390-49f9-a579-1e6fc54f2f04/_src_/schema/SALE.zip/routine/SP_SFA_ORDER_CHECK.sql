CREATE PROCEDURE      SP_SFA_ORDER_CHECK
(
        in_CUST_ID            IN VARCHAR2 default NULL, 
        in_flag      IN  VARCHAR2 DEFAULT NULL,
        in_ymd       IN  date,
        in_GUMAE_NO  IN  VARCHAR2 DEFAULT NULL, 
        in_INPUT_SEQ IN  VARCHAR2 DEFAULT NULL, 
        in_ITEM_ID   IN  VARCHAR2 DEFAULT NULL, 
        in_QTY       IN  VARCHAR2 DEFAULT NULL, 
        in_DANGA     IN  NUMBER   DEFAULT NULL, 
        in_AMT       IN  VARCHAR2 DEFAULT NULL, 
        in_VAT       IN  VARCHAR2 DEFAULT NULL, 
        in_DC_AMT    IN  VARCHAR2 DEFAULT NULL,
        in_DC_QTY    IN  VARCHAR2 DEFAULT NULL, 
        in_DC_DANGA  IN  VARCHAR2 DEFAULT NULL,
        out_CODE     OUT NUMBER,
        out_MSG      OUT VARCHAR2,
        out_COUNT    OUT NUMBER,
        out_RESULT   OUT TYPES.CURSOR_TYPE

  )
IS
/*---------------------------------------------------------------------------
프로그램명  : 주문체크
호출프로그램 : 주문서등록의 수량입력후    
                                   
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼
                   - GMP에서 생성한 펑션을 호？하여 수량체크한다. 
 ---------------------------------------------------------------------------*/ 
        v_ITEM_ID   VARCHAR2(10);
        v_QTY       VARCHAR2(13);
        v_DANGA     VARCHAR2(13);
    
        v_retmsg    VARCHAR2(400);   

BEGIN     
                            
   IF in_FLAG = 'I' THEN

        v_ITEM_ID  := in_ITEM_ID;
        v_QTY      := in_QTY;
        v_DANGA    := to_char(in_DANGA);
 
   
        --제품체크 수량체크 ::이 체크로직은 SFA에서는 두곳에서 체크됨 : SP_Z_ORDER_CHECK 와 SP_Z_ORDR_123
        SELECT ORAGMP.fnSLordItemCheck('1000', to_char(in_ymd,'YYYYMMDD'), in_CUST_ID, in_CUST_ID, v_ITEM_ID, to_number(v_QTY), 'SFA', to_number(v_DANGA))
          INTO v_retmsg
          FROM DUAL; 
        
        IF SUBSTR(v_retmsg,1,1) = '0' THEN                     
            out_CODE := 1;     --0이면 out_MSG 가 client에 넘어가지 않음.
            out_MSG := '정상'; --이곳을 타면 수량은 정상임..
        ELSIF SUBSTR(v_retmsg,1,2) = '10' THEN   
            out_CODE := 2;     --0이면 out_MSG 가 client에 넘어가지 않음.
            out_MSG := v_retmsg ||' - 주문은 가능합니다' ; --이곳을 타면 수량위반  
        ELSE 
            out_CODE := 3; 
            out_MSG := v_retmsg; 
        END IF;   
     
    END IF; 
      
 
EXCEPTION  
        WHEN OTHERS THEN
             out_CODE := SQLCODE;
             out_MSG :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM || out_MSG);      
END;
/
