CREATE PROCEDURE      SP_SFA_ORDER_CHECK
(
        in_CUST_ID            IN VARCHAR2 default NULL, 
        in_flag      IN  VARCHAR2 DEFAULT NULL,
        in_ymd       IN  date,
        in_GUMAE_NO  IN  VARCHAR2 DEFAULT NULL, 
        in_INPUT_SEQ IN  VARCHAR2 DEFAULT NULL, 
        in_ITEM_ID   IN  VARCHAR2 DEFAULT NULL, 
        in_QTY       IN  VARCHAR2 DEFAULT NULL, 
        in_DANGA     IN  NUMBER DEFAULT NULL, 
        in_AMT       IN  VARCHAR2 DEFAULT NULL, 
        in_VAT       IN  VARCHAR2 DEFAULT NULL, 
        in_DC_AMT    IN  VARCHAR2 DEFAULT NULL,
        in_DC_QTY    IN  VARCHAR2 DEFAULT NULL, 
        in_DC_DANGA  IN  VARCHAR2 DEFAULT NULL,
        out_CODE     OUT NUMBER,
        out_MSG      OUT VARCHAR2,
        out_COUNT    OUT NUMBER,
        out_RESULT   OUT TYPES.CURSOR_TYPE

  )
IS
         /*---------------------------------------------------------------------------
         프로그램명   : 주문체크
         호출프로그램 :주문서등록의 수량입력후    
                   
         수정기록     : 
         1.20140403/ 김태안/ 위반주문 체크를 위한 수량체크 
          저장 프로시져 SP_SFA_ORDER_110 에서 수량체크를 하여 수량 초과이면 주문불가
          처리하였으나 그런 주문도 약속내용을 입력하면 주문가능하도록 로직변경하면서 
          수량체크를 하도록 함.(윤홍주 요청)
         2. 2014.05.16 KTA 로직 틀린거 수정함.
          이달의주문수량이 평균수량보다 크면 수량초과 메세지
          그리고 이것을 통과한경우 주문금액이 평균주문금액과비교하도록 수정함.
         3.2015.02.02 KTA 3개월이상 거래처 수량로직 수정
           ->이달주문수량이 20개 초과일때 월평균수량보다 큰지 체크하여 초과이면 주문불가함.
           ->이달주문수량이 20개 이내일때 월평균수량보다 큰지 체크하여 초과이면 주문불가하고 이내이면 월평균주문금액을 체크하여 초과이면 주문불가함.                
         4.2015.02.04 KTA 로직정리 다시하여 수정함
             <로직정리>
               .주문수량한도: 해당제품의 거래개월의 평균수량의 1.5배    
               .주문금액한도: 해당제품의 거래개월의 평균금액의 1.5배    
               .이달주문수량: 해당제품의 이달 총주문수량의 합계

               -이달주문수량이 20개 초과면 
               ----이달주문수량이 주문수량한도 이내면 가능
                                  
               -이달주문수량이 20개 이하면
               ----이달주문수량이 주문수량한도 이내면 가능
               ----이달주문수량이 주문수량한도 초과면 
               --------이달주문금액이 주문금액한도 이내면 가능
         5.2016.05.18 KTA 아시크라듀오시럽50ml*1병(30003) 은 40개 단위로만 주문가능.  
         
         6. 20170913 CHOE 관리부에서 요청 아시크라듀오시럽50ml*1병(30003)이 40개 단위의 주문이 아닌 경우에도 들어 온다고 함 : 오류 수정
         ITEM_ID = '30003' 에 40배수가 아닌 경우 return 3 + msg 으로 전달      
        ---------------------------------------------------------------------------*/
             
        ll_months number := 0;   --개시개월수
        ll_mqty number := 0;   --이달의주문수량계
        ll_avgqty number := 0;   --평균주문수량(3개월)
        ll_mamt number := 0;   --이달의주문금액계
        ll_avgamt number := 0;   --평균주문금액(3개월)
        ll_limit_qtyrate number := 0;   --주문수량한도율 거래처등록에서 가져옴      
        ll_limit_amtrate number := 0;   --주문금액한도율 공통코드 IN02 에서 가져옴
        ll_SupplySum number := 0;   --주문금액계산용TEMP 
            
        v_CUST_ID VARCHAR2(10); 
        v_ITEM_ID VARCHAR2(10);
        v_date_first DATE;
        v_date_last DATE;
        v_QTY VARCHAR2(12);
        v_AMT VARCHAR2(13);
        v_VAT VARCHAR2(13);
        v_ITEM_NM VARCHAR2(50);
            
            
        v_retmsg VARCHAR2(400);    
        ERROR_RAISE EXCEPTION; 
        ERROR_RAISE_C1 EXCEPTION; 

BEGIN   


--    INSERT INTO SFA_SP_CALLED_HIST 
--    VALUES ('SP_SFA_ORDER_CHECK','1000',sysdate,'in_CUST_ID'||in_CUST_ID
--            ||'||in_flag     :'||in_flag
--            ||'||in_ymd      :'||to_char(in_ymd,'yyyymmdd')
--            ||'||in_GUMAE_NO :'||in_GUMAE_NO
--            ||'||in_INPUT_SEQ:'||in_INPUT_SEQ
--            ||'||in_ITEM_ID  :'||in_ITEM_ID
--            ||'||in_QTY      :'||in_QTY
--            ||'||in_DANGA    :'||in_DANGA
--            ||'||in_VAT      :'||in_VAT
--            ||'||in_DC_AMT   :'||in_DC_AMT
--            ||'||in_DC_QTY   :'||in_DC_QTY
--            ||'||in_DC_DANGA :'||in_DC_DANGA
--            );
--    COMMIT; 
                
   IF in_FLAG = 'I' THEN            
        --주문수량통제 start ---------------------------------------------------------------------
        BEGIN
    
            v_CUST_ID := in_CUST_ID;
            v_ITEM_ID := in_ITEM_ID;    
            v_date_first := to_date(to_char(in_YMD,'yyyymm')||'01','yyyymmdd');
            v_date_last  := last_day(to_date(to_char(in_YMD,'yyyymm')||'01','yyyymmdd'));
            v_QTY        := in_QTY;
            --v_AMT        := in_AMT; --주문로직에서 분리하면서 안들어옴   
            select  item_nm into v_ITEM_NM from  sale.sale0004 where item_id = v_ITEM_ID;  


            --아시크라듀오시럽50ml*1병(30003) 은 40개 단위로만 주문가능
            IF v_ITEM_ID = '30003' THEN
                IF MOD(v_QTY,40) <> 0 THEN  
                    v_retmsg := v_ITEM_NM || ' 은 40개 배수로만 주문가능 합니다. 주문 수량을 수정하시기 바랍니다.';
                    --RAISE ERROR_RAISE;  --CHOE 20170913
                    RAISE ERROR_RAISE_C1;
                END IF;
            END IF;
            

            --주문월-개시월=개시개월수
            ll_months := 0;
            SELECT trunc(months_between(to_date(to_char(in_YMD,'yyyymm'),'yyyymm'), to_date(to_char(START_YMD,'yyyymm'),'yyyymm')))  --일자로 하지 않고 1일로 바꿔서 
              INTO ll_months
              FROM SALE.SALE0003
             WHERE CUST_ID = v_CUST_ID;
                               
           --이달주문수량(이번 주문포함)
            SELECT sum(QTY1) + sum(QTY2) + v_QTY
              INTO ll_mqty
              FROM (--ERP 이달주문수량
                    SELECT NVL(SUM(B.QTY),0) QTY1 , 0 AS QTY2
                      FROM SALE0203 A, SALE0204 B  
                     WHERE A.CUST_ID    = v_CUST_ID
                       AND A.YMD        >= v_date_first
                       AND A.YMD        <= LAST_DAY(TO_DATE(TO_CHAR(in_YMD,'YYYYMM')||'01','YYYYMMDD'))
                       AND A.GUMAE_NO   = B.GUMAE_NO 
                       AND B.ITEM_ID    = v_ITEM_ID
                   UNION
                   --온라인 이달주문수량
                    SELECT 0 AS QTY1 , NVL(SUM(B.QTY),0) QTY2
                      FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B 
                     WHERE A.CUST_ID    = v_CUST_ID
                       AND A.YMD        >= v_date_first
                       AND A.YMD        <= v_date_last
                       AND A.GUMAE_NO   = B.GUMAE_NO
                       AND A.RECEIPT_GB = '1'--접수구분(1.접수, 2.승인, 3.반려) 
                       AND A.WIBAN_ORDER_CONF_YN    <> '2' /*위반주문 지점장 반려한것빼고 */
                       AND B.ITEM_ID    = v_ITEM_ID
                   );
                             
            --수량을 선택하면서 이프로시져가 호출되었기에  v_AMT 와 v_VAT는 값이 들어오지 않는다.
            --따라서 이달의 주문금액을 위해 이번 주문의 금액을 먼저 계산한다. 
            --3번 4번으로 시작하는 거래처는 소숫점이하 1자리가 .1 이상이면 일의자리를 +1 해준다       
            
            --이번주문의 주문금액  
            SELECT OUT_DANGA * to_number(in_QTY) INTO ll_SupplySum FROM SALE0004 WHERE ITEM_ID = in_ITEM_ID;
            
            IF SUBSTR(v_CUST_ID,1,1) = '3' OR SUBSTR(v_CUST_ID,1,1) = '4' THEN
               if ll_SupplySum >= 0 then
                  v_AMT := round(ll_SupplySum / 1.1 + 0.4);
               else
                  v_AMT := round(ll_SupplySum / 1.1 - 0.4);
               end if;
               v_VAT := ll_SupplySum - v_AMT;
            ELSE               
               v_VAT := ll_SupplySum * 0.1;
            END IF;
             
                     
            --이달주문금액(이번 주문포함) 모든제품을 통틀어서 합계를 구한다.
            SELECT sum(AMT1) + sum(AMT2) + NVL(v_AMT,0) + NVL(v_VAT,0) 
              INTO ll_mamt
              FROM (--ERP 이달주문수량
                    SELECT NVL(SUM(B.AMT),0) + NVL(SUM(B.VAT),0) AS AMT1
                          ,0 AS AMT2
                      FROM SALE0203 A, SALE0204 B  
                     WHERE A.CUST_ID    = v_CUST_ID
                       AND A.YMD        BETWEEN v_date_first AND v_date_last
                       AND A.GUMAE_NO   = B.GUMAE_NO 
                       --AND B.ITEM_ID    = v_ITEM_ID
                   UNION
                   --온라인 이달주문수량
                    SELECT 0 AS AMT1
                          ,NVL(SUM(B.AMT),0) + NVL(SUM(B.VAT),0) AS AMT2
                      FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B 
                     WHERE A.CUST_ID    = v_CUST_ID
                       AND A.YMD        BETWEEN v_date_first AND v_date_last
                       AND A.GUMAE_NO   = B.GUMAE_NO
                       AND A.RECEIPT_GB = '1'--접수구분(1.접수, 2.승인, 3.반려) 
                       --AND B.ITEM_ID    = v_ITEM_ID
                   );

                               
            --주문한도율
            SELECT JUMUN_LIMIT / 100 INTO ll_limit_qtyrate FROM SALE.SALE0003 WHERE CUST_ID = v_CUST_ID;
               
            --주문금액한도율 
            SELECT  TO_NUMBER(NVL(CODE2_NM,'0')) / 100 INTO ll_limit_amtrate FROM SALE0001 WHERE CODE_GB = 'IN02' AND CODE1 = '040';
                 
            IF ll_months = 0 THEN      --이달개시거래처 또는 향정제품은 이달수량만 체크

                IF ll_mqty > 20 THEN  --이달주문수량
                    --v_retmsg := '1';
                    v_retmsg := v_ITEM_NM || '의 이달 주문합계수량('|| ll_mqty || ')이 20개를 초과하였습니다(개시당월)';
                    RAISE ERROR_RAISE;
                END IF;
                            
            ELSIF ll_months = 1 OR  ll_months = 2 THEN  --개시개월1달
            
                        
                --주문수량한도
                SELECT ROUND(QTY * ll_limit_qtyrate)
                  INTO ll_avgqty
                  FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / ll_months )) QTY
                            FROM SALE.SALE0203 A, SALE.SALE0204 B 
                           WHERE A.GUMAE_NO = B.GUMAE_NO
                             AND A.CUST_ID  = v_CUST_ID 
                             AND B.ITEM_ID  = v_ITEM_ID 
                             AND A.YMD     BETWEEN ADD_MONTHS(v_date_first,-(ll_months)) AND ADD_MONTHS(v_date_last,-1) 
                         );
                        
                                     
                IF ll_mqty > 20 THEN  --이달주문수량 20개 초과이면 주문수량한도체크   
                    IF ll_mqty > ll_avgqty THEN
                       v_retmsg := v_ITEM_NM || '의 이달 주문합계수량('|| ll_mqty || ')이 '|| ll_months ||' 개월평균주문수량의1.5배인 '|| ll_avgqty ||' 개를 초과하였습니다(개시'|| ll_months ||'개월)';
                       RAISE ERROR_RAISE;
                    END IF;             
                  
                ELSE                  --이달주문수량 20개 이내일때 주문수량한도 초과면 주문금액한도 체크   
                                                   
                    IF ll_mqty > ll_avgqty THEN
                    
                        --주문가능금액
                        SELECT ROUND(AMT * ll_limit_amtrate)
                          INTO ll_avgamt
                          FROM   (SELECT ROUND((NVL(SUM(B.AMT + B.VAT),0) / ll_months )) AMT
                                    FROM SALE.SALE0203 A, SALE.SALE0204 B 
                                   WHERE A.GUMAE_NO = B.GUMAE_NO
                                     AND A.CUST_ID  = v_CUST_ID   
                                 );                            

                        IF ll_mamt > ll_avgamt THEN  --이달주문금액이 월평균주문금액 보다 크면 
                            v_retmsg := v_ITEM_NM || '의 이달 주문합계금액('|| ll_mamt || ')이 '|| ll_months ||' 개월평균주문금액의1.5배인 '|| ll_avgamt ||' 원을 초과하였습니다(개시'|| ll_months ||'개월)';
                            RAISE ERROR_RAISE;
                        END IF; 
                    END IF;             
                    
                END IF;  
                
                         
            ELSE                         --개시개월3달이상
                        
                --주문수량한도         
                SELECT ROUND(QTY * ll_limit_qtyrate)
                  INTO ll_avgqty
                  FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 3 )) QTY
                            FROM SALE.SALE0203 A, SALE.SALE0204 B 
                           WHERE A.GUMAE_NO = B.GUMAE_NO
                             AND A.YMD      BETWEEN ADD_MONTHS(v_date_first,-3) AND ADD_MONTHS(v_date_last,-1) 
                             AND A.CUST_ID  = v_CUST_ID 
                             AND B.ITEM_ID  = v_ITEM_ID 
                         );
                                        
                IF ll_mqty > 20 THEN  --이달주문수량 20개 초과시 주문수량한도체크
                   
                    IF ll_mqty > ll_avgqty THEN                        
                       v_retmsg := v_ITEM_NM || '의 이달 주문합계수량('|| ll_mqty || ')이 3개월평균주문수량의1.5배인 '|| ll_avgqty ||' 개를 초과하였습니다(개시3개월이상)';
                       RAISE ERROR_RAISE;                       
                    END IF;
                    
                ELSE                   --이달주문수량 20개 이내일때 주문수량한도 초과면 주문금액한도 체크   
                    
                    IF ll_mqty > ll_avgqty THEN      
                                     
                        --주문금액한도 : 제품에 관계없이 최근3개월간의 총금액으로 한다....윤홍주차장요청
                        SELECT ROUND(AMT * ll_limit_amtrate )
                          INTO ll_avgamt
                          FROM   (SELECT ROUND((NVL(SUM(B.AMT + B.VAT),0) / 3 )) AMT
                                    FROM SALE.SALE0203 A, SALE.SALE0204 B 
                                   WHERE A.GUMAE_NO = B.GUMAE_NO
                                     AND A.YMD      BETWEEN ADD_MONTHS(v_date_first,-3) AND ADD_MONTHS(v_date_last,-1) 
                                     AND A.CUST_ID  = v_CUST_ID   
                                 );
                        IF ll_mamt > ll_avgamt THEN
                            v_retmsg := v_ITEM_NM || '의 이달 주문합계금액('|| ll_mamt || ')이 3개월평균주문금액의1.5배인 '|| ll_avgamt ||' 원을 초과하였습니다(개시3개월이상)';
                            RAISE ERROR_RAISE;
                        END IF;       
                         
                    END IF;                  
                    
                END IF;  
                                                
            END IF;  

        END; 
                    
                    
        --주문수량통제 end --------------------------------------------------------------------- 
    
    END IF;
    
    
      
    out_CODE := 1;     --0이면 out_MSG 가 client에 넘어가지 않음.
    out_MSG := '정상'; --이곳을 타면 수량은 정상임..   
  
EXCEPTION 
        WHEN ERROR_RAISE THEN
                out_CODE := 2;     --0이면 out_MSG 가 client에 넘어가지 않음.
                out_MSG := v_retmsg ||' - 주문은 가능합니다' ; --이곳을 타면 수량위반   
        
        WHEN ERROR_RAISE_C1 THEN
                out_CODE := 3; 
                out_MSG := v_retmsg; 
        
        WHEN OTHERS THEN
                out_CODE := SQLCODE;
                out_MSG :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM || out_MSG);      
END;
/
