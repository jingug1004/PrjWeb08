CREATE PROCEDURE      SP_X_COMMON_TEAMNAME
(
    in_KEYWORD     IN VARCHAR2,
    out_DEPT_NM   OUT VARCHAR2,
    out_CODE      OUT NUMBER,
    out_MSG       OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_COMMON_TEAMNAME
-- 작 성 자      : 유명배
-- 작성일자      : 2017-12-01
-- 수 정 자      : 
-- 수정일자      : 2017-12-01
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  부서명 검색 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
   	SELECT A.DEPT_NM INTO out_DEPT_NM
		  FROM SALE.SALE0008 A
		 WHERE A.DEPT_CD = in_KEYWORD;
		 
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
