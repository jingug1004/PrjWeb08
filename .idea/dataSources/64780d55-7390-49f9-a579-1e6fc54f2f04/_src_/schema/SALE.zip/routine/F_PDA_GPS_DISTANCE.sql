CREATE FUNCTION      F_PDA_GPS_DISTANCE (FROM_LAT NUMBER,FROM_LONG NUMBER,
TO_LAT NUMBER,TO_LONG NUMBER)
RETURN NUMBER IS

N_NUM NUMBER := 0;

EARTH_R NUMBER := 6371000.0;

Rad NUMBER := 0;
radLat1 NUMBER := 0;
radLat2 NUMBER := 0;
radDist NUMBER := 0;
distance NUMBER := 0;
        
BEGIN
IF (FROM_LAT = TO_LAT) AND (FROM_LONG = TO_LONG) THEN
RETURN 0;
ELSE
/*
N_NUM := 3959.0 * ACOS(SIN(TO_LAT/57.30) * SIN(FROM_LAT/57.30)
+ COS(TO_LAT/57.30) * COS(FROM_LAT/57.30)
* COS((TO_LONG/57.30) - (FROM_LONG/57.30)));
--N_NUM := acos((sin(TO_LAT)-sin(FROM_LAT)*cos(N_NUM))/(cos(FROM_LAT)*sin(N_NUM)))*(180/3.141592);


RETURN ROUND(N_NUM,0);
*/
--signed long double Distance = acos(sin(dLat1)*sin(dLat2) + cos(dLat1)*cos(dLat2)*cos(dLon1 - dLon2));
-- signed long double Degree = acos((sin(dLat2)-sin(dLat1)*cos(Distance))/(cos(dLat1)*sin(Distance)))*(180/3.141592);
/*
N_NUM := ACOS(SIN(TO_LAT) * SIN(FROM_LAT)
+ COS(TO_LAT) * COS(FROM_LAT)
* COS((TO_LONG) - (FROM_LONG)));

N_NUM := acos((sin(TO_LAT)-sin(FROM_LAT)*cos(N_NUM))/(cos(FROM_LAT)*sin(N_NUM)))*(180/3.141592);
*/

Rad := 3.14 / 180;
radLat1 := Rad * from_lat;
radLat2 := Rad * to_lat;
radDist := Rad * (from_long - to_long);
        
distance := sin(radLat1) * sin(radLat2);
distance := distance + cos(radLat1) * cos(radLat2) * cos(radDist);
N_NUM := EARTH_R * acos(distance);

return  N_NUM;

--RETURN ROUND(N_NUM,0);

END IF;
END; -- COMPUTE DISTANCE 

/
