CREATE PROCEDURE      SP_SFA_COMMON_LIST   
(
    in_CODE_GB           IN  VARCHAR2,  -- 그룹코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 공통코드 현황
 호출프로그램 : LoginActivity - bizCommonCodes
 최초작성   : 2012.10.01
 수정기록   : 2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
BEGIN 
     
    SELECT SUM(CNT)
      INTO v_num
      FROM (SELECT COUNT(*) AS CNT
              FROM oragmp.cmcommonm                    
             WHERE usediv = 'Y'     
               AND cmmcode in ('SL05','SL30','SL42','CM15','CM20') --진료과목,고객구분,직책,유통구분,거래처상태 
            UNION ALL
            SELECT COUNT(*) AS CNT          
              FROM hanagw.TGWBDRM 
             WHERE BRD_TYPE LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,5) IN ( 'BRD-0', 'BRD-2') THEN NVL(in_CODE_GB,'%') ELSE 'NO' END)
            UNION ALL
            SELECT COUNT(*) AS CNT   
              FROM hanagw.TCMORG 
             WHERE ORGNO IN (SELECT DISTINCT ORGNO FROM hanagw.TCMORG_R)
               AND 'BRD-D'||ORGNO LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,5) = 'BRD-D' THEN NVL(in_CODE_GB,'%')||'%'  ELSE 'NO' END)
            UNION ALL
            SELECT COUNT(*) AS CNT  
              FROM (SELECT acccode,accname,'식당,술집'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%복리후생비%'  UNION ALL
                    SELECT acccode,accname,'주유소,차수리,교통카드충전,하이패스'    AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%차량유지비%'  UNION ALL
                    SELECT acccode,accname,'교통비(버스,기차,비행기),숙박비,주차비' AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%여비교통비%'  UNION ALL
                    SELECT acccode,accname,'가전제품매장,철물점 등'            AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%소모품비%'    UNION ALL
                    SELECT acccode,accname,'회의비'                     AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%회의비%'      UNION ALL
                    SELECT acccode,accname,'교육훈련비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%교육훈련비%'  UNION ALL
                    SELECT acccode,accname,'도서인쇄비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%도서인쇄비%'  UNION ALL
                    SELECT acccode,accname,'운반비'                     AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%운반비%'      UNION ALL
                    SELECT acccode,accname,'철도청,반환수수료'               AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%지급수수료%'  UNION ALL
                    SELECT acccode,accname,'지급수수료'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%집기비품%'    UNION ALL
                    SELECT acccode,accname,'판매촉진비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%판매촉진비%'  UNION ALL
                    SELECT acccode,accname,'통신비'                     AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%통신비%'      UNION ALL
                    SELECT acccode,accname,'광고선전비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%광고선전비%'
                    )               A,            
                    oragmp.acaccm   B
              WHERE B.acccode = A.acccode 
                AND B.orduseyn = 'Y'
                AND B.acccode IN ('73300000','73310000','73110000','73120000','73220000','73550100')
             UNION ALL
             SELECT COUNT(*) AS CNT  FROM DUAL   
                        
           );
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT cmmcode                   AS out_CODE_GB  
              ,cmmname                   AS out_CODE_GB_NM
              ,divcode                   AS out_CODE1   
              ,divname                   AS out_CODE1_NM  
          FROM ORAGMP.CMCOMMONM                    
         WHERE usediv = 'Y'     
           AND cmmcode in ('SL05','SL30','SL42','CM15','CM20') --진료과목,고객구분,직책,유통구분,거래처상태 
        UNION ALL
        SELECT 'BRD-'||BRD_TYPE          AS out_CODE_GB     -- 카테고리 그룹코드(0:게시판, 2:자료실)
             , DECODE(BRD_TYPE, '0', '게시판', '2', '자료실', '미정의') AS out_CODE_GB_NM
             , TO_CHAR(BRD_NO)           AS out_CODE1       -- 카테고리 코드 NUMBER
             , BRD_NM                    AS out_CODE1_NM    -- 카테고리 명               
          FROM hanagw.TGWBDRM 
         WHERE 'BRD-'||BRD_TYPE LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,5) IN ( 'BRD-0', 'BRD-2') THEN NVL(in_CODE_GB,'%') ELSE 'NO' END)
        UNION ALL
        SELECT 'BRD-D'                   AS out_CODE_GB     -- 그룹코드
             , '그룹웨어 부서'                AS out_CODE_GB_NM  -- 그룹코드명
             , ORGNO                     AS out_CODE1       -- 부서코드 
             , ORG_NM                    AS out_CODE1_NM    -- 부서 명               
          FROM hanagw.TCMORG 
         WHERE ORGNO IN (SELECT DISTINCT ORGNO FROM hanagw.TCMORG_R)
           AND 'BRD-D'||ORGNO LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,5) = 'BRD-D' THEN NVL(in_CODE_GB,'%')||'%'  ELSE 'NO' END)
        UNION ALL
        SELECT 'ACNT'                    AS out_CODE_GB     -- 그룹코드(회계 계정)
             , '그룹웨어 회계계정'              AS out_CODE_GB_NM  -- 그룹코드명
             , A.acccode                 AS out_CODE1       -- 계정과목
             , A.accname                 AS out_CODE1_NM    -- 사용과목명
          FROM (SELECT acccode,accname,'식당,술집'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%복리후생비%'  UNION ALL
                SELECT acccode,accname,'주유소,차수리,교통카드충전,하이패스'    AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%차량유지비%'  UNION ALL
                SELECT acccode,accname,'교통비(버스,기차,비행기),숙박비,주차비' AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%여비교통비%'  UNION ALL
                SELECT acccode,accname,'가전제품매장,철물점 등'            AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%소모품비%'    UNION ALL
                SELECT acccode,accname,'회의비'                     AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%회의비%'      UNION ALL
                SELECT acccode,accname,'교육훈련비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%교육훈련비%'  UNION ALL
                SELECT acccode,accname,'도서인쇄비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%도서인쇄비%'  UNION ALL
                SELECT acccode,accname,'운반비'                     AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%운반비%'      UNION ALL
                SELECT acccode,accname,'철도청,반환수수료'               AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%지급수수료%'  UNION ALL
                SELECT acccode,accname,'지급수수료'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%집기비품%'    UNION ALL
                SELECT acccode,accname,'판매촉진비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%판매촉진비%'  UNION ALL
                SELECT acccode,accname,'통신비'                     AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%통신비%'      UNION ALL
                SELECT acccode,accname,'광고선전비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '%광고선전비%'
                )                A,            
                oragmp.acaccm   B
          WHERE B.acccode = A.acccode 
            AND B.orduseyn = 'Y'
            AND B.acccode IN ('73300000','73310000','73110000','73120000','73220000','73550100')
         UNION ALL
         SELECT 'ACNT','그룹웨어 회계계정','','선택안함' FROM DUAL   
         ORDER BY 1, 3;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
