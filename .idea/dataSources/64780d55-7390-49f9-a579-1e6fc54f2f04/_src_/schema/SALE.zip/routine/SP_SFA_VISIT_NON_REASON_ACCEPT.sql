CREATE PROCEDURE      SP_SFA_VISIT_NON_REASON_ACCEPT 
(
    in_PROCESS      IN  VARCHAR2,   
    in_SAWON_ID          IN  VARCHAR2,   
    in_SOLAR             IN  VARCHAR2,    
    in_REASON1          IN  VARCHAR2,   
    in_REASON2          IN  VARCHAR2,   
    in_REASON3          IN  VARCHAR2,   
    in_REASON          IN  VARCHAR2,   
    in_SEONGIN_EMP_NO          IN  VARCHAR2,   
    in_SEONGIN_CONF_YN         IN  VARCHAR2,   
    in_COMP_CONF_YN          IN  VARCHAR2,   
    out_CODE             out NUMBER,
    out_MSG              out VARCHAR2,
    out_COUNT            out NUMBER,
    out_RESULT           out TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 미방문사유등록
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
   
     SELECT COUNT(*)
      INTO v_num
     FROM SFA_VISIT_NON_REASON 
     WHERE EMP_NO = in_SAWON_ID
        AND SALES_PLAN_NO = in_SOLAR
    ;
   
    
    IF v_num = 0 THEN -- 신규등록
        insert into 
            SFA_VISIT_NON_REASON(SALES_PLAN_NO, EMP_NO,          REASON_GB1,        REASON_GB2,     REASON_GB3, 
                                NONVISIT_REASON,SEONGINJA_EMP_NO,SEONGINJA_CONF_YN, COMPANY_CONF_YN) 
                         values (in_SOLAR,      in_SAWON_ID,in_REASON1,in_REASON2,in_REASON3,
                                in_REASON,    in_SEONGIN_EMP_NO,in_SEONGIN_CONF_YN,in_COMP_CONF_YN) ;
                
        out_CODE := 0;
        out_MSG := '요청하신 작업이 처리되었습니다.';  
                
    ELSE    -- 업데이트
        update SFA_VISIT_NON_REASON set REASON_GB1      = in_REASON1,
                                        REASON_GB2      = in_REASON2,
                                        REASON_GB3      = in_REASON3,
                                        NONVISIT_REASON = in_REASON,
                                        SEONGINJA_EMP_NO= in_SEONGIN_EMP_NO,
                                        SEONGINJA_CONF_YN = in_SEONGIN_CONF_YN,
                                        COMPANY_CONF_YN = in_COMP_CONF_YN
               where EMP_NO = in_SAWON_ID
                    AND SALES_PLAN_NO = in_SOLAR;                         
        out_CODE := 0;
        out_MSG := '요청하신 작업이 처리되었습니다.';                                        
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
