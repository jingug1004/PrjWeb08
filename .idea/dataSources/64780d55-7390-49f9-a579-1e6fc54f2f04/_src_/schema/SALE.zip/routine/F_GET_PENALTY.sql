CREATE FUNCTION      F_GET_PENALTY -- 벌금현황
(
        in_DEAL_NO IN VARCHAR2
        ,in_CUST_ID IN VARCHAR2
        ,in_RCUST_ID IN VARCHAR2 
        ,in_ITEM_ID IN VARCHAR2
        ,in_QTY IN NUMBER   
        ,in_DANGA IN NUMBER  
        ,in_PROD_NO IN VARCHAR2
        ,in_USE_YMD_TO IN VARCHAR2        
        ,in_OPTION1 IN VARCHAR2      
) 
RETURN VARCHAR2 IS
PRAGMA AUTONOMOUS_TRANSACTION;

        V_CNT NUMBER; --자료 조회에 사용할 변수  
        V_RETURN VARCHAR2(1000);
       
        V_TURN_BACK_DT VARCHAR2(8); --반품일
        V_SALES_DT VARCHAR2(8); --매출일
        
        V_REMAIN_QTY_1 SALE0207_PENALTY.REMAIN_QTY%TYPE;  --남은 수량을 입력 할때 사용한다. 임시 변수
        V_REMAIN_QTY_2 SALE0207_PENALTY.REMAIN_QTY%TYPE;  --남은 수량을 조회 할때 사용한다. 임시 변수        
                
        V_IN_QTY NUMBER;  --매출 수량 
        V_PENALTY_QTY NUMBER;  --최종적으로 계산된 수량
    
BEGIN

        /* CHOE 20121007
        반품 벌금 
        업부 정리 - 아래 설명을 충분히 확인 후 수정 바랍니다.

        파라미터 정의 
        in_FROM_YMD - 조회 시작일
        in_TO_YMD - 조회 종료일
        
        in_DEAL_NO - 거래처 코드  
        in_QTY - 반품 수량   
        in_PROD_NO - 제조번호 전달 받음 
        in_USE_YMD_TO - 유통기한 전달 받음
       
        in_OPTION1 - 팀원 = 'EMP' / 팀장 = 'TEAM'  : 수량 값이 아닌 계산 된 벌금 전달
        
        리턴은 숫자가 아닌 문자로 전달합니다. 받는 곳에서 숫자로 번환하여 사용 바랍니다.
        리턴 값이 '0000000' 인 경우 오류 입니다.
 
        */
        
        
        /*0. 파라미터 정보 체크*/
        V_RETURN := '초기화';  --변수 초기화
        --V_RETURN := '999999999';     
        IF in_DEAL_NO = '' OR in_CUST_ID = '' OR in_RCUST_ID = '' OR in_ITEM_ID = '' OR in_QTY = '' OR in_PROD_NO = '' OR in_USE_YMD_TO = '' OR in_OPTION1 = '' THEN
                V_RETURN := '파라미터 오류';                   
                RETURN V_RETURN;  --파라미터 오류
        END IF;
        
       -- 팀원 팀장 구분 없이 1년 이상 남은 경우 벌금 없음
        V_TURN_BACK_DT := SUBSTR(in_DEAL_NO ,1 ,8);
        
         /*1-1. 반품일 + 1년 > 유통기한 (1년이상 남은 경우)*/
        --IF ROUND((TO_DATE(in_USE_YMD_TO) - TO_DATE(V_TURN_BACK_DT)) / 30 ) >= 12 THEN   --ROUND x        
        IF TRUNC((TO_DATE(in_USE_YMD_TO) - TO_DATE(V_TURN_BACK_DT)) / 30 ) >= 12 THEN
                                  
                V_RETURN := '유통기한1년이상 0원';                
                RETURN V_RETURN;
        
        ELSE              
                
                V_IN_QTY := 0;
                V_PENALTY_QTY := in_QTY * -1;  --반품 수량 전체 양의 부호를 만든다. 
                V_REMAIN_QTY_1 := 0;  --남은 수량      
                V_REMAIN_QTY_2 := 0;  --남은 수량       
                /*매출 없이 반품이 들어 오는 경우*/  
                BEGIN   
                        SELECT COUNT(*)     
                        INTO V_CNT                        
                        FROM SALE0207 A
                        ,SALE0208 B   
                        ,SALE0208_1 C                                    
                        WHERE A.DEAL_NO = B.DEAL_NO  
                        AND A.DEAL_NO= C.DEAL_NO                                     
                        AND A.YMD = B.YMD  
                        AND B.ITEM_ID = C.ITEM_ID
                        AND B.INPUT_SEQ = C.INPUT_SEQ                           
                        AND A.CUST_ID = in_CUST_ID
                        AND A.RCUST_ID = in_RCUST_ID
                        AND B.ITEM_ID = in_ITEM_ID 
                        AND C.PROD_NO = in_PROD_NO
                        AND A.DEAL_GB = '01'  --출고                                       
                        ORDER BY A.DEAL_NO DESC
                        ;
                         IF V_CNT = 0 THEN
                                V_RETURN := '매출정보찾기실패';                                        
                                RETURN V_RETURN;
                        END IF;
                         
                EXCEPTION 
                        WHEN NO_DATA_FOUND THEN
                                RETURN V_RETURN;       
                        WHEN others THEN
                                RETURN V_RETURN;           
                END;                                    
                 
                /*계산 하기 위한 반품 수량을 계산해 온다.*/  
                BEGIN      
                                        
                        FOR C1 IN (
                                SELECT NVL(A.DEAL_NO ,'') AS DEAL_NO
                                ,B.QTY                                 
                                FROM SALE0207 A
                                ,SALE0208 B   
                                ,SALE0208_1 C                                    
                                WHERE A.DEAL_NO = B.DEAL_NO  
                                AND A.DEAL_NO= C.DEAL_NO                                     
                                AND A.YMD = B.YMD  
                                AND B.ITEM_ID = C.ITEM_ID
                                AND B.INPUT_SEQ = C.INPUT_SEQ                           
                                AND A.CUST_ID = in_CUST_ID
                                AND A.RCUST_ID = in_RCUST_ID
                                AND B.ITEM_ID = in_ITEM_ID 
                                AND C.PROD_NO = in_PROD_NO
                                AND A.DEAL_GB = '01'  --출고                                       
                                ORDER BY A.DEAL_NO DESC
                        ) LOOP
                                
                                V_RETURN := V_RETURN||' , '||V_SALES_DT;   
                                /*종료 조건은 V_PENALTY_QTY 계산을 위한 반품수량이 0이 된 경우 ,모든 loop를 비교한 경우*/
                                IF V_PENALTY_QTY = 0 THEN                                                      
                                        EXIT;                               
                                END IF;
                                        
                                V_IN_QTY := C1.QTY;                                                
                                V_SALES_DT := SUBSTR(C1.DEAL_NO ,1 ,8);  --매출일     
                                                                              
                                /*등록된 정보가 있는지 본다.*/
                                SELECT COUNT(*)
                                INTO V_CNT
                                FROM SALE0207_PENALTY
                                WHERE IN_DEAL_NO = C1.DEAL_NO
                                ;
                                                       
                                IF V_CNT = 0 THEN
                                               
                                        /*2-1. 반품 수량 >= 매출 수량*/
                                        IF V_PENALTY_QTY >= V_IN_QTY THEN
                                                
                                                /*3-1. 매출일 + 1년 > 유통기한 (1년 미만)*/
                                                IF ROUND((TO_DATE(in_USE_YMD_TO) - TO_DATE(V_SALES_DT)) / 30 ) < 12 THEN
                                                --IF TO_DATE(V_SALES_DT) + 365 > TO_DATE(in_USE_YMD_TO) THEN
                                                        V_PENALTY_QTY := V_PENALTY_QTY - V_IN_QTY; --매출 수량 모두 소진 , 계산할 반품 수량을 줄여준다 : 1년 미만 제품이 나가서 미안                                                             
                                                                         
                                                        INSERT INTO SALE0207_PENALTY (INPUT_SEQ ,IN_DEAL_NO ,REMAIN_QTY)
                                                        VALUES(SEQ_SALE0207_PENALTY.NEXTVAL ,C1.DEAL_NO ,0)
                                                        ;
                                                        COMMIT;
                                                /*3-2. 유통기간 + 1년 >= 매출일 (1년 이상)*/       
                                                --ELSE  --처리할 내용 없음, 해당 매출은 다른 반품 건과 비교 가능 하다 : 기록하지 않고 넘김                                                                        
                                                END IF;
                                        /*2-1. 반품 수량 < 매출 수량*/                                                                        
                                        ELSE
                                                                    
                                                /*3-1. 매출일 + 1년 > 유통기한 (1년 미만)*/
                                                IF ROUND((TO_DATE(in_USE_YMD_TO) - TO_DATE(V_SALES_DT)) / 30 ) < 12 THEN
                                                --IF TO_DATE(V_SALES_DT) + 365 > TO_DATE(in_USE_YMD_TO) THEN
                                                        V_PENALTY_QTY := 0; --계산할 반품 수량은 없는 것으로 계산할 반품 수량을 줄여준다 : 1년 미만 제품이 나가서 미안                                                           
                                                                                                                              
                                                        --등록되어 있는 자료가 없다 V_CNT = 0   :해당 매출건의 처리 가 처음이다.
                                                        --남은 수량은 매출 수량에서 반품 수량을 빼준 나머지를 저장한다.    
                                                        V_REMAIN_QTY_1 := V_IN_QTY - V_PENALTY_QTY;                                                                        
                                                                        
                                                        INSERT INTO SALE0207_PENALTY (INPUT_SEQ ,IN_DEAL_NO ,REMAIN_QTY)
                                                        VALUES(SEQ_SALE0207_PENALTY.NEXTVAL ,C1.DEAL_NO ,V_REMAIN_QTY_1)
                                                        ;
                                                        COMMIT;
                                                /*3-2. 유통기간 + 1년 >= 매출일 (1년 미만)*/       
                                                --ELSE  --처리할 내용 없음 다음 매출 건과 비교한다. : 해당 매출은 다른 반품 건과 비교 가능 하다 : 기록하지 않고 넘김                                                                        
                                                END IF;
                                        END IF;
                                                        
                                ELSE    
                                                                                                   
                                        V_REMAIN_QTY_2 := 0; 
                                        SELECT REMAIN_QTY
                                        INTO V_REMAIN_QTY_2
                                        FROM SALE0207_PENALTY
                                        WHERE IN_DEAL_NO = C1.DEAL_NO
                                        ;
                                        
                                         /*2-1. 반품 수량 >= 매출 수량 (기록에 남은 수량)*/
                                        IF V_PENALTY_QTY >= V_REMAIN_QTY_2 THEN
                                                                
                                                /*3-1. 매출일 + 1년 > 유통기한 (1년 미만)*/
                                                IF ROUND((TO_DATE(in_USE_YMD_TO) - TO_DATE(V_SALES_DT)) / 30 ) < 12 THEN  
                                                --IF TO_DATE(V_SALES_DT) + 365 > TO_DATE(in_USE_YMD_TO) THEN
                                                        V_PENALTY_QTY := V_PENALTY_QTY - V_REMAIN_QTY_2; --매출 수량 모두 소진 , 계산할 반품 수량을 줄여준다 : 1년 미만 제품이 나가서 미안                                                             
                                                                        
                                                        UPDATE SALE0207_PENALTY SET REMAIN_QTY = 0
                                                        WHERE IN_DEAL_NO = C1.DEAL_NO 
                                                        ;
                                                        COMMIT;
                                                /*3-2. 유통기간 + 1년 >= 매출일 (1년 이상)*/       
                                                --ELSE  --처리할 내용 없음, 해당 매출은 다른 반품 건과 비교 가능 하다 : 기록하지 않고 넘김                                                                        
                                                END IF;
                                                        
                                        /*2-1. 반품 수량 < 매출 수량*/                                                                        
                                        ELSE
                                                        
                                                /*3-1. 매출일 + 1년 > 유통기한 (1년 미만)*/
                                                IF ROUND((TO_DATE(in_USE_YMD_TO) - TO_DATE(V_SALES_DT)) / 30 ) < 12 THEN
                                                --IF TO_DATE(V_SALES_DT) + 365 > TO_DATE(in_USE_YMD_TO) THEN
                                                       --등록되어 있는 자료가 없다 V_CNT = 0   :해당 매출건의 처리 가 처음이다.
                                                       --남은 수량은 매출 수량에서 반품 수량을 빼준 나머지를 저장한다.    
                                                        V_REMAIN_QTY_2 := V_REMAIN_QTY_2 - V_PENALTY_QTY;      
                                                               
                                                        UPDATE SALE0207_PENALTY SET REMAIN_QTY = V_REMAIN_QTY_2
                                                        WHERE IN_DEAL_NO = C1.DEAL_NO 
                                                        ;      
                                                        COMMIT;                                                  
                                                        
                                                        V_PENALTY_QTY := 0; --계산할 반품 수량은 없는 것으로 계산할 반품 수량을 줄여준다 : 1년 미만 제품이 나가서 미안       
                                                               
                                                /*3-2. 유통기간 + 1년 >= 매출일 (1년 미만)*/       
                                                --ELSE  --처리할 내용 없음 다음 매출 건과 비교한다. : 해당 매출은 다른 반품 건과 비교 가능 하다 : 기록하지 않고 넘김                                                                        
                                                END IF;
                                        END IF;
                                END IF;
                                      
                        END LOOP;                 
                EXCEPTION 
                        WHEN NO_DATA_FOUND THEN
                                V_RETURN := V_RETURN||'NO_DATA_FOUND';
                                RETURN V_RETURN;       
                        WHEN others THEN
                                --DBMS_OUTPUT.PUT_LINE(SQLCODE);
                                --DBMS_OUTPUT.PUT_LINE(SQLERRM);

                                V_RETURN := V_RETURN||'others'||SQLCODE||SQLERRM;
                                RETURN V_RETURN;           
                END;  
                        
               V_RETURN := '확인 '||TO_CHAR(V_PENALTY_QTY);         
                IF V_PENALTY_QTY = 0 THEN
                        V_RETURN := '매출1년미만제품출고 0원';
                        RETURN V_RETURN; 
                END IF;
                
                
                /*1-2. 반품일 + 6개월 < 유통기한 (6개월 미만인 경우)*/
                IF ROUND((TO_DATE(in_USE_YMD_TO) - TO_DATE(V_TURN_BACK_DT)) / 30 ) < 6 THEN
                        IF in_OPTION1 = 'EMP' THEN 
                                V_RETURN := TO_CHAR(ROUND(V_PENALTY_QTY * in_DANGA * 0.1));
                        ELSIF in_OPTION1 = 'TEAM' THEN
                                V_RETURN := TO_CHAR(ROUND(V_PENALTY_QTY * in_DANGA * 0.01));
                        END IF;
                /*1-3. 반품일 + 6개월 >= 유통기한 / 반품일 + 12개월 <= 유통기한 */
                ELSIF ROUND((TO_DATE(in_USE_YMD_TO) - TO_DATE(V_TURN_BACK_DT)) / 30 ) >= 6 AND ROUND((TO_DATE(in_USE_YMD_TO) - TO_DATE(V_TURN_BACK_DT)) / 30 ) <= 12 THEN                
                       IF in_OPTION1 = 'EMP' THEN 
                                V_RETURN := TO_CHAR(ROUND(V_PENALTY_QTY * in_DANGA * 0.05));
                       ELSIF in_OPTION1 = 'TEAM' THEN
                                V_RETURN := TO_CHAR(ROUND(V_PENALTY_QTY * in_DANGA * 0.01));
                       END IF;
                ELSE  --반품일 20160527 인데 유통기한 20150101 제품인 경우도 있다                        
                        IF in_OPTION1 = 'EMP' THEN
                                V_RETURN := TO_CHAR(ROUND(V_PENALTY_QTY * in_DANGA * 0.1));
                        ELSIF in_OPTION1 = 'TEAM' THEN
                                V_RETURN := TO_CHAR(ROUND(V_PENALTY_QTY * in_DANGA * 0.01));
                        END IF;
                END IF;
                                                
        END IF;  
          
        --COMMIT;      
        RETURN V_RETURN; 
        
        --벌금을 계산하기 위한 수량 기록 TABLE을 모두 지운다.
        --DELETE SALE0207_PENALTY;
        
/*        
        BEGIN               
   
        EXCEPTION 
                WHEN NO_DATA_FOUND THEN
                        RETURN V_RETURN;       
                WHEN others THEN
                        RETURN V_RETURN;           
        END;
*/        
    
EXCEPTION
        WHEN NO_DATA_FOUND THEN
        RETURN '';
END;
/
