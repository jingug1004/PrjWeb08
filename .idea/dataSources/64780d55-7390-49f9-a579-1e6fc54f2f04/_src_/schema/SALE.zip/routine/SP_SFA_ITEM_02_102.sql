CREATE PROCEDURE      SP_SFA_ITEM_02_102
(
    in_ITEM_ID           IN  VARCHAR2,  
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   :제품조회상세 
 호출프로그램 :product.Productinfo
          2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    ITEM_ID_NULL         EXCEPTION;
BEGIN
    
   --insert into SFA_SP_CALLED_HIST values ('SP_SFA_ITEM_02_102','4',sysdate,'in_ITEM_ID:'||in_ITEM_ID);
   -- commit;
    
    IF in_ITEM_ID IS NULL THEN
        RAISE ITEM_ID_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.CMITEMM  a
          ,SALE.SFA_OFFICE_ITEMDOC  b
     WHERE a.itemcode  = b.item_code(+)
       AND a.itemcode  = in_ITEM_ID
     ;
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT a.itemcode             AS out_ITEM_ID        -- 제품코드
             , a.itemname             AS out_ITEM_NM        -- 제품명
             , a.unitqty              AS out_STANDARD       -- 규격
             , a.unit                 AS out_UNIT           -- 단위
             , a.drugprc              AS out_DANGA          -- 단가(출고단가)  
             , NULL                   AS out_STOCK          -- 재고
             , DECODE(a.productdiv, '04', 'Y', 'N')    AS out_CHUL_YN    -- 출하중지(Y,N)
             , DECODE(a.productdiv, '04', '출하중지', '출하가능')  AS out_CHUL_NM   -- 출하중지여부명
             , NULL                   AS out_STOCK_GUBUN    -- 재고구분
             , a.remark               AS out_VIEW_TXT       -- 모양
             , B.ITEM_POINT           AS out_ITEM_POINT     -- 특장점
             , B.ITEM_EFFECT          AS out_EFFECT         -- 효능효과(제품상세설명)
             , B.ITEM_USE_DOES        AS out_ITEM_USE_DOES  -- 용량용법
             , B.ITEM_ATTENTION       AS out_ITEM_ATTENTION -- 주의사항
             , B.ITEM_PHOTO           AS out_PHOTO          -- 이미지     
             , B.ITEM_1SPEECH         AS out_ITEM_1SPEECH   -- 1분 스피치
             , B.ITEM_3SPEECH         AS out_ITEM_3SPEECH   -- 3분 스피치
             , a.mplantcode           AS out_SAUPJANG_CD    --관리사업장  1001-도매지점 1002-도매향정 2001-하길마약 2002-하길향정        
          FROM ORAGMP.CMITEMM    a
              ,SALE.SFA_OFFICE_ITEMDOC  b
         WHERE a.itemcode  = b.item_code(+)
           AND a.itemcode  = in_ITEM_ID
         ORDER BY a.itemname;
    END IF;
    
EXCEPTION
WHEN ITEM_ID_NULL THEN
   out_CODE := '101';
   out_MSG  := '제품코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
