CREATE PROCEDURE SPSLBASE0022P(
-- ---------------------------------------------------------------
-- 프로시저명       : SPSLBASE0022P
-- 작 성 자         : 김만수
-- 작성일자         : 2017-08-10
-- ---------------------------------------------------------------
-- 프로시저 설명    : 품절 품목을 등록, 삭제하는 프로시저이다.
-- ---------------------------------------------------------------
        p_div		     IN	 VARCHAR2 := '',         
        p_plantcode      IN	 VARCHAR2 := '', 
        p_yearmonth      IN	 VARCHAR2 := '', 
        p_empcode        IN	 VARCHAR2 := '',
        p_empname        IN	 VARCHAR2 := '', 
        p_ecustcode      IN	 VARCHAR2 := '', 
        p_ecustname      IN	 VARCHAR2 := '', 
        p_mhdiv          IN	 VARCHAR2 := '',
        p_dcustcode      IN	 VARCHAR2 := '', 
        p_dcustname      IN	 VARCHAR2 := '', 
        p_businessno     IN	 VARCHAR2 := '', 
        p_custname       IN	 VARCHAR2 := '', 
        p_barcode        IN	 VARCHAR2 := '',
        p_seq            INT := 0,
        p_processdiv     IN	 VARCHAR2 := '',
        p_datadiv        IN	 VARCHAR2 := '',
        p_selectyn       IN	 VARCHAR2 := '',
        
        p_userid	     IN	 VARCHAR2 := '',
        p_reasondiv  	 IN	 VARCHAR2 := '',
        p_reasontext	 IN	 VARCHAR2 := '',
        IO_CURSOR			 OUT TYPES.DataSet,
        MESSAGE 			 OUT VARCHAR2
)
AS 
BEGIN
    MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);
    
    IF(p_div = 'S')    THEN
    
        OPEN IO_CURSOR FOR
        
            SELECT    A.PLANTCODE  ,   --사업장코드
                      A.DATADIV    ,   --자료구분(거점:10,도도매:20)
                      A.YEARMONTH  ,   --실적년월
                      A.SEQ        ,   --자료순번
                      A.EMPCODE    ,   --사원코드
                      A.EMPNAME    ,   --담당자명
                      A.ECUSTCODE  ,   --원내코드(처방처)
                      A.ECUSTNAME  ,   --처방처명
                      A.MHDIV      ,   --M/H
                      A.SALEDATE   ,   --매출일자
                      A.DCUSTCODE  ,   --거래코드(도매처)
                      A.DCUSTNAME  ,   --거래선명(도매처)
                      A.BUSINESSNO ,   --사업자번호
                      A.CUSTNAME   ,   --매출처명
                      A.ITEMCODE   ,   --제품코드
                      A.BARCODE    ,   --표준(바)코드
                      A.ITEMNAME   ,   --제품명
                      A.ITEMUNIT   ,   --규격
                      A.SALQTY     ,   --수량
                      A.DRUGPRI    ,   --단가
                      A.SALAMT     ,   --금액
                      A.SLJAMT     ,   --실적가
                      A.POST       ,   --우편번호
                      A.ADDR       ,   --주소
                      A.SIDOADDR   ,   --시도명
                      A.GNGUADDR   ,   --시군구명
                      A.PROCESSDIV ,   --자료흐름구분(영업사원자료조정가능:P,작업마감:E,작업취소:C,생성초기값:S)
                      A.FIXYN      ,   --자료완료구분(초기값:N,작업완료:Y,작업취소:C)
                      A.INSERTDT   ,   --등록일시
                      A.IEMPCODE   ,   --등록자사번
                      A.UPDATEDT   ,   --변경일시
                      A.UEMPCODE       --변경자사번
             FROM SLDOMAEORG A
             WHERE A.DATADIV    = '10'
               AND A.PROCESSDIV = 'E'
               AND NVL(A.EMPCODE,'x') = 'x'
               AND A.YEARMONTH  = p_yearmonth
               AND NOT EXISTS (SELECT 'X'                            --영업담당자가 선정한 자료는 담당자 선정 작업 시 미 선택자료에 안나오게 처리
                                FROM SLDOMAECHG X
                               WHERE X.DATADIV   = A.DATADIV
                                 AND X.YEARMONTH = A.YEARMONTH
                                 AND X.SEQ       = A.SEQ)
            ORDER BY A.SEQ ;
    
    ELSIF(p_div = 'S2') THEN
        
        OPEN IO_CURSOR FOR
        
            SELECT    A.PLANTCODE  ,      -- 사업장코드
                      A.YEARMONTH  ,      -- 실적년월
                      A.SEQ        ,      -- 자료순번
                      A.EMPCODE    ,      -- 사원코드
                      D.EMPNAME    ,      -- 담당자명
                      A.ECUSTCODE  ,      -- 원내코드(처방처)
                      A.ECUSTNAME  ,      -- 처방처명
                      A.MHDIV      ,      -- M/H
                      C.SALEDATE   ,      -- 매출일자
                      C.DCUSTCODE  ,      -- 거래코드(도매처)
                      C.DCUSTNAME  ,      -- 거래선명(도매처)
                      C.BUSINESSNO ,      -- 사업자번호
                      C.CUSTNAME   ,      -- 매출처명
                      A.BARCODE    ,      -- 표준(바)코드
                      C.ITEMNAME   ,      -- 제품명
                      C.ITEMUNIT   ,      -- 규격
                      C.SALQTY     ,      -- 수량
                      C.DRUGPRI    ,      -- 단가
                      C.SALAMT     ,      -- 금액
                      C.SLJAMT     ,      -- 실적가
                      C.POST       ,      -- 우편번호
                      C.ADDR       ,      -- 주소
                      C.SIDOADDR   ,      -- 시도명
                      C.GNGUADDR   ,      -- 시군구명
                      C.PROCESSDIV ,      -- 자료흐름구분(영업사원자료조정가능:P,작업마감:E,작업취소:C,생성초기값:S)
                      C.INSERTDT   ,      -- 등록일시
                      C.IEMPCODE   ,      -- 등록자사번
                      C.UPDATEDT   ,      -- 변경일시
                      C.UEMPCODE   ,      -- 변경자사번
                      B.CHG_COUNT  ,      -- 선택건수
                      (CASE WHEN B.CHG_COUNT = 1
                            THEN 'Y'
                            ELSE A.SELECTYN
                       END) AS SELECTYN   -- 선택여부(Y/N)
             FROM SLDOMAECHG A,
                ( SELECT YEARMONTH,
                         SEQ      ,
                         DATADIV  ,
                         COUNT(*) AS CHG_COUNT 
                    FROM SLDOMAECHG
                   WHERE YEARMONTH = p_yearmonth
                GROUP BY YEARMONTH, SEQ, DATADIV
                ) B,
                  SLDOMAEORG C,
                  CMEMPM     D
             WHERE A.DATADIV   = '10'
               AND A.DATADIV   = B.DATADIV
               AND A.YEARMONTH = B.YEARMONTH
               AND A.SEQ       = B.SEQ
               AND A.DATADIV   = C.DATADIV
               AND A.YEARMONTH = C.YEARMONTH
               AND A.SEQ       = C.SEQ
               AND 'E'         = C.PROCESSDIV
               AND A.YEARMONTH = p_yearmonth
               AND A.EMPCODE   = D.EMPCODE
           ORDER BY A.SEQ;
        
    ELSIF(p_div = 'I')    THEN
        
        UPDATE SLDOMAEORG
           SET EMPCODE   = p_empcode  ,
               EMPNAME   = p_empname  ,
               ECUSTCODE = p_ecustcode,
               ECUSTNAME = p_ecustname,
               MHDIV     = p_mhdiv
        WHERE DATADIV    = '10'
          AND PROCESSDIV = 'E'
          AND YEARMONTH  = p_yearmonth
          AND SEQ        = p_seq ;
          
        IF ( TO_CHAR(SQL%ROWCOUNT) = '0' ) THEN 
            
            MESSAGE :=  '[Error] Invalid Row Update' || CHR(13) || CHR(13) ||
                        '작업 중 오류가 발생하였습니다.' || CHR(13) || 
                        '전산담당자에게 문의 하세요!!' ;
        ELSE
        
            MESSAGE := '자료가 저장되었습니다.'; 
        
        END IF;
        
    ELSIF(p_div = 'I2')    THEN   
        
        UPDATE SLDOMAECHG
           SET SELECTYN   = p_selectyn
         WHERE DATADIV    = '10'
--           AND PROCESSDIV = 'E'
           AND YEARMONTH  = p_yearmonth
           AND SEQ        = p_seq
           AND EMPCODE    = p_empcode
           AND ECUSTCODE  = p_ecustcode
           AND DCUSTCODE  = p_dcustcode
           AND BUSINESSNO = p_businessno
           AND BARCODE    = p_barcode ;
        
        IF ( TO_CHAR(SQL%ROWCOUNT) = '0' ) THEN
            
            MESSAGE :=  '[Error] Invalid Row Update' || CHR(13) || CHR(13) ||
                        '작업 중 오류가 발생하였습니다.' || CHR(13) || 
                        '전산담당자에게 문의 하세요!!' ;
        ELSE
        
            MESSAGE := '자료가 저장되었습니다.'; 
        
        END IF;
          
    END IF;
    
    IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END SPSLBASE0022P;
/
