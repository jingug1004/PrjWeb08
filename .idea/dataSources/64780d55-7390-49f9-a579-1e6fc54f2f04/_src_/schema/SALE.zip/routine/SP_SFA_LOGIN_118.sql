CREATE PROCEDURE      SP_SFA_LOGIN_118
(
    in_SAWON_ID       IN VARCHAR2,   -- 로그인사번(인사사번으로로그인한다)
    in_SAWON_PSWD IN VARCHAR2,   -- 로그인비밀변경
    in_HP                   IN VARCHAR2,   -- 핸드폰 번호
    in_GUBUN             IN VARCHAR2,   -- A:안드로이드, W:웹
    in_COMM_DT        IN VARCHAR2,   -- 공통코드 변경유무 기준일자시간(14자리, 24시간)
    in_ANDROID_ID_1  IN VARCHAR2,  -- 디바이스 ID 
    in_ANDROID_ID_2  IN VARCHAR2,  -- 빌드 ID
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 안드로이드폰과 웹 로그인
 호출프로그램 :  120 으로 대체됨
  ---------------------------------------------------------------------------
 전산실은 모든 프로그램의 로그인은 인사사번으로 하기로 하였다.
 따라서 로그인은 인사사번으로 하고 권한이 맞으면 영업사번으로 업무를 처리한다.
 수정기록    :2013.02.16 KTA - 카드리더기없이수기카드사용가능여부컬럼 추가 
              2013.03.04 KTA - 위치속이는프로그램 노트에 설치되어 있는지 관련 수정   
              2013.07.05 CHOE - 고유ID값을 저장하고 저장된 값이 있으면 비교해 다른사람이 로그인 불가하다록 한다.
              2013.07.19 KTA - 고유ID값체크시 영업사원이아니면 다른ID 로그인 가능하도록 한다.  
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
    v_retir_dt           VARCHAR2(8);
    v_engag_div          VARCHAR2(5);
    v_sawon_pswd         VARCHAR2(20);
    v_hp                 VARCHAR2(12);
    
    v_change_cnt         NUMBER;
    v_change_yn         CHAR(1);
    v_notice_cnt         NUMBER;
    v_time_out           VARCHAR2(50);
    v_version             VARCHAR2(10);
    v_sawon_id          VARCHAR2(10); 
        
    v_msg_no              NUMBER;
    v_seq                    NUMBER;
    v_message            VARCHAR2(4000);
    
    v_bt_id                   VARCHAR2(30);  --BT아이디     
    v_bt_nm                 VARCHAR2(30); --BT기기명
    v_bt_free_yn           VARCHAR2(1); --카드리더기없이수금가능여부(Y-가능,N-불가) 사원테이블에 있음
    v_fakegpsapp_nm       VARCHAR2(30); --위치속이는앱이름을 클라이언트에 보내서 찾게 만든다
    
    v_android_id_1    VARCHAR2(30);
    v_android_id_2    VARCHAR2(30); 
    v_android_id_deny VARCHAR2(1); 

BEGIN 

    out_CODE := 0;
    out_MSG := '로그인이 정상 처리되었습니다.';
    
    --버전체크
    SELECT MAX(ver) INTO v_version FROM SFA_SYS_VERSION;
                  
    --사번오류체크          
    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
       out_CODE := 101;
       out_MSG := '사원ID를 입력하십시오.';  
       RETURN;
    END IF;
    
    --비번오류체크
    IF in_SAWON_PSWD IS NULL OR TRIM(in_SAWON_PSWD) = '' THEN
       out_CODE := 102;
       out_MSG := '패스워드를 입력하십시오.'; 
       RETURN;
    END IF;
    
    --로그인구분( A:안드로이드, W:웹) 오류체크
    IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
       out_CODE := 103;
       out_MSG := '로그인구분이 누락되었습니다(관리자에 연락바랍니다.)'; 
       RETURN;
    END IF;

    --로그인구분( A:안드로이드, W:웹) A 이면 공통코드테이블의 변경유무 체크
    IF in_GUBUN = 'A'  THEN 
        IF in_COMM_DT IS NULL THEN   -- 변경기준일자가 없는 경우에는 무조건 공통코드를 받는다.
            v_change_yn := 'Y';
        ELSE
            SELECT COUNT(*)
              INTO v_change_cnt
              FROM SALE0001
             WHERE TO_CHAR(INPUT_YMD, 'YYYYMMDDHH24MISS') >= in_COMM_DT;
             
            IF v_change_cnt > 0 OR in_COMM_DT IS NULL THEN   -- 공통코드 변경사항이 있는 경우
                v_change_yn := 'Y';
            ELSE                       -- 없는 경우
                v_change_yn := 'N'; 
            END IF;
        END IF;
    END IF;
            
    --입력된 로그인 사번은  인사사번이어야 하므로 체크    
    SELECT COUNT(*) INTO v_num FROM hanahr.hr_hc_empbas_0 WHERE EMP_NO = in_SAWON_ID;
    IF (v_num = 0) THEN
        out_CODE := 104;
        out_MSG := '로그인 정보가 존재하지 않습니다.(인사사번을 입력하셔야 합니다)';    
        RETURN;
    END IF;
    
    --입력받은 인사사번이 hanaerp시스템  사용자정보테이블에 등록되어 있는지 체크
    SELECT COUNT(*) INTO v_num FROM hanacomm.co_us_member_0 WHERE EMP_NO = in_SAWON_ID ;
    IF (v_num = 0) THEN
        out_CODE := 105;
        out_MSG := '로그인 정보가 존재하지 않습니다.(관리자에게 문의하십시오)';     
        RETURN;
    END IF;
 
    --입력받은 인사사번이 사용가능한지 체크 
    SELECT COUNT(*) INTO v_num FROM hanacomm.co_us_member_0 WHERE EMP_NO = in_SAWON_ID and USE_YN = 'Y';
    IF (v_num = 0) THEN
        out_CODE := 106;
        out_MSG := '입력한 사번은 사용중지중입니다.';     
        RETURN;
    END IF;

    --비밀번호체크
    SELECT PASS_WORD INTO v_sawon_pswd FROM hanacomm.co_us_member_0 WHERE EMP_NO = in_SAWON_ID and USE_YN = 'Y';
    IF in_SAWON_PSWD <> v_sawon_pswd  THEN
        out_CODE := 107;
        out_MSG := '비밀번호가 틀립니다.';     
        RETURN;
    END IF;
 

    --권한통과하면 인사사번을 영업사번으로 바꿔서 다음처리 ------------------------------
    
    --인사사번으로 영업사번 가져오기       
    -- 영업사번으로 건수가 1개이상발생하면 관리부에서 아직 처리하지 않은 것이 있음.에러처리 
    SELECT COUNT(*) INTO v_num from sale0007 where insa_sawon_id = in_SAWON_ID and GUBUN='Y';
    IF (v_num = 0) THEN
        out_CODE := 108;     
        out_MSG := '영업사원과 인사사번이 연결되어 있지 않습니다.관리부에 문의바랍니다.';
        RETURN;
    ELSIF (v_num = 0) THEN        
        out_CODE := 109;
        out_MSG := '입력한 사번으로 자료가 1건이상발생합니다.관리부에 문의바랍니다.';
        RETURN;
    END IF; 
    
    --입력받은 인사사번으로 영업사번 가져온다.
    select sawon_id into v_sawon_id from sale0007 where insa_sawon_id = in_SAWON_ID and GUBUN='Y'; 
    --여기서 부터는 영업사번으로 모든것을 처리한다. 

    --사원정보채크 퇴직,휴직체크            
    SELECT C.ENGAG_DIV, TRIM(C.RETIR_DT), A.SAWON_PSWD, A.HP,A.BT_ID,A.BT_NM,A.BT_FREE_YN 
      INTO v_engag_div, v_retir_dt, v_sawon_pswd, v_hp,v_bt_id,v_bt_nm,v_bt_free_yn
      FROM SALE0007 A  INNER JOIN hanahr.hr_hc_empbas_0 C
                           ON A.INSA_SAWON_ID = C.EMP_NO
                          AND A.SAWON_ID     = v_sawon_id;
                               
    IF v_engag_div <> '70010' THEN  -- 70010:재직, 70020:퇴직, 70030:휴직
       out_CODE := 108;
       out_MSG  := CASE WHEN v_engag_div = '70020' THEN '퇴사한 직원입니다.' ELSE '휴직한 직원입니다.' END;   
       RETURN;
    END IF;



        /* -----------------------------------------------------------------------------------------
                CHOE 20130705 ANDROID ID or BUILD ID를 전달받아 고유 값 인지 TEST 한다.
                in_ANDROID_ID_1 : getDeviceId() 
                in_ANDROID_ID_2 : bd.SERIAL;   이 값을 고유값으로 일단 설정한다.
                
                조건1. 위에서 사원 DATA의 적합성 TEST는 통과한 상태로 생각한다. (사원 유무 재직 등등)
                조건2. ANDROID_ID_1 의 값은 비어 있다면 넣어만 준다. : 고유값인지만 확인
                조건3. ANDROID_ID_2 의 값이 없다면 UPDATE한다. v_android_id_deny Y 처리 로그인 통과한다.
                           ANDROID_ID_2 의 값이 있다면 비교 후 적합하면 v_android_id_deny Y 처리 아니면 N 처리를 한다.
         -----------------------------------------------------------------------------------------*/
        v_android_id_1 := '';  
        v_android_id_2 := '';
        SELECT TRIM(ANDROID_ID_1), TRIM(ANDROID_ID_2) 
        INTO v_android_id_1,  v_android_id_2
        FROM SALE0007 
        WHERE SAWON_ID = v_sawon_id;
           
        IF v_android_id_1 IS NULL THEN  
           UPDATE SALE0007 SET ANDROID_ID_1 = in_ANDROID_ID_1 WHERE SAWON_ID = v_sawon_id;
        END IF;      
        
        IF v_android_id_2 IS NULL THEN  
           UPDATE SALE0007 SET ANDROID_ID_2 = in_ANDROID_ID_2 WHERE SAWON_ID = v_sawon_id;
           v_android_id_deny := 'Y';  --로그인 통과값을 얻음
        ELSE
            IF v_android_id_2 = in_ANDROID_ID_2 THEN
               v_android_id_deny := 'Y';  --로그인 통과값을 얻음
            ELSE      
               --전산팀과 박민호대리 만 빼고 모두 통제               
               IF NOT (in_ANDROID_ID_2 = '41071e0422666fe5' OR in_ANDROID_ID_2 = '4107492c7b678fff' OR in_ANDROID_ID_2 = '9b833cf4' OR in_ANDROID_ID_2 = '4107d9175b1b9f03' OR in_ANDROID_ID_2 = '410749196f1f9f5f' or in_ANDROID_ID_2 = '41075b0eb1818f85') THEN
                   v_android_id_deny := 'N';   --로그인 불가 판정
                   out_CODE := 111;
                   out_MSG  := 'ID ['||SUBSTR(in_ANDROID_ID_2,1,4)||'****'||SUBSTR(in_ANDROID_ID_2,9,4) || '****] 접근 통제 상황 : 본사 기획실로 연락 바랍니다.';   
                   RETURN;                        
               END IF;
            END IF;
        END IF;



    --전산팀긴급공지 처리
    BEGIN
        SELECT msg_no,message INTO v_msg_no,v_message FROM SFA_SYS_HOTMSG A 
         WHERE NOT EXISTS (SELECT 'X' FROM SFA_SYS_HOTMSGREADERS WHERE MSG_NO = A.MSG_NO  AND SAWON_ID = in_SAWON_ID)
           AND CURRENT_MSG_YN = 'Y';
    EXCEPTION WHEN NO_DATA_FOUND THEN
       DBMS_OUTPUT.PUT_LINE('111v_msg_no  '||to_char(v_msg_no)||'message : '||v_message);
    END;   
    
    IF v_msg_no > 0 THEN           
       DBMS_OUTPUT.PUT_LINE('111v_msg_no  '||to_char(v_msg_no)||'message : '||v_message);
       SELECT max(seq) + 1 INTO v_seq FROM SFA_SYS_HOTMSGREADERS WHERE msg_no = v_msg_no;         
       INSERT INTO SFA_SYS_HOTMSGREADERS VALUES(v_msg_no,nvl(v_seq,1),in_SAWON_ID,sysdate);
       
    ELSE   
       DBMS_OUTPUT.PUT_LINE('222v_msg_no  '||to_char(v_msg_no)||'message : '||v_message);
    END IF;
     

    -- 공지사항(안읽은 공지사항) 건수 넘겨주기
    -- 공지사항은 인사사번기준으로 데이터가 생성되어 있으므로 인사사번으로 검색해야 함.                 
    select count(*)
      into v_notice_cnt
      from (
            select A.NTCNO                               AS out_BOARD_ID 
                  ,A.NTC_TITL                            AS out_TITLE
                  ,FNC_LONG2CHAR(A.NTCNO)                AS out_DISCRIPTION
                  ,SUBSTR(A.NTC_STR_DTM, 1,8)            AS out_START_DATE
                  ,(select decode(min(inq_uno),null,'New','읽음') 
                      from hanagw.TGWNTCFM 
                     where ntcno = a.ntcno and inq_uno = (select uno from hanagw.tcmusr where loin_usid = in_SAWON_ID)) as read_yn
              from hanagw.TGWNT_M a  --공지사항 MASTER
                  ,hanagw.TGWNTTGT b  --공지사항 공지대상
             where a.ntcno = b.ntcno
               and b.tgt_orguno in (  select uno from hanagw.tcmusr where loin_usid = in_SAWON_ID
                                      union
                                      select orgno
                                        from hanagw.tcmorg  --그룹웨어부서정
                                     connect by  orgno = prior supr_orgno
                                       start with orgno = ( select orgno
                                                            from hanagw.tcmorg_r --그룹웨어유저와부서연결정보
                                                           where uno = (select uno from hanagw.tcmusr where loin_usid = in_SAWON_ID) -- 그룹웨어유정보 
                                                          )
                                     )
                and A.NTC_STR_DTM >= '20120901000000' --과거공지는 보이지 않도록.
               order by A.NTC_STR_DTM desc
            )
      where read_yn = 'New'; 
          
    -- 타임아웃. 분단위/정수형 스트링 구현
    SELECT TRIM(CODE1_NM) INTO v_time_out FROM SALE0001
     WHERE CODE_GB = '0067'  -- 타임아웃 설정 그룹코드 입력
       AND CODE1   = '01'   -- 타임아웃 설정 항목코드 입력
       AND ROWNUM  = 1;               
    IF v_time_out IS NULL THEN
        v_time_out := '10';     -- NULL이면 10분 설정
    END IF;

    --위치속이는앱이름을 찾도록 공통테이블에서 찾음
    SELECT TRIM(CODE1_NM) INTO v_fakegpsapp_nm FROM SALE0001
     WHERE CODE_GB = '0069'  
       AND CODE1   = '01'  
       AND ROWNUM  = 1; 
           
    out_COUNT := 1;         
    -- sql문 필요함
    OPEN out_RESULT FOR
    SELECT A.SAWON_ID                     AS out_SAWON_ID   -- 사원ID
          ,A.SAWON_NM                     AS out_SAWON_NM   -- 사원명
          ,A.SAWON_PSWD                   AS out_SAWON_PSWD -- 패스워드
          ,A.DEPT_CD                      AS out_DEPT_CD    -- 부서코드
          ,B.DEPT_NM                      AS out_DEPT_NM    -- 부서명
          ,decode(a.pda_auth,'A','27000',C.ASSGN_CD ) AS out_ASSIGN_CD -- 직책코드(27020:관리이사, 27030:팀장, 27040:팀원)참고: 27000은 sfa상에서 전체권한의 의미를 부여함.
          ,decode(a.pda_auth,'A','Admin',D.COMN_NM  ) AS out_ASSIGN_NM -- 직책코드명(27020:관리이사, 27030:팀장, 27040:팀원)
          ,v_change_yn                    AS out_CHANGE_YN  -- 공통코드 변경여부(Y이면 변경사항이 있음)
          ,v_notice_cnt                   AS out_NOTICE_CNT -- 안읽은 공지사항 건수
          ,v_time_out                     AS out_TIME_OUT   -- 타임아웃. 분단위/정수형 스트링 구현
          ,v_version                      AS out_VERSION    -- mobilesfa버전
          ,v_message                      AS out_MESSAGE    -- 긴급공지 
          ,A.PDA_ID                       AS out_PDA_ID     -- PDA소유번호
          ,A.PART_GB                      AS out_PART_GB    -- 파트구분(01-도매,02-종병,03-세미,04-로컬,05-도매로컬,06-O/A,07-제주지점  
          ,v_bt_id                        AS out_BT_ID      -- 카드리더기 BT아이디
          ,v_bt_nm                        AS out_BT_NM      -- 카드리더기 BT기기명
          ,E.DEPT_KO_NM                   AS out_INSA_DEPT_NM --인사부서명
          ,v_bt_free_yn                   AS out_BT_FREE_YN   --카드리더기없이수금가능여부(Y-가능,N-불가) 사원마다 지정할 수 있다 
          ,v_fakegpsapp_nm                AS out_FAKEGPSAPP_NM   -- 위치속이는앱이름
          ,TO_CHAR(SYSDATE,'YYYYMMDD')    AS out_SERVER_YMD --서버일자    
          ,v_android_id_deny AS out_ANDROID_ID_DENY  -- 안드로이드 고유ID 비교       
      FROM SALE0007 A 
          ,SALE0008 B               
          ,HR_HC_EMPBAS_0 C  
          ,HR_CO_COMMON_0 D
          ,HR_CO_DEPART_0 E  
     WHERE A.DEPT_CD       = B.DEPT_CD(+)
       AND A.INSA_SAWON_ID = C.EMP_NO(+)
       AND C.ASSGN_CD      = D.COMN_CD
       AND C.DEPT_CD       = E.DEPT_CD
       AND A.SAWON_ID      = v_sawon_id
     ; 

EXCEPTION 
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
   DBMS_OUTPUT.PUT_LINE('out_CODE  '||to_char(out_CODE)||'out_MSG : '||out_MSG);
END;

/
