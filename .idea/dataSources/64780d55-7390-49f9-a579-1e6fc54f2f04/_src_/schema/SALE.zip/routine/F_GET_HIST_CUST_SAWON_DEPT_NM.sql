CREATE function      F_GET_HIST_CUST_SAWON_DEPT_NM
        ( A_CUST_ID      VARCHAR2,  
          A_YMD          DATE       
        )
   RETURN VARCHAR2
AS
   user_err       exception   ;
   A_SYMD         VARCHAR2(8);
   
   V_TRAN_YMD_CD  VARCHAR2(14);
   V_TRAN_YMD_CD2  VARCHAR2(14); 
   V_SYMD         VARCHAR2(8);
   V_SYMD2         VARCHAR2(8);
   V_CUST_NM      VARCHAR2(50);
   V_SAWON_ID     VARCHAR2(7);
   V_SAWON_NM     VARCHAR2(20);
   n_rtn_value    VARCHAR2(250);
   v_curr_error   VARCHAR2(250);

/*----------------------------------------------------------------
 개요  :거래처코드 와 일자를 받아서 해당시점의 거래처명_ 사원명_부서명 리턴
 작성일:2014.01.20
 작성자:김태안 
----------------------------------------------------------------*/
BEGIN
       A_SYMD := TO_CHAR(A_YMD, 'YYYYMMDD');  

      -- 거래처의 담당사원을 찾는다. -----------------------------------------------------------
       SELECT MAX(APPL_DATE) --적용일자: 담당사원변경일자기준 
         INTO V_SYMD
         FROM SALE0003H
        WHERE CUST_ID  =  A_CUST_ID AND APPL_DATE <= A_SYMD; --넘어온 날짜

       SELECT MAX(TRAN_YMD_CD) --변경일자
         INTO V_TRAN_YMD_CD
         FROM SALE0003H
        WHERE CUST_ID  = A_CUST_ID AND APPL_DATE = V_SYMD; --적용일자: 담당사원변경일자기준 
          
       v_curr_error := A_CUST_ID||':'||A_SYMD||':'||V_TRAN_YMD_CD||':'||V_SYMD;
       IF (V_SYMD IS NULL) OR (V_TRAN_YMD_CD IS NULL)  THEN
          RETURN '00'; --미지정거래구분
       END IF;
      
        SELECT CUST_NM,SAWON_ID,(select z.sawon_nm from sale0007 z where z.sawon_id = A.SAWON_ID) 
          INTO V_CUST_NM,V_SAWON_ID,V_SAWON_NM
          FROM SALE0003H A
         WHERE A.CUST_ID     = A_CUST_ID
           AND A.TRAN_YMD_CD = V_TRAN_YMD_CD
           AND A.APPL_DATE   = V_SYMD;

      --사원의 부서이력을 찾는다.--------------------------------------------------------------
      SELECT MAX(APPL_DATE) --적용일자 
         INTO V_SYMD2
         FROM SALE0007H
        WHERE SAWON_ID   =  V_SAWON_ID AND APPL_DATE <= A_SYMD; --넘어온 날짜

       SELECT MAX(TRAN_YMD_CD) --사원변경일자 
         INTO V_TRAN_YMD_CD2
         FROM SALE0007H
        WHERE SAWON_ID  = V_SAWON_ID AND APPL_DATE = V_SYMD2;  --적용일자
          
       v_curr_error := V_SAWON_ID||':'||A_SYMD||':'||V_TRAN_YMD_CD2||':'||V_SYMD2;
       IF (V_SYMD2 IS NULL) OR (V_TRAN_YMD_CD2 IS NULL)  THEN
          RETURN '00'; --미지정거래구분
       END IF;
      
        SELECT V_CUST_NM||'-'||V_SAWON_NM||'-'||(select z.dept_nm from sale0008 z where z.dept_cd = A.DEPT_CD)
          INTO n_rtn_value
          FROM SALE0007H A
         WHERE A.SAWON_ID    = V_SAWON_ID
           AND A.TRAN_YMD_CD = V_TRAN_YMD_CD2
           AND A.APPL_DATE   = V_SYMD2;  
           
           
        RETURN n_rtn_value;

        EXCEPTION WHEN user_err THEN
                       RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
                  WHEN OTHERS THEN
                       RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;
/
