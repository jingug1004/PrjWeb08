CREATE PROCEDURE      SP_Z_VISIT_02
(
    in_PARAM             IN  VARCHAR2,
    in_SAWON_ID          IN  VARCHAR2,     -- 담당자 사번
    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS    
 /*---------------------------------------------------------------------------
 프로그램명  : hira거래처조회
 호출프로그램 : spVisitPlanCustomerList - 방문계획화면의 hira거래처리스트
          bizVisitPlan             -방문계획등록 화면의 조회   
 수정기록    
     2014.12.18 - KTA -팀장과 팀원들 자료가 너무 많아서 뿌리지 못하면서 SFA죽는 문제 발생하여 팀장도 본인거래처만 조회하도록 함
     2015.06.08 KTA  - 임시팀장 직책코드 추가관련 수정                      
     2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_insa_sawon_id     VARCHAR2(7);
    v_query_deptcode     VARCHAR2(4);
    v_assgn_cd          VARCHAR2(5);
    v_deptcode          VARCHAR2(5);
    
BEGIN
                
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    select classdiv,deptcode into v_assgn_cd,v_deptcode from ORAGMP.CMEMPM  where empcode = in_SAWON_ID;
    
    v_query_deptcode := v_deptcode;              
    -- 조회부서:: 로그인 직책에따라 상위부서를 찾거나 본인부서를 찾는다.
    if v_assgn_cd = '27010' or v_assgn_cd = '27020' or v_assgn_cd = '27025' or v_assgn_cd = '27018' or v_assgn_cd = '27026' then   --본부장관리이사,, 총괄지점장 부본부장 선임지점장
       select deptcode 
         into v_query_deptcode 
         from ORAGMP.CMDEPTM 
        where useyn = 'Y' and level = 2 connect by deptcode = prior predeptcode start with plantcode = '1000' and deptcode = v_deptcode;
    end if;

    SELECT count(*)
      INTO v_num
      FROM (SELECT *
              FROM ORAGMP.CMHIRAM a
             WHERE a.ordempcode = in_SAWON_ID OR a.areaempcode = in_SAWON_ID
            UNION
            SELECT *
              FROM ORAGMP.CMHIRAM a
             WHERE hiracode in ('0000005') 
         );
    
-- insert into SFA_SP_CALLED_HIST values ('SP_SFA_VISIT_02','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||' / v_num:'||to_char(v_num));
     
    out_COUNT := v_num;
    
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
     
        
        OPEN out_RESULT FOR
        SELECT *
          FROM (
                SELECT a.hiracode               AS out_SFA_SALES_NO,           -- 거래처코드 NUMBER
                       a.hiraname               AS out_SFA_SALES_NM,           -- 거래처명
                       a.hiracode               AS out_SFA_SALES_SEQ,          -- 거래처 Key
                       F_Z_SFA_CODE_NM('CUST_STAT_GB',decode(in_SAWON_ID,a.ordempcode,'01','02'))   AS out_CUST_STAT_GB
                  FROM ORAGMP.CMHIRAM a
                 WHERE ordempcode = in_SAWON_ID OR areaempcode = in_SAWON_ID 
                UNION
                SELECT a.hiracode               AS out_SFA_SALES_NO,           -- 거래처코드 NUMBER
                       a.hiraname               AS out_SFA_SALES_NM,           -- 거래처명
                       a.hiracode               AS out_SFA_SALES_SEQ,          -- 거래처 Key
                       a.hiracode                 AS out_CUST_STAT_GB
                  FROM ORAGMP.CMHIRAM a
                 WHERE hiracode in ('0000005') 
               ) a
         ORDER BY out_CUST_STAT_GB,a.out_SFA_SALES_NM  
         ;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
