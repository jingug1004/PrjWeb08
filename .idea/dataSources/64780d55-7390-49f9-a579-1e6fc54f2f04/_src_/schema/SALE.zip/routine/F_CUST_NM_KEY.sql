CREATE FUNCTION      F_CUST_NM_KEY  -- 거래처명 가져오기
(
    in_GUBUN    IN  VARCHAR2
,   in_CUST_KEY  IN  NUMBER
) 
RETURN VARCHAR2 IS

    v_cust_nm   VARCHAR2(75);
    
BEGIN
    IF in_GUBUN = 'CODE' THEN 
        SELECT SFA_SALES_NO
          INTO v_cust_nm
          FROM SFA_SALES_CODE
         WHERE SFA_SALES_SEQ    = in_CUST_KEY;
    
    ELSIF in_GUBUN = 'KEYCODE' THEN
        SELECT SFA_SALES_SEQ
          INTO v_cust_nm
          FROM SFA_SALES_CODE
         WHERE SFA_SALES_NO    = in_CUST_KEY;
         
    ELSIF in_GUBUN = 'KEYNAME' THEN
        SELECT TRADE_NAME
          INTO v_cust_nm
          FROM SFA_SALES_CODE
         WHERE SFA_SALES_NO    = in_CUST_KEY;
    
   
    ELSIF in_GUBUN = 'NAME' THEN
        SELECT TRADE_NAME
          INTO v_cust_nm
          FROM SFA_SALES_CODE
         WHERE SFA_SALES_SEQ    = in_CUST_KEY;
    END IF;

    RETURN v_cust_nm;
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;

/
