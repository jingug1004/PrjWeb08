CREATE PROCEDURE      SP_X_MYPL_GROUPGRIDLIST
(
    in_SAWON_ID  IN VARCHAR2,
    in_SIDX      IN VARCHAR2,
    in_SORD      IN VARCHAR2,
    out_RESULT  OUT TYPES.CURSOR_TYPE,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_MYPL_GROUPGRIDLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
    
	OPEN out_RESULT FOR
		SELECT SAWON_ID, PLGRP_NO, PLGRP_NM, COMMENTS, SORT_SEQ
		  FROM SALE.SFA_MYPL_GROUP
		 WHERE SAWON_ID = in_SAWON_ID
			ORDER BY in_SIDX||' '||in_SORD;
			
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
