CREATE PROCEDURE      P_DOCYCLE
              ( AS_YMDF IN  VARCHAR2,
                AS_YMDT IN  VARCHAR2)
                
IS
 /* ************* 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
 /*   TITLE        :  도매회전일분석자료를 임시테이블에 저장                        */
 /*   PROJECT      :  채권관리부                                                    */
 /*   AUTHOR       :                                                                */
 /*   PROGRAM_ID   :  P_DOCYCLE                                                     */
 /*   HISTORY      :  2010.11.02(화)                                                */
 /*   PROCESS      :  항목별로 데이타 넣는다                                        */
 /* ******************************************************************************* */
    T_CUST_ID    VARCHAR2(10);
    T_DEALNOF    VARCHAR2(14);
    T_DEALNOT    VARCHAR2(14);
    T_INPUTSEQF  VARCHAR2(14);
    T_INPUTSEQT  VARCHAR2(14);
    T_REAMT      NUMBER;
    T_REAMTF     NUMBER;
    T_REAMTT     NUMBER;
    T_CHGCNT     NUMBER;
    T_CNT        NUMBER;
 	
   CURSOR CUR1 IS
        SELECT A.CUST_ID, A.CASH_AMT, B.REAMT + A.MIDORA_AMT REAMT
          FROM (
                SELECT CUST_ID, SUM(CASH_AMT) CASH_AMT, SUM(MIDORA_AMT) MIDORA_AMT
                  FROM (
                        --기간내 현금금액 
                        SELECT A.CUST_ID, SUM(A.CASH_AMT) CASH_AMT, 0 MIDORA_AMT
                          FROM SALE0401 A
                         WHERE SUBSTR(A.JUNPYO_NO,1,8) BETWEEN AS_YMDF AND AS_YMDT 
                           AND A.CUST_ID LIKE '11%'
                           AND A.CASH_AMT <> 0
                         GROUP BY A.CUST_ID   
                        UNION ALL   
                        --기간내 신용카드,압인금액 
                        SELECT A.CUST_ID, SUM(B.AMT) BILL_AMT, 0 MIDORA_AMT
                          FROM SALE0401 A, SALE0402 B
                         WHERE SUBSTR(A.JUNPYO_NO,1,8) BETWEEN AS_YMDF AND AS_YMDT
                           AND A.CUST_ID LIKE '11%'
                           AND A.JUNPYO_NO = B.JUNPYO_NO
                           AND B.BILL_GB IN ('100','101') 
                         GROUP BY A.CUST_ID   
                        UNION ALL    
                        --기간내 어음금액 
                        SELECT A.CUST_ID, SUM(B.AMT) BILL_AMT, 0 MIDORA_AMT
                          FROM SALE0401 A, SALE0402 B
                         WHERE A.CUST_ID LIKE '11%'
                           AND A.JUNPYO_NO = B.JUNPYO_NO
                           AND B.BILL_GB NOT IN ('100','101')
                           AND TO_CHAR(B.END_YMD,'YYYYMMDD') BETWEEN AS_YMDF AND AS_YMDT  
                         GROUP BY A.CUST_ID   
                        UNION ALL    
                        --기간후 어음미도래금액 
                        SELECT A.CUST_ID, 0 BILL_AMT, SUM(B.AMT) MIDORA_AMT
                          FROM SALE0401 A, SALE0402 B
                         WHERE A.CUST_ID LIKE '11%'
                           AND A.JUNPYO_NO = B.JUNPYO_NO
                           AND B.BILL_GB NOT IN ('100','101')
                           AND TO_CHAR(B.END_YMD,'YYYYMMDD') > AS_YMDT  
                         GROUP BY A.CUST_ID   
                       ) A
                 GROUP BY A.CUST_ID       
               ) A,
               (
                SELECT C.CUST_ID                     CUST_ID,
                       MAX(NVL(B.BEFORE_AMT,0)) + SUM(NVL(A.AMT,0) + NVL(A.VAT,0) - NVL(A.SUKUM,0)) REAMT
                  FROM (SELECT A.CUST_ID                     CUST_ID,
                               B.AMT                         AMT,
                               B.VAT                         VAT,
                               0                             SUKUM               
                          FROM SALE0207 A, 
                               SALE0208 B
                         WHERE A.DEAL_NO = B.DEAL_NO
                           AND A.YMD     = B.YMD
                           AND TO_CHAR(A.YMD,'YYYYMMDD') BETWEEN AS_YMDF AND AS_YMDT
                           AND A.CUST_ID LIKE '11%'
                        UNION ALL /*  수금(할인) 내역 */
                        SELECT A.CUST_ID                     CUST_ID,
                               0                             AMT,
                               0                             VAT,
                               CASH_AMT                      SUKUM
                          FROM SALE0401 A
                         WHERE TO_CHAR(A.YMD,'YYYYMMDD') BETWEEN AS_YMDF AND AS_YMDT
                           AND A.CUST_ID  LIKE '11%'
                           AND A.CASH_AMT <> 0
                        UNION ALL
                        SELECT A.CUST_ID                     CUST_ID,
                               0                             AMT,
                               0                             VAT,
                               B.AMT                         SUKUM
                          FROM SALE0402  B,
                               SALE0401  A
                         WHERE TO_CHAR(A.YMD,'YYYYMMDD') BETWEEN AS_YMDF AND AS_YMDT
                           AND A.JUNPYO_NO   = B.JUNPYO_NO
                           AND A.CUST_ID     LIKE '11%') A,
                       (SELECT CUST_ID                  CUST_ID,
                               NVL(SUM(BEFORE_AMT),0)   BEFORE_AMT
                          FROM (SELECT CUST_ID,                   /*전월 잔액 */
                                       BEFORE_AMT      BEFORE_AMT
                                  FROM SALE0306
                                 WHERE CUST_ID     LIKE '11%'
                                   AND YMD         = TO_DATE(SUBSTR(AS_YMDF,1,6)||'01','YYYY/MM/DD')
                                 UNION ALL
                                SELECT CUST_ID,                  /*금월의 조회조건 기간까지의 잔액*/
                                       NVL(A.AMT,0) + NVL(A.VAT,0)  
                                       BEFORE_AMT
                                  FROM SALE0207  B,
                                       SALE0208  A
                                 WHERE A.DEAL_NO    = B.DEAL_NO
                                   AND A.YMD        = B.YMD
                                   AND B.CUST_ID    LIKE '11%'
                                   AND A.YMD        >= TO_DATE(SUBSTR(AS_YMDF,1,6)||'01','YYYY/MM/DD')
                                   AND A.YMD        <  TO_DATE(AS_YMDF,'YYYY/MM/DD')
                                     UNION all
                                SELECT CUST_ID,     
                                       (NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1  
                                       BEFORE_AMT
                                  FROM SALE0401  A
                                 WHERE A.CUST_ID    LIKE '11%'
                                   AND A.YMD        >= TO_DATE(SUBSTR(AS_YMDF,1,6)||'01','YYYY/MM/DD')
                                   AND A.YMD        <  TO_DATE(AS_YMDF,'YYYY/MM/DD'))
                         GROUP BY CUST_ID          )  B,
                      SALE0003 C
                WHERE C.CUST_ID    LIKE '11%'
                  AND C.CUST_ID    = A.CUST_ID(+)
                  AND C.CUST_ID    = B.CUST_ID(+)
                GROUP BY C.CUST_ID  
               ) B 
         WHERE A.CUST_ID = B.CUST_ID(+);

   CURSOR CUR2 IS
        SELECT A.DEAL_NO                     DEAL_NO,
               B.INPUT_SEQ                   INPUT_SEQ,
               B.ITEM_ID                     ITEM_ID,
               (NVL(B.AMT,0) + NVL(B.VAT,0)) AMT
          FROM SALE0207 A, SALE0208 B
         WHERE A.DEAL_NO = B.DEAL_NO
           AND A.YMD     = B.YMD
           AND A.YMD     BETWEEN TO_DATE('20080101','YYYY/MM/DD') AND TO_DATE(AS_YMDT,'YYYY/MM/DD')
           AND A.CUST_ID = T_CUST_ID  
         ORDER BY 1 DESC,2 DESC;

         
 BEGIN
    DELETE FROM DOCYCLE WHERE CDATEF >= AS_YMDF AND CDATET <= AS_YMDT;

    FOR C1 IN CUR1 LOOP
        T_CUST_ID := C1.CUST_ID;
        T_REAMT   := C1.REAMT; --현잔액 
        T_CHGCNT  := 1;
        FOR C2 IN CUR2 LOOP
            T_REAMT := T_REAMT - C2.AMT;
            --종료일자를 구한다.
            IF T_REAMT <= 0 AND T_CHGCNT = 1 THEN
               T_DEALNOT   := C2.DEAL_NO;
               T_INPUTSEQT := C2.INPUT_SEQ;
               T_REAMTT    := C2.AMT + T_REAMT;   --종료일자금액에서 뺀다.
               T_REAMT     := C1.CASH_AMT;        --수금액으로 치환한다. 
               T_REAMT     := T_REAMT - (C2.AMT - T_REAMTT); --여기서부터 수금액을 차감한다. 
               T_CHGCNT    := 2;
            END IF;
            --시작일자를 구한다.
            IF T_REAMT <= 0 AND T_CHGCNT = 2 THEN --종료일자를 구한다.
               T_DEALNOF   := C2.DEAL_NO;
               T_INPUTSEQF := C2.INPUT_SEQ;
               T_REAMTF    := T_REAMT * -1;       --시작일자금액에서 뺀다.
               EXIT;
            END IF;
        END LOOP;

        --도매회전일분석테이블에 저장한다.
        INSERT INTO DOCYCLE
        SELECT AS_YMDF,
               AS_YMDT,
               TO_CHAR(A.YMD,'YYYYMMDD') YMD, 
               B.DEAL_NO                 DEAL_NO,
               B.INPUT_SEQ               INPUT_SEQ,
               A.CUST_ID                 CUST_ID,   
               C.CUST_NM1                CUST_NM ,
               A.RCUST_ID                RCUST_ID,   
               D.CUST_NM1                RCUST_NM,
               E.ITEM_ID                 ITEM_ID,
               E.ITEM_NM                 ITEM_NM,
               E.STANDARD                STANDARD,  
               B.QTY                     QTY,
               B.DC_QTY                  DC_QTY,    
               ROUND(B.DANGA * 1.1)                                                                                             BAL_AMT,     
               ROUND((1 - (ROUND(B.DANGA * 1.1)/
                           DECODE(TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'BAS_AMT')),0,1,
                                  TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'BAS_AMT'))))) * 100 ,2)   QTY_YUL,
               B.AMT+B.VAT                                                                                                      AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT1'))                                  YAK_AMT,     
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'AMT_YUL'))                                   AMT_YUL,
               B.QTY * TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT1'))                          ACT_SALE,    
               ROUND(B.DANGA * 1.1) -
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT'))                                   DANGA_CHA,     
               (B.AMT+B.VAT) -                                                                                                      
               (B.QTY * TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT1')))                        HAL_AMT,
               ROUND((((B.AMT+B.VAT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C'))))/100,0) + 
               ROUND((((B.AMT+B.VAT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC'))))/100,0) + 
               ROUND((((B.AMT+B.VAT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC'))))/100,0) BOSANG_AMT,
               (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C')) +
                TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC')) +
                TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC')))                                     BOSANG_YUL, 
               ROUND((((B.AMT+B.VAT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C'))))/100,0) C_AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C'))                                         C,     
               ROUND((((B.AMT+B.VAT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC'))))/100,0) GC_AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC'))                                        GC,     
               ROUND((((B.AMT+B.VAT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC'))))/100,0) ETC_AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC'))                                       ETC,     
               B.GC_EN_YN                                                                                                       GC_EN_YN,              
               F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'BIGO')                                                 BIGO     
          FROM SALE0207 A,         
               SALE0208 B,
               SALE0003 C, 
               SALE0003 D,
               SALE0004 E
         WHERE A.CUST_ID  = C.CUST_ID 
           AND A.RCUST_ID = D.CUST_ID
           AND A.DEAL_NO  = B.DEAL_NO
           AND B.ITEM_ID  = E.ITEM_ID
           AND (B.DC_AMT   <> 0 OR
                F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C')   <> '0' OR 
                F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC')  <> '0' OR 
                F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC') <> '0' OR 
                A.CUST_ID = T_CUST_ID ) 
           AND A.DEAL_NO||B.INPUT_SEQ > T_DEALNOF||T_INPUTSEQF 
           AND A.DEAL_NO||B.INPUT_SEQ < T_DEALNOT||T_INPUTSEQT 
           AND A.CUST_ID = T_CUST_ID;
        --시작일자에서 차액을 뺀금액 저장한다. 
        INSERT INTO DOCYCLE
        SELECT AS_YMDF,
               AS_YMDT,
               TO_CHAR(A.YMD,'YYYYMMDD') YMD, 
               B.DEAL_NO                 DEAL_NO,
               B.INPUT_SEQ               INPUT_SEQ,
               A.CUST_ID                 CUST_ID,   
               C.CUST_NM1                CUST_NM ,
               A.RCUST_ID                RCUST_ID,   
               D.CUST_NM1                RCUST_NM,
               E.ITEM_ID                 ITEM_ID,
               E.ITEM_NM                 ITEM_NM,
               E.STANDARD                STANDARD,  
               B.QTY                     QTY,
               B.DC_QTY                  DC_QTY,    
               ROUND(B.DANGA * 1.1)                                                                                            BAL_AMT,     
               ROUND((1 - (ROUND(B.DANGA * 1.1)/
                           DECODE(TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'BAS_AMT')),0,1,
                                  TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'BAS_AMT'))))) * 100 ,2)   QTY_YUL,
               B.AMT+B.VAT-T_REAMTF                                                                                             AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT1'))                                  YAK_AMT,     
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'AMT_YUL'))                                   AMT_YUL,
               B.QTY * TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT1'))                          ACT_SALE,    
               ROUND(B.DANGA * 1.1) -
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT'))                                   DANGA_CHA,     
               (B.AMT+B.VAT-T_REAMTF) -                                                                                                      
               (B.QTY * TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT1')))                        HAL_AMT,
               ROUND((((B.AMT+B.VAT-T_REAMTF) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C'))))/100,0) + 
               ROUND((((B.AMT+B.VAT-T_REAMTF) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC'))))/100,0) + 
               ROUND((((B.AMT+B.VAT-T_REAMTF) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC'))))/100,0) BOSANG_AMT,
               (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C')) +
                TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC')) +
                TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC')))                                     BOSANG_YUL, 
               ROUND((((B.AMT+B.VAT-T_REAMTF) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C'))))/100,0) C_AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C'))                                         C,     
               ROUND((((B.AMT+B.VAT-T_REAMTF) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC'))))/100,0) GC_AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC'))                                        GC,     
               ROUND((((B.AMT+B.VAT-T_REAMTF) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC'))))/100,0) ETC_AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC'))                                       ETC,     
               B.GC_EN_YN                                                                                                       GC_EN_YN,              
               F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'BIGO')                                                 BIGO     
          FROM SALE0207 A,         
               SALE0208 B,
               SALE0003 C, 
               SALE0003 D,
               SALE0004 E
         WHERE A.CUST_ID  = C.CUST_ID 
           AND A.RCUST_ID = D.CUST_ID
           AND A.DEAL_NO  = B.DEAL_NO
           AND B.ITEM_ID  = E.ITEM_ID
           AND (B.DC_AMT   <> 0 OR
                F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C')   <> '0' OR 
                F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC')  <> '0' OR 
                F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC') <> '0' OR 
                A.CUST_ID = T_CUST_ID ) 
           AND A.DEAL_NO||B.INPUT_SEQ = T_DEALNOF||T_INPUTSEQF
           AND A.CUST_ID   = T_CUST_ID;
        --종료일자에서 차액을 뺀금액 저장한다.
        --시작일자와 종료일자가 같은경우는 쿼리를 처리하지않는다.
        SELECT COUNT(*)
          INTO T_CNT
          FROM DOCYCLE
         WHERE CDATEF >= AS_YMDF AND CDATET <= AS_YMDT
           AND CUST_ID = T_CUST_ID;
        IF T_CNT < 2 THEN
           GOTO CONTINUE;
        END IF;

        INSERT INTO DOCYCLE
        SELECT AS_YMDF,
               AS_YMDT,
               TO_CHAR(A.YMD,'YYYYMMDD') YMD, 
               B.DEAL_NO                 DEAL_NO,
               B.INPUT_SEQ               INPUT_SEQ,
               A.CUST_ID                 CUST_ID,   
               C.CUST_NM1                CUST_NM ,
               A.RCUST_ID                RCUST_ID,   
               D.CUST_NM1                RCUST_NM,
               E.ITEM_ID                 ITEM_ID,
               E.ITEM_NM                 ITEM_NM,
               E.STANDARD                STANDARD,  
               B.QTY                     QTY,
               B.DC_QTY                  DC_QTY,    
               ROUND(B.DANGA * 1.1)                                                                                            BAL_AMT,     
               ROUND((1 - (ROUND(B.DANGA * 1.1)/
                           DECODE(TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'BAS_AMT')),0,1,
                                  TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'BAS_AMT'))))) * 100 ,2)   QTY_YUL,
               B.AMT+B.VAT-T_REAMTT                                                                                             AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT1'))                                  YAK_AMT,     
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'AMT_YUL'))                                   AMT_YUL,
               B.QTY * TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT1'))                          ACT_SALE,    
               ROUND(B.DANGA * 1.1) -
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT'))                                   DANGA_CHA,     
               (B.AMT+B.VAT-T_REAMTT) -                                                                                                      
               (B.QTY * TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'YAK_AMT1')))                        HAL_AMT,
               ROUND((((B.AMT+B.VAT-T_REAMTT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C'))))/100,0) + 
               ROUND((((B.AMT+B.VAT-T_REAMTT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC'))))/100,0) + 
               ROUND((((B.AMT+B.VAT-T_REAMTT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC'))))/100,0) BOSANG_AMT,
               (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C')) +
                TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC')) +
                TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC')))                                     BOSANG_YUL, 
               ROUND((((B.AMT+B.VAT-T_REAMTT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C'))))/100,0) C_AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C'))                                         C,     
               ROUND((((B.AMT+B.VAT-T_REAMTT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC'))))/100,0) GC_AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC'))                                        GC,     
               ROUND((((B.AMT+B.VAT-T_REAMTT) - (B.dc_amt + TRUNC(B.dc_amt * 0.1,0))) * (TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC'))))/100,0) ETC_AMT,
               TO_NUMBER(F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC'))                                       ETC,     
               B.GC_EN_YN                                                                                                       GC_EN_YN,              
               F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'BIGO')                                                 BIGO     
          FROM SALE0207 A,         
               SALE0208 B,
               SALE0003 C, 
               SALE0003 D,
               SALE0004 E
         WHERE A.CUST_ID  = C.CUST_ID 
           AND A.RCUST_ID = D.CUST_ID
           AND A.DEAL_NO  = B.DEAL_NO
           AND B.ITEM_ID  = E.ITEM_ID
           AND (B.DC_AMT   <> 0 OR
                F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'C')   <> '0' OR 
                F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'GC')  <> '0' OR 
                F_Get_Sale0405_AmtH(A.CUST_ID,A.RCUST_ID,B.ITEM_ID,A.YMD,'ETC') <> '0' OR 
                A.CUST_ID = T_CUST_ID ) 
           AND A.DEAL_NO||B.INPUT_SEQ = T_DEALNOT||T_INPUTSEQT
           AND A.CUST_ID   = T_CUST_ID;
           
        << CONTINUE >>
        
        T_CNT :=  0; --GOTO문을쓰기위해서 임시로 사용한것 로직에 전혀관계없음 

    END LOOP;
    
    COMMIT;
    
    EXCEPTION
       WHEN OTHERS THEN
          ROLLBACK;
          RAISE_APPLICATION_ERROR(-20001, SUBSTRB('오류!'||SQLCODE||'/'||SQLERRM,1,250)||'###'||T_CUST_ID||':'||T_DEALNOF||'-'||T_INPUTSEQF||':'||T_DEALNOT||'-'||T_INPUTSEQT) ;
   
    END P_DOCYCLE;

/
