CREATE PROCEDURE      SP_Z_ORDER_STOCK_CONFIRM
(
    in_SAWON_ID IN  VARCHAR2,   -- 영업사원번호    
    in_COUNT IN NUMBER,   -- 선택한 COUNT
    in_ITEM_ID IN VARCHAR2,   -- 제품정보
    in_REG_DATE IN VARCHAR2,   -- 관리자등록시각
    out_CODE OUT NUMBER,
    out_MSG OUT VARCHAR2 
)
IS
        /*---------------------------------------------------------------------------
        프로그램명   : 입고현황 
        호출프로그램 : VISIT.VISITDAILY 의 입고 현황 POPUP  내용 확인     
        
        in_ITEM_ID_DATA  5자리 + @ 1자리
        in_REG_DATE_DATA  14자리 + @ 1자리
          
        ---------------------------------------------------------------------------*/    

        V_SALE0705_2_NUM NUMBER; --입고현황 입력된 수
        V_SALE0705_3_NUM NUMBER; --영업사원이 입고현황 확인 한 수 
        V_ITEM_ID SALE0705_2.ITEM_ID%TYPE;
        V_REG_DATE SALE0705_2.REG_DATE%TYPE;      
    
BEGIN   
       
        IF in_SAWON_ID = NULL THEN
                out_CODE := 1;
                out_MSG := '저장실패 사원번호가 정확하지 않습니다.';
        ELSIF in_COUNT <= 0 THEN
                out_CODE := 1;
                out_MSG := '저장실패 선택항목이 정확하지 않습니다.'; 
        ELSIF in_ITEM_ID = NULL OR in_REG_DATE = NULL THEN
                out_CODE := 1;
                out_MSG := '저장실패 입고현황의 정보가 정확하지 않습니다.';
        END IF;
        
--        INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_STOCK_CONFIRM' ,'1' ,SYSDATE ,'in_SAWON_ID:'||in_SAWON_ID||' ,in_COUNT: '||in_COUNT||' ,in_ITEM_ID: '||in_ITEM_ID||' ,in_REG_DATE: '||in_REG_DATE);
--        COMMIT;
      
        FOR ll_loop IN 1.. in_COUNT LOOP  

                V_ITEM_ID := TRIM(SUBSTR(REPLACE(in_ITEM_ID,'@',' '), 1 + 6*(ll_loop -1),  6));  
                V_REG_DATE := TRIM(SUBSTR(REPLACE(in_REG_DATE,'@',' '), 1 + 14*(ll_loop -1),  14));
                
                IF V_ITEM_ID = NULL THEN
                   V_ITEM_ID := '999999'; 
                END IF; 
                
                -- 입고현황의 내용은 삭제 가능하도록 설계한다.
                V_SALE0705_2_NUM := 0;
                SELECT COUNT(*)
                  INTO V_SALE0705_2_NUM                          
                  FROM SALE0705_2
                 WHERE ITEM_ID = V_ITEM_ID
                   AND REG_DATE = V_REG_DATE
                ;

                V_SALE0705_3_NUM := 0;                 
                SELECT COUNT(*)
                  INTO V_SALE0705_3_NUM
                  FROM SALE0705_3 A
                 WHERE A.ITEM_ID = V_ITEM_ID
                   AND A.REG_DATE = V_REG_DATE
                   AND A.SAWON_ID = in_SAWON_ID                        
                ;
                
                -- V_SALE0705_2_NUM 값을 이용하여 등록된 정보를 하려고 했으나 삭제 가능하도록 변경  
                IF V_SALE0705_3_NUM = 0  THEN 
                        
                        INSERT INTO SALE0705_3 (ITEM_ID ,REG_DATE ,SAWON_ID ,CONFIRM_DATE)
                        VALUES (V_ITEM_ID ,V_REG_DATE ,in_SAWON_ID ,TO_CHAR(SYSDATE ,'YYYYMMDDHH24MISS'))
                        ;
                        COMMIT
                        ;
                END IF;
                
        END LOOP;      
       
        out_CODE := 0;
        out_MSG := '저장완료';    
         
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
