CREATE PROCEDURE      SP_SFA_ADMIN_BLOB    -- 이미지 BLOB
(
    in_ITEM_CD           IN  NUMBER,     -- 제품코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_ITEMDOC
     WHERE ITEM_CODE    = in_ITEM_CD;
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
     
        OPEN out_RESULT FOR
        SELECT ITEM_PHOTO                 AS out_ITEM_BLOB      -- BLOB
          FROM SFA_OFFICE_ITEMDOC
         WHERE ITEM_CODE    = in_ITEM_CD;
      
    END IF; 
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
