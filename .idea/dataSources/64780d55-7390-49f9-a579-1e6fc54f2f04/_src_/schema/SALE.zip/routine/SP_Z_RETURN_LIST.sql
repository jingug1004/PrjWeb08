CREATE PROCEDURE      SP_Z_RETURN_LIST 
(
    in_PROCESS          IN  VARCHAR2,
    in_SAWON_ID          IN  VARCHAR2,   
    in_CDT_FR            IN  VARCHAR2,    
    in_CDT_TO            IN  VARCHAR2,    
    in_CUST_ID           IN  VARCHAR2,    
    in_RCUST_ID          IN  VARCHAR2,    
    out_CODE             out NUMBER,
    out_MSG              out VARCHAR2,
    out_COUNT            out NUMBER,
    out_RESULT           out TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문현황
 호출프로그램 : 
 수정내역
  1.2014.04.08 KTA 위반주문 팀장승인상태를 화면에 보여주도록 수정함.    
  2.2014.12.12 KTA 수정버튼시 주문등록화면으로 넘어가면서 가지고갈 회전일 추가.  
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_VISIT_NON_REASON_LIST','1',sysdate,'v_PLAN_DT:'||in_SAWON_ID||'/in_SAWON_ID:'||in_SAWON_ID );
   
        SELECT COUNT(*)
          INTO v_num
        FROM sfa_banpum_reason A
        where a.CUST_SAWON_ID = in_SAWON_ID
           and YMD between in_CDT_FR and in_CDT_TO
           and CUST_ID like '%'||in_CUST_ID||'%'
           and RCUST_ID like '%'|| in_RCUST_ID || '%';
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
    
            OPEN out_RESULT FOR
            SELECT 
                a.YMD                 as out_YYYYMM     -- K
                ,a.CUST_ID            as out_CUSTID     --K
                ,''                 as out_CUSTNM
                ,a.RCUST_ID           as out_RCUSTID    --K
                ,''                 as out_RCUSTNM
                ,a.ITEM_ID            as out_ITEM_CD    --k
                ,b.itemname             as out_ITEM_NM
                ,a.PROD_NO            as out_PRODNO     --k
                ,a.BANPUM_QTY         as out_BANPUMQTY   
                ,a.BARCODE_QTY        as out_BARCODEQTY  
                
                ,a.AMT                as out_AMT
                ,a.BANPUM_REASON      as out_REASON_CODE 
                ,a.SEONGIN_STATE      as out_APPR
                ,a.SEONGIN_NO_REASON  as out_REASON
                  
            FROM sfa_banpum_reason a
                left outer join oragmp.CMITEMM b on a.ITEM_ID = b.itemcode
            where a.CUST_SAWON_ID = in_SAWON_ID
                and a.YMD between in_CDT_FR and in_CDT_TO
           and CUST_ID like '%'||in_CUST_ID||'%'
           and RCUST_ID like '%'|| in_RCUST_ID || '%';
    
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
