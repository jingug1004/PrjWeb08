CREATE PROCEDURE      SP_CUST_ID_MAKE
IS

        V_SALE_ID SALE0000_TEMP.SALE_ID% TYPE;
        V_SALE_D6 SALE0000_TEMP.SALE_D6%TYPE;
        
        V_CUST_ID SALE0003.CUST_ID%TYPE;
        V_CUST_SEQ SALE0003.CUST_ID%TYPE;
        
        V_CNT NUMBER;
        V_TMP_CNT NUMBER;
  
        V_CURR_ERROR VARCHAR2(1000) ;
        USER_ERR EXCEPTION; 
        
CURSOR C_LOAD IS
        SELECT SALE_ID
        FROM SALE0000_TEMP
        WHERE SALE_D6 = '490'
        ;
  
BEGIN
        OPEN C_LOAD;
        V_CNT := 0;
  
        LOOP
                FETCH C_LOAD
                INTO V_SALE_ID;
                 
                
                IF C_LOAD%NOTFOUND THEN
                        DBMS_OUTPUT.PUT_LINE('NOTFOUND EXIT : V_SALE_ID : '||V_SALE_ID); 
                        EXIT;
                END IF;
                
                V_SALE_D6 := 0;
                SELECT TRIM(SALE_D6)
                INTO V_SALE_D6
                FROM SALE0000_TEMP
                WHERE SALE_ID = V_SALE_ID
                ;
                
                
                V_TMP_CNT := 0;                
                SELECT COUNT(*)
                INTO V_TMP_CNT
                FROM SALE0003
                WHERE CUST_ID LIKE V_SALE_D6||'%'
                ;
                
                
                V_CUST_ID :=0;
                IF V_TMP_CNT = 0 THEN
                      V_CUST_ID := V_SALE_D6||'0001';  
                ELSE                                
                        SELECT TO_CHAR(MAX(SUBSTR(CUST_ID ,4 ,4)) + 1 + V_CNT)
                        INTO V_CUST_SEQ
                        FROM SALE0003
                        WHERE CUST_ID LIKE V_SALE_D6||'%'
                        ;
                        DBMS_OUTPUT.PUT_LINE('V_SALE_ID : '||V_SALE_ID||' ,V_CUST_SEQ : '||V_CUST_SEQ||' ,V_CNT: '||V_CNT);    
                        
                        IF LENGTH(V_CUST_SEQ) != 4 THEN
                                V_CUST_SEQ := LPAD(V_CUST_SEQ ,4 ,'0');
                        END IF;
                        
                        V_CUST_ID := V_SALE_D6||V_CUST_SEQ;    
                        --DBMS_OUTPUT.PUT_LINE('END : V_CUST_ID : '||V_CUST_ID);                    
                END IF;
                
                UPDATE SALE0000_TEMP SET SALE_D3 = V_CUST_ID
                WHERE SALE_ID = V_SALE_ID
                ;
                
                V_CNT := V_CNT + 1;
                COMMIT;  

        END LOOP;

END  SP_CUST_ID_MAKE;

/
