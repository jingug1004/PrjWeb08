CREATE PROCEDURE      SP_SFA_COLLECT_05
(
    in_SAWON_ID          IN  VARCHAR2,     -- 사원 ID
    in_DEPT_CD           IN  VARCHAR2,     -- 부서코드
    in_CUST_CD           IN  VARCHAR2,     -- 거래처코드
    in_DT_FR             IN  VARCHAR2,     -- 기준일자 FROM
    in_DT_TO             IN  VARCHAR2,     -- 기준일자 TO
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처원장
 호출프로그램 :       
 수정내역    2015.04.28 kta 부서코드 체크하는 부분은 막음.어차피 거래처 선택시 로그인사원이 볼수 있는 거래처만 선택할수 있기 때문에 의미 없음.
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    

    SELECT COUNT(*)  
      INTO v_num
      FROM (SELECT 1                             SEQ,
                   A.YMD                         YMD,
                   A.CUST_ID                     CUST_ID,
                   A.RCUST_ID                    RCUST_ID,
                   B.ITEM_ID                     ITEM_ID,
                   D.ITEM_NM                     ITEM_NM,
                   D.STANDARD                    STANDARD,
                   B.QTY                         QTY,
                   B.DANGA                       DANGA,
                   B.AMT                         AMT,
                   B.VAT                         VAT,
                   B.DC_AMT                      DC_AMT,
                   B.DC_QTY                      DC_QTY,
                   B.DC_EN_YN                    DC_EN_YN,
                   0                             SUKUM,
                   (NVL(B.AMT,0) + NVL(B.VAT,0)) TOT,
                   A.DEAL_NO                     DEAL_NO,
                   DECODE(E.GUMAE_GB,'12',E.BIGO,'13',E.BIGO,'') BIGO,
                   B.INPUT_SEQ                    INPUT_SEQ
              FROM SALE0207 A, 
                   SALE0208 B, 
                   SALE0004 D,
                   SALE0203 E
             WHERE A.DEAL_NO  = B.DEAL_NO
               AND A.YMD      = B.YMD
               AND B.ITEM_ID  = D.ITEM_ID
               AND A.YMD      BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
               AND A.CUST_ID  = in_CUST_CD  
               AND A.GUMAE_NO = E.GUMAE_NO(+)
            UNION ALL /*  수금(할인) 내역 */
            SELECT 2                             SEQ,
                   A.YMD                         YMD,
                   A.CUST_ID                     CUST_ID,
                   A.RCUST_ID                    RCUST_ID,
                   DECODE(A.JUNPYO_GB,'01','현금','10','매출할인','20','부실채권','30','거래이관','35','대손상각','40','잡수익','45','손실정리'
                                     ,'50','부도어음대체','55','폐업상품입고','기타수금')
                                                 ITEM_ID,
                   BIGO                          ITEM_NM,
                   ''                            STANDARD,
                   0                             QTY,
                   0                             DANGA,
                   0                             AMT,
                   0                             VAT,
                   0                             DC_AMT,
                   0                             DC_QTY,
                   ''                            DC_EN_YN,
                   CASH_AMT                      SUKUM,
                   NVL(-(CASH_AMT),0)            TOT,
                   ''                            DEAL_NO,
                   ''                            BIGO,
                   ''                            INPUT_SEQ
              FROM SALE0401  A
             WHERE A.YMD         BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
               AND A.CUST_ID     = in_CUST_CD 
                 AND A.CASH_AMT      <> 0
            UNION ALL
            SELECT 2                             SEQ,
                   A.YMD                         YMD,
                   A.CUST_ID                     CUST_ID,
                   A.RCUST_ID                    RCUST_ID,
                   C.CODE1_NM                    ITEM_ID,                                             
                   B.BILL_NO                     ITEM_NM,
                   ''                            STANDARD,
                   0                             QTY,
                   0                             DANGA,
                   0                             AMT,
                   0                             VAT,
                   0                             DC_AMT,
                   0                             DC_QTY,
                   ''                            DC_EN_YN,
                   AMT                           SUKUM,
                   NVL(-(AMT),0)                 TOT,
                   ''                            DEAL_NO,
                   DECODE(C.CODE1,'100','',TO_CHAR(B.END_YMD,'YYYYMMDD')) BIGO,
                   ''                            INPUT_SEQ
              FROM SALE0402  B,
                   SALE0401  A,
                   (SELECT CODE1, CODE1_NM FROM  SALE0001 WHERE CODE_GB = '0007') C
             WHERE A.YMD         BETWEEN  TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
               AND A.JUNPYO_NO   = B.JUNPYO_NO
               AND A.CUST_ID     = in_CUST_CD  
               AND B.BILL_GB = C.CODE1(+))  A,
           (SELECT CUST_ID                  CUST_ID,
                   NVL(SUM(BEFORE_AMT),0)   BEFORE_AMT
              FROM (SELECT CUST_ID,                   /*전월 잔액 */
                           BEFORE_AMT      BEFORE_AMT
                      FROM SALE0306
                     WHERE CUST_ID     = in_CUST_CD  
                       AND YMD         = TO_DATE(SUBSTR(in_DT_FR,1,6)||'01', 'YYYY/MM/DD')
                     UNION ALL
                    SELECT CUST_ID,                  --금월의 조회조건 기간까지의 잔액
                           NVL(A.AMT,0) + NVL(A.VAT,0)  
                           BEFORE_AMT
                      FROM SALE0207  B,
                           SALE0208  A
                     WHERE A.DEAL_NO    = B.DEAL_NO
                       AND A.YMD        = B.YMD
                       AND B.CUST_ID    = in_CUST_CD  
                       AND A.YMD        >= TO_DATE(SUBSTR(in_DT_FR,1, 6)||'01', 'YYYY/MM/DD')
                       AND A.YMD        <  TO_DATE(in_DT_FR)
                         UNION all
                    SELECT CUST_ID,     
                           (NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1  
                           BEFORE_AMT
                      FROM SALE0401  A
                     WHERE A.CUST_ID    = in_CUST_CD  
                       AND A.YMD        >= TO_DATE(SUBSTR(in_DT_FR,1, 6)||'01', 'YYYY/MM/DD')
                       AND A.YMD        <  TO_DATE(in_DT_FR)
                    )
             GROUP BY CUST_ID          )  B,
            SALE0003                      C,
            SALE0003                      D,
            (SELECT B.SAWON_ID, B.SAWON_NM, B.DEPT_CD, C.DEPT_NM 
               FROM SALE0007 B, SALE0008 C  
              WHERE B.DEPT_CD = C.DEPT_CD) E
     WHERE C.CUST_ID    = in_CUST_CD  
       AND C.CUST_ID    = A.CUST_ID(+)
       AND C.CUST_ID    = B.CUST_ID(+)
       AND A.RCUST_ID   = D.CUST_ID(+)
       AND C.SAWON_ID   = E.SAWON_ID(+)
       --AND (E.DEPT_CD IN   (SELECT PART_CD FROM SALE0008D WHERE DEPT_CD = in_DEPT_CD) OR  E.DEPT_CD LIKE (SELECT PART_CD FROM SALE0008D WHERE DEPT_CD = in_DEPT_CD AND PART_CD = '%'))
       AND (NVL(A.TOT,0) <> 0 OR NVL(B.BEFORE_AMT,0) <> 0);
 
/*
  IF in_SAWON_ID = '39488' THEN
    insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_05','1',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'in_DEPT_CD:'||in_DEPT_CD||'in_CUST_CD:'||in_CUST_CD||' / v_num:'||to_char(v_num));
  END IF;
*/  

    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
     
        OPEN out_RESULT FOR
        select *
          from (


                    --이월 --------------------------------------------------------------------------------------------------------
                    SELECT DISTINCT ''                                                AS out_YM,
                           '00000000'                                                 AS out_YMD,               -- 일자
                           ''                                                         AS out_CUST_ID,
                           ''                                                         AS out_RCUST_ID,
                           ''                                                         AS out_VOU_NO,
                           ''                                                         AS out_CUST_NM,
                           ''                                                         AS out_ADDR,
                           ''                                                         AS out_PRESIDENT,
                           ''                                                         AS out_SAWON_ID,
                           ''                                                         AS out_SAWON_NM,
                           ''                                                         AS out_RCUST_NM,
                           ''                                                         AS out_ITEM_ID,          -- 제품ID
                           ''                                                         AS out_ITEM_NM,          -- 제품명
                           ''                                                         AS out_STANDARD,         -- 규격
                           0                                                          AS out_QTY,              -- 수량
                           0                                                          AS out_DANGA,            -- 단가
                           0                                                          AS out_AMT,
                           0                                                          AS out_VAT,
                           0                                                          AS out_SUKUM,            -- 수금액
                           0                                                          AS out_TOT,              -- 합계금액
                           NVL(B.BEFORE_AMT,0)                                        AS out_BEFORE_AMT,       -- 이월금액
                           ''                                                         AS out_DEAL_NO,
                           ''                                                         AS out_INPUT_SEQ,
                           0                                                          AS out_DC_AMT,
                           0                                                          AS out_DC_QTY,
                           0                                                          AS out_DC_EN_AMT,
                           ''                                                         AS out_DC_EN_YN,
                           ''                                                         AS out_TEL,
                           ''                                                         AS out_BIGO,            -- 비고
                           ''                                                         AS out_DATEF,
                           ''                                                         AS out_DATET,
                           0                                                          AS out_JAN_AMT, --잔액
                           0                                                          AS out_TOT_DC_AMT       -- 매출할인
                      FROM (SELECT 1                             SEQ,
                                   A.YMD                         YMD,
                                   A.CUST_ID                     CUST_ID,
                                   A.RCUST_ID                    RCUST_ID,
                                   B.ITEM_ID                     ITEM_ID,
                                   D.ITEM_NM                     ITEM_NM,
                                   D.STANDARD                    STANDARD,
                                   B.QTY                         QTY,
                                   B.DANGA                       DANGA,
                                   B.AMT                         AMT,
                                   B.VAT                         VAT,
                                   B.DC_AMT                      DC_AMT,
                                   B.DC_QTY                      DC_QTY,
                                   B.DC_EN_YN                    DC_EN_YN,
                                   0                             SUKUM,
                                   (NVL(B.AMT,0) + NVL(B.VAT,0)) TOT,
                                   A.DEAL_NO                     DEAL_NO,
                                   DECODE(E.GUMAE_GB,'12',E.BIGO,'13',E.BIGO,'') BIGO,
                                   B.INPUT_SEQ                    INPUT_SEQ
                              FROM SALE0207 A, 
                                   SALE0208 B, 
                                   SALE0004 D,
                                   SALE0203 E
                             WHERE A.DEAL_NO = B.DEAL_NO
                               AND A.YMD     = B.YMD
                               AND B.ITEM_ID = D.ITEM_ID
                               AND A.YMD BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                               AND A.CUST_ID = in_CUST_CD 
                               AND A.GUMAE_NO = E.GUMAE_NO(+)
                            UNION ALL /*  수금(할인) 내역 */
                            SELECT 2                             SEQ,
                                   A.YMD                         YMD,
                                   A.CUST_ID                     CUST_ID,
                                   A.RCUST_ID                    RCUST_ID,
                                   DECODE(A.JUNPYO_GB,'01','현금','10','매출할인','20','부실채권','30','거래이관','35','대손상각','40','잡수익','45','손실정리'
                                                     ,'50','부도어음대체','55','폐업상품입고','기타수금')
                                                                 ITEM_ID,
                                   BIGO                          ITEM_NM,
                                   ''                            STANDARD,
                                   0                             QTY,
                                   0                             DANGA,
                                   0                             AMT,
                                   0                             VAT,
                                   0                             DC_AMT,
                                   0                             DC_QTY,
                                   ''                            DC_EN_YN,
                                   CASH_AMT                      SUKUM,
                                   NVL(-(CASH_AMT),0)            TOT,
                                   ''                            DEAL_NO,
                                   ''                            BIGO,
                                   ''                            INPUT_SEQ
                              FROM SALE0401  A
                             WHERE A.YMD         BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                               AND A.CUST_ID     = in_CUST_CD  
                                 AND A.CASH_AMT      <> 0
                            UNION ALL
                            SELECT 2                             SEQ,
                                   A.YMD                         YMD,
                                   A.CUST_ID                     CUST_ID,
                                   A.RCUST_ID                    RCUST_ID,
                                   C.CODE1_NM                    ITEM_ID,                                             
                                   B.BILL_NO                     ITEM_NM,
                                   ''                            STANDARD,
                                   0                             QTY,
                                   0                             DANGA,
                                   0                             AMT,
                                   0                             VAT,
                                   0                             DC_AMT,
                                   0                             DC_QTY,
                                   ''                            DC_EN_YN,
                                   AMT                           SUKUM,
                                   NVL(-(AMT),0)                 TOT,
                                   ''                            DEAL_NO,
                                   DECODE(C.CODE1,'100','',TO_CHAR(B.END_YMD,'YYYYMMDD')) BIGO,
                                   ''                            INPUT_SEQ
                              FROM SALE0402  B,
                                   SALE0401  A,
                                   (SELECT CODE1, CODE1_NM FROM  SALE0001 WHERE CODE_GB = '0007') C
                             WHERE A.YMD         BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                               AND A.JUNPYO_NO   = B.JUNPYO_NO
                               AND A.CUST_ID     = in_CUST_CD 
                               AND B.BILL_GB = C.CODE1(+))  A,
                           (SELECT CUST_ID                  CUST_ID,
                                   NVL(SUM(BEFORE_AMT),0)   BEFORE_AMT
                              FROM (SELECT CUST_ID,                   /*전월 잔액 */
                                           BEFORE_AMT      BEFORE_AMT
                                      FROM SALE0306
                                     WHERE CUST_ID     = in_CUST_CD 
                                       AND YMD         = TO_DATE(SUBSTR(in_DT_FR,1,6)||'01', 'YYYY/MM/DD')
                                     UNION ALL
                                    SELECT CUST_ID,                  --금월의 조회조건 기간까지의 잔액
                                           NVL(A.AMT,0) + NVL(A.VAT,0)  
                                           BEFORE_AMT
                                      FROM SALE0207  B,
                                           SALE0208  A
                                     WHERE A.DEAL_NO    = B.DEAL_NO
                                       AND A.YMD        = B.YMD
                                       AND B.CUST_ID    = in_CUST_CD  --IN (SELECT CUST_ID FROM SALE0003 WHERE CUST_NM LIKE '%'||NVL(in_CUST_NM, '%')||'%')
                                       AND A.YMD        >= TO_DATE(SUBSTR(in_DT_FR,1, 6)||'01', 'YYYY/MM/DD')--TO_DATE(TO_CHAR(in_DT_FR,'YYYY/MM')||'/01','YYYY/MM/DD')
                                       AND A.YMD        <  TO_DATE(in_DT_FR)
                                         UNION all
                                    SELECT CUST_ID,     
                                           (NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1  
                                           BEFORE_AMT
                                      FROM SALE0401  A
                                     WHERE A.CUST_ID    = in_CUST_CD  --IN (SELECT CUST_ID FROM SALE0003 WHERE CUST_NM LIKE '%'||NVL(in_CUST_NM, '%')||'%')
                                       AND A.YMD        >= TO_DATE(SUBSTR(in_DT_FR,1, 6)||'01', 'YYYY/MM/DD')--TO_DATE(TO_CHAR(in_DT_FR,'YYYY/MM')||'/01','YYYY/MM/DD')
                                       AND A.YMD        <  TO_DATE(in_DT_FR)
                                  )
                             GROUP BY CUST_ID          )  B,
                           SALE0003                       C,
                           SALE0003                       D,
                          (SELECT B.SAWON_ID, B.SAWON_NM, B.DEPT_CD, C.DEPT_NM 
                             FROM SALE0007 B, SALE0008 C  
                            WHERE B.DEPT_CD = C.DEPT_CD)  E
                     WHERE C.CUST_ID     = in_CUST_CD 
                       AND C.CUST_ID    = A.CUST_ID(+)
                       AND C.CUST_ID    = B.CUST_ID(+)
                       AND A.RCUST_ID   = D.CUST_ID(+)
                       AND C.SAWON_ID   = E.SAWON_ID(+)
                       --AND (E.DEPT_CD IN   (SELECT PART_CD FROM SALE0008D WHERE DEPT_CD = in_DEPT_CD) OR E.DEPT_CD LIKE (SELECT PART_CD FROM SALE0008D WHERE DEPT_CD = in_DEPT_CD AND PART_CD = '%'))
                       AND (NVL(A.TOT,0) <> 0 OR NVL(B.BEFORE_AMT,0) <> 0)
                    
                    UNION ALL
 
                    --거래내역  --------------------------------------------------------------------------------------------------------                   
                    select * 
                      from (
                            SELECT TO_CHAR(A.YMD,'YYYYMM')                                    AS out_YM,
                                   TO_CHAR(A.YMD, 'YYYYMMDD')                                 AS out_YMD,               -- 일자
                                   C.CUST_ID                                                  AS out_CUST_ID,
                                   A.RCUST_ID                                                 AS out_RCUST_ID,
                                   C.VOU_NO                                                   AS out_VOU_NO,
                                   C.CUST_NM||'('||C.CUST_ID||')'                             AS out_CUST_NM,
                                   RTRIM(C.ADDR1)||' '||RTRIM(C.ADDR2)                        AS out_ADDR,
                                   C.PRESIDENT                                                AS out_PRESIDENT,
                                   E.SAWON_ID                                                 AS out_SAWON_ID,
                                   E.SAWON_NM                                                 AS out_SAWON_NM,
                                   D.CUST_NM                                                  AS out_RCUST_NM,
                                   A.ITEM_ID                                                  AS out_ITEM_ID,          -- 제품ID
                                   DECODE(A.YMD,null,'****  거래내역 없음  ****',A.ITEM_NM)   AS out_ITEM_NM,          -- 제품명
                                   A.STANDARD                                                 AS out_STANDARD,         -- 규격
                                   A.QTY                                                      AS out_QTY,              -- 수량
                                   A.DANGA                                                    AS out_DANGA,            -- 단가
                                   NVL(A.AMT,0)                                               AS out_AMT,
                                   NVL(A.VAT,0)                                               AS out_VAT,
                                   NVL(A.SUKUM,0)                                             AS out_SUKUM,            -- 수금액
                                   NVL(A.AMT,0) + nvl(A.VAT,0)                                AS out_TOT,              -- 합계금액
                                   NVL(B.BEFORE_AMT,0)                                        AS out_BEFORE_AMT,       -- 이월금액
                                   A.DEAL_NO                                                  AS out_DEAL_NO,
                                   A.INPUT_SEQ                                                AS out_INPUT_SEQ,
                                   A.DC_AMT                                                   AS out_DC_AMT,
                                   A.DC_QTY                                                   AS out_DC_QTY,
                                   DECODE(A.DC_EN_YN,'Y',A.DC_AMT)                            AS out_DC_EN_AMT,
                                   A.DC_EN_YN                                                 AS out_DC_EN_YN,
                                   C.TEL                                                      AS out_TEL,
                                   --A.BIGO                                                     AS out_BIGO,            -- 비고,
                                   decode(f_SP_SFA_collect_05_maxdt(in_SAWON_ID,in_DEPT_CD,in_CUST_CD,TO_CHAR(NVL(A.YMD,SYSDATE),'YYYYMM')||'01',TO_CHAR(last_day(NVL(A.YMD,SYSDATE)),'YYYYMMDD')),TO_CHAR(NVL(A.YMD,SYSDATE),'YYYYMMDD')||ITEM_ID
                                         ,f_SP_SFA_collect_05_sum(in_SAWON_ID,in_DEPT_CD,in_CUST_CD,TO_CHAR(NVL(A.YMD,SYSDATE),'YYYYMM')||'01',TO_CHAR(last_day(NVL(A.YMD,SYSDATE)),'YYYYMMDD')),'')  AS out_BIGO,            -- 비고                
                                   TO_CHAR(in_DT_FR)                                          AS out_DATEF,
                                   TO_CHAR(in_DT_TO)                                          AS out_DATET,
                                   /*SUM(NVL(A.AMT,0)   + NVL(A.VAT,0) - NVL(A.SUKUM,0)) OVER(ORDER BY A.RCUST_ID,A.YMD,A.ITEM_ID) + NVL(B.BEFORE_AMT,0) AS out_JAN_AMT, --잔액 CHOE 20121024 거래처잔액수정건*/
                                   SUM(NVL(A.AMT,0)   + NVL(A.VAT,0) - NVL(A.SUKUM,0)) OVER(PARTITION BY A.CUST_ID ORDER BY A.YMD, A.DEAL_NO, A.INPUT_SEQ) + NVL(B.BEFORE_AMT,0) AS out_JAN_AMT, --잔액
                                   0                                                          AS out_TOT_DC_AMT       -- 매출할인
                              FROM (SELECT 1                             SEQ,
                                           A.YMD                         YMD,
                                           A.CUST_ID                     CUST_ID,
                                           A.RCUST_ID                    RCUST_ID,
                                           B.ITEM_ID                     ITEM_ID,
                                           D.ITEM_NM                     ITEM_NM,
                                           D.STANDARD                    STANDARD,
                                           B.QTY                         QTY,
                                           B.DANGA                       DANGA,
                                           B.AMT                         AMT,
                                           B.VAT                         VAT,
                                           B.DC_AMT                      DC_AMT,
                                           B.DC_QTY                      DC_QTY,
                                           B.DC_EN_YN                    DC_EN_YN,
                                           0                             SUKUM,
                                           (NVL(B.AMT,0) + NVL(B.VAT,0)) TOT,
                                           A.DEAL_NO                     DEAL_NO,
                                           DECODE(E.GUMAE_GB,'12',E.BIGO,'13',E.BIGO,'') BIGO,
                                           B.INPUT_SEQ                    INPUT_SEQ
                                      FROM SALE0207 A, 
                                           SALE0208 B, 
                                           SALE0004 D,
                                           SALE0203 E
                                     WHERE A.DEAL_NO = B.DEAL_NO
                                       AND A.YMD     = B.YMD
                                       AND B.ITEM_ID = D.ITEM_ID
                                       AND A.YMD BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                                       AND A.CUST_ID = in_CUST_CD 
                                       AND A.GUMAE_NO = E.GUMAE_NO(+)
                                    UNION ALL /*  수금(할인) 내역 */
                                    SELECT 2                             SEQ,
                                           A.YMD                         YMD,
                                           A.CUST_ID                     CUST_ID,
                                           A.RCUST_ID                    RCUST_ID,
                                           DECODE(A.JUNPYO_GB,'01','현금','10','매출할인','20','부실채권','30','거래이관','35','대손상각','40','잡수익','45','손실정리'
                                                             ,'50','부도어음대체','55','폐업상품입고','기타수금')
                                                                         ITEM_ID,
                                           BIGO                          ITEM_NM,
                                           ''                            STANDARD,
                                           0                             QTY,
                                           0                             DANGA,
                                           0                             AMT,
                                           0                             VAT,
                                           0                             DC_AMT,
                                           0                             DC_QTY,
                                           ''                            DC_EN_YN,
                                           CASH_AMT                      SUKUM,
                                           NVL(-(CASH_AMT),0)            TOT,
                                           ''                            DEAL_NO,
                                           ''                            BIGO,
                                           ''                            INPUT_SEQ
                                      FROM SALE0401  A
                                     WHERE A.YMD         BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                                       AND A.CUST_ID     = in_CUST_CD  
                                         AND A.CASH_AMT      <> 0
                                    UNION ALL
                                    SELECT 2                             SEQ,
                                           A.YMD                         YMD,
                                           A.CUST_ID                     CUST_ID,
                                           A.RCUST_ID                    RCUST_ID,
                                           C.CODE1_NM                    ITEM_ID,                                             
                                           B.BILL_NO                     ITEM_NM,
                                           ''                            STANDARD,
                                           0                             QTY,
                                           0                             DANGA,
                                           0                             AMT,
                                           0                             VAT,
                                           0                             DC_AMT,
                                           0                             DC_QTY,
                                           ''                            DC_EN_YN,
                                           AMT                           SUKUM,
                                           NVL(-(AMT),0)                 TOT,
                                           ''                            DEAL_NO,
                                           DECODE(C.CODE1,'100','',TO_CHAR(B.END_YMD,'YYYYMMDD')) BIGO,
                                           ''                            INPUT_SEQ
                                      FROM SALE0402  B,
                                           SALE0401  A,
                                           (SELECT CODE1, CODE1_NM FROM  SALE0001 WHERE CODE_GB = '0007') C
                                     WHERE A.YMD         BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                                       AND A.JUNPYO_NO   = B.JUNPYO_NO
                                       AND A.CUST_ID     = in_CUST_CD 
                                       AND B.BILL_GB = C.CODE1(+))  A,
                                   (SELECT CUST_ID                  CUST_ID,
                                           NVL(SUM(BEFORE_AMT),0)   BEFORE_AMT
                                      FROM (SELECT CUST_ID,                   /*전월 잔액 */
                                                   BEFORE_AMT      BEFORE_AMT
                                              FROM SALE0306
                                             WHERE CUST_ID     = in_CUST_CD 
                                               AND YMD         = TO_DATE(SUBSTR(in_DT_FR,1,6)||'01', 'YYYY/MM/DD')
                                             UNION ALL
                                            SELECT CUST_ID,                  --금월의 조회조건 기간까지의 잔액
                                                   NVL(A.AMT,0) + NVL(A.VAT,0)  
                                                   BEFORE_AMT
                                              FROM SALE0207  B,
                                                   SALE0208  A
                                             WHERE A.DEAL_NO    = B.DEAL_NO
                                               AND A.YMD        = B.YMD
                                               AND B.CUST_ID    = in_CUST_CD  --IN (SELECT CUST_ID FROM SALE0003 WHERE CUST_NM LIKE '%'||NVL(in_CUST_NM, '%')||'%')
                                               AND A.YMD        >= TO_DATE(SUBSTR(in_DT_FR,1, 6)||'01', 'YYYY/MM/DD')--TO_DATE(TO_CHAR(in_DT_FR,'YYYY/MM')||'/01','YYYY/MM/DD')
                                               AND A.YMD        <  TO_DATE(in_DT_FR)
                                                 UNION all
                                            SELECT CUST_ID,     
                                                   (NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1  
                                                   BEFORE_AMT
                                              FROM SALE0401  A
                                             WHERE A.CUST_ID    = in_CUST_CD  --IN (SELECT CUST_ID FROM SALE0003 WHERE CUST_NM LIKE '%'||NVL(in_CUST_NM, '%')||'%')
                                               AND A.YMD        >= TO_DATE(SUBSTR(in_DT_FR,1, 6)||'01', 'YYYY/MM/DD')--TO_DATE(TO_CHAR(in_DT_FR,'YYYY/MM')||'/01','YYYY/MM/DD')
                                               AND A.YMD        <  TO_DATE(in_DT_FR)
                                          )
                                     GROUP BY CUST_ID          )  B,
                                   SALE0003                       C,
                                   SALE0003                       D,
                                  (SELECT B.SAWON_ID, B.SAWON_NM, B.DEPT_CD, C.DEPT_NM 
                                     FROM SALE0007 B, SALE0008 C  
                                    WHERE B.DEPT_CD = C.DEPT_CD)  E
                             WHERE C.CUST_ID     = in_CUST_CD 
                               AND C.CUST_ID    = A.CUST_ID(+)
                               AND C.CUST_ID    = B.CUST_ID(+)
                               AND A.RCUST_ID   = D.CUST_ID(+)
                               AND C.SAWON_ID   = E.SAWON_ID(+)
                              -- AND (E.DEPT_CD IN   (SELECT PART_CD FROM SALE0008D WHERE DEPT_CD = in_DEPT_CD) OR E.DEPT_CD LIKE (SELECT PART_CD FROM SALE0008D WHERE DEPT_CD = in_DEPT_CD AND PART_CD = '%'))
                               AND (NVL(A.TOT,0) <> 0 OR NVL(B.BEFORE_AMT,0) <> 0)                      
                              -- order by   nvl(out_CUST_ID,' '),nvl(out_YMD,' '),nvl(out_DEAL_NO,' '),nvl(out_INPUT_SEQ,' ')
                         )
                       
                    UNION ALL

                    --합계 --------------------------------------------------------------------------------------------------------                    
                    SELECT ''                                                         AS out_YM,
                           ''                                                     AS out_YMD,               -- 일자
                           ''                                                         AS out_CUST_ID,
                           ''                                                         AS out_RCUST_ID,
                           ''                                                         AS out_VOU_NO,
                           ''                                                         AS out_CUST_NM,
                           ''                                                         AS out_ADDR,
                           ''                                                         AS out_PRESIDENT,
                           ''                                                         AS out_SAWON_ID,
                           ''                                                         AS out_SAWON_NM,
                           ''                                                         AS out_RCUST_NM,
                           ''                                                         AS out_ITEM_ID,          -- 제품ID
                           ''                                                         AS out_ITEM_NM,          -- 제품명
                           '합계'                                                     AS out_STANDARD,         -- 규격
                           0                                                          AS out_QTY,              -- 수량
                           0                                                          AS out_DANGA,            -- 단가
                           0                                                          AS out_AMT,
                           0                                                          AS out_VAT,
                           SUM(NVL(A.SUKUM,0))                                        AS out_SUKUM,            -- 수금액
                           SUM(NVL(A.AMT,0) + nvl(A.VAT,0))                           AS out_TOT,              -- 합계금액
                           0                                                          AS out_BEFORE_AMT,       -- 이월금액
                           ''                                                         AS out_DEAL_NO,
                           ''                                                         AS out_INPUT_SEQ,
                           0                                                          AS out_DC_AMT,
                           0                                                          AS out_DC_QTY,
                           0                                                          AS out_DC_EN_AMT,
                           ''                                                         AS out_DC_EN_YN,
                           ''                                                         AS out_TEL,
                           ''                                                         AS out_BIGO,            -- 비고
                           ''                                                         AS out_DATEF,
                           ''                                                         AS out_DATET,
                           0                                                          AS out_JAN_AMT, --잔액
                           0                                                          AS out_TOT_DC_AMT       -- 매출할인
                      FROM (SELECT 1                             SEQ,
                                   A.YMD                         YMD,
                                   A.CUST_ID                     CUST_ID,
                                   A.RCUST_ID                    RCUST_ID,
                                   B.ITEM_ID                     ITEM_ID,
                                   D.ITEM_NM                     ITEM_NM,
                                   D.STANDARD                    STANDARD,
                                   B.QTY                         QTY,
                                   B.DANGA                       DANGA,
                                   B.AMT                         AMT,
                                   B.VAT                         VAT,
                                   B.DC_AMT                      DC_AMT,
                                   B.DC_QTY                      DC_QTY,
                                   B.DC_EN_YN                    DC_EN_YN,
                                   0                             SUKUM,
                                   (NVL(B.AMT,0) + NVL(B.VAT,0)) TOT,
                                   A.DEAL_NO                     DEAL_NO,
                                   DECODE(E.GUMAE_GB,'12',E.BIGO,'13',E.BIGO,'') BIGO,
                                   B.INPUT_SEQ                    INPUT_SEQ
                              FROM SALE0207 A, 
                                   SALE0208 B, 
                                   SALE0004 D,
                                   SALE0203 E
                             WHERE A.DEAL_NO = B.DEAL_NO
                               AND A.YMD     = B.YMD
                               AND B.ITEM_ID = D.ITEM_ID
                               AND A.YMD BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                               AND A.CUST_ID = in_CUST_CD 
                               AND A.GUMAE_NO = E.GUMAE_NO(+)
                            UNION ALL /*  수금(할인) 내역 */
                            SELECT 2                             SEQ,
                                   A.YMD                         YMD,
                                   A.CUST_ID                     CUST_ID,
                                   A.RCUST_ID                    RCUST_ID,
                                   DECODE(A.JUNPYO_GB,'01','현금','10','매출할인','20','부실채권','30','거래이관','35','대손상각','40','잡수익','45','손실정리'
                                                     ,'50','부도어음대체','55','폐업상품입고','기타수금')
                                                                 ITEM_ID,
                                   BIGO                          ITEM_NM,
                                   ''                            STANDARD,
                                   0                             QTY,
                                   0                             DANGA,
                                   0                             AMT,
                                   0                             VAT,
                                   0                             DC_AMT,
                                   0                             DC_QTY,
                                   ''                            DC_EN_YN,
                                   CASH_AMT                      SUKUM,
                                   NVL(-(CASH_AMT),0)            TOT,
                                   ''                            DEAL_NO,
                                   ''                            BIGO,
                                   ''                            INPUT_SEQ
                              FROM SALE0401  A
                             WHERE A.YMD         BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                               AND A.CUST_ID     = in_CUST_CD  
                                 AND A.CASH_AMT      <> 0
                            UNION ALL
                            SELECT 2                             SEQ,
                                   A.YMD                         YMD,
                                   A.CUST_ID                     CUST_ID,
                                   A.RCUST_ID                    RCUST_ID,
                                   C.CODE1_NM                    ITEM_ID,                                             
                                   B.BILL_NO                     ITEM_NM,
                                   ''                            STANDARD,
                                   0                             QTY,
                                   0                             DANGA,
                                   0                             AMT,
                                   0                             VAT,
                                   0                             DC_AMT,
                                   0                             DC_QTY,
                                   ''                            DC_EN_YN,
                                   AMT                           SUKUM,
                                   NVL(-(AMT),0)                 TOT,
                                   ''                            DEAL_NO,
                                   DECODE(C.CODE1,'100','',TO_CHAR(B.END_YMD,'YYYYMMDD')) BIGO,
                                   ''                            INPUT_SEQ
                              FROM SALE0402  B,
                                   SALE0401  A,
                                   (SELECT CODE1, CODE1_NM FROM  SALE0001 WHERE CODE_GB = '0007') C
                             WHERE A.YMD         BETWEEN TO_DATE(in_DT_FR, 'YYYY/MM/DD') AND TO_DATE(in_DT_TO, 'YYYY/MM/DD')
                               AND A.JUNPYO_NO   = B.JUNPYO_NO
                               AND A.CUST_ID     = in_CUST_CD 
                               AND B.BILL_GB = C.CODE1(+))  A,
                           (SELECT CUST_ID                  CUST_ID,
                                   NVL(SUM(BEFORE_AMT),0)   BEFORE_AMT
                              FROM (SELECT CUST_ID,                   /*전월 잔액 */
                                           BEFORE_AMT      BEFORE_AMT
                                      FROM SALE0306
                                     WHERE CUST_ID     = in_CUST_CD 
                                       AND YMD         = TO_DATE(SUBSTR(in_DT_FR,1,6)||'01', 'YYYY/MM/DD')
                                     UNION ALL
                                    SELECT CUST_ID,                  --금월의 조회조건 기간까지의 잔액
                                           NVL(A.AMT,0) + NVL(A.VAT,0)  
                                           BEFORE_AMT
                                      FROM SALE0207  B,
                                           SALE0208  A
                                     WHERE A.DEAL_NO    = B.DEAL_NO
                                       AND A.YMD        = B.YMD
                                       AND B.CUST_ID    = in_CUST_CD  --IN (SELECT CUST_ID FROM SALE0003 WHERE CUST_NM LIKE '%'||NVL(in_CUST_NM, '%')||'%')
                                       AND A.YMD        >= TO_DATE(SUBSTR(in_DT_FR,1, 6)||'01', 'YYYY/MM/DD')--TO_DATE(TO_CHAR(in_DT_FR,'YYYY/MM')||'/01','YYYY/MM/DD')
                                       AND A.YMD        <  TO_DATE(in_DT_FR)
                                         UNION all
                                    SELECT CUST_ID,     
                                           (NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1  
                                           BEFORE_AMT
                                      FROM SALE0401  A
                                     WHERE A.CUST_ID    = in_CUST_CD  --IN (SELECT CUST_ID FROM SALE0003 WHERE CUST_NM LIKE '%'||NVL(in_CUST_NM, '%')||'%')
                                       AND A.YMD        >= TO_DATE(SUBSTR(in_DT_FR,1, 6)||'01', 'YYYY/MM/DD')--TO_DATE(TO_CHAR(in_DT_FR,'YYYY/MM')||'/01','YYYY/MM/DD')
                                       AND A.YMD        <  TO_DATE(in_DT_FR)
                                  )
                             GROUP BY CUST_ID          )  B,
                           SALE0003                       C,
                           SALE0003                       D,
                          (SELECT B.SAWON_ID, B.SAWON_NM, B.DEPT_CD, C.DEPT_NM 
                             FROM SALE0007 B, SALE0008 C  
                            WHERE B.DEPT_CD = C.DEPT_CD)  E
                     WHERE C.CUST_ID     = in_CUST_CD 
                       AND C.CUST_ID    = A.CUST_ID(+)
                       AND C.CUST_ID    = B.CUST_ID(+)
                       AND A.RCUST_ID   = D.CUST_ID(+)
                       AND C.SAWON_ID   = E.SAWON_ID(+)
                       --AND (E.DEPT_CD IN   (SELECT PART_CD FROM SALE0008D WHERE DEPT_CD = in_DEPT_CD) OR E.DEPT_CD LIKE (SELECT PART_CD FROM SALE0008D WHERE DEPT_CD = in_DEPT_CD AND PART_CD = '%'))
                       AND (NVL(A.TOT,0) <> 0 OR NVL(B.BEFORE_AMT,0) <> 0)
                     
           )
           --order by   nvl(out_CUST_ID,' '),nvl(out_YMD,' '),nvl(out_DEAL_NO,' '),nvl(out_INPUT_SEQ,' ')
           --order by   out_CUST_ID,out_YMD,out_DEAL_NO,out_INPUT_SEQ
           ;
        
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
