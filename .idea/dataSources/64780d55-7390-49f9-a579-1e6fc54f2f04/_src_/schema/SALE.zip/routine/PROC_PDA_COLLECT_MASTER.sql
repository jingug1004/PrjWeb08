CREATE PROCEDURE      PROC_PDA_COLLECT_MASTER
  (in_flag IN VARCHAR2 DEFAULT NULL,
  in_ymd IN date,
  in_junpyo_no IN VARCHAR2 default NULL,
  in_cust_id IN VARCHAR2 DEFAULT NULL, 
  in_rcust_id IN VARCHAR2 DEFAULT NULL, 
  in_cash_amt IN VARCHAR2 DEFAULT NULL,
  in_bill_amt IN VARCHAR2 DEFAULT NULL, 
  in_sawon_id IN VARCHAR2 DEFAULT NULL, 
  in_bigo IN VARCHAR2 DEFAULT NULL,
  out_junpyo_no OUT VARCHAR2
        )
IS
    ll_max number := 0;
    ll_count number := 0;
    
    V_junpyo_no VARCHAR2(20);
    V_sawon_id VARCHAR2(20);
BEGIN
-- raise_application_error (-20000,'통제 여신 규정을 위반 하였습니다.')
if in_flag = 'I' or in_flag = '' then
   --중지거래처  통제(다른거래처에 수금입력 오류방지) 
   
   SELECT COUNT(*) INTO ll_count  FROM SALE0003 WHERE CUST_ID = in_cust_id AND NVL(USE_YN,'Y') <> 'Y';
   IF ll_count > 0 THEN
      raise_application_error (-20000,'<중지된 거래처입니다. 담당자와 상의하십시요.>');
   END IF;

--    select count(*) as cnt 
--    into ll_count
--    from sale.sale0402i
--    where ymd > add_months(sysdate, -2)
--    and cust_id = in_CUST_ID and rcust_id = in_CUST_ID;

--    if ll_count = 0 then
--        raise_application_error (-20000,'<2개월간 잔고 확인이 없습니다.>');
--    end if;



    SP_SYS100C_MAX_VALUE('SALE0401', to_char(in_ymd, 'yyyyMMdd'), null,null, null, null, ll_max );
    dbms_output.put_line( in_ymd  );

    dbms_output.put_line(ll_max  );

     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패 SP_SYS100C_MAX_VALUE');
            ROLLBACK;
            return;
     END IF;
 
    V_junpyo_no:= TO_CHAR(in_YMD,'YYYYMMDD')||TRIM(TO_CHAR(ll_max,'0000'));
    
    dbms_output.put_line( V_junpyo_no  );
    -- 담당사원  ID 가져오기
    select  sawon_id 
    into V_sawon_id
    from sale.sale0003
    where cust_id = in_CUST_ID ;
    
    
    /*INSERT INTO SALE.SALE0401_20100129 (
       YMD, JUNPYO_GB, JUNPYO_NO, 
       CUST_ID, RCUST_ID, CASH_AMT, 
       BILL_AMT, SAWON_ID, INPUT_YMD, 
       MAGAM_YN, BIGO, ACC_JUNPYO_CD, 
       LOG_DATE, INPUT_ID) 
    VALUES ( , , ,
        , , ,
        , , ,
        , , ,
        , )    */
    
    INSERT INTO SALE.SALE0401 (
       YMD, JUNPYO_GB, JUNPYO_NO, 
       CUST_ID, RCUST_ID, 
       CASH_AMT,
       BILL_AMT
       ,  SAWON_ID,INPUT_ID, INPUT_YMD, BIGO) 
    VALUES ( in_ymd, '01',V_junpyo_no,
        in_cust_id, in_rcust_id, 
        decode( NVL(in_cash_amt, ''),'','0',in_CASH_AMT), 
        decode( NVL(in_bill_amt, ''),'','0',in_BILL_AMT), 
        V_sawon_id,in_sawon_id,sysdate ,in_bigo );
        
     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패  INSERT INTO SALE.SALE0401');
            ROLLBACK;
            return;
     END IF;
        out_junpyo_no := V_junpyo_no;
else

     /*UPDATE SALE.SALE0401
    SET    YMD           = :YMD,
           JUNPYO_GB     = :JUNPYO_GB,
           JUNPYO_NO     = :JUNPYO_NO,
           CUST_ID       = :CUST_ID,
           RCUST_ID      = :RCUST_ID,
           CASH_AMT      = :CASH_AMT,
           BILL_AMT      = :BILL_AMT,
           SAWON_ID      = :SAWON_ID,
           INPUT_YMD     = :INPUT_YMD,
           MAGAM_YN      = :MAGAM_YN,
           BIGO          = :BIGO,
           ACC_JUNPYO_CD = :ACC_JUNPYO_CD,
           LOG_DATE      = :LOG_DATE,
           INPUT_ID      = :INPUT_ID
    WHERE  JUNPYO_NO     = :JUNPYO_NO
    */
    
    UPDATE SALE.SALE0401
    SET    YMD           = in_YMD,
           CUST_ID       = in_CUST_ID,
           RCUST_ID      = in_RCUST_ID,
           CASH_AMT      = decode( NVL(in_CASH_AMT, ''),'','0',in_CASH_AMT),
           BILL_AMT      = decode( NVL(in_BILL_AMT, ''),'','0',in_BILL_AMT),
           SAWON_ID      = in_SAWON_ID,
           BIGO          = in_bigo
    WHERE  JUNPYO_NO     = in_junpyo_no;

end if;
        
        
    
 IF SQLCODE <> 0 THEN
     dbms_output.put_line('실패 UPDATE SALE.SALE0401');
        ROLLBACK;
        return;
 END IF;
end;

/
