CREATE FUNCTION      F_ITEM_AVERAGE_SALE  
(
    in_CUST_CD  IN VARCHAR2,
    in_RCUST_CD  IN VARCHAR2,
    in_FROM_YMD IN DATE,
    in_TO_YMD IN DATE,    
    in_ITEM_ID IN VARCHAR2,
    in_FLAG IN VARCHAR2
) 
RETURN NUMBER IS
        
        V_ITEM_AVG_QTY   NUMBER;       
        V_JUMUN_LIMIT  NUMBER;        
       
        V_MONTH_QTY_1   NUMBER;  --승인
        V_MONTH_QTY_2   NUMBER;  --접수        
        
        V_CNT_1               NUMBER;
        V_CNT_2               NUMBER;
        V_CHECK            VARCHAR2(7); 
        
        V_CURR_ERROR VARCHAR2(1000) ;
        USER_ERR     EXCEPTION; 
    
BEGIN

        /*----------------------------------------------------------------------------------------
        CHOE 20130820
        주문 월평균 수량 계산해 오기
        주문의 월평균 수량을 계산에 주문 허용한도를 CHECK 한다.
        
        in_CUST_CD - 거래처
        in_RCUST_CD - 매출처
        in_FROM_YMD - 기간 시작일
        in_TO_YMD - 기간 종료일  한달인 경우 FROM과 TO가 한달 차이가 발생되면 한달 월평균 수량을 구함
        in_ITEM_ID - 주문가능한 품목
        in_FLAG - Y는 평균을 구하고 N값만 찾는다
        
        SUM - 1. 해당월(주문등록월) 제품별판매현황의 주문 수량을 가져오고
                  2. 해당월의 주문되었지만 미승인 건에 대해서 가져온다
                  
                  1번과 2번을 더해 해당월의 총 주문 수량을 알려준다.
                  2번에 미승건으로 한정한 이유른 승인이 난 경우 OR 승인후 주문수량을 수정한 경우에는 
                  제품별판매현황의 수량을 이용하기 위해서
        ----------------------------------------------------------------------------------------*/
      
        SELECT CUST_ID, JUMUN_LIMIT
        INTO V_CHECK, V_JUMUN_LIMIT
        FROM SALE.SALE0003
        WHERE CUST_ID = in_RCUST_CD; 
                   
        V_MONTH_QTY_1 := 0;
        V_MONTH_QTY_2 := 0;        

        IF in_FLAG = 'Y' OR in_FLAG = 'SUM' THEN
                SELECT COUNT(*)
                INTO V_CNT_1
                FROM SALE.SALE0204 B
                WHERE GUMAE_NO IN( 
                                                    SELECT A.GUMAE_NO
                                                    FROM SALE.SALE0203 A
                                                    WHERE A.CUST_ID  = in_CUST_CD
                                                    AND A.RCUST_ID = in_RCUST_CD                                                    
                                                    AND A.YMD BETWEEN in_FROM_YMD AND in_TO_YMD
                                                )
                AND B.ITEM_ID = in_ITEM_ID;  
                    
                
                IF V_CNT_1 >= 1 THEN 
                        /*주문승인된 내용 수량*/ 
                        SELECT NVL(SUM(B.QTY), 0)
                        INTO V_MONTH_QTY_1
                        FROM SALE.SALE0204 B
                        WHERE GUMAE_NO IN( 
                                                            SELECT A.GUMAE_NO
                                                            FROM SALE.SALE0203 A
                                                            WHERE A.CUST_ID  = in_CUST_CD
                                                            AND A.RCUST_ID = in_RCUST_CD                                                    
                                                            AND A.YMD BETWEEN in_FROM_YMD AND in_TO_YMD
                                                        )
                        AND B.ITEM_ID = in_ITEM_ID
                        GROUP BY B.ITEM_ID;                       
                END IF;        
        END IF;
                
        IF in_FLAG = 'N' THEN
                SELECT COUNT(*)
                INTO V_CNT_2
                --FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
                FROM SALE.SALE0203 A, SALE.SALE0204 B
                WHERE A.CUST_ID  = in_CUST_CD
                AND A.RCUST_ID = in_RCUST_CD               
                AND A.GUMAE_NO = B.GUMAE_NO 
                AND B.ITEM_ID = in_ITEM_ID
                AND A.YMD BETWEEN in_FROM_YMD AND in_TO_YMD
                ; 
                
                   
                IF V_CNT_2 >= 1 THEN 
                        SELECT NVL(SUM(B.QTY),0)
                        INTO V_MONTH_QTY_2
                        --FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
                        FROM SALE.SALE0203 A, SALE.SALE0204 B
                        WHERE A.CUST_ID  = in_CUST_CD
                        AND A.RCUST_ID = in_RCUST_CD               
                        AND A.GUMAE_NO = B.GUMAE_NO 
                        AND B.ITEM_ID = in_ITEM_ID
                        AND A.YMD BETWEEN in_FROM_YMD AND in_TO_YMD
                        GROUP BY B.ITEM_ID ;    
                END IF;                      
        END IF; 
        
        
        IF in_FLAG = 'SUM' THEN
                SELECT COUNT(*)
                INTO V_CNT_2
                FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
                WHERE A.CUST_ID  = in_CUST_CD
                AND A.RCUST_ID = in_RCUST_CD               
                AND A.GUMAE_NO = B.GUMAE_NO 
                AND B.ITEM_ID = in_ITEM_ID
                AND A.ACCEPT_YN = 'Y'   --승인구분- 'Y' 초기상태, 'S' 승인상태 
                AND A.YMD BETWEEN in_FROM_YMD AND in_TO_YMD
                ; 
                
                   
                IF V_CNT_2 >= 1 THEN 
                        SELECT NVL(SUM(B.QTY),0)
                        INTO V_MONTH_QTY_2
                        FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
                        WHERE A.CUST_ID  = in_CUST_CD
                        AND A.RCUST_ID = in_RCUST_CD               
                        AND A.GUMAE_NO = B.GUMAE_NO 
                        AND B.ITEM_ID = in_ITEM_ID
                        AND A.ACCEPT_YN = 'Y'   --승인구분- 'Y' 초기상태, 'S' 승인상태             
                        AND A.YMD BETWEEN in_FROM_YMD AND in_TO_YMD
                        GROUP BY B.ITEM_ID ;    
                END IF;                      
        END IF;             
        
        
        V_ITEM_AVG_QTY := NVL(V_MONTH_QTY_1, 0) + NVL(V_MONTH_QTY_2,0);      
        DBMS_OUTPUT.PUT_LINE('F_ITEM_AVERAGE_SALE  V_ITEM_AVG_QTY: '||V_ITEM_AVG_QTY||' ,V_MONTH_QTY_1: '||V_MONTH_QTY_1||' ,V_MONTH_QTY_2: '||V_MONTH_QTY_2); 
        
        /*2. 3개월 평균을 구하는 경우에는 허용한도를 곱하고 3개월로 나눠준다.*/
        IF in_FLAG = 'Y' THEN
                V_ITEM_AVG_QTY := ROUND ( V_ITEM_AVG_QTY  / 3 );
                V_ITEM_AVG_QTY :=  ROUND ( V_ITEM_AVG_QTY * ( V_JUMUN_LIMIT / 100 ));                
        END IF;
        
        
        RETURN V_ITEM_AVG_QTY;
    

END F_ITEM_AVERAGE_SALE;

/
