CREATE PROCEDURE      SP_X_INFO_INSERTCUSTOMERINFO
(
    in_CUST_ID        IN VARCHAR2,
    in_CUSTOMER_ID    IN VARCHAR2,
    in_CUSTOMER_NM    IN VARCHAR2,
    in_SEX            IN VARCHAR2,
    in_BIRTH_DAY      IN VARCHAR2,
    in_ACT_BIRTH_DAY  IN VARCHAR2,
    in_MARRY_YN       IN VARCHAR2,
    in_MARRY_DAY      IN VARCHAR2,
    in_CHILD_KIND     IN VARCHAR2,
    in_DISPOSITION    IN VARCHAR2,
    in_RELIGION       IN VARCHAR2,
    in_HIGHSCHOOL     IN VARCHAR2,
    in_UNIVERSITY     IN VARCHAR2,
    in_ZIP            IN VARCHAR2,
    in_ADDRESS1       IN VARCHAR2,
    in_ADDRESS2       IN VARCHAR2,
    in_TEL            IN VARCHAR2,
    in_MOBILE         IN VARCHAR2,
    in_FAX            IN VARCHAR2,
    in_EMAIL          IN VARCHAR2,
    in_CAR_NO         IN VARCHAR2,
    in_CAR_COLOR      IN VARCHAR2,
    in_FOREIGN        IN VARCHAR2,
    in_RANK           IN VARCHAR2,
    in_LESSON         IN VARCHAR2,
    in_HOSPITAL       IN VARCHAR2,
    in_MAJOR          IN VARCHAR2,
    in_MAIN_BUYING    IN VARCHAR2,
    in_HUMAN_REL      IN VARCHAR2,
    in_HOBBY          IN VARCHAR2,
    in_TABOO_LIST     IN VARCHAR2,
    in_GITA           IN VARCHAR2,
    out_CODE         OUT NUMBER,
    out_MSG          OUT VARCHAR2
)
IS
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INFO_INSERTCUSTOMERINFO
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 고객정보 저장 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	INSERT INTO SALE.CRM_MASTER (
			   CUST_ID, CUSTOMER_ID, CUSTOMER_NM, SEX, BIRTH_DAY, ACT_BIRTH_DAY, 
			   MARRY_YN, MARRY_DAY, CHILD_KIND, DISPOSITION, RELIGION, HIGHSCHOOL, 
			   UNIVERSITY, ZIP, ADDRESS1, ADDRESS2, TEL, MOBILE, 
			   FAX, EMAIL, CAR_NO, CAR_COLOR, FOREIGN_STUDY_YN, RANK, 
			   LESSON, HOSPITAL, MAJOR, MAIN_BUYING, HUMAN_REL, HOBBY, 
			   TABOO_LIST, GITA) 
			 VALUES (in_CUST_ID         
			        ,in_CUSTOMER_ID    
				    ,in_CUSTOMER_NM    
				    ,in_SEX            
				    ,in_BIRTH_DAY      
				    ,in_ACT_BIRTH_DAY  
				    ,in_MARRY_YN       
				    ,in_MARRY_DAY      
				    ,in_CHILD_KIND     
				    ,in_DISPOSITION    
				    ,in_RELIGION       
				    ,in_HIGHSCHOOL     
				    ,in_UNIVERSITY     
				    ,in_ZIP            
				    ,in_ADDRESS1       
				    ,in_ADDRESS2       
				    ,in_TEL            
				    ,in_MOBILE         
				    ,in_FAX            
				    ,in_EMAIL          
				    ,in_CAR_NO         
				    ,in_CAR_COLOR      
				    ,in_FOREIGN        
				    ,in_RANK           
				    ,in_LESSON         
				    ,in_HOSPITAL       
				    ,in_MAJOR          
				    ,in_MAIN_BUYING    
				    ,in_HUMAN_REL      
				    ,in_HOBBY          
				    ,in_TABOO_LIST     
				    ,in_GITA   
			     );
	
	IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 INSERT ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 저장';
        COMMIT;
	END IF; 
    
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK;
END ;
/
