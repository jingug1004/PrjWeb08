CREATE PROCEDURE      SP_SFA_WIBANORDER_CONFLIST   
(
    in_SAWON_ID          IN  VARCHAR2,    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 회전일위반 주문 승인용 리스트조회
 호출프로그램 : 일일방문화면에서 내역이 있을때 팝업에서 호출된다.                    
 수정사항     :
  2015.04.15 kta 총괄지점장은 위반주문승인이 하위지점들 모두의 것이 보이도록 처리함.
                (김민진 차장이 중부총괄지점장과 원주팀장을 겸직하면서 위반주문승인해줘야 해서)  
  2015.06.08 KTA  - 임시팀장 직책코드 추가관련 수정                
 ---------------------------------------------------------------------------*/    

    v_num               NUMBER;
    v_insa_sawon_id     VARCHAR2(7);
    v_insa_dept_cd      VARCHAR2(4);
    v_assgn_cd          VARCHAR2(5);
    
BEGIN
 
    --로그인사원의 인사사번   
    select insa_sawon_id into v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID and gubun = 'Y';
                
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    select assgn_cd into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
                
    --인사기본테이블에서 총괄팀장 이면 한레벨 상위부서코드를 찾고 팀장이면 자기부서를 찾는다.
    if v_assgn_cd = '27010' or v_assgn_cd = '27020' or v_assgn_cd = '27025' or v_assgn_cd = '27018' or v_assgn_cd = '27026' then   --본부장,관리이사 총괄지점장 부본부장 선임지점장
        select dept_cd
          into v_insa_dept_cd  
          from hr_co_depart_0 
         where use_yn = 'Y' and level = 2
       connect by dept_cd = prior up_dept_cd start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id);
                                   
    elsif (v_assgn_cd = '27027' or v_assgn_cd = '27030' or v_assgn_cd = '27035' ) then --팀장,임시팀장 
        select dept_cd into v_insa_dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    end if; 
    
    
    -- 로그인한 사원의 납품처에 납품된 제품중 거래처별단가테이블에서 담당제품으로 주문된것들...
    SELECT COUNT(*)
      INTO v_num
      from sale_on.sale0203 a
     where a.ymd >= to_date('20140301','yyyymmdd')  --이날 이후로 회전일위반주문승인여부 체크하기로 하였음.
       and a.wiban_order_req_yn  = 'Y'   --요청여부
       and a.wiban_order_conf_yn = '0'  --승인여부0-대기,1-승인,2-반려
       and a.sawon_id in (  select sawon_id --팀장인경우 하위 모든 사원(영업사원테이블)
                              from sale0007 
                             where insa_sawon_id in (
                                                      select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                       where dept_cd in (   select dept_cd from hr_co_depart_0
                                                                           connect by prior dept_cd = up_dept_cd
                                                                             start with dept_cd = v_insa_dept_cd
                                                                         )
                                                         and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                     )
                               and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                         )
       and v_assgn_cd in ('27025','27027','27030','27035','27018','27026');  --총괄지점장,팀장,임시팀장 부본부장 선임지점장                           
       
       
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_WIBANORDER_CONFLIST','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||' / v_num:'||to_char(v_num));
--COMMIT;
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
            
        OPEN out_RESULT FOR        
        select a.gumae_no              AS out_GUMAE_NO
              ,a.ymd                   AS out_ORDER_DATE
              ,c.cust_nm               AS out_CUST_NM
              ,decode(a.wiban_kind,'1','회전일','2','수량') AS out_WIBAN_KIND             
              ,f_sawon_nm(a.sawon_id)   AS out_SAWON_NM
              ,a.pbigo                  AS out_PBIGO 
              ,F_RATE_DAY_BEFOREMONTH(to_char(add_months(sysdate,-1),'yyyymm'),A.CUST_ID)  AS out_RATE_DAY --에이징의회전일
              ,(select code1_nm from sale0001 where code_gb = '0068' ) AS out_CONTROL_RATE_DAY            
          from sale_on.sale0203 a
              ,sale0003 c
         where a.cust_id  = c.cust_id
           and a.ymd >= to_date('20140301','yyyymmdd')  --이날 이후로 회전일위반주문승인여부 체크하기로 하였음.
           and a.wiban_order_req_yn  = 'Y'   --요청여부
           and a.wiban_order_conf_yn = '0'  --승인여부0-대기,1-승인,2-반려
           and a.sawon_id in (  select sawon_id --팀장인경우 하위 모든 사원(영업사원테이블)
                                  from sale0007 
                                 where insa_sawon_id in (
                                                          select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                           where dept_cd in (   select dept_cd from hr_co_depart_0
                                                                               connect by prior dept_cd = up_dept_cd
                                                                                 start with dept_cd = v_insa_dept_cd
                                                                             )
                                                             and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                         )
                                   and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                             )
           and v_assgn_cd in ('27025','27027','27030','27035','27018','27026');  --총괄지점장,팀장,임시팀장 부본부장 선임지점장 
       
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
