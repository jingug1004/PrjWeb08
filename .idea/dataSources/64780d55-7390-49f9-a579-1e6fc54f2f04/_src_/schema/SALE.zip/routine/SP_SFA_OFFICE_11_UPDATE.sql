CREATE PROCEDURE      SP_SFA_OFFICE_11_UPDATE    -- office.Decision : 결재승인처리 : SALE.SP_SFA_OFFICE_11_UPDATE
(   
    in_SAWON_ID      IN  VARCHAR2,
    in_DOCNO            IN  VARCHAR2,
    in_D_STATUS       IN  VARCHAR2,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2
)
IS
        V_NUM                                         NUMBER;        
        V_SALE0007_INSA_SAWON_ID       VARCHAR2(10); -- 중간 연결
        V_TCMUSR_UNO                           VARCHAR2(10); -- 그룹웨어 코드로 변환
        V_LAST_APV_UNO                         VARCHAR2(10); -- 마지막결재자
        V_NEXT_APV_SEQ                         VARCHAR2(10); -- 다음 결재 자
        V_NEXT_APV_STS                         VARCHAR2(2);   -- 다음 결재자의 결재상태 
        
        V_D_STATUS                                VARCHAR2(5); -- 나의결재상태   
        V_NOW_STATUS                           VARCHAR2(5); -- 이미 저장된 나의결재상태   
        V_NEXT_D_STATUS                       VARCHAR2(5); -- 다음결재상태   
        V_LST_PROC_RSLT                        VARCHAR2(5); -- 문서결재상태 
        
        SAWON_ID_NULL                          EXCEPTION;      
        DOCNO_NULL                               EXCEPTION;
        D_STATUS_NULL                          EXCEPTION;
        ERROR_EXCEPTION                      EXCEPTION;
    
BEGIN

        /*  0. PARAMETER 확인        */
        IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
                RAISE SAWON_ID_NULL;
        END IF;
        
        IF in_DOCNO IS NULL OR TRIM(in_DOCNO) = '' THEN
                RAISE DOCNO_NULL;
        END IF;
    
        IF in_D_STATUS IS NULL OR TRIM(in_D_STATUS) = '' THEN
                RAISE D_STATUS_NULL;
        END IF;
        

        /* 1-1. 영업사원번호  -> 인사사원번호 변경 */
        BEGIN
                SELECT INSA_SAWON_ID
                INTO V_SALE0007_INSA_SAWON_ID 
                FROM SALE.SALE0007 
                WHERE SAWON_ID = in_SAWON_ID;
        EXCEPTION WHEN OTHERS THEN
                out_CODE := 1;
                out_MSG := '<인사사원번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END;
        
        IF V_SALE0007_INSA_SAWON_ID = '' THEN
                out_CODE := 1;
                out_MSG := '<인사사원번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END IF;
              
          
        /* 1-2. 인사사원번호 -> 그룹웨어 UNO 변경 */
        BEGIN                
                SELECT UNO 
                INTO V_TCMUSR_UNO 
                FROM HANAGW.TCMUSR 
                WHERE LOIN_USID = V_SALE0007_INSA_SAWON_ID;                
        EXCEPTION WHEN OTHERS THEN
                out_CODE := 1;
                out_MSG := '<그룹웨어번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END;   
        
        IF V_TCMUSR_UNO = '' THEN
                out_CODE := 1;
                out_MSG := '<인사사원번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END IF;         

        /*2. 해당 자료 확인 */
        BEGIN
               SELECT COUNT(*)  
                INTO V_NUM
                 FROM HANAGW.TGWEDAPV   
                          ,HANAGW.TGWEDDOC 
             WHERE ( tgwedapv.docno = tgweddoc.docno )  
                 AND ( tgwedapv.apv_uno = V_TCMUSR_UNO )  
                 AND ( tgweddoc.docno = in_DOCNO)            
                  AND ( tgweddoc.lst_proc_rslt in ('01','10','11') )              --결재상인, 진행중, 완결 문서만
                 AND ( tgwedapv.apv_knd <> '3') 
                 AND ( tgwedapv.apv_sts in ('01','11') )   --결재상신와 승인완료 경우만  sp_sfa_office_11과 같은 조회
            ORDER BY tgweddoc.docno DESC ; 
        EXCEPTION WHEN OTHERS THEN
                out_CODE := 1;
                out_MSG := '<결재문서를 조회 중에 err가 발생 되었습니다. 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END;  
       
       
        --out_COUNT := V_NUM;
        --DBMS_OUTPUT.put_line('out_COUNT:'||to_char(out_COUNT));
    
        IF (V_NUM = 0) THEN
                out_CODE := 1;
                out_MSG := '결재할 문서가  없습니다.';
        ELSIF (V_NUM >= 1) THEN
                
                /* 결재 action을 결정한다. */
                V_D_STATUS := '';
                V_NEXT_D_STATUS := '';
                
                IF in_D_STATUS = 'approve' THEN  --승인
                        V_D_STATUS := '11';
                        V_NEXT_D_STATUS := '01';                       
                ELSIF in_D_STATUS = 'approve_cancel' THEN  --승인취소
                        V_D_STATUS := '01';
                        V_NEXT_D_STATUS := '00';                       
                /*ELSIF in_D_STATUS = 'return' THEN  --반려    
                        V_D_STATUS := '21';
                ELSIF in_D_STATUS = 'return_cancel' THEN  --반려취소
                        V_D_STATUS := '01';     
                ELSIF in_D_STATUS = 'delay' THEN  --보류
                        V_D_STATUS := '22';*/
                ELSE              
                        out_CODE := 1;
                        out_MSG := '<결재문서처리 중에 err가 발생 되었습니다. 관련부서에 문의 하세요.>'; 
                        RAISE ERROR_EXCEPTION;
                END IF;
                
                
                /* 나의 결재상태가 같은 결재를 진행 하려고 하면 RETURN 한다. */
                BEGIN                         

                        SELECT APV_STS 
                        INTO V_NOW_STATUS 
                        FROM HANAGW.TGWEDAPV
                        WHERE APV_UNO = V_TCMUSR_UNO
                        AND DOCNO = in_DOCNO 
                        AND APV_KND IN ('1', '2');  --결재, 협조선 중에     
                                        
                EXCEPTION WHEN OTHERS THEN
                        out_CODE := 1;
                        out_MSG := '<결재 상태를 확인 중에 중에 ERR가 발생되었습니다.>'; 
                        RAISE ERROR_EXCEPTION;
                END;        

                IF V_D_STATUS = V_NOW_STATUS THEN
                        out_CODE := 1;
                        out_MSG := '<이미 같은 결재 상태를 진행 하였습니다.>'; 
                        RAISE ERROR_EXCEPTION;
                END IF;


                /* 0. 나의 action이 가능한 상태인가 ?  
                        나보다 뒤에 있는 결재자가 진행한 경우 난 action을 할수 없다. 
                        내가 마지막 결재자 인가? 나보다 위의 결재가 있는가? 판단.*/
                V_LAST_APV_UNO := '';  
                BEGIN                         

                        SELECT APV_UNO 
                        INTO V_LAST_APV_UNO 
                        FROM HANAGW.TGWEDAPV
                        WHERE APV_SEQ = (
                                                        SELECT MAX(APV_SEQ)
                                                        FROM HANAGW.TGWEDAPV
                                                        WHERE DOCNO = in_DOCNO
                                                        AND APV_KND IN ('1', '2')  --결재, 협조선 중에 
                                                      )
                        AND DOCNO = in_DOCNO 
                        AND APV_KND IN ('1', '2');  --결재, 협조선 중에     
                                        
                EXCEPTION WHEN OTHERS THEN
                        out_CODE := 1;
                        out_MSG := '<결재문서처리 중에 err가 발생 되었습니다. 관련부서에 문의 하세요.>'; 
                        RAISE ERROR_EXCEPTION;
                END;                  
                
                
                /* 내가 마지막 결재자 인경우 */
                IF V_TCMUSR_UNO = V_LAST_APV_UNO THEN                  


                        /* 결재선 처리 : 나의 결재선 */    
                        BEGIN            
                                UPDATE HANAGW.TGWEDAPV SET APV_DTM = SYSDATE
                                                                                  ,APV_STS = V_D_STATUS              
                                WHERE APV_UNO = V_TCMUSR_UNO
                                    AND DOCNO = in_DOCNO   
                                    AND APV_KND IN ('1', '2');  -- 결재 OR 참조     
                        EXCEPTION WHEN OTHERS THEN
                                out_CODE := 1;
                                out_MSG := '<나의 결재선 처리중에 ERR 발생 되었습니다. 관련부서에 문의 하세요.>'; 
                                RAISE ERROR_EXCEPTION;
                        END;  
                         
                        /* 결재문서 완결 처리 : 결재상태와 문서상태가 같은 값이다.*/
                        BEGIN
                                V_LST_PROC_RSLT := V_D_STATUS;  
                                UPDATE  HANAGW.TGWEDDOC SET LST_PROC_RSLT = V_LST_PROC_RSLT  --11번은 완결 문서 결재 종료                      
                                                                                   ,LST_PROC_DT = TO_CHAR(SYSDATE, 'YYYYMMDD')
                                WHERE DOCNO = in_DOCNO;
                        EXCEPTION WHEN OTHERS THEN
                                out_CODE := 1;
                                out_MSG := '<문서 완료 처리중에 ERR 발생 되었습니다. 관련부서에 문의 하세요.>'; 
                                RAISE ERROR_EXCEPTION;
                        END;     
                                 

                /* 내가 마지막 결재가 아닌 경우 (뒤에 결재 자가 있음 : 상위결재자 조회)*/             
                ELSE

                        V_NEXT_APV_SEQ := '';                     
                        V_NEXT_APV_STS := '';
                        BEGIN                               
                                
                                SELECT APV_SEQ, APV_STS
                                INTO V_NEXT_APV_SEQ, V_NEXT_APV_STS 
                                FROM HANAGW.TGWEDAPV
                                WHERE APV_SEQ = (
                                                        SELECT APV_SEQ + 1
                                                        FROM HANAGW.TGWEDAPV                                                        
                                                        WHERE APV_UNO = V_TCMUSR_UNO  
                                                        AND DOCNO = in_DOCNO
                                                        AND APV_KND IN ('1', '2')  --결재, 협조선 중에 
                                                      )
                                AND DOCNO = in_DOCNO 
                                AND APV_KND IN ('1', '2');  --결재, 협조선 중에  
                                                   
                        EXCEPTION WHEN OTHERS THEN
                                out_CODE := 1;
                                out_MSG := '<결재문서처리 중에 err가 발생 되었습니다. 관련부서에 문의 하세요.>'; 
                                RAISE ERROR_EXCEPTION;
                        END;     
                        
                        --IF V_NEXT_APV_SEQ <> '' AND V_NEXT_APV_STS <> '' THEN

                                /* 다음 결재자  ACTION을 하기 전엔 가능 */
                                IF V_NEXT_APV_STS = '00' OR V_NEXT_APV_STS = '01' THEN   

                                        /* 결재선 처리 : 나의 결재선 */   
                                        BEGIN             
                                                UPDATE HANAGW.TGWEDAPV SET APV_DTM = DECODE(V_D_STATUS, '11', SYSDATE, '')
                                                                                                  ,APV_STS = V_D_STATUS              
                                                WHERE APV_UNO = V_TCMUSR_UNO
                                                    AND DOCNO = in_DOCNO   
                                                    AND APV_KND IN ('1', '2');  -- 결재 OR 참조
                                        EXCEPTION WHEN OTHERS THEN
                                                out_CODE := 1;
                                                out_MSG := '<ACTION 나의 결재 처리중에 ERR 발생 되었습니다. 관련부서에 문의 하세요.>'; 
                                                RAISE ERROR_EXCEPTION;
                                        END;    

                                        /* 결재선 처리 : 다음 결재선 */      
                                        BEGIN          
                                                UPDATE HANAGW.TGWEDAPV SET APV_STS = V_NEXT_D_STATUS             
                                                WHERE APV_SEQ = V_NEXT_APV_SEQ
                                                    AND DOCNO = in_DOCNO   
                                                    AND APV_KND IN ('1', '2');  -- 결재 OR 참조   
                                        EXCEPTION WHEN OTHERS THEN
                                                out_CODE := 1;
                                                out_MSG := '<ACTION 문서 완료 처리중에 ERR 발생 되었습니다. 관련부서에 문의 하세요.>'; 
                                                RAISE ERROR_EXCEPTION;
                                        END;            
                                ELSE
                                        out_CODE := 1;
                                        out_MSG := '<상위 결재자가 결재를 진행하였습니다. 문서결재를 진행 할 수 없습니다..>'; 
                                        RAISE ERROR_EXCEPTION;                                    
                                END IF;
                        --END IF;                         
                END IF;              

                out_CODE := 0;
                out_MSG := '<전자결재 처리가 완료 되었습니다.>'; 
         
        END IF;
         
EXCEPTION
WHEN SAWON_ID_NULL THEN
        out_CODE := 101;
        out_MSG  := '사원코드가 누락되었습니다.';
WHEN DOCNO_NULL THEN
        out_CODE := 101;
        out_MSG  := '문서번호가 잘못되었습니다.';
WHEN D_STATUS_NULL THEN
        out_CODE := 101;
        out_MSG  := '결재상태가 잘못되었습니다.';
WHEN ERROR_EXCEPTION THEN
        out_CODE := SQLCODE;
        out_MSG  :=out_MSG||'-'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
