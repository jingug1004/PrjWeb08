CREATE PROCEDURE      SP_SFA_COLLECT_BLOB
   (in_JUNPYO_NO    IN VARCHAR2 DEFAULT NULL,
    in_SIGN_IMAGE   IN BLOB, 
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 카드수금-사인저장 
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

   ERROR_EXCEPTION     EXCEPTION;
   
   v_CNT  NUMBER;
BEGIN
  
   -- insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_BLOB','1_'||in_JUNPYO_NO,sysdate,'in_JUNPYO_NO:'||in_JUNPYO_NO );

    v_CNT :=0;
    SELECT COUNT(*)
      INTO v_CNT
      FROM SALE0401
     WHERE JUNPYO_NO = in_JUNPYO_NO;
    IF v_CNT = 0 THEN       
       out_CODE := 999;
       out_MSG := '수금마스터에수금내역없음';      
       RAISE ERROR_EXCEPTION;
    END IF;
    
    BEGIN
        UPDATE SALE0402
           SET SIGN_IMAGE  = in_SIGN_IMAGE
         WHERE JUNPYO_NO = in_JUNPYO_NO;
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '사인저장실패:'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
        RAISE ERROR_EXCEPTION;
    END;  
               
    out_CODE := 0;
    out_MSG := '수금 정상 처리 및 사인 이미지 처리 완료';


EXCEPTION
WHEN ERROR_EXCEPTION THEN 
    insert into SFA_SP_CALLED_HIST 
    values ('SP_SFA_COLLECT_BLOB',in_JUNPYO_NO,sysdate
          ,'[out_MSG1:'||out_MSG||']');
   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
    insert into SFA_SP_CALLED_HIST 
    values ('SP_SFA_COLLECT_BLOB','1_'||in_JUNPYO_NO,sysdate
          ,'[out_MSG1:'||out_MSG||']');
END;

/
