CREATE PROCEDURE      SP_X_APP_ITEMINFO
(
    in_REQ_DATE   IN VARCHAR2,
    in_GUMAE_NO   IN VARCHAR2,
    out_RESULT   OUT TYPES.CURSOR_TYPE,    
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_ITEMINFO
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 

	OPEN out_RESULT FOR
        SELECT NVL(CHUL_YN,'N') CHUL_YN, NVL(USE_YN,'N') USE_YN
		 FROM SALE.SALE0004
		WHERE ITEM_ID IN (SELECT ITEM_ID
						    FROM SALE_ON.SALE0204
						   WHERE YMD = in_REQ_DATE
							 AND GUMAE_NO = in_GUMAE_NO)
		  AND (NVL(CHUL_YN,'N') = 'Y' OR  NVL(USE_YN,'N') = 'N')
		  AND ROWNUM = 1;
		  
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
