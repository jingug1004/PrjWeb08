CREATE PROCEDURE      SP_Z_RETURN_UP 
(
    in_PROCESS      IN  VARCHAR2,   
    in_SAWON_ID     IN  VARCHAR2,   
    in_BREASON      IN  VARCHAR2,   -- 반품이유
    in_SSTATE       IN  VARCHAR2,   -- 결재 상태
    in_SREASON      IN  VARCHAR2,   -- 승인자 불가사유
    in_CUST_ID      IN  VARCHAR2,   
    in_RCUST_ID     IN  VARCHAR2,   
    out_CODE        out NUMBER,
    out_MSG         out VARCHAR2
)
IS
 /*---------------------------------------------------------------------------
 프로그램명
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_Z_VISIT_NON_REASON_UP',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SAWON_ID,sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_SOLAR '||in_SOLAR );
--commit;
   
     SELECT COUNT(*)
      INTO v_num
     FROM sfa_banpum_reason a
     where a.CUST_SAWON_ID = in_SAWON_ID
        and CUST_ID = in_CUST_ID
        and RCUST_ID = in_RCUST_ID;
   
    IF v_num = 0 THEN -- 신규등록
        out_CODE := 0;
        out_MSG := '요청하신 작업이 등록되었습니다.';  
        insert into sfa_banpum_reason(ymd,cust_id,rcust_id,item_id,prod_no,
                                        BARCODE_QTY,MANUAL_QTY,BANPUM_QTY,BANPUM_REASON,SEONGIN_STATE,
                                        SEONGIN_NO_REASON) 
                                values ('20171228','2009018','2009018','100411','100411',
                                        1,2,3,'BANPUM_REASON','SEONGIN_STATE',
                                        'SEONGIN_NO_REASON') ;
                
    ELSE    -- 업데이트
        out_CODE := 0;
        out_MSG := '요청하신 작업이 수정되었습니다.';      
        update sfa_banpum_reason set 
                                        BANPUM_REASON       = in_BREASON,
                                        SEONGIN_STATE       = in_SSTATE,
                                        SEONGIN_NO_REASON   = in_SREASON
                                  where 
                                            CUST_ID = in_CUST_ID
                                        and RCUST_ID = in_RCUST_ID;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
