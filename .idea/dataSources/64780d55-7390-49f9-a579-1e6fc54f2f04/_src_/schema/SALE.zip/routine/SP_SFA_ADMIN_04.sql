CREATE PROCEDURE      SP_SFA_ADMIN_04    -- 경쟁품목 등록
(
    in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3)
    in_ITEM_CD           IN  VARCHAR2,     -- 품목코드
    in_SEQ_NO            IN  NUMBER,       -- SEQ
    in_ITEM_NM           IN  VARCHAR2,     -- 자사제품명
    in_RIVAL_ITEM        IN  VARCHAR2,     -- 경쟁사제품명
    in_PRICE             IN  NUMBER,       -- 단가
    in_ONEDAY_COST       IN  NUMBER,       -- 1일 Cost
    in_STRONG_FAULT      IN  VARCHAR2,     -- 장단점
    in_INPUT_DT          IN  VARCHAR2,     -- 입력일자
    in_INPUT_ID          IN  VARCHAR2,     -- 입력자
    in_BIGO              IN  VARCHAR2,     -- 비고
    in_RIVAL_COMPANY_NM  IN  VARCHAR2,     -- 제조사
    in_STOP_PRODUCTION   IN  VARCHAR2,     -- 단종여부
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    v_seq                NUMBER;
    
BEGIN
    IF in_BTN_GUBUN <> 1 THEN 
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_OFFICE_RIVALITEM
         WHERE ITEM_CODE   = in_ITEM_CD
           AND SEQ_NO      = in_SEQ_NO;
             
        out_COUNT := v_num;
    END IF;
    
    IF in_BTN_GUBUN = 1 THEN -- 등록버튼 클릭한 경우
        IF in_SEQ_NO IS NOT NULL AND v_num >= 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 있습니다';
        ELSE
            -- 필수값 체크 루틴 넣을것.
            
            -- SEQ MAX 생성
            SELECT NVL(MAX(SEQ_NO),0)+1
              INTO v_seq
              FROM SFA_OFFICE_RIVALITEM
             WHERE ITEM_CODE = in_ITEM_CD ;
              
            -- 경쟁품목 등록
            INSERT INTO SFA_OFFICE_RIVALITEM(ITEM_CODE,  SEQ_NO, ITEM_NAME, RIVAL_ITEM, PRICE, ONEDAY_COST, STRONG_FAULT, INPUT_DTM, INPUT_WORKER, BIGO, RIVAL_COMPANY_NM, STOP_PRODUCTION) 
                                VALUES(in_ITEM_CD, v_seq,  in_ITEM_NM, in_RIVAL_ITEM, in_PRICE, in_ONEDAY_COST, in_STRONG_FAULT, TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'), in_INPUT_ID, in_BIGO, in_RIVAL_COMPANY_NM, in_STOP_PRODUCTION);
            
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT ITEM_CODE                  AS out_ITEM_CODE    -- 품목코드
                 , SEQ_NO                     AS out_SEQ_NO       -- 일련번호
                 , ITEM_NAME                  AS out_ITEM_NM      -- 자사품목명
                 , RIVAL_ITEM                 AS out_RIVAL_ITEM   -- 경쟁사품목명
                 , PRICE                      AS out_PRICE        -- 단가
                 , ONEDAY_COST                AS out_ONEDAY_COST  -- 1일 COST
                 , STRONG_FAULT               AS out_STRONG_FAULT  -- 장단점
                 , INPUT_DTM                  AS out_INPUT_DT     -- 입력일자
                 , INPUT_WORKER               AS out_INPUT_ID     -- 입력자
                 , F_SAWON_NM(INPUT_WORKER)   AS out_INPUT_NM    -- 입력자 명
                 , BIGO                       AS out_BIGO         -- 비고
                 , RIVAL_COMPANY_NM           AS out_RIVAL_COMPANY_NM   -- 제조사
                 , STOP_PRODUCTION            AS out_STOP_PRODUCTION    -- 단종여부
                FROM SFA_OFFICE_RIVALITEM
               WHERE ITEM_CODE   = in_ITEM_CD
                 AND SEQ_NO      = v_seq;
             
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '등록이 완료되었습니다';
        END IF;
    ELSIF in_BTN_GUBUN = 2 THEN -- 수정버튼 클릭한 경우
        IF v_num < 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            UPDATE SFA_OFFICE_RIVALITEM
               SET ITEM_NAME        =    in_ITEM_NM
                 , RIVAL_ITEM       =    in_RIVAL_ITEM
                 , PRICE            =    in_PRICE
                 , ONEDAY_COST      =    in_ONEDAY_COST
                 , STRONG_FAULT     =    in_STRONG_FAULT
                 , BIGO             =    in_BIGO
                 , RIVAL_COMPANY_NM = in_RIVAL_COMPANY_NM
                 , STOP_PRODUCTION  = in_STOP_PRODUCTION
             WHERE ITEM_CODE        =    in_ITEM_CD
               AND SEQ_NO           =    in_SEQ_NO;
              
            COMMIT;

            OPEN out_RESULT FOR
            SELECT ITEM_CODE                 AS out_ITEM_CODE    -- 품목코드
                 , SEQ_NO                    AS out_SEQ_NO       -- 일련번호
                 , ITEM_NAME                 AS out_ITEM_NM      -- 자사품목명
                 , RIVAL_ITEM                AS out_RIVAL_ITEM   -- 경쟁사품목명
                 , PRICE                     AS out_PRICE        -- 단가
                 , ONEDAY_COST               AS out_ONEDAY_COST  -- 1일 COST
                 , STRONG_FAULT              AS out_STRONG_FAULT  -- 장단점
                 , INPUT_DTM                 AS out_INPUT_DT     -- 입력일자
                 , INPUT_WORKER              AS out_INPUT_ID     -- 입력자
                 , F_SAWON_NM(INPUT_WORKER)  AS out_INPUT_NM    -- 입력자 명
                 , BIGO                      AS out_BIGO         -- 비고
                 , RIVAL_COMPANY_NM          AS out_RIVAL_COMPANY_NM   -- 제조사
                 , STOP_PRODUCTION           AS out_STOP_PRODUCTION    -- 단종여부
                FROM SFA_OFFICE_RIVALITEM
               WHERE ITEM_CODE   = in_ITEM_CD
                 AND SEQ_NO      = in_SEQ_NO;
             
            out_CODE := 0;
            out_MSG := '수정이 완료되었습니다';
        END IF;
    ELSIF in_BTN_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우
        IF v_num < 1 THEN
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            DELETE FROM SFA_OFFICE_RIVALITEM
             WHERE ITEM_CODE   = in_ITEM_CD   AND  SEQ_NO      =    in_SEQ_NO;
              
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT ITEM_CODE                AS out_ITEM_CODE    -- 품목코드
                 , SEQ_NO                   AS out_SEQ_NO       -- 일련번호
                 , ITEM_NAME                AS out_ITEM_NM      -- 자사품목명
                 , RIVAL_ITEM               AS out_RIVAL_ITEM   -- 경쟁사품목명
                 , PRICE                    AS out_PRICE        -- 단가
                 , ONEDAY_COST              AS out_ONEDAY_COST  -- 1일 COST
                 , STRONG_FAULT             AS out_STRONG_FAULT  -- 장단점
                 , INPUT_DTM                AS out_INPUT_DT     -- 입력일자
                 , INPUT_WORKER             AS out_INPUT_ID     -- 입력자
                 , F_SAWON_NM(INPUT_WORKER) AS out_INPUT_NM    -- 입력자 명
                 , BIGO                     AS out_BIGO         -- 비고
                 , RIVAL_COMPANY_NM         AS out_RIVAL_COMPANY_NM   -- 제조사
                 , STOP_PRODUCTION          AS out_STOP_PRODUCTION    -- 단종여부
                FROM SFA_OFFICE_RIVALITEM
               WHERE ITEM_CODE   = in_ITEM_CD
                 AND SEQ_NO      = (SELECT MAX(SEQ_NO) FROM SFA_OFFICE_RIVALITEM WHERE ITEM_CODE = in_ITEM_CD);
             
            out_CODE := 0;
            out_MSG := '삭제가 완료되었습니다';
         END IF;
    ELSE   -- 조회처리
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '정보가 존재하지 않습니다.';
        ELSIF (v_num >= 1) THEN
            out_CODE := 0;
            out_MSG := '정보 확인완료';    
             
            OPEN out_RESULT FOR
            SELECT ITEM_CODE                  AS out_ITEM_CODE    -- 품목코드
                 , SEQ_NO                     AS out_SEQ_NO       -- 일련번호
                 , ITEM_NAME                  AS out_ITEM_NM    -- 자사품목명
                 , RIVAL_ITEM                 AS out_RIVAL_ITEM   -- 경쟁사품목명
                 , PRICE                      AS out_PRICE        -- 단가
                 , ONEDAY_COST                AS out_ONEDAY_COST  -- 1일 COST
                 , STRONG_FAULT               AS out_STRONG_FAULT  -- 장단점
                 , INPUT_DTM                  AS out_INPUT_DT     -- 입력일자
                 , INPUT_WORKER               AS out_INPUT_ID     -- 입력자
                 , F_SAWON_NM(INPUT_WORKER)   AS out_INPUT_NM    -- 입력자 명
                 , BIGO                       AS out_BIGO         -- 비고
                 , RIVAL_COMPANY_NM           AS out_RIVAL_COMPANY_NM   -- 제조사
                 , STOP_PRODUCTION            AS out_STOP_PRODUCTION    -- 단종여부
                FROM SFA_OFFICE_RIVALITEM
               WHERE ITEM_CODE   = in_ITEM_CD
                 AND SEQ_NO      = in_SEQ_NO;
        END IF;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
