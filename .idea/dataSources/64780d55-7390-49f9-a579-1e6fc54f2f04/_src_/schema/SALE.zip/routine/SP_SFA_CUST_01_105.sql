CREATE PROCEDURE      SP_SFA_CUST_01_105
(
    in_SAWON_ID          IN  VARCHAR2,    -- 로그인사번
    in_CUST_NM           IN  VARCHAR2,    -- 거래처명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  :로그인 사번의 주문거래처 및 활동거래처를 HIRA거래처정보에서 검색 
 호출프로그램 :customer.CustomerList
 수정내용     2015.04.22 KTA-총괄지점장 직책코드  추가 관련수정
          2015.06.08 KTA임시팀장 직책코드 추가관련 수정
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼   
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_assgn_cd          VARCHAR2(5);
    v_deptcode          VARCHAR2(4);  --로그인사번의 부서
    v_query_deptcode    VARCHAR2(4);  --검색가능부서
    
    DEPT_CD_NULL         EXCEPTION;
    SAWON_ID_NULL        EXCEPTION;
BEGIN
    
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_01_105',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_DEPT_CD,sysdate,'in_DEPT_CD:'||in_DEPT_CD||'/in_PART_CD '||in_PART_CD );
--commit;

    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
        RAISE SAWON_ID_NULL;
    END IF; 
                
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    select classdiv,deptcode into v_assgn_cd,v_deptcode from ORAGMP.CMEMPM  where empcode = in_SAWON_ID;
                
    -- 조회부서:: 로그인 직책에따라 상위부서를 찾거나 본인부서를 찾는다.
    if v_assgn_cd = '27010' or v_assgn_cd = '27020' or v_assgn_cd = '27025' or v_assgn_cd = '27018' or v_assgn_cd = '27026' then   --본부장관리이사,, 총괄지점장 부본부장 선임지점장
       select deptcode 
         into v_query_deptcode 
         from ORAGMP.CMDEPTM 
        where useyn = 'Y' and level = 2 connect by deptcode = prior predeptcode start with plantcode = '1000' and deptcode = v_deptcode;
                                   
    elsif (v_assgn_cd = '27027' or v_assgn_cd = '27030' or v_assgn_cd = '27035' ) then --팀장,임시팀장 
        v_query_deptcode := v_deptcode;        
    end if;

     
   
    --검색건수
    --admin은 모든 부서찾기 가능 ,팀원이면 본인의 부서 ,총괄팀장 또는 팀장이면 하위모든 사원의 부서를 찾는다.
    SELECT COUNT(*) 
      INTO v_num
      FROM (
            SELECT a.*,b.useyn
              FROM ORAGMP.CMHIRAM a
                  ,ORAGMP.CMCUSTM b
             WHERE a.plantcode = b.plantcode(+)
               AND a.custcode  = b.custcode(+)
               AND a.plantcode = '1000'
               AND a.hiracode  > '0000009'
               AND a.hiraname  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
               AND a.orderempcode in (select empcode from ORAGMP.CMEMPM where deptcode in (select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode))
            UNION
            SELECT a.*,b.useyn   
              FROM ORAGMP.CMHIRAM a
                  ,ORAGMP.CMCUSTM b
             WHERE a.plantcode = b.plantcode(+)
               AND a.custcode  = b.custcode(+)
               AND a.plantcode = '1000'
               AND a.hiracode  > '0000009'
               AND a.hiraname  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
               AND a.areaempcode in (select empcode from ORAGMP.CMEMPM where deptcode in (select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode))         
           );    
 
    out_COUNT := v_num;
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num > 500) THEN
        out_CODE := 1;
        out_MSG := '검색건수가 1000건이 넘습니다.팀원이 아닌경우 1000건이 넘을수 있으니 거래처명을 입력하십시오.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT hiracode                              AS out_SFA_SALES_SEQ  -- SFA거래처키컬럼
              ,hiracode                              AS out_CUST_CD        -- SFA거래처코드
              ,decode(useyn,'N','중지됨')||hiraname     AS out_CUST_NM        -- 거래처명
              ,nvl(ceoname, ' ')                     AS out_MANAGER_NM     -- 대표자명
              ,custcode                              AS out_ERP_CD         -- ERP 코드
              ,decode(sagodiv,'1','Y','N')           AS out_YN             -- 주문거래처여부  sagodiv 1-주문,2-활동 3-비활동
              ,decode(sagodiv,'1','거래','비거래')       AS out_TRADE_NM       -- 거래여부
              ,'['||F_SFA_CODE_NM('CUST_STAT_GB',sagodiv)||'-'||decode(sagodiv,'1',oragmp.fncommonnm('emp',orderempcode,''),oragmp.fncommonnm('emp',areaempcode,''))||'] '||hiraaddr 
                                                     AS out_ADDR1          -- 주소
              ,''                                    AS out_ADDR2          -- 상세주소
         FROM (
                SELECT a.hiracode,a.hiraname,a.ceoname,a.custcode,a.orderempcode  as empcode,a.hiraaddr,b.useyn,a.sagodiv,a.orderempcode,a.areaempcode
                  FROM ORAGMP.CMHIRAM a
                      ,ORAGMP.CMCUSTM b
                 WHERE a.plantcode = b.plantcode(+)
                   AND a.custcode  = b.custcode(+)
                   AND a.plantcode = '1000'
                   AND a.hiracode  > '0000009'
                   AND a.hiraname  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND a.orderempcode in (select empcode from ORAGMP.CMEMPM where deptcode in (select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode))
                UNION
                SELECT a.hiracode,a.hiraname,a.ceoname,a.custcode,a.areaempcode  as empcode,a.hiraaddr,b.useyn,a.sagodiv,a.orderempcode,a.areaempcode
                  FROM ORAGMP.CMHIRAM a
                      ,ORAGMP.CMCUSTM b
                 WHERE a.plantcode = b.plantcode(+)
                   AND a.custcode  = b.custcode(+)
                   AND a.plantcode = '1000'
                   AND a.hiracode  > '0000009'
                   AND a.hiraname  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND a.areaempcode in (select empcode from ORAGMP.CMEMPM where deptcode in (select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode))         
          )
          ORDER BY '['||F_SFA_CODE_NM('CUST_STAT_GB',decode(orderempcode,null,decode(areaempcode,null,'03','02'),'01'))||'-'||decode(orderempcode,null,decode(areaempcode,null,'',oragmp.fncommonnm('emp',areaempcode,'')),oragmp.fncommonnm('emp',orderempcode,''))||'] '||hiraaddr 
        ;
                 
    END IF;
    
EXCEPTION
WHEN DEPT_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '부서코드가 누락되었습니다.';
WHEN SAWON_ID_NULL THEN
   out_CODE := 102;
   out_MSG  := '사원 ID가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
