CREATE PROCEDURE      SP_Z_STATUS_01
(
    in_PART_CD           IN  VARCHAR2,     -- 파트 코드
    in_DEPT_CD           IN  VARCHAR2,     -- 부서 코드
    in_SAWON_ID          IN  VARCHAR2,     -- 사원 ID
    in_DT_FR             IN  VARCHAR2,     -- 기준일자 FROM
    in_DT_TO             IN  VARCHAR2,     -- 기준일자 TO
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 실적조회
 호출프로그램 :       
 수정기록 : 
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_gubun              NUMBER;
    p_frdate             VARCHAR2(10);
    p_todate             VARCHAR2(10);
    p_frym               VARCHAR2(10);
    p_toym               VARCHAR2(10);
    
    DT_NULL              EXCEPTION;
BEGIN

    p_frdate := TO_CHAR(to_date(in_DT_FR,'YYYYMMDD'),'YYYY-MM-DD');
    p_todate := TO_CHAR(to_date(in_DT_TO,'YYYYMMDD'),'YYYY-MM-DD'); 
    p_frym   := SUBSTR(p_frdate,1,7);
    p_toym   := SUBSTR(p_todate,1,7);
    

    -- 정상작동 될때까지 막음 
  --  IF in_SAWON_ID not in ('2015248') THEN
       out_CODE := 101;
       out_MSG := '아직 사용할수 없습니다';  
       RETURN;
  --  END IF; 

    IF in_DT_FR IS NULL OR in_DT_TO IS NULL THEN
        RAISE DT_NULL;
    END IF; 

        
    IF in_PART_CD IS NULL AND in_DEPT_CD IS NULL AND in_SAWON_ID IS NULL THEN
        v_gubun := 1;  -- 파트 전체 검색
    ELSIF in_PART_CD IS NOT NULL AND in_DEPT_CD IS NULL AND in_SAWON_ID IS NULL THEN
        v_gubun := 2;  -- 부서 전체 검색
    ELSIF in_PART_CD IS NOT NULL AND in_DEPT_CD IS NOT NULL AND in_SAWON_ID IS NULL THEN
        v_gubun := 3;  -- 파트별 부서별 전체 사원 검색
    ELSIF in_PART_CD IS NOT NULL AND in_DEPT_CD IS NOT NULL AND in_SAWON_ID IS NOT NULL THEN
        v_gubun := 4;  -- 파트별 부서별 개별 사원 검색
    END IF;
                
-- insert into SFA_SP_CALLED_HIST values ('SP_SFA_STATUS_01',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_DEPT_CD,sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_PART_CD '||in_PART_CD ||'v_gubun:'||v_gubun||'p_frym:'||p_frym||'p_toym:'||p_toym);
--commit;
 

 
    IF v_gubun = 1 THEN  -- 파트 실적 
    
           SELECT count(*)
             INTO v_num
             FROM (
                    SELECT 1                              
                     FROM
                        ( SELECT F_Z_FIND_PART(A.DEPTCODE )                                      AS PART  ,    --파트
                                 A.YEARMONTH                                                     AS YEARMONTH ,    --년월
                                 (CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END)          AS SAL_TAG_AMT,   --판매목표
                                 0                                                               AS SAL_ACT_AMT,   --판매실적
                                 (CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END)          AS COL_TAG_AMT,   --수금목표
                                 0                                                               AS COL_ACT_AMT    --수금실적
                            FROM oragmp.SLTARGETSALEM A
                           WHERE A.YEARMONTH  BETWEEN p_frym AND p_toym
                       UNION ALL
                          SELECT F_Z_FIND_PART(A.DEPTCODE )                                      AS PART  ,    --파트
                                 SUBSTR(A.ORDERDATE,1,7)                                         AS YEARMONTH  ,   --년월
                                 0                                                               AS SAL_TAG_AMT,   --판매목표
                                 CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT ELSE -B.TOTAMT END   AS SAL_ACT_AMT,   --판매실적
                                 0                                                               AS COL_TAG_AMT,   --수금목표
                                 0                                                               AS COL_ACT_AMT    --수금실적
                            FROM oragmp.SLORDM  A,
                                 oragmp.SLORDD  B
                           WHERE A.STATEDIV = '09'
                             AND A.ORDERNO  = B.ORDERNO
                             AND A.ORDERDATE  BETWEEN p_frdate AND p_todate
                       UNION ALL
                          SELECT F_Z_FIND_PART(A.DEPTCODE )                                      AS PART  ,    --파트
                                 SUBSTR(A.COLDATE,1,7)                                           AS YEARMONTH  ,   --년월
                                 0                                                               AS SAL_TAG_AMT,   --판매목표
                                 CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT ELSE 0 END AS SAL_ACT_AMT,   --판매실적
                                 0                                                               AS COL_TAG_AMT,   --수금목표
                                 CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT ELSE 0 END  AS COL_ACT_AMT    --수금실적
                            FROM oragmp.SLCOLM  A
                           WHERE A.STATEDIV = '09'
                             AND A.COLDATE  BETWEEN p_frdate AND p_todate
                        ) A
                 WHERE A.PART  = in_PART_CD                        
                 GROUP BY A.PART, A.YEARMONTH
               );  
         
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';     
        
           OPEN out_RESULT FOR   
           
               SELECT '00'                                                    AS out_GUBUN_CD         -- 구분코드
                    , '00'                                                    AS out_GUBUN_NM         -- 구분명
                    , '00'                                                    AS out_RPT_GB           -- 생성구분
                    , SUM(A.SAL_TAG_AMT)                                      AS out_SALE_AMT         -- 판매목표
                    , SUM(A.SAL_ACT_AMT)                                      AS out_SALE_AMT_SILJUK  -- 판매금액
                    , round(sum(SAL_ACT_AMT)/DECODE(sum(SAL_TAG_AMT),0,1,sum(SAL_TAG_AMT))*100,2)  AS out_SALE_PERCENT     -- 판매달성율
                    , SUM(A.COL_TAG_AMT)                                      AS out_IN_AMT           -- 수금목표
                    , SUM(A.COL_ACT_AMT)                                      AS out_IN_AMT_SILJUK    -- 수금금액
                    , round(sum(COL_TAG_AMT)/DECODE(sum(COL_ACT_AMT),0,1,sum(COL_ACT_AMT))*100,2)  AS out_in_PERCENT       -- 수금달성율  
                    ,sysdate                                                  AS out_PROC_DATE        -- batch data 생성시각 
                 FROM
                    ( SELECT F_Z_FIND_PART(A.DEPTCODE )                                      AS PART  ,    --파트
                             A.YEARMONTH                                                     AS YEARMONTH  ,   --년월
                             (CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END)          AS SAL_TAG_AMT,   --판매목표
                             0                                                               AS SAL_ACT_AMT,   --판매실적
                             (CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END)          AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLTARGETSALEM A
                       WHERE A.YEARMONTH  BETWEEN p_frym AND p_toym 
                   UNION ALL
                      SELECT F_Z_FIND_PART(A.DEPTCODE )                                      AS PART  ,    --파트
                             SUBSTR(A.ORDERDATE,1,7)                                         AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT ELSE -B.TOTAMT END   AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLORDM  A,
                             oragmp.SLORDD  B
                       WHERE A.STATEDIV = '09'
                         AND A.ORDERNO  = B.ORDERNO
                         AND A.ORDERDATE  BETWEEN p_frdate AND p_todate 
                   UNION ALL
                      SELECT F_Z_FIND_PART(A.DEPTCODE )                                      AS PART  ,    --파트 
                             SUBSTR(A.COLDATE,1,7)                                           AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT ELSE 0 END AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT ELSE 0 END  AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLCOLM  A
                       WHERE A.STATEDIV = '09'
                         AND A.COLDATE  BETWEEN p_frdate AND p_todate
                    ) A
              WHERE   A.PART  = in_PART_CD
              GROUP BY '00'
              
              UNION ALL
              
               SELECT PART                                                    AS out_GUBUN_CD         -- 구분코드
                    , oragmp.fncommonnm('emp',a.PART,'')                  AS out_GUBUN_NM         -- 구분명
                    , '01'                                                    AS out_RPT_GB           -- 생성구분
                    , SUM(A.SAL_TAG_AMT)                                      AS out_SALE_AMT         -- 판매목표
                    , SUM(A.SAL_ACT_AMT)                                      AS out_SALE_AMT_SILJUK  -- 판매금액
                    , round(sum(SAL_ACT_AMT)/DECODE(sum(SAL_TAG_AMT),0,1,sum(SAL_TAG_AMT))*100,2)  AS out_SALE_PERCENT     -- 판매달성율
                    , SUM(A.COL_TAG_AMT)                                      AS out_IN_AMT           -- 수금목표
                    , SUM(A.COL_ACT_AMT)                                      AS out_IN_AMT_SILJUK    -- 수금금액
                    , round(sum(COL_TAG_AMT)/DECODE(sum(COL_ACT_AMT),0,1,sum(COL_ACT_AMT))*100,2)  AS out_in_PERCENT       -- 수금달성율  
                    ,sysdate                                                  AS out_PROC_DATE        -- batch data 생성시각 
                 FROM
                    ( SELECT F_Z_FIND_PART(A.DEPTCODE )                                      AS PART  ,    --파트
                             A.YEARMONTH                                                     AS YEARMONTH  ,   --년월
                             (CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END)          AS SAL_TAG_AMT,   --판매목표
                             0                                                               AS SAL_ACT_AMT,   --판매실적
                             (CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END)          AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLTARGETSALEM A
                       WHERE A.YEARMONTH  BETWEEN p_frym AND p_toym 
                   UNION ALL
                      SELECT F_Z_FIND_PART(A.DEPTCODE )                                      AS PART  ,    --파트
                             SUBSTR(A.ORDERDATE,1,7)                                         AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT ELSE -B.TOTAMT END   AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLORDM  A,
                             oragmp.SLORDD  B
                       WHERE A.STATEDIV = '09'
                         AND A.ORDERNO  = B.ORDERNO
                         AND A.ORDERDATE  BETWEEN p_frdate AND p_todate 
                   UNION ALL
                      SELECT F_Z_FIND_PART(A.DEPTCODE )                                      AS PART  ,    --파트
                             SUBSTR(A.COLDATE,1,7)                                           AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT ELSE 0 END AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT ELSE 0 END  AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLCOLM  A
                       WHERE A.STATEDIV = '09'
                         AND A.COLDATE  BETWEEN p_frdate AND p_todate
                    ) A
              WHERE   A.PART  = in_PART_CD
              GROUP BY A.PART, A.YEARMONTH 
             order by 1,2
             ;
         
         END IF;
        
    END IF;


      

    IF v_gubun = 2 THEN  -- 부서 실적 
    
           SELECT count(*)
             INTO v_num
             FROM (
                    SELECT 1                              
                     FROM
                        ( SELECT A.DEPTCODE                                                       AS DEPTCODE    ,   --부서코드
                                 A.YEARMONTH                                                     AS YEARMONTH  ,   --년월
                                 (CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END)          AS SAL_TAG_AMT,   --판매목표
                                 0                                                               AS SAL_ACT_AMT,   --판매실적
                                 (CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END)          AS COL_TAG_AMT,   --수금목표
                                 0                                                               AS COL_ACT_AMT    --수금실적
                            FROM oragmp.SLTARGETSALEM A
                           WHERE A.YEARMONTH  BETWEEN p_frym AND p_toym
                       UNION ALL
                          SELECT A.DEPTCODE                                                      AS DEPTCODE    ,   --부서코드
                                 SUBSTR(A.ORDERDATE,1,7)                                         AS YEARMONTH  ,   --년월
                                 0                                                               AS SAL_TAG_AMT,   --판매목표
                                 CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT ELSE -B.TOTAMT END   AS SAL_ACT_AMT,   --판매실적
                                 0                                                               AS COL_TAG_AMT,   --수금목표
                                 0                                                               AS COL_ACT_AMT    --수금실적
                            FROM oragmp.SLORDM  A,
                                 oragmp.SLORDD  B
                           WHERE A.STATEDIV = '09'
                             AND A.ORDERNO  = B.ORDERNO
                             AND A.ORDERDATE  BETWEEN p_frdate AND p_todate
                       UNION ALL
                          SELECT A.DEPTCODE                                                      AS DEPTCODE    ,  --부서코드
                                 SUBSTR(A.COLDATE,1,7)                                           AS YEARMONTH  ,   --년월
                                 0                                                               AS SAL_TAG_AMT,   --판매목표
                                 CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT ELSE 0 END AS SAL_ACT_AMT,   --판매실적
                                 0                                                               AS COL_TAG_AMT,   --수금목표
                                 CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT ELSE 0 END  AS COL_ACT_AMT    --수금실적
                            FROM oragmp.SLCOLM  A
                           WHERE A.STATEDIV = '09'
                             AND A.COLDATE  BETWEEN p_frdate AND p_todate
                        ) A
                 WHERE A.DEPTCODE  = in_DEPT_CD                        
                 GROUP BY A.DEPTCODE, A.YEARMONTH
               );  
         
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';     
        
           OPEN out_RESULT FOR   
           
               SELECT '00'                                                    AS out_GUBUN_CD         -- 구분코드
                    , '00'                                                    AS out_GUBUN_NM         -- 구분명
                    , '00'                                                    AS out_RPT_GB           -- 생성구분
                    , SUM(A.SAL_TAG_AMT)                                      AS out_SALE_AMT         -- 판매목표
                    , SUM(A.SAL_ACT_AMT)                                      AS out_SALE_AMT_SILJUK  -- 판매금액
                    , round(sum(SAL_ACT_AMT)/DECODE(sum(SAL_TAG_AMT),0,1,sum(SAL_TAG_AMT))*100,2)  AS out_SALE_PERCENT     -- 판매달성율
                    , SUM(A.COL_TAG_AMT)                                      AS out_IN_AMT           -- 수금목표
                    , SUM(A.COL_ACT_AMT)                                      AS out_IN_AMT_SILJUK    -- 수금금액
                    , round(sum(COL_TAG_AMT)/DECODE(sum(COL_ACT_AMT),0,1,sum(COL_ACT_AMT))*100,2)  AS out_in_PERCENT       -- 수금달성율  
                    ,sysdate                                                  AS out_PROC_DATE        -- batch data 생성시각 
                 FROM
                    ( SELECT A.DEPTCODE                                                      AS DEPTCODE    ,   --부서코드
                             A.YEARMONTH                                                     AS YEARMONTH  ,   --년월
                             (CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END)          AS SAL_TAG_AMT,   --판매목표
                             0                                                               AS SAL_ACT_AMT,   --판매실적
                             (CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END)          AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLTARGETSALEM A
                       WHERE A.YEARMONTH  BETWEEN p_frym AND p_toym 
                   UNION ALL
                      SELECT A.DEPTCODE                                                      AS DEPTCODE    ,   --부서코드
                             SUBSTR(A.ORDERDATE,1,7)                                         AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT ELSE -B.TOTAMT END   AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLORDM  A,
                             oragmp.SLORDD  B
                       WHERE A.STATEDIV = '09'
                         AND A.ORDERNO  = B.ORDERNO
                         AND A.ORDERDATE  BETWEEN p_frdate AND p_todate 
                   UNION ALL
                      SELECT A.DEPTCODE                                                       AS DEPTCODE    ,   --부서코드
                             SUBSTR(A.COLDATE,1,7)                                           AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT ELSE 0 END AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT ELSE 0 END  AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLCOLM  A
                       WHERE A.STATEDIV = '09'
                         AND A.COLDATE  BETWEEN p_frdate AND p_todate
                    ) A
              WHERE   A.DEPTCODE  = in_DEPT_CD
              GROUP BY '00'
              
              UNION ALL
              
               SELECT DEPTCODE                                                AS out_GUBUN_CD         -- 구분코드
                    , oragmp.fncommonnm('emp',a.DEPTCODE,'')                   AS out_GUBUN_NM         -- 구분명
                    , '01'                                                    AS out_RPT_GB           -- 생성구분
                    , SUM(A.SAL_TAG_AMT)                                      AS out_SALE_AMT         -- 판매목표
                    , SUM(A.SAL_ACT_AMT)                                      AS out_SALE_AMT_SILJUK  -- 판매금액
                    , round(sum(SAL_ACT_AMT)/DECODE(sum(SAL_TAG_AMT),0,1,sum(SAL_TAG_AMT))*100,2)  AS out_SALE_PERCENT     -- 판매달성율
                    , SUM(A.COL_TAG_AMT)                                      AS out_IN_AMT           -- 수금목표
                    , SUM(A.COL_ACT_AMT)                                      AS out_IN_AMT_SILJUK    -- 수금금액
                    , round(sum(COL_TAG_AMT)/DECODE(sum(COL_ACT_AMT),0,1,sum(COL_ACT_AMT))*100,2)  AS out_in_PERCENT       -- 수금달성율  
                    ,sysdate                                                  AS out_PROC_DATE        -- batch data 생성시각 
                 FROM
                    ( SELECT A.DEPTCODE                                                      AS DEPTCODE    ,   --부서코드
                             A.YEARMONTH                                                     AS YEARMONTH  ,   --년월
                             (CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END)          AS SAL_TAG_AMT,   --판매목표
                             0                                                               AS SAL_ACT_AMT,   --판매실적
                             (CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END)          AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLTARGETSALEM A
                       WHERE A.YEARMONTH  BETWEEN p_frym AND p_toym 
                   UNION ALL
                      SELECT A.DEPTCODE                                                      AS DEPTCODE    ,   --부서코드
                             SUBSTR(A.ORDERDATE,1,7)                                         AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT ELSE -B.TOTAMT END   AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLORDM  A,
                             oragmp.SLORDD  B
                       WHERE A.STATEDIV = '09'
                         AND A.ORDERNO  = B.ORDERNO
                         AND A.ORDERDATE  BETWEEN p_frdate AND p_todate 
                   UNION ALL
                      SELECT A.DEPTCODE                                                      AS DEPTCODE    ,   --부서코드
                             SUBSTR(A.COLDATE,1,7)                                           AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT ELSE 0 END AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT ELSE 0 END  AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLCOLM  A
                       WHERE A.STATEDIV = '09'
                         AND A.COLDATE  BETWEEN p_frdate AND p_todate
                    ) A
              WHERE   A.DEPTCODE  = in_DEPT_CD
              GROUP BY A.DEPTCODE, A.YEARMONTH 
             order by 1,2
             ;
         
         END IF;
        
    END IF;
    
    
    
    
    IF v_gubun = 3 THEN  --  개별 사원 검색
    
           SELECT count(*)
             INTO v_num
             FROM (
                    SELECT 1                              
                     FROM
                        ( SELECT A.EMPCODE                                                       AS EMPCODE    ,   --사원번호
                                 A.YEARMONTH                                                     AS YEARMONTH  ,   --년월
                                 (CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END)          AS SAL_TAG_AMT,   --판매목표
                                 0                                                               AS SAL_ACT_AMT,   --판매실적
                                 (CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END)          AS COL_TAG_AMT,   --수금목표
                                 0                                                               AS COL_ACT_AMT    --수금실적
                            FROM oragmp.SLTARGETSALEM A
                           WHERE A.YEARMONTH  BETWEEN p_frym AND p_toym
                       UNION ALL
                          SELECT NVL(B.EMPCODE,A.EMPCODE)                                        AS EMPCODE    ,   --사원번호
                                 SUBSTR(A.ORDERDATE,1,7)                                         AS YEARMONTH  ,   --년월
                                 0                                                               AS SAL_TAG_AMT,   --판매목표
                                 CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT ELSE -B.TOTAMT END   AS SAL_ACT_AMT,   --판매실적
                                 0                                                               AS COL_TAG_AMT,   --수금목표
                                 0                                                               AS COL_ACT_AMT    --수금실적
                            FROM oragmp.SLORDM  A,
                                 oragmp.SLORDD  B
                           WHERE A.STATEDIV = '09'
                             AND A.ORDERNO  = B.ORDERNO
                             AND A.ORDERDATE  BETWEEN p_frdate AND p_todate
                       UNION ALL
                          SELECT A.EMPCODE                                                       AS EMPCODE    ,   --사원코드
                                 SUBSTR(A.COLDATE,1,7)                                           AS YEARMONTH  ,   --년월
                                 0                                                               AS SAL_TAG_AMT,   --판매목표
                                 CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT ELSE 0 END AS SAL_ACT_AMT,   --판매실적
                                 0                                                               AS COL_TAG_AMT,   --수금목표
                                 CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT ELSE 0 END  AS COL_ACT_AMT    --수금실적
                            FROM oragmp.SLCOLM  A
                           WHERE A.STATEDIV = '09'
                             AND A.COLDATE  BETWEEN p_frdate AND p_todate
                        ) A
                 WHERE A.EMPCODE  = in_SAWON_ID                        
                 GROUP BY A.EMPCODE, A.YEARMONTH
               );  
         
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';     
        
           OPEN out_RESULT FOR   
           
               SELECT '00'                                                    AS out_GUBUN_CD         -- 구분코드
                    , '00'                                                    AS out_GUBUN_NM         -- 구분명
                    , '00'                                                    AS out_RPT_GB           -- 생성구분
                    , SUM(A.SAL_TAG_AMT)                                      AS out_SALE_AMT         -- 판매목표
                    , SUM(A.SAL_ACT_AMT)                                      AS out_SALE_AMT_SILJUK  -- 판매금액
                    , round(sum(SAL_ACT_AMT)/DECODE(sum(SAL_TAG_AMT),0,1,sum(SAL_TAG_AMT))*100,2)  AS out_SALE_PERCENT     -- 판매달성율
                    , SUM(A.COL_TAG_AMT)                                      AS out_IN_AMT           -- 수금목표
                    , SUM(A.COL_ACT_AMT)                                      AS out_IN_AMT_SILJUK    -- 수금금액
                    , round(sum(COL_TAG_AMT)/DECODE(sum(COL_ACT_AMT),0,1,sum(COL_ACT_AMT))*100,2)  AS out_in_PERCENT       -- 수금달성율  
                    ,sysdate                                                  AS out_PROC_DATE        -- batch data 생성시각 
                 FROM
                    ( SELECT A.EMPCODE                                                       AS EMPCODE    ,   --사원번호
                             A.YEARMONTH                                                     AS YEARMONTH  ,   --년월
                             (CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END)          AS SAL_TAG_AMT,   --판매목표
                             0                                                               AS SAL_ACT_AMT,   --판매실적
                             (CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END)          AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLTARGETSALEM A
                       WHERE A.YEARMONTH  BETWEEN p_frym AND p_toym 
                   UNION ALL
                      SELECT NVL(B.EMPCODE,A.EMPCODE)                                        AS EMPCODE    ,   --사원번호
                             SUBSTR(A.ORDERDATE,1,7)                                         AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT ELSE -B.TOTAMT END   AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLORDM  A,
                             oragmp.SLORDD  B
                       WHERE A.STATEDIV = '09'
                         AND A.ORDERNO  = B.ORDERNO
                         AND A.ORDERDATE  BETWEEN p_frdate AND p_todate 
                   UNION ALL
                      SELECT A.EMPCODE                                                       AS EMPCODE    ,   --사원코드
                             SUBSTR(A.COLDATE,1,7)                                           AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT ELSE 0 END AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT ELSE 0 END  AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLCOLM  A
                       WHERE A.STATEDIV = '09'
                         AND A.COLDATE  BETWEEN p_frdate AND p_todate
                    ) A
              WHERE   A.EMPCODE  = in_SAWON_ID
              GROUP BY '00'
              
              UNION ALL
              
               SELECT empcode                                                 AS out_GUBUN_CD         -- 구분코드
                    , oragmp.fncommonnm('emp',a.empcode,'')                   AS out_GUBUN_NM         -- 구분명
                    , '01'                                                    AS out_RPT_GB           -- 생성구분
                    , SUM(A.SAL_TAG_AMT)                                      AS out_SALE_AMT         -- 판매목표
                    , SUM(A.SAL_ACT_AMT)                                      AS out_SALE_AMT_SILJUK  -- 판매금액
                    , round(sum(SAL_ACT_AMT)/DECODE(sum(SAL_TAG_AMT),0,1,sum(SAL_TAG_AMT))*100,2)  AS out_SALE_PERCENT     -- 판매달성율
                    , SUM(A.COL_TAG_AMT)                                      AS out_IN_AMT           -- 수금목표
                    , SUM(A.COL_ACT_AMT)                                      AS out_IN_AMT_SILJUK    -- 수금금액
                    , round(sum(COL_TAG_AMT)/DECODE(sum(COL_ACT_AMT),0,1,sum(COL_ACT_AMT))*100,2)  AS out_in_PERCENT       -- 수금달성율  
                    ,sysdate                                                  AS out_PROC_DATE        -- batch data 생성시각 
                 FROM
                    ( SELECT A.EMPCODE                                                       AS EMPCODE    ,   --사원번호
                             A.YEARMONTH                                                     AS YEARMONTH  ,   --년월
                             (CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END)          AS SAL_TAG_AMT,   --판매목표
                             0                                                               AS SAL_ACT_AMT,   --판매실적
                             (CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END)          AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLTARGETSALEM A
                       WHERE A.YEARMONTH  BETWEEN p_frym AND p_toym 
                   UNION ALL
                      SELECT NVL(B.EMPCODE,A.EMPCODE)                                        AS EMPCODE    ,   --사원번호
                             SUBSTR(A.ORDERDATE,1,7)                                         AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.SALDIV LIKE 'A%' THEN B.TOTAMT ELSE -B.TOTAMT END   AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             0                                                               AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLORDM  A,
                             oragmp.SLORDD  B
                       WHERE A.STATEDIV = '09'
                         AND A.ORDERNO  = B.ORDERNO
                         AND A.ORDERDATE  BETWEEN p_frdate AND p_todate 
                   UNION ALL
                      SELECT A.EMPCODE                                                       AS EMPCODE    ,   --사원코드
                             SUBSTR(A.COLDATE,1,7)                                           AS YEARMONTH  ,   --년월
                             0                                                               AS SAL_TAG_AMT,   --판매목표
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT ELSE 0 END AS SAL_ACT_AMT,   --판매실적
                             0                                                               AS COL_TAG_AMT,   --수금목표
                             CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT ELSE 0 END  AS COL_ACT_AMT    --수금실적
                        FROM oragmp.SLCOLM  A
                       WHERE A.STATEDIV = '09'
                         AND A.COLDATE  BETWEEN p_frdate AND p_todate
                    ) A
              WHERE   A.EMPCODE  = in_SAWON_ID
              GROUP BY A.EMPCODE, A.YEARMONTH 
             order by 1,2
             ;
         
         END IF;
        
    END IF;
    
        
    
EXCEPTION
WHEN DT_NULL THEN
   out_CODE := 101;
   out_MSG  := '조회기간이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
