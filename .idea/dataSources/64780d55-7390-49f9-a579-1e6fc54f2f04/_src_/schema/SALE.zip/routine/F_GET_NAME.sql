CREATE function      F_GET_NAME
        ( a_gb          VARCHAR2, -- 해당 테이블
          a_cd          VARCHAR2, -- 찾을 코드
          a_ext         VARCHAR2  -- 확장성 (찾을 코드의 조건이 더 있을경우)
        )
   RETURN VARCHAR2
AS
   user_err     exception   ;
   v_curr_jakup varchar2(100) ;
   v_curr_error varchar2(100) ;
   v_message    varchar2(250) ;

   v_rtn_value VARCHAR2(100) ;

   v_gb        varchar2(20) ;
   v_cd        varchar2(20) ;
   v_ext       varchar2(20) ;
   v_count     Number ;
   v_dummy     varchar2(20) ;
BEGIN

    Begin
        v_rtn_value := ' ';
        v_gb     := upper(LTRIM(RTRIM(a_gb))) ;
        v_cd     := LTRIM(RTRIM(a_cd)) ;
        v_ext    := LTRIM(RTRIM(a_ext)) ;

        If NVL(v_gb, ' ') = ' ' or
           NVL(v_cd, ' ') = ' ' Then
           goto the_end;
        End if ;

        If v_gb = 'SALE0004' Then -- 제품명
           select nvl(Max(item_nm), ' ')
             into v_rtn_value
             from SALE0004
            where item_id = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'SALE0003' Then -- 거래처명
           select nvl(Max(cust_nm), ' ')
             into v_rtn_value
             from SALE0003
            where cust_id = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'SFA_SALES_CODE' Then -- 거래처명
           select nvl(Max(TRADE_NAME), ' ')
             into v_rtn_value
             from SFA_SALES_CODE
            where sfa_sales_no = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'INV0001' Then -- 원부자재 전표구분명
           select nvl(Max(junpyogb_nm), ' ')
             into v_rtn_value
             from INV0001
            where junpyogb_cd = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'INV0002' Then -- 원부자재 공정명
           select nvl(Max(process_nm), ' ')
             into v_rtn_value
             from INV0002
            where process_cd = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'INV0003' Then -- 원부자재명
           select nvl(Max(material_nm), ' ')
             into v_rtn_value
             from INV0003
            where material_id = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'INV0011' Then -- 구매거래처
           select nvl(Max(cust_nm), ' ')
             into v_rtn_value
             from INV0011
            where cust_id = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'SALE0007' Then -- 사원
           select nvl(Max(sawon_nm), ' ')
             into v_rtn_value
             from sale.SALE0007
            where sawon_id = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'SALE0008' Then -- 부서
           select nvl(Max(dept_nm), ' ')
             into v_rtn_value
             from SALE0008
            where dept_cd = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'BUY0001' Then -- 외자구매: Offer상
           select nvl(Max(offer_nm), ' ')
             into v_rtn_value
             from BUY0001
            where offer_cd = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'BUY0002' Then -- 외자구매: 화폐코드
           select nvl(Max(coin_nm), ' ')
             into v_rtn_value
             from BUY0002
            where coin_cd = v_cd
              and rownum < 2  ;
        ElsIf v_gb = 'SALE0001' Then -- Offer
           -- 3001  외자구매-결제조건  3002  외자구매-가격조건                                 
           -- 3003  외자구매-원산지    3004  외자구매-수입원장적요 3005  외자구매-지급처                                   
           If NVL(v_ext, ' ') = ' ' Then
              goto the_end;
           End if ;
           select nvl(Max(code1_nm), ' ')
             into v_rtn_value
             from SALE0001
            where code_gb = v_cd
              and code1   = v_ext
              and rownum < 2  ;
        End If ;

        <<the_end>>

        RETURN v_rtn_value;

    EXCEPTION WHEN user_err THEN
                   RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_jakup||v_curr_error,1,250));
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_jakup||v_curr_error||SQLERRM,1,250));
    END ;

END;
/
