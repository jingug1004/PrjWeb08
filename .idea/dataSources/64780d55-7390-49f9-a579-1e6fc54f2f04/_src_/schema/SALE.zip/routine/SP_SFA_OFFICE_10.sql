CREATE PROCEDURE      SP_SFA_OFFICE_10
(
    in_DEPT_CD           IN  VARCHAR2,     -- 부서코드
    in_SAWON_ID          IN  VARCHAR2,     -- 사원번호
    in_DT_FR             IN  VARCHAR2,     -- 기준일자 FROM
    in_DT_TO             IN  VARCHAR2,     -- 기준일자 TO
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
BEGIN
 /*---------------------------------------------------------------------------
 프로그램명   : 정산관리_카드내역조회  105 버전으로대체 
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    
    SELECT COUNT(*)
      INTO v_num
      FROM SALE0601 A
     WHERE A.USE_DT         BETWEEN in_DT_FR AND in_DT_TO
       AND A.DEPT_CD        LIKE  NVL(in_DEPT_CD, '%')
       AND A.SAWON_ID       LIKE  NVL(in_SAWON_ID, '%')
   ;
    
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_OFFICE_10','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||' / v_num:'||to_char(v_num));
--COMMIT;
   
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
     
        OPEN out_RESULT FOR
        SELECT A.CARD_NO                                                                                  AS out_CARD_NO              -- 카드번호
             , A.USE_DT                                                                                   AS out_USE_DT               -- 사용일자
             , A.USE_TM                                                                                   AS out_USE_TM               -- 사용시간
             , A.CARD_OK_NO                                                                               AS out_CARD_OK_NO           -- 카드승인번호
             , A.USE_GUBUN                                                                                AS out_USE_GUBUN            -- 사용구분(03:매입, 04:매입취소)
             , DECODE(A.USE_GUBUN, '03', '매입', '04', '매입취소')                                        AS out_USE_GUBUN_NM         -- 사용구분명
             , A.SAWON_ID                                                                                 AS out_SAWON_ID             -- 사원아이디(카드소지자)
             , F_SAWON_NM(A.SAWON_ID)                                                                     AS out_SAWON_NM             -- 사원명
             , A.DEPT_CD                                                                                  AS out_DEPT_CD              -- 부서
             , (SELECT DEPT_NM FROM SALE0008 WHERE DEPT_CD = A.DEPT_CD)                                   AS out_DEPT_NM              -- 부서명
             , A.USE_AMT                                                                                  AS out_USE_AMT              -- 카드 사용금액
             , A.SAUPJANG_NM                                                                              AS out_SAUPJANG_NM          -- 가맹점명
             , A.SAUP_NO                                                                                  AS out_SAUP_NO              -- 가맹점 사업자번호
             , A.TAX_GB                                                                                   AS out_TAX_GB               -- 가맹점 과세구분(1:간이, 2:일반, 3:면세)
             , DECODE(A.TAX_GB, '1', '간이', '02', '일반', '3', '면세')                                   AS out_TAX_GB_NM            -- 가맹점 과세구분명
             , A.GAEJUNG_CD                                                                               AS out_GAEJUNG_CD           -- 계정과목
             , A.USE_DETAIL                                                                               AS out_USE_DETAIL           -- 사용내역 상세
             , A.TEAMJANG_CONF_YN                                                                         AS out_TEAMJANG_CONF_YN     -- 입력완료여부 (N:진행, Y:완료)
             , DECODE(A.TEAMJANG_CONF_YN, 'N', '진행', 'Y', '완료')                                       AS out_TEAMJANG_CONF_NM     -- 입력완료 여부명
             , A.TEAMJANG_CONF_SABUN                                                                      AS out_TEAMJANG_CONF_ID     -- 입력확인자
             , F_SAWON_NM(A.TEAMJANG_CONF_SABUN)                                                          AS out_TEAMJANG_CONF_ID_NM  -- 입력확인자명
             , NVL((SELECT 'Y' FROM SALE0603 WHERE CARD_NO = A.CARD_NO AND USE_DT = A.USE_DT  
                       AND USE_TM = A.USE_TM AND CARD_OK_NO = A.CARD_OK_NO AND LENGTH(PHOTO1) > 0), 'N')  AS out_BLOB_BILL            -- 증빙사진 반영 여부
             , A.GONGJAE_YN                                                                               AS out_GONGJAE_YN           -- 공제여부 (1:선택안함, 2:공제, 3:비공제)
             , DECODE(A.GONGJAE_YN, '1', '선택안함', '2', '공제', '비공제')                               AS out_GONGJAE_NM           -- 공제여부명
          FROM SALE0601 A
         WHERE A.USE_DT         BETWEEN in_DT_FR AND in_DT_TO
           AND A.DEPT_CD        LIKE  NVL(in_DEPT_CD, '%')
           AND A.SAWON_ID       LIKE  NVL(in_SAWON_ID, '%')
         ORDER BY A.USE_DT;
        
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
