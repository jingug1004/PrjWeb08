CREATE PROCEDURE      SP_SFA_PART
(
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
BEGIN
 /*---------------------------------------------------------------------------
 프로그램명   : PART 검색
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    
    SELECT COUNT(*)
      INTO v_num
      FROM hanahr.HR_CO_DEPART_0
     WHERE LEVEL = 2
       AND USE_YN = 'Y'
   CONNECT BY PRIOR DEPT_CD = UP_DEPT_CD
     START WITH  DEPT_CD = '0023'  --영업부 ‘0023’
     ORDER BY SORT_NO;
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT DEPT_CD           AS out_PART_CD    -- PART 번호
             , DEPT_KO_NM         AS out_PART_NM    -- PART 명
          FROM hanahr.HR_CO_DEPART_0 
         WHERE LEVEL = 2
           AND USE_YN = 'Y'
       CONNECT BY PRIOR DEPT_CD = UP_DEPT_CD
         START WITH  DEPT_CD = '0023'  --영업부 ‘0023’
         ORDER BY SORT_NO;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
