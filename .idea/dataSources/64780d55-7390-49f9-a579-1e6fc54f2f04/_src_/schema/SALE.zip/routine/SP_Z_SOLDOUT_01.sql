CREATE PROCEDURE      SP_Z_SOLDOUT_01
(
    in_ITEM_CD           IN  VARCHAR2,   -- 제품코드
    in_ITEM_NM           IN  VARCHAR2,   -- 제품 명
    in_REG_DATE         IN  VARCHAR2,   -- 조회시각  type yyyymmdd
    out_CODE              OUT NUMBER,
    out_MSG                OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
/*---------------------------------------------------------------------------
프로그램명  : 품절현황 
호출프로그램 : state.soldout       
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼   
---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
--    insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDERCUST_LIST','1',sysdate,'in_CUST_CD'||in_CUST_CD||' / in_CUST_NM:'||in_CUST_NM||'/in_SAWON_ID:'||in_SAWON_ID);
     
      SELECT COUNT(*)
        INTO v_num
        FROM SALE.SALE0705_1 a
            ,ORAGMP.CMITEMM b
      WHERE a.item_id = b.itemcode  
        AND a.item_id   LIKE '%'||NVL(in_ITEM_CD, '%')||'%'
        AND b.itemname  LIKE '%'||NVL(in_ITEM_NM, '%')||'%'
        AND SUBSTR(a.reg_date ,1 ,8) <= in_REG_DATE
        ;
    
        out_COUNT := v_num;
        
        IF (v_num = 0) THEN
             out_CODE := 1;
             out_MSG := '검색내용이 없습니다.';
        ELSIF (v_num >= 1) THEN
             out_CODE := 0;
             out_MSG := '검색 확인완료';    
         
             OPEN out_RESULT FOR
             SELECT a.item_id                AS out_ITEM_ID,     -- 제품코드
                    b.itemname               AS out_ITEM_NM,     -- 제품명
                    b.unit                   AS out_STANDARD,    -- 규격                
                    a.due_date               AS out_DUE_DATE,    -- 입고예정일
                    a.explanation            AS out_EXPLANATION, -- 비고
                    SUBSTR(a.reg_date ,1 ,8) AS out_REG_DATE
                FROM SALE.SALE0705_1 a
                    ,ORAGMP.CMITEMM b
              WHERE a.item_id = b.itemcode  
                AND a.item_id   LIKE '%'||NVL(in_ITEM_CD, '%')||'%'
                AND b.itemname  LIKE '%'||NVL(in_ITEM_NM, '%')||'%'
                AND SUBSTR(a.reg_date ,1 ,8) <= in_REG_DATE
              ORDER BY a.due_date desc ,b.itemname 
              ;
              
        END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
