CREATE PROCEDURE      SP_X_APP_GETITEMYNLIST
(
    in_GUMAE_NO  IN VARCHAR2,
    out_ITEM_GB OUT VARCHAR2,
    out_CODE    OUT NUMBER,
    out_MSG     OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_APP_GETITEMYNLIST
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	SELECT ITEM_GB1 INTO out_ITEM_GB
		  FROM SALE.SALE0004 a, SALE_ON.SALE0204 b
		 WHERE a.ITEM_ID = b.ITEM_ID
		   AND b.GUMAE_NO = in_GUMAE_NO;

    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
