CREATE PROCEDURE      SP_SFA_RORDER_LIST   
(
    in_SAWON_ID          IN  VARCHAR2,   
    in_CUST_ID           IN  VARCHAR2,    
    in_RCUST_ID          IN  VARCHAR2,    
    in_CDT_FR            IN  VARCHAR2,    
    in_CDT_TO            IN  VARCHAR2,    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 간납처 주문현황
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num         NUMBER;
    v_SILSAWON_ID VARCHAR2(7);
    
BEGIN

    --실사원id를 찾는다.
    select sil_sawon_id into v_SILSAWON_ID from sale0007 where sawon_id = in_SAWON_ID;
    
    IF v_silsawon_id IS NULL OR v_silsawon_id = '' THEN
       out_CODE := 1;
       out_MSG := '사번 ' || in_SAWON_ID || ' 은 실사원아이디가 존재하지 않습니다. 관리자에게 문의 하십시오.';
       RETURN;
    END IF;

    -- 로그인한 사원의 납품처에 납품된 제품중 거래처별단가테이블에서 담당제품으로 주문된것들...
    SELECT COUNT(*)
      INTO v_num
      FROM SALE0203 a
     WHERE a.gumae_no in (           
                    select distinct a.gumae_no 
                      from SALE0203 a
                          ,SALE0204 b
                          ,SALE0405 c
                     where a.gumae_no = b.gumae_no
                       and a.cust_id  = c.cust_id
                       and a.rcust_id = c.rcust_id
                       and b.item_id  = c.item_id       
                       and a.rsawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)
                       --and F_GET_SALE0405_SAWONIDH (a.gumae_no, a.CUST_ID, a.RCUST_ID, b.ITEM_ID, a.YMD) in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)
                       and a.ymd between to_date(in_CDT_FR,'YYYYMMDD') AND to_date(in_CDT_TO,'YYYYMMDD')
                       and a.cust_id like NVL(in_CUST_ID,'%')
                       and a.rcust_id like NVL(in_RCUST_ID,'%')
                    )     
     ;
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDER_LIST','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||'/in_CUST_ID'||in_CUST_ID||' / v_num:'||to_char(v_num));
--COMMIT
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
        out_CODE := 1;
        out_MSG := '조회한 내역이 존재하지 않습니다.';   
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
    
        OPEN out_RESULT FOR
        SELECT A.GUMAE_NO                       AS out_GUMAE_NO,
               A.YMD                            AS out_ORDER_DATE,
               DECODE( A.GUBUN, '01', '출고',  '02', '샘플', '07', '매출할인', '08', '수금할인', '09', '수출', '10', '반품', '11', '수취거부', '12', '매출할인', '13', '수금할인', '14', '판매대행수수료', '15', '수입수수료', '20', '기부출고', A.GUBUN) AS out_GUBUN,
               DECODE( A.ACCEPT_YN, 'Y', '대기','S','승인', '검토') AS OUT_ACCEPT_YN,
               A.CUST_ID                        AS out_CUST_ID,   
               A.RCUST_ID                       AS out_RCUST_ID,   
               F_CUST_NM(TO_NUMBER(A.CUST_ID))  AS out_CUST_NM,   
               F_CUST_NM(TO_NUMBER(A.RCUST_ID)) AS out_RCUST_NM,   
               A.AMT_SUM                        AS out_AMT_SUM,
               A.VAT_SUM                        AS out_VAT_SUM,
               A.AMT_SUM + A.VAT_SUM            AS out_AMOUNT,
               A.SAWON_ID                       AS out_SAWON_ID,
               A.RSAWON_ID                      AS out_RSAWON_ID,
               F_SAWON_NM(A.SAWON_ID)           AS out_SAWON_NM,
               F_SAWON_NM(A.RSAWON_ID)          AS out_RSAWON_NM
          FROM SALE0203 A
         WHERE gumae_no in (           
                        select distinct a.gumae_no 
                          from SALE0203 a
                              ,SALE0204 b
                              ,SALE0405 c
                         where a.gumae_no = b.gumae_no
                           and a.cust_id  = c.cust_id
                           and a.rcust_id = c.rcust_id
                           and b.item_id  = c.item_id       
                           and a.rsawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)
                           --and F_GET_SALE0405_SAWONIDH (a.gumae_no, a.CUST_ID, a.RCUST_ID, b.ITEM_ID, a.YMD) in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)
                           and a.ymd between to_date(in_CDT_FR,'YYYYMMDD') AND to_date(in_CDT_TO,'YYYYMMDD')
                           and a.cust_id like NVL(in_CUST_ID,'%')
                           and a.rcust_id like NVL(in_RCUST_ID,'%')
                        )     
           ORDER BY A.GUMAE_NO DESC;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
