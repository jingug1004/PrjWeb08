CREATE PROCEDURE      SP_X_INFO_CUSTOMERDETAIL
(
    in_CUST_ID    IN VARCHAR2,
    out_RESULT    OUT TYPES.CURSOR_TYPE,
    out_CODE      OUT NUMBER,
    out_MSG       OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INFO_CUSTOMERDETAIL
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  거래처 기타 상세정보 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    OPEN out_RESULT FOR	
       SELECT CUST_ID,
		       CUST_NM, 
		       CUST_NM1, 
		       VOU_NO, 
		       PRESIDENT,
		       BUPIN_NO,
		       UPTAE,
		       JONGMOK, 
		       ZIP, 
		       ADDR1,
		       ADDR2,
		       TEL,
		       HP,
		       FAX, 
		       EMAIL,
		       (SELECT CODE1_NM FROM SALE.SALE0001 WHERE CODE_GB = '0020' AND CODE1 = CUST_GB1) CUST_GB1,
		       ROOM_CNT,
		       TO_CHAR(TO_DATE(OPEN_DATE), 'YYYY-MM-DD') OPEN_DATE,
		       TO_CHAR(START_YMD, 'YYYY-MM-DD') START_YMD,
		       TO_CHAR(USE_YMD, 'YYYY-MM-DD') USE_YMD, 
		       TO_CHAR(TO_DATE(SUBMIT_DATE), 'YYYY-MM-DD') SUBMIT_DATE,
		       BEDNO 
		  FROM SALE.SALE0003
		 WHERE CUST_ID = in_CUST_ID;
		 
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
