CREATE PROCEDURE      SP_Z_COLLECT_05
(
    in_SAWON_ID          IN  VARCHAR2,     -- 사원 ID
    in_DEPT_CD           IN  VARCHAR2,     -- 부서코드
    in_CUST_CD           IN  VARCHAR2,     -- 거래처코드
    in_DT_FR             IN  VARCHAR2,     -- 기준일자 FROM
    in_DT_TO             IN  VARCHAR2,     -- 기준일자 TO
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처원장
 호출프로그램 :       
 수정내역    2015.04.28 kta 부서코드 체크하는 부분은 막음.어차피 거래처 선택시 로그인사원이 볼수 있는 거래처만 선택할수 있기 때문에 의미 없음.
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    p_frdate             VARCHAR2(10);
    p_todate             VARCHAR2(10);
    p_dayopen            VARCHAR2(10);  -- 일계 표시여부
    p_monopen            VARCHAR2(10);  -- 월계 표시여부
    
BEGIN
    p_frdate := TO_CHAR(to_date(in_DT_FR,'YYYYMMDD'),'YYYY-MM-DD');
    p_todate := TO_CHAR(to_date(in_DT_TO,'YYYYMMDD'),'YYYY-MM-DD'); 
    p_dayopen := 'Y';
    p_monopen := 'Y'; 

--insert into SFA_SP_CALLED_HIST values ('KTA_SP_Z_COLLECT_05',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SAWON_ID,sysdate,'in_CUST_CD:'||in_CUST_CD||'/p_frdate '||p_frdate ||'/p_todate '||p_todate);
--commit;


    SELECT COUNT(*)  
      INTO v_num
      FROM (
               SELECT *
                 FROM
                    ( SELECT '0' || TO_CHAR(TO_DATE(p_frdate,'YYYY/MM/DD') - 1,'YYYY-MM-DD')      AS gb       ,  --자료순서
                             TO_CHAR(TO_DATE(p_frdate,'YYYY/MM/DD') - 1,'YYYY-MM-DD')             AS appdate  ,  --거래일자
                             '0'                                                                  AS orderno  ,  --전표번호
                             0                                                                    AS seq      ,  --거래순번
                             ''                                                                   AS saldiv   ,  --영업구분
                             ''                                                                   AS saldivnm ,  --영업구분명
                             ''                                                                   AS ecustcode,  --간납처코드
                             ''                                                                   AS ecustname,  --간납처명
                             ''                                                                   AS itemcode ,  --제품코드
                             '전기이월'                                                               AS itemname ,  --제품명
                             ''                                                                   AS unit     ,  --규격
                             0                                                                    AS salqty   ,  --수량
                             0                                                                    AS salprc   ,  --단가
                             0                                                                    AS salvat   ,  --부가세
                             0                                                                    AS salamt   ,  --공급가액 
                             0                                                                    AS totamt   ,  --합계
                             0                                                                    AS colamt   ,  --수금액
                             ''                                                                   AS orderdiv ,  --영업영역
                             ''                                                                   AS ordername,  --영업영역명
                             ''                                                                   AS remark   ,  --비고
                             SUM(A.REMAMT)                                                        AS remamt   ,  --잔고산출용
                             0                                                                    AS turncnt
                        FROM
                           ( --전월잔고
                             SELECT NVL(SUM(A.BALANCE),0) AS REMAMT
                               FROM oragmp.SLRESULTM A
                              WHERE A.YEARMONTH = TO_CHAR(TO_DATE(substr(p_frdate,1,7)||'-01','YYYY/MM/DD') - 1,'YYYY-MM')
                                AND A.CUSTCODE  = in_CUST_CD
                          UNION ALL
                             --1일부터 시작전일까지의 판매 금액산출
                             SELECT NVL(SUM(CASE WHEN SUBSTR(A.SALDIV,1,1) = 'A'
                                                 THEN  B.TOTAMT
                                                 ELSE -B.TOTAMT
                                            END),0) AS AMT
                               FROM oragmp.SLORDM A,
                                    oragmp.SLORDD B
                              WHERE A.STATEDIV   = '09'
                                AND A.ORDERNO    = B.ORDERNO
                                AND A.ORDERDATE >= substr(p_frdate,1,7)||'-01'
                                AND A.ORDERDATE <  TO_CHAR(TO_DATE(p_frdate,'YYYY/MM/DD') - 1,'YYYY-MM-DD')
                                AND A.CUSTCODE   = in_CUST_CD
                          UNION ALL
                             --1일부터 시작전일까지의 수금 금액산출
                             SELECT NVL(SUM(-A.COLAMT),0) AS AMT
                               FROM oragmp.SLCOLM A
                              WHERE A.STATEDIV   = '09'
                                AND A.COLDATE   >= substr(p_frdate,1,7)||'-01'
                                AND A.COLDATE   <  TO_CHAR(TO_DATE(p_frdate,'YYYY/MM/DD') - 1,'YYYY-MM-DD')
                                AND A.CUSTCODE   = in_CUST_CD
                           ) A
                   UNION ALL
                      SELECT '1' || A.ORDERDATE                                                   AS gb       ,  --자료순서
                             A.ORDERDATE                                                          AS appdate  ,  --거래일자
                             A.ORDERNO                                                            AS orderno  ,  --전표번호
                             B.SEQ                                                                AS seq      ,  --거래순번
                             A.SALDIV                                                             AS saldiv   ,  --영업구분
                             S.DIVNAME                                                            AS saldivnm ,  --영업구분명
                             A.ECUSTCODE                                                          AS ecustcode,  --간납처코드
                             H.CUSTNAME                                                           AS ecustname,  --간납처명
                             B.ITEMCODE                                                           AS itemcode ,  --제품코드
                             I.ITEMNAME                                                           AS itemname ,  --제품명
                             I.ITEMUNIT                                                           AS unit     ,  --규격
                             CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALQTY ELSE -B.SALQTY END  AS salqty   ,  --수량
                             B.SALPRC                                                             AS salprc   ,  --단가
                             CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALVAT ELSE -B.SALVAT END  AS salvat   ,  --부가세
                             CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALAMT ELSE -B.SALAMT END  AS salamt   ,  --공급가액
                             CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.TOTAMT ELSE -B.TOTAMT END  AS totamt   ,  --합계
                             0                                                                    AS colamt   ,  --수금액
                             A.ORDERDIV                                                           AS orderdiv ,  --영업영역
                             T.DIVNAME                                                            AS ordername,  --영업영역명
                             A.REMARK                                                             AS remark   ,  --비고
                             CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.TOTAMT ELSE -B.TOTAMT END  AS remamt   ,   --잔고산출용
                             0                                                                    AS turncnt
                        FROM oragmp.SLORDM    A,
                             oragmp.SLORDD    B,
                             oragmp.CMCUSTM   H,
                             oragmp.CMITEMM   I,
                             oragmp.CMCOMMONM S,
                             oragmp.CMCOMMONM T
                       WHERE A.STATEDIV  = '09'
                         AND A.ORDERNO   = B.ORDERNO
                         AND A.ECUSTCODE = H.CUSTCODE
                         AND 'SL10'      = S.CMMCODE (+)
                         AND A.SALDIV    = S.DIVCODE (+)
                         AND 'SL43'      = T.CMMCODE (+)
                         AND A.ORDERDIV  = T.DIVCODE (+)
                         AND B.ITEMCODE  = I.ITEMCODE(+)
                         AND A.ORDERDATE BETWEEN p_frdate AND p_todate
                         AND A.CUSTCODE  = in_CUST_CD
                   UNION ALL
                      SELECT '1' || A.COLDATE                                                            AS gb       ,  --자료순서
                             A.COLDATE                                                                   AS appdate  ,  --거래일자
                             A.COLNO                                                                     AS orderno  ,  --전표번호
                             TO_NUMBER(A.COLSEQ)                                                         AS seq      ,  --거래순번
                             A.COLDIV                                                                    AS saldiv   ,  --영업구분
                             S.DIVNAME                                                                   AS saldivnm ,  --영업구분명
                             A.ECUSTCODE                                                                 AS ecustcode,  --간납처코드
                             H.CUSTNAME                                                                  AS ecustname,  --간납처명
                             ''                                                                          AS itemcode ,  --제품코드
                             CASE WHEN A.COLDIV LIKE '3%' THEN NVL(A.BILLNO, 'unknown') || ':' || A.EXPDATE                                                          --어음번호와 만기일자
                                  WHEN SUBSTR(A.COLDIV, 1, 1) = '1' THEN I.ACCREMARK || ':' || NVL(A.ACCOUNTNO,'')                                                   --계좌은행
                                  WHEN SUBSTR(A.COLDIV, 1, 1) = '2' THEN (CASE WHEN (NVL (A.DIVMONTH, 0) = 0) THEN U.DIVNAME                                         --카드사
                                                                               WHEN (NVL (A.DIVMONTH, 0) > 0) THEN U.DIVNAME || ' ' || TO_CHAR(A.DIVMONTH) || '개월' --카드사
                                                                                                              ELSE ''
                                                                          END)
                                  ELSE ''
                             END                                                                            AS itemname ,  --제품명
                             ''                                                                             AS unit     ,  --규격
                             0                                                                              AS salqty   ,  --수량
                             0                                                                              AS salprc   ,  --단가
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLVAT              ELSE 0 END   AS salvat   ,  --부가세
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -(A.COLAMT - A.COLVAT) ELSE 0 END   AS salamt   ,  --공급가액
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT              ELSE 0 END   AS totamt   ,  --합계
                             CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT               ELSE 0 END   AS colamt   ,  --수금액
                             A.ORDERDIV                                                                     AS orderdiv ,  --영업영역
                             T.DIVNAME                                                                      AS ordername,  --영업영역명
                             A.REMARK                                                                       AS remark   ,  --비고
                             -A.COLAMT                                                                      AS remamt   ,  --잔고산출용
                             0                                                                              AS turncnt
                        FROM oragmp.SLCOLM     A,
                             oragmp.CMCUSTM    H,
                             oragmp.CMACCOUNTM I,
                             oragmp.CMCOMMONM  S,
                             oragmp.CMCOMMONM  T,
                             oragmp.CMCOMMONM  U
                       WHERE A.STATEDIV  = '09'
                         AND A.ECUSTCODE = H.CUSTCODE
                         AND A.ACCOUNTNO = I.ACCOUNTNO(+)
                         AND 'SL18'      = S.CMMCODE  (+)
                         AND A.COLDIV    = S.DIVCODE  (+)
                         AND 'SL43'      = T.CMMCODE  (+)
                         AND A.ORDERDIV  = T.DIVCODE  (+)
                         AND 'AC17'      = U.CMMCODE  (+)
                         AND A.CARDCOMP  = U.DIVCODE  (+)
                         AND A.COLDATE BETWEEN p_frdate AND p_todate
                         AND A.CUSTCODE  = in_CUST_CD
                   UNION ALL
                      SELECT '1' || A.appdate || '-99'                                                   AS gb       ,  --자료순서
                             ''                                                                          AS appdate  ,  --거래일자
                             '0'                                                                         AS orderno  ,  --전표번호
                             0                                                                           AS seq      ,  --거래순번
                             'Z99'                                                                       AS saldiv   ,  --영업구분
                             ''                                                                          AS saldivnm ,  --영업구분명
                             ''                                                                          AS ecustcode,  --간납처코드
                             ''                                                                          AS ecustname,  --간납처명
                             ''                                                                          AS itemcode ,  --제품코드
                             REPLACE(A.appdate, '-', '/') || ' 일 계'                                    AS itemname ,  --제품명
                             ''                                                                          AS unit     ,  --규격
                             0                                                                           AS salqty   ,  --수량
                             0                                                                           AS salprc   ,  --단가
                             SUM(A.SALVAT)                                                               AS salvat   ,  --부가세
                             SUM(A.SALAMT)                                                               AS salamt   ,  --공급가액
                             SUM(A.TOTAMT)                                                               AS totamt   ,  --합계
                             SUM(A.COLAMT)                                                               AS colamt   ,  --수금액
                             ''                                                                          AS orderdiv ,  --영업영역
                             ''                                                                          AS ordername,  --영업영역명
                             ''                                                                          AS remark   ,  --비고
                             0                                                                           AS remamt   ,   --잔고산출용
                             0                                                                           AS turncnt
                        FROM
                           ( SELECT A.ORDERDATE                                                          AS appdate  ,  --거래일자
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALVAT ELSE -B.SALVAT END  AS SALVAT   ,  --부가세
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALAMT ELSE -B.SALAMT END  AS SALAMT   ,  --공급가액
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.TOTAMT ELSE -B.TOTAMT END  AS TOTAMT   ,  --합계
                                    0                                                                    AS COLAMT      --수금액
                               FROM oragmp.SLORDM    A,
                                    oragmp.SLORDD    B
                              WHERE A.STATEDIV  = '09'
                                AND A.ORDERNO   = B.ORDERNO
                                AND A.ORDERDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                          UNION ALL
                             SELECT A.COLDATE                                                                     AS appdate  ,  --거래일자
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLVAT              ELSE 0 END  AS salvat   ,  --부가세
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -(A.COLAMT - A.COLVAT) ELSE 0 END  AS salamt   ,  --공급가액
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT              ELSE 0 END  AS totamt   ,  --합계
                                    CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT               ELSE 0 END  AS colamt      --수금액
                               FROM oragmp.SLCOLM     A
                              WHERE A.STATEDIV  = '09'
                                AND A.COLDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                           ) A
                       WHERE p_dayopen = 'Y'
                    GROUP BY A.appdate
                   UNION ALL
                      SELECT '1' || a.appdate || '-98-99'                                                      AS gb       ,  --자료순서
                             ''                                                                                AS appdate  ,  --거래일자
                             '0'                                                                               AS orderno  ,  --전표번호
                             0                                                                                 AS seq      ,  --거래순번
                             'Z99'                                                                             AS saldiv   ,  --영업구분
                             ''                                                                                AS saldivnm ,  --영업구분명
                             ''                                                                                AS ecustcode,  --간납처코드
                             ''                                                                                AS ecustname,  --간납처명
                             ''                                                                                AS itemcode ,  --제품코드
                             REPLACE(A.appdate, '-', '/') || ' 월 계'                                          AS itemname ,  --제품명
                             ''                                                                                AS unit     ,  --규격
                             0                                                                                 AS salqty   ,  --수량
                             0                                                                                 AS salprc   ,  --단가
                             SUM(A.SALVAT)                                                                     AS salvat   ,  --부가세
                             SUM(A.SALAMT)                                                                     AS salamt   ,  --공급가액
                             SUM(A.TOTAMT)                                                                     AS totamt   ,  --합계
                             SUM(A.COLAMT)                                                                     AS colamt   ,  --수금액
                             ''                                                                                AS orderdiv ,  --영업영역
                             ''                                                                                AS ordername,  --영업영역명
                             ''                                                                                AS remark   ,  --비고
                             0                                                                                 AS remamt   ,  --잔고산출용
                             NVL(B.TURNCNT,0)                                                                  AS turncnt
                        FROM
                           ( SELECT A.CUSTCODE                                                                 AS CUSTCODE ,  --거래처코드
                                    SUBSTR(A.ORDERDATE,1,7)                                                    AS appdate  ,  --거래일자
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALVAT ELSE -B.SALVAT END        AS SALVAT   ,  --부가세
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALAMT ELSE -B.SALAMT END        AS SALAMT   ,  --공급가액 
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.TOTAMT ELSE -B.TOTAMT END        AS TOTAMT   ,  --합계
                                    0                                                                          AS COLAMT      --수금액
                               FROM oragmp.SLORDM     A,
                                    oragmp.SLORDD     B
                              WHERE A.STATEDIV  = '09'
                                AND A.ORDERNO   = B.ORDERNO
                                AND A.ORDERDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                          UNION ALL
                             SELECT A.CUSTCODE                                                                    AS CUSTCODE ,  --거래처코드
                                    SUBSTR(A.COLDATE,1,7)                                                         AS appdate  ,  --거래일자
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLVAT              ELSE 0 END  AS salvat   ,  --부가세
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -(A.COLAMT - A.COLVAT) ELSE 0 END  AS salamt   ,  --공급가액
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT              ELSE 0 END  AS totamt   ,  --합계
                                    CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT               ELSE 0 END  AS colamt      --수금액
                               FROM oragmp.SLCOLM     A
                              WHERE A.STATEDIV  = '09'
                                AND A.COLDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                           ) A,
                             oragmp.SLTURNCUSTM B
                       WHERE A.appdate  = B.YEARMONTH(+)
                         AND A.CUSTCODE = B.CUSTCODE (+)
                         AND p_monopen = 'Y'
                    GROUP BY A.appdate, B.TURNCNT
                   UNION ALL
                      SELECT '1' || a.appdate || '-99-99'                                                      AS gb       ,  --자료순서
                             ''                                                                                AS appdate  ,  --거래일자
                             '0'                                                                               AS orderno  ,  --전표번호
                             0                                                                                 AS seq      ,  --거래순번
                             'Z99'                                                                             AS saldiv   ,  --영업구분
                             ''                                                                                AS saldivnm ,  --영업구분명
                             ''                                                                                AS ecustcode,  --간납처코드
                             ''                                                                                AS ecustname,  --간납처명
                             ''                                                                                AS itemcode ,  --제품코드
                             REPLACE(A.appdate, '-', '/') || ' 년 계'                                          AS itemname ,  --제품명
                             ''                                                                                AS unit     ,  --규격
                             0                                                                                 AS salqty   ,  --수량
                             0                                                                                 AS salprc   ,  --단가
                             SUM(A.SALVAT)                                                                     AS salvat   ,  --부가세
                             SUM(A.SALAMT)                                                                     AS salamt   ,  --공급가액
                             SUM(A.TOTAMT)                                                                     AS totamt   ,  --합계
                             SUM(A.COLAMT)                                                                     AS colamt   ,  --수금액
                             ''                                                                                AS orderdiv ,  --영업영역
                             ''                                                                                AS ordername,  --영업영역명
                             ''                                                                                AS remark   ,  --비고
                             0                                                                                 AS remamt   ,   --잔고산출용
                             0                                                                                 AS turncnt
                        FROM
                           ( SELECT SUBSTR(A.ORDERDATE,1,4)                                                    AS appdate  ,  --거래일자
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALVAT ELSE -B.SALVAT END        AS SALVAT   ,  --부가세
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALAMT ELSE -B.SALAMT END        AS SALAMT   ,  --공급가액
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.TOTAMT ELSE -B.TOTAMT END        AS TOTAMT   ,  --합계
                                    0                                                                          AS COLAMT      --수금액
                               FROM oragmp.SLORDM     A,
                                    oragmp.SLORDD     B
                              WHERE A.STATEDIV  = '09'
                                AND A.ORDERNO   = B.ORDERNO
                                AND A.ORDERDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                          UNION ALL
                             SELECT SUBSTR(A.COLDATE,1,4)                                                         AS appdate  ,  --거래일자
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLVAT              ELSE 0 END  AS salvat   ,  --부가세
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -(A.COLAMT - A.COLVAT) ELSE 0 END  AS salamt   ,  --공급가액
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT              ELSE 0 END  AS totamt   ,  --합계
                                    CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT               ELSE 0 END  AS colamt      --수금액
                               FROM oragmp.SLCOLM     A
                              WHERE A.STATEDIV  = '09'
                                AND A.COLDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                           ) A
                    GROUP BY A.appdate
                     ) A
              ORDER BY A.GB, A.SALDIV, A.ORDERNO, A.SEQ, A.ITEMCODE             
            );
 
/*
  IF in_SAWON_ID = '39488' THEN
    insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_05','1',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'in_DEPT_CD:'||in_DEPT_CD||'in_CUST_CD:'||in_CUST_CD||' / v_num:'||to_char(v_num));
  END IF;
*/  

    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
     
        OPEN out_RESULT FOR
            SELECT TO_CHAR(to_date(APPDATE),'YYYYMM')                         AS out_YM,
                   TO_CHAR(to_date(APPDATE), 'YYYYMMDD')                      AS out_YMD,               -- 일자
                   ''                                                         AS out_CUST_ID,
                   ECUSTCODE                                                  AS out_RCUST_ID,
                   ''                                                         AS out_VOU_NO,
                   ''                                                         AS out_CUST_NM,
                   ''                                                         AS out_ADDR,
                   ''                                                         AS out_PRESIDENT,
                   ''                                                         AS out_SAWON_ID,
                   ''                                                         AS out_SAWON_NM,
                   ECUSTNAME                                                  AS out_RCUST_NM,
                   ITEMCODE                                                   AS out_ITEM_ID,          -- 제품ID
                   ITEMNAME                                                   AS out_ITEM_NM,          -- 제품명
                   UNIT                                                       AS out_STANDARD,         -- 규격
                   SALQTY                                                     AS out_QTY,              -- 수량
                   SALPRC                                                     AS out_DANGA,            -- 단가
                   SALAMT                                                     AS out_AMT,              -- 공급가액
                   SALVAT                                                     AS out_VAT,              -- 부가세
                   COLAMT                                                     AS out_SUKUM,            -- 수금액
                   SALAMT + SALVAT                                            AS out_TOT,              -- 합계금액
                   0                                                          AS out_BEFORE_AMT,       -- 이월금액
                   ORDERNO                                                    AS out_DEAL_NO,
                   SEQ                                                        AS out_INPUT_SEQ,
                   0                                                          AS out_DC_AMT,
                   0                                                          AS out_DC_QTY,
                   0                                                          AS out_DC_EN_AMT,
                   0                                                          AS out_DC_EN_YN,
                   ''                                                         AS out_TEL,
                   SALAMT + SALVAT ||'/'|| COLAMT                             AS out_BIGO,            -- 비고,
                   TO_CHAR(p_frdate)                                          AS out_DATEF,
                   TO_CHAR(p_todate)                                          AS out_DATET,                                   
                   JANGOAMT                                                   AS out_JAN_AMT,         --잔액
                   0                                                          AS out_TOT_DC_AMT       -- 매출할인
          from ( 
               SELECT A.GB         AS GB        ,  --자료순서
                      A.APPDATE    AS APPDATE   ,  --거래일자
                      A.ORDERNO    AS ORDERNO   ,  --전표번호
                      A.SEQ        AS SEQ       ,  --거래순번
                      A.SALDIV     AS SALDIV    ,  --영업구분
                      A.SALDIVNM   AS SALDIVNM  ,  --영업구분명
                      A.ECUSTCODE  AS ECUSTCODE ,  --간납처코드
                      A.ECUSTNAME  AS ECUSTNAME ,  --간납처명
                      A.ITEMCODE   AS ITEMCODE  ,  --제품코드
                      A.ITEMNAME   AS ITEMNAME  ,  --제품명
                      A.UNIT       AS UNIT      ,  --규격
                      A.SALQTY     AS SALQTY    ,  --수량
                      A.SALPRC     AS SALPRC    ,  --단가
                      A.SALAMT     AS SALAMT    ,  --공급가액
                      A.SALVAT     AS SALVAT    ,  --브가세
                      A.TOTAMT     AS TOTAMT    ,  --합계
                      A.COLAMT     AS COLAMT    ,  --수금액
                      A.ORDERDIV   AS ORDERDIV  ,  --영업영역
                      A.ORDERNAME  AS ORDERNAME ,  --영업영역명
                      A.REMARK     AS REMARK    ,  --비고
                      A.REMAMT     AS REMAMT    ,  --잔고산출용
                      A.TURNCNT    AS TURNCNT   ,  --월별회전일수
                      SUM(A.REMAMT) OVER(ORDER BY A.GB, A.SALDIV, A.ORDERNO, A.SEQ, A.ITEMCODE) AS JANGOAMT  --잔고
                 FROM
                    ( SELECT '0' || TO_CHAR(TO_DATE(p_frdate,'YYYY/MM/DD') - 1,'YYYY-MM-DD')      AS gb       ,  --자료순서
                             TO_CHAR(TO_DATE(p_frdate,'YYYY/MM/DD') - 1,'YYYY-MM-DD')             AS appdate  ,  --거래일자
                             '0'                                                                  AS orderno  ,  --전표번호
                             0                                                                    AS seq      ,  --거래순번
                             ''                                                                   AS saldiv   ,  --영업구분
                             ''                                                                   AS saldivnm ,  --영업구분명
                             ''                                                                   AS ecustcode,  --간납처코드
                             ''                                                                   AS ecustname,  --간납처명
                             ''                                                                   AS itemcode ,  --제품코드
                             '전기이월'                                                               AS itemname ,  --제품명
                             ''                                                                   AS unit     ,  --규격
                             0                                                                    AS salqty   ,  --수량
                             0                                                                    AS salprc   ,  --단가
                             0                                                                    AS salvat   ,  --부가세
                             0                                                                    AS salamt   ,  --공급가액 
                             0                                                                    AS totamt   ,  --합계
                             0                                                                    AS colamt   ,  --수금액
                             ''                                                                   AS orderdiv ,  --영업영역
                             ''                                                                   AS ordername,  --영업영역명
                             ''                                                                   AS remark   ,  --비고
                             SUM(A.REMAMT)                                                        AS remamt   ,  --잔고산출용
                             0                                                                    AS turncnt
                        FROM
                           ( --전월잔고
                             SELECT NVL(SUM(A.BALANCE),0) AS REMAMT
                               FROM oragmp.SLRESULTM A
                              WHERE A.YEARMONTH = TO_CHAR(TO_DATE(substr(p_frdate,1,7)||'-01','YYYY/MM/DD') - 1,'YYYY-MM')
                                AND A.CUSTCODE  = in_CUST_CD
                          UNION ALL
                             --1일부터 시작전일까지의 판매 금액산출
                             SELECT NVL(SUM(CASE WHEN SUBSTR(A.SALDIV,1,1) = 'A'
                                                 THEN  B.TOTAMT
                                                 ELSE -B.TOTAMT
                                            END),0) AS AMT
                               FROM oragmp.SLORDM A,
                                    oragmp.SLORDD B
                              WHERE A.STATEDIV   = '09'
                                AND A.ORDERNO    = B.ORDERNO
                                AND A.ORDERDATE >= substr(p_frdate,1,7)||'-01'
                                AND A.ORDERDATE <  TO_CHAR(TO_DATE(p_frdate,'YYYY/MM/DD') - 1,'YYYY-MM-DD')
                                AND A.CUSTCODE   = in_CUST_CD
                          UNION ALL
                             --1일부터 시작전일까지의 수금 금액산출
                             SELECT NVL(SUM(-A.COLAMT),0) AS AMT
                               FROM oragmp.SLCOLM A
                              WHERE A.STATEDIV   = '09'
                                AND A.COLDATE   >= substr(p_frdate,1,7)||'-01'
                                AND A.COLDATE   <  TO_CHAR(TO_DATE(p_frdate,'YYYY/MM/DD') - 1,'YYYY-MM-DD')
                                AND A.CUSTCODE   = in_CUST_CD
                           ) A
                   UNION ALL
                      SELECT '1' || A.ORDERDATE                                                   AS gb       ,  --자료순서
                             A.ORDERDATE                                                          AS appdate  ,  --거래일자
                             A.ORDERNO                                                            AS orderno  ,  --전표번호
                             B.SEQ                                                                AS seq      ,  --거래순번
                             A.SALDIV                                                             AS saldiv   ,  --영업구분
                             S.DIVNAME                                                            AS saldivnm ,  --영업구분명
                             A.ECUSTCODE                                                          AS ecustcode,  --간납처코드
                             H.CUSTNAME                                                           AS ecustname,  --간납처명
                             B.ITEMCODE                                                           AS itemcode ,  --제품코드
                             I.ITEMNAME                                                           AS itemname ,  --제품명
                             I.ITEMUNIT                                                           AS unit     ,  --규격
                             CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALQTY ELSE -B.SALQTY END  AS salqty   ,  --수량
                             B.SALPRC                                                             AS salprc   ,  --단가
                             CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALVAT ELSE -B.SALVAT END  AS salvat   ,  --부가세
                             CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALAMT ELSE -B.SALAMT END  AS salamt   ,  --공급가액
                             CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.TOTAMT ELSE -B.TOTAMT END  AS totamt   ,  --합계
                             0                                                                    AS colamt   ,  --수금액
                             A.ORDERDIV                                                           AS orderdiv ,  --영업영역
                             T.DIVNAME                                                            AS ordername,  --영업영역명
                             A.REMARK                                                             AS remark   ,  --비고
                             CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.TOTAMT ELSE -B.TOTAMT END  AS remamt   ,   --잔고산출용
                             0                                                                    AS turncnt
                        FROM oragmp.SLORDM    A,
                             oragmp.SLORDD    B,
                             oragmp.CMCUSTM   H,
                             oragmp.CMITEMM   I,
                             oragmp.CMCOMMONM S,
                             oragmp.CMCOMMONM T
                       WHERE A.STATEDIV  = '09'
                         AND A.ORDERNO   = B.ORDERNO
                         AND A.ECUSTCODE = H.CUSTCODE
                         AND 'SL10'      = S.CMMCODE (+)
                         AND A.SALDIV    = S.DIVCODE (+)
                         AND 'SL43'      = T.CMMCODE (+)
                         AND A.ORDERDIV  = T.DIVCODE (+)
                         AND B.ITEMCODE  = I.ITEMCODE(+)
                         AND A.ORDERDATE BETWEEN p_frdate AND p_todate
                         AND A.CUSTCODE  = in_CUST_CD
                   UNION ALL
                      SELECT '1' || A.COLDATE                                                            AS gb       ,  --자료순서
                             A.COLDATE                                                                   AS appdate  ,  --거래일자
                             A.COLNO                                                                     AS orderno  ,  --전표번호
                             TO_NUMBER(A.COLSEQ)                                                         AS seq      ,  --거래순번
                             A.COLDIV                                                                    AS saldiv   ,  --영업구분
                             S.DIVNAME                                                                   AS saldivnm ,  --영업구분명
                             A.ECUSTCODE                                                                 AS ecustcode,  --간납처코드
                             H.CUSTNAME                                                                  AS ecustname,  --간납처명
                             ''                                                                          AS itemcode ,  --제품코드
                             CASE WHEN A.COLDIV LIKE '3%' THEN NVL(A.BILLNO, 'unknown') || ':' || A.EXPDATE                                                          --어음번호와 만기일자
                                  WHEN SUBSTR(A.COLDIV, 1, 1) = '1' THEN I.ACCREMARK || ':' || NVL(A.ACCOUNTNO,'')                                                   --계좌은행
                                  WHEN SUBSTR(A.COLDIV, 1, 1) = '2' THEN (CASE WHEN (NVL (A.DIVMONTH, 0) = 0) THEN U.DIVNAME                                         --카드사
                                                                               WHEN (NVL (A.DIVMONTH, 0) > 0) THEN U.DIVNAME || ' ' || TO_CHAR(A.DIVMONTH) || '개월' --카드사
                                                                                                              ELSE oragmp.fncommonnm('comm','SL18',A.COLDIV)
                                                                          END)
                                  ELSE oragmp.fncommonnm('comm','SL18',A.COLDIV)
                             END                                                                            AS itemname ,  --제품명
                             ''                                                                             AS unit     ,  --규격
                             0                                                                              AS salqty   ,  --수량
                             0                                                                              AS salprc   ,  --단가
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLVAT              ELSE 0 END   AS salvat   ,  --부가세
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -(A.COLAMT - A.COLVAT) ELSE 0 END   AS salamt   ,  --공급가액
                             CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT              ELSE 0 END   AS totamt   ,  --합계
                             CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT               ELSE 0 END   AS colamt   ,  --수금액
                             A.ORDERDIV                                                                     AS orderdiv ,  --영업영역
                             T.DIVNAME                                                                      AS ordername,  --영업영역명
                             A.REMARK                                                                       AS remark   ,  --비고
                             -A.COLAMT                                                                      AS remamt   ,  --잔고산출용
                             0                                                                              AS turncnt
                        FROM oragmp.SLCOLM     A,
                             oragmp.CMCUSTM    H,
                             oragmp.CMACCOUNTM I,
                             oragmp.CMCOMMONM  S,
                             oragmp.CMCOMMONM  T,
                             oragmp.CMCOMMONM  U
                       WHERE A.STATEDIV  = '09'
                         AND A.ECUSTCODE = H.CUSTCODE
                         AND A.ACCOUNTNO = I.ACCOUNTNO(+)
                         AND 'SL18'      = S.CMMCODE  (+)
                         AND A.COLDIV    = S.DIVCODE  (+)
                         AND 'SL43'      = T.CMMCODE  (+)
                         AND A.ORDERDIV  = T.DIVCODE  (+)
                         AND 'AC17'      = U.CMMCODE  (+)
                         AND A.CARDCOMP  = U.DIVCODE  (+)
                         AND A.COLDATE BETWEEN p_frdate AND p_todate
                         AND A.CUSTCODE  = in_CUST_CD
                   UNION ALL
                      SELECT '1' || A.appdate || '-99'                                                   AS gb       ,  --자료순서
                             ''                                                                          AS appdate  ,  --거래일자
                             '0'                                                                         AS orderno  ,  --전표번호
                             0                                                                           AS seq      ,  --거래순번
                             'Z99'                                                                       AS saldiv   ,  --영업구분
                             ''                                                                          AS saldivnm ,  --영업구분명
                             ''                                                                          AS ecustcode,  --간납처코드
                             ''                                                                          AS ecustname,  --간납처명
                             ''                                                                          AS itemcode ,  --제품코드
                             REPLACE(A.appdate, '-', '/') || ' 일 계'                                    AS itemname ,  --제품명
                             ''                                                                          AS unit     ,  --규격
                             0                                                                           AS salqty   ,  --수량
                             0                                                                           AS salprc   ,  --단가
                             SUM(A.SALVAT)                                                               AS salvat   ,  --부가세
                             SUM(A.SALAMT)                                                               AS salamt   ,  --공급가액
                             SUM(A.TOTAMT)                                                               AS totamt   ,  --합계
                             SUM(A.COLAMT)                                                               AS colamt   ,  --수금액
                             ''                                                                          AS orderdiv ,  --영업영역
                             ''                                                                          AS ordername,  --영업영역명
                             ''                                                                          AS remark   ,  --비고
                             0                                                                           AS remamt   ,   --잔고산출용
                             0                                                                           AS turncnt
                        FROM
                           ( SELECT A.ORDERDATE                                                          AS appdate  ,  --거래일자
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALVAT ELSE -B.SALVAT END  AS SALVAT   ,  --부가세
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALAMT ELSE -B.SALAMT END  AS SALAMT   ,  --공급가액
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.TOTAMT ELSE -B.TOTAMT END  AS TOTAMT   ,  --합계
                                    0                                                                    AS COLAMT      --수금액
                               FROM oragmp.SLORDM    A,
                                    oragmp.SLORDD    B
                              WHERE A.STATEDIV  = '09'
                                AND A.ORDERNO   = B.ORDERNO
                                AND A.ORDERDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                          UNION ALL
                             SELECT A.COLDATE                                                                     AS appdate  ,  --거래일자
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLVAT              ELSE 0 END  AS salvat   ,  --부가세
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -(A.COLAMT - A.COLVAT) ELSE 0 END  AS salamt   ,  --공급가액
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT              ELSE 0 END  AS totamt   ,  --합계
                                    CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT               ELSE 0 END  AS colamt      --수금액
                               FROM oragmp.SLCOLM     A
                              WHERE A.STATEDIV  = '09'
                                AND A.COLDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                           ) A
                       WHERE p_dayopen = 'N'
                    GROUP BY A.appdate
                   UNION ALL
                      SELECT '1' || a.appdate || '-98-99'                                                      AS gb       ,  --자료순서
                             ''                                                                                AS appdate  ,  --거래일자
                             '0'                                                                               AS orderno  ,  --전표번호
                             0                                                                                 AS seq      ,  --거래순번
                             'Z99'                                                                             AS saldiv   ,  --영업구분
                             ''                                                                                AS saldivnm ,  --영업구분명
                             ''                                                                                AS ecustcode,  --간납처코드
                             ''                                                                                AS ecustname,  --간납처명
                             ''                                                                                AS itemcode ,  --제품코드
                             REPLACE(A.appdate, '-', '/') || ' 월 계'                                            AS itemname ,  --제품명
                             ''                                                                                AS unit     ,  --규격
                             0                                                                                 AS salqty   ,  --수량
                             0                                                                                 AS salprc   ,  --단가
                             SUM(A.SALVAT)                                                                     AS salvat   ,  --부가세
                             SUM(A.SALAMT)                                                                     AS salamt   ,  --공급가액
                             SUM(A.TOTAMT)                                                                     AS totamt   ,  --합계
                             SUM(A.COLAMT)                                                                     AS colamt   ,  --수금액
                             ''                                                                                AS orderdiv ,  --영업영역
                             ''                                                                                AS ordername,  --영업영역명
                             ''                                                                                AS remark   ,  --비고
                             0                                                                                 AS remamt   ,  --잔고산출용
                             NVL(B.TURNCNT,0)                                                                  AS turncnt
                        FROM
                           ( SELECT A.CUSTCODE                                                                 AS CUSTCODE ,  --거래처코드
                                    SUBSTR(A.ORDERDATE,1,7)                                                    AS appdate  ,  --거래일자
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALVAT ELSE -B.SALVAT END        AS SALVAT   ,  --부가세
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALAMT ELSE -B.SALAMT END        AS SALAMT   ,  --공급가액 
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.TOTAMT ELSE -B.TOTAMT END        AS TOTAMT   ,  --합계
                                    0                                                                          AS COLAMT      --수금액
                               FROM oragmp.SLORDM     A,
                                    oragmp.SLORDD     B
                              WHERE A.STATEDIV  = '09'
                                AND A.ORDERNO   = B.ORDERNO
                                AND A.ORDERDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                          UNION ALL
                             SELECT A.CUSTCODE                                                                    AS CUSTCODE ,  --거래처코드
                                    SUBSTR(A.COLDATE,1,7)                                                         AS appdate  ,  --거래일자
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLVAT              ELSE 0 END  AS salvat   ,  --부가세
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -(A.COLAMT - A.COLVAT) ELSE 0 END  AS salamt   ,  --공급가액
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT              ELSE 0 END  AS totamt   ,  --합계
                                    CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT               ELSE 0 END  AS colamt      --수금액
                               FROM oragmp.SLCOLM     A
                              WHERE A.STATEDIV  = '09'
                                AND A.COLDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                           ) A,
                             oragmp.SLTURNCUSTM B
                       WHERE A.appdate  = B.YEARMONTH(+)
                         AND A.CUSTCODE = B.CUSTCODE (+)
                         AND p_monopen = 'Y'
                    GROUP BY A.appdate, B.TURNCNT
                   UNION ALL
                      SELECT '1' || a.appdate || '-99-99'                                                      AS gb       ,  --자료순서
                             ''                                                                                AS appdate  ,  --거래일자
                             '0'                                                                               AS orderno  ,  --전표번호
                             0                                                                                 AS seq      ,  --거래순번
                             'Z99'                                                                             AS saldiv   ,  --영업구분
                             ''                                                                                AS saldivnm ,  --영업구분명
                             ''                                                                                AS ecustcode,  --간납처코드
                             ''                                                                                AS ecustname,  --간납처명
                             ''                                                                                AS itemcode ,  --제품코드
                             REPLACE(A.appdate, '-', '/') || ' 년 계'                                          AS itemname ,  --제품명
                             ''                                                                                AS unit     ,  --규격
                             0                                                                                 AS salqty   ,  --수량
                             0                                                                                 AS salprc   ,  --단가
                             SUM(A.SALVAT)                                                                     AS salvat   ,  --부가세
                             SUM(A.SALAMT)                                                                     AS salamt   ,  --공급가액
                             SUM(A.TOTAMT)                                                                     AS totamt   ,  --합계
                             SUM(A.COLAMT)                                                                     AS colamt   ,  --수금액
                             ''                                                                                AS orderdiv ,  --영업영역
                             ''                                                                                AS ordername,  --영업영역명
                             ''                                                                                AS remark   ,  --비고
                             0                                                                                 AS remamt   ,   --잔고산출용
                             0                                                                                 AS turncnt
                        FROM
                           ( SELECT SUBSTR(A.ORDERDATE,1,4)                                                    AS appdate  ,  --거래일자
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALVAT ELSE -B.SALVAT END        AS SALVAT   ,  --부가세
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.SALAMT ELSE -B.SALAMT END        AS SALAMT   ,  --공급가액
                                    CASE SUBSTR(A.SALDIV,1,1) WHEN 'A' THEN B.TOTAMT ELSE -B.TOTAMT END        AS TOTAMT   ,  --합계
                                    0                                                                          AS COLAMT      --수금액
                               FROM oragmp.SLORDM     A,
                                    oragmp.SLORDD     B
                              WHERE A.STATEDIV  = '09'
                                AND A.ORDERNO   = B.ORDERNO
                                AND A.ORDERDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                          UNION ALL
                             SELECT SUBSTR(A.COLDATE,1,4)                                                         AS appdate  ,  --거래일자
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLVAT              ELSE 0 END  AS salvat   ,  --부가세
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -(A.COLAMT - A.COLVAT) ELSE 0 END  AS salamt   ,  --공급가액
                                    CASE WHEN A.COLDIV     IN ('52','59') THEN -A.COLAMT              ELSE 0 END  AS totamt   ,  --합계
                                    CASE WHEN A.COLDIV NOT IN ('52','59') THEN A.COLAMT               ELSE 0 END  AS colamt      --수금액
                               FROM oragmp.SLCOLM     A
                              WHERE A.STATEDIV  = '09'
                                AND A.COLDATE BETWEEN p_frdate AND p_todate
                                AND A.CUSTCODE  = in_CUST_CD
                           ) A
                    GROUP BY A.appdate
                     ) A
              ORDER BY A.GB, A.SALDIV, A.ORDERNO, A.SEQ, A.ITEMCODE
           ) 
           ;
        
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
