CREATE FUNCTION      F_ITEM_NM  -- 제품명 가져오기
(
    in_ITEM_CD  IN  VARCHAR2
) 
RETURN VARCHAR2 IS

    v_item_nm   VARCHAR2(75);
    
BEGIN

    SELECT ITEM_NM||' '||STANDARD
      INTO v_item_nm
      FROM SALE0004
     WHERE ITEM_ID    = in_ITEM_CD;
        
    RETURN v_item_nm;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;
/
