CREATE PROCEDURE      SP_SFA_VISIT_02
(
    in_PARAM             IN  VARCHAR2,
    in_SAWON_ID          IN  VARCHAR2,     -- 담당자 사번
    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS    
 /*---------------------------------------------------------------------------
 프로그램명   : 개인방문계획
 호출프로그램 :       
 수정기록    
          2014.12.18 - KTA -팀장과 팀원들 자료가 너무 많아서 뿌리지 못하면서  
                            SFA죽는 문제 발생하여 팀장도 본인거래처만 조회하도록 함
          2015.06.08 KTA  - 임시팀장 직책코드 추가관련 수정                    
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_insa_sawon_id     VARCHAR2(7);
    v_insa_dept_cd      VARCHAR2(4);
    v_assgn_cd          VARCHAR2(5);
    
BEGIN

     
    --로그인사원의 인사사번   
    select insa_sawon_id into v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID and gubun = 'Y';
    
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장 ,팀장인지 파악
    select assgn_cd into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    
    --총괄팀장 이면 한레벨 상위부서코드를 찾고 팀장이면 자기부서를 찾는다.
    if v_assgn_cd = '27010' or v_assgn_cd = '27026' then --총괄팀장 선임지점장 
        select dept_cd
          into v_insa_dept_cd  
          from hr_co_depart_0 
         where use_yn = 'Y' and level = 2
       connect by dept_cd = prior up_dept_cd start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id);
                       
    elsif (v_assgn_cd = '27027' or v_assgn_cd = '27030' or v_assgn_cd = '27035' ) then --팀장,임시팀장
        select dept_cd into v_insa_dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    end if;    


    SELECT COUNT(distinct SFA_SALES_SEQ)
      INTO v_num
      FROM (
            SELECT *
              FROM SFA_SALES_CODE A
             WHERE SFA_SALES_SEQ IN
                                    (  SELECT SFA_SALES_SEQ
                                          FROM SFA_SALES_CODE    
                                         WHERE EMP_NO  IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) 
                                        UNION
                                         SELECT A.SFA_SALES_SEQ
                                          FROM SFA_SALES_CODE_SAWON A
                                              ,SFA_SALES_CODE B
                                         WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                           AND A.EMP_NO  IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) 
                                           AND A.REQ_GB  = '1'  --활동거래처
                                           AND A.OK_STAT = '2'  --승인
                                     )   
           );
        
      /* KTA 2014.12.18 팀장과 팀원들 자료가 너무 많아서 뿌리지 못하면서  SFA죽는 문제 발생하여 팀장도 본인거래처만 조회하도록 함 
 
     --로그인사번의 주문거래처 + 요청테이블의 활동거래처요청중 승인된거래처
     SELECT COUNT(distinct SFA_SALES_SEQ)
       INTO v_num
       FROM(SELECT *
              FROM (
                    SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE A
                     WHERE A.EMP_NO  in (  select sawon_id --총괄팀장 ,팀장인경우 하위 모든 사원(영업사원테이블)
                                          from sale0007 
                                         where insa_sawon_id in (
                                                                select emp_no from hr_hc_empbas_0 --총괄팀장 ,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                 where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                    connect by prior dept_cd = up_dept_cd
                                                                                      start with dept_cd = v_insa_dept_cd
                                                                                  )
                                                                   and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                )
                                          and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                          union
                                          select sawon_id
                                          from sale0007
                                          where sawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)                                          
                                     )
                    UNION     
                     SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE_SAWON A
                     WHERE A.EMP_NO  in (  select sawon_id --총괄팀장 ,팀장인경우 하위 모든 사원(영업사원테이블)
                                          from sale0007 
                                         where insa_sawon_id in (
                                                                select emp_no from hr_hc_empbas_0 --총괄팀장 ,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                 where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                    connect by prior dept_cd = up_dept_cd
                                                                                      start with dept_cd = v_insa_dept_cd
                                                                                  )
                                                                   and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                )
                                          and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                          union
                                          select sawon_id
                                          from sale0007
                                          where sawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)         
                                     )
                       AND A.REQ_GB  = '1'
                       AND A.OK_STAT = '2'
                    )
             WHERE v_assgn_cd <> '27040' --팀원아니고 팀장 또는 총괄팀장 이면
             UNION ALL
              SELECT *
              FROM (
                    SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE A
                     WHERE A.EMP_NO   IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) 
                    UNION     
                     SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE_SAWON A
                     WHERE A.EMP_NO   IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) 
                       AND A.REQ_GB  = '1'
                       AND A.OK_STAT = '2'
                    )       
             WHERE v_assgn_cd = '27040' --팀원이면      
                   
             );
    */               
             
    
-- insert into SFA_SP_CALLED_HIST values ('SP_SFA_COMMON_02','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||' / v_num:'||to_char(v_num));
     
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
     
        
        OPEN out_RESULT FOR
        SELECT A.SFA_SALES_NO                           AS out_SFA_SALES_NO,           -- 거래처코드 NUMBER
               F_CUST_NM_KEY('NAME',A.SFA_SALES_SEQ)                AS out_SFA_SALES_NM,           -- 거래처명
               A.SFA_SALES_SEQ                            AS out_SFA_SALES_SEQ,           -- 거래처 Key
               F_SFA_CODE_NM('CUST_STAT_GB',decode(in_SAWON_ID,emp_no,'01','02'))||'-'||SUBSTR(F_SFA_CUST_SAWON_NM(in_SAWON_ID,SFA_SALES_SEQ),2)  AS out_CUST_STAT_GB
          FROM SFA_SALES_CODE A
         WHERE SFA_SALES_SEQ IN
                                (  SELECT SFA_SALES_SEQ
                                      FROM SFA_SALES_CODE    
                                     WHERE EMP_NO  IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) 
                                    UNION
                                     SELECT A.SFA_SALES_SEQ
                                      FROM SFA_SALES_CODE_SAWON A
                                          ,SFA_SALES_CODE B
                                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                       AND A.EMP_NO  IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) 
                                       AND A.REQ_GB  = '1'  --활동거래처
                                       AND A.OK_STAT = '2'  --승인
                                 )  
         ORDER BY F_SFA_CUST_SAWON_NM(in_SAWON_ID,SFA_SALES_SEQ),F_SFA_CODE_NM('CUST_STAT_GB',decode(in_SAWON_ID,emp_no,'01','02')),out_SFA_SALES_NM;
        
 /*KTA 2014.12.18 팀장과 팀원들 자료가 너무 많아서 뿌리지 못하면서  SFA죽는 문제 발생하여 팀장도 본인거래처만 조회하도록 함
         SELECT A.SFA_SALES_NO                           AS out_SFA_SALES_NO,           -- 거래처코드 NUMBER
               F_CUST_NM_KEY('NAME',A.SFA_SALES_SEQ)                AS out_SFA_SALES_NM,           -- 거래처명
               A.SFA_SALES_SEQ                            AS out_SFA_SALES_SEQ,           -- 거래처 Key
               F_SFA_CODE_NM('CUST_STAT_GB',decode(in_SAWON_ID,emp_no,'01','02'))||'-'||SUBSTR(F_SFA_CUST_SAWON_NM(in_SAWON_ID,SFA_SALES_SEQ),2)  AS out_CUST_STAT_GB
          FROM SFA_SALES_CODE A
         WHERE SFA_SALES_SEQ IN ( SELECT SFA_SALES_SEQ
                                      FROM (SELECT SFA_SALES_SEQ
                                              FROM SFA_SALES_CODE    
                                             WHERE EMP_NO in (  select sawon_id --총괄팀장 ,팀장인경우 하위 모든 사원(영업사원테이블)
                                                                  from sale0007 
                                                                 where insa_sawon_id in (
                                                                                        select emp_no from hr_hc_empbas_0 --총괄팀장 ,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                                         where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                                            connect by prior dept_cd = up_dept_cd
                                                                                                              start with dept_cd = v_insa_dept_cd)
                                                                                                                and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                                        )
                                                                  and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                                                  union
                                                                  select sawon_id
                                                                  from sale0007
                                                                  where sawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)         
                                                             )
                                            UNION
                                             SELECT A.SFA_SALES_SEQ
                                              FROM SFA_SALES_CODE_SAWON A
                                                  ,SFA_SALES_CODE B
                                             WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                               AND A.EMP_NO in (  select sawon_id --총괄팀장 ,팀장인경우 하위 모든 사원(영업사원테이블)
                                                                  from sale0007 
                                                                 where insa_sawon_id in (
                                                                                        select emp_no from hr_hc_empbas_0 --총괄팀장 ,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                                         where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                                            connect by prior dept_cd = up_dept_cd
                                                                                                              start with dept_cd = v_insa_dept_cd)
                                                                                                                and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                                        )
                                                                  and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                                                  union
                                                                  select sawon_id
                                                                  from sale0007
                                                                  where sawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)    
                                                             )
                                               AND A.REQ_GB  = '1'  --활동거래처
                                               AND A.OK_STAT = '2'  --승인
                                           )
                                     WHERE v_assgn_cd <> '27040' --팀원아니고 팀장 또는 총괄팀장 이면
                                    UNION ALL
                                    SELECT SFA_SALES_SEQ
                                      FROM (SELECT SFA_SALES_SEQ
                                              FROM SFA_SALES_CODE    
                                             WHERE EMP_NO  IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) 
                                            UNION
                                             SELECT A.SFA_SALES_SEQ
                                              FROM SFA_SALES_CODE_SAWON A
                                                  ,SFA_SALES_CODE B
                                             WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                               AND A.EMP_NO  IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) 
                                               AND A.REQ_GB  = '1'  --활동거래처
                                               AND A.OK_STAT = '2'  --승인
                                           ) 
                                     WHERE v_assgn_cd = '27040' --팀원이면
                                 )  
         ORDER BY F_SFA_CUST_SAWON_NM(in_SAWON_ID,SFA_SALES_SEQ),F_SFA_CODE_NM('CUST_STAT_GB',decode(in_SAWON_ID,emp_no,'01','02')),out_SFA_SALES_NM;

 */       
        
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
