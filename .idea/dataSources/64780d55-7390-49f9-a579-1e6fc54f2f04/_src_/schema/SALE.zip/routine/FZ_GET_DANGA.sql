CREATE function      FZ_GET_DANGA
        ( in_CUST_ID      VARCHAR2, -- 직납처
          in_RCUST_ID     VARCHAR2, -- 간납처
          in_ITEM_ID      VARCHAR2  -- 제품코드 
        )
   RETURN VARCHAR2
AS
   v_cnt        NUMBER ;
   v_out_danga  NUMBER ;
   
/*----------------------------------------------------------------
 2017.09.20 KTA
 제품이  비급여여부에 따라 단가 다르게 적용
 - 급여 -> SALE0004 의 OUT_DANGA
 - 비급여 -> SALE0405 의 BAL_AMT
  
  호출하는곳 : SP_SFA_ITEM_MULTI_139 
         2017.11.01 KTA - NEW ERP메 맞게 컨버젼 
----------------------------------------------------------------*/

BEGIN

       v_cnt := 0;
       v_out_danga := 0;
       
       SELECT COUNT(*)
         INTO v_cnt
         FROM ORAGMP.CMITEMM
        WHERE itemcode  = in_ITEM_ID
          AND paidyn = 'Y';
                    
       IF v_cnt > 0 THEN                 
           SELECT NVL(befprc,0)
             INTO v_out_danga
             FROM ORAGMP.SLPROMPRCM
            WHERE custcode  = in_CUST_ID
              AND ecustcode = in_RCUST_ID
              AND itemcode  = in_ITEM_ID
              AND EDATE >= TO_CHAR(SYSDATE, 'yyyy-MM-dd');
       ELSE
           SELECT drugprc
             INTO v_out_danga
             FROM ORAGMP.CMITEMM
            WHERE itemcode  = in_ITEM_ID;       
                     
       END IF; 
       
       RETURN NVL(v_out_danga,0);
       
EXCEPTION WHEN OTHERS THEN
       RETURN 0;
END;
/
