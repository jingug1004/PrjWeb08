CREATE function      F_GET_SALE0406H
        ( A_CUST_ID      VARCHAR2, -- 수금거래처
          A_YMD          DATE,     -- 수금일자
          A_GUBUN        VARCHAR2  -- 수금구분(1-'현금',2-'카드') 
        )
   RETURN VARCHAR2
AS
   user_err       exception   ; 
   
   v_amt_yul      number;
   v_cnt          number;
      
   n_rtn_value    VARCHAR2(250);
   v_curr_error   VARCHAR2(250);

/*----------------------------------------------------------------
 어떤 수금건에 대하여 그 수금거래처의 할인율을 넘겨준다. 
 이력이 없으면 넘어온 구분에 따라 현금5%, 카드 2% 를 기본값으로 넘겨준다.
----------------------------------------------------------------*/
BEGIN

       SELECT COUNT(*) 
         INTO v_cnt
         FROM SALE.SALE0406H
        WHERE CUST_ID   =  A_CUST_ID   
          AND TO_CHAR(A_YMD,'YYYYMMDD') BETWEEN STR_YMD AND END_YMD;
       IF v_cnt = 0 then
          IF A_GUBUN = '1' THEN
             n_rtn_value := 5;
          ELSE
             n_rtn_value := 2;
          END IF;
       
       ELSE
           SELECT amt_yul
             INTO v_amt_yul
             FROM SALE.SALE0406H
            WHERE CUST_ID   =  A_CUST_ID  
              AND TO_CHAR(A_YMD,'YYYYMMDD') BETWEEN STR_YMD AND END_YMD; 
           n_rtn_value := v_amt_yul;
          
       END IF;
       
       RETURN n_rtn_value;

EXCEPTION WHEN user_err THEN
               RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
          WHEN OTHERS THEN
               RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;

/
