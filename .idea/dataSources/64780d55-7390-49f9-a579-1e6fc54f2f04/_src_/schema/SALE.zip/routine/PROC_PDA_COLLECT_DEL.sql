CREATE PROCEDURE      PROC_PDA_COLLECT_DEL
  (in_ymd IN date,   
   in_AMT IN VARCHAR2 DEFAULT NULL, 
   in_BILL_NO IN VARCHAR2 DEFAULT NULL, 
   in_BILL_GB IN VARCHAR2 DEFAULT NULL, 
   in_GYULJAE_YMD IN VARCHAR2 DEFAULT NULL,
   in_BIGO IN VARCHAR2 DEFAULT NULL
        )
IS    

    ll_count number := 0;   --
    V_JUNPYO_NO VARCHAR2(20); --전표번호 찾기
    
BEGIN

--bigo 승인번호
--bill_no 카드번호
--bill_gn 결재구분 '100' 카드

    select count(*) as cnt
    into ll_count
    from SALE.SALE0402 
    where YMD = in_YMD and AMT = decode(nvl(in_AMT,''),'','0', in_AMT)
    and GYULJAE_YMD = in_GYULJAE_YMD and  BILL_NO = in_BILL_NO
    and BILL_GB = in_BILL_GB and BIGO = in_BIGO;
  --group by JUNPYO_NO
  
   IF SQLCODE <> 0 THEN
         dbms_output.put_line('Fail  SELECT COUNT SALE.SALE0402');
            ROLLBACK;
            return;
     END IF;
     
    if ll_count = 0 then
        raise_application_error (-20000,'<해당하는 전표가 없습니다.>');
        return;
    elsif ll_count > 1 then    
        raise_application_error (-20000,'<유일한 수금 결재정보가 아닙니다.>');
        return;
    end if;
    
    if in_YMD <> to_char(sysdate, 'YYYY-MM-DD') then
        raise_application_error (-20000,'<당일 전표가 아닙니다.>');
        return;
    end if;
    
    select JUNPYO_NO
    into V_JUNPYO_NO
    from SALE.SALE0402 
    where YMD = in_YMD and AMT = decode(nvl(in_AMT,''),'','0', in_AMT)
    and GYULJAE_YMD = in_GYULJAE_YMD and  BILL_NO = in_BILL_NO
    and BILL_GB = in_BILL_GB and BIGO = in_BIGO;

   IF SQLCODE <> 0 THEN
         dbms_output.put_line('Fail  SELECT CHECK  JUNPYO_NO SALE.SALE0402');
            ROLLBACK;
            return;
     END IF;
     


    delete from SALE.SALE0402 
    where YMD = in_YMD and AMT = decode(nvl(in_AMT,''),'','0', in_AMT)
    and GYULJAE_YMD = in_GYULJAE_YMD and  BILL_NO = in_BILL_NO
    and BILL_GB = in_BILL_GB and BIGO = in_BIGO;
  
  
        
     IF SQLCODE <> 0 THEN
         dbms_output.put_line('FAIL DELETE SALE.SALE0402');
            ROLLBACK;
            return;
     END IF;
     
        
    delete from SALE.SALE0401 
    where JUNPYO_NO = V_JUNPYO_NO;
  
  
        
     IF SQLCODE <> 0 THEN
         dbms_output.put_line('FAIL DELETE SALE.SALE0401');
            ROLLBACK;
            return;
     END IF;

end;

/
