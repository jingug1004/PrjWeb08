CREATE PROCEDURE      P_SALEPART_BATCH2 ( AS_USER_FLAG IN VARCHAR2
                                                                                           ,AS_YMD IN VARCHAR2 )IS
        /*------------------------------------------------------------------
        호출 변수
        AS_USER_FLAG : 사용자의 프로시저 호출 (실적조회 화면에서 해당 프로시저를 호출하여 DATA를 생성 할수 있음)
        AS_YMD            : DATA를 만들고자하는 년 월 (일자는 없은 것으로 : 201208  6BYTE 전달)        
        
        개요  :파트별전체실적BATCH 프로그램의 업그레이드 버전임
               파트별전체실적BATCH 는 그대로 두고 새로 작성한것임.
              기존실적은 사원TABLE로 당시의 사원으로 실적을 구했으나
              사원이력TALBE 을 사용하기로 한 후(2014년1월15일이후)로 이것을 만든것임
        ------------------------------------------------------------------*/
  
        V_DATE_FROM        VARCHAR2(8);
        V_DATE_TO          VARCHAR2(8);
        V_LAST_DATE        DATE;
        V_TMP_CNT          NUMBER; 

        V_PROC_USE_YN SALEPART_GAIN.PROC_USE_YN%TYPE;  -- 프로시저 사용유무

        V_CURR_ERROR       VARCHAR2(1000) ;
        V_CURR_ERROR2       VARCHAR2(1000) ;
        USER_ERR           EXCEPTION; 
        USER_ERR2          EXCEPTION; 

BEGIN 
  
        --DBMS_OUTPUT.PUT_LINE('--------------------------------- START SALEPART_BATCH2 ');      
        
        /*0. 중복 사용 유무 파악*/
        V_PROC_USE_YN := 'N';
        SELECT PROC_USE_YN INTO V_PROC_USE_YN FROM SALEPART_GAIN WHERE PROC_NM = 'P_SALEPART_BATCH2';
        
        IF V_PROC_USE_YN = 'Y' THEN
            V_CURR_ERROR := '현재 BATCH 실적 DATA를 생성 중입니다. 조금만 기다려 주세요';
            RAISE USER_ERR2;
        ELSE
            UPDATE SALEPART_GAIN SET PROC_USE_YN = 'Y',PROC_USE_DATE = SYSDATE ,RESULT_SQL = ''
             WHERE PROC_NM = 'P_SALEPART_BATCH2';
            COMMIT;
        END IF;         
        
        V_CURR_ERROR := '';       
        /*1. 조회 기간을 설정한다.  기본적으로 현재년월일을 설정한다. ①번 ㉮번 case */
        BEGIN
            SELECT TO_CHAR(SYSDATE, 'YYYYMMDD')  
                INTO V_DATE_TO
               FROM DUAL;
            
            V_DATE_FROM := SUBSTR(V_DATE_TO, 1, 6)||'01';           
              
        EXCEPTION  WHEN OTHERS THEN 
            V_CURR_ERROR := 'ERR DATE : '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
            RAISE USER_ERR;
        END;              
         
        BEGIN
                /*프로시저 활동 조건
                ① User Click 
                        ㉮ 현재 날짜 DATA : 무조건 생성한다.
                        ㉯ 과거 날짜 DATA : 무조건 생성한다.
                ② Job Work
                        ㉰ 현재 날짜 DATA : ⓐ 말일인 경우 : 30분 마다 자동 생성 => 21일 보다 큰경우 30분 단위 변경
                                                         ⓑ 하루에 한번 : 새벽 01시 에 한번만 생성 => 1일 ~ 20일 경우 2시간 단위 생성
                        ㉱ 과거 날짜 DATA : 생성할수 없다 : 호출하지 않는다.             */            
                IF SUBSTR(V_DATE_TO,1,6) = AS_YMD THEN     
                       IF TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,  'YYYYMMDDHH24MISS'), 9, 4)) > 830 AND 
                           --TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,  'YYYYMMDDHH24MISS'), 9, 4)) < 1000 THEN
                           TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,  'YYYYMMDDHH24MISS'), 9, 4)) < 930 THEN
                                V_CURR_ERROR := '제한된 시간에 DATA를 생성하려고 합니다. 종료합니다. '||V_LAST_DATE;
                                
                                UPDATE SALEPART_GAIN SET PROC_USE_YN = 'N' ,RESULT_SQL = V_CURR_ERROR     WHERE PROC_NM = 'P_SALEPART_BATCH2';
                                COMMIT;
                                
                                RETURN;    
                        END IF; 

                                                         
                        IF AS_USER_FLAG = 'J' THEN                           
                                DBMS_OUTPUT.PUT_LINE('----------------- JOB INSERT WORK');                                  
                                --V_LAST_DATE  := LAST_DAY(TO_DATE(AS_YMD||'01','YYYYMMDD'));     
                                /*②번  ㉰번 ⓐ번 case 변경후*/
                                IF TO_NUMBER(SUBSTR(V_DATE_TO,7,2)) >= 21 THEN
                                        V_CURR_ERROR := 'JOB INSERT WORK LAST : '||V_LAST_DATE;
                                /*②번  ㉰번 ⓑ번 case 변경후 */  
                                ELSE                                   

                                        IF MOD(TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,  'YYYYMMDDHH24MISS'), 9, 2)), 2) = 0 AND  --2시간 단위
                                            TO_NUMBER(SUBSTR(TO_CHAR(SYSDATE,  'YYYYMMDDHH24MISS'), 11, 2)) > 30 THEN --30분보다 큰 경우 
                                                --insert into SFA_SP_CALLED_HIST values ( 'P_SALEPART_BATCH2' , '1' , sysdate , '실정생성 평일 2시간' );
                                                V_CURR_ERROR := 'JOB INSERT ONE TIME : '||TO_CHAR(V_LAST_DATE - 1, 'YYYYMMDD');                                                 
                                        ELSE
                                                --insert into SFA_SP_CALLED_HIST values ( 'P_SALEPART_BATCH2' , '2' , sysdate , '실정생성 무시 return' );
                                                UPDATE SALEPART_GAIN SET PROC_USE_YN = 'N' ,RESULT_SQL = '매월21일전에는 2시간단위 실행인데 2시간 아직 안됨'  WHERE PROC_NM = 'P_SALEPART_BATCH2';
                                                COMMIT;
                                                RETURN;
                                        END IF;
                                END IF;  
                        ELSE
                                DBMS_OUTPUT.PUT_LINE('----------------- USER INSERT WORK');
                                 V_CURR_ERROR := 'USER INSERT - F: '||V_DATE_FROM||'      ,T: '||V_DATE_TO;                        
                        END IF;     
                ELSE            
                        /* ①번 ㉯번 case */ 
                        V_DATE_FROM := SUBSTR(AS_YMD, 1, 6)||'01';  
                        V_DATE_TO := TO_CHAR(LAST_DAY(TO_DATE(AS_YMD||'01','YYYYMMDD')), 'YYYYMMDD'); 
                        V_CURR_ERROR := 'USER INSERT past time - F: '||V_DATE_FROM||'      ,T: '||V_DATE_TO;                            
                END IF;          
        EXCEPTION  WHEN OTHERS THEN 
            V_CURR_ERROR := 'ERR DATE : '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
            RAISE USER_ERR;
        END;         
        DBMS_OUTPUT.PUT_LINE('FIRST DATA  - V_DATE_FROM: '||V_DATE_FROM||'      ,V_DATE_TO: '||V_DATE_TO);              
        
        /*2. 이전 자료를 한달 단위로 지운고 다시 만듭니다. */
        BEGIN
            DELETE FROM SALEPART_BATCH2 WHERE DATE_TIME BETWEEN V_DATE_FROM AND V_DATE_TO;
               
        EXCEPTION  WHEN OTHERS THEN 
            V_CURR_ERROR := 'ERR DELETE : '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
            RAISE USER_ERR;
        END;
         
        /* 3. DATA INSERT  */
        BEGIN
                --내용 삽입
                DBMS_OUTPUT.PUT_LINE('NOW INSERT JOB');                 
               INSERT INTO SALEPART_BATCH2 (  DATE_TIME ,EMP_NO ,EMP_NM ,TEAM_CD ,TEAM_NM ,PART_CD ,PART_NM ,RPT_GB ,RORDER                    
                                                                  ,SALE_AMT ,SALE_AMT_SILJUK_IN ,SALE_AMT_SILJUK_IN_LOCAL 
                                                                  ,SALE_AMT_SILJUK_IN_01 ,SALE_AMT_SILJUK_IN_02 ,SALE_AMT_SILJUK_IN_03 ,SALE_AMT_SILJUK_IN_04 ,SALE_AMT_SILJUK_IN_05     
                                                                  ,SALE_AMT_SILJUK_OUT ,SALE_AMT_SILJUK_BYUNG ,SALE_AMT_SILJUK_MBYUNG ,SALE_AMT_BANPUM 
                                                                  ,SALE_AMT_HALIN ,SALE_AMT_HALINS01 ,SALE_AMT_HALINS02 ,SALE_AMT_SILJUK ,SALE_PERCENT              
                                                                  ,IN_AMT ,IN_AMT_SILJUK_IN ,IN_AMT_SILJUK_IN_LOCAL    
                                                                  ,IN_AMT_SILJUK_IN_01 ,IN_AMT_SILJUK_IN_02 ,IN_AMT_SILJUK_IN_03 ,IN_AMT_SILJUK_IN_04 ,IN_AMT_SILJUK_IN_05       
                                                                  ,IN_AMT_SILJUK_OUT ,IN_AMT_SILJUK_BYUNG ,IN_AMT_SILJUK_MBYUNG ,IN_AMT_SILJUK ,IN_PERCENT
                                                                  ,PROC_COMMENT, PROC_DATE                
                                                              )
                SELECT V_DATE_TO AS DATE_TIME
               ,X.SAWON_ID
               ,A.SAWON_NM
               ,X.DEPT_CD AS DEPT_CD
               ,NVL(C.DEPT_NM, ' ') AS DEPT_NM
               ,B.CODE1 AS PART_CD
               ,NVL(B.CODE1_NM, ' ') AS PART_NM
               ,'01' AS RPT_GB
               ,NVL(C.RORDER, 9999) AS RORDER
               ,SUM(X.sale_amt) AS sale_amt
               ,SUM(X.sale_amt_siljuk_in) AS sale_amt_siljuk_in
               ,SUM(X.sale_amt_siljuk_in_LOCAL) AS sale_amt_siljuk_in_LOCAL
               ,SUM(X.SALE_AMT_SILJUK_IN_01) AS SALE_AMT_SILJUK_IN_01
               ,SUM(X.SALE_AMT_SILJUK_IN_02) AS SALE_AMT_SILJUK_IN_02
               ,SUM(X.SALE_AMT_SILJUK_IN_03) AS SALE_AMT_SILJUK_IN_03
               ,SUM(X.SALE_AMT_SILJUK_IN_04) AS SALE_AMT_SILJUK_IN_04
               ,SUM(X.SALE_AMT_SILJUK_IN_05) AS SALE_AMT_SILJUK_IN_05
               ,SUM(X.sale_amt_siljuk_out) AS sale_amt_siljuk_out
               ,SUM(X.sale_amt_siljuk_byung) AS sale_amt_siljuk_byung
               ,SUM(X.sale_amt_siljuk_mbyung) AS sale_amt_siljuk_mbyung
               ,SUM(X.sale_amt_banpum) AS sale_amt_banpum
               ,SUM(X.sale_amt_HALIN) AS sale_amt_HALIN
               ,SUM(X.SALE_AMT_HALINS01) AS SALE_AMT_HALINS01
               ,SUM(X.SALE_AMT_HALINS02) AS SALE_AMT_HALINS02
               ,SUM(X.sale_amt_siljuk_in) + SUM(X.sale_amt_siljuk_out) + SUM(X.sale_amt_siljuk_byung) + SUM(X.sale_amt_siljuk_mbyung) + SUM(X.sale_amt_banpum) + (SUM(X.sale_amt_HALIN) + SUM(X.SALE_AMT_HALINS01)) AS sale_amt_siljuk
               ,DECODE(SUM(NVL(X.sale_amt,0)),0, 0,
                ROUND( ( SUM(X.sale_amt_siljuk_in) + SUM(X.sale_amt_siljuk_out) + SUM(X.sale_amt_siljuk_byung) + SUM(X.sale_amt_siljuk_mbyung)
                                           + SUM(X.sale_amt_banpum) + SUM(X.sale_amt_HALIN) + SUM(X.SALE_AMT_HALINS01)) / SUM(X.sale_amt) * 100,2 ) ) AS sale_percent
               ,SUM(X.in_amt) AS In_amt
               ,SUM(X.in_amt_siljuk_in) AS in_amt_siljuk_in
               ,SUM(X.IN_AMT_SILJUK_IN_LOCAL) AS IN_AMT_SILJUK_IN_LOCAL
               ,SUM(X.IN_AMT_SILJUK_IN_01) AS IN_AMT_SILJUK_IN_01
               ,SUM(X.IN_AMT_SILJUK_IN_02) AS IN_AMT_SILJUK_IN_02
               ,SUM(X.IN_AMT_SILJUK_IN_03) AS IN_AMT_SILJUK_IN_03
               ,SUM(X.IN_AMT_SILJUK_IN_04) AS IN_AMT_SILJUK_IN_04
               ,SUM(X.IN_AMT_SILJUK_IN_05) AS IN_AMT_SILJUK_IN_05
               ,SUM(X.in_amt_siljuk_out) AS in_amt_siljuk_out
               ,SUM(X.in_amt_siljuk_byung) AS in_amt_siljuk_byung
               ,SUM(X.in_amt_siljuk_mbyung) AS in_amt_siljuk_mbyung
               ,SUM(X.in_amt_siljuk_in) + SUM(X.in_amt_siljuk_out) + SUM(X.in_amt_siljuk_byung) + SUM(X.in_amt_siljuk_mbyung) AS in_amt_siljuk
               ,DECODE(SUM(NVL(X.in_amt,0)), 0, 0,
                ROUND(( SUM(X.in_amt_siljuk_in) + SUM(X.in_amt_siljuk_out) + SUM(X.in_amt_siljuk_byung) + SUM(X.in_amt_siljuk_mbyung)) / SUM(X.in_amt) * 100,2)) AS in_percent
               ,V_CURR_ERROR
               ,TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS')
                FROM (
                        select b.sawon_id                sawon_id,
                        b.dept_cd                 dept_cd,                                          
                        SUM(sale_amt)                 sale_amt,
                        SUM(sale_amt_siljuk_in)       sale_amt_siljuk_in,
                        SUM(sale_amt_siljuk_in_LOCAL) sale_amt_siljuk_in_LOCAL,
                        SUM(SALE_AMT_SILJUK_IN_01)    SALE_AMT_SILJUK_IN_01,
                        SUM(SALE_AMT_SILJUK_IN_02)    SALE_AMT_SILJUK_IN_02,
                        SUM(SALE_AMT_SILJUK_IN_03)    SALE_AMT_SILJUK_IN_03,
                        SUM(SALE_AMT_SILJUK_IN_04)    SALE_AMT_SILJUK_IN_04,
                        SUM(SALE_AMT_SILJUK_IN_05)    SALE_AMT_SILJUK_IN_05,
                        SUM(sale_amt_siljuk_out)      sale_amt_siljuk_out,
                        SUM(sale_amt_banpum)          sale_amt_banpum,
                        SUM(sale_amt_HALIN)           sale_amt_HALIN,
                        SUM(SALE_AMT_HALINS01)        SALE_AMT_HALINS01,
                        SUM(SALE_AMT_HALINS02)        SALE_AMT_HALINS02,
                        SUM(in_amt)                   in_amt,
                        SUM(in_amt_siljuk_in)         in_amt_siljuk_in,
                        SUM(IN_AMT_SILJUK_IN_LOCAL)   IN_AMT_SILJUK_IN_LOCAL,
                        SUM(IN_AMT_SILJUK_IN_01)      IN_AMT_SILJUK_IN_01,
                        SUM(IN_AMT_SILJUK_IN_02)      IN_AMT_SILJUK_IN_02,
                        SUM(IN_AMT_SILJUK_IN_03)      IN_AMT_SILJUK_IN_03,
                        SUM(IN_AMT_SILJUK_IN_04)      IN_AMT_SILJUK_IN_04,
                        SUM(IN_AMT_SILJUK_IN_05)      IN_AMT_SILJUK_IN_05,
                        SUM(in_amt_siljuk_out)        in_amt_siljuk_out,
                        SUM(sale_amt_siljuk_byung)    sale_amt_siljuk_byung,
                        SUM(in_amt_siljuk_byung)      in_amt_siljuk_byung,
                        SUM(sale_amt_siljuk_mbyung)   sale_amt_siljuk_mbyung,
                        SUM(in_amt_siljuk_mbyung)     in_amt_siljuk_mbyung
                        from (
                        
                                -- 목표 
                                select sawon_id,
                                F_GET_SALE0007H_DEPT_CD(sawon_id,V_DATE_FROM) DEPT_CD,                                
                                NVL(sale_amt,0) sale_amt,                 --판매목표
                                0               sale_amt_siljuk_in,       --매출:간납합계
                                0               sale_amt_siljuk_in_LOCAL, --매출:도매로컬
                                0               SALE_AMT_SILJUK_IN_01,    --매출:의원
                                0               SALE_AMT_SILJUK_IN_02,    --매출:일반간납
                                0               SALE_AMT_SILJUK_IN_03,    --매출:턴키
                                0               SALE_AMT_SILJUK_IN_04,    --매출:입찰
                                0               SALE_AMT_SILJUK_IN_05,    --매출:기타
                                0               sale_amt_siljuk_out,      --매출:약국
                                0               sale_amt_banpum,          --매출:반품
                                0               sale_amt_HALIN,           --매출:매출할인외
                                0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                NVL(in_amt,0)   in_amt,                   --수금목표
                                0               in_amt_siljuk_in,         --수금:간납합계
                                0               IN_AMT_SILJUK_IN_LOCAL,   --수금:도매로컬
                                0               IN_AMT_SILJUK_IN_01,      --수금:의원
                                0               IN_AMT_SILJUK_IN_02,      --수금:일반간납
                                0               IN_AMT_SILJUK_IN_03,      --수금:턴키
                                0               IN_AMT_SILJUK_IN_04,      --수금:입찰
                                0               IN_AMT_SILJUK_IN_05,      --수금:기타
                                0               in_amt_siljuk_out,        --수금:약국
                                0               sale_amt_siljuk_byung,    --매출:종합병원
                                0               in_amt_siljuk_byung,      --수금:종합병원
                                0               sale_amt_siljuk_mbyung,   --매출:준종합병원
                                0               in_amt_siljuk_mbyung      --수금:준종합병원
                                from SALE0403
                                where YMD BETWEEN to_date(substrb(V_DATE_FROM,1,6)||'01','yyyymmdd') AND last_day(to_date(substrb(V_DATE_TO,1,6),'yyyymm'))
                                union all
                                
                                -- 판매 
                                select F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                F_GET_SALE0405_DEPTCDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID,GEORAE.YMD) DEPT_CD,
                                0,
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)))  as sale_amt_siljuk_in,  --매출:간납합계
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)))  as sale_amt_siljuk_in_LOCAL,  --매출:도매로컬
                                SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',DECODE(SUBSTR(GEORAE.RCUST_ID,1,1),'4',NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) as SALE_AMT_SILJUK_IN_01,  --매출:의원
                                SUM(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, DECODE(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',DECODE(LEAST('6'||' ',SUBSTR(GEORAE.RCUST_ID,1,1)),'6'||' ', NVL(GEORAE_D.AMT,0)+NVL(GEORAE_D.VAT,0)-NVL(GEORAE_D.DC_AMT*1.1,0),0),0))) as SALE_AMT_SILJUK_IN_02,   --매출:일반간납
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) as SALE_AMT_SILJUK_IN_03,  --매출:턴키
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) as SALE_AMT_SILJUK_IN_04,  --매출:입찰
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) as SALE_AMT_SILJUK_IN_05,  --매출:기타
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) as sale_amt_siljuk_out,   --매출:약국
                                sum(decode(substr(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)
                                                                                                ,'11', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0),0))  as sale_amt_banpum,     --매출:반품
                                sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),'12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)) as sale_amt_HALIN, --매출할인
                                sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),
                                                 '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0))  as SALE_AMT_HALINS01, --수금할인(일반)
                                sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                         '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),
                                                 '13', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                                         '4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0))          as SALE_AMT_HALINS02,        --수금할인(조건)
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                0,
                                sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))),
                                0
                                from SALE0207 GEORAE, SALE0208 GEORAE_D
                                where GEORAE.ymd BETWEEN to_date(V_DATE_FROM,'yyyymmdd') AND to_date(V_DATE_TO,'yyyymmdd')
                                and GEORAE.deal_no  = GEORAE_D.deal_no
                                and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                                group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD),
                                F_GET_SALE0405_DEPTCDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID,GEORAE.YMD)
                                union all
                                SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD) ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD) END SAWON_ID,
                                CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_DEPTCDH(SUGUM.CUST_ID, SUGUM.YMD) ELSE F_GET_SALE0401_DEPTCDH(SUGUM.RCUST_ID,SUGUM.YMD) END DEPT_CD,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0               sale_amt_HALIN,           --매출:매출할인외
                                0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                0,
                                sum(decode(substr(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),1,1),'4', NVL(SUGUM.cash_amt,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUM.cash_amt,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUM.cash_amt,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUM.cash_amt,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUM.cash_amt,0),0)),
                                sum(decode(substr(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),1,1),'4', NVL(SUGUM.cash_amt,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUM.cash_amt,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUM.cash_amt,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUM.CASH_AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUM.cash_amt,0),0)),
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUM.CASH_AMT,0),0),0)),
                                0,
                                0,
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUM.cash_amt,0),0)),
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUM.cash_amt,0),0)),
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUM.cash_amt,0),0)),
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUM.cash_amt,0),0))
                                from SALE0401 SUGUM
                                where SUGUM.ymd BETWEEN to_date(V_DATE_FROM,'yyyymmdd') AND to_date(V_DATE_TO,'yyyymmdd')
                                and SUGUM.JUNPYO_GB       LIKE '0%'
                                and NVL(SUGUM.cash_amt,0) <> 0
                                GROUP BY CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD)ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD) END,
                                CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_DEPTCDH(SUGUM.CUST_ID, SUGUM.YMD) ELSE F_GET_SALE0401_DEPTCDH(SUGUM.RCUST_ID, SUGUM.YMD) END 
                                union all
                                SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD) ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD) END SAWON_ID,
                                CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_DEPTCDH(SUGUM.CUST_ID,SUGUM.YMD) ELSE F_GET_SALE0401_DEPTCDH(SUGUM.RCUST_ID,SUGUM.YMD) END DEPT_CD, 
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0               sale_amt_HALIN,           --매출:매출할인외
                                0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                0,
                                sum(decode(substr(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),1,1),'4', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                sum(decode(substr(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),1,1),'4', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                0,
                                0,
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                                from SALE0401 SUGUM, SALE0402 SUGUMD
                                where SUGUM.ymd BETWEEN to_date(V_DATE_FROM,'yyyymmdd') AND to_date(V_DATE_TO,'yyyymmdd')
                                and SUGUM.JUNPYO_GB LIKE '0%'
                                AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                                AND SUGUMD.END_YMD IS NULL
                                group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD) ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD) END,
                                CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_DEPTCDH(SUGUM.CUST_ID, SUGUM.YMD) ELSE F_GET_SALE0401_DEPTCDH(SUGUM.RCUST_ID, SUGUM.YMD) END 
                                union all
                                SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD) ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD) END SAWON_ID,
                                CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_DEPTCDH(SUGUM.CUST_ID, SUGUM.YMD) ELSE F_GET_SALE0401_DEPTCDH(SUGUM.RCUST_ID,SUGUM.YMD) END DEPT_CD,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0               sale_amt_HALIN,           --매출:매출할인외
                                0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                0,
                                sum(decode(substr(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),1,1),'4', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                sum(decode(substr(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),1,1),'4', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                0,
                                0,
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                                from SALE0401 SUGUM, SALE0402 SUGUMD
                                where SUGUM.ymd BETWEEN to_date(V_DATE_FROM,'yyyymmdd') AND to_date(V_DATE_TO,'yyyymmdd')
                                and SUGUM.JUNPYO_GB LIKE '0%'
                                AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                                AND SUGUMD.END_YMD  IS NOT NULL
                                AND SUGUMD.END_YMD  BETWEEN TO_DATE(SUBSTR(V_DATE_FROM,1,6)||'01','YYYYMMDD') AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(V_DATE_FROM,1,6)||'01','YYYYMMDD'),6))
                                group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD) ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD) END,
                                CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_DEPTCDH(SUGUM.CUST_ID,SUGUM.YMD) ELSE F_GET_SALE0401_DEPTCDH(SUGUM.RCUST_ID, SUGUM.YMD) END 
                                union all
                                /*2015.06.04 kta 어음만기도래월의 실적담당자를 찾기위해 어음발생일 대신에 도래월의첫날을 넣기로 함                                            
                                SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD) ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, SUGUM.YMD) END SAWON_ID,
                                CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_DEPTCDH(SUGUM.CUST_ID,SUGUM.YMD) ELSE F_GET_SALE0401_DEPTCDH(SUGUM.RCUST_ID,SUGUM.YMD) END DEPT_CD,*/
                                SELECT CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD) ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, V_DATE_FROM) END SAWON_ID,
                                CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_DEPTCDH(SUGUM.CUST_ID,SUGUM.YMD) ELSE F_GET_SALE0401_DEPTCDH(SUGUM.RCUST_ID,V_DATE_FROM) END DEPT_CD,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0,
                                0               sale_amt_HALIN,           --매출:매출할인외
                                0               SALE_AMT_HALINS01,        --매출:수금할인(일반)
                                0               SALE_AMT_HALINS02,        --매출:수금할인(조건)
                                0,
                                sum(decode(substr(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),1,1),'4', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                sum(decode(substr(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),1,1),'4', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'70', NVL(SUGUMD.AMT,0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'90', NVL(SUGUMD.AMT,0),0)) +
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(LEAST('6'||' ',SUBSTR(SUGUM.RCUST_ID,1,1)),'6'||' ', NVL(SUGUMD.AMT,0),0),0)) +
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'05', NVL(SUGUMD.AMT,0),0)),
                                SUM(DECODE(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'10', DECODE(SUBSTR(SUGUM.RCUST_ID,1,1),'4',NVL(SUGUMD.AMT,0),0),0)),
                                0,
                                0,
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'99',NVL(SUGUMD.AMT,0),0)),
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'20',NVL(SUGUMD.AMT,0),0)),
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'60',NVL(SUGUMD.AMT,0),0)),
                                0,
                                sum(decode(F_GET_SALE0003H_CUSTGB1(SUGUM.RCUST_ID, SUGUM.YMD),'80',NVL(SUGUMD.AMT,0),0))
                                from SALE0401 SUGUM, SALE0402 SUGUMD
                                where SUGUM.ymd < to_date(V_DATE_FROM,'yyyymmdd')
                                and SUGUM.JUNPYO_GB LIKE '0%'
                                AND SUGUM.JUNPYO_NO = SUGUMD.JUNPYO_NO
                                AND SUGUMD.END_YMD  IS NOT NULL
                                AND SUGUMD.END_YMD  BETWEEN ADD_MONTHS(TO_DATE(SUBSTR(V_DATE_FROM,1,6)||'01','YYYYMMDD'),6) AND LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(V_DATE_FROM,1,6)||'01','YYYYMMDD'),6))
                                group by CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_SAWONIDH(SUGUM.CUST_ID,  SUGUM.YMD) ELSE F_GET_SALE0401_SAWONIDH(SUGUM.RCUST_ID, V_DATE_FROM) END,
                                CASE WHEN TO_CHAR(SUGUM.YMD, 'YYYY') < '2010' THEN F_GET_SALE0401_DEPTCDH(SUGUM.CUST_ID,SUGUM.YMD) ELSE F_GET_SALE0401_DEPTCDH(SUGUM.RCUST_ID,V_DATE_FROM) END                                                    
                                ) B
                        GROUP BY b.sawon_id,b.dept_cd
                ) X,
                SALE0007 A,
                (SELECT code1, code1_nm, code2, code2_nm from SALE0001 where code_gb = '0013' ) B,
                SALE0008 C
                WHERE X.SAWON_ID = A.SAWON_ID
                AND X.DEPT_CD  = C.DEPT_CD(+)
                AND A.PART_GB  = B.CODE1(+)
                GROUP BY X.SAWON_ID
                ,A.SAWON_NM
                ,X.DEPT_CD
                ,NVL(C.DEPT_NM, ' ')
                ,B.CODE1
                ,NVL(B.CODE1_NM, ' ')
                ,NVL(C.RORDER, 9999) 
                ;
                                                                   
                UPDATE SALEPART_GAIN SET PROC_USE_YN = 'N',RESULT_SQL = '정상실행' WHERE PROC_NM = 'P_SALEPART_BATCH2';                
                
        EXCEPTION WHEN OTHERS THEN
            V_CURR_ERROR := 'ERR 01 INSERT '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
            RAISE USER_ERR;
        END;                  
                   
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('--------------------------------- END SALEPART_BATCH2');     
  
EXCEPTION
    WHEN USER_ERR2 THEN
            RAISE_APPLICATION_ERROR(-20001,V_CURR_ERROR);            
            RETURN;
            
    WHEN USER_ERR THEN
            ROLLBACK; 
            UPDATE SALEPART_GAIN SET PROC_USE_YN = 'N',RESULT_SQL = V_CURR_ERROR WHERE PROC_NM = 'P_SALEPART_BATCH2';
            COMMIT; 
            RAISE_APPLICATION_ERROR(-20001, V_CURR_ERROR);             

    WHEN OTHERS THEN
            V_CURR_ERROR2 := 'ERR OTHERS ' || TO_CHAR(SQLCODE)|| '-'|| substr(sqlerrm, 1, 90);
            ROLLBACK;  
            UPDATE SALEPART_GAIN SET PROC_USE_YN = 'N',RESULT_SQL = V_CURR_ERROR ||'-'|| V_CURR_ERROR2 WHERE PROC_NM = 'P_SALEPART_BATCH2';            
            COMMIT; 
            RAISE_APPLICATION_ERROR(-20001, V_CURR_ERROR);    
    
END P_SALEPART_BATCH2;
/
