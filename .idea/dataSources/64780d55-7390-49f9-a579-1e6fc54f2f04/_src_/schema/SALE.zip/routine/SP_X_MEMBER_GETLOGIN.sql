CREATE PROCEDURE      SP_X_MEMBER_GETLOGIN
 (
         sp_empCode  IN VARCHAR2,
         sp_password IN VARCHAR2,
         out_RESULT OUT TYPES.CURSOR_TYPE,
         out_CODE OUT NUMBER,
         out_MSG OUT  VARCHAR2
 )
IS
        -- ---------------------------------------------------------------
        -- 프로시저명   : SP_X_MEMBER_GETLOGIN
        -- 작 성 자      : 유명배
        -- 작성일자      : 2017-11-28
        -- 수 정 자      :
        -- 수정일자      : 2017-11-28
        -- 수정내용      : .
        -- 수 정 자       :
        -- E-Mail   : nago51@daum.net
        -- ---------------------------------------------------------------
        -- 프로시저 설명    :  프로시저이다.
        -- ---------------------------------------------------------------
BEGIN
        out_CODE := 0;
        out_MSG  := '데이터 확인';
        
        OPEN out_RESULT FOR
        SELECT CUST_ID AS EMP_CODE,
               CUST_NM AS EMP_NAME,
               ''      AS DEPT_CODE,
               '1'     AS EMP_GB,
               PASSWORD,
               USE_YN
        FROM   SALE.SALE0003
        WHERE  CUST_ID LIKE '11%'
        AND    CUST_ID    = sp_empCode
        AND    PASSWORD   = UTL_I18N.STRING_TO_RAW(sp_password,'AL32UTF8');

EXCEPTION
WHEN NO_DATA_FOUND THEN
        RAISE;
WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE)
        ||'-'
        || SQLERRM);
END ;
/
