CREATE PROCEDURE      SP_SFA_CUST_011_109
(
    in_DEPT_CD           IN  VARCHAR2,    -- 부서코드
    in_SAWON_ID          IN  VARCHAR2,    -- 사원 ID
    in_CUST_NM           IN  VARCHAR2,    -- 거래처명
    in_SIDO_NM              IN  VARCHAR2,    -- 시도 
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처요청
 호출프로그램 :sfa - 거래처-거래처요청화면-조회버튼        
 수정사항    :2013-01-18 우리약국처럼 400건 가까운건수가 조회되는 문제가 있어서 시도조건추가함       
             2015-05-13 kta COMPANY_ADDR1 이 null 인경우 조회안되는 문제 수정         
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    DEPT_CD_NULL         EXCEPTION;
    SAWON_ID_NULL        EXCEPTION;
BEGIN
    
    IF in_DEPT_CD IS NULL OR TRIM(in_DEPT_CD) = '' THEN
        RAISE DEPT_CD_NULL;
    END IF;
    
    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
        RAISE SAWON_ID_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_SALES_CODE A 
     WHERE A.TRADE_NAME  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
       AND nvl(A.COMPANY_ADDR1,A.COMPANY_ADDR2) LIKE '%'||NVL(in_SIDO_NM,'%')||'%' ;

    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num > 100) THEN
        out_CODE := 1;
        out_MSG := '검색 결과가 100 건이상입니다. 조건을 다시 입력하세요.';  
        
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT A.SFA_SALES_SEQ                          AS out_CUST_KEY 
                ,A.SFA_SALES_NO                          AS out_CUST_CD        -- 거래처코드
             , NVL(A.TRADE_NAME,' ')                   AS out_CUST_NM        -- 거래처명
             , NVL(A.MANAGER_NAME, ' ')                AS out_MANAGER_NM     -- 대표자명
             , A.ERP_SALES_CODE                        AS out_ERP_CD         -- ERP 코드
             , nvl(A.COMPANY_ADDR1,A.COMPANY_ADDR2)   AS out_ADDR1          -- 주소
            , CUST_STAT_GB              AS out_CUST_STAT_GB          -- 거래처종류
             , case 
                when (CUST_STAT_GB = '01')    then '주문' 
                when (CUST_STAT_GB = '02')    then '활동' 
                when (CUST_STAT_GB = '03')    then '비활동' 
                else ''                              end AS out_CUST_STAT_GBNM
          FROM SFA_SALES_CODE A
         WHERE TRADE_NAME  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
           AND nvl(A.COMPANY_ADDR1,A.COMPANY_ADDR2) LIKE '%'||NVL(in_SIDO_NM,'%')||'%' 
         ORDER BY CUST_STAT_GB,TRADE_NAME;
    END IF;
    
EXCEPTION
WHEN DEPT_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '부서코드가 누락되었습니다.';
WHEN SAWON_ID_NULL THEN
   out_CODE := 102;
   out_MSG  := '사원 ID가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
