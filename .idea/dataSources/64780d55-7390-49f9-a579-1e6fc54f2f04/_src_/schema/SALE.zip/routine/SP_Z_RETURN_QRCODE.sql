CREATE PROCEDURE      SP_Z_RETURN_QRCODE 
(
    in_PROCESS      IN  VARCHAR2,   
    in_SAWON_ID     IN  VARCHAR2,   
    in_QRCODE       IN  VARCHAR2,   
    in_CUST_ID      IN  VARCHAR2, 
    in_RCUST_ID     IN  VARCHAR2,
    in_ITEM_CD     IN  VARCHAR2,   
    in_PRODNO       IN  VARCHAR2,
    in_QTY          IN  NUMBER , 
    in_BARCODEQTY  IN  NUMBER, 
    in_REASON_CODE      IN  VARCHAR2,
    out_CODE             out NUMBER,
    out_MSG              out VARCHAR2,
    out_COUNT            out NUMBER,
    out_RESULT           out TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
BEGIN
    IF in_PROCESS = '0' THEN -- QR CODE 읽은데이타가 사입이력이 있는지
        SELECT COUNT(*)
            INTO v_num
        from rfid_user.DELIVERY_TAGINFO a
                 ,oragmp.slordm b
                 ,oragmp.slordd c
                 ,oragmp.SLITEMTAKINGOUT d
        where   a.delivery_order_no = b.orderno
            and a.delivery_order_no = c.orderno
            and a.item_no           = c.itemcode
            and a.delivery_order_no = d.orderno
            and a.item_no           = d.itemcode
            and a.lot_no            = d.lotno
            and a.tagid             = in_QRCODE;
    ELSE
         SELECT COUNT(*)
          INTO v_num
         FROM sfa_banpum_reason 
         where 
                CUST_ID = in_CUST_ID
            and RCUST_ID = in_RCUST_ID
            and ITEM_ID = in_ITEM_CD
            and PROD_NO = in_PRODNO
            and YMD = in_QRCODE;
    END IF;
     
    IF in_PROCESS = '0' THEN -- QR CODE 읽은데이타가 사입이력이 있는지
        IF v_num = 0 THEN -- 신규등록
            out_CODE := 1;
            out_MSG := '사입내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '요청하신 작업이 확인되었습니다.';      
            
            OPEN out_RESULT FOR
            select  b.orderdate                                 out_YYYYMM  -- 출고일자
                   ,b.custcode                                  out_CUSTID  -- 거래처코드
                   ,oragmp.fncommonnm('cust',b.custcode,'')     out_CUSTNM  -- 거래처명
                   ,b.ecustcode                                 out_RCUSTID -- 납품처코드
                   ,oragmp.fncommonnm('cust',b.ecustcode,'')    out_RCUSTNM -- 납품처명 
                   ,c.itemcode                                  out_ITEM_CD -- 제품코드
                   ,oragmp.fncommonnm('item',c.itemcode,'')     out_ITEM_NM -- 제품명
                   ,d.lotno                                     out_PRODNO  -- 제조번호
                   ,d.expdate                                   out_USEDYMD -- 사용기간
                   ,c.salprc                                    out_PRICE   -- 단가
                   ,b.empcode                                   거래처담당CODE
                   ,oragmp.fncommonnm('emp',b.empcode,'')       거래처담당명
                   ,b.ecustcode                                 납품처담당CODE
                   ,oragmp.fncommonnm('emp',b.ecustcode,'')     납품처담당명
                   ,b.orderno                                   out_ORDER_NO -- 주문번호
               from rfid_user.DELIVERY_TAGINFO a
                   ,oragmp.slordm b
                   ,oragmp.slordd c
                   ,oragmp.SLITEMTAKINGOUT d
              where a.delivery_order_no = b.orderno
                and a.delivery_order_no = c.orderno
                and a.item_no = c.itemcode
                and a.delivery_order_no = d.orderno
                and a.item_no = d.itemcode
                and a.lot_no  = d.lotno
                and a.tagid = in_QRCODE;                         
        END IF;
        
    ELSE
        
        out_CODE := 1;
        out_MSG := '사입내역이 존재하지 않습니다.';
        
        
    END IF;
     
    
      
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
