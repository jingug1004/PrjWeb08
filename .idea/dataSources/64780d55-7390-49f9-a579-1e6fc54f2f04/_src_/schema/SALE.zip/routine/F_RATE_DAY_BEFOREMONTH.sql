CREATE FUNCTION      F_RATE_DAY_BEFOREMONTH  -- 사원명 가져오기
(
    in_YYYYMM  IN  VARCHAR2,  --조회년월: 주문월에서 한달전월이 넘어옴.
    in_CUST_CD IN  VARCHAR2   --거래처코드
) 
RETURN VARCHAR2 IS

    v_rateday   VARCHAR2(20);
    v_cnt       number;
    ll_months   number;
    
/*----------------------------------------------------------------------------*
 기능    : 에이징테이블에 계산되어있는 회전일수를  return
 추가설명:에이징은 영업관리부에서 마감된달에 대하여 생성버튼으로 생성하고 있음       
 작성자:김태안
 작성일:2013.01.29
 수정기록
 2013.10.26 - kta : 넘어온달로 회전일이 없으면 전달로 찾는다 왜냐하면 매달첫줄근에
             전달  에이징을 생성하므로 에이징생성전에는 전달의 회전일이  없기 때문임.
 2015.07.15 - kta : 이관받은 거래처의 회전일은 이관한달 이전에는 없으므로 회전일 위반으로 처리
            예) 7월2일 이관받은 거래처의 회전일은 6월달에는 만들어 지지 않았을 것임.              
 2016.12.07 - kta :신규거래처가 아니더라도 거래처 등록한후 한번도 주문이 없는 경우는 위반아닌것으로 처리 신용하      
            
 *----------------------------------------------------------------------------*/          
BEGIN
 
    --매월 첫줄근날 전월의 에이징을 생성한다.
    --주문당월 에이징은 만들어 지지 않음.
    --이 함수에 요청되는 에이징 요청월은 주문 전달이 아규먼트로 넘어옴.
    SELECT COUNT(*) 
      INTO v_cnt
      FROM EIJING A  
     WHERE A.YM_F    = in_YYYYMM 
       AND A.CUST_ID = in_CUST_CD;
    IF v_cnt > 0 THEN
         /*넘어온 년월의 에이징의 회전일 찾음*/
         SELECT TO_CHAR(NVL(A.RATEDAY,0))
          INTO v_rateday
          FROM EIJING A  
         WHERE A.YM_F    = in_YYYYMM 
           AND A.CUST_ID = in_CUST_CD;     
           
    ELSE
    
        --요청한년월에 에이징이 없어서 이곳을 탐.
        --요청한년월 전월에 에이징이 있는지 본다.
        --이관받은 거래처인경우는 에이징테이블에 존재하지 않을 것이므로 회전일 위반으로 처리한다. 2015.07.15 윤홍주 
        v_cnt := 0;
        SELECT count(*) INTO v_cnt 
          FROM EIJING A  
         WHERE A.YM_F    = TO_CHAR(add_months(to_date(in_YYYYMM||'01','YYYYMMDD'),-1),'YYYYMM')
           AND A.CUST_ID = in_CUST_CD;              
         IF v_cnt = 0 THEN
         
             --신규처외에는 에이징이 없으면 위반으로 처리한다. 개시한지 2달이상인경우 위반처리 2015.07.16 윤홍주
             --주문월-개시월=개시개월수
            ll_months := 0;
            SELECT trunc(months_between(to_date(in_YYYYMM,'yyyymm'), to_date(to_char(START_YMD,'yyyymm'),'yyyymm')))   --일자로 하지 않고 1일로 바꿔서 
              INTO ll_months
              FROM SALE.SALE0003
             WHERE CUST_ID = in_CUST_CD;            
            IF ll_months > 1 THEN      --개시한지 2달이내 0:개시개월,1:개시2개월
               
               --신규등록후 한번도 주문이 없은경우 위반처리하지 않음 
               v_cnt := 0;
               SELECT count(*) INTO v_cnt FROM SALE0207 WHERE cust_id = in_CUST_CD and rownum =1;
               IF v_cnt = 0 THEN
                  v_rateday := '0'; --위반처리하지 않음.  
               ELSE
                   v_rateday := '999';  --위반으로 처리하기 위해...
               END IF;   
            ELSE
               v_rateday := '0'; --개시2개월이내는 위반처리하지 않음.  
            END IF; 
             
         ELSE    
             /*넘어온 년월의 전월 (11월이면 9월)  에이징의 회전일 찾음*/
             /*TO_CHAR(add_months(to_date(in_YYYYMM||'01','YYYYMMDD'),-1),'YYYYMM')*/         
             SELECT TO_CHAR(NVL(A.RATEDAY,0))
              INTO v_rateday
              FROM EIJING A  
             WHERE A.YM_F    = TO_CHAR(add_months(to_date(in_YYYYMM||'01','YYYYMMDD'),-1),'YYYYMM')
               AND A.CUST_ID = in_CUST_CD;
         END IF;
         
    END IF; 
        
    RETURN v_rateday;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '0';
END;
/
