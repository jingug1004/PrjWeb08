CREATE PROCEDURE      SP_SFA_CUST_04_LIST
(
    in_SAWON_ID          IN  VARCHAR2,     -- 사용자 ID
    in_CUST_CD           IN  NUMBER,       -- 거래처 코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 고객 상세 하단 리스트
 호출프로그램 :  105버전 적용후 삭제할것       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_client_no          NUMBER;
    v_main_client        NUMBER;

    CUST_CD_NULL         EXCEPTION;

BEGIN

    IF in_CUST_CD IS NULL OR TRIM(in_CUST_CD) = '' THEN
        RAISE CUST_CD_NULL;
    END IF;

    SELECT COUNT(*)
      INTO v_num
      FROM SFA_COM_CUSTOMER
     WHERE SFA_SALES_SEQ  = F_CUST_NM_KEY('KEYCODE',in_CUST_CD)
       AND NVL(DEL_YN, 'N') = 'N';

    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '고객 정보가 존재하지 않습니다.';
    ELSIF (v_num >= 1) THEN
        out_COUNT := v_num;
        out_CODE := 0;
        out_MSG := '고객 정보 확인완료';

        OPEN out_RESULT FOR
        SELECT SFA_SALES_SEQ                                                                    AS out_CUST_CD
             , NVL(F_CUST_NM_KEY('NAME',SFA_SALES_SEQ), '')                                                AS out_CUST_NM
             , SFA_CLIENT_NO                                                                   AS out_CLIENT_NO
             , CLIENT_GUBUN                                                                    AS out_CLIENT_GUBUN
             --, NVL(CLIENT_DEPT, '')                                                            AS out_CLIENT_DEPT
             --, CLIENT_JIKWI                                                                    AS out_CLIENT_JIKWI
             , NVL(POSITION_NAME, '')                                                            AS out_CLIENT_DEPT  -- 직책
            -- , DEPARTMENT_CODE                                                                    AS out_CLIENT_JIKWI -- 전문과  
             , NVL(CLIENT_NAME, '')                                                            AS out_CLIENT_NM
             , MALE                                                                            AS out_MALE
             , TEL_NO                                                                          AS out_TEL_NO
             , HP_NO                                                                           AS out_HP_NO
             , EMAIL                                                                           AS out_EMAIL
             , BIRTHDAY                                                                        AS out_BIRTHDAY
             , BIRTHDAY_GUBUN                                                                  AS out_BIRTHDAY_GUBUN
             , ZIP_CODE                                                                        AS out_ZIP_CODE
             , DETAIL_ADDR1                                                                    AS out_DETAIL_ADDR1
             , DETAIL_ADDR2                                                                    AS out_DETAIL_ADDR2
         --    , HOBBY                                                                           AS out_HOBBY
       --      , ACTIVE_TYPE                                                                     AS out_ACTIVE_TYPE
             , MARRY_YN                                                                        AS out_MARRY_YN
             , MARRY_DAY                                                                       AS out_MARRY_DAY
             , MODIFY_DT                                                                       AS out_INPUT_DT
             , MODIFY_WORKER                                                                   AS out_INPUT_SAWON
             , DECODE(SFA_CLIENT_NO, '1', 'Y', 'N') AS out_MAIN_YN  -- 대표고객여부 
                 , DECODE(SFA_CLIENT_NO, '1',  '대표고객', '고객') AS out_MAIN_NM 
             --    , POSITION_NAME AS out_POSITION_NM
           --  , DEPARTMENT_CODE AS out_DEPARTMENT_CD
            FROM SFA_COM_CUSTOMER
         WHERE SFA_SALES_SEQ  = F_CUST_NM_KEY('KEYCODE',in_CUST_CD)
           AND NVL(DEL_YN, 'N') = 'N';
    END IF;

EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG := '거래처코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
