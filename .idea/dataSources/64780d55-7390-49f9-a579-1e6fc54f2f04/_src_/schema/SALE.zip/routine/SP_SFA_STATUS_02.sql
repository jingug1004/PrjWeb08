CREATE PROCEDURE      SP_SFA_STATUS_02    -- 거래처 여신현황
(
    in_CUST_CD           IN  VARCHAR2,    -- 거래처코드
    in_DT                IN  VARCHAR2,    -- 기간
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 거래처여신현황 
 호출프로그램 : 거래처> 거래처현황      
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼    
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    CUST_CD_NULL         EXCEPTION;
    DT_NULL              EXCEPTION;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_04_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SFA_SALES_SEQ,sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN||'/in_CLIENT_NO '||in_CLIENT_NO );
--commit; 
    
    IF in_CUST_CD IS NULL THEN
        RAISE CUST_CD_NULL;
    END IF;
    
    IF in_DT IS NULL THEN
        RAISE DT_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM SALE0003 A,
           SALE0007 B,
           SALE0008 C,
           (SELECT A.CUST_ID                                  CUST_ID,
                   SUM(A.AMT) + SUM(VAT)                      TODAY_AMT,
                   SUM(A.SUKUM)                               TODAY_SU_AMT,
                   SUM(A.MISU_AMT) + SUM(A.AMT)+SUM(A.VAT)    SALE_AMT,
                   SUM(A.SU_AMT)   + SUM(SUKUM)               SU_AMT,
                  (SUM(A.BEFORE_AMT)+ SUM(A.MISU_AMT) - SUM(A.SU_AMT))+ (SUM(A.AMT)+SUM(A.VAT)-SUM(SUKUM))    JANGO
             FROM (SELECT A.CUST_ID         CUST_ID,
                          A.SU_AMT          SU_AMT,
                          A.MISU_AMT        MISU_AMT,
                          A.BEFORE_AMT      BEFORE_AMT,
                          0                 AMT,
                          0                 VAT,
                          0                 SUKUM
                     FROM SALE0306 A
                    WHERE A.CUST_ID = in_CUST_CD
                      AND A.YMD     = TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(in_DT,'YYYY/MM'),-1),'YYYYMM') || '01')
                    UNION ALL
                   SELECT A.CUST_ID         CUST_ID,
                          0                 SU_AMT,
                          0                 MISU_AMT,
                          0                 BEFORE_AMT,
                          B.AMT             AMT,
                          B.VAT             VAT,
                          0                 SUKUM
                     FROM SALE0207 A,
                          SALE0208 B,
                          SALE0004 D
                    WHERE A.DEAL_NO = B.DEAL_NO
                      AND A.YMD     = B.YMD
                      AND B.ITEM_ID = D.ITEM_ID
                      AND TO_CHAR(A.YMD,'YYYYYMMDD')     LIKE in_DT||'%'
                      AND A.CUST_ID = in_CUST_CD
                    UNION ALL /*  수금(할인) 내역 */
                   SELECT A.CUST_ID          CUST_ID,
                          0                  SU_AMT,
                          0                  MISU_AMT,
                          0                  BEFORE_AMT,
                          0                  AMT,
                          0                  VAT,
                          CASH_AMT           SUKUM
                     FROM SALE0401  A
                    WHERE TO_CHAR(A.YMD,'YYYYYMMDD')     LIKE in_DT||'%'
                      AND A.CUST_ID = in_CUST_CD
                      AND A.CASH_AMT      <> 0
                    UNION ALL
                   SELECT A.CUST_ID          CUST_ID,
                          0                  SU_AMT,
                          0                  MISU_AMT,
                          0                  BEFORE_AMT,
                          0                  AMT,
                          0                  VAT,
                          AMT                SUKUM
                     FROM SALE0402  B,
                          SALE0401  A
                    WHERE TO_CHAR(A.YMD,'YYYYYMMDD')     LIKE in_DT||'%'
                      AND A.CUST_ID = in_CUST_CD
                      AND A.JUNPYO_NO   = B.JUNPYO_NO ) A
            GROUP BY CUST_ID                          ) D,
            (SELECT X.CUST_ID        CUST_ID ,
                    NVL(SUM(AMT),0)  BILL_AMT
               FROM SALE0401 X ,
                    SALE0402 Y
              WHERE X.CUST_ID   = in_CUST_CD
                AND X.YMD       = Y.YMD
                AND X.JUNPYO_NO = Y.JUNPYO_NO
                AND TO_CHAR(Y.END_YMD, 'YYYYMM')  > in_DT
                AND NVL(Y.BILL_GB,'*') not IN ('025','035','040')
              GROUP BY X.CUST_ID                     ) E,
            (SELECT X.CUST_ID        CUST_ID ,
                    NVL(SUM(AMT),0)  BILL_AMT
               FROM SALE0401 X ,
                    SALE0402 Y
              WHERE X.CUST_ID   = in_CUST_CD
                AND X.YMD       = Y.YMD
                AND X.JUNPYO_NO = Y.JUNPYO_NO
                AND TO_CHAR(Y.END_YMD, 'YYYYMM')  > in_DT
                AND NVL(Y.BILL_GB,'*') IN ('025','035','040')
              GROUP BY X.CUST_ID                     ) F ,
            (SELECT CUST_ID   CUST_ID,
                    SUM(SALE_DAMBO_AMT) AMT
               FROM SALE0404
              WHERE CUST_ID = in_CUST_CD
                AND BILL_GB IN ('약어','약어(신보)','어음')
              GROUP BY CUST_ID                       ) G,
            (SELECT CUST_ID   CUST_ID,
                    SUM(SALE_DAMBO_AMT) AMT
               FROM SALE0404
              WHERE CUST_ID = in_CUST_CD
                AND BILL_GB IN ('가수','당좌')
              GROUP BY CUST_ID                       ) H,
            (SELECT CUST_ID   CUST_ID,
                    SUM(SALE_DAMBO_AMT) AMT
               FROM SALE0404
              WHERE CUST_ID = in_CUST_CD
                AND BILL_GB NOT IN ('약어','약어(신보)','어음','가수','당좌')
              GROUP BY CUST_ID                       ) I,
            (SELECT CUST_ID   CUST_ID,
                    DECODE(COUNT(*), 1, MAX(BILL_GB), MAX(BILL_GB)||'외 '||TO_CHAR(count(*) - 1)||'건')  BILL_GB
               FROM SALE0404
              WHERE CUST_ID = in_CUST_CD
              GROUP BY CUST_ID                       ) J,
            (sELECT CUST_ID     CUST_ID, 
                    MONTHS_BETWEEN(TO_DATE(in_DT||'01'),TO_DATE(TO_CHAR(MIN(YMD),'YYYYMM')||'01')) MONTH_SU,
                    MIN(YMD)    MIN_YMD
               FROM SALE0207
              WHERE CUST_ID = in_CUST_CD
              GROUP BY CUST_ID                       ) L,
           (SELECT A.CUST_ID                CUST_ID,
                   NVL(SUM(A.MISU_AMT),0)   MISU_AMT,
                   NVL(SUM(A.SU_AMT),0)     SU_AMT
              FROM SALE0306 A
             WHERE A.CUST_ID = in_CUST_CD
               AND A.YMD <= TO_DATE(in_DT||'01')
             GROUP BY A.CUST_ID                      ) M
     WHERE A.USE_YN   = 'Y'
       AND A.CUST_ID  = in_CUST_CD
       AND A.SAWON_ID = B.SAWON_ID
       AND B.DEPT_CD  = C.DEPT_CD
       AND A.CUST_ID  = D.CUST_ID(+)
       AND A.CUST_ID  = E.CUST_ID(+)
       AND A.CUST_ID  = F.CUST_ID(+)
       AND A.CUST_ID  = G.CUST_ID(+)
       AND A.CUST_ID  = H.CUST_ID(+)
       AND A.CUST_ID  = I.CUST_ID(+)
       AND A.CUST_ID  = J.CUST_ID(+)
       AND A.CUST_ID  = L.CUST_ID(+)
       AND A.CUST_ID  = M.CUST_ID(+);
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT A.CUST_ID                                                                                     AS out_CUST_ID,
               A.CUST_NM                                                                                     AS out_CUST_NM,
               A.SAWON_ID                                                                                    AS out_SAWON_ID,
               B.SAWON_NM                                                                                    AS out_SAWON_NM,
               C.DEPT_NM                                                                                     AS out_DEPT_NM,
               D.JANGO                                                                                       AS out_JANGO,
               E.BILL_AMT                                                                                    AS out_MIDORAE_CHA,
               NVL(F.BILL_AMT,0)                                                                             AS out_MIDORAE_TASU,
               D.JANGO + E.BILL_AMT                                                                          AS out_TOT,   --총여신
               NVL(G.AMT,0)                                                                                  AS out_EOEUM,  --어음담보
               NVL(H.AMT,0)                                                                                  AS out_SUPYO, --수표담보
               NVL(I.AMT,0)                                                                                  AS out_GITA,  --기타담보
               NVL(G.AMT,0) + NVL(H.AMT,0) + NVL(I.AMT,0)                                                    AS out_TOT_DAMBO, --담보총금
               ROUND(((NVL(G.AMT,0) + NVL(H.AMT,0) + NVL(I.AMT,0) ) / (D.JANGO + E.BILL_AMT)) * 100,2)       AS out_YUL, --확보율
               J.BILL_GB                                                                                     AS out_BILL_GB,
               DECODE(A.YEONDAE,  'Y','O','X')                                                               AS out_YEONDAE_1, --대표연대보증
               DECODE(A.YEONDAE_2,'Y','O','X')                                                               AS out_YEONDAE_2, --제3자연대보증
               DECODE(A.YEONDAE_3,'Y','O','X')                                                               AS out_YEONDAE_3, --담보예외
               TO_CHAR(A.START_YMD)                                                                          AS out_START_YMD,
               DECODE(NVL(M.MISU_AMT,0),0,0,DECODE(NVL(L.MONTH_SU,0),0,0,ROUND(M.MISU_AMT / L.MONTH_SU,0)))  AS out_AVG_SALE ,
               D.TODAY_AMT                                                                                   AS out_TODAY_AMT,
               DECODE(NVL(M.SU_AMT,0),0,0,DECODE(NVL(L.MONTH_SU,0),0,0,ROUND(M.SU_AMT  / L.MONTH_SU,0)))     AS out_AVG_SU_AMT ,
               D.TODAY_SU_AMT                                                                                AS out_TODAY_SU_AMT,
               A.GYEOYAK                                                                                     AS out_GYEOYAK
          FROM SALE0003 A,
               SALE0007 B,
               SALE0008 C,
               (SELECT A.CUST_ID                                  CUST_ID,
                       SUM(A.AMT) + SUM(VAT)                      TODAY_AMT,
                       SUM(A.SUKUM)                               TODAY_SU_AMT,
                       SUM(A.MISU_AMT) + SUM(A.AMT)+SUM(A.VAT)    SALE_AMT,
                       SUM(A.SU_AMT)   + SUM(SUKUM)               SU_AMT,
                      (SUM(A.BEFORE_AMT)+ SUM(A.MISU_AMT) - SUM(A.SU_AMT))+ (SUM(A.AMT)+SUM(A.VAT)-SUM(SUKUM))    JANGO
                 FROM (SELECT A.CUST_ID         CUST_ID,
                              A.SU_AMT          SU_AMT,
                              A.MISU_AMT        MISU_AMT,
                              A.BEFORE_AMT      BEFORE_AMT,
                              0                 AMT,
                              0                 VAT,
                              0                 SUKUM
                         FROM SALE0306 A
                        WHERE A.CUST_ID = in_CUST_CD
                          AND A.YMD     = TO_DATE(TO_CHAR(ADD_MONTHS(TO_DATE(in_DT,'YYYY/MM'),-1),'YYYYMM') || '01')
                        UNION ALL
                       SELECT A.CUST_ID         CUST_ID,
                              0                 SU_AMT,
                              0                 MISU_AMT,
                              0                 BEFORE_AMT,
                              B.AMT             AMT,
                              B.VAT             VAT,
                              0                 SUKUM
                         FROM SALE0207 A,
                              SALE0208 B,
                              SALE0004 D
                        WHERE A.DEAL_NO = B.DEAL_NO
                          AND A.YMD     = B.YMD
                          AND B.ITEM_ID = D.ITEM_ID
                          AND TO_CHAR(A.YMD,'YYYYYMMDD')     LIKE in_DT||'%'
                          AND A.CUST_ID = in_CUST_CD
                        UNION ALL /*  수금(할인) 내역 */
                       SELECT A.CUST_ID          CUST_ID,
                              0                  SU_AMT,
                              0                  MISU_AMT,
                              0                  BEFORE_AMT,
                              0                  AMT,
                              0                  VAT,
                              CASH_AMT           SUKUM
                         FROM SALE0401  A
                        WHERE TO_CHAR(A.YMD,'YYYYYMMDD')     LIKE in_DT||'%'
                          AND A.CUST_ID = in_CUST_CD
                          AND A.CASH_AMT      <> 0
                        UNION ALL
                       SELECT A.CUST_ID          CUST_ID,
                              0                  SU_AMT,
                              0                  MISU_AMT,
                              0                  BEFORE_AMT,
                              0                  AMT,
                              0                  VAT,
                              AMT                SUKUM
                         FROM SALE0402  B,
                              SALE0401  A
                        WHERE TO_CHAR(A.YMD,'YYYYYMMDD')     LIKE in_DT||'%'
                          AND A.CUST_ID = in_CUST_CD
                          AND A.JUNPYO_NO   = B.JUNPYO_NO ) A
                GROUP BY CUST_ID                          ) D,
                (SELECT X.CUST_ID        CUST_ID ,
                        NVL(SUM(AMT),0)  BILL_AMT
                   FROM SALE0401 X ,
                        SALE0402 Y
                  WHERE X.CUST_ID   = in_CUST_CD
                    AND X.YMD       = Y.YMD
                    AND X.JUNPYO_NO = Y.JUNPYO_NO
                    AND TO_CHAR(Y.END_YMD, 'YYYYMM')  > in_DT
                    AND NVL(Y.BILL_GB,'*') not IN ('025','035','040')
                  GROUP BY X.CUST_ID                     ) E,
                (SELECT X.CUST_ID        CUST_ID ,
                        NVL(SUM(AMT),0)  BILL_AMT
                   FROM SALE0401 X ,
                        SALE0402 Y
                  WHERE X.CUST_ID   = in_CUST_CD
                    AND X.YMD       = Y.YMD
                    AND X.JUNPYO_NO = Y.JUNPYO_NO
                    AND TO_CHAR(Y.END_YMD, 'YYYYMM')  > in_DT
                    AND NVL(Y.BILL_GB,'*') IN ('025','035','040')
                  GROUP BY X.CUST_ID                     ) F ,
                (SELECT CUST_ID   CUST_ID,
                        SUM(SALE_DAMBO_AMT) AMT
                   FROM SALE0404
                  WHERE CUST_ID = in_CUST_CD
                    AND BILL_GB IN ('약어','약어(신보)','어음')
                  GROUP BY CUST_ID                       ) G,
                (SELECT CUST_ID   CUST_ID,
                        SUM(SALE_DAMBO_AMT) AMT
                   FROM SALE0404
                  WHERE CUST_ID = in_CUST_CD
                    AND BILL_GB IN ('가수','당좌')
                  GROUP BY CUST_ID                       ) H,
                (SELECT CUST_ID   CUST_ID,
                        SUM(SALE_DAMBO_AMT) AMT
                   FROM SALE0404
                  WHERE CUST_ID = in_CUST_CD
                    AND BILL_GB NOT IN ('약어','약어(신보)','어음','가수','당좌')
                  GROUP BY CUST_ID                       ) I,
                (SELECT CUST_ID   CUST_ID,
                        DECODE(COUNT(*), 1, MAX(BILL_GB), MAX(BILL_GB)||'외 '||TO_CHAR(count(*) - 1)||'건')  BILL_GB
                   FROM SALE0404
                  WHERE CUST_ID = in_CUST_CD
                  GROUP BY CUST_ID                       ) J,
                (sELECT CUST_ID     CUST_ID, 
                        MONTHS_BETWEEN(TO_DATE(in_DT||'01'),TO_DATE(TO_CHAR(MIN(YMD),'YYYYMM')||'01')) MONTH_SU,
                        MIN(YMD)    MIN_YMD
                   FROM SALE0207
                  WHERE CUST_ID = in_CUST_CD
                  GROUP BY CUST_ID                       ) L,
               (SELECT A.CUST_ID                CUST_ID,
                       NVL(SUM(A.MISU_AMT),0)   MISU_AMT,
                       NVL(SUM(A.SU_AMT),0)     SU_AMT
                  FROM SALE0306 A
                 WHERE A.CUST_ID = in_CUST_CD
                   AND A.YMD <= TO_DATE(in_DT||'01')
                 GROUP BY A.CUST_ID                      ) M
         WHERE A.USE_YN   = 'Y'
           AND A.CUST_ID  = in_CUST_CD
           AND A.SAWON_ID = B.SAWON_ID
           AND B.DEPT_CD  = C.DEPT_CD
           AND A.CUST_ID  = D.CUST_ID(+)
           AND A.CUST_ID  = E.CUST_ID(+)
           AND A.CUST_ID  = F.CUST_ID(+)
           AND A.CUST_ID  = G.CUST_ID(+)
           AND A.CUST_ID  = H.CUST_ID(+)
           AND A.CUST_ID  = I.CUST_ID(+)
           AND A.CUST_ID  = J.CUST_ID(+)
           AND A.CUST_ID  = L.CUST_ID(+)
           AND A.CUST_ID  = M.CUST_ID(+)
         ORDER BY A.CUST_NM;
    END IF;
    
EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '거래처 코드가 누락되었습니다.';
WHEN DT_NULL THEN
   out_CODE := 102;
   out_MSG  := '조회 년월이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
