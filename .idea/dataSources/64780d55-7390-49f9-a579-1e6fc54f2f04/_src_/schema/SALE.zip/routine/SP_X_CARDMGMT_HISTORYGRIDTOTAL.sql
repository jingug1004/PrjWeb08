CREATE PROCEDURE      SP_X_CARDMGMT_HISTORYGRIDTOTAL
(
    in_USE_DT_FR  IN VARCHAR2,
    in_USE_DT_TO  IN VARCHAR2,
    in_SAWON_ID   IN VARCHAR2,
    in_TEAMMEMBER IN VARCHAR2,
    out_RESULT   OUT TYPES.CURSOR_TYPE,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_CARDMGMT_HISTORYGRIDTOTAL
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-30
-- 수 정 자      : 
-- 수정일자      : 2017-11-30
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  법인카드관리 BK 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	 
	 OPEN out_RESULT FOR
	     SELECT count(*) total_cnt, SUM(NVL(a.USE_AMT, 0)) total_use_amt
		    FROM (
			  SELECT a.CARD_NO,   
			         a.USE_DT,    
			         a.USE_TM,    
			         a.CARD_OK_NO,
			         a.USE_GUBUN,   
			         a.SAWON_ID,   
			         a.DEPT_CD,   
			         a.USE_AMT,   
			         a.SAUPJANG_NM,   
			         a.SAUP_NO,   
			         a.tax_gb,
			         a.GAEJUNG_CD,
			         (select gaejung_nm from account.faca03c where gaejung_cd = a.gaejung_cd) as gaejung_nm,   
			         a.USE_DETAIL,   
			         a.TEAMJANG_CONF_YN,   
			         a.TEAMJANG_CONF_SABUN,   
			         a.SALECAMP_CONF_YN,   
			         a.SALECAMP_CONF_SABUN,   
			         a.JUNPYO_YN,   
			         a.JUNPYO_NO,   
			         a.JUNPYO_SABUN,
			         a.JUNPYO_CRTDT,
			         a.JUNPYO_RESULT,
			         a.JUKYO,
			         a.GONGJAE_YN,
			         'N' as SEL_YN, 
			         (select sawon_nm from sale.sale0007 where sawon_id = a.TEAMJANG_CONF_SABUN) as TEAMJANG_CONF_SABUN_nm,
			         (select sawon_nm from sale.sale0007 where sawon_id = a.sawon_id) as sawon_nm,
			         (select dept_nm from sale.sale0008 where dept_cd = a.dept_cd) as dept_nm,
			         (select sawon_nm from sale.sale0007 where sawon_id = a.salecamp_conf_sabun) as salecamp_conf_sabun_nm,
			         nvl((select seungin_yn from account.faca11m where h_junpyo_cd = a.junpyo_no),'N') as seungin_yn
			    FROM sale.SALE0601_IBK a 
			   WHERE a.USE_DT BETWEEN in_USE_DT_FR AND in_USE_DT_TO
			     AND a.SAWON_ID IN (SELECT SAWON_ID FROM sale.SALE0007 WHERE part_gb is not null)
			     AND a.SAWON_ID IN ( SELECT SAWON_ID FROM sale.SALE0007 WHERE SIL_SAWON_ID = NVL(trim(in_SAWON_ID)   ,'%') )
			     AND trim(in_TEAMMEMBER) = 'Y'   
			UNION
			  SELECT a.CARD_NO,   
			         a.USE_DT,    
			         a.USE_TM,    
			         a.CARD_OK_NO,
			         a.USE_GUBUN,   
			         a.SAWON_ID,   
			         a.DEPT_CD,   
			         a.USE_AMT,   
			         a.SAUPJANG_NM,   
			         a.SAUP_NO,   
			         a.tax_gb,
			         a.GAEJUNG_CD,
			         (select gaejung_nm from account.faca03c where gaejung_cd = a.gaejung_cd) as gaejung_nm,   
			         a.USE_DETAIL,   
			         a.TEAMJANG_CONF_YN,   
			         a.TEAMJANG_CONF_SABUN,   
			         a.SALECAMP_CONF_YN,   
			         a.SALECAMP_CONF_SABUN,   
			         a.JUNPYO_YN,   
			         a.JUNPYO_NO,   
			         a.JUNPYO_SABUN,
			         a.JUNPYO_CRTDT,
			         a.JUNPYO_RESULT,
			         a.JUKYO,
			         a.GONGJAE_YN,
			         'N' as SEL_YN, 
			         (select sawon_nm from sale.sale0007 where sawon_id = a.TEAMJANG_CONF_SABUN) as TEAMJANG_CONF_SABUN_nm,
			         (select sawon_nm from sale.sale0007 where sawon_id = a.sawon_id) as sawon_nm,
			         (select dept_nm from sale.sale0008 where dept_cd = a.dept_cd) as dept_nm,
			         (select sawon_nm from sale.sale0007 where sawon_id = a.salecamp_conf_sabun) as salecamp_conf_sabun_nm,
			         nvl((select seungin_yn from account.faca11m where h_junpyo_cd = a.junpyo_no),'N') as seungin_yn
			    FROM sale.SALE0601_IBK a 
			   WHERE a.USE_DT BETWEEN in_USE_DT_FR AND in_USE_DT_TO
			     AND a.SAWON_ID IN (SELECT SAWON_ID FROM sale.SALE0007 WHERE part_gb is not null)
			     AND a.SAWON_ID IN (   SELECT SAWON_ID FROM sale.SALE0007 
			                                WHERE DEPT_CD IN ( SELECT DEPT_CD FROM sale.SALE0007 WHERE SIL_SAWON_ID = NVL(trim(in_SAWON_ID),'%') AND GUBUN = 'Y' )  
			                                        OR SAWON_ID IN ( SELECT SAWON_ID FROM sale.SALE0007 WHERE SIL_SAWON_ID = NVL(trim(in_SAWON_ID),'%'))
			                                   )   
			     AND trim(in_TEAMMEMBER) = 'N') a;

    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
END ;
/
