CREATE PROCEDURE      SP_X_INFO_UPDATECUSTOMERDETAIL
(
    in_TEL         IN VARCHAR2,
    in_HP          IN VARCHAR2,
    in_OPEN_DATE   IN VARCHAR2,
    in_FAX         IN VARCHAR2,
    in_ROOM_CNT    IN VARCHAR2,
    in_SUBMIT_DATE IN VARCHAR2,
    in_BEDNO       IN VARCHAR2,
    in_EMAIL       IN VARCHAR2,
    in_CUST_ID     IN VARCHAR2,
    out_CODE      OUT NUMBER,
    out_MSG       OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_INFO_UPDATECUSTOMERDETAIL
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    : 거래처 상세정보 및 기타사항 주정 프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
    UPDATE SALE.SALE0003
		   SET TEL			= in_TEL,
		       HP			= in_HP,
		       OPEN_DATE	= in_OPEN_DATE,
		       FAX			= in_FAX,
		       ROOM_CNT		= in_ROOM_CNT,
		       SUBMIT_DATE	= in_SUBMIT_DATE,
		       BEDNO		= in_BEDNO,
		       EMAIL		= in_EMAIL 
		 WHERE CUST_ID      = in_CUST_ID;
		 
 IF SQLCODE <> 0 THEN
	    DBMS_OUTPUT.PUT_LINE('실패 UPDATE ');
	    ROLLBACK;
	ELSE
	    out_CODE := 0;
        out_MSG := '데이터 수정';
        COMMIT;
	END IF; 
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 
        ROLLBACK; 	 
END ;
/
