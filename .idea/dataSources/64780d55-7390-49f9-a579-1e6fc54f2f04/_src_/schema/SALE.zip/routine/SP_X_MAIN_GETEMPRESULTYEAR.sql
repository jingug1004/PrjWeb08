CREATE PROCEDURE      SP_X_MAIN_GETEMPRESULTYEAR
(
    in_SILJUKYUL_IN    IN VARCHAR2,
    in_SILJUKYUL_IN_SU IN VARCHAR2,
    in_YEAR            IN VARCHAR2,
    in_EMPID           IN VARCHAR2,
    out_RESULT        OUT TYPES.CURSOR_TYPE,
    out_CODE          OUT NUMBER,
    out_MSG           OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 
	
	OPEN out_RESULT FOR
        SELECT 	
			  SUBSTR(DATE_TIME,5,2) AS MONTH,
	          SUM(SALE_AMT) AS SALE_GOAL_AMT,  
	          ROUND((SUM(SALE_AMT_SILJUK) + SUM(SALE_AMT_HALINS02) )  * ( NVL(in_SILJUKYUL_IN,100) * 0.01 ) ,0)  AS SALE_RESULT_AMT,  
	          AVG(SALE_PERCENT) AS SALE_PERCENT,
	          SUM(IN_AMT) AS IN_SALE_GOAL_AMT,  
	          ROUND(SUM(IN_AMT_SILJUK) * ( NVL(in_SILJUKYUL_IN_SU,100) * 0.01), 0) AS IN_SALE_RESULT_AMT,
	          SUM(IN_PERCENT) AS IN_PERCENT   
	     FROM SALE.SALEPART_BATCH2
	    WHERE SUBSTR(DATE_TIME,1,4) = in_YEAR 
	      AND EMP_NO = in_EMPID
	    GROUP BY SUBSTR(DATE_TIME,5,2)
	    ORDER BY MONTH;
	    
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
