CREATE PROCEDURE      SP_Z_CUST_011_109
(
    in_DEPT_CD           IN  VARCHAR2,    -- 부서코드
    in_SAWON_ID          IN  VARCHAR2,    -- 사원 ID
    in_CUST_NM           IN  VARCHAR2,    -- 거래처명
    in_SIDO_NM              IN  VARCHAR2,    -- 시도 
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처요청
 호출프로그램 :sfa - 거래처-거래처요청화면-조회버튼        
 수정사항    :2013-01-18 우리약국처럼 400건 가까운건수가 조회되는 문제가 있어서 시도조건추가함       
          2015-05-13 kta COMPANY_ADDR1 이 null 인경우 조회안되는 문제 수정    
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼     
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    DEPT_CD_NULL         EXCEPTION;
    SAWON_ID_NULL        EXCEPTION;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_04_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SFA_SALES_SEQ,sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN||'/in_CLIENT_NO '||in_CLIENT_NO );
--commit;

    
    IF in_DEPT_CD IS NULL OR TRIM(in_DEPT_CD) = '' THEN
        RAISE DEPT_CD_NULL;
    END IF;
    
    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
        RAISE SAWON_ID_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.CMHIRAM a 
     WHERE a.plantcode = '1000'
       AND a.hiraname LIKE '%'||NVL(in_CUST_NM,'%')||'%'
       AND nvl(a.hiraaddr,'%') LIKE '%'||NVL(in_SIDO_NM,'%')||'%' ;

    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num > 100) THEN
        out_CODE := 1;
        out_MSG := '검색 결과가 100 건이상입니다. 조건을 다시 입력하세요.';  
        
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        
        SELECT a.hiracode                   AS out_CUST_KEY 
              ,a.hiracode                   AS out_CUST_CD        -- 거래처코드
              ,a.hiraname                   AS out_CUST_NM        -- 거래처명
              ,a.ceoname                    AS out_MANAGER_NM     -- 대표자명
              ,a.custcode                   AS out_ERP_CD         -- ERP 코드
              ,'['||F_SFA_CODE_NM('CUST_STAT_GB',a.sagodiv)||'-'||decode(a.sagodiv,'1',oragmp.fncommonnm('emp',a.orderempcode,''),oragmp.fncommonnm('emp',a.areaempcode,''))||'] '||a.hiraaddr                   
                                            AS out_ADDR1          -- 주소
              ,a.sagodiv                    AS out_CUST_STAT_GB   -- 거래상태
             , case 
                when (a.sagodiv = '1')    then '주문' 
                when (a.sagodiv = '2')    then '활동' 
                when (a.sagodiv = '3')    then '비활동' 
                else ''  end                AS out_CUST_STAT_GBNM
          FROM ORAGMP.CMHIRAM a 
         WHERE a.plantcode = '1000'
           AND a.hiraname LIKE '%'||NVL(in_CUST_NM,'%')||'%'
           AND nvl(a.hiraaddr,'%') LIKE '%'||NVL(in_SIDO_NM,'%')||'%'  
         ORDER BY a.sagodiv,a.hiraname
         ;
    END IF;
    
EXCEPTION
WHEN DEPT_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '부서코드가 누락되었습니다.';
WHEN SAWON_ID_NULL THEN
   out_CODE := 102;
   out_MSG  := '사원 ID가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
