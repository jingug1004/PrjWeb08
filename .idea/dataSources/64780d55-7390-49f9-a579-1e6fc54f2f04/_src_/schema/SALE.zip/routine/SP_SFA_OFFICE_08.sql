CREATE PROCEDURE      SP_SFA_OFFICE_08
(
    in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3)
    in_BRD_NO            IN  NUMBER,       -- 게시판 번호
    in_BRDWRT_NO         IN  NUMBER,       -- 게시글 번호
    in_BRDWRT_SEQ        IN  NUMBER,       -- 게시글 순번
    in_SAWON_ID          IN  VARCHAR2,     -- 사번
    in_BRDWRT_TYPE       IN  VARCHAR2,     -- 게시글 유형
    in_TITL              IN  VARCHAR2,     -- 제목
    in_CONT              IN  VARCHAR2,     -- 내용
    in_BRD_STR_DD        IN  VARCHAR2,     -- 게시 시작일
    in_BRD_END_DD        IN  VARCHAR2,     -- 게시 종료일
    in_DEL_YN            IN  VARCHAR2,     -- 삭제여부
    in_SUPER_BRDWRT_SEQ  IN  NUMBER,       -- 상위게시글 순번
    in_GW_DEPT           IN  VARCHAR2,     -- 게시대상 부서
    in_GW_UNO            IN  VARCHAR2,     -- 게시대상 사번
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 게시판 신규,수정,삭제 
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_no                 NUMBER;
    v_seq                NUMBER;
    
    v_uno                VARCHAR2(7);
    v_ent_uno            VARCHAR2(7);
    v_cnt                NUMBER;
    v_gw_dept            VARCHAR2(6);
    v_gw_uno             VARCHAR2(7);
    
BEGIN 


    SELECT COUNT(*)
      INTO v_num
      FROM hanagw.TGWBDM A   LEFT OUTER JOIN hanagw.TGWBDATCH B
                              ON  A.BRD_NO         = B.BRD_NO
                              AND A.BRDWRT_NO      = B.BRDWRT_NO
                              AND A.BRDWRT_SEQ     = B.BRDWRT_SEQ                                   
     WHERE A.BRD_NO      = in_BRD_NO
       AND NVL(A.DEL_YN, 'N') = 'N';
         
    out_COUNT := v_num;
    IF in_BTN_GUBUN = 1 THEN -- 등록버튼 클릭한 경우
    
            
        out_CODE := 1;
        out_MSG := '자료등록 실패 : SFA 게시판의 게시물 등록 서비스를 잠시 중단합니다.   그룹웨어 자료실을 이용해 주시기 바랍니다.    - 전산팀 배상 -';
        RETURN;    
        --2015.08.12 KTA :게시판이 그룹웨어와 연결되지 않아서 잠시 막음. 프로시져를 그룹웨어와 연동후 서비스 제게 할것임.
    
        SELECT COUNT(*)
          INTO v_num
          FROM hanagw.TGWBDM A   LEFT OUTER JOIN hanagw.TGWBDATCH B
                              ON  A.BRD_NO         = B.BRD_NO
                              AND A.BRDWRT_NO      = B.BRDWRT_NO
                              AND A.BRDWRT_SEQ     = B.BRDWRT_SEQ                                    
         WHERE A.BRD_NO      = in_BRD_NO
           AND A.BRDWRT_NO   = in_BRDWRT_NO
           AND A.BRDWRT_SEQ  = in_BRDWRT_SEQ
           AND NVL(A.DEL_YN, 'N') = 'N';
                  
        IF v_num >= 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 있습니다';
        ELSE
            -- 필수값 체크 루틴 넣을것.                    
            SELECT NVL(UNO, '0000000')
              INTO v_uno
              FROM V_SAWON_ID_MAP
             WHERE SAWON_ID = in_SAWON_ID;
             
            -- 게시글번호 MAX 생성
            SELECT NVL(MAX(BRDWRT_NO),0) + 1
              INTO v_no
              FROM hanagw.TGWBDM 
             WHERE BRD_NO = in_BRD_NO;
             
             
            -- 게시글번호 MAX 생성
            SELECT NVL(MAX(BRDWRT_SEQ),0)+1
              INTO v_seq
              FROM hanagw.TGWBDM 
             WHERE BRD_NO = in_BRD_NO
               AND BRDWRT_NO = v_no;
              
            -- 등록     -- 
            INSERT INTO hanagw.TGWBDM(BRD_NO,       BRDWRT_NO,   BRDWRT_SEQ, DRW_UNO,    BRDWRT_TYPE,    TITL,    CONT,    DRW_DTM,                              
                                                   BRD_STR_DD,   BRD_END_DD,  DEL_YN,     ENT_UNO,    ENT_DTM) 
                                             VALUES(in_BRD_NO,   v_no,        v_seq,      v_uno, '0', in_TITL, in_CONT, TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'), 
                                                   TO_CHAR(SYSDATE, 'YYYYMMDD'), '29991231', 'N', v_uno, SYSDATE) ;
            -- 게시대상자 리스트 INSERT(로그인사원의 부서 INSERT시 WHERE조건 주석해제, 전체 INSERT할 경우 WHERE 조건 제거할것)
            INSERT INTO hanagw.TGWBDTGT(BRD_NO,    BRDWRT_NO, BRDWRT_SEQ, TGT_UNO, REMK, ENT_UNO, ENT_DTM)
             SELECT in_BRD_NO,   v_no,      v_seq,      UNO, in_CONT, (SELECT UNO FROM V_SAWON_ID_MAP WHERE SAWON_ID = in_SAWON_ID), SYSDATE
               FROM hanagw.TCMORG_R
--              WHERE ORGNO = (SELECT ORGNO FROM TCMORG_R@HANA_GW1.HANA.CO.KR WHERE UNO = (SELECT UNO FROM V_SAWON_ID_MAP WHERE SAWON_ID = in_SAWON_ID))
              ;
              
            COMMIT;
/*            
            IF in_GW_UNO IS NULL THEN  --  부서별 게시
               v_cnt := LENGTH(in_GW_DEPT)/6;   -- 부서는 CHAR(6) 임
               FOR i IN 1 .. v_cnt LOOP
                   v_gw_dept := SUBSTR(in_GW_DEPT, (i+(5*(i-1))), (i+(5*i)));
                   INSERT INTO TGWBDTGT@HANA_GW1.HANA.CO.KR(BRD_NO,    BRDWRT_NO, BRDWRT_SEQ, TGT_UNO, REMK, ENT_UNO, ENT_DTM)
                               SELECT in_BRD_NO,   v_no,      v_seq,      UNO, in_CONT, (SELECT UNO FROM V_SAWON_ID_MAP WHERE SAWON_ID = in_SAWON_ID), SYSDATE
                                 FROM TCMORG_R@HANA_GW1.HANA.CO.KR
                                WHERE ORGNO = v_gw_dept;
               END LOOP;
                                      
            ELSE   -- 사원별 게시
               v_cnt := LENGTH(in_GW_UNO)/7;   -- 사원코드는 CHAR(7) 임
               FOR i IN 1 .. v_cnt LOOP
                   v_gw_uno := SUBSTR(in_GW_UNO, (i+(6*(i-1))), (i+(6*i)));
                   INSERT INTO TGWBDTGT@HANA_GW1.HANA.CO.KR(BRD_NO,    BRDWRT_NO, BRDWRT_SEQ, TGT_UNO, REMK, ENT_UNO, ENT_DTM)
                               VALUES(in_BRD_NO,   v_no,      v_seq,      v_gw_uno, in_CONT, (SELECT UNO FROM V_SAWON_ID_MAP WHERE SAWON_ID = in_SAWON_ID), SYSDATE);
               END LOOP;
            END IF;
            
            COMMIT;
*/                        
            OPEN out_RESULT FOR
            SELECT A.BRD_NO                 AS out_BRD_NO            --게시판 번호
                 , A.BRDWRT_NO              AS out_BRDWRT_NO         --게시글 번호
                 , A.BRDWRT_SEQ             AS out_BRDWRT_SEQ        --게시글 일련번호
                 , SUBSTR(A.DRW_DTM,1,8)    AS out_DRW_DTM           -- 작성일자
                 , A.DRW_UNO                AS out_DRW_UNO           -- 작성자 사번
                 , (SELECT DISTINCT EMP_KO_NM FROM V_SAWON_ID_MAP WHERE UNO = A.DRW_UNO)                       AS out_DRW_NM            -- 작성자 명
                 , A.TITL                   AS out_TITL              --게시글 제목
                 , A.CONT                   AS out_CONT              --게시글 내용
                 , A.BRD_STR_DD             AS out_BRD_STR_DD        --게시 시작일
                 , A.BRD_END_DD             AS out_BRD_END_DD        --게시 종료일  
                 , B.FILE_NM                AS out_FILE_NM        -- 첨부파일명  
                 , B.USE_APP_PATH           AS out_APP_PATH       -- 첨부파일경로   
                 , in_SAWON_ID              AS out_SAWON_ID   -- UNO 변환 SALE사번  -- (SELECT NVL(SAWON_ID, EMP_NO) FROM V_SAWON_ID_MAP WHERE UNO = A.DRW_UNO AND SAWON_ID = in_SAWON_ID)
                FROM hanagw.TGWBDM A  LEFT OUTER JOIN hanagw.TGWBDATCH B
                              ON  A.BRD_NO         = B.BRD_NO
                              AND A.BRDWRT_NO      = B.BRDWRT_NO
                              AND A.BRDWRT_SEQ     = B.BRDWRT_SEQ   -- TGWBDM@HANA_GW1.HANA.CO.KR A
             WHERE A.BRD_NO      = in_BRD_NO
               AND A.BRDWRT_NO   = v_no
               AND A.BRDWRT_SEQ  = v_seq
               AND NVL(A.DEL_YN, 'N') = 'N'
             ORDER BY A.DRW_DTM DESC;
             
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '등록이 완료되었습니다';
        END IF;
        
        
    ELSIF in_BTN_GUBUN = 2 THEN -- 수정버튼 클릭한 경우
        -- 필수값 체크 루틴 넣을것.                    
        SELECT NVL(UNO, '0000000')
          INTO v_uno
          FROM V_SAWON_ID_MAP
         WHERE SAWON_ID = in_SAWON_ID;
             
        IF v_num < 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            SELECT A.ENT_UNO
              INTO v_ent_uno
              FROM hanagw.TGWBDM A  LEFT OUTER JOIN hanagw.TGWBDATCH B
                              ON  A.BRD_NO         = B.BRD_NO
                              AND A.BRDWRT_NO      = B.BRDWRT_NO
                              AND A.BRDWRT_SEQ     = B.BRDWRT_SEQ   
             WHERE A.BRD_NO      = in_BRD_NO
               AND A.BRDWRT_NO   = in_BRDWRT_NO
               AND A.BRDWRT_SEQ  = in_BRDWRT_SEQ;
               
            IF v_uno <> v_ENT_uno THEN
                out_CODE := 1;
                out_MSG := '본인 등록 게시글이 아닙니다.';
            ELSE
                UPDATE hanagw.TGWBDM 
                   SET DRW_UNO        =    v_uno
                     , BRDWRT_TYPE    =    in_BRDWRT_TYPE
                     , TITL           =    in_TITL
                     , CONT           =    in_CONT
                     , BRD_STR_DD     =    NVL(in_BRD_STR_DD, TO_CHAR(SYSDATE, 'YYYYMMDD'))
                     , BRD_END_DD     =    NVL(in_BRD_END_DD, '29991231')
                     , DEL_YN         =    NVL(in_DEL_YN, 'N')
                     , UPD_UNO        =    v_uno
                     , UPD_DTM        =    SYSDATE
                 WHERE BRD_NO      = in_BRD_NO
                   AND BRDWRT_NO   = in_BRDWRT_NO
                   AND BRDWRT_SEQ  = in_BRDWRT_SEQ;
                  
                COMMIT;

                OPEN out_RESULT FOR
                SELECT A.BRD_NO                 AS out_BRD_NO            --게시판 번호
                     , A.BRDWRT_NO              AS out_BRDWRT_NO         --게시글 번호
                     , A.BRDWRT_SEQ             AS out_BRDWRT_SEQ        --게시글 일련번호
                     , SUBSTR(A.DRW_DTM,1,8)    AS out_DRW_DTM           -- 작성일자
                     , A.DRW_UNO                AS out_DRW_UNO           -- 작성자 사번
                     , (SELECT DISTINCT EMP_KO_NM FROM V_SAWON_ID_MAP WHERE UNO = A.DRW_UNO)                 AS out_DRW_NM            -- 작성자 명
                     , A.TITL                   AS out_TITL              --게시글 제목
                     , A.CONT                   AS out_CONT              --게시글 내용
                     , A.BRD_STR_DD             AS out_BRD_STR_DD        --게시 시작일
                     , A.BRD_END_DD             AS out_BRD_END_DD        --게시 종료일  
                     , B.FILE_NM                AS out_FILE_NM        -- 첨부파일명 
                     , B.USE_APP_PATH           AS out_APP_PATH       -- 첨부파일경로      
                     , in_SAWON_ID              AS out_SAWON_ID   -- UNO 변환 SALE사번  -- (SELECT NVL(SAWON_ID, EMP_NO) FROM V_SAWON_ID_MAP WHERE UNO = A.DRW_UNO AND SAWON_ID = in_SAWON_ID)
                    FROM hanagw.TGWBDM A  LEFT OUTER JOIN hanagw.TGWBDATCH B
                                  ON  A.BRD_NO         = B.BRD_NO
                                  AND A.BRDWRT_NO      = B.BRDWRT_NO
                                  AND A.BRDWRT_SEQ     = B.BRDWRT_SEQ   
                 WHERE A.BRD_NO      = in_BRD_NO
                   AND A.BRDWRT_NO   = in_BRDWRT_NO
                   AND A.BRDWRT_SEQ  = in_BRDWRT_SEQ
                   AND NVL(A.DEL_YN, 'N') = 'N'
                 ORDER BY A.DRW_DTM DESC;
                 
                out_CODE := 0;
                out_MSG := '수정이 완료되었습니다';
            END IF;
        END IF;
    ELSIF in_BTN_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우
        -- 필수값 체크 루틴 넣을것.                    
        SELECT NVL(UNO, '0000000')
          INTO v_uno
          FROM V_SAWON_ID_MAP
         WHERE SAWON_ID = in_SAWON_ID;
         
        IF v_num < 1 THEN
            out_CODE := 1;
            out_MSG := '기존 등록된 답글이 없습니다';
        ELSE            
            SELECT A.ENT_UNO
              INTO v_ent_uno
              FROM hanagw.TGWBDM A  LEFT OUTER JOIN hanagw.TGWBDATCH B
                              ON  A.BRD_NO         = B.BRD_NO
                              AND A.BRDWRT_NO      = B.BRDWRT_NO
                              AND A.BRDWRT_SEQ     = B.BRDWRT_SEQ   
             WHERE A.BRD_NO      = in_BRD_NO
               AND A.BRDWRT_NO   = in_BRDWRT_NO
               AND A.BRDWRT_SEQ  = in_BRDWRT_SEQ;
               
            IF v_uno <> v_ENT_uno THEN
                out_CODE := 1;
                out_MSG := '본인 등록 게시글이 아닙니다.';
            ELSE          
                UPDATE hanagw.TGWBDM 
                   SET DEL_YN          = 'Y'
                     , UPD_UNO         = v_uno
                     , UPD_DTM         = SYSDATE
                 WHERE BRD_NO          = in_BRD_NO
                   AND BRDWRT_NO       = in_BRDWRT_NO
                   AND BRDWRT_SEQ      = in_BRDWRT_SEQ;
                  
                COMMIT;
                
                OPEN out_RESULT FOR
                SELECT A.BRD_NO                 AS out_BRD_NO            --게시판 번호
                     , A.BRDWRT_NO              AS out_BRDWRT_NO         --게시글 번호
                     , A.BRDWRT_SEQ             AS out_BRDWRT_SEQ        --게시글 일련번호
                     , SUBSTR(A.DRW_DTM,1,8)    AS out_DRW_DTM           -- 작성일자
                     , A.DRW_UNO                AS out_DRW_UNO           -- 작성자 사번
                     , (SELECT DISTINCT EMP_KO_NM FROM V_SAWON_ID_MAP WHERE UNO = A.DRW_UNO)                      AS out_DRW_NM            -- 작성자 명
                     , A.TITL                   AS out_TITL              --게시글 제목
                     , A.CONT                   AS out_CONT              --게시글 내용
                     , A.BRD_STR_DD             AS out_BRD_STR_DD        --게시 시작일
                     , A.BRD_END_DD             AS out_BRD_END_DD        --게시 종료일  
                     , B.FILE_NM                AS out_FILE_NM        -- 첨부파일명   
                     , B.USE_APP_PATH           AS out_APP_PATH       -- 첨부파일경로    
                     , in_SAWON_ID              AS out_SAWON_ID   -- UNO 변환 SALE사번  -- (SELECT NVL(SAWON_ID, EMP_NO) FROM V_SAWON_ID_MAP WHERE UNO = A.DRW_UNO AND SAWON_ID = in_SAWON_ID)
                    FROM hanagw.TGWBDM A  LEFT OUTER JOIN hanagw.TGWBDATCH B
                                  ON  A.BRD_NO         = B.BRD_NO
                                  AND A.BRDWRT_NO      = B.BRDWRT_NO
                                  AND A.BRDWRT_SEQ     = B.BRDWRT_SEQ    
                 WHERE A.BRD_NO      = in_BRD_NO
                   AND A.BRDWRT_NO   = in_BRDWRT_NO
                   AND A.BRDWRT_SEQ  = (SELECT MAX(BRDWRT_SEQ) FROM hanagw.TGWBDM WHERE BRD_NO = in_BRD_NO  AND BRDWRT_NO   = in_BRDWRT_NO AND NVL(A.DEL_YN, 'N') = 'N')
                   AND NVL(A.DEL_YN, 'N') = 'N'
                 ORDER BY A.DRW_DTM DESC;
                 
                out_CODE := 0;
                out_MSG := '삭제가 완료되었습니다';
            END IF;
         END IF;
         
    ELSE   -- 조회처리
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '정보가 존재하지 않습니다.';
        ELSIF (v_num >= 1) THEN
            out_CODE := 0;
            out_MSG := '정보 확인완료';    
             
            OPEN out_RESULT FOR
            SELECT A.BRD_NO                 AS out_BRD_NO            --게시판 번호
                 , A.BRDWRT_NO              AS out_BRDWRT_NO         --게시글 번호
                 , A.BRDWRT_SEQ             AS out_BRDWRT_SEQ        --게시글 일련번호
                 , SUBSTR(A.DRW_DTM,1,8)    AS out_DRW_DTM           -- 작성일자
                 , A.DRW_UNO                AS out_DRW_UNO           -- 작성자 사번
                 , (SELECT DISTINCT EMP_KO_NM FROM V_SAWON_ID_MAP WHERE UNO = A.DRW_UNO)                       AS out_DRW_NM            -- 작성자 명
                 , A.TITL                   AS out_TITL              --게시글 제목
                 , A.CONT                   AS out_CONT              --게시글 내용
                 , A.BRD_STR_DD             AS out_BRD_STR_DD        --게시 시작일
                 , A.BRD_END_DD             AS out_BRD_END_DD        --게시 종료일 
                 , B.FILE_NM                AS out_FILE_NM        -- 첨부파일명    
                 , B.USE_APP_PATH           AS out_APP_PATH       -- 첨부파일경로   
                 , in_SAWON_ID              AS out_SAWON_ID   -- UNO 변환 SALE사번  -- (SELECT NVL(SAWON_ID, EMP_NO) FROM V_SAWON_ID_MAP WHERE UNO = A.DRW_UNO AND SAWON_ID = in_SAWON_ID)
                FROM hanagw.TGWBDM A  LEFT OUTER JOIN hanagw.TGWBDATCH B
                              ON  A.BRD_NO         = B.BRD_NO
                              AND A.BRDWRT_NO      = B.BRDWRT_NO
                              AND A.BRDWRT_SEQ     = B.BRDWRT_SEQ     
             WHERE A.BRD_NO      = in_BRD_NO
               AND NVL(A.DEL_YN, 'N') = 'N'
             ORDER BY A.DRW_DTM DESC;
        END IF;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
