CREATE PROCEDURE      SP_SFA_STATUS_09
(
    in_CUST_CD           IN  VARCHAR2,    -- 거래처코드
    in_DT                IN  VARCHAR2,    -- 기간
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 거래처 담보현황
 호출프로그램 : 거래처> 거래처현황       
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼           
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    CUST_CD_NULL         EXCEPTION;
    DT_NULL              EXCEPTION;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_04_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SFA_SALES_SEQ,sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN||'/in_CLIENT_NO '||in_CLIENT_NO );
--commit;
    
    IF in_CUST_CD IS NULL THEN
        RAISE CUST_CD_NULL;
    END IF;
    
    IF in_DT IS NULL THEN
        RAISE DT_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.CMCUSTSCRTD a
     WHERE a.plantcode = '1000'
       AND a.custcode = in_CUST_CD     
       AND in_DT BETWEEN substr(replace(nvl(a.fixdate,to_char(sysdate - 30,'yyyy-mm-dd')), '-',''),1,6) AND substr(replace(a.expdate,'-',''),1,6)
    ; 
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT a.custcode                                 AS out_CUST_CD,           -- 거래처 코드
               oragmp.fncommonnm('cust',a.custcode,'')    AS out_CUST_NM,           -- 거래처 명 
               a.seq                                      AS out_INPUT_SEQ,         -- 입력순번(입력일자 14자리)
               a.scrtamt                                  AS out_SALE_DAMBO_AMT,    -- 매출담보금액, 담보가치액
               0                                          AS out_BUY_DAMBO_AMT,     -- 매입담보금액
               replace(a.expdate, '-','')                 AS out_END_YMD,           -- 만기일자
               replace(a.fixdate, '-','')                 AS out_START_YMD,         -- 발행일자
               a.guarantor                                AS out_BALHANG,           -- 발행처,발행자
               replace(a.objectaddr,'지급처:','')            AS out_JIGEUB,            -- 지급처. 물건지주소
               a.billno                                   AS out_BILL_NO,           -- 어음번호
               oragmp.fncommonnm('comm','SL04',a.scrtdiv) AS out_BILL_GB,           -- 어음 구분,담보구분
               a.remark                                   AS out_BIGO,              -- 비고
               TO_CHAR(a.insertdt, 'YYYYMMDD')            AS out_INPUT_YMD,         -- 입력일자
               ''                                         AS out_CHULGO_YMD         -- 출고일자
          FROM ORAGMP.CMCUSTSCRTD a
         WHERE a.plantcode = '1000'
           AND a.custcode = in_CUST_CD     
           --AND in_DT BETWEEN substr(replace(nvl(a.fixdate,to_char(sysdate - 30,'yyyy-mm-dd')), '-',''),1,6) AND substr(replace(nvl(a.expdate,'9999-12-31'), '-',''),1,6)
         ORDER BY a.fixdate desc;
    END IF;
    
EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '거래처 코드가 누락되었습니다.';
WHEN DT_NULL THEN
   out_CODE := 102;
   out_MSG  := '조회 년월이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
