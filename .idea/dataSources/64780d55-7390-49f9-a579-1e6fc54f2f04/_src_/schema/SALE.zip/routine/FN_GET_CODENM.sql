CREATE function fn_get_codenm(
       v_codel in varchar2, 
       v_codes in varchar2) 
return varchar2 is

begin
  For c1 in ( SELECT CODE1_NM
                FROM SALE0001  
               WHERE CODE_GB = v_codel
                 AND CODE1   = v_codes
            ) loop
            
      Return c1.CODE1_NM;
   End loop;

 return '';

end fn_get_codenm;

/
