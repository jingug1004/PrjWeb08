CREATE PROCEDURE      SP_SFA_ADMIN_05    -- 브로셔 검색
(
    in_BRUSH_NM          IN  VARCHAR2,  -- 브러쉬명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_BRUSHER
     WHERE BRUSH_NM LIKE '%'||NVL(in_BRUSH_NM, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT BRUSH_CD                  AS out_BRUSH_CD         -- 제품코드
             , BRUSH_SEQ                 AS out_SEQ              -- 일련번호
             , BRUSH_NM                  AS out_BRUSH_NM         -- 제품명
             , BRUSH_YN                  AS out_BRUSH_YN         -- 사용여부
             , ITEM_PATH                 AS out_ITEM_PATH        -- 저장경로(서버)
             , ITEM_NAME                 AS out_ITEM_NM          -- 원래파일명
             , SAVE_ITEM_NAME            AS out_SAVE_ITEM_NM          -- 폴더저장파일명
          FROM SFA_OFFICE_BRUSHER
         WHERE BRUSH_NM LIKE '%'||NVL(in_BRUSH_NM, '%')||'%'
         ORDER BY BRUSH_NM;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
