CREATE PROCEDURE      SP_SFA_CUST_05_106
(
    in_CLIENT_NM         IN  VARCHAR2,     -- 고객 명 코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 전국 고객 검색
 호출프로그램 : 거래처> 전국고객찾기화면       
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼     
 ---------------------------------------------------------------------------*/   
    v_num                NUMBER;
    
BEGIN 

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_04_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SFA_SALES_SEQ,sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN||'/in_CLIENT_NO '||in_CLIENT_NO );
--commit; 

    
    SELECT COUNT(*)
      INTO v_num
      FROM SALE.SFA_HIRA_CUSTOMER a
          ,ORAGMP.CMHIRAM b
     WHERE a.hiracode  = b.hiracode
       AND a.client_name  LIKE '%'||NVL(in_CLIENT_NM,'%')||'%'
       AND nvl(a.del_yn, 'N') = 'N'
    ;
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 고객이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '고객 검색 완료';    
     
        OPEN out_RESULT FOR
        SELECT a.hiracode                                       AS out_SFA_SALES_SEQ 
             , a.hiracode                                       AS out_CUST_CD
             , b.hiraname                                       AS out_CUST_NM
             , a.sfa_client_no                                  AS out_CLIENT_NO
             , oragmp.fncommonnm('comm','SL05',a.client_dept)   AS out_CLIENT_DEPT --진료과목
             , a.position_name                                  AS out_POSITION_NM
             , a.client_name                                    AS out_CLIENT_NM
             , b.hiraaddr                                       AS out_ADDRESS   
             , a.birthday                                       AS out_BIRTHDAY
             , a.birthday_gubun                                 AS out_BIRTHDAY_GUBUN
          FROM SALE.SFA_HIRA_CUSTOMER a
              ,ORAGMP.CMHIRAM b
         WHERE a.hiracode  = b.hiracode
           AND a.client_name  LIKE '%'||NVL(in_CLIENT_NM,'%')||'%'
           AND nvl(a.del_yn, 'N') = 'N'
         ORDER BY a.client_name;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
