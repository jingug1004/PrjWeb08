CREATE PROCEDURE      SP_X_MAIN_GETEMPINFO
(
    in_EMPID      IN VARCHAR2,
    out_RESULT   OUT TYPES.CURSOR_TYPE,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2
)
IS 
-- ---------------------------------------------------------------
-- 프로시저명   : SP_X_
-- 작 성 자      : 유명배
-- 작성일자      : 2017-11-28
-- 수 정 자      : 
-- 수정일자      : 2017-11-28
-- 수정내용      : 
-- 수 정 자       : 
-- E-Mail   : nago51@daum.net
-- ---------------------------------------------------------------
-- 프로시저 설명    :  프로시저이다.
-- ---------------------------------------------------------------
BEGIN 

	OPEN out_RESULT FOR
        SELECT A.SAWON_NM, A.SIL_SAWON_ID EMP_ID, A.PART_GB PART_GB, CODE1_NM PART_NM, A.DEPT_CD, C.DEPT_NM 
		FROM SALE.SALE0007 A, SALE.SALE0001 B, SALE.SALE0008 C
		WHERE A.SAWON_ID = in_EMPID AND A.GUBUN = 'Y'
		AND B.CODE_GB = '0013' AND B.CODE1 = A.PART_GB
		AND C.DEPT_CD = A.DEPT_CD;
		
    out_CODE := 0;
    out_MSG := '데이터 확인';
	
EXCEPTION
    WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 	 

END ;
/
