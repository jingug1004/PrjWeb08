CREATE function      F_GET_SALE0007_SAWON_NM
        ( A_SAWON_ID      VARCHAR2   
        )
   RETURN VARCHAR2
AS 
   n_rtn_value    VARCHAR2(250); 

/*----------------------------------------------------------------
 개요  :사번을 받아서 사원명을  리턴
 작성일:2014.01.09
 작성자:김태안 
----------------------------------------------------------------*/
BEGIN
  
      SELECT A.SAWON_NM
          INTO n_rtn_value
          FROM SALE0007 A
         WHERE A.SAWON_ID     = A_SAWON_ID;

        IF SQL%NOTFOUND THEN
              RETURN '01';
        ELSIF n_rtn_value IS NULL THEN
              RETURN '01';
        END IF;
            
        RETURN n_rtn_value;

        EXCEPTION WHEN OTHERS THEN
                       RAISE_APPLICATION_ERROR(-20002, substrb(SQLERRM,1,250));
END;

/
