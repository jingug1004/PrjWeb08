CREATE PROCEDURE      SP_SFA_COMMON_021 
(
    in_GUBUN             IN  NUMBER,    -- 1:코드, 2:거래처명
    in_ITEM              IN  VARCHAR2,  -- 거래처 코드/명
    in_DEPT_CD           IN  VARCHAR2,  -- 부서코드--사용하지 않음 테이블변경전에 사용하였음.
    in_SAWON_ID          IN  VARCHAR2,  -- 사원코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 히라거래처선택팝업 -  사용여부 판단필요
 호출프로그램  : 
 수정기록    :   
         2017.11.01 KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    
   
    v_num               NUMBER; 
    v_assgn_cd          VARCHAR2(5);
    v_deptcode          VARCHAR2(4);  -- 로그인사원부서
    v_query_deptcode    VARCHAR2(4);  -- 조회부서
    
    v_cust_cd           VARCHAR2(7);  
    v_cust_nm           VARCHAR2(20);
    
    GUBUN_NULL           EXCEPTION;
BEGIN

    
    IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
        RAISE GUBUN_NULL;
    END IF;    
     
    
--    insert into SFA_SP_CALLED_HIST values ('SP_SFA_COMMON_02_110','1',sysdate,'v_cust_cd'||v_cust_cd||' / v_cust_nm:'||v_cust_nm||'/in_SAWON_ID:'||in_SAWON_ID);
    
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    select classdiv,deptcode into v_assgn_cd,v_deptcode from ORAGMP.CMEMPM  where empcode = in_SAWON_ID;
                
    -- 조회부서:: 로그인 직책에따라 상위부서를 찾거나 본인부서를 찾는다.
    if v_assgn_cd = '27010' or v_assgn_cd = '27020' or v_assgn_cd = '27025' or v_assgn_cd = '27018' or v_assgn_cd = '27026' then   --본부장관리이사,, 총괄지점장 부본부장 선임지점장
       select deptcode 
         into v_query_deptcode 
         from ORAGMP.CMDEPTM 
        where useyn = 'Y' and level = 2 connect by deptcode = prior predeptcode start with plantcode = '1000' and deptcode = v_deptcode;
                                   
    elsif (v_assgn_cd = '27027' or v_assgn_cd = '27030' or v_assgn_cd = '27035' ) then --팀장,임시팀장 
        v_query_deptcode := v_deptcode;        
    end if;
    
    
    IF in_GUBUN = '1' THEN
       v_cust_cd := in_ITEM; 
    ELSE
       v_cust_nm := in_ITEM;
    END IF;
           
    SELECT count(*) 
      INTO v_num
      FROM ORAGMP.CMCUSTM a
     WHERE a.plantcode = '1000'
       AND a.custdiv   = '2' --매입
       AND a.empcode in (select empcode from ORAGMP.CMEMPM where plantcode = '1000' and deptcode in ( select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode))
       AND a.custcode  LIKE '%'||NVL(v_cust_cd,'%')||'%'
       AND a.custname  LIKE '%'||NVL(v_cust_nm,'%')||'%'
    ;           
                 
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
        
        if v_num > 1000 then           
           out_CODE := 1;
           out_MSG := '검색건수가 1000건이 넘습니다. 거래처명을 2자이상 조건으로 입력해주세요';
           return;
        end if;
         
        OPEN out_RESULT FOR
        SELECT a.custcode                             AS out_CUST_CD    -- 거래처코드
              ,a.custname                             AS out_CUST_NM    -- 거래처명
              ,a.addr1||' '||a.addr2                  AS out_ADDRESS    -- 거래처 주소
              ,a.ceoname                              AS out_MANAGER_NM -- 대표자 명                
              ,oragmp.fngetturncnt(a.custcode,to_char(sysdate,'yyyy-mm'))  AS out_RATE_DAY    -- 회전일  
              ,a.empcode                              AS out_EMP_NO     -- 담당사원 ID
              ,oragmp.fncommonnm ('emp',a.empcode,'') AS out_EMP_NM      -- 담당사원명
          FROM ORAGMP.CMCUSTM a
         WHERE a.plantcode = '1000'
           AND a.custdiv   = '2' --매입
           AND a.empcode in (select empcode from ORAGMP.CMEMPM where plantcode = '1000' and deptcode in ( select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode))
           AND a.custcode  LIKE '%'||NVL(v_cust_cd,'%')||'%'
           AND a.custname  LIKE '%'||NVL(v_cust_nm,'%')||'%'
         ORDER BY a.custname
        ; 
    
    END IF;
    
EXCEPTION
WHEN GUBUN_NULL THEN
   out_CODE := 101;
   out_MSG  := '검색 구분코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
