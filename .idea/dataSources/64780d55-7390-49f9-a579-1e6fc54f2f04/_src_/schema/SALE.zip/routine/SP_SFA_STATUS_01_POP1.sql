CREATE PROCEDURE      SP_SFA_STATUS_01_POP1   
(
    in_SAWON_ID          IN  VARCHAR2,     -- 사번
    in_DT_FR             IN  VARCHAR2,     -- 기준일자 FROM
    in_DT_TO             IN  VARCHAR2,     -- 기준일자 TO   
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처별 주문 수금 내역
 호출프로그램 : 현황/실적현황에서 사원명이 리스트될때 사원을 클릭하면 해당사원의
                해당기간에 대한 거래처별 주문,수금내역이 나온다.      
 이 화면은 영업기획부의 요청이아닌 영업담당자의 요청으로 만들려고 하였으나   영업기획부에서 오픈하지 말라고 해서 만들다가 일단 중단한 화면임 20140.01.03 김태안
 ---------------------------------------------------------------------------*/    

    v_num         NUMBER;
    v_SILSAWON_ID VARCHAR2(7);
    v_date_fr     DATE;
    v_date_to     DATE; 
    
BEGIN


     --insert into SFA_SP_CALLED_HIST values ('SP_SFA_STATUS_01_POP1','1',sysdate,'in_SAWON_ID:'||in_SAWON_ID||' /v_date_fr:'||v_date_fr||' /v_date_to:'||v_date_to||' /cnt:'||to_char(v_num));
          
        v_date_fr := to_date(in_DT_FR,'yyyymmdd');
        v_date_to := to_date(in_DT_TO,'yyyymmdd');

     SELECT count(*) INTO v_num
       FROM (
            SELECT SUM(A.TOT1)
              FROM (SELECT 1                             AS SEQ,
                           A.RCUST_ID                    AS CUST_ID,
                           (NVL(B.AMT,0) + NVL(B.VAT,0)) AS TOT1,
                           0                             AS TOT2
                      FROM SALE.SALE0207 A, 
                           SALE.SALE0208 B, 
                           SALE.SALE0004 D,
                           SALE.SALE0203 E
                     WHERE A.DEAL_NO = B.DEAL_NO
                       AND A.YMD     = B.YMD
                       AND B.ITEM_ID = D.ITEM_ID
                       AND A.YMD BETWEEN v_date_fr AND v_date_to
                       AND A.GUMAE_NO = E.GUMAE_NO(+)
                    UNION ALL /*  수금(할인) 내역 */
                    SELECT 2                             AS SEQ,
                           A.RCUST_ID                    AS CUST_ID,
                           0                             AS TOT1,
                           NVL(-(CASH_AMT),0)            AS TOT2
                      FROM SALE.SALE0401  A
                     WHERE A.YMD         BETWEEN v_date_fr AND v_date_to
                       AND A.CASH_AMT      <> 0
                    UNION ALL
                    SELECT 2                             AS SEQ,
                           A.RCUST_ID                    AS CUST_ID ,
                           0                             AS TOT1,
                           NVL(-(AMT),0)                 AS TOT2
                      FROM SALE.SALE0402  B,
                           SALE.SALE0401  A,
                           (SELECT CODE1, CODE1_NM FROM  SALE.SALE0001 WHERE CODE_GB = '0007') C
                     WHERE A.YMD         BETWEEN v_date_fr AND v_date_to
                       AND A.JUNPYO_NO   = B.JUNPYO_NO
                       AND B.BILL_GB = C.CODE1(+)
                     )  A,
                   (SELECT RCUST_ID                 CUST_ID, 
                           NVL(SUM(BEFORE_AMT),0)   BEFORE_AMT
                      FROM (SELECT RCUST_ID,                   /*전월 잔액 */
                                   BEFORE_AMT      BEFORE_AMT
                              FROM SALE.SALE0306
                             WHERE YMD         = TO_DATE(TO_CHAR(v_date_fr,'YYYY/MM')||'/01','YYYY/MM/DD')
                             UNION ALL
                            SELECT RCUST_ID,                  /*금월의 조회조건 기간까지의 잔액*/
                                   NVL(A.AMT,0) + NVL(A.VAT,0)  
                                   BEFORE_AMT
                              FROM SALE.SALE0207  B,
                                   SALE.SALE0208  A
                             WHERE A.DEAL_NO    = B.DEAL_NO
                               AND A.YMD        = B.YMD
                               AND A.YMD        >= TO_DATE(TO_CHAR(v_date_fr,'YYYY/MM')||'/01','YYYY/MM/DD')
                               AND A.YMD        <  v_date_fr
                                 UNION all
                            SELECT RCUST_ID,     
                                   (NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1  
                                   BEFORE_AMT
                              FROM SALE.SALE0401  A
                             WHERE A.YMD        >= TO_DATE(TO_CHAR(v_date_fr,'YYYY/MM')||'/01','YYYY/MM/DD')
                               AND A.YMD        <  v_date_fr)
                     GROUP BY RCUST_ID          )  B,
                  SALE.SALE0003 C
            WHERE C.CUST_ID    = A.CUST_ID(+)
              AND C.CUST_ID    = B.CUST_ID(+)
              AND C.SAWON_ID IN (SELECT SAWON_ID FROM SALE.SALE0007 WHERE SAWON_ID = in_SAWON_ID)
              AND (NVL(A.TOT1,0) <> 0 OR NVL(B.BEFORE_AMT,0) <> 0)
            GROUP BY C.CUST_ID, C.CUST_NM
        );  
 
     --insert into SFA_SP_CALLED_HIST values ('SP_SFA_STATUS_01_POP1','2',sysdate,'in_SAWON_ID:'||in_SAWON_ID||' /v_date_fr:'||v_date_fr||' /v_date_to:'||v_date_to||' /cnt:'||to_char(v_num));
 
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.1111234G';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
    
        OPEN out_RESULT FOR 
        SELECT '1'                      AS out_GUMAE_NO
              ,'20131212'                      AS out_ORDER_DATE
              ,C.CUST_ID               AS out_CUST_NM
              ,C.CUST_NM               AS out_RCUST_NM
              ,'3'                      AS out_ITEM_NM
              ,SUM(A.TOT1)             AS out_QTY
              ,SUM(A.TOT2)             AS out_AMOUNT
          FROM (SELECT 1                             AS SEQ,
                       A.RCUST_ID                    AS CUST_ID,
                       (NVL(B.AMT,0) + NVL(B.VAT,0)) AS TOT1,
                       0                             AS TOT2
                  FROM SALE.SALE0207 A, 
                       SALE.SALE0208 B, 
                       SALE.SALE0004 D,
                       SALE.SALE0203 E
                 WHERE A.DEAL_NO = B.DEAL_NO
                   AND A.YMD     = B.YMD
                   AND B.ITEM_ID = D.ITEM_ID
                   AND A.YMD BETWEEN v_date_fr AND v_date_to
                   AND A.GUMAE_NO = E.GUMAE_NO(+)
                UNION ALL /*  수금(할인) 내역 */
                SELECT 2                             AS SEQ,
                       A.RCUST_ID                    AS CUST_ID,
                       0                             AS TOT1,
                       NVL(-(CASH_AMT),0)            AS TOT2
                  FROM SALE.SALE0401  A
                 WHERE A.YMD         BETWEEN v_date_fr AND v_date_to
                   AND A.CASH_AMT      <> 0
                UNION ALL
                SELECT 2                             AS SEQ,
                       A.RCUST_ID                    AS CUST_ID ,
                       0                             AS TOT1,
                       NVL(-(AMT),0)                 AS TOT2
                  FROM SALE.SALE0402  B,
                       SALE.SALE0401  A,
                       (SELECT CODE1, CODE1_NM FROM  SALE.SALE0001 WHERE CODE_GB = '0007') C
                 WHERE A.YMD         BETWEEN v_date_fr AND v_date_to
                   AND A.JUNPYO_NO   = B.JUNPYO_NO
                   AND B.BILL_GB = C.CODE1(+)
                 )  A,
               (SELECT RCUST_ID                 CUST_ID, 
                       NVL(SUM(BEFORE_AMT),0)   BEFORE_AMT
                  FROM (SELECT RCUST_ID,                   /*전월 잔액 */
                               BEFORE_AMT      BEFORE_AMT
                          FROM SALE.SALE0306
                         WHERE YMD         = TO_DATE(TO_CHAR(v_date_fr,'YYYY/MM')||'/01','YYYY/MM/DD')
                         UNION ALL
                        SELECT RCUST_ID,                  /*금월의 조회조건 기간까지의 잔액*/
                               NVL(A.AMT,0) + NVL(A.VAT,0)  
                               BEFORE_AMT
                          FROM SALE.SALE0207  B,
                               SALE.SALE0208  A
                         WHERE A.DEAL_NO    = B.DEAL_NO
                           AND A.YMD        = B.YMD
                           AND A.YMD        >= TO_DATE(TO_CHAR(v_date_fr,'YYYY/MM')||'/01','YYYY/MM/DD')
                           AND A.YMD        <  v_date_fr
                             UNION all
                        SELECT RCUST_ID,     
                               (NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1  
                               BEFORE_AMT
                          FROM SALE.SALE0401  A
                         WHERE A.YMD        >= TO_DATE(TO_CHAR(v_date_fr,'YYYY/MM')||'/01','YYYY/MM/DD')
                           AND A.YMD        <  v_date_fr)
                 GROUP BY RCUST_ID          )  B,
              SALE.SALE0003 C
        WHERE C.CUST_ID    = A.CUST_ID(+)
          AND C.CUST_ID    = B.CUST_ID(+)
          AND C.SAWON_ID IN (SELECT SAWON_ID FROM SALE.SALE0007 WHERE SAWON_ID = in_SAWON_ID)
          AND (NVL(A.TOT1,0) <> 0 OR NVL(B.BEFORE_AMT,0) <> 0)
        GROUP BY C.CUST_ID, C.CUST_NM
        ORDER BY C.CUST_ID
        ;
       
    insert into SFA_SP_CALLED_HIST values ('SP_SFA_STATUS_01_POP1','3',sysdate,'in_SAWON_ID:'||in_SAWON_ID||' /v_date_fr:'||v_date_fr||' /v_date_to:'||v_date_to||' /cnt:'||to_char(v_num));
    
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
