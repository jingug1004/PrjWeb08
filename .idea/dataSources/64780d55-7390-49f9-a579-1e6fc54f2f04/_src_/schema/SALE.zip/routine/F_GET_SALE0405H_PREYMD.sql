CREATE function      F_GET_SALE0405H_PREYMD
        ( A_CUST_ID      VARCHAR2, -- 직납처
          A_RCUST_ID     VARCHAR2, -- 간납처
          A_ITEM_ID      VARCHAR2, -- 제품코드
          A_APPL_DATE    VARCHAR2  --적용일자
        )
   RETURN VARCHAR2
AS
   ERROR_1       exception  ;  
   ERROR_2       exception  ;  
   
   v_ymd         VARCHAR2(8);
   
BEGIN
     
    /*
     이력 적용일자를 넣으면 바로 전이력의 시행종료일자를 RETURN  
    */
    BEGIN
        SELECT /*+ index_desc(A SALE0405H_PK) */
               to_char(a.ymd,'yyyymmdd')
          into v_ymd     
          FROM SALE0405H A
         WHERE CUST_ID     = A_CUST_ID
           AND RCUST_ID    = A_RCUST_ID
           AND ITEM_ID     = A_ITEM_ID                   
           AND APPL_DATE   < A_APPL_DATE
           AND ROWNUM = 1;
    
    EXCEPTION  
         WHEN NO_DATA_FOUND THEN
            RAISE ERROR_1; 
         WHEN OTHERS THEN
            RAISE ERROR_2; 
    END; 
    
    RETURN v_ymd;
    
            
EXCEPTION  
     WHEN ERROR_1 THEN
          RETURN '0';   
     WHEN ERROR_2 THEN
          RAISE_APPLICATION_ERROR(-20002, substrb(A_CUST_ID||'-'||A_RCUST_ID||'-'||A_ITEM_ID||'-'||SQLERRM,1,250));
END;
/
