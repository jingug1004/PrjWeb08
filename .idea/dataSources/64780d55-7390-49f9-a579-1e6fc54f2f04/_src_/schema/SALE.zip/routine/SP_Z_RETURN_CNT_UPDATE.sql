CREATE PROCEDURE      SP_Z_RETURN_CNT_UPDATE 
(
    in_PROCESS      IN  VARCHAR2,   
    in_SAWON_ID     IN  VARCHAR2,   
    in_CDT_FR     IN  VARCHAR2,   
    in_CUST_ID      IN  VARCHAR2, 
    in_RCUST_ID     IN  VARCHAR2,
    in_ITEM_CD     IN  VARCHAR2,   
    in_PRODNO       IN  VARCHAR2,
    in_QTY          IN  NUMBER , 
    in_BARCODEQTY  IN  NUMBER, 
    in_REASON_CODE      IN  VARCHAR2,
    out_CODE        out NUMBER,
    out_MSG         out VARCHAR2
)
IS
    v_num                NUMBER;
BEGIN
     SELECT COUNT(*)
      INTO v_num
     FROM sfa_banpum_reason 
     where 
            CUST_ID = in_CUST_ID
        and RCUST_ID = in_RCUST_ID
        and ITEM_ID = in_ITEM_CD
        and PROD_NO = in_PRODNO
        and YMD = in_CDT_FR;
    IF v_num = 0 THEN -- 신규등록
        out_CODE := 1;
        out_MSG := '처라할 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '요청하신 작업이 수정되었습니다.';      
        update sfa_banpum_reason set 
                                        BANPUM_QTY          = in_QTY ,
                                        BANPUM_REASON       = in_REASON_CODE ,
                                        AMT                 = in_QTY
                                  where 
                                            CUST_ID = in_CUST_ID
                                        and RCUST_ID = in_RCUST_ID
                                        and ITEM_ID = in_ITEM_CD
                                        and PROD_NO = in_PRODNO
                                        and YMD = in_CDT_FR;
        commit;                              
    END IF;
      
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
