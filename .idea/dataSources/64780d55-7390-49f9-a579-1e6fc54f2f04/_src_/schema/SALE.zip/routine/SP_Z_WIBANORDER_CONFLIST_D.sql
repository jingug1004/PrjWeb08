CREATE PROCEDURE      SP_Z_WIBANORDER_CONFLIST_D   
(
    in_GUMAE_NO          IN  VARCHAR2,    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 회전일위반 주문 승인용 주문상세 조회
 호출프로그램 : 일일방문화면에서 내역이 있을때 팝업에서 호출된다.  
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼     
 ---------------------------------------------------------------------------*/    

    v_num         NUMBER; 
    v_month3_qty  NUMBER;  --3개월평균수량
    
BEGIN
 
    SELECT COUNT(*)
      INTO v_num 
      from oragmp.slordm a
          ,oragmp.slordd b
     where a.orderno = b.orderno
       and a.orderno = in_GUMAE_NO
      ;                         
        
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDER_LIST','1',sysdate,'in_GUMAE_NO'||in_GUMAE_NO||'/in_CUST_ID'||in_CUST_ID||' / v_num:'||to_char(v_num));
--COMMIT
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';     
 

        OPEN out_RESULT FOR        
         select a.orderno                                  AS out_GUMAE_NO
               ,replace(a.orderdate,'-','')                AS out_ORDER_DATE
               ,oragmp.fncommonnm('cust',a.custcode,'')    AS out_CUST_NM
               ,''                                         AS out_WIBAN_KIND             
               ,oragmp.fncommonnm('item',b.itemcode,'')    AS out_ITEM_NM
               ,b.salqty                                   AS out_QTY
               ,F_Z_ITEM_AVERAGE_SALE (a.custcode, a.ecustcode,a.orderdate, b.itemcode)  AS out_MONTH3_QTY -- 3개월평균수량
               ,''                                         AS out_RATE_DAY              
           from oragmp.slordm a
               ,oragmp.slordd b
          where a.orderno = b.orderno
            and a.orderno = in_GUMAE_NO
          ;                         
       
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
