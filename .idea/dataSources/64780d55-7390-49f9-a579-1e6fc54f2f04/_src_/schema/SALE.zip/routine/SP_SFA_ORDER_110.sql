CREATE PROCEDURE      SP_SFA_ORDER_110
 (in_FLAG               IN VARCHAR2 DEFAULT NULL,
  in_YMD                IN date,
  in_GUMAE_NO           IN VARCHAR2 default NULL,
  in_SAWON_ID           IN VARCHAR2 default NULL,
  in_CUST_ID            IN VARCHAR2 default NULL,
  in_RSAWON_ID          IN VARCHAR2 default NULL,
  in_RCUST_ID           IN VARCHAR2 default NULL,
  in_AMT_SUM            IN VARCHAR2 default NULL,
  in_VAT_SUM            IN VARCHAR2 default NULL,
  in_BIGO               IN VARCHAR2 default NULL,
  in_COUNT              IN NUMBER,
  in_DATASET            IN VARCHAR2 default NULL,
  out_CODE              OUT NUMBER,
  out_MSG               OUT VARCHAR2       )
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문등록(주문마스터와 주문상세를 모두 이곳에서 처리)
 호출프로그램 : 주문서등록의 등록버튼,       
 수정기록     :
 1.20130130/ 김태안/ 주문프로세서 재정리에 따라 로직 수정함(윤홍주차장요청)
   <개요>신규처도 수량체크,회전일180초과시주문불가,월평균판매량,월평균판매금액적용.
  
   -SFA 주문등록 화면에서 회전일이 180일을 넘는 거래처는 주문불가 하도록 처리함.
   -신규처 개월수 = 0 일때 해당월판매량이 20개이상이면 return
           개월수 <>0 일때 해당월판매량20개이상이면 월평균판매량의1.5배이상일때 return
                           해당월판매량20개이하이면 월평균판매량의1.5배이상일때 월평균판매금액의1.5배이상일때 return
   -기존처->해당월판매량20개이상이면 월평균판매량의1.5배이상일때 return
            해당월판매량20개이하이면 월평균판매량의1.5배이상일때 월평균판매금액의1.5배이상일때 return
2.20130304/김태안/거래처회전일을 위한 에이징이 전달로 생성이 안되어있으면 주문불가            
3.2014.04.03. :  123 버전으로 대체                 
 ---------------------------------------------------------------------------*/

    --주문마스터에서 사용할 변수
    is_ITEM_ID VARCHAR2(10);
    is_QTY     NUMBER;
    
    ll_count   NUMBER;   
    ll_max number;
    
    b_yn boolean;

    V_gumae_no VARCHAR2(14);

    is_check_yn VARCHAR2(20);
    is_gicho_yul VARCHAR2(20);
    is_gicho_tot VARCHAR2(20)   ;

    dec_yul VARCHAR2(20);
    ldec_tot VARCHAR2(20);
    is_yeondae_2 VARCHAR2(20);
    is_yeondae_3 VARCHAR2(20)   ;

    is_dambo VARCHAR(20)  ;

    is_BUDONG_YN VARCHAR(20)  ;
    is_USE_YN    VARCHAR(20)  ;
    is_EMAIL     VARCHAR(30)  ;
    is_ROOM_CNT  VARCHAR(30)  ;

    V_YEOSIN           NUMBER;
    V_CREDIT_LIMIT_AMT NUMBER;

    --주문상세에서 사용할 변수    
    ll_loop      number := 0;
    ll_months    number := 0;   --개시개월수
    ll_mqty      number := 0;   --이달의주문수량계
    ll_avgqty    number := 0;   --평균주문수량(3개월)
    ll_mamt      number := 0;   --이달의주문금액계
    ll_avgamt    number := 0;   --평균주문금액(3개월)
    ll_limit     number := 0;   --주문한도    
    
    N_COUNT      NUMBER := 0;
    N_GAYOUNG_JAEGO      NUMBER := 0; --가용재고
    N_CHANGGO_JAEGO      NUMBER := 0; --창고재고 
    v_ITEM_NM    VARCHAR2(200);
    v_use_yn     VARCHAR2(1);
    v_chul_yn    VARCHAR2(1);

    V_ITEM_DANGA NUMBER := 0;
    V_PSB_QTY    NUMBER := 0;
    V_M_QTY      NUMBER := 0;   
    
    v_ITEM_ID   VARCHAR2(10);
    v_QTY       VARCHAR2(12);
    v_DANGA     VARCHAR2(13);
    v_AMT       VARCHAR2(13);
    v_VAT       VARCHAR2(13);   
    
    v_saupjang_cd VARCHAR2(3);
    v_cnt             NUMBER;
    v_cnt_101         NUMBER;
    v_cnt_102         NUMBER;
    v_cnt_103         NUMBER;
    v_amt_sumadd      NUMBER;
   
    --수정시에 안넘어오므로 
    v_CUST_ID    VARCHAR2(10); 
    v_RCUST_ID    VARCHAR2(10); 
 
 
    v_date_first DATE;
    v_date_last DATE;
    
    --에러처리    
    ERROR_RAISE EXCEPTION;
    
BEGIN

    /*CHOE 20130627 주문일자 노트의 날짜를 따라간다. SYSTEM 날짜 변경 버젼 1.1.8 에서 적용하기 전까지 날짜가 다르면 저장하지 않는다.*/
    IF TO_CHAR(in_YMD, 'YYYYMMDD') <> TO_CHAR(SYSDATE, 'YYYYMMDD') THEN
            out_MSG := '주문일자가 다릅니다. 확인 후 다시 주문등록해 주시기 바랍니다.';
            RAISE ERROR_RAISE;    
    END IF; 

    v_date_first := to_date(to_char(in_YMD,'yyyymm')||'01','yyyymmdd');
    v_date_last  := last_day(to_date(to_char(in_YMD,'yyyymm')||'01','yyyymmdd'));

    /*
    v_cnt := 0;
    SELECT 1  
      INTO v_cnt 
      FROM DUAL 
     WHERE EXISTS (SELECT 'X' FROM EIJING A WHERE A.YM_F    = to_char(add_months(sysdate,-1),'yyyymm') AND ROWNUM = 1);
    if v_cnt = 0 then
      out_CODE := -1; 
      out_MSG  := '전달 회전일집계(에이징)가 없습니다. 관리부에 문의하십시오.';
      RETURN;      
    end if;  
    */
       
    ----------------------------------------------------------------------------
    --주문마스터 시작
    ----------------------------------------------------------------------------
--            INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','1000',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--            COMMIT;
    
    IF in_FLAG = 'I' THEN
        
        --수정시기존주문삭제 -------------------------------------------------------
        --주문번호가 있으면 주문수정을 한 것이므로  기존주문내역 삭제
        --숭인된것은 주문수정 불가로 client에서 넘어오지 않음.        
        
           
        --주문수정시는 안넘어오므로    
        v_CUST_ID := in_CUST_ID;
        v_RCUST_ID := in_RCUST_ID; 

        if in_GUMAE_NO IS NOT NULL then 

--            INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','1001',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--            COMMIT;
            
           --주문수정시는 안넘어 오므로 기존 구매번호로 찾는다.
           SELECT CUST_ID,RCUST_ID
             INTO v_CUST_ID,v_RCUST_ID
             FROM SALE_ON.SALE0203
            WHERE GUMAE_NO = in_GUMAE_NO;


            --주문상세삭제 --삭제된주문에 대한 모든  제품의 수량을 SALE0305 의 에 반영시킨다.
            DECLARE CURSOR Cur_1 IS    
             SELECT ITEM_ID,QTY    
               FROM SALE_ON.SALE0204
              WHERE GUMAE_NO = in_GUMAE_NO;
            BEGIN               
                FOR cur IN Cur_1 LOOP 
                    is_ITEM_ID  := cur.ITEM_ID;
                    is_QTY      := cur.QTY;
                     
                    --온라인주문용출고수량에 빼준다
                    BEGIN
                        UPDATE sale.sale0305
                           SET chulgo_qtyst = nvl(chulgo_qtyst,0) - is_QTY
                         WHERE ymd       = to_date(to_char(sysdate, 'yyyymm')||'01','yyyymmdd')
                           AND store_loc = '01' 
                           AND item_id   = is_ITEM_ID;        
                    EXCEPTION 
                         WHEN OTHERS THEN                  
                              out_CODE := SQLCODE; 
                              out_MSG  :='온라인주문용출고수량에 반영 에러=>'||'(제품:'||is_ITEM_ID||')'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                              ROLLBACK;
                              RETURN;
                    END;
                    
                END LOOP ;        
               
            END;           

            
            --3.주문상세삭제 
            BEGIN
                DELETE SALE_ON.SALE0204
                 WHERE gumae_no = in_GUMAE_NO;
            EXCEPTION
                 WHEN OTHERS THEN
                     out_CODE := SQLCODE; 
                     out_MSG  :='주문상세삭제 에러=>'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);  
                     ROLLBACK;    
                     RETURN;    
            END;
            
            
            --4.주문마스터삭제 
            BEGIN
                DELETE SALE_ON.SALE0203
                 WHERE gumae_no = in_GUMAE_NO;
            EXCEPTION
                 WHEN OTHERS THEN
                     out_CODE := SQLCODE; 
                     out_MSG  :='주문마스터삭제 에러=>'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);   
                     ROLLBACK;    
                     RETURN;           
            END; 

        end if;

                  
        --주문전 체크 -------------------------------------------------------------- 
        
        --잔고 확인 최근 2년간 
        /* --로직 없어짐: 20130128 윤홍주 
        b_yn := false;

        select count(*) as cnt
        into ll_count
        from sale.sale0402i
        where ymd > add_months(sysdate, -24)
        and cust_id = v_CUST_ID and rcust_id = v_CUST_ID;

        if ll_count = 0 then
          out_CODE := 101;
          out_MSG := '<잔고가 없습니다.관련 부서로 문의 바랍니다>';         
          RAISE ERROR_RAISE; --- (-20000,'<2개월간 잔고 확인이 없습니다.>');
        end if;
        */
        
--            INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','1002',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--            COMMIT;
            
        --거래처 확인  --order check BUDONG  출하중치처 확인
        SELECT BUDONG_YN, USE_YN, EMAIL, ROOM_CNT
        into    is_BUDONG_YN ,is_USE_YN, is_EMAIL, is_ROOM_CNT
        FROM SALE0003 WHERE CUST_ID = v_CUST_ID  ;
        if is_BUDONG_YN = 'Y' then
          out_CODE := 1032;
          out_MSG := '출하중치처입니다. 관련 부서로 문의 바랍니다';
          RAISE ERROR_RAISE; --- raise_application_error (-20000,'<출하중지처 이므로 관련 부서로 문의 바랍니다>');
        end if;

        if is_USE_YN != 'Y' then
          out_CODE := 103;
          out_MSG := '사용중지처 이므로 관련 부서로 문의 바랍니다';
          RAISE ERROR_RAISE; ---raise_application_error (-20000,'<사용중지처 이므로 관련 부서로 문의 바랍니다>');
        end if;

        if is_EMAIL IS NULL then
          out_CODE := 104;
           out_MSG := '거래처의 이메일이 없습니다. 관련 부서로 문의 바랍니다';
          RAISE ERROR_RAISE; ---raise_application_error (-20000,'<이메일정보가 없습니다. 관련 부서로 문의 바랍니다>');
        end if;

        if is_ROOM_CNT IS NULL then
           out_CODE := 105;
           out_MSG := '거래처의 요양기관번호가 없습니다. 관련 부서로 문의 바랍니다';
          RAISE ERROR_RAISE; ---raise_application_error (-20000,'<요양기관번호가 없습니다. 관련 부서로 문의 바랍니다>');
        end if;


        --간넙처 확인  --order check BUDONG  출하중치처 확인
        SELECT BUDONG_YN, USE_YN, EMAIL, ROOM_CNT
        into    is_BUDONG_YN ,is_USE_YN, is_EMAIL, is_ROOM_CNT
        FROM SALE0003 WHERE CUST_ID = v_RCUST_ID  ;
        if is_BUDONG_YN = 'Y' then
          out_CODE := 106;
          out_MSG := '출하중치처입니다. 관련 부서로 문의 바랍니다';
          RAISE ERROR_RAISE; --- raise_application_error (-20000,'<출하중지처 이므로 관련 부서로 문의 바랍니다>');
        end if; 

        out_CODE := 0;
        out_MSG := '거래처 확인 완료';
      

--            INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','1003',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--            COMMIT;

        --여신한도 체크
        --주문저장시 거래처 총여신 <= 거래처정보의 여신한도금액 이면 통과
        --쿼리값이 1이면 '여신초과되었습니다. 관리부에 문의하세요!''메세지를 보여준다.
        --여신한도 채크로직 수정:2013.09.02 KTA --여신한도는 사업자번호로 체크한다. 동일거래처가 코드가 1개이상 있을수 있어서...
        ll_count := 0;
        SELECT COUNT(DISTINCT VOU_NO) INTO ll_count FROM SALE0003 WHERE cust_id = v_CUST_ID;
        IF ll_count > 1 THEN
           out_CODE := 101;
           out_MSG := '이 거래처가 사업자번호가 1개이상 존재합니다. 관련부서로 문의 바랍니다.';
           RAISE ERROR_RAISE;
        END IF;
        
        SELECT NVL(MAX(CREDIT_LIMIT_AMT),0)
          INTO V_CREDIT_LIMIT_AMT
          FROM SALE0003
         WHERE VOU_NO = (SELECT VOU_NO FROM SALE0003 WHERE cust_id = v_CUST_ID);
                 
        SELECT NVL(F.BEFORE_AMT,0) + NVL(F.MISU_AMT,0) - NVL(F.SU_AMT,0) + NVL(L.BILL_010_AMT,0) + NVL(L.BILL_020_AMT,0) + NVL(L.BILL_030_AMT,0) + NVL(L.BILL_100_AMT,0) + NVL(L.BILL_900_AMT,0) + NVL(G.GMISU_AMT, 0) YEOSIN
          INTO V_YEOSIN 
          FROM SALE.SALE0003 A,
             ( SELECT CUST_ID ,
                      SUM(BEFORE_AMT)  BEFORE_AMT,
                      SUM(MISU_AMT)    MISU_AMT,
                      SUM(SU_AMT)      SU_AMT
                 FROM SALE.SALE0306
                WHERE YMD        = TO_DATE(TO_CHAR(in_YMD,'YYYY/MM')||'/01','YYYY/MM/DD')
                  AND CUST_ID    = v_CUST_ID
                GROUP BY CUST_ID
             ) F,
             (
               SELECT X.CUST_ID        CUST_ID ,
                      NVL(SUM(DECODE(Y.BILL_GB,'010',Y.AMT)),0)  BILL_010_AMT,
                      NVL(SUM(DECODE(Y.BILL_GB,'020',Y.AMT)),0)  BILL_020_AMT,
                      NVL(SUM(DECODE(Y.BILL_GB,'025',Y.AMT)),0)  BILL_025_AMT,
                      NVL(SUM(DECODE(Y.BILL_GB,'030',Y.AMT)),0)  BILL_030_AMT,
                      NVL(SUM(DECODE(Y.BILL_GB,'035',Y.AMT)),0)  BILL_035_AMT,
                      NVL(SUM(DECODE(Y.BILL_GB,'040',Y.AMT)),0)  BILL_040_AMT,
                      NVL(SUM(DECODE(Y.BILL_GB,'100',Y.AMT)),0)  BILL_100_AMT,
                      NVL(SUM(DECODE(Y.BILL_GB,'900',Y.AMT)),0)  BILL_900_AMT
                 FROM SALE.SALE0401 X ,
                      SALE.SALE0402 Y
                WHERE X.YMD       = Y.YMD
                  AND X.JUNPYO_NO = Y.JUNPYO_NO
                  AND Y.END_YMD  >= SYSDATE
                GROUP BY X.CUST_ID
               ) L,
               (
                 SELECT CUST_ID,
                        SUM(AMT_SUM + VAT_SUM) GMISU_AMT
                   FROM SALE_ON.SALE0203
                  WHERE RECEIPT_GB = '1'
                    AND CUST_ID    = v_CUST_ID
                  GROUP BY CUST_ID
               ) G
        WHERE A.CUST_ID    = v_CUST_ID
          AND A.CUST_ID    = F.CUST_ID(+)
          AND A.CUST_ID    = L.CUST_ID(+)
          AND A.CUST_ID    = G.CUST_ID(+) ;

        IF (V_CREDIT_LIMIT_AMT <> 0) AND ((V_YEOSIN + TO_NUMBER(in_AMT_SUM) + TO_NUMBER(in_VAT_SUM)) > V_CREDIT_LIMIT_AMT ) THEN
            out_MSG := '여신초과되었습니다. 관리부에 문의하세요!';
            RAISE ERROR_RAISE; 
        END IF;

        out_CODE := 0;
        out_MSG := '완료';  --CHOE 20130624 SFA에서 완료 저장 완료 MSG를 받으면 주문 초기화 되도록 설정

--            INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','1004',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--            COMMIT;

        --order check 1
        --여신규정코드중 사용어부,확보율,총여신 가져온다.
        DECLARE CURSOR cur_order_check IS
            SELECT MAX(A.CHECK_YN) CHECK_YN,  --사용여부
                   MAX(A.YUL)      GICHO_YUL,--확보율
                   MAX(A.TOT)      GICHO_TOT          --총여신
              FROM(SELECT DECODE(CODE1,'01',BIGO) CHECK_YN,
                          DECODE(CODE1,'02',BIGO) YUL,
                          DECODE(CODE1,'03',BIGO) TOT
                     FROM SALE0001
                    WHERE CODE_GB = '4001' --여신규정
                  ) A  ;
        BEGIN
          FOR cur IN cur_order_check LOOP
              is_check_yn := cur.CHECK_YN;
              is_gicho_yul := cur.GICHO_YUL;
              is_gicho_tot := cur.GICHO_TOT;

          END LOOP ; 
        end;

        --order check2
        --거래처에 대한 금액정보를 가져온다.
        DECLARE CURSOR cur_order_check IS
            SELECT
                    ROUND((NVL(H.SALE_DAMBO_AMT,0)/
                    DECODE(((NVL(F.BEFORE_AMT,0) + NVL(F.MISU_AMT,0) -
                    NVL(F.SU_AMT,0))+(NVL(L.BILL_010_AMT,0) + NVL(L.BILL_020_AMT,0) +
                    NVL(L.BILL_030_AMT,0) +  NVL(L.BILL_100_AMT,0) +
                    NVL(L.BILL_900_AMT,0))),0,1,((NVL(F.BEFORE_AMT,0) +
                    NVL(F.MISU_AMT,0) -  NVL(F.SU_AMT,0))+(NVL(L.BILL_010_AMT,0) +
                    NVL(L.BILL_020_AMT,0) +  NVL(L.BILL_030_AMT,0) +
                    NVL(L.BILL_100_AMT,0) + NVL(L.BILL_900_AMT,0))))*100),2) YUL,
                    NVL(F.BEFORE_AMT,0) + NVL(F.MISU_AMT,0) - NVL(F.SU_AMT,0) +
                    NVL(L.BILL_010_AMT,0) + NVL(L.BILL_020_AMT,0) +
                    NVL(L.BILL_030_AMT,0) +  NVL(L.BILL_100_AMT,0) +
                    NVL(L.BILL_900_AMT,0) TOT,
                    A.YEONDAE_2                  YEONDAE_2,
                    A.YEONDAE_3                  YEONDAE_3
              FROM SALE0003 A,
                    ( SELECT CUST_ID ,
                             SUM(BEFORE_AMT)  BEFORE_AMT,
                             SUM(MISU_AMT)    MISU_AMT,
                             SUM(SU_AMT)      SU_AMT
                        FROM SALE0306
                       WHERE YMD  = TO_DATE(TO_CHAR( to_date(in_YMD,'YYYY/MM/DD'),'YYYY/MM')||'/01','YYYY/MM/DD')
                         AND CUST_ID    = v_CUST_ID
                       GROUP BY CUST_ID  ) F,
                    ( SELECT X.CUST_ID, NVL(SUM(X.SALE_DAMBO_AMT),0) SALE_DAMBO_AMT
                        FROM SALE0404 X
                       WHERE X.CUST_ID    = v_CUST_ID
                         AND NVL(X.CHULGO_YMD,TO_DATE('2999/01/01','YYYY/MM/DD')) = TO_DATE('2999/01/01','YYYY/MM/DD')
                       GROUP BY X.CUST_ID ) H,
                    ( SELECT X.CUST_ID        CUST_ID ,
                             NVL(SUM(DECODE(Y.BILL_GB,'010',Y.AMT)),0)  BILL_010_AMT,
                             NVL(SUM(DECODE(Y.BILL_GB,'020',Y.AMT)),0)  BILL_020_AMT,
                             NVL(SUM(DECODE(Y.BILL_GB,'030',Y.AMT)),0)  BILL_030_AMT,
                             NVL(SUM(DECODE(Y.BILL_GB,'100',Y.AMT)),0)  BILL_100_AMT,
                             NVL(SUM(DECODE(Y.BILL_GB,'900',Y.AMT)),0)  BILL_900_AMT
                        FROM SALE0401 X ,  SALE0402 Y
                       WHERE X.YMD       = Y.YMD
                         AND X.JUNPYO_NO = Y.JUNPYO_NO
                         AND Y.END_YMD  >= SYSDATE
                       GROUP BY X.CUST_ID ) L
             WHERE A.CUST_ID    = v_CUST_ID
               AND A.CUST_ID    = F.CUST_ID(+)
               AND A.CUST_ID    = H.CUST_ID(+)
               AND A.CUST_ID    = L.CUST_ID(+);

        BEGIN
            FOR cur IN cur_order_check LOOP
              dec_yul := cur.YUL;
              ldec_tot := cur.TOT;
              is_yeondae_2 := cur.YEONDAE_2;
              is_yeondae_3 := cur.YEONDAE_3;

            END LOOP ;
        end;
        
--            INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','1005',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--            COMMIT;

        if is_check_yn = 'Y' then
            if substr(v_CUST_ID,0,2) = '11' then
                if is_yeondae_2 = 'Y' then
                    DECLARE CURSOR cur_order_check IS
                    SELECT NVL(BIGO,'0')     DAMBO   --담보
                     FROM SALE0001
                    WHERE CODE_GB = '4001' AND CODE1   = '04';

                    BEGIN
                      FOR cur IN cur_order_check LOOP
                          is_dambo := cur.DAMBO;
                      END LOOP ;
                    END;

              end if;

              if ( (ldec_tot > (is_gicho_tot + is_dambo))  and  (dec_yul < is_gicho_yul) ) then
                  out_CODE := 106;
                  RAISE ERROR_RAISE; ---raise_application_error (-20000,'<통제 여신 규정을 위반 하였습니다.>');
              end if;

            end if;
        end if;
        --체크완료 
        
        

        --신규인경우 SEQ 주문 번호 가져오기
        if in_GUMAE_NO IS NULL then                 
           sale.SP_SYS100C_MAX_VALUE('SALE0203', TO_CHAR(in_YMD,'YYYYMMDD'), null,null, null, null, ll_max );
           IF SQLCODE <> 0 THEN
              out_CODE := 10610;
              out_MSG := '주문번호 채번오류';
              RAISE ERROR_RAISE;
           END IF;

           V_gumae_no := TO_CHAR(in_YMD,'YYYYMMDD')||TRIM(TO_CHAR(ll_max,'0000')); --주문번호 셋팅            
        end if;

--            INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','1006',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--            COMMIT; 

        --SFA주문테이블에 insert
        BEGIN 
            INSERT INTO SALE_on.SALE0203 (GUMAE_NO, GUMAE_GB, YMD,  SAWON_ID, CUST_ID, RSAWON_ID, RCUST_ID, GYULJAE_GB, TAX_TYPE, DECIMAL_PROC, 
                                          GUBUN, ACCEPT_YN,AMT_SUM, VAT_SUM,INPUT_YMD, INPUT_ID   , slip_gb,RECEIPT_GB,BIGO)
            VALUES (V_gumae_no
                    ,'01'
                    , in_YMD
                    ,in_SAWON_ID
                    ,v_CUST_ID
                    ,in_RSAWON_ID
                    ,v_RCUST_ID
                    ,'01'
                    , '01'
                    ,'03'
                    ,'01'
                    ,'Y'
                    ,TO_NUMBER(in_AMT_SUM)
                    ,TO_NUMBER(in_VAT_SUM)
                    ,sysdate
                    ,in_SAWON_ID
                    ,'2'
                    ,'1'
                    ,'');
                                         
        EXCEPTION 
             WHEN OTHERS THEN  
                  out_CODE := 109;
                  out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                  RAISE ERROR_RAISE;         
        END;

    END IF;
   
--            INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','1007',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--            COMMIT;  
   
    --------------------------------------------------------------------------
    --주문상세 시작
    --------------------------------------------------------------------------
    v_cnt_101 := 0;
    v_cnt_102 := 0;
    v_cnt_103 := 0;    
    v_amt_sumadd := 0;
        
    IF in_FLAG = 'I' THEN    
       
       -- 사업장이 석여있는 제품이 들어오면 허용불가..
       --client 에서 제조사업장이 다른 제품이 들어오는것은 막았는데 아직 업그레이드 하지 않아서...
        FOR ll_loop IN 1.. in_COUNT LOOP 

            v_ITEM_ID  := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 1 +61*(ll_loop -1),  10)); --v_ITEM_ID
            v_QTY      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 11+61*(ll_loop -1),  12)); --v_QTY
            v_DANGA    := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 23+61*(ll_loop -1),  13)); --v_DANGA
            v_AMT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 36+61*(ll_loop -1),  13)); --v_AMT
            v_VAT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 49+61*(ll_loop -1),  13)); --v_VAT
            
            v_saupjang_cd := '';
            SELECT A.SAUPJANG_CD   --사업장코드(101-하길,102-도매,103-도매(향정))
              INTO v_saupjang_cd          
              FROM SALE0004 A 
             WHERE A.ITEM_ID  = v_ITEM_ID;
            
            if v_saupjang_cd = '101' then
               v_cnt_101 := 1;
            elsif v_saupjang_cd = '102' then
               v_cnt_102 := 1;
            elsif v_saupjang_cd = '103' then
               v_cnt_103 := 1;
            end if;
            
            --제품금액누적
            v_amt_sumadd := v_amt_sumadd + v_AMT;

        END LOOP;
        
        if  v_cnt_101 + v_cnt_102 + v_cnt_103 > 1 then
            out_CODE := -20000;
            out_MSG := '동일사업장이 아닌 제품이 섞여 있습니다.주문을 분리하십시오.';
            RAISE ERROR_RAISE;            
        end if;                    
 
        if  TO_NUMBER(in_AMT_SUM)  <> v_amt_sumadd then
            out_CODE := -20000;
            out_MSG := '주문금액과 제품합계금액이 틀립니다.확인하십시오.';
            RAISE ERROR_RAISE;            
        end if;                 
            
        FOR ll_loop IN 1.. in_COUNT LOOP 

            v_ITEM_ID  := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 1 +61*(ll_loop -1),  10)); --v_ITEM_ID
            v_QTY      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 11+61*(ll_loop -1),  12)); --v_QTY
            v_DANGA    := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 23+61*(ll_loop -1),  13)); --v_DANGA
            v_AMT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 36+61*(ll_loop -1),  13)); --v_AMT
            v_VAT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 49+61*(ll_loop -1),  13)); --v_VAT     

--           INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','2002',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--           COMMIT;

            --수량이 0이 아닌 경우만 처리
            if v_QTY is not null or v_QTY <> '' then  

                N_GAYOUNG_JAEGO :=0; 
                select  item_nm, use_yn, chul_yn , OUT_DANGA AS danga
                into v_ITEM_NM,v_use_yn, v_chul_yn, V_ITEM_DANGA
                from  sale.sale0004
                where item_id = v_ITEM_ID;  

                if v_use_yn != 'Y' then
                    out_CODE := -20000;
                    out_MSG := v_ITEM_NM || ' : 사용중지 중입니다.';
                    RAISE ERROR_RAISE;
                end if;

                if v_chul_yn = 'Y' then
                    out_CODE := -20000;
                    out_MSG := v_ITEM_NM || ' : 출하중지 중입니다.';
                    RAISE ERROR_RAISE;
                end if;


                if V_ITEM_DANGA != v_DANGA then
                    out_CODE := -20000;
                    out_MSG := v_ITEM_NM || ' : 제품정보 새로받기를 해주세요 ';
                    RAISE ERROR_RAISE;
                end if;

--           INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','2003',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--           COMMIT;

                select count(*)
                into n_count
                from sale.sale0305 a , sale.sale0004 b
                where a.item_id = b.item_id
                and  ymd= to_char(sysdate, 'YYYYMM')||'01' and a.item_id = v_ITEM_ID
                and store_loc = '01';
                if n_count = 0 then                
                    out_CODE := -20000;
                    out_MSG := v_ITEM_NM || ' '|| v_ITEM_ID || ' 제품 이월처리가 아직 안되어 있습니다.';
                    RAISE ERROR_RAISE;
                end if;
                
                if n_count > 0 then
                    --재고 체크 :
                    --2011.11.19 KTA 창고재고로 체크가 바뀌면서 이것 사용하지 않음::테스트 끝나면 막을것 
                    select NVL(before_qtys,0)+ NVL(IPGO_QTYS,0) - NVL(CHULGO_QTYS,0) - NVL(CHULGO_QTYST,0) + NVL(BANPUM_QTYS,0) + NVL(CONTROL_QTYS,0) as ajego_qtys,
                           b.item_nm
                      into N_GAYOUNG_JAEGO, v_ITEM_NM
                      from sale.sale0305 a , sale.sale0004 b
                     where a.item_id = b.item_id
                       and  ymd= to_char(sysdate, 'YYYYMM')||'01' and a.item_id = v_ITEM_ID
                       and store_loc = '01' ;
                       
                    --창고재고 : 제조번호별 재고의 합계
                    select nvl(sum(  nvl(ipgo_qtys,0) - nvl(chulgo_qtys,0) - nvl(chulgo_qtyst,0) + nvl(banpum_qtys,0) ),0)
                      into N_CHANGGO_JAEGO
                      from sale.sale0305_1 a
                     where a.item_id = v_ITEM_ID
                       and store_loc = '01';
                
                    --KTA 2013.11.19 창고수량이 가용재고보다 크면 가용재고만큼만, 창고수량이 가용수량보다 적으면 창고수량만큼만.
                    if N_CHANGGO_JAEGO >= N_GAYOUNG_JAEGO then
                       --창고수량이 가용재고보다 크면 가용재고만큼만 ::재고관리가 정상적인 상태
                       if N_GAYOUNG_JAEGO <  to_number(v_QTY) then
                            out_CODE := -20000;
                            out_MSG := v_ITEM_NM || ' (' || N_GAYOUNG_JAEGO ||  ') | ' || v_ITEM_ID || ' 재고가 불충분 합니다';
                            RAISE ERROR_RAISE;
                        end if;                     
                       
                    else
                       --창고수량이 가용수량보다 적으면 창고수량만큼만:: 재고관리가 비정상적인 상태
                       if N_CHANGGO_JAEGO <  to_number(v_QTY) then
                            out_CODE := -20000;
                            out_MSG := v_ITEM_NM || ' (' || N_CHANGGO_JAEGO ||  ') | ' || v_ITEM_ID || ' 재고가 불충분 합니다';
                            RAISE ERROR_RAISE;
                        end if;                     
                    
                    end if;   
                          
                end if; 


                --주문수량통제 start ---------------------------------------------------------------------
                BEGIN

                    --주문월-개시월=개시개월수
                    ll_months := 0;
                    SELECT trunc(months_between(to_date(to_char(in_YMD,'yyyymm'),'yyyymm'), to_date(to_char(START_YMD,'yyyymm'),'yyyymm')))  --일자로 하지 않고 1일로 바꿔서 
                      INTO ll_months
                      FROM SALE.SALE0003
                     WHERE CUST_ID = v_CUST_ID;
                           
                   --이달주문수량(이번 주문포함)
                    SELECT sum(QTY1) + sum(QTY2) + v_QTY
                      INTO ll_mqty
                      FROM (--ERP 이달주문수량
                            SELECT NVL(SUM(B.QTY),0) QTY1 , 0 AS QTY2
                              FROM SALE0203 A, SALE0204 B  
                             WHERE A.CUST_ID    = v_CUST_ID
                               AND A.YMD        >= v_date_first
                               AND A.YMD        <= LAST_DAY(TO_DATE(TO_CHAR(in_YMD,'YYYYMM')||'01','YYYYMMDD'))
                               AND A.GUMAE_NO   = B.GUMAE_NO 
                               AND B.ITEM_ID    = v_ITEM_ID
                           UNION
                           --온라인 이달주문수량
                            SELECT 0 AS QTY1 , NVL(SUM(B.QTY),0) QTY2
                              FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B 
                             WHERE A.CUST_ID    = v_CUST_ID
                               AND A.YMD        >= v_date_first
                               AND A.YMD        <= v_date_last
                               AND A.GUMAE_NO   = B.GUMAE_NO
                               AND A.RECEIPT_GB = '1'--접수구분(1.접수, 2.승인, 3.반려) 
                               AND B.ITEM_ID    = v_ITEM_ID
                           );
                             
                    --이달주문금액(이번 주문포함)
                    SELECT sum(AMT1) + sum(AMT2) + v_AMT + v_VAT 
                      INTO ll_mamt
                      FROM (--ERP 이달주문수량
                            SELECT NVL(SUM(B.AMT),0) + NVL(SUM(B.VAT),0) AS AMT1
                                  ,0 AS AMT2
                              FROM SALE0203 A, SALE0204 B  
                             WHERE A.CUST_ID    = v_CUST_ID
                               AND A.YMD        >= v_date_first
                               AND A.YMD        <= v_date_last
                               AND A.GUMAE_NO   = B.GUMAE_NO 
                               AND B.ITEM_ID    = v_ITEM_ID
                           UNION
                           --온라인 이달주문수량
                            SELECT 0 AS AMT1
                                  ,NVL(SUM(B.AMT),0) + NVL(SUM(B.VAT),0) AS AMT2
                              FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B 
                             WHERE A.CUST_ID    = v_CUST_ID
                               AND A.YMD        >= v_date_first
                               AND A.YMD        <= v_date_last
                               AND A.GUMAE_NO   = B.GUMAE_NO
                               AND A.RECEIPT_GB = '1'--접수구분(1.접수, 2.승인, 3.반려) 
                               AND B.ITEM_ID    = v_ITEM_ID
                           );

                           
                    --주문한도율
                    SELECT JUMUN_LIMIT / 100
                      INTO ll_limit
                      FROM SALE.SALE0003 
                     WHERE CUST_ID = v_CUST_ID
                    ; 
                    
                    IF ll_months = 0 THEN      --이달개시거래처 또는 향정제품은 이달수량만 체크

                        IF ll_mqty > 20 THEN  --이달주문수량
                            out_CODE := -20000;
                            out_MSG := v_ITEM_NM || ' (' || v_ITEM_ID || ') 의 이달 주문합계수량이 20개를 초과하였습니다.1';
                            RAISE ERROR_RAISE;
                        END IF;
                        
                    ELSIF ll_months = 1  THEN  --개시개월1달
                    
                        --평균주문수량(1개월)의1.5배,평균주문금액(1개월)의1.5배
                        SELECT ROUND(QTY * ll_limit),ROUND(AMT * ll_limit)
                          INTO ll_avgqty,ll_avgamt
                          FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 1 )) QTY
                                        ,ROUND((NVL(SUM(B.AMT + B.VAT),0) /1 )) AMT
                                    FROM SALE.SALE0203 A, SALE.SALE0204 B 
                                   WHERE A.GUMAE_NO = B.GUMAE_NO
                                     AND A.CUST_ID  = v_CUST_ID 
                                     AND B.ITEM_ID  = v_ITEM_ID 
                                 );
                                 
                        IF ll_avgqty = 0 THEN  --첫주문인 경우
                            IF ll_mqty > 20 THEN  --이달주문수량
                                out_CODE := -20000;
                                out_MSG := v_ITEM_NM || ' (' || v_ITEM_ID || ') 의 이달 주문합계수량이 20개를 초과하였습니다.2';
                                RAISE ERROR_RAISE;
                            END IF;
                             
                        ELSE     
                                                
                            IF ll_mqty > 20 THEN  --이달주문수량
                                IF ll_mqty > ll_avgqty THEN  --이달주문수량이 월평균주문수량(1개월)의1.5배 보다 크면 
                                    out_CODE := -20000;
                                    out_MSG := v_ITEM_NM || ' (' || v_ITEM_ID || ') 의 이달 주문합계수량이 월평균주문수량(1개월)의1.5배인 '|| ll_avgqty ||' 개를 초과하였습니다.';
                                    RAISE ERROR_RAISE;
                                END IF;

                            ELSE
                                IF ll_mqty > ll_avgqty THEN  --이달주문수량이 월평균주문수량(1개월)의1.5배 보다 크면

                                    --평균주문수량(1개월)의1.5배,평균주문금액(1개월)의1.5배
                                    SELECT ROUND(AMT * ll_limit)
                                      INTO ll_avgamt
                                      FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 1 )) QTY
                                                    ,ROUND((NVL(SUM(B.AMT + B.VAT),0) /1 )) AMT
                                                FROM SALE.SALE0203 A, SALE.SALE0204 B 
                                               WHERE A.GUMAE_NO = B.GUMAE_NO
                                                 AND A.CUST_ID  = v_CUST_ID   
                                             );                            

                                    IF ll_mamt > ll_avgamt THEN  --이달주문금액이 월평균주문금액(1개월) 보다 크면 
                                        out_CODE := -20000;
                                        out_MSG := v_ITEM_NM || ' (' || v_ITEM_ID || ') 의 이달 주문합계금액이 월평균주문금액(1개월)의1.5배인 '|| ll_avgamt ||' 원을 초과하였습니다.';
                                        RAISE ERROR_RAISE;
                                    END IF;
                                END IF;
                            
                            END IF; 
                                                   
                        END IF;    
                        
                    ELSIF ll_months = 2  THEN  --개시개월2달
                    
                         
                        --평균주문수량(2개월)의1.5배,평균주문금액(2개월)의1.5배
                        SELECT ROUND(QTY * ll_limit),ROUND(AMT * ll_limit)
                          INTO ll_avgqty,ll_avgamt
                          FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 2 )) QTY
                                        ,ROUND((NVL(SUM(B.AMT + B.VAT),0) / 2 )) AMT
                                    FROM SALE.SALE0203 A, SALE.SALE0204 B 
                                   WHERE A.GUMAE_NO = B.GUMAE_NO
                                     AND A.CUST_ID  = v_CUST_ID 
                                     AND B.ITEM_ID  = v_ITEM_ID 
                                 );
                                 
                        IF ll_avgqty = 0 THEN  --첫주문인 경우
                            IF ll_mqty > 20 THEN  --이달주문수량
                                out_CODE := -20000;
                                out_MSG := v_ITEM_NM || ' (' || v_ITEM_ID || ') 의 이달 주문합계수량이 20개를 초과하였습니다.3';
                                RAISE ERROR_RAISE;
                            END IF; 
                            
                        ELSE     
                                                
                            IF ll_mqty > 20 THEN  --이달주문수량
                                IF ll_mqty > ll_avgqty THEN  --이달주문수량이 월평균주문수량(2개월)의1.5배 보다 크면 
                                    out_CODE := -20000;
                                    out_MSG := v_ITEM_NM || ' (' || v_ITEM_ID || ') 의 이달 주문합계수량이 월평균주문수량(2개월)의1.5배인 '|| ll_avgqty ||' 개를 초과하였습니다.';
                                    RAISE ERROR_RAISE;
                                END IF;
                            
                            ELSE
                                IF ll_mqty > ll_avgqty THEN  --이달주문수량이 월평균주문수량(1개월)의1.5배 보다 크면
                                
                                    --평균주문수량(1개월)의1.5배,평균주문금액(1개월)의1.5배
                                    SELECT ROUND(AMT * ll_limit)
                                      INTO ll_avgamt
                                      FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 2 )) QTY
                                                    ,ROUND((NVL(SUM(B.AMT + B.VAT),0) /2 )) AMT
                                                FROM SALE.SALE0203 A, SALE.SALE0204 B 
                                               WHERE A.GUMAE_NO = B.GUMAE_NO
                                                 AND A.CUST_ID  = v_CUST_ID   
                                             );                            
                            
                                    IF ll_mamt > ll_avgamt THEN  --이달주문금액이 월평균주문금액(2개월) 보다 크면 
                                        out_CODE := -20000;
                                        out_MSG := v_ITEM_NM || ' (' || v_ITEM_ID || ') 의 이달 주문합계금액이 월평균주문금액(2개월)의1.5배인 '|| ll_avgamt ||' 원을 초과하였습니다.';
                                        RAISE ERROR_RAISE;
                                    END IF;
                                END IF;                            
                            END IF;                                  
                        END IF;         

                     
                    ELSE                         --개시개월3달이상
                    
                    
                        --이때는 이 제품의 3개월간의 총수량으로 한다.
                        --평균주문수량(3개월)의1.5배
                        SELECT ROUND(QTY * ll_limit)
                          INTO ll_avgqty
                          FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 3 )) QTY
                                        ,ROUND((NVL(SUM(B.AMT + B.VAT),0) / 3 )) AMT
                                    FROM SALE.SALE0203 A, SALE.SALE0204 B 
                                   WHERE A.GUMAE_NO = B.GUMAE_NO
                                     AND A.YMD      < v_date_first
                                     AND A.YMD      >= ADD_MONTHS(v_date_first ,-3)
                                     AND A.CUST_ID  = v_CUST_ID 
                                     AND B.ITEM_ID  = v_ITEM_ID 
                                 );
                                 
                        --이때는 제품에 관계없이 3개월간의 총수량으로 한다.
                        --평균주문금액(3개월)의1.5배
                        SELECT ROUND(AMT * ll_limit)
                          INTO ll_avgamt
                          FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 3 )) QTY
                                        ,ROUND((NVL(SUM(B.AMT + B.VAT),0) / 3 )) AMT
                                    FROM SALE.SALE0203 A, SALE.SALE0204 B 
                                   WHERE A.GUMAE_NO = B.GUMAE_NO
                                     AND A.YMD      < v_date_first
                                     AND A.YMD      >= ADD_MONTHS(v_date_first ,-3)
                                     AND A.CUST_ID  = v_CUST_ID 
                                     --AND B.ITEM_ID  = v_ITEM_ID   --제품에 관계없이...윤차장과 협의 
                                 );
                                    
                                 
                        IF ll_avgqty = 0 THEN  --첫주문인 경우
                            IF ll_mqty > 20 THEN  --이달주문수량
                                out_CODE := -20000;
                                out_MSG := v_ITEM_NM || ' (' || v_ITEM_ID || ') 의 이달 주문합계수량이 20개를 초과하였습니다.4';
                                RAISE ERROR_RAISE;
                            END IF; 
                            
                        ELSE                 
                            IF ll_mqty > 20 THEN  --이달주문수량
                                IF ll_mqty > ll_avgqty THEN  --이달주문수량이 월평균주문수량(3개월)의1.5배 보다 크면 
                                    out_CODE := -20000;
                                    out_MSG := v_ITEM_NM || ' (' || v_ITEM_ID || ') 의 이달 주문합계수량이 월평균주문수량(3개월)의1.5배인 '|| ll_avgqty ||' 개를 초과하였습니다.';
                                    RAISE ERROR_RAISE;
                                END IF;

                            ELSE
                                IF ll_mqty > ll_avgqty THEN  --이달주문수량이 월평균주문수량(1개월)의1.5배 보다 크면                        
                                    IF ll_mamt > ll_avgamt THEN  --이달주문금액이 월평균주문금액(3개월) 보다 크면 
                                        out_CODE := -20000;
                                        out_MSG := v_ITEM_NM || ' (' || v_ITEM_ID || ') 의 이달 주문합계금액이 월평균주문금액(3개월)의1.5배인 '|| ll_avgamt ||' 원을 초과하였습니다.';
                                        RAISE ERROR_RAISE;
                                    END IF;
                                END IF;

                            END IF;  

                        END IF;  
                                            
                    END IF;  

                END;
                
                --주문수량통제 end ---------------------------------------------------------------------
                
                --INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','2006',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
                --COMMIT;    
                                
                --주문상세 INSERT
                BEGIN
                    INSERT INTO SALE_ON.SALE0204 (YMD, GUMAE_NO, INPUT_SEQ,ITEM_ID, QTY, DANGA,AMT, VAT,BALJU_YN, CHULGO_YN)
                    VALUES (in_YMD, v_GUMAE_NO, LPAD(ll_loop,4,'0'),v_ITEM_ID, v_QTY, v_DANGA,v_AMT, v_VAT,'N', 'N') ;
                EXCEPTION 
                     WHEN OTHERS THEN
                          out_CODE := SQLCODE;
                          out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                          RAISE ERROR_RAISE;
                END; 

--                INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','2007',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--                COMMIT; 

                --재고UPDATE
                BEGIN
                    update sale.sale0305
                       set chulgo_qtyst = nvl(chulgo_qtyst,0) + v_qty
                     where ymd = to_char(sysdate, 'yyyyMM')||'01' 
                       and store_loc = '01' and item_id = v_ITEM_ID;
                EXCEPTION 
                     WHEN OTHERS THEN
                          out_CODE := SQLCODE;
                          out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                          RAISE ERROR_RAISE;
                END; 

            END IF;

        END LOOP ; 
             
        out_CODE  := 0;
        out_MSG := '저장 완료'; --CHOE 20130624 SFA에서 완료 저장 완료 MSG를 받으면 주문 초기화 되도록 설정              
                    
    END IF;  
    
--    INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_110','END-',sysdate,'in_FLAG:'||in_FLAG||'/in_SAWON_ID'||in_SAWON_ID||' / in_YMD:'||to_char(in_YMD,'yyyymmdd')||'/in_CUST_ID:'||in_CUST_ID);
--    COMMIT;



EXCEPTION
     WHEN ERROR_RAISE THEN
          --DBMS_OUTPUT.put_line('ERROR_RAISE out_CODE:'||to_char(out_CODE)||'  out_MSG:'||out_MSG);
          ROLLBACK; 

     WHEN OTHERS THEN
          out_CODE := SQLCODE;
          out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
          --DBMS_OUTPUT.put_line('OTHERS out_CODE:'||to_char(out_CODE)||'  out_MSG:'||out_MSG);

end;

/
