CREATE PROCEDURE      SP_SFA_ORDERCUST_LIST_118 
(
    in_CUST_CD         IN  VARCHAR2,  -- 거래처 코드
    in_CUST_NM           IN  VARCHAR2,  -- 거래처명
    in_SAWON_ID          IN  VARCHAR2,  -- 사원코드    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문거래처 거래처 검색 팝업
 호출프로그램 : 주문서등록
 수정기록     :2014.05.13 KTA - 사용중지거래처는 리스트에 안나오도록 함 
               2015.06.08 KTA - 임시팀장 직책코드 추가관련 수정   
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_insa_sawon_id     VARCHAR2(7);
    v_insa_dept_cd      VARCHAR2(4);
    v_assgn_cd          VARCHAR2(5);
    v_pda_auth          VARCHAR2(1);  --영업시스템권한  A:전체,P-개인,D-부서
    
    GUBUN_NULL           EXCEPTION;
    JUMUN_STOP           EXCEPTION;
    
    v_temp              VARCHAR2(6);
    
BEGIN
 
 --   if in_SAWON_ID = '2012060' then
  
 --      v_temp := to_char(sysdate,'hh24miss');  
 --      if (v_temp > '180000' and  v_temp < '210000') then       
   --        RAISE JUMUN_STOP; 
 --      end if;     
 
--    end if;


    
    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDERCUST_LIST','1',sysdate,'in_CUST_CD'||in_CUST_CD||' / in_CUST_NM:'||in_CUST_NM||'/in_SAWON_ID:'||in_SAWON_ID);

    --로그인사원의 인사사번   
    select pda_auth,insa_sawon_id into v_pda_auth, v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID and gubun = 'Y' ;
    
    --로그인사원이 팀원인지,팀원이아닌 본부장,팀장인지 파악
    select decode(v_pda_auth,'A','27000',assgn_cd) into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
         
   --인사기본테이블에서 총괄팀장 이면 한레벨 상위부서코드를 찾고 팀장이면 자기부서를 찾는다.
    if v_assgn_cd = '27010' or v_assgn_cd = '27020' or v_assgn_cd = '27025' or v_assgn_cd = '27018' or v_assgn_cd = '27026' then --본부장,관리이사,총괄지점장 부본부장 선임지점장
        select dept_cd
          into v_insa_dept_cd  
          from hr_co_depart_0 
         where use_yn = 'Y' and level = 2
       connect by dept_cd = prior up_dept_cd start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id);
                       
    elsif (v_assgn_cd = '27027' or v_assgn_cd = '27030' or v_assgn_cd = '27035') then --팀장,임시팀장 
        select dept_cd into v_insa_dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    end if;    
    
    SELECT COUNT(*)
      INTO v_num      
      FROM (SELECT *
              FROM SFA_SALES_CODE
             WHERE EMP_NO in (  select sawon_id --본부장,총괄팀장,팀장인경우 하위 모든 사원(영업사원테이블)
                                  from sale0007 
                                 where insa_sawon_id in (
                                                        select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                         where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                            connect by prior dept_cd = up_dept_cd
                                                                              start with dept_cd = v_insa_dept_cd)
                                                                                --and ENGAG_DIV in ('70010','70030') --재직,휴직 CHOE20130123
                                                        )
                                 -- and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사) CHOE20130123
                                  union
                                  select sawon_id
                                  from sale0007
                                  where sawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)
                             )
               AND ERP_SALES_CODE LIKE '%'||NVL(in_CUST_CD,'%')||'%'
               AND TRADE_NAME     LIKE '%'||NVL(in_CUST_NM,'%')||'%'
               AND CUST_STAT_GB IN ('01') --주문거래처
               AND v_assgn_cd in ('27010','27020','27025','27027','27030','27035','27018','27026') --본부장,관리이사,총괄지점장,팀장,임시팀장 부본부장 선임지점장
             UNION ALL 
            SELECT *
              FROM SFA_SALES_CODE
             WHERE EMP_NO      IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)                
               AND ERP_SALES_CODE LIKE '%'||NVL(in_CUST_CD,'%')||'%'
               AND TRADE_NAME     LIKE '%'||NVL(in_CUST_NM,'%')||'%'
               AND CUST_STAT_GB IN ('01') --주문거래처
               AND v_assgn_cd in ('27040','27050') --팀원,차석
             UNION ALL 
            SELECT *
              FROM SFA_SALES_CODE
             WHERE ERP_SALES_CODE LIKE '%'||NVL(in_CUST_CD,'%')||'%'
               AND TRADE_NAME     LIKE '%'||NVL(in_CUST_NM,'%')||'%'
               AND CUST_STAT_GB IN ('01') --주문거래처
               AND v_assgn_cd = '27000' --Admin 이면
           ) A , SALE0003 B
         WHERE A.ERP_SALES_CODE = B.CUST_ID(+)
           AND B.USE_YN IN ('Y');
           
    -- insert into SFA_SP_CALLED_HIST values ('SP_SFA_COMMON_021','1',sysdate,'v_num:'||to_char(v_num));
           
                 
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
        
        if v_num > 1000 then           
           out_CODE := 1;
           out_MSG := '검색건수가 1000건이 넘습니다. 거래처명을 2자이상 조건으로 입력해주세요';
           return;
        end if;
         
        OPEN out_RESULT FOR
        SELECT A.ERP_SALES_CODE                         AS out_CUST_CD    -- 거래처코드
              ,DECODE(B.USE_YN,'N',NVL(A.TRADE_NAME,' ')||'-중지됨',NVL(A.TRADE_NAME,' ')) AS out_CUST_NM    -- 거래처명
              ,A.COMPANY_ADDR1||' '||A.BUNJI1           AS out_ADDRESS    -- 거래처 주소
              ,MANAGER_NAME                             AS out_MANAGER_NM -- 대표자 명                
              ,F_RATE_DAY_BEFOREMONTH(to_char(add_months(sysdate,-1),'yyyymm'),A.erp_sales_code) AS out_RATE_DAY -- 회전일  
              ,A.EMP_NO                                 AS out_EMP_NO     -- 담당사원 ID
              ,F_SAWON_NM(A.EMP_NO)                     AS out_EMP_NM      -- 담당사원명
              --,(select code1_nm from sale0001 where code_gb = '0068' and code1 = '01' ) AS out_CONTROL_RATE_DAY --주문제어회전일::거래처별 제어로 변경하면서 막음20130402
              ,(select nvl(z.control_rate_day,'120') from sale0003 z where z.cust_id = a.erp_sales_code) AS out_CONTROL_RATE_DAY --주문제어회전일
              ,TO_CHAR(SYSDATE, 'YYYY.MM.DD') AS out_SERVER_YMD  --CHOE 20130701서버의 날자를 가져가서 주문일자로 사용한다.
          FROM (SELECT *
                  FROM SFA_SALES_CODE
                 WHERE EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                      from sale0007 
                                     where insa_sawon_id in (
                                                            select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                             where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                connect by prior dept_cd = up_dept_cd
                                                                                  start with dept_cd = v_insa_dept_cd)
                                                                                    --and ENGAG_DIV in ('70010','70030') --재직,휴직 CHOE20130123
                                                            )
                                     -- and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사) CHOE20130123
                                      union
                                      select sawon_id
                                      from sale0007
                                      where sawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)
                                 )               
                   AND ERP_SALES_CODE LIKE '%'||NVL(in_CUST_CD,'%')||'%'
                   AND TRADE_NAME     LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND CUST_STAT_GB IN ('01') --주문거래처
                   AND v_assgn_cd in ('27010','27020','27025','27027','27030','27035','27018','27026') --본부장,관리이사,총괄지점장,팀장,임시팀장 부본부장 선임지점장
                 UNION ALL 
                SELECT *
                  FROM SFA_SALES_CODE
                 WHERE EMP_NO      IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) --LIKE  NVL(in_SAWON_ID, '%')               
                   AND ERP_SALES_CODE LIKE '%'||NVL(in_CUST_CD,'%')||'%'
                   AND TRADE_NAME     LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND CUST_STAT_GB IN ('01') --주문거래처
                       AND v_assgn_cd in ('27040','27050') --팀원,차석
                 UNION ALL 
                SELECT *
                  FROM SFA_SALES_CODE
                 WHERE ERP_SALES_CODE LIKE '%'||NVL(in_CUST_CD,'%')||'%'
                   AND TRADE_NAME     LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND CUST_STAT_GB IN ('01') --주문거래처
                   AND ERP_SALES_CODE IS NOT NULL
                   AND v_assgn_cd = '27000' --Admin 이면
               ) A , SALE0003 B
         WHERE A.ERP_SALES_CODE = B.CUST_ID(+)
           AND B.USE_YN IN ('Y')
         ORDER BY TRADE_NAME;
    END IF;
    
EXCEPTION
WHEN GUBUN_NULL THEN
   out_CODE := 101;
   out_MSG  := '검색 구분코드가 누락되었습니다.';
WHEN JUMUN_STOP THEN
   out_CODE := 102;
   out_MSG  := '전산시스템 점검작업으로 2시간동안 주문불가합니다. 공지를 참고하십시요';   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
