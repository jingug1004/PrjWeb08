CREATE PROCEDURE      SP_SFA_COMMON_06
(
    in_GUBUN             IN  NUMBER,    -- 1:코드, 2:이름
    in_ITEM              IN  VARCHAR2,  -- 부서코드/부서명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 부서별 사원검색 팝업
 호출프로그램 : 호출한곳 없음 확인후 지울것        
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
    GUBUN_NULL           EXCEPTION;
BEGIN
    
    IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
        RAISE GUBUN_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM SALE0007   A 
     WHERE A.DEPT_CD  IN (SELECT DEPT_CD FROM SALE0008 WHERE DECODE(in_GUBUN, 1, DEPT_CD, DEPT_NM) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%'));
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT A.SAWON_ID                              AS out_SAWON_ID,   -- 사원 ID
               A.SAWON_NM                              AS out_SAWON_NM    -- 사원명
          FROM SALE0007   A 
         WHERE A.DEPT_CD  IN (SELECT DEPT_CD FROM SALE0008 WHERE DECODE(in_GUBUN, 1, DEPT_CD, DEPT_NM) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%'))
         ORDER BY SAWON_NM;
    END IF;
    
EXCEPTION
WHEN GUBUN_NULL THEN
   out_CODE := 101;
   out_MSG  := '검색 구분코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
