CREATE PROCEDURE      SP_SFA_COLLECT_01_110
(
    in_SAWON_ID      IN  VARCHAR2,   
    in_CDT_FR        IN  VARCHAR2,    
    in_CDT_TO        IN  VARCHAR2,    
    in_GUBUN         IN  VARCHAR2,    
    in_CUSTOMER_CODE IN  VARCHAR2,    
    out_CODE         OUT NUMBER,
    out_MSG          OUT VARCHAR2,
    out_COUNT        OUT NUMBER,
    out_RESULT       OUT TYPES.CURSOR_TYPE
)
IS
/*---------------------------------------------------------------------------
 프로그램명 : 수금현황
 호출프로그램 : 
 수정기록 : 
 - 20130218 kta 영수증재발행 버튼 추가관련 수정. 
 - 20150424 kta 수금사원 기준으로 조회되던것을 실제담당사원기준으로
                       조회되도록 변경 ( 도매 이승원부장이 팀원들과 거래처조정하면서
                       변경된 본인 거래처만 나오도록 요청 한 것임) - 윤홍주차장 확인.
 - 20150721 인수인계 이전 자료를 조회 가능하도록 수정 - 영업사원 김정원         
   2017.11.01 KTA - NEW ERP메 맞게 컨버젼     
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_gubun              VARCHAR2(2);
    GUBUN_NULL           EXCEPTION;     
        
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_01_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SAWON_ID,sysdate
--                                      ,'in_CDT_FR:'||in_CDT_FR||'/in_CDT_TO:'||in_CDT_TO||'/in_GUBUN '||in_GUBUN ||'/in_CUSTOMER_CODE '||in_CUSTOMER_CODE );
--commit;


       IF in_GUBUN = '0' THEN      --전체
            SELECT COUNT(*) 
              INTO v_num
              FROM ORAGMP.SLCOLM a 
             WHERE a.plantcode = '1000'
               AND a.STATEDIV  = '09'  -- 9:수금확정               
               AND a.COLDIV       in ('01','21')  -- 01-현금  21-카드             
               AND a.coldate between  TO_CHAR(TO_DATE(in_CDT_FR,'YYYYMMDD'),'YYYY-MM-DD') AND TO_CHAR(TO_DATE(in_CDT_TO,'YYYYMMDD'),'YYYY-MM-DD')                               
               AND a.custcode   LIKE '%'||NVL(in_CUSTOMER_CODE, '%')||'%'                                 
               AND a.empcode       = in_SAWON_ID;  
  
       ELSIF in_GUBUN = '1' THEN  --현금
            SELECT COUNT(*) 
              INTO v_num
              FROM ORAGMP.SLCOLM a 
             WHERE a.plantcode = '1000'
               AND a.STATEDIV  = '09'  -- 9:수금확정               
               AND a.COLDIV       in ('01')  -- 01-현금  21-카드             
               AND a.coldate between  TO_CHAR(TO_DATE(in_CDT_FR,'YYYYMMDD'),'YYYY-MM-DD') AND TO_CHAR(TO_DATE(in_CDT_TO,'YYYYMMDD'),'YYYY-MM-DD')                               
               AND a.custcode   LIKE '%'||NVL(in_CUSTOMER_CODE, '%')||'%'                                 
               AND a.empcode       = in_SAWON_ID;  
       ELSIF in_GUBUN = '2' THEN  --카드
            SELECT COUNT(*) 
              INTO v_num
              FROM ORAGMP.SLCOLM a 
             WHERE a.plantcode = '1000'
               AND a.STATEDIV  = '09'  -- 9:수금확정               
               AND a.COLDIV       in ('21')  -- 01-현금  21-카드             
               AND a.coldate between  TO_CHAR(TO_DATE(in_CDT_FR,'YYYYMMDD'),'YYYY-MM-DD') AND TO_CHAR(TO_DATE(in_CDT_TO,'YYYYMMDD'),'YYYY-MM-DD')                               
               AND a.custcode   LIKE '%'||NVL(in_CUSTOMER_CODE, '%')||'%'                                 
               AND a.empcode   = in_SAWON_ID;  
       END IF;  
                    
    
        out_COUNT := v_num;
    
        IF v_num = 0 THEN
                out_CODE := 1;
                out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
                out_CODE := 0;
                out_MSG := '검색 완료';    
                
    
                IF in_GUBUN = '0' THEN  --전체
                        OPEN out_RESULT FOR
                            SELECT oragmp.fncommonnm ('CUST',a.custcode,'')  AS out_CUST_ID   --거래처
                                  ,oragmp.fncommonnm ('CUST',a.ecustcode,'')  AS out_RCUST_ID  --수금거래처
                                  ,a.colno                                 AS out_JUNPYO_NO --전표번호
                                  ,decode(a.coldiv,'01',a.colamt,0)        AS out_CASH_AMT  --현금수금액
                                  ,decode(a.coldiv,'21',a.colamt,0)        AS out_CARD_AMT  --카드수금액
                                  ,replace(a.coldate,'-','')               AS out_COLL_DATE  --일자    
                                  ,a.cardcomp                              AS out_CARD_COMP --카드사    
                                  ,a.cardno                                AS out_CARD_NO --카드번호  
                                  ,''                                      AS out_CARD_USE_PERIOD --유효기간 
                                  ,a.cardokno                              AS out_CARD_ACCEPT_NO --승인번호  
                                  ,''                                      AS out_CARD_BILL_GB --거래종류(신용결재승인,신용결재취소)   
                                  ,a.divmonth                              AS out_CARD_ALLOTMENT --할부개월수
                              FROM ORAGMP.SLCOLM a 
                             WHERE a.plantcode = '1000'
                               AND a.statediv  = '09'  -- 9:수금확정               
                               AND a.coldiv       in ('01','21')  -- 01-현금  21-카드             
                               AND a.coldate between  TO_CHAR(TO_DATE(in_CDT_FR,'YYYYMMDD'),'YYYY-MM-DD') AND TO_CHAR(TO_DATE(in_CDT_TO,'YYYYMMDD'),'YYYY-MM-DD')                               
                               AND a.custcode   LIKE '%'||NVL(in_CUSTOMER_CODE, '%')||'%'                                 
                               AND a.empcode       = in_SAWON_ID            
                             ORDER BY a.colno
                             ;                       
             
                ELSIF in_GUBUN = '1' THEN --현금
                        OPEN out_RESULT FOR
                            SELECT oragmp.fncommonnm ('CUST',a.custcode,'')  AS out_CUST_ID   --거래처
                                  ,oragmp.fncommonnm ('CUST',a.ecustcode,'')  AS out_RCUST_ID  --수금거래처
                                  ,a.colno                                 AS out_JUNPYO_NO --전표번호
                                  ,decode(a.coldiv,'01',a.colamt,0)        AS out_CASH_AMT  --현금수금액
                                  ,decode(a.coldiv,'21',a.colamt,0)        AS out_CARD_AMT  --카드수금액
                                  ,replace(a.coldate,'-','')               AS out_COLL_DATE  --일자    
                                  ,a.cardcomp                              AS out_CARD_COMP --카드사    
                                  ,a.cardno                                AS out_CARD_NO --카드번호  
                                  ,''                                      AS out_CARD_USE_PERIOD --유효기간 
                                  ,a.cardokno                              AS out_CARD_ACCEPT_NO --승인번호  
                                  ,''                                      AS out_CARD_BILL_GB --거래종류(신용결재승인,신용결재취소)   
                                  ,a.divmonth                              AS out_CARD_ALLOTMENT --할부개월수
                              FROM ORAGMP.SLCOLM a 
                             WHERE a.plantcode = '1000'
                               AND a.STATEDIV  = '09'  -- 9:수금확정               
                               AND a.COLDIV       in ('01')  -- 01-현금  21-카드             
                               AND a.coldate between  TO_CHAR(TO_DATE(in_CDT_FR,'YYYYMMDD'),'YYYY-MM-DD') AND TO_CHAR(TO_DATE(in_CDT_TO,'YYYYMMDD'),'YYYY-MM-DD')                               
                               AND a.custcode   LIKE '%'||NVL(in_CUSTOMER_CODE, '%')||'%'                                 
                               AND a.empcode       = in_SAWON_ID            
                             ORDER BY a.colno
                             ;            
             
                ELSIF in_GUBUN = '2'THEN --카드     
                        OPEN out_RESULT FOR
                            SELECT oragmp.fncommonnm ('CUST',a.custcode,'')  AS out_CUST_ID   --거래처
                                  ,oragmp.fncommonnm ('CUST',a.ecustcode,'')  AS out_RCUST_ID  --수금거래처
                                  ,a.colno                                 AS out_JUNPYO_NO --전표번호
                                  ,decode(a.coldiv,'01',a.colamt,0)        AS out_CASH_AMT  --현금수금액
                                  ,decode(a.coldiv,'21',a.colamt,0)        AS out_CARD_AMT  --카드수금액
                                  ,replace(a.coldate,'-','')               AS out_COLL_DATE  --일자    
                                  ,a.cardcomp                              AS out_CARD_COMP --카드사    
                                  ,a.cardno                                AS out_CARD_NO --카드번호  
                                  ,''                                      AS out_CARD_USE_PERIOD --유효기간 
                                  ,a.cardokno                              AS out_CARD_ACCEPT_NO --승인번호  
                                  ,''                                      AS out_CARD_BILL_GB --거래종류(신용결재승인,신용결재취소)   
                                  ,a.divmonth                              AS out_CARD_ALLOTMENT --할부개월수
                              FROM ORAGMP.SLCOLM a 
                             WHERE a.plantcode = '1000'
                               AND a.STATEDIV  = '09'  -- 9:수금확정               
                               AND a.COLDIV       in ('21')  -- 01-현금  21-카드             
                               AND a.coldate between  TO_CHAR(TO_DATE(in_CDT_FR,'YYYYMMDD'),'YYYY-MM-DD') AND TO_CHAR(TO_DATE(in_CDT_TO,'YYYYMMDD'),'YYYY-MM-DD')                               
                               AND a.custcode   LIKE '%'||NVL(in_CUSTOMER_CODE, '%')||'%'                                 
                               AND a.empcode       = in_SAWON_ID             
                             ORDER BY a.colno
                             ;
                                
                END IF;
         
        END IF;
    
EXCEPTION
        WHEN GUBUN_NULL THEN
                out_CODE := 101;
                out_MSG := '구분코드가 누락되었습니다.'; 
        WHEN OTHERS THEN
                out_CODE := SQLCODE;
                out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
