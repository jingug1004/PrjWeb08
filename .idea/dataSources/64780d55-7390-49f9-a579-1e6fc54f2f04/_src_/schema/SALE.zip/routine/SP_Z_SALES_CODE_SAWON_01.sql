CREATE PROCEDURE      SP_Z_SALES_CODE_SAWON_01 
(
    in_GUBUN             IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3)
    in_SFA_SALES_SEQ     IN  VARCHAR2,     -- SFA거래처 키컬럼
    in_EMP_NO            IN  VARCHAR2,     -- 요청사번
    in_REQ_GB            IN  VARCHAR2,     -- 요청구분(1-활동거래처요청,2-주문거래처요청)
    in_REQ_DT            IN  VARCHAR2,     -- 요청일자
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 거래처요청 입력,수정,삭제
 호출프로그램 : 거래처요청화면 활동거래처요청 버튼  주문거래처요청 버튼           
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼     
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_cust_stat_gb       VARCHAR2(2);
    
    SFA_SALES_SEQ_NULL  EXCEPTION;
    EMP_NO_NULL         EXCEPTION;
    REQ_GB_NULL         EXCEPTION;
    REQ_INSERT_ERR1     EXCEPTION; 
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_04_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SFA_SALES_SEQ,sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN||'/in_CLIENT_NO '||in_CLIENT_NO );
--commit;

    
    IF in_SFA_SALES_SEQ IS NULL OR TRIM(in_SFA_SALES_SEQ) = '' THEN
        RAISE SFA_SALES_SEQ_NULL;
    END IF;

    IF in_EMP_NO IS NULL OR TRIM(in_EMP_NO) = '' THEN
        RAISE EMP_NO_NULL;
    END IF;
        
    IF in_REQ_GB IS NULL OR TRIM(in_REQ_GB) = '' THEN
        RAISE REQ_GB_NULL;
    END IF;                 
    
    -- 등록
    IF in_GUBUN = 1 THEN           
          
        --활동거래처요청         
        IF in_REQ_GB = '1' THEN 

            -- hira 테이블체크 
            SELECT count(*) INTO v_num FROM oragmp.CMHIRAM WHERE hiracode = in_SFA_SALES_SEQ AND orderempcode is not null;
            IF v_num = 1 THEN 
                out_CODE := 1;
                out_MSG := '이미 주문거래처로 지정된 거래처 입니다. 활동거래처로 요청할 수 없습니다.';
                RETURN;
            END IF;

            -- hira 테이블체크 
            SELECT count(*) INTO v_num FROM oragmp.CMHIRAM WHERE hiracode = in_SFA_SALES_SEQ AND orderempcode is not null;
            IF v_num = 1 THEN 
                out_CODE := 1;
                out_MSG := '이미 활동거래처로 지정된 거래처 입니다. 활동거래처로 요청할 수 없습니다. 활동거래처는 한사람씩만 지정됩니다.';
                RETURN;
            END IF;

            -- 요청  테이블체크 
            SELECT count(*) INTO v_num FROM SALE.SFA_HIRA_CODE_SAWON WHERE hiracode = in_SFA_SALES_SEQ AND req_gb = '1' AND ok_stat = '2'; --활동,승인
            IF v_num = 1 THEN 
                out_CODE := 1;
                out_MSG := '이미 배정완료된 활동거래처 입니다. 활동거래처는 한사람만 배정됩니다.';
                RETURN;
            END IF;

            -- 요청  테이블체크        
            SELECT count(*) INTO v_num FROM SALE.SFA_HIRA_CODE_SAWON WHERE hiracode = in_SFA_SALES_SEQ AND emp_no   = in_EMP_NO AND req_gb = '1' AND ok_stat = '1'; --활동,대기
            IF v_num = 1 THEN 
                out_CODE := 1;
                out_MSG := '이미 활동거래처 요청하여 승인대기 중 입니다.';
                RETURN;
            END IF;

            -- 요청  테이블체크
            SELECT count(*) INTO v_num FROM SALE.SFA_HIRA_CODE_SAWON WHERE hiracode = in_SFA_SALES_SEQ AND emp_no   = in_EMP_NO AND req_gb = in_REQ_GB AND ok_stat = '3'; --활동,불가
            IF v_num = 1 THEN 
                out_CODE := 1;
                out_MSG := '활동거래처로 요청하였으나 승인불가처리된 거래처 입니다.';
                RETURN;
            END IF;        
            
            BEGIN                
                INSERT INTO SALE.SFA_HIRA_CODE_SAWON(hiracode,emp_no,req_gb,req_dt,insertdt,iempcode,updatedt,uempcode)
                VALUES(in_SFA_SALES_SEQ,in_EMP_NO,in_REQ_GB,TO_CHAR(SYSDATE,'YYYYMMDD'),sysdate,in_EMP_NO,sysdate,in_EMP_NO);           
            EXCEPTION 
                 WHEN OTHERS THEN  
                    out_CODE := SQLCODE;
                    out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                    RETURN; 
            END;    
            out_COUNT := 0;
            out_CODE := 0;
            out_MSG := '활동거래처 요청이 완료되었습니다';            
            
        END IF;          
          
       
       --주문거래처요청
       IF in_REQ_GB = '2' THEN    

            -- hira 테이블체크 
            SELECT count(*) INTO v_num FROM oragmp.CMHIRAM WHERE hiracode = in_SFA_SALES_SEQ AND orderempcode is not null;
            IF v_num = 1 THEN 
                out_CODE := 1;
                out_MSG := '이미 주문거래처로 지정된 거래처 입니다. 주문거래처로 요청할 수 없습니다.';
                RETURN;
            END IF;

            -- hira 테이블체크 
            SELECT count(*) INTO v_num FROM oragmp.CMHIRAM WHERE hiracode = in_SFA_SALES_SEQ AND orderempcode = in_EMP_NO;
            IF v_num = 0 THEN 
                out_CODE := 1;
                out_MSG := '주문거래처로 요청하려면 본인의 활동거래처 여야 합니다';
                RETURN;
            END IF;

            -- 요청  테이블체크 
            /* 데이터 이관때문에 이 자료는 없을수 도 있으므로 일단 막음
            SELECT count(*) INTO v_num FROM SALE.SFA_HIRA_CODE_SAWON WHERE hiracode = in_SFA_SALES_SEQ AND emp_no   = in_EMP_NO AND req_gb = '1' AND ok_stat = '2'; --활동,승인
            IF v_num = 0 THEN 
                out_CODE := 1;
                out_MSG := '주문거래처로 요청하려면 본인의 활동거래처로 승인되어 있어야 합니다';
                RETURN;
            END IF;
            */
        

            -- 요청  테이블체크
            SELECT count(*) INTO v_num FROM SALE.SFA_HIRA_CODE_SAWON WHERE hiracode = in_SFA_SALES_SEQ AND emp_no   = in_EMP_NO AND req_gb = in_REQ_GB AND ok_stat = '1'; --주문,대기
            IF v_num = 1 THEN 
                out_CODE := 1;
                out_MSG := '이미 주문거래처 요청하여 승인대기 중 입니다.';
                RETURN;
            END IF;

            -- 요청  테이블체크
            SELECT count(*) INTO v_num FROM SALE.SFA_HIRA_CODE_SAWON WHERE hiracode = in_SFA_SALES_SEQ AND emp_no   = in_EMP_NO AND req_gb = in_REQ_GB AND ok_stat = '2'; --주문,승인
            IF v_num = 1 THEN 
                out_CODE := 1;
                out_MSG := '이미 주문거래처로 요청하여 승인된 거래처 입니다.';
                RETURN;
            END IF;

            -- 요청  테이블체크
            SELECT count(*) INTO v_num FROM SALE.SFA_HIRA_CODE_SAWON WHERE hiracode = in_SFA_SALES_SEQ AND emp_no   = in_EMP_NO AND req_gb = in_REQ_GB AND ok_stat = '3'; --주문,불가
            IF v_num = 1 THEN 
                out_CODE := 1;
                out_MSG := '이미 주문거래처로 요청하였으나 승인불가처리된 거래처 입니다.';
                RETURN;
            END IF;        
            
            BEGIN                
                INSERT INTO SALE.SFA_HIRA_CODE_SAWON(hiracode,emp_no,req_gb,req_dt,insertdt,iempcode,updatedt,uempcode)
                VALUES(in_SFA_SALES_SEQ,in_EMP_NO,in_REQ_GB,TO_CHAR(SYSDATE,'YYYYMMDD'),sysdate,in_EMP_NO,sysdate,in_EMP_NO);                     
            EXCEPTION 
                 WHEN OTHERS THEN  
                    out_CODE := SQLCODE;
                    out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                    RETURN; 
            END;    
            out_COUNT := 0;
            out_CODE := 0;
            out_MSG := '주문거래처 요청이 완료되었습니다';  
        
       END IF; 
        
    END IF;
     
    
EXCEPTION
WHEN SFA_SALES_SEQ_NULL THEN
   out_CODE := 101;
   out_MSG := '거래처키컬럼이 누락되었습니다.';  
WHEN EMP_NO_NULL THEN
   out_CODE := 102;
   out_MSG := '거래처요청사번이 누락되었습니다.';  
WHEN REQ_GB_NULL THEN
   out_CODE := 103;
   out_MSG := '거래처요청구분이 누락되었습니다.';  
WHEN REQ_INSERT_ERR1 THEN
   out_CODE := 104;
   out_MSG := '비활동 거래처를 주문거래처로 요청할 수 없습니다.';   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
