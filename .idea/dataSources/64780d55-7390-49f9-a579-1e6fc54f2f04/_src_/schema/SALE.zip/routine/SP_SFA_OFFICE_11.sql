CREATE PROCEDURE      SP_SFA_OFFICE_11    -- office.Decision : 결재승인 : SALE.SP_SFA_OFFICE_11
(   
    in_SAWON_ID          IN  VARCHAR2, --영업사번
    in_STR_DT            IN  VARCHAR2,
    in_END_DT            IN  VARCHAR2,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
        V_NUM                                         NUMBER; 
        V_SALE0007_INSA_SAWON_ID       VARCHAR2(10); 
        V_TCMUSR_UNO                           VARCHAR2(10); 
        
        SAWON_ID_NULL                          EXCEPTION;
        STR_DT_NULL                              EXCEPTION;
        END_DT_NULL                              EXCEPTION;
        ERROR_EXCEPTION                      EXCEPTION;
    
BEGIN

        /*  0. PARAMETER 확인        */
        IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
                RAISE SAWON_ID_NULL;
        END IF;
    
        IF in_STR_DT IS NULL OR TRIM(in_STR_DT) = '' THEN
                RAISE STR_DT_NULL;
        END IF;
        
        IF in_END_DT IS NULL OR TRIM(in_END_DT) = '' THEN
                RAISE END_DT_NULL;
        END IF;  
        
        
        V_SALE0007_INSA_SAWON_ID := '';     
        V_TCMUSR_UNO := '';   
        /* 1-1. 영업사원번호  -> 인사사원번호 변경 */
        BEGIN
                SELECT INSA_SAWON_ID
                INTO V_SALE0007_INSA_SAWON_ID 
                FROM SALE.SALE0007 
                WHERE SAWON_ID = in_SAWON_ID;
        EXCEPTION WHEN OTHERS THEN
                out_CODE := 1;
                out_MSG := '<인사사원번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END;
        
        IF V_SALE0007_INSA_SAWON_ID = '' THEN
                out_CODE := 1;
                out_MSG := '<인사사원번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END IF;
              
          
        /* 1-2. 인사사원번호 -> 그룹웨어 UNO 변경 */
        BEGIN                
                SELECT UNO 
                INTO V_TCMUSR_UNO 
                FROM HANAGW.TCMUSR 
                WHERE LOIN_USID = V_SALE0007_INSA_SAWON_ID;                
        EXCEPTION WHEN OTHERS THEN
                out_CODE := 1;
                out_MSG := '<그룹웨어번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END;   
        
        IF V_TCMUSR_UNO = '' THEN
                out_CODE := 1;
                out_MSG := '<인사사원번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END IF;         

        /*2. 해당 자료 확인 */
        BEGIN
                SELECT  count(*)
                   INTO V_NUM
                 FROM hanagw.tgwedapv,   
                           hanagw.tgweddoc  
             WHERE ( tgwedapv.docno = tgweddoc.docno )  
                 AND ( ( tgwedapv.apv_uno = V_TCMUSR_UNO )  AND ( tgweddoc.drw_dt >= in_STR_DT )  AND ( tgweddoc.drw_dt <= in_END_DT ) )    
                 AND ( tgweddoc.lst_proc_rslt in ('01','10','11') )  --결재상신, 진행중, 완결 문서만
                 AND ( tgwedapv.apv_knd <> '3') 
                 AND ( tgwedapv.apv_sts in ('01','11') )   --결재상신와 승인완료 경우만
            ORDER BY tgweddoc.docno DESC ; 
        EXCEPTION WHEN OTHERS THEN
                out_CODE := 1;
                out_MSG := '<결재문서를 조회 중에 err가 발생 되었습니다. 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END;  
       
       
    out_COUNT := V_NUM;
    DBMS_OUTPUT.put_line('out_COUNT:'||to_char(out_COUNT));
    
    IF (V_NUM = 0) THEN
        out_CODE := 1;
        out_MSG := '조회할 결재문서가  없습니다.';
    ELSIF (V_NUM >= 1) THEN
        out_CODE := 0;
        out_MSG := '조회할 결재문서 확인완료';    
         
        OPEN out_RESULT FOR
                       
           SELECT  tgweddoc.docno AS out_DOCNO, 
                         tgweddoc.dockndno AS out_DOCKNDNO,                         
                         tgweddoc.titl AS out_D_TITLE,  
                         /*tgweddoc.cont*/tgweddoc.titl||'-contents' AS out_CONT,            
                         to_char(to_date(tgweddoc.drw_dt), 'YYYY.MM.DD') AS out_DRW_DT, 
                         decode(tgweddoc.lst_proc_rslt,'01','결재상신','10','진행중','11','결재완료','22','보류','기타') AS out_LST_PROC_RSLT,
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '1' and apv_seq = 1), '') as out_APV_STS_1,  
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '1' and apv_seq = 2), '') as out_APV_STS_2,  
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '1' and apv_seq = 3), '') as out_APV_STS_3,  
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '1' and apv_seq = 4), '') as out_APV_STS_4,
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '1' and apv_seq = 5), '') as out_APV_STS_5,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '1' and apv_seq = 1), '') as out_APV_UNO_1,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '1' and apv_seq = 2) , '') as out_APV_UNO_2,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '1' and apv_seq = 3), '') as out_APV_UNO_3,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '1' and apv_seq = 4), '') as out_APV_UNO_4,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '1' and apv_seq = 5), '') as out_APV_UNO_5,
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '1' and apv_seq = 6 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('1', tgweddoc.docno)), '') as out_APV_STS_6,  
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '1' and apv_seq = 7 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('1', tgweddoc.docno)), '') as out_APV_STS_7,  
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '1' and apv_seq = 8 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('1', tgweddoc.docno)), '') as out_APV_STS_8,  
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '1' and apv_seq = 9 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('1', tgweddoc.docno)), '') as out_APV_STS_9,
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '1' and apv_seq = 10- hanagw.SF_CM_000_GET_APV_SEQ_MAX('1', tgweddoc.docno)), '') as out_APV_STS_10,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '1' and apv_seq = 6 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('1', tgweddoc.docno)), '') as out_APV_UNO_6,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '1' and apv_seq = 7 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('1', tgweddoc.docno)), '') as out_APV_UNO_7,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '1' and apv_seq = 8 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('1', tgweddoc.docno)), '') as out_APV_UNO_8,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '1' and apv_seq = 9 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('1', tgweddoc.docno)), '') as out_APV_UNO_9,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '1' and apv_seq = 10- hanagw.SF_CM_000_GET_APV_SEQ_MAX('1', tgweddoc.docno)), '') as out_APV_UNO_10,
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '2' and apv_seq = 11 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('2', tgweddoc.docno)), '') as out_APV_STS_11,  
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '2' and apv_seq = 12 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('2', tgweddoc.docno)), '') as out_APV_STS_12,  
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '2' and apv_seq = 13 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('2', tgweddoc.docno)), '') as out_APV_STS_13,  
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '2' and apv_seq = 14 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('2', tgweddoc.docno)), '') as out_APV_STS_14,
                         NVL((select to_char(apv_dtm, 'YYYY.MM.DD HH24:MI:SS') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '2' and apv_seq = 15 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('2', tgweddoc.docno)), '') as out_APV_STS_15,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '2' and apv_seq = 11 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('2', tgweddoc.docno)), '') as out_APV_UNO_11,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '2' and apv_seq = 12 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('2', tgweddoc.docno)), '') as out_APV_UNO_12,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '2' and apv_seq = 13 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('2', tgweddoc.docno)), '') as out_APV_UNO_13,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '2' and apv_seq = 14 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('2', tgweddoc.docno)), '') as out_APV_UNO_14,
                         NVL((select hanagw.SF_CM_004_GET_USRINFO(apv_uno, 'NM') from hanagw.tgwedapv where docno = tgweddoc.docno and apv_knd = '2' and APV_KND_DTL = '2' and apv_seq = 15 - hanagw.SF_CM_000_GET_APV_SEQ_MAX('2', tgweddoc.docno)), '') as out_APV_UNO_15
                          /*'N'   chk,
                         tgweddoc.docno AS out_BOARD_ID,   
                         tgweddoc.dockndno AS out_BOARD_SEQ,   
                         --tgweddoc.doc_cat,   
                         tgweddoc.titl AS out_TITLE,   
                         tgweddoc.carg_uno AS out_DISCRIPTION,   
                         --SF_CM_004_GET_USRINFO(tgweddoc.carg_uno, 'NM')  as carg_usr_nm,   
                         tgweddoc.drw_dt AS out_START_DATE,   
                         --tgweddoc.apv_lim,  
                         tgweddoc.lst_proc_rslt AS out_READ_YN*/
                FROM hanagw.tgwedapv,   
                          hanagw.tgweddoc 
             WHERE ( tgwedapv.docno = tgweddoc.docno )  
                 AND ( ( tgwedapv.apv_uno = V_TCMUSR_UNO ) AND ( tgweddoc.drw_dt >= in_STR_DT )  AND ( tgweddoc.drw_dt <= in_END_DT ) )    
                 AND ( tgweddoc.lst_proc_rslt in ('01','10','11') )              --결재상인, 진행중, 완결 문서만
                 AND ( tgwedapv.apv_knd <> '3') 
                 AND ( tgwedapv.apv_sts in ('01','11') )   --결재상신와 승인완료 경우만
            ORDER BY tgweddoc.docno DESC;
         
    END IF;
         
EXCEPTION
WHEN SAWON_ID_NULL THEN
        out_CODE := 101;
        out_MSG  := '사원코드가 누락되었습니다.';
WHEN STR_DT_NULL THEN
        out_CODE := 101;
        out_MSG  := '조회기간이 잘못되었습니다.';
WHEN END_DT_NULL THEN
        out_CODE := 101;
        out_MSG  := '조회기간이 잘못되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
