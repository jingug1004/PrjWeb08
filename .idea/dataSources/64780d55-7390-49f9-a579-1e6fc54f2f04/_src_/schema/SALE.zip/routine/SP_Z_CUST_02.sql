CREATE PROCEDURE      SP_Z_CUST_02
(
    in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3)
    in_CUST_CD           IN  VARCHAR2,     -- 거래처 코드
    in_CUST_GUBUN        IN  VARCHAR2,     -- 거래처 구분
    in_CUST_NM           IN  VARCHAR2,     -- 거래처 명
    in_TAX_NO            IN  VARCHAR2,     -- 사업자 번호
    in_MANAGER_NM        IN  VARCHAR2,     -- 대표자 명
    in_USE_YN            IN  VARCHAR2,     -- 거래여부
    in_STATUS_NM         IN  VARCHAR2,     -- 업태
    in_VITEM_NM          IN  VARCHAR2,     -- 업종
    in_ZIP_CODE          IN  VARCHAR2,     -- 우편버호
    in_ADDR1             IN  VARCHAR2,     -- 주소
    in_ADDR2             IN  VARCHAR2,     -- 상세주소
    in_EMAIL             IN  VARCHAR2,     -- E-MAIL
    in_HP_NO             IN  VARCHAR2,     -- 핸드폰번호
    in_TEL_NO            IN  VARCHAR2,     -- 전화번호
    in_FAX_NO            IN  VARCHAR2,     -- 팩스번호
    in_LICENSE_NO        IN  VARCHAR2,     -- 면허번호
    in_FLOW              IN  VARCHAR2,     -- 유통구분
    in_PHARM_NO          IN  VARCHAR2,     -- 요양기관
    in_GPS_NUM1          IN  VARCHAR2,     -- SFA_SALES_CODE.GPS_NUM1%TYPE,       -- 위도
    in_GPS_NUM2          IN  VARCHAR2,     -- SFA_SALES_CODE.GPS_NUM2%TYPE,       -- 경도
    in_INPUT_DT          IN  VARCHAR2,     -- 입력일자
    in_INPUT_SAWON       IN  VARCHAR2,     -- 입력자 사번
    in_SAWON_ID          IN  VARCHAR2,     -- 사용자 ID
    in_CLIENT_NO         IN  VARCHAR2,     -- 고객코드
    in_ERP_CD            IN  VARCHAR2,     -- ERP 코드
    in_DEPT_CD           IN  VARCHAR2,     -- 부서코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처관리
 호출프로그램 : 102버전을 대체되었으니 삭제할것.      
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_client_no          NUMBER;
    v_cust_no            NUMBER;
    
    CUST_CD_NULL         EXCEPTION;

BEGIN

    
    IF in_BTN_GUBUN <> 1 AND (in_CUST_CD IS NULL OR TRIM(in_CUST_CD) = '') THEN
        RAISE CUST_CD_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_SALES_CODE
     WHERE SFA_SALES_NO = in_CUST_CD;
         
    IF in_BTN_GUBUN = 1 THEN -- 등록버튼 클릭한 경우
        IF v_num >= 1 THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '기존 등록된 거래처가 있습니다 02';
        ELSE
            -- 필수값 체크 루틴 넣을것.
            
            -- 거래처번호 MAX 생성
            SELECT NVL(MAX(SFA_SALES_NO),0)+1
              INTO v_cust_no
              FROM SFA_SALES_CODE;
            
            -- 고객번호 MAX 생성. 
            SELECT NVL(MAX(SFA_CLIENT_NO),0)+1
              INTO v_client_no
              FROM SFA_COM_CUSTOMER
             WHERE SFA_SALES_SEQ = v_cust_no;
            
            -- 대표자명으로 기본고객을 생성. CLIENT_GUBUN 은 1(대표)로 설정.
            INSERT INTO SFA_SALES_CODE(SFA_SALES_SEQ,  TRADE_NAME,     TAX_NO,          MANAGER_NAME, 
                                       STATUS_NAME,      VITEM_NAME,     ZIP_CODE,        COMPANY_ADDR1, COMPANY_ADDR2,
                                       HP_NO,            TEL_NO,         FAX_NO,          LICENSE_NO, 
                                       PHARMACY_NO,      GPS_NUM1,       GPS_NUM2,        INPUT_DT, 
                                       INPUT_WORKER,  EMP_NO,           ERP_SALES_CODE  )
                                VALUES(v_cust_no,      in_CUST_NM,     in_TAX_NO,       in_MANAGER_NM,
                                       in_STATUS_NM,     in_VITEM_NM,    in_ZIP_CODE,     in_ADDR1,      in_ADDR2,
                                       in_HP_NO,         in_TEL_NO,      in_FAX_NO,       in_LICENSE_NO,
                                       in_PHARM_NO,      TO_NUMBER(in_GPS_NUM1),    TO_NUMBER(in_GPS_NUM2),     TO_CHAR(SYSDATE, 'YYYYMMDD'),
                                       in_INPUT_SAWON,in_SAWON_ID,      in_ERP_CD);
    
            
             -- 대표자명으로 기본고객을 생성. CLIENT_GUBUN 은 1(대표)로 설정.
            INSERT INTO SFA_COM_CUSTOMER(SFA_SALES_SEQ , SFA_CLIENT_NO , CLIENT_NAME , MODIFY_DT , MODIFY_WORKER , CLIENT_GUBUN)
                   VALUES(v_cust_no, v_client_no, in_MANAGER_NM, TO_CHAR(SYSDATE, 'YYYYMMDD'), in_INPUT_SAWON, '1');    
                   
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT SFA_SALES_NO        AS out_CUST_CD
                 , ERP_SALES_CODE      AS out_ERP_CD
                 , ''     AS out_CUST_GUBUN     --SFA_SALES_GUBUN
                 , TRADE_NAME          AS out_CUST_NM
                 , TAX_NO              AS out_TAX_NO
                 , MANAGER_NAME        AS out_MANAGER_NM
                 , ''            AS out_USE_YN      --TRADE_YN
                 , STATUS_NAME         AS out_STATUS_NM
                 , VITEM_NAME          AS out_VITEM_NM
                 , ZIP_CODE            AS out_ZIP_CODE
                 , COMPANY_ADDR1       AS out_ADDR1
                 , COMPANY_ADDR2       AS out_ADDR2 
                 , HP_NO               AS out_HP_NO
                 , TEL_NO              AS out_TEL_NO
                 , FAX_NO              AS out_FAX_NO
                 , LICENSE_NO          AS out_LICENSE_NO
                 , ''                AS out_FLOW        --FLOW
                 , ''  AS out_FLOW_NM       -- F_CODE_ITEM_NM('0020', FLOW)
                 , PHARMACY_NO         AS out_PHARM_NO
                 , TO_CHAR(GPS_NUM1)            AS out_GPS_NUM1
                 , TO_CHAR(GPS_NUM2)            AS out_GPS_NUM2
                 , ''      AS out_CLIENT_NO-- SFA_CLIENT_NO 
                FROM SFA_SALES_CODE  
             WHERE SFA_SALES_NO = v_cust_no;
             
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '거래처 등록이 완료되었습니다 02';
        END IF;
    ELSIF in_BTN_GUBUN = 2 THEN -- 수정버튼 클릭한 경우
        IF v_num < 1 THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '기존 등록된 거래처가 없습니다 02';
        ELSE
            UPDATE SFA_SALES_CODE 
               SET 
               --SFA_SALES_GUBUN     = in_CUST_GUBUN
                  TRADE_NAME          = in_CUST_NM
                 , TAX_NO              = in_TAX_NO
                 , MANAGER_NAME        = in_MANAGER_NM
                -- , TRADE_YN            = in_USE_YN
                 , STATUS_NAME         = in_STATUS_NM
                 , VITEM_NAME          = in_VITEM_NM
                 , ZIP_CODE            = in_ZIP_CODE
                 , COMPANY_ADDR1       = in_ADDR1
                 , COMPANY_ADDR2       = in_ADDR2 
                 , HP_NO               = in_HP_NO
                 , TEL_NO              = in_TEL_NO
                 , FAX_NO              = in_FAX_NO
                 , LICENSE_NO          = in_LICENSE_NO
                 --, ''                = in_FLOW      --FLOW
                 , PHARMACY_NO         = in_PHARM_NO
                 , GPS_NUM1            = TO_NUMBER(in_GPS_NUM1)
                 , GPS_NUM2            = TO_NUMBER(in_GPS_NUM2)
                 --, ''       = in_CLIENT_NO      --SFA_CLIENT_NO
               WHERE SFA_SALES_NO      = in_CUST_CD
                 AND ERP_SALES_CODE    IS NULL;
              
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT SFA_SALES_NO        AS out_CUST_CD
                 , ERP_SALES_CODE      AS out_ERP_CD
                 , ''     AS out_CUST_GUBUN     -- SFA_SALES_GUBUN
                 , TRADE_NAME          AS out_CUST_NM
                 , TAX_NO              AS out_TAX_NO
                 , MANAGER_NAME        AS out_MANAGER_NM
                 , ''            AS out_USE_YN        --TRADE_YN
                 , STATUS_NAME         AS out_STATUS_NM
                 , VITEM_NAME          AS out_VITEM_NM
                 , ZIP_CODE            AS out_ZIP_CODE
                 , COMPANY_ADDR1       AS out_ADDR1
                 , COMPANY_ADDR2       AS out_ADDR2 
                 , HP_NO               AS out_HP_NO
                 , TEL_NO              AS out_TEL_NO
                 , FAX_NO              AS out_FAX_NO
                 , LICENSE_NO          AS out_LICENSE_NO
                 , ''                AS out_FLOW      --FLOW
                 , ''  AS out_FLOW_NM       -- F_CODE_ITEM_NM('0020', FLOW)
                 , PHARMACY_NO         AS out_PHARM_NO
                 , TO_CHAR(GPS_NUM1)            AS out_GPS_NUM1
                 , TO_CHAR(GPS_NUM2)            AS out_GPS_NUM2
                 , ''       AS out_CLIENT_NO    --SFA_CLIENT_NO
                FROM SFA_SALES_CODE  
             WHERE SFA_SALES_NO = in_CUST_CD;
             
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '거래처 수정이 완료되었습니다 02';
        END IF;
    ELSIF in_BTN_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우
        IF v_num < 1 THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '기존 등록된 거래처가 없습니다 02';
        ELSE
            -- 거래처 삭제
         --   UPDATE SFA_SALES_CODE 
         --      SET DEL_DT       = in_INPUT_DT
         --        , DEL_WORKER   = in_INPUT_SAWON
         --        , DEL_YN       = 'Y'
         --    WHERE SFA_SALES_NO = in_CUST_CD
         --      AND ERP_SALES_CODE    IS NULL;
              
           -- 거래처 종속된 고객 삭제
            UPDATE SFA_COM_CUSTOMER
               SET DEL_YN       = 'Y'
             WHERE SFA_SALES_SEQ = in_CUST_CD;

            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT SFA_SALES_NO        AS out_CUST_CD
                 , ERP_SALES_CODE      AS out_ERP_CD
                 , ''     AS out_CUST_GUBUN     -- SFA_SALES_GUBUN
                 , TRADE_NAME          AS out_CUST_NM
                 , TAX_NO              AS out_TAX_NO
                 , MANAGER_NAME        AS out_MANAGER_NM
                 , ''            AS out_USE_YN        --TRADE_YN
                 , STATUS_NAME         AS out_STATUS_NM
                 , VITEM_NAME          AS out_VITEM_NM
                 , ZIP_CODE            AS out_ZIP_CODE
                 , COMPANY_ADDR1       AS out_ADDR1
                 , COMPANY_ADDR2       AS out_ADDR2 
                 , HP_NO               AS out_HP_NO
                 , TEL_NO              AS out_TEL_NO
                 , FAX_NO              AS out_FAX_NO
                 , LICENSE_NO          AS out_LICENSE_NO
                 , ''                AS out_FLOW      --FLOW
                 , ''  AS out_FLOW_NM       -- F_CODE_ITEM_NM('0020', FLOW)
                 , PHARMACY_NO         AS out_PHARM_NO
                 , TO_CHAR(GPS_NUM1)            AS out_GPS_NUM1
                 , TO_CHAR(GPS_NUM2)            AS out_GPS_NUM2
                 , ''       AS out_CLIENT_NO    --SFA_CLIENT_NO
                FROM SFA_SALES_CODE  
             WHERE SFA_SALES_NO = in_CUST_CD;
             
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '거래처 삭제가 완료되었습니다 02';
         END IF;
    ELSE   -- 조회처리
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '거래처 정보가 존재하지 않습니다. 02';
        ELSIF (v_num >= 1) THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '거래처 정보 확인완료 02';    
             
            OPEN out_RESULT FOR
            SELECT SFA_SALES_NO        AS out_CUST_CD
                 , ERP_SALES_CODE      AS out_ERP_CD
                 , ''     AS out_CUST_GUBUN     -- SFA_SALES_GUBUN
                 , TRADE_NAME          AS out_CUST_NM
                 , TAX_NO              AS out_TAX_NO
                 , MANAGER_NAME        AS out_MANAGER_NM
                 , ''            AS out_USE_YN        --TRADE_YN
                 , STATUS_NAME         AS out_STATUS_NM
                 , VITEM_NAME          AS out_VITEM_NM
                 , ZIP_CODE            AS out_ZIP_CODE
                 , COMPANY_ADDR1       AS out_ADDR1
                 , COMPANY_ADDR2       AS out_ADDR2 
                 , HP_NO               AS out_HP_NO
                 , TEL_NO              AS out_TEL_NO
                 , FAX_NO              AS out_FAX_NO
                 , LICENSE_NO          AS out_LICENSE_NO
                 , ''                AS out_FLOW      --FLOW
                 , ''  AS out_FLOW_NM       -- F_CODE_ITEM_NM('0020', FLOW)
                 , PHARMACY_NO         AS out_PHARM_NO
                 , TO_CHAR(GPS_NUM1)            AS out_GPS_NUM1
                 , TO_CHAR(GPS_NUM2)            AS out_GPS_NUM2
                 , ''       AS out_CLIENT_NO    --SFA_CLIENT_NO
                FROM SFA_SALES_CODE  
             WHERE SFA_SALES_NO = in_CUST_CD;
        END IF;
    END IF;
    
EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG := '거래처코드가 누락되었습니다. 02';  
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
