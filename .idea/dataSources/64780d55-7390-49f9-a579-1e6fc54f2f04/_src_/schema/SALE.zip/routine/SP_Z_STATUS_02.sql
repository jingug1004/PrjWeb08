CREATE PROCEDURE      SP_Z_STATUS_02    -- 거래처 여신현황
(
    in_CUST_CD           IN  VARCHAR2,    -- 거래처코드
    in_DT                IN  VARCHAR2,    -- 기간
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 거래처여신현황 
 호출프로그램 : 거래처> 거래처현황      
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼    
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_yyyymm             VARCHAR2(7);
    v_befbalance         NUMBER;----전월 잔고
    v_turncnt            NUMBER;--당월회전일
    v_dscrtamtsum        NUMBER;--담보가치액 합계
    v_dscrtamtsum2       NUMBER;--담보가치액 인정금액
    v_securityexyn       NUMBER;--담보예외
    v_creditlmt          NUMBER;--여신 한도액
    v_maehal             NUMBER;--미정리 매출할인금액
    v_guarantor          VARCHAR2(30); -- 제3자 보증인 
    
    CUST_CD_NULL         EXCEPTION;
    DT_NULL              EXCEPTION;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_04_110',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SFA_SALES_SEQ,sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN||'/in_CLIENT_NO '||in_CLIENT_NO );
--commit; 
    
    IF in_CUST_CD IS NULL THEN
        RAISE CUST_CD_NULL;
    END IF;
    
    IF in_DT IS NULL THEN
        RAISE DT_NULL;
    END IF;
    
    v_yyyymm := SUBSTR(in_DT,1,4)||'-'||SUBSTR(in_DT,5,2);

    -- 전월 잔고 v_befbalance
    SELECT SUM(NVL(balance, 0)) INTO v_befbalance 
      FROM oragmp.SLRESULTM WHERE YEARMONTH = TO_CHAR(ADD_MONTHS(TO_DATE('2017-10', 'YYYY-MM'), -1), 'YYYY-MM') AND CUSTCODE  = in_CUST_CD;
           
    --당월회전일  v_turncnt
    SELECT turndccnt INTO v_turncnt FROM TABLE(oragmp.fnSLcustTURN('1000', '1100293', '%',  '%', SYSDATE, 0));
            
    --담보가치액 합계  v_dscrtamtsum
    SELECT NVL(SUM(scrtamt), 0) INTO v_dscrtamtsum   
      FROM oragmp.CMCUSTSCRTD  
     WHERE custcode = in_CUST_CD AND NVL(returnyn, ' ') <> 'Y' AND expdate >= TO_CHAR(SYSDATE, 'YYYY-MM-DD');
          
    -- 담보예외여부 v_securityexyn    여신 한도액 v_creditlmt
    SELECT securityexyn,NVL(creditlmt,0) creditlmt 
      INTO v_securityexyn,v_creditlmt
      FROM oragmp.CMCUSTM A     
     WHERE a.custcode = in_CUST_CD;
  
    --미정리 매출할인금액  v_maehal
    SELECT SUM((B.SALPRC * B.SALQTY) - (B.SALPRC1 * B.SALQTY)) MAEHAL         -- 주문 입력 시 발행가, 약정가로 계산  발행가 - 약정가 
      INTO v_maehal
      FROM oragmp.SLORDM A
          ,oragmp.SLORDD B
     WHERE A.PLANTCODE = B.PLANTCODE
       AND A.ORDERNO   = B.ORDERNO
       AND A.STATEDIV IN ('09') --매출확정
       AND A.CUSTCODE = in_CUST_CD
       AND NVL(B.MAEHALYN, 'N') = 'N'
       AND B.AFTAMT <> 0
    ; 
     
    --거래처담보내역 - 연대보증인  v_guarantor
    SELECT GUARANTOR  INTO v_guarantor
      FROM oragmp.CMCUSTSCRTD   
     WHERE custcode = in_CUST_CD 
       AND NVL(returnyn, ' ') <> 'Y'  
       AND SCRTDIV = '1' -- 보증구분 1: 연대보증인
       AND expdate >= TO_CHAR(SYSDATE, 'YYYY-MM-DD')     
    ;      
    
    SELECT COUNT(*)
      INTO v_num
      FROM oragmp.SLRESULTM 
     WHERE yearmonth = SUBSTR(v_yyyymm, 0, 7)         
       AND custcode  = in_CUST_CD
    ;
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        select NVL(SUM(balance)    , 0)  AS balance     ,  --현잔고    
               NVL(v_befbalance,     0)  AS befbalance  ,  --전월 잔고
               NVL(SUM(pendbillcol), 0)  AS pendbillcol ,  --미도래어음
               NVL(SUM(PENDBILLCOLJ), 0) AS pendbillcolj,  --자수
               NVL(SUM(PENDBILLCOLT), 0) AS pendbillcolt,  --타수
               NVL(SUM(balance)    , 0) + NVL(SUM(PENDBILLCOLJ), 0) AS totjango    ,  --총잔고
               NVL(v_turncnt  , 0)  AS turncnt    ,  --당월회전일
               NVL(v_dscrtamtsum   , 0)  AS scrtamtsum  ,  --담보가치액 합계
               NVL(v_dscrtamtsum2   , 0)  AS scrtamtsum2  ,  --담보가치액 인정금액
               (CASE WHEN NVL(SUM(balance)    , 0) = 0 THEN 0 ELSE NVL(SUM(balance) ,0) / CASE WHEN NVL(SUM(pendbillcol), 1) = 0 THEN 1 ELSE NVL(SUM(pendbillcol), 1) END * 100 END)  AS scrtamtrate,    --담보확보율
               NVL(SUM(totamt), 0) totamt,                  --당월매출액
               NVL(SUM(totcol), 0) totcol,                   --당월수금액
               CASE WHEN v_securityexyn = 'Y' THEN '담보예외' ELSE oragmp.fnComma(NVL(TO_CHAR(v_creditlmt), '0')) END creditlmt,   --여신 한도액
               NVL(v_maehal, 0) maehal,                     --미정리 매출할인금액
               MAX(empcode),oragmp.fncommonnm('emp',MAX(empcode),'') EMPNAME,
               MAX(deptcode),oragmp.fncommonnm('dept',MAX(deptcode),'') DEPTNAME,
               MAX(eempcode),oragmp.fncommonnm('emp',MAX(eempcode),'') EEMPNAME,
               MAX(edeptcode),oragmp.fncommonnm('dept',MAX(edeptcode),'') EDEPTNAME
          FROM oragmp.SLRESULTM 
         WHERE yearmonth = SUBSTR(v_yyyymm, 0, 7)         
           AND custcode  = in_CUST_CD;
    END IF;
    
EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '거래처 코드가 누락되었습니다.';
WHEN DT_NULL THEN
   out_CODE := 102;
   out_MSG  := '조회 년월이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
