CREATE PROCEDURE      SP_Z_RETURN_UPDATE
(
    in_PROCESS      IN  VARCHAR2,   
    in_EMP_NO       IN  VARCHAR2,
    in_YMD          IN  VARCHAR2,
    in_CUST_ID       IN  VARCHAR2,
    in_RCUST_ID      IN  VARCHAR2,
    in_ITEM_CD      IN  VARCHAR2,
    in_PRODNO       IN  VARCHAR2,
    in_USEDYMD      IN  VARCHAR2,
    in_PRICE        IN  VARCHAR2,
    in_SAWON_ID     IN  VARCHAR2,
    in_RSAWON_ID    IN  VARCHAR2,
    in_ORDER_NO     IN  VARCHAR2,
    out_CODE        out NUMBER,
    out_MSG         out VARCHAR2
)
IS
 /*---------------------------------------------------------------------------
 프로그램명
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN

insert into SFA_SP_CALLED_HIST values ('SP_Z_RETURN_UPDATE',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SAWON_ID,sysdate,'in_SAWON_ID:'||in_ORDER_NO );
commit;

    IF in_PROCESS = '0' THEN -- 신규등록
        SELECT COUNT(*) INTO v_num
        FROM sfa_banpum_reason a
        where a.CUST_SAWON_ID = in_SAWON_ID
            and ITEM_ID = in_ITEM_CD
            and JUMUN_NO = in_ORDER_NO;
    ELSE
         SELECT COUNT(*) INTO v_num
         FROM sfa_banpum_reason a
         where a.CUST_SAWON_ID = in_SAWON_ID
            and CUST_ID = ''
            and RCUST_ID = '';
    END IF;

   
    IF in_PROCESS = '0' THEN -- 신규등록
        IF v_num = 0 THEN -- 기존 데이타 없음
            out_CODE := 0;
            out_MSG := '요청하신 작업이 등록되었습니다.';  
            insert into sfa_banpum_reason(  ymd,cust_id,rcust_id,item_id,prod_no,
                                            USE_YMD_TO,DANGA,CUST_SAWON_ID,RCUST_SAWON_ID, JUMUN_NO,
                                            SEONGIN_STATE, INPUT_DT, CREATE_SAWON_ID ) 
                                    values (replace(in_YMD,'-',''),in_CUST_ID,in_RCUST_ID,in_ITEM_CD,in_PRODNO,
                                            in_USEDYMD,in_PRICE,in_SAWON_ID,in_RSAWON_ID,in_ORDER_NO,
                                            '1', sysdate, in_EMP_NO);
            commit;                                            

        ELSE    -- 업데이트
            out_CODE := 0;
            out_MSG := '요청하신 작업이 수정되었습니다.';      
            update sfa_banpum_reason set 
                                            BANPUM_REASON       = ''
                                      where 
                                                CUST_ID = ''
                                            and RCUST_ID = '';
        END IF;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
