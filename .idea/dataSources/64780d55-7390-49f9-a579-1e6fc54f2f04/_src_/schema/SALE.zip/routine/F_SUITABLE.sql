CREATE FUNCTION      F_SUITABLE  
(
     in_value  IN  VARCHAR2
) 
RETURN VARCHAR2 IS

    v_return_int   VARCHAR2(20);
    
BEGIN
    
        /* ----------------------------------------------------------------------------------------------
        CHOE 20.1211116 기초자료 적합성 확인 FUCTION
        1. 등록된 사원번호의 기초 자료 
        2. 거래처와 SFA거래처 DATA 확인 
        ----------------------------------------------------------------------------------------------*/
        v_return_int :=0;
        --RETURN v_return_int;  -- CHOE 20121116 이 주석만 풀면 사용 안하도록 됨

        /*조건 1번 확인 : 회계, 영업, 묶음 사번 값 없는 경우 */
        SELECT count(*)
            INTO v_return_int
          FROM SALE0007
        WHERE ( ACC_SAWON_ID <> INSA_SAWON_ID  --  회계사번 <> 인사사번
                      OR ACC_SAWON_ID IS NULL                 -- 회계사번 없는 경우
                      OR INSA_SAWON_ID IS NULL                -- 인사사번없는 경우
                      OR SIL_SAWON_ID IS NULL )                --묶음사번 없는 경우                 
            AND GUBUN = 'Y'                                         --재직중인  
        ORDER BY SAWON_NM;
        
        IF v_return_int = 0 THEN
                /*조건 2번 확인 : 묶음 사번 오류*/ 
                SELECT COUNT(*)
                   INTO v_return_int 
                  FROM SALE0007 A 
                ,(
                SELECT SAWON_NM
                            ,SAWON_ID
                            ,GUBUN                
                 FROM SALE0007
                 WHERE GUBUN = 'Y'      
                ORDER BY SAWON_NM
                )B 
                WHERE A.SAWON_NM = B.SAWON_NM 
                    AND B.GUBUN <> A.GUBUN
                    AND A.SIL_SAWON_ID <> B.SAWON_ID;
        END IF;
        
        
        IF v_return_int = 0 THEN
                /*조건 3번 확인 : dpt 번호 등록 오류 */ 
                SELECT COUNT(*)
                   INTO v_return_int 
                  FROM SALE0007
                WHERE GUBUN = 'Y'
                    AND ( SUBSTR(PDA_ID, 1, 5) <> 'DPT0F' 
                             OR LENGTH(PDA_ID) <> 10
                             OR SUBSTR(PDA_ID, 6, 5) IN ( '00000' ,'11111' ,'99999' ) 
                           ) ;
        END IF;
        
        
        IF v_return_int = 0 THEN
                /*조건 4번 확인 : 거래처등록 - sfa거래처 비교*/ 
              SELECT COUNT(*)
                 INTO v_return_int 
               FROM SALE.SFA_SALES_CODE 
             WHERE SFA_SALES_NO IN (
                                                        SELECT SFA_SALES_NO FROM SALE.SFA_SALES_CODE  --93156 건
                                                        MINUS
                                                        SELECT CUST_ID FROM SALE0003  --29023  건      
                                                    );
        END IF;
        
        
        IF v_return_int = 0 THEN
                /*조건 5번 확인 : 거래처 단가등록 sale0402i */ 
              SELECT COUNT(*)
                INTO v_return_int 
              FROM SALE0003 
            WHERE USE_YN = 'Y' 
                AND CUST_ID NOT IN ( SELECT CUST_ID FROM SALE0402I GROUP BY CUST_ID);  --10008 건            
        END IF;
        
        
        RETURN v_return_int;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;

/
