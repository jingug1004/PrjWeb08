CREATE PROCEDURE      SP_SFA_GIS_01_SUB
(
    in_DEPT_CD           IN  VARCHAR2,  -- 부서 코드
    in_SAWON_ID          IN  VARCHAR2,  -- 사원 ID
    in_DT                IN  VARCHAR2,  -- 방문/계획 일자
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 활동경로분석 상세
 호출프로그램 : 웹페이지        
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    DEPT_CD_NULL         EXCEPTION;
    SAWON_ID_NULL        EXCEPTION;
    DT_NULL              EXCEPTION;
BEGIN
    
    IF in_DEPT_CD IS NULL THEN
        RAISE DEPT_CD_NULL;
    END IF;
    
    IF in_SAWON_ID IS NULL THEN
        RAISE SAWON_ID_NULL;
    END IF;
    
    IF in_DT IS NULL THEN
        RAISE DT_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_VISIT_PLANACT  A
         WHERE A.DEPT_NO        = in_DEPT_CD
           AND A.EMP_NO         = in_SAWON_ID
           AND A.SALES_PLAN_NO  = in_DT
         ORDER BY A.SALES_PLAN_NO, A.DETAIL_PLAN_NO; 
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT A.SALES_PLAN_NO                          AS out_SALES_PLAN_NO    -- 방문계획 번호(일자)
             , A.DETAIL_PLAN_NO                         AS out_DETAIL_PLAN_NO   -- 방문계획 번호(상세번호)
             , A.SFA_SALES_SEQ                          AS out_CUST_CD          -- 거래처 코드
             , (select trade_name from sfa_sales_code where sfa_sales_seq = a.sfa_sales_seq)  AS out_CUST_NM          -- 거래처 명
             , A.SFA_CLIENT_NO                          AS out_CLIENT_NO        -- 고객코드
             , (SELECT CLIENT_NAME FROM SFA_COM_CUSTOMER
                 WHERE SFA_SALES_SEQ = A.SFA_SALES_SEQ 
                   AND SFA_CLIENT_NO = A.SFA_CLIENT_NO) AS out_CLIENT_NM        -- 고객명
             , A.EMP_NO                                 AS out_SAWON_ID         -- 사원ID
             , F_SAWON_NM(A.EMP_NO)                     AS out_SAWON_NM         -- 사원명
             , A.EMP_CALL_DTM                           AS out_START_DTM        -- 방문시작시간
             , A.EMP_CALL_DTM                           AS out_END_DTM          -- 방문종료시간
             , TO_CHAR(A.GPS_NUM1)                      AS out_GPS_NUM1         -- 위도
             , TO_CHAR(A.GPS_NUM2)                      AS out_GPS_NUM2         -- 경도
             , A.STATUS                                 AS out_STATUS           -- 상태
             , F_SFA_CODE_NM('STATUS', A.CALL_YN)        AS out_STATUS_NM        -- 상태명
          FROM SFA_VISIT_PLANACT  A
         WHERE A.DEPT_NO        = in_DEPT_CD
           AND A.EMP_NO         = in_SAWON_ID
           AND A.SALES_PLAN_NO  = in_DT
         ORDER BY out_START_DTM, A.SALES_PLAN_NO, A.DETAIL_PLAN_NO; 
    END IF;
    
EXCEPTION
WHEN DEPT_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '부서코드가 누락되었습니다.';
WHEN SAWON_ID_NULL THEN
   out_CODE := 102;
   out_MSG  := '사원ID가 누락되었습니다.';
WHEN DT_NULL THEN
   out_CODE := 103;
   out_MSG  := '검색일자가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
