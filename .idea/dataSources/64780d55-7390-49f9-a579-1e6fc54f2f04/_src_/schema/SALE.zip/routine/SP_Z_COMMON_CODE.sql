CREATE PROCEDURE      SP_Z_COMMON_CODE   
(
    in_CODE_GB           IN  VARCHAR2, 
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
BEGIN 
     
    SELECT count(*)
      INTO v_num
              FROM oragmp.cmcommonm                    
             WHERE usediv = 'Y'     
               AND cmmcode =in_CODE_GB;  
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT cmmcode                   AS out_CODE_GB  
              ,cmmname                   AS out_CODE_GB_NM
              ,divcode                   AS out_CODE1   
              ,divname                   AS out_CODE1_NM  
          FROM ORAGMP.CMCOMMONM                    
         WHERE usediv = 'Y'      
               AND cmmcode =in_CODE_GB  
         ORDER BY 1, 3;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
