CREATE TRIGGER TR_SALE0705_1_B_01
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0705_1
FOR EACH ROW
  declare 가져온레코드수   number ;
        메시지           varchar2(1000) ;
begin
   /* 메시지 처리 준비 */
   if INSERTING then
      메시지 := '품절내역(SALE0705_1_HIST) 추가 불가 !!  ' ;
   elsif UPDATING then
      메시지 := '품절내역(SALE0705_1_HIST) 수정 불가 !!  ' ;
   else
      메시지 := '품절내역(SALE0705_1_HIST) 삭제 불가 !!  ' ;
   end if ;
    
   
   if INSERTING then
      -- ---------------------------------------------------------------------
      -- 내용 : 이력생성
      -- ---------------------------------------------------------------------
      begin
         insert
           into SALE0705_1_HIST ( item_id,hist_dtm, reg_date,due_date,EXPLANATION )
           values (:New.item_id
                  ,to_char(sysdate,'yyyymmddhhmiss')
                  ,:New.reg_date
                  ,:New.due_date
                  ,'신규: '||:New.EXPLANATION
                  );
         exception
              when OTHERS then
                   raise_application_error( -20999, 메시지 || sqlerrm ) ;
      end ;       
   end if ;
    
   
   if UPDATING  then
      -- ---------------------------------------------------------------------
      -- 내용 : 이력생성
      -- ---------------------------------------------------------------------
      begin
         insert
           into SALE0705_1_HIST ( item_id,hist_dtm, reg_date,due_date,EXPLANATION )
           values (:New.item_id
                  ,to_char(sysdate,'yyyymmddhhmiss')
                  ,:New.reg_date
                  ,:New.due_date
                  ,'수정: '||:New.EXPLANATION
                  );
         exception
              when OTHERS then
                   raise_application_error( -20999, 메시지 || sqlerrm ) ;
      end ;       
   end if ;
    
   
   if DELETING  then
      -- ---------------------------------------------------------------------
      -- 내용 : 이력생성
      -- ---------------------------------------------------------------------
      begin
         insert
           into SALE0705_1_HIST ( item_id,hist_dtm, reg_date,due_date,EXPLANATION )
           values (:Old.item_id
                  ,to_char(sysdate,'yyyymmddhhmiss')
                  ,:Old.reg_date
                  ,:Old.due_date
                  ,'삭제: '||:Old.EXPLANATION
                  );
         exception
              when OTHERS then
                   raise_application_error( -20999, 메시지 || sqlerrm ) ;
      end ;       
   end if ;

end ;
/
