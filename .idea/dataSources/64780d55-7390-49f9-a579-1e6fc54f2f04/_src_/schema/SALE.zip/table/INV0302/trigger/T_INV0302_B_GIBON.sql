CREATE TRIGGER T_INV0302_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON INV0302
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : INV0302                                                      */
/*  테이블명 : 입출고전표 Detail                                             */
/*  트리거명 : T_INV0302_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2001.12.10(월)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 일자형, 코드 존재여부 확인                                  */
/*             2. 입출고전표 Master 존재여부 확인                            */
/*             3. 작업일,전표종류,원부자재코드에 따른 일/월계 실적 누적        */
/*  수정내역 : 2001.12.13(목) 출고전표는 공정마다 발행함에 따른 설계 변경 내용 반영 */
/*                            공정관련 칼럼을 입출고전표Detail->Master로 옮김.*/
/*             2002.01.19(토) 불출,수령사원,창고 칼럼을 inv0301로 옮김 */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(100) ;
   v_message    VARCHAR2(250) ;

   user_err     EXCEPTION     ;

   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;
   v_dummy1     VARCHAR2(100) ;
   v_ipchul_gb_old  VARCHAR2(1) ;   -- 1 입고, 2 출고
   v_ipchul_gb_new  VARCHAR2(1) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'INV0302 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'INV0302 수정 불가 !! ' ;
   ELSE
      v_message := 'INV0302 삭제 불가 !! ' ;
   END IF ;

   IF INSERTING OR
      UPDATING('ymd') OR UPDATING('slip_no') OR
      UPDATING('material_id') OR UPDATING('qty') OR UPDATING('danga') OR UPDATING('amt') OR
      UPDATING('junpyogb_cd') OR UPDATING('balju_no') OR
      DELETING THEN
      v_dummy  := ' ';
      v_dummy1 := ' ';
      IF INSERTING OR UPDATING THEN
         v_dummy := SUBSTRB(:NEW.ymd,1,6) ;
      END IF ;
      IF UPDATING OR DELETING THEN
         v_dummy1 := SUBSTRB(:OLD.ymd,1,6) ;
      END IF ;
      SELECT COUNT(*)
        INTO v_count
        FROM INV0401
       WHERE (yyyymm   = v_dummy OR yyyymm   = v_dummy1)
         AND magam_yn = 'Y'
         AND ROWNUM < 3 ;
      IF v_count > 0 THEN
         v_curr_error := '해당월은 전표마감이 완료되었으므로 작업이 불가하니 관리자에게 문의바람.=> '||v_dummy ;
         RAISE user_err ;
      END IF ;
   END IF;

   IF INSERTING OR UPDATING THEN
      IF INSERTING OR
         UPDATING('ymd')         OR UPDATING('slip_no') OR
         UPDATING('junpyogb_cd') OR UPDATING('material_id')OR
         UPDATING('qty')         OR UPDATING('danga')  OR UPDATING('amt') THEN

        v_curr_jakup := '입출고전표Master,:NEW.전표구분코드 확인: ' ;
        SELECT 1, INV0301.junpyogb_cd, INV0001.ipchul_gb
          INTO v_count, :NEW.junpyogb_cd, v_ipchul_gb_new
          FROM INV0301, INV0001
         WHERE INV0301.ymd      = :NEW.ymd
           AND INV0301.slip_no  = :NEW.slip_no
           AND INV0301.junpyogb_cd = INV0001.junpyogb_cd;
         IF v_count != 1 THEN
            v_curr_error := '해당 일자/전표번호가 INV0301에 존재하지 않거나 전표구분코드 값이 없음.=> '
                            ||:NEW.ymd||'/'||:NEW.slip_no ;
           RAISE user_err ;
         END IF ;
      END IF ;

      IF INSERTING OR
         UPDATING('ymd')         OR
         UPDATING('junpyogb_cd') OR UPDATING('material_id')OR
         UPDATING('qty')         OR UPDATING('danga') OR UPDATING('amt') THEN

         :NEW.material_id     := LTRIM(RTRIM(:NEW.material_id));
         :NEW.qty   := NVL(LTRIM(RTRIM(:NEW.qty)), 0) ;
         :NEW.danga := NVL(LTRIM(RTRIM(:NEW.danga)), 0) ;
     --    :NEW.amt   := :NEW.qty * :NEW.danga ;

         v_curr_jakup := '입력값 확인 ';
         IF NVL(:NEW.material_id,' ') = ' ' OR
            :NEW.qty = 0 THEN
            v_curr_error := '원부자재코드와 수량은 반드시 입력해야 함.' ;
            RAISE user_err ;
         END IF ;

         v_curr_jakup := '원부자재코드 확인: ' ;
         SELECT COUNT(*)
           INTO v_count
           FROM INV0003
          WHERE material_id = :NEW.material_id
            AND use_yn      = 'Y'
            AND ROWNUM      < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 원부자재코드는 존재하지 않거나 사용중지된 코드임.=> '||:NEW.material_id ;
            RAISE user_err ;
         END IF ;
      END IF ;
   END IF ;
   /* ******************************************************************** */
   v_curr_jakup := '구매발주Detail(BUY0402) 확인: ' ;
   IF (INSERTING OR
       (UPDATING('balju_no')    AND NVL(:NEW.balju_no,' ') != NVL(:OLD.balju_no,' ')) OR
       (UPDATING('material_id') AND :NEW.material_id       != :OLD.material_id))
      AND :NEW.balju_no > ' ' AND v_ipchul_gb_new = '1' THEN

      SELECT COUNT(balju_no)
        INTO v_count
        FROM BUY0402
       WHERE balju_no    = :NEW.balju_no
         AND material_id = :NEW.material_id
         AND ROWNUM      < 3 ;

      IF v_count = 0 THEN
         v_curr_error := '해당 발주번호/원부자재는 존재하지 않아 작업이 불가함.' ;
         RAISE user_err ;
      END IF ;
   END IF ;

   /* ******************************************************************** */
   IF INSERTING OR
      UPDATING('ymd')         OR
      UPDATING('junpyogb_cd') OR UPDATING('material_id')OR
      UPDATING('qty')         OR UPDATING('danga') OR  UPDATING('amt') OR
      DELETING                                          THEN

      IF UPDATING OR DELETING THEN
         v_curr_jakup := ':OLD.전표구분코드 확인: ' ;

         SELECT 1, ipchul_gb
           INTO v_count, v_ipchul_gb_old
           FROM INV0001
          WHERE junpyogb_cd = :OLD.junpyogb_cd;
         IF v_count != 1 THEN
            v_curr_error := '해당 :OLD.전표코드가 존재하지 않음.=> '||:OLD.junpyogb_cd ;
            RAISE user_err ;
         END IF ;

         v_curr_jakup := '입출고전표-일계 누적 ';
         IF v_ipchul_gb_old = '1' THEN -- 1 입고, 2 출고
            v_curr_jakup := v_curr_jakup||'입고(OLD): ' ;
            UPDATE INV0402
               SET ipgo_qty = ipgo_qty - :OLD.qty,
  --                ipgo_amt = ipgo_amt - (:OLD.qty * :OLD.danga)
                   ipgo_amt = ipgo_amt - :OLD.amt
             WHERE ymd         = :OLD.ymd
               AND material_id = :OLD.material_id ;
         ELSE
            v_curr_jakup := v_curr_jakup||'출고(OLD): ' ;
            UPDATE INV0402
               SET chulgo_qty = chulgo_qty - :OLD.qty
--                   chulgo_amt = chulgo_amt - (:OLD.qty * :OLD.danga)
             WHERE ymd         = :OLD.ymd
               AND material_id = :OLD.material_id ;
         END IF ;
         IF SQL%ROWCOUNT != 1 THEN
            v_curr_error := '누적할 자료가 존재하지 않음.=> '||:OLD.ymd||'/'||:OLD.material_id ;
            RAISE user_err ;
         END IF ;

         v_curr_jakup := '입출고전표-월계 누적 ';
         IF v_ipchul_gb_old = '1' THEN -- 1 입고, 2 출고
            v_curr_jakup := v_curr_jakup||'입고(OLD): ' ;
            UPDATE INV0403
               SET ipgo_qty = ipgo_qty - :OLD.qty,
--                   ipgo_amt = ipgo_amt - (:OLD.qty * :OLD.danga)\
                   ipgo_amt = ipgo_amt - :OLD.amt
             WHERE yyyymm      = SUBSTRB(:OLD.ymd,1,6)
               AND yyyymm      > SUBSTRB(:OLD.ymd,1,4)||'00' -- 이월자료는 '년도00'
               AND material_id = :OLD.material_id ;
         ELSE
            v_curr_jakup := v_curr_jakup||'출고(OLD): ' ;
            UPDATE INV0403
               SET chulgo_qty = chulgo_qty - :OLD.qty
--                   chulgo_amt = chulgo_amt - (:OLD.qty * :OLD.danga)
             WHERE yyyymm      = SUBSTRB(:OLD.ymd,1,6)
               AND yyyymm      > SUBSTRB(:OLD.ymd,1,4)||'00' -- 이월자료는 '년도00'
               AND material_id = :OLD.material_id ;
         END IF ;
         IF SQL%ROWCOUNT != 1 THEN
            v_curr_error := '누적할 자료가 존재하지 않음.=> '||SUBSTRB(:OLD.ymd,1,6)||'/'||:OLD.material_id ;
            RAISE user_err ;
         END IF ;
      END IF ;

      IF INSERTING OR UPDATING THEN
         v_curr_jakup := '입출고전표-일계 누적 ';
         IF v_ipchul_gb_new = '1' THEN -- 1 입고, 2 출고
            v_curr_jakup := v_curr_jakup||'입고(NEW): ' ;
            UPDATE INV0402
               SET ipgo_qty = ipgo_qty + :NEW.qty,
                   ipgo_amt = ipgo_amt + :NEW.amt
--                   ipgo_amt = ipgo_amt + (:NEW.qty * :NEW.danga)
             WHERE ymd         = :NEW.ymd
               AND material_id = :NEW.material_id ;
         ELSE
            v_curr_jakup := v_curr_jakup||'출고(NEW): ' ;
            UPDATE INV0402
               SET chulgo_qty = chulgo_qty + :NEW.qty
--                   chulgo_amt = chulgo_amt + (:NEW.qty * :NEW.danga)
             WHERE ymd         = :NEW.ymd
               AND material_id = :NEW.material_id ;
         END IF ;

         IF SQL%ROWCOUNT = 0 THEN
            INSERT INTO INV0402
                        (ymd, material_id, ipgo_qty, ipgo_amt, chulgo_qty, chulgo_amt, bigo)
                  SELECT :NEW.ymd, :NEW.material_id,
                         NVL(DECODE(v_ipchul_gb_new, '1', :NEW.qty), 0),
--                         NVL(decode(v_ipchul_gb_new, '1', :NEW.qty * :NEW.danga), 0),
                         NVL(DECODE(v_ipchul_gb_new, '1', :NEW.amt), 0),
                         NVL(DECODE(v_ipchul_gb_new, '2', :NEW.qty), 0), 0,
                         DECODE(v_ipchul_gb_new,'1','입고','출고')||'/'||TO_CHAR(SYSDATE,'yyyymmdd')
                    FROM DUAL ;
         END IF ;

         v_curr_jakup := '입출고전표-월계 누적';
         IF v_ipchul_gb_new = '1' THEN -- 1 입고, 2 출고
            v_curr_jakup := v_curr_jakup||'입고(NEW): ' ;
            UPDATE INV0403
               SET ipgo_qty = ipgo_qty + :NEW.qty,
   --                ipgo_amt = ipgo_amt + (:NEW.qty * :NEW.danga)
                   ipgo_amt = ipgo_amt + :NEW.amt
             WHERE yyyymm      = SUBSTRB(:NEW.ymd,1,6)
               AND yyyymm      > SUBSTRB(:NEW.ymd,1,4)||'00' -- 이월자료는 '년도00'
               AND material_id = :NEW.material_id ;
         ELSE
            v_curr_jakup := v_curr_jakup||'출고(NEW): ' ;
            UPDATE INV0403
               SET chulgo_qty = chulgo_qty + :NEW.qty
--                   chulgo_amt = chulgo_amt + (:NEW.qty * :NEW.danga)
             WHERE yyyymm      = SUBSTRB(:NEW.ymd,1,6)
               AND yyyymm      > SUBSTRB(:NEW.ymd,1,4)||'00' -- 이월자료는 '년도00'
               AND material_id = :NEW.material_id ;
         END IF ;
         IF SQL%ROWCOUNT = 0 THEN
            INSERT INTO INV0403
                        (yyyymm, material_id,
                         ipgo_qty, ipgo_amt, chulgo_qty, chulgo_amt, bigo)
                  SELECT SUBSTRB(:NEW.ymd,1,6), :NEW.material_id,
                         NVL(DECODE(v_ipchul_gb_new, '1', :NEW.qty), 0),
        --                 NVL(decode(v_ipchul_gb_new, '1', :NEW.qty * :NEW.danga), 0),
                         NVL(DECODE(v_ipchul_gb_new, '1', :NEW.amt), 0),
                         NVL(DECODE(v_ipchul_gb_new, '2', :NEW.qty), 0), 0,
                         DECODE(v_ipchul_gb_new,'1','입고','출고')||'/'||TO_CHAR(SYSDATE,'yyyymmdd')
                    FROM DUAL ;
         END IF ;
      END IF ;
   END IF ;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
