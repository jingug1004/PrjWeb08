CREATE TRIGGER T_INV0302_B_GIBON_AUDIT
BEFORE INSERT OR UPDATE OR DELETE
  ON INV0302
FOR EACH ROW
  DECLARE
   v_count           NUMBER ;
   v_message         VARCHAR2(255) := '작업불가' ;
   v_table_nm        VARCHAR2(10) ;
   v_dml_ymdhms      VARCHAR2(14) ; /*작업일시*/
   v_dml_gb          VARCHAR2(3) ;  /*작업구분-INSERT,UPDATE,DELETE*/
   v_oldnew_gb       VARCHAR2(3) ;  /*값 구분-OLD, NEW*/

   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(100) ;

   user_err     EXCEPTION     ;

   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;
   v_dummy1     VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message   := 'INV0302 추가 불가 !! ' ;
      v_dml_gb    := 'INS' ;
      v_oldnew_gb := 'NEW' ;
   ELSIF UPDATING THEN
      v_message   := 'INV0302 수정 불가 !! ' ;
      v_dml_gb    := 'UPD' ;
      v_oldnew_gb := 'NEW' ;
   ELSE
      v_message   := 'INV0302 삭제 불가 !! ' ;
      v_dml_gb    := 'DEL' ;
      v_oldnew_gb := 'OLD' ;
   END IF ;

   /* ************************************************ */
   /* 신규 입력되거나 수정, 삭제될때 : 감사 처리 작업  */
   /* ************************************************ */
   v_curr_jakup := '작업시간 ' ;
   v_table_nm := 'INV0302' ;
   SELECT TO_CHAR(SYSDATE, 'yyyymmddhh24miss')
     INTO v_dml_ymdhms
     FROM dual ;
   -- ##### 임시로 3월11일 까지 작업분만 Audit Table에 추가함.
   IF v_dml_ymdhms > '20020311999999' THEN
      GOTO the_end ;
   END IF ;

   IF INSERTING OR
      (UPDATING('ymd')         AND :NEW.ymd         != :OLD.ymd) OR
      (UPDATING('junpyogb_cd') AND :NEW.junpyogb_cd != :OLD.junpyogb_cd) OR
      (UPDATING('material_id') AND :NEW.material_id != :OLD.material_id) OR
      (UPDATING('qty')         AND :NEW.qty         != :OLD.qty) OR
      (UPDATING('danga')       AND :NEW.danga       != :OLD.danga) OR
      (UPDATING('amt')         AND :NEW.amt         != :OLD.amt) OR
      DELETING THEN
      v_dummy  := ' ';
      v_dummy1 := ' ';
      IF INSERTING OR UPDATING THEN
         v_dummy := SUBSTRB(:NEW.ymd,1,6) ;
      END IF ;
      IF UPDATING OR DELETING THEN
         v_dummy1 := SUBSTRB(:OLD.ymd,1,6) ;
      END IF ;
/* ##### 월마감 전 입력/수정/삭제 데이타는 Audit Table에 저장하지 말까 ???????????
      v_curr_jakup := '월마감여부확인 ' ;
      select count(*)
        into v_count
        from INV0401
       where (yyyymm   = v_dummy OR yyyymm   = v_dummy1)
         and magam_yn = 'Y'
         and rownum < 3 ;
      IF v_count = 0 THEN
         goto the_end ;
      END IF ;
*/
      v_oldnew_gb  := 'NEW' ;
      v_curr_jakup := '감사자료추가: ' ||v_dml_gb||'/'||v_oldnew_gb||' ' ;
      IF INSERTING OR UPDATING THEN
         INSERT INTO INV_AUDIT_D (TABLE_NM, DML_YMDHMS, DML_GB, OLDNEW_GB,
                                TABLE_PK_NEW, TABLE_PK_OLD,
                                VAR_1, VAR_2, VAR_3, VAR_4, VAR_5,
                                NUM_1, NUM_2, NUM_3, NUM_4, NUM_5,
                                USERNAME, MACHINE, TERMINAL, PROGRAM, BIGO)
         SELECT v_table_nm, v_dml_ymdhms, v_dml_gb, v_oldnew_gb,
                :NEW.ymd||' '||:NEW.slip_no||' '||:NEW.seq,
                DECODE(v_dml_gb,'UPD',:OLD.ymd||' '||:OLD.slip_no||' '||:OLD.seq, ' '),
                :NEW.junpyogb_cd, :NEW.material_id, NULL, NULL, NULL,
                :NEW.qty, :NEW.danga, :NEW.amt, NULL, NULL,
                username, machine, terminal, program, NULL
           FROM V$SESSION
          WHERE audsid = USERENV('SESSIONID') ;
      END IF ;
      v_oldnew_gb  := 'OLD' ;
      v_curr_jakup := '감사자료추가: ' ||v_dml_gb||'/'||v_oldnew_gb||' ' ;
      IF UPDATING OR DELETING THEN
         INSERT INTO INV_AUDIT_D (TABLE_NM, DML_YMDHMS, DML_GB, OLDNEW_GB,
                                TABLE_PK_NEW, TABLE_PK_OLD,
                                VAR_1, VAR_2, VAR_3, VAR_4, VAR_5,
                                NUM_1, NUM_2, NUM_3, NUM_4, NUM_5,
                                USERNAME, MACHINE, TERMINAL, PROGRAM, BIGO)
         SELECT v_table_nm, v_dml_ymdhms, v_dml_gb, v_oldnew_gb,
                DECODE(v_dml_gb,'UPD',:NEW.ymd||' '||:NEW.slip_no||' '||:NEW.seq, ' '),
                :OLD.ymd||' '||:OLD.slip_no||' '||:OLD.seq,
                :OLD.junpyogb_cd, :OLD.material_id, NULL, NULL, NULL,
                :OLD.qty, :OLD.danga, :OLD.amt, NULL, NULL,
                username, machine, terminal, program, NULL
           FROM V$SESSION
          WHERE audsid = USERENV('SESSIONID') ;
      END IF ;

   END IF;

   <<the_end>>
   NULL;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20099, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END ;
/
