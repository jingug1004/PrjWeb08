CREATE TRIGGER TB_SALE0208_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0208
FOR EACH ROW
  DECLARE  T_MSG VARCHAR2(100) ;

        T_STORE_LOC SALE0207.STORE_LOC%TYPE;         
        T_CUST_ID SALE0207.CUST_ID%TYPE ;
        T_DEAL_GB SALE0207.DEAL_GB%TYPE;
        T_SAWON_ID SALE0207.SAWON_ID%TYPE ;

        T_YMD SALE0208.YMD%TYPE ;
        T_DEAL_NO SALE0208.DEAL_NO%TYPE ;
        T_OLD_QTY SALE0208.QTY%TYPE;
        T_NEW_QTY SALE0208.QTY%TYPE;

BEGIN

        /* CHOE 20160525
        수취거분건에 대한 대응 가능
                        
        w_sale01e09 dw_2 ue_delete 에서 detail 삭제 후 master 삭제 
        이유 : SALE0207의  DEAL_GB 거래구분 = 11 수취 거부 건을 찾아 내기 위해                
         // Update할 Datawindow를 정한다. KTA 20160421 삭제 트리거 시 DW_1 을 먼저 지우면 SALE0207 참조 오류 때문에 순서 변경함
        idw_upd[1] = dw_2
        idw_upd[2] = dw_1
       */
       
       
        /*---------------------------------------------------------------------
       공통 INSERT UPDATE DELETE 모두 사용
       ---------------------------------------------------------------------*/
        BEGIN
                IF INSERTING THEN
                        SELECT STORE_LOC ,YMD ,CUST_ID ,SAWON_ID ,DEAL_GB
                        INTO T_STORE_LOC, T_YMD, T_CUST_ID, T_SAWON_ID ,T_DEAL_GB                
                        FROM SALE0207
                        WHERE DEAL_NO = :NEW.DEAL_NO
                        AND YMD = :NEW.YMD;
                ELSE
                        SELECT STORE_LOC ,YMD ,CUST_ID ,SAWON_ID ,DEAL_GB
                        INTO T_STORE_LOC, T_YMD, T_CUST_ID, T_SAWON_ID ,T_DEAL_GB                
                        FROM SALE0207
                        WHERE DEAL_NO = :OLD.DEAL_NO
                        AND YMD = :OLD.YMD;
                END IF;
        EXCEPTION
                WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR( -20001, SQLERRM||'['||:NEW.DEAL_NO||']' ) ;
        END;
       T_YMD := TO_DATE(TO_CHAR(T_YMD ,'yyyy/mm')||'/01','yyyy/mm/dd');
       
       
       /*---------------------------------------------------------------------
       입력
       ---------------------------------------------------------------------*/
        IF INSERTING THEN
                BEGIN
                        IF NVL(:NEW.DC_QTY_EN_YN,'N') = 'Y' THEN
                                T_NEW_QTY := NVL(:NEW.qty,0) + NVL(:NEW.dc_qty,0);
                        ELSE
                                T_NEW_QTY := NVL(:NEW.qty,0) ;
                        END IF;

                        /*IF T_DEAL_GB = '11' THEN --수취 거부
                                UPDATE SALE0305 
                                SET CHULGO_QTY  = NVL(CHULGO_QTY,0)  + T_NEW_QTY,
                                CHULGO_QTYS = NVL(CHULGO_QTYS,0) + T_NEW_QTY,
                                CHULGO_AMT = NVL(CHULGO_AMT,0)  + NVL(:NEW.AMT,0),
                                CHULGO_VAT = NVL(CHULGO_VAT,0)  + NVL(:NEW.VAT,0)
                                WHERE STORE_LOC = T_STORE_LOC
                                AND ITEM_ID = :NEW.ITEM_ID
                                AND YMD = T_YMD 
                                ;
                        ELSE*/
                                UPDATE SALE0305 
                                SET CHULGO_QTY  = NVL(CHULGO_QTY,0)  + T_NEW_QTY,
                                CHULGO_QTYS = NVL(CHULGO_QTYS,0) + DECODE(SIGN(T_NEW_QTY), -1, 0, T_NEW_QTY),
                                CHULGO_AMT = NVL(CHULGO_AMT,0)  + NVL(:NEW.AMT,0),
                                CHULGO_VAT = NVL(CHULGO_VAT,0)  + NVL(:NEW.VAT,0)
                                WHERE STORE_LOC = T_STORE_LOC
                                AND ITEM_ID = :NEW.ITEM_ID
                                AND YMD = T_YMD 
                                ;                        
                        --END IF;
                        
                        IF SQL%NOTFOUND THEN
                                INSERT INTO SALE0305 (STORE_LOC ,YMD ,ITEM_ID ,CHULGO_QTY ,CHULGO_AMT ,CHULGO_VAT ,CHULGO_QTYS)
                                VALUES (T_STORE_LOC ,T_YMD ,:NEW.ITEM_ID ,T_NEW_QTY ,NVL(:NEW.AMT,0) ,NVL(:NEW.VAT,0) ,DECODE(SIGN(T_NEW_QTY), -1, 0, T_NEW_QTY) ) ;
                        END IF;
                END;
        END IF ;


        /*---------------------------------------------------------------------
        수정
        ---------------------------------------------------------------------*/
        IF UPDATING THEN
                IF UPDATING('ITEM_ID') OR  UPDATING('AMT')    OR  UPDATING('VAT') OR  UPDATING('QTY') OR  UPDATING('DC_QTY') OR  UPDATING('DC_QTY_EN_YN') THEN
                         IF NVL(:OLD.DC_QTY_EN_YN,'N') = 'Y' THEN
                                T_OLD_QTY := NVL(:OLD.QTY,0) + NVL(:OLD.DC_QTY,0);
                         ELSE
                                T_OLD_QTY := NVL(:OLD.QTY,0);
                         END IF;

                        IF NVL(:NEW.DC_QTY_EN_YN,'N') = 'Y' THEN
                                T_NEW_QTY := NVL(:NEW.QTY,0) + NVL(:NEW.DC_QTY,0);
                        ELSE
                                T_NEW_QTY := NVL(:NEW.QTY,0);
                        END IF;

                        /*IF T_DEAL_GB = '11' THEN --수취 거부
                                IF (:NEW.ITEM_ID = :OLD.ITEM_ID) THEN  -- 수량이나 금액이 바뀐 경우
                                        UPDATE SALE0305
                                        SET CHULGO_QTY = (NVL(CHULGO_QTY,0)  - T_OLD_QTY) + T_NEW_QTY,
                                        CHULGO_QTYS = (NVL(CHULGO_QTYS,0) - T_OLD_QTY) + T_NEW_QTY,
                                        CHULGO_AMT = NVL(CHULGO_AMT,0)   - NVL(:OLD.AMT,0) + NVL(:NEW.AMT,0),
                                        CHULGO_VAT = NVL(CHULGO_VAT,0)   - NVL(:OLD.VAT,0) + NVL(:NEW.VAT,0)
                                        WHERE STORE_LOC = T_STORE_LOC
                                        AND ITEM_ID = :NEW.ITEM_ID
                                        AND YMD = T_YMD
                                        ;
                                ELSE                                  -- 품목이 바뀐 경우
                                        UPDATE SALE0305
                                        SET CHULGO_QTY  = NVL(CHULGO_QTY,0) - T_OLD_QTY,
                                        CHULGO_QTYS = NVL(CHULGO_QTYS,0) - T_OLD_QTY,
                                        CHULGO_AMT = NVL(CHULGO_AMT,0) - NVL(:OLD.AMT,0),
                                        CHULGO_VAT = NVL(CHULGO_VAT,0) - NVL(:OLD.VAT,0)
                                        WHERE STORE_LOC = T_STORE_LOC
                                        AND ITEM_ID = :OLD.ITEM_ID
                                        AND YMD = T_YMD;

                                        UPDATE SALE0305
                                        SET CHULGO_QTY  = NVL(CHULGO_QTY,0) + T_NEW_QTY,
                                        CHULGO_QTYS = NVL(CHULGO_QTYS,0) + T_NEW_QTY,
                                        CHULGO_AMT = NVL(CHULGO_AMT,0) + NVL(:NEW.AMT,0),
                                        CHULGO_VAT = NVL(CHULGO_VAT,0) + NVL(:NEW.VAT,0)
                                        WHERE STORE_LOC  = T_STORE_LOC
                                        AND ITEM_ID = :NEW.ITEM_ID
                                        AND YMD = ITEM_ID;
                                END IF;
                        
                        ELSE*/
                                IF (:NEW.ITEM_ID = :OLD.ITEM_ID) THEN  -- 수량이나 금액이 바뀐 경우
                                        UPDATE SALE0305
                                        SET CHULGO_QTY = (NVL(CHULGO_QTY,0)  - T_OLD_QTY) + T_NEW_QTY,
                                        CHULGO_QTYS = (NVL(CHULGO_QTYS,0) - DECODE(SIGN(T_OLD_QTY), -1, 0, T_OLD_QTY)) + DECODE(SIGN(T_NEW_QTY), -1, 0, T_NEW_QTY),
                                        CHULGO_AMT = NVL(CHULGO_AMT,0)   - NVL(:OLD.AMT,0) + NVL(:NEW.AMT,0),
                                        CHULGO_VAT = NVL(CHULGO_VAT,0)   - NVL(:OLD.VAT,0) + NVL(:NEW.VAT,0)
                                        WHERE STORE_LOC = T_STORE_LOC
                                        AND ITEM_ID = :NEW.ITEM_ID
                                        AND YMD = T_YMD
                                        ;
                                ELSE                                  -- 품목이 바뀐 경우
                                        UPDATE SALE0305
                                        SET CHULGO_QTY  = NVL(CHULGO_QTY,0) - T_OLD_QTY,
                                        CHULGO_QTYS = NVL(CHULGO_QTYS,0) - DECODE(SIGN(T_OLD_QTY), -1, 0, T_OLD_QTY),
                                        CHULGO_AMT = NVL(CHULGO_AMT,0) - NVL(:OLD.AMT,0),
                                        CHULGO_VAT = NVL(CHULGO_VAT,0) - NVL(:OLD.VAT,0)
                                        WHERE STORE_LOC = T_STORE_LOC
                                        AND ITEM_ID = :OLD.ITEM_ID
                                        AND YMD = T_YMD;

                                        UPDATE SALE0305
                                        SET CHULGO_QTY  = NVL(CHULGO_QTY,0) + T_NEW_QTY,
                                        CHULGO_QTYS = NVL(CHULGO_QTYS,0) + DECODE(SIGN(T_NEW_QTY), -1, 0, T_NEW_QTY),
                                        CHULGO_AMT = NVL(CHULGO_AMT,0) + NVL(:NEW.AMT,0),
                                        CHULGO_VAT = NVL(CHULGO_VAT,0) + NVL(:NEW.VAT,0)
                                        WHERE STORE_LOC  = T_STORE_LOC
                                        AND ITEM_ID = :NEW.ITEM_ID
                                        AND YMD = ITEM_ID;
                                END IF;
                        --END IF;
                        
                        IF SQL%NOTFOUND THEN
                                INSERT INTO SALE0305 (STORE_LOC ,YMD ,ITEM_ID ,CHULGO_QTY ,CHULGO_AMT ,CHULGO_VAT ,CHULGO_QTYS)
                                VALUES (T_STORE_LOC ,T_YMD ,:NEW.ITEM_ID ,T_NEW_QTY ,NVL(:NEW.AMT,0) ,NVL(:NEW.VAT,0) ,DECODE(SIGN(T_NEW_QTY), -1, 0, T_NEW_QTY) ) ;
                        END IF ;
                END IF;
        END IF ;


        /*---------------------------------------------------------------------
        삭제        

        ---------------------------------------------------------------------*/
        IF DELETING THEN
                BEGIN
                        IF NVL(:OLD.DC_QTY_EN_YN,'N') = 'Y' THEN
                                T_OLD_QTY := NVL(:OLD.QTY,0) + NVL(:OLD.DC_QTY,0);
                        ELSE
                                T_OLD_QTY := NVL(:OLD.QTY,0);
                        END IF;
                        
                        /*IF T_DEAL_GB = '11' THEN --수취 거부
                                UPDATE SALE0305
                                SET CHULGO_QTY  = NVL(CHULGO_QTY,0)  - T_OLD_QTY,
                                CHULGO_QTYS = NVL(CHULGO_QTYS,0) - T_OLD_QTY,
                                CHULGO_AMT = NVL(CHULGO_AMT,0) - (NVL(:OLD.amt,0)),
                                CHULGO_VAT = NVL(CHULGO_VAT,0) - (NVL(:OLD.vat,0))
                                WHERE STORE_LOC = T_STORE_LOC
                                AND ITEM_ID = :OLD.ITEM_ID
                                AND YMD = T_YMD
                                ;
                        ELSE*/      
                                UPDATE SALE0305
                                SET CHULGO_QTY  = NVL(CHULGO_QTY,0)  - T_OLD_QTY,
                                CHULGO_QTYS = NVL(CHULGO_QTYS,0) - DECODE(SIGN(T_OLD_QTY), -1, 0, T_OLD_QTY),
                                CHULGO_AMT = NVL(CHULGO_AMT,0) - (NVL(:OLD.amt,0)),
                                CHULGO_VAT = NVL(CHULGO_VAT,0) - (NVL(:OLD.vat,0))
                                WHERE STORE_LOC = T_STORE_LOC
                                AND ITEM_ID = :OLD.ITEM_ID
                                AND YMD = T_YMD
                                ;
                        --END IF;
                END;
      
                BEGIN
                        DELETE SALE0208_1
                        WHERE DEAL_NO = :OLD.deal_no
                        AND INPUT_SEQ = :OLD.input_seq
                        AND ITEM_ID = :OLD.item_id
                        ;
                END;
        END IF ;
END TB_SALE0208_IUD;
/
