CREATE TRIGGER TB_SALE0210_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0210
FOR EACH ROW
  DECLARE  T_MSG        VARCHAR2(100) ;
         T_YMD        SALE0210.ymd%TYPE ;
         T_STORE_LOC  SALE0209.store_loc%TYPE ;
         T_CUST_ID    SALE0209.cust_id%TYPE ;
         T_RCUST_ID   SALE0209.rcust_id%TYPE ;
         T_SAWON_ID   SALE0209.sawon_id%TYPE ;

BEGIN

  

   /* ------------------------------------------------------------------------ */
   /* 신규입력일 경우                                                          */
   /* ------------------------------------------------------------------------ */
   IF INSERTING THEN
      BEGIN
          SELECT store_loc, ymd , cust_id, rcust_id, sawon_id
            INTO T_STORE_LOC, T_YMD, T_CUST_ID, T_RCUST_ID, T_SAWON_ID
            FROM SALE0209
           WHERE sale_no = :NEW.sale_no
             AND ymd     = :NEW.ymd;
      END;

      
 
--      T_CUST_ID  := :NEW.cust_id;
--      T_SAWON_ID := :NEW.sawon_id;
      T_YMD := TO_DATE(TO_CHAR(:NEW.ymd ,'yyyy/mm')||'/01','yyyy/mm/dd');
 

      BEGIN
          UPDATE SALE0306
             SET MISU_AMT   = NVL(MISU_AMT,0) + NVL(:NEW.amt,0) + NVL(:NEW.vat,0)
           WHERE YMD        = T_YMD
             AND CUST_ID    = T_CUST_ID
             AND RCUST_ID   = T_RCUST_ID
             AND SAWON_ID   = T_SAWON_ID; 

          IF SQL%NOTFOUND THEN
              UPDATE SALE0306
                 SET MISU_AMT   = NVL(MISU_AMT,0) + NVL(:NEW.amt,0) + NVL(:NEW.vat,0)
               WHERE YMD        = T_YMD
                 AND CUST_ID    = T_CUST_ID
                 AND RCUST_ID   = T_RCUST_ID;
 

              IF SQL%NOTFOUND THEN 
                  
                  INSERT INTO SALE0306 (YMD,         CUST_ID,       RCUST_ID,     SAWON_ID,     MISU_AMT )
                                VALUES (T_YMD,     T_CUST_ID,     T_RCUST_ID,   T_SAWON_ID,    NVL(:NEW.amt,0) + NVL(:NEW.vat,0) ) ;
              END IF ;
          END IF ;
    --    UPDATE SALE0208 SET SALE_NO  = :NEW.sale_no,
    --                        SALE_SEQ = :NEW.input_seq
    --                  WHERE YMD      = :ldt_ymd1
    --                    AND DEAL_NO  = :NEW.deal_no;

    --      exception
    --           when OTHERS then
    --                raise_application_error( -20001, sqlerrm ) ;
      END;
   END IF ;

   /* ------------------------------------------------------------------------ */
   /* 수정이 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF UPDATING THEN
      BEGIN
          SELECT store_loc, ymd , cust_id, rcust_id, sawon_id
            INTO T_STORE_LOC, T_YMD, T_CUST_ID, T_RCUST_ID, T_SAWON_ID
            FROM SALE0209
           WHERE sale_no = :NEW.sale_no
             AND ymd     = :NEW.ymd;
      END;

      T_YMD := TO_DATE(TO_CHAR(T_YMD ,'yyyy/mm')||'/01','yyyy/mm/dd');

      BEGIN
          IF (NVL(:OLD.amt,0) - NVL(:OLD.vat,0)) <> (NVL(:NEW.amt,0) - NVL(:NEW.vat,0)) THEN  -- 금액이 바뀐 경우
              UPDATE SALE0306
                 SET MISU_AMT   = NVL(MISU_AMT,0) - NVL(:OLD.amt,0) - NVL(:OLD.vat,0)
                                + NVL(:NEW.amt,0) + NVL(:NEW.vat,0)
               WHERE YMD        = T_YMD
                 AND CUST_ID    = T_CUST_ID
                 AND RCUST_ID   = T_RCUST_ID
                 AND SAWON_ID   = T_SAWON_ID;

              IF SQL%NOTFOUND THEN
                    UPDATE SALE0306
                       SET MISU_AMT   = NVL(MISU_AMT,0) - NVL(:OLD.amt,0) - NVL(:OLD.vat,0)
                                      + (NVL(:NEW.amt,0) + NVL(:NEW.vat,0))
                     WHERE YMD        = T_YMD
                       AND CUST_ID    = T_CUST_ID
                       AND RCUST_ID   = T_RCUST_ID;

                    IF SQL%NOTFOUND THEN
                           RAISE_APPLICATION_ERROR( -20001, 'SALE0306에서 정리 할 거래처를 찾지 못했습니다' ) ;
                    END IF ;
              END IF;
          END IF;    -- 금액이 바뀐경우 END

--        exception
--            when OTHERS then
--                 raise_application_error( -20001, sqlerrm ) ;
      END;
   END IF ;


   /* ------------------------------------------------------------------------ */
   /* 삭제가 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF DELETING THEN
      BEGIN
         FOR c1 IN (  SELECT store_loc, ymd , cust_id, rcust_id, sawon_id
                        FROM SALE0209
                       WHERE sale_no = :OLD.sale_no
                         AND ymd     = :OLD.ymd )
         LOOP
               T_SAWON_ID  := c1.sawon_id;
               T_CUST_ID   := c1.cust_id;
               T_RCUST_ID  := c1.rcust_id;
               T_STORE_LOC := c1.store_loc;
               T_YMD       := TO_DATE(TO_CHAR(c1.ymd ,'yyyy/mm')||'/01','yyyy/mm/dd');

               UPDATE SALE0306
                  SET MISU_AMT   = NVL(MISU_AMT,0) - (NVL(:OLD.amt,0) + NVL(:OLD.vat,0))
                WHERE YMD        = T_YMD
                  AND CUST_ID    = T_CUST_ID
                  AND RCUST_ID   = T_RCUST_ID
                  AND SAWON_ID   = T_SAWON_ID;

               IF SQL%NOTFOUND THEN
                     UPDATE SALE0306
                        SET MISU_AMT   = NVL(MISU_AMT,0) - (NVL(:OLD.amt,0) + NVL(:OLD.vat,0))
                      WHERE YMD        = T_YMD
                        AND CUST_ID    = T_CUST_ID
                        AND RCUST_ID   = T_RCUST_ID;

                     IF SQL%NOTFOUND THEN
                        RAISE_APPLICATION_ERROR( -20001, 'SALE0306에서 정리 할 거래처를 찾지 못했습니다' ) ;
                     END IF ;
               END IF ;

         END LOOP;

      END;
   END IF ;

END TB_SALE0210_IUD;
/
