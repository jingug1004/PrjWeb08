CREATE TRIGGER T_BUY0501_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON BUY0501
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : BUY0502                                                      */
/*  테이블명 : 수입원장 Master                                               */
/*  트리거명 : T_BUY0501_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2002.02.05(화)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 일자형, 코드 존재여부 확인                                  */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(100) ;
   v_message    VARCHAR2(250) ;

   user_err     EXCEPTION     ;

   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'BUY0502 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'BUY0502 수정 불가 !! ' ;
   ELSE
      v_message := 'BUY0502 삭제 불가 !! ' ;
   END IF ;

   IF INSERTING OR UPDATING('offer_cd') THEN
      :NEW.offer_cd := LTRIM(RTRIM(:NEW.offer_cd)) ;

      IF :NEW.offer_cd > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM BUY0001
          WHERE offer_cd = :NEW.offer_cd
            AND use_yn   = 'Y'
            AND ROWNUM < 3 ;
         IF v_count = 0 OR v_dummy = ' ' THEN
            v_curr_error := '해당 Offer상코드는 존재하지 않거나 사용중지됨. => '||:NEW.offer_cd ;
            RAISE user_err ;
         END IF ;
      END IF ;
   END IF ;

   IF INSERTING OR UPDATING('coin_cd') THEN
      :NEW.offer_cd := LTRIM(RTRIM(:NEW.coin_cd)) ;

      IF :NEW.coin_cd > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM BUY0002
          WHERE coin_cd = :NEW.coin_cd
            AND use_yn   = 'Y'
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 화폐코드는 등록되지 않았음. => '||:NEW.coin_cd ;
            RAISE user_err ;
         END IF ;
      END IF ;
   END IF ;

   IF INSERTING OR UPDATING('input_ymd') OR UPDATING('finish_ymd') THEN
      v_curr_jakup := '일자 확인: ' ;
      IF F_CHECK_DATE('YMD', :NEW.input_ymd) = 'FALSE' THEN
         v_curr_error := '입력일자값 오류임.=> '||:NEW.input_ymd ;
         RAISE user_err ;
      END IF ;

      IF F_CHECK_DATE('YMD', :NEW.finish_ymd) = 'FALSE' THEN
         v_curr_error := '업무종료일자값 오류임.=> '||:NEW.finish_ymd ;
         RAISE user_err ;
      END IF ;
   END IF ;

   IF INSERTING OR
      UPDATING('balju_no')    OR UPDATING('material_id')OR
      UPDATING('qty')         OR UPDATING('danga')  THEN

      :NEW.balju_no        := LTRIM(RTRIM(:NEW.balju_no));
      :NEW.material_id     := LTRIM(RTRIM(:NEW.material_id));
      :NEW.qty   := NVL(LTRIM(RTRIM(:NEW.qty)), 0) ;
      :NEW.danga := NVL(LTRIM(RTRIM(:NEW.danga)), 0) ;
      :NEW.amt   := :NEW.qty * :NEW.danga ;

      v_curr_jakup := '입력값 확인 ';
      IF NVL(:NEW.balju_no,' ') = ' ' OR NVL(:NEW.material_id,' ') = ' ' OR
         :NEW.qty = 0 OR :NEW.danga = 0 THEN
         v_curr_error := '발주번호/원부자재코드/수량/단가는 반드시 입력해야 함.' ;
         RAISE user_err ;
      END IF ;

      SELECT COUNT(balju_no)
        INTO v_count
        FROM BUY0402
       WHERE balju_no    = :NEW.balju_no
         AND material_id = :NEW.material_id
         AND ROWNUM      < 3 ;

      IF v_count = 0 THEN
         v_curr_error := '해당 발주번호/원부자재는 존재하지 않아 작업이 불가함.' ;
         RAISE user_err ;
      END IF ;
   END IF ;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
