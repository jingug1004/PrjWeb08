CREATE TRIGGER T_INV0305_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON INV0305
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : INV0305                                                      */
/*  테이블명 : 제조지시서 Detail                                             */
/*  트리거명 : T_INV0305_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2002.02.19(화)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 일자형, 코드 존재여부 확인                                  */
/*             2. 제조지시서 Master 존재여부 확인                            */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(100) ;
   v_message    VARCHAR2(250) ;

   user_err     EXCEPTION     ;

   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'INV0305 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'INV0305 수정 불가 !! ' ;
   ELSE
      v_message := 'INV0305 삭제 불가 !! ' ;
   END IF ;

   IF INSERTING OR UPDATING THEN
      v_curr_jakup := '제조지시서Master(INV0303) 존재여부 확인: ' ;

      SELECT COUNT(prod_seq)
        INTO v_count
        FROM INV0303
       WHERE prod_seq = :NEW.prod_seq
         AND ROWNUM < 3 ;

      IF v_count != 1 THEN
         v_curr_error := '해당 제조지시서 번호가 존재하지 않음.=> '||:NEW.prod_seq ;
         RAISE user_err ;
      END IF ;
   END IF ;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
