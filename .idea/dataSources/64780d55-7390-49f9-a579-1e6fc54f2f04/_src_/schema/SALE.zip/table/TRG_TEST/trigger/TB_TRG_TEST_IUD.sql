CREATE TRIGGER TB_TRG_TEST_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON TRG_TEST
FOR EACH ROW
  DECLARE
     T_UPDATE_CHK   NUMBER;
     메시지         varchar2(1000) ;
     
BEGIN
   /* ********************************************************************* */
   /* 수정될때                                                              */
   /* ********************************************************************* */
   if UPDATING then
         DBMS_OUTPUT.PUT_LINE('XXXXXXXXXXXXXXXXXXXXXXXXXXXXX');
         raise_application_error( -20671, :NEW.B||':'||:OLD.B ) ;

   end if ;


END tb_trg_test_iud;
/
