CREATE TRIGGER T_INV0301_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON INV0301
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : INV0301                                                      */
/*  테이블명 : 입출고전표 Master                                             */
/*  트리거명 : T_INV0301_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2001.12.10(월)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 관리자가 해당월 마감확정여부를 Y로 체크한 경우 입력불가 처리  */
/*             2. 일자형, 코드 존재여부 확인                                  */
/*             3. 전표 종류에 따른 관련값 입력여부 확인                       */
/*  수정내역 : 2001.12.12(수) 제조번호를 별도 테이블로 분리함에 따른 수정      */
/*             2001.12.13(목) 출고전표는 공정마다 발행함에 따른 설계 변경 내용 반영 */
/*                            공정관련 칼럼을 입출고전표Detail->Master로 옮김.*/
/*             2002.01.19(토) 공정관리를 별도로 분리함에 따른 관련 칼럼 체크사항 삭제 */
/*                            불출,수령사원,창고 칼럼을 inv0302에서 동테이블로 옮김 */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(200) ;
   v_curr_error VARCHAR2(250) ;
   user_err     EXCEPTION     ;
   v_message  VARCHAR2(50) ;
   v_dummy      VARCHAR2(6) ;
   v_dummy1     VARCHAR2(6) ;
   v_item_yn    VARCHAR2(3) ;
   v_cust_yn    VARCHAR2(2) ;
   v_prod_no_yn VARCHAR2(2) ;
   v_ipchul_gb VARCHAR2(2) ;
   
   v_magam_sawon_nm VARCHAR2(10) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'INV0301 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'INV0301 수정 불가 !! ' ;
   ELSE
      v_message := 'INV0301 삭제 불가 !! ' ;
   END IF ;

   IF INSERTING AND NVL(RTRIM(:NEW.input_ymd),' ') = ' ' THEN
      SELECT TO_CHAR(SYSDATE, 'yyyymmdd')
        INTO :NEW.input_ymd
        FROM dual ;
   END IF ;

   IF INSERTING OR UPDATING OR DELETING THEN
      v_curr_jakup := '마감확정여부 확인: ' ;
      v_dummy  := ' ';
      v_dummy1 := ' ';
      IF INSERTING OR UPDATING THEN
         v_dummy := SUBSTRB(:NEW.ymd,1,6) ;
      END IF ;
      IF UPDATING OR INSERTING THEN
         v_dummy1 := SUBSTRB(:OLD.ymd,1,6) ;
      END IF ;
      SELECT COUNT(*)
        INTO v_count
        FROM INV0401
       WHERE (yyyymm   = v_dummy OR yyyymm   = v_dummy1)
         AND magam_yn = 'Y'
         AND ROWNUM < 3 ;
      IF v_count > 0 THEN
         
         SELECT SAWON_NM INTO v_magam_sawon_nm FROM sale0007 WHERE sawon_id = (select user_id from inv0401 where  (yyyymm = v_dummy OR yyyymm = v_dummy1) AND magam_yn = 'Y');
         v_curr_error := '해당월은 자재마감이 완료되었으므로 작업이 불가하니 마감작업자 에게 문의바람.=> 마감월:'||v_dummy ||' 마감작업자:'||v_magam_sawon_nm;
         RAISE user_err ;
      END IF ;
   END IF;
  
   
/* ##### 2002.02.16(토) PowerBuilder 공통모듈에서 에서 Master->Detail 순서로 Update문장이
                        날라가기 때문에 의미 없음.
   IF UPDATING('YMD') OR UPDATING('SLIP_NO') OR
      DELETING THEN
      v_curr_jakup := '해당전표의 Detail 존재여부 확인: ' ;
      select count(*)
        into v_count
        from INV0302
       where ymd     = :OLD.ymd
         and slip_no = :OLD.slip_no
         and rownum < 3 ;
      IF v_count > 0 THEN
         v_curr_error := 'Detail(INV0302)이 존재하여 작업이 불가하니 관리자에게 문의바람.=> OLD'||
                         :OLD.ymd ||'-'|| :OLD.slip_no ;
         RAISE user_err ;
      END IF ;
   END IF;
   ##################################### */
   IF INSERTING OR
      UPDATING('YMD') OR UPDATING('JUNPYOGB_CD') OR UPDATING('ITEM_ID') THEN

      :NEW.JUNPYOGB_CD := LTRIM(RTRIM(:NEW.JUNPYOGB_CD));
      :NEW.prod_seq    := LTRIM(RTRIM(:NEW.prod_seq));
      :NEW.cust_id     := LTRIM(RTRIM(:NEW.cust_id));

      v_curr_jakup := '일자 확인: ' ;
      IF F_Check_Date('YMD', :NEW.ymd) = 'FALSE' THEN
         v_curr_error := '작업일자값 오류임.=> '||:NEW.ymd ;
         RAISE user_err ;
      END IF ;

      v_curr_jakup := '입력값 확인: ' ;

      SELECT 1, NVL(prod_no_yn, 'N'), NVL(cust_yn,'N'), ipchul_gb
          INTO v_count, v_prod_no_yn, v_cust_yn, v_ipchul_gb
        FROM INV0001
       WHERE junpyogb_cd = :NEW.JUNPYOGB_CD
            AND use_yn  = 'Y';

      IF v_count = 0 THEN
         v_curr_error := '해당 전표코드는 존재하지 않거나 사용중지된 코드임.=> '||:NEW.JUNPYOGB_CD ;
         RAISE user_err ;
      END IF ;

      IF NVL(v_ipchul_gb,' ') = ' ' THEN -- 1 입고전표, 2 출고전표
         v_curr_error := '해당전표의 입출고 구분이 설정 되어있지 않음.' ;
         RAISE user_err ;
      END IF ;

      IF v_prod_no_yn = 'Y' AND NVL(:NEW.prod_seq,' ') = ' ' THEN
         v_curr_error := '해당전표는 제조번호를 반드시 입력해야 함.' ;
         RAISE user_err ;
      END IF ;

      IF :NEW.prod_seq > ' ' THEN
         SELECT COUNT(*), NVL(MAX(finish_ymd),' ')
           INTO v_count, v_dummy
           FROM INV0303
          WHERE prod_seq = :NEW.prod_seq
            AND ROWNUM < 3 ;
--###2002.03.04(월)
--         IF v_count = 0 OR v_dummy != ' ' THEN
         IF v_count = 0 THEN
            v_curr_error := '해당 제조번호는 존재하지 않음.=> '||:NEW.prod_seq ;
            RAISE user_err ;
         END IF ;
      END IF ;

      IF v_ipchul_gb = '2' AND v_prod_no_yn = 'Y' AND NVL(:NEW.process_cd,' ') = ' ' THEN
         v_curr_error := '제조번호가 필수 인 출고전표인데 공정코드를 입력하지 않음.' ;
         RAISE user_err ;
      END IF ;

      IF :NEW.process_cd > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM INV0002
          WHERE process_cd = :NEW.process_cd
            AND use_yn  = 'Y'
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 공정코드는 존재하지 않거나 사용중지된 코드임.=> '||:NEW.process_cd ;
            RAISE user_err ;
         END IF ;
      END IF ;

      IF v_cust_yn = 'Y' AND NVL(:NEW.cust_id,' ') = ' ' THEN
         v_curr_error := '해당전표는 거래처를 반드시 입력해야 함.' ;
         RAISE user_err ;
      END IF ;

      IF :NEW.cust_id > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM INV0011
          WHERE cust_id = :NEW.cust_id
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 거래처코드는 등록되지 않음. 구매관리자에게 문의 바람.=> '||:NEW.cust_id ;
            RAISE user_err ;
         END IF ;
      END IF ;

      IF :NEW.sawon_id > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM SALE0007
          WHERE sawon_id = :NEW.sawon_id
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 사원은 등록되지 않음. => '||:NEW.sawon_id ;
            RAISE user_err ;
         END IF ;
      END IF ;
      IF :NEW.ip_sawon_id > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM SALE0007
          WHERE sawon_id = :NEW.ip_sawon_id
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 사원은 등록되지 않음. => '||:NEW.ip_sawon_id ;
            RAISE user_err ;
         END IF ;
      END IF ;
      IF :NEW.chul_sawon_id > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM SALE0007
          WHERE sawon_id = :NEW.chul_sawon_id
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 사원은 등록되지 않음. => '||:NEW.chul_sawon_id ;
            RAISE user_err ;
         END IF ;
      END IF ;

   END IF ;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
