CREATE TRIGGER TR_SALE0304_IU
AFTER INSERT OR UPDATE OR DELETE
  ON SALE0304
FOR EACH ROW
  declare
   ln_ret number := 0;
   ls_lnk_comp_no  VARCHAR2(14);
   ls_cust_id      VARCHAR2(10);  /*거래처아이디*/
   ls_hist_gbn     VARCHAR2(2) := '01';  /*업무구분*/
   ls_data_gbn     VARCHAR2(2) := '01';  /*데이터구분*/
   ls_drug_no      VARCHAR2(10);         /*의약품번호*/
   ls_hist_dt      VARCHAR2(8);
   ln_qty          NUMBER(5);
   ln_cnt          NUMBER(5);
BEGIN
   /* 입력또는 수정되는 값이 있을때 특정도매상, 특정의약품일때 RFID TEMP영역으로 복사한다. */
   ls_cust_id := NVL(:NEW.CUST_ID,:OLD.CUST_ID);
   IF     (NVL(:NEW.ITEM_ID,:OLD.ITEM_ID) = '60703' )    /*염몰핀코드*/
      AND (ls_cust_id = '1100223' OR ls_cust_id = '1100007') THEN  /*이화, 태종*/
      IF    (NVL(:NEW.IPCHUL_GB, :OLD.IPCHUL_GB)) = '01' THEN
         ls_hist_gbn := '01';
      ELSIF (NVL(:NEW.IPCHUL_GB, :OLD.IPCHUL_GB)) = '10' THEN
         ls_hist_gbn := '02';
      END IF;
      IF INSERTING THEN
         ls_lnk_comp_no  := '61142';
         ls_drug_no      := NVL(:NEW.ITEM_ID,:OLD.ITEM_ID);         /*의약품번호*/
         ls_hist_dt      := to_char(NVL(:NEW.YMD,:OLD.YMD),'YYYYMMDD');
         ln_qty          := NVL(:NEW.QTY,:OLD.QTY);
      ELSIF UPDATING THEN
         ls_lnk_comp_no  := '61142';
         ls_drug_no      := NVL(:NEW.ITEM_ID,:OLD.ITEM_ID);         /*의약품번호*/
         ls_hist_dt      := to_char(NVL(:NEW.YMD,:OLD.YMD),'YYYYMMDD');
         ln_qty          := NVL(:NEW.QTY,0) - NVL(:OLD.QTY,0);
      ELSIF DELETING THEN
         ls_lnk_comp_no  := '61142';
         ls_drug_no      := NVL(:NEW.ITEM_ID,:OLD.ITEM_ID);         /*의약품번호*/
         ls_hist_dt      := to_char(NVL(:NEW.YMD,:OLD.YMD),'YYYYMMDD');
         ln_qty          := NVL(:NEW.QTY,0) - NVL(:OLD.QTY,0);
      END IF;
      BEGIN
         SELECT count(*) INTO ln_cnt
           FROM SALE.BHCO_HIST_SUM_LNK
          WHERE LNK_CMP_NO = ls_lnk_comp_no
            AND HIST_GBN   = ls_hist_gbn
            AND DATA_GBN   = ls_data_gbn
            AND DRUG_NO    = ls_drug_no
            AND HIST_DT    = ls_hist_dt;
         ln_cnt := nvl(ln_cnt, 0);
      EXCEPTION WHEN OTHERS THEN
         ln_cnt := 0;
      END;
      IF ln_cnt = 0 THEN
         INSERT INTO SALE.BHCO_HIST_SUM_LNK
                (LNK_CMP_NO, HIST_GBN, DATA_GBN, DRUG_NO, HIST_DT,
                 QTY       , INPUT_NM, INPUT_DT, STAT)
         VALUES (ls_lnk_comp_no, ls_hist_gbn, ls_data_gbn, ls_drug_no, ls_hist_dt,
                 ln_qty        , ''         , ''         , '02');
      ELSE
         UPDATE SALE.BHCO_HIST_SUM_LNK
            SET QTY = nvl(QTY,0) + nvl(ln_qty,0)
          WHERE LNK_CMP_NO = ls_lnk_comp_no
            AND HIST_GBN   = ls_hist_gbn
            AND DATA_GBN   = ls_data_gbn
            AND DRUG_NO    = ls_drug_no
            AND HIST_DT    = ls_hist_dt;
      END IF;
   END IF;
EXCEPTION WHEN NO_DATA_FOUND THEN
   NULL;
END;
/
