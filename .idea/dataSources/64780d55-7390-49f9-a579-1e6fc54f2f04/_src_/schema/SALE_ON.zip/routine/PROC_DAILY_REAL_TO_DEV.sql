CREATE PROCEDURE         PROC_DAILY_REAL_TO_DEV IS

       /*-------------------------------------------------------------------
       DESCRIPTION
       변경일자 - 20171201 CHOE
       2번 db를 13번 db와 싱크하기 위한 프로시져
       
       TRADEDATA_TBL 
       
       동기화 진행                    
      -------------------------------------------------------------------*/
        V_CNT1 NUMBER;
        V_CNT2 NUMBER;     

BEGIN 
 
   --TRADEDATA_TBL
   BEGIN  
       insert into TRADEDATA_TBL   
       select DEAL_CODE      
            ,COMP_CODE      
            ,BANK_CD        
            ,MESS_CODE      
            ,JOB_DIFF       
            ,TRAN_NUMB      
            ,SEQ_NO         
            ,TRAN_DATE      
            ,TRAN_TIME      
            ,STAN_RESP_CODE 
            ,BANK_RESP_CODE 
            ,INQU_DATE      
            ,INQU_NO        
            ,BANK_SEQ_NO    
            ,BANK_CD_3      
            ,FILLER_1       
            ,ACCO_NUMB      
            ,COMP_CNT       
            ,DEAL_SELE      
            ,IN_BANK_CD     
            ,TOTAL_AMT      
            ,BALA_MONE      
            ,GIRO           
            ,RECE_NM        
            ,CHEC_NO        
            ,CASH           
            ,OUT_BANK_CHEC  
            ,ETC_CHEC       
            ,CMS_NO         
            ,DEAL_STAR_DATE 
            ,DEAL_STAR_TIME 
            ,ACCO_SERI_NO   
            ,IN_BANK_CD_3   
            ,GIRO_3         
            ,FILLER_2       
            ,''    
         from SALE_ON.TRADEDATA_TBL@REAL_SALE.HANA.CO.KR a
        where tran_date  > to_char(sysdate - 60,'yyyymmdd')
          and not exists (select 'x' from TRADEDATA_TBL where tran_date = a.tran_date and tran_time = a.tran_time and seq_no = a.seq_no)
       ;

   EXCEPTION WHEN OTHERS THEN
       ROLLBACK;       
       insert into RFID_USER.ZPROC_DAILY_COPY_HIST values (TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),'SALE_ON','TRADEDATA_TBL',sysdate,'');
       commit;        
       return;
   END;           
   
   COMMIT;
    
    
EXCEPTION   
        WHEN OTHERS THEN
            ROLLBACK;        
END  PROC_DAILY_REAL_TO_DEV;
/
