CREATE TRIGGER TB_TRADEDATA_VTPMS_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON TRADEDATA_VTPMS
FOR EACH ROW
  DECLARE 
 
   /*
   트리거로 수금테이블에 가상계좌를 반영하려 하였으나 트리거는 오류가 발생하여 oragmp 에 가져가는 프로시져로 col_Sal_Day_Conversion 로  처리함  
   
   p_plantcode          ORAGMP.SLCOLM.PLANTCODE%TYPE;
   p_coldate            ORAGMP.SLCOLM.COLDATE%TYPE;
   p_coldiv             ORAGMP.SLCOLM.COLDIV%TYPE;
   p_coldtldiv          ORAGMP.SLCOLM.COLDTLDIV%TYPE;
   p_orderdiv           ORAGMP.SLCOLM.ORDERDIV%TYPE;
   p_tasooyn            ORAGMP.SLCOLM.TASOOYN%TYPE;
   p_custcode           ORAGMP.SLCOLM.CUSTCODE%TYPE;
   p_deptcode           ORAGMP.SLCOLM.DEPTCODE%TYPE;
   p_empcode            ORAGMP.SLCOLM.EMPCODE%TYPE;
   p_ecustcode          ORAGMP.SLCOLM.ECUSTCODE%TYPE;
   p_edeptcode          ORAGMP.SLCOLM.EDEPTCODE%TYPE;
   p_eempcode           ORAGMP.SLCOLM.EEMPCODE%TYPE;
   p_colamt             ORAGMP.SLCOLM.COLAMT%TYPE;
   p_colvat             ORAGMP.SLCOLM.COLVAT%TYPE;
   p_accountno          ORAGMP.SLCOLM.ACCOUNTNO%TYPE;
   p_billno             ORAGMP.SLCOLM.BILLNO%TYPE;
   p_issdate            ORAGMP.SLCOLM.ISSDATE%TYPE;
   p_expdate            ORAGMP.SLCOLM.EXPDATE%TYPE;
   p_paybank            ORAGMP.SLCOLM.PAYBANK%TYPE;
   p_paybankbr          ORAGMP.SLCOLM.PAYBANKBR%TYPE;
   p_issempnm           ORAGMP.SLCOLM.ISSEMPNM%TYPE;
   p_baeseo             ORAGMP.SLCOLM.BAESEO%TYPE;
   p_cardcomp           ORAGMP.SLCOLM.CARDCOMP%TYPE;
   p_cardno             ORAGMP.SLCOLM.CARDNO%TYPE;
   p_cardokno           ORAGMP.SLCOLM.CARDOKNO%TYPE;
   p_divmonth           ORAGMP.SLCOLM.DIVMONTH%TYPE;
   p_autoyn             ORAGMP.SLCOLM.AUTOYN%TYPE;
   p_carddate           ORAGMP.SLCOLM.CARDDATE%TYPE;
   p_discntdate         ORAGMP.SLCOLM.DISCNTDATE%TYPE;     
   p_appdate            ORAGMP.SLCOLM.APPDATE%TYPE;   
   p_custprtyn          ORAGMP.SLCOLM.CUSTPRTYN%TYPE;
   p_bigo               ORAGMP.SLCOLM.BIGO%TYPE;
   p_remark             ORAGMP.SLCOLM.REMARK%TYPE;
   p_apprstatus         ORAGMP.SLCOLM.APPRSTATUS%TYPE;
   p_moneycode          ORAGMP.SLCOLM.MONEYCODE%TYPE;
   p_exrtrate           ORAGMP.SLCOLM.EXRTRATE%TYPE;
   p_exrtamt            ORAGMP.SLCOLM.EXRTAMT%TYPE;
   p_iempcode           ORAGMP.SLCOLM.IEMPCODE%TYPE; 
   */
   p_out                varchar2(20);
BEGIN
  
   IF INSERTING THEN
      p_out := '';
      /*
      BEGIN
         BEGIN
             SELECT A.CUSTCODE,
                    A.EMPCODE ,
                    B.DEPTCODE
               INTO p_custcode,
                    p_empcode ,
                    p_deptcode
               FROM ORAGMP.CMCUSTM A,
                    ORAGMP.CMEMPM  B
              WHERE A.EMPCODE = B.EMPCODE
                AND TRIM(A.VIRTUALACCOUNT) = TRIM(:NEW.CMS_NO);
         EXCEPTION
              WHEN NO_DATA_FOUND THEN
                  insert into RFID_USER.ZPROC_DAILY_COPY_HIST values (:NEW.CMS_NO||' '||:NEW.SEQ_NO||' '||TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),'SALE_ON','가상계좌로사번미확인',sysdate,:NEW.CMS_NO);
         END;

         p_plantcode  := '1000';
         p_coldate    := TO_CHAR(TO_DATE(:NEW.DEAL_STAR_DATE),'YYYY-MM-DD');
         p_coldiv     := '01';
         p_orderdiv   := '4';
         p_tasooyn    := 'N';
         p_custcode   := p_custcode;
         p_deptcode   := p_deptcode;
         p_empcode    := p_empcode ;
         p_ecustcode  := p_custcode;
         p_edeptcode  := p_deptcode;
         p_eempcode   := p_empcode;
         p_colamt     := TO_NUMBER(:NEW.TOTAL_AMT);
         p_colvat     := 0;
         p_accountno  := :NEW.CMS_NO;                 --계좌번호
         p_billno     := '';
         p_issdate    := '';
         p_expdate    := '';
         p_paybank    := :NEW.BANK_CD;                --은행코드
         p_paybankbr  := :NEW.COMP_CODE;
         p_issempnm   := :NEW.SEQ_NO;
         p_baeseo     := :NEW.TRAN_DATE;
         p_cardcomp   := :NEW.TRAN_TIME;
         p_cardno     := :NEW.DEAL_SELE;
         p_cardokno   := '';
         p_divmonth   := 0;
         p_carddate   := TO_CHAR(TO_DATE(:NEW.DEAL_STAR_DATE),'YYYY-MM-DD');
         p_autoyn     := 'N';
         p_appdate    := TO_CHAR(TO_DATE(:NEW.DEAL_STAR_DATE),'YYYY-MM-DD');
         p_discntdate := '';
         p_custprtyn  := 'N';
         p_bigo       := '가상계좌';
         p_remark     := '가상계좌';
         p_apprstatus := '00';
         p_exrtrate   := 0;
         p_exrtamt    := 0;
         p_iempcode   := 'TRADEDATA_VTPMS';  
       
         ORAGMP.COL_SAL_spSLcol0099P ( p_plantcode  => p_plantcode
                                      ,p_coldate    => p_coldate
                                      ,p_coldiv     => p_coldiv
                                      ,p_coldtldiv  => p_coldtldiv
                                      ,p_orderdiv   => p_orderdiv
                                      ,p_tasooyn    => p_tasooyn
                                      ,p_custcode   => p_custcode
                                      ,p_deptcode   => p_deptcode
                                      ,p_empcode    => p_empcode
                                      ,p_ecustcode  => p_ecustcode
                                      ,p_edeptcode  => p_edeptcode
                                      ,p_eempcode   => p_eempcode
                                      ,p_colamt     => p_colamt
                                      ,p_colvat     => p_colvat
                                      ,p_accountno  => p_accountno
                                      ,p_billno     => p_billno
                                      ,p_issdate    => p_issdate
                                      ,p_expdate    => p_expdate
                                      ,p_paybank    => p_paybank
                                      ,p_paybankbr  => p_paybankbr
                                      ,p_issempnm   => p_issempnm
                                      ,p_baeseo     => p_baeseo
                                      ,p_cardcomp   => p_cardcomp
                                      ,p_cardno     => p_cardno
                                      ,p_cardokno   => p_cardokno
                                      ,p_divmonth   => p_divmonth
                                      ,p_autoyn     => p_autoyn
                                      ,p_carddate   => p_carddate
                                      ,p_discntdate => p_discntdate
                                      ,p_custprtyn  => p_custprtyn
                                      ,p_remark     => p_remark
                                      ,p_apprstatus => p_apprstatus
                                      ,p_moneycode  => p_moneycode
                                      ,p_exrtrate   => p_exrtrate
                                      ,p_exrtamt    => p_exrtamt
                                      ,p_iempcode   => p_iempcode  
                                      ,p_out        => p_out
                                      );
                                      
            --:NEW.JUNPYO_NO := p_out; --수금테이블에 연동된 전표번호를 기록한다.                               
            --COMMIT;
            
      EXCEPTION
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, '가상계좌내역 현금수금 자동입금시 INS Err:'||SQLERRM||':NEW.CMS_NO '||':'||:NEW.CMS_NO||' '||:NEW.SEQ_NO ) ;
      END;
   
      */
    
   END IF; 

END tb_TRADEDATA_VTPMS_iud;
/
