CREATE TRIGGER TB_TRADEDATA_TBL_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON TRADEDATA_TBL
FOR EACH ROW
  DECLARE
     T_MAX          NUMBER;
     T_CNT          NUMBER;
     T_JUNPYO_NO    VARCHAR2(14);
     T_CUST_ID      VARCHAR2(10);
     T_SAWON_ID     VARCHAR2(8);
     
     T_MSG          VARCHAR2(100);

BEGIN

    /*
    2017.12.15 KTA 
    QA서버는 트리거 오류 발생하여 꺼둠 
    */

   /* -------------------------------------------------------------------------*/
   /* 가상계좌에 자료가 들어오면 실시간으로 수금등록마스터(SALE.SALE0401)에    */
   /* 현금으로 자동입력처리한다.                                               */
   /* -------------------------------------------------------------------------*/

   /* ------------------------------------------------------------------------ */
   /* 신규입력일 경우                                                          */
   /* ------------------------------------------------------------------------ */
   IF INSERTING THEN
         --수금전표번호 
         SELECT NVL(MAX(A.MAX) + 1,0)
           INTO T_MAX
           FROM SALE.SYS100C A
          WHERE A.TABLE_NM = 'SALE0401'
            AND A.COL01    = :NEW.DEAL_STAR_DATE
            AND A.COL02    = '*'
            AND A.COL03    = '*'
            AND A.COL04    = '*'
            AND A.COL05    = '*' ;

         IF T_MAX = 0 THEN
            T_MAX := T_MAX + 1;
            INSERT INTO SALE.SYS100C(TABLE_NM,COL01,COL02,COL03,COL04,COL05,MAX)
                              VALUES('SALE0401',:NEW.DEAL_STAR_DATE,'*','*','*','*',T_MAX);
         ELSE
            UPDATE SALE.SYS100C A SET A.MAX = T_MAX
                                WHERE A.TABLE_NM = 'SALE0401'
                                  AND A.COL01    = :NEW.DEAL_STAR_DATE
                                  AND A.COL02    = '*'
                                  AND A.COL03    = '*'
                                  AND A.COL04    = '*'
                                  AND A.COL05    = '*' ;
         END IF;
         T_JUNPYO_NO := :NEW.DEAL_STAR_DATE||TRIM(TO_CHAR(T_MAX,'0000'));
         
         --거래처코드
         SELECT COUNT(*) INTO T_CNT FROM SALE.SALE0003VN WHERE VIRTUAL_NO = TRIM(:NEW.CMS_NO);
         IF T_CNT = 0 THEN
            T_CUST_ID := '0000000';
            BEGIN
               INSERT INTO TRADEDATA_TBL_ERROR (YMD,CMS_NO,YMDTS,COMMENTS) VALUES (TO_DATE(:NEW.DEAL_STAR_DATE),:NEW.CMS_NO,TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),'가상계좌번호에 매칭된 거래처 없음');
            EXCEPTION WHEN OTHERS THEN
               T_CUST_ID := '0000000';
            END;
         ELSE
            SELECT CUST_ID INTO T_CUST_ID FROM SALE.SALE0003VN WHERE VIRTUAL_NO = TRIM(:NEW.CMS_NO);
         END IF;
        
         --담당사원
         SELECT COUNT(*) INTO T_CNT FROM SALE.SALE0003 WHERE CUST_ID = T_CUST_ID;         
         IF T_CNT = 0 THEN
            T_SAWON_ID := '00000';
            BEGIN
               INSERT INTO TRADEDATA_TBL_ERROR (YMD,CMS_NO,YMDTS,COMMENTS) VALUES (TO_DATE(:NEW.DEAL_STAR_DATE),:NEW.CMS_NO,TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),'가상계좌번호로 찾은 거래처가 거래처마스터에 없음');
            EXCEPTION WHEN OTHERS THEN
               T_CUST_ID := '0000000';
            END;            
         ELSE
            SELECT SAWON_ID INTO T_SAWON_ID FROM SALE.SALE0003 WHERE CUST_ID = T_CUST_ID;         
         END IF;
         
         
        BEGIN         
             INSERT INTO SALE.SALE0401 ( YMD, JUNPYO_GB, JUNPYO_NO, 
                                         CUST_ID, RCUST_ID, CASH_AMT, 
                                         BILL_AMT, SAWON_ID, INPUT_YMD, 
                                         MAGAM_YN, BIGO, ACC_JUNPYO_CD, 
                                         LOG_DATE, INPUT_ID, CMS_NO)
                                VALUES ( TO_DATE(:NEW.DEAL_STAR_DATE), '01', T_JUNPYO_NO,
                                         T_CUST_ID, T_CUST_ID, TO_NUMBER(:NEW.TOTAL_AMT),
                                         0, T_SAWON_ID, SYSDATE,
                                         'N', '가상계좌입금:'||:NEW.CMS_NO, NULL,
                                         SYSDATE, T_SAWON_ID, :NEW.CMS_NO ) ;
                                                     
             :NEW.JUNPYO_NO := T_JUNPYO_NO; --수금테이블에 연동된 전표번호를 기록한다.                                       
                                       
        EXCEPTION
              WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR( -20001, '가상계좌내역 현금수금 자동입금시 INS Err:'||SQLERRM ) ; 
                T_MSG :=  '가상계좌내역 현금수금 자동입금시 INS Err11:'||SQLERRM;                                         
                ROLLBACK;       
                insert into TRADEDATA_TBL_ERROR values (TO_CHAR(SYSDATE,'YYYYMMDD'),:NEW.CMS_NO,TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),T_MSG);
                commit;                        
                                          
        END;
   END IF;


EXCEPTION  WHEN OTHERS THEN
                RAISE_APPLICATION_ERROR( -20001, '가상계좌내역 현금수금 자동입금시 INS Err:'||SQLERRM ) ; 
                T_MSG :=  '가상계좌내역 현금수금 자동입금시 INS Err22:'||SQLERRM;                                         
                ROLLBACK;       
                insert into TRADEDATA_TBL_ERROR values (TO_CHAR(SYSDATE,'YYYYMMDD'),:NEW.CMS_NO,TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),T_MSG);
                commit;                        

END tb_TRADEDATA_TBL_iud;
/
