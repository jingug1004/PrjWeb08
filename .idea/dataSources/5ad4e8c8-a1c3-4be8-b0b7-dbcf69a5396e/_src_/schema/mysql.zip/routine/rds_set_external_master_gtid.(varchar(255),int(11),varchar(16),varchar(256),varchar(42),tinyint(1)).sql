CREATE PROCEDURE rds_set_external_master_gtid(IN host                  VARCHAR(255), IN port INT, IN USER VARCHAR(16),
                                              IN passwd                VARCHAR(256), IN gtid VARCHAR(42),
                                              IN enable_ssl_encryption TINYINT(1))
  BEGIN
DECLARE v_rdsrepl INT;
DECLARE v_mysql_version VARCHAR(20);
DECLARE v_called_by_user VARCHAR(50);
DECLARE v_sleep INT;
DECLARE sql_logging BOOLEAN;
SELECT @@sql_log_bin INTO sql_logging;
SELECT COUNT(1) INTO v_rdsrepl FROM mysql.rds_history WHERE action = 'disable set master' AND master_user = 'rdsrepladmin';
SELECT USER() INTO v_called_by_user;
SELECT version() INTO v_mysql_version;
IF v_rdsrepl > 0 AND  v_called_by_user != 'rdsadmin@localhost'
THEN
SET @@sql_log_bin=off;
SELECT 'RDS_SET_EXTERNAL_MASTER is disabled on this host.' AS Message;
ELSE
SET @cmd = CONCAT('CHANGE MASTER TO ',
CONCAT_WS(', ',
CONCAT('MASTER_HOST = "', TRIM(BOTH FROM host), '"'),
CONCAT('MASTER_PORT = ', port),
CONCAT('MASTER_USER = "', TRIM(BOTH FROM USER), '"'),
CONCAT('MASTER_PASSWORD = "', TRIM(BOTH FROM passwd), '"'),
CONCAT('MASTER_USE_GTID = slave_pos'),
CONCAT('MASTER_SSL = ', enable_ssl_encryption)));
PREPARE rds_set_master FROM @cmd;
UPDATE mysql.rds_replication_status SET called_by_user=v_called_by_user, action='set master', mysql_version=v_mysql_version , master_host=TRIM(BOTH FROM host), master_port=port WHERE action IS NOT NULL;
commit;
SET GLOBAL gtid_slave_pos = gtid;
EXECUTE rds_set_master;
DEALLOCATE PREPARE rds_set_master;
INSERT INTO mysql.rds_history(called_by_user, action, mysql_version, master_host, master_port, master_user, master_gtid, master_ssl)
VALUES (v_called_by_user,'set master', v_mysql_version, TRIM(BOTH FROM host), port, TRIM(BOTH FROM USER), TRIM(BOTH FROM gtid), enable_ssl_encryption);
commit;
 END IF;
SET @@sql_log_bin=sql_logging;
END;
