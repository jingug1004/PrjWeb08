CREATE TRIGGER T_GW_EA_APPROVAL
AFTER UPDATE
  ON GW_EA_APPROVAL
FOR EACH ROW
  DECLARE
        ll_cnt NUMBER;  --결재자의 정보가 시행부서 정보에 있는 건
BEGIN
        /*  CHOE 20151211
        결재자와 시행부서의 인원이 증복 등록된 경우 
        결재만 진행하여도 시행부서의 내용은 읽은 것으로 변경하는 트리거 
        
        20160212 사용하지 않음
        결재요청시(시행부서 인원 등록 newReport.xml - insertImplDeptEmp) 에서 중복으로 등록된 경우는에는 시행부서 정보는 읽을 처리하는 것으로 변경
        요청 - 윤홍주
        
        */

        IF UPDATING('READ_DT') THEN
                
                /*결재자가의 정보가 변경 될때 시행부서에 같은 정보가 있는지 확인 한다.*/
                ll_cnt := 0;
                SELECT COUNT(*)
                INTO ll_cnt
                FROM GW_EA_IMPL_DEPT_EMP A
                WHERE A.APPROVAL_SEQ = :OLD.APPROVAL_SEQ 
                AND A.EMP_NO = :OLD.EMP_NO
                ;
                        
                IF ll_cnt = 1 THEN
                        UPDATE GW_EA_IMPL_DEPT_EMP A
                        SET A.READ_DT  = :NEW.READ_DT
                        ,A.READ_YN = 'Y'            
                        WHERE A.APPROVAL_SEQ = :OLD.APPROVAL_SEQ 
                        AND A.EMP_NO = :OLD.EMP_NO
                        ;
                END IF;
        END IF;

END T_GW_EA_APPROVAL;
/
