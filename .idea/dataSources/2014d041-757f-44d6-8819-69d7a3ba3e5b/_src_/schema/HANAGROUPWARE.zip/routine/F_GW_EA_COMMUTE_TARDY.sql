CREATE FUNCTION               F_GW_EA_COMMUTE_TARDY (
    I_EMP_NO IN VARCHAR2,
    I_YEAR IN VARCHAR2
) 
RETURN VARCHAR2 IS
        
        V_RETURN VARCHAR2(10);  --결과값 전달
        V_CNT NUMBER;  --결과값 전달

BEGIN
       /*-------------------------------------------------------------------
       DESCRIPTION
       CHOE 20161118
       
       그룹웨어에서 사원번호로 년도에 지각일을 알고자 할때 사용한다.       
       -------------------------------------------------------------------*/
        
        V_RETURN := '';  --초기값
        V_CNT := 0;
        SELECT COUNT(*)
        INTO V_CNT
        FROM GW_EA_APPROVAL_MASTER A 
        ,GW_EA_COMMUTE B
        WHERE A.APPROVAL_SEQ = B.APPROVAL_SEQ
        AND A.CREATE_NO = I_EMP_NO
        AND TO_CHAR(REQ_DT, 'YYYY') = I_YEAR
        AND B.LATE_TM IS NOT NULL  --지각계만 
        AND A.STATE = 'E02004'  --완료된 문서만  
        GROUP BY A.CREATE_NO
        ;
       
        IF V_CNT = 0 THEN
                V_RETURN := '0';
        ELSE
                V_RETURN := TO_CHAR(V_CNT);
        END IF;
        
        RETURN(V_RETURN);
EXCEPTION
        WHEN NO_DATA_FOUND THEN
                V_RETURN := '0';
                RETURN V_RETURN;
        WHEN OTHERS THEN
                V_RETURN := '0';
                RETURN V_RETURN;       
END F_GW_EA_COMMUTE_TARDY;
/
