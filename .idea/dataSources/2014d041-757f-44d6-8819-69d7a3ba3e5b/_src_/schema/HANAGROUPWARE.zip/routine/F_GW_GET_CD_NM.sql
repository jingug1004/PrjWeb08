CREATE FUNCTION F_GW_GET_CD_NM
(CODE CHAR)   
   RETURN VARCHAR IS   
      
   CD_NM VARCHAR(500);
BEGIN           
    SELECT CD_NM 
    INTO CD_NM
      FROM GW_CO_CODE
     WHERE CD = CODE;         
            
    RETURN CD_NM;    
END;

/
