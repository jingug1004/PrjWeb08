CREATE FUNCTION               F_GW_EA_APPROVAL_EMP (I_EMP_NO IN VARCHAR2
                                                                                                                          ,I_APPROVAL_SEQ IN VARCHAR2
) 
RETURN VARCHAR2 IS
        
        V_RETURN VARCHAR2(10);  --결과값 전달
        V_CNT NUMBER;  --결과값 전달

BEGIN
       /*-------------------------------------------------------------------
       DESCRIPTION
       CHOE 20160212
       
       결재자와 시행부서에 같은 인원이 등록된 경우인지 찾아오는 함수
       I_EMP_NO - 사원정보
       I_APPROVAL_SEQ - 문서번호
       
       V_RETURN - N 시행부서 정보에 읽지 않음으로 등록한다.
                          Y 읽음으로  등록한다.
       -------------------------------------------------------------------*/
        
       V_RETURN := 'N';  --초기값 : 읽지 않음
       V_CNT := 0;
        SELECT COUNT(*)
        INTO V_CNT
        FROM GW_EA_APPROVAL APPR
        WHERE APPR.EMP_NO = I_EMP_NO 
        AND APPR.APPROVAL_SEQ = I_APPROVAL_SEQ
        ;    
        
        IF V_CNT = 1 THEN
                V_RETURN := 'Y';
        END IF;
        
        RETURN(V_RETURN);
EXCEPTION
        WHEN NO_DATA_FOUND THEN
                V_RETURN := 'N';
                RETURN V_RETURN;
        WHEN OTHERS THEN
                V_RETURN := 'N';
                RETURN V_RETURN;       
END F_GW_EA_APPROVAL_EMP;
/
