CREATE PROCEDURE               P_GW_EA_DOCU_INSERT IS

BEGIN
        /*CHOE 20150417 등록된 부서에 대해서 문서 유형 등록*/
        FOR V1 IN (
                SELECT DEPT_CD 
                FROM HANAHR.HR_CO_DEPART_0
                WHERE USE_YN = 'Y'       
                AND DEPT_CD NOT IN ('0007','0417','0418','0419')   --144건 
        ) 
        LOOP
                INSERT INTO  HANAGROUPWARE.GW_EA_DOCU 
                VALUES (SEQ_GW_EA_DOCU.NEXTVAL,V1.DEPT_CD,'원부자재 납품확인서' ,'E01016','N','N','원부자재 납품확인서',SYSDATE,'9999999' ,'','','Y');                                    
        END LOOP;
        
EXCEPTION
        WHEN OTHERS THEN
        RAISE_APPLICATION_ERROR(-20001,'/'||sqlerrm);        
END P_GW_EA_DOCU_INSERT;
/
