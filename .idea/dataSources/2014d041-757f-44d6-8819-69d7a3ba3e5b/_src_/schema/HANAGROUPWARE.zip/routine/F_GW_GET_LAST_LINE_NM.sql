CREATE FUNCTION               F_GW_GET_LAST_LINE_NM
(SAPPROVAL_SEQ CHAR)   
   RETURN VARCHAR IS   
      
   EMP_NAME VARCHAR(500);
BEGIN        
   

       SELECT EMP_NO||'^'||EMP_NAME
         INTO EMP_NAME
          FROM (
                SELECT ROWNUM RNUM,TB.EMP_NO,TB.EMP_NAME
                  FROM (
                        SELECT TA.EMP_NO, TB.EMPNAME EMP_NAME
                          FROM GW_EA_APPROVAL TA ,ORAGMP.CMEMPM TB
                         WHERE TA.APPROVAL_SEQ = SAPPROVAL_SEQ
                           AND TA.EMP_NO = TB.EMPCODE
                           AND TA.APPROVAL_DT IS NOT NULL
                         ORDER BY TA.APPROVAL_DT DESC
                        /*SELECT TA.EMP_NO, TB.EMP_KO_NM EMP_NAME
                          FROM GW_EA_APPROVAL TA, HANAHR.HR_HC_EMPBAS_0 TB
                         WHERE TA.APPROVAL_SEQ = SAPPROVAL_SEQ
                           AND TA.EMP_NO = TB.EMP_NO
                           AND TA.APPROVAL_DT IS NOT NULL
                         ORDER BY TA.APPROVAL_DT DESC*/ 
                       ) TB
                )
         WHERE RNUM = '1';   
            
    RETURN EMP_NAME;    
END;
/
