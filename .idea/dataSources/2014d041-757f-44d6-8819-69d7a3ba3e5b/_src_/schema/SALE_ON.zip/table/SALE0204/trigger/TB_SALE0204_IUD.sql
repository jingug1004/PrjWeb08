CREATE TRIGGER TB_SALE0204_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0204
FOR EACH ROW
  DECLARE
        T_UPDATE_CHK   NUMBER;
        메시지         varchar2(1000) ;
        V_SFA_SALES_CODE_CNT NUMBER;
        V_CNT  NUMBER;
     
BEGIN
        /* 메시지 처리 준비 */
        IF INSERTING THEN
                메시지 := '거래처관리(SALE0204) 추가 불가 !!  ' ;
        ELSIF UPDATING THEN
                메시지 := '거래처관리(SALE0204) 수정 불가 !!  ' ;
        ELSE
                메시지 := '거래처관리(SALE0204) 삭제 불가 !!  ' ;
        END IF ;

      /*
        IF INSERTING THEN 
                IF :NEW.AMT < :NEW.DC_AMT THEN            
                       --insert into SFA_SP_CALLED_HIST values ('TB_SALE0204_IUD','INBSERT',sysdate,'NEW.GUMAE_NO: '||:NEW.GUMAE_NO||' /NEW.QTY :'||:NEW.QTY||' /NEW.AMT:'||:NEW.AMT||' /NEW.DC_DANGA:'||:NEW.DC_DANGA||' /NEW.DC_AMT:'||:NEW.DC_AMT);
                       --COMMIT;
                       --RAISE_APPLICATION_ERROR( -20001, '할인금액이 공급가보다 큰 경우가 발생했습니다. 하나제약으로 연락 바랍니다.' ) ;
               END IF;
        END IF;      
        
        
        IF UPDATING THEN
                IF :NEW.AMT < :NEW.DC_AMT THEN            
                      -- insert into SFA_SP_CALLED_HIST values ('TB_SALE0204_IUD','UPDATE',sysdate,'NEW.GUMAE_NO: '||:NEW.GUMAE_NO||' /NEW.QTY :'||:NEW.QTY||' /NEW.AMT:'||:NEW.AMT||' /NEW.DC_DANGA:'||:NEW.DC_DANGA||' /NEW.DC_AMT:'||:NEW.DC_AMT);
                      -- COMMIT;
                       --RAISE_APPLICATION_ERROR( -20001, '할인금액이 공급가보다 큰 경우가 발생했습니다. 하나제약으로 연락 바랍니다.' ) ;
                END IF;
        END IF;
        */

END TB_SALE0204_IUD;
/
