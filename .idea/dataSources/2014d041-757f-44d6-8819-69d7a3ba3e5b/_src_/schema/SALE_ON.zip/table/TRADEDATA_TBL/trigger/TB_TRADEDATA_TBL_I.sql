CREATE TRIGGER TB_TRADEDATA_TBL_I
BEFORE INSERT
  ON TRADEDATA_TBL
FOR EACH ROW
  DECLARE 
 
   /*
   2017.12.15 KTA
   가상계좌수금이 넘어오면 tradedata_vtpms 로 자료를 복사함. ORAGMP.col_Sal_Day_Conversion 프로시져에서 tradedata_vtpms TALBE 자료를 5 분마다 가져감 
   VTPMS 그랜드 오픈 전 운영에서 일주일 테스트필요 하여 이 트리거 생성함 
   VTPMS 그랜드 오픈 후에도 기존ERP로 가상계좌가 넘어가도록 한다. 일정기간 유지 예정임
   */

   p_plantcode          ORAGMP.SLCOLM.PLANTCODE%TYPE;
   
BEGIN
  
   IF INSERTING THEN
 
        insert into tradedata_vtpms
               (
                 DEAL_CODE
                ,COMP_CODE
                ,BANK_CD
                ,MESS_CODE
                ,JOB_DIFF
                ,TRAN_NUMB
                ,SEQ_NO
                ,TRAN_DATE
                ,TRAN_TIME
                ,STAN_RESP_CODE
                ,BANK_RESP_CODE
                ,INQU_DATE
                ,INQU_NO
                ,BANK_SEQ_NO
                ,BANK_CD_3
                ,FILLER_1
                ,ACCO_NUMB
                ,COMP_CNT
                ,DEAL_SELE
                ,IN_BANK_CD
                ,TOTAL_AMT
                ,BALA_MONE
                ,GIRO
                ,RECE_NM
                ,CHEC_NO
                ,CASH
                ,OUT_BANK_CHEC
                ,ETC_CHEC
                ,CMS_NO
                ,DEAL_STAR_DATE
                ,DEAL_STAR_TIME
                ,ACCO_SERI_NO
                ,IN_BANK_CD_3
                ,GIRO_3
                ,FILLER_2
               ,JUNPYO_NO
               )
        values (
                 :NEW.DEAL_CODE
                ,:NEW.COMP_CODE
                ,:NEW.BANK_CD
                ,:NEW.MESS_CODE
                ,:NEW.JOB_DIFF
                ,:NEW.TRAN_NUMB
                ,:NEW.SEQ_NO
                ,:NEW.TRAN_DATE
                ,:NEW.TRAN_TIME
                ,:NEW.STAN_RESP_CODE
                ,:NEW.BANK_RESP_CODE
                ,:NEW.INQU_DATE
                ,:NEW.INQU_NO
                ,:NEW.BANK_SEQ_NO
                ,:NEW.BANK_CD_3
                ,:NEW.FILLER_1
                ,:NEW.ACCO_NUMB
                ,:NEW.COMP_CNT
                ,:NEW.DEAL_SELE
                ,:NEW.IN_BANK_CD
                ,:NEW.TOTAL_AMT
                ,:NEW.BALA_MONE
                ,:NEW.GIRO
                ,:NEW.RECE_NM
                ,:NEW.CHEC_NO
                ,:NEW.CASH
                ,:NEW.OUT_BANK_CHEC
                ,:NEW.ETC_CHEC
                ,:NEW.CMS_NO
                ,:NEW.DEAL_STAR_DATE
                ,:NEW.DEAL_STAR_TIME
                ,:NEW.ACCO_SERI_NO
                ,:NEW.IN_BANK_CD_3
                ,:NEW.GIRO_3
                ,:NEW.FILLER_2
                ,:NEW.JUNPYO_NO
                ); 
    
   END IF; 

END tb_TRADEDATA_TBL_i;
/
