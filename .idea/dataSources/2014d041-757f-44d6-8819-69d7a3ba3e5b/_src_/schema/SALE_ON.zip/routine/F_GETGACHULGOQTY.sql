CREATE function         f_getgachulgoqty
                          (in_item_id       IN  VARCHAR2         -- 제품코드
                           )  RETURN number 
AS
   v_cnt number; 
   
/*----------------------------------------------------------------------------*
 기능 :  제품코드를 받아서 현 가출고 수량 리턴 
 작성자:김태안
 작성일:2016.10.17 
 수정기록
 참고사항: 
 *----------------------------------------------------------------------------*/          


BEGIN
    
    
    v_cnt := 0;      
 
    
   --제품코있없으면 주문번호와 제품코드로 금액오류 체크  
             
    select sum(b.qty)
      into v_cnt
      from sale_on.sale0203 a
           ,sale_on.sale0204 b
     where a.gumae_no = b.gumae_no 
       and a.accept_yn  = 'Y'
       and a.receipt_gb = '1'   
       and a.wiban_order_conf_yn <> '2'
       and b.item_id    =  in_item_id;
 
            
      return NVL(v_cnt,0);

END;
/
