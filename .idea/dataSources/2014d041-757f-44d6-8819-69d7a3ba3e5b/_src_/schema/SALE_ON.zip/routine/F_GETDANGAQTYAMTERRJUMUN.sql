CREATE function         f_getDangaQtyAmtErrJumun
                          (in_gumae_no       IN  VARCHAR2,         -- 주문번호
                           in_item_id       IN  VARCHAR2         -- 제품코드
                           )  RETURN varchar2 
AS
   v_cnt number; 
   
/*----------------------------------------------------------------------------*
 기능:단가 * 수량= 금액  이 잘못된 자료인지 아닌지 체크하는 로직 
 작성자:김태안
 작성일:2016.10.06 
 수정기록
 참고사항: 
 *----------------------------------------------------------------------------*/          


BEGIN
    
    
    v_cnt := 0;      

      
    if in_item_id is not null then
    
       --제품코있없으면 주문번호와 제품코드로 금액오류 체크  
             
        SELECT COUNT (*)
          INTO v_cnt
          FROM (SELECT a.item_id
                  FROM sale0204 a, sale0203 b
                 WHERE     a.gumae_no = b.gumae_no
                       AND a.gumae_no = in_gumae_no
                       AND a.item_id = in_item_id
                       AND a.qty * a.danga <> a.amt
                       AND b.cust_id LIKE '11%'
                UNION
                SELECT a.item_id
                  FROM sale0204 a, sale0203 b
                 WHERE     a.gumae_no = b.gumae_no
                       AND a.gumae_no = in_gumae_no
                       AND a.item_id = in_item_id
                       AND a.qty * a.danga <> a.amt + a.vat
                       AND SUBSTR (b.cust_id, 1, 1) IN ('3', '4')
              );  
               
    else
             
       --제품코드없으면 주문번호만으로 체크  
        SELECT COUNT (*)
          INTO v_cnt
          FROM (SELECT a.item_id
                  FROM sale0204 a, sale0203 b
                 WHERE     a.gumae_no = b.gumae_no
                       AND a.gumae_no = in_gumae_no
                       AND a.qty * a.danga <> a.amt
                       AND b.cust_id LIKE '11%'
                       AND ROWNUM = 1
                UNION
                SELECT a.item_id
                  FROM sale0204 a, sale0203 b
                 WHERE     a.gumae_no = b.gumae_no
                       AND a.gumae_no = in_gumae_no
                       AND a.qty * a.danga <> a.amt + a.vat
                       AND SUBSTR (b.cust_id, 1, 1) IN ('3', '4')
                       AND ROWNUM = 1
              );
                
    end if;  
 
           
    if v_cnt = 0 then
      return  '정상';
    else
      return  '오류';
    end if;   

END;
/
