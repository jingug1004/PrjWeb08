CREATE function         f_getgongjangqty
                          (in_item_id       IN  VARCHAR2         -- 제품코드
                           )  RETURN number 
AS
   v_cnt number; 
   
/*----------------------------------------------------------------------------*
 기능 :  제품코드를 받아서 공장재고 리턴
 작성자:김태안
 작성일:2016.10.17 
 수정기록
 참고사항: 
 *----------------------------------------------------------------------------*/          


BEGIN 
    
    v_cnt := 0;       
      
    select NVL(sum(nvl(ipgo_qtys,0) - nvl(chulgo_qtys,0) - nvl(chulgo_qtyst,0) + nvl(banpum_qtys,0)),0) 
      into v_cnt
        from sale0305_1 
       where store_loc = '01'  
         and item_id = in_item_id
    ;
 
            
      return v_cnt;

END;
/
