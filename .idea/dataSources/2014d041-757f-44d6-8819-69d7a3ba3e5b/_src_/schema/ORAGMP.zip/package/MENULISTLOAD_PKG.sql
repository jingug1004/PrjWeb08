CREATE PACKAGE MENULISTLOAD_PKG AS
    TYPE T_CURSOR IS REF CURSOR;
    PROCEDURE SPMENULISTLOAD (

        p_div                                IN varchar2 := null,

        p_empcode                        IN varchar2 := null,
        p_parentmenu                IN varchar2 := null,
        p_plantcode                    IN varchar2 := null,
        p_deptcode                    IN varchar2 := null,

        p_userid                        IN varchar2 := null,
        p_reasondiv                    IN varchar2 := null,
        p_reasontext                IN varchar2 := null,

    message                     IN OUT varchar2,
    IO_CURSOR                   IN OUT T_CURSOR
    );

END MENULISTLOAD_PKG;
/
