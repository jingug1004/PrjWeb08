CREATE PACKAGE LOGINPOPUP_PKG AS

PROCEDURE SPLOGINPOPUP
(
    p_div           IN VARCHAR2 := '',
    p_plantcode     IN VARCHAR2 := '',
    p_empcode       IN VARCHAR2 := '',
    p_deptcode      IN VARCHAR2 := '',

    p_userid        IN VARCHAR2 := '',
    p_reasondiv     IN VARCHAR2 := '',
    p_reasontext    IN VARCHAR2 := '',

    message         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
);

END LOGINPOPUP_PKG;
/
