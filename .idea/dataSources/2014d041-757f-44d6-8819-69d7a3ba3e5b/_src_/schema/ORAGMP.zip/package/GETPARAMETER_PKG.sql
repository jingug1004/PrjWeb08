CREATE PACKAGE GETPARAMETER_PKG
AS
	TYPE T_CURSOR IS REF CURSOR;

	PROCEDURE SPGETPARAMETER(
		p_div			   IN	  VARCHAR2 := '',
		p_parametercode    IN	  VARCHAR2 := '',
		p_userid		   IN	  VARCHAR2 := '',
		p_reasondiv 	   IN	  VARCHAR2 := '',
		p_reasontext	   IN	  VARCHAR2 := '',
		MESSAGE 			  OUT VARCHAR2,
		IO_CURSOR			  OUT TYPES.DATASET
	);
END GETPARAMETER_PKG;
/
