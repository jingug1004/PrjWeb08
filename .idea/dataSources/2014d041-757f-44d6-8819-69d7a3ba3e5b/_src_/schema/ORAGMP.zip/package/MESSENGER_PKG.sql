CREATE PACKAGE        MESSENGER_PKG
AS
	PROCEDURE SPMESSENGER(
		p_div			IN	   VARCHAR2 := NULL,
		p_plantcode 	IN	   VARCHAR2 := NULL,
		p_empcode		IN	   VARCHAR2 := NULL,
		p_nickname		IN	   VARCHAR2 := NULL,
		p_ip			IN	   VARCHAR2 := NULL,
		p_loginstat 	IN	   VARCHAR2 := NULL,
		p_userid		IN	   VARCHAR2 := NULL,
		p_reasondiv 	IN	   VARCHAR2 := NULL,
		p_reasontext	IN	   VARCHAR2 := NULL,
		MESSAGE 		IN OUT VARCHAR2,
		IO_CURSOR		IN OUT TYPES.DataSet
	);
END MESSENGER_PKG;
/
