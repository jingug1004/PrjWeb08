CREATE PACKAGE BODY MESSENGERMSGBOX_PKG
AS
   PROCEDURE SPMESSENGERMSGBOX (p_div          IN     VARCHAR2 := '',
                                p_seq          IN     INT := 0,
                                p_sender       IN     VARCHAR2 := '',
                                p_recv         IN     VARCHAR2 := '',
                                p_msg          IN     VARCHAR2 := '',
                                p_senddt       IN     VARCHAR2 := NULL,
                                p_empcode      IN     VARCHAR2 := '',
                                p_readyn       IN     VARCHAR2 := '',
                                p_priority     IN     VARCHAR2 := NULL,
                                p_gb           IN     VARCHAR2 := '',
                                p_fileid1      IN     INT := NULL,
                                p_fileid2      IN     INT := NULL,
                                p_fileid3      IN     INT := NULL,
                                p_fileid4      IN     INT := NULL,
                                p_fileid5      IN     INT := NULL,
                                p_filenames    IN     VARCHAR2 := '',
                                p_filedata     IN     BLOB := NULL,
                                p_startdate    IN     VARCHAR2 := NULL,
                                p_enddate      IN     VARCHAR2 := NULL,
                                p_userid       IN     VARCHAR2 := '',
                                p_reasondiv    IN     VARCHAR2 := '',
                                p_reasontext   IN     VARCHAR2 := '',
                                MESSAGE        IN OUT VARCHAR2,
                                IO_CURSOR      IN OUT T_CURSOR)

   IS
      V_CURSOR     T_CURSOR;
      v_seq        INT;
      v_priority   VARCHAR2 (100);
   BEGIN
      DBMS_OUTPUT.PUT_LINE ('===== spGetCommon PROCEDURE START =====');
      MESSAGE := '데이터 확인';

      IF (p_div = 'S')
      THEN
         OPEN V_CURSOR FOR
              SELECT seq,
                     sender,
                     CASE WHEN sender = p_empcode THEN '나' ELSE s.empname END
                        AS sname,
                     recv,
                     CASE WHEN recv = p_empcode THEN '나' ELSE r.empname END
                        AS rname,
                     msg,
                     senddt,
                     readyn,
                     sdelete,
                     rdelete,
                     CASE WHEN recv = p_empcode THEN A.priority ELSE 'B' END
                        AS priority                                      --중요도
                                   ,
                     CASE
                        WHEN sender = p_empcode AND recv = p_empcode THEN NULL
                        WHEN sender = p_empcode THEN 'S'
                        WHEN recv = p_empcode THEN 'R'
                     END
                        AS senddiv,
                     CASE WHEN A.fileid1 IS NULL THEN 'N' ELSE 'Y' END
                        AS fileyn
                FROM SYSMESSENGERMSGBOX A
                     LEFT OUTER JOIN CMEMPM s ON A.sender = s.empcode
                     LEFT OUTER JOIN CMEMPM r ON A.recv = r.empcode
               WHERE     (   (recv = p_empcode AND rdelete != 'Y')
                          OR (sender = p_empcode AND sdelete != 'Y'))
                     AND TO_CHAR (senddt, 'yyyy-mm-dd') BETWEEN p_startdate
                                                            AND p_enddate
                     AND readyn =
                            CASE p_readyn
                               WHEN '1' THEN 'N'
                               WHEN '2' THEN 'Y'
                               ELSE readyn
                            END
                     AND NVL (priority, ' ') LIKE p_priority
                     AND (   (p_gb = '0')
                          OR ( (p_gb = '1') AND (recv = p_empcode))
                          OR ( (p_gb = '2') AND (sender = p_empcode)))
            ORDER BY seq DESC;
      ELSIF (p_div = 'S2')
      THEN
         OPEN V_CURSOR FOR
              --컬럼순서 바꾸지말것.
              SELECT empcode,
                     deptcode,
                     empname,
                     deptname
                FROM vnEMP
            ORDER BY deptcode;
      ELSIF (p_div = 'S3')
      THEN
         SELECT MIN (seq)
           INTO v_seq
           FROM SYSMESSENGERMSGBOX
          WHERE sender = p_sender AND recv = p_empcode AND senddt = p_senddt;


         OPEN V_CURSOR FOR
            SELECT f.filenames, f.fileid
              FROM SYSMESSENGERMSGBOX A
                   INNER JOIN SYSMESSENGERFILE f ON A.fileid1 = f.fileid
             WHERE seq = v_seq
            UNION
            SELECT f.filenames, f.fileid
              FROM SYSMESSENGERMSGBOX A
                   INNER JOIN SYSMESSENGERFILE f ON A.fileid2 = f.fileid
             WHERE seq = v_seq
            UNION
            SELECT f.filenames, f.fileid
              FROM SYSMESSENGERMSGBOX A
                   INNER JOIN SYSMESSENGERFILE f ON A.fileid3 = f.fileid
             WHERE seq = v_seq
            UNION
            SELECT f.filenames, f.fileid
              FROM SYSMESSENGERMSGBOX A
                   INNER JOIN SYSMESSENGERFILE f ON A.fileid4 = f.fileid
             WHERE seq = v_seq
            UNION
            SELECT f.filenames, f.fileid
              FROM SYSMESSENGERMSGBOX A
                   INNER JOIN SYSMESSENGERFILE f ON A.fileid5 = f.fileid
             WHERE seq = v_seq;
      ELSIF (p_div = 'I')
      THEN
         v_priority := 'B';

         IF (SUBSTR (p_msg, 1, 3) = '※ [')
         THEN
            v_priority := 'C';

            INSERT INTO SYSMESSENGERMSGBOX (sender,
                                         recv,
                                         msg,
                                         senddt,
                                         readyn,
                                         sdelete,
                                         rdelete,
                                         priority,
                                         fileid1,
                                         fileid2,
                                         fileid3,
                                         fileid4,
                                         fileid5)
                 VALUES (p_sender,
                         NVL(p_recv,p_sender) ,
                         p_msg,
                         p_senddt                                    --절대 수정금지
                                 ,
                         'N',
                         'N',
                         'N',
                         v_priority,
                         p_fileid1,
                         p_fileid2,
                         p_fileid3,
                         p_fileid4,
                         p_fileid5);
         END IF;
      ELSIF (p_div = 'U')
      THEN
         UPDATE SYSMESSENGERMSGBOX
            SET readyn = 'Y'
          WHERE sender = p_sender AND recv = p_empcode AND TO_CHAR(senddt,'YYYY-MM-DD') = p_senddt;
      ELSIF (p_div = 'U2')
      THEN
         UPDATE SYSMESSENGERMSGBOX
            SET readyn = p_readyn
          WHERE seq = p_seq;
      ELSIF (p_div = 'U3')
      THEN
         UPDATE SYSMESSENGERMSGBOX
            SET priority = p_priority
          WHERE seq = p_seq;
      ELSIF (p_div = 'D')
      THEN
         UPDATE SYSMESSENGERMSGBOX
            SET sdelete = 'Y'
          WHERE seq = p_seq;
      ELSIF (p_div = 'D2')
      THEN
         UPDATE SYSMESSENGERMSGBOX
            SET rdelete = 'Y', readyn = 'Y'
          WHERE seq = p_seq;
      --첨부파일저장
      ELSIF (p_div = 'IF')
      THEN
         INSERT INTO SYSMESSENGERFILE (filenames, filedata)
              VALUES (p_filenames, p_filedata);

         MESSAGE := SQL%ROWCOUNT;
      --첨부파일열기
      ELSIF (p_div = 'SF')
      THEN
         OPEN V_CURSOR FOR
            SELECT filenames, filedata
              FROM SYSMESSENGERFILE
             WHERE fileid = p_fileid1;
      END IF;

      IF (V_CURSOR IS NULL)
      THEN
         OPEN V_CURSOR FOR SELECT 1 FROM DUAL;
      END IF;

      IO_CURSOR := V_CURSOR;

      DBMS_OUTPUT.PUT_LINE ('===== spGetCommon PROCEDURE END =====');
   END SPMESSENGERMSGBOX;
END MESSENGERMSGBOX_PKG;
/
