CREATE PACKAGE BODY LOGINACCESS_PKG
AS
	PROCEDURE SPLOGINACCESS(
		p_div				 IN 	VARCHAR2 := '',
		p_startdate 		 IN 	VARCHAR2 := '',
		p_enddate			 IN 	VARCHAR2 := '',
		p_empcode			 IN 	VARCHAR2 := '',
		p_locationno		 IN 	VARCHAR2 := '',
		p_programcode		 IN 	VARCHAR2 := '',
		p_loginid			 IN 	INT := 0,
		p_programaccessid	 IN 	INT := 0,
		p_logindt			 IN 	DATE := NULL,
		p_logoutdt			 IN 	DATE := NULL,
		p_errordiv			 IN 	VARCHAR2 := '',
		p_userid			 IN 	VARCHAR2 := '',
		p_reasondiv 		 IN 	VARCHAR2 := '',
		p_reasontext		 IN 	VARCHAR2 := '',
		MESSAGE 			 IN OUT VARCHAR2,
		IO_CURSOR			 IN OUT T_CURSOR,
		IO_CURSOR2			 IN OUT T_CURSOR
	)
	IS
		V_CURSOR	T_CURSOR;
		V_CURSOR2	T_CURSOR;

		p_check 	VARCHAR2(5);
	BEGIN
		DBMS_OUTPUT.PUT_LINE('===== spGetCommon PROCEDURE START =====');
		MESSAGE := '데이터 확인';

		IF (UPPER(P_DIV) = 'S')
		THEN
			OPEN V_CURSOR FOR
				SELECT	 A.empcode,
						 b.empname,
						 --                    a.locationno,
						 --                    d.workroomname as locationnoname,
						 TO_CHAR(A.logindt, 'yyyy-mm-dd hh24:mi:ss') AS logindt,
						 TO_CHAR(A.logoutdt, 'yyyy-mm-dd hh24:mi:ss') AS logoutdt,
						 fnCalcTime('H', datediff('second', A.logindt, A.logoutdt)) AS usehour,
						 fnCalcTime('M', datediff('second', A.logindt, A.logoutdt)) AS useminute,
						 fnCalcTime('S', datediff('second', A.logindt, A.logoutdt)) AS usesecond,
						 CASE WHEN UPPER(A.empcode) = 'GMPIT' AND successyn = 'Y' THEN '' ELSE TRIM(A.hostname) END AS hostname																																									  --관리저접속정보는 비공개
																														,
						 CASE WHEN UPPER(A.empcode) = 'GMPIT' AND successyn = 'Y' THEN '' ELSE A.netaddress END AS netaddress																																										  --관리저접속정보는 비공개
																													  ,
						 CASE WHEN UPPER(A.empcode) = 'GMPIT' AND successyn = 'Y' THEN '' ELSE A.ipaddress END AS ipaddress																																										  --관리저접속정보는 비공개
																													,
						 CASE WHEN successyn = 'Y' THEN '성공' ELSE '실패' END AS successyn
				FROM	 LoginAccess A INNER JOIN CMEMPM b ON A.empcode = b.empcode
				--                    inner join ComputerLocationManage c
				--                        on a.locationno = c.locationno
				--                    inner join WorkroomMaster d
				--                        on c.objcode = d.workroomcode

				WHERE	 (A.empcode LIKE p_empcode || '%' OR b.empname LIKE p_empcode || '%') --and a.locationno like p_locationno || '%'
						 AND A.logindt BETWEEN TO_DATE(p_startdate || ' 00:00:00', 'yyyy-mm-dd hh24:mi:ss') AND TO_DATE(p_enddate || ' 23:59:59', 'yyyy-mm-dd hh24:mi:ss')
				ORDER BY A.logindt DESC;
		ELSIF (UPPER(P_DIV) = 'S2')
		THEN
			OPEN V_CURSOR FOR
				SELECT	 E.programname,
						 A.empcode,
						 b.empname,
						 TO_CHAR(A.logindt, 'yyyy-mm-dd hh24:mi:ss') AS logindt,
						 TO_CHAR(A.logoutdt, 'yyyy-mm-dd hh24:mi:ss') AS logoutdt,
						 fnCalcTime('H', datediff('second', A.logindt, A.logoutdt)) AS usehour,
						 fnCalcTime('M', datediff('second', A.logindt, A.logoutdt)) AS useminute,
						 fnCalcTime('S', datediff('second', A.logindt, A.logoutdt)) AS usesecond,
						 CASE WHEN UPPER(A.empcode) = 'GMPIT' THEN '' ELSE TRIM(A.hostname) END AS hostname																																														  --관리저접속정보는 비공개
																									,
						 CASE WHEN UPPER(A.empcode) = 'GMPIT' THEN '' ELSE A.netaddress END AS netaddress																																															  --관리저접속정보는 비공개
																								  ,
						 CASE WHEN UPPER(A.empcode) = 'GMPIT' THEN '' ELSE A.ipaddress END AS ipaddress																																															  --관리저접속정보는 비공개
				FROM	 ProgramAccess A
						 INNER JOIN CMEMPM b ON A.empcode = b.empcode
						 INNER JOIN ProgramManage E ON A.programcode = E.programcode
				WHERE	 (A.empcode LIKE p_empcode || '%' OR b.empname LIKE p_empcode || '%') AND A.logindt BETWEEN TO_DATE(p_startdate || ' 00:00:00', 'yyyy-mm-dd hh24:mi:ss') AND TO_DATE(p_enddate || ' 23:59:59', 'yyyy-mm-dd hh24:mi:ss') AND A.programcode LIKE p_programcode || '%'
				ORDER BY A.empcode ASC, A.locationno ASC, A.logindt DESC;
		ELSIF (UPPER(P_DIV) = 'I')
		THEN
			INSERT INTO LoginAccess(loginid,
									empcode,
									locationno,
									logindt,
									logoutdt,
									hostname,
									netaddress,
									ipaddress,
									successyn)

				SELECT LoginAccess_SEQ.NEXTVAL,
					   p_empcode,
					   p_locationno,
					   SYSDATE,
					   p_logoutdt,
					   SYS_CONTEXT('USERENV', 'HOST') AS hostname,
					   NULL AS net_address,
					   SYS_CONTEXT('USERENV', 'IP_ADDRESS') AS client_net_address,
					   'Y' AS successyn
				FROM   DUAL;


			SELECT MAX(loginid)
			INTO   MESSAGE
			FROM   LoginAccess
			WHERE  empcode = p_empcode;

			--실패횟수를 초기화한다(080314추가)

			UPDATE electronicsign
			SET    failednum = 0
			--, TEMPSIGNYN = 'u'
			--, INPUTDATE = SYSDATE
			--, CHANGEDATE = SYSDATE
			WHERE  empcode = p_empcode;
		ELSIF (UPPER(P_DIV) = 'IP')
		THEN
			INSERT INTO ProgramAccess(empcode,
									  locationno,
									  programcode,
									  logindt																																																													-- ,logoutdt
											 ,
									  hostname,
									  netaddress,
									  ipaddress,
									  PROGRAMACCESSID)
				SELECT p_empcode,
					   p_locationno,
					   p_programcode,
					   SYSDATE,																																																																  -- ,p_logoutdt
					   SYS_CONTEXT('USERENV', 'HOST') AS hostname,
					   NULL AS net_address,
					   SYS_CONTEXT('USERENV', 'IP_ADDRESS') AS client_net_address,
					   (SELECT COUNT(PROGRAMACCESSID) + 1 FROM ProgramAccess) AS PROGRAMACCESSID
				FROM   DUAL;

			SELECT TO_CHAR(MAX(PROGRAMACCESSID)) INTO MESSAGE FROM ProgramAccess;
		ELSIF (UPPER(P_DIV) = 'U')
		THEN
			UPDATE LoginAccess
			SET    logoutdt = SYSDATE
			WHERE  empcode = p_empcode AND loginid = p_loginid;
		ELSIF (UPPER(P_DIV) = 'UP')
		THEN
			UPDATE ProgramAccess
			SET    logoutdt = SYSDATE
			WHERE  programaccessid = p_programaccessid;
		ELSIF (UPPER(P_DIV) = 'U1')
		THEN
			UPDATE LoginAccess
			SET    logoutdt = p_logoutdt
			--,errordiv = p_errordiv

			WHERE  empcode = p_empcode AND loginid != p_loginid;
		ELSIF (UPPER(P_DIV) = 'U2')
		THEN
			UPDATE ProgramAccess
			SET    logoutdt = p_logoutdt
			--,errordiv = p_errordiv

			WHERE  programaccessid = p_programaccessid;
		ELSIF (UPPER(P_DIV) = 'S3')
		THEN
			SELECT value1
			INTO   p_check
			FROM   parametermanage
			WHERE  UPPER(parametercode) = 'LOGOUTFIX';


			IF (NVL(p_check, ' ') = 'Y' AND UPPER(p_empcode) != 'GMPIT')
			THEN
				OPEN V_CURSOR FOR
					SELECT	 loginid, logindt
					FROM	 loginaccess
					WHERE	 empcode = p_empcode AND logoutdt IS NULL AND loginid != p_loginid AND ROWNUM <= 1
					ORDER BY logindt DESC;

				--Fetch first 1 rows only;


				OPEN V_CURSOR2 FOR
					SELECT	 A.programaccessid, '프로그램  : ' || TO_CHAR(b.programname) || TO_CHAR(A.logindt, 'YYYY-MM-DD HH24:MI:SS') AS displaytext
					FROM	 ProgramAccess A INNER JOIN ProgramManage b ON A.programcode = b.programcode
					WHERE	 A.empcode = p_empcode AND A.logoutdt IS NULL
					ORDER BY A.logindt;
			ELSIF (NVL(p_check, ' ') = 'N')
			THEN
				OPEN V_CURSOR FOR SELECT '' AS loginid, '' AS logindt FROM DUAL;
			END IF;
		END IF;


		IF (V_CURSOR IS NULL)
        THEN
            OPEN V_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
        END IF;

        IF (V_CURSOR2 IS NULL)
        THEN
            OPEN V_CURSOR2 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
        END IF;

		IO_CURSOR := V_CURSOR;
		IO_CURSOR2 := V_CURSOR2;

		DBMS_OUTPUT.PUT_LINE('===== spGetCommon PROCEDURE END =====');
	END SPLOGINACCESS;
END LOGINACCESS_PKG;
/
