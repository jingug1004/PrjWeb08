CREATE PACKAGE BODY GETPARAMETER_PKG
AS
	PROCEDURE SPGETPARAMETER(
		p_div			   IN	  VARCHAR2 := '',
		p_parametercode    IN	  VARCHAR2 := '',
		p_userid		   IN	  VARCHAR2 := '',
		p_reasondiv 	   IN	  VARCHAR2 := '',
		p_reasontext	   IN	  VARCHAR2 := '',
		MESSAGE 			  OUT VARCHAR2,
		IO_CURSOR			  OUT TYPES.DATASET
	)
	IS
	BEGIN
		DBMS_OUTPUT.PUT_LINE('===== spGetCommon PROCEDURE START =====');
		MESSAGE := '데이터베이스 성공';

		IF (p_div = 'S')
		THEN
			OPEN IO_CURSOR FOR
				SELECT parametercode, value1, value2, value3
				FROM   parametermanage
				WHERE  parametercode = p_parametercode;
		ELSIF (p_div = '품질관리서명자')
		THEN
			SELECT value1 || ';' || value2
			INTO   MESSAGE
			FROM   parametermanage a
				   LEFT OUTER JOIN Employeemaster b ON a.value1 = b.empcode
				   LEFT OUTER JOIN Employeemaster c ON a.value2 = c.empcode
			WHERE  parametercode = 'LimsSigner'
				   AND usediv = 'Y';
		ELSIF (p_div = '소비자불만등록알림1')
		THEN
			SELECT value1 || ';' || value2
			INTO   MESSAGE
			FROM   parametermanage a
				   LEFT OUTER JOIN Employeemaster b ON a.value1 = b.empcode
				   LEFT OUTER JOIN Employeemaster c ON a.value2 = c.empcode
			WHERE  parametercode = 'LimsComplainDept1'
				   AND usediv = 'Y';
		ELSIF (p_div = '소비자불만등록알림2')
		THEN
			SELECT value1 || ';' || value2
			INTO   MESSAGE
			FROM   parametermanage a
				   LEFT OUTER JOIN Employeemaster b ON a.value1 = b.empcode
				   LEFT OUTER JOIN Employeemaster c ON a.value2 = c.empcode
			WHERE  parametercode = 'LimsComplainDept2'
				   AND usediv = 'Y';
		ELSIF (p_div = '소비자불만등록알림3')
		THEN
			SELECT value1 || ';' || value2
			INTO   MESSAGE
			FROM   parametermanage a
				   LEFT OUTER JOIN Employeemaster b ON a.value1 = b.empcode
				   LEFT OUTER JOIN Employeemaster c ON a.value2 = c.empcode
			WHERE  parametercode = 'LimsComplainDept3'
				   AND usediv = 'Y';
		ELSIF (p_div = '소비자불만등록알림4')
		THEN
			SELECT value1 || ';' || value2
			INTO   MESSAGE
			FROM   parametermanage a
				   LEFT OUTER JOIN Employeemaster b ON a.value1 = b.empcode
				   LEFT OUTER JOIN Employeemaster c ON a.value2 = c.empcode
			WHERE  parametercode = 'LimsComplainAccept1'
				   AND usediv = 'Y';
		ELSIF (p_div = '작업실')
		THEN
			SELECT 'workroommaster' INTO MESSAGE FROM DUAL;
		ELSIF (p_div = '사업장')
		THEN
			OPEN IO_CURSOR FOR
				SELECT NVL(postcode, '') || ' ' || NVL(address, '') || ' ' || NVL(detailaddress, '') AS address, telno, faxno
				FROM   CMPLANTM
				WHERE  plantcode = p_parametercode;
		ELSIF (p_div = '회사상호')
		THEN
			OPEN IO_CURSOR FOR SELECT compcode, compname, compename FROM CMCOMPM;
		END IF;

		IF (IO_CURSOR IS NULL)
		THEN
			OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
		END IF;

		DBMS_OUTPUT.PUT_LINE('===== spGetCommon PROCEDURE END =====');
	END SPGETPARAMETER;
END GETPARAMETER_PKG;
/
