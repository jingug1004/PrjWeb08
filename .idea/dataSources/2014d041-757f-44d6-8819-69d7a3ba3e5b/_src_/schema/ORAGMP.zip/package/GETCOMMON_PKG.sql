CREATE PACKAGE        GETCOMMON_PKG
AS
	TYPE T_CURSOR IS REF CURSOR;

	PROCEDURE SPGETCOMMON(
		p_div			IN	   VARCHAR2 := NULL,																																																													   -- 구분
		p_diff			IN	   VARCHAR2 := NULL,																																													 -- 조회 시 구분자 값인지, 화면 display값인지 구분한다.("A":조회시 전체 값, "B",공백 값, "N"은 값만조회)
		p_strwhere		IN	   VARCHAR2 := NULL,																																																													 -- 조회조건
		p_strwhere2 	IN	   VARCHAR2 := '', 																																																													-- 조회조건2
		p_userid		IN	   VARCHAR2 := NULL,
		p_reasondiv 	IN	   VARCHAR2 := NULL,
		p_reasontext	IN	   VARCHAR2 := NULL,
		MESSAGE 		   OUT VARCHAR2,
		IO_CURSOR		   OUT TYPES.DATASET
	);
END GETCOMMON_PKG;
/
