CREATE PACKAGE        MESSENGERMSGBOX_PKG
AS
	TYPE T_CURSOR IS REF CURSOR;

	PROCEDURE SPMESSENGERMSGBOX(
		p_div			IN	   VARCHAR2 := '',
		p_seq				   INT := 0,
		p_sender		IN	   VARCHAR2 := '',
		p_recv			IN	   VARCHAR2 := '',
		p_msg			IN	   VARCHAR2 := '',
		p_senddt		IN	   VARCHAR2 := NULL,
		p_empcode		IN	   VARCHAR2 := '',
		p_readyn		IN	   VARCHAR2 := '',
		p_priority		IN	   VARCHAR2 := NULL,
		p_gb			IN	   VARCHAR2 := '',
		p_fileid1		IN	   INT := NULL,
		p_fileid2		IN	   INT := NULL,
		p_fileid3		IN	   INT := NULL,
		p_fileid4		IN	   INT := NULL,
		p_fileid5		IN	   INT := NULL,
		p_filenames 	IN	   VARCHAR2 := '',
		p_filedata			   BLOB := NULL,
		p_startdate 	IN	   VARCHAR2 := NULL,
		p_enddate		IN	   VARCHAR2 := NULL,
		p_userid		IN	   VARCHAR2 := '',
		p_reasondiv 	IN	   VARCHAR2 := '',
		p_reasontext	IN	   VARCHAR2 := '',
		MESSAGE 		IN OUT VARCHAR2,
		IO_CURSOR		IN OUT T_CURSOR
	);
END MESSENGERMSGBOX_PKG;
/
