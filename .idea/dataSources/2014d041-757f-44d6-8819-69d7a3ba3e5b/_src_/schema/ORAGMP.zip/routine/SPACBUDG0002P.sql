CREATE PROCEDURE        spACbudg0002P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACbudg0002P
 -- 작 성 자         : 최기홍
 -- 작성일자         : 2010-11-12
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2017-01-02
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 년예산설정관리를 등록,수정,삭제,조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_cyear         IN  VARCHAR2 DEFAULT '' ,
    p_deptcode      IN  VARCHAR2 DEFAULT '' ,
    p_deptname      IN  VARCHAR2 DEFAULT '' ,
    p_acccode       IN  VARCHAR2 DEFAULT '' ,
    p_accname       IN  VARCHAR2 DEFAULT '' ,
    p_budgctldiv    IN  VARCHAR2 DEFAULT '' ,
    p_ybudgamt      IN  FLOAT    DEFAULT 0 ,
    p_frshybudgamt  IN  FLOAT    DEFAULT 0 ,
    p_afthybudgamt  IN  FLOAT    DEFAULT 0 ,
    p_qurt1budgamt  IN  FLOAT    DEFAULT 0 ,
    p_qurt2budgamt  IN  FLOAT    DEFAULT 0 ,
    p_qurt3budgamt  IN  FLOAT    DEFAULT 0 ,
    p_qurt4budgamt  IN  FLOAT    DEFAULT 0 ,
    p_m1budgamt     IN  FLOAT    DEFAULT 0 ,
    p_m2budgamt     IN  FLOAT    DEFAULT 0 ,
    p_m3budgamt     IN  FLOAT    DEFAULT 0 ,
    p_m4budgamt     IN  FLOAT    DEFAULT 0 ,
    p_m5budgamt     IN  FLOAT    DEFAULT 0 ,
    p_m6budgamt     IN  FLOAT    DEFAULT 0 ,
    p_m7budgamt     IN  FLOAT    DEFAULT 0 ,
    p_m8budgamt     IN  FLOAT    DEFAULT 0 ,
    p_m9budgamt     IN  FLOAT    DEFAULT 0 ,
    p_m10budgamt    IN  FLOAT    DEFAULT 0 ,
    p_m11budgamt    IN  FLOAT    DEFAULT 0 ,
    p_m12budgamt    IN  FLOAT    DEFAULT 0 ,
    p_budgetyn      IN  VARCHAR2 DEFAULT '' ,
    p_remark        IN  VARCHAR2 DEFAULT '' ,
    p_insertdt      IN  DATE     DEFAULT NULL ,
    p_iempcode      IN  VARCHAR2 DEFAULT '' ,
    p_updatedt      IN  DATE     DEFAULT NULL ,
    p_uempcode      IN  VARCHAR2 DEFAULT '' ,
    p_restotamt     IN  FLOAT    DEFAULT 0 ,
    p_budgym        IN  VARCHAR2 DEFAULT '' ,
    p_budgamt       IN  FLOAT    DEFAULT 0 ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT ''  ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_yy   VARCHAR2(4);-- 년도생성시 저장되있는 가장 큰 년도 데이터 값참조하기위해 선언

    p_amt  FLOAT;  -- 총예산함수선언
    p_bun1 NUMBER; -- 1분기함수선언
    p_bun2 NUMBER; -- 2분기함수선언
    p_bun3 NUMBER; -- 3분기함수선언
    p_bun4 NUMBER; -- 4분기함수선언
BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    IF ( UPPER(p_div) = UPPER('S') ) THEN

        OPEN  IO_CURSOR FOR
            SELECT  NVL(a.compcode, '') compcode  ,
                    NVL(a.cyear, '') cyear  ,
                    NVL(a.deptcode, '') deptcode  ,
                    NVL(a.acccode, '') acccode  ,
                    NVL(a.budgctldiv, '') budgctldiv  ,
                    NVL(E.divname, '') budgctldivnm  ,
                    NVL(a.ybudgamt, 0) ybudgamt  ,
                    NVL(a.frshybudgamt, 0) frshybudgamt  ,
                    NVL(a.afthybudgamt, 0) afthybudgamt  ,
                    NVL(a.qurt1budgamt, 0) qurt1budgamt  ,
                    NVL(a.qurt2budgamt, 0) qurt2budgamt  ,
                    NVL(a.qurt3budgamt, 0) qurt3budgamt  ,
                    NVL(a.qurt4budgamt, 0) qurt4budgamt  ,
                    NVL(a.m1budgamt, 0) m1budgamt  ,
                    NVL(a.m2budgamt, 0) m2budgamt  ,
                    NVL(a.m3budgamt, 0) m3budgamt  ,
                    NVL(a.m4budgamt, 0) m4budgamt  ,
                    NVL(a.m5budgamt, 0) m5budgamt  ,
                    NVL(a.m6budgamt, 0) m6budgamt  ,
                    NVL(a.m7budgamt, 0) m7budgamt  ,
                    NVL(a.m8budgamt, 0) m8budgamt  ,
                    NVL(a.m9budgamt, 0) m9budgamt  ,
                    NVL(a.m10budgamt, 0) m10budgamt  ,
                    NVL(a.m11budgamt, 0) m11budgamt  ,
                    NVL(a.m12budgamt, 0) m12budgamt  ,
                    NVL(a.remark, '') remark  ,
                    NVL(b.deptname, '') deptname  ,
                    NVL(c.accname, '') accname  ,
                    CASE WHEN NVL(D.budgetyn, 'N') = 'Y' THEN '확정'
                         WHEN NVL(D.budgetyn, 'N') = 'N' THEN '미확정'
                    END budgetyn
            FROM    ACBUDGYY a
                    LEFT JOIN CMDEPTM b   ON a.deptcode = b.deptcode
                    LEFT JOIN ACACCM c    ON a.acccode = c.acccode
                    LEFT JOIN ACSESSION D ON a.cyear = D.cyear
                    LEFT JOIN CMCOMMONM E ON a.budgctldiv = E.divcode
                    AND E.cmmcode = 'AC91'
            WHERE   a.compcode = p_compcode
                    AND a.cyear LIKE p_cyear || '%'
                    AND a.deptcode LIKE p_deptcode || '%'
                    AND a.acccode LIKE p_acccode || '%'
            ORDER BY a.deptcode, a.acccode ;

    ELSIF ( p_div = 'S2' ) THEN

        FOR  rec IN (   SELECT  D.budgetyn  AS alias1
                        FROM    ACBUDGYY a
                                LEFT JOIN CMDEPTM b   ON a.deptcode = b.deptcode
                                LEFT JOIN ACACCM c   ON a.acccode = c.acccode
                                LEFT JOIN ACSESSION D   ON a.cyear = D.cyear
                        WHERE   a.compcode = p_compcode
                                AND a.acccode = p_acccode
                                AND a.cyear = p_cyear
                                AND a.deptcode = p_deptcode
        )
        LOOP
            MESSAGE := rec.alias1 ;
        END LOOP;

    ELSIF ( p_div = 'SC' ) THEN

        FOR  rec IN (   SELECT  COUNT(acccode)   AS alias1
                        FROM    ACBUDGYY
                        WHERE   compcode = p_compcode
                                AND acccode = p_acccode
                                AND cyear = p_cyear
                                AND deptcode = p_deptcode
        )
        LOOP
            MESSAGE := rec.alias1 ;
        END LOOP;

    ELSIF ( p_div = 'SD' ) THEN

        MESSAGE := '' ;

        FOR  rec IN (   SELECT '데이터 확인' AS alias1
                        FROM    ACBUDGMM
                        WHERE   compcode = p_compcode
                                AND SUBSTR(budgym, 0, 4) = p_cyear
                                AND restotamt <> 0
        )
        LOOP
            MESSAGE := rec.alias1 ;
        END LOOP;

    ELSIF ( p_div = 'S1' ) THEN --전년 예산검사

        FOR  rec IN (   SELECT  COUNT(cyear)   AS alias1
                        FROM    ACBUDGYY
                        WHERE   compcode = p_compcode
                                AND cyear = TO_CHAR(ADD_MONTHS(TO_DATE(p_cyear || '-01-01', 'YYYY-MM-DD'), -12), 'YYYY')
        )
        LOOP
            MESSAGE := rec.alias1 ;
        END LOOP;

    ELSIF ( p_div = 'I' ) THEN

        INSERT INTO ACBUDGYY (
            compcode
            , cyear
            , deptcode
            , acccode
            , budgctldiv
            , ybudgamt
            , frshybudgamt
            , afthybudgamt
            , qurt1budgamt
            , qurt2budgamt
            , qurt3budgamt
            , qurt4budgamt
            , m1budgamt
            , m2budgamt
            , m3budgamt
            , m4budgamt
            , m5budgamt
            , m6budgamt
            , m7budgamt
            , m8budgamt
            , m9budgamt
            , m10budgamt
            , m11budgamt
            , m12budgamt
            , remark
            , insertdt
            , iempcode )
        VALUES (
            p_compcode
            , p_cyear
            , p_deptcode
            , p_acccode
            , p_budgctldiv
            , p_m1budgamt + p_m2budgamt + p_m3budgamt + p_m4budgamt + p_m5budgamt + p_m6budgamt + p_m7budgamt + p_m8budgamt + p_m9budgamt + p_m10budgamt + p_m11budgamt + p_m12budgamt
            , p_m1budgamt + p_m2budgamt + p_m3budgamt + p_m4budgamt + p_m5budgamt + p_m6budgamt
            , p_m7budgamt + p_m8budgamt + p_m9budgamt + p_m10budgamt + p_m11budgamt + p_m12budgamt
            , p_m1budgamt + p_m2budgamt + p_m3budgamt
            , p_m4budgamt + p_m5budgamt + p_m6budgamt
            , p_m7budgamt + p_m8budgamt + p_m9budgamt
            , p_m10budgamt + p_m11budgamt + p_m12budgamt
            , p_m1budgamt
            , p_m2budgamt
            , p_m3budgamt
            , p_m4budgamt
            , p_m5budgamt
            , p_m6budgamt
            , p_m7budgamt
            , p_m8budgamt
            , p_m9budgamt
            , p_m10budgamt
            , p_m11budgamt
            , p_m12budgamt
            , p_remark
            , SYSDATE
            , p_iempcode );

    ELSIF ( p_div = 'IC' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT   p_compcode     AS compcode
                    ,p_cyear        AS cyear
                    ,p_deptcode     AS deptcode
                    ,p_acccode      AS acccode
                    ,p_budgctldiv   AS budgctldiv
                    ,p_ybudgamt     AS ybudgamt
                    ,p_frshybudgamt AS frshybudgamt
                    ,p_afthybudgamt AS afthybudgamt
                    ,p_qurt1budgamt AS qurt1budgamt
                    ,p_qurt2budgamt AS qurt2budgamt
                    ,p_qurt3budgamt AS qurt3budgamt
                    ,p_qurt4budgamt AS qurt4budgamt
                    ,p_m1budgamt    AS m1budgamt
                    ,p_m2budgamt    AS m2budgamt
                    ,p_m3budgamt    AS m3budgamt
                    ,p_m4budgamt    AS m4budgamt
                    ,p_m5budgamt    AS m5budgamt
                    ,p_m6budgamt    AS m6budgamt
                    ,p_m7budgamt    AS m7budgamt
                    ,p_m8budgamt    AS m8budgamt
                    ,p_m9budgamt    AS m9budgamt
                    ,p_m10budgamt   AS m10budgamt
                    ,p_m11budgamt   AS m11budgamt
                    ,p_m12budgamt   AS m12budgamt
                    ,p_remark       AS remark
                    ,SYSDATE        AS insertdt
                    ,p_iempcode     AS iempcode
            FROM DUAL ;

    ELSIF ( p_div = 'I1' ) THEN --전년도 예산 인설트

        DELETE  ACBUDGYY
        WHERE   compcode = p_compcode
                AND cyear = p_cyear;

        INSERT INTO ACBUDGYY (
            compcode
            , cyear
            , deptcode
            , acccode
            , budgctldiv
            , ybudgamt
            , frshybudgamt
            , afthybudgamt
            , qurt1budgamt
            , qurt2budgamt
            , qurt3budgamt
            , qurt4budgamt
            , m1budgamt
            , m2budgamt
            , m3budgamt
            , m4budgamt
            , m5budgamt
            , m6budgamt
            , m7budgamt
            , m8budgamt
            , m9budgamt
            , m10budgamt
            , m11budgamt
            , m12budgamt
            , remark
            , insertdt
            , iempcode )
        (   SELECT  compcode ,
                    TO_CHAR(ADD_MONTHS(TO_DATE(cyear || '-01-01', 'YYYY-MM-DD'), 12), 'YYYY') ,
                    deptcode ,
                    acccode ,
                    budgctldiv ,
                    ybudgamt ,
                    frshybudgamt ,
                    afthybudgamt ,
                    qurt1budgamt ,
                    qurt2budgamt ,
                    qurt3budgamt ,
                    qurt4budgamt ,
                    m1budgamt ,
                    m2budgamt ,
                    m3budgamt ,
                    m4budgamt ,
                    m5budgamt ,
                    m6budgamt ,
                    m7budgamt ,
                    m8budgamt ,
                    m9budgamt ,
                    m10budgamt ,
                    m11budgamt ,
                    m12budgamt ,
                    remark ,
                    SYSDATE ,
                    p_iempcode
            FROM    ACBUDGYY
            WHERE   compcode = p_compcode
                    AND cyear = TO_CHAR(ADD_MONTHS(TO_DATE(p_cyear || '-01-01', 'YYYY-MM-DD'), -12), 'YYYY')
        ) ;


    ELSIF ( p_div = 'SC1' ) THEN --기수마스터 예산확정구분 유무검사

        FOR  rec IN (   SELECT  COUNT(budgetyn)   AS alias1
                        FROM    ACSESSION
                        WHERE   compcode = p_compcode
                                AND cyear = p_cyear
                                AND budgetyn = 'Y'
        )
        LOOP
            MESSAGE := rec.alias1 ;
        END LOOP;

    ELSIF ( p_div = 'SC2' ) THEN -- 기수마스터 년도 검사

        FOR  rec IN (   SELECT  COUNT(cyear)   AS alias1
                        FROM    ACSESSION
                        WHERE   compcode = p_compcode
                                AND cyear = p_cyear
        )
        LOOP
            MESSAGE := rec.alias1 ;
        END LOOP;


        -- 기수마스터에 년도가 없으면
        IF TO_NUMBER(MESSAGE) = 0 THEN

            DELETE  ACBUDGMM
            WHERE   compcode = p_compcode
                    AND SUBSTR(budgym, 0, 4) = p_cyear;


            SELECT  MAX(cyear) cyear
            INTO    p_yy
            FROM    ACSESSION
            WHERE ROWNUM <= 1 ;


            INSERT INTO ACSESSION (
                compcode
                , cyear
                , sseq
                , curstrdate
                , curenddate
                , prvstrdate
                , prvenddate
                , reportdate
                , fixdate
                , budgetyn
                , insertdt
                , iempcode )
            (   SELECT  p_compcode ,-- 가장 년도 높은 데이터 select후 인설트
                        p_cyear ,
                        ( SELECT MAX(sseq)  + 1 FROM ACSESSION  ) ,
                        p_cyear || SUBSTR(curstrdate, -6, 6) curstrdate  ,
                        p_cyear || SUBSTR(curenddate, -6, 6) curenddate  ,
                        TO_CHAR(p_cyear - 1) || SUBSTR(curenddate, -6, 6) prvstrdate  ,
                        TO_CHAR(p_cyear - 1) || SUBSTR(curenddate, -6, 6) prvenddate  ,
                        reportdate ,
                        fixdate ,
                        budgetyn ,
                        SYSDATE ,
                        p_iempcode
                FROM    ACSESSION
                WHERE   compcode = p_compcode
                        AND cyear = p_yy
            );

        END IF;

    ELSIF ( p_div = 'SC3' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  compcode ,
                    cyear ,
                    acccode ,
                    deptcode
            FROM    ACBUDGYY
            WHERE   compcode = p_compcode
                    AND cyear = p_cyear ;

    ELSIF ( p_div = 'I2' ) THEN -- 한계정코드에 월별데이터 생성 저장  1계정당 1월~ 12월 생성 |예산확정|

        UPDATE  ACSESSION
        SET     budgetyn = 'Y' -- 년예산테이블 예산확정 'Y'변경
        WHERE   compcode = p_compcode
                AND cyear = p_cyear ;

        INSERT INTO ACBUDGMM (
            compcode
            , budgym
            , deptcode
            , acccode
            , budgamt
            , restotamt
            , inttotamt
            , chgyn
            , remark
            , insertdt
            , iempcode
        )
        SELECT  compcode ,
                cyear || '-' || fnLPAD(TO_CHAR(ROW_NUMBER() OVER ( PARTITION BY deptcode, acccode ORDER BY cyear  )), 2, '0') cyear  ,
                deptcode ,
                acccode ,
                budgamt ,
                0 restotamt  ,
                0 inttotamt  ,
                '' chgyn  ,
                remark ,
                SYSDATE insertdt  ,
                p_iempcode iempcode
        FROM    (   SELECT  compcode ,
                            deptcode ,
                            acccode ,
                            cyear ,
                            m1budgamt a01  ,
                            m2budgamt a02  ,
                            m3budgamt a03  ,
                            m4budgamt a04  ,
                            m5budgamt a05  ,
                            m6budgamt a06  ,
                            m7budgamt a07  ,
                            m8budgamt a08  ,
                            m9budgamt a09  ,
                            m10budgamt a10  ,
                            m11budgamt a11  ,
                            m12budgamt a12  ,
                            remark
                    FROM    ACBUDGYY
                    WHERE   compcode = p_compcode
                            AND cyear = p_cyear
                            AND deptcode = p_deptcode
                            AND acccode = p_acccode ) a

        UNPIVOT (budgamt FOR budgamtname IN ( a01 , a02 , a03 , a04 , a05 , a06 , a07 , a08 , a09 , a10 , a11 , a12 ) ) P

        WHERE   compcode = p_compcode
                AND cyear = p_cyear
                AND deptcode = p_deptcode
                AND acccode = p_acccode ;



    ELSIF ( p_div = 'U' ) THEN

        UPDATE  ACBUDGYY
        SET     compcode = p_compcode,
                cyear = p_cyear,
                deptcode = p_deptcode,
                acccode = p_acccode,
                budgctldiv = p_budgctldiv,
                ybudgamt = p_ybudgamt,
                frshybudgamt = p_frshybudgamt,
                afthybudgamt = p_afthybudgamt,
                qurt1budgamt = p_qurt1budgamt,
                qurt2budgamt = p_qurt2budgamt,
                qurt3budgamt = p_qurt3budgamt,
                qurt4budgamt = p_qurt4budgamt,
                m1budgamt = p_m1budgamt,
                m2budgamt = p_m2budgamt,
                m3budgamt = p_m3budgamt,
                m4budgamt = p_m4budgamt,
                m5budgamt = p_m5budgamt,
                m6budgamt = p_m6budgamt,
                m7budgamt = p_m7budgamt,
                m8budgamt = p_m8budgamt,
                m9budgamt = p_m9budgamt,
                m10budgamt = p_m10budgamt,
                m11budgamt = p_m11budgamt,
                m12budgamt = p_m12budgamt,
                remark = p_remark,
                updatedt = SYSDATE,
                uempcode = p_iempcode
        WHERE   compcode = p_compcode
                AND deptcode = p_deptcode
                AND acccode = p_acccode
                AND cyear = p_cyear ;

    ELSIF ( p_div = 'D' ) THEN

        DELETE  ACBUDGYY
        WHERE   compcode = p_compcode
                AND deptcode = p_deptcode
                AND acccode = p_acccode
                AND cyear = p_cyear ;

    ELSIF ( p_div = 'D1' ) THEN

        DELETE  ACBUDGYY
        WHERE   compcode = p_compcode
                AND deptcode = p_deptcode
                AND cyear = p_cyear ;

    ELSIF ( p_div = 'D2' ) THEN

        -- 예산취소 예산구분은 'N'변경.
        DELETE  ACBUDGMM
        WHERE   compcode = p_compcode
                AND SUBSTR(budgym, 0, 4) = p_cyear ;


        DELETE  ACBUDGYH -- 변경이력 삭제
        WHERE   compcode = p_compcode
                AND SUBSTR(cyear, 0, 4) = p_cyear ;


        UPDATE  ACSESSION
        SET     budgetyn = 'N'
        WHERE   compcode = p_compcode
                AND cyear = p_cyear ;

    ELSIF ( p_div = 'SU' ) THEN -- 자동분배

        p_amt  := p_ybudgamt ;                                                                                                                      --총예산
        p_bun1 := FLOOR(FLOOR(p_amt / 2 / 10000) / 2) * 10000 ;                                                                                     --1분기 계산식
        p_bun2 := FLOOR(p_amt / 2 / 10000) * 10000 - FLOOR(FLOOR(p_amt / 2 / 10000) / 2) * 10000 ;                                                  --2분기계산식
        p_bun3 := FLOOR((p_amt - FLOOR(p_amt / 2 / 10000) * 10000 * (2 - 1)) / 2 / 10000) * 10000 ;                                                 --3분기계산식
        p_bun4 := p_amt - FLOOR(p_amt / 2 / 10000) * 10000 * (2 - 1) - FLOOR((p_amt - FLOOR(p_amt / 2 / 10000) * 10000 * (2 - 1)) / 20000) * 10000 ;--4분기계산식

        OPEN  IO_CURSOR FOR

            SELECT  FLOOR(p_amt / 2 / 10000) * 10000 frshybudgamt ,                     --상반기
                    p_amt - FLOOR(p_amt / 2 / 10000) * 10000 * (2 - 1) afthybudgamt ,   --하반기

                    p_bun1 qurt1budgamt ,                                               --1분기
                    p_bun2 qurt2budgamt ,                                               --2분기
                    p_bun3 qurt3budgamt ,                                               --3분기
                    p_bun4 qurt4budgamt ,                                               --4분기

                    FLOOR(p_bun1 / 3 / 10000) * 10000 m1budgamt ,                       --1월
                    FLOOR(p_bun1 / 3 / 10000) * 10000 m2budgamt ,                       --2월
                    FLOOR(p_bun1 - FLOOR(p_bun1 / 3 / 10000) * 10000 * 2) m3budgamt ,   --3월

                    FLOOR(p_bun2 / 3 / 10000) * 10000 m4budgamt ,                       --4월
                    FLOOR(p_bun2 / 3 / 10000) * 10000 m5budgamt ,                       --5월
                    FLOOR(p_bun2 - FLOOR(p_bun2 / 3 / 10000) * 10000 * 2) m6budgamt ,   --6월

                    FLOOR(p_bun3 / 3 / 10000) * 10000 m7budgamt ,                       --7월
                    FLOOR(p_bun3 / 3 / 10000) * 10000 m8budgamt ,                       --8월
                    FLOOR(p_bun3 - FLOOR(p_bun3 / 3 / 10000) * 10000 * 2) m9budgamt ,   --9월

                    FLOOR(p_bun4 / 3 / 10000) * 10000 m10budgamt ,                      --10월
                    FLOOR(p_bun4 / 3 / 10000) * 10000 m11budgamt ,                      --11월
                    FLOOR(p_bun4 - FLOOR(p_bun4 / 3 / 10000) * 10000 * 2) m12budgamt    --12월
            FROM DUAL ;


    ELSIF ( p_div = 'gb' ) THEN

        --엑셀 특정부서 검색비교대상
        OPEN  IO_CURSOR FOR

            SELECT  *
            FROM    ACBUDGYY
            WHERE   compcode = p_compcode
                    AND cyear = p_cyear
                    AND deptcode = p_deptcode
                    AND acccode = p_acccode ;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
