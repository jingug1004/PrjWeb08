CREATE PROCEDURE spACacc0018P
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0018P
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-06-01
	-- 수정일자       :   노영래
	-- E-mail       :   0rae0926@gmail.com
	-- 수정일자       :   2016-12-14
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 법인카드 완료처리를 관리하는 프로시저이다.
	-- ---------------------------------------------------------------
(
	p_div			   IN	  VARCHAR2 DEFAULT '',
	p_compcode		   IN	  VARCHAR2 DEFAULT '',
	p_strdate		   IN	  VARCHAR2 DEFAULT '',
	p_enddate		   IN	  VARCHAR2 DEFAULT '',
	p_endyn 		   IN	  VARCHAR2 DEFAULT '',
	p_search		   IN	  VARCHAR2 DEFAULT '',
	p_card_seq		   IN	  VARCHAR2 DEFAULT '',
	p_appr_date 	   IN	  VARCHAR2 DEFAULT '',
	p_appr_date_seq    IN	  VARCHAR2 DEFAULT '',
	p_userid		   IN	  VARCHAR2 DEFAULT '',
	p_reasondiv 	   IN	  VARCHAR2 DEFAULT '',
	p_reasontext	   IN	  VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT    VARCHAR2,
	IO_CURSOR		   OUT    TYPES.DATASET
)
AS

    v_temp     NUMBER := 0;

BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	-- 카드전표내역 검색
	IF (UPPER(P_DIV) = 'S') THEN

		-- 기업은행
		OPEN IO_CURSOR FOR

			SELECT	 CASE WHEN c.APPR_DATE IS NOT NULL THEN 'Y' ELSE 'N' END seldiv, -- 선택여부
					 FNSTUFF(FNSTUFF(FNSTUFF(a.CARD_NO, 5, 0, '-'), 10, 0, '-'), 15, 0, '-') card_nb, -- 카드번호
					 FNSTUFF(FNSTUFF(RTRIM(a.APPR_DATE), 5, 0, '-'), 8, 0, '-') appr_date, -- 승인일자
					 a.APPR_TIME APPR_TIME, -- 승인시간
					 RTRIM(a.APPR_NO) appr_nb, -- 승인번호
					 RTRIM(a.CHAIN_NM) fr_nm, -- 가맹점
					 a.APPR_AMT APPR_AMT, -- 승인금액
					 RTRIM(a.BRANCHTYPE) fr_upjong_nm, -- 업종
					 RTRIM(a.BRANCH_ADDR1) fr_addr, -- 주소
                     CASE WHEN TRIM(a.CHAIN_ID) IS NOT NULL THEN FNSTUFF(FNSTUFF(RTRIM(a.CHAIN_ID), 4, 0, '-'), 7, 0, '-')
                          ELSE ''
                     END fr_co_reg_nb, -- 사업자번호
					 RTRIM(a.CANCEL_YN) appr_cancel_yn, -- 취소여부
					 RTRIM(D.cardcustom) bank_nm, -- 카드사명
					 NVL(E.empname, '') empname, -- 보유사원
					 NVL(f.deptname, '') deptname, -- 보유부서
					 NVL(G.remark1, '') remark, -- 사용내역
					 NVL(h.accname, '') accname, -- 분개계정
					 b.slipinno, -- 전표일자
					 b.slipinseq, -- 전표순번
					 a.CARD_NO card_seq,
					 a.APPR_SEQ appr_date_seq

			FROM	 IBKDB_CCM_APPR a
					 LEFT JOIN ACORDCARD b
						 ON b.compcode = p_compcode
							AND a.APPR_DATE = b.appr_date
							AND a.APPR_TIME = b.appr_time
							AND a.APPR_NO = b.appr_nb
					 LEFT JOIN IB_CARD_COMP c
						 ON a.CARD_NO = c.CARD_SEQ
							AND a.APPR_DATE = c.APPR_DATE
							AND a.APPR_SEQ = c.APPR_DATE_SEQ
					 LEFT JOIN ACCARDM D
						 ON D.compcode = p_compcode
							AND a.CARD_NO = REPLACE(D.cardno, '-', '')
					 LEFT JOIN CMEMPM E ON D.empcode = E.empcode
					 LEFT JOIN CMDEPTM f ON D.deptcode = f.deptcode
					 LEFT JOIN ACORDD G
						 ON b.compcode = G.compcode
							AND b.slipinno = G.slipinno
							AND b.slipinseq = G.slipinseq
					 LEFT JOIN ACACCM h ON G.acccode = h.acccode

			WHERE	 a.APPR_DATE BETWEEN REPLACE(p_strdate, '-', '') AND REPLACE(p_enddate, '-', '')
					 AND (p_endyn = '0'
						  OR p_endyn = '1'
							 AND a.APPR_DATE = b.appr_date
						  OR p_endyn = '2'
							 AND b.appr_date IS NULL)
					 AND (RTRIM(a.CARD_NO) LIKE '%' || p_search || '%'
						  OR RTRIM(a.CHAIN_NM) LIKE '%' || p_search || '%'
						  OR NVL(E.empname, ' ') LIKE '%' || p_search || '%'
						  OR NVL(f.deptname, ' ') LIKE '%' || p_search || '%'
						  OR NVL(G.remark1, ' ') LIKE '%' || p_search || '%'
						  OR NVL(h.accname, ' ') LIKE '%' || p_search || '%')
			ORDER BY a.APPR_DATE, a.APPR_TIME, a.CARD_NO;

	ELSIF (UPPER(P_DIV) = 'I') THEN

		-- 법인카드 완료저장
        FOR rec IN (    SELECT COUNT(*) AS alias1
                        FROM   DUAL
                        WHERE  NOT EXISTS
                                   (SELECT *
                                    FROM   IB_CARD_COMP
                                    WHERE  card_seq = p_card_seq
                                           AND appr_date = p_appr_date
                                           AND NVL(TRIM(appr_date_seq), ' ') = NVL(p_appr_date_seq,' '))
        )
        LOOP
            v_temp := rec.alias1 ;
        END LOOP;

        IF v_temp = 1 THEN
            IF p_appr_date_seq IS NOT NULL THEN

                INSERT INTO IB_CARD_COMP
                    (SELECT p_card_seq, p_appr_date, p_appr_date_seq FROM DUAL);
            ELSE
                INSERT INTO IB_CARD_COMP
                    (SELECT p_card_seq, p_appr_date, ' ' FROM DUAL);
            END IF;
        END IF;


  ELSIF (UPPER(P_DIV) = 'D') THEN
    -- 법인카드 완료삭제
    DELETE IB_CARD_COMP
    WHERE  card_seq = p_card_seq
         AND appr_date = p_appr_date
         AND appr_date_seq = p_appr_date_seq;
  END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
