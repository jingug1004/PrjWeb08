CREATE PROCEDURE        spACbudg0012P
-- ---------------------------------------------------------------
-- 프로시저명       : spACbudg0012P
-- 작 성 자         : 배종성
-- 작성일자         : 2010-12-22
-- 수    정         : 2011-02-01 이영재 (월생성시 년예산 없는경우 년 예산 생성)
-- ---------------------------------------------------------------
-- 프로시저 설명    : 월예산변경관리에서 원예산변경을 조회 및 원예산을 입력하는 프로시저이다.
-- ---------------------------------------------------------------
(
    p_div            IN  VARCHAR2    DEFAULT '',
    p_compcode       IN  VARCHAR2    DEFAULT '',
    p_dedate1        IN  VARCHAR2    DEFAULT '',
    p_dedate2        IN  VARCHAR2    DEFAULT '',
    p_acccodeS       IN  VARCHAR2    DEFAULT '',
    p_deptcodeS      IN  VARCHAR2    DEFAULT '',
    p_yyyy           IN  VARCHAR2    DEFAULT '',
    p_edtdiv         IN  VARCHAR2    DEFAULT '',
    p_budgym         IN  VARCHAR2    DEFAULT '',
    p_budgamt        IN  FLOAT       DEFAULT 0,
    p_aft1budgamt    IN  FLOAT       DEFAULT 0,
    p_aftbudgym      IN  VARCHAR2    DEFAULT '',
    p_aftacccode     IN  VARCHAR2    DEFAULT '',
    p_aftdeptcode    IN  VARCHAR2    DEFAULT '',
    p_frm2budgamt    IN  FLOAT       DEFAULT 0,
    p_aft2budgamt    IN  FLOAT       DEFAULT 0,
    p_remark         IN  VARCHAR2    DEFAULT '',
    p_iempcode       IN  VARCHAR2    DEFAULT '',
    p_seq            IN  NUMBER      DEFAULT 0,
    p_userid         IN  VARCHAR2    DEFAULT '',
    p_reasondiv      IN  VARCHAR2    DEFAULT '',
    p_reasontext     IN  VARCHAR2    DEFAULT '',

    MESSAGE          OUT VARCHAR2,
    IO_CURSOR        OUT TYPES.DataSet
)
AS
    ip_seq           NUMBER         := p_seq;
    p_acccode2       VARCHAR2(20);
    p_deptcode2      VARCHAR2(20);
    p_chgym          VARCHAR2(7);

    p_preym          VARCHAR2(7);
    p_value1         VARCHAR2(20);
    p_deptcode       VARCHAR2(20);
BEGIN

   MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF( UPPER(p_div) = 'S') THEN

        OPEN  IO_CURSOR FOR

            SELECT  a.seq
                    ,a.chgdate
                    ,a.chgdiv
                    ,b.divname AS chgdivnm
                    ,a.remark
                    ,a.frmbudgym
                    ,a.frmacccode
                    ,a.frmdeptcode
                    ,a.frm1budgamt
                    ,a.aft1budgamt
                    ,a.aftbudgym
                    ,a.aftacccode
                    ,a.aftdeptcode
                    ,a.frm2budgamt
                    ,a.aft2budgamt
                    ,CASE WHEN a.seq = c.seq AND (a.aftacccode IS NULL OR a.seq = d.seq) THEN 0 ELSE 1 END AS nxtseq
            FROM    ACBUDGYH a
                    LEFT JOIN CMCOMMONM b ON a.chgdiv = b.divcode
                                             AND b.cmmcode = 'AC90'
                    LEFT JOIN ( SELECT  frmbudgym
                                        , frmacccode
                                        , frmdeptcode
                                        , max(seq) AS seq
                                FROM (  SELECT  frmbudgym
                                                , frmacccode
                                                , frmdeptcode
                                                , seq
                                        FROM    ACBUDGYH
                                        WHERE   compcode = p_compcode
                                                AND cyear = p_yyyy
                                        UNION ALL
                                        SELECT  aftbudgym
                                                , aftacccode
                                                , aftdeptcode
                                                , seq
                                        FROM    ACBUDGYH
                                        WHERE   compcode = p_compcode
                                                AND cyear = p_yyyy
                                                AND aftacccode IS NOT NULL ) a
                                GROUP BY frmbudgym, frmacccode, frmdeptcode ) c ON a.frmbudgym = c.frmbudgym
                                                                                   AND a.frmacccode = c.frmacccode
                                                                                   AND a.frmdeptcode = c.frmdeptcode
                    LEFT JOIN ( SELECT  frmbudgym, frmacccode, frmdeptcode, max(seq) AS seq
                                FROM (  SELECT  frmbudgym
                                                , frmacccode
                                                , frmdeptcode
                                                , seq
                                        FROM    ACBUDGYH
                                        WHERE   compcode = p_compcode
                                                AND cyear = p_yyyy
                                        UNION ALL
                                        SELECT  aftbudgym
                                                , aftacccode
                                                , aftdeptcode
                                                , seq
                                        FROM    ACBUDGYH
                                        WHERE   compcode = p_compcode
                                                AND cyear = p_yyyy
                                                AND aftacccode IS NOT NULL ) a
                                GROUP BY frmbudgym, frmacccode, frmdeptcode ) d ON a.aftbudgym = d.frmbudgym
                                                                                   AND a.aftacccode = d.frmacccode
                                                                                   AND a.aftdeptcode = d.frmdeptcode

            WHERE   a.compcode = p_compcode
                    AND a.cyear = p_yyyy
                    AND a.chgdate BETWEEN p_dedate1 AND p_dedate2
                    AND ( p_deptcodeS > ' ' AND a.frmdeptcode = p_deptcodeS OR p_deptcodeS IS NULL )
                    AND ( p_acccodeS > ' ' AND a.frmacccode = p_acccodeS OR p_acccodeS IS NULL )
                    AND a.chgdiv LIKE p_edtdiv
            ORDER BY a.seq ;

    ELSIF( UPPER(p_div) = 'S1') THEN

        OPEN  IO_CURSOR FOR

            SELECT  budgym
                    ,deptcode
                    ,acccode
                    ,budgamt
                    ,restotamt
                    ,remark
            FROM    ACBUDGMM

            WHERE   compcode = p_compcode
                    AND deptcode = p_deptcodeS
                    AND budgym = p_budgym
                    AND acccode = p_acccodeS ;

    ELSIF( UPPER(p_div) = 'I') THEN

        INSERT INTO ACBUDGMM (
            compcode
            ,budgym
            ,deptcode
            ,acccode
            ,budgamt
            ,restotamt
            ,inttotamt
            ,chgyn
            ,remark
            ,insertdt
            ,iempcode
        )
        VALUES (
            p_compcode
            ,p_budgym
            ,p_deptcodeS
            ,p_acccodeS
            ,p_budgamt
            ,0
            ,0
            ,'Y'
            ,p_remark
            ,SYSDATE
            ,p_iempcode
        ) ;

    ELSIF( UPPER(p_div) = 'SY1') THEN  -- 년 예산테이블 존재 여부 확인

        OPEN  IO_CURSOR FOR

            SELECT  cyear
                    ,deptcode
                    ,acccode
            FROM    ACBUDGYY
            WHERE   compcode = p_compcode
                    AND cyear = p_yyyy
                    AND deptcode = p_deptcodeS
                    AND acccode = p_acccodeS ;

    ELSIF( UPPER(p_div) = 'IY') THEN        --년 예산테이블에 0 예산 생성

        INSERT INTO ACBUDGYY (
            compcode
            ,cyear
            ,deptcode
            ,acccode
            ,ybudgamt
            ,frshybudgamt
            ,afthybudgamt
            ,qurt1budgamt
            ,qurt2budgamt
            ,qurt3budgamt
            ,qurt4budgamt
            ,m1budgamt
            ,m2budgamt
            ,m3budgamt
            ,m4budgamt
            ,m5budgamt
            ,m6budgamt
            ,m7budgamt
            ,m8budgamt
            ,m9budgamt
            ,m10budgamt
            ,m11budgamt
            ,m12budgamt
            ,budgctldiv
            ,remark
            ,insertdt
            ,iempcode
        )
        VALUES      (
            p_compcode
            ,p_yyyy
            ,p_deptcodeS
            ,p_acccodeS
            ,0,0,0,0,0,0,0
            ,0,0,0,0,0,0,0,0,0,0,0,0
            ,'1'
            ,''
            ,SYSDATE
            ,p_iempcode
        ) ;

    ELSIF( UPPER(p_div) = 'U') THEN

        UPDATE  ACBUDGMM a
        SET     a.compcode = p_compcode
                , a.budgym = p_budgym
                , a.deptcode = p_deptcodeS
                , a.acccode = p_acccodeS
                , a.budgamt = p_budgamt
                , a.chgyn = 'Y'
                , a.remark = p_remark
                , a.updatedt = SYSDATE
                , a.uempcode = p_iempcode
        WHERE   compcode = p_compcode
                AND budgym = p_budgym
                AND deptcode = p_deptcodeS
                AND acccode = p_acccodeS ;

    ELSIF( UPPER(p_div) = 'I2') THEN

        IF ip_seq = 0 THEN

            SELECT  NVL(MAX(seq), 0)+1
            INTO    ip_seq
            FROM    ACBUDGYH
            WHERE   compcode = p_compcode
                    AND cyear = p_yyyy ;
        END IF;

        INSERT INTO ACBUDGYH (
            compcode
            ,cyear
            ,seq
            ,chgdate
            ,chgdiv
            ,remark
            ,frmbudgym
            ,frmacccode
            ,frmdeptcode
            ,frm1budgamt
            ,aft1budgamt
            ,aftbudgym
            ,aftacccode
            ,aftdeptcode
            ,frm2budgamt
            ,aft2budgamt
            ,insertdt
            ,iempcode
        )
        VALUES (
            p_compcode
            ,p_yyyy
            ,ip_seq
            ,TO_CHAR(SYSDATE, 'YYYY-MM-DD')
            ,p_edtdiv
            ,p_remark
            ,p_budgym
            ,p_acccodeS
            ,p_deptcodeS
            ,p_budgamt
            ,p_aft1budgamt
            ,p_aftbudgym
            ,p_aftacccode
            ,p_aftdeptcode
            ,p_frm2budgamt
            ,p_aft2budgamt
            ,SYSDATE
            ,p_iempcode
        ) ;

    ELSIF( UPPER(p_div) = 'D2') THEN

        -- 변경전 처리
        FOR rec IN (
                        SELECT  frmacccode
                                , frmdeptcode
                                , frmbudgym
                        FROM    ACBUDGYH
                        WHERE   compcode = p_compcode
                                AND cyear = p_yyyy
                                AND seq = ip_seq
        )
        LOOP
            p_acccode2  := rec.frmacccode ;
            p_deptcode2 := rec.frmdeptcode ;
            p_chgym     := rec.frmbudgym ;
        END LOOP ;


        MERGE INTO ACBUDGMM a
        USING(
                SELECT  -- 업데이트 데이터
                        CASE WHEN SUBSTR(p_chgym, -2) = '01' THEN b.m1budgamt
                             WHEN SUBSTR(p_chgym, -2) = '02' THEN b.m2budgamt
                             WHEN SUBSTR(p_chgym, -2) = '03' THEN b.m3budgamt
                             WHEN SUBSTR(p_chgym, -2) = '04' THEN b.m4budgamt
                             WHEN SUBSTR(p_chgym, -2) = '05' THEN b.m5budgamt
                             WHEN SUBSTR(p_chgym, -2) = '06' THEN b.m6budgamt
                             WHEN SUBSTR(p_chgym, -2) = '07' THEN b.m7budgamt
                             WHEN SUBSTR(p_chgym, -2) = '08' THEN b.m8budgamt
                             WHEN SUBSTR(p_chgym, -2) = '09' THEN b.m9budgamt
                             WHEN SUBSTR(p_chgym, -2) = '10' THEN b.m10budgamt
                             WHEN SUBSTR(p_chgym, -2) = '11' THEN b.m11budgamt
                             WHEN SUBSTR(p_chgym, -2) = '12' THEN b.m12budgamt
                             ELSE 0 END + NVL(c.chgamt, 0) AS budgamt
                        , CASE WHEN c.chgamt <> 0 THEN 'Y' ELSE '' END AS chgyn
                        , CASE WHEN c.chgamt <> 0 THEN c.remark ELSE '' END AS remark

                        --비교 데이터
                        , a.compcode
                        , a.budgym
                        , a.deptcode
                        , a.acccode

                FROM    ACBUDGMM a
                        LEFT JOIN ACBUDGYY b ON a.compcode = b.compcode
                                                AND b.cyear = p_yyyy
                                                AND a.deptcode = b.deptcode
                                                AND a.acccode = b.acccode
                        LEFT JOIN ( SELECT  a.remark
                                            , b.chgamt
                                    FROM    ACBUDGYH a
                                            JOIN (
                                                    SELECT  MAX(seq) AS seq
                                                            , SUM(chgamt) AS chgamt
                                                    FROM (
                                                            SELECT  seq
                                                                    , aft1budgamt - frm1budgamt AS chgamt
                                                            FROM    ACBUDGYH
                                                            WHERE   compcode = p_compcode
                                                                    AND cyear = p_yyyy
                                                                    AND seq <> ip_seq
                                                                    AND frmacccode = p_acccode2
                                                                    AND frmdeptcode = p_deptcode2
                                                                    AND frmbudgym = p_chgym
                                                            UNION ALL
                                                            SELECT  seq
                                                                    , aft2budgamt - frm2budgamt AS chgamt
                                                            FROM    ACBUDGYH
                                                            WHERE   compcode = p_compcode
                                                                    AND cyear = p_yyyy
                                                                    AND seq <> ip_seq
                                                                    AND aftacccode = p_acccode2
                                                                    AND aftdeptcode = p_deptcode2
                                                                    AND aftbudgym = p_chgym ) a
                                                 ) b ON a.seq = b.seq
                                    WHERE   a.compcode = p_compcode
                                            AND a.cyear = p_yyyy ) c ON 1 = 1
                WHERE   a.compcode = p_compcode
                        AND a.budgym = p_chgym
                        AND a.deptcode = p_deptcode2
                        AND a.acccode = p_acccode2
        ) b ON ( a.compcode = b.compcode
                 AND a.budgym = b.budgym
                 AND a.deptcode = b.deptcode
                 AND a.acccode = b.acccode )
        WHEN MATCHED THEN UPDATE SET    a.budgamt = b.budgamt
                                        , a.chgyn = b.chgyn
                                        , a.remark = b.remark ;


        --변경 후 처리
        FOR rec IN (
                        SELECT  aftacccode
                                , aftdeptcode
                                , aftbudgym
                        FROM    ACBUDGYH
                        WHERE   compcode = p_compcode
                                AND cyear = p_yyyy
                                AND seq = ip_seq
        )
        LOOP
            p_acccode2  := rec.aftacccode ;
            p_deptcode2 := rec.aftdeptcode ;
            p_chgym     := rec.aftbudgym ;
        END LOOP ;


        MERGE INTO ACBUDGMM a
        USING(
                SELECT  -- 업데이트 데이터
                        CASE WHEN SUBSTR(p_chgym, -2) = '01' THEN b.m1budgamt
                             WHEN SUBSTR(p_chgym, -2) = '02' THEN b.m2budgamt
                             WHEN SUBSTR(p_chgym, -2) = '03' THEN b.m3budgamt
                             WHEN SUBSTR(p_chgym, -2) = '04' THEN b.m4budgamt
                             WHEN SUBSTR(p_chgym, -2) = '05' THEN b.m5budgamt
                             WHEN SUBSTR(p_chgym, -2) = '06' THEN b.m6budgamt
                             WHEN SUBSTR(p_chgym, -2) = '07' THEN b.m7budgamt
                             WHEN SUBSTR(p_chgym, -2) = '08' THEN b.m8budgamt
                             WHEN SUBSTR(p_chgym, -2) = '09' THEN b.m9budgamt
                             WHEN SUBSTR(p_chgym, -2) = '10' THEN b.m10budgamt
                             WHEN SUBSTR(p_chgym, -2) = '11' THEN b.m11budgamt
                             WHEN SUBSTR(p_chgym, -2) = '12' THEN b.m12budgamt
                             ELSE 0 END + NVL(c.chgamt, 0) AS budgamt
                        , CASE WHEN c.chgamt <> 0 THEN 'Y' ELSE '' END AS chgyn
                        , CASE WHEN c.chgamt <> 0 THEN c.remark ELSE '' END AS remark

                        --비교 데이터
                        , a.compcode
                        , a.budgym
                        , a.deptcode
                        , a.acccode

                FROM    ACBUDGMM a
                        LEFT JOIN ACBUDGYY b ON a.compcode = b.compcode
                                                AND b.cyear = p_yyyy
                                                AND a.deptcode = b.deptcode
                                                AND a.acccode = b.acccode
                        LEFT JOIN ( SELECT  a.remark
                                            , b.chgamt
                                    FROM    ACBUDGYH a
                                            JOIN (
                                                    SELECT  MAX(seq) AS seq
                                                            , SUM(chgamt) AS chgamt
                                                    FROM (
                                                            SELECT  seq
                                                                    , aft1budgamt - frm1budgamt AS chgamt
                                                            FROM    ACBUDGYH
                                                            WHERE   compcode = p_compcode
                                                                    AND cyear = p_yyyy
                                                                    AND seq <> ip_seq
                                                                    AND frmacccode = p_acccode2
                                                                    AND frmdeptcode = p_deptcode2
                                                                    AND frmbudgym = p_chgym
                                                            UNION ALL
                                                            SELECT  seq
                                                                    , aft2budgamt - frm2budgamt AS chgamt
                                                            FROM    ACBUDGYH
                                                            WHERE   compcode = p_compcode
                                                                    AND cyear = p_yyyy
                                                                    AND seq <> ip_seq
                                                                    AND aftacccode = p_acccode2
                                                                    AND aftdeptcode = p_deptcode2
                                                                    AND aftbudgym = p_chgym ) a
                                                 ) b ON a.seq = b.seq
                                    WHERE   a.compcode = p_compcode
                                            AND a.cyear = p_yyyy ) c ON 1 = 1
                WHERE   a.compcode = p_compcode
                        AND a.budgym = p_chgym
                        AND a.deptcode = p_deptcode2
                        AND a.acccode = p_acccode2
        ) b ON ( a.compcode = b.compcode
                 AND a.budgym = b.budgym
                 AND a.deptcode = b.deptcode
                 AND a.acccode = b.acccode )
        WHEN MATCHED THEN UPDATE SET    a.budgamt = b.budgamt
                                        , a.chgyn = b.chgyn
                                        , a.remark = b.remark ;


        DELETE FROM ACBUDGYH
        WHERE   compcode = p_compcode
                AND cyear = p_yyyy
                AND seq = ip_seq ;

    ELSIF( UPPER(p_div) = 'SC') THEN

        p_preym := TO_CHAR(ADD_MONTHS(TO_DATE(p_budgym || '-01', 'YYYY-MM-DD'), -1), 'YYYY-MM') ;

        SELECT  NVL(value1, NULL)
        INTO    p_value1
        FROM    SYSPARAMETERMANAGE
        WHERE   parametercode = 'acbudgsaleacc' ;

        SELECT  CASE WHEN NVL(TRIM(value2), NULL) IS NULL THEN ''
                     ELSE SUBSTR(value2,1,INSTR(value2, ';')-1)
                END
        INTO    p_deptcode
        FROM    SYSPARAMETERMANAGE
        WHERE   parametercode = 'calprofitplant' ;

        IF NVL(p_value1, NULL) IS NULL THEN

            IF (IO_CURSOR IS NULL) THEN
                OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
            END IF;

            RETURN ;
        END IF;


        -- 영업부서 임시파일을 생성
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0012P_CMDEPTM' ;

        INSERT INTO VGT.TT_ACBUDG0012P_CMDEPTM
            SELECT  deptcode
                    , deptname
                    , predeptcode
            FROM    CMDEPTM
            WHERE   deptcode LIKE p_deptcode || '%'
                    AND LENGTH(RTRIM(deptcode)) >= 7 ;


        -- 영업사원 임시파일을 생성
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0012P_CMEMPM' ;

        INSERT INTO VGT.TT_ACBUDG0012P_CMEMPM
            SELECT  a.empcode
                    , a.empname
                    , a.deptcode
                    , b.deptname
            FROM    CMEMPM a
                    JOIN VGT.TT_ACBUDG0012P_CMDEPTM b ON a.deptcode = b.deptcode
            WHERE    a.responsibilitydiv = '0003' ;


        -- 의무판매제도 예산설정
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0012P_ACBDGSAL' ;

        INSERT INTO VGT.TT_ACBUDG0012P_ACBDGSAL
            SELECT  deptcode
                    , itemcode
                    , MIN(budgamt) AS budgamt
                    , MAX(targetcust) AS targetcust
                    , MAX(newcust) AS newcust
                    , SUM(targetcnt) AS targetcnt
                    , row_number() OVER(PARTITION BY deptcode ORDER BY itemcode) AS ord
            FROM (
                    SELECT  a.deptcode
                            , NVL(c.itemcode1, b.itemcode1) AS itemcode
                            , NVL(c.budgamt, b.budgamt) AS budgamt
                            , NVL(c.targetcust1, b.targetcust1) AS targetcust
                            , NVL(c.newcust1, b.newcust1) AS newcust
                            , NVL(c.targetcnt1, b.targetcnt1) AS targetcnt
                    FROM    VGT.TT_ACBUDG0012P_CMDEPTM a
                            JOIN ACBDGSAL b ON b.compcode = p_compcode
                                                AND b.budgym = p_preym
                                                AND NVL(TRIM(b.deptcode), '') IS NULL
                            LEFT JOIN ACBDGSAL c ON c.compcode = p_compcode
                                                    AND c.budgym = p_preym
                                                    AND a.deptcode = c.deptcode
                    WHERE   NVL(c.itemcode1, b.itemcode1) IS NOT NULL

                    UNION

                    SELECT  a.deptcode
                            , NVL(c.itemcode2, b.itemcode2) AS itemcode
                            , NVL(c.budgamt, b.budgamt) AS budgamt
                            , NVL(c.targetcust2, b.targetcust2) AS targetcust
                            , NVL(c.newcust2, b.newcust2) AS newcust
                            , NVL(c.targetcnt2, b.targetcnt2) AS targetcnt
                    FROM    VGT.TT_ACBUDG0012P_CMDEPTM a
                            JOIN ACBDGSAL b ON b.compcode = p_compcode
                                                AND b.budgym = p_preym
                                                AND NVL(TRIM(b.deptcode), '') IS NULL
                            LEFT JOIN ACBDGSAL c ON c.compcode = p_compcode
                                                    AND c.budgym = p_preym
                                                    AND a.deptcode = c.deptcode
                    WHERE    NVL(c.itemcode2, b.itemcode2) IS NOT NULL

                    UNION

                    SELECT  a.deptcode
                            , NVL(c.itemcode3, b.itemcode3) AS itemcode
                            , NVL(c.budgamt, b.budgamt) AS budgamt
                            , NVL(c.targetcust3, b.targetcust3) AS targetcust
                            , NVL(c.newcust3, b.newcust3) AS newcust
                            , NVL(c.targetcnt3, b.targetcnt3) AS targetcnt
                    FROM    VGT.TT_ACBUDG0012P_CMDEPTM a
                            JOIN ACBDGSAL b ON b.compcode = p_compcode
                                                AND b.budgym = p_preym
                                                AND NVL(TRIM(b.deptcode), '') IS NULL
                            LEFT JOIN ACBDGSAL c ON c.compcode = p_compcode
                                                    AND c.budgym = p_preym
                                                    AND a.deptcode = c.deptcode
                    WHERE   NVL(c.itemcode3, b.itemcode3) IS NOT NULL

                    UNION

                    SELECT  a.deptcode
                            , NVL(c.itemcode4, b.itemcode4) AS itemcode
                            , NVL(c.budgamt, b.budgamt) AS budgamt
                            , NVL(c.targetcust4, b.targetcust4) AS targetcust
                            , NVL(c.newcust4, b.newcust4) AS newcust
                            , NVL(c.targetcnt4, b.targetcnt4) AS targetcnt
                    FROM    VGT.TT_ACBUDG0012P_CMDEPTM a
                            JOIN ACBDGSAL b ON b.compcode = p_compcode
                                                AND b.budgym = p_preym
                                                AND NVL(TRIM(b.deptcode), '') IS NULL
                            LEFT JOIN ACBDGSAL c ON c.compcode = p_compcode
                                                    AND c.budgym = p_preym
                                                    AND a.deptcode = c.deptcode
                    WHERE   NVL(c.itemcode4, b.itemcode4) IS NOT NULL
                ) a
            GROUP BY deptcode, itemcode ;


        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0012P_SLORDM' ;

        INSERT INTO VGT.TT_ACBUDG0012P_SLORDM
            SELECT  a.empcode
                    , a.itemcode
                    , MAX(a.budgamt) AS budgamt
                    , COUNT(*) AS custcnt
                    , COUNT(b.custcode) AS newcnt
                    , SUM(a.salqty) AS salqty
            FROM (
                    SELECT  a.empcode
                            , a.custcode
                            , c.itemcode
                            , SUM(CASE WHEN SUBSTR(a.saldiv,0,1) = 'A' THEN b.salqty ELSE -b.salqty END) AS salqty
                            , MAX(c.budgamt) AS budgamt
                            , max(c.targetcust) AS targetcust
                            , MAX(c.newcust) AS newcust
                            , max(c.targetcnt) AS targetcnt
                    FROM    SLORDM a
                            JOIN SLORDD b ON a.orderno = b.orderno
                                             AND a.plantcode = b.plantcode
                            JOIN VGT.TT_ACBUDG0012P_ACBDGSAL c ON a.deptcode = c.deptcode
                                                                  AND b.itemcode LIKE c.itemcode || '%'
                                                                  AND NVL(TRIM(c.itemcode), '') IS NOT NULL
                    WHERE   a.yymm = p_preym
                            AND a.statediv = '09'
                            AND a.saldiv IN ('A01', 'A03', 'B01', 'B03')
                    GROUP BY a.empcode, a.custcode, c.itemcode
                    HAVING SUM(CASE WHEN SUBSTR(a.saldiv,0,1) = 'A' THEN b.salqty ELSE -b.salqty END) > 0
                ) a
                LEFT JOIN CMCUSTM b ON a.custcode = b.custcode
                                       AND b.ascustcheck = 'Y'
            GROUP BY a.empcode, a.itemcode
            HAVING COUNT(*) >= MAX(a.targetcust) AND COUNT(b.custcode) >= MAX(a.newcust) AND SUM(a.salqty) >= MAX(a.targetcnt) ;



        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0012P_ACBUDGYH' ;

        INSERT INTO VGT.TT_ACBUDG0012P_ACBUDGYH
            SELECT  SUBSTR(p_budgym,0,4) AS cyear
                    , ROW_NUMBER()OVER(ORDER BY a.deptcode) + b.seq AS seq
                    , a.deptcode
                    , NVL(c.budgamt,0) AS frm1budgamt
                    , NVL(c.budgamt,0)+a.budgamt AS aft1budgamt
            FROM (
                    SELECT  a.deptcode
                            , MAX(b.budgamt) * COUNT(DISTINCT a.empcode) AS budgamt
                    FROM    VGT.TT_ACBUDG0012P_CMEMPM a
                            JOIN VGT.TT_ACBUDG0012P_ACBDGSAL b    ON a.deptcode = b.deptcode
                            LEFT JOIN VGT.TT_ACBUDG0012P_SLORDM c ON a.empcode = c.empcode
                                                                     AND b.itemcode = c.itemcode
                    GROUP BY a.deptcode
                    HAVING COUNT(b.itemcode) = COUNT(c.itemcode)
                ) a
                LEFT JOIN (
                            SELECT  NVL(max(seq),0) AS seq
                            FROM    ACBUDGYH
                            WHERE   compcode = p_compcode
                                    AND cyear = SUBSTR(p_budgym,0,4) ) b ON 1 = 1
                LEFT JOIN ACBUDGMM c ON c.compcode = p_compcode
                                        AND c.budgym = p_budgym
                                        AND a.deptcode = c.deptcode
                                        AND c.acccode = p_value1 ;


        INSERT INTO ACBUDGYY (  compcode,     cyear,          deptcode,       acccode,        ybudgamt,
                                frshybudgamt, afthybudgamt,   qurt1budgamt,   qurt2budgamt,   qurt3budgamt,
                                qurt4budgamt, m1budgamt,      m2budgamt,      m3budgamt,      m4budgamt,
                                m5budgamt,    m6budgamt,      m7budgamt,      m8budgamt,      m9budgamt,
                                m10budgamt,   m11budgamt,     m12budgamt,     budgctldiv,     remark,
                                insertdt,     iempcode )
            SELECT              p_compcode,   a.cyear,        a.deptcode,     p_value1,       0,
                                0,            0,              0,              0,              0,
                                0,            0,              0,              0,              0,
                                0,            0,              0,              0,              0,
                                0,            0,              0,              '2',            '',
                                SYSDATE,      p_iempcode
            FROM    VGT.TT_ACBUDG0012P_ACBUDGYH a
                    LEFT JOIN ACBUDGYY b ON b.compcode = p_compcode
                                            AND a.cyear = b.cyear
                                            AND a.deptcode = b.deptcode
                                            AND b.acccode = p_value1
            WHERE   b.compcode IS NULL
            ORDER BY a.deptcode ;



        INSERT INTO ACBUDGYH (  compcode,       cyear,     seq,        chgdate,                         chgdiv,
                                remark,         frmbudgym, frmacccode, frmdeptcode,                     frm1budgamt,
                                aft1budgamt,    aftbudgym, aftacccode, aftdeptcode,                     frm2budgamt,
                                aft2budgamt,    insertdt,  iempcode )
            SELECT              p_compcode,     cyear,     seq,        TO_CHAR(SYSDATE, 'YYYY-MM-DD'),  '3',
                                '영업예산조정 자동추가', p_budgym,  p_value1,   deptcode,                         frm1budgamt,
                                aft1budgamt,    p_budgym,  '',         '',                               0,
                                0,              SYSDATE,    p_iempcode
            FROM    VGT.TT_ACBUDG0012P_ACBUDGYH
            ORDER BY deptcode ;



        MERGE INTO ACBUDGMM a
        USING(
                SELECT  --업데이트 데이터
                        a.aft1budgamt
                        --비교데이터
                        , B.COMPCODE
                        , B.BUDGYM
                        , B.DEPTCODE
                        , B.ACCCODE
                FROM    VGT.TT_ACBUDG0012P_ACBUDGYH a
                        JOIN ACBUDGMM b ON b.compcode = p_compcode
                                           AND b.budgym = p_budgym
                                           AND a.deptcode = b.deptcode
                                           AND b.acccode = p_value1
             ) b ON (   a.COMPCODE = b.COMPCODE
                        AND a.BUDGYM = b.BUDGYM
                        AND a.DEPTCODE = b.DEPTCODE
                        AND a.ACCCODE = b.ACCCODE   )
        WHEN MATCHED THEN UPDATE SET    a.budgamt = b.aft1budgamt
                                        , a.chgyn = 'Y'
                                        , a.remark = '영업예산조정 자동추가'
                                        , a.updatedt = SYSDATE
                                        , a.uempcode = p_iempcode ;


        INSERT INTO ACBUDGMM (
            compcode
            , budgym
            , deptcode
            , acccode
            , budgamt
            , restotamt
            , inttotamt
            , chgyn
            , remark
            , insertdt
            , iempcode )
        SELECT  p_compcode
                , p_budgym
                , a.deptcode
                , p_value1
                , aft1budgamt
                , 0
                , 0
                , 'Y'
                , '영업예산조정 자동추가'
                , SYSDATE
                , p_iempcode
        FROM    VGT.TT_ACBUDG0012P_ACBUDGYH a
                LEFT JOIN ACBUDGMM b ON b.compcode = p_compcode
                                        AND b.budgym = p_budgym
                                        AND a.deptcode = b.deptcode
                                        AND b.acccode = p_value1
        WHERE   b.compcode IS NULL
        ORDER BY a.deptcode ;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
