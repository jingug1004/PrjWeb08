CREATE FUNCTION fnSeekMaxNo(
    -- ---------------------------------------------------------------
    -- 함 수 명			: fnSeekMaxNo
    -- 작 성 자         : 최인범
    -- 작성일자         : 2007-10-25
    -- 수정일자      :   노영래
    -- E-mail      :   0rae0926@gmail.com
    -- 수정일자      :   2016-01-12
    -- ---------------------------------------------------------------
    -- 함수설명			: 전표번호 생성
    -- ---------------------------------------------------------------


    p_div 		IN 	VARCHAR2 	DEFAULT '' ,
    p_keys 		IN 	VARCHAR2 	DEFAULT ''
)
	RETURN VARCHAR2
AS
   p_tostring VARCHAR2(20);

BEGIN
    IF ( p_div = 'ElectronicSignHistory' ) THEN

        FOR  rec IN ( 	SELECT max(workseq)   workseq
                        FROM ElectronicSignHistory
                        WHERE  programcode || LPAD(revisionno, 10, ' ') || KEYS || LPAD(signseq, 10, ' ') = p_keys
        )
        LOOP
        	p_tostring := rec.workseq;
        END LOOP;

    END IF;
    	RETURN (p_tostring);

    EXCEPTION WHEN OTHERS THEN NULL;
END;
/
