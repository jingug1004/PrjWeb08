CREATE PROCEDURE        spACacc0304R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0304R
 -- 작 성 자         : 배종성
 -- 작성일자         : 2011-03-21
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-27
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 받을어음명세서를 조회하는 프로시저이다.
 -- ---------------------------------------------------------------

(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_plantcode     IN  VARCHAR2 DEFAULT '' ,
    p_yymm          IN  VARCHAR2 DEFAULT '' ,
    p_viewdiv       IN  VARCHAR2 DEFAULT '' ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_enddate VARCHAR2(10);

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( p_div = 'S' ) THEN

        -- 부문별
        p_enddate := TO_CHAR(ADD_MONTHS(TO_DATE(p_yymm || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD');

        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0304R_ACAUTOORDT ';

        INSERT INTO VGT.TT_ACACC0304R_ACAUTOORDT (
            SELECT  a.billno ,
                    MAX(b.slipdate)  slipdate
            FROM    ACAUTOORDT a
                    JOIN ACORDM b ON a.compcode = b.compcode
                                     AND a.slipinno = b.slipinno
                                     AND NVL(TRIM(b.slipdate), '') IS NOT NULL
            WHERE   a.compcode = p_compcode
                    AND a.acattype = 'C'
                    AND a.acatrulecode LIKE 'C03%'
                    AND a.slipindate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'),-12), 'YYYY-MM-DD') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'),72), 'YYYY-MM-DD')
            GROUP BY a.billno
        );



        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0304R_DUAL ';

        INSERT INTO VGT.TT_ACACC0304R_DUAL (
            SELECT  a.compcode ,
                    a.plantcode ,                                             --사업장
                    NVL(a.coldate, '') coldate ,                              --수취일자
                    a.billdiv ,                                               --어음종류
                    NVL(a.custcode, '') custcode ,                            --거래처
                    a.billno ,                                                --어음번호
                    a.expdate ,                                               --만기일자
                    NVL(f.divname || ' ', '') || NVL(a.paybank, '') paybank , --지급지점
                    NVL(a.issempnm, '') issempnm ,                            --발행인
                    a.billamt - NVL(c.chgamt, 0) billamt                      --어음금액
            FROM    ACBILLM a
                    LEFT JOIN VGT.TT_ACACC0304R_ACAUTOORDT b   ON a.billno = b.billno
                    LEFT JOIN ( SELECT  a.billno ,                            --어음번호
                                        SUM(c.chgamt)  chgamt                 --변경금액
                                FROM    ACBILLM a
                                        LEFT JOIN VGT.TT_ACACC0304R_ACAUTOORDT b ON a.billno = b.billno
                                        JOIN ACBILLP c ON a.compcode = c.compcode
                                                          AND a.billno = c.billno
                                                          AND SUBSTR(c.chgslipno, 0, 8) <= REPLACE(p_enddate, '-', '')
                                        LEFT JOIN ACORDM D ON a.compcode = D.compcode
                                                              AND c.chgslipno = D.slipinno
                                WHERE   a.compcode = p_compcode
                                        AND a.plantcode LIKE p_plantcode
                                        AND NVL(b.slipdate, a.coldate) <= p_enddate
                                        AND p_enddate <= CASE WHEN D.slipdate > a.expdate THEN D.slipdate
                                                              ELSE a.expdate
                                                         END
                                        AND a.billcls = '1'                   -- 받을어음
                                        AND REPLACE(p_enddate, '-', '') < NVL(a.rtnslipno, '2999-12-31')
                                GROUP BY a.billno ) c ON a.billno = c.billno
                    LEFT JOIN ACORDM D ON a.compcode = D.compcode
                                          AND NVL(a.pchgslipno, a.chgslipno) = D.slipinno
                    LEFT JOIN ACORDM E ON a.compcode = E.compcode
                                          AND a.rtnslipno = E.slipinno
                    LEFT JOIN CMCOMMONM f ON f.cmmcode = 'PS88'
                                             AND a.bankcode = f.divcode
            WHERE   a.compcode = p_compcode
                    AND a.plantcode LIKE p_plantcode
                    AND NVL(b.slipdate, a.coldate) <= p_enddate
                    AND p_enddate < CASE WHEN D.slipdate > a.expdate THEN D.slipdate
                                         ELSE a.expdate
                                    END
                    AND a.billcls = '1' -- 받을어음
                    AND ( NULLIF(D.slipdate, NULL) IS NULL OR NVL(TRIM(c.billno), '') IS NOT NULL
                          AND a.billamt - c.chgamt > 0 OR c.billno IS NULL
                          AND p_enddate < D.slipdate OR E.slipdate IS NOT NULL
                          AND E.slipdate <= p_enddate )
        );




        INSERT INTO VGT.TT_ACACC0304R_DUAL (

            SELECT  a.compcode ,
                    a.plantcode ,                                               --사업장
                    NVL(a.coldate, '') coldate ,                               --수취일자
                    '98' billdiv ,                                              --어음종류
                    NVL(a.custcode, '') custcode ,                             --거래처
                    a.billno ,                                                  --어음번호
                    a.expdate ,                                                 --만기일자
                    NVL(f.divname || ' ', '') || NVL(a.paybank, '') paybank , --지급지점
                    NVL(a.issempnm, '') issempnm ,                              --발행인
                    a.billamt - NVL(c.chgamt, 0) billamt                        --어음금액

            FROM    ACBILLM a
                    LEFT JOIN VGT.TT_ACACC0304R_ACAUTOORDT b   ON a.billno = b.billno
                    LEFT JOIN ( SELECT  a.billno ,                  --어음번호
                                        SUM(c.chgamt)  chgamt       --변경금액
                                FROM    ACBILLM a
                                        LEFT JOIN VGT.TT_ACACC0304R_ACAUTOORDT b ON a.billno = b.billno
                                        JOIN ACBILLP c ON a.compcode = c.compcode
                                                          AND a.billno = c.billno
                                                          AND SUBSTR(c.chgslipno, 0, 8) <= REPLACE(p_enddate, '-', '')
                                        LEFT JOIN ACORDM D ON a.compcode = D.compcode
                                                              AND c.chgslipno = D.slipinno
                                WHERE   a.compcode = p_compcode
                                        AND a.plantcode LIKE p_plantcode
                                        AND NVL(b.slipdate, a.coldate) <= p_enddate
                                        AND p_enddate <= CASE WHEN D.slipdate > a.expdate THEN D.slipdate
                                                              ELSE a.expdate
                                                         END
                                        AND a.billcls = '1' -- 받을어음
                                        AND REPLACE(p_enddate, '-', '') < NVL(a.rtnslipno, '2999-12-31')
                                GROUP BY a.billno ) c ON a.billno = c.billno
                    JOIN ACORDM D ON a.compcode = D.compcode
                                     AND NVL(a.pchgslipno, a.chgslipno) = D.slipinno
                    LEFT JOIN ACORDM E ON a.compcode = E.compcode
                                          AND a.chgslipno = E.slipinno
                                          AND a.billstate = '5'
                    LEFT JOIN CMCOMMONM f ON f.cmmcode = 'PS88'
                                             AND a.bankcode = f.divcode
            WHERE   a.compcode = p_compcode
                    AND a.plantcode LIKE p_plantcode
                    AND NVL(b.slipdate, a.coldate) <= p_enddate
                    AND p_enddate < CASE WHEN D.slipdate > a.expdate THEN D.slipdate
                                         ELSE a.expdate
                                    END
                    AND p_enddate < NVL(E.slipdate, a.expdate)
                    AND a.billcls = '1' -- 받을어음
                    AND p_enddate >= D.slipdate
                    AND NVL(a.pbillstate, a.billstate) = '2'
        );


        OPEN  IO_CURSOR FOR

            SELECT  seq ,
                    a.plantcode ,                                               --사업장
                    coldate ,                                                   --수취일자
                    billdiv ,                                                   --어음종류
                    CASE WHEN billdiv = '98' AND seq = '1' THEN '예탁어음'
                         WHEN seq = '1' THEN c.divname
                         WHEN billdiv = '98' AND seq = '2' THEN '예탁어음 합계'
                         WHEN seq = '2' THEN c.divname || ' 합계'
                         WHEN billdiv = '99' THEN '총합계'
                    END billdivnm  ,
                    a.custcode ,                                                --거래처
                    NVL(b.custname, '') custname  ,
                    billno ,                                                    --어음번호
                    expdate ,                                                   --만기일자
                    paybank ,                                                   --지급지점
                    issempnm ,                                                  --발행인
                    billamt                                                     --어음금액

            FROM (  SELECT  '1' seq  ,
                            plantcode ,                     --사업장
                            NVL(coldate, '') coldate ,      --수취일자
                            billdiv ,                       --어음종류
                            NVL(custcode, '') custcode ,    --거래처
                            billno ,                        --어음번호
                            expdate ,                       --만기일자
                            NVL(paybank, '') paybank ,     --지급지점
                            NVL(issempnm, '') issempnm ,   --발행인
                            NVL(billamt, 0) billamt         --어음금액
                    FROM VGT.TT_ACACC0304R_DUAL

                    UNION ALL

                    SELECT  '2' seq  ,
                            '' plantcode ,                  --사업장
                            '' coldate ,                    --수취일자
                            NVL(billdiv, '') billdiv ,      --어음종류
                            '' custcode ,                   --거래처
                            '' billno ,                     --어음번호
                            '' expdate ,                    --만기일자
                            '' paybank ,                    --지급지점
                            '' issempnm ,                   --발행인
                            SUM(NVL(billamt, 0))  billamt   --어음금액
                    FROM VGT.TT_ACACC0304R_DUAL
                    GROUP BY billdiv

                    UNION ALL

                    SELECT  '3' seq  ,
                            '' plantcode ,                  --사업장
                            '' coldate ,                    --수취일자
                            '99' billdiv ,                  --어음종류
                            '' custcode ,                   --거래처
                            '' billno ,                     --어음번호
                            '' expdate ,                    --만기일자
                            '' paybank ,                    --지급지점
                            '' issempnm ,                   --발행인
                            SUM(NVL(billamt, 0))  billamt   --어음금액
                    FROM VGT.TT_ACACC0304R_DUAL
                    GROUP BY compcode ) a

                    LEFT JOIN CMCUSTM b ON a.custcode = b.custcode
                    LEFT JOIN CMCOMMONM c ON c.cmmcode = 'SL181'
                                             AND a.billdiv = c.divcode
                    ORDER BY billdiv, seq, expdate, coldate, billno;

   END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
