CREATE FUNCTION fnCalcSampling
-- ---------------------------------------------------------------
 -- 함 수 명			: fnCalcSampling
 -- 작 성 자         : 최인범
 -- 작성일자         : 2008-01-08
 -- 수 정 자         : 임정호
 -- 수정일자         : 2017-01-12
 -- ---------------------------------------------------------------
 -- 함수설명			: 원자재의 샘플링 공식
 -- ---------------------------------------------------------------

(
  p_div IN VARCHAR2 DEFAULT '' ,
  p_samplingpackqty IN NUMBER DEFAULT 0
)
RETURN VARCHAR2
AS
   p_returnresult VARCHAR2(50);

BEGIN
   IF ( p_div = 'F' ) THEN


      p_returnresult := '√( ' || fnNumericToString(p_samplingpackqty, 'S') || ' + 1 )' ;


   ELSIF ( p_div = 'S' ) THEN


         p_returnresult :=  CASE
                                WHEN SQRT(p_samplingpackqty + 1) > FLOOR(SQRT(p_samplingpackqty + 1)) THEN
                                    fnNumericToString(FLOOR(SQRT(p_samplingpackqty + 1)) + 1, 'S')
                                ELSE
                                    fnNumericToString(SQRT(p_samplingpackqty + 1), 'S')
                            END ;

         IF ( p_samplingpackqty = 1 ) THEN


            p_returnresult := '1' ;


         END IF;



   END IF;
   RETURN (p_returnresult);

EXCEPTION WHEN OTHERS THEN RETURN NULL;
END;
/
