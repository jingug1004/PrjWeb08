CREATE PROCEDURE        spACacc0180R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0180R
 -- 작 성 자         : 최용석
 -- 작성일자         : 2012-05-31
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-20
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 채권에이징
 -- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '' ,

    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_plantcode     IN  VARCHAR2 DEFAULT '%' ,
    p_yearmonth     IN  VARCHAR2 DEFAULT '' ,
    p_acccode       IN  VARCHAR2 DEFAULT '' ,
    p_custcode      IN  VARCHAR2 DEFAULT '' ,

    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,

    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_strdate VARCHAR2(10);
    p_enddate VARCHAR2(10);
BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( p_div = 'S' ) THEN

        p_strdate := SUBSTR(p_yearmonth, 0, 5) || '01-01' ;
        p_enddate := TO_CHAR(ADD_MONTHS(TO_DATE(p_yearmonth || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD') ;



        -- 1. 거래처별 잔액구하기
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0180R_ACORDSMM';

        INSERT INTO VGT.TT_ACACC0180R_ACORDSMM (
            SELECT  A.custcode ,
                    MAX(b.dcdiv)  dcdiv  ,
                    SUM(CASE WHEN b.dcdiv = '1' THEN A.bsdebamt - A.bscreamt
                             ELSE A.bscreamt - A.bsdebamt
                        END)  restamt
            FROM (  SELECT  A.mngcluval custcode  ,
                            A.bsdebamt ,
                            A.bscreamt
                    FROM    ACORDSMM A
                    WHERE   A.compcode = p_compcode
                            AND A.plantcode LIKE p_plantcode
                            AND A.slipym = SUBSTR(p_yearmonth, 0, 5) || '01'
                            AND A.closediv IN ( '10', '20' )
                            AND A.acccode = p_acccode
                            AND A.mngclucode = 'S010'
                            AND NVL(TRIM(A.mngcluval), ' ') LIKE p_custcode || '%'
                            AND NVL(TRIM(A.mngcluval), '') IS NOT NULL
                    UNION ALL
                    SELECT  b.mngcluval custcode  ,
                            A.debamt ,
                            A.creamt
                    FROM    ACORDD A
                            JOIN ACORDS b   ON A.compcode = b.compcode
                                                AND A.slipinno = b.slipinno
                                                AND A.slipinseq = b.slipinseq
                                                AND b.mngclucode = 'S010'
                                                AND NVL(TRIM(b.mngcluval), ' ') LIKE p_custcode || '%'
                                                AND NVL(TRIM(b.mngcluval), '') IS NOT NULL
                            JOIN ACORDM c   ON A.compcode = c.compcode
                                                AND A.slipinno = c.slipinno
                                                AND c.slipdiv <> 'F'
                    WHERE   A.compcode = p_compcode
                            AND A.plantcode LIKE p_plantcode
                            AND A.acccode = p_acccode
                            AND A.slipdate BETWEEN p_strdate AND p_enddate ) A
                    JOIN ACACCM b ON b.acccode = p_acccode
            GROUP BY A.custcode
            HAVING SUM(CASE WHEN b.dcdiv = '1' THEN A.bsdebamt - A.bscreamt
                            ELSE A.bscreamt - A.bsdebamt
                       END)  <> 0
        ) ;





        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0180R_ACORDD';

        INSERT INTO VGT.TT_ACACC0180R_ACORDD (

            SELECT  D.custcode ,
                    ROW_NUMBER() OVER ( PARTITION BY D.custcode ORDER BY A.slipno DESC, b.slipinseq DESC ) seq  ,
                    A.slipdate ,
                    A.slipno ,
                    b.slipinseq ,
                    b.debamt + b.creamt slipamt  ,
                    0 sumamt
            FROM    ACORDM A
                    JOIN ACORDD b ON A.compcode = b.compcode
                                     AND A.slipinno = b.slipinno
                                     AND b.acccode = p_acccode
                                     AND b.slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -12*3), 'YYYY-MM-DD') AND p_enddate
                    JOIN ACORDS c ON b.compcode = c.compcode
                                     AND b.slipinno = c.slipinno
                                     AND b.slipinseq = c.slipinseq
                                     AND c.mngclucode = 'S010'
                    JOIN VGT.TT_ACACC0180R_ACORDSMM D ON c.mngcluval = D.custcode
                                                         AND ( D.dcdiv = '1' AND b.dcdiv IN ( '1', '4' ) AND b.debamt > 0 OR
                                                               D.dcdiv = '2' AND b.dcdiv IN ( '2', '3' ) AND b.creamt > 0 )
                                                         AND D.restamt > 0
        ) ;



        MERGE INTO VGT.TT_ACACC0180R_ACORDD A
        USING (
                    SELECT  NVL(b.sumamt, 0) AS sumamt
                            , A.custcode
                            , A.seq
                    FROM    VGT.TT_ACACC0180R_ACORDD A
                            JOIN (  SELECT  A.custcode ,
                                            A.seq ,
                                            SUM(b.slipamt)  sumamt
                                    FROM    VGT.TT_ACACC0180R_ACORDD A
                                            LEFT JOIN VGT.TT_ACACC0180R_ACORDD b ON A.custcode = b.custcode
                                                                                    AND A.seq > b.seq
                                    GROUP BY A.custcode, A.seq ) b ON A.custcode = b.custcode
                                                                     AND A.seq = b.seq
              ) b ON ( A.custcode = b.custcode AND A.seq = b.seq )
        WHEN MATCHED THEN UPDATE SET A.sumamt = b.sumamt;





        FOR rec IN (
            SELECT  A.custcode
                    , A.seq
            FROM    VGT.TT_ACACC0180R_ACORDD A
                    JOIN (  SELECT  A.custcode ,
                                    MIN(A.seq)  seq
                            FROM    VGT.TT_ACACC0180R_ACORDD A
                                    JOIN VGT.TT_ACACC0180R_ACORDSMM b ON A.custcode = b.custcode
                                                                         AND A.sumamt >= b.restamt
                            GROUP BY A.custcode ) B ON A.custcode = b.custcode
                                                       AND A.seq >= b.seq
        )
        LOOP

            DELETE FROM VGT.TT_ACACC0180R_ACORDD A
            WHERE   A.custcode = rec.custcode
                    AND A.seq  = rec.seq ;

        END LOOP ;





        MERGE INTO VGT.TT_ACACC0180R_ACORDD A
        USING (
                    SELECT  CASE WHEN b.restamt - A.sumamt >= A.slipamt THEN A.slipamt
                                 ELSE b.restamt - A.sumamt
                            END AS slipamt
                            , A.custcode
                            , A.seq
                    FROM    VGT.TT_ACACC0180R_ACORDD A
                            JOIN (  SELECT  A.custcode ,
                                            MAX(A.restamt)  restamt  ,
                                            MAX(b.seq)  seq
                                    FROM    VGT.TT_ACACC0180R_ACORDSMM A
                                            JOIN VGT.TT_ACACC0180R_ACORDD b ON A.custcode = b.custcode
                                    WHERE   A.restamt > 0
                                    GROUP BY A.custcode ) b ON A.custcode = b.custcode
                                                               AND A.seq = b.seq
              ) b ON ( A.custcode = b.custcode AND A.seq = b.seq )
        WHEN MATCHED THEN UPDATE SET A.slipamt = b.slipamt;





        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0180R_AGING';

        INSERT INTO VGT.TT_ACACC0180R_AGING (
            SELECT  A.custcode ,
                    b.custname ,
                    A.restamt ,
                    aging01 ,
                    aging03 ,
                    aging06 ,
                    aging10 ,
                    aging20 ,
                    aging30 ,
                    aging40 ,
                    --DATEDIFF('DAY', TO_DATE(slipdate, 'YYYY-MM-DD'), TO_DATE(p_enddate, 'YYYY-MM-DD') ) turnday
                    DATEDIFF('DAY', slipdate, p_enddate ) turnday
            FROM ( SELECT   A.custcode ,
                            MAX(A.restamt)  restamt  ,
                            SUM(CASE WHEN b.slipdate > TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -1), 'YYYY-MM-DD') THEN b.slipamt
                                      ELSE 0
                                END)  aging01  ,
                            SUM(CASE WHEN b.slipdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -1), 'YYYY-MM-DD')
                                          AND b.slipdate > TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -3), 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  aging03  ,
                            SUM(CASE WHEN b.slipdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -3), 'YYYY-MM-DD')
                                          AND b.slipdate > TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -6), 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  aging06  ,
                            SUM(CASE WHEN b.slipdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -6), 'YYYY-MM-DD')
                                          AND b.slipdate > TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -12), 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  aging10  ,
                            SUM(CASE WHEN b.slipdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -12), 'YYYY-MM-DD')
                                          AND b.slipdate > TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -24), 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  aging20  ,
                            SUM(CASE WHEN b.slipdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -24), 'YYYY-MM-DD')
                                          AND b.slipdate > TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -36), 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  aging30  ,
                            SUM(CASE WHEN b.slipdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -36), 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  aging40  ,
                            MIN(b.slipdate)  slipdate
            FROM    VGT.TT_ACACC0180R_ACORDSMM A
                    LEFT JOIN VGT.TT_ACACC0180R_ACORDD b ON A.custcode = b.custcode
            WHERE   A.restamt > 0
            GROUP BY A.custcode

            UNION

            SELECT  A.custcode ,
                    A.restamt ,
                    A.restamt ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    NULL
            FROM    VGT.TT_ACACC0180R_ACORDSMM A
            WHERE   A.restamt <= 0 ) A
                    LEFT JOIN CMCUSTM b ON A.custcode = b.custcode );

        UPDATE VGT.TT_ACACC0180R_AGING A
        SET aging40 = restamt - aging01 - aging03 - aging06 - aging10 - aging20 - aging30;

        OPEN  IO_CURSOR FOR
            SELECT  *
            FROM    VGT.TT_ACACC0180R_AGING
            ORDER BY custcode ;


    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
