CREATE PROCEDURE spACacc0172R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0172R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2014-07-10
	-- 수 정 자     : 강현호
	-- E-Mail       : roykang0722@gmail.com
	-- 수정일자      : 2016-12-13
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 결의전표조회(차변기준)을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------
(
    p_div			 IN 	VARCHAR2 DEFAULT '',
    p_compcode		 IN 	VARCHAR2 DEFAULT '',
    p_plantcode 	 IN 	VARCHAR2 DEFAULT '',
    p_slipsdate 	 IN 	VARCHAR2 DEFAULT '',
    p_slipedate 	 IN 	VARCHAR2 DEFAULT '',
    p_deptcode		 IN 	VARCHAR2 DEFAULT '',
    p_empcode		 IN 	VARCHAR2 DEFAULT '',
    p_slipdiv		 IN 	VARCHAR2 DEFAULT '',
    p_slipinstate	 IN 	VARCHAR2 DEFAULT '',
    p_stracccode	 IN 	VARCHAR2 DEFAULT '',
    p_endacccode	 IN 	VARCHAR2 DEFAULT '',
    p_stramt		 IN 	FLOAT    DEFAULT -999999999,
    p_endamt		 IN 	FLOAT    DEFAULT 999999999,
    p_search		 IN 	VARCHAR2 DEFAULT '',
    p_userid		 IN 	VARCHAR2 DEFAULT '',
    p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
    p_reasontext	 IN 	VARCHAR2 DEFAULT '',

    MESSAGE          OUT    VARCHAR2,
    IO_CURSOR        OUT    TYPES.DataSet
)
AS
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF (p_div = 'S') THEN



        OPEN IO_CURSOR FOR

            -- 결의전표내역 검색

            WITH TT_ACACC0172R_DUAL AS (
                SELECT A.compcode,
                        A.slipindate,
                        b.slipinno,
                        b.slipinseq,
                        b.remark1,
                        b.dcdiv,
                        b.debamt,
                        b.creamt
                 FROM	ACORDM A
                        JOIN ACORDD b ON A.compcode = b.compcode
                                         AND A.plantcode = b.plantcode
                                         AND A.slipinno = b.slipinno
                 WHERE	A.compcode = p_compcode
                        AND A.plantcode LIKE p_plantcode
                        AND A.slipindate BETWEEN p_slipsdate AND p_slipedate
                        AND A.deptcode LIKE p_deptcode || '%'
                        AND A.empcode LIKE p_empcode || '%'
                        AND A.slipdiv LIKE p_slipdiv || '%'
                        AND A.slipinstate LIKE p_slipinstate
                        AND (p_stracccode IS NULL OR p_stracccode <= b.acccode)
                        AND (p_endacccode IS NULL OR b.acccode <= p_endacccode)
                        AND b.debamt + b.creamt BETWEEN p_stramt AND p_endamt
                        AND (NVL(A.slipinremark,' ') LIKE '%' || p_search || '%' OR
                             NVL(A.slipincomment,' ') LIKE '%' || p_search || '%' OR
                             NVL(b.remark1,' ') LIKE '%' || p_search || '%' OR
                             NVL(b.remark2,' ') LIKE '%' || p_search || '%')
            ) --WITH END
            SELECT	 A.slipindate,
                     b.mngcludec custname,
                     A.remark1,
                     A.debamt,
                     A.creamt,
                     c.accname,
                     c.paydiv,
                     c.empname
            FROM	 TT_ACACC0172R_DUAL A
                     LEFT JOIN ACORDS b ON A.compcode = b.compcode
                                            AND A.slipinno = b.slipinno
                                            AND A.slipinseq = b.slipinseq
                                            AND b.mngclucode = 'S010'
                     LEFT JOIN (SELECT A.compcode,
                                       A.slipinno,
                                       A.slipinseq,
                                       E.accname,
                                       DECODE (f.accremark || f.accountno,NULL , SUBSTR(G.cardno, -4, 4),SUBSTR(f.accremark, 0, 2) || '-' || SUBSTR(f.accountno, -3, 3) ) paydiv,
                                       h.empname
                                FROM   (SELECT	 A.compcode
                                                 , A.slipinno
                                                 , A.slipinseq
                                                 , NVL(MIN(b.slipinseq), MIN(c.slipinseq)) slipinseqc
                                        FROM	 TT_ACACC0172R_DUAL A
                                                 LEFT JOIN ACORDD b ON A.compcode = b.compcode
                                                                        AND A.slipinno = b.slipinno
                                                                        AND A.slipinseq <= b.slipinseq
                                                                        AND (A.dcdiv IN ('1', '4')
                                                                        AND b.dcdiv IN ('2', '3') OR A.dcdiv IN ('2', '3')
                                                                        AND b.dcdiv IN ('1', '4'))
                                                 LEFT JOIN ACORDD c ON A.compcode = c.compcode
                                                                        AND A.slipinno = c.slipinno
                                                                        AND (A.dcdiv IN ('1', '4')
                                                                        AND c.dcdiv IN ('2', '3') OR A.dcdiv IN ('2', '3')
                                                                        AND c.dcdiv IN ('1', '4'))
                                        GROUP BY A.compcode, A.slipinno, A.slipinseq ) A

                                       LEFT JOIN ACORDD b ON A.compcode = b.compcode
                                                             AND A.slipinno = b.slipinno
                                                             AND A.slipinseqc = b.slipinseq

                                       LEFT JOIN ACORDS c ON b.compcode = c.compcode
                                                             AND b.slipinno = c.slipinno
                                                             AND b.slipinseq = c.slipinseq
                                                             AND c.mngclucode = 'S020'

                                       LEFT JOIN ACORDS D ON b.compcode = D.compcode
                                                             AND b.slipinno = D.slipinno
                                                             AND b.slipinseq = D.slipinseq
                                                             AND D.mngclucode = 'S060'
                                       LEFT JOIN ACACCM E ON CASE WHEN b.dcdiv IN ('1', '2') THEN b.acccode ELSE '11101010' END = E.acccode
                                       LEFT JOIN CMACCOUNTM f ON c.mngcluval = f.accountno
                                       LEFT JOIN ACCARDM G ON D.mngcluval = G.cardno
                                       LEFT JOIN CMEMPM h ON G.empcode = h.empcode) c ON A.compcode = c.compcode
                                                                                         AND A.slipinno = c.slipinno
                                                                                         AND A.slipinseq = c.slipinseq

            ORDER BY A.slipinno, A.slipinseq;

    END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
