CREATE FUNCTION fnGetSopStandardQty
-- ---------------------------------------------------------------
 -- 함 수 명			: fnGetSopStandardQty
 -- 작 성 자         : 이종석
 -- 작성일자         : 2017-10-10
 -- ---------------------------------------------------------------
 -- 함수설명			: 표준운영절차 기준량 가져오기
 -- ---------------------------------------------------------------
(
    p_plantcode         IN VARCHAR2 DEFAULT ''
,   p_orderno           IN VARCHAR2 DEFAULT ''    --  제조지시번호
,   p_soprevisionno     IN NUMBER DEFAULT 0       --  SOP 버전
,   p_sopid             IN NUMBER DEFAULT 0       --  SOP ID
)

RETURN VARCHAR2
AS
   v_StandardQty NUMBER DEFAULT 0 ;

BEGIN

    --      기준량환산 =  제조수량 / 배치사이즈 * 기준량
    FOR rec IN (  SELECT  CASE WHEN NVL(e.batchsize,0) = 0 THEN 1
                               WHEN NVL(b.standardqty,0) = 0 THEN 1
                               ELSE ROUND(a.manufactureqty / e.batchsize * b.standardqty,2)
                          END AS StandardQty                               --  SOP 기준량
              FROM    MakingOrders a

                      INNER JOIN GoodsStandardRevision c
                        ON  a.revisionno = c.revisionno
                        AND a.itemcode = c.itemcode

                      INNER JOIN SopProcess b
                        ON  a.itemcode   = b.itemcode
                        AND a.itemcode   = c.itemcode
                        AND b.revisionno = p_soprevisionno
                        AND b.sopid      = p_sopid

                      INNER JOIN Prescriptionrevisionmanage e
                        ON  c.plantcode = e.plantcode
                       AND  c.itemcode  = e.itemcode
                       AND  c.prescriptionid = e.revisionno

              WHERE   a.plantcode = p_plantcode
              AND     a.orderno   = p_orderno
              AND     b.transfercheck = 'Y'

               )
    LOOP

        v_StandardQty       := rec.StandardQty;    --  제조수량


    END LOOP;

    RETURN (v_StandardQty);

    EXCEPTION WHEN OTHERS THEN RETURN (v_StandardQty);
END;
/
