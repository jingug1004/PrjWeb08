CREATE FUNCTION fnNextDatetime(
	ip_srcdate 	IN 	DATE, 		-- 최초일자
    p_repaysep 	IN 	VARCHAR2, 	-- 증가값
	p_dstdate 	IN 	VARCHAR2, 	-- 최종년월
	p_selcnt 	IN 	NUMBER		-- 0:당월 1:이전월
)
	RETURN VARCHAR2
AS
	p_srcdate	 DATE := ip_srcdate; -- 최초일자
	p_tempdate	 DATE;
-- 0:당월 1:이전월
BEGIN
	IF p_repaysep IN ('', '0', '4')
	THEN
		RETURN TO_CHAR(p_srcdate, 'YYYY-MM');
	END IF;

	IF (TO_CHAR(p_srcdate, 'YYYY-MM') >= p_dstdate)
	THEN
		RETURN TO_CHAR(p_srcdate, 'YYYY-MM');
	END IF;

	IF p_repaysep = '1'
	THEN
		p_tempdate := ADD_MONTHS(p_srcdate,1);
	ELSIF p_repaysep = '2'
    THEN
        p_tempdate := ADD_MONTHS(p_srcdate,3);
    ELSIF p_repaysep = '3'
    THEN
        p_tempdate := ADD_MONTHS(p_srcdate,6);
	END IF;

	IF TO_CHAR(p_tempdate,'YYYY-MM') < p_dstdate
	THEN
        IF p_repaysep = '1'
        THEN
            p_srcdate := ADD_MONTHS(p_srcdate,1);
        ELSIF p_repaysep = '2'
        THEN
            p_srcdate := ADD_MONTHS(p_srcdate,3);
        ELSIF p_repaysep = '3'
        THEN
            p_srcdate := ADD_MONTHS(p_srcdate,6);
        END IF;
  END IF;

  WHILE TO_CHAR(p_tempdate,'YYYY-MM') < p_dstdate
  LOOP
        IF p_repaysep = '1'
        THEN
            p_tempdate := ADD_MONTHS(p_srcdate,1);
        ELSIF p_repaysep = '2'
        THEN
            p_tempdate := ADD_MONTHS(p_srcdate,3);
        ELSIF p_repaysep = '3'
        THEN
            p_tempdate := ADD_MONTHS(p_srcdate,6);
        END IF;

        IF TO_CHAR(p_tempdate,'YYYY-MM') < p_dstdate
        THEN
            IF p_repaysep = '1'
            THEN
                p_srcdate := ADD_MONTHS(p_srcdate,1);
            ELSIF p_repaysep = '2'
            THEN
                p_srcdate := ADD_MONTHS(p_srcdate,3);
            ELSIF p_repaysep = '3'
            THEN
                p_srcdate := ADD_MONTHS(p_srcdate,6);
            END IF;
        END IF;
  END LOOP;

  IF p_selcnt = 0
  THEN
        IF p_repaysep = '1'
        THEN
            p_srcdate := ADD_MONTHS(p_srcdate,1);
        ELSIF p_repaysep = '2'
        THEN
            p_srcdate := ADD_MONTHS(p_srcdate,3);
        ELSIF p_repaysep = '3'
        THEN
            p_srcdate := ADD_MONTHS(p_srcdate,6);
        END IF;
  END IF;

  RETURN TO_CHAR(p_srcdate,'YYYY-MM');
EXCEPTION
  WHEN OTHERS
  THEN RETURN NULL;
END;
/
