CREATE FUNCTION fnMask
-- ---------------------------------------------------------------
 -- 함 수 명			: fnMask
 -- 작 성 자         : 최인범
 -- 작성일자         : 2014-04-02
 -- ---------------------------------------------------------------
 -- 함수설명			: 초기준의 시분초 구하기
 -- ---------------------------------------------------------------
(
    p_div   IN VARCHAR2 DEFAULT '' ,
    ip_mask IN VARCHAR2 DEFAULT ''
)
RETURN VARCHAR2
AS
   p_mask VARCHAR2(255) := ip_mask;

BEGIN

    IF ( NVL(TRIM(p_mask), '') IS NULL OR NVL(TRIM(p_mask), ' ') = ' ' ) THEN
        p_mask := p_mask ;
    ELSIF ( p_div = 'Y' ) THEN
        p_mask := '******' ;
    ELSIF ( p_div = 'N' ) THEN
        p_mask := p_mask ;
    END IF;

   RETURN (p_mask);

EXCEPTION WHEN OTHERS THEN RETURN (p_mask);
END;
/
