CREATE PROCEDURE        spACbudg0010R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACbudg0010R
 -- 작 성 자         : 배종성
 -- 작성일자         : 2010-12-22
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2017-01-02
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 월별예산편성현황을 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
 -- select * from ACBUDGYY select * from ACBUDGMM
 -- exec spACbudg0010R 'S','100','11105000','','2009', '','','','N'
 -- exec spACbudg0010R 'S','100','11105000','A101001A1105','2009', '','','','N'
 -- exec spACbudg0010R 'S','100','','','2009', '','','','N'

(
    p_div               IN  VARCHAR2 DEFAULT '' ,
    p_compcode          IN  VARCHAR2 DEFAULT '' ,
    p_acccodeS          IN  VARCHAR2 DEFAULT '' ,
    p_btedeptcodeS      IN  VARCHAR2 DEFAULT '' ,
    p_yyyy              IN  VARCHAR2 DEFAULT '' ,
    p_userid            IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv         IN  VARCHAR2 DEFAULT '' ,
    p_reasontext        IN  VARCHAR2 DEFAULT '' ,
    MESSAGE             OUT VARCHAR2,
    IO_CURSOR           OUT TYPES.DataSet
)
AS

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

   IF ( UPPER(p_div) = 'S' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  CASE WHEN E.grp = 1 THEN a.cyear ELSE '' END cyear  ,
                    CASE WHEN E.grp = 1 THEN a.deptcode ELSE '' END deptcode  ,
                    MAX(CASE WHEN E.grp = 1 THEN c.deptname ELSE '' END)  deptname  ,
                    CASE WHEN E.grp = 1 THEN a.acccode ELSE '' END acccode  ,
                    MAX(CASE WHEN E.grp = 1 THEN D.accname ELSE '합계' END)  accname  ,
                    SUM(a.ybudgamt)  ybudgamt  ,
                    SUM(b.totbudgamt)  totbudgamt  ,
                    SUM(b.restotamt)  restotamt  ,
                    SUM(b.m1budgamt)  m1budgamt  ,
                    SUM(b.m2budgamt)  m2budgamt  ,
                    SUM(b.m3budgamt)  m3budgamt  ,
                    SUM(b.m4budgamt)  m4budgamt  ,
                    SUM(b.m5budgamt)  m5budgamt  ,
                    SUM(b.m6budgamt)  m6budgamt  ,
                    SUM(b.m7budgamt)  m7budgamt  ,
                    SUM(b.m8budgamt)  m8budgamt  ,
                    SUM(b.m9budgamt)  m9budgamt  ,
                    SUM(b.m10budgamt)  m10budgamt  ,
                    SUM(b.m11budgamt)  m11budgamt  ,
                    SUM(b.m12budgamt)  m12budgamt  ,
                    SUM(b.m1restotamt)  m1restotamt  ,
                    SUM(b.m2restotamt)  m2restotamt  ,
                    SUM(b.m3restotamt)  m3restotamt  ,
                    SUM(b.m4restotamt)  m4restotamt  ,
                    SUM(b.m5restotamt)  m5restotamt  ,
                    SUM(b.m6restotamt)  m6restotamt  ,
                    SUM(b.m7restotamt)  m7restotamt  ,
                    SUM(b.m8restotamt)  m8restotamt  ,
                    SUM(b.m9restotamt)  m9restotamt  ,
                    SUM(b.m10restotamt)  m10restotamt  ,
                    SUM(b.m11restotamt)  m11restotamt  ,
                    SUM(b.m12restotamt)  m12restotamt
                    , CASE WHEN E.grp = 1 THEN 0 ELSE 1 END i_order
            FROM    ACBUDGYY a
                    LEFT JOIN ( SELECT  deptcode ,
                                        acccode ,
                                        SUM(budgamt)  totbudgamt  ,
                                        SUM(restotamt)  restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '01' THEN budgamt ELSE 0 END)  m1budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '02' THEN budgamt ELSE 0 END)  m2budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '03' THEN budgamt ELSE 0 END)  m3budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '04' THEN budgamt ELSE 0 END)  m4budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '05' THEN budgamt ELSE 0 END)  m5budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '06' THEN budgamt ELSE 0 END)  m6budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '07' THEN budgamt ELSE 0 END)  m7budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '08' THEN budgamt ELSE 0 END)  m8budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '09' THEN budgamt ELSE 0 END)  m9budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '10' THEN budgamt ELSE 0 END)  m10budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '11' THEN budgamt ELSE 0 END)  m11budgamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '12' THEN budgamt ELSE 0 END)  m12budgamt  ,

                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '01' THEN restotamt ELSE 0 END)  m1restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '02' THEN restotamt ELSE 0 END)  m2restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '03' THEN restotamt ELSE 0 END)  m3restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '04' THEN restotamt ELSE 0 END)  m4restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '05' THEN restotamt ELSE 0 END)  m5restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '06' THEN restotamt ELSE 0 END)  m6restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '07' THEN restotamt ELSE 0 END)  m7restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '08' THEN restotamt ELSE 0 END)  m8restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '09' THEN restotamt ELSE 0 END)  m9restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '10' THEN restotamt ELSE 0 END)  m10restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '11' THEN restotamt ELSE 0 END)  m11restotamt  ,
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '12' THEN restotamt ELSE 0 END)  m12restotamt

                                        FROM    ACBUDGMM
                                        WHERE   compcode = p_compcode
                                                AND budgym BETWEEN p_yyyy || '-01' AND p_yyyy || '-12'
                                                AND ( p_btedeptcodeS IS NULL OR deptcode = p_btedeptcodeS )
                                                AND acccode LIKE p_acccodeS || '%'
                                        GROUP BY deptcode,acccode ) b ON a.deptcode = b.deptcode
                                                                         AND a.acccode = b.acccode
                    LEFT JOIN CMDEPTM c   ON a.deptcode = c.deptcode
                    LEFT JOIN ACACCM D   ON a.acccode = D.acccode
                    JOIN (  SELECT 1 grp FROM DUAL
                            UNION
                            SELECT 2 FROM DUAL ) E ON 1 = 1
            WHERE   a.compcode = p_compcode
                    AND a.cyear = p_yyyy
                    AND ( p_btedeptcodeS IS NULL OR a.deptcode = p_btedeptcodeS )
                    AND a.acccode LIKE p_acccodeS || '%'

            --GROUP BY E.grp , a.cyear, a.deptcode, a.acccode


            GROUP BY E.grp
                     , CASE WHEN E.grp = 1 THEN a.cyear ELSE '' END
                      ,CASE WHEN E.grp = 1 THEN a.deptcode
                            ELSE ''
                        END
                     , CASE WHEN E.grp = 1 THEN a.acccode ELSE '' END

            ORDER BY i_order, grp, cyear, deptcode, acccode ;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
