CREATE PROCEDURE spACacc0022P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0022P
 -- 작 성 자         : 최용석
 -- 작성일자         : 2012-10-04
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-12
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 가수금을 관리하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div               IN VARCHAR2 DEFAULT '' ,
    p_compcode          IN VARCHAR2 DEFAULT '' ,
    p_strdate           IN VARCHAR2 DEFAULT '' ,
    p_enddate           IN VARCHAR2 DEFAULT '' ,
    p_endyn             IN VARCHAR2 DEFAULT '' ,
    p_acct_no           IN VARCHAR2 DEFAULT '' ,
    p_acct_txday        IN VARCHAR2 DEFAULT '' ,
    p_acct_txday_seq    IN NUMBER   DEFAULT 0 ,
    p_userid            IN VARCHAR2 DEFAULT '' ,
    p_reasondiv         IN VARCHAR2 DEFAULT '' ,
    p_reasontext        IN VARCHAR2 DEFAULT '' ,

    MESSAGE             OUT VARCHAR2,
    IO_CURSOR           OUT TYPES.DataSet
)
AS

    v_temp NUMBER := 0;

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO   ATINFO (USERID, REASONDIV, REASONTEXT)
    VALUES (p_userid, p_reasondiv, p_reasontext);

   IF ( UPPER(p_div) = UPPER('S') ) THEN -- 계좌거래내역 검색(수금만)

      OPEN  IO_CURSOR FOR

         SELECT CASE WHEN NVL(TRIM(b.acct_no), '') IS NOT NULL THEN 'Y' ELSE 'N' END seldiv ,-- 선택여부
                NVL(c.accountno, RTRIM(A.acct_no)) acct_no ,-- 계좌번호
                SUBSTR(TRIM(A.acct_txday), 1, 4) || '-' || SUBSTR(TRIM(A.acct_txday), 5, 2) || '-' || SUBSTR(TRIM(A.acct_txday), 7, 2) AS acct_txday ,-- 거래일자
                SUBSTR(TRIM(A.acct_txtime), 1, 2) || ':' || SUBSTR(TRIM(A.acct_txtime), 3, 2) || ':' || SUBSTR(TRIM(A.acct_txtime), 5, 2) AS acct_txtime  ,-- 거래시간
                RTRIM(A.jeokyo) jeokyo ,-- 적요
                A.tx_amt tx_amt ,-- 입금액
                A.acct_txday_seq
           FROM   ISS_ACCT_HIS A
                  LEFT JOIN IBK_ACCT_HIS b   ON   b.compcode = p_compcode
                                                  AND A.acct_no = b.acct_no
                                                  AND A.acct_txday = b.acct_txday
                                                  AND A.acct_txday_seq = b.acct_txday_seq
                  LEFT JOIN CMACCOUNTM c   ON A.acct_no = REPLACE(c.accountno, '-', '')
          WHERE A.inout_gubun = '2'
                AND ( NVL(TRIM(A.acct_no), ' ') LIKE '%' || REPLACE(p_acct_no, '-', '') || '%' OR A.jeokyo LIKE '%' || p_acct_no || '%' )
                AND A.acct_txday BETWEEN REPLACE(p_strdate, '-', '')
                AND REPLACE(p_enddate, '-', '')
                AND ( p_endyn = '0' OR p_endyn = '1' AND A.acct_no = b.acct_no OR p_endyn = '2' AND b.acct_no IS NULL )
                AND A.site_no = ( SELECT REPLACE(businessno, '-', '')
                                  FROM CMPLANTM
                                  WHERE  plantcode = '1000' )
           ORDER BY A.acct_no, A.acct_txday, A.acct_txtime ;


    ELSIF ( UPPER(p_div) = UPPER('I') ) THEN

        -- 가수금 저장
         FOR rec IN (   SELECT  COUNT(*) AS alias1
                        FROM    DUAL
                        WHERE NOT EXISTS (  SELECT  COMPCODE
                                            FROM    IBK_ACCT_HIS
                                            WHERE   compcode = p_compcode
                                                    AND acct_no = REPLACE(p_acct_no, '-', '')
                                                    AND acct_txday = p_acct_txday
                                                    AND acct_txday_seq = p_acct_txday_seq ) )
        LOOP

            v_temp := rec.alias1;

        END LOOP;

        IF v_temp = 1 THEN

            INSERT INTO IBK_ACCT_HIS
                ( SELECT    p_compcode ,
                            acct_no ,
                            acct_txday ,
                            acct_txday_seq ,
                            acct_txtime ,
                            jeokyo ,
                            inout_gubun ,
                            tx_amt
                  FROM      ISS_ACCT_HIS

                  WHERE acct_no = REPLACE(p_acct_no, '-', '')
                        AND acct_txday = p_acct_txday
                        AND acct_txday_seq = p_acct_txday_seq );

        END IF;


    ELSIF ( UPPER(p_div) = UPPER('D') ) THEN

        -- 가수금 삭제
        DELETE  IBK_ACCT_HIS
        WHERE   acct_no = REPLACE(p_acct_no, '-', '')
                AND acct_txday = p_acct_txday
                AND acct_txday_seq = p_acct_txday_seq;

   END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
