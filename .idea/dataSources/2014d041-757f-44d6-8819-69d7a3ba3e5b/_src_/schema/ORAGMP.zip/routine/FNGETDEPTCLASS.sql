CREATE FUNCTION fnGetDeptClass
-- ---------------------------------------------------------------
-- 함 수 명   : fnGetDeptClass
-- 작 성 자         : 최용석
-- 작성일자         : 2015-04-22
-- ---------------------------------------------------------------
-- 함수설명   : 부서 형태
-- ---------------------------------------------------------------
(   p_deptcode      IN  VARCHAR2    DEFAULT '',
    p_rtnselect     IN  NUMBER      DEFAULT 1 -- 1:코드 2:명칭
)
    RETURN VARCHAR2
AS
    p_returnresult      VARCHAR2(50);
BEGIN

    IF p_deptcode IN ('005003', '005016') THEN --관납/NH

        p_returnresult := CASE WHEN p_rtnselect = 1 THEN '12' ELSE '국내 관납' END;

    ELSIF p_deptcode IN ('005001') THEN --본사

        p_returnresult := CASE WHEN p_rtnselect = 1 THEN '13' ELSE '국내 본사관리' END;

    ELSIF (p_deptcode LIKE '005%' AND p_deptcode NOT IN ('005003', '005016', '005001')) THEN -- 관납/NH/본사 제외 나머지

        p_returnresult := CASE WHEN p_rtnselect = 1 THEN '11' ELSE '국내 필드' END;

    ELSIF p_deptcode LIKE '006%' THEN

        p_returnresult := CASE WHEN p_rtnselect = 1 THEN '21' ELSE '해외사업부' END;

    ELSIF p_deptcode LIKE '007%' THEN

        p_returnresult := CASE WHEN p_rtnselect = 1 THEN '31' ELSE '바이오사업부' END;

    ELSIF p_deptcode LIKE '008%' THEN

        p_returnresult := CASE WHEN p_rtnselect = 1 THEN '41' ELSE 'CA사업부' END;

    END IF;

    RETURN (p_returnresult);

END;
/
