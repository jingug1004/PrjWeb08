CREATE PROCEDURE        spACacc0026P
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0026P
-- 작 성 자         : 최용석
-- 작성일자         : 2012-11-05
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2016-12-14
-- ---------------------------------------------------------------
-- 프로시저 설명    : 반제전표완료를 관리하는 프로시저이다.
-- ---------------------------------------------------------------
(
    p_div			IN	   VARCHAR2 DEFAULT '',
    p_compcode		IN	   VARCHAR2 DEFAULT '',
    p_strdate		IN	   VARCHAR2 DEFAULT '',
    p_enddate		IN	   VARCHAR2 DEFAULT '',
    p_viewdiv		IN	   VARCHAR2 DEFAULT '',
    p_acccode		IN	   VARCHAR2 DEFAULT '',
    p_slipinno		IN	   VARCHAR2 DEFAULT '',
    p_slipinseq 	IN	   NUMBER   DEFAULT 0,
    p_userid		IN	   VARCHAR2 DEFAULT '',
    p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
    p_reasontext	IN	   VARCHAR2 DEFAULT '',

    MESSAGE 		OUT    VARCHAR2,
    IO_CURSOR		OUT    TYPES.DataSet
)
AS

    v_temp          NUMBER := 0;

BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF ( UPPER(p_div) = UPPER('S') ) THEN

        OPEN IO_CURSOR FOR

            WITH TT_ACORDRPYM AS
            (            
                SELECT  A.compcode
                        , A.slipinno
                        , A.slipinseq
                        , SUM(c.repayamt) repayamt
                FROM    ACORDD A
                        JOIN ACORDRPYM b ON A.compcode = b.compcode
                                            AND A.slipinno = b.slipinno
                                            AND A.slipinseq = b.slipinseq
                        LEFT JOIN ACORDRPYD c ON b.compcode = c.compcode
                                                 AND b.slipinno = c.slipinno
                                                 AND b.slipinseq = c.slipinseq
                WHERE   A.compcode = p_compcode
                        AND A.acccode = p_acccode
                        AND A.slipdate BETWEEN p_strdate AND p_enddate
                GROUP BY A.compcode, A.slipinno, A.slipinseq
            )
            SELECT	 CASE WHEN D.compcode IS NOT NULL THEN 'Y' ELSE 'N' END seldiv,
                     A.slipinno,
                     A.slipinseq,
                     A.slipdate,
                     A.slipnum,
                     A.acccode,
                     b.accname,
                     A.debamt + A.creamt slipamt,
                     A.debamt + A.creamt - NVL(D.repayamt, 0) - NVL(E.repayamt, 0) restamt,
                     CASE WHEN TRIM(D.compcode) IS NOT NULL OR E.compcode IS NOT NULL THEN '완료'
                          ELSE '미완료'
                     END slipstatus,
                     A.remark1,
                     A.remark2,
                     c.mngcluval1,
                     c.mngcluval2,
                     c.mngcluval3,
                     CASE WHEN NVL(TRIM(D.rpyslipinno), ' ') <> '20100101A0000' THEN 'N' ELSE 'Y' END "MODIFY"
            FROM	 ACORDD A
                     JOIN ACACCM b ON A.acccode = b.acccode
                                      AND (A.dcdiv IN ('1', '4')
                                      AND b.dcdiv = '1' OR A.dcdiv IN ('2', '3')
                                      AND b.dcdiv = '2')
                     LEFT JOIN (SELECT	 A.slipinno
                                         , A.slipinseq
                                         , MAX(CASE WHEN A.ord = 1 THEN mngcluval ELSE '' END) mngcluval1
                                         , MAX(CASE WHEN A.ord = 2 THEN mngcluval ELSE '' END) mngcluval2
                                         , MAX(CASE WHEN A.ord = 3 THEN mngcluval ELSE '' END) mngcluval3
                                FROM	 (  SELECT  A.slipinno
                                                    , A.slipinseq
                                                    , ROW_NUMBER() OVER (PARTITION BY A.slipinno, A.slipinseq ORDER BY b.seq) ord
                                                    , b.mngcluval || ':' || b.mngcludec mngcluval
                                            FROM    ACORDD A
                                                    JOIN ACORDS b ON A.compcode = b.compcode
                                                                     AND A.slipinno = b.slipinno
                                                                     AND A.slipinseq = b.slipinseq
                                            WHERE   A.compcode = p_compcode
                                                    AND A.acccode = p_acccode
                                                    AND A.slipdate BETWEEN p_strdate AND p_enddate ) A
                                GROUP BY A.slipinno, A.slipinseq ) c ON A.slipinno = c.slipinno
                                                                       AND A.slipinseq = c.slipinseq
                     LEFT JOIN (    SELECT	A.compcode
                                            , A.slipinno
                                            , A.slipinseq
                                            , SUM(b.repayamt) repayamt
                                            , MAX(b.rpyslipinno) rpyslipinno
                                    FROM    ACORDD A
                                            JOIN ACORDRPYP b ON A.compcode = b.compcode
                                                                AND A.slipinno = b.slipinno
                                                                AND A.slipinseq = b.slipinseq
                                    WHERE	A.compcode = p_compcode
                                            AND A.acccode = p_acccode
                                            AND A.slipdate BETWEEN p_strdate AND p_enddate
                                    GROUP BY A.compcode, A.slipinno, A.slipinseq    ) D ON  A.compcode = D.compcode
                                                                                            AND A.slipinno = D.slipinno
                                                                                            AND A.slipinseq = D.slipinseq
                     LEFT JOIN TT_ACORDRPYM E ON A.compcode = E.compcode
                                                 AND A.slipinno = E.slipinno
                                                 AND A.slipinseq = E.slipinseq
            WHERE	 A.compcode = p_compcode
                     AND A.acccode = p_acccode
                     AND A.slipdate BETWEEN p_strdate AND p_enddate
                     AND (  p_viewdiv = '0' OR 
                            p_viewdiv = '1' AND ( NVL(TRIM(D.compcode), '') IS NOT NULL OR NVL(TRIM(E.compcode), '') IS NOT NULL ) OR
                            p_viewdiv = '2' AND NVL(TRIM(D.compcode), '') IS NULL AND NVL(TRIM(E.compcode), '') IS NULL)
                     AND NVL(TRIM(E.compcode), '') IS NULL
            ORDER BY A.slipdate, A.slipnum;

    ELSIF ( UPPER(p_div) = UPPER('I') ) THEN

        FOR rec IN (    SELECT COUNT(*) AS alias1
                        FROM   DUAL
                        WHERE  NOT EXISTS
                                   (SELECT *
                                    FROM   ACORDRPYP
                                    WHERE  compcode = p_compcode
                                           AND slipinno = p_slipinno
                                           AND slipinseq = p_slipinseq )
        )
        LOOP
            v_temp := rec.alias1 ;
        END LOOP;

        IF v_temp = 1 THEN

            INSERT INTO ACORDRPYP
                (SELECT compcode,
                        slipinno,
                        slipinseq,
                        '20100101A0000',
                        0,
                        debamt + creamt
                 FROM	ACORDD
                 WHERE	compcode = p_compcode
                        AND slipinno = p_slipinno
                        AND slipinseq = p_slipinseq);


            INSERT INTO ACORDRPYR
                (SELECT compcode, slipinno, slipinseq, debamt + creamt, debamt + creamt
                 FROM	ACORDD
                 WHERE	compcode = p_compcode
                        AND slipinno = p_slipinno
                        AND slipinseq = p_slipinseq);

        END IF;

    ELSIF ( UPPER(p_div) = UPPER('D') ) THEN

        FOR rec IN (    SELECT COUNT(*) AS alias1
                        FROM   DUAL
                        WHERE  EXISTS
                                   (SELECT *
                                    FROM   ACORDRPYP
                                    WHERE  compcode = p_compcode
                                           AND slipinno = p_slipinno
                                           AND slipinseq = p_slipinseq
                                           AND rpyslipinno = '20100101A0000')
        )
        LOOP
            v_temp := rec.alias1 ;
        END LOOP;

        IF v_temp = 1 THEN

            DELETE ACORDRPYR
            WHERE  compcode = p_compcode
                   AND slipinno = p_slipinno
                   AND slipinseq = p_slipinseq;


            DELETE ACORDRPYP
            WHERE  compcode = p_compcode
                   AND slipinno = p_slipinno
                   AND slipinseq = p_slipinseq
                   AND rpyslipinno = '20100101A0000';

        END IF;


	END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
