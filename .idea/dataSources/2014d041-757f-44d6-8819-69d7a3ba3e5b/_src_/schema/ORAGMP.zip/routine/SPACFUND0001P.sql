CREATE PROCEDURE        spACfund0001P
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACfund0001P
   -- 작 성 자         : 최용석
   -- 작성일자         : 2011-02-28
   --  수 정 자         : 임 정호
   --  수정일자          : 2016-12-27
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 적기적금 불입내용을 조회하는 프로시저이다.
   -- ---------------------------------------------------------------
(

   p_div          IN     VARCHAR2 DEFAULT '',
   p_compcode     IN     VARCHAR2 DEFAULT '',
   p_plantcode    IN     VARCHAR2 DEFAULT '',
   p_payym        IN     VARCHAR2 DEFAULT '',
   p_exrtcode     IN     VARCHAR2 DEFAULT '',
   p_exrtprc      IN     FLOAT DEFAULT 0,
   p_accountno    IN     VARCHAR2 DEFAULT '',
   p_deposdiv     IN     VARCHAR2 DEFAULT '',
   p_bankcode     IN     VARCHAR2 DEFAULT '',
   p_slipinno     IN     VARCHAR2 DEFAULT '',
   p_slipinseq    IN     NUMBER DEFAULT 0,
   p_paydate      IN     VARCHAR2 DEFAULT '',
   p_paycnt       IN     NUMBER DEFAULT 0,
   p_payamt       IN     FLOAT DEFAULT 0,
   p_payexamt     IN     FLOAT DEFAULT 0,
   p_accountnop   IN     VARCHAR2 DEFAULT '',
   p_remark       IN     VARCHAR2 DEFAULT '',
   p_create       IN     VARCHAR2 DEFAULT '',
   p_iempcode     IN     VARCHAR2 DEFAULT '',
   p_userid       IN     VARCHAR2 DEFAULT '',
   p_reasondiv    IN     VARCHAR2 DEFAULT '',
   p_reasontext   IN     VARCHAR2 DEFAULT '',
   IO_CURSOR         OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2
)
AS
   v_temp   NUMBER (1, 0) := 0;
   v_cnt    NUMBER (10, 0) := 0;
BEGIN
   MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

   IF (p_div = 'S') THEN

      EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACFUND0001P_CMACCOUNTM';

      INSERT INTO VGT.TT_ACFUND0001P_CMACCOUNTM
         SELECT compcode,                                              -- 회사코드
                plantcode,                                            -- 사업장코드
                'N' selcheck,                                          -- 처리선택
                accountno,                                             -- 계좌번호
                accremark,                                             -- 계좌명칭
                NVL (penddate, expdate) expdate,                       -- 만기일자
                exrtcode,                                              -- 화폐코드
                mainamt,                                               -- 계약금액
                payincnt,                                             -- 총불입횟수
                CASE WHEN TRIM (p_exrtcode) IS NULL THEN paysumamt ELSE paysumexamt END paysumamt,                                          -- 총불입액
                CASE WHEN strdate <= SUBSTR (strdate, 1, 8) || SUBSTR ('0' || payinday, -2) THEN SUBSTR (strdate, 1, 7)
                     ELSE DECODE ( strdate, NULL, NULL, TO_CHAR ( ADD_MONTHS (TO_DATE (strdate, 'YYYY-MM-DD'), 1), 'YYYY-MM'))
                END strym,                                               -- 시작월
                SUBSTR ('0' || RTRIM (payinday), -2) payinday,          -- 불입일
                payinamt,                                              -- 월불입액
                payinamt * p_exrtprc payinexamt,                   -- 월불입액(외화)
                0 paycnt1,                                              -- 미불입
                0 paydate,                                            -- 납부예정일
                0 paycnt2,                                               -- 불입
                0 payamt,                                               -- 불입액
                0 payexamt,                                         -- 불입액(외화)
                ' ' remark
           FROM CMACCOUNTM A
                JOIN
                CMCOMMONM b
                   ON     b.cmmcode = 'AC40'
                      AND A.deposdiv = b.divcode
                      AND b.filter1 = 'P'
          WHERE     compcode = p_compcode
                AND plantcode = p_plantcode
                AND enddiv = 'A'
                AND NVL(exrtcode,-999) = NVL(p_exrtcode,-999)
                AND (   mainamt = 0
                     OR TRIM (p_exrtcode) IS NULL AND mainamt > paysumamt
                     OR     TRIM (p_exrtcode) IS NOT NULL
                        AND mainamt > paysumexamt)
                AND accountno LIKE p_accountno || '%'
                AND isdate (strdate) = 1
                AND strdate <= TO_CHAR ( LAST_DAY (TO_DATE (p_payym, 'YYYY-MM')), 'YYYY-MM-DD')
                AND isnumeric (payinday) = 1
                AND payinamt > 0
                AND deposdiv LIKE p_deposdiv
                AND bankcode LIKE p_bankcode;

      UPDATE VGT.TT_ACFUND0001P_CMACCOUNTM
         SET strym =
                CASE
                   WHEN strym = p_payym
                   THEN
                      p_payym
                   ELSE
                      TO_CHAR ( ADD_MONTHS (TO_DATE (strym || '-01', 'YYYY-MM-DD'), payincnt), 'YYYY-MM')
                END
       WHERE payincnt > 0;

-------------------------------------
-------------------------------------
--------------------------------------
      LOOP

         SELECT COUNT (*) INTO v_temp
           FROM DUAL
          WHERE EXISTS
                   (SELECT *
                      FROM VGT.TT_ACFUND0001P_CMACCOUNTM
                     WHERE     strym || '-' || payinday <= expdate
                           AND strym <= p_payym
                           AND mainamt >= payamt + payinamt);


         IF v_temp != 1 THEN

            EXIT;
         END IF;



         UPDATE VGT.TT_ACFUND0001P_CMACCOUNTM
            SET strym = TO_CHAR ( ADD_MONTHS (TO_DATE (strym || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM'),
                paycnt1 = paycnt1 + 1,
                paydate = strym || '-' || payinday,
                paycnt2 = paycnt2 + 1,
                payamt = payamt + payinamt,
                payexamt =
                   CASE
                      WHEN TRIM (p_exrtcode) IS NULL THEN 0
                      ELSE payexamt + payinexamt
                   END
          WHERE     strym || '-' || payinday <= expdate
                AND strym <= p_payym
                AND mainamt >= payamt + payinamt;



      END LOOP;
---------------------

      UPDATE VGT.TT_ACFUND0001P_CMACCOUNTM
         SET paydate =
                CASE
                   WHEN isdate (paydate) = 1 THEN
                      paydate
                   ELSE
                      TO_CHAR (TO_DATE (strym || '-01', 'YYYY-MM-DD') - 1, 'YYYY-MM-DD')
                END,
             payexamt = round(payexamt, 0);

      OPEN IO_CURSOR FOR
           SELECT *
             FROM VGT.TT_ACFUND0001P_CMACCOUNTM
            WHERE payamt > 0
         ORDER BY accountno;
   ELSIF (p_div = 'I') THEN

      INSERT INTO ACORDD (compcode,
                          slipinno,
                          slipinseq,
                          dcdiv,
                          acccode,
                          plantcode,
                          debamt,
                          creamt,
                          slipdate,
                          slipnum,
                          remark1,
                          remark2,
                          taxno,
                          datadiv,
                          rptseq,
                          insertdt,
                          iempcode)
           SELECT A.compcode,
                  p_slipinno,
                  p_slipinseq + b.acautoseq,
                  b.dcdiv,
                  CASE
                     WHEN b.dcdiv = '1' THEN

                        NVL (A.acccode, b.acacccode)
                     ELSE
                        b.acacccode
                  END
                     col,
                  A.plantcode,
                  CASE
                     WHEN b.dcdiv = '1' THEN
                        CASE WHEN b.accamtdiv = '01' THEN p_payamt ELSE 0 END
                     ELSE
                        0
                  END
                     col,
                  CASE
                     WHEN b.dcdiv = '2' THEN
                        CASE WHEN b.accamtdiv = '01' THEN p_payamt ELSE 0 END
                     ELSE
                        0
                  END
                     col,
                  p_paydate,
                  SUBSTR (p_slipinno, -5, 5),
                  CASE
                     WHEN b.dcdiv = '1' THEN
                           A.accremark
                        || ' '
                        || TO_CHAR (p_paycnt)
                        || '회 불입'
                     ELSE
                        p_remark
                  END
                     col,
                  c.remark2,
                  ' ',
                  CASE
                     WHEN p_create = '0' THEN TO_CHAR (b.acautoseq)
                     ELSE ' '
                  END
                     col,
                  p_slipinseq + b.acautoseq,
                  SYSDATE,
                  p_iempcode
             FROM CMACCOUNTM A
                  JOIN
                  ACAUTORULESM b
                     ON b.acautorcode =
                           CASE
                              WHEN p_accountnop = ' ' THEN 'A03210'
                              ELSE 'A03211'
                           END
                  JOIN ACAUTORULE c ON b.acautorcode = c.acautorcode
            WHERE     A.compcode = p_compcode
                  AND A.accountno = p_accountno
                  AND p_payamt <> 0
         ORDER BY b.acautoseq;

      INSERT INTO ACORDS (compcode,
                          slipinno,
                          slipinseq,
                          mngclucode,
                          seq,
                          mngcluval,
                          mngcludec,
                          insertdt,
                          iempcode)
           SELECT A.compcode,
                  p_slipinno,
                  p_slipinseq + b.acautoseq,
                  c.mngclucode,
                  ROW_NUMBER () OVER (PARTITION BY b.acautoseq ORDER BY D.seq),
                  CASE c.mngcluvaldiv
                     WHEN '01' THEN
                        A.deptcode
                     WHEN '05' THEN
                        A.expdate
                     WHEN '11' THEN
                        CASE WHEN b.dcdiv = '1' THEN p_accountno ELSE p_accountnop END
                     ELSE
                        ' '
                  END,
                  CASE c.mngcludecdiv
                     WHEN '01' THEN
                        E.deptname
                     WHEN '05' THEN
                        A.expdate
                     WHEN '11' THEN
                        CASE
                           WHEN b.dcdiv = '1' THEN A.accremark
                           ELSE f.accremark
                        END
                     ELSE
                        ' '
                  END,
                  SYSDATE,
                  p_iempcode
             FROM CMACCOUNTM A
                  JOIN
                  ACAUTORULESM b
                     ON b.acautorcode =
                           CASE
                              WHEN p_accountnop = ' ' THEN 'A03210'
                              ELSE 'A03211'
                           END
                  JOIN ACAUTORULEDS c
                     ON     b.acautorcode = c.acautorcode
                        AND b.acautoseq = c.acautoseq
                  LEFT JOIN ACACCMNGM D
                     ON     b.acacccode = D.acccode
                        AND b.dcdiv = D.dcdiv
                        AND c.mngclucode = D.mngclucode
                  LEFT JOIN CMDEPTM E ON A.deptcode = E.deptcode
                  LEFT JOIN CMACCOUNTM f
                     ON A.compcode = f.compcode AND f.accountno = p_accountnop
            WHERE     A.compcode = p_compcode
                  AND A.accountno = p_accountno
                  AND p_payamt <> 0
         ORDER BY b.acautoseq, D.seq;

      UPDATE CMACCOUNTM A
         SET A.payincnt = payincnt + p_paycnt,
             A.paysumamt = paysumamt + p_payamt,
             A.paysumexamt = paysumexamt + p_payexamt,
             A.enddiv =
                CASE
                   WHEN mainamt <=
                           CASE
                              WHEN p_exrtcode = ' ' THEN paysumamt + p_payamt
                              ELSE paysumexamt + p_payexamt
                           END
                   THEN
                      'B'
                   ELSE
                      enddiv
                END,
             A.updatedt = SYSDATE,
             A.uempcode = p_iempcode
       WHERE A.compcode = p_compcode AND A.accountno = p_accountno;

      FOR rec IN
      (
        SELECT  MAX (p_slipinseq + b.acautoseq) AS alias1
        FROM    CMACCOUNTM A
                JOIN ACAUTORULESM b
                    ON b.acautorcode = CASE WHEN TRIM(p_accountnop) IS NULL THEN 'A03210' ELSE 'A03211' END
        WHERE   A.compcode = p_compcode
            AND A.accountno = p_accountno
            AND p_payamt <> 0)
      LOOP
         MESSAGE := rec.alias1;
      END LOOP;
   END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
