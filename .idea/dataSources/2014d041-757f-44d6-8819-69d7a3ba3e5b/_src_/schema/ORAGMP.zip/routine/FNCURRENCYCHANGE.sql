CREATE FUNCTION        fnCurrencyChange(
    -- ---------------------------------------------------------------
    -- 함 수 명			: fnRerturnLmtamt
    -- 작 성 자         : 
    -- 작성일자         : 2016-06-01
    -- 수 정 자       :   노영래
	-- 수정일자        :   2017-07-31
    -- ---------------------------------------------------------------
    -- 함수설명			: 해당 거래처의 외화채권 금액을 리턴
    -- SELECT [dbo].[fnCurrencyChange] ('2016-09-07',1000000)
    -- ---------------------------------------------------------------
    p_basedate       IN		VARCHAR2 	DEFAULT '',   --환율적용일
    p_baseamt		 IN		NUMBER 		DEFAULT 0
)
	RETURN VARCHAR2
AS
	p_Balancecur	VARCHAR(12); -- 채권통화
	p_BalanceRate	NUMBER(15, 4) := 1; -- 채권환율
	-- 리턴용 변수
	p_ReturnValue	NUMBER(15, 4); -- 잔고금액
BEGIN
	-- 계산용 변수


	-- 2. 해당 채권통화의 환율 조회
	FOR REC IN (SELECT NVL(EXCHANGERATE, 1) c1
				  FROM ASEXCHANGEM
				 WHERE CURRENCY = 'USD'
					   AND EXCHANGEDATE = p_basedate)
	LOOP
		p_BalanceRate := REC.c1;
	END LOOP;

	-- 3. 통화금액 계산
	FOR REC IN (SELECT p_baseamt / p_BalanceRate c1 FROM DUAL)
	LOOP
		p_ReturnValue := REC.c1;
	END LOOP;

	-- 4. 리턴
	RETURN (p_ReturnValue);
EXCEPTION
	WHEN OTHERS
	THEN
		p_ReturnValue := '';
END;
/
