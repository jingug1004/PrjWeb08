CREATE PROCEDURE spACacc0114R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0114R
 -- 수 정 자         : 배종성
 -- 수정일자         : 2010-12-14
 --수정자         :  임 정호
 -- 수정일         : 2016-12-20
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 계정명세서를 조회하는 프로시저이다.    --전면수정
 -- ---------------------------------------------------------------
 -- select * from ACORDM 회계전표내역
 -- select * from ACORDD 회계전표상세내역
 -- select * from ACACCM 계정과목마스터
 -- select * from ACORDS 회계전표관리항목내역
 -- select * from ACACCMNGM 계정별관리항목마스터
 -- select * from ACORDSMM 회계전표관리항목월집계
 -- select * from ACMNGM 관리항목마스터
 -- exec spACacc0114R 'S','100','%','11101031','1','2010-09-01','2010-10-10','','','1', '','','','N'
 -- exec spACacc0114R 'S','100','%','11101031','1','2010-09-01','2010-12-17','','','1', '','','','N'

(
    p_div IN VARCHAR2 DEFAULT '' ,
    p_compcode IN VARCHAR2 DEFAULT '' ,
    p_plantcode IN VARCHAR2 DEFAULT '' ,
    p_acccode IN VARCHAR2 DEFAULT '' ,
    p_dcdiv IN VARCHAR2 DEFAULT '' ,
    p_startdt IN VARCHAR2 DEFAULT '' ,
    p_enddt IN VARCHAR2 DEFAULT '' ,
    p_bteacccodeS1 IN VARCHAR2 DEFAULT '' ,
    p_bteacccodeS2 IN VARCHAR2 DEFAULT '' ,
    p_outputdiv IN NUMBER DEFAULT 0 ,
    p_userid IN VARCHAR2 DEFAULT '' ,
    p_reasondiv IN VARCHAR2 DEFAULT '' ,
    p_reasontext IN VARCHAR2 DEFAULT '' ,
    IO_CURSOR         OUT TYPES.DataSet,
    MESSAGE           OUT VARCHAR2
)
AS
   p_odiv1 VARCHAR2(5);
   p_odiv2 VARCHAR2(5);
   p_cashcode VARCHAR2(20);

BEGIN

   MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( p_outputdiv = '1' ) THEN
    --K-GAAP
        p_odiv1 := '20' ;
        p_odiv2 := 'F' ;
    END IF;

    IF ( p_outputdiv = '2' ) THEN
    --IFRS
        p_odiv1 := '30' ;
        p_odiv2 := 'K' ;
    END IF;

    p_cashcode := '11101010';
    for rec in (
        select  value1
        from    SYSPARAMETERMANAGE
        where   parametercode = 'acccashcode')
    loop
        p_cashcode := rec.value1;
    end loop;
        
    p_cashcode := '11101010x';

    IF ( trim(p_div) = 'S' ) THEN
      OPEN  IO_CURSOR FOR
         SELECT A.mngclucode ,
                CASE mngcluval
                              WHEN 'ZZZZZZZZZZZZZZZZZZZZ' THEN b.mngcluname || ' 합계'
                ELSE b.mngcluname
                   END mngcluname  ,
                CASE mngcluval
                              WHEN 'ZZZZZZZZZZZZZZZZZZZZ' THEN ''
                ELSE mngcluval
                   END mngcluval  ,
                mngcludec ,
                bsamt ,
                debamt ,
                creamt ,
                fnamt
           FROM (
--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                    SELECT  mngclucode,
                            mngcluval,
                            mngcludec,
                            bsamt,
                            debamt,
                            creamt,
                            fnamt
                    FROM (
                            SELECT mngclucode,
                                   mngcluval,
                                   mngcludec,
                                   bsamt,
                                   debamt,
                                   creamt,
                                   CASE p_dcdiv
                                      WHEN '1' THEN bsamt + debamt - creamt
                                      WHEN '2' THEN bsamt + creamt - debamt
                                   END
                                      fnamt                                                         --전기잔액
                              FROM (
            -------------------------------
                                      SELECT mngclucode,
                                             mngcluval,
                                             MAX (mngcludec) mngcludec,
                                             SUM (bsamt) bsamt,
                                             SUM (debamt) debamt,
                                             SUM (creamt) creamt
                                        FROM (  SELECT mngclucode,
                                                       mngcluval,
                                                       MAX (mngcludec) mngcludec,
                                                       SUM (bsamt) bsamt,                                   --전기이월
                                                       0 debamt,
                                                       0 creamt
                                                  FROM (  SELECT NVL (mngclucode, '') mngclucode,
                                                                 NVL (mngcluval, '') mngcluval,
                                                                 NVL (mngcludec, '') mngcludec,
                                                                 CASE p_dcdiv
                                                                    WHEN '1' THEN SUM (A.bsdebamt) - SUM (A.bscreamt)
                                                                    WHEN '2' THEN SUM (A.bscreamt) - SUM (A.bsdebamt)
                                                                 END
                                                                    bsamt,                                  --전기이월
                                                                 0 debamt,
                                                                 0 creamt
                                                            FROM ACORDSMM A LEFT JOIN ACACCM b ON b.acccode = A.acccode
                                                           WHERE     A.compcode = p_compcode
                                                                 AND A.plantcode LIKE p_plantcode
                                                                 AND A.acccode = p_acccode
                                                                 AND slipym = SUBSTR (p_startdt, 1, 7)
                                                                 AND (closediv = '10' OR closediv = p_odiv1 ) -- 출력구분 [K-GAAP, IFRS]
                                                                 AND (   bsdebamt <> 0
                                                                      OR bscreamt <> 0
                                                                      OR debamt <> 0
                                                                      OR creamt <> 0)
                                                        GROUP BY mngclucode, mngcluval, mngcludec
                                                        UNION ALL
                                                          SELECT NVL (mngclucode, '') mngclucode,
                                                                 NVL (b.mngcluval, '') mngcluval,
                                                                 MAX (NVL (b.mngcludec, '')) mngcludec,
                                                                 CASE p_dcdiv
                                                                    WHEN '1' THEN SUM (A.debamt) - SUM (A.creamt)
                                                                    WHEN '2' THEN SUM (A.creamt) - SUM (A.debamt)
                                                                 END bsamt,                                  --전기잔액
                                                                 0 debamt,
                                                                 0 creamt
                                                            FROM ACORDD A
                                                                 LEFT JOIN
                                                                 ACORDS b
                                                                    ON     b.compcode = A.compcode
                                                                       AND b.slipinno = A.slipinno
                                                                       AND b.slipinseq = A.slipinseq
                                                                 LEFT JOIN
                                                                 ACORDM c
                                                                    ON     c.compcode = A.compcode
                                                                       AND c.plantcode = A.plantcode
                                                                       AND c.slipinno = A.slipinno
                                                           WHERE     A.compcode = p_compcode
                                                                 AND A.plantcode LIKE p_plantcode
                                                                 AND A.slipdate < p_startdt
                                                                 AND A.slipdate >= SUBSTR (p_startdt, 1, 7) || '-01'
                                                                 AND A.acccode = p_acccode
                                                                 AND c.slipdiv <> p_odiv2
                                                        GROUP BY mngclucode, mngcluval) A
                                              GROUP BY mngclucode, mngcluval
                                              UNION ALL
                                                SELECT NVL (mngclucode, '') mngclucode,
                                                       NVL (b.mngcluval, '') mngcluval,
                                                       MAX (b.mngcludec) mngcludec,
                                                       0 bsamt,                                             --전기잔액
                                                       SUM (A.debamt) 차변금액,
                                                       SUM (A.creamt) 대변금액
                                                  FROM ACORDD A
                                                       LEFT JOIN
                                                       ACORDS b
                                                          ON     b.compcode = A.compcode
                                                             AND b.slipinno = A.slipinno
                                                             AND b.slipinseq = A.slipinseq
                                                       LEFT JOIN
                                                       ACORDM c
                                                          ON     c.compcode = A.compcode
                                                             AND c.plantcode = A.plantcode
                                                             AND c.slipinno = A.slipinno
                                                 WHERE     A.compcode = p_compcode
                                                       AND A.plantcode LIKE p_plantcode
                                                       AND A.slipdate BETWEEN p_startdt AND p_enddt
                                                       AND A.acccode =p_acccode
                                                       AND c.slipdiv <> p_odiv2      -- K-GAAP <> 'F', IFRS <> 'K'
                                              GROUP BY b.mngclucode, b.mngcluval) A
                                    GROUP BY mngclucode, mngcluval
                                    ORDER BY mngclucode, mngcluval
            -------------------------------
                                    ) tt_ACacc0114R1
                            UNION ALL
                              SELECT mngclucode,
                                     'ZZZZZZZZZZZZZZZZZZZZ' mngcluval,
                                     '' mngcludec,
                                     SUM (bsamt) bsamt,
                                     SUM (debamt) debamt,
                                     SUM (creamt) creamt,
                                     CASE p_dcdiv
                                        WHEN '1' THEN SUM (bsamt) + SUM (debamt) - SUM (creamt)
                                        WHEN '2' THEN SUM (bsamt) + SUM (creamt) - SUM (debamt)
                                     END
                                        fnamt                                                       --전기잔액
                                FROM (
            --------------------------------------------
                                          SELECT mngclucode,
                                                 mngcluval,
                                                 MAX (mngcludec) mngcludec,
                                                 SUM (bsamt) bsamt,
                                                 SUM (debamt) debamt,
                                                 SUM (creamt) creamt
                                            FROM (  SELECT mngclucode,
                                                           mngcluval,
                                                           MAX (mngcludec) mngcludec,
                                                           SUM (bsamt) bsamt,                                   --전기이월
                                                           0 debamt,
                                                           0 creamt
                                                      FROM (  SELECT NVL (mngclucode, '') mngclucode,
                                                                     NVL (mngcluval, '') mngcluval,
                                                                     NVL (mngcludec, '') mngcludec,
                                                                     CASE p_dcdiv
                                                                        WHEN '1' THEN SUM (A.bsdebamt) - SUM (A.bscreamt)
                                                                        WHEN '2' THEN SUM (A.bscreamt) - SUM (A.bsdebamt)
                                                                     END
                                                                        bsamt,                                  --전기이월
                                                                     0 debamt,
                                                                     0 creamt
                                                                FROM ACORDSMM A LEFT JOIN ACACCM b ON b.acccode = A.acccode
                                                               WHERE     A.compcode = p_compcode
                                                                     AND A.plantcode LIKE p_plantcode
                                                                     AND A.acccode = p_acccode
                                                                     AND slipym = SUBSTR (p_startdt, 1, 7)
                                                                     AND (closediv = '10' OR closediv = p_odiv1 ) -- 출력구분 [K-GAAP, IFRS]
                                                                     AND (   bsdebamt <> 0
                                                                          OR bscreamt <> 0
                                                                          OR debamt <> 0
                                                                          OR creamt <> 0)
                                                            GROUP BY mngclucode, mngcluval, mngcludec
                                                            UNION ALL
                                                              SELECT NVL (mngclucode, '') mngclucode,
                                                                     NVL (b.mngcluval, '') mngcluval,
                                                                     MAX (NVL (b.mngcludec, '')) mngcludec,
                                                                     CASE p_dcdiv
                                                                        WHEN '1' THEN SUM (A.debamt) - SUM (A.creamt)
                                                                        WHEN '2' THEN SUM (A.creamt) - SUM (A.debamt)
                                                                     END bsamt,                                  --전기잔액
                                                                     0 debamt,
                                                                     0 creamt
                                                                FROM ACORDD A
                                                                     LEFT JOIN
                                                                     ACORDS b
                                                                        ON     b.compcode = A.compcode
                                                                           AND b.slipinno = A.slipinno
                                                                           AND b.slipinseq = A.slipinseq
                                                                     LEFT JOIN
                                                                     ACORDM c
                                                                        ON     c.compcode = A.compcode
                                                                           AND c.plantcode = A.plantcode
                                                                           AND c.slipinno = A.slipinno
                                                               WHERE     A.compcode = p_compcode
                                                                     AND A.plantcode LIKE p_plantcode
                                                                     AND A.slipdate < p_startdt
                                                                     AND A.slipdate >= SUBSTR (p_startdt, 1, 7) || '-01'
                                                                     AND A.acccode = p_acccode
                                                                     AND c.slipdiv <> p_odiv2
                                                            GROUP BY mngclucode, mngcluval) A
                                                  GROUP BY mngclucode, mngcluval
                                                  UNION ALL
                                                    SELECT NVL (mngclucode, '') mngclucode,
                                                           NVL (b.mngcluval, '') mngcluval,
                                                           MAX (b.mngcludec) mngcludec,
                                                           0 bsamt,                                             --전기잔액
                                                           SUM (A.debamt) 차변금액,
                                                           SUM (A.creamt) 대변금액
                                                      FROM ACORDD A
                                                           LEFT JOIN
                                                           ACORDS b
                                                              ON     b.compcode = A.compcode
                                                                 AND b.slipinno = A.slipinno
                                                                 AND b.slipinseq = A.slipinseq
                                                           LEFT JOIN
                                                           ACORDM c
                                                              ON     c.compcode = A.compcode
                                                                 AND c.plantcode = A.plantcode
                                                                 AND c.slipinno = A.slipinno
                                                     WHERE     A.compcode = p_compcode
                                                           AND A.plantcode LIKE p_plantcode
                                                           AND A.slipdate BETWEEN p_startdt AND p_enddt
                                                           AND A.acccode = p_acccode
                                                           AND c.slipdiv <> p_odiv2      -- K-GAAP <> 'F', IFRS <> 'K'
                                                  GROUP BY b.mngclucode, b.mngcluval) A
                                        GROUP BY mngclucode, mngcluval
                                        ORDER BY mngclucode, mngcluval
            --------------------------------------------
                                     )tt_ACacc0114R1
                            GROUP BY mngclucode
                              ) A
                    ORDER BY mngclucode, mngcluval NULLS first
--!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                )/*tt_ACacc0114R2*/ A
                  LEFT JOIN ACMNGM b   ON NVL(A.mngclucode,' ') = NVL(b.mngclucode, ' ');

    ELSIF ( p_div = 'A' ) THEN
        OPEN  IO_CURSOR FOR
        SELECT  acccode , accname , dcdiv
        FROM    ACACCM
        WHERE   orduseyn = 'Y'
            AND acccode != p_cashcode
        ORDER BY acccode;
    ELSIF ( p_div = 'A1' ) THEN

        OPEN  IO_CURSOR FOR
        SELECT  acccode, accname, dcdiv
        FROM    ACACCM
        WHERE     orduseyn = 'Y'
            AND (   (acccode BETWEEN nvl(p_bteacccodeS1, ' ') AND nvl(p_bteacccodeS2, ' '))
                    OR (acccode BETWEEN nvl(p_bteacccodeS2, ' ') AND nvl(p_bteacccodeS1, ' ')))
            AND acccode != p_cashcode
        ORDER BY acccode;
    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
