CREATE PROCEDURE        spACacc0302R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0302R
	-- 작 성 자         : 배종성
	-- 작성일자         : 2011-03-21
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 매출채권명세서를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_yymm			IN	   VARCHAR2 DEFAULT '',
	p_outputdiv 	IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	p_odiv1   VARCHAR2(5);
	p_odiv2   VARCHAR2(5);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_outputdiv = '1')
	THEN
		--K-GAAP
		p_odiv1 := '20';
		p_odiv2 := 'F';
	END IF;

	IF (p_outputdiv = '2')
	THEN
		--IFRS
		p_odiv1 := '30';
		p_odiv2 := 'K';
	END IF;

	IF (p_div = 'S')
	THEN
		-- 부문별
		OPEN IO_CURSOR FOR
			SELECT	 'a' rptdiv,
					 p_outputdiv outputdiv,
					 p_yymm slipym,
					 p_plantcode plantcode,
					 a.acccode,
					 MAX(c.accname) accname,
					 '' mngcluval,
					 '' mngcludec,
					 '' custbusinessno,
					 '' whenissued, --발행일
					 '' detail, --내역
					 SUM(CASE WHEN c.dcdiv = '1' THEN a.totdebamt - a.totcreamt ELSE a.totcreamt - a.totdebamt END) totamt,
					 '' remark
			FROM	 ACORDDMM a
					 JOIN CMCOMMONM b
						 ON cmmcode = 'AC252'
							AND a.acccode = b.filter1
					 LEFT JOIN ACACCM c ON a.acccode = c.acccode
			WHERE	 a.compcode = p_compcode
					 AND a.plantcode LIKE p_plantcode
					 AND a.slipym = p_yymm
					 AND (closediv = '10'
						  OR closediv = p_odiv1)
			GROUP BY a.acccode
			HAVING	 SUM(a.totcreamt) <> SUM(a.totdebamt)
			ORDER BY a.acccode;
	ELSIF (p_div = 'S1')
	THEN
		-- 개별
		OPEN IO_CURSOR FOR
			SELECT	 'b' rptdiv,
					 p_outputdiv outputdiv,
					 p_yymm slipym,
					 p_plantcode plantcode,
					 a.acccode,
					 MAX(c.accname) accname,
					 a.mngcluval mngcluval,
					 MAX(NVL(D.custname, a.mngcludec)) mngcludec,
					 MAX(D.businessno) custbusinessno,
					 MAX(E.slipdate) whenissued, --발행일
					 MAX(E.remark1) detail, --내역
					 SUM(CASE WHEN c.dcdiv = '1' THEN a.totdebamt - a.totcreamt ELSE a.totcreamt - a.totdebamt END) totamt,
					 '' remark
			FROM	 ACORDSMM a
					 JOIN CMCOMMONM b
						 ON cmmcode = 'AC252'
							AND a.acccode = b.filter1
					 LEFT JOIN ACACCM c ON a.acccode = c.acccode
					 LEFT JOIN CMCUSTM D ON a.mngcluval = D.custcode
					 LEFT JOIN (SELECT a.acccode, a.mngcluval, a.slipdate, a.remark1
								FROM   (SELECT a.slipinno,
											   a.slipinseq,
											   a.slipdate,
											   a.acccode,
											   a.debamt,
											   a.creamt,
											   a.remark1,
											   D.mngcluval
										FROM   ACORDD a
											   JOIN CMCOMMONM b
												   ON cmmcode = 'AC252'
													  AND a.acccode = b.filter1
											   JOIN ACACCM c ON a.acccode = c.acccode
											   JOIN ACORDS D
												   ON D.compcode = p_compcode
													  AND a.slipinno = D.slipinno
													  AND a.slipinseq = D.slipinseq
													  AND D.mngclucode = b.filter2
										WHERE  a.compcode = p_compcode
											   AND a.plantcode LIKE p_plantcode
											   AND a.slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_yymm, 'YYYY-MM'), -12 * 3), 'YYYY-MM-DD') AND TO_CHAR(LAST_DAY(TO_DATE(p_yymm, 'YYYY-MM')), 'YYYY-MM-DD')
											   AND (c.dcdiv = '1'
													AND a.debamt <> 0
													OR c.dcdiv = '2'
													   AND a.creamt <> 0)) a
									   JOIN (SELECT   a.acccode, a.mngcluval, a.slipinno, MAX(a.slipinseq) slipinseq
											 FROM	  (SELECT a.slipinno,
															  a.slipinseq,
															  a.slipdate,
															  a.acccode,
															  a.debamt,
															  a.creamt,
															  a.remark1,
															  D.mngcluval
													   FROM   ACORDD a
															  JOIN CMCOMMONM b
																  ON cmmcode = 'AC252'
																	 AND a.acccode = b.filter1
															  JOIN ACACCM c ON a.acccode = c.acccode
															  JOIN ACORDS D
																  ON D.compcode = p_compcode
																	 AND a.slipinno = D.slipinno
																	 AND a.slipinseq = D.slipinseq
																	 AND D.mngclucode = b.filter2
													   WHERE  a.compcode = p_compcode
															  AND a.plantcode LIKE p_plantcode
															  AND a.slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_yymm, 'YYYY-MM'), -12 * 3), 'YYYY-MM-DD') AND TO_CHAR(LAST_DAY(TO_DATE(p_yymm, 'YYYY-MM')), 'YYYY-MM-DD')
															  AND (c.dcdiv = '1'
																   AND a.debamt <> 0
																   OR c.dcdiv = '2'
																	  AND a.creamt <> 0)) a
													  JOIN (SELECT	 acccode, mngcluval, MAX(slipinno) slipinno
															FROM	 (SELECT a.slipinno,
																			 a.slipinseq,
																			 a.slipdate,
																			 a.acccode,
																			 a.debamt,
																			 a.creamt,
																			 a.remark1,
																			 D.mngcluval
																	  FROM	 ACORDD a
																			 JOIN CMCOMMONM b
																				 ON cmmcode = 'AC252'
																					AND a.acccode = b.filter1
																			 JOIN ACACCM c ON a.acccode = c.acccode
																			 JOIN ACORDS D
																				 ON D.compcode = p_compcode
																					AND a.slipinno = D.slipinno
																					AND a.slipinseq = D.slipinseq
																					AND D.mngclucode = b.filter2
																	  WHERE  a.compcode = p_compcode
																			 AND a.plantcode LIKE p_plantcode
																			 AND a.slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_yymm, 'YYYY-MM'), -12 * 3), 'YYYY-MM-DD') AND TO_CHAR(LAST_DAY(TO_DATE(p_yymm, 'YYYY-MM')), 'YYYY-MM-DD')
																			 AND (c.dcdiv = '1'
																				  AND a.debamt <> 0
																				  OR c.dcdiv = '2'
																					 AND a.creamt <> 0))
															GROUP BY acccode, mngcluval) b
														  ON a.acccode = b.acccode
															 AND a.slipinno = b.slipinno
															 AND a.mngcluval = b.mngcluval
											 GROUP BY a.acccode, a.mngcluval, a.slipinno) b
										   ON a.slipinno = b.slipinno
											  AND a.slipinseq = b.slipinseq) E
						 ON a.acccode = E.acccode
							AND a.mngcluval = E.mngcluval
			WHERE	 a.compcode = p_compcode
					 AND a.plantcode LIKE p_plantcode
					 AND a.slipym = p_yymm
					 AND (a.closediv = '10'
						  OR a.closediv = p_odiv1)
					 AND a.mngclucode = b.filter2
			GROUP BY a.acccode, a.mngcluval
			HAVING	 SUM(a.totcreamt) <> SUM(a.totdebamt)
			ORDER BY a.acccode, a.mngcluval;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
