CREATE PROCEDURE        spACbudg0106R
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACbudg0106R
   -- 작 성 자         : 배종성
   -- 작성일자         : 2011-01-03
   -- 수 정 자         : 임 정호
   -- 수정일자         : 2017-01-02
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 예산집계분석보고서 조회하는 프로시저이다.
   -- ---------------------------------------------------------------
(

   p_div          IN     VARCHAR2 DEFAULT '',
   p_compcode     IN     VARCHAR2 DEFAULT '',
   p_yyyymm       IN     VARCHAR2 DEFAULT '',
   p_deptcode1    IN     VARCHAR2 DEFAULT '',
   p_deptcode2    IN     VARCHAR2 DEFAULT '',
   p_userid       IN     VARCHAR2 DEFAULT '',
   p_reasondiv    IN     VARCHAR2 DEFAULT '',
   p_reasontext   IN     VARCHAR2 DEFAULT '',
   IO_CURSOR         OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2)
AS
   p_deptcodeS   VARCHAR2 (20);
   p_acccodeS    VARCHAR2 (20);
   p_rows        NUMBER (10, 0);
BEGIN
   MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

   IF (p_div = 'S') THEN
      EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0106R_DUAL ';
      INSERT INTO VGT.TT_ACBUDG0106R_DUAL
         SELECT compcode,
                cyear,
                deptcode,
                acccode,
                ybudgamt,
                remark,
                insertdt,
                iempcode
           FROM ACBUDGYY
          WHERE     compcode = p_compcode
                AND cyear = SUBSTR (p_yyyymm, 0, 4)
                AND (NVL(p_deptcode1,' ') > ' ' AND deptcode >= NVL(p_deptcode1,' ') OR trim(p_deptcode1) IS NULL )
                AND (NVL(p_deptcode2,' ') > ' ' AND deptcode <= NVL(p_deptcode2,' ') OR trim(p_deptcode2) IS NULL );

      FOR REC IN
      (

        SELECT  deptcode, acccode
        FROM    ACBUDGMM
        WHERE   compcode = p_compcode
                AND SUBSTR (budgym, 0, 4) = SUBSTR (p_yyyymm, 0, 4)
                AND (NVL(p_deptcode1,' ') > ' ' AND deptcode >= NVL(p_deptcode1,' ') OR trim(p_deptcode1) IS NULL )
                AND (NVL(p_deptcode2,' ') > ' ' AND deptcode <= NVL(p_deptcode2,' ') OR trim(p_deptcode2) IS NULL )

      )
      LOOP
         p_deptcodeS := REC.deptcode;
         p_acccodeS := REC.acccode;
         p_rows := 0;

         FOR rec IN
         (
            SELECT  COUNT (*) AS alias1
            FROM    ACBUDGYY
            WHERE   compcode = p_compcode
                AND cyear = SUBSTR (p_yyyymm, 0, 4)
                AND deptcode = p_deptcodeS
                AND acccode = p_acccodeS
         )
         LOOP
            p_rows := rec.alias1;
         END LOOP;

         IF (p_rows = 0) THEN
            INSERT INTO VGT.TT_ACBUDG0106R_DUAL (compcode, cyear, deptcode, acccode,
                                                 ybudgamt, remark,insertdt, iempcode)
                                         VALUES (p_compcode, SUBSTR (p_yyyymm, 0, 4), p_deptcodeS,  p_acccodeS,
                                                 0,          '조회용삽입',                 SYSDATE,       NULL);
         END IF;
      END LOOP;

      
      --DELETE FROM TT_ACBUDG0106R_DUAL;
      --INSERT INTO TT_ACBUDG0106R_DUAL
      --SELECT * FROM VGT.TT_ACBUDG0106R_DUAL;
      
      -- 상위계정, 계정과목, 실행예산, 당월예산실적분석 and  당월말(계획, 실적, 차이, 실적율), 당월말 전년실적분석
        
      EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0106R_ACbudg0106R1 ';

      INSERT INTO VGT.TT_ACBUDG0106R_ACBUDG0106R1
         (  SELECT    '0' seq,
                      MAX(D.hacccode)  hacccode  ,
                      MAX(E.accname)  haccname  ,
                      A.acccode ,
                      MAX(D.accname)  accname  ,
                      MAX(NVL(A.ybudgamt, 0))  ybudgamt  ,
                      MAX(NVL(b.budgamt, 0))  budgamt  ,
                      MAX(NVL(b.restotamt, 0))  restotamt  ,
                      MAX(NVL(b.budgamt, 0))  - MAX(b.restotamt)  diffamt  ,
                      CASE  MAX(NVL(b.budgamt, 0)) WHEN 0 THEN 0 ELSE FLOOR(MAX(NVL(b.restotamt, 0))  / MAX(NVL(b.budgamt, 0))  * 100) / 10 END pert ,--당월 예산대비 실적
                      SUM(NVL(c.budgamt, 0))  cumbudgamt  ,
                      SUM(NVL(c.restotamt, 0))  cumrestotamt  ,
                      SUM(NVL(c.budgamt, 0))  - SUM(NVL(c.restotamt, 0))  diffamt1  ,
                      CASE SUM(NVL(c.budgamt, 0)) WHEN 0 THEN 0 ELSE FLOOR(SUM(NVL(c.restotamt, 0))  / SUM(NVL(c.budgamt, 0))  * 100) / 10 END pert1 ,--누계 예산대비 실적
                      MAX(NVL(f.restotamt, 0))  pastrestotamt ,--전년 월실적
                      MAX(NVL(b.restotamt, 0))  - MAX(NVL(f.restotamt, 0))  diffrestotamt ,-- 당기 당월 실적 - 전년 월 실적
                      CASE SUM(NVL(f.restotamt, 0)) WHEN 0 THEN 0 ELSE FLOOR(SUM(NVL(b.restotamt, 0))  / SUM(NVL(f.restotamt, 0))  * 100) / 10 END pert2 ,-- 전년비 대비 실적율
                      SUM(NVL(G.restotamt, 0))  pastcumrestotamt ,-- 작년 월까지 누계실적 합
                      SUM(NVL(c.restotamt, 0))  - SUM(NVL(G.restotamt, 0))  diffcumrestotamt ,--증감액 :  당기월누계  - 전년월 누계
                      CASE SUM(NVL(G.restotamt, 0)) WHEN 0 THEN 0 ELSE FLOOR(SUM(NVL(c.restotamt, 0))  / SUM(NVL(G.restotamt, 0))  * 100) / 10 END pert3 -- 전년 월예산누계 대비 당기월예산누계
              FROM VGT.TT_ACbudg0106R_DUAL A                         -- 해당년도 a
                   LEFT JOIN
                   (  SELECT compcode,
                             SUBSTR (p_yyyymm, 0, 4) cyear,
                             deptcode,
                             acccode,
                             SUM (budgamt) budgamt,
                             SUM (restotamt) restotamt
                        FROM ACBUDGMM
                       WHERE compcode = p_compcode AND budgym = p_yyyymm
                    GROUP BY compcode,
                             deptcode,
                             acccode,
                             budgym) b
                      ON     A.compcode = b.compcode
                         AND A.acccode = b.acccode
                         AND A.deptcode = b.deptcode
                         AND A.cyear = b.cyear                       -- 해당년월 b
                   LEFT JOIN
                   (  SELECT compcode,
                             SUBSTR (p_yyyymm, 0, 4) cyear,
                             deptcode,
                             acccode,
                             SUM (budgamt) budgamt,
                             SUM (restotamt) restotamt
                        FROM ACBUDGMM
                       WHERE     compcode = p_compcode
                             AND budgym >= SUBSTR (p_yyyymm, 0, 4) || '-01'
                             AND budgym <= p_yyyymm
                    GROUP BY compcode,
                             deptcode,
                             acccode,
                             budgym) c
                      ON     A.compcode = c.compcode
                         AND A.acccode = c.acccode
                         AND A.deptcode = c.deptcode
                         AND A.cyear = c.cyear                -- 해당년도~해당월 누적 c
                   LEFT JOIN ACACCM D ON A.acccode = D.acccode
                   LEFT JOIN ACACCM E ON D.hacccode = E.acccode
                   LEFT JOIN
                   (  SELECT compcode,
                             SUBSTR (p_yyyymm, 0, 4) cyear,
                             deptcode,
                             acccode,
                             SUM (budgamt) budgamt,
                             SUM (restotamt) restotamt
                        FROM ACBUDGMM
                       WHERE     compcode = p_compcode
                             AND budgym =TO_CHAR (ADD_MONTHS (TO_DATE (p_yyyymm || '-01','YYYY-MM-DD'),-12),'YYYY-MM')
                    GROUP BY compcode,
                             deptcode,
                             acccode,
                             budgym) f
                      ON     A.compcode = f.compcode
                         AND A.acccode = f.acccode
                         AND A.deptcode = f.deptcode
                         AND A.cyear = f.cyear                    -- 작년 해당 월 f
                   LEFT JOIN
                   (  SELECT compcode,
                             SUBSTR (p_yyyymm, 0, 4) cyear,
                             deptcode,
                             acccode,
                             SUM (budgamt) budgamt,
                             SUM (restotamt) restotamt
                        FROM ACBUDGMM
                       WHERE     compcode = p_compcode
                             AND budgym BETWEEN TO_CHAR (ADD_MONTHS (TO_DATE (p_yyyymm || '-01','YYYY-MM-DD'),-12),'YYYY')|| '-01' AND TO_CHAR (ADD_MONTHS (TO_DATE (p_yyyymm || '-01','YYYY-MM-DD'),-12),'YYYY-MM')
                    GROUP BY compcode,
                             deptcode,
                             acccode,
                             budgym) G
                      ON     A.compcode = G.compcode
                         AND A.acccode = G.acccode
                         AND A.deptcode = G.deptcode
                         AND A.cyear = G.cyear                    -- 작년 월 누적 g
             WHERE     A.compcode = p_compcode
                   AND A.cyear = SUBSTR (p_yyyymm, 0, 4)
                   AND (nvl(p_deptcode1,' ') > ' ' AND A.deptcode >= nvl(p_deptcode1,' ') OR trim(p_deptcode1) IS NULL )
                   AND (nvl(p_deptcode2,' ') > ' ' AND A.deptcode <= nvl(p_deptcode2,' ') OR trim(p_deptcode2) IS NULL )
          GROUP BY A.acccode);
--          GROUP BY A.deptcode, A.acccode);
          

      DELETE VGT.TT_ACBUDG0106R_ACbudg0106R1
       WHERE     ybudgamt = 0
             AND budgamt = 0
             AND restotamt = 0
             AND diffamt = 0
             AND pert = 0
             AND cumbudgamt = 0
             AND cumrestotamt = 0
             AND diffamt1 = 0
             AND pert1 = 0
             AND pastrestotamt = 0
             AND diffrestotamt = 0
             AND pert2 = 0
             AND pastcumrestotamt = 0
             AND diffcumrestotamt = 0
             AND pert3 = 0;
        
        --DELETE FROM TT_ACBUDG0106R_ACbudg0106R1;
        --INSERT INTO TT_ACBUDG0106R_ACbudg0106R1
        --SELECT * FROM VGT.TT_ACBUDG0106R_ACbudg0106R1;

      OPEN IO_CURSOR FOR
           SELECT *
             FROM (SELECT '1' seq,
                          hacccode,
                          haccname,
                          '1' seq1,
                          acccode,
                          accname,
                          ybudgamt,
                          budgamt,
                          restotamt,
                          diffamt,
                          pert,
                          cumbudgamt,
                          cumrestotamt,
                          diffamt1,
                          pert1,
                          pastrestotamt,
                          diffrestotamt,
                          pert2,
                          pastcumrestotamt,
                          diffcumrestotamt,
                          pert3
                     FROM VGT.TT_ACBUDG0106R_ACbudg0106R1
                   UNION ALL
                     SELECT '1' seq,
                            hacccode,
                            '소계' haccname,
                            --,'' as deptcode
                            '2' seq1,
                            ' ' acccode,
                            ' ' accname,
                            SUM (ybudgamt) ybudgamt,
                            SUM (budgamt) budgamt,
                            SUM (restotamt) restotamt,
                            SUM (diffamt) diffamt,
                            CASE SUM (budgamt) WHEN 0 THEN 0 ELSE FLOOR (SUM (restotamt) / SUM (budgamt) * 100) / 10 END pert,
                            SUM (cumbudgamt) cumbudgamt,
                            SUM (cumrestotamt) cumrestotamt,
                            SUM (diffamt1) diffamt1,
                            CASE SUM (cumbudgamt) WHEN 0 THEN 0 ELSE FLOOR ( SUM (cumrestotamt) / SUM (cumbudgamt) * 100) / 10 END pert1,
                            SUM (pastrestotamt) pastrestotamt,
                            SUM (diffrestotamt) diffrestotamt,
                            CASE SUM (pastrestotamt) WHEN 0 THEN 0 ELSE FLOOR ( SUM (restotamt) / SUM (pastrestotamt) * 100) / 10 END pert2,
                            SUM (pastcumrestotamt) pastcumrestotamt,
                            SUM (diffcumrestotamt) diffcumrestotamt,
                            CASE SUM (pastcumrestotamt) WHEN 0 THEN 0 ELSE FLOOR ( SUM (cumrestotamt) / SUM (pastcumrestotamt) * 100) / 10 END pert3
                       FROM VGT.TT_ACBUDG0106R_ACbudg0106R1
                   GROUP BY hacccode
                   UNION ALL
                     SELECT '2' seq,
                            ' ' hacccode,
                            '합계' haccname,
                            --,'' as deptcode
                            '1' seq1,
                            ' ' acccode,
                            ' ' accname,
                            SUM (ybudgamt) ybudgamt,
                            SUM (budgamt) budgamt,
                            SUM (restotamt) restotamt,
                            SUM (diffamt) diffamt,
                            CASE SUM (budgamt)  WHEN 0 THEN 0 ELSE FLOOR (SUM (restotamt) / SUM (budgamt) * 100) / 10 END pert,
                            SUM (cumbudgamt) cumbudgamt,
                            SUM (cumrestotamt) cumrestotamt,
                            SUM (diffamt1) diffamt1,
                            CASE SUM (cumbudgamt) WHEN 0 THEN 0 ELSE FLOOR ( SUM (cumrestotamt) / SUM (cumbudgamt) * 100) / 10 END pert1,
                            SUM (pastrestotamt) pastrestotamt,
                            SUM (diffrestotamt) diffrestotamt,
                            CASE SUM (pastrestotamt) WHEN 0 THEN 0 ELSE FLOOR ( SUM (restotamt) / SUM (pastrestotamt) * 100) / 10 END pert2,
                            SUM (pastcumrestotamt) pastcumrestotamt,
                            SUM (diffcumrestotamt) diffcumrestotamt,
                            CASE SUM (pastcumrestotamt) WHEN 0 THEN 0 ELSE FLOOR ( SUM (cumrestotamt) / SUM (pastcumrestotamt) * 100) / 10 END pert3
                       FROM VGT.TT_ACBUDG0106R_ACbudg0106R1 A
                   GROUP BY A.seq) A
         ORDER BY seq, hacccode, seq1, acccode;
   END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
