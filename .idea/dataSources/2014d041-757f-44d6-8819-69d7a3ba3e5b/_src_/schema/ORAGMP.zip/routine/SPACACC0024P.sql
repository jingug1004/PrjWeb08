CREATE PROCEDURE spACacc0024P
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0024P
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-10-05
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 현금시재를 등록,수정,삭제,조회하는 프로시저이다.
	-- ---------------------------------------------------------------
(
	p_div			IN	   VARCHAR2 DEFAULT '',

	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_cashym		IN	   VARCHAR2 DEFAULT '',

	p_cashdate		IN	   VARCHAR2 DEFAULT '',
	p_amt10 		IN	   FLOAT    DEFAULT 0,
	p_amt50 		IN	   FLOAT    DEFAULT 0,
	p_amt100		IN	   FLOAT    DEFAULT 0,
	p_amt500		IN	   FLOAT    DEFAULT 0,
	p_amt1000		IN	   FLOAT    DEFAULT 0,
	p_amt5000		IN	   FLOAT    DEFAULT 0,
	p_amt10000		IN	   FLOAT    DEFAULT 0,
	p_amt50000		IN	   FLOAT    DEFAULT 0,
	p_amt100000 	IN	   FLOAT    DEFAULT 0,
	p_amtfree		IN	   FLOAT    DEFAULT 0,
	p_inamt 		IN	   FLOAT    DEFAULT 0,
	p_outamt		IN	   FLOAT    DEFAULT 0,
	p_iempcode		IN	   VARCHAR2 DEFAULT '',

	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		OUT    VARCHAR2,
	IO_CURSOR		OUT    TYPES.DataSet
)
AS

    v_temp     NUMBER := 0;

BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	IF (p_div = 'S') THEN

        OPEN IO_CURSOR FOR
            SELECT	 p_compcode compcode,
                     p_plantcode plantcode,
                     TO_CHAR(A.solar_date, 'YYYY-MM-DD') cashdate,
                     NVL(b.amt10, 0) amt10,
                     NVL(b.amt10 * 10, 0) wamt10,
                     NVL(b.amt50, 0) amt50,
                     NVL(b.amt50 * 50, 0) wamt50,
                     NVL(b.amt100, 0) amt100,
                     NVL(b.amt100 * 100, 0) wamt100,
                     NVL(b.amt500, 0) amt500,
                     NVL(b.amt500 * 500, 0) wamt500,
                     NVL(b.amt1000, 0) amt1000,
                     NVL(b.amt1000 * 1000, 0) wamt1000,
                     NVL(b.amt5000, 0) amt5000,
                     NVL(b.amt5000 * 5000, 0) wamt5000,
                     NVL(b.amt10000, 0) amt10000,
                     NVL(b.amt10000 * 10000, 0) wamt10000,
                     NVL(b.amt50000, 0) amt50000,
                     NVL(b.amt50000 * 50000, 0) wamt50000,
                     NVL(b.amt100000, 0) amt100000,
                     NVL(b.amt100000 * 100000, 0) wamt100000,
                     NVL(b.amtfree, 0) amtfree,
                     NVL(b.amt100000 * 100000 + b.amtfree, 0) amtfreesum,
                     NVL(b.amt10 * 10 + b.amt50 * 50 + b.amt100 * 100 + b.amt500 * 500 + b.amt1000 * 1000 + b.amt5000 * 5000 + b.amt10000 * 10000 + b.amt50000 * 50000 + b.amt100000 * 100000 + b.amtfree, 0) amtsum,
                     NVL(b.amt10 * 10 + b.amt50 * 50 + b.amt100 * 100 + b.amt500 * 500, 0) amtcoin,
                     NVL(b.inamt, 0) inamt,
                     NVL(b.outamt, 0) outamt
            FROM	 PSLUNSOLDAY A
                     LEFT JOIN ACCASHM b ON b.compcode = p_compcode
                                            AND b.plantcode = p_plantcode
                                            AND A.solar_date = b.cashdate
            WHERE	 TO_CHAR(A.solar_date, 'YYYY-MM-DD') BETWEEN (p_cashym || '-01') AND TO_CHAR( ADD_MONTHS(TO_DATE(p_cashym || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD')



            ORDER BY A.solar_date;

	ELSIF (p_div = 'U') THEN

        FOR rec IN (    SELECT 1 AS alias1
                        FROM   DUAL
                        WHERE  EXISTS
                                   (SELECT *
                                    FROM   ACCASHM
                                    WHERE  compcode = p_compcode
                                           AND plantcode = p_plantcode
                                           AND cashdate = p_cashdate)
        )
        LOOP
            v_temp := rec.alias1 ;
        END LOOP;

        IF v_temp = 1 THEN

            UPDATE ACCASHM A
            SET    A.amt10 = p_amt10,
                   A.amt50 = p_amt50,
                   A.amt100 = p_amt100,
                   A.amt500 = p_amt500,
                   A.amt1000 = p_amt1000,
                   A.amt5000 = p_amt5000,
                   A.amt10000 = p_amt10000,
                   A.amt50000 = p_amt50000,
                   A.amt100000 = p_amt100000,
                   A.amtfree = p_amtfree,
                   A.inamt = p_inamt,
                   A.outamt = p_outamt,
                   A.updatedt = SYSDATE,
                   A.uempcode = p_iempcode
            WHERE  compcode = p_compcode
                   AND plantcode = p_plantcode
                   AND cashdate = p_cashdate;

        ELSE

            INSERT INTO ACCASHM(compcode,
                                plantcode,
                                cashdate,
                                amt10,
                                amt50,
                                amt100,
                                amt500,
                                amt1000,
                                amt5000,
                                amt10000,
                                amt50000,
                                amt100000,
                                amtfree,
                                inamt,
                                outamt,
                                insertdt,
                                iempcode)
                (SELECT p_compcode,
                        p_plantcode,
                        p_cashdate,
                        p_amt10,
                        p_amt50,
                        p_amt100,
                        p_amt500,
                        p_amt1000,
                        p_amt5000,
                        p_amt10000,
                        p_amt50000,
                        p_amt100000,
                        p_amtfree,
                        p_inamt,
                        p_outamt,
                        SYSDATE,
                        p_iempcode
                 FROM  DUAL);

        END IF;

    ELSIF (p_div = 'CP') THEN

        OPEN IO_CURSOR FOR

            SELECT NVL(A.amt10, 0) amt10,
                   NVL(A.amt10 * 10, 0) wamt10,
                   NVL(A.amt50, 0) amt50,
                   NVL(A.amt50 * 50, 0) wamt50,
                   NVL(A.amt100, 0) amt100,
                   NVL(A.amt100 * 100, 0) wamt100,
                   NVL(A.amt500, 0) amt500,
                   NVL(A.amt500 * 500, 0) wamt500,
                   NVL(A.amt1000, 0) amt1000,
                   NVL(A.amt1000 * 1000, 0) wamt1000,
                   NVL(A.amt5000, 0) amt5000,
                   NVL(A.amt5000 * 5000, 0) wamt5000,
                   NVL(A.amt10000, 0) amt10000,
                   NVL(A.amt10000 * 10000, 0) wamt10000,
                   NVL(A.amt50000, 0) amt50000,
                   NVL(A.amt50000 * 50000, 0) wamt50000,
                   NVL(A.amt100000, 0) amt100000,
                   NVL(A.amt100000 * 100000, 0) wamt100000,
                   NVL(A.amtfree, 0) amtfree,
                   NVL(A.amt100000 * 100000 + A.amtfree, 0) amtfreesum,
                   NVL(A.amt10 * 10 + A.amt50 * 50 + A.amt100 * 100 + A.amt500 * 500 + A.amt1000 * 1000 + A.amt5000 * 5000 + A.amt10000 * 10000 + A.amt50000 * 50000 + A.amt100000 * 100000 + A.amtfree, 0) amtsum,
                   NVL(A.amt10 * 10 + A.amt50 * 50 + A.amt100 * 100 + A.amt500 * 500, 0) amtcoin,
                   NVL(A.inamt, 0) inamt,
                   NVL(A.outamt, 0) outamt

            FROM   ACCASHM A
                   JOIN (SELECT   compcode, plantcode, MAX(cashdate) cashdate
                         FROM    ACCASHM
                         WHERE    compcode = p_compcode
                                  AND plantcode = p_plantcode
                                  AND cashdate < p_cashdate
                         GROUP BY compcode, plantcode) b ON A.compcode = b.compcode
                                                            AND A.plantcode = b.plantcode
                                                            AND A.cashdate = b.cashdate;

    ELSIF (p_div = 'CR') THEN

        OPEN IO_CURSOR FOR

            WITH TT_ACCASHM AS
            (
                SELECT 0 ord,
                       '' cashdate,
                       amt10 * 10 amt10,
                       amt50 * 50 amt50,
                       amt100 * 100 amt100,
                       amt500 * 500 amt500,
                       amt1000 * 1000 amt1000,
                       amt5000 * 5000 amt5000,
                       amt10000 * 10000 amt10000,
                       amt50000 * 50000 amt50000,
                       amt100000 * 100000 + amtfree amtfree,
                       amt10 * 10 + amt50 * 50 + amt100 * 100 + amt500 * 500 + amt1000 * 1000 + amt5000 * 5000 + amt10000 * 10000 + amt50000 * 50000 + amt100000 * 100000 + amtfree amtsum,
                       amt10 * 10 + amt50 * 50 + amt100 * 100 + amt500 * 500 amtcoin,
                       inamt,
                       outamt

                FROM   ACCASHM A
                       JOIN (SELECT   compcode, plantcode, MAX(cashdate) cashdate
                             FROM    ACCASHM
                             WHERE    compcode = p_compcode
                                      AND plantcode = p_plantcode
                                      AND cashdate < p_cashym || '-01'
                                      AND amt10 + amt50 + amt100 + amt500 + amt1000 + amt5000 + amt10000 + amt50000 + amt100000 + amtfree > 0
                             GROUP BY compcode, plantcode) b ON A.compcode = b.compcode
                                                                AND A.plantcode = b.plantcode
                                                                AND A.cashdate = b.cashdate

                UNION ALL

                SELECT ROW_NUMBER() OVER (ORDER BY cashdate) ord, TO_CHAR(TO_DATE(cashdate, 'YYYY-MM-DD'), 'MM') || '/' || TO_CHAR(TO_DATE(cashdate, 'YYYY-MM-DD'), 'DD') cashdate,
                       amt10 * 10 amt10,
                       amt50 * 50 amt50,
                       amt100 * 100 amt100,
                       amt500 * 500 amt500,
                       amt1000 * 1000 amt1000,
                       amt5000 * 5000 amt5000,
                       amt10000 * 10000 amt10000,
                       amt50000 * 50000 amt50000,
                       amt100000 * 100000 + amtfree amtfree,
                       amt10 * 10 + amt50 * 50 + amt100 * 100 + amt500 * 500 + amt1000 * 1000 + amt5000 * 5000 + amt10000 * 10000 + amt50000 * 50000 + amt100000 * 100000 + amtfree amtsum,
                       amt10 * 10 + amt50 * 50 + amt100 * 100 + amt500 * 500 amtcoin,
                       inamt,
                       outamt
                FROM   ACCASHM
                WHERE  cashdate BETWEEN p_cashym || '-01' AND p_cashym || '-31'
                       AND amt10 + amt50 + amt100 + amt500 + amt1000 + amt5000 + amt10000 + amt50000 + amt100000 + amtfree > 0
            ) -- WITH END


            SELECT SUBSTR(p_cashym, 0, 4) || '년' YEAR,

                   MAX(CASE WHEN ord = 1 THEN SUBSTR(cashdate, -5, 5) END) cashdate_01,
                   MAX(CASE WHEN ord = 1 THEN amtsum END) amtpre_01,
                   MAX(CASE WHEN ord = 1 THEN inamt END) inamt_01,
                   MAX(CASE WHEN ord = 1 THEN outamt END) outamt_01,
                   MAX(CASE WHEN ord = 1 THEN amtsum END) amtsum_01,
                   MAX(CASE WHEN ord = 1 THEN amtfree END) amtfree_01,
                   MAX(CASE WHEN ord = 1 THEN amt50000 END) amt50000_01,
                   MAX(CASE WHEN ord = 1 THEN amt10000 END) amt10000_01,
                   MAX(CASE WHEN ord = 1 THEN amt5000 END) amt5000_01,
                   MAX(CASE WHEN ord = 1 THEN amt1000 END) amt1000_01,
                   MAX(CASE WHEN ord = 1 THEN amt500 END) amt500_01,
                   MAX(CASE WHEN ord = 1 THEN amt100 END) amt100_01,
                   MAX(CASE WHEN ord = 1 THEN amt50 END) amt50_01,
                   MAX(CASE WHEN ord = 1 THEN amt10 END) amt10_01,
                   MAX(CASE WHEN ord = 1 THEN amtcoin END) amtcoin_01,


                   MAX(CASE WHEN ord = 2 THEN SUBSTR(cashdate, -5, 5) END) cashdate_02,
                   MAX(CASE WHEN ord = 2 THEN amtsum END) amtpre_02,
                   MAX(CASE WHEN ord = 2 THEN inamt END) inamt_02,
                   MAX(CASE WHEN ord = 2 THEN outamt END) outamt_02,
                   MAX(CASE WHEN ord = 2 THEN amtsum END) amtsum_02,
                   MAX(CASE WHEN ord = 2 THEN amtfree END) amtfree_02,
                   MAX(CASE WHEN ord = 2 THEN amt50000 END) amt50000_02,
                   MAX(CASE WHEN ord = 2 THEN amt10000 END) amt10000_02,
                   MAX(CASE WHEN ord = 2 THEN amt5000 END) amt5000_02,
                   MAX(CASE WHEN ord = 2 THEN amt1000 END) amt1000_02,
                   MAX(CASE WHEN ord = 2 THEN amt500 END) amt500_02,
                   MAX(CASE WHEN ord = 2 THEN amt100 END) amt100_02,
                   MAX(CASE WHEN ord = 2 THEN amt50 END) amt50_02,
                   MAX(CASE WHEN ord = 2 THEN amt10 END) amt10_02,
                   MAX(CASE WHEN ord = 2 THEN amtcoin END) amtcoin_02,


                   MAX(CASE WHEN ord = 3 THEN SUBSTR(cashdate, -5, 5) END) cashdate_03,
                   MAX(CASE WHEN ord = 3 THEN amtsum END) amtpre_03,
                   MAX(CASE WHEN ord = 3 THEN inamt END) inamt_03,
                   MAX(CASE WHEN ord = 3 THEN outamt END) outamt_03,
                   MAX(CASE WHEN ord = 3 THEN amtsum END) amtsum_03,
                   MAX(CASE WHEN ord = 3 THEN amtfree END) amtfree_03,
                   MAX(CASE WHEN ord = 3 THEN amt50000 END) amt50000_03,
                   MAX(CASE WHEN ord = 3 THEN amt10000 END) amt10000_03,
                   MAX(CASE WHEN ord = 3 THEN amt5000 END) amt5000_03,
                   MAX(CASE WHEN ord = 3 THEN amt1000 END) amt1000_03,
                   MAX(CASE WHEN ord = 3 THEN amt500 END) amt500_03,
                   MAX(CASE WHEN ord = 3 THEN amt100 END) amt100_03,
                   MAX(CASE WHEN ord = 3 THEN amt50 END) amt50_03,
                   MAX(CASE WHEN ord = 3 THEN amt10 END) amt10_03,
                   MAX(CASE WHEN ord = 3 THEN amtcoin END) amtcoin_03,


                   MAX(CASE WHEN ord = 4 THEN SUBSTR(cashdate, -5, 5) END) cashdate_04,
                   MAX(CASE WHEN ord = 4 THEN amtsum END) amtpre_04,
                   MAX(CASE WHEN ord = 4 THEN inamt END) inamt_04,
                   MAX(CASE WHEN ord = 4 THEN outamt END) outamt_04,
                   MAX(CASE WHEN ord = 4 THEN amtsum END) amtsum_04,
                   MAX(CASE WHEN ord = 4 THEN amtfree END) amtfree_04,
                   MAX(CASE WHEN ord = 4 THEN amt50000 END) amt50000_04,
                   MAX(CASE WHEN ord = 4 THEN amt10000 END) amt10000_04,
                   MAX(CASE WHEN ord = 4 THEN amt5000 END) amt5000_04,
                   MAX(CASE WHEN ord = 4 THEN amt1000 END) amt1000_04,
                   MAX(CASE WHEN ord = 4 THEN amt500 END) amt500_04,
                   MAX(CASE WHEN ord = 4 THEN amt100 END) amt100_04,
                   MAX(CASE WHEN ord = 4 THEN amt50 END) amt50_04,
                   MAX(CASE WHEN ord = 4 THEN amt10 END) amt10_04,
                   MAX(CASE WHEN ord = 4 THEN amtcoin END) amtcoin_04,


                   MAX(CASE WHEN ord = 5 THEN SUBSTR(cashdate, -5, 5) END) cashdate_05,
                   MAX(CASE WHEN ord = 5 THEN amtsum END) amtpre_05,
                   MAX(CASE WHEN ord = 5 THEN inamt END) inamt_05,
                   MAX(CASE WHEN ord = 5 THEN outamt END) outamt_05,
                   MAX(CASE WHEN ord = 5 THEN amtsum END) amtsum_05,
                   MAX(CASE WHEN ord = 5 THEN amtfree END) amtfree_05,
                   MAX(CASE WHEN ord = 5 THEN amt50000 END) amt50000_05,
                   MAX(CASE WHEN ord = 5 THEN amt10000 END) amt10000_05,
                   MAX(CASE WHEN ord = 5 THEN amt5000 END) amt5000_05,
                   MAX(CASE WHEN ord = 5 THEN amt1000 END) amt1000_05,
                   MAX(CASE WHEN ord = 5 THEN amt500 END) amt500_05,
                   MAX(CASE WHEN ord = 5 THEN amt100 END) amt100_05,
                   MAX(CASE WHEN ord = 5 THEN amt50 END) amt50_05,
                   MAX(CASE WHEN ord = 5 THEN amt10 END) amt10_05,
                   MAX(CASE WHEN ord = 5 THEN amtcoin END) amtcoin_05,


                   MAX(CASE WHEN ord = 6 THEN SUBSTR(cashdate, -5, 5) END) cashdate_06,
                   MAX(CASE WHEN ord = 6 THEN amtsum END) amtpre_06,
                   MAX(CASE WHEN ord = 6 THEN inamt END) inamt_06,
                   MAX(CASE WHEN ord = 6 THEN outamt END) outamt_06,
                   MAX(CASE WHEN ord = 6 THEN amtsum END) amtsum_06,
                   MAX(CASE WHEN ord = 6 THEN amtfree END) amtfree_06,
                   MAX(CASE WHEN ord = 6 THEN amt50000 END) amt50000_06,
                   MAX(CASE WHEN ord = 6 THEN amt10000 END) amt10000_06,
                   MAX(CASE WHEN ord = 6 THEN amt5000 END) amt5000_06,
                   MAX(CASE WHEN ord = 6 THEN amt1000 END) amt1000_06,
                   MAX(CASE WHEN ord = 6 THEN amt500 END) amt500_06,
                   MAX(CASE WHEN ord = 6 THEN amt100 END) amt100_06,
                   MAX(CASE WHEN ord = 6 THEN amt50 END) amt50_06,
                   MAX(CASE WHEN ord = 6 THEN amt10 END) amt10_06,
                   MAX(CASE WHEN ord = 6 THEN amtcoin END) amtcoin_06,


                   MAX(CASE WHEN ord = 7 THEN SUBSTR(cashdate, -5, 5) END) cashdate_07,
                   MAX(CASE WHEN ord = 7 THEN amtsum END) amtpre_07,
                   MAX(CASE WHEN ord = 7 THEN inamt END) inamt_07,
                   MAX(CASE WHEN ord = 7 THEN outamt END) outamt_07,
                   MAX(CASE WHEN ord = 7 THEN amtsum END) amtsum_07,
                   MAX(CASE WHEN ord = 7 THEN amtfree END) amtfree_07,
                   MAX(CASE WHEN ord = 7 THEN amt50000 END) amt50000_07,
                   MAX(CASE WHEN ord = 7 THEN amt10000 END) amt10000_07,
                   MAX(CASE WHEN ord = 7 THEN amt5000 END) amt5000_07,
                   MAX(CASE WHEN ord = 7 THEN amt1000 END) amt1000_07,
                   MAX(CASE WHEN ord = 7 THEN amt500 END) amt500_07,
                   MAX(CASE WHEN ord = 7 THEN amt100 END) amt100_07,
                   MAX(CASE WHEN ord = 7 THEN amt50 END) amt50_07,
                   MAX(CASE WHEN ord = 7 THEN amt10 END) amt10_07,
                   MAX(CASE WHEN ord = 7 THEN amtcoin END) amtcoin_07,


                   MAX(CASE WHEN ord = 8 THEN SUBSTR(cashdate, -5, 5) END) cashdate_08,
                   MAX(CASE WHEN ord = 8 THEN amtsum END) amtpre_08,
                   MAX(CASE WHEN ord = 8 THEN inamt END) inamt_08,
                   MAX(CASE WHEN ord = 8 THEN outamt END) outamt_08,
                   MAX(CASE WHEN ord = 8 THEN amtsum END) amtsum_08,
                   MAX(CASE WHEN ord = 8 THEN amtfree END) amtfree_08,
                   MAX(CASE WHEN ord = 8 THEN amt50000 END) amt50000_08,
                   MAX(CASE WHEN ord = 8 THEN amt10000 END) amt10000_08,
                   MAX(CASE WHEN ord = 8 THEN amt5000 END) amt5000_08,
                   MAX(CASE WHEN ord = 8 THEN amt1000 END) amt1000_08,
                   MAX(CASE WHEN ord = 8 THEN amt500 END) amt500_08,
                   MAX(CASE WHEN ord = 8 THEN amt100 END) amt100_08,
                   MAX(CASE WHEN ord = 8 THEN amt50 END) amt50_08,
                   MAX(CASE WHEN ord = 8 THEN amt10 END) amt10_08,
                   MAX(CASE WHEN ord = 8 THEN amtcoin END) amtcoin_08,


                   MAX(CASE WHEN ord = 9 THEN SUBSTR(cashdate, -5, 5) END) cashdate_09,
                   MAX(CASE WHEN ord = 9 THEN amtsum END) amtpre_09,
                   MAX(CASE WHEN ord = 9 THEN inamt END) inamt_09,
                   MAX(CASE WHEN ord = 9 THEN outamt END) outamt_09,
                   MAX(CASE WHEN ord = 9 THEN amtsum END) amtsum_09,
                   MAX(CASE WHEN ord = 9 THEN amtfree END) amtfree_09,
                   MAX(CASE WHEN ord = 9 THEN amt50000 END) amt50000_09,
                   MAX(CASE WHEN ord = 9 THEN amt10000 END) amt10000_09,
                   MAX(CASE WHEN ord = 9 THEN amt5000 END) amt5000_09,
                   MAX(CASE WHEN ord = 9 THEN amt1000 END) amt1000_09,
                   MAX(CASE WHEN ord = 9 THEN amt500 END) amt500_09,
                   MAX(CASE WHEN ord = 9 THEN amt100 END) amt100_09,
                   MAX(CASE WHEN ord = 9 THEN amt50 END) amt50_09,
                   MAX(CASE WHEN ord = 9 THEN amt10 END) amt10_09,
                   MAX(CASE WHEN ord = 9 THEN amtcoin END) amtcoin_09,


                   MAX(CASE WHEN ord = 10 THEN SUBSTR(cashdate, -5, 5) END) cashdate_10,
                   MAX(CASE WHEN ord = 10 THEN amtsum END) amtpre_10,
                   MAX(CASE WHEN ord = 10 THEN inamt END) inamt_10,
                   MAX(CASE WHEN ord = 10 THEN outamt END) outamt_10,
                   MAX(CASE WHEN ord = 10 THEN amtsum END) amtsum_10,
                   MAX(CASE WHEN ord = 10 THEN amtfree END) amtfree_10,
                   MAX(CASE WHEN ord = 10 THEN amt50000 END) amt50000_10,
                   MAX(CASE WHEN ord = 10 THEN amt10000 END) amt10000_10,
                   MAX(CASE WHEN ord = 10 THEN amt5000 END) amt5000_10,
                   MAX(CASE WHEN ord = 10 THEN amt1000 END) amt1000_10,
                   MAX(CASE WHEN ord = 10 THEN amt500 END) amt500_10,
                   MAX(CASE WHEN ord = 10 THEN amt100 END) amt100_10,
                   MAX(CASE WHEN ord = 10 THEN amt50 END) amt50_10,
                   MAX(CASE WHEN ord = 10 THEN amt10 END) amt10_10,
                   MAX(CASE WHEN ord = 10 THEN amtcoin END) amtcoin_10,


                   MAX(CASE WHEN ord = 11 THEN SUBSTR(cashdate, -5, 5) END) cashdate_11,
                   MAX(CASE WHEN ord = 11 THEN amtsum END) amtpre_11,
                   MAX(CASE WHEN ord = 11 THEN inamt END) inamt_11,
                   MAX(CASE WHEN ord = 11 THEN outamt END) outamt_11,
                   MAX(CASE WHEN ord = 11 THEN amtsum END) amtsum_11,
                   MAX(CASE WHEN ord = 11 THEN amtfree END) amtfree_11,
                   MAX(CASE WHEN ord = 11 THEN amt50000 END) amt50000_11,
                   MAX(CASE WHEN ord = 11 THEN amt10000 END) amt10000_11,
                   MAX(CASE WHEN ord = 11 THEN amt5000 END) amt5000_11,
                   MAX(CASE WHEN ord = 11 THEN amt1000 END) amt1000_11,
                   MAX(CASE WHEN ord = 11 THEN amt500 END) amt500_11,
                   MAX(CASE WHEN ord = 11 THEN amt100 END) amt100_11,
                   MAX(CASE WHEN ord = 11 THEN amt50 END) amt50_11,
                   MAX(CASE WHEN ord = 11 THEN amt10 END) amt10_11,
                   MAX(CASE WHEN ord = 11 THEN amtcoin END) amtcoin_11,


                   MAX(CASE WHEN ord = 12 THEN SUBSTR(cashdate, -5, 5) END) cashdate_12,
                   MAX(CASE WHEN ord = 12 THEN amtsum END) amtpre_12,
                   MAX(CASE WHEN ord = 12 THEN inamt END) inamt_12,
                   MAX(CASE WHEN ord = 12 THEN outamt END) outamt_12,
                   MAX(CASE WHEN ord = 12 THEN amtsum END) amtsum_12,
                   MAX(CASE WHEN ord = 12 THEN amtfree END) amtfree_12,
                   MAX(CASE WHEN ord = 12 THEN amt50000 END) amt50000_12,
                   MAX(CASE WHEN ord = 12 THEN amt10000 END) amt10000_12,
                   MAX(CASE WHEN ord = 12 THEN amt5000 END) amt5000_12,
                   MAX(CASE WHEN ord = 12 THEN amt1000 END) amt1000_12,
                   MAX(CASE WHEN ord = 12 THEN amt500 END) amt500_12,
                   MAX(CASE WHEN ord = 12 THEN amt100 END) amt100_12,
                   MAX(CASE WHEN ord = 12 THEN amt50 END) amt50_12,
                   MAX(CASE WHEN ord = 12 THEN amt10 END) amt10_12,
                   MAX(CASE WHEN ord = 12 THEN amtcoin END) amtcoin_12,


                   MAX(CASE WHEN ord = 13 THEN SUBSTR(cashdate, -5, 5) END) cashdate_13,
                   MAX(CASE WHEN ord = 13 THEN amtsum END) amtpre_13,
                   MAX(CASE WHEN ord = 13 THEN inamt END) inamt_13,
                   MAX(CASE WHEN ord = 13 THEN outamt END) outamt_13,
                   MAX(CASE WHEN ord = 13 THEN amtsum END) amtsum_13,
                   MAX(CASE WHEN ord = 13 THEN amtfree END) amtfree_13,
                   MAX(CASE WHEN ord = 13 THEN amt50000 END) amt50000_13,
                   MAX(CASE WHEN ord = 13 THEN amt10000 END) amt10000_13,
                   MAX(CASE WHEN ord = 13 THEN amt5000 END) amt5000_13,
                   MAX(CASE WHEN ord = 13 THEN amt1000 END) amt1000_13,
                   MAX(CASE WHEN ord = 13 THEN amt500 END) amt500_13,
                   MAX(CASE WHEN ord = 13 THEN amt100 END) amt100_13,
                   MAX(CASE WHEN ord = 13 THEN amt50 END) amt50_13,
                   MAX(CASE WHEN ord = 13 THEN amt10 END) amt10_13,
                   MAX(CASE WHEN ord = 13 THEN amtcoin END) amtcoin_13,


                   MAX(CASE WHEN ord = 14 THEN SUBSTR(cashdate, -5, 5) END) cashdate_14,
                   MAX(CASE WHEN ord = 14 THEN amtsum END) amtpre_14,
                   MAX(CASE WHEN ord = 14 THEN inamt END) inamt_14,
                   MAX(CASE WHEN ord = 14 THEN outamt END) outamt_14,
                   MAX(CASE WHEN ord = 14 THEN amtsum END) amtsum_14,
                   MAX(CASE WHEN ord = 14 THEN amtfree END) amtfree_14,
                   MAX(CASE WHEN ord = 14 THEN amt50000 END) amt50000_14,
                   MAX(CASE WHEN ord = 14 THEN amt10000 END) amt10000_14,
                   MAX(CASE WHEN ord = 14 THEN amt5000 END) amt5000_14,
                   MAX(CASE WHEN ord = 14 THEN amt1000 END) amt1000_14,
                   MAX(CASE WHEN ord = 14 THEN amt500 END) amt500_14,
                   MAX(CASE WHEN ord = 14 THEN amt100 END) amt100_14,
                   MAX(CASE WHEN ord = 14 THEN amt50 END) amt50_14,
                   MAX(CASE WHEN ord = 14 THEN amt10 END) amt10_14,
                   MAX(CASE WHEN ord = 14 THEN amtcoin END) amtcoin_14,


                   MAX(CASE WHEN ord = 15 THEN SUBSTR(cashdate, -5, 5) END) cashdate_15,
                   MAX(CASE WHEN ord = 15 THEN amtsum END) amtpre_15,
                   MAX(CASE WHEN ord = 15 THEN inamt END) inamt_15,
                   MAX(CASE WHEN ord = 15 THEN outamt END) outamt_15,
                   MAX(CASE WHEN ord = 15 THEN amtsum END) amtsum_15,
                   MAX(CASE WHEN ord = 15 THEN amtfree END) amtfree_15,
                   MAX(CASE WHEN ord = 15 THEN amt50000 END) amt50000_15,
                   MAX(CASE WHEN ord = 15 THEN amt10000 END) amt10000_15,
                   MAX(CASE WHEN ord = 15 THEN amt5000 END) amt5000_15,
                   MAX(CASE WHEN ord = 15 THEN amt1000 END) amt1000_15,
                   MAX(CASE WHEN ord = 15 THEN amt500 END) amt500_15,
                   MAX(CASE WHEN ord = 15 THEN amt100 END) amt100_15,
                   MAX(CASE WHEN ord = 15 THEN amt50 END) amt50_15,
                   MAX(CASE WHEN ord = 15 THEN amt10 END) amt10_15,
                   MAX(CASE WHEN ord = 15 THEN amtcoin END) amtcoin_15,


                   MAX(CASE WHEN ord = 16 THEN SUBSTR(cashdate, -5, 5) END) cashdate_16,
                   MAX(CASE WHEN ord = 16 THEN amtsum END) amtpre_16,
                   MAX(CASE WHEN ord = 16 THEN inamt END) inamt_16,
                   MAX(CASE WHEN ord = 16 THEN outamt END) outamt_16,
                   MAX(CASE WHEN ord = 16 THEN amtsum END) amtsum_16,
                   MAX(CASE WHEN ord = 16 THEN amtfree END) amtfree_16,
                   MAX(CASE WHEN ord = 16 THEN amt50000 END) amt50000_16,
                   MAX(CASE WHEN ord = 16 THEN amt10000 END) amt10000_16,
                   MAX(CASE WHEN ord = 16 THEN amt5000 END) amt5000_16,
                   MAX(CASE WHEN ord = 16 THEN amt1000 END) amt1000_16,
                   MAX(CASE WHEN ord = 16 THEN amt500 END) amt500_16,
                   MAX(CASE WHEN ord = 16 THEN amt100 END) amt100_16,
                   MAX(CASE WHEN ord = 16 THEN amt50 END) amt50_16,
                   MAX(CASE WHEN ord = 16 THEN amt10 END) amt10_16,
                   MAX(CASE WHEN ord = 16 THEN amtcoin END) amtcoin_16,


                   MAX(CASE WHEN ord = 17 THEN SUBSTR(cashdate, -5, 5) END) cashdate_17,
                   MAX(CASE WHEN ord = 17 THEN amtsum END) amtpre_17,
                   MAX(CASE WHEN ord = 17 THEN inamt END) inamt_17,
                   MAX(CASE WHEN ord = 17 THEN outamt END) outamt_17,
                   MAX(CASE WHEN ord = 17 THEN amtsum END) amtsum_17,
                   MAX(CASE WHEN ord = 17 THEN amtfree END) amtfree_17,
                   MAX(CASE WHEN ord = 17 THEN amt50000 END) amt50000_17,
                   MAX(CASE WHEN ord = 17 THEN amt10000 END) amt10000_17,
                   MAX(CASE WHEN ord = 17 THEN amt5000 END) amt5000_17,
                   MAX(CASE WHEN ord = 17 THEN amt1000 END) amt1000_17,
                   MAX(CASE WHEN ord = 17 THEN amt500 END) amt500_17,
                   MAX(CASE WHEN ord = 17 THEN amt100 END) amt100_17,
                   MAX(CASE WHEN ord = 17 THEN amt50 END) amt50_17,
                   MAX(CASE WHEN ord = 17 THEN amt10 END) amt10_17,
                   MAX(CASE WHEN ord = 17 THEN amtcoin END) amtcoin_17,


                   MAX(CASE WHEN ord = 18 THEN SUBSTR(cashdate, -5, 5) END) cashdate_18,
                   MAX(CASE WHEN ord = 18 THEN amtsum END) amtpre_18,
                   MAX(CASE WHEN ord = 18 THEN inamt END) inamt_18,
                   MAX(CASE WHEN ord = 18 THEN outamt END) outamt_18,
                   MAX(CASE WHEN ord = 18 THEN amtsum END) amtsum_18,
                   MAX(CASE WHEN ord = 18 THEN amtfree END) amtfree_18,
                   MAX(CASE WHEN ord = 18 THEN amt50000 END) amt50000_18,
                   MAX(CASE WHEN ord = 18 THEN amt10000 END) amt10000_18,
                   MAX(CASE WHEN ord = 18 THEN amt5000 END) amt5000_18,
                   MAX(CASE WHEN ord = 18 THEN amt1000 END) amt1000_18,
                   MAX(CASE WHEN ord = 18 THEN amt500 END) amt500_18,
                   MAX(CASE WHEN ord = 18 THEN amt100 END) amt100_18,
                   MAX(CASE WHEN ord = 18 THEN amt50 END) amt50_18,
                   MAX(CASE WHEN ord = 18 THEN amt10 END) amt10_18,
                   MAX(CASE WHEN ord = 18 THEN amtcoin END) amtcoin_18,


                   MAX(CASE WHEN ord = 19 THEN SUBSTR(cashdate, -5, 5) END) cashdate_19,
                   MAX(CASE WHEN ord = 19 THEN amtsum END) amtpre_19,
                   MAX(CASE WHEN ord = 19 THEN inamt END) inamt_19,
                   MAX(CASE WHEN ord = 19 THEN outamt END) outamt_19,
                   MAX(CASE WHEN ord = 19 THEN amtsum END) amtsum_19,
                   MAX(CASE WHEN ord = 19 THEN amtfree END) amtfree_19,
                   MAX(CASE WHEN ord = 19 THEN amt50000 END) amt50000_19,
                   MAX(CASE WHEN ord = 19 THEN amt10000 END) amt10000_19,
                   MAX(CASE WHEN ord = 19 THEN amt5000 END) amt5000_19,
                   MAX(CASE WHEN ord = 19 THEN amt1000 END) amt1000_19,
                   MAX(CASE WHEN ord = 19 THEN amt500 END) amt500_19,
                   MAX(CASE WHEN ord = 19 THEN amt100 END) amt100_19,
                   MAX(CASE WHEN ord = 19 THEN amt50 END) amt50_19,
                   MAX(CASE WHEN ord = 19 THEN amt10 END) amt10_19,
                   MAX(CASE WHEN ord = 19 THEN amtcoin END) amtcoin_19,


                   MAX(CASE WHEN ord = 20 THEN SUBSTR(cashdate, -5, 5) END) cashdate_20,
                   MAX(CASE WHEN ord = 20 THEN amtsum END) amtpre_20,
                   MAX(CASE WHEN ord = 20 THEN inamt END) inamt_20,
                   MAX(CASE WHEN ord = 20 THEN outamt END) outamt_20,
                   MAX(CASE WHEN ord = 20 THEN amtsum END) amtsum_20,
                   MAX(CASE WHEN ord = 20 THEN amtfree END) amtfree_20,
                   MAX(CASE WHEN ord = 20 THEN amt50000 END) amt50000_20,
                   MAX(CASE WHEN ord = 20 THEN amt10000 END) amt10000_20,
                   MAX(CASE WHEN ord = 20 THEN amt5000 END) amt5000_20,
                   MAX(CASE WHEN ord = 20 THEN amt1000 END) amt1000_20,
                   MAX(CASE WHEN ord = 20 THEN amt500 END) amt500_20,
                   MAX(CASE WHEN ord = 20 THEN amt100 END) amt100_20,
                   MAX(CASE WHEN ord = 20 THEN amt50 END) amt50_20,
                   MAX(CASE WHEN ord = 20 THEN amt10 END) amt10_20,
                   MAX(CASE WHEN ord = 20 THEN amtcoin END) amtcoin_20,


                   MAX(CASE WHEN ord = 21 THEN SUBSTR(cashdate, -5, 5) END) cashdate_21,
                   MAX(CASE WHEN ord = 21 THEN amtsum END) amtpre_21,
                   MAX(CASE WHEN ord = 21 THEN inamt END) inamt_21,
                   MAX(CASE WHEN ord = 21 THEN outamt END) outamt_21,
                   MAX(CASE WHEN ord = 21 THEN amtsum END) amtsum_21,
                   MAX(CASE WHEN ord = 21 THEN amtfree END) amtfree_21,
                   MAX(CASE WHEN ord = 21 THEN amt50000 END) amt50000_21,
                   MAX(CASE WHEN ord = 21 THEN amt10000 END) amt10000_21,
                   MAX(CASE WHEN ord = 21 THEN amt5000 END) amt5000_21,
                   MAX(CASE WHEN ord = 21 THEN amt1000 END) amt1000_21,
                   MAX(CASE WHEN ord = 21 THEN amt500 END) amt500_21,
                   MAX(CASE WHEN ord = 21 THEN amt100 END) amt100_21,
                   MAX(CASE WHEN ord = 21 THEN amt50 END) amt50_21,
                   MAX(CASE WHEN ord = 21 THEN amt10 END) amt10_21,
                   MAX(CASE WHEN ord = 21 THEN amtcoin END) amtcoin_21,


                   MAX(CASE WHEN ord = 22 THEN SUBSTR(cashdate, -5, 5) END) cashdate_22,
                   MAX(CASE WHEN ord = 22 THEN amtpre END) amtpre_22,
                   MAX(CASE WHEN ord = 22 THEN inamt END) inamt_22,
                   MAX(CASE WHEN ord = 22 THEN outamt END) outamt_22,
                   MAX(CASE WHEN ord = 22 THEN amtsum END) amtsum_22,
                   MAX(CASE WHEN ord = 22 THEN amtfree END) amtfree_22,
                   MAX(CASE WHEN ord = 22 THEN amt50000 END) amt50000_22,
                   MAX(CASE WHEN ord = 22 THEN amt10000 END) amt10000_22,
                   MAX(CASE WHEN ord = 22 THEN amt5000 END) amt5000_22,
                   MAX(CASE WHEN ord = 22 THEN amt1000 END) amt1000_22,
                   MAX(CASE WHEN ord = 22 THEN amt500 END) amt500_22,
                   MAX(CASE WHEN ord = 22 THEN amt100 END) amt100_22,
                   MAX(CASE WHEN ord = 22 THEN amt50 END) amt50_22,
                   MAX(CASE WHEN ord = 22 THEN amt10 END) amt10_22,
                   MAX(CASE WHEN ord = 22 THEN amtcoin END) amtcoin_22

            FROM   (SELECT  A.*
                            , NVL(b.amtsum, 0) amtpre
                    FROM    TT_ACCASHM A
                            LEFT JOIN TT_ACCASHM b ON A.ord = b.ord - 1
                    WHERE  A.ord > 0 ) A;


  END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
