CREATE PROCEDURE        SPACFAUTOSLIP (
   -- ---------------------------------------------------------------
   -- 프로시저명       : spacfAutoSlip
   -- 작 성 자         : 최용석
   -- 작성일자         : 2015-09-17
   -- 수정자          : 임정호
   -- 수정일자         : 2016-12-16
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 회계전표 테이블 내역을 조회하는 프로시저이다.
   -- ---------------------------------------------------------------


   p_div            IN     VARCHAR2 DEFAULT '',
   p_acautorcode    IN     VARCHAR2 DEFAULT '',
   p_custcode       IN     VARCHAR2 DEFAULT '',
   p_custname       IN     VARCHAR2 DEFAULT '',
   p_accountno      IN     VARCHAR2 DEFAULT '',
   p_slipinremark   IN     VARCHAR2 DEFAULT '',
   p_slipamt        IN     FLOAT DEFAULT 0,
   p_slipvat        IN     FLOAT DEFAULT 0,
   p_userid         IN     VARCHAR2 DEFAULT '',
   p_reasondiv      IN     VARCHAR2 DEFAULT '',
   p_reasontext     IN     VARCHAR2 DEFAULT '',
   IO_CURSOR           OUT TYPES.DataSet,
   IO_CURSOR2          OUT TYPES.DataSet,
   IO_CURSOR3          OUT TYPES.DataSet,
   MESSAGE             OUT VARCHAR2)
AS
BEGIN
   MESSAGE := '데이터 확인';

   EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

   INSERT INTO ATINFO (USERID, REASONDIV, REASONTEXT)
        VALUES (p_userid, p_reasondiv, p_reasontext);


   INSERT INTO ATINFO (USERID, REASONDIV, REASONTEXT)
        VALUES (p_userid, p_reasondiv, p_reasontext);

   IF (p_div = 'S')
   THEN
      -- 자동분개정보


      OPEN IO_CURSOR FOR
         SELECT NVL (
                   MAX (
                      CASE
                         WHEN b.accamtdiv = '02' AND E.filter2 NOT IN ('B')
                         THEN
                            b.accamtdiv
                         ELSE
                            ''
                      END),
                   '')
                   accamtdiv,
                NVL (
                   MAX (
                      CASE
                         WHEN c.mngclucode = 'S020' THEN c.mngclucode
                         ELSE ''
                      END),
                   '')
                   mngclucode
           FROM ACAUTORULE A
                JOIN ACAUTORULESM b ON A.acautorcode = b.acautorcode
                LEFT JOIN ACAUTORULEDS c ON b.acautorcode = c.acautorcode
                LEFT JOIN CMCOMMONM D
                   ON D.cmmcode = 'AC251' AND b.acacccode = D.filter1
                LEFT JOIN CMCOMMONM E
                   ON E.cmmcode = 'AC60' AND D.filter2 = E.divcode
          WHERE A.acautorcode = p_acautorcode;
   ELSIF (p_div = 'C')
   THEN
      -- 자동분개전표정보

      OPEN IO_CURSOR FOR
         SELECT condition2 eviddiv, p_slipinremark slipinremark
           FROM ACAUTORULE
          WHERE acautorcode = p_acautorcode;

      OPEN IO_CURSOR2 FOR
           SELECT A.acautoseq slipinseq,
                  A.dcdiv,
                  A.acacccode acccode,
                  b.accname,
                  CASE
                     WHEN A.dcdiv IN ('1', '4')
                     THEN
                          CASE A.accamtdiv
                             WHEN '01' THEN p_slipamt
                             WHEN '02' THEN p_slipvat
                             WHEN '03' THEN p_slipamt + p_slipvat
                             ELSE 0
                          END
                        * CASE WHEN amtdiv = '+' THEN 1 ELSE -1 END
                     ELSE
                        0
                  END
                     debamt,
                  CASE
                     WHEN A.dcdiv IN ('2', '3')
                     THEN
                          CASE A.accamtdiv
                             WHEN '01' THEN p_slipamt
                             WHEN '02' THEN p_slipvat
                             WHEN '03' THEN p_slipamt + p_slipvat
                             ELSE 0
                          END
                        * CASE WHEN amtdiv = '+' THEN 1 ELSE -1 END
                     ELSE
                        0
                  END
                     creamt,
                  p_slipinremark remark1
             FROM ACAUTORULESM A LEFT JOIN ACACCM b ON A.acacccode = b.acccode
            WHERE A.acautorcode = p_acautorcode
         ORDER BY A.acautoseq;

      OPEN IO_CURSOR3 FOR
         SELECT NVL (MAX (A.custcode), '') custcode,
                NVL (MAX (NVL (p_custname, A.custname)), '') custname,
                NVL (MAX (b.accountno), '') accountno,
                NVL (MAX (b.accremark), '') accremark,
                NVL (MAX (c.bankcode), '') bankcode,
                NVL (MAX (c.bankname), '') bankname
           FROM CMCUSTM A
                LEFT JOIN CMACCOUNTM b ON b.accountno = p_accountno
                LEFT JOIN CMBANKM c ON b.bankcode = c.bankcode
          WHERE A.custcode = p_custcode;
   END IF;


   IF (IO_CURSOR IS NULL)
   THEN
      OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
   END IF;

   IF (IO_CURSOR2 IS NULL)
   THEN
      OPEN IO_CURSOR2 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
   END IF;

   IF (IO_CURSOR3 IS NULL)
   THEN
      OPEN IO_CURSOR3 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
   END IF;
END;
/
