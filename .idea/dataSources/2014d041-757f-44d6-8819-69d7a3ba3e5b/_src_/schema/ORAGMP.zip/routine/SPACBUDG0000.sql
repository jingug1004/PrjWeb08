CREATE PROCEDURE        spACbudg0000
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbudg0000
	-- 작 성 자         : 민승기
	-- 작성일자         : 2010-10-06
    -- 수 정 자     : 강현호
    -- E-Mail       : roykang0722@gmail.com
    -- 수정일자      : 2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계예산내역 검색 가능여부 체크하는 프로시저이다.
	-- ---------------------------------------------------------------
	-- exec spACbudg0000 '', '', '','','','N'
(
    p_div			IN	   VARCHAR2 DEFAULT '',
    p_iempcode		IN	   VARCHAR2 DEFAULT '',
    p_sdeptcode 	IN	   VARCHAR2 DEFAULT '',
    p_edeptcode 	IN	   VARCHAR2 DEFAULT '',
    p_userid		IN	   VARCHAR2 DEFAULT '',
    p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
    p_reasontext	IN	   VARCHAR2 DEFAULT '',

    MESSAGE         OUT    VARCHAR2,
    IO_CURSOR       OUT    TYPES.DataSet
)
AS
    p_jurisdictionyn    VARCHAR2(20);

    p_audittype         VARCHAR2(5);
    p_ii                NUMBER := 0;
    v_temp              NUMBER := 0;

BEGIN

	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	IF ( UPPER(p_div) = '' OR UPPER(p_div) IS NULL ) THEN -- 회계예산내역 권한체크

        FOR rec IN (SELECT CASE WHEN E.empcode = 'gmpit' OR					-- 슈퍼유저
                                     p1.parametercode IS NOT NULL OR		-- 회계슈퍼유저
                                     p2.parametercode IS NOT NULL			-- 회계슈퍼부서
                                     THEN  '%'
                                 ELSE NVL(NULLIF(D.bdgdeptcode, ''), D.deptcode)
                           END alias1
                    FROM   CMEMPM E
                           JOIN CMDEPTM D ON E.deptcode = D.deptcode
                           LEFT JOIN SYSPARAMETERMANAGE p1 ON p1.parametercode = 'acbudgsuperdept'
                                                              AND (p1.value1 = D.deptcode OR p1.value2 = D.deptcode OR p1.value3 = D.deptcode)
                           LEFT JOIN SYSPARAMETERMANAGE p2 ON p2.parametercode = 'acbudgsuperemp'
                                                              AND (p2.value1 = E.empcode OR p2.value2 = E.empcode OR p2.value3 = E.empcode )
                    WHERE  E.empcode = p_iempcode)
        LOOP
            p_jurisdictionyn := rec.alias1;
        END LOOP;

        MESSAGE := p_jurisdictionyn;

	ELSIF(p_div = 'S') THEN -- 회계예산내역 권한체크

        FOR rec IN (SELECT CASE WHEN a.empcode = 'gmpit' OR                 -- 슈퍼유저
                                     c.parametercode IS NOT NULL OR         -- 회계슈퍼유저
                                     D.parametercode IS NOT NULL OR         -- 회계슈퍼부서
                                     E.empcode IS NOT NULL 				    -- 예산권한유져
                                     THEN  '%'
                                 ELSE NVL(NULLIF(b.bdgdeptcode, ''), b.deptcode)
                           END alias1
                    FROM   CMEMPM a
                           JOIN CMDEPTM b ON a.deptcode = b.deptcode
                           LEFT JOIN SYSPARAMETERMANAGE c ON c.parametercode = 'acbudgsuperdept'
                                                             AND (c.value1 = b.deptcode OR c.value2 = b.deptcode OR c.value3 = b.deptcode)
                           LEFT JOIN SYSPARAMETERMANAGE D ON D.parametercode = 'acbudgsuperemp'
                                                             AND (D.value1 = a.empcode OR D.value2 = a.empcode OR D.value3 = a.empcode)
                           LEFT JOIN ACBUDGAM E ON a.empcode = E.empcode
                    WHERE  a.empcode = p_iempcode)
        LOOP
            p_jurisdictionyn := rec.alias1;
        END LOOP;

        MESSAGE := p_jurisdictionyn;

	ELSIF (p_div = 'C') THEN -- 사원별 부서예산 조회권한체크

		BEGIN
			p_audittype := '';

			FOR rec IN (SELECT audittype
						FROM   ACBUDGAM
						WHERE  empcode = p_iempcode)
			LOOP
				p_audittype := rec.audittype;
			END LOOP;


            EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0000_HIGHDEPT';

			INSERT INTO VGT.TT_ACBUDG0000_HIGHDEPT
				(SELECT DISTINCT deptcode
				 FROM	CMDEPTM a
						JOIN ACBUDGAM b
							ON b.empcode = p_iempcode
							   AND audittype IN ('1', '3')
							   AND a.deptcode IN (b.deptcode1, b.deptcode2, b.deptcode3, b.deptcode4, b.deptcode5));


            EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0000_LOWDEPT';

			INSERT INTO VGT.TT_ACBUDG0000_LOWDEPT
				(SELECT DISTINCT deptcode
				 FROM	CMDEPTM a
						JOIN ACBUDGAM b
							ON b.empcode = p_iempcode
							   AND audittype IN ('2', '3')
							   AND a.deptcode IN (b.deptcode1, b.deptcode2, b.deptcode3, b.deptcode4, b.deptcode5));



			IF p_audittype IN ('1', '3') THEN

                p_ii := 1;

                WHILE p_ii < 10 LOOP

                    INSERT INTO VGT.TT_ACBUDG0000_HIGHDEPT
                        (SELECT DISTINCT a.predeptcode
                         FROM	CMDEPTM a
                                JOIN VGT.TT_ACBUDG0000_HIGHDEPT b ON a.deptcode = b.deptcode
                                LEFT JOIN VGT.TT_ACBUDG0000_HIGHDEPT c ON a.predeptcode = c.deptcode
                         WHERE	NVL(TRIM(a.predeptcode), '') IS NOT NULL
                                AND c.deptcode IS NULL);

                    p_ii := p_ii + 1;

                END LOOP;

			END IF;


			IF p_audittype IN ('2', '3') THEN

                p_ii := 1;

                WHILE p_ii < 10 LOOP

                    INSERT INTO VGT.TT_ACBUDG0000_LOWDEPT
                        (SELECT DISTINCT a.deptcode
                         FROM	CMDEPTM a
                                JOIN VGT.TT_ACBUDG0000_LOWDEPT b ON a.predeptcode = b.deptcode
                                LEFT JOIN VGT.TT_ACBUDG0000_LOWDEPT c ON a.deptcode = c.deptcode
                         WHERE	c.deptcode IS NULL);

                    p_ii := p_ii + 1;

                END LOOP;

			END IF;


            FOR rec IN( SELECT 1 AS alias1
                        FROM   DUAL
                        WHERE  p_audittype = '9'
                                OR NOT EXISTS   (  SELECT *
                                                   FROM   CMDEPTM a
                                                          LEFT JOIN (SELECT deptcode FROM VGT.TT_ACBUDG0000_HIGHDEPT

                                                                     UNION

                                                                     SELECT deptcode FROM VGT.TT_ACBUDG0000_LOWDEPT

                                                                     UNION

                                                                     SELECT deptcode
                                                                     FROM   CMEMPM
                                                                     WHERE  empcode = p_iempcode

                                                                     UNION

                                                                     SELECT b.bdgdeptcode
                                                                     FROM   CMEMPM a
                                                                            JOIN CMDEPTM b ON a.deptcode = b.deptcode
                                                                     WHERE    a.empcode = p_iempcode  ) b ON a.deptcode = b.deptcode

                                                   WHERE  ( p_sdeptcode IS NULL OR p_sdeptcode <= a.deptcode )
                                                          AND (p_edeptcode IS NULL OR a.deptcode <= p_edeptcode )
                                                          AND b.deptcode IS NULL )  )
            LOOP

                v_temp := rec.alias1;

            END LOOP;

			IF v_temp = 1 THEN

                MESSAGE := '';

			END IF;

		END;

	ELSIF (p_div = 'E') THEN -- 사원별 부서예산 조회권한 존재체크

        MESSAGE := '';

        FOR rec IN (SELECT empcode
                    FROM   ACBUDGAM
                    WHERE  empcode = p_iempcode)
        LOOP
            MESSAGE := rec.empcode;
        END LOOP;

	END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
