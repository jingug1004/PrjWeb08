CREATE FUNCTION fnRetPayAmt(
-- ---------------------------------------------------------------
-- 생 성 자 : 최용석
-- 생성일자 : 2017-12-19
-- ---------------------------------------------------------------
    p_div           IN  VARCHAR2,   -- 1:DB 2:중간입사 3:분기 4:4월 5:10월

    p_empcode       IN  VARCHAR2,   -- 사원코드
    p_strdt         IN  VARCHAR2,   -- 시작일
    p_enddt         IN  VARCHAR2    -- 종료일
)
    RETURN NUMBER
AS
    p_payamt            NUMBER(17, 0); 	-- 반환금액
    ip_strdt            VARCHAR2(10);   -- 시작일
    ip_enddt            VARCHAR2(10);   -- 종료일
BEGIN
    p_payamt := 0;

    -- DB형 금액 구하기
    if p_div = '1' then
        select  round(round(a.daycnt * round((nvl(payamt,0) + nvl(bonusamt,0)) / paycnt, 2) * 30 / 365, 0) * 0.1, 0) * 10 into p_payamt
        from (
            select  FNdatediff('day', case when midcalcdt is null or is_date(midcalcdt) = 0 then enterdt else midcalcdt end, p_enddt) + 1 as daycnt,
                    FNdatediff('day', to_char(add_months(to_date(substr(p_enddt,1,7),'yyyy-MM'), -2), 'yyyy-MM-dd'), p_enddt) + 1 as paycnt
            from    CMEMPM
            where   empcode = p_empcode
        ) a
                left join (
                    select  sum(amt) as payamt
                    from    PSPAYD
                    where   empcode = p_empcode
                            and yearmonth between to_char(add_months(to_date(substr(p_enddt,1,7),'yyyy-MM'), -2), 'yyyy-MM') and substr(p_enddt,1,7)
                            and sugodiv = 'su'
                            and sugocode in ( select  sugocode
                                              from    PSSUGOITEMM
                                              where   sugodiv = 'su'
                                                      and retiryn = 'Y'
                                                      and useyn = 'Y')
                ) b on 1 = 1
                left join (
                    select  round(sum(nvl(b.amt, c.amt)) * 3 / 12, 0) as bonusamt
                    from    SYSCALENDARMONTH a
                            left join (
                                select  yearmonth, sum(bonusamt) as amt
                                from    PSRETBONUSM
                                where   empcode = p_empcode
                                        and yearmonth between to_char(add_months(to_date(substr(p_enddt,1,7), 'yyyy-MM'), -11), 'yyyy-MM') and substr(p_enddt,1,7)
                                group by yearmonth
                            ) b on a.yearmonth = b.yearmonth
                            left join (
                                select  yearmonth, sum(amt) as amt
                                from    PSPAYD
                                where   empcode = p_empcode
                                        and yearmonth between to_char(add_months(to_date(substr(p_enddt,1,7), 'yyyy-MM'), -11), 'yyyy-MM') and substr(p_enddt,1,7)
                                        and sugodiv = 'su'
                                        and sugocode = '700'
                                        and paybonusdiv in ('01','02','03')
                                group by yearmonth
                            ) c on a.yearmonth = c.yearmonth
                    where   a.yearmonth between to_char(add_months(to_date(substr(p_enddt,1,7), 'yyyy-MM'), -11), 'yyyy-MM') and substr(p_enddt,1,7)
                ) c on 1 = 1;

    elsif p_div = '2' then  --중간입사자
--        select  --round(sum(c.yearsalary / (b.retyearday * 12)), -1) into p_payamt
--                round(sum(c.yearsalary / (365 * 12)), -1) into p_payamt --다영테스트
--        from    SYSCALENDARMASTER a
--                join (
--                    select  a.yearmonth, max(a.retyearday) as retyearday, max(b.yyyymm) as yyyymm
--                    from    SYSCALENDARMONTH a
--                            join PSYEARSALARYM b
--                                on a.yearmonth >= b.yyyymm
--                                and b.empcode = p_empcode
--                    where   a.yearmonth between substr(p_strdt,1,7) and substr(p_enddt,1,7)
--                    group by a.yearmonth
--                ) b on substr(a.daydate,1,7) = b.yearmonth
--                join PSYEARSALARYM c
--                    on b.yyyymm = c.yyyymm
--                    and c.empcode = p_empcode
--        where   a.daydate between p_strdt and p_enddt;

        FOR rec
          IN (select  --round(sum(c.yearsalary / (b.retyearday * 12)), -1) into p_payamt
                round(sum(c.yearsalary / (365 * 12)), -1) as amt --다영테스트
        from    SYSCALENDARMASTER a
                join (
                    select  a.yearmonth, max(a.retyearday) as retyearday, max(b.yyyymm) as yyyymm
                    from    SYSCALENDARMONTH a
                            join PSYEARSALARYM b
                                on a.yearmonth >= b.yyyymm
                                and b.empcode = p_empcode
                    where   a.yearmonth between substr(p_strdt,1,7) and substr(p_enddt,1,7)
                    group by a.yearmonth
                ) b on substr(a.daydate,1,7) = b.yearmonth
                join PSYEARSALARYM c
                    on b.yyyymm = c.yyyymm
                    and c.empcode = p_empcode
        where   a.daydate between p_strdt and p_enddt)
       LOOP
          p_payamt := rec.amt;
       END LOOP;

    elsif p_div = '6' then  --중간입사자 3월급여 -- 다영 추가
--        select  max(yearsalary)/12 into p_payamt --다영테스트
--        from    PSYEARSALARYM c
--        where   c.yyyymm = substr(p_strdt, 1, 7)
--          and   c.empcode = p_empcode;

        FOR rec
        IN (select  max(yearsalary)/12 as amt --다영테스트
              from    PSYEARSALARYM c
             where   c.yyyymm = substr(p_strdt, 1, 7)
               and   c.empcode = p_empcode)
       LOOP
          p_payamt := rec.amt;
       END LOOP;

    elsif p_div = '3' then  --분기별 금액
        for rec in (
            select  case when enterdt < p_strdt then p_strdt else enterdt end as strdt,
                    case when retiredt is null or p_enddt < retiredt then p_enddt else retiredt end as enddt
            from    CMEMPM
            where   empcode = p_empcode)
        loop
            ip_strdt := rec.strdt;
            ip_enddt := rec.enddt;
        end loop ;

        select  round(sum(c.yearsalary / (b.retyearday * 12)), -1) into p_payamt
        from    SYSCALENDARMASTER a
                join (
                    select  a.yearmonth, max(a.retyearday) as retyearday, max(b.yyyymm) as yyyymm
                    from    SYSCALENDARMONTH a
                            join PSYEARSALARYM b
                                on a.yearmonth >= b.yyyymm
                                and b.empcode = p_empcode
                    where   a.yearmonth between substr(ip_strdt,1,7) and substr(ip_enddt,1,7)
                    group by a.yearmonth
                ) b on substr(a.daydate,1,7) = b.yearmonth
                join PSYEARSALARYM c
                    on b.yyyymm = c.yyyymm
                    and c.empcode = p_empcode
        where   a.daydate between ip_strdt and ip_enddt;

    elsif p_div = '4' then   --4월 진급자 연봉 월급
--        select  round(a.yearsalary / 12, 0) into p_payamt
--        from    PSYEARSALARYM a
--                join (
--                    select  max(yyyymm) as yyyymm
--                    from    PSYEARSALARYM
--                    where   empcode = p_empcode
--                            and yyyymm <= substr(p_enddt,1,7)
--                            and statediv = '09'
--                ) b on a.yyyymm = b.yyyymm
--        where   a.empcode = p_empcode;

        FOR rec
        IN (select  round(a.yearsalary / 12, 0) as amt
        from    PSYEARSALARYM a
                join (
                    select  max(yyyymm) as yyyymm
                    from    PSYEARSALARYM
                    where   empcode = p_empcode
                            and yyyymm <= substr(p_enddt,1,7)
                            and statediv = '09'
                ) b on a.yyyymm = b.yyyymm
        where   a.empcode = p_empcode)
       LOOP
          p_payamt := rec.amt;
       END LOOP;

    elsif p_div = '5' then  --10월 진급자 연봉 월급


--        select  round(a.yearsalary / 12, 0) into p_payamt
--        from    PSYEARSALARYM a
--                join (
--                    select  max(yyyymm) as yyyymm
--                    from    PSYEARSALARYM
--                    where   empcode = p_empcode
--                            and yyyymm between substr(p_strdt,1,7) and substr(p_enddt,1,7)
--                            and statediv = '09'
--                ) b on a.yyyymm = b.yyyymm
--        where   a.empcode = p_empcode;

        FOR rec
          IN (select  round(a.yearsalary / 12, 0) as amt
                from    PSYEARSALARYM a
                        join (
                            select  max(yyyymm) as yyyymm
                            from    PSYEARSALARYM
                            where   empcode = p_empcode
                                    and yyyymm between substr(p_strdt,1,7) and substr(p_enddt,1,7)
                                    and statediv = '09'
                        ) b on a.yyyymm = b.yyyymm
                where   a.empcode = p_empcode)
       LOOP
          p_payamt := rec.amt;
       END LOOP;

    end if;

    return (nvl(p_payamt,0));
EXCEPTION
    WHEN OTHERS
    THEN RETURN 0;
END;
/
