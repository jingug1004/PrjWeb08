CREATE PROCEDURE        SPAAROYTEST
(
    name            IN     VARCHAR2 DEFAULT '',    
    IO_CURSOR       OUT    TYPES.DataSet
    
)
AS
 
BEGIN

    OPEN IO_CURSOR FOR
        SELECT name || '1' AS name FROM DUAL ;

        

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
