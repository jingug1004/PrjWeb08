CREATE PROCEDURE        spAccountManage(
   ------------------------------------------------------------------------------------
   --Sp명                :  spMenuProgramManage
   --작성자            :  이세민
   --작성일자            :  2007-10-04
   ------------------------------------------------------------------------------------
   --프로그램설명        :  메뉴를 등록/관리하는 마스터 Sp입니다.
   ------------------------------------------------------------------------------------

   p_div          IN    VARCHAR2 := '',
   p_empcode         IN    VARCHAR2 := '',
   p_deptcode        IN    VARCHAR2 := '',
   p_existaccountyn  IN    VARCHAR2 := ' ',
   p_gb           IN    CHAR := '',
   p_plantcode       IN    VARCHAR2 := '',
   p_userid       IN    VARCHAR2 := '',
   p_reasondiv       IN    VARCHAR2 := '',
   p_reasontext      IN    VARCHAR2 := '',
   IO_CURSOR            OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2
)
AS
   v_id         VARCHAR2(100);
   v_pwd        VARCHAR2(100);
   v_lockcnt       INT := 0;
   v_signperiod    INT := 0;
   v_esignperiod   INT := 0;
   v_check      INT := 0;
   ip_plantcode    VARCHAR2(4) := p_plantcode;
    
BEGIN

   MESSAGE := '데이터 확인';

   IF (ip_plantcode IS NULL)
   THEN
      ip_plantcode := '1000';
   END IF;

   FOR REC IN (SELECT TO_NUMBER(value1) D1
            FROM   parametermanage
            WHERE  parametercode = 'ESignFailedNum')
   LOOP
      v_lockcnt := REC.D1;
   END LOOP;


   IF (p_div = 'S')
   THEN
      FOR REC IN (SELECT REPLACE(value1, ',', '') D1
               FROM   parametermanage
               WHERE  parametercode = 'SignPeriod')
      LOOP
         v_signperiod := REC.D1;
      END LOOP;

      FOR REC IN (SELECT REPLACE(value1, ',', '') D1
               FROM   parametermanage
               WHERE  parametercode = 'ESignPeriod')
      LOOP
         v_esignperiod := REC.D1;
      END LOOP;

      OPEN IO_CURSOR FOR
         SELECT NVL(A.empcode, '') AS empcode,
                NVL(A.empname, '') AS empname,
                NVL(d.deptname, '') AS deptname,
                NVL(A.enterdt, '') AS enteringdate,
                NVL(A.retiredt, '') AS retirementdate,
                NVL(E.divname, '') AS sexdivnm,
                NVL(b.divname, '') AS positiondivnm,
                NVL(c.divname, '') AS responsibilitydivnm,
                CASE WHEN TRIM(f.empcode) IS NULL THEN '미발행' ELSE '발행' END AS existaccountyn,
                CASE WHEN NVL(f.changedate, inputdate) IS NOT NULL THEN TO_CHAR(NVL(f.changedate, inputdate), 'yyyy-mm-dd') || '~' || '2099-12-31' ELSE ' ' END AS accountterm,
                CASE WHEN TRIM(f.pwd) IS NULL THEN '발행' ELSE '미발행' END AS tempaccountyn,
                'N' AS accountcheck,
                CASE WHEN f.failednum >= v_lockcnt THEN 'LOCK' ELSE ' ' END AS lock1
           FROM CMEMPM A
      LEFT JOIN CMCOMMONM B       ON A.positiondiv = b.divcode
                                 AND b.cmmcode  = 'CMM27'          --직위
      LEFT JOIN CMCOMMONM C       ON A.classdiv = c.divcode
                                 AND c.cmmcode  = 'CMM28'          --직책
      LEFT JOIN CMDEPTM   D       ON A.deptcode = d.deptcode
      LEFT JOIN CMCOMMONM E       ON A.sexdiv   = E.divcode
                                 AND E.cmmcode  = 'PS30'           --성별
      LEFT JOIN ELECTRONICSIGN F  ON A.empcode  = f.empcode
          WHERE (A.empcode LIKE p_empcode || '%'   OR A.empname LIKE p_empcode || '%')
            AND (NVL(A.deptcode, ' ') LIKE p_deptcode || '%' OR d.deptname LIKE p_deptcode || '%')
            AND ((p_gb = '0') OR  ((p_gb = '1') and NVL(outyn,'N') = 'N') OR ((p_gb = '2') AND NVL(outyn,'N') = 'Y'))
            AND NVL(f.empcode, ' ') = (CASE WHEN p_existaccountyn = 'Y' THEN A.empcode
                                            WHEN p_existaccountyn = 'N' THEN 'null'
                                            WHEN p_existaccountyn = '-' THEN NVL(p_existaccountyn,' ')
                                                                        ELSE NVL(f.empcode, ' ')
                                       END)
       ORDER BY A.empcode, A.positiondiv;
            
   ELSIF (p_div = 'I') THEN

      IF SUBSTR(p_empcode,1,1) = '8' THEN    --사원번호 '8'로 시작하는 코드는 영업의 거래처코드에서 생성한 도매처 자료이며, 사원구분이 미사원으로 등록되어 있음.

         FOR rec IN
            (SELECT CUSTCODE
               FROM CMEMPM
              WHERE EMPCODE = p_empcode
         )
         LOOP
            v_id := rec.custcode;
         END LOOP;

      ELSE

         v_id := p_empcode;

      END IF;

      v_pwd := '';

      INSERT INTO signHistory(empcode, ID, pwd, changedate, SIGNHISTORYID)
      VALUES      (p_empcode, v_id, v_pwd, SYSDATE, (SELECT NVL(MAX(SIGNHISTORYID), 0) + 1 FROM signHistory));

      FOR REC IN (SELECT COUNT(empcode) D1
                    FROM ElectronicSign
                   WHERE empcode = p_empcode
                     AND plantcode = ip_plantcode)
      LOOP
         v_check := REC.D1;
      END LOOP;

      IF (v_check = 0) THEN

         INSERT INTO ElectronicSign(plantcode,
                              empcode,
                              ID,
                              pwd,
                              failednum,
                              exityn,
                              inputdate,
                              changedate,
                              tempsignyn,
                              fixidyn)
         VALUES   (ip_plantcode,
                   p_empcode,
                   v_id,
                   v_pwd,
                   0,
                   NULL,
                   SYSDATE,
                   NULL,
                   'Y',
                   'Y');

      END IF;

      IF (v_check = 1) THEN
        
         UPDATE ElectronicSign
            SET pwd        = v_pwd,
                failednum  = 0,
                exityn     = NULL,
                changedate = SYSDATE,
                tempsignyn = 'Y'
          WHERE empcode   = p_empcode
            AND plantcode = ip_plantcode;

      END IF;
        
   ELSIF (p_div = 'LK')
   THEN
    
      UPDATE electronicsign
      SET    failednum = v_lockcnt
      WHERE  empcode = p_empcode
            AND plantcode = ip_plantcode;
               
   ELSIF (p_div = 'ULK')
   THEN
    
      UPDATE electronicsign
      SET    failednum = 0
      WHERE  empcode = p_empcode
            AND plantcode = ip_plantcode;
   END IF;

   IF (IO_CURSOR IS NULL)
   THEN
      OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
   END IF;
END spAccountManage;
/
