CREATE PROCEDURE SetACORDDMM (
-- ---------------------------------------------------------------
-- 프로시저명       : SetACORDDMM
-- ---------------------------------------------------------------
-- 프로시저 설명    : 이전 시스템에서 회계잔액을 가져오는 프로시저이다.
-- ---------------------------------------------------------------
    p_div         IN  VARCHAR2 DEFAULT ''
)
AS
    MESSAGE           VARCHAR2(200);
    IO_CURSOR         TYPES.DataSet;
    p_count           INTEGER := 0;
BEGIN
    -- 계정별 잔액
    delete
    from    ACORDDMM
    where   slipym like '2017%';
    
    insert into ACORDDMM
    select  '100', '1000', slipym, '10', acccode, sum(bsdebamt), sum(bscreamt), sum(debamt), sum(creamt), sum(totdebamt), sum(totcreamt)
    from (
        select  to_char(add_months(to_date('2013-01', 'yyyy-MM'), 12 * (a.gisu - 35)), 'yyyy-MM') as slipym, b.acccode, a.cha_gumak as bsdebamt, a.dae_gumak as bscreamt, 0 as debamt, 0 as creamt, 0 as totdebamt, 0 as totcreamt
        from    account.FACA45S a
                join ACACCM b
                    on a.gaejung_cd = b.altcode
        where   a.gisu = 39
        union all
        select  fnstuff(magam_ym,5,0,'-'), b.acccode, 0, 0, a.cha_gumak, a.dae_gumak, 0, 0
        from    account.FACA43S a
                join ACACCM b
                    on a.gaejung_cd = b.altcode
        where   a.magam_ym between '201701' and '201712'
    ) a
    group by slipym, acccode;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    insert into ACORDDMM
    select  a.compcode, a.plantcode, to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM'), a.closediv, a.acccode, 0, 0, 0, 0, 0, 0
    from    ACORDDMM a
            left join ACORDDMM b
                on to_char(add_months(to_date(a.slipym, 'yyyy-MM'), 1), 'yyyy-MM') = b.slipym
                and a.acccode = b.acccode
    where   a.slipym like '2017%' and substr(a.slipym,-2) < '12' and b.slipym is null;
    
    merge into ACORDDMM a
    using (
        select  a.slipym, a.acccode, nvl(sum(b.bsdebamt+b.debamt),0) as bsdebamt, nvl(sum(b.bscreamt+b.creamt),0) as bscreamt
        from    ACORDDMM a
                left join ACORDDMM b
                    on a.slipym > b.slipym
                    and a.acccode = b.acccode
                    and substr(a.slipym,1,4) = substr(b.slipym,1,4)
        where   a.slipym like '2017%'
        group by a.slipym, a.acccode
    ) b on (a.slipym = b.slipym
            and a.acccode = b.acccode)
    when matched
    then
        update set a.bsdebamt = a.bsdebamt + b.bsdebamt,
                   a.bscreamt = a.bscreamt + b.bscreamt,
                   a.totdebamt = a.bsdebamt + a.debamt + b.bsdebamt,
                   a.totcreamt = a.bscreamt + a.creamt + b.bscreamt;

    -- 반제전표 생성
    delete
    from    ACORDD_REPAY;

    delete
    from    ACORDD_SEQ;

    insert into ACORDD_REPAY
    select  a.gaejung_cd,
            account.FACA_SF_GAEJUNG_SNM(b.mok_cd) || '-' || b.gaejung_nm as gaejung_nm,
            c.jukyo,
            a.cross_cd,
            c.seq_no,
            DECODE(b.dc_gubun, '차', a.cha_gumak
                                   , '대', a.dae_gumak
                  )                                            wongum,
            /*잔액- 계정코드의 대차구분에 의해 원금 - 회계반제내역(FACA23T)의 반대변합계액)을 읽기*/
            DECODE(b.dc_gubun, '차', a.cha_gumak - a.dae_sang + NVL(SEUNGIN.dae_gumak, 0)
                                   , '대', a.dae_gumak - a.cha_sang + NVL(SEUNGIN.cha_gumak, 0)
                  )                                            janak,
            account.FACA_SF_BOGU_NM(c.bogu_cd1)                                                 bogu_nm1,
            c.bojo_cd1,
            account.FACA_SF_BOJO_CHASU_NM(c.bogu_cd1,  c.bojo_cd1,  c.georae_chasu) bojo_nm1,
            account.FACA_SF_BOGU_NM(c.bogu_cd2)                                                 bogu_nm2,
            c.bojo_cd2,
            account.FACA_SF_BOJO_CHASU_NM(c.bogu_cd2,  c.bojo_cd2,  c.georae_chasu) bojo_nm2,
            account.FACA_SF_BOGU_NM(c.bogu_cd3)                                                 bogu_nm3,
            c.bojo_cd3,
            account.FACA_SF_BOJO_CHASU_NM(c.bogu_cd3,  c.bojo_cd3,  c.georae_chasu) bojo_nm3,
            account.FACA_SF_BOGU_NM(c.bogu_cd4)                                                 bogu_nm4,
            c.bojo_cd4,
            account.FACA_SF_BOJO_CHASU_NM(c.bogu_cd4,  c.bojo_cd4,  c.georae_chasu) bojo_nm4,
            account.FACA_SF_BOGU_NM(c.bogu_cd5)                                                 bogu_nm5,
            c.bojo_cd5,
            account.FACA_SF_BOJO_CHASU_NM(c.bogu_cd5,  c.bojo_cd5,  c.georae_chasu) bojo_nm5,
            account.FACA_SF_BOGU_NM(c.bogu_cd6)                                                 bogu_nm6,
            c.bojo_cd6,
            account.FACA_SF_BOJO_CHASU_NM(c.bogu_cd6,  c.bojo_cd6,  c.georae_chasu) bojo_nm6,
            account.FACA_SF_BOGU_NM(c.bogu_cd7)                                                 bogu_nm7,
            c.bojo_cd7,
            account.FACA_SF_BOJO_CHASU_NM(c.bogu_cd7,  c.bojo_cd7,  c.georae_chasu) bojo_nm7,
            account.FACA_SF_BOGU_NM(c.bogu_cd8)                                                 bogu_nm8,
            c.bojo_cd8,
            account.FACA_SF_BOJO_CHASU_NM(c.bogu_cd8,  c.bojo_cd8,  c.georae_chasu) bojo_nm8,
            account.FACA_SF_BOGU_NM(c.bogu_cd9)                                                 bogu_nm9,
            c.bojo_cd9,
            account.FACA_SF_BOJO_CHASU_NM(c.bogu_cd9,  c.bojo_cd9,  c.georae_chasu) bojo_nm9,
            account.FACA_SF_BOGU_NM(c.bogu_cd10)                                                bogu_nm10,
            c.bojo_cd10,
            account.FACA_SF_BOJO_CHASU_NM(c.bogu_cd10, c.bojo_cd10, c.georae_chasu) bojo_nm10,
            e.dept_cd ,
            f.dept_nm
       from account.FACA20M a,
            account.FACA03C b,
            account.FACA10T c,
            account.FACA09M d,
            account.FACA11M e,
            account.SYS901C f,
            ( select cross_cd,
                     cross_hms,
                     NVL(SUM(cha_gumak), 0) cha_gumak,
                     NVL(SUM(dae_gumak), 0) dae_gumak
                from account.FACA23T
               where jojung_yn  = 'N'
                 and junpyo_cd  > '20171231' || '9999'
               group by cross_cd, cross_hms )                  SEUNGIN
      where   a.danwi_cd      = '100'
              and a.cross_cd      < '20171231' || '힝힝'
              and c.junpyo_cd     = a.cross_cd
              and c.junpyo_hms    = a.cross_hms
              and d.junpyo_cd     = c.junpyo_cd
              and e.h_junpyo_cd   = d.h_junpyo_cd
              and b.gaejung_cd    = a.gaejung_cd
              and SEUNGIN.cross_cd  (+) = a.cross_cd
              and SEUNGIN.cross_hms (+) = a.cross_hms
              and DECODE(b.dc_gubun, '차', a.cha_gumak - a.dae_sang + NVL(SEUNGIN.dae_gumak, 0)
                                   , '대', a.dae_gumak - a.cha_sang + NVL(SEUNGIN.cha_gumak, 0)) != 0
        and e.dept_cd = f.dept_cd
      order by 1, 4, 5;      

    delete
    from    ACORDD_REPAY
    where   (cross_cd, seq_no) in (select  cross_cd, seq_no
                                   from    ACORDD_REPAYOLD);

    select  count(*) into p_count
    from    ACORDD_REPAY;

    if p_count > 0 then
        delete
        from    ACORDD
        where   slipinno < '2018'
                and acccode = '11101010';
        
        insert into ACORDM
            (compcode, slipinno, slipdiv, slipindate, slipinnum, deptcode, plantcode, empcode, eviddiv, slipinremark, slipno, slipdate, slipnum, skreqdate, slipinstate, insertdt, iempcode)
        select  '100', cross_cd||'A0001', 'A', fnstuff(fnstuff(cross_cd,5,0,'-'),8,0,'-'), 'A0001', '0008', '1000', '2016224', '99', '반제전표 자동생성',
                cross_cd||'A0001', fnstuff(fnstuff(cross_cd,5,0,'-'),8,0,'-'), 'A0001', fnstuff(fnstuff(cross_cd,5,0,'-'),8,0,'-'), '4', sysdate, 'gmpit'
        from (
            select  substr(cross_cd,1,8) as cross_cd
            from    ACORDD_REPAY a
            group by substr(cross_cd,1,8)
        ) a
                left join ACORDM b
                    on a.cross_cd||'A0001' = b.slipinno
        where   b.slipinno is null;
    
        insert into ACORDD_SEQ
        select  slipinno, max(slipinseq) as slipinseq
        from    ACORDD
        where   slipinno < '2018'
        group by slipinno;
    
        insert into ACORDD
            (compcode, slipinno, slipinseq, dcdiv, acccode, plantcode, debamt, creamt, slipdate, slipnum, remark1, rptseq, insertdt, iempcode)
        select  '100', substr(a.cross_cd,1,8)||'A0001',
                row_number()over(partition by substr(a.cross_cd,1,8) order by a.cross_cd, a.seq_no) + nvl(c.slipinseq,0),
                b.dcdiv, b.acccode, '1000', case when b.dcdiv = '1' then a.janak else 0 end,
                case when b.dcdiv = '2' then a.janak else 0 end, fnstuff(fnstuff(substr(a.cross_cd,1,8),5,0,'-'),8,0,'-'), 'A0001', a.jukyo,
                row_number()over(partition by substr(a.cross_cd,1,8) order by a.cross_cd, a.seq_no) + nvl(c.slipinseq,0), sysdate, 'gmpit'
        from    ACORDD_REPAY a
                join ACACCM b
                    on a.gaejung_cd = b.altcode
                left join ACORDD_SEQ c
                    on substr(a.cross_cd,1,8)||'A0001' = c.slipinno;
    
        insert into ACORDS
            (compcode, slipinno, slipinseq, mngclucode, seq, mngcluval, mngcludec, insertdt, iempcode)
        select  '100', substr(cross_cd,1,8)||'A0001', slipinseq, mngclucode, 1, mngcluval, mngcludec, sysdate, 'gmpit'
        from (
            select  cross_cd, row_number()over(partition by substr(cross_cd,1,8) order by cross_cd, seq_no) + nvl(b.slipinseq,0) as slipinseq,
                    'S010' as mngclucode, bojo_cd1 as mngcluval, bojo_nm1 as mngcludec, bogu_nm1
            from    ACORDD_REPAY a
                    left join ACORDD_SEQ b
                        on substr(a.cross_cd,1,8)||'A0001' = b.slipinno
        ) a
        where   bogu_nm1 = '거래처';
        
        insert into ACORDS
            (compcode, slipinno, slipinseq, mngclucode, seq, mngcluval, mngcludec, insertdt, iempcode)
        select  '100', substr(cross_cd,1,8)||'A0001', slipinseq, mngclucode, 1, mngcluval, mngcludec, sysdate, 'gmpit'
        from (
            select  cross_cd, row_number()over(partition by substr(cross_cd,1,8) order by cross_cd, seq_no) + nvl(b.slipinseq,0) as slipinseq,
                    'S040' as mngclucode, bojo_cd1 as mngcluval, bojo_nm1 as mngcludec, bogu_nm1
            from    ACORDD_REPAY a
                    left join ACORDD_SEQ b
                        on substr(a.cross_cd,1,8)||'A0001' = b.slipinno
        ) a
        where   bogu_nm1 = '부서';
        
        insert into ACORDS
            (compcode, slipinno, slipinseq, mngclucode, seq, mngcluval, mngcludec, insertdt, iempcode)
        select  '100', substr(cross_cd,1,8)||'A0001', slipinseq, mngclucode, 1, mngcluval, mngcludec, sysdate, 'gmpit'
        from (
            select  cross_cd, row_number()over(partition by substr(cross_cd,1,8) order by cross_cd, seq_no) + nvl(b.slipinseq,0) as slipinseq,
                    'S050' as mngclucode, bojo_cd2 as mngcluval, bojo_nm2 as mngcludec, bogu_nm2
            from    ACORDD_REPAY a
                    left join ACORDD_SEQ b
                        on substr(a.cross_cd,1,8)||'A0001' = b.slipinno
        ) a
        where   bogu_nm2 = '사원';
        
        insert into ACORDS
            (compcode, slipinno, slipinseq, mngclucode, seq, mngcluval, mngcludec, insertdt, iempcode)
        select  '100', substr(cross_cd,1,8)||'A0001', slipinseq, mngclucode, 1, mngcluval, mngcludec, sysdate, 'gmpit'
        from (
            select  cross_cd, row_number()over(partition by substr(cross_cd,1,8) order by cross_cd, seq_no) + nvl(b.slipinseq,0) as slipinseq,
                    'U020' as mngclucode, bojo_cd4 as mngcluval, bojo_nm4 as mngcludec, bogu_nm4
            from    ACORDD_REPAY a
                    left join ACORDD_SEQ b
                        on substr(a.cross_cd,1,8)||'A0001' = b.slipinno
        ) a
        where   bogu_nm4 = '만기일';
        
        insert into ACORDS
            (compcode, slipinno, slipinseq, mngclucode, seq, mngcluval, mngcludec, insertdt, iempcode)
        select  '100', substr(cross_cd,1,8)||'A0001', slipinseq, mngclucode, 1, mngcluval, mngcludec, sysdate, 'gmpit'
        from (
            select  cross_cd, row_number()over(partition by substr(cross_cd,1,8) order by cross_cd, seq_no) + nvl(b.slipinseq,0) as slipinseq,
                    'S110' as mngclucode, bojo_cd5 as mngcluval, bojo_nm5 as mngcludec, bogu_nm5
            from    ACORDD_REPAY a
                    left join ACORDD_SEQ b
                        on substr(a.cross_cd,1,8)||'A0001' = b.slipinno
        ) a
        where   bogu_nm5 = '어음번호';
        
        merge into ACORDS a
        using (
            select  slipinno, slipinseq, mngclucode, row_number()over(partition by slipinno, slipinseq order by mngclucode) as seq
            from    ACORDS) b
        on (a.slipinno = b.slipinno
            and a.slipinseq = b.slipinseq
            and a.mngclucode = b.mngclucode)
        when matched
        then
            update set a.seq = b.seq;
        
        delete from ACORDSMM where slipym < '2018' and acccode in ('21030600', '21010100', '21010200', '11108060', '11120020', '21030200', '21030500');
        
        insert into ACORDSMM
        select  '100', '1000', '2017-12', '10', a.acccode, a.mngclucode, a.mngcluval, a.mngcludec, a.debamt, a.creamt, 0, 0, a.debamt, a.creamt
        from (
            select  a.acccode, b.mngclucode, b.mngcluval, max(b.mngcludec) as mngcludec, sum(a.debamt) as debamt, sum(a.creamt) as creamt
            from    ACORDD a
                    join ACORDS b
                        on a.slipinno = b.slipinno
                        and a.slipinseq = b.slipinseq
                        and b.mngclucode = 'S010'
            where   a.slipinno < '2018'
            group by a.acccode, b.mngclucode, b.mngcluval
        ) a
                join (
                    select  acccode, mngclucode
                    from    ACACCMNGM
                    where   remainyn = 'Y'
                    group by acccode, mngclucode
                ) b on a.acccode = b.acccode
                    and a.mngclucode = b.mngclucode
        order by a.acccode, a.mngclucode, a.mngcluval;
        
        insert into ACORDSMM
        select  '100', '1000', '2017-12', '10', a.acccode, a.mngclucode, a.mngcluval, a.mngcludec, a.debamt, a.creamt, 0, 0, a.debamt, a.creamt
        from (
            select  a.acccode, b.mngclucode, b.mngcluval, max(b.mngcludec) as mngcludec, sum(a.debamt) as debamt, sum(a.creamt) as creamt
            from    ACORDD a
                    join ACORDS b
                        on a.slipinno = b.slipinno
                        and a.slipinseq = b.slipinseq
                        and b.mngclucode = 'S110'
            where   a.slipinno < '2018'
            group by a.acccode, b.mngclucode, b.mngcluval
        ) a
                join (
                    select  acccode, mngclucode
                    from    ACACCMNGM
                    where   remainyn = 'Y'
                    group by acccode, mngclucode
                ) b on a.acccode = b.acccode
                    and a.mngclucode = b.mngclucode
        order by a.acccode, a.mngclucode, a.mngcluval;
        
        insert into ACORDD
        select  '100', slipinno, slipinseq, dcdiv, '11101010', '1000', debamt, creamt, slipdate, slipnum, '자료보정', null, null, null, null, slipinseq, sysdate, 'gmpit', null, null
        from (
            select  slipinno,
                    case when sum(debamt) < sum(creamt) then '1' else '2' end as dcdiv,
                    case when sum(debamt) > sum(creamt) then 0 else sum(creamt) - sum(debamt) end as debamt,
                    case when sum(debamt) > sum(creamt) then sum(debamt) - sum(creamt) else 0 end as creamt,
                    max(slipinseq)+1 as slipinseq, max(slipdate) as slipdate, max(slipnum) as slipnum
            from    ACORDD
            where   slipinno < '2018'
            group by slipinno
            having sum(debamt) <> sum(creamt)
        ) a;
        
        insert into ACBILLM
        select  '100', nvl(c.billno,b.billno), '1', b.coldiv, '', b.coldate, b.issdate, b.expdate, a.janak, b.custcode, b.issempnm, b.paybank, b.paybankbr,
                b.deptcode, b.plantcode, nvl(b.tasooyn,'N'), 'A', '1', '', '', '', b.remark, '', '', '', '', sysdate, 'gmpit', '', ''
        from    ACORDD_REPAY a
                join SLCOLM b
                    on a.bojo_nm5 = b.billno
                    and a.bojo_nm4 = replace(b.expdate,'-','')
                    and a.wongum = b.colamt
                left join (
                    select  bojo_nm5, bojo_nm5 || '-1' as billno, max(cross_cd) as cross_cd
                    from    ACORDD_REPAY
                    where   bogu_nm5 = '어음번호'
                    group by bojo_nm5
                    having count(*) > 1
                ) c on a.bojo_nm5 = c.bojo_nm5
                    and a.cross_cd = c.cross_cd
                left join ACBILLM d
                    on nvl(c.billno,b.billno) = d.billno
        where   a.gaejung_cd = '11140CA'
                and a.bogu_nm5 = '어음번호'
                and d.billno is null;
        
        insert into ACBILLM
        select  '100', a.bojo_nm5, '1', case a.bojo_nm3 when '당좌' then '32' when '가-수(타)' then '31' else '30' end, '', FNstuff(FNstuff(a.bojo_nm2,5,0,'-'),8,0,'-'), FNstuff(FNstuff(substr(a.cross_cd,1,8),5,0,'-'),8,0,'-'),
                FNstuff(FNstuff(a.bojo_nm4,5,0,'-'),8,0,'-'), a.janak, a.bojo_cd1, a.bojo_nm7,
                case substr(a.bojo_nm6,1,2) when '대구' then '031' when '신한' then '088' when '농협' then '011' when '국민' then '006' when '제일' then '023' when '기업' then '003' when '우리' then '020'
                                            when '광주' then '034' when '부산' then '032' when '경남' then '039' when '전북' then '037' when '하나' then '081' when '조흥' then '088' else a.bojo_nm6 end,
                a.bojo_nm6, '0416', '1000', case a.bojo_nm3 when '가-수(타)' then 'Y' else 'N' end, 'A', '1', '', '', '', '', '', '', '', '', sysdate, 'gmpit', '', ''
        from    ACORDD_REPAY a
                left join SLCOLM b
                    on a.bojo_nm5 = b.billno
                    and a.bojo_nm4 = replace(b.expdate,'-','')
                    and a.wongum = b.colamt
                left join ACBILLM c
                    on a.bojo_nm5 = c.billno
        where   a.gaejung_cd = '11140CA'
                and a.bogu_nm5 = '어음번호'
                and b.billno is null
                and c.billno is null;
        
        insert into ACBILLM
        select  '100', a.bojo_nm5, '2', '30', '', FNstuff(FNstuff(a.bojo_nm3,5,0,'-'),8,0,'-'), '', FNstuff(FNstuff(a.bojo_nm4,5,0,'-'),8,0,'-'), a.janak, a.bojo_cd1, '', '003',
                '', '0416', '1000', '', '', '1', '', '', '', '', '', '', '', '', sysdate, 'gmpit', '', ''
        from    ACORDD_REPAY a
                left join ACBILLM b
                    on a.bojo_nm5 = b.billno
        where   a.gaejung_cd = '21010AC'
                and a.bogu_nm5 = '어음번호'
                and b.billno is null;
        
        insert into ACORDD_REPAYOLD
        select  *
        from    ACORDD_REPAY;    
    
        -- 회계전표 잔액 집계처리
        spACord0000MM(p_div => 'T',
                      p_compcode => '100', -- 회사코드
                      p_closediv => '10', -- 결산구분(운영)
                      p_strslipym => '2018-01', -- 결의전표번호
                      p_endslipym => '2018-03', -- 결의전표번호
                      p_userid => 'gmpit',
                      p_reasondiv => '',
                      p_reasontext => '',
                      MESSAGE => MESSAGE,
                      IO_CURSOR => IO_CURSOR);
    end if;

--    open IO_CURSOR for
--    select  distinct insertdt
--    from    ACORDD
--    where   slipinno < '2018'
--    order by insertdt;
--
--    if (IO_CURSOR is null)
--    then
--        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
--    end if;
END;
/
