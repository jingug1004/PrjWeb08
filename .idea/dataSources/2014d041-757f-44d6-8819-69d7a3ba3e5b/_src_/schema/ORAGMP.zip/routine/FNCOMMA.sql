CREATE FUNCTION fnCOMMA
-- ---------------------------------------------------------------
 -- 함 수 명            : fnDateHan
 -- 작 성 자         : 김  훈
 -- 작성일자         : 2010-04-23
 -- ---------------------------------------------------------------
 -- 함수설명            :    날짜 한글 &
 --                    :    근무 기간
 -- ---------------------------------------------------------------
(
    p_num     IN VARCHAR2 DEFAULT '',
    P_digit   IN NUMBER   DEFAULT 0
)
RETURN VARCHAR2
AS
    p_tostring   VARCHAR2(50);
    p_format     VARCHAR2(50);
BEGIN

    p_format := '999,999,999,999,999,999,999,999,999' ||
                case P_digit when 1 then '.9'
                             when 2 then '.99'
                             when 3 then '.999'
                             when 4 then '.9999'
                             end;

    p_tostring := trim(to_char(p_num, p_format));

    RETURN p_tostring;

EXCEPTION

    WHEN OTHERS THEN
        p_tostring :=' ';

    IF p_tostring IS NULL THEN
        p_tostring :='오류';
    END IF;
--EXCEPTION WHEN OTHERS THEN utils.handleerror(SQLCODE,SQLERRM);
END;
/
