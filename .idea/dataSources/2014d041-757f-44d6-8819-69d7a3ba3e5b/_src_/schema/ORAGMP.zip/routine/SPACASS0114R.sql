CREATE PROCEDURE        spACass0114R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACass0114R
	-- 작 성 자         : 최인범
	-- 작성일자         : 2010-10-04
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2017-01-02
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 감가상각명세서를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '',
	p_caldiv		IN	   VARCHAR2 DEFAULT '',
	p_assym 		IN	   VARCHAR2 DEFAULT '',
	p_assdiv		IN	   VARCHAR2 DEFAULT '',
	p_deptcode		IN	   VARCHAR2 DEFAULT '',
	p_workdiv		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	p_strym 	VARCHAR2(7);
	p_strdate	VARCHAR2(10);
	p_enddate	VARCHAR2(10);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	-- 계산기간 설정
	p_strym := SUBSTR(p_assym, 0, 4) || '-01';

	FOR rec IN (SELECT MAX(SUBSTR(curstrdate, 0, 7)) AS alias1
				FROM   ACSESSION a
				WHERE  compcode = p_compcode
					   AND cyear <= SUBSTR(p_assym, 0, 4))
	LOOP
		p_strym := rec.alias1;
	END LOOP;

	IF SUBSTR(p_assym, -2, 2) < SUBSTR(p_strym, -2, 2)
	THEN
		p_strym := TO_CHAR(TO_NUMBER(SUBSTR(p_assym, 0, 4)) - 1) || SUBSTR(p_strym, -3, 3);
	ELSE
		p_strym := SUBSTR(p_assym, 0, 4) || SUBSTR(p_strym, -3, 3);
	END IF;

	p_strdate := p_strym || '-01';
	p_enddate := TO_CHAR(LAST_DAY(TO_DATE(p_assym, 'YYYY-MM')), 'YYYY-MM-DD');

	IF (p_div = 'S')
	THEN
		OPEN IO_CURSOR FOR
			SELECT	 b.assdiv assdiv,
					 ac70.divname assdivname,
					 a.asscode asscode,
					 b.assname assname,
					 a.curassamt - a.revamt - a.expamt + a.salamt - CASE WHEN b.strdate BETWEEN p_strdate AND p_enddate THEN a.curassamt ELSE 0 END fnassamt,
					 a.revamt + a.expamt + CASE WHEN b.strdate BETWEEN p_strdate AND p_enddate THEN a.curassamt ELSE 0 END incassamt,
					 a.salamt decassamt,
					 a.curassamt lsassamt,
					 a.predepamt bsdepramt,
					 a.depamt depamt,
					 a.drpamt drpamt,
					 a.predepamt + a.depamt - a.drpamt bedepramt,
					 a.curassamt - a.predepamt - a.depamt + a.drpamt yetdepramt,
					 a.lifeyear lifeyear,
					 TO_NUMBER(SUBSTR(a.assym, 0, 4)) - TO_NUMBER(SUBSTR(b.strdate, 0, 4)) runlifeyear,
					 a.lifeyear - TO_NUMBER(SUBSTR(a.assym, 0, 4)) + TO_NUMBER(SUBSTR(b.strdate, 0, 4)) minlifeyear,
					 a.deprate deprate,
					 a.deprdiv deprdiv,
					 ac74.divname deprdivname,
					 b.strdate strdate
			FROM	 ACASSDEPR a
					 LEFT JOIN ACASSM b
						 ON b.compcode = a.compcode
							AND NVL(b.asscode,' ') = NVL(a.asscode,' ')
					 LEFT JOIN CMCOMMONM ac70
						 ON ac70.cmmcode = 'AC70' --자산형태
							AND NVL(ac70.divcode,' ') = NVL(b.assdiv, ' ')
					 LEFT JOIN CMCOMMONM ac74
						 ON ac74.cmmcode = 'AC74' --자산상각방법
							AND NVL(ac74.divcode, ' ') = NVL(a.deprdiv, ' ')
			WHERE	 a.compcode = p_compcode
					 AND a.closediv = p_closediv
					 AND a.caldiv = p_caldiv
					 AND a.assym = p_assym
					 AND b.plantcode LIKE p_plantcode
					 AND NVL(b.mngdeptcode, ' ') LIKE p_deptcode || '%'
					 AND NVL(b.assdiv, ' ') LIKE p_assdiv
					 AND NVL(b.workdiv, ' ') LIKE p_workdiv
			ORDER BY b.assdiv , a.asscode NULLS FIRST;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
