CREATE PROCEDURE col_Sal_Day_Conversion_Loop
-- ---------------------------------------------------------------
-- 프로시저명        :
-- 작 성 자          :
-- 작성일자          :
-- ---------------------------------------------------------------
-- 프로시저 설명     : 가 오픈 시 사용하는 주문,수금 자료 생성 프로시저이다
--                가상계좌수금 과 전자어음은 별도로 반영되므로 여기서 생성하지 않음
-- ---------------------------------------------------------------
(
   p_ymd                IN    VARCHAR2 DEFAULT ''
)
AS

   p_plantcode                VARCHAR2(30);
   p_coldate                  VARCHAR2(30);
   p_coldiv                   VARCHAR2(30);
   p_coldtldiv                VARCHAR2(30);
   p_orderdiv                 VARCHAR2(30);
   p_tasooyn                  VARCHAR2(30);
   p_custcode                 VARCHAR2(30);
   p_deptcode                 VARCHAR2(30);
   p_empcode                  VARCHAR2(30);
   p_ecustcode                VARCHAR2(30);
   p_edeptcode                VARCHAR2(30);
   p_eempcode                 VARCHAR2(30);
   p_colamt                   FLOAT := 0;
   p_colvat                   FLOAT := 0;
   p_accountno                VARCHAR2(30);
   p_billno                   VARCHAR2(30);
   p_issdate                  VARCHAR2(30);
   p_expdate                  VARCHAR2(30);
   p_paybank                  VARCHAR2(30);
   p_paybankbr                VARCHAR2(30);
   p_issempnm                 VARCHAR2(30);
   p_baeseo                   VARCHAR2(30);
   p_cardcomp                 VARCHAR2(30);
   p_cardno                   VARCHAR2(50);
   p_cardokno                 VARCHAR2(30);
   p_carddate                 VARCHAR2(30);
   p_divmonth                 FLOAT := 0;
   p_autoyn                   VARCHAR2(30);
   p_appdate                  VARCHAR2(30);
   p_discntdate               VARCHAR2(30);
   p_custprtyn                VARCHAR2(30);
   p_remark                   VARCHAR2(30);
   p_apprstatus               VARCHAR2(30);
   p_moneycode                VARCHAR2(30);
   p_exrtrate                 FLOAT := 0;
   p_exrtamt                  FLOAT := 0;
   p_iempcode                 VARCHAR2(30);

   p_bill_gb                  VARCHAR2(10);

   v_spSLSALERESULT_N_param   VARCHAR2(256);
--
--   MESSAGE                 VARCHAR2(32767);
--   IO_CURSOR               TYPES.DataSet;


   CURSOR CARD_SUGUM_READ IS
      SELECT TO_CHAR(A.YMD,'YYYY-MM-DD') AS COLDATE  ,     --입력일자
             A.BILL_NO        AS CARDNO   ,     --카드번호
             A.AMT            AS COLAMT   ,     --수금액
             B.CARD_ACCEPT_NO AS CARDOKNO ,     --거래승인번호
             B.CUST_ID        AS CUSTCODE ,     --거래처코드
             D.INSA_SAWON_ID  AS EMPCODE  ,     --인사사원번호
             E.DEPT_CD        AS DEPTCODE ,     --부서코드
             B.RCUST_ID       AS ECUSTCODE,     --간납거래처코드
             H.INSA_SAWON_ID  AS EEMPCODE ,     --인사사원번호
             I.DEPT_CD        AS EDEPTCODE,     --부서코드
             A.BILL_GB                          --어음구분(수금구분)100-신용카드,101-압인수금,102-수기카드
        FROM SALE.SALE0402@REAL_SALE.HANA.CO.KR          A,
             SALE.SALE0401@REAL_SALE.HANA.CO.KR          B,
             SALE.SALE0007@REAL_SALE.HANA.CO.KR          D,    --사원정보
             HANAHR.HR_HC_EMPBAS_0@REAL_SALE.HANA.CO.KR  E,    --부서정보
             SALE.SALE0003@REAL_SALE.HANA.CO.KR          G,    --거래처정보
             SALE.SALE0007@REAL_SALE.HANA.CO.KR          H,    --사원정보
             HANAHR.HR_HC_EMPBAS_0@REAL_SALE.HANA.CO.KR  I     --부서정보
       WHERE A.YMD = B.YMD
         AND A.JUNPYO_NO = B.JUNPYO_NO
         AND B.SAWON_ID       = D.SAWON_ID
         AND D.INSA_SAWON_ID  = E.EMP_NO
         AND B.RCUST_ID       = G.CUST_ID
         AND G.SAWON_ID       = H.SAWON_ID
         AND H.INSA_SAWON_ID  = I.EMP_NO
         AND TO_CHAR(A.YMD,'YYYYMMDD') = REPLACE(p_ymd,'-','')
         and a.junpyo_no not in (
                            select distinct a.junpyo_no
                              from sale.sale0401@REAL_SALE.HANA.CO.KR a ,sale.sale0402@REAL_SALE.HANA.CO.KR b
                             where a.junpyo_no = b.junpyo_no(+)
                               and a.junpyo_no like p_ymd||'%'
                               and a.bigo      like '가상%'   --가상
                            union
                            select distinct a.junpyo_no
                              from sale.sale0401@REAL_SALE.HANA.CO.KR a ,sale.sale0402@REAL_SALE.HANA.CO.KR b
                             where a.junpyo_no = b.junpyo_no(+)
                               and a.junpyo_no like p_ymd||'%'
                               and b.bill_gb  in ('010','040') and substr(b.jigeub,3,4) = '0000' -- 어음
                            )
    ORDER BY A.JUNPYO_NO, A.INPUT_SEQ;

BEGIN

   --테스트 서버의 수급 자료 삭제
   DELETE FROM SLCOLM
    WHERE REPLACE(COLDATE,'-','') = REPLACE(p_ymd,'-','');

   -- 가상계좌 전자어음제외 처리
   OPEN CARD_SUGUM_READ;
   LOOP
      FETCH CARD_SUGUM_READ INTO p_coldate  , p_cardno  , p_colamt   , p_cardokno ,
                                 p_custcode , p_empcode , p_deptcode ,
                                 p_ecustcode, p_eempcode, p_edeptcode, p_bill_gb  ;
      EXIT WHEN CARD_SUGUM_READ%NOTFOUND ;

      p_plantcode  := '1000';
    --p_coldate    := :NEW.수금일자;               --일자형식 - 2017-11-01
      p_coldiv     := '21';
      p_orderdiv   := '4';
      p_tasooyn    := 'N';
    --p_custcode   := :NEW.수금처코드;
    --p_deptcode   := :NEW.수금담당부서코드;
    --p_empcode    := :NEW.수금담당코드;
    --p_ecustcode  := p_custcode;                  --수금처코드
    --p_edeptcode  := p_deptcode;                  --수금담당부서코드
    --p_eempcode   := p_empcode;                   --수금담당코드
    --p_colamt     := :NEW.수금액;
      p_colvat     := 0;
      p_accountno  := '';
      p_billno     := '';
      p_issdate    := '';
      p_expdate    := '';
      p_paybank    := '';
      p_paybankbr  := '';
      p_issempnm   := '';
      p_baeseo     := '';
      p_cardcomp   := '999';                       --카드사코드 없으면 '999'
    --p_cardno     := :NEW.카드번호;
    --p_cardokno   := :NEW.카드승인번호;
      p_carddate   := '';
      p_divmonth   := 0;
      p_carddate   := p_coldate; --:NEW.수금일자;               --일자형식 - 2017-11-01
      p_autoyn     := 'Y';
      p_carddate   := p_coldate; --:NEW.수금일자:               --일자형식 - 2017-11-01
      p_discntdate := '';
      p_custprtyn  := 'N';
      p_remark     := CASE p_bill_gb WHEN '100' THEN '신용카드' WHEN '101' THEN '압인카드' WHEN '102' THEN '수기카드' ELSE '기타' END;
      p_apprstatus := '00';
      p_exrtrate   := 0;
      p_exrtamt    := 0;
      p_iempcode   := 'card Auto';                      --작업자사번

      v_spSLSALERESULT_N_param := 'N';

      ORAGMP.COL_SAL_spSLcol0099P (p_plantcode   => p_plantcode
                          ,p_coldate     => p_coldate
                          ,p_coldiv      => p_coldiv
                          ,p_coldtldiv   => p_coldtldiv
                          ,p_orderdiv    => p_orderdiv
                          ,p_tasooyn     => p_tasooyn
                          ,p_custcode    => p_custcode
                          ,p_deptcode    => p_deptcode
                          ,p_empcode     => p_empcode
                          ,p_ecustcode   => p_ecustcode
                          ,p_edeptcode   => p_edeptcode
                          ,p_eempcode    => p_eempcode
                          ,p_colamt      => p_colamt
                          ,p_colvat      => p_colvat
                          ,p_accountno   => p_accountno
                          ,p_billno      => p_billno
                          ,p_issdate     => p_issdate
                          ,p_expdate     => p_expdate
                          ,p_paybank     => p_paybank
                          ,p_paybankbr   => p_paybankbr
                          ,p_issempnm    => p_issempnm
                          ,p_baeseo      => p_baeseo
                          ,p_cardcomp    => p_cardcomp
                          ,p_cardno      => p_cardno
                          ,p_cardokno    => p_cardokno
                          ,p_carddate    => p_carddate
                          ,p_divmonth    => p_divmonth
                          ,p_autoyn      => p_autoyn
                          ,p_discntdate  => p_discntdate
                          ,p_custprtyn   => p_custprtyn
                          ,p_remark      => p_remark
                          ,p_apprstatus  => p_apprstatus
                          ,p_moneycode   => p_moneycode
                          ,p_exrtrate    => p_exrtrate
                          ,p_exrtamt     => p_exrtamt
                          ,p_iempcode    => p_iempcode
--                          ,MESSAGE       => v_spSLSALERESULT_N_param
--                          ,IO_CURSOR     => IO_CURSOR
                          );

   END LOOP;
   CLOSE CARD_SUGUM_READ;
END;
/
