CREATE FUNCTION fnMakeACRPTM2
-- ---------------------------------------------------------------
 -- 함 수 명 : fnMakeACRPTM2
 -- 작 성 자 : 최용석
 -- 작성일자 : 2013-08-27
 -- ---------------------------------------------------------------
 -- 함수설명 : 월별 손익계산서(제조원가명세서)를 생성히가 위한 함수
 -- ---------------------------------------------------------------

(
  p_compcode    IN VARCHAR2 DEFAULT '' ,
  p_plantcode   IN VARCHAR2 DEFAULT '' ,
  p_rptdiv      IN VARCHAR2 DEFAULT '' ,
  p_closediv    IN VARCHAR2 DEFAULT '' ,
  ip_startym    IN VARCHAR2 DEFAULT '' ,
  p_endym       IN VARCHAR2 DEFAULT ''
)
RETURN FNMAKEACRPTM2_TABLE
AS
    p_startym    VARCHAR2(7) := ip_startym;
    p_basisyy    VARCHAR2(4);
    p_yyyy01     VARCHAR2(7);
    p_cashcode   VARCHAR2(20);
    p_strym      VARCHAR2(7);
    p_firstyn    VARCHAR2(1);
    -- 임시테이블의 calcseq의 최대값을 조회
    p_maxseq     NUMBER(10,0);
    p_curseq     NUMBER(10,0);
    -- 시작월의 손익계산서 생성
    p_yyyy01_p   VARCHAR2(7);
    -- 임시테이블의 calcseq의 최대값을 조회
    p_maxseq_p   NUMBER(10,0);
    p_curseq_p   NUMBER(10,0);
    v_temp       SYS_REFCURSOR;


    i NUMBER := 1;

    TABLEACRPTMA FNMAKEACRPTM2_TABLE := FNMAKEACRPTM2_TABLE();

    /*---------------------------------------------
    ▼▼▼▼  함수에서 DML 문장을 수행 하지 위한 트랜젝션 옵션 설정  ▼▼▼▼
    ---------------------------------------------*/
    PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN

    p_strym := p_startym ;
    p_firstyn := 'N' ;
    p_startym := TO_CHAR(add_months(to_date (p_startym || '-01','YYYY-MM-DD'),-1),'YYYY-MM');
   -- 종료월의 손익계산서 생성
   -- 기간 설정
    p_yyyy01 := SUBSTR(p_endym, 0, 4) || '-01' ;

    FOR  rec IN
    (
        SELECT  SUBSTR(curstrdate, 0, 7)  AS alias1
        FROM    ACSESSION
        WHERE   compcode = p_compcode
            AND cyear <= SUBSTR(p_endym, 0, 4)
    )
    LOOP
        p_yyyy01 := rec.alias1;
    END LOOP;

    IF SUBSTR(p_endym, -2) < SUBSTR(p_yyyy01, -2) THEN
        p_yyyy01 := TO_CHAR(ADD_MONTHS (TO_DATE ( p_endym || '-01','YYYY-MM-DD'), -12),'YYYY-') || SUBSTR(p_yyyy01, -2) ;
    ELSE
        p_yyyy01 := SUBSTR(p_endym, 1, 5) || SUBSTR(p_yyyy01, -2) ;
    END IF;

    p_cashcode := '11101010' ;

    FOR  rec IN
    (
        SELECT  value1
        FROM    SYSPARAMETERMANAGE
        WHERE   parametercode = 'acccashcode'
    )
    LOOP
        p_cashcode := rec.value1   ;
    END LOOP;

    IF p_strym = p_yyyy01 THEN
        p_firstyn := 'Y' ;
    END IF;

    -- 보고서 조회년도 설정
    FOR  rec IN
    (
        SELECT  MAX(rptyear)   AS alias1
        FROM    ACRPTM
        WHERE   compcode = p_compcode
            AND rptdiv = p_rptdiv
            AND rptyear <= SUBSTR(p_endym, 0, 4)
    )
    LOOP
        p_basisyy := rec.alias1   ;
    END LOOP;

    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_FNMAKEACRPTM2_ACORDDMM';
   -- 전표에서 월집계 임시파일을 생성
    INSERT INTO VGT.TT_FNMAKEACRPTM2_ACORDDMM
    SELECT  p_compcode compcode  ,
            p_plantcode plantcode  ,
            p_endym slipym  ,
            CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv  ,
            acccode ,
            SUM(totdebamt)  totdebamt  ,
            SUM(totcreamt)  totcreamt
    FROM    (
                SELECT  b.acccode ,
                        b.debamt totdebamt  ,
                        b.creamt totcreamt
                FROM    ACORDM A
                        JOIN ACORDD b
                            ON      A.compcode = b.compcode
                                AND A.slipinno = b.slipinno
                WHERE   A.compcode = p_compcode
                    AND A.plantcode LIKE p_plantcode
                    AND A.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR (ADD_MONTHS (TO_DATE (p_endym || '-01','YYYY-MM-DD'),1 ),'YYYYMM')
                    AND A.slipinstate = '4'
                    AND ( A.slipdiv NOT IN ( 'K','F' ) OR p_closediv = '1' AND A.slipdiv = 'K' OR p_closediv = '2' AND A.slipdiv = 'F' )
                UNION ALL
                SELECT  p_cashcode acccode  ,
                        b.creamt totdebamt  ,
                        b.debamt totcreamt
                FROM    ACORDM A
                        JOIN ACORDD b
                            ON      A.compcode = b.compcode
                                AND A.slipinno = b.slipinno
                                AND b.dcdiv IN ( '3','4' )
                WHERE   A.compcode = p_compcode
                    AND A.plantcode LIKE p_plantcode
                    AND A.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR (ADD_MONTHS (TO_DATE (p_endym || '-01','YYYY-MM-DD'),1 ),'YYYYMM')
                    AND A.slipinstate = '4'
                    AND ( A.slipdiv NOT IN ( 'K','F' ) OR p_closediv = '1' AND A.slipdiv = 'K' OR p_closediv = '2' AND A.slipdiv = 'F' )
                UNION ALL
                SELECT  acccode ,
                        bsdebamt totdebamt  ,
                        bscreamt totcreamt
                FROM    ACORDDMM
                WHERE   compcode = p_compcode
                    AND plantcode LIKE p_plantcode
                    AND slipym = p_yyyy01
                    AND ( p_closediv = '1' AND closediv IN ( '10','20' ) OR p_closediv = '2' AND closediv IN ( '10','30' ) )
            ) A
        GROUP BY acccode ;

   -- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_FNMAKEACRPTM2_ACRPTMA';

    INSERT INTO VGT.TT_FNMAKEACRPTM2_ACRPTMA
                ( seqline, acccode, accrname, acckname, lrdiv, prtyn, prtdiv, prtbold, sseqline, calcseq, calcdiv, objdatadiv, amt )
    SELECT  A.seqline ,
            MAX(A.acccode)  ,
            MAX(A.accrname)  ,
            MAX(A.acckname)  ,
            MAX(A.lrdiv)  ,
            MAX(A.prtyn)  ,
            MAX(A.prtdiv)  ,
            MAX(A.prtbold)  ,
            MAX(A.sseqline)  ,
            MAX(A.calcseq)  ,
            MAX(A.calcdiv)  ,
            MAX(A.objdatadiv)  ,
            NVL(SUM (
                        CASE    WHEN c.slipym = p_endym THEN
                                    CASE    WHEN A.objdatadiv IN ( 'D','F' ) THEN c.totdebamt
                                            WHEN A.objdatadiv IN ( 'C','E' ) THEN c.totcreamt
                                            WHEN A.objdatadiv = 'J' THEN
                                                CASE    WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt
                                                        ELSE c.totcreamt - c.totdebamt
                                                END
                                    END
                        END
                    ) , 0) amt
    FROM    ACRPTM A
            LEFT JOIN ACACCM b
                ON      NVL(A.acccode,' ') = NVL(b.acccode,' ')
            LEFT JOIN VGT.TT_FNMAKEACRPTM2_ACORDDMM c
                ON      A.compcode = c.compcode
                    AND c.plantcode LIKE p_plantcode
                    AND c.slipym = p_endym
                    AND ( p_closediv = '1' AND c.closediv IN ( '10','20' ) OR p_closediv = '2' AND c.closediv IN ( '10','30' ) )
                    AND NVL(A.acccode, ' ')  = NVL(c.acccode,' ')
    WHERE   A.compcode = p_compcode
        AND A.rptdiv = p_rptdiv
        AND A.rptyear = p_basisyy
        AND A.useyn = 'Y'
    GROUP BY A.seqline
    ORDER BY A.seqline;

   /*==========================================================================*/
   -- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
    MERGE INTO VGT.TT_FNMAKEACRPTM2_ACRPTMA tg
    USING     (SELECT a.lrdiv,
                       a.prtdiv,
                       a.calcdiv,
                       a.objdatadiv,
                       a.seqline,
                       a.acccode,
                       a.sseqline,
                       a.accrname,
                       a.acckname,
                       a.prtyn,
                       a.prtbold,
                       a.calcseq,
                       CASE WHEN A.objdatadiv = 'A' THEN b.amt ELSE A.amt - b.amt END AS amt
                FROM   VGT.TT_FNMAKEACRPTM2_ACRPTMA A
                       JOIN (SELECT   A.seqline,
                                      NVL(SUM(CASE WHEN c.slipym = p_yyyy01 THEN CASE WHEN A.objdatadiv = 'F' THEN c.bsdebamt WHEN A.objdatadiv = 'E' THEN c.bscreamt WHEN A.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) amt
                             FROM    ACRPTM A
                                      LEFT JOIN ACACCM b ON NVL(A.acccode, ' ') = NVL(b.acccode, ' ')
                                      LEFT JOIN ACORDDMM c
                                          ON A.compcode = c.compcode
                                             AND c.plantcode LIKE p_plantcode
                                             AND c.slipym = p_yyyy01
                                             AND (p_closediv = '1'
                                                  AND c.closediv IN ('10', '20')
                                                  OR p_closediv = '2'
                                                     AND c.closediv IN ('10', '30'))
                                             AND NVL(A.acccode, ' ') = NVL(c.acccode, ' ')
                             WHERE    A.compcode = p_compcode
                                      AND A.rptdiv = p_rptdiv
                                      AND A.rptyear = p_basisyy
                                      AND A.useyn = 'Y'
                                      AND A.objdatadiv IN ('A', 'E', 'F')
                             GROUP BY A.seqline) b
                           ON A.seqline = b.seqline) src
    ON       (NVL(tg.lrdiv, ' ') = NVL(src.lrdiv, ' ')
                AND NVL(tg.prtdiv, ' ') = NVL(src.prtdiv, ' ')
                AND NVL(tg.calcdiv, ' ') = NVL(src.calcdiv, ' ')
                AND NVL(tg.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
                AND NVL(tg.seqline, ' ') = NVL(src.seqline, ' ')
                AND NVL(tg.acccode, ' ') = NVL(src.acccode, ' ')
                AND NVL(tg.sseqline, ' ') = NVL(src.sseqline, ' ')
                AND NVL(tg.accrname, ' ') = NVL(src.accrname, ' ')
                AND NVL(tg.acckname, ' ') = NVL(src.acckname, ' ')
                AND NVL(tg.prtyn, ' ') = NVL(src.prtyn, ' ')
                AND NVL(tg.prtbold, ' ') = NVL(src.prtbold, ' ')
                AND NVL(tg.calcseq, 0) = NVL(src.calcseq, 0))
        WHEN MATCHED
        THEN
            UPDATE SET tg.amt = src.amt;

    /*===========================================================================*/
    p_curseq := 0 ;

    FOR  rec IN
    (
        SELECT  MAX(calcseq)   AS alias1
        FROM    VGT.TT_FNMAKEACRPTM2_ACRPTMA
    )
    LOOP
        p_maxseq := rec.alias1   ;
    END LOOP;

    -- 각 레벨별로 sum을하여 update
    WHILE p_curseq <= p_maxseq
    LOOP
      FOR SRC IN(
            SELECT a.seqline,
                   a.acccode,
                   a.accrname,
                   a.acckname,
                   a.lrdiv,
                   a.prtyn,
                   a.prtdiv,
                   a.prtbold,
                   a.sseqline,
                   a.calcseq,
                   a.calcdiv,
                   a.objdatadiv,
                   a.amt + b.amt amt
            FROM   VGT.TT_FNMAKEACRPTM2_ACRPTMA A
                   JOIN (SELECT   sseqline,
                                  SUM(CASE WHEN calcdiv = '+' THEN amt ELSE -amt END) amt
                         FROM    VGT.TT_FNMAKEACRPTM2_ACRPTMA
                         WHERE    calcseq = p_curseq
                                  AND TRIM(sseqline) IS NOT NULL
                         GROUP BY sseqline) b
                       ON A.seqline = b.sseqline
        )
        LOOP
            UPDATE VGT.TT_FNMAKEACRPTM2_ACRPTMA a
            SET    a.amt = src.amt
            WHERE  NVL(a.seqline, ' ') = NVL(src.seqline, ' ')
                   AND NVL(a.acccode, ' ') = NVL(src.acccode, ' ')
                   AND NVL(a.accrname, ' ') = NVL(src.accrname, ' ')
                   AND NVL(a.acckname, ' ') = NVL(src.acckname, ' ')
                   AND NVL(a.lrdiv, ' ') = NVL(src.lrdiv, ' ')
                   AND NVL(a.prtyn, ' ') = NVL(src.prtyn, ' ')
                   AND NVL(a.prtdiv, ' ') = NVL(src.prtdiv, ' ')
                   AND NVL(a.prtbold, ' ') = NVL(src.prtbold, ' ')
                   AND NVL(a.sseqline, ' ') = NVL(src.sseqline, ' ')
                   AND NVL(a.calcseq, 0) = NVL(src.calcseq, 0)
                   AND NVL(a.calcdiv, ' ') = NVL(src.calcdiv, ' ')
                   AND NVL(a.objdatadiv, ' ') = NVL(src.objdatadiv, ' ');
        END LOOP;

         p_curseq := p_curseq + 1 ;
    END LOOP;


    -- 시작월의 손익계산서 생성

    -- 기간 설정
    p_yyyy01_p := SUBSTR(p_startym, 1, 4) || '-01' ;

    FOR  rec IN
    (
        SELECT  SUBSTR(curstrdate, 1, 7)  AS alias1
        FROM    ACSESSION
        WHERE   compcode = p_compcode
            AND cyear <= SUBSTR(p_startym, 1, 4)
    )
    LOOP
        p_yyyy01_p := rec.alias1   ;
    END LOOP;

    IF SUBSTR(p_startym, -2) < SUBSTR(p_yyyy01_p, -2) THEN
        p_yyyy01_p := TO_CHAR(add_months (to_date(p_startym || '-01','YYYY-MM-DD'), -12 ),'YYYY-') || SUBSTR(p_yyyy01_p, -2) ;
    ELSE
        p_yyyy01_p := SUBSTR(p_startym, 1, 5) || SUBSTR(p_yyyy01_p, -2) ;
    END IF;

    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_FNMAKEACRPTM2_ACORDDMMP';
   -- 전표에서 월집계 임시파일을 생성
    INSERT INTO VGT.TT_FNMAKEACRPTM2_ACORDDMMP
    SELECT  p_compcode compcode  ,
            p_plantcode plantcode  ,
            p_startym slipym  ,
            CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv  ,
            acccode ,
            SUM(totdebamt)  totdebamt  ,
            SUM(totcreamt)  totcreamt
    FROM(
            SELECT  b.acccode ,
                    b.debamt totdebamt  ,
                    b.creamt totcreamt
            FROM    ACORDM A
                    JOIN ACORDD b
                        ON      A.compcode = b.compcode
                            AND A.slipinno = b.slipinno
            WHERE   A.compcode = p_compcode
                AND A.plantcode LIKE p_plantcode
                AND A.slipno BETWEEN REPLACE(p_yyyy01_p, '-', '') AND  TO_CHAR(ADD_MONTHS (TO_DATE(p_startym || '-01','YYYY-MM-DD'),1 ),'YYYYMM')
                AND A.slipinstate = '4'
                AND ( A.slipdiv NOT IN ( 'K','F' ) OR p_closediv = '1' AND A.slipdiv = 'K' OR p_closediv = '2' AND A.slipdiv = 'F' )
            UNION ALL
            SELECT  p_cashcode acccode  ,
                    b.creamt totdebamt  ,
                    b.debamt totcreamt
            FROM    ACORDM A
                    JOIN ACORDD b
                        ON      A.compcode = b.compcode
                            AND A.slipinno = b.slipinno
                            AND b.dcdiv IN ( '3','4' )
            WHERE   A.compcode = p_compcode
                AND A.plantcode LIKE p_plantcode
                AND A.slipno BETWEEN REPLACE(p_yyyy01_p, '-', '') AND TO_CHAR(ADD_MONTHS (TO_DATE(p_startym || '-01','YYYY-MM-DD'),1 ),'YYYYMM')
                AND A.slipinstate = '4'
                AND ( A.slipdiv NOT IN ( 'K','F' ) OR p_closediv = '1' AND A.slipdiv = 'K' OR p_closediv = '2' AND A.slipdiv = 'F' )
            UNION ALL
            SELECT  acccode ,
                    bsdebamt totdebamt  ,
                    bscreamt totcreamt
            FROM    ACORDDMM
            WHERE   compcode = p_compcode
                AND plantcode LIKE p_plantcode
                AND slipym = p_yyyy01_p
                AND ( p_closediv = '1' AND closediv IN ( '10','20' ) OR p_closediv = '2' AND closediv IN ( '10','30' ) )
        ) A
    WHERE  p_firstyn = 'N'
    GROUP BY acccode ;

    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_FNMAKEACRPTM2_ACRPTMAP';
    -- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
    INSERT INTO  VGT.TT_FNMAKEACRPTM2_ACRPTMAP
                ( seqline, acccode, accrname, acckname, lrdiv, prtyn, prtdiv, sseqline, calcseq, calcdiv, objdatadiv, amt )
    SELECT  A.seqline ,
            MAX(A.acccode)  ,
            MAX(A.accrname)  ,
            MAX(A.acckname)  ,
            MAX(A.lrdiv)  ,
            MAX(A.prtyn)  ,
            MAX(A.prtdiv)  ,
            MAX(A.sseqline)  ,
            MAX(A.calcseq)  ,
            MAX(A.calcdiv)  ,
            MAX(A.objdatadiv)  ,
            NVL(
                    SUM (   CASE
                                WHEN c.slipym = p_startym THEN
                                    CASE
                                        WHEN A.objdatadiv IN ( 'D','F' ) THEN c.totdebamt
                                        WHEN A.objdatadiv IN ( 'C','E' ) THEN c.totcreamt
                                        WHEN A.objdatadiv = 'J' THEN
                                            CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt
                                                 ELSE c.totcreamt - c.totdebamt
                                            END
                                    END
                            END) , 0
                ) amt
    FROM    ACRPTM A
            LEFT JOIN ACACCM b   ON NVL(A.acccode,' ') = NVL(b.acccode,' ')
            LEFT JOIN VGT.TT_FNMAKEACRPTM2_ACORDDMMP c
                ON      A.compcode = c.compcode
                    AND c.plantcode LIKE p_plantcode
                    AND c.slipym = p_startym
                    AND ( p_closediv = '1' AND c.closediv IN ( '10','20' ) OR p_closediv = '2' AND c.closediv IN ( '10','30' ) )
                    AND NVL(A.acccode,' ') = NVL(c.acccode,' ')
    WHERE   A.compcode = p_compcode
        AND A.rptdiv = p_rptdiv
        AND A.rptyear = p_basisyy
        AND A.useyn = 'Y'
        AND p_firstyn = 'N'
    GROUP BY A.seqline
    ORDER BY A.seqline;



   -- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
    MERGE INTO VGT.TT_FNMAKEACRPTM2_ACRPTMAP TG
    USING     (SELECT a.lrdiv,
                       a.prtdiv,
                       a.calcdiv,
                       a.objdatadiv,
                       a.seqline,
                       a.acccode,
                       a.sseqline,
                       a.accrname,
                       a.acckname,
                       a.prtyn,
                       a.calcseq,
                       CASE WHEN A.objdatadiv = 'A' THEN b.amt ELSE A.amt - b.amt END AS amt
                FROM   VGT.TT_FNMAKEACRPTM2_ACRPTMAP A
                       JOIN (SELECT   A.seqline,
                                      NVL(SUM(CASE WHEN c.slipym = p_yyyy01_p THEN CASE WHEN A.objdatadiv = 'F' THEN c.bsdebamt WHEN A.objdatadiv = 'E' THEN c.bscreamt WHEN A.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) amt
                             FROM    ACRPTM A
                                      LEFT JOIN ACACCM b ON NVL(A.acccode, ' ') = NVL(b.acccode, ' ')
                                      LEFT JOIN ACORDDMM c
                                          ON A.compcode = c.compcode
                                             AND c.plantcode LIKE p_plantcode
                                             AND c.slipym = p_yyyy01_p
                                             AND (p_closediv = '1'
                                                  AND c.closediv IN ('10', '20')
                                                  OR p_closediv = '2'
                                                     AND c.closediv IN ('10', '30'))
                                             AND NVL(A.acccode, ' ') = NVL(c.acccode, ' ')
                             WHERE    A.compcode = p_compcode
                                      AND A.rptdiv = p_rptdiv
                                      AND A.rptyear = p_basisyy
                                      AND A.useyn = 'Y'
                                      AND A.objdatadiv IN ('A', 'E', 'F')
                             GROUP BY A.seqline) b
                           ON A.seqline = b.seqline
                WHERE  p_firstyn = 'N') src
    ON       (NVL(tg.lrdiv, ' ') = NVL(src.lrdiv, ' ')
                AND NVL(tg.prtdiv, ' ') = NVL(src.prtdiv, ' ')
                AND NVL(tg.calcdiv, ' ') = NVL(src.calcdiv, ' ')
                AND NVL(tg.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
                AND NVL(tg.seqline, ' ') = NVL(src.seqline, ' ')
                AND NVL(tg.acccode, ' ') = NVL(src.acccode, ' ')
                AND NVL(tg.sseqline, ' ') = NVL(src.sseqline, ' ')
                AND NVL(tg.accrname, ' ') = NVL(src.accrname, ' ')
                AND NVL(tg.acckname, ' ') = NVL(src.acckname, ' ')
                AND NVL(tg.prtyn, ' ') = NVL(src.prtyn, ' ')
                AND NVL(tg.calcseq, 0) = NVL(src.calcseq, 0))
    WHEN MATCHED
    THEN
        UPDATE SET TG.amt = src.amt;



    p_curseq_p := 0 ;

    FOR  rec IN
    (
        SELECT  MAX(calcseq)   AS alias1
        FROM    VGT.TT_FNMAKEACRPTM2_ACRPTMAP
    )
    LOOP
        p_maxseq_p := rec.alias1   ;
    END LOOP;

   -- 각 레벨별로 sum을하여 update
    WHILE p_curseq_p <= p_maxseq_p
    LOOP
      FOR SRC IN(
            SELECT a.lrdiv,
                   a.prtdiv,
                   a.calcdiv,
                   a.objdatadiv,
                   a.seqline,
                   a.acccode,
                   a.sseqline,
                   a.accrname,
                   a.acckname,
                   a.prtyn,
                   a.calcseq,
                   NVL(a.amt, 0) + NVL(b.amt, 0) amt
            FROM   VGT.TT_FNMAKEACRPTM2_ACRPTMAP A
                   JOIN (SELECT   sseqline,
                                  SUM(CASE WHEN calcdiv = '+' THEN amt ELSE -amt END) amt
                         FROM    VGT.TT_FNMAKEACRPTM2_ACRPTMAP
                         WHERE    calcseq = p_curseq_p
                                  AND TRIM(sseqline) IS NOT NULL
                         GROUP BY sseqline) b
                       ON A.seqline = b.sseqline
        )
        LOOP
            UPDATE VGT.TT_FNMAKEACRPTM2_ACRPTMAP TG
            SET    TG.amt = src.amt
            WHERE  NVL(tg.lrdiv, ' ') = NVL(src.lrdiv, ' ')
                   AND NVL(tg.prtdiv, ' ') = NVL(src.prtdiv, ' ')
                   AND NVL(tg.calcdiv, ' ') = NVL(src.calcdiv, ' ')
                   AND NVL(tg.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
                   AND NVL(tg.seqline, ' ') = NVL(src.seqline, ' ')
                   AND NVL(tg.acccode, ' ') = NVL(src.acccode, ' ')
                   AND NVL(tg.sseqline, ' ') = NVL(src.sseqline, ' ')
                   AND NVL(tg.accrname, ' ') = NVL(src.accrname, ' ')
                   AND NVL(tg.acckname, ' ') = NVL(src.acckname, ' ')
                   AND NVL(tg.prtyn, ' ') = NVL(src.prtyn, ' ')
                   AND NVL(tg.calcseq, 0) = NVL(src.calcseq, 0);
        END LOOP;

        p_curseq_p := p_curseq_p + 1 ;

    END LOOP;

    -- 종료월에서 시작월자료를 감함
    MERGE INTO VGT.TT_FNMAKEACRPTM2_ACRPTMA TG
    USING     (SELECT a.lrdiv,
                       a.prtdiv,
                       a.calcdiv,
                       a.objdatadiv,
                       a.seqline,
                       a.acccode,
                       a.sseqline,
                       a.accrname,
                       a.acckname,
                       a.prtyn,
                       a.prtbold,
                       a.calcseq,
                       NULLIF(NVL(A.amt, 0) - NVL(c.amt, 0), 0) AS amt
                FROM   VGT.TT_FNMAKEACRPTM2_ACRPTMA A
                       JOIN ACRPTM b
                           ON b.compcode = p_compcode
                              AND b.rptdiv = p_rptdiv
                              AND b.rptyear = p_basisyy
                              AND A.seqline = b.seqline
                       LEFT JOIN VGT.TT_FNMAKEACRPTM2_ACRPTMAP c ON b.seqline = c.seqline
                       LEFT JOIN ACRPTM D
                           ON D.compcode = p_compcode
                              AND D.rptdiv = p_rptdiv
                              AND D.rptyear = p_basisyy
                              AND NVL(b.remark, ' ') = NVL(D.seqline, ' ')
                WHERE  TRIM(D.seqline) IS NULL) src
    ON       (NVL(tg.lrdiv, ' ') = NVL(src.lrdiv, ' ')
                AND NVL(tg.prtdiv, ' ') = NVL(src.prtdiv, ' ')
                AND NVL(tg.calcdiv, ' ') = NVL(src.calcdiv, ' ')
                AND NVL(tg.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
                AND NVL(tg.seqline, ' ') = NVL(src.seqline, ' ')
                AND NVL(tg.acccode, ' ') = NVL(src.acccode, ' ')
                AND NVL(tg.sseqline, ' ') = NVL(src.sseqline, ' ')
                AND NVL(tg.accrname, ' ') = NVL(src.accrname, ' ')
                AND NVL(tg.acckname, ' ') = NVL(src.acckname, ' ')
                AND NVL(tg.prtyn, ' ') = NVL(src.prtyn, ' ')
                AND NVL(tg.prtbold, ' ') = NVL(src.prtbold, ' ')
                AND NVL(tg.calcseq, 0) = NVL(src.calcseq, 0))
    WHEN MATCHED
    THEN
        UPDATE SET TG.amt = src.amt;

   -- 시작월의 기말재고를 종료월의 기초재고로 설정
    MERGE INTO VGT.TT_FNMAKEACRPTM2_ACRPTMA TG
    USING     (SELECT a.lrdiv,
                       a.prtdiv,
                       a.calcdiv,
                       a.objdatadiv,
                       a.seqline,
                       a.acccode,
                       a.sseqline,
                       a.accrname,
                       a.acckname,
                       a.prtyn,
                       a.prtbold,
                       a.calcseq,
                       c.amt
                FROM   VGT.TT_FNMAKEACRPTM2_ACRPTMA A
                       JOIN ACRPTM b
                           ON b.compcode = p_compcode
                              AND b.rptdiv = p_rptdiv
                              AND b.rptyear = p_basisyy
                              AND A.seqline = b.seqline
                              AND NVL(b.seqline, ' ') <> NVL(b.remark, ' ')
                       JOIN VGT.TT_FNMAKEACRPTM2_ACRPTMAP c ON NVL(b.remark, ' ') = NVL(c.seqline, ' ')) src
    ON       (NVL(tg.lrdiv, ' ') = NVL(src.lrdiv, ' ')
                AND NVL(tg.prtdiv, ' ') = NVL(src.prtdiv, ' ')
                AND NVL(tg.calcdiv, ' ') = NVL(src.calcdiv, ' ')
                AND NVL(tg.objdatadiv, ' ') = NVL(src.objdatadiv, ' ')
                AND NVL(tg.seqline, ' ') = NVL(src.seqline, ' ')
                AND NVL(tg.acccode, ' ') = NVL(src.acccode, ' ')
                AND NVL(tg.sseqline, ' ') = NVL(src.sseqline, ' ')
                AND NVL(tg.accrname, ' ') = NVL(src.accrname, ' ')
                AND NVL(tg.acckname, ' ') = NVL(src.acckname, ' ')
                AND NVL(tg.prtyn, ' ') = NVL(src.prtyn, ' ')
                AND NVL(tg.prtbold, ' ') = NVL(src.prtbold, ' ')
                AND NVL(tg.calcseq, 0) = NVL(src.calcseq, 0))
    WHEN MATCHED
    THEN
        UPDATE SET TG.amt = src.amt;

    FOR rec IN
    (
        SELECT  seqline, acccode, accrname, acckname,
                lrdiv, prtyn, prtdiv, prtbold,
                sseqline, calcseq,calcdiv, objdatadiv,  amt
        FROM    VGT.TT_FNMAKEACRPTM2_ACRPTMA

    )
    LOOP
        TABLEACRPTMA.EXTEND;

        TABLEACRPTMA (i)  := FNMAKEACRPTM2_VARIABLE (     REC.SEQLINE ,
                                                          REC.ACCCODE  ,
                                                          REC.ACCRNAME  ,
                                                          REC.ACCKNAME ,
                                                          REC.LRDIV,
                                                          REC.PRTYN ,
                                                          REC.PRTDIV ,
                                                          REC.PRTBOLD ,
                                                          REC.SSEQLINE ,
                                                          REC.CALCSEQ,
                                                          REC.CALCDIV,
                                                          REC.OBJDATADIV,
                                                          REC.AMT
                                                      );
        i := i+1;
    END LOOP;

    COMMIT;
    RETURN TABLEACRPTMA;

END;
/
