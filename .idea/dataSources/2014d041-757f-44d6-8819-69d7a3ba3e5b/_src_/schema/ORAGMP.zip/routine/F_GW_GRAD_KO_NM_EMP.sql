CREATE FUNCTION F_GW_GRAD_KO_NM_EMP (
        I_EMP_NO IN VARCHAR2
)
RETURN VARCHAR2 IS

        V_RETURN VARCHAR2(10);  --결과값 전달
        V_CNT NUMBER;  --결과값 전달
        V_GRAD_CD VARCHAR2(5);  --직급코드

BEGIN
       /*-------------------------------------------------------------------
       DESCRIPTION
       CHOE 20171214

       그룹웨어에서 사원번호로 직급명을 알고자 할때 전달한다.
       EX) 8급사원A 이하는 모두 사원으로 표기 하도록 한다. - 안상윤 요청(최동재 사장님 지시) 2016.01.19
       2016.03.03 윤홍주 요청 시스템 트리에 표기시 사원으로 변경
       -------------------------------------------------------------------*/

        V_RETURN := '';  --초기값
        V_CNT := 0;
        SELECT COUNT(*)
        INTO V_CNT
        FROM ORAGMP.CMCOMMONM
        WHERE CMMCODE = 'PS01'
        AND DIVCODE = (
                SELECT CLASSDIV
                FROM  ORAGMP.CMEMPM TB
                WHERE EMPCODE = I_EMP_NO
        )
        ;

        IF V_CNT = 1 THEN
                V_GRAD_CD := '';
                SELECT DIVCODE
                INTO V_GRAD_CD
                FROM ORAGMP.CMCOMMONM
                WHERE CMMCODE = 'PS01'
                AND DIVCODE = (
                        SELECT CLASSDIV
                        FROM  ORAGMP.CMEMPM TB
                        WHERE EMPCODE = I_EMP_NO
                )
                ;

                IF V_GRAD_CD = '00530' OR
                    V_GRAD_CD = '00531'  OR
                    V_GRAD_CD = '00532'  OR
                    V_GRAD_CD = '00533'  OR
                    V_GRAD_CD = '00534'  OR
                    V_GRAD_CD = '00535'  OR
                    V_GRAD_CD = '00536'  THEN
                        V_RETURN := '사원';
                ELSE
                        SELECT DIVNAME
                        INTO V_RETURN
                        FROM ORAGMP.CMCOMMONM
                        WHERE CMMCODE = 'PS01'
                        ;

                END IF;
        ELSE
                V_RETURN := '직급명오류';
        END IF;

        RETURN(V_RETURN);
EXCEPTION
        WHEN NO_DATA_FOUND THEN
                V_RETURN := '';
                RETURN V_RETURN;
        WHEN OTHERS THEN
                V_RETURN := '';
                RETURN V_RETURN;
END F_GW_GRAD_KO_NM_EMP;
/
