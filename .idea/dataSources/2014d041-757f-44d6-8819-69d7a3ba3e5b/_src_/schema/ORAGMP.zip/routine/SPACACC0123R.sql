CREATE PROCEDURE spACacc0123R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0123R
 -- 작 성 자         : 최용석
 -- 작성일자         : 2012-07-12
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-20
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 관리항목원장(잔액)을 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '' ,
    p_acccode       IN VARCHAR2 DEFAULT '' ,
    p_dcdiv         IN VARCHAR2 DEFAULT '' ,
    p_startdt       IN VARCHAR2 DEFAULT '' ,
    p_enddt         IN VARCHAR2 DEFAULT '' ,
    p_mngclucode    IN VARCHAR2 DEFAULT '' ,
    p_mngcluval1    IN VARCHAR2 DEFAULT '' ,
    p_mngcluval2    IN VARCHAR2 DEFAULT '' ,
    p_outputdiv     IN VARCHAR2 DEFAULT '' ,
    p_downview      IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,

    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_odiv1 VARCHAR2(5);
    p_odiv2 VARCHAR2(5);

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);



    IF ( UPPER(p_div) = UPPER('S') ) THEN

        IF ( p_outputdiv = '1' ) THEN
            --K-GAAP
            p_odiv1 := '20' ;
            p_odiv2 := 'F' ;
        ELSIF ( p_outputdiv = '2' ) THEN
            --IFRS
            p_odiv1 := '30' ;
            p_odiv2 := 'K' ;
        END IF;


      OPEN  IO_CURSOR FOR
         SELECT a.acccode ,
                MAX(b.accname)  accname  ,
                p_mngclucode mngclucode  ,
                mngcluval ,
                MAX(a.mngcludec)  mngcludec  ,
                SUM(a.bsamt)  bsamt  ,
                SUM(a.debamt)  debamt  ,
                SUM(a.creamt)  creamt  ,
                CASE
                     WHEN p_dcdiv = '1' THEN SUM(a.bsamt)  + SUM(a.debamt)  - SUM(a.creamt)
                ELSE SUM(a.bsamt)  + SUM(a.creamt)  - SUM(a.debamt)
                   END fnamt
           FROM (
                  -- 월집계 해당년월 데이터 가져오기
                  SELECT a.acccode ,
                         a.mngcluval ,
                         a.mngcludec ,
                         CASE WHEN p_dcdiv = '1' THEN a.bsdebamt - a.bscreamt
                              ELSE a.bscreamt - a.bsdebamt
                         END bsamt ,--전기이월

                         0 debamt  ,
                         0 creamt
                  FROM ACORDSMM a
                   WHERE  a.compcode = p_compcode
                            AND a.plantcode LIKE p_plantcode
                            AND a.slipym = SUBSTR(p_startdt, 0, 7)
                            AND a.acccode IN ( SELECT acccode
                                               FROM (  SELECT  COALESCE(c.acccode, b.acccode, a.acccode) acccode
                                                        FROM    ACACCM a
                                                                LEFT JOIN ACACCM b ON ( a.acccode = b.acccode OR a.acccode = b.hacccode )
                                                                                      AND p_downview = 'Y'
                                                                LEFT JOIN ACACCM c ON a.acccode <> b.acccode
                                                                                      AND b.acccode = c.hacccode
                                                                                      AND p_downview = 'Y'
                                                        WHERE   a.acccode = p_acccode )  )

                            AND a.mngclucode = p_mngclucode
                            AND ( p_mngcluval1 IS NULL AND p_mngcluval2 IS NULL OR a.mngcluval BETWEEN p_mngcluval1 AND p_mngcluval2 )
                            AND ( a.closediv = '10' OR a.closediv = p_odiv1 )
                  UNION ALL

                  --조회 시작일 이전 날짜 데이터 가져오기
                  SELECT a.acccode ,
                         b.mngcluval ,
                         b.mngcludec ,
                         CASE
                              WHEN p_dcdiv = '1' THEN a.debamt - a.creamt
                         ELSE a.creamt - a.debamt
                            END bsamt ,--전기이월

                         0 debamt  ,
                         0 creamt
                  FROM ACORDD a
                         JOIN ACORDS b   ON a.compcode = b.compcode
                         AND a.slipinno = b.slipinno
                         AND a.slipinseq = b.slipinseq
                         AND b.mngclucode = p_mngclucode
                         AND ( p_mngcluval1 IS NULL AND p_mngcluval2 IS NULL OR b.mngcluval BETWEEN p_mngcluval1 AND p_mngcluval2 )
                         JOIN ACORDM c   ON a.compcode = c.compcode
                         AND a.slipinno = c.slipinno
                         AND c.slipdiv <> p_odiv2
                   WHERE  a.compcode = p_compcode
                            AND a.acccode IN ( SELECT acccode
                                               FROM (       SELECT  COALESCE(c.acccode, b.acccode, a.acccode) acccode
                                                            FROM    ACACCM a
                                                                    LEFT JOIN ACACCM b ON ( a.acccode = b.acccode OR a.acccode = b.hacccode )
                                                                                          AND p_downview = 'Y'
                                                                    LEFT JOIN ACACCM c ON a.acccode <> b.acccode
                                                                                          AND b.acccode = c.hacccode
                                                                                          AND p_downview = 'Y'
                                                            WHERE   a.acccode = p_acccode )  )

                            AND a.slipdate >= SUBSTR(p_startdt, 1, 7) || '-01'
                            AND a.slipdate < p_startdt
                            AND a.plantcode LIKE p_plantcode
                  UNION ALL

                  --조회시작일부터 종료일까지 데이터 가져오기
                  SELECT a.acccode ,
                         b.mngcluval ,
                         b.mngcludec ,
                         0 bsamt  ,
                         a.debamt ,
                         a.creamt
                  FROM ACORDD a
                         JOIN ACORDS b   ON a.compcode = b.compcode
                         AND a.slipinno = b.slipinno
                         AND a.slipinseq = b.slipinseq
                         AND b.mngclucode = p_mngclucode
                         AND ( p_mngcluval1 IS NULL AND p_mngcluval2 IS NULL OR b.mngcluval BETWEEN p_mngcluval1 AND p_mngcluval2 )
                         JOIN ACORDM c   ON a.compcode = c.compcode
                         AND a.slipinno = c.slipinno
                         AND c.slipdiv <> p_odiv2
                   WHERE  a.compcode = p_compcode
                            AND a.acccode IN ( SELECT acccode
                                               FROM (       SELECT  COALESCE(c.acccode, b.acccode, a.acccode) acccode
                                                            FROM    ACACCM a
                                                                    LEFT JOIN ACACCM b ON ( a.acccode = b.acccode OR a.acccode = b.hacccode )
                                                                                          AND p_downview = 'Y'
                                                                    LEFT JOIN ACACCM c ON a.acccode <> b.acccode
                                                                                          AND b.acccode = c.hacccode
                                                                                          AND p_downview = 'Y'
                                                            WHERE   a.acccode = p_acccode )  )

                            AND a.slipdate BETWEEN p_startdt AND p_enddt
                            AND a.plantcode LIKE p_plantcode ) a
                  JOIN (    SELECT  COALESCE(c.acccode, b.acccode, a.acccode) acccode  ,
                                    COALESCE(c.accname, b.accname, a.accname) accname
                            FROM    ACACCM a
                                    LEFT JOIN ACACCM b ON ( a.acccode = b.acccode OR a.acccode = b.hacccode )
                                                          AND p_downview = 'Y'
                                    LEFT JOIN ACACCM c ON a.acccode <> b.acccode
                                                          AND b.acccode = c.hacccode
                                                          AND p_downview = 'Y'
                            WHERE   a.acccode = p_acccode ) b   ON a.acccode = b.acccode
            GROUP BY a.acccode,a.mngcluval

            HAVING SUM(a.bsamt)  <> 0 OR SUM(a.debamt)  <> 0 OR SUM(a.creamt)  <> 0
            ORDER BY a.acccode, a.mngcluval nulls first;

    ELSIF ( p_div = 'A1' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  b.mngclucode keyfield  ,
                    MAX(b.mngcluname)  displayfield
            FROM    ACACCM a
                    LEFT JOIN ACACCMNGM b   ON a.acccode = b.acccode
            WHERE   a.acccode = p_acccode
            GROUP BY b.mngclucode
            ORDER BY b.mngclucode ;

    ELSIF ( p_div = 'A2' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  a.mngclucode mngclucode  ,
                    a.mngcluname mngcluname  ,
                    a.mngcludiv mngcludiv  ,
                    c.divname mngcludivnm  ,
                    D.filter1 codeseek  ,
                    a.remark codermk
            FROM    ACMNGM a
                    LEFT JOIN CMCOMMONM c   ON a.mngcludiv = c.divcode
                                                AND c.cmmcode = 'AC12'
                    LEFT JOIN CMCOMMONM D   ON a.codehelp = D.divcode
                                                AND D.cmmcode = 'CMHL'
            WHERE   a.mngclucode = p_mngclucode ;

    ELSIF ( p_div = 'A3' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  acccode ,
                    dcdiv
            FROM    ACACCM
            WHERE   acccode = p_acccode ;

    ELSIF ( p_div = 'RMK' ) THEN

        -- 코드헬프 검색
        OPEN  IO_CURSOR FOR

            SELECT  NVL(codehelp, '') codehelp ,-- 코드헬프번호
                    NVL(remark, '') codermk -- 코드헬프비고
            FROM    ACMNGM
            WHERE   mngclucode = p_mngclucode ;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
