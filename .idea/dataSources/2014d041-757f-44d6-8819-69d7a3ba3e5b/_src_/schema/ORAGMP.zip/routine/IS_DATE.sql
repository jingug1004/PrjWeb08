CREATE FUNCTION        is_date(v_str_date IN varchar2, V_FORMAT IN VARCHAR2 DEFAULT 'YYYYMMDD') 

RETURN NUMBER 

IS   /* 데이터가 DATE 형인지 검사하는 함수임. 1 이 나오면 DATE 형임 */ 

     V_DATE DATE; 
     V_DATE_CHECK varchar2(8);      

BEGIN

  V_DATE_CHECK := replace(v_str_date,'-','');

  V_DATE := TO_DATE(V_DATE_CHECK, V_FORMAT);

  RETURN 1;    

EXCEPTION

  WHEN OTHERS THEN RETURN 0    ;

END;
/
