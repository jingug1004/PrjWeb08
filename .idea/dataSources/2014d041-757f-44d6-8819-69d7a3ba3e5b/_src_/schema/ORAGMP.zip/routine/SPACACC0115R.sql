CREATE PROCEDURE        spACacc0115R
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0115R
-- 수 정 자         : 최용석
-- 수정일자         : 2016-12-14
--수정자         : 최용석
-- 수정일         : 2017-02-22
-- ---------------------------------------------------------------
-- 프로시저 설명    : 계정별원장(잔액)을 조회하는 프로시저이다.	--전면수정
-- ---------------------------------------------------------------
(
    p_div in varchar2 default '' ,
    p_compcode in varchar2 default '' ,
    p_plantcode in varchar2 default '' ,
    p_strdate in varchar2 default '' ,
    p_enddate in varchar2 default '' ,
    p_stracccode in varchar2 default '' ,
    p_endacccode in varchar2 default '' ,
    p_outputdiv in number default 1 ,
    p_userid in varchar2 default '' ,
    p_reasondiv in varchar2 default '' ,
    p_reasontext in varchar2 default '' ,
    message out varchar2,
    IO_CURSOR out TYPES.DataSet
)
as
    p_cashcode varchar2(20);
    p_odiv1 varchar2(5);
    p_odiv2 varchar2(5);

begin

    message := '데이터 확인';

    DELETE from ATINFO;

    insert into ATINFO(USERID, REASONDIV, REASONTEXT)
    values (p_userid, p_reasondiv, p_reasontext);

    if p_outputdiv = '1'	--K-GAAP
    then
        p_odiv1 := '20';
        p_odiv2 := 'F';
    end if;

    if p_outputdiv = '2'	--IFRS
    then
        p_odiv1 := '30';
        p_odiv2 := 'K';
    end if;

    p_cashcode := '11101010';
    for rec IN
    (
        select  value1
        from    SYSPARAMETERMANAGE
        where   parametercode = 'acccashcode'
    )
    loop
        p_cashcode := rec.value1;
    end loop;

    if trim(p_div) = 'S'
    then
        open IO_CURSOR for
        select	 a.acccode
                ,max(b.accname) as accname
                ,sum(case when b.dcdiv = '1' then a.bsdebamt - a.bscreamt else a.bscreamt - a.bsdebamt end) as bsamt
                ,sum(a.debamt) as debamt
                ,sum(a.creamt) as creamt
                ,sum(case when b.dcdiv = '1' then a.bsdebamt + a.debamt - a.bscreamt - a.creamt else a.bscreamt + a.creamt - a.bsdebamt - a.debamt end) as fnamt
                ,p_plantcode as plantcode
                ,p_strdate as strdate
                ,p_enddate as enddate
                ,p_outputdiv as closediv
    
        from (
            -- 월집계 해당년월 데이터 가져오기
            select	 a.acccode
                    ,a.bsdebamt
                    ,a.bscreamt
                    ,0 as debamt
                    ,0 as creamt
            from	  ACORDDMM a
            where	  a.compcode = p_compcode
                    and a.plantcode like p_plantcode
                    and	a.slipym = substr(p_strdate,1,7)
                    and (a.closediv = '10' or a.closediv = p_odiv1)
                    and a.acccode between nvl(p_stracccode,' ') and nvl(p_endacccode,'zzzzzzzz')
                    and a.bsdebamt <> a.bscreamt
      
            union all
      
            -- 기간에 해당하는 데이터 가져오기
            select	 a.acccode
                    ,case when a.slipdate < p_strdate then debamt else 0 end as bsdebamt
                    ,case when a.slipdate < p_strdate then creamt else 0 end as bscreamt
                    ,case when p_strdate <= a.slipdate then debamt else 0 end as debamt
                    ,case when p_strdate <= a.slipdate then creamt else 0 end as creamt
            from	  ACORDD a
                    join ACORDM b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
                        and b.slipdiv <> p_odiv2
            where	  a.compcode = p_compcode
                    and a.plantcode like p_plantcode
                    and a.acccode between nvl(p_stracccode,' ') and nvl(p_endacccode,'zzzzzzzz')
                    and a.slipdate between substr(p_strdate,1,7)||'-01' and p_enddate
      
            union all
      
            -- 기간에 해당하는 현금데이터 가져오기
            select	 p_cashcode as acccode
                    ,case when a.slipdate < p_strdate then creamt else 0 end as bsdebamt
                    ,case when a.slipdate < p_strdate then debamt else 0 end as bscreamt
                    ,case when p_strdate <= a.slipdate then creamt else 0 end as debamt
                    ,case when p_strdate <= a.slipdate then debamt else 0 end as creamt
            from	  ACORDD a
                    join ACORDM b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
                        and b.slipdiv <> p_odiv2
            where	  a.compcode = p_compcode
                    and a.plantcode like p_plantcode
                    and p_cashcode between nvl(p_stracccode,' ') and nvl(p_endacccode,'zzzzzzzz')
                    and a.slipdate between substr(p_strdate,1,7)||'-01' and p_enddate
                    and a.dcdiv in ('3', '4')
        ) a
                join ACACCM b
                    on a.acccode = b.acccode

        group by a.acccode
    
        order by a.acccode;
    end if;

    if IO_CURSOR is null
    then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;
end;
/
