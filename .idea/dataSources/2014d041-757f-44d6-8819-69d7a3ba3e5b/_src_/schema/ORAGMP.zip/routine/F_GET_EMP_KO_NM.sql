CREATE FUNCTION F_GET_EMP_KO_NM(
        I_EMP_NO IN STRING
)
        RETURN VARCHAR2 IS
        V_EMPNAME ORAGMP.CMEMPM.EMPNAME%TYPE;
        -- 부서명칭 가져오기 ( 한글 )
BEGIN
        SELECT EMPNAME
        INTO V_EMPNAME
        FROM ORAGMP.CMEMPM EMP
        WHERE EMPCODE = I_EMP_NO;

        IF SQLCODE <> 0 THEN
                V_EMPNAME := ' ';
        END IF;

        RETURN V_EMPNAME;
EXCEPTION
        WHEN NO_DATA_FOUND THEN

        IF V_EMPNAME IS NULL THEN
                V_EMPNAME := ' ';
        END IF;

        RETURN V_EMPNAME;
END;
/
