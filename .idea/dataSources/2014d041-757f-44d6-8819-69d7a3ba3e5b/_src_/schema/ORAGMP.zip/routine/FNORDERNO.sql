CREATE FUNCTION        fnOrderNo( 
    -- ---------------------------------------------------------------
    -- 함 수 명   : fnOrderNo
    -- 작 성 자         : 조성희
    -- 작성일자         : 2008-11-05
    -- 수정일자       :   노영래
    -- E-mail       :   0rae0926@gmail.com
    -- 수정일자       :   2016-01-17
    -- 주석부분 테이블 없음
    -- ---------------------------------------------------------------
    -- 함수설명   : --영업주문서 신규전표번호 : SLORDM
    --수금명세서 신규전표번호 : SLCOLM
    --배송전표   신규전표번호 : SLOUTM
    --인수인계등록 등록번호   : SLCUSTTRANE
    --인수인계등록 확정번호   : SLCUSTTRANM
    -- ---------------------------------------------------------------
    --  select dbo.fnorderno('SLCUSTTRANE', '1000', '2009-01')


    p_gb 			IN 	VARCHAR2 	DEFAULT '', 
    p_plantcode 	IN 	VARCHAR2 	DEFAULT '', 
    p_setdate 		IN 	VARCHAR2 	DEFAULT ''
)
	RETURN VARCHAR2
AS
	p_tostring	  VARCHAR2(20);
BEGIN
	IF (p_gb = 'SLORDM')
	THEN
		FOR rec IN (SELECT SUBSTR('0000' || (NVL(MAX(orderseq), 0) + 1), -4, 4) AS alias1
					FROM   SLORDM a
					WHERE  orderdate = p_setdate)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'SLCOLM')
	THEN
		FOR rec IN (SELECT SUBSTR('0000' || (NVL(MAX(colseq), 0) + 1), -4, 4) AS alias1
					FROM   SLCOLM a
					WHERE  coldate = p_setdate)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
--	ELSIF (p_gb = 'SLCUSTTRANE')
--	THEN
--		FOR rec IN (SELECT 'E' || REPLACE(p_setdate, '-', '') || SUBSTR('000' || (NVL(TO_NUMBER(SUBSTR(MAX(entryno), 8, 3)), 0) + 1), -3, 3) AS alias1
--					FROM   SLCUSTTRANSEM a
--					WHERE  SUBSTR(entrydate, 1, 7) = p_setdate)
--		LOOP
--			p_tostring := rec.alias1;
--		END LOOP;
	ELSIF (p_gb = 'SLTRANSMNGM')
	THEN
		DECLARE
			--월단위로 인수인계 번호를 관리한다 _ 2013-11-15:이세민
			p_sdt	 VARCHAR2(10);
			p_edt	 VARCHAR2(10);
		--인수인계 등록번호 생성 추가(2013-11-13:이세민)
		BEGIN
			p_sdt := SUBSTR(p_setdate, 1, 7) || '-01';
			p_edt := TO_CHAR(LAST_DAY(TO_DATE(p_sdt,'YYYY-MM-DD')),'YYYY-MM-DD');

			FOR rec IN (SELECT ('E' || SUBSTR(REPLACE(p_setdate, '-', ''), 1, 6) || SUBSTR('000' || (NVL(TO_NUMBER(SUBSTR(MAX(entryno), 8, 3)), 0) + 1), -3, 3)) AS alias1
						FROM   SLTRANSMNGM a
						WHERE  a.entrydate BETWEEN p_sdt AND p_edt)
			LOOP
				p_tostring := rec.alias1;
			END LOOP;
		END;
--	ELSIF (p_gb = 'SLCUSTTRANM')
--	THEN
--		FOR rec IN (SELECT 'P' || REPLACE(p_setdate, '-', '') || SUBSTR('000' || (NVL(TO_NUMBER(SUBSTR(MAX(fixno), 8, 3)), 0) + 1), -3, 3) AS alias1
--					FROM   SLCUSTTRANSM a
--					WHERE  SUBSTR(movedate, 1, 7) = p_setdate)
--		LOOP
--			p_tostring := rec.alias1;
--		END LOOP;
	ELSIF (p_gb = 'chasoo')
	THEN
		--확정차수(본사외)
		FOR rec IN (SELECT TO_CHAR(NVL(fixseq, 0) + 1) AS alias1
					FROM   (SELECT MAX(fixseq) fixseq
							FROM   vnOrders
							WHERE  fixdate = p_setdate
								   AND warehouse IN (SELECT warehouse
													 FROM	SLSTOREHOUSEM
													 WHERE	workdiv = p_plantcode)) a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'chasoo2')
	THEN
		--확정차수(본사 - 서울)
		FOR rec IN (SELECT TO_CHAR(NVL(fixseq, 0) + 1) AS alias1
					FROM   (SELECT MAX(fixseq) fixseq
							FROM   vnOrders
							WHERE  fixdate = p_setdate
								   AND warehouse IN (SELECT warehouse
													 FROM	SLSTOREHOUSEM
													 WHERE	workdiv = p_plantcode)) a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'pchasoo')
	THEN
		--picking 차수(본사외)
		FOR rec IN (SELECT TO_CHAR(NVL(chasoo, 0) + 1) AS alias1
					FROM   (SELECT MAX(chasoo) chasoo
							FROM   SLITEMTAKINGOUT
							WHERE  outdate = p_setdate
								   AND warehouse IN (SELECT warehouse
													 FROM	SLSTOREHOUSEM
													 WHERE	workdiv = p_plantcode)) a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'pchasoo2')
	THEN
		--picking 차수(본사 - 서울)
		FOR rec IN (SELECT TO_CHAR(NVL(chasoo, 0) + 1) AS alias1
					FROM   (SELECT MAX(chasoo) chasoo
							FROM   SLITEMTAKINGOUT
							WHERE  outdate = p_setdate
								   AND warehouse IN (SELECT warehouse
													 FROM	SLSTOREHOUSEM
													 WHERE	workdiv = p_plantcode)) a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'inputno')
	THEN
		FOR rec IN (SELECT DECODE(requestno, NULL, 'I' || REPLACE(p_setdate, '-', '') || '0001', SUBSTR(requestno, 0, 9) || SUBSTR('0000' || (TO_NUMBER(SUBSTR(requestno, -4, 4)) + 1), -4, 4)) AS alias1
					FROM   (SELECT MAX(inputno) requestno
							FROM   SLINORDERM
							WHERE --inputdate = @setdate
								 SUBSTR(inputno, 0, 9) LIKE 'I' || REPLACE(p_setdate, '-', '') || '%'
								   AND SUBSTR(inputno, 2, 1) != 'I') a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'outputno')
	THEN
		FOR rec IN (SELECT DECODE(requestno, NULL, 'O' || REPLACE(p_setdate, '-', '') || '0001', SUBSTR(requestno, 0, 9) || SUBSTR('0000' || (TO_NUMBER(SUBSTR(requestno, -4, 4)) + 1), -4, 4)) AS alias1
					FROM   (SELECT MAX(outputno) requestno
							FROM   SLOUTORDERM
							WHERE  outputdate = p_setdate
								   AND SUBSTR(outputno, 2, 1) != 'O') a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'inno')
	THEN
		FOR rec IN (SELECT DECODE(requestno, NULL, 'II' || REPLACE(p_setdate, '-', '') || '0001', SUBSTR(requestno, 0, 10) || SUBSTR('0000' || (TO_NUMBER(SUBSTR(requestno, -4, 4)) + 1), -4, 4)) AS alias1
					FROM   (SELECT MAX(inputno) requestno
							FROM   SLITEMWAREHOUSING
							WHERE  indate = p_setdate
								   AND inputno LIKE 'II%') a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'outno')
	THEN
		FOR rec IN (SELECT DECODE(requestno, NULL, 'OO' || REPLACE(p_setdate, '-', '') || '0001', SUBSTR(requestno, 0, 10) || SUBSTR('0000' || (TO_NUMBER(SUBSTR(requestno, -4, 4)) + 1), -4, 4)) AS alias1
					FROM   (SELECT MAX(orderno) requestno
							FROM   SLITEMTAKINGOUTETC
							WHERE  outdate = p_setdate
								   AND orderno LIKE 'OO%') a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'inputseq')
	THEN
		FOR rec IN (SELECT TO_CHAR(NVL(requestno, 0) + 1) AS alias1
					FROM   (SELECT MAX(inseq) requestno
							FROM   SLITEMWAREHOUSING
							WHERE  indate = p_setdate) a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'outputseq')
	THEN
		FOR rec IN (SELECT TO_CHAR(NVL(requestno, 0) + 1) AS alias1
					FROM   (SELECT MAX(outseq) requestno
							FROM   SLITEMTAKINGOUT
							WHERE  outdate = p_setdate) a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
	ELSIF (p_gb = 'outseq')
	THEN
		FOR rec IN (SELECT TO_CHAR(NVL(requestno, 0) + 1) AS alias1
					FROM   (SELECT MAX(outseq) requestno
							FROM   SLITEMTAKINGOUTETC
							WHERE  outdate = p_setdate) a)
		LOOP
			p_tostring := rec.alias1;
		END LOOP;
    ELSIF (p_gb = 'SLORDM_BN')
    THEN
        FOR rec IN (
                     SELECT CASE WHEN COUNT(BNORDERNO) = 0 
                                 THEN TO_CHAR(TO_DATE(p_setdate, 'YYYY-MM-DD'), 'YYYYMMDD') || '0001'
                                 ELSE (TO_CHAR(TO_DATE(p_setdate, 'YYYY-MM-DD'), 'YYYYMMDD') || LPAD(SUBSTR(MAX(BNORDERNO), -4) + 1, 4, '0')) END AS alias1
                       FROM SLORDM
                      WHERE BNORDERNO LIKE TO_CHAR(TO_DATE(p_setdate, 'YYYY-MM-DD'), 'YYYYMMDD') || '%'
                   )
        LOOP
            p_tostring := rec.alias1;
        END LOOP; 
	END IF;

	RETURN (p_tostring);
EXCEPTION
	WHEN OTHERS
	THEN
		NULL;
END;
/
