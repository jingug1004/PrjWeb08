CREATE PROCEDURE spACacc0000PP(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0000PP
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-11-15
	-- 수정일자       :   노영래
	-- E-mail       :   0rae0926@gmail.com
	-- 수정일자       :   2016-12-13
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 영업손익반영내역 테이블 (SFORDEP)을 등록,수정,삭제하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_slipinno		IN	   VARCHAR2 DEFAULT '',
	p_slipinseq 	IN	   NUMBER   DEFAULT 0,
	p_sctdiv		IN	   VARCHAR2 DEFAULT '',
	p_seqno 		IN	   NUMBER   DEFAULT 0,
	p_sectorcode	IN	   VARCHAR2 DEFAULT '',
	p_applyper		IN	   FLOAT    DEFAULT 0,
	p_remark		IN	   VARCHAR2 DEFAULT '',
	p_iempcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		OUT    VARCHAR2,
    IO_CURSOR       OUT    TYPES.DataSet
)
AS
BEGIN
	MESSAGE := '데이터 확인';


    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	IF( UPPER(P_DIV) = 'I' ) THEN

        INSERT INTO SFORDEP(compcode,
							slipinno,
							slipinseq,
							sctdiv,
							seqno,
							sectorcode,
							applyper,
							remark,
							insertdt,
							iempcode)
			(SELECT p_compcode,
					p_slipinno,
					p_slipinseq,
					p_sctdiv,
					p_seqno,
					p_sectorcode,
					p_applyper,
					p_remark,
					SYSDATE,
					p_iempcode
			 FROM	DUAL) ;

	ELSIF( UPPER(P_DIV) = 'U' ) THEN

        UPDATE SFORDEP a
		SET    sectorcode = p_sectorcode
               , applyper = p_applyper
               , remark = p_remark
               , updatedt = SYSDATE
               , uempcode = p_iempcode
		WHERE  a.compcode = p_compcode
			   AND a.slipinno = p_slipinno
			   AND a.slipinseq = p_slipinseq
			   AND a.sctdiv = p_sctdiv
			   AND a.seqno = p_seqno ;

	ELSIF (UPPER(P_DIV) = 'D') THEN

        FOR REC IN (SELECT A.COMPCODE
                           , A.SLIPINNO
                           , A.SLIPINSEQ
                           , A.SCTDIV
                           , A.SEQNO
					FROM   SFORDEP a
					WHERE  a.compcode = p_compcode
						   AND a.slipinno = p_slipinno
						   AND a.slipinseq = p_slipinseq
						   AND a.sctdiv = p_sctdiv
						   AND a.seqno = p_seqno )
		LOOP
			DELETE FROM SFORDEP A
			WHERE		A.COMPCODE = REC.COMPCODE
						AND A.SLIPINNO = REC.SLIPINNO
						AND A.SLIPINSEQ = REC.SLIPINSEQ
						AND A.SCTDIV = REC.SCTDIV
						AND A.SEQNO = REC.SEQNO ;
		END LOOP;

	END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
