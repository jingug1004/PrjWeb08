CREATE PROCEDURE spACacc0020P
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACacc0020P
   -- 작 성 자         : 최용석
   -- 작성일자         : 2012-08-17
   -- 수 정 자         : 임 정호
   -- 작성일자         : 2016-12-19
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 부서별경비명세서 조회하는 프로시저이다.
   -- ---------------------------------------------------------------
(
    p_div          IN     VARCHAR2 DEFAULT '',
    p_compcode     IN     VARCHAR2 DEFAULT '',
    p_plantcode    IN     VARCHAR2 DEFAULT '',
    p_startym      IN     VARCHAR2 DEFAULT '',
    p_endym        IN     VARCHAR2 DEFAULT '',
    p_outputdiv    IN     VARCHAR2 DEFAULT '',
    p_divS         IN     VARCHAR2 DEFAULT '',
    p_startdept    IN     VARCHAR2 DEFAULT '',
    p_enddept      IN     VARCHAR2 DEFAULT '',
    p_preview      IN     VARCHAR2 DEFAULT '',
    p_iempcode     IN     VARCHAR2 DEFAULT '',
    p_userid       IN     VARCHAR2 DEFAULT '',
    p_reasondiv    IN     VARCHAR2 DEFAULT '',
    p_reasontext   IN     VARCHAR2 DEFAULT '',
    IO_CURSOR         OUT TYPES.DataSet,
    MESSAGE           OUT VARCHAR2
)
AS
    p_slipdiv       VARCHAR2 (5);
    p_strdate       VARCHAR2 (10);
    p_enddate       VARCHAR2 (10);
    p_acautorcode   VARCHAR2 (20);
    p_acc           VARCHAR2 (5);


    p_acccode  VARCHAR2 (20);   -- 경상연구개발비
    p_acccode1 VARCHAR2 (20);   -- 접대비
    p_acccode2 VARCHAR2 (20);   -- 판매촉진비
    p_tmpcode1 VARCHAR2 (20);   -- 접대비(제조)
    p_tmpcode2 VARCHAR2 (20);   -- 경상연구개발비(제조)
    p_tmpcode3 VARCHAR2 (20);   -- 판매촉진비(판관)
    p_tmpcode4 VARCHAR2 (20);   -- 접대비(판관)
    p_tmpcode5 VARCHAR2 (20);   -- 경상연구개발비(판관)
    p_slipnum    NUMBER (10, 0);

BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    p_strdate := p_startym || '-01';
    p_enddate := TO_CHAR(ADD_MONTHS(TO_DATE ( p_endym || '-01','YYYY-MM-DD'),1),'YYYY-MM-DD');
    p_acautorcode := 'A04040';

    FOR rec IN
    (
        SELECT  filter1
        FROM    CMCOMMONM
        WHERE   cmmcode = 'AC27'
            AND divcode = p_divS
    )
    LOOP
        p_acc := rec.filter1;
    END LOOP;

    IF p_outputdiv = '1' THEN
      --K-GAAP
        p_slipdiv := 'K';
    ELSIF p_outputdiv = '2' THEN
        --IFRS
        p_slipdiv := 'F';
    END IF;

    IF (p_div = 'S')    THEN

        OPEN IO_CURSOR FOR
        SELECT p_strdate startdt,
                 p_enddate enddt,
                 p_outputdiv outputdiv,
                 a.acccode,
                 MAX (D.accname) accname,
                 MAX(D.ACCNAME) AS ACCNAME,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'01', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON1,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'02', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON2,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'03', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON3,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'04', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON4,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'05', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON5,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'06', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON6,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'07', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON7,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'08', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON8,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'09', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON9,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'10', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON10,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'11', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON11,
                 SUM (DECODE (A.SLIPDATE,NULL,0, TO_CHAR(TO_DATE (A.SLIPDATE,'YYYY-MM-DD'),'MM'),'12', DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ),0 )) AS MON12,
                 SUM (DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT )) AS AMT
            FROM ACORDD a
                 JOIN ACORDM b
                    ON     a.compcode = b.compcode
                       AND a.slipinno = b.slipinno
                       AND (   b.slipdiv = p_slipdiv
                            OR b.slipdiv NOT IN ('F', 'K'))
                       AND (   p_preview = '0'
                            OR     p_preview = 1
                               AND b.acautorcode <> p_acautorcode)
                 LEFT JOIN ACORDS c
                    ON     a.compcode = c.compcode
                       AND a.slipinno = c.slipinno
                       AND a.slipinseq = c.slipinseq
                       AND c.mngclucode = 'S040'
                 LEFT JOIN ACACCM D ON a.acccode = D.acccode
           WHERE     a.compcode = p_compcode
                 AND a.plantcode LIKE p_plantcode
                 AND SUBSTR (a.acccode, 0, 2) = p_acc
                 AND a.slipdate BETWEEN p_strdate AND p_enddate
                 AND (   TRIM(p_startdept)IS NULL AND TRIM(p_enddept) IS NULL
                      OR c.mngcluval BETWEEN p_startdept AND p_enddept)
        GROUP BY a.acccode
          HAVING SUM ( DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ) )  <> 0
        ORDER BY a.acccode;

    ELSIF (p_div = 'R') THEN
         -- 카드전표내역 정산전표저장

        p_tmpcode1 := '43030';

        FOR rec IN
        (
            SELECT  filter1
            FROM    CMCOMMONM
            WHERE   cmmcode = 'AC261'
                AND divcode = '43030'
        )
        LOOP
            p_tmpcode1 := rec.filter1;
        END LOOP;

        p_tmpcode2 := '43380000';

        FOR rec IN
        (
            SELECT  filter1
            FROM    CMCOMMONM
            WHERE   cmmcode = 'AC261'
                AND divcode = '43380000'
        )
        LOOP
            p_tmpcode2 := rec.filter1;
        END LOOP;

        p_tmpcode3 := '73130';

        FOR rec IN
        (
            SELECT  filter1
            FROM    CMCOMMONM
            WHERE   cmmcode = 'AC261'
                AND divcode = '73130'
        )
        LOOP
            p_tmpcode3 := rec.filter1;
        END LOOP;

        p_tmpcode4 := '73550';

        FOR rec IN
        (
            SELECT filter1
            FROM CMCOMMONM
            WHERE cmmcode = 'AC261' AND divcode = '73550'
        )
        LOOP
            p_tmpcode4 := rec.filter1;
        END LOOP;

        p_tmpcode5 := '73560000';

        FOR rec IN
        (
            SELECT  filter1
            FROM    CMCOMMONM
            WHERE   cmmcode = 'AC261'
                AND divcode = '73560000'
        )
        LOOP
            p_tmpcode5 := rec.filter1;
        END LOOP;

        p_acccode  := CASE WHEN p_divS IN ('6','7') THEN p_tmpcode2 ELSE p_tmpcode5 END ;
        p_acccode1 := CASE WHEN p_divS IN ('6','7') THEN p_tmpcode1 ELSE p_tmpcode4 END ;
        p_acccode2 := CASE WHEN p_divS IN ('6','7') THEN p_tmpcode3 ELSE p_tmpcode3 END ;

        p_slipdiv  := 'A';

        FOR rec IN
        (
            SELECT  (NVL (SUBSTR (MAX (slipnum), -4, 4), 0)) AS alias1
            FROM    ACORDM a
            WHERE   compcode = p_compcode
                AND slipno LIKE REPLACE (p_enddate, '-', '') || RTRIM (p_slipdiv) || '%'
        )
        LOOP
            p_slipnum := rec.alias1;
        END LOOP;


            INSERT INTO ACORDM (    compcode, slipinno, slipdiv, slipindate, slipinnum,
                                    deptcode, plantcode,empcode, eviddiv, slipinremark,
                                    slipno,   slipdate, slipnum, slipdeptcode, slipempcode,
                                    skreqyn, skreqdiv, skreqdate, skreqdeptcode, skreqempcode,
                                    accountno, slipinstate, slipremark, acautorcode, insertdt, iempcode)
                    (SELECT         compcode,
                                    slipno,
                                    p_slipdiv,
                                    p_enddate,
                                    slipnum,
                                    deptcode,
                                    plantcode,
                                    p_iempcode,
                                    '99',
                                    '경상연구비대체 자동분개',
                                    slipno,
                                    p_enddate,
                                    slipnum,
                                    deptcode,
                                    p_iempcode,
                                    NULL,
                                    NULL,
                                    p_enddate,
                                    NULL,
                                    NULL,
                                    NULL,
                                    '4',
                                    NULL,
                                    p_acautorcode,
                                    SYSDATE,
                                    p_iempcode
                        FROM (
                        -----------------------------------
                                SELECT compcode,
                                       p_slipdiv ||  p_slipnum || LPAD(ROW_NUMBER () OVER (ORDER BY plantcode),4,'0') slipnum,
                                       REPLACE (p_enddate, '-', '') || p_slipdiv || LPAD (p_slipnum || ROW_NUMBER () OVER (ORDER BY plantcode),4,'0' ) slipno,
                                       (SELECT deptcode FROM CMEMPM WHERE empcode = p_iempcode GROUP BY deptcode) deptcode,
                                       plantcode
                                FROM (SELECT DISTINCT compcode, plantcode
                                      FROM   (
                                      --------------------------
                                                SELECT  a.compcode,
                                                        ROW_NUMBER () OVER (PARTITION BY a.plantcode ORDER BY a.acccode) - 1 slipinseq,
                                                        a.acccode,
                                                        a.plantcode,
                                                        p_divS dcdiv,
                                                        SUM (a.debamt) debamt,
                                                        SUM (a.creamt) creamt,
                                                        NVL (c.mngcluval, '') mngcluval,
                                                        MAX (NVL (c.mngcludec, 0)) mngcludec,
                                                        MAX (D.accname) accname
                                                FROM ACORDD a
                                                    JOIN ACORDM b
                                                       ON     a.compcode = b.compcode
                                                          AND a.slipinno = b.slipinno
                                                          AND (   b.slipdiv = p_slipdiv
                                                               OR b.slipdiv NOT IN ('F', 'K'))
                                                    LEFT JOIN ACORDS c
                                                       ON     a.compcode = c.compcode
                                                          AND a.slipinno = c.slipinno
                                                          AND a.slipinseq = c.slipinseq
                                                          AND c.mngclucode = 'S040'
                                                    LEFT JOIN ACACCM D ON a.acccode = D.acccode
                                                WHERE     a.compcode = p_compcode
                                                    AND a.plantcode LIKE p_plantcode
                                                    AND SUBSTR (a.acccode, 0, 2) = p_acc
                                                    AND a.acccode NOT LIKE p_acccode || '%'
                                                    AND a.acccode NOT LIKE p_acccode1 || '%'
                                                    AND a.acccode NOT LIKE p_acccode2 || '%'
                                                    AND a.slipdate BETWEEN p_strdate AND p_enddate
                                                    AND (   TRIM(p_startdept)IS NULL AND TRIM(p_enddept) IS NULL
                                                         OR c.mngcluval BETWEEN p_startdept AND p_enddept)
                                                    AND DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ) <> 0
                                                GROUP BY a.compcode,a.plantcode, a.acccode, c.mngcluval
                                      ----------------------------
                                             )
                                      ) a
                        ------------------------------------
                             ) --tt_ACORDM_3
                        );

            INSERT INTO ACORDD (compcode,
                                slipinno,
                                slipinseq,
                                dcdiv,
                                acccode,
                                plantcode,
                                debamt,
                                creamt,
                                slipdate,
                                slipnum,
                                remark1,
                                remark2,
                                taxno,
                                rptseq,
                                insertdt,
                                iempcode)
                 SELECT b.compcode,
                        b.slipno,
                        a.slipinseq * 2 + c.grp,
                        a.dcdiv,
                        CASE WHEN grp = 1 THEN a.acccode ELSE p_acccode END col,
                        a.plantcode,
                        CASE WHEN grp = 1 THEN -debamt ELSE debamt END col,
                        CASE WHEN grp = 1 THEN -creamt ELSE creamt END col,
                        p_enddate,
                        b.slipnum,
                        a.accname || ' 경상연구비대체 자동분개',
                        '',
                        '',
                        a.slipinseq * 2 + c.grp,
                        SYSDATE,
                        p_iempcode
                   FROM (
------------------------------------------------
                         SELECT     a.compcode,
                                    ROW_NUMBER () OVER (PARTITION BY a.plantcode ORDER BY a.acccode) - 1 slipinseq,
                                    a.acccode,
                                    a.plantcode,
                                    p_divS dcdiv,
                                    SUM (a.debamt) debamt,
                                    SUM (a.creamt) creamt,
                                    NVL (c.mngcluval, '') mngcluval,
                                    MAX (NVL (c.mngcludec, 0)) mngcludec,
                                    MAX (D.accname) accname
                            FROM ACORDD a
                                JOIN ACORDM b
                                   ON     a.compcode = b.compcode
                                      AND a.slipinno = b.slipinno
                                      AND (   b.slipdiv = p_slipdiv
                                           OR b.slipdiv NOT IN ('F', 'K'))
                                LEFT JOIN ACORDS c
                                   ON     a.compcode = c.compcode
                                      AND a.slipinno = c.slipinno
                                      AND a.slipinseq = c.slipinseq
                                      AND c.mngclucode = 'S040'
                                LEFT JOIN ACACCM D ON a.acccode = D.acccode
                            WHERE     a.compcode = p_compcode
                                AND a.plantcode LIKE p_plantcode
                                AND SUBSTR (a.acccode, 0, 2) = p_acc
                                AND a.acccode NOT LIKE p_acccode || '%'
                                AND a.acccode NOT LIKE p_acccode1 || '%'
                                AND a.acccode NOT LIKE p_acccode2 || '%'
                                AND a.slipdate BETWEEN p_strdate AND p_enddate
                                AND (   TRIM(p_startdept)IS NULL AND TRIM(p_enddept) IS NULL
                                     OR c.mngcluval BETWEEN p_startdept AND p_enddept)
                                AND DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ) <> 0
                            GROUP BY a.compcode,a.plantcode, a.acccode, c.mngcluval
------------------------------------------------
                        ) /*tt_ACORDD_5*/  a
                        JOIN
                        (
--------------------------
                            SELECT compcode,
                                   p_slipdiv ||  p_slipnum || LPAD(ROW_NUMBER () OVER (ORDER BY plantcode),4,'0') slipnum,
                                   REPLACE (p_enddate, '-', '') || p_slipdiv || LPAD (p_slipnum || ROW_NUMBER () OVER (ORDER BY plantcode),4,'0' ) slipno,
                                   (SELECT deptcode FROM CMEMPM WHERE empcode = p_iempcode GROUP BY deptcode) deptcode,
                                   plantcode
                            FROM (SELECT DISTINCT compcode, plantcode
                                  FROM   (
                                  --------------------------
                                            SELECT  a.compcode,
                                                    ROW_NUMBER () OVER (PARTITION BY a.plantcode ORDER BY a.acccode) - 1 slipinseq,
                                                    a.acccode,
                                                    a.plantcode,
                                                    p_divS dcdiv,
                                                    SUM (a.debamt) debamt,
                                                    SUM (a.creamt) creamt,
                                                    NVL (c.mngcluval, '') mngcluval,
                                                    MAX (NVL (c.mngcludec, 0)) mngcludec,
                                                    MAX (D.accname) accname
                                            FROM ACORDD a
                                                JOIN ACORDM b
                                                   ON     a.compcode = b.compcode
                                                      AND a.slipinno = b.slipinno
                                                      AND (   b.slipdiv = p_slipdiv
                                                           OR b.slipdiv NOT IN ('F', 'K'))
                                                LEFT JOIN ACORDS c
                                                   ON     a.compcode = c.compcode
                                                      AND a.slipinno = c.slipinno
                                                      AND a.slipinseq = c.slipinseq
                                                      AND c.mngclucode = 'S040'
                                                LEFT JOIN ACACCM D ON a.acccode = D.acccode
                                            WHERE     a.compcode = p_compcode
                                                AND a.plantcode LIKE p_plantcode
                                                AND SUBSTR (a.acccode, 0, 2) = p_acc
                                                AND a.acccode NOT LIKE p_acccode || '%'
                                                AND a.acccode NOT LIKE p_acccode1 || '%'
                                                AND a.acccode NOT LIKE p_acccode2 || '%'
                                                AND a.slipdate BETWEEN p_strdate AND p_enddate
                                                AND (   TRIM(p_startdept)IS NULL AND TRIM(p_enddept) IS NULL
                                                     OR c.mngcluval BETWEEN p_startdept AND p_enddept)
                                                AND DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ) <> 0
                                            GROUP BY a.compcode,a.plantcode, a.acccode, c.mngcluval
                                  ----------------------------
                                         )
                                  ) a
--------------------------
                        ) /*tt_ACORDM_3*/ b
                           ON     a.compcode = b.compcode
                              AND a.plantcode = b.plantcode
                        JOIN (SELECT 1 grp FROM DUAL
                              UNION
                              SELECT 2 FROM DUAL) c
                           ON 1 = 1
               ORDER BY a.slipinseq * 2 + c.grp;

            INSERT INTO ACORDS (compcode, slipinno, slipinseq, mngclucode, seq,
                                mngcluval, mngcludec, insertdt, iempcode            )
                 SELECT b.compcode,
                        b.slipno,
                        a.slipinseq * 2 + c.grp,
                        'S040',
                        1,
                        a.mngcluval,
                        a.mngcludec,
                        SYSDATE,
                        p_iempcode
                   FROM (
                   --------------------------------
                            SELECT      a.compcode,
                                        ROW_NUMBER () OVER (PARTITION BY a.plantcode ORDER BY a.acccode) - 1 slipinseq,
                                        a.acccode,
                                        a.plantcode,
                                        p_divS dcdiv,
                                        SUM (a.debamt) debamt,
                                        SUM (a.creamt) creamt,
                                        NVL (c.mngcluval, '') mngcluval,
                                        MAX (NVL (c.mngcludec, 0)) mngcludec,
                                        MAX (D.accname) accname
                            FROM ACORDD a
                                JOIN ACORDM b
                                   ON     a.compcode = b.compcode
                                      AND a.slipinno = b.slipinno
                                      AND (   b.slipdiv = p_slipdiv
                                           OR b.slipdiv NOT IN ('F', 'K'))
                                LEFT JOIN ACORDS c
                                   ON     a.compcode = c.compcode
                                      AND a.slipinno = c.slipinno
                                      AND a.slipinseq = c.slipinseq
                                      AND c.mngclucode = 'S040'
                                LEFT JOIN ACACCM D ON a.acccode = D.acccode
                            WHERE     a.compcode = p_compcode
                                AND a.plantcode LIKE p_plantcode
                                AND SUBSTR (a.acccode, 0, 2) = p_acc
                                AND a.acccode NOT LIKE p_acccode || '%'
                                AND a.acccode NOT LIKE p_acccode1 || '%'
                                AND a.acccode NOT LIKE p_acccode2 || '%'
                                AND a.slipdate BETWEEN p_strdate AND p_enddate
                                AND (   TRIM(p_startdept)IS NULL AND TRIM(p_enddept) IS NULL
                                     OR c.mngcluval BETWEEN p_startdept AND p_enddept)
                                AND DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ) <> 0
                            GROUP BY a.compcode,a.plantcode, a.acccode, c.mngcluval
                   --------------------------------
                        ) /*tt_ACORDD_5*/ a
                        JOIN
                        (
                   --------------------------------
                            SELECT compcode,
                                   p_slipdiv ||  p_slipnum || LPAD(ROW_NUMBER () OVER (ORDER BY plantcode),4,'0') slipnum,
                                   REPLACE (p_enddate, '-', '') || p_slipdiv || LPAD (p_slipnum || ROW_NUMBER () OVER (ORDER BY plantcode),4,'0' ) slipno,
                                   (SELECT deptcode FROM CMEMPM WHERE empcode = p_iempcode GROUP BY deptcode) deptcode,
                                   plantcode
                            FROM (SELECT DISTINCT compcode, plantcode
                                  FROM   (
                                  --------------------------
                                            SELECT  a.compcode,
                                                    ROW_NUMBER () OVER (PARTITION BY a.plantcode ORDER BY a.acccode) - 1 slipinseq,
                                                    a.acccode,
                                                    a.plantcode,
                                                    p_divS dcdiv,
                                                    SUM (a.debamt) debamt,
                                                    SUM (a.creamt) creamt,
                                                    NVL (c.mngcluval, '') mngcluval,
                                                    MAX (NVL (c.mngcludec, 0)) mngcludec,
                                                    MAX (D.accname) accname
                                            FROM ACORDD a
                                                JOIN ACORDM b
                                                   ON     a.compcode = b.compcode
                                                      AND a.slipinno = b.slipinno
                                                      AND (   b.slipdiv = p_slipdiv
                                                           OR b.slipdiv NOT IN ('F', 'K'))
                                                LEFT JOIN ACORDS c
                                                   ON     a.compcode = c.compcode
                                                      AND a.slipinno = c.slipinno
                                                      AND a.slipinseq = c.slipinseq
                                                      AND c.mngclucode = 'S040'
                                                LEFT JOIN ACACCM D ON a.acccode = D.acccode
                                            WHERE     a.compcode = p_compcode
                                                AND a.plantcode LIKE p_plantcode
                                                AND SUBSTR (a.acccode, 0, 2) = p_acc
                                                AND a.acccode NOT LIKE p_acccode || '%'
                                                AND a.acccode NOT LIKE p_acccode1 || '%'
                                                AND a.acccode NOT LIKE p_acccode2 || '%'
                                                AND a.slipdate BETWEEN p_strdate AND p_enddate
                                                AND (   TRIM(p_startdept)IS NULL AND TRIM(p_enddept) IS NULL
                                                     OR c.mngcluval BETWEEN p_startdept AND p_enddept)
                                                AND DECODE (P_DIVS,'2', A.CREAMT, '4',  A.CREAMT,  A.DEBAMT ) <> 0
                                            GROUP BY a.compcode,a.plantcode, a.acccode, c.mngcluval
                                  ----------------------------
                                         )
                                  ) a
                   --------------------------------
                        ) /*tt_ACORDM_3*/ b
                           ON     a.compcode = b.compcode
                              AND a.plantcode = b.plantcode
                        JOIN (SELECT 1 grp FROM DUAL
                              UNION
                              SELECT 2 FROM DUAL) c
                           ON 1 = 1
               ORDER BY a.slipinseq * 2 + c.grp;

            spACord0000MM ('T',
                           p_compcode,
                           '',
                           '%',
                           p_startym,
                           p_endym,
                           p_userid,
                           p_reasondiv,
                           p_reasontext,
                           MESSAGE,
                           IO_CURSOR);

    END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
