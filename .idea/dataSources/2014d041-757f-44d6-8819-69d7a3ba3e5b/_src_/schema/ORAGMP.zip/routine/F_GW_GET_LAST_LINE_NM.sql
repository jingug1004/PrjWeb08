CREATE FUNCTION F_GW_GET_LAST_LINE_NM (
        SAPPROVAL_SEQ CHAR
)
        RETURN VARCHAR IS

        /*CHOE 20171214 그룹웨어 사용 FUNCTION
        */

        EMP_NAME VARCHAR(500);
BEGIN

        SELECT EMP_NO||'^'||EMPNAME
        INTO EMP_NAME
        FROM (
                SELECT ROWNUM RNUM ,TB.EMP_NO ,TB.EMPNAME
                FROM (
                        SELECT TA.EMP_NO ,TB.EMPNAME AS EMPNAME
                        FROM HANAGROUPWARE.GW_EA_APPROVAL TA
                        ,ORAGMP.CMEMPM TB
                        WHERE TA.APPROVAL_SEQ = SAPPROVAL_SEQ
                        AND TA.EMP_NO = TB.EMPCODE
                        AND TA.APPROVAL_DT IS NOT NULL
                        ORDER BY TA.APPROVAL_DT DESC
                ) TB
        )
        WHERE RNUM = '1';

        RETURN EMP_NAME;
END;
/
