CREATE PROCEDURE        spACbase0104P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbase0104P
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-07-08
	-- 수정일자  		 :   노영래
	-- E-mail  		 :   0rae0926@gmail.com
	-- 수정일자  		 :   2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 재무양식마스터를 등록,수정,삭제,조회하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_rptdiv		IN	   VARCHAR2 DEFAULT '',
	p_rptyear		IN	   VARCHAR2 DEFAULT '',
	p_seqline		IN	   VARCHAR2 DEFAULT '',
	p_acccode		IN	   VARCHAR2 DEFAULT '',
	p_accrname		IN	   VARCHAR2 DEFAULT '',
	p_acckname		IN	   VARCHAR2 DEFAULT '',
	p_objdatadiv	IN	   VARCHAR2 DEFAULT '',
	p_calcdiv		IN	   VARCHAR2 DEFAULT '',
	p_sseqline		IN	   VARCHAR2 DEFAULT '',
	p_cseqline		IN	   VARCHAR2 DEFAULT '',
	p_calcseq		IN	   NUMBER DEFAULT 0,
	p_lrdiv 		IN	   VARCHAR2 DEFAULT '',
	p_prtyn 		IN	   VARCHAR2 DEFAULT '',
	p_prtdiv		IN	   VARCHAR2 DEFAULT '',
	p_prtbold		IN	   VARCHAR2 DEFAULT '',
	p_remark		IN	   VARCHAR2 DEFAULT '',
	p_useyn 		IN	   VARCHAR2 DEFAULT '',
	p_iempcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO   ATINFO (USERID, REASONDIV, REASONTEXT)
    VALUES (p_userid, p_reasondiv, p_reasontext);

	IF (UPPER(P_DIV) = 'S') THEN
		OPEN IO_CURSOR FOR
			SELECT	 NVL(a.compcode, '') compcode,
					 NVL(a.rptdiv, '') rptdiv,
					 NVL(a.rptyear, '') rptyear,
					 NVL(a.seqline, '') seqline,
					 NVL(a.acccode, '') acccode,
					 NVL(a.accrname, '') accrname,
					 NVL(a.acckname, '') acckname,
					 NVL(a.objdatadiv, '') objdatadiv,
					 NVL(a.calcdiv, '') calcdiv,
					 NVL(a.sseqline, '') sseqline,
					 NVL(a.cseqline, '') cseqline,
					 NVL(a.calcseq, 0) calcseq,
					 NVL(a.lrdiv, '') lrdiv,
					 NVL(a.prtyn, '') prtyn,
					 NVL(a.prtdiv, '') prtdiv,
					 NVL(a.prtbold, 'N') prtbold,
					 NVL(a.remark, '') remark,
					 NVL(a.useyn, '') useyn
			FROM	 ACRPTM a LEFT JOIN ACACCM b ON a.acccode = b.acccode
			WHERE	 a.compcode = p_compcode
					 AND a.rptdiv = p_rptdiv
					 AND a.rptyear = p_rptyear
					 AND (NVL(a.prtdiv, ' ') LIKE p_prtdiv
						  OR a.prtdiv = 'B')
			ORDER BY a.seqline;

	ELSIF (UPPER(P_DIV) = 'SY') THEN
		OPEN IO_CURSOR FOR
			SELECT	 rptyear keyfield, rptyear displayfield
			FROM	 (SELECT DISTINCT TO_CHAR(SYSDATE, 'YYYY') rptyear
					  FROM	 CMCOMPM
					  WHERE  NOT EXISTS
								 (SELECT *
								  FROM	 ACRPTM
								  WHERE  compcode = p_compcode
										 AND rptdiv = p_rptdiv)
					  UNION ALL
					  SELECT DISTINCT rptyear
					  FROM	 ACRPTM
					  WHERE  compcode = p_compcode
							 AND rptdiv = p_rptdiv) a
			ORDER BY rptyear DESC;

	ELSIF (UPPER(P_DIV) = 'SC') THEN
		FOR rec IN (
        	SELECT COUNT(compcode) AS alias1
            FROM   ACRPTM
            WHERE  compcode = p_compcode
                   AND rptdiv = p_rptdiv
                   AND rptyear = p_rptyear
                   AND seqline = p_seqline
        )
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;

	ELSIF (UPPER(P_DIV) = 'I') THEN
		INSERT INTO ACRPTM(compcode,
						   rptdiv,
						   rptyear,
						   seqline,
						   acccode,
						   accrname,
						   acckname,
						   objdatadiv,
						   calcdiv,
						   sseqline,
						   cseqline,
						   calcseq,
						   lrdiv,
						   prtyn,
						   prtdiv,
						   prtbold,
						   remark,
						   useyn,
						   insertdt,
						   iempcode)
		VALUES		(p_compcode,
					 p_rptdiv,
					 p_rptyear,
					 p_seqline,
					 p_acccode,
					 p_accrname,
					 p_acckname,
					 p_objdatadiv,
					 p_calcdiv,
					 p_sseqline,
					 p_cseqline,
					 p_calcseq,
					 p_lrdiv,
					 p_prtyn,
					 p_prtdiv,
					 p_prtbold,
					 p_remark,
					 p_useyn,
					 SYSDATE,
					 p_iempcode);

	ELSIF (UPPER(P_DIV) = 'U') THEN
		UPDATE ACRPTM
		SET    acccode = p_acccode,
			   accrname = p_accrname,
			   acckname = p_acckname,
			   objdatadiv = p_objdatadiv,
			   calcdiv = p_calcdiv,
			   sseqline = p_sseqline,
			   cseqline = p_cseqline,
			   calcseq = p_calcseq,
			   lrdiv = p_lrdiv,
			   prtyn = p_prtyn,
			   prtdiv = p_prtdiv,
			   prtbold = p_prtbold,
			   remark = p_remark,
			   useyn = p_useyn,
			   updatedt = SYSDATE,
			   uempcode = p_iempcode
		WHERE  compcode = p_compcode
			   AND rptdiv = p_rptdiv
			   AND rptyear = p_rptyear
			   AND seqline = p_seqline;

	ELSIF (UPPER(P_DIV) = 'D') THEN
		DELETE ACRPTM
		WHERE  compcode = p_compcode
			   AND rptdiv = p_rptdiv
			   AND rptyear = p_rptyear
			   AND seqline = p_seqline;

	ELSIF (UPPER(P_DIV) = 'CP') THEN
		DELETE ACRPTM
		WHERE  compcode = p_compcode
			   AND rptdiv = p_rptdiv
			   AND rptyear = p_seqline;

		INSERT INTO ACRPTM
			(SELECT compcode,
					rptdiv,
					p_seqline,
					seqline,
					acccode,
					accrname,
					acckname,
					objdatadiv,
					calcdiv,
					sseqline,
					cseqline,
					calcseq,
					lrdiv,
					prtyn,
					prtdiv,
					prtbold,
					remark,
					useyn,
					insertdt,
					iempcode,
					updatedt,
					uempcode
			 FROM	ACRPTM
			 WHERE	compcode = p_compcode
					AND rptdiv = p_rptdiv
					AND rptyear = p_rptyear);

	END IF;

	IF (IO_CURSOR IS NULL) THEN
		OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
	END IF;
END;
/
