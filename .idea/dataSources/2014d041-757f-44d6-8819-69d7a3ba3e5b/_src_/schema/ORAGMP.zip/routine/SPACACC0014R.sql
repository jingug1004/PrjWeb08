CREATE PROCEDURE spACacc0014R
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACacc0014R
   -- 작 성 자         : 배종성
   -- 작성일자         : 2011-04-26
   -- 수정자         : 임정호
   --수정일         : 2016-12-14

   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 예산실적전표를 조회하는 프로시저이다.
   --       마스터조회조건 (관리항목조회조건은 ACacc0010R)
   -- ---------------------------------------------------------------
   -- select * from ACORDM
   -- select * from ACORDD
   -- select * from CMCOMMONM where cmmcode = 'AC20' -- 전표유형
   -- select * from CMCOMMONM where cmmcode = 'AC21' -- 전표상태
   -- select * from CMCOMMONM where cmmcode = 'AC22' -- 차대구분
   -- exec spACacc0014R 'S','100','%','2010-01-01','2011-01-31','','','%','%','43050200','43050200', '','','','N'
(

   p_div           IN     VARCHAR2 DEFAULT '',
   p_compcode      IN     VARCHAR2 DEFAULT '',
   p_plantcode     IN     VARCHAR2 DEFAULT '',
   p_slipsdate     IN     VARCHAR2 DEFAULT '',
   p_slipedate     IN     VARCHAR2 DEFAULT '',
   p_deptcode      IN     VARCHAR2 DEFAULT '',
   p_empcode       IN     VARCHAR2 DEFAULT '',
   p_slipdiv       IN     VARCHAR2 DEFAULT '',
   p_slipinstate   IN     VARCHAR2 DEFAULT '',
   p_stracccode    IN     VARCHAR2 DEFAULT '',
   p_endacccode    IN     VARCHAR2 DEFAULT '',
   p_userid        IN     VARCHAR2 DEFAULT '',
   p_reasondiv     IN     VARCHAR2 DEFAULT '',
   p_reasontext    IN     VARCHAR2 DEFAULT '',
   IO_CURSOR          OUT TYPES.DataSet,
   MESSAGE            OUT VARCHAR2

)
AS
BEGIN
   MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

   IF (p_div = 'S')
   THEN
      -- 결의전표내역 검색

      OPEN IO_CURSOR FOR
           SELECT a.slipindate slipindate,                  -- 결의일자
                  a.slipinnum slipinnum,                    -- 결의번호
                  a.deptcode deptcode,                      -- 결의부서
                  D.deptname deptname,                   -- 발의부서명 ㅁ
                  a.empcode empcode,                        -- 결의사원
                  E.empname empname,                      -- 발의자명 ㅁ
                  b.acccode acccode,
                  f.accname accname,                       -- 계정명 ㅁ
                  CASE b.dcdiv
                     WHEN '3' THEN NVL(b.creamt, 0)
                     ELSE b.debamt
                  END
                     totamt,                                            -- 총금액
                  b.remark1 remark,                         -- 결의내용
                  a.skreqdate skreqdate,                  -- 송금의뢰일자
                  a.slipinstate slipinstate,                -- 전표상태
                  ac21.divname slipinstatenm,             -- 전표상태 ㅁ
                  a.slipdate slipdate,                      -- 회계일자
                  a.slipnum slipnum,                        -- 회계번호
                  a.slipempcode slipempcode,                 -- 승인자
                  es.empname slipempname,                 -- 승인자명 ㅁ
                  a.slipdiv slipdiv,                      -- 전표유형구분
                  ac20.divname slipdivnm,                 -- 전표유형 ㅁ
                  a.slipremark slipremark                   -- 처리사유
             FROM ACORDM a
                  LEFT JOIN
                  ACORDD b
                     ON     a.compcode = b.compcode
                        AND a.plantcode = b.plantcode
                        AND a.slipinno = b.slipinno
                  LEFT JOIN CMDEPTM                                    -- 발의부서
                                   D ON a.deptcode = D.deptcode
                  LEFT JOIN CMEMPM E                                    -- 발의자
                                    ON a.empcode = E.empcode
                  LEFT JOIN CMEMPM es                                   -- 승인자
                                     ON a.slipempcode = es.empcode
                  LEFT JOIN ACACCM f ON b.acccode = f.acccode
                  LEFT JOIN CMCOMMONM ac20                             -- 전표유형
                     ON ac20.cmmcode = 'AC20' AND a.slipdiv = ac20.divcode
                  LEFT JOIN CMCOMMONM ac21                             -- 전표상태
                     ON ac21.cmmcode = 'AC21' AND a.slipinstate = ac21.divcode
            WHERE     a.compcode = p_compcode
                  AND a.plantcode LIKE p_plantcode
                  AND a.slipindate BETWEEN p_slipsdate AND p_slipedate
                  AND a.deptcode LIKE p_deptcode || '%'
                  AND a.empcode LIKE p_empcode || '%'
                  AND a.slipdiv LIKE p_slipdiv
                  AND (b.dcdiv = '1' OR b.dcdiv = '3' OR b.dcdiv = '4')
                  AND a.slipinstate LIKE p_slipinstate
                  AND (   p_stracccode > ' ' AND b.acccode >= p_stracccode
                       OR p_stracccode IS NULL)
                  AND (   p_endacccode > ' ' AND b.acccode <= p_endacccode
                       OR p_endacccode IS NULL)
         ORDER BY slipindate, slipinnum, slipinseq;
   END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
