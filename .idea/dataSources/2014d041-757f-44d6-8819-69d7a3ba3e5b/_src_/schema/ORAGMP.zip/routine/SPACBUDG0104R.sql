CREATE PROCEDURE        spACbudg0104R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACbudg0104R
 -- 작 성 자         : 배종성
 -- 작성일자         : 2010-12-30
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2017-01-02
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 월별예산조정현황 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
 -- select * from ACBUDGYH
 -- exec spACbudg0104R 'S','100','A101001A1051','A101001A1051','','','','2011-01-01','2011-01-31', '','','','N'
 -- delete ACBUDGYH where remark = '테스트임'
(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_deptcode1     IN  VARCHAR2 DEFAULT '' ,
    p_deptcode2     IN  VARCHAR2 DEFAULT '' ,
    p_acccode1      IN  VARCHAR2 DEFAULT '' ,
    p_acccode2      IN  VARCHAR2 DEFAULT '' ,
    p_divS          IN  VARCHAR2 DEFAULT '' ,
    p_startdt       IN  VARCHAR2 DEFAULT '' ,
    p_enddt         IN  VARCHAR2 DEFAULT '' ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS

BEGIN

   MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( UPPER(p_div) = 'S' ) THEN

        --변경일자, 변경구분, 변경내용, 변경대상년월, 변경전계정과목, 변경부서1,변경전예산금액, 변경후예산금액
        OPEN  IO_CURSOR FOR

            SELECT  a.seq ,
                    a.chgdate ,
                    f.divname chgdiv  ,
                    a.remark ,
                    NVL(a.frmbudgym, '') frmbudgym  ,
                    NVL(a.frmacccode, '') frmacccode  ,
                    NVL(b.accname, '') frmaccname  ,
                    NVL(a.frmdeptcode, '') frmdeptcode  ,
                    NVL(c.deptname, '') frmdeptname  ,
                    NVL(a.frm1budgamt, 0) frm1budgamt  ,
                    NVL(a.aft1budgamt, 0) frm2budgamt  ,
                    NVL(a.aftbudgym, '') aftbudgym  ,
                    NVL(a.aftacccode, '') aftacccode  ,
                    NVL(D.accname, '') aftaccname  ,
                    NVL(a.aftdeptcode, '') aftdeptcode  ,
                    NVL(E.deptname, '') aftdeptname  ,
                    NVL(a.frm2budgamt, 0) aft1budgamt  ,
                    NVL(a.aft2budgamt, 0) aft2budgamt
            FROM    ACBUDGYH a
                    LEFT JOIN ACACCM b   ON a.frmacccode = b.acccode
                    LEFT JOIN CMDEPTM c   ON a.frmdeptcode = c.deptcode
                    LEFT JOIN ACACCM D   ON a.aftacccode = D.acccode
                    LEFT JOIN CMDEPTM E   ON a.aftdeptcode = E.deptcode
                    LEFT JOIN CMCOMMONM f   ON a.chgdiv = f.divcode
                    AND f.cmmcode = 'AC90'
            WHERE   a.compcode = p_compcode
                    AND ( ( p_acccode1 > ' ' AND a.frmacccode >= p_acccode1 OR p_acccode1 IS NULL )
                           AND ( NVL(p_acccode2,' ') > ' ' AND a.frmacccode <= p_acccode2 OR p_acccode2 IS NULL ) OR
                               ( NVL(p_acccode1,' ') > ' ' AND a.aftacccode >= p_acccode1 OR p_acccode1 IS NULL )
                           AND ( NVL(p_acccode2,' ') > ' ' AND a.aftacccode <= p_acccode2 OR p_acccode2 IS NULL ) )
                    AND ( ( p_deptcode1 > ' ' AND a.frmdeptcode >= p_deptcode1 OR p_deptcode1 IS NULL )
                            AND ( NVL(p_deptcode2,' ') > ' ' AND a.frmdeptcode <= p_deptcode2 OR p_deptcode2 IS NULL ) OR
                                ( NVL(p_deptcode1,' ') > ' ' AND a.aftdeptcode >= p_deptcode1 OR p_deptcode1 IS NULL )
                            AND ( NVL(p_deptcode2,' ') > ' ' AND a.aftdeptcode <= p_deptcode2 OR p_deptcode2 IS NULL ) )
                    AND chgdiv LIKE p_divS || '%'
                    AND chgdate BETWEEN p_startdt AND p_enddt ;
--- 조회선태 ? 년도 :  기간선택(월기준) 부서 (~) , 계정(~)
--                    변경구분 : 콤보(AC90)
--- 조회조건 : 선택년도, 선택부서 조건으로 변경 이력을 조회.


    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
