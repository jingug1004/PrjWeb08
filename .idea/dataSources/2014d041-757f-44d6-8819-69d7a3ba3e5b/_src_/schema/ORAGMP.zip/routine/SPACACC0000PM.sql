CREATE PROCEDURE spACacc0000PM
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0000PM
 -- 작 성 자         : 민승기
 -- 작성일자         : 2010-10-06
 -- 수정자          : 임정호
 -- 작성일자         : 2016-12-15
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 회계전표내역 테이블 (ACORDM)을 등록,수정,삭제하는 프로시저이다.
 -- ---------------------------------------------------------------

(
  p_div IN VARCHAR2 DEFAULT ' ' ,
  p_compcode IN VARCHAR2 DEFAULT ' ' ,
  p_slipinno IN VARCHAR2 DEFAULT ' ' ,
  p_slipdiv IN VARCHAR2 DEFAULT ' ' ,
  p_slipindate IN VARCHAR2 DEFAULT ' ' ,
  p_slipinnum IN VARCHAR2 DEFAULT ' ' ,
  p_deptcode IN VARCHAR2 DEFAULT ' ' ,
  p_plantcode IN VARCHAR2 DEFAULT ' ' ,
  p_empcode IN VARCHAR2 DEFAULT ' ' ,
  p_eviddiv IN VARCHAR2 DEFAULT '99' ,
  p_slipinremark IN VARCHAR2 DEFAULT ' ' ,
  p_slipincomment IN VARCHAR2 DEFAULT ' ' ,
  p_slipno IN VARCHAR2 DEFAULT ' ' ,
  p_slipdate IN VARCHAR2 DEFAULT ' ' ,
  p_slipnum IN VARCHAR2 DEFAULT ' ' ,
  p_slipdeptcode IN VARCHAR2 DEFAULT ' ' ,
  p_slipempcode IN VARCHAR2 DEFAULT ' ' ,
  p_skreqyn IN VARCHAR2 DEFAULT ' ' ,
  p_skreqdiv IN VARCHAR2 DEFAULT ' ' ,
  p_skreqdate IN VARCHAR2 DEFAULT ' ' ,
  p_skreqdeptcode IN VARCHAR2 DEFAULT ' ' ,
  p_skreqempcode IN VARCHAR2 DEFAULT ' ' ,
  p_accountno IN VARCHAR2 DEFAULT ' ' ,
  p_slipinstate IN VARCHAR2 DEFAULT ' ' ,
  p_acautorcode IN VARCHAR2 DEFAULT ' ' ,
  p_iempcode IN VARCHAR2 DEFAULT ' ' ,
  p_userid IN VARCHAR2 DEFAULT ' ' ,
  p_reasondiv IN VARCHAR2 DEFAULT ' ' ,
  p_reasontext IN VARCHAR2 DEFAULT ' ' ,
  IO_CURSOR         OUT TYPES.DataSet,
  MESSAGE           OUT VARCHAR2
)
AS
   ip_slipnum VARCHAR2(5) := p_slipnum;
   ip_slipno VARCHAR2(20) := p_slipno;
   ip_slipindate VARCHAR2(10) := p_slipindate;
   ip_slipinnum VARCHAR2(5) := p_slipinnum;
   ip_slipinno VARCHAR2(20) := p_slipinno;
   p_taxdel VARCHAR2(5);
   p_bdgcalc VARCHAR2(5);
   p_bdgcalc2 VARCHAR2(5);
   v_temp NUMBER(1, 0);
   p_minseq NUMBER(10,0);
   p_maxseq NUMBER(10,0);
BEGIN

    MESSAGE := '데이터 확인' ;
    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    IF ( p_div = 'I' ) THEN

    -- 회계전표내역 등록

        IF ( p_slipdiv IN ( 'A','F','K' )  ) THEN

       -- 회계/IFRS/K-GAP전표인 경우

            IF p_slipdiv = 'A' THEN

            -- 회계전표인 경우

                FOR  rec IN
                (
                    SELECT  p_slipdiv ||  LPAD(NVL(MAX(SUBSTR(SLIPINNUM,-4)),0)+1,4,'0')  AS alias1
                    FROM    ACORDM a
                    WHERE   compcode = p_compcode
                        AND slipdate = p_slipdate
                        AND slipnum LIKE p_slipdiv || '%'
                )
                LOOP
                    ip_slipnum := rec.alias1 ;
                END LOOP;


            ELSE


                FOR  rec IN
                (
                    SELECT  p_slipdiv ||  LPAD(NVL(MAX(SUBSTR(SLIPINNUM,-4)),0)+1,4,'0')  AS alias1
                    FROM    ACORDM a
                    WHERE   compcode = p_compcode
                        AND slipindate = p_slipdate
                        AND slipdiv = p_slipdiv
                )
                LOOP
                    ip_slipnum := rec.alias1   ;
                END LOOP;

            END IF;

            ip_slipno := REPLACE(p_slipdate, '-', '') || ip_slipnum ;
            ip_slipindate := p_slipdate ;
            ip_slipinnum := ip_slipnum ;
            ip_slipinno := REPLACE(ip_slipindate, '-', '') || ip_slipinnum ;

        ELSE

       -- 결의전표인 경우
            FOR  rec IN
            (
                SELECT  p_slipdiv || LPAD(NVL(MAX(SUBSTR(SLIPINNUM,-4)),0)+1,4,'0')  AS alias1
                FROM    ACORDM a
                WHERE   compcode = p_compcode
                    AND slipindate = ip_slipindate
                    AND slipdiv = p_slipdiv
            )
            LOOP
                ip_slipinnum := rec.alias1   ;
            END LOOP;

            ip_slipinno := REPLACE(ip_slipindate, '-', '') || ip_slipinnum ;
        END IF;



        INSERT INTO ACORDM
                            ( compcode,         slipinno,       slipdiv,         slipindate,      slipinnum,   deptcode,        plantcode,
                              empcode,          eviddiv,        slipinremark,    slipincomment,   slipno,      slipdate,        slipnum,
                              slipdeptcode,     slipempcode,    skreqyn,         skreqdiv,        skreqdate,   skreqdeptcode,   skreqempcode,
                              accountno,        slipinstate,    acautorcode,     insertdt,        iempcode
                            )
                     VALUES ( p_compcode,       ip_slipinno,     p_slipdiv,       ip_slipindate,    ip_slipinnum, p_deptcode,      p_plantcode,
                              p_empcode,        p_eviddiv,      p_slipinremark,  p_slipincomment, ip_slipno,    p_slipdate,      ip_slipnum,
                              p_slipdeptcode,   p_slipempcode,  p_skreqyn,       p_skreqdiv,      p_skreqdate, p_skreqdeptcode, p_skreqempcode,
                              p_accountno,      p_slipinstate,  p_acautorcode,   sysdate,         p_iempcode
                            );

        MESSAGE :=  CASE
                        WHEN p_slipdiv IN ( 'A','F','K' ) THEN
                            ip_slipnum
                        ELSE
                            ip_slipinnum
                    END ;


    ELSIF ( p_div = 'U' ) THEN

       -- 회계전표내역 수정


        UPDATE ACORDM
           SET slipdiv = p_slipdiv,
               slipindate = ip_slipindate,
               slipinnum = ip_slipinnum,
               deptcode = p_deptcode,
               plantcode = p_plantcode,
               empcode = p_empcode,
               eviddiv = p_eviddiv,
               slipinremark = p_slipinremark,
               slipincomment = p_slipincomment,
               slipno = ip_slipno,
               slipdate = p_slipdate,
               slipnum = ip_slipnum,
               slipdeptcode = p_slipdeptcode,
               slipempcode = p_slipempcode,
               skreqyn = p_skreqyn,
               skreqdiv = p_skreqdiv,
               skreqdate = p_skreqdate,
               skreqdeptcode = p_skreqdeptcode,
               skreqempcode = p_skreqempcode,
               accountno = p_accountno,
               slipinstate = p_slipinstate,
               updatedt = SYSDATE,
               uempcode = p_iempcode
         WHERE compcode = p_compcode AND slipinno = ip_slipinno;

         MESSAGE := CASE
                        WHEN p_slipdiv IN ( 'A','F','K' ) THEN
                            ip_slipnum
                        ELSE
                            ip_slipinnum
                    END ;

    ELSIF ( p_div = 'D' ) THEN
          -- 회계전표내역 삭제

        FOR  rec IN
        (
            SELECT  value1
            FROM    SYSPARAMETERMANAGE
            WHERE   parametercode = 'accsliptaxdel'
        )
        LOOP
            p_taxdel := rec.value1   ;
        END LOOP;

        IF p_taxdel = 'Y' THEN


            DELETE FROM ACTAXD TG
            WHERE (TG.COMPCODE, TG.PLANTCODE, TG.TAXNO, TG.SEQ) IN (
                                                                        SELECT  B.COMPCODE, B.PLANTCODE, B.TAXNO, B.SEQ
                                                                        FROM    ACORDD a, ACTAXD b
                                                                        WHERE   a.compcode = b.compcode
--                                                                            AND a.plantcode = b.plantcode
                                                                            AND a.taxno = b.taxno
                                                                            AND a.compcode = p_compcode
                                                                            AND a.slipinno = ip_slipinno
                                                                    );

            DELETE FROM ACTAXM TG
            WHERE (TG.COMPCODE, TG.PLANTCODE, TG.TAXNO) IN (
                                                                SELECT  B.COMPCODE, B.PLANTCODE, B.TAXNO
                                                                FROM    ACORDD a
                                                                        JOIN ACTAXM b
                                                                            ON      a.compcode = b.compcode
--                                                                                AND a.plantcode = b.plantcode
                                                                                AND a.taxno = b.taxno
                                                                WHERE  a.compcode = p_compcode
                                                                   AND a.slipinno = ip_slipinno
                                                           );





        END IF;

        DELETE SFORDEP
        WHERE   compcode = p_compcode
            AND slipinno = ip_slipinno;

        DELETE FROM VGT.TT_ACACC0000PM_ACORDRPYR;

        INSERT INTO VGT.TT_ACACC0000PM_ACORDRPYR
        SELECT DISTINCT b.compcode, b.slipinno, b.slipinseq
          FROM ACORDD a
               JOIN
               ACORDRPYP b
                  ON     a.compcode = b.compcode
                     AND a.slipinno = b.rpyslipinno
                     AND a.slipinseq = b.rpyslipinseq
        WHERE  a.compcode = p_compcode AND a.slipinno = ip_slipinno;


        DELETE FROM ACORDRPYP TG
        WHERE (TG.COMPCODE, TG.SLIPINNO, TG.SLIPINSEQ, TG.RPYSLIPINNO, TG.RPYSLIPINSEQ) IN  (
                                                                                                SELECT  B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ, B.RPYSLIPINNO, B.RPYSLIPINSEQ
                                                                                                FROM    ACORDD a
                                                                                                        JOIN ACORDRPYP b
                                                                                                            ON      a.compcode = b.compcode
                                                                                                                AND a.slipinno = b.rpyslipinno
                                                                                                                AND a.slipinseq = b.rpyslipinseq
                                                                                                WHERE   a.compcode = p_compcode
                                                                                                    AND a.slipinno = ip_slipinno
                                                                                            );

        MERGE INTO ACORDRPYR TG
            USING (
                    SELECT  A.COMPCODE, A.SLIPINNO, A.SLIPINSEQ, C.REPAYAMT
                    FROM    ACORDRPYR a
                            JOIN
                            VGT.TT_ACACC0000PM_ACORDRPYR b
                                ON      a.compcode = b.compcode
                                    AND a.slipinno = b.slipinno
                                    AND a.slipinseq = b.slipinseq
                            LEFT JOIN
                            (
                                SELECT  a.compcode, a.slipinno, a.slipinseq, SUM (a.repayamt) AS repayamt
                                FROM    ACORDRPYP a
                                        JOIN
                                            VGT.TT_ACACC0000PM_ACORDRPYR b
                                                ON      a.compcode = b.compcode
                                                    AND a.slipinno = b.slipinno
                                                    AND a.slipinseq = b.slipinseq
                                GROUP BY a.compcode, a.slipinno, a.slipinseq
                            ) C

                            ON     a.compcode  = c.compcode
                               AND a.slipinno  = c.slipinno
                               AND a.slipinseq = c.slipinseq
                   ) TT
                   ON  (TG.COMPCODE =TT.COMPCODE AND TG.SLIPINNO=TT.SLIPINNO AND TG.SLIPINSEQ=TT.SLIPINSEQ)
        WHEN MATCHED THEN
            UPDATE SET TG.REPAYAMT=NVL(TT.REPAYAMT,0);


        DELETE FROM ACORDRPYR TG
        WHERE (TG.COMPCODE, TG.SLIPINNO, TG.SLIPINSEQ) IN   (
                                                                SELECT  A.COMPCODE, A.SLIPINNO, A.SLIPINSEQ
                                                                FROM    ACORDRPYR a
                                                                        JOIN VGT.TT_ACACC0000PM_ACORDRPYR b
                                                                            ON      a.compcode  = b.compcode
                                                                                AND a.slipinno  = b.slipinno
                                                                                AND a.slipinseq = b.slipinseq
                                                                WHERE  A.REPAYAMT = 0
                                                            );
        DELETE  ACORDS
        WHERE   compcode = p_compcode
            AND slipinno = ip_slipinno;

        DELETE ACORDD
        WHERE  compcode = p_compcode
            AND slipinno = ip_slipinno;

        DELETE ACORDM
        WHERE  compcode = p_compcode
            AND slipinno = ip_slipinno;


    ELSIF ( p_div = 'UC' ) THEN
    -- 회계전표내역 결재상신
        UPDATE ACORDM
          SET slipinstate   = p_slipinstate,
              updatedt      = SYSDATE,
              uempcode      = p_iempcode
        WHERE compcode      = p_compcode
          AND slipinno      = ip_slipinno;

        p_bdgcalc := '2' ;
        FOR  rec IN
        (
            SELECT  value1
            FROM    SYSPARAMETERMANAGE
            WHERE   parametercode = 'accslipbdgcalc'
        )
        LOOP
            p_bdgcalc := rec.value1   ;
        END LOOP;

        IF p_bdgcalc <> '1' THEN
            spACbudg0000MM( 'AD', p_compcode, ip_slipinno, '', '', p_userid, p_reasondiv, p_reasontext,IO_CURSOR, MESSAGE) ;
        END IF;

    ELSIF ( p_div = 'CC' ) THEN
        -- 회계전표내역 상신취소

        p_bdgcalc2 := '2' ;
        FOR  rec IN
        (
            SELECT  value1
            FROM    SYSPARAMETERMANAGE
            WHERE   parametercode = 'accslipbdgcalc'
        )
        LOOP
            p_bdgcalc2 := rec.value1   ;
        END LOOP;

        IF p_bdgcalc2 <> '1' THEN
            spACbudg0000MM('MI', p_compcode, ip_slipinno, '', '', p_userid, p_reasondiv, p_reasontext,IO_CURSOR, MESSAGE) ;
        END IF;

        UPDATE  ACORDM
            SET slipinstate = p_slipinstate,
                updatedt = SYSDATE,
                uempcode = p_iempcode
        WHERE   compcode = p_compcode
            AND slipinno = ip_slipinno;

    -- 회계전표상세 순서변경
    elsif (p_div = 'SC') then
        v_temp := 0;

        select  count(*) into v_temp
        from    DUAL
        where   exists (select  *
                        from    ACORDD
                        where   compcode = p_compcode
                                and slipinno = ip_slipinno
                                and slipinseq <> rptseq);

        if v_temp = 1 then
            for rec in (
                select  min(slipinseq) as minseq,
                        max(slipinseq) as maxseq
                from    ACORDD
                where   compcode = p_compcode
                        and slipinno = ip_slipinno
                        and slipinseq <> rptseq)
            loop
                p_minseq := rec.minseq;
                p_maxseq := rec.maxseq;
            end loop;

            -- 기존자료 백업
            execute immediate 'delete from VGT.TT_ACACC0000PM_ACORDD2';
            insert into VGT.TT_ACACC0000PM_ACORDD2
            select  *
            from    ACORDD
            where   compcode = p_compcode
                    and slipinno = ip_slipinno
                    and slipinseq between p_minseq and p_maxseq;

            execute immediate 'delete from VGT.TT_ACACC0000PM_ACORDS';
            insert into VGT.TT_ACACC0000PM_ACORDS
            select  a.compcode,
                    a.slipinno,
                    b.rptseq,
                    a.mngclucode,
                    a.seq,
                    a.mngcluval,
                    a.mngcludec,
                    a.insertdt,
                    a.iempcode,
                    a.updatedt,
                    a.uempcode
            from    ACORDS a
                    join ACORDD b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
                        and a.slipinseq = b.slipinseq
            where   a.compcode = p_compcode
                    and a.slipinno = ip_slipinno
                    and a.slipinseq between p_minseq and p_maxseq;

            -- 기존자료 삭제
            delete
            from    ACORDS
            where   compcode = p_compcode
                    and slipinno = ip_slipinno
                    and slipinseq between p_minseq and p_maxseq;

            delete
            from    ACORDD
            where   compcode = p_compcode
                    and slipinno = ip_slipinno
                    and slipinseq between p_minseq and p_maxseq;

            -- 백업자료 복원
            insert into ACORDD
                (compcode, slipinno, slipinseq, dcdiv, acccode, plantcode, debamt, creamt, slipdate, slipnum, remark1, remark2, taxno, datadiv, rptseq, insertdt, iempcode, updatedt, uempcode)
            select  compcode,
                    slipinno,
                    rptseq,
                    dcdiv,
                    acccode,
                    plantcode,
                    debamt,
                    creamt,
                    slipdate,
                    slipnum,
                    remark1,
                    remark2,
                    taxno,
                    datadiv,
                    rptseq,
                    insertdt,
                    iempcode,
                    updatedt,
                    uempcode
            from    VGT.TT_ACACC0000PM_ACORDD2 a
            order by a.rptseq;

            insert into ACORDS
                (compcode, slipinno, slipinseq, mngclucode, seq, mngcluval, mngcludec, insertdt, iempcode, updatedt, uempcode)
            select  compcode,
                    slipinno,
                    slipinseq,
                    mngclucode,
                    seq,
                    mngcluval,
                    mngcludec,
                    insertdt,
                    iempcode,
                    updatedt,
                    uempcode
            from    VGT.TT_ACACC0000PM_ACORDS
            order by slipinseq;

            -- 반제전표 순서변경
            update  ACORDRPYR a
            set     a.slipinseq = ( select  rptseq
                                    from    VGT.TT_ACACC0000PM_ACORDD2 b
                                    where   a.slipinseq = b.slipinseq)
            where   a.compcode = p_compcode
                    and a.slipinno = ip_slipinno
                    and a.slipinseq in (select  slipinseq
                                        from    VGT.TT_ACACC0000PM_ACORDD2
                                        where   slipinseq <> rptseq);

            update  ACORDRPYP a
            set     a.slipinseq = ( select  rptseq
                                    from    VGT.TT_ACACC0000PM_ACORDD2 b
                                    where   a.slipinseq = b.slipinseq)
            where   a.compcode = p_compcode
                    and a.slipinno = ip_slipinno
                    and a.slipinseq in (select  slipinseq
                                        from    VGT.TT_ACACC0000PM_ACORDD2
                                        where   slipinseq <> rptseq);

            update  ACORDRPYP a
            set     a.rpyslipinseq = (select  rptseq
                                      from    VGT.TT_ACACC0000PM_ACORDD2 b
                                      where   a.slipinseq = b.slipinseq)
            where   a.compcode = p_compcode
                    and a.rpyslipinno = ip_slipinno
                    and a.rpyslipinseq in ( select  slipinseq
                                            from    VGT.TT_ACACC0000PM_ACORDD2
                                            where   slipinseq <> rptseq);

--            -- 손익반영 순서변경
--            update  SFORDEP a
--            set     a.slipinseq = ( select  rptseq
--                                    from    VGT.TT_ACACC0000PM_ACORDD2 b
--                                    where   a.slipinseq = b.slipinseq)
--            where   a.compcode = p_compcode
--                    and a.slipinno = ip_slipinno
--                    and a.slipinseq in (select  slipinseq
--                                        from    VGT.TT_ACACC0000PM_ACORDD2
--                                        where   slipinseq <> rptseq);

--            -- 법인카드 순서변경
--            update  ACORDCARD a
--            set     a.slipinseq = ( select  rptseq
--                                    from    VGT.TT_ACACC0000PM_ACORDD2 b
--                                    where   a.slipinseq = b.slipinseq)
--            where   a.compcode = p_compcode
--                    and a.slipinno = ip_slipinno
--                    and a.slipinseq in (select  slipinseq
--                                        from    VGT.TT_ACACC0000PM_ACORDD2
--                                        where   slipinseq <> rptseq);

            MESSAGE := '순서변경' ;
        end if;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
