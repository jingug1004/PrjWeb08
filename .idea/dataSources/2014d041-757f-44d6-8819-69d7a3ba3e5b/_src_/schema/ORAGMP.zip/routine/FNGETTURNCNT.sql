CREATE FUNCTION fnGetTurncnt
-- ---------------------------------------------------------------
 -- 함 수 명			: fnGetTurncnt
 -- 작 성 자         : 조성희
 -- 작성일자         : 2008-10-22
 -- ---------------------------------------------------------------
 -- 함수설명			: 거래처의 회전일을 가져오는 함수이다.
 -- ---------------------------------------------------------------
(
    p_custcode   IN VARCHAR2 DEFAULT '' ,
    p_yearmonth        IN VARCHAR2 DEFAULT ''
)
RETURN NUMBER
AS
    p_turncnt NUMBER := 0;
BEGIN

    FOR  rec IN (   SELECT  TURNCNT AS alias1
                    FROM    SLTURNCUSTM
                    WHERE   YEARMONTH = p_yearmonth
                      AND   CUSTCODE = p_custcode
    )
    LOOP
        p_turncnt := rec.alias1 ;
    END LOOP;


   RETURN (p_turncnt);

EXCEPTION WHEN OTHERS THEN RETURN (p_turncnt);
END;
/
