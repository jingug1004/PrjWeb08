CREATE FUNCTION        F_GET_SORT_SEQ 
(
  V_EMPCODE  IN STRING
)
RETURN VARCHAR2
AS

  V_PAY_SORT_NO VARCHAR2(10);
  V_DEPT_SORT_NO VARCHAR2(1);
  V_DEPT_SORT_NO_D VARCHAR2(1);
  V_GRADEDIV    HR_HC_EMPBAS_0.GRAD_CD%TYPE;
  V_DEPTCODE    HR_HC_EMPBAS_0.DEPT_CD%TYPE;
  V_OFFICER_YN HR_CO_CLASCD_0.OFFICER_YN%TYPE;          --? 모르겠다
  V_SORT_NO    HR_CO_CLASCD_0.SORT_NO%TYPE;             --? 모르겠다


BEGIN

        IF V_EMPCODE = 'HANAPH' THEN                     --사원코드
                V_PAY_SORT_NO := '1000000000';          --SORTING 번호
                RETURN V_PAY_SORT_NO;
        END IF;
  
   /* 변수 초기화 */
   V_PAY_SORT_NO := '';
   V_DEPT_SORT_NO := '';
   V_DEPT_SORT_NO_D := '';
   
   /* 사번에 따른 직급&부서코드 가져옴 */
   SELECT NVL(GRADEDIV,''), NVL(DEPTCODE,'')
     INTO V_GRADEDIV, V_DEPTCODE
     FROM CMEMPM
    WHERE EMPCODE = V_EMPCODE
      AND GRADEDIV IS NOT NULL AND DEPTCODE IS NOT NULL;
    
   /* 부서코드에 따른 내근직/상신/하길/영업부 순으로 분리
    SELECT MIN(DECODE(DEPT_CD,'0001','1','0021','2','0020','3','0023','4','9'))   CHOE 20160713 BAK 
   */
   /* 부서코드에 따른 내근직/생산본부/영업본부/영업부 순으로 분리 */
   SELECT MIN(DECODE(DEPTCODE,'0001','1','0412','2','0437','3','0023','4','9'))
     INTO V_DEPT_SORT_NO
     FROM CMDEPTM
    WHERE USEYN = 'Y'
  CONNECT BY  DEPTCODE = PRIOR PREDEPTCODE
    START WITH  DEPTCODE = V_DEPTCODE;    
   
   /* 부서코드에 따른 영업부 detail 종병/로컬/세미/도매  순으로 분리 */ 
   SELECT MIN(DECODE(DEPTCODE,'0040','1','0041','2','0042','3','0111','4','9'))
     INTO V_DEPT_SORT_NO_D
     FROM CMDEPTM
    WHERE USEYN = 'Y'
  CONNECT BY  DEPTCODE = PRIOR PREDEPTCODE
    START WITH  DEPTCODE = V_DEPTCODE;
    
    
   /* 직급코드에 따른 임원여부&직급순서 가져옴 */
   SELECT USEDIV, divcode 
     INTO V_OFFICER_YN, V_SORT_NO                  --?
     FROM CMCOMMONM                --직급 commonm form
    WHERE DIVCODE = V_GRADEDIV
      AND CMMCODE = 'PS01'
      AND USEDIV   = 'Y';
    

   /* A 1자리*/
   IF V_OFFICER_YN = 'Y' THEN
      V_PAY_SORT_NO := V_PAY_SORT_NO||'1';
   ELSE
      V_PAY_SORT_NO := V_PAY_SORT_NO||'2';
   END IF;
   
   /* B 1자리*/
   IF V_OFFICER_YN = 'Y' THEN
      V_PAY_SORT_NO := V_PAY_SORT_NO||'0';
   ELSE    
      V_PAY_SORT_NO := V_PAY_SORT_NO||V_DEPT_SORT_NO;      
   END IF;
   
   /* C 5자리*/ 
   IF V_OFFICER_YN = 'Y' THEN
      V_PAY_SORT_NO := V_PAY_SORT_NO||'00000';
   ELSE 
      IF V_DEPTCODE = '0012' THEN  /*총무부인 경우*/
         IF V_DEPT_SORT_NO_D = '9' THEN /*상단에서 9를 가져옴*/
            V_DEPT_SORT_NO_D := '1';
         END IF;   
      END IF;
      V_PAY_SORT_NO := V_PAY_SORT_NO||V_DEPT_SORT_NO_D;     
      V_PAY_SORT_NO := V_PAY_SORT_NO||V_DEPTCODE;
   END IF;    

   /* D 3자리*/
   IF LENGTH(V_SORT_NO) = 1 THEN
      V_PAY_SORT_NO := V_PAY_SORT_NO||'00'||V_SORT_NO;
   END IF;
   
   IF LENGTH(V_SORT_NO) = 2 THEN
      V_PAY_SORT_NO := V_PAY_SORT_NO||'0'||V_SORT_NO;
   END IF;
   
   IF LENGTH(V_SORT_NO) = 3 THEN
      V_PAY_SORT_NO := V_PAY_SORT_NO||V_SORT_NO;
   END IF;
  
  DBMS_OUTPUT.PUT_LINE(' V_PAY_SORT_NO:'||V_PAY_SORT_NO);
  RETURN V_PAY_SORT_NO;
  
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    IF V_PAY_SORT_NO IS NULL THEN
      V_PAY_SORT_NO := '99999';
    END IF;
    RETURN V_PAY_SORT_NO;
END;
/
