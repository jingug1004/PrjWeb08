CREATE FUNCTION fnAcAutoORDamt
-- ---------------------------------------------------------------
-- 함 수 명            : fnAcAutoORDamt
-- 작 성 자         : 민승기
-- 작성일자         : 2010-12-03
-- ---------------------------------------------------------------
-- 함수설명            : 회계자동분개 금액정의
-- ---------------------------------------------------------------
(
    p_amtdiv      IN VARCHAR2 DEFAULT ' ',
    p_accamtdiv   IN VARCHAR2 DEFAULT ' ',
    p_acccalcdiv  IN VARCHAR2 DEFAULT ' ',
    p_accsamtdiv  IN VARCHAR2 DEFAULT ' ',

    p_trn1amt     IN FLOAT DEFAULT NULL,
    p_trn2amt     IN FLOAT DEFAULT NULL,
    p_trn3amt     IN FLOAT DEFAULT NULL,
    p_trn4amt     IN FLOAT DEFAULT NULL,
    p_trn5amt     IN FLOAT DEFAULT NULL,
    p_trn6amt     IN FLOAT DEFAULT NULL,
    p_trn7amt     IN FLOAT DEFAULT NULL,
    p_trn8amt     IN FLOAT DEFAULT NULL,
    p_trn9amt     IN FLOAT DEFAULT NULL,
    p_trn10amt    IN FLOAT DEFAULT NULL,
    p_trn11amt    IN FLOAT DEFAULT NULL,
    p_trn12amt    IN FLOAT DEFAULT NULL,
    p_trn13amt    IN FLOAT DEFAULT NULL,
    p_trn14amt    IN FLOAT DEFAULT NULL,
    p_trn15amt    IN FLOAT DEFAULT NULL,
    p_trn16amt    IN FLOAT DEFAULT NULL,
    p_trn17amt    IN FLOAT DEFAULT NULL,
    p_trn18amt    IN FLOAT DEFAULT NULL,
    p_trn19amt    IN FLOAT DEFAULT NULL,
    p_trn20amt    IN FLOAT DEFAULT NULL,
    p_trn21amt    IN FLOAT DEFAULT NULL,
    p_trn22amt    IN FLOAT DEFAULT NULL,
    p_trn23amt    IN FLOAT DEFAULT NULL,
    p_trn24amt    IN FLOAT DEFAULT NULL,
    p_trn25amt    IN FLOAT DEFAULT NULL,
    p_trn26amt    IN FLOAT DEFAULT NULL,
    p_trn27amt    IN FLOAT DEFAULT NULL,
    p_trn28amt    IN FLOAT DEFAULT NULL,
    p_trn29amt    IN FLOAT DEFAULT NULL,
    p_trn30amt    IN FLOAT DEFAULT NULL
)
RETURN FLOAT
AS
   p_amt1            FLOAT(53);
   p_amt2            FLOAT(53);
   p_rtn             FLOAT(53);
BEGIN
    p_amt1 := case p_accamtdiv when '01' then nvl(p_trn1amt, 0)
                               when '02' then nvl(p_trn2amt, 0)
                               when '03' then nvl(p_trn3amt, 0)
                               when '04' then nvl(p_trn4amt, 0)
                               when '05' then nvl(p_trn5amt, 0)
                               when '06' then nvl(p_trn6amt, 0)
                               when '07' then nvl(p_trn7amt, 0)
                               when '08' then nvl(p_trn8amt, 0)
                               when '09' then nvl(p_trn9amt, 0)
                               when '10' then nvl(p_trn10amt, 0)
                               when '11' then nvl(p_trn11amt, 0)
                               when '12' then nvl(p_trn12amt, 0)
                               when '13' then nvl(p_trn13amt, 0)
                               when '14' then nvl(p_trn14amt, 0)
                               when '15' then nvl(p_trn15amt, 0)
                               when '16' then nvl(p_trn16amt, 0)
                               when '17' then nvl(p_trn17amt, 0)
                               when '18' then nvl(p_trn18amt, 0)
                               when '19' then nvl(p_trn19amt, 0)
                               when '20' then nvl(p_trn20amt, 0)
                               when '21' then nvl(p_trn21amt, 0)
                               when '22' then nvl(p_trn22amt, 0)
                               when '23' then nvl(p_trn23amt, 0)
                               when '24' then nvl(p_trn24amt, 0)
                               when '25' then nvl(p_trn25amt, 0)
                               when '26' then nvl(p_trn26amt, 0)
                               when '27' then nvl(p_trn27amt, 0)
                               when '28' then nvl(p_trn28amt, 0)
                               when '29' then nvl(p_trn29amt, 0)
                               when '30' then nvl(p_trn30amt, 0)
                               else 0
                               end;

    p_amt2 := case p_accsamtdiv when '01' then nvl(p_trn1amt, 0)
                                when '02' then nvl(p_trn2amt, 0)
                                when '03' then nvl(p_trn3amt, 0)
                                when '04' then nvl(p_trn4amt, 0)
                                when '05' then nvl(p_trn5amt, 0)
                                when '06' then nvl(p_trn6amt, 0)
                                when '07' then nvl(p_trn7amt, 0)
                                when '08' then nvl(p_trn8amt, 0)
                                when '09' then nvl(p_trn9amt, 0)
                                when '10' then nvl(p_trn10amt, 0)
                                when '11' then nvl(p_trn11amt, 0)
                                when '12' then nvl(p_trn12amt, 0)
                                when '13' then nvl(p_trn13amt, 0)
                                when '14' then nvl(p_trn14amt, 0)
                                when '15' then nvl(p_trn15amt, 0)
                                when '16' then nvl(p_trn16amt, 0)
                                when '17' then nvl(p_trn17amt, 0)
                                when '18' then nvl(p_trn18amt, 0)
                                when '19' then nvl(p_trn19amt, 0)
                                when '20' then nvl(p_trn20amt, 0)
                                when '21' then nvl(p_trn21amt, 0)
                                when '22' then nvl(p_trn22amt, 0)
                                when '23' then nvl(p_trn23amt, 0)
                                when '24' then nvl(p_trn24amt, 0)
                                when '25' then nvl(p_trn25amt, 0)
                                when '26' then nvl(p_trn26amt, 0)
                                when '27' then nvl(p_trn27amt, 0)
                                when '28' then nvl(p_trn28amt, 0)
                                when '29' then nvl(p_trn29amt, 0)
                                when '30' then nvl(p_trn30amt, 0)
                                else 0
                                end;

    p_rtn := case p_acccalcdiv when '+' then p_amt1 + p_amt2
                               when '-' then p_amt1 - p_amt2
                               else p_amt1
                               end;

    p_rtn := case when p_amtdiv = '-' then -p_rtn else p_rtn end;

    return (p_rtn);
END;
/
