CREATE FUNCTION fnGetYearCnt(
-- ---------------------------------------------------------------
 -- 함 수 명			: fnGetYearCnt
 -- 작 성 자         : 최용석
 -- 작성일자         : 2016-01-15
 -- ---------------------------------------------------------------
 -- 함수설명			: 조회일자의 년일수 구하기
 -- ---------------------------------------------------------------


	p_date IN VARCHAR2 DEFAULT ''
)
RETURN NUMBER
AS
	p_yearcnt NUMBER(10,0);

BEGIN
    p_yearcnt := FNDATEDIFF('DAY', SUBSTR(p_date, 0, 4) || '-01-01', SUBSTR(p_date, 0, 4) || '-12-31') + 1 ;
	RETURN (p_yearcnt);

	EXCEPTION WHEN OTHERS THEN RETURN '';
END;
/
