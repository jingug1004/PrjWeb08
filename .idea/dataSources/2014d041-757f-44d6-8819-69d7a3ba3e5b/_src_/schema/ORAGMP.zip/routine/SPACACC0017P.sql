CREATE PROCEDURE        spACacc0017P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0017P
 -- 작 성 자         : 최용석
 -- 작성일자         : 2017-09-28
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 법인카드 전표를 생성하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '',

    p_compcode      IN VARCHAR2 DEFAULT '',
    p_datediv       IN VARCHAR2 DEFAULT '',
    p_slipsdate     IN VARCHAR2 DEFAULT '',
    p_slipedate     IN VARCHAR2 DEFAULT '',
    p_empdiv        IN VARCHAR2 DEFAULT '',
    p_cardno        IN VARCHAR2 DEFAULT '',
    p_deptcode      IN VARCHAR2 DEFAULT '',
    p_empcode       IN VARCHAR2 DEFAULT '',
    p_custname      IN VARCHAR2 DEFAULT '',
    p_acccode       IN VARCHAR2 DEFAULT '',
    p_confdiv       IN VARCHAR2 DEFAULT '',
    p_crtdiv        IN VARCHAR2 DEFAULT '',
    p_cancel        IN VARCHAR2 DEFAULT '',

    p_card_no       IN VARCHAR2 DEFAULT '',
    p_use_dt        IN VARCHAR2 DEFAULT '',
    p_use_tm        IN VARCHAR2 DEFAULT '',
    p_card_ok_no    IN VARCHAR2 DEFAULT '',
    p_use_gubun     IN VARCHAR2 DEFAULT '',
    p_mod_dt        IN VARCHAR2 DEFAULT '',
    p_gongjae_yn    IN VARCHAR2 DEFAULT '',
    p_use_detail    IN VARCHAR2 DEFAULT '',
    p_conf_yn       IN VARCHAR2 DEFAULT '',
    p_jukyo         IN VARCHAR2 DEFAULT '',
    p_iempcode      IN VARCHAR2 DEFAULT '',

    p_slipinno      IN VARCHAR2 DEFAULT '',
    p_slipinseq     IN NUMBER DEFAULT 0,
    p_seq           IN NUMBER DEFAULT 0,
    p_slipdate      IN VARCHAR2 DEFAULT '',

    p_userid        IN VARCHAR2 DEFAULT '',
    p_reasondiv     IN VARCHAR2 DEFAULT '',
    p_reasontext    IN VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    ip_acautorcode  VARCHAR2(10) := 'A04050';
    ip_taxno        VARCHAR2(20);
BEGIN

    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo (userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    if ( p_div = 'S') then
        spHANALINK_IBK('C', p_userid, p_reasondiv, p_reasontext, MESSAGE);

        merge into IBK_ACQUIRE_DATA a
        using (
            select  a.seq
            from    IBK_ACQUIRE_DATA a
                    left join ACORDM b
                        on b.compcode = p_compcode
                        and a.junpyo_no = b.slipinno
            where   (p_datediv = '0' and a.use_dt between replace(p_slipsdate, '-', '') and replace(p_slipedate, '-', '') or
                     p_datediv = '1' and a.crt_dt between to_date(p_slipsdate, 'yyyy-MM-dd') and to_date(p_slipedate, 'yyyy-MM-dd'))
                    and b.compcode is null) b
        on (a.seq = b.seq)
        when matched
        then
            update set a.junpyo_yn = '1',
                       a.junpyo_no = null;

    end if;

    -- 카드전표내역 검색
    if ( p_div = 'S' and p_cancel = 'N') then
        open IO_CURSOR for
        select  'N' as seldiv                                                       -- 선택
                ,FNstuff(FNstuff(a.use_dt,5,0,'-'),8,0,'-') as mod_dt               -- 수정일자
                ,FNstuff(FNstuff(a.use_dt,5,0,'-'),8,0,'-') as use_dt               -- 사용일자
                ,FNstuff(FNstuff(a.use_tm,3,0,':'),6,0,':') as use_tm               -- 사용시간
                ,b.cardno as card_no                                                -- 카드번호
                ,a.card_ok_no as card_ok_no                                         -- 승인번호
                ,case when a.use_gubun = '03' then '승인' else '취소' end as use_gubun  -- 사용구분
                ,b.empcode                                                          -- 사용사원
                ,c.empname                                                          -- 사용사원명
                ,c.deptcode                                                         -- 부서코드
                ,d.deptname                                                         -- 부서명
                ,a.use_amt                                                          -- 사용금액
                ,a.saupjang_nm                                                      -- 가맹점명
                ,a.vendor_mmc_name                                                  -- 업종
                ,FNstuff(FNstuff(a.saup_no,4,0,'-'),7,0,'-') as saup_no             -- 사업자번호
                ,case a.tax_gb when '1' then '일반' when '2' then '간이' when '3' then '면세' when '4' then '비영리' when '9' then '휴업' else '폐업' end as tax_gb   -- 과세구분
                ,case when a.gongjae_yn = 'Y' then '공제가능' else a.gongjae_yn end as gongjae_yn   -- 공제여부
                ,a.use_detail                                                       -- 상세내역
                ,a.gaejung_cd as acccode                                            -- 계정코드
                ,e.accname                                                          -- 계정명
                ,a.teamjang_conf_yn as conf_yn                                      -- 입력상태
                ,a.salecamp_conf_sabun                                              -- 입력사원
                ,f.empname as confempname                                           -- 입력사원명
                ,a.jukyo                                                            -- 적요
                ,case when a.junpyo_yn = '1' then '미생성' else '생성' end as junpyo_yn  -- 전표생성
                ,FNstuff(g.slipinno,9,0,'-') as junpyo_no                           -- 전표번호
                ,a.seq                                                              -- 순번

        from    IBK_ACQUIRE_DATA a
                join ACCARDM b
                    on b.compcode = p_compcode
                    and a.card_no = replace(b.cardno,'-','')
                    and a.card_no like '%' || replace(p_cardno,'-','') || '%'
                    and nvl(b.empcode,' ') like p_empcode || '%'
                left join CMEMPM c
                    on b.empcode = c.empcode
                left join CMDEPTM d
                    on c.deptcode = d.deptcode
                left join ACACCM e
                    on a.gaejung_cd = e.acccode
                left join CMEMPM f
                    on a.salecamp_conf_sabun = f.empcode
                left join ACORDM g
                    on g.compcode = p_compcode
                    and a.junpyo_no = g.slipinno

        where   (p_datediv = '0' and a.use_dt between replace(p_slipsdate, '-', '') and replace(p_slipedate, '-', '') or
                 p_datediv = '1' and a.crt_dt between to_date(p_slipsdate, 'yyyy-MM-dd') and to_date(p_slipedate, 'yyyy-MM-dd'))
                and (p_empdiv = '0' or
                     p_empdiv = '1' and a.biz_nonbiz_gb = '2' or
                     p_empdiv = '2' and a.biz_nonbiz_gb <> '2')
                and nvl(c.deptcode,' ') like p_deptcode || '%'
                and nvl(a.saupjang_nm,' ') like '%' || p_custname || '%'
                and nvl(a.gaejung_cd,' ') like p_acccode || '%'
                and (p_confdiv = '0' or
                     p_confdiv = '1' and a.teamjang_conf_yn <> 'Y' or
                     p_confdiv = '2' and a.teamjang_conf_yn = 'Y')
                and (p_crtdiv = '0' or
                     p_crtdiv = '1' and g.slipinno is null or
                     p_crtdiv = '2' and g.slipinno is not null)

        order by a.use_dt, a.use_tm, a.card_no;

    elsif ( p_div = 'S' and p_cancel = 'Y') then
        execute immediate 'delete from VGT.TT_HANALINK_IBK_ACQUIRE_DATA';
        insert into VGT.TT_HANALINK_IBK_ACQUIRE_DATA
            (
                card_num
                ,approve_date
                ,approve_time
                ,approve_num
                ,gubun
            )
        select   a.card_no
                ,a.use_dt
                ,a.use_tm
                ,a.card_ok_no
                ,'03'
        from    IBK_ACQUIRE_DATA a
                join ACCARDM b
                    on b.compcode = p_compcode
                    and a.card_no = replace(b.cardno,'-','')
                    and a.card_no like '%' || replace(p_cardno,'-','') || '%'
                    and nvl(b.empcode,' ') like p_empcode || '%'
                left join CMEMPM c
                    on b.empcode = c.empcode
                left join CMDEPTM d
                    on c.deptcode = d.deptcode
                left join ACACCM e
                    on a.gaejung_cd = e.acccode
                left join CMEMPM f
                    on a.salecamp_conf_sabun = f.empcode
                left join ACORDM g
                    on g.compcode = p_compcode
                    and a.junpyo_no = g.slipinno

        where   (p_datediv = '0' and a.use_dt between replace(p_slipsdate, '-', '') and replace(p_slipedate, '-', '') or
                 p_datediv = '1' and a.crt_dt between to_date(p_slipsdate, 'yyyy-MM-dd') and to_date(p_slipedate, 'yyyy-MM-dd'))
                and (p_empdiv = '0' or
                     p_empdiv = '1' and a.biz_nonbiz_gb = '2' or
                     p_empdiv = '2' and a.biz_nonbiz_gb <> '2')
                and nvl(c.deptcode,' ') like p_deptcode || '%'
                and nvl(a.saupjang_nm,' ') like '%' || p_custname || '%'
                and nvl(a.gaejung_cd,' ') like p_acccode || '%'
                and (p_confdiv = '0' or
                     p_confdiv = '1' and a.teamjang_conf_yn <> 'Y' or
                     p_confdiv = '2' and a.teamjang_conf_yn = 'Y')
                and (p_crtdiv = '0' or
                     p_crtdiv = '1' and g.slipinno is null or
                     p_crtdiv = '2' and g.slipinno is not null)
                and a.use_gubun = '04';

        open IO_CURSOR for
        select  'N' as seldiv                                                       -- 선택
                ,FNstuff(FNstuff(a.use_dt,5,0,'-'),8,0,'-') as mod_dt               -- 수정일자
                ,FNstuff(FNstuff(a.use_dt,5,0,'-'),8,0,'-') as use_dt               -- 사용일자
                ,FNstuff(FNstuff(a.use_tm,3,0,':'),6,0,':') as use_tm               -- 사용시간
                ,b.cardno as card_no                                                -- 카드번호
                ,a.card_ok_no as card_ok_no                                         -- 승인번호
                ,case when a.use_gubun = '03' then '승인' else '취소' end as use_gubun  -- 사용구분
                ,b.empcode                                                          -- 사용사원
                ,c.empname                                                          -- 사용사원명
                ,c.deptcode                                                         -- 부서코드
                ,d.deptname                                                         -- 부서명
                ,a.use_amt                                                          -- 사용금액
                ,a.saupjang_nm                                                      -- 가맹점명
                ,a.vendor_mmc_name                                                  -- 업종
                ,FNstuff(FNstuff(a.saup_no,4,0,'-'),7,0,'-') as saup_no             -- 사업자번호
                ,case a.tax_gb when '1' then '일반' when '2' then '간이' when '3' then '면세' when '4' then '비영리' when '9' then '휴업' else '폐업' end as tax_gb   -- 과세구분
                ,case when a.gongjae_yn = 'Y' then '공제가능' else a.gongjae_yn end as gongjae_yn   -- 공제여부
                ,a.use_detail                                                       -- 상세내역
                ,a.gaejung_cd as acccode                                            -- 계정코드
                ,e.accname                                                          -- 계정명
                ,a.teamjang_conf_yn as conf_yn                                      -- 입력상태
                ,a.salecamp_conf_sabun                                              -- 입력사원
                ,f.empname as confempname                                           -- 입력사원명
                ,a.jukyo                                                            -- 적요
                ,case when a.junpyo_yn = '1' then '미생성' else '생성' end as junpyo_yn  -- 전표생성
                ,FNstuff(g.slipinno,9,0,'-') as junpyo_no                           -- 전표번호
                ,a.seq                                                              -- 순번

        from    IBK_ACQUIRE_DATA a
                join ACCARDM b
                    on b.compcode = p_compcode
                    and a.card_no = replace(b.cardno,'-','')
                    and a.card_no like '%' || replace(p_cardno,'-','') || '%'
                    and nvl(b.empcode,' ') like p_empcode || '%'
                left join CMEMPM c
                    on b.empcode = c.empcode
                left join CMDEPTM d
                    on c.deptcode = d.deptcode
                left join ACACCM e
                    on a.gaejung_cd = e.acccode
                left join CMEMPM f
                    on a.salecamp_conf_sabun = f.empcode
                left join ACORDM g
                    on g.compcode = p_compcode
                    and a.junpyo_no = g.slipinno

        where   (a.card_no, a.card_ok_no) in (select  card_num, approve_num
                                              from    VGT.TT_HANALINK_IBK_ACQUIRE_DATA)

        order by a.card_no, a.use_dt, a.use_tm, a.use_gubun;

    elsif ( p_div = 'SA') then
        open IO_CURSOR for
        select  *
        from    ACAUTORULE
        where   acautorcode = ip_acautorcode;

    -- 카드전표내역 선택저장
    elsif ( p_div = 'U') then
        update  IBK_ACQUIRE_DATA a
        set     use_dt = replace(p_mod_dt,'-','')
                ,use_detail = p_use_detail
                ,gaejung_cd = p_acccode
                ,teamjang_conf_yn = p_conf_yn
                ,jukyo = p_jukyo
                ,salecamp_conf_sabun = p_iempcode
        where   card_no = replace(p_card_no,'-','')
                and use_dt = replace(p_use_dt,'-','')
                and use_tm = replace(p_use_tm,':','')
                and card_ok_no = p_card_ok_no
                and use_gubun = case when p_use_gubun = '승인' then '03' else '04' end;

    -- 회계전표상세 생성
    elsif (p_div = 'I') then
        --세금계산서 생성.
        ip_taxno := substr(p_slipinno, 1, 6) || '01';
        
        for rec in (
            select  ip_taxno || substr('00000' || to_char((nvl(substr(max(taxno), -5, 5), 0) + 1)), -5, 5) as taxno
            from    ACTAXM
            where   compcode = p_compcode
                    --and plantcode = p_plantcode
                    and taxno like ip_taxno || '%'
                    and saleinyn = 'N')
        loop
            ip_taxno := rec.taxno;
        end loop;

        insert into ACTAXM
            (
                compcode,
                plantcode,
                taxno,        -- yyyymm03nnnnn
                taxdiv,       -- 계산서 구분(  select * from cmcommonm where cmmcode = 'AC60'  )
                iotaxdiv,     -- 매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
                sdeptcode,
                taxdate,
                custcode,
                custname,
                businessno,
                biznotype,    -- 사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
                blankcnt,
                amt,
                vat,
                vatamt,
                purposediv,   -- 영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
                credittot,
                electaxyn,    -- 전자세금계산서여부
                purdiv,
                saleinyn,     -- 영업자동생성여부
                insertdt,
                iempcode
            )
        select  p_compcode,
                b.plantcode,
                ip_taxno,
                '207',        -- 매입-카과
                '01',
                b.deptcode,
                FNstuff(FNstuff(a.use_dt,5,0,'-'),8,0,'-'),
                c.custcode,
                c.custname,
                c.businessno,
                '01',
                0,
                round(a.use_amt * 10 / 11, 0),
                a.use_amt - round(a.use_amt * 10 / 11, 0),
                a.use_amt,
                '02',
                a.use_amt,
                'N',
                '0',
                'N',
                sysdate,
                p_iempcode
        from	  IBK_ACQUIRE_DATA a
                join CMEMPM b
                    on b.empcode = p_iempcode
                left join (
                    select  a.custcode, a.custname, a.businessno
                    from    CMCUSTM a
                    where   a.custcode in ( select  min(b.custcode) as custcode
                                            from	  IBK_ACQUIRE_DATA a
                                                    left join CMCUSTM b
                                                        on a.saup_no = replace(b.businessno,'-','')
                                            where	  a.seq = p_seq)
                ) c on 1 = 1
        where	  a.seq = p_seq
                and a.gongjae_yn = 'Y';

        insert into ACTAXD
            (
                compcode,
                plantcode,
                taxno, -- yyyymm03nnnnn
                seq,
                itemnm, -- item
                amt,
                vat,
                vatamt,
                insertdt,
                iempcode
            )
        select  p_compcode,
                b.plantcode,
                ip_taxno,
                1,
                a.use_detail,
                round(a.use_amt * 10 / 11, 0),
                a.use_amt - round(a.use_amt * 10 / 11, 0),
                a.use_amt,
                sysdate,
                p_iempcode
        from	  IBK_ACQUIRE_DATA a
                join CMEMPM b
                    on b.empcode = p_iempcode
        where	  a.seq = p_seq
                and a.gongjae_yn = 'Y';


        insert into ACORDD
            (
                compcode,
                slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                taxno,
                datadiv,
                rptseq,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                p_slipinseq + row_number() over(order by b.acautoseq),
                b.dcdiv,
                case when b.accamtdiv = '01' then a.gaejung_cd else b.acacccode end,
                d.plantcode,
                case when b.dcdiv = '1'
                     then case when a.gongjae_yn = 'Y'
                          then case b.accamtdiv when '01' then round(a.use_amt * 10 / 11, 0) when '02' then a.use_amt - round(a.use_amt * 10 / 11, 0) else a.use_amt end
                          else case b.accamtdiv when '01' then a.use_amt when '02' then 0 else a.use_amt end
                          end * case when b.amtdiv = '+' then 1 else -1 end
                     else 0 end,
                case when b.dcdiv = '2'
                     then case when a.gongjae_yn = 'Y'
                          then case b.accamtdiv when '01' then round(a.use_amt * 10 / 11, 0) when '02' then a.use_amt - round(a.use_amt * 10 / 11, 0) else a.use_amt end
                          else case b.accamtdiv when '01' then a.use_amt when '02' then 0 else a.use_amt end
                          end * case when b.amtdiv = '+' then 1 else -1 end
                     else 0 end,
                p_slipdate,
                case when p_slipdate is null then '' else substr(p_slipinno, -5) end,
                case when b.dcdiv = '1' or c.crtdiv = '2' then a.use_detail else c.remark1 end,
                case when b.dcdiv = '1' or c.crtdiv = '2' then a.saupjang_nm else c.remark2 end,
                case when a.gongjae_yn = 'Y' and b.accamtdiv = '02' then ip_taxno else '' end,
                case when b.accamtdiv = '01' or c.crtdiv = '1' then to_char(a.seq) else '' end,
                p_slipinseq + row_number() over(order by b.acautoseq),
                sysdate,
                p_iempcode
        from	  IBK_ACQUIRE_DATA a
                join ACAUTORULESM b
                    on b.acautorcode = ip_acautorcode
                    and (a.gongjae_yn = 'Y' or b.accamtdiv <> '02')
                join ACAUTORULE c
                    on b.acautorcode = c.acautorcode
                join CMEMPM d
                    on d.empcode = p_iempcode
        where	  a.seq = p_seq
        order by b.acautoseq;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select	p_compcode,
                p_slipinno,
                d.slipinseq,
                c.mngclucode,
                row_number() over(partition by b.acautoseq order by c.seq),
                case c.mngclucode when 'S010' then e.custcode when 'S030' then h.bankcode when 'S040' then f.deptcode when 'S050' then p_iempcode when 'S060' then h.cardno when 'U081' then h.cardcls else '' end,
                case c.mngclucode when 'S010' then e.custname when 'S030' then j.bankname when 'S040' then g.deptname when 'S050' then f.empname when 'S060' then h.cardname when 'U081' then i.divname else '' end,
                sysdate,
                p_iempcode
        from	  IBK_ACQUIRE_DATA a
                join ACAUTORULESM b
                    on b.acautorcode = ip_acautorcode
                    and (a.gongjae_yn = 'Y' or b.accamtdiv <> '02')
                left join ACACCMNGM c
                    on case when b.accamtdiv = '01' then a.gaejung_cd else b.acacccode end = c.acccode
                    and b.dcdiv = c.dcdiv
                left join (
                    select  b.acautoseq, p_slipinseq + row_number() over(order by b.acautoseq) as slipinseq
                    from	  IBK_ACQUIRE_DATA a
                            join ACAUTORULESM b
                                on b.acautorcode = ip_acautorcode
                                and (a.gongjae_yn = 'Y' or b.accamtdiv <> '02')
                    where	  a.seq = p_seq
                ) d on b.acautoseq = d.acautoseq
                left join (
                    select  a.custcode, a.custname, a.businessno
                    from    CMCUSTM a
                    where   a.custcode in ( select  min(b.custcode) as custcode
                                            from	  IBK_ACQUIRE_DATA a
                                                    left join CMCUSTM b
                                                        on a.saup_no = replace(b.businessno,'-','')
                                            where	  a.seq = p_seq)
                ) e on 1 = 1
                left join CMEMPM f
                    on f.empcode = p_iempcode
                left join CMDEPTM g
                    on f.deptcode = g.deptcode
                left join ACCARDM h
                    on h.compcode = p_compcode
                    and a.card_no = replace(h.cardno,'-','')
                left join CMCOMMONM i
                    on i.cmmcode = 'AC17'
                    and h.cardcls = i.divcode
                left join CMBANKM j
                    on h.bankcode = j.bankcode
        where	  a.seq = p_seq
        order by b.acautoseq, c.seq;

        update  IBK_ACQUIRE_DATA
        set     junpyo_no = p_slipinno,
                junpyo_yn = '2'
        where	  seq = p_seq;

        select  count(*) into MESSAGE
        from    ACORDD a
        where   compcode = p_compcode
                and slipinno = p_slipinno;

    elsif (p_div = 'C') then
        execute immediate ' delete from VGT.TT_ACFUND0017P_ACORD ';
        -- 기존자료 부문별합계 임시파일 생성
        insert into VGT.TT_ACFUND0017P_ACORD
        select  row_number() over(order by a.card_no, case when a.dcdiv = '1' then a.datadiv else 'zzzzzzzzzz' end, min(a.slipinseq)) as slipinseq,
                a.dcdiv,
                a.acccode,
                max(a.plantcode) as plantcode,
                sum(a.debamt) as debamt,
                sum(a.creamt) as creamt,
                max(a.slipdate) as slipdate,
                max(a.slipnum) as slipnum,
                a.remark1,
                max(a.remark2) as remark2,
                a.taxno,
                case when a.dcdiv = '1' then a.datadiv else 'zzzzzzzzzz' end,
                a.mngclucode1,
                a.mngclucode2,
                a.mngclucode3,
                a.mngclucode4,
                a.mngclucode5,
                a.mngclucode6,
                a.mngcluval1,
                a.mngcluval2,
                a.mngcluval3,
                a.mngcluval4,
                a.mngcluval5,
                a.mngcluval6,
                max(a.mngcludec1) as mngcludec1,
                max(a.mngcludec2) as mngcludec2,
                max(a.mngcludec3) as mngcludec3,
                max(a.mngcludec4) as mngcludec4,
                max(a.mngcludec5) as mngcludec5,
                max(a.mngcludec6) as mngcludec6
        from (
            select  case when a.dcdiv = '1' then a.slipinseq else a.slipinseq + 1000 end as slipinseq,
                    max(a.dcdiv) as dcdiv,
                    max(a.acccode) as acccode,
                    max(a.plantcode) as plantcode,
                    max(a.debamt) as debamt,
                    max(a.creamt) as creamt,
                    max(a.slipdate) as slipdate,
                    max(a.slipnum) as slipnum,
                    max(a.remark1) as remark1,
                    max(a.remark2) as remark2,
                    max(a.taxno) as taxno,
                    max(a.datadiv) as datadiv,
                    max(case when b.seq = 1 then b.mngclucode else '' end) as mngclucode1,
                    max(case when b.seq = 2 then b.mngclucode else '' end) as mngclucode2,
                    max(case when b.seq = 3 then b.mngclucode else '' end) as mngclucode3,
                    max(case when b.seq = 4 then b.mngclucode else '' end) as mngclucode4,
                    max(case when b.seq = 5 then b.mngclucode else '' end) as mngclucode5,
                    max(case when b.seq = 6 then b.mngclucode else '' end) as mngclucode6,
                    max(case when b.seq = 1 then b.mngcluval else '' end) as mngcluval1,
                    max(case when b.seq = 2 then b.mngcluval else '' end) as mngcluval2,
                    max(case when b.seq = 3 then b.mngcluval else '' end) as mngcluval3,
                    max(case when b.seq = 4 then b.mngcluval else '' end) as mngcluval4,
                    max(case when b.seq = 5 then b.mngcluval else '' end) as mngcluval5,
                    max(case when b.seq = 6 then b.mngcluval else '' end) as mngcluval6,
                    max(case when b.seq = 1 then b.mngcludec else '' end) as mngcludec1,
                    max(case when b.seq = 2 then b.mngcludec else '' end) as mngcludec2,
                    max(case when b.seq = 3 then b.mngcludec else '' end) as mngcludec3,
                    max(case when b.seq = 4 then b.mngcludec else '' end) as mngcludec4,
                    max(case when b.seq = 5 then b.mngcludec else '' end) as mngcludec5,
                    max(case when b.seq = 6 then b.mngcludec else '' end) as mngcludec6,
                    max(c.card_no) as card_no
            from	  ACORDD a
                    left join ACORDS b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
                        and a.slipinseq = b.slipinseq
                    left join IBK_ACQUIRE_DATA c
                        on to_number(a.datadiv) = c.seq
            where   a.compcode = p_compcode
                    and a.slipinno = p_slipinno
            group by case when a.dcdiv = '1' then a.slipinseq else a.slipinseq + 1000 end
        ) a
        group by  a.dcdiv,
                  a.acccode,
                  a.remark1,
                  a.taxno,
                  case when a.dcdiv = '1' then a.datadiv else 'zzzzzzzzzz' end,
                  a.mngclucode1,
                  a.mngclucode2,
                  a.mngclucode3,
                  a.mngclucode4,
                  a.mngclucode5,
                  a.mngclucode6,
                  a.mngcluval1,
                  a.mngcluval2,
                  a.mngcluval3,
                  a.mngcluval4,
                  a.mngcluval5,
                  a.mngcluval6,
                  a.card_no;

        -- 기존자료 삭제
        delete
        from    ACORDS
        where   compcode = p_compcode
                and slipinno = p_slipinno;

        delete
        from    ACORDD
        where   compcode = p_compcode
                and slipinno = p_slipinno;

        -- 부문별자료 생성
        insert into ACORDD
            (
                compcode,
                slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                taxno,
                datadiv,
                rptseq,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                taxno,
                case when taxno is not null or datadiv = 'zzzzzzzzzz' then '' else datadiv end,
                slipinseq,
                sysdate,
                p_iempcode
        from	  VGT.TT_ACFUND0017P_ACORD;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                slipinseq,
                mngclucode1,
                1,
                mngcluval1,
                mngcludec1,
                sysdate,
                p_iempcode
        from	  VGT.TT_ACFUND0017P_ACORD
        where	  mngclucode1 is not null;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                slipinseq,
                mngclucode2,
                2,
                mngcluval2,
                mngcludec2,
                sysdate,
                p_iempcode
        from	  VGT.TT_ACFUND0017P_ACORD
        where	  mngclucode2 is not null;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                slipinseq,
                mngclucode3,
                3,
                mngcluval3,
                mngcludec3,
                sysdate,
                p_iempcode
        from	  VGT.TT_ACFUND0017P_ACORD
        where	  mngclucode3 is not null;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                slipinseq,
                mngclucode4,
                4,
                mngcluval4,
                mngcludec4,
                sysdate,
                p_iempcode
        from	  VGT.TT_ACFUND0017P_ACORD
        where	  mngclucode4 is not null;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                slipinseq,
                mngclucode5,
                5,
                mngcluval5,
                mngcludec5,
                sysdate,
                p_iempcode
        from	  VGT.TT_ACFUND0017P_ACORD
        where	  mngclucode5 is not null;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                slipinseq,
                mngclucode6,
                6,
                mngcluval6,
                mngcludec6,
                sysdate,
                p_iempcode
        from	  VGT.TT_ACFUND0017P_ACORD
        where	  mngclucode6 is not null;

    -- 엑셀 카드전표내역 저장
    elsif ( p_div = 'UE') then
        update  IBK_ACQUIRE_DATA a
        set     use_dt = replace(p_use_dt,'-','')
                ,use_tm = replace(p_use_tm,':','')
                ,gongjae_yn = case when p_gongjae_yn = '공제가능' then 'Y' when p_gongjae_yn = 'N' then 'N' else 'X' end
                ,use_detail = p_use_detail
                ,gaejung_cd = p_acccode
                ,teamjang_conf_yn = case when p_conf_yn = '완료' then 'Y' else 'N' end
                ,jukyo = p_jukyo
        where   seq = p_seq;

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
