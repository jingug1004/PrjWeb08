CREATE PROCEDURE        spACacc0301R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0301R
	-- 작 성 자         : 이영재
	-- 작성일자         : 2011-03-21
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-27
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 현금과현금등가물명세서를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------
	-- select * from ACORDSMM
	-- select * from CMCUSTM
	-- select * from ACACCM   -- dcdiv (차대구분) 1 - 차변 2- 대변
	-- select * from CMCOMMONM where cmmcode = 'AC02'
	-- select * from CMCOMMONM where cmmcode = 'AC04'
	-- select * from CMCOMMONM where cmmcode = 'AC081'
	-- select * from CMCOMMONM where cmmcode = 'AC252' - 매출채권명세서 찍을목록
	-- select * from ACORDDMM
	-- spACacc0301R 'S','100','1000','2011-01','1', '','','','N'


	p_div			 IN 	VARCHAR2 DEFAULT '',
	p_compcode		 IN 	VARCHAR2 DEFAULT '',
	p_plantcode 	 IN 	VARCHAR2 DEFAULT '',
	p_yearmonth 	 IN 	VARCHAR2 DEFAULT '',
	p_outputdiv 	 IN 	VARCHAR2 DEFAULT '',
	p_chshacccode	 IN 	VARCHAR2 DEFAULT '',
	p_userid		 IN 	VARCHAR2 DEFAULT '',
	p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
	p_reasontext	 IN 	VARCHAR2 DEFAULT '',
	MESSAGE 			OUT VARCHAR2,
	IO_CURSOR			OUT TYPES.DATASET
)
AS
	ip_chshacccode	  VARCHAR2(20) := p_chshacccode;
	p_odiv1 		  VARCHAR2(5);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);


	IF (p_outputdiv = '1')
	THEN
		--K-GAAP
		p_odiv1 := '20';
	END IF;

	IF (p_outputdiv = '2')
	THEN
		--IFRS
		p_odiv1 := '30';
	END IF;

	FOR rec IN (SELECT value1
				FROM   SYSPARAMETERMANAGE
				WHERE  parametercode = 'acccashcode')
	LOOP
		ip_chshacccode := rec.value1;
	END LOOP;

	IF (p_div = 'S')
	THEN
		-- 부문별
		OPEN IO_CURSOR FOR
			SELECT	 acccode,
					 accname,
					 mngcluval,
					 accremark,
					 totamt1,
					 totamt2,
					 plantcode,
					 yearmonth,
					 closediv
			FROM	 (SELECT acccode,
							 accname,
							 mngcluval,
							 accremark,
							 totamt1,
							 totamt2,
							 plantcode,
							 yearmonth,
							 closediv
					  FROM	 (SELECT a.acccode acccode, --  이월
									 c.accname accname,
									 a.mngcluval mngcluval,
									 D.accremark accremark,
									 a.totamt totamt1,
									 a.totamt totamt2,
									 p_plantcode plantcode,
									 p_yearmonth yearmonth,
									 p_outputdiv closediv
							  FROM	 (SELECT   a.acccode acccode,
											   '' mngcluval,
											   SUM(NVL(a.totdebamt, 0) - NVL(a.totcreamt, 0)) totamt
									  FROM	   ACORDDMM a
									  WHERE    plantcode LIKE p_plantcode
											   AND slipym = p_yearmonth --조회월조회
											   AND a.acccode = ip_chshacccode
											   AND (closediv = '10'
													OR closediv = p_odiv1) -- 출력구분 [K-GAAP, IFRS]
									  -- 현금계정
									  GROUP BY a.acccode
									  UNION ALL
									  SELECT   a.acccode acccode,
											   '' mngcluval,
											   SUM(NVL(a.totdebamt, 0) - NVL(a.totcreamt, 0)) totamt
									  FROM	   ACORDDMM a, CMCOMMONM b
									  WHERE    plantcode LIKE p_plantcode
											   AND slipym = p_yearmonth --시작월조회
											   AND b.cmmcode = 'AC256' -- 자금일보계정
											   AND a.acccode LIKE b.filter1 || '%'
											   AND TRIM(b.filter2) IS NULL
											   AND (closediv = '10'
													OR closediv = p_odiv1) -- 출력구분 [K-GAAP, IFRS]
									  GROUP BY a.acccode
									  UNION ALL
									  SELECT   a.acccode acccode,
											   a.mngcluval mngcluval,
											   SUM(NVL(a.totdebamt, 0) - NVL(a.totcreamt, 0)) totamt
									  FROM	   ACORDSMM a, CMCOMMONM b
									  WHERE    plantcode LIKE p_plantcode
											   AND slipym = p_yearmonth --시작월조회
											   AND b.cmmcode = 'AC256' -- 자금일보계정
											   AND a.acccode LIKE b.filter1 || '%'
											   AND a.mngclucode = b.filter2
											   AND TRIM(b.filter2) IS NOT NULL
											   AND (closediv = '10'
													OR closediv = p_odiv1) -- 출력구분 [K-GAAP, IFRS]
									  GROUP BY a.acccode, a.mngcluval) a
									 LEFT JOIN ACACCM c ON c.acccode = a.acccode
									 LEFT JOIN CMACCOUNTM D --select * from CMACCOUNTM
										 ON D.compcode = p_compcode
											AND D.accountno = a.mngcluval))
			WHERE	 totamt1 != 0
					 AND totamt2 != 0
			ORDER BY acccode, mngcluval;
	END IF;

	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
