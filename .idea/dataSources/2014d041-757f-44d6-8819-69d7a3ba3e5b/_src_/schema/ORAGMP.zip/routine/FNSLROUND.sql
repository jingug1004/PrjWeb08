CREATE FUNCTION fnSLround
-- ---------------------------------------------------------------
-- 함 수 명            : [dbo].[fnSLround]
-- 작 성 자         : 민승기
-- 작성일자         : 2014-01-14
-- 작 성 자         : 임 정호
-- 작성일자         : 2017-02-08
-- ---------------------------------------------------------------
-- 함수설명            : 달성율, 성장율, 금액단위 환산 등 계산
--                        @length    : 소수이하자릿수
--                        @func    : 반올림 = 0    ,    절사   = 1
-- ---------------------------------------------------------------
-- select [dbo].[fnSLround]('dalsung',1,3)
(
   p_div      IN VARCHAR2,
   ip_numer   IN FLOAT,         -- 분자
   ip_denom   IN FLOAT
)
   RETURN FLOAT
AS
   p_numer    FLOAT (53) := ip_numer;
   p_denom    FLOAT (53) := ip_denom;
   p_return   FLOAT (53);
   p_length   NUMBER (10, 0);                        -- 소수이하자릿수
   p_func     NUMBER (10, 0);                        -- 반올림 = 0    ,    절사 = 1
   p_biyL     NUMBER (10, 0);                        -- 달성   = 0    ,    성장 = 1
-- 분모
BEGIN
   p_length := 0;
   p_func := 0;
   p_biyL := 0;
   p_numer := NVL (p_numer, 0);
   p_denom := NVL (p_denom, 0);

   IF (p_div IN ('금액단위', 'won'))
   THEN
      p_length := 0;
      p_func := 1;
      p_biyL := 0;
   END IF;

   IF (p_div IN ('달성율', 'dalsung'))
   THEN
      p_length := 1;
      p_func := 1;
      p_biyL := 0;
   END IF;

   IF (p_div IN ('성장율', 'sungjang'))
   THEN
      p_length := 1;
      p_func := 0;
      p_biyL := 1;
   END IF;

   IF (p_div IN ('진도율', 'jindo'))
   THEN
      p_length := 1;
      p_func := 0;
      p_biyL := 1;
   END IF;

   IF (p_div IN ('진척율', 'jinchuk'))
   THEN
      p_length := 1;
      p_func := 0;
      p_biyL := 1;
   END IF;

   IF (p_div IN ('담보율', 'dambo'))
   THEN
      p_length := 1;
      p_func := 1;
      p_biyL := 0;
   END IF;

   IF (p_div IN ('비중', 'bijung'))
   THEN
      p_length := 1;
      p_func := 0;
      p_biyL := 0;
   END IF;

   IF (p_div IN ('구성비', 'gusung'))
   THEN
      p_length := 2;
      p_func := 0;
      p_biyL := 0;
   END IF;

   IF (p_div IN ('가동율', 'gadong'))
   THEN
      p_length := 1;
      p_func := 1;
      p_biyL := 0;
   END IF;

   IF (p_div IN ('반품율', 'banyul'))
   THEN
      p_length := 1;
      p_func := 1;
      p_biyL := 1;
   END IF;

   IF (p_div IN ('금액단위', 'won'))
   THEN
      IF (p_denom = 0)
      THEN
         p_denom := 1;

         IF p_func = 0
         THEN
            p_return := ROUND ( (p_numer / p_denom), p_length);
         ELSE
            p_return := TRUNC ( (p_numer / p_denom), p_length);
         END IF;
      ELSE
         IF p_func = 0
         THEN
            p_return := ROUND ( (p_numer / p_denom), p_length);
         ELSE
            p_return := TRUNC ( (p_numer / p_denom), p_length);
         END IF;
      END IF;
   END IF;

   IF NOT (p_div IN ('금액단위', 'won'))
   THEN
      IF (p_biyL = 0)
      THEN
         p_return :=
            CASE
               WHEN (p_denom = 0)
               THEN
                  0
               ELSE
                  CASE
                     WHEN p_func = 0
                     THEN
                        ROUND ( (p_numer / p_denom) * 100, p_length)
                     ELSE
                        TRUNC ( (p_numer / p_denom) * 100, p_length)
                  END
            END;
      ELSE
         p_return :=
            CASE
               WHEN ( (p_denom = 0) OR (p_numer = 0))
               THEN
                  0
               ELSE
                  CASE
                     WHEN p_func = 0
                     THEN
                        ROUND ( ( (p_numer / p_denom) - 1) * 100, p_length)
                     ELSE
                        TRUNC ( ( (p_numer / p_denom) - 1) * 100, p_length)
                  END
            END;
      END IF;
   END IF;


   RETURN (p_return);
END;
/
