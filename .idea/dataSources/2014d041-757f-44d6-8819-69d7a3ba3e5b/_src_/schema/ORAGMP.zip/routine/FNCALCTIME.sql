CREATE FUNCTION fnCalcTime
-- ---------------------------------------------------------------
 -- 함 수 명            : fnCalcTime
 -- 작 성 자         : 최인범
 -- 작성일자         : 2007-10-29
 -- ---------------------------------------------------------------
 -- 함수설명            : 초기준의 시분초 구하기
 -- ---------------------------------------------------------------

(
  p_div IN VARCHAR2 DEFAULT ' ' ,
  p_second IN NUMBER DEFAULT 0
)
RETURN NUMBER
AS
   p_comptime NUMBER(10,0);

BEGIN
   IF ( p_div = 'H' ) THEN

   BEGIN
      p_comptime := FLOOR(p_second / 3600.0) ;

   END;
   ELSE
      IF ( p_div = 'M' ) THEN

      BEGIN
         p_comptime := FLOOR(p_second / 60.0) - FLOOR(p_second / 3600.0) * 60 ;

      END;
      ELSE
         IF ( p_div = 'S' ) THEN

         BEGIN
            p_comptime := p_second - FLOOR(p_second / 60.0) * 60 ;

         END;
         END IF;
      END IF;
   END IF;
   RETURN (p_comptime);

	EXCEPTION WHEN OTHERS THEN NULL;
END;
/
