CREATE PROCEDURE spACacc0000PS(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0000PS
	-- 작 성 자         : 민승기
	-- 작성일자         : 2010-10-06
	-- 수정일자       :   노영래
	-- E-mail       :   0rae0926@gmail.com
	-- 수정일자       :   2016-12-13
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계전표관리항목내역 테이블 (ACORDS)을 등록,수정,삭제하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_slipinno		IN	   VARCHAR2 DEFAULT '',
	p_slipinseq 	IN	   NUMBER DEFAULT 0,
	p_mngclucode	IN	   VARCHAR2 DEFAULT '',
	p_seq			IN	   NUMBER DEFAULT 0,
	p_mngcluval 	IN	   VARCHAR2 DEFAULT '',
	p_mngcludec 	IN	   VARCHAR2 DEFAULT '',
	p_iempcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DataSet
)
AS
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);

	IF (UPPER(P_DIV) = 'I')
	THEN
		-- 회계전표관리항목내역 등록
		INSERT INTO ACORDS(compcode,
						   slipinno,
						   slipinseq,
						   mngclucode,
						   seq,
						   mngcluval,
						   mngcludec,
						   insertdt,
						   iempcode)
		VALUES		(p_compcode,
					 p_slipinno,
					 p_slipinseq,
					 p_mngclucode,
					 p_seq,
					 p_mngcluval,
					 p_mngcludec,
					 SYSDATE,
					 p_iempcode);
	ELSIF (UPPER(P_DIV) = 'U')
	THEN
		-- 회계전표관리항목내역 수정
		UPDATE ACORDS a
		SET    seq = p_seq, mngcluval = p_mngcluval, mngcludec = p_mngcludec, updatedt = SYSDATE, uempcode = p_iempcode
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq
			   AND mngclucode = p_mngclucode;
	ELSIF (UPPER(P_DIV) = 'D')
	THEN
		-- 회계전표관리항목내역 삭제
		DELETE ACORDS
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq
			   AND mngclucode = p_mngclucode;
	END IF;

	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
