CREATE PROCEDURE        spACacc0226R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0226R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2013-05-27
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-26
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 특정시점의 재무비율을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '',
	p_basisym		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	p_basisyy	 VARCHAR2(4);
	p_beyymm	 VARCHAR2(7);
	p_yyyy01	 VARCHAR2(7);
	p_beyy01	 VARCHAR2(7);
	p_cashcode	 VARCHAR2(20);
	p_rptdiv	 VARCHAR2(5);
	-- 임시테이블의 calcseq의 최대값을 조회
	p_maxseq	 NUMBER(10, 0);
	p_curseq	 NUMBER(10, 0);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	IF (p_div = 'S')
	THEN
		-- 기간 설정
		p_yyyy01 := SUBSTR(p_basisym, 0, 4) || '-01';

		FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
					FROM   ACSESSION
					WHERE  compcode = p_compcode
						   AND cyear <= SUBSTR(p_basisym, 0, 4))
		LOOP
			p_yyyy01 := rec.alias1;
		END LOOP;

		IF SUBSTR(p_basisym, -2, 2) < SUBSTR(p_yyyy01, -2, 2)
		THEN
			p_yyyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), -12), 'YYYY-') || SUBSTR(p_yyyy01, -2, 2);
		ELSE
			p_yyyy01 := SUBSTR(p_basisym, 0, 5) || SUBSTR(p_yyyy01, -2, 2);
		END IF;

		p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), -12), 'YYYY-MM');
		p_beyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01, 'YYYY-MM'), -12), 'YYYY-MM');
		p_cashcode := '11101010';

		FOR rec IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'acccashcode')
		LOOP
			p_cashcode := rec.value1;
		END LOOP;

		-- 전표에서 월집계 임시파일을 생성
		EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0226R_ACORDDMM';

		INSERT INTO VGT.TT_ACACC0226R_ACORDDMM
			(SELECT   p_compcode compcode,
					  p_plantcode plantcode,
					  p_basisym slipym,
					  CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
					  acccode,
					  SUM(totdebamt) totdebamt,
					  SUM(totcreamt) totcreamt
			 FROM	  (SELECT b.acccode, b.debamt totdebamt, b.creamt totcreamt
					   FROM   ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
					   WHERE  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), 1), 'YYYYMM')
							  AND a.slipinstate = '4'
							  AND (a.slipdiv NOT IN ('K', 'F')
								   OR p_closediv = '1'
									  AND a.slipdiv = 'K'
								   OR p_closediv = '2'
									  AND a.slipdiv = 'F')
					   UNION ALL
					   SELECT p_cashcode acccode, b.creamt totdebamt, b.debamt totcreamt
					   FROM   ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
									 AND b.dcdiv IN ('3', '4')
					   WHERE  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym, 'YYYY-MM'), 1), 'YYYYMM')
							  AND a.slipinstate = '4'
							  AND (a.slipdiv NOT IN ('K', 'F')
								   OR p_closediv = '1'
									  AND a.slipdiv = 'K'
								   OR p_closediv = '2'
									  AND a.slipdiv = 'F')
					   UNION ALL
					   SELECT acccode, bsdebamt totdebamt, bscreamt totcreamt
					   FROM   ACORDDMM
					   WHERE  compcode = p_compcode
							  AND plantcode LIKE p_plantcode
							  AND slipym = p_yyyy01
							  AND (p_closediv = '1'
								   AND closediv IN ('10', '20')
								   OR p_closediv = '2'
									  AND closediv IN ('10', '30'))) a
			 GROUP BY acccode);

		INSERT INTO VGT.TT_ACACC0226R_ACORDDMM
			(SELECT   p_compcode compcode,
					  p_plantcode plantcode,
					  p_beyymm slipym,
					  CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
					  acccode,
					  SUM(totdebamt) totdebamt,
					  SUM(totcreamt) totcreamt
			 FROM	  ACORDDMM
			 WHERE	  compcode = p_compcode
					  AND plantcode LIKE p_plantcode
					  AND slipym = p_beyymm
					  AND (p_closediv = '1'
						   AND closediv IN ('10', '20')
						   OR p_closediv = '2'
							  AND closediv IN ('10', '30'))
			 GROUP BY acccode);

		-- 보고서 조회년도 설정
		p_rptdiv := '3';

		FOR rec IN (SELECT MAX(rptyear) AS alias1
					FROM   ACRPTM
					WHERE  compcode = p_compcode
						   AND rptdiv = p_rptdiv
						   AND rptyear <= SUBSTR(p_basisym, 0, 4))
		LOOP
			p_basisyy := rec.alias1;
		END LOOP;

		EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0226R_ACC204A';

		-- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
		INSERT INTO VGT.TT_ACACC0226R_ACC204A(seqline,
											  acccode,
											  accrname,
											  acckname,
											  lrdiv,
											  prtyn,
											  prtdiv,
											  sseqline,
											  calcseq,
											  calcdiv,
											  cseqline,
											  cgb,
											  objdatadiv,
											  amt,
											  beamt)
			SELECT	 a.seqline,
					 MAX(a.acccode),
					 MAX(a.accrname),
					 MAX(a.acckname),
					 MAX(a.lrdiv),
					 MAX(a.prtyn),
					 MAX(a.prtdiv),
					 MAX(a.sseqline),
					 MAX(a.calcseq),
					 MAX(a.calcdiv),
					 MAX(a.cseqline),
					 '1',
					 MAX(a.objdatadiv),
					 NVL(SUM(CASE WHEN c.slipym = p_basisym THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END END), 0)
						 amt2,
					 NVL(SUM(CASE WHEN c.slipym = p_beyymm THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END END), 0)
						 amt4
			FROM	 ACRPTM a
					 LEFT JOIN ACACCM b ON a.acccode = b.acccode
					 LEFT JOIN VGT.TT_ACACC0226R_ACORDDMM c
						 ON a.compcode = c.compcode
							AND c.plantcode LIKE p_plantcode
							AND c.slipym IN (p_basisym, p_beyymm)
							AND (p_closediv = '1'
								 AND c.closediv IN ('10', '20')
								 OR p_closediv = '2'
									AND c.closediv IN ('10', '30'))
							AND a.acccode = c.acccode
			WHERE	 a.compcode = p_compcode
					 AND a.rptdiv = p_rptdiv
					 AND a.rptyear = p_basisyy
					 AND a.useyn = 'Y'
			GROUP BY a.seqline
			ORDER BY a.seqline;

		-- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
		MERGE INTO VGT.TT_ACACC0226R_ACC204A a
		USING	   (SELECT A.SEQLINE,
						   A.ACCCODE,
						   A.ACCRNAME,
						   A.ACCKNAME,
						   A.LRDIV,
						   A.PRTYN,
						   A.PRTDIV,
						   A.SSEQLINE,
						   A.CALCSEQ,
						   A.CALCDIV,
						   A.CSEQLINE,
						   A.CGB,
						   A.OBJDATADIV,
						   A.CALCAMT,
						   A.BECALCAMT,
						   CASE WHEN a.objdatadiv = 'A' THEN b.amt ELSE a.amt - b.amt END AS pos_2,
						   CASE WHEN a.objdatadiv = 'A' THEN b.beamt ELSE a.beamt - b.beamt END AS pos_3
					FROM   VGT.TT_ACACC0226R_ACC204A a
						   JOIN
						   (SELECT	 a.seqline,
									 NVL(SUM(CASE WHEN c.slipym = p_yyyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) amt,
									 NVL(SUM(CASE WHEN c.slipym = p_beyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) beamt
							FROM	 ACRPTM a
									 LEFT JOIN ACACCM b ON a.acccode = b.acccode
									 LEFT JOIN ACORDDMM c
										 ON a.compcode = c.compcode
											AND c.plantcode LIKE p_plantcode
											AND c.slipym IN (p_yyyy01, p_beyy01)
											AND (p_closediv = '1'
												 AND c.closediv IN ('10', '20')
												 OR p_closediv = '2'
													AND c.closediv IN ('10', '30'))
											AND a.acccode = c.acccode
							WHERE	 a.compcode = p_compcode
									 AND a.rptdiv = p_rptdiv
									 AND a.rptyear = p_basisyy
									 AND a.useyn = 'Y'
									 AND a.objdatadiv IN ('A', 'E', 'F')
							GROUP BY a.seqline) b
							   ON a.seqline = b.seqline) src
		ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
					AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
					AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
					AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
					AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
					AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
					AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
					AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
					AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
					AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
					AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
					AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
					AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
					AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
					AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
		WHEN MATCHED
		THEN
			UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;

		-- 당기순이익을 구함
		spACacc0208R(p_div => 'S',
						   p_compcode => p_compcode,
						   p_plantcode => p_plantcode,
						   p_rptdiv => '5',
						   p_closediv => p_closediv,
						   p_basisym => p_basisym,
						   p_viewyn => 'N',
						   p_pretype => '1',
						   MESSAGE => MESSAGE,
						   IO_CURSOR => IO_CURSOR);

		IF MESSAGE <> '데이터 확인'
		THEN
			MERGE INTO VGT.TT_ACACC0226R_ACC204A a
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.CSEQLINE,
							   A.CGB,
							   A.OBJDATADIV,
							   A.CALCAMT,
							   A.BECALCAMT,
							   TO_NUMBER(SUBSTR(MESSAGE, 0, INSTR(MESSAGE, ';') - 1)) AS pos_2,
							   TO_NUMBER(SUBSTR(MESSAGE, INSTR(MESSAGE, ';') + 1, LENGTH(MESSAGE))) AS pos_3
						FROM   VGT.TT_ACACC0226R_ACC204A a
							   JOIN ACRPTM b
								   ON b.compcode = p_compcode
									  AND b.rptdiv = p_rptdiv
									  AND b.rptyear = p_basisyy
									  AND a.seqline = b.seqline
						WHERE  b.remark = '당기순이익') src
			ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
						AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
						AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
						AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
						AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
			WHEN MATCHED
			THEN
				UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;
		END IF;

		p_curseq := 0;

		FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0226R_ACC204A)
		LOOP
			p_maxseq := rec.alias1;
		END LOOP;

		-- 각 레벨별로 sum을하여 update
		WHILE p_curseq <= p_maxseq
		LOOP
			MERGE INTO VGT.TT_ACACC0226R_ACC204A a
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.CSEQLINE,
							   A.CGB,
							   A.OBJDATADIV,
							   A.CALCAMT,
							   A.BECALCAMT,
							   a.amt + b.amt AS pos_2,
							   a.beamt + b.beamt AS pos_3
						FROM   VGT.TT_ACACC0226R_ACC204A a
							   JOIN (SELECT   sseqline, SUM(CASE WHEN calcdiv = '+' THEN amt ELSE -amt END) amt, SUM(CASE WHEN calcdiv = '+' THEN beamt ELSE -beamt END) beamt
									 FROM	  VGT.TT_ACACC0226R_ACC204A
									 WHERE	  calcseq = p_curseq
											  AND TRIM(sseqline) IS NOT NULL
									 GROUP BY sseqline) b
								   ON a.seqline = b.sseqline) src
			ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
						AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
						AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
						AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
						AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
			WHEN MATCHED
			THEN
				UPDATE SET A.amt = SRC.pos_2, A.beamt = SRC.pos_3;

			p_curseq := p_curseq + 1;
		END LOOP;

		-- 보고서 조회년도 설정
		p_rptdiv := '5';

		FOR rec IN (SELECT MAX(rptyear) AS alias1
					FROM   ACRPTM
					WHERE  compcode = p_compcode
						   AND rptdiv = p_rptdiv
						   AND rptyear <= SUBSTR(p_basisym, 0, 4))
		LOOP
			p_basisyy := rec.alias1;
		END LOOP;

		EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0226R_ACC206A';

		-- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
		INSERT INTO VGT.TT_ACACC0226R_ACC206A(seqline,
											  acccode,
											  accrname,
											  acckname,
											  lrdiv,
											  prtyn,
											  prtdiv,
											  sseqline,
											  calcseq,
											  calcdiv,
											  cseqline,
											  cgb,
											  objdatadiv,
											  amt,
											  beamt)
			SELECT	 a.seqline,
					 MAX(a.acccode),
					 MAX(a.accrname),
					 MAX(a.acckname),
					 MAX(a.lrdiv),
					 MAX(a.prtyn),
					 MAX(a.prtdiv),
					 MAX(a.sseqline),
					 MAX(a.calcseq),
					 MAX(a.calcdiv),
					 MAX(a.cseqline),
					 '1',
					 MAX(a.objdatadiv),
					 NVL(SUM(CASE WHEN c.slipym = p_basisym THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END END), 0)
						 amt2,
					 NVL(SUM(CASE WHEN c.slipym = p_beyymm THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt ELSE c.totcreamt - c.totdebamt END END END), 0)
						 amt4
			FROM	 ACRPTM a
					 LEFT JOIN ACACCM b ON a.acccode = b.acccode
					 LEFT JOIN VGT.TT_ACACC0226R_ACORDDMM c
						 ON a.compcode = c.compcode
							AND c.plantcode LIKE p_plantcode
							AND c.slipym IN (p_basisym, p_beyymm)
							AND (p_closediv = '1'
								 AND c.closediv IN ('10', '20')
								 OR p_closediv = '2'
									AND c.closediv IN ('10', '30'))
							AND a.acccode = c.acccode
			WHERE	 a.compcode = p_compcode
					 AND a.rptdiv = p_rptdiv
					 AND a.rptyear = p_basisyy
					 AND a.useyn = 'Y'
			GROUP BY a.seqline
			ORDER BY a.seqline;

		-- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
		MERGE INTO VGT.TT_ACACC0226R_ACC206A a
		USING	   (SELECT A.SEQLINE,
						   A.ACCCODE,
						   A.ACCRNAME,
						   A.ACCKNAME,
						   A.LRDIV,
						   A.PRTYN,
						   A.PRTDIV,
						   A.SSEQLINE,
						   A.CALCSEQ,
						   A.CALCDIV,
						   A.CSEQLINE,
						   A.CGB,
						   A.OBJDATADIV,
						   A.CALCAMT,
						   A.BECALCAMT,
						   CASE WHEN a.objdatadiv = 'A' THEN b.amt ELSE a.amt - b.amt END AS pos_2,
						   CASE WHEN a.objdatadiv = 'A' THEN b.beamt ELSE a.beamt - b.beamt END AS pos_3
					FROM   VGT.TT_ACACC0226R_ACC206A a
						   JOIN
						   (SELECT	 a.seqline,
									 NVL(SUM(CASE WHEN c.slipym = p_yyyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) amt,
									 NVL(SUM(CASE WHEN c.slipym = p_beyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt WHEN a.objdatadiv = 'E' THEN c.bscreamt WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt ELSE c.bscreamt - c.bsdebamt END END END), 0) beamt
							FROM	 ACRPTM a
									 LEFT JOIN ACACCM b ON a.acccode = b.acccode
									 LEFT JOIN ACORDDMM c
										 ON a.compcode = c.compcode
											AND c.plantcode LIKE p_plantcode
											AND c.slipym IN (p_yyyy01, p_beyy01)
											AND (p_closediv = '1'
												 AND c.closediv IN ('10', '20')
												 OR p_closediv = '2'
													AND c.closediv IN ('10', '30'))
											AND a.acccode = c.acccode
							WHERE	 a.compcode = p_compcode
									 AND a.rptdiv = p_rptdiv
									 AND a.rptyear = p_basisyy
									 AND a.useyn = 'Y'
									 AND a.objdatadiv IN ('A', 'E', 'F')
							GROUP BY a.seqline) b
							   ON a.seqline = b.seqline) src
		ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
					AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
					AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
					AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
					AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
					AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
					AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
					AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
					AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
					AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
					AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
					AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
					AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
					AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
					AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
		WHEN MATCHED
		THEN
			UPDATE SET a.amt = SRC.pos_2, a.beamt = SRC.pos_3;

		-- 당기제품제조원가를 구함
		spACacc0208R(p_div => 'S',
						   p_compcode => p_compcode,
						   p_plantcode => p_plantcode,
						   p_rptdiv => '9',
						   p_closediv => p_closediv,
						   p_basisym => p_basisym,
						   p_viewyn => 'N',
						   MESSAGE => MESSAGE,
						   IO_CURSOR => IO_CURSOR);

		IF MESSAGE <> '데이터 확인'
		THEN
			MERGE INTO VGT.TT_ACACC0226R_ACC206A a
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.CSEQLINE,
							   A.CGB,
							   A.OBJDATADIV,
							   A.CALCAMT,
							   A.BECALCAMT,
							   TO_NUMBER(SUBSTR(MESSAGE, 0, INSTR(MESSAGE, ';') - 1)) AS pos_2,
							   TO_NUMBER(SUBSTR(MESSAGE, INSTR(MESSAGE, ';') + 1, LENGTH(MESSAGE))) AS pos_3
						FROM   VGT.TT_ACACC0226R_ACC206A a
							   JOIN ACRPTM b
								   ON b.compcode = p_compcode
									  AND b.rptdiv = p_rptdiv
									  AND b.rptyear = p_basisyy
									  AND a.seqline = b.seqline
						WHERE  b.remark = '당기제품제조원가') src
			ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
						AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
						AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
						AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
						AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
			WHEN MATCHED
			THEN
				UPDATE SET a.amt = SRC.pos_2, a.beamt = SRC.pos_3;
		END IF;

		-- 임시테이블의 calcseq의 최대값을 조회
		p_curseq := 0;

		FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0226R_ACC206A)
		LOOP
			p_maxseq := rec.alias1;
		END LOOP;

		-- 각 레벨별로 sum을하여 update
		WHILE p_curseq <= p_maxseq
		LOOP
			MERGE INTO VGT.TT_ACACC0226R_ACC206A a
			USING	   (SELECT A.SEQLINE,
							   A.ACCCODE,
							   A.ACCRNAME,
							   A.ACCKNAME,
							   A.LRDIV,
							   A.PRTYN,
							   A.PRTDIV,
							   A.SSEQLINE,
							   A.CALCSEQ,
							   A.CALCDIV,
							   A.CSEQLINE,
							   A.CGB,
							   A.OBJDATADIV,
							   A.CALCAMT,
							   A.BECALCAMT,
							   a.amt + b.amt AS pos_2,
							   a.beamt + b.beamt AS pos_3
						FROM   VGT.TT_ACACC0226R_ACC206A a
							   JOIN
							   (SELECT	 VGT.TT_ACACC0226R_ACC206A.sseqline,
										 SUM(CASE WHEN VGT.TT_ACACC0226R_ACC206A.calcdiv = '+' THEN VGT.TT_ACACC0226R_ACC206A.amt ELSE -VGT.TT_ACACC0226R_ACC206A.amt END) amt,
										 SUM(CASE WHEN VGT.TT_ACACC0226R_ACC206A.calcdiv = '+' THEN VGT.TT_ACACC0226R_ACC206A.beamt ELSE -VGT.TT_ACACC0226R_ACC206A.beamt END) beamt
								FROM	 VGT.TT_ACACC0226R_ACC206A
								WHERE	 VGT.TT_ACACC0226R_ACC206A.calcseq = p_curseq
										 AND NVL(VGT.TT_ACACC0226R_ACC206A.sseqline, '') <> ''
								GROUP BY VGT.TT_ACACC0226R_ACC206A.sseqline) b
								   ON a.seqline = b.sseqline) src
			ON		   (NVL(A.SEQLINE, ' ') = NVL(SRC.SEQLINE, ' ')
						AND NVL(A.ACCCODE, ' ') = NVL(SRC.ACCCODE, ' ')
						AND NVL(A.ACCRNAME, ' ') = NVL(SRC.ACCRNAME, ' ')
						AND NVL(A.ACCKNAME, ' ') = NVL(SRC.ACCKNAME, ' ')
						AND NVL(A.LRDIV, ' ') = NVL(SRC.LRDIV, ' ')
						AND NVL(A.PRTYN, ' ') = NVL(SRC.PRTYN, ' ')
						AND NVL(A.PRTDIV, ' ') = NVL(SRC.PRTDIV, ' ')
						AND NVL(A.SSEQLINE, ' ') = NVL(SRC.SSEQLINE, ' ')
						AND NVL(A.CALCSEQ, 0) = NVL(SRC.CALCSEQ, 0)
						AND NVL(A.CALCDIV, ' ') = NVL(SRC.CALCDIV, ' ')
						AND NVL(A.CSEQLINE, ' ') = NVL(SRC.CSEQLINE, ' ')
						AND NVL(A.CGB, 0) = NVL(SRC.CGB, 0)
						AND NVL(A.OBJDATADIV, ' ') = NVL(SRC.OBJDATADIV, ' ')
						AND NVL(A.CALCAMT, 0) = NVL(SRC.CALCAMT, 0)
						AND NVL(A.BECALCAMT, 0) = NVL(SRC.BECALCAMT, 0))
			WHEN MATCHED
			THEN
				UPDATE SET a.amt = SRC.pos_2, a.beamt = SRC.pos_3;

			p_curseq := p_curseq + 1;
		END LOOP;



		OPEN IO_CURSOR FOR
            SELECT '안전성' grpname,
                   '유동비율' itemname,
                   '(유동자산 ÷ 유동부채) × 100' calculus,
                   CASE WHEN NVL(b.amt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / NVL(b.amt, 0) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC204A a FULL JOIN VGT.TT_ACACC0226R_ACC204A b ON b.seqline = '200010'
            WHERE  a.seqline = '100010'
            UNION ALL
            SELECT '안전성' grpname,
                   '당좌비율' itemname,
                   '(당좌자산 ÷ 유동부채) × 100' calculus,
                   CASE WHEN NVL(b.amt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / NVL(b.amt, 0) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC204A a FULL JOIN VGT.TT_ACACC0226R_ACC204A b ON b.seqline = '200010'
            WHERE  a.seqline = '100020'
            UNION ALL
            SELECT '안전성' grpname,
                   '부채비율' itemname,
                   '(부채총계 ÷ 자본총계) × 100' calculus,
                   CASE WHEN NVL(b.amt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / NVL(b.amt, 0) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC204A a FULL JOIN VGT.TT_ACACC0226R_ACC204A b ON b.seqline = '390000'
            WHERE  a.seqline = '290000'
            UNION ALL
            SELECT '안전성' grpname,
                   '이자보상비율' itemname,
                   '(사업수익 ÷ 이자비용) × 100' calculus,
                   CASE WHEN NVL(b.amt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / NVL(b.amt, 0) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC206A a FULL JOIN VGT.TT_ACACC0226R_ACC206A b ON b.seqline = '106010'
            WHERE  a.seqline = '104000'
            UNION ALL
            SELECT '수익성' grpname,
                   '총자산이익율' itemname,
                   '(당기순손익 ÷ ((전기자산총계 + 당기자산총계) / 2)) × 100' calculus,
                   CASE WHEN NVL(b.amt + b.beamt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / (NVL(b.amt + b.beamt, 0) / 2) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC206A a FULL JOIN VGT.TT_ACACC0226R_ACC204A b ON b.seqline = '190000'
            WHERE  a.seqline = '111000'
            UNION ALL
            SELECT '수익성' grpname,
                   '자기자본이익율' itemname,
                   '(당기순손익 ÷ ((전기자본총계 + 당기자본총계) / 2)) × 100' calculus,
                   CASE WHEN NVL(b.amt + b.beamt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / (NVL(b.amt + b.beamt, 0) / 2) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC206A a FULL JOIN VGT.TT_ACACC0226R_ACC204A b ON b.seqline = '390000'
            WHERE  a.seqline = '111000'
            UNION ALL
            SELECT '수익성' grpname,
                   '매출액순이익율' itemname,
                   '(당기순손익 ÷ 매출액) × 100' calculus,
                   CASE WHEN NVL(b.amt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / NVL(b.amt, 0) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC206A a FULL JOIN VGT.TT_ACACC0226R_ACC206A b ON b.seqline = '100000'
            WHERE  a.seqline = '111000'
            UNION ALL
            SELECT '수익성' grpname,
                   '매출액영업이익율' itemname,
                   '(영업이익 ÷ 매출액) × 100' calculus,
                   CASE WHEN NVL(b.amt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / NVL(b.amt, 0) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC206A a FULL JOIN VGT.TT_ACACC0226R_ACC206A b ON b.seqline = '100000'
            WHERE  a.seqline = '104000'
            UNION ALL
            SELECT '수익성' grpname,
                   '매출액총이익율' itemname,
                   '(총이익 ÷ 매출액) × 100' calculus,
                   CASE WHEN NVL(b.amt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / NVL(b.amt, 0) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC206A a FULL JOIN VGT.TT_ACACC0226R_ACC206A b ON b.seqline = '100000'
            WHERE  a.seqline = '102000'
            UNION ALL
            SELECT '성장성' grpname,
                   '총자산증가율' itemname,
                   '(당기자산총계 - 전기자산총계) ÷ 전기자산총계' calculus,
                   CASE WHEN NVL(a.beamt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND((NVL(a.amt, 0) - NVL(a.beamt, 0)) / NVL(a.beamt, 0), 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC204A a
            WHERE  a.seqline = '190000'
            UNION ALL
            SELECT '성장성' grpname,
                   '자기자본증가율' itemname,
                   '(당기자본총계 - 전기자본총계) ÷ 전기자본총계' calculus,
                   CASE WHEN NVL(a.beamt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND((NVL(a.amt, 0) - NVL(a.beamt, 0)) / NVL(a.beamt, 0), 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC204A a
            WHERE  a.seqline = '390000'
            UNION ALL
            SELECT '성장성' grpname,
                   '사업수익증가율' itemname,
                   '(당기사업수익 - 전기사업수익) ÷ 전기사업수익' calculus,
                   CASE WHEN NVL(a.beamt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND((NVL(a.amt, 0) - NVL(a.beamt, 0)) / NVL(a.beamt, 0), 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC206A a
            WHERE  a.seqline = '104000'
            UNION ALL
            SELECT '성장성' grpname,
                   '순이익증가율' itemname,
                   '(당기당기순손익 - 전기당기순손익) ÷ 전기당기순손익' calculus,
                   CASE WHEN NVL(a.beamt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND((NVL(a.amt, 0) - NVL(a.beamt, 0)) / NVL(a.beamt, 0), 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC206A a
            WHERE  a.seqline = '111000'
            UNION ALL
            SELECT '활동성' grpname,
                   '총자산회전율' itemname,
                   '(사업수익 ÷ ((전기자산총계 + 당기자산총계) / 2)) × 100' calculus,
                   CASE WHEN NVL(b.amt + b.beamt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / (NVL(b.amt + b.beamt, 0) / 2) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC206A a FULL JOIN VGT.TT_ACACC0226R_ACC204A b ON b.seqline = '190000'
            WHERE  a.seqline = '104000'
            UNION ALL
            SELECT '활동성' grpname,
                   '자기자본회전율' itemname,
                   '(사업수익 ÷ ((전기자본총계 + 당기자본총계) / 2)) × 100' calculus,
                   CASE WHEN NVL(b.amt + b.beamt, 0) = 0 THEN '0' ELSE fnNumberFM(ROUND(NVL(a.amt, 0) / (NVL(b.amt + b.beamt, 0) / 2) * 100, 1)) END VALUE
            FROM   VGT.TT_ACACC0226R_ACC206A a FULL JOIN VGT.TT_ACACC0226R_ACC204A b ON b.seqline = '390000'
            WHERE  a.seqline = '104000';
	ELSIF (p_div = 'Y')
	THEN
		OPEN IO_CURSOR FOR
			SELECT *
			FROM   (SELECT	 CASE WHEN cyear = SUBSTR(p_basisym, 0, 4) THEN sseq ELSE sseq - TO_NUMBER(cyear) + TO_NUMBER(SUBSTR(p_basisym, 0, 4)) END sseq
					FROM	 ACSESSION
					WHERE	 compcode = p_compcode
							 AND cyear <= SUBSTR(p_basisym, 0, 4)
					ORDER BY cyear DESC)
			WHERE  ROWNUM <= 1;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
