CREATE PROCEDURE        spACacc0038P
-- ---------------------------------------------------------------
-- 프로시저명       : ACacc0038P
-- 작 성 자         : 최용석
-- 작성일자         : 2017-07-14
-- ---------------------------------------------------------------
-- 프로시저 설명    : 카드매출엑셀정산을 관리하는 프로시저이다.
-- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '',

    p_compcode      IN  VARCHAR2 DEFAULT '',
    p_plantcode     IN  VARCHAR2 DEFAULT '',
    p_strdate       IN  VARCHAR2 DEFAULT '',
    p_enddate       IN  VARCHAR2 DEFAULT '',
    p_viewdiv       IN  VARCHAR2 DEFAULT '',
    p_cardcomp      IN  VARCHAR2 DEFAULT '%',

    p_depodate      IN  VARCHAR2 DEFAULT '',
    p_approvalno    IN  VARCHAR2 DEFAULT '',
    p_businessno    IN  VARCHAR2 DEFAULT '',
    p_custname      IN  VARCHAR2 DEFAULT '',
    p_approvalamt   IN  FLOAT    DEFAULT 0,
    p_depositamt    IN  FLOAT    DEFAULT 0,
    p_feeamt        IN  FLOAT    DEFAULT 0,
    p_apprdate      IN  VARCHAR2 DEFAULT '',
    p_iempcode      IN  VARCHAR2 DEFAULT '',

    p_slipdate      IN  VARCHAR2 DEFAULT '',
    p_slipinno      IN  VARCHAR2 DEFAULT '',
    p_slipinseq     IN  NUMBER   DEFAULT 0,
    p_cardcode      IN  VARCHAR2 DEFAULT '',
    p_accountno     IN  VARCHAR2 DEFAULT '',

    p_userid        IN  VARCHAR2 DEFAULT '',
    p_reasondiv     IN  VARCHAR2 DEFAULT '',
    p_reasontext    IN  VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_acautorcode       VARCHAR2(10);
    p_slipdiv           VARCHAR2(5);
    p_slipno            VARCHAR2(20);
    p_slipnum           VARCHAR2(5);
    p_deptcode          VARCHAR2(20);
    p_remark            VARCHAR2(100);
    v_temp              NUMBER := 0;

    p_ordseq            NUMBER(10,0);   -- 출력순번
    ip_approvalno       LONG := p_approvalno;
    v_approvalno        VARCHAR2(30);
    ip_approvalamt      LONG := p_businessno;
    v_approvalamt       VARCHAR2(30);

BEGIN

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);
    
    MESSAGE := '데이터 확인';
    p_acautorcode := 'A04040';

    if (p_div = 'S') then
        merge into ACCARDIN a
        using (
            select  a.compcode, a.plantcode, a.depodate, a.approvalno, a.approvalamt
            from    ACCARDIN a
                    left join ACORDM b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
            where   a.compcode = p_compcode
                    and a.plantcode = p_plantcode
                    and a.depodate between p_strdate and p_enddate
                    and b.compcode is null) b
        on (a.compcode = b.compcode
            and a.plantcode = b.plantcode
            and a.depodate = b.depodate
            and a.approvalno = b.approvalno
            and a.approvalamt = b.approvalamt)
        when matched
        then
            update set a.slipinno = null;

        open IO_CURSOR for
        select  'N' seldiv,
                b.divcode as cardcode,
                b.divname as cardname,
                a.depodate,
                a.apprdate,
                a.approvalamt,
                a.feeamt,
                a.depositamt,
                a.custname,
                a.businessno,
                a.approvalno,
                FNstuff(a.slipinno,9,0,'-') as slipinno,
                a.plantcode
        from    ACCARDIN a
                left join (
                    select  divcode, divname
                    from    CMCOMMONM
                    where   cmmcode = 'AC17'
                    union all
                    select  '070', '비씨카드'
                    from    DUAL
                ) b on a.cardcomp = b.divname
                left join ACORDM c
                    on a.compcode = c.compcode
                    and a.slipinno = c.slipinno
        where   a.compcode = p_compcode
                and a.plantcode = p_plantcode
                and a.depodate between p_strdate and p_enddate
                and (p_viewdiv = 0 or p_viewdiv = 1 and c.slipinno is not null or p_viewdiv = 2 and c.slipinno is null)
                and nvl(b.divcode,' ') like p_cardcomp
        order by a.depodate, b.divname, a.apprdate, a.approvalno;

    elsif (p_div = 'I') then
        select  count(*) into v_temp
        from    ACCARDIN
        where   compcode = p_compcode
                and plantcode = p_plantcode
                and depodate = FNstuff(FNstuff(p_depodate,5,0,'-'),8,0,'-')
                and approvalno = p_approvalno
                and approvalamt = p_approvalamt;

        if v_temp = 1 then
            update  ACCARDIN
            set     businessno = FNstuff(FNstuff(p_businessno,4,0,'-'),7,0,'-'),
                    custname = p_custname,
                    cardcomp = p_cardcomp,
                    approvalamt = p_approvalamt,
                    depositamt = p_depositamt,
                    feeamt = p_feeamt,
                    apprdate = replace(p_apprdate,'.','-'),
                    updatedt = sysdate,
                    uempcode = p_iempcode
            where   compcode = p_compcode
                    and plantcode = p_plantcode
                    and depodate = FNstuff(FNstuff(p_depodate,5,0,'-'),8,0,'-')
                    and approvalno = p_approvalno
                    and approvalamt = p_approvalamt;
        else
            insert into ACCARDIN
                (
                    compcode,
                    plantcode,
                    depodate,
                    approvalno,
                    businessno,
                    custname,
                    cardcomp,
                    approvalamt,
                    depositamt,
                    feeamt,
                    apprdate,
                    insertdt,
                    iempcode
                )
            select  p_compcode,
                    p_plantcode,
                    FNstuff(FNstuff(p_depodate,5,0,'-'),8,0,'-'),
                    p_approvalno,
                    FNstuff(FNstuff(p_businessno,4,0,'-'),7,0,'-'),
                    p_custname,
                    p_cardcomp,
                    p_approvalamt,
                    p_depositamt,
                    p_feeamt,
                    replace(p_apprdate,'.','-'),
                    sysdate,
                    p_iempcode
            from    DUAL;
        end if;

    elsif (p_div = 'IM') then
        for rec in (
            select  accdiv
                    ,remark2
                    ,condition1
            from    ACAUTORULE
            where   acautorcode = p_acautorcode)
        loop
            p_slipdiv := rec.accdiv;
            p_remark := rec.remark2;
            p_slipno := rec.condition1;
        end loop;

        for rec in (
            select  deptcode
            from    CMEMPM
            where   empcode = p_iempcode)
        loop
            p_deptcode := rec.deptcode;
        end loop;

        for rec in (
            select  p_slipdiv || substr('0000' || to_char((nvl(substr(max(slipinnum), -4), 0) + 1)), -4) as slipnum
            from    ACORDM a
            where   compcode = p_compcode
                    and p_slipno = '0'
                    and slipinno like replace(p_slipdate, '-', '') || rtrim(p_slipdiv) || '%'
            union
            select  p_slipdiv || substr('0000' || to_char((nvl(substr(max(slipnum), -4), 0) + 1)), -4) as slipnum
            from    ACORDM a
            where   compcode = p_compcode
                    and p_slipno = '1'
                    and slipno like replace(p_slipdate, '-', '') || rtrim(p_slipdiv) || '%')
        loop
            p_slipnum := rec.slipnum;
        end loop;

        p_slipno := replace(p_slipdate, '-', '') || p_slipnum;

        insert into ACORDM
            (
                compcode,
                slipinno,
                slipdiv,
                slipindate,
                slipinnum,
                deptcode,
                plantcode,
                empcode,
                eviddiv,
                slipinremark,
                slipno,
                slipdate,
                slipnum,
                slipdeptcode,
                slipempcode,
                skreqyn,
                skreqdiv,
                skreqdate,
                skreqdeptcode,
                skreqempcode,
                accountno,
                slipinstate,
                slipremark,
                acautorcode,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipno,
                p_slipdiv,
                p_slipdate,
                p_slipnum,
                p_deptcode,
                p_plantcode,
                p_iempcode,
                '99',
                p_remark,
                p_slipno,
                case when condition1 = '0' then '' else p_slipdate end,
                case when condition1 = '0' then '' else p_slipnum end,
                '',
                '',
                '',
                '',
                p_slipdate,
                '',
                '',
                '',
                case when condition1 = '0' then '2' else '4' end,
                '',
                acautorcode,
                sysdate,
                p_iempcode
        from    ACAUTORULE
        where   acautorcode = p_acautorcode;

        MESSAGE := p_slipno;

    elsif (p_div = 'ID') then
        insert into ACORDD
            (
                compcode,
                slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                rptseq,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                p_slipinseq + b.acautoseq,
                b.dcdiv,
                b.acacccode,
                p_plantcode,
                case when b.dcdiv = '1' then case b.accamtdiv when '01' then p_depositamt when '02' then p_feeamt else p_approvalamt end else 0 end,
                case when b.dcdiv = '2' then case b.accamtdiv when '01' then p_depositamt when '02' then p_feeamt else p_approvalamt end else 0 end,
                c.slipdate,
                c.slipnum,
                d.divname || ' ' || case b.accamtdiv when '01' then '수금입금' when '02' then '수수료' else '미수금' end,
                '',
                p_slipinseq + b.acautoseq,
                sysdate,
                p_iempcode
        from    ACAUTORULE a
                join ACAUTORULESM b
                    on a.acautorcode = b.acautorcode
                join ACORDM c
                    on c.compcode = p_compcode
                    and c.slipinno = p_slipinno
                left join CMCOMMONM d
                    on d.cmmcode = 'AC17'
                    and d.divcode = p_cardcode
        where   a.acautorcode = p_acautorcode
        order by b.acautoseq;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                p_slipinseq + a.acautoseq,
                a.mngclucode,
                a.acautoseq,
                case a.mngclucode when 'S020' then p_accountno when 'U081' then p_cardcode when 'S040' then d.deptcode when 'S050' then p_iempcode else '' end,
                case a.mngclucode when 'S020' then b.accremark when 'U081' then c.divname when 'S040' then e.deptname when 'S050' then d.empname else '' end,
                sysdate,
                p_iempcode
        from    ACAUTORULEDS a
                left join CMACCOUNTM b
                    on b.accountno = p_accountno
                left join CMCOMMONM c
                    on c.cmmcode = 'AC17'
                    and c.divcode = p_cardcode
                left join CMEMPM d
                    on d.empcode = p_iempcode
                left join CMDEPTM e
                    on d.deptcode = e.deptcode
        where   a.acautorcode = p_acautorcode
        order by a.acautoseq;

    elsif (p_div = 'IC') then
        p_ordseq := 1;

        execute immediate 'delete from VGT.TT_ACACC0038R_TEMP';
        while(instr(ip_approvalno, ';') > 0)
        loop
            v_approvalno := substr(ip_approvalno, 1, instr(ip_approvalno, ';') - 1);
            ip_approvalno := substr(ip_approvalno, instr(ip_approvalno, ';') + 1, length(ip_approvalno));
            v_approvalamt := substr(ip_approvalamt, 1, instr(ip_approvalamt, ';') - 1);
            ip_approvalamt := substr(ip_approvalamt, instr(ip_approvalamt, ';') + 1, length(ip_approvalamt));

            insert into VGT.TT_ACACC0038R_TEMP
            values (p_ordseq, v_approvalno, v_approvalamt);

            p_ordseq := p_ordseq + 1;
        end loop;

        merge into ACCARDIN a
        using (
            select  a.compcode, a.plantcode, a.depodate, a.approvalno, a.approvalamt
            from    ACCARDIN a
                    join VGT.TT_ACACC0038R_TEMP b
                        on a.approvalno = b.approvalno
                        and a.approvalamt = to_number(b.approvalamt)
            where   a.compcode = p_compcode
                    and a.plantcode = p_plantcode
                    and a.depodate = p_depodate) b
        on (a.compcode = b.compcode
            and a.plantcode = b.plantcode
            and a.depodate = b.depodate
            and a.approvalno = b.approvalno
            and a.approvalamt = b.approvalamt)
        when matched
        then
            update set a.slipinno = p_slipinno;

    end if;
    
    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
