CREATE PROCEDURE        spACfund0000P
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACfund0000P
   -- 작 성 자         : 최기홍
   -- 작성일자         : 2010-09-08
   --  수 정 자         : 임 정호
   --  수정일자          : 2016-12-27
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 예적금 등록,수정,삭제,조회하는 프로시저이다.
   -- ---------------------------------------------------------------
(

   p_div            IN     VARCHAR2 DEFAULT '',
   p_compcode       IN     VARCHAR2 DEFAULT '',
   p_accountno      IN     VARCHAR2 DEFAULT '',
   p_deposdiv       IN     VARCHAR2 DEFAULT '',
   p_accremark      IN     VARCHAR2 DEFAULT '',
   p_deptcode       IN     VARCHAR2 DEFAULT '',
   p_plantcode      IN     VARCHAR2 DEFAULT '',
   p_acccode        IN     VARCHAR2 DEFAULT '',
   p_bankcode       IN     VARCHAR2 DEFAULT '',
   p_paybank        IN     VARCHAR2 DEFAULT '',
   p_payaccountno   IN     VARCHAR2 DEFAULT '',
   p_mainamt        IN     FLOAT    DEFAULT 0,
   p_strdate        IN     VARCHAR2 DEFAULT '',
   p_expdate        IN     VARCHAR2 DEFAULT '',
   p_penddate       IN     VARCHAR2 DEFAULT '',
   p_interate       IN     FLOAT    DEFAULT 0,
   p_mmperiod       IN     NUMBER   DEFAULT 0,
   p_payinday       IN     CHAR     DEFAULT '',
   p_payinamt       IN     FLOAT    DEFAULT 0,
   p_mortgyn        IN     VARCHAR2 DEFAULT '',
   p_mortgremark    IN     VARCHAR2 DEFAULT '',
   p_enddiv         IN     VARCHAR2 DEFAULT '',
   p_enddate        IN     VARCHAR2 DEFAULT '',
   p_endrate        IN     FLOAT    DEFAULT 0,
   p_payincnt       IN     NUMBER   DEFAULT 0,
   p_paysumamt      IN     FLOAT    DEFAULT 0,
   p_costamt        IN     FLOAT    DEFAULT 0,
   p_exrtcode       IN     VARCHAR2 DEFAULT '',
   p_paysumexamt    IN     FLOAT    DEFAULT 0,
   p_costexamt      IN     FLOAT    DEFAULT 0,
   p_iempcode       IN     VARCHAR2 DEFAULT '',
   p_chkenddivS     IN     VARCHAR2 DEFAULT '',
   p_userid         IN     VARCHAR2 DEFAULT '',
   p_reasondiv      IN     VARCHAR2 DEFAULT '',
   p_reasontext     IN     VARCHAR2 DEFAULT '',
   IO_CURSOR           OUT TYPES.DataSet,
   MESSAGE             OUT VARCHAR2

)
AS
BEGIN
   MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF (p_div = 'S') THEN

        OPEN IO_CURSOR FOR
            SELECT NVL (A.compcode, '') compcode,
                NVL (A.accountno, '') accountno,
                NVL (A.deposdiv, '') deposdiv,
                NVL (A.accremark, '') accremark,
                NVL (A.deptcode, '') deptcode,
                NVL (A.plantcode, '') plantcode,
                NVL (A.acccode, '') acccode,
                NVL (A.bankcode, '') bankcode,
                NVL (A.paybank, '') paybank,
                NVL (A.payaccountno, '') payaccountno,
                NVL (A.mainamt, 0) mainamt,
                NVL (A.strdate, '') strdate,
                NVL (A.expdate, '') expdate,
                NVL (A.penddate, '') penddate,
                NVL (A.interate, 0) interate,
                NVL (A.mmperiod, 0) mmperiod,
                NVL (A.payinday, '') payinday,
                NVL (A.payinamt, 0) payinamt,
                NVL (A.mortgyn, '') mortgyn,
                NVL (A.mortgremark, '') mortgremark,
                NVL (A.enddiv, '') enddiv,
                NVL (A.enddate, '') enddate,
                NVL (A.endrate, 0) endrate,
                NVL (A.payincnt, 0) payincnt,
                NVL (A.paysumamt, 0) paysumamt,
                NVL (A.costamt, 0) costamt,
                NVL (A.exrtcode, '') exrtcode,
                NVL (A.paysumexamt, 0) paysumexamt,
                NVL (A.costexamt, 0) costexamt,
                NVL (b.deptname, '') deptname,
                NVL (c.accname, '') accname,
                NVL (E.accremark, '') payaccremark
            FROM CMACCOUNTM A
                LEFT JOIN CMDEPTM b ON A.deptcode = b.deptcode
                LEFT JOIN ACACCM  c ON A.acccode = c.acccode
                JOIN CMCOMMONM D ON D.cmmcode = 'AC41' AND A.enddiv = D.divcode
                LEFT JOIN CMACCOUNTM E ON A.compcode = E.compcode
                                          AND A.payaccountno = E.accountno
            WHERE     (   ( (p_chkenddivS = 'Y') AND D.filter1 IN ('Y')) OR ( (p_chkenddivS = 'N') AND D.filter1 IN ('Y', 'N')))
                AND NVL(A.bankcode, ' ') LIKE p_bankcode || '%'
                AND A.deposdiv LIKE p_deposdiv || '%'
                AND A.accremark LIKE p_accremark || '%'
                AND A.compcode = p_compcode
            ORDER BY accountno ;


    ELSIF (p_div = 'S1')    THEN

        OPEN IO_CURSOR FOR
        SELECT NVL (A.compcode, '') compcode,
            NVL (A.accountno, '') accountno,
            NVL (A.deposdiv, '') deposdiv,
            NVL (A.accremark, '') accremark,
            NVL (A.deptcode, '') deptcode,
            NVL (A.plantcode, '') plantcode,
            NVL (A.acccode, '') acccode,
            NVL (A.bankcode, '') bankcode,
            NVL (A.paybank, '') paybank,
            NVL (A.payaccountno, '') payaccountno,
            NVL (A.mainamt, 0) mainamt,
            NVL (A.strdate, '') strdate,
            NVL (A.expdate, '') expdate,
            NVL (A.penddate, '') penddate,
            NVL (A.interate, 0) interate,
            NVL (A.mmperiod, 0) mmperiod,
            NVL (A.payinday, '') payinday,
            NVL (A.payinamt, 0) payinamt,
            NVL (A.mortgyn, '') mortgyn,
            NVL (A.mortgremark, '') mortgremark,
            NVL (A.enddiv, '') enddiv,
            NVL (A.enddate, '') enddate,
            NVL (A.endrate, 0) endrate,
            NVL (A.payincnt, 0) payincnt,
            NVL (A.paysumamt, 0) paysumamt,
            NVL (A.costamt, 0) costamt,
            NVL (A.exrtcode, '') exrtcode,
            NVL (A.paysumexamt, 0) paysumexamt,
            NVL (A.costexamt, 0) costexamt,
            NVL (b.deptname, '') deptname,
            NVL (c.accname, '') accname,
            NVL (E.accremark, '') payaccremark
        FROM CMACCOUNTM A
            LEFT JOIN CMDEPTM b ON A.deptcode = b.deptcode
            LEFT JOIN ACACCM c ON A.acccode = c.acccode
            JOIN CMCOMMONM D
               ON D.cmmcode = 'AC41' AND A.enddiv = D.divcode
            LEFT JOIN
            CMACCOUNTM E
               ON     A.compcode = E.compcode
                  AND A.payaccountno = E.accountno
        WHERE A.compcode = p_compcode AND A.accountno = p_accountno;
    ELSIF (p_div = 'SC') THEN

        FOR rec IN
        (
            SELECT  COUNT (accountno) AS alias1
            FROM    CMACCOUNTM
            WHERE   compcode = p_compcode
                AND accountno = p_accountno
        )
        LOOP
            MESSAGE := rec.alias1;
        END LOOP;

    ELSIF (p_div = 'IC') THEN

        FOR rec IN
        (
            SELECT  COUNT (accountno) AS alias1
            FROM    CMACCOUNTM
            WHERE   compcode = p_compcode
                AND accountno = p_accountno
        )
        LOOP
            MESSAGE := rec.alias1;
        END LOOP;

    ELSIF (p_div = 'DC') THEN

        FOR rec IN
        (
            SELECT CASE WHEN payincnt > 0 THEN 'Y'                     --삭제불가
                        ELSE 'N'             --삭제가능
                   END AS alias1
            FROM CMACCOUNTM
            WHERE compcode = p_compcode AND accountno = p_accountno
        )
        LOOP
            MESSAGE := rec.alias1;
        END LOOP;
    ELSIF (p_div = 'I') THEN
        INSERT INTO CMACCOUNTM (
                                  compcode,
                                  accountno,
                                  deposdiv,
                                  accremark,
                                  deptcode,
                                  plantcode,
                                  acccode,
                                  bankcode,
                                  paybank,
                                  payaccountno,
                                  mainamt,
                                  strdate,
                                  expdate,
                                  penddate,
                                  interate,
                                  mmperiod,
                                  payinday,
                                  payinamt,
                                  mortgyn,
                                  mortgremark,
                                  enddiv,
                                  enddate,
                                  endrate,
                                  payincnt,
                                  paysumamt,
                                  costamt,
                                  exrtcode,
                                  paysumexamt,
                                  costexamt,
                                  insertdt,
                                  iempcode,
                                  inoutdiv,                   -- 입출구분 (미사용이나 고정한다.)
                                  useempcode,                 -- 취급사원 (미사용이나 고정한다.)
                                  usedate,                    -- 취급일자 (미사용이나 고정한다.)
                                  useyn                       -- 사용여부 (미사용이나 고정한다.)
                                )

                        VALUES (
                                   p_compcode,
                                   p_accountno,
                                   p_deposdiv,
                                   p_accremark,
                                   p_deptcode,
                                   p_plantcode,
                                   p_acccode,
                                   p_bankcode,
                                   p_paybank,
                                   p_payaccountno,
                                   p_mainamt,
                                   p_strdate,
                                   p_expdate,
                                   p_penddate,
                                   p_interate,
                                   p_mmperiod,
                                   p_payinday,
                                   p_payinamt,
                                   p_mortgyn,
                                   p_mortgremark,
                                   p_enddiv,
                                   p_enddate,
                                   p_endrate,
                                   p_payincnt,
                                   p_paysumamt,
                                   p_costamt,
                                   p_exrtcode,
                                   p_paysumexamt,
                                   p_costexamt,
                                   SYSDATE,
                                   p_iempcode,
                                   '3',                                   -- 입출구분 (미사용이나 고정한다.)
                                   'gmpit',                               -- 취급사원 (미사용이나 고정한다.)
                                   '2010-11-01',                          -- 취급일자 (미사용이나 고정한다.)
                                   'Y'                                    -- 사용여부 (미사용이나 고정한다.)
                                );

      -- 영업 인터페이스 처리
        INSERT INTO E_ACCOUNTM (CRTDATE, CRTTIME, CRTSEQ, CRTSYS, CRTTYP, STATUS,
                                REMARKS, ACCOUNTNO, ACCREMARK, DEPOSDIV, USEDIV)
        (SELECT  to_char(sysdate,'yyyymmdd'),
                 to_char(sysdate,'HH24MISS'),
                 1,
                 'E',
                 'I',
                 'N',
                 NULL,
                 p_accountno,
                 p_accremark,
                 divname,
                 CASE WHEN p_enddiv = 'A' THEN 'Y' ELSE 'N' END col
        FROM CMCOMMONM
        WHERE    cmmcode = 'AC40'
            AND divcode = p_deposdiv
            AND divcode IN ('11'));

    ELSIF (p_div = 'U') THEN
        UPDATE CMACCOUNTM
         SET deposdiv       = p_deposdiv,
             accremark      = p_accremark,
             deptcode       = p_deptcode,
             plantcode      = p_plantcode,
             acccode        = p_acccode,
             bankcode       = p_bankcode,
             paybank        = p_paybank,
             payaccountno   = p_payaccountno,
             mainamt        = p_mainamt,
             strdate        = p_strdate,
             expdate        = p_expdate,
             penddate       = p_penddate,
             interate       = p_interate,
             mmperiod       = p_mmperiod,
             payinday       = p_payinday,
             payinamt       = p_payinamt,
             mortgyn        = p_mortgyn,
             mortgremark    = p_mortgremark,
             enddiv         = p_enddiv,
             enddate        = p_enddate,
             endrate        = p_endrate,
             payincnt       = p_payincnt,
             paysumamt      = p_paysumamt,
             costamt        = p_costamt,
             exrtcode       = p_exrtcode,
             paysumexamt    = p_paysumexamt,
             costexamt      = p_costexamt,
             updatedt       = SYSDATE,
             uempcode       = p_iempcode
        WHERE compcode      = p_compcode
         AND accountno = p_accountno;

      -- 영업 인터페이스 처리
        INSERT INTO E_ACCOUNTM (CRTDATE, CRTTIME, CRTSEQ, CRTSYS, CRTTYP,
                              STATUS, REMARKS, ACCOUNTNO, ACCREMARK, DEPOSDIV, USEDIV)

        (SELECT  to_char(sysdate,'yyyymmdd'),
                 to_char(sysdate,'HH24MISS'),
                 1,
                'E',
                'U',
                'N',
                 NULL,
                 p_accountno,
                 p_accremark,
                 divname,
                 CASE WHEN p_enddiv = 'A' THEN 'Y' ELSE 'N' END col
        FROM     CMCOMMONM
        WHERE    cmmcode = 'AC40'
             AND divcode = p_deposdiv
             AND divcode IN ('11'));
    ELSIF (p_div = 'D') THEN

      -- 영업 인터페이스 처리
        INSERT INTO E_ACCOUNTM (CRTDATE,
                              CRTTIME,
                              CRTSEQ,
                              CRTSYS,
                              CRTTYP,
                              STATUS,
                              REMARKS,
                              ACCOUNTNO,
                              ACCREMARK,
                              DEPOSDIV,
                              USEDIV)
         (SELECT to_char(sysdate,'yyyymmdd'),
                 to_char(sysdate,'HH24MISS'),
                 1,
                 'E',
                 'D',
                 'N',
                 NULL,
                 A.accountno,
                 A.accremark,
                 b.divname,
                 CASE WHEN enddiv = 'A' THEN 'Y' ELSE 'N' END col
            FROM CMACCOUNTM A
                 JOIN
                 CMCOMMONM b
                    ON     b.cmmcode = 'AC40'
                       AND A.deposdiv = b.divcode
                       AND b.divcode IN ('11')
           WHERE A.accountno = p_accountno);

      DELETE CMACCOUNTM
       WHERE compcode = p_compcode
        AND accountno = p_accountno;
    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
