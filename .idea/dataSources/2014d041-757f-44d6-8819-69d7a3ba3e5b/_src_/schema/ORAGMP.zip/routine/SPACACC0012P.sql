CREATE PROCEDURE        spACacc0012P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0012P
	-- 작 성 자         : 최용석
	-- 작성일자         : 2011-02-10
	-- 수 정 자     : 강현호
	-- E-Mail       : roykang0722@gmail.com
	-- 수정일자      : 2016-12-14
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계전표 반제내역을 관리하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			 IN 	VARCHAR2 DEFAULT '',
	p_compcode		 IN 	VARCHAR2 DEFAULT '',
	p_plantcode 	 IN 	VARCHAR2 DEFAULT '',
	p_expdiv		 IN 	VARCHAR2 DEFAULT '',
	p_empcode		 IN 	VARCHAR2 DEFAULT '',
	p_expym 		 IN 	VARCHAR2 DEFAULT '',
	p_startdate 	 IN 	VARCHAR2 DEFAULT '',
	p_enddate		 IN 	VARCHAR2 DEFAULT '',
	p_slipinno		 IN 	VARCHAR2 DEFAULT '',
	p_slipinseq 	 IN 	NUMBER DEFAULT 0,
	p_createday 	 IN 	NUMBER DEFAULT 0,
	p_repeatmon 	 IN 	NUMBER DEFAULT 0,
	p_acccode		 IN 	VARCHAR2 DEFAULT '',
	p_search		 IN 	VARCHAR2 DEFAULT '',
	p_remark		 IN 	VARCHAR2 DEFAULT '',
	p_endyn 		 IN 	VARCHAR2 DEFAULT '',
	p_repaydate 	 IN 	VARCHAR2 DEFAULT '',
	p_repayamt		 IN 	FLOAT DEFAULT 0,
	p_crtslipinno	 IN 	VARCHAR2 DEFAULT '',
	p_seq			 IN 	NUMBER DEFAULT 0,
	p_mngclucode	 IN 	VARCHAR2 DEFAULT '',
	p_mngcluval 	 IN 	VARCHAR2 DEFAULT '',
	p_mngcludec 	 IN 	VARCHAR2 DEFAULT '',
	p_mngclucode2	 IN 	VARCHAR2 DEFAULT '',
	p_mngcluval2	 IN 	VARCHAR2 DEFAULT '',
	p_mngcludec2	 IN 	VARCHAR2 DEFAULT '',
	p_slipno		 IN 	VARCHAR2 DEFAULT '',
	p_slipseq		 IN 	NUMBER DEFAULT 0,
	p_stramt		 IN 	FLOAT DEFAULT 0,
	p_endamt		 IN 	FLOAT DEFAULT 0,
	p_saccountno	 IN 	VARCHAR2 DEFAULT '',
	p_bankcode		 IN 	VARCHAR2 DEFAULT '',
	p_bankempname	 IN 	VARCHAR2 DEFAULT '',
	p_accountno 	 IN 	VARCHAR2 DEFAULT '',
	p_crttran		 IN 	VARCHAR2 DEFAULT 'Y',
	p_crtmathod 	 IN 	VARCHAR2 DEFAULT '0',
	p_reg_date		 IN 	VARCHAR2 DEFAULT '',
	p_reg_time		 IN 	VARCHAR2 DEFAULT '',
	p_userid		 IN 	VARCHAR2 DEFAULT '',
	p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
	p_reasontext	 IN 	VARCHAR2 DEFAULT '',
	MESSAGE 			OUT VARCHAR2,
	IO_CURSOR			OUT TYPES.DataSet
)
AS
	ip_empcode		 VARCHAR2(20) := p_empcode;
	ip_startdate	 VARCHAR2(10) := p_startdate;
	ip_enddate		 VARCHAR2(10) := p_enddate;
	ip_remark		 VARCHAR2(100) := p_remark;

	p_oslipinseq	 NUMBER(10, 0);

	p_plantcodeR	 VARCHAR2(4);

	v_temp			 NUMBER := 0;

	p_sendacc		 VARCHAR2(50);
	p_tran_dt_seq	 NUMBER(10, 0);
	p_group_nm		 VARCHAR2(50);
	p_list_nm		 VARCHAR2(100);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);

	FOR rec IN (SELECT CASE WHEN value1 = 'Y' THEN '%' ELSE ip_empcode END AS alias1
				FROM   SYSPARAMETERMANAGE
				WHERE  parametercode = 'accsliprpyview'
					   AND p_div IN ('SM', 'SC'))
	LOOP
		ip_empcode := rec.alias1;
	END LOOP;



	IF (UPPER(p_div) = UPPER('SM'))
	THEN -- 반제마스터내역 검색
		ip_startdate := p_expym || '-01';
		ip_enddate := TO_CHAR(ADD_MONTHS(TO_DATE(ip_startdate, 'YYYY-MM-DD'), 1) - 1, 'YYYY-MM-DD');

		OPEN IO_CURSOR FOR
			SELECT	 A.compcode, -- 회사코드
					 A.slipinno, -- 전표번호
					 A.slipinseq, -- 전표일번
					 A.expdiv, -- 반제구분
					 A.empcode, -- 등록사원
					 A.startdate, -- 시작일자
					 A.enddate, -- 종료일자
					 A.createday, -- 생성일자
					 A.repeatmon, -- 생성주기
					 A.acccode, -- 상대계정
					 A.remark, -- 반제비고
					 A.endyn, -- 완료여부
					 b.slipdate, -- 회계일자
					 b.slipnum, -- 회계번호
					 NVL(b.debamt + b.creamt, 0) slipamt, -- 전표금액
					 b.remark1 sremark, -- 전표비고
					 c.accname, -- 상대계정명
					 D.accname saccname, -- 전표계정명
					 NVL(E.repayamt, 0) repayamt, -- 반제금액
					 b.plantcode
			FROM	 ACORDRPYM A -- 반제마스터내역
					 JOIN ACORDD b
						 ON A.compcode = b.compcode -- 전표상세내역
							AND A.slipinno = b.slipinno
							AND A.slipinseq = b.slipinseq
							AND b.plantcode LIKE p_plantcode
					 LEFT JOIN ACACCM c ON A.acccode = c.acccode -- 상대계정정보
					 LEFT JOIN ACACCM D ON b.acccode = D.acccode -- 전표계정정보
					 LEFT JOIN (SELECT	 A.compcode,
										 A.slipinno,
										 A.slipinseq,
										 SUM(b.repayamt) repayamt
								FROM	 ACORDRPYM A
										 JOIN ACORDRPYD b
											 ON A.compcode = b.compcode
												AND A.slipinno = b.slipinno
												AND A.slipinseq = b.slipinseq
										 JOIN ACORDM c
											 ON b.compcode = c.compcode -- 전표내역
												AND b.crtslipinno = c.slipinno
								WHERE	 A.compcode = p_compcode
										 AND A.expdiv = p_expdiv
										 AND A.empcode LIKE ip_empcode
										 AND A.startdate <= ip_enddate
										 AND ip_startdate <= NVL(NULLIF(A.enddate, NULL), TO_CHAR(ADD_MONTHS(SYSDATE, 120), 'YYYY-MM-DD'))
								GROUP BY A.compcode, A.slipinno, A.slipinseq) E
						 ON A.compcode = E.compcode
							AND A.slipinno = E.slipinno
							AND A.slipinseq = E.slipinseq
			WHERE	 A.compcode = p_compcode
					 AND A.expdiv = p_expdiv
					 AND A.empcode LIKE ip_empcode
					 AND A.startdate <= ip_enddate
					 AND ip_startdate <= NVL(NULLIF(A.enddate, NULL), TO_CHAR(ADD_MONTHS(SYSDATE, 120), 'YYYY-MM-DD'))
					 AND A.endyn = p_endyn
			ORDER BY b.slipdate, b.slipnum, A.slipinseq;
	ELSIF (UPPER(p_div) = UPPER('SD'))
	THEN -- 반제상세내역 검색
		-- 전표가 없는 반제정보 갱신
		UPDATE ACORDRPYM A
		SET    A.endyn = 'N'
		WHERE  (A.COMPCODE, A.SLIPINNO, A.SLIPINSEQ) = (SELECT A.COMPCODE,
															   A.SLIPINNO,
															   A.SLIPINSEQ
														FROM   ACORDRPYM A
															   JOIN ACORDRPYD b
																   ON A.compcode = b.compcode -- 반제상세내역
																	  AND A.slipinno = b.slipinno
																	  AND A.slipinseq = b.slipinseq
															   LEFT JOIN ACORDM c
																   ON b.compcode = c.compcode -- 전표내역
																	  AND b.crtslipinno = c.slipinno
														WHERE  A.compcode = p_compcode
															   AND A.slipinno = p_slipinno
															   AND A.slipinseq = p_slipinseq
															   AND c.compcode IS NULL);


		DELETE FROM ACORDRPYD A
		WHERE		(A.COMPCODE, A.SLIPINNO, A.SLIPINSEQ, A.REPAYDATE) = (SELECT A.COMPCODE,
																				 A.SLIPINNO,
																				 A.SLIPINSEQ,
																				 A.REPAYDATE
																		  FROM	 ACORDRPYD A -- 반제상세내역
																				 LEFT JOIN ACORDM b
																					 ON A.compcode = b.compcode -- 전표내역
																						AND A.crtslipinno = b.slipinno
																		  WHERE  A.compcode = p_compcode
																				 AND A.slipinno = p_slipinno
																				 AND A.slipinseq = p_slipinseq
																				 AND A.autocrtyn = 'Y'
																				 AND b.compcode IS NULL);



		UPDATE ACORDRPYD A
		SET    A.crtslipinno = ''
		WHERE  (A.COMPCODE, A.SLIPINNO, A.SLIPINSEQ, A.REPAYDATE) = (SELECT A.COMPCODE,
																			A.SLIPINNO,
																			A.SLIPINSEQ,
																			A.REPAYDATE
																	 FROM	ACORDRPYD A -- 반제상세내역
																			LEFT JOIN ACORDM b
																				ON A.compcode = b.compcode -- 전표내역
																				   AND A.crtslipinno = b.slipinno
																	 WHERE	A.compcode = p_compcode
																			AND A.slipinno = p_slipinno
																			AND A.slipinseq = p_slipinseq
																			AND A.autocrtyn = 'N'
																			AND b.compcode IS NULL);

		-- 반제상세내역 검색
		OPEN IO_CURSOR FOR
			SELECT	 A.compcode, -- 회사코드
					 A.slipinno, -- 전표번호
					 A.slipinseq, -- 전표일번
					 A.repaydate, -- 반제일자
					 A.repayamt, -- 반제금액
					 b.slipinno crtslipinno, -- 생선전표번호
					 b.slipdate, -- 회계일자
					 b.slipnum, -- 회계번호
					 c.endyn, -- 완료여부
					 c.repayamt -- 반제금액
			FROM	 ACORDRPYD A -- 반제상세내역
					 LEFT JOIN ACORDM b
						 ON A.compcode = b.compcode -- 전표내역
							AND A.crtslipinno = b.slipinno
					 JOIN (SELECT MAX(A.endyn) endyn,
								  NVL(SUM(b.repayamt), 0) repayamt
						   FROM   ACORDRPYM A
								  LEFT JOIN ACORDRPYD b
									  ON A.compcode = b.compcode
										 AND A.slipinno = b.slipinno
										 AND A.slipinseq = b.slipinseq
						   WHERE  A.compcode = p_compcode
								  AND A.slipinno = p_slipinno
								  AND A.slipinseq = p_slipinseq) c
						 ON 1 = 1
			WHERE	 A.compcode = p_compcode
					 AND A.slipinno = p_slipinno
					 AND A.slipinseq = p_slipinseq
			ORDER BY A.repaydate;
	ELSIF (UPPER(p_div) = UPPER('SS'))
	THEN -- 반제관리내역 검색
		OPEN IO_CURSOR FOR
			SELECT	 A.compcode, -- 회사코드
					 A.slipinno, -- 전표번호
					 A.slipinseq, -- 전표일번
					 A.seq, -- 일련번호
					 A.mngclucode, -- 관리코드
					 A.mngcluval, -- 항목코드
					 A.mngcludec, -- 항목명
					 NVL(c.mngcluname, '') mngcluname, -- 관리명
					 NVL(c.requireyn, '') requireyn, -- 필수입력여부
					 NVL(c.returnyn, '') returnyn, -- 반제여부
					 NVL(c.remainyn, '') remainyn, -- 잔액관리여부
					 NVL(D.mngcludiv, '') mngcludiv, -- 관리항목형태
					 NVL(D.codehelp, '') codehelp, -- 코드헬프번호
					 NVL(D.remark, '') codermk -- 코드헬프비고
			FROM	 ACORDRPYS A -- 반제관리내역
					 JOIN ACORDRPYM b
						 ON A.compcode = b.compcode -- 반제마스터내역
							AND A.slipinno = b.slipinno
							AND A.slipinseq = b.slipinseq
					 LEFT JOIN ACACCMNGM c
						 ON b.acccode = c.acccode -- 관리항목필수여부
							AND CASE WHEN b.expdiv = '1' THEN '2' ELSE '1' END = c.dcdiv
							AND A.mngclucode = c.mngclucode
					 LEFT JOIN ACMNGM D ON A.mngclucode = D.mngclucode -- 관리항목정보
			WHERE	 A.compcode = p_compcode
					 AND A.slipinno = p_slipinno
					 AND A.slipinseq = p_slipinseq
			ORDER BY A.seq;
	ELSIF (UPPER(p_div) = UPPER('SA'))
	THEN -- 계정별 관리항목 검색
		FOR rec IN (SELECT MAX(slipinseq) AS alias1
					FROM   ACORDS
					WHERE  compcode = p_compcode
						   AND slipinno = p_slipinno
						   AND slipinseq <> p_slipinseq)
		LOOP
			p_oslipinseq := rec.alias1;
		END LOOP;


		OPEN IO_CURSOR FOR
			SELECT	 NVL(A.seq, 0) seq, -- 일련번호
					 NVL(A.mngclucode, '') mngclucode, -- 관리항목코드
					 COALESCE(c.mngcluval, D.mngcluval, '') mngcluval, -- 관리항목값
					 COALESCE(c.mngcludec, D.mngcludec, '') mngcludec, -- 관리항목값명
					 NVL(A.mngcluname, '') mngcluname, -- 관리항목명
					 NVL(A.requireyn, '') requireyn, -- 필수입력여부
					 NVL(A.returnyn, '') returnyn, -- 반제여부
					 NVL(A.remainyn, '') remainyn, -- 잔액관리여부
					 NVL(b.mngcludiv, '') mngcludiv, -- 관리항목형태
					 NVL(b.codehelp, '') codehelp, -- 코드헬프번호
					 NVL(b.remark, '') codermk -- 코드헬프비고
			FROM	 ACACCMNGM A -- 반제마스터내역
					 LEFT JOIN ACMNGM b ON A.mngclucode = b.mngclucode -- 관리항목정보
					 LEFT JOIN ACORDS c
						 ON c.compcode = p_compcode -- 전표관리항목내역
							AND c.slipinno = p_slipinno
							AND c.slipinseq = p_slipinseq
							AND b.mngclucode = c.mngclucode
					 LEFT JOIN ACORDS D
						 ON D.compcode = p_compcode -- 전표관리항목내역
							AND D.slipinno = p_slipinno
							AND D.slipinseq = p_oslipinseq
							AND b.mngclucode = D.mngclucode
			WHERE	 A.acccode = p_acccode
					 AND A.dcdiv = CASE WHEN p_expdiv = '1' THEN '2' ELSE '1' END
			ORDER BY A.seq;
	ELSIF (UPPER(p_div) = UPPER('SO'))
	THEN -- 회계전표내역 검색
		OPEN IO_CURSOR FOR
			SELECT	 'N' crtsel,
					 A.slipinno,
					 A.slipinseq,
					 A.dcdiv,
					 A.acccode,
					 b.accname,
					 A.debamt + A.creamt slipamt,
					 z.slipindate,
					 z.slipinnum,
					 A.slipdate,
					 A.slipnum,
					 A.remark1,
					 c.mngcludec1,
					 c.mngcludec2,
					 c.mngcludec3
			FROM	 ACORDD A
					 JOIN ACORDM z
						 ON A.compcode = z.compcode
							AND A.slipinno = z.slipinno
					 JOIN ACACCM b
						 ON A.acccode = b.acccode
							AND b.dcdiv = CASE WHEN p_expdiv = '1' THEN '2' ELSE '1' END
							AND b.returnyn = 'Y'
					 LEFT JOIN (SELECT	 compcode,
										 slipinno,
										 slipinseq,
										 MAX(CASE WHEN seq = 1 THEN mngcludec ELSE '' END) mngcludec1,
										 MAX(CASE WHEN seq = 2 THEN mngcludec ELSE '' END) mngcludec2,
										 MAX(CASE WHEN seq = 3 THEN mngcludec ELSE '' END) mngcludec3,
										 MAX(CASE WHEN seq = 4 THEN mngcludec ELSE '' END) mngcludec4,
										 MAX(CASE WHEN seq = 5 THEN mngcludec ELSE '' END) mngcludec5,
										 MAX(CASE WHEN seq = 6 THEN mngcludec ELSE '' END) mngcludec6
								FROM	 (SELECT A.compcode,
												 A.slipinno,
												 A.slipinseq,
												 ROW_NUMBER() OVER (PARTITION BY A.compcode, A.slipinno, A.slipinseq ORDER BY b.seq) seq,
												 NVL(b.mngcludec, '') || ' : ' || NVL(b.mngcluval, '') mngcludec
										  FROM	 ACORDD A
												 JOIN ACORDS b
													 ON A.compcode = b.compcode
														AND A.slipinno = b.slipinno
														AND A.slipinseq = b.slipinseq
												 LEFT JOIN ACMNGM c ON b.mngclucode = c.mngclucode
										  WHERE  A.compcode = p_compcode
												 AND A.acccode LIKE p_acccode || '%'
												 AND A.slipdate BETWEEN ip_startdate AND ip_enddate
												 AND (p_expdiv = '2'
													  AND A.dcdiv IN ('1', '4')
													  OR p_expdiv = '1'
														 AND A.dcdiv IN ('2', '3'))) A
								GROUP BY compcode, slipinno, slipinseq) c
						 ON A.compcode = c.compcode
							AND A.slipinno = c.slipinno
							AND A.slipinseq = c.slipinseq
					 LEFT JOIN ACORDRPYM D
						 ON A.compcode = D.compcode
							AND A.slipinno = D.slipinno
							AND A.slipinseq = D.slipinseq
					 LEFT JOIN ACORDRPYP E
						 ON A.compcode = E.compcode
							AND A.slipinno = E.slipinno
							AND A.slipinseq = E.slipinseq
			WHERE	 A.compcode = p_compcode
					 AND A.slipdate BETWEEN ip_startdate AND ip_enddate
					 AND (p_expdiv = '2'
						  AND A.dcdiv IN ('1', '4')
						  OR p_expdiv = '1'
							 AND A.dcdiv IN ('2', '3'))
					 AND A.acccode LIKE p_acccode || '%'
					 AND A.plantcode LIKE p_plantcode
					 AND D.compcode IS NULL
					 AND (A.remark1 LIKE '%' || p_search || '%'
						  OR A.remark2 LIKE '%' || p_search || '%'
						  OR c.mngcludec1 LIKE '%' || p_search || '%'
						  OR c.mngcludec2 LIKE '%' || p_search || '%'
						  OR c.mngcludec3 LIKE '%' || p_search || '%'
						  OR c.mngcludec4 LIKE '%' || p_search || '%'
						  OR c.mngcludec5 LIKE '%' || p_search || '%'
						  OR c.mngcludec6 LIKE '%' || p_search || '%')
					 AND A.debamt + A.creamt BETWEEN p_stramt AND p_endamt
					 AND E.compcode IS NULL
			ORDER BY A.slipdate, A.slipnum, A.slipinseq;
	ELSIF (p_div = 'SC')
	THEN -- 반제전표생성 검색
		-- 전표가 없는 반제정보 갱신
		MERGE INTO ACORDRPYM A
		USING	   (SELECT b.compcode,
						   b.slipinno,
						   b.slipinseq
					FROM   ACORDRPYD a -- 반제상세내역
						   JOIN ACORDRPYM b -- 반제내역
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno
								  AND a.slipinseq = b.slipinseq
						   LEFT JOIN ACORDM c -- 전표내역
							   ON a.compcode = c.compcode
								  AND a.crtslipinno = c.slipinno
					WHERE  a.compcode = p_compcode
						   AND a.repaydate BETWEEN p_startdate AND p_enddate
						   AND c.compcode IS NULL) src
		ON		   (a.compcode = src.compcode
					AND a.slipinno = src.slipinno
					AND a.slipinseq = src.slipinseq)
		WHEN MATCHED
		THEN
			UPDATE SET a.endyn = 'N';

		-- 기존 작업
		--        UPDATE  ACORDRPYM A
		--        SET     A.endyn = 'N'
		--        WHERE   ( A.COMPCODE , A.SLIPINNO , A.SLIPINSEQ ) = (   SELECT  b.COMPCODE
		--                                                                        , b.SLIPINNO
		--                                                                        , b.SLIPINSEQ
		--
		--                                                                FROM    ACORDRPYD A -- 반제상세내역
		--                                                                        JOIN ACORDRPYM b ON A.compcode = b.compcode -- 반제내역
		--                                                                                            AND A.slipinno = b.slipinno
		--                                                                                            AND A.slipinseq = b.slipinseq
		--                                                                        LEFT JOIN ACORDM c ON A.compcode = c.compcode -- 전표내역
		--                                                                                              AND A.crtslipinno = c.slipinno
		--                                                                WHERE   A.compcode = p_compcode
		--                                                                        AND A.repaydate BETWEEN ip_startdate AND ip_enddate
		--                                                                        AND c.compcode IS NULL  ) ;
		FOR REC IN (SELECT a.compcode,
						   a.slipinno,
						   a.slipinseq,
						   a.repaydate
					FROM   ACORDRPYD a -- 반제상세내역
						   LEFT JOIN ACORDM b -- 전표내역
							   ON a.compcode = b.compcode
								  AND a.crtslipinno = b.slipinno
					WHERE  a.compcode = p_compcode
						   AND a.repaydate BETWEEN p_startdate AND p_enddate
						   AND a.autocrtyn = 'Y'
						   AND b.compcode IS NULL)
		LOOP
			DELETE FROM ACORDRPYD a
			WHERE		a.compcode = rec.compcode
						AND a.slipinno = rec.slipinno
						AND a.slipinseq = rec.slipinseq
						AND a.repaydate = rec.repaydate;
		END LOOP;

		-- 기존 작업
		--        DELETE FROM ACORDRPYD A
		--        WHERE ( A.COMPCODE, A.SLIPINNO, A.SLIPINSEQ, A.REPAYDATE ) = ( SELECT  A.COMPCODE
		--                                                                                , A.SLIPINNO
		--                                                                                , A.SLIPINSEQ
		--                                                                                , A.REPAYDATE
		--
		--                                                                        FROM    ACORDRPYD A -- 반제상세내역
		--                                                                                LEFT JOIN ACORDM b ON A.compcode = b.compcode -- 전표내역
		--                                                                                                      AND A.crtslipinno = b.slipinno
		--                                                                        WHERE   A.compcode = p_compcode
		--                                                                                AND A.repaydate BETWEEN ip_startdate AND ip_enddate
		--                                                                                AND A.autocrtyn = 'Y'
		--                                                                                AND b.compcode IS NULL  ) ;

		MERGE INTO ACORDRPYD a
		USING	   (SELECT a.compcode,
						   a.slipinno,
						   a.slipinseq,
						   a.repaydate
					FROM   ACORDRPYD a -- 반제상세내역
						   LEFT JOIN ACORDM b -- 전표내역
							   ON a.compcode = b.compcode
								  AND a.crtslipinno = b.slipinno
					WHERE  a.compcode = p_compcode
						   AND a.repaydate BETWEEN p_startdate AND p_enddate
						   AND a.autocrtyn = 'N'
						   AND b.compcode IS NULL) src
		ON		   (a.compcode = src.compcode
					AND a.slipinno = src.slipinno
					AND a.slipinseq = src.slipinseq
					AND a.repaydate = src.repaydate)
		WHEN MATCHED
		THEN
			UPDATE SET a.crtslipinno = '';


		-- 기존 작업
		--  UPDATE ACORDRPYD A
		--  SET    A.crtslipinno = ''
		--  WHERE  (A.COMPCODE, A.SLIPINNO, A.SLIPINSEQ, A.REPAYDATE) = (SELECT A.COMPCODE,
		--                   A.SLIPINNO,
		--                   A.SLIPINSEQ,
		--                   A.REPAYDATE
		--                  FROM ACORDRPYD A -- 반제상세내역
		--                   LEFT JOIN ACORDM b
		--                    ON A.compcode = b.compcode -- 전표내역
		--                       AND A.crtslipinno = b.slipinno
		--                  WHERE A.compcode = p_compcode
		--                   AND A.repaydate BETWEEN ip_startdate AND ip_enddate
		--                   AND A.autocrtyn = 'N'
		--                   AND b.compcode IS NULL);

		p_plantcodeR := '';

		FOR rec IN (SELECT value2
					FROM   SYSPARAMETERMANAGE A
					WHERE  parametercode = 'accsliprpyview')
		LOOP
			p_plantcodeR := rec.value2;
		END LOOP;


		-- 반제전표생성 검색
		OPEN IO_CURSOR FOR
			WITH TT_ACORDRPYD
				 AS (SELECT 'N' crtsel, -- 출력여부
							A.slipinno, -- 전표번호
							A.slipinseq, -- 일련번호
							c.slipdate, -- 전표일자
							c.slipnum, -- 전표번호
							f.accname slipaccname, -- 전표계정명
							c.remark1 slipremark, -- 전표비고
							A.repaydate, -- 생성일자
							A.repayamt, -- 반제금액
							A.repayamt createamt, -- 생성금액
							c.debamt + c.creamt - NVL(G.repayamt, 0) restamt, -- 생성잔액
							b.acccode, -- 상대계정코드
							D.accname, -- 상대계정명
							b.remark, -- 반제비고
							COALESCE(j.custname, M.custname, K.mngcludec, '') custname, -- 거래처
							COALESCE(j.bankcode, M.bankcode, l.paybankdiv, '') bankcode, -- 은행코드
							COALESCE(j.bankempname, M.bankempname, l.payaccempnm, '') bankempname, -- 예금주
							COALESCE(j.accountno, M.accountno, l.payaccno, '') accountno, -- 계좌번호
							h.mngcluval saccountno, -- 지급계좌번호
							'1' crediv, -- 생성구분
							CASE WHEN p_plantcodeR IS NULL THEN c.plantcode ELSE p_plantcodeR END plantcode -- 사업장
					 FROM	ACORDRPYD A -- 반제상세내역
							JOIN ACORDRPYM b
								ON A.compcode = b.compcode -- 반제마스터내역
								   AND A.slipinno = b.slipinno
								   AND A.slipinseq = b.slipinseq
								   AND b.endyn = 'N'
							JOIN ACORDD c
								ON A.compcode = c.compcode -- 전표상세내역
								   AND A.slipinno = c.slipinno
								   AND A.slipinseq = c.slipinseq
								   AND c.plantcode LIKE p_plantcode
								   AND NVL(c.acccode,' ') LIKE p_acccode || '%'
							JOIN ACACCM D ON NVL(b.acccode,' ') = NVL(D.acccode,' ') -- 상대계정정보
							LEFT JOIN ACORDM E
								ON A.compcode = E.compcode -- 전표내역
								   AND A.crtslipinno = E.slipinno
							LEFT JOIN ACACCM f ON NVL(c.acccode,' ') = NVL(f.acccode,' ') -- 전표계정정보
							LEFT JOIN (SELECT	A.compcode,
												A.slipinno,
												A.slipinseq,
												A.repaydate,
												SUM(c.repayamt) repayamt
									   FROM 	ACORDRPYD A
												JOIN ACORDRPYM b
													ON A.compcode = b.compcode
													   AND A.slipinno = b.slipinno
													   AND A.slipinseq = b.slipinseq
												JOIN ACORDRPYD c
													ON A.compcode = c.compcode
													   AND A.slipinno = c.slipinno
													   AND A.slipinseq = c.slipinseq
													   AND A.repaydate >= c.repaydate
									   WHERE	A.compcode = p_compcode
												AND A.repaydate BETWEEN ip_startdate AND ip_enddate
												AND b.expdiv = p_expdiv
												AND b.empcode LIKE ip_empcode
									   GROUP BY A.compcode, A.slipinno, A.slipinseq, A.repaydate) G
								ON A.compcode = G.compcode
								   AND A.slipinno = G.slipinno
								   AND A.slipinseq = G.slipinseq
								   AND A.repaydate = G.repaydate
							LEFT JOIN ACORDRPYS h
								ON A.compcode = h.compcode
								   AND A.slipinno = h.slipinno
								   AND A.slipinseq = h.slipinseq
								   AND h.mngclucode = 'S020'
							LEFT JOIN ACORDRPYS i
								ON A.compcode = i.compcode
								   AND A.slipinno = i.slipinno
								   AND A.slipinseq = i.slipinseq
								   AND i.mngclucode = 'S010'
							LEFT JOIN CMCUSTM j ON i.mngcluval = j.custcode
							LEFT JOIN ACORDRPYS K
								ON A.compcode = K.compcode
								   AND A.slipinno = K.slipinno
								   AND A.slipinseq = K.slipinseq
								   AND K.mngclucode = 'S050'
							LEFT JOIN PSEMPPAYBASEM l ON K.mngcluval = l.empcode
							LEFT JOIN (SELECT A.compcode,
											  A.slipinno,
											  A.slipinseq,
											  A.repaydate,
											  c.mngcluval bankcode,
											  D.mngcluval bankempname,
											  REPLACE(E.mngcluval, '-', '') accountno,
											  f.mngcluval custname
									   FROM   ACORDRPYD A -- 반제상세내역
											  JOIN ACORDRPYM b
												  ON A.compcode = b.compcode -- 반제마스터내역
													 AND A.slipinno = b.slipinno
													 AND A.slipinseq = b.slipinseq
													 AND b.endyn = 'N'
											  LEFT JOIN ACORDS c
												  ON A.compcode = c.compcode
													 AND A.slipinno = c.slipinno
													 AND A.slipinseq = c.slipinseq
													 AND c.mngclucode = 'S030'
													 AND c.mngcluval IS NOT NULL
											  LEFT JOIN ACORDS D
												  ON A.compcode = D.compcode
													 AND A.slipinno = D.slipinno
													 AND A.slipinseq = D.slipinseq
													 AND D.mngclucode = 'U091'
													 AND D.mngcluval IS NOT NULL
											  LEFT JOIN ACORDS E
												  ON A.compcode = E.compcode
													 AND A.slipinno = E.slipinno
													 AND A.slipinseq = E.slipinseq
													 AND E.mngclucode = 'U090'
													 AND E.mngcluval IS NOT NULL
											  LEFT JOIN ACORDS f
												  ON A.compcode = f.compcode
													 AND A.slipinno = f.slipinno
													 AND A.slipinseq = f.slipinseq
													 AND f.mngclucode = 'U092'
													 AND f.mngcluval IS NOT NULL
									   WHERE  A.compcode = p_compcode
											  AND A.repaydate BETWEEN ip_startdate AND ip_enddate
											  AND b.expdiv = p_expdiv
											  AND b.empcode LIKE ip_empcode) M
								ON A.slipinno = M.slipinno
								   AND A.slipinseq = M.slipinseq
								   AND A.repaydate = M.repaydate
					 WHERE	A.compcode = p_compcode
							AND A.repaydate BETWEEN ip_startdate AND ip_enddate
							AND b.expdiv = p_expdiv
							AND b.empcode LIKE ip_empcode
							AND E.compcode IS NULL
					 UNION ALL
					 SELECT 'N' crtsel, -- 출력여부
							A.slipinno, -- 전표번호
							A.slipinseq, -- 일련번호
							c.slipdate, -- 전표일자
							c.slipnum, -- 전표번호
							E.accname slipaccname, -- 전표계정명
							c.remark1 slipremark, -- 전표비고
							'' repaydate, -- 생성일자
							c.debamt + c.creamt - NVL(b.repayamt, 0) repayamt, -- 반제금액
							c.debamt + c.creamt - NVL(b.repayamt, 0) createamt, -- 생성금액
							0 restamt, -- 생성잔액
							A.acccode, -- 상대계정코드
							D.accname, -- 상대계정명
							A.remark, -- 반제비고
							COALESCE(j.custname, M.custname, K.mngcludec, '') custname, -- 거래처
							COALESCE(j.bankcode, M.bankcode, l.paybankdiv, '') bankcode, -- 은행코드
							COALESCE(j.bankempname, M.bankempname, l.payaccempnm, '') bankempname, -- 예금주
							COALESCE(j.accountno, M.accountno, l.payaccno, '') accountno, -- 계좌번호
							h.mngcluval saccountno, -- 지급계좌번호
							'2' crediv, -- 생성구분
							CASE WHEN p_plantcodeR IS NULL THEN c.plantcode ELSE p_plantcodeR END plantcode -- 사업장
					 FROM	ACORDRPYM A -- 반제마스터내역
							JOIN (SELECT   A.slipinno,
										   A.slipinseq,
										   SUM(b.repayamt) repayamt
								  FROM	   ACORDRPYM A -- 반제마스터내역
										   LEFT JOIN ACORDRPYD b
											   ON A.compcode = b.compcode -- 반제상세내역
												  AND A.slipinno = b.slipinno
												  AND A.slipinseq = b.slipinseq
												  AND b.crtslipinno IS NOT NULL
										   LEFT JOIN ACORDRPYD c
											   ON A.compcode = c.compcode -- 반제상세내역
												  AND A.slipinno = c.slipinno
												  AND A.slipinseq = c.slipinseq
												  AND c.crtslipinno IS NULL
								  WHERE    A.compcode = p_compcode
										   AND A.expdiv = p_expdiv
										   AND A.empcode LIKE ip_empcode
										   AND A.startdate <= ip_enddate
										   AND ip_startdate <= A.enddate
										   AND A.endyn = 'N'
										   AND c.compcode IS NULL
								  GROUP BY A.slipinno, A.slipinseq) b
								ON A.slipinno = b.slipinno
								   AND A.slipinseq = b.slipinseq
							JOIN ACORDD c
								ON A.compcode = c.compcode -- 전표상세내역
								   AND A.slipinno = c.slipinno
								   AND A.slipinseq = c.slipinseq
								   AND c.plantcode LIKE p_plantcode
								   AND NVL(c.acccode,' ') LIKE p_acccode || '%'
							JOIN ACACCM D ON NVL(A.acccode,' ') = NVL(D.acccode,' ') -- 상대계정정보
							LEFT JOIN ACACCM E ON NVL(c.acccode,' ') = NVL(E.acccode,' ') -- 전표계정정보
							LEFT JOIN ACORDRPYS h
								ON A.compcode = h.compcode
								   AND A.slipinno = h.slipinno
								   AND A.slipinseq = h.slipinseq
								   AND h.mngclucode = 'S020'
							LEFT JOIN ACORDRPYS i
								ON A.compcode = i.compcode
								   AND A.slipinno = i.slipinno
								   AND A.slipinseq = i.slipinseq
								   AND i.mngclucode = 'S010'
							LEFT JOIN CMCUSTM j ON i.mngcluval = j.custcode
							LEFT JOIN ACORDRPYS K
								ON A.compcode = K.compcode
								   AND A.slipinno = K.slipinno
								   AND A.slipinseq = K.slipinseq
								   AND K.mngclucode = 'S050'
							LEFT JOIN PSEMPPAYBASEM l ON K.mngcluval = l.empcode
							LEFT JOIN (SELECT A.compcode,
											  A.slipinno,
											  A.slipinseq,
											  c.mngcluval bankcode,
											  D.mngcluval bankempname,
											  REPLACE(E.mngcluval, '-', '') accountno,
											  f.mngcluval custname
									   FROM   ACORDRPYM A -- 반제상세내역
											  LEFT JOIN ACORDS c
												  ON A.compcode = c.compcode
													 AND A.slipinno = c.slipinno
													 AND A.slipinseq = c.slipinseq
													 AND c.mngclucode = 'S030'
													 AND c.mngcluval IS NOT NULL
											  LEFT JOIN ACORDS D
												  ON A.compcode = D.compcode
													 AND A.slipinno = D.slipinno
													 AND A.slipinseq = D.slipinseq
													 AND D.mngclucode = 'U091'
													 AND D.mngcluval IS NOT NULL
											  LEFT JOIN ACORDS E
												  ON A.compcode = E.compcode
													 AND A.slipinno = E.slipinno
													 AND A.slipinseq = E.slipinseq
													 AND E.mngclucode = 'U090'
													 AND E.mngcluval IS NOT NULL
											  LEFT JOIN ACORDS f
												  ON A.compcode = f.compcode
													 AND A.slipinno = f.slipinno
													 AND A.slipinseq = f.slipinseq
													 AND f.mngclucode = 'U092'
													 AND f.mngcluval IS NOT NULL
									   WHERE  A.compcode = p_compcode
											  AND A.expdiv = p_expdiv
											  AND A.empcode LIKE ip_empcode
											  AND A.startdate <= ip_enddate
											  AND ip_startdate <= A.enddate
											  AND A.endyn = 'N') M
								ON A.slipinno = M.slipinno
								   AND A.slipinseq = M.slipinseq
					 WHERE	A.compcode = p_compcode
							AND A.expdiv = p_expdiv
							AND A.empcode LIKE ip_empcode
							AND A.startdate <= ip_enddate
							AND ip_startdate <= A.enddate
							AND A.endyn = 'N') --WITH END
			SELECT	 A.*,
					 b.mngcludec1,
					 b.mngcludec2,
					 b.mngcludec3,
					 b.mngcludec4,
					 b.mngcludec5,
					 b.mngcludec6
			FROM	 TT_ACORDRPYD A
					 LEFT JOIN (SELECT	 slipinno,
										 slipinseq,
										 MAX(CASE WHEN seq = 1 THEN mngcludec ELSE '' END) mngcludec1,
										 MAX(CASE WHEN seq = 2 THEN mngcludec ELSE '' END) mngcludec2,
										 MAX(CASE WHEN seq = 3 THEN mngcludec ELSE '' END) mngcludec3,
										 MAX(CASE WHEN seq = 4 THEN mngcludec ELSE '' END) mngcludec4,
										 MAX(CASE WHEN seq = 5 THEN mngcludec ELSE '' END) mngcludec5,
										 MAX(CASE WHEN seq = 6 THEN mngcludec ELSE '' END) mngcludec6
								FROM	 (SELECT b.slipinno,
												 b.slipinseq,
												 ROW_NUMBER() OVER (PARTITION BY b.slipinno, b.slipinseq ORDER BY c.seq) seq,
												 NVL(c.mngcludec, '') || ' : ' || NVL(c.mngcluval, '') mngcludec
										  FROM	 TT_ACORDRPYD A
												 JOIN ACORDD b
													 ON b.compcode = p_compcode
														AND A.slipinno = b.slipinno
														AND A.slipinseq = b.slipinseq
												 JOIN ACORDS c
													 ON b.compcode = c.compcode
														AND b.slipinno = c.slipinno
														AND b.slipinseq = c.slipinseq) A
								GROUP BY slipinno, slipinseq) b
						 ON A.slipinno = b.slipinno
							AND A.slipinseq = b.slipinseq
			ORDER BY A.slipdate, A.slipinno, A.slipinseq, A.repaydate;
	ELSIF (p_div = 'IM')
	THEN -- 반제마스터내역 입력
		INSERT INTO ACORDRPYM(compcode,
							  slipinno,
							  slipinseq,
							  expdiv,
							  empcode,
							  startdate,
							  enddate,
							  createday,
							  repeatmon,
							  acccode,
							  remark,
							  endyn,
							  insertdt,
							  iempcode)
		VALUES		(p_compcode,
					 p_slipinno,
					 p_slipinseq,
					 p_expdiv,
					 ip_empcode,
					 ip_startdate,
					 ip_enddate,
					 p_createday,
					 p_repeatmon,
					 p_acccode,
					 ip_remark,
					 p_endyn,
					 SYSDATE,
					 ip_empcode);
	ELSIF (p_div = 'UM')
	THEN -- 반제마스터내역 수정
		UPDATE ACORDRPYM
		SET    expdiv = p_expdiv,
			   empcode = ip_empcode,
			   startdate = ip_startdate,
			   enddate = ip_enddate,
			   createday = p_createday,
			   repeatmon = p_repeatmon,
			   acccode = p_acccode,
			   remark = ip_remark,
			   endyn = p_endyn,
			   updatedt = SYSDATE,
			   uempcode = ip_empcode
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq;
	ELSIF (p_div = 'DM')
	THEN -- 반제마스터내역 삭제
		FOR rec IN (SELECT 1 AS alias1
					FROM   DUAL
					WHERE  NOT EXISTS
							   (SELECT *
								FROM   ACORDRPYD A
									   JOIN ACORDM b
										   ON A.compcode = b.compcode
											  AND A.crtslipinno = b.slipinno
								WHERE  A.compcode = p_compcode
									   AND A.slipinno = p_slipinno
									   AND A.slipinseq = p_slipinseq))
		LOOP
			v_temp := rec.alias1;
		END LOOP;

		IF v_temp = 1
		THEN
			DELETE ACORDRPYS
			WHERE  compcode = p_compcode
				   AND slipinno = p_slipinno
				   AND slipinseq = p_slipinseq;

			DELETE ACORDRPYD
			WHERE  compcode = p_compcode
				   AND slipinno = p_slipinno
				   AND slipinseq = p_slipinseq;

			DELETE ACORDRPYM
			WHERE  compcode = p_compcode
				   AND slipinno = p_slipinno
				   AND slipinseq = p_slipinseq;
		ELSE
			MESSAGE := '';
		END IF;
	ELSIF (UPPER(p_div) = UPPER('ID'))
	THEN -- 반제상세내역 입력
		INSERT INTO ACORDRPYD(compcode,
							  slipinno,
							  slipinseq,
							  repaydate,
							  repayamt,
							  crtslipinno,
							  autocrtyn,
							  insertdt,
							  iempcode)
		VALUES		(p_compcode,
					 p_slipinno,
					 p_slipinseq,
					 p_repaydate,
					 p_repayamt,
					 p_crtslipinno,
					 'N',
					 SYSDATE,
					 ip_empcode);
	ELSIF (UPPER(p_div) = 'UD')
	THEN -- 반제상세내역 수정
		UPDATE ACORDRPYD
		SET    repayamt = p_repayamt, autocrtyn = 'N', updatedt = SYSDATE, uempcode = ip_empcode
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq
			   AND repaydate = p_repaydate;
	ELSIF (UPPER(p_div) = 'DD')
	THEN -- 반제상세내역 삭제
		FOR rec IN (SELECT 1 AS alias1
					FROM   DUAL
					WHERE  NOT EXISTS
							   (SELECT *
								FROM   ACORDRPYD A
									   JOIN ACORDM b
										   ON A.compcode = b.compcode
											  AND A.crtslipinno = b.slipinno
								WHERE  A.compcode = p_compcode
									   AND A.slipinno = p_slipinno
									   AND A.slipinseq = p_slipinseq
									   AND A.repaydate = p_repaydate))
		LOOP
			v_temp := rec.alias1;
		END LOOP;


		IF v_temp = 1
		THEN
			DELETE ACORDRPYD
			WHERE  compcode = p_compcode
				   AND slipinno = p_slipinno
				   AND slipinseq = p_slipinseq
				   AND repaydate = p_repaydate;
		ELSE
			MESSAGE := '';
		END IF;
	ELSIF (p_div = 'IS')
	THEN -- 반제관리내역 입력
		INSERT INTO ACORDRPYS(compcode,
							  slipinno,
							  slipinseq,
							  mngclucode,
							  seq,
							  mngcluval,
							  mngcludec,
							  insertdt,
							  iempcode)
		VALUES		(p_compcode,
					 p_slipinno,
					 p_slipinseq,
					 p_mngclucode,
					 p_seq,
					 p_mngcluval,
					 p_mngcludec,
					 SYSDATE,
					 ip_empcode);
	ELSIF (p_div = 'US')
	THEN -- 반제관리내역 수정
		UPDATE ACORDRPYS
		SET    seq = p_seq, mngcluval = p_mngcluval, mngcludec = p_mngcludec, updatedt = SYSDATE, uempcode = ip_empcode
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq
			   AND mngclucode = p_mngclucode;
	ELSIF (p_div = 'DS')
	THEN -- 반제관리내역 삭제
		DELETE ACORDRPYS
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq
			   AND mngclucode = p_mngclucode;
	ELSIF (UPPER(p_div) = UPPER('CO'))
	THEN -- 반제관리내역 생성
		INSERT INTO ACORDRPYM(compcode,
							  slipinno,
							  slipinseq,
							  expdiv,
							  empcode,
							  startdate,
							  enddate,
							  createday,
							  repeatmon,
							  acccode,
							  remark,
							  endyn,
							  insertdt,
							  iempcode)
			(SELECT compcode,
					slipinno,
					slipinseq,
					p_expdiv,
					ip_empcode,
					slipdate,
					TO_CHAR(ADD_MONTHS(TO_DATE(slipdate, 'YYYY-MM-DD'), 12), 'YYYY-MM-DD'),
					31,
					1,
					p_acccode,
					ip_remark,
					'N',
					SYSDATE,
					ip_empcode
			 FROM	ACORDD A
			 WHERE	A.compcode = p_compcode
					AND A.slipinno = p_slipinno
					AND A.slipinseq = p_slipinseq);


		INSERT INTO ACORDRPYS(compcode,
							  slipinno,
							  slipinseq,
							  mngclucode,
							  seq,
							  mngcluval,
							  mngcludec,
							  insertdt,
							  iempcode)
			(SELECT p_compcode,
					p_slipinno,
					p_slipinseq,
					A.mngclucode,
					A.seq,
					CASE
						WHEN A.mngclucode = b.mngclucode
							 AND A.mngcluval IS NULL
						THEN
							b.mngcluval
						WHEN A.mngclucode = c.mngclucode
							 AND A.mngcluval IS NULL
						THEN
							c.mngcluval
						WHEN A.mngclucode = D.mngclucode
							 AND A.mngcluval IS NULL
						THEN
							D.mngcluval
						ELSE
							A.mngcluval
					END
						col,
					CASE
						WHEN A.mngclucode = b.mngclucode
							 AND A.mngcluval IS NULL
						THEN
							b.mngcludec
						WHEN A.mngclucode = c.mngclucode
							 AND A.mngcluval IS NULL
						THEN
							c.mngcludec
						WHEN A.mngclucode = D.mngclucode
							 AND A.mngcluval IS NULL
						THEN
							D.mngcludec
						ELSE
							A.mngcludec
					END
						col,
					SYSDATE,
					ip_empcode
			 FROM	(SELECT A.mngclucode,
							A.seq,
							CASE WHEN A.mngclucode = p_mngclucode THEN p_mngcluval WHEN A.mngclucode = p_mngclucode2 THEN p_mngcluval2 ELSE '' END mngcluval,
							CASE WHEN A.mngclucode = p_mngclucode THEN p_mngcludec WHEN A.mngclucode = p_mngclucode2 THEN p_mngcludec2 ELSE '' END mngcludec
					 FROM	ACACCMNGM A -- 반제마스터내역
					 WHERE	A.acccode = p_acccode
							AND A.dcdiv = CASE WHEN p_expdiv = '1' THEN '2' ELSE '1' END) A
					LEFT JOIN ACORDS b
						ON b.compcode = p_compcode
						   AND b.slipinno = p_slipinno
						   AND b.slipinseq = p_slipinseq
						   AND b.mngclucode = 'S010'
					LEFT JOIN ACORDS c
						ON c.compcode = p_compcode
						   AND c.slipinno = p_slipinno
						   AND c.slipinseq = p_slipinseq
						   AND c.mngclucode = 'S040'
					LEFT JOIN ACORDS D
						ON D.compcode = p_compcode
						   AND D.slipinno = p_slipinno
						   AND D.slipinseq = p_slipinseq
						   AND D.mngclucode = 'S050');
	ELSIF (p_div = 'CC')
	THEN -- 반제전표 내역 생성
		-- 원인전표 생성
		INSERT INTO ACORDD(compcode,
						   slipinno,
						   slipinseq,
						   dcdiv,
						   acccode,
						   plantcode,
						   debamt,
						   creamt,
						   slipdate,
						   slipnum,
						   remark1,
						   remark2,
						   taxno,
						   datadiv,
						   rptseq,
						   insertdt,
						   iempcode)
			(SELECT A.compcode,
					p_slipno,
					p_slipseq + CASE WHEN b.expdiv = '1' THEN 1 ELSE 2 END,
					b.expdiv,
					A.acccode,
					--p_slipplantcode,
					c.plantcode,
					CASE WHEN b.expdiv = '1' THEN p_repayamt ELSE 0 END col,
					CASE WHEN b.expdiv = '1' THEN 0 ELSE p_repayamt END col,
					p_repaydate,
					SUBSTR(p_slipno, -5, 5),
					A.remark1,
					A.remark2,
					'',
					b.expdiv,
					p_slipseq + CASE WHEN b.expdiv = '1' THEN 1 ELSE 2 END,
					SYSDATE,
					ip_empcode
			 FROM	ACORDD A
					JOIN ACORDRPYM b
						ON A.compcode = b.compcode
						   AND A.slipinno = b.slipinno
						   AND A.slipinseq = b.slipinseq
					JOIN ACORDM c
						ON A.compcode = c.compcode
						   AND c.slipinno = p_slipno
			 WHERE	A.compcode = p_compcode
					AND A.slipinno = p_slipinno
					AND A.slipinseq = p_slipinseq);



		INSERT INTO ACORDS(compcode,
						   slipinno,
						   slipinseq,
						   mngclucode,
						   seq,
						   mngcluval,
						   mngcludec,
						   insertdt,
						   iempcode)
			(SELECT A.compcode,
					p_slipno,
					p_slipseq + CASE WHEN b.expdiv = '1' THEN 1 ELSE 2 END,
					A.mngclucode,
					A.seq,
					CASE
						WHEN D.remainyn = 'Y'
							 OR p_crtmathod <> '2'
						THEN
							A.mngcluval
						ELSE
							''
					END
						col,
					CASE
						WHEN D.remainyn = 'Y'
							 OR p_crtmathod <> '2'
						THEN
							A.mngcludec
						ELSE
							''
					END
						col,
					SYSDATE,
					ip_empcode
			 FROM	ACORDS A
					JOIN ACORDRPYM b
						ON A.compcode = b.compcode
						   AND A.slipinno = b.slipinno
						   AND A.slipinseq = b.slipinseq
					JOIN ACORDD c
						ON A.compcode = c.compcode
						   AND A.slipinno = c.slipinno
						   AND A.slipinseq = c.slipinseq
					LEFT JOIN ACACCMNGM D
						ON c.acccode = D.acccode
						   AND (c.dcdiv IN ('1', '4')
								AND D.dcdiv = '1'
								OR c.dcdiv IN ('2', '3')
								   AND D.dcdiv = '2')
						   AND A.mngclucode = D.mngclucode
			 WHERE	A.compcode = p_compcode
					AND A.slipinno = p_slipinno
					AND A.slipinseq = p_slipinseq);


		-- 반제전표 생성
		INSERT INTO ACORDD(compcode,
						   slipinno,
						   slipinseq,
						   dcdiv,
						   acccode,
						   plantcode,
						   debamt,
						   creamt,
						   slipdate,
						   slipnum,
						   remark1,
						   remark2,
						   taxno,
						   datadiv,
						   rptseq,
						   insertdt,
						   iempcode)
			(SELECT A.compcode,
					p_slipno,
					p_slipseq + CASE WHEN b.expdiv = '1' THEN 2 ELSE 1 END,
					CASE WHEN b.expdiv = '1' THEN '2' ELSE '1' END col,
					b.acccode,
					c.plantcode,
					CASE WHEN b.expdiv = '1' THEN 0 ELSE p_repayamt END col,
					CASE WHEN b.expdiv = '1' THEN p_repayamt ELSE 0 END col,
					p_repaydate,
					SUBSTR(p_slipno, -5, 5),
					A.remark1,
					A.remark2,
					'',
					CASE WHEN b.expdiv = '1' THEN '2' ELSE '1' END col,
					p_slipseq + CASE WHEN b.expdiv = '1' THEN 2 ELSE 1 END,
					SYSDATE,
					ip_empcode
			 FROM	ACORDD A
					JOIN ACORDRPYM b
						ON A.compcode = b.compcode
						   AND A.slipinno = b.slipinno
						   AND A.slipinseq = b.slipinseq
					JOIN ACORDM c
						ON A.compcode = c.compcode
						   AND c.slipinno = p_slipno
			 WHERE	A.compcode = p_compcode
					AND A.slipinno = p_slipinno
					AND A.slipinseq = p_slipinseq);


		INSERT INTO ACORDS(compcode,
						   slipinno,
						   slipinseq,
						   mngclucode,
						   seq,
						   mngcluval,
						   mngcludec,
						   insertdt,
						   iempcode)
			SELECT	 A.compcode,
					 p_slipno,
					 p_slipseq + CASE WHEN b.expdiv = '1' THEN 2 ELSE 1 END,
					 A.mngclucode,
					 A.seq,
					 CASE
						 WHEN D.remainyn = 'Y'
							  OR p_crtmathod <> '2'
						 THEN
							 CASE WHEN A.mngclucode = 'S020' THEN NVL(E.accountno, A.mngcluval) ELSE A.mngcluval END
						 ELSE
							 ''
					 END
						 col,
					 CASE
						 WHEN D.remainyn = 'Y'
							  OR p_crtmathod <> '2'
						 THEN
							 CASE WHEN A.mngclucode = 'S020' THEN NVL(E.accremark, A.mngcludec) ELSE A.mngcludec END
						 ELSE
							 ''
					 END
						 col,
					 SYSDATE,
					 ip_empcode
			FROM	 ACORDRPYS A
					 JOIN ACORDRPYM b
						 ON A.compcode = b.compcode
							AND A.slipinno = b.slipinno
							AND A.slipinseq = b.slipinseq
					 JOIN ACORDD c
						 ON A.compcode = c.compcode
							AND A.slipinno = c.slipinno
							AND A.slipinseq = c.slipinseq
					 LEFT JOIN ACACCMNGM D
						 ON b.acccode = D.acccode
							AND (c.dcdiv IN ('1', '4')
								 AND D.dcdiv = '2'
								 OR c.dcdiv IN ('2', '3')
									AND D.dcdiv = '1')
							AND A.mngclucode = D.mngclucode
					 LEFT JOIN CMACCOUNTM E ON E.accountno = p_saccountno
			WHERE	 A.compcode = p_compcode
					 AND A.slipinno = p_slipinno
					 AND A.slipinseq = p_slipinseq
			ORDER BY A.seq;



		-- 반제상세 갱신
		FOR rec IN (SELECT 1 AS alias1
					FROM   DUAL
					WHERE  EXISTS
							   (SELECT *
								FROM   ACORDRPYD
								WHERE  compcode = p_compcode
									   AND slipinno = p_slipinno
									   AND slipinseq = p_slipinseq
									   AND repaydate = p_repaydate))
		LOOP
			v_temp := rec.alias1;
		END LOOP;

		IF v_temp = 1
		THEN
			UPDATE ACORDRPYD A
			SET    A.crtslipinno = p_slipno
			WHERE  compcode = p_compcode
				   AND slipinno = p_slipinno
				   AND slipinseq = p_slipinseq
				   AND repaydate = p_repaydate;
		ELSE
			INSERT INTO ACORDRPYD(compcode,
								  slipinno,
								  slipinseq,
								  repaydate,
								  repayamt,
								  crtslipinno,
								  autocrtyn,
								  insertdt,
								  iempcode)
				(SELECT p_compcode,
						p_slipinno,
						p_slipinseq,
						p_repaydate,
						p_repayamt,
						p_slipno,
						'Y',
						SYSDATE,
						ip_empcode
				 FROM	DUAL);
		END IF;



		UPDATE ACORDRPYM A
		SET    A.endyn = 'Y'
		WHERE  (A.COMPCODE, A.SLIPINNO, A.SLIPINSEQ) = (SELECT A.COMPCODE,
															   A.SLIPINNO,
															   A.SLIPINSEQ
														FROM   ACORDRPYM A
															   JOIN ACORDD b
																   ON A.compcode = b.compcode
																	  AND A.slipinno = b.slipinno
																	  AND A.slipinseq = b.slipinseq
															   JOIN (SELECT SUM(A.repayamt) repayamt
																	 FROM	ACORDRPYD A
																			JOIN ACORDD b
																				ON A.compcode = b.compcode
																				   AND A.slipinno = b.slipinno
																				   AND A.slipinseq = b.slipinseq
																	 WHERE	A.compcode = p_compcode
																			AND A.slipinno = p_slipinno
																			AND A.slipinseq = p_slipinseq) c
																   ON 1 = 1
														WHERE  A.compcode = p_compcode
															   AND A.slipinno = p_slipinno
															   AND A.slipinseq = p_slipinseq
															   AND (b.debamt + b.creamt) <= c.repayamt);

		MESSAGE := p_slipseq + 2;

		FOR rec IN (SELECT value2
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'copercardpopup')
		LOOP
			p_sendacc := rec.value2;
		END LOOP;

		p_group_nm := 'ACacc0012P' || p_slipinno || fnLPAD(p_slipinseq, 5, '0');

		p_list_nm := '';

		FOR rec IN (SELECT mngcludec
					FROM   ACORDRPYS
					WHERE  compcode = p_compcode
						   AND slipinno = p_slipinno
						   AND slipinseq = p_slipinseq
						   AND mngclucode = 'S010')
		LOOP
			p_list_nm := rec.mngcludec;
		END LOOP;


		IF p_list_nm IS NULL
		THEN
			FOR rec IN (SELECT mngcludec
						FROM   ACORDRPYS
						WHERE  compcode = p_compcode
							   AND slipinno = p_slipinno
							   AND slipinseq = p_slipinseq
							   AND mngclucode = 'S050')
			LOOP
				p_list_nm := rec.mngcludec;
			END LOOP;
		END IF;


		ip_remark := '';


		FOR rec IN (SELECT remark
					FROM   ACORDRPYM
					WHERE  compcode = p_compcode
						   AND slipinno = p_slipinno
						   AND slipinseq = p_slipinseq)
		LOOP
			ip_remark := rec.remark;
		END LOOP;



		FOR rec IN (SELECT 1 AS alias1
					FROM   DUAL
					WHERE  EXISTS
							   (SELECT *
								FROM   ACORDRPYM
								WHERE  compcode = p_compcode
									   AND slipinno = p_slipinno
									   AND slipinseq = p_slipinseq
									   AND acccode = p_sendacc
									   AND expdiv = '1')
						   AND p_crttran = 'Y')
		LOOP
			v_temp := rec.alias1;
		END LOOP;
	/* 2016-12-14  : ERP_ICHE_DATA , ERP_ICHE_DATA 테이블이 없어서 주석 처리함
                  IF v_temp = 1 THEN

                      -- 기업 EBranch
                      DELETE ERP_ICHE_DATA
                      WHERE  erp_rec_no = p_group_nm;

                      FOR  rec IN (   SELECT  NVL(MAX(reg_seq) , 0) + 1  AS alias1
                                      FROM    ERP_ICHE_DATA
                                      WHERE   reg_date = p_reg_date
                                              AND reg_time = p_reg_time
                                              AND ext_1 = ip_empcode )
                      LOOP
                          p_tran_dt_seq := rec.alias1 ;
                      END LOOP;


                      INSERT INTO ERP_ICHE_DATA ( site_no,        reg_date,       reg_time,                   reg_seq,                                        iche_gb,
                                                  fl_seq,         rsrv_yn,        in_bank_cd,                 in_acct_no,                                     tran_amt,
                                                  pre_reci_man,   pay_gb,         in_prt,                     out_prt,                                        erp_rec_no,
                                                  ext_1 )

                      ( SELECT                    '1348115033' ,  p_reg_date ,    p_reg_time ,                p_tran_dt_seq ,                                 '4' ,

                                                  1 ,             '0' ,           SUBSTR(p_bankcode, 0, 3) ,  SUBSTR(REPLACE(p_accountno, '-', ''), 0, 20) ,  p_repayamt ,
                                                  p_list_nm ,     '' ,            TO_CHAR(ip_remark) ,        p_list_nm ,                                     p_group_nm ,
                                                  ip_empcode
                      FROM DUAL  );

                  END IF;
          */

	END IF;

	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
