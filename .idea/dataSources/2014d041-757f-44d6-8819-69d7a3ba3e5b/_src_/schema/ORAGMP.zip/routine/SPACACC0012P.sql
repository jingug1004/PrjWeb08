CREATE PROCEDURE spACacc0012P(
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0012P
-- 작 성 자         : 최용석
-- 작성일자         : 2011-02-10
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2016-12-14
-- ---------------------------------------------------------------
-- 프로시저 설명    : 회계전표 반제내역을 관리하는 프로시저이다.
-- ---------------------------------------------------------------
    p_div           IN  VARCHAR2 DEFAULT '',

    p_compcode      IN  VARCHAR2 DEFAULT '',
    p_plantcode     IN  VARCHAR2 DEFAULT '',
    p_expdiv        IN  VARCHAR2 DEFAULT '',
    p_empcode       IN  VARCHAR2 DEFAULT '',
    p_expym         IN  VARCHAR2 DEFAULT '',
    p_startdate     IN  VARCHAR2 DEFAULT '',
    p_enddate       IN  VARCHAR2 DEFAULT '',
    p_slipinno      IN  VARCHAR2 DEFAULT '',
    p_slipinseq     IN  NUMBER DEFAULT 0,
    p_createday     IN  NUMBER DEFAULT 0,
    p_repeatmon     IN  NUMBER DEFAULT 0,
    p_acccode       IN  VARCHAR2 DEFAULT '',
    p_search        IN  VARCHAR2 DEFAULT '',
    p_remark        IN  VARCHAR2 DEFAULT '',
    p_endyn         IN  VARCHAR2 DEFAULT '',
    p_repaydate     IN  VARCHAR2 DEFAULT '',
    p_repayamt      IN  FLOAT DEFAULT 0,
    p_crtslipinno   IN  VARCHAR2 DEFAULT '',
    p_seq           IN  NUMBER DEFAULT 0,
    p_mngclucode    IN  VARCHAR2 DEFAULT '',
    p_mngcluval     IN  VARCHAR2 DEFAULT '',
    p_mngcludec     IN  VARCHAR2 DEFAULT '',
    p_mngclucode2   IN  VARCHAR2 DEFAULT '',
    p_mngcluval2    IN  VARCHAR2 DEFAULT '',
    p_mngcludec2    IN  VARCHAR2 DEFAULT '',
    p_slipno        IN  VARCHAR2 DEFAULT '',
    p_slipseq       IN  NUMBER DEFAULT 0,
    p_stramt        IN  FLOAT DEFAULT 0,
    p_endamt        IN  FLOAT DEFAULT 0,
    p_saccountno    IN  VARCHAR2 DEFAULT '',
    p_bankcode      IN  VARCHAR2 DEFAULT '',
    p_bankempname   IN  VARCHAR2 DEFAULT '',
    p_accountno     IN  VARCHAR2 DEFAULT '',
    p_crttran       IN  VARCHAR2 DEFAULT 'Y',
    p_crtmathod     IN  VARCHAR2 DEFAULT '0',
    p_reg_date      IN  VARCHAR2 DEFAULT '',
    p_reg_time      IN  VARCHAR2 DEFAULT '',

    p_userid        IN  VARCHAR2 DEFAULT '',
    p_reasondiv     IN  VARCHAR2 DEFAULT '',
    p_reasontext    IN  VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    ip_empcode          VARCHAR2(20) := p_empcode;
    ip_startdate        VARCHAR2(10) := p_startdate;
    ip_enddate          VARCHAR2(10) := p_enddate;
    ip_remark           VARCHAR2(100) := p_remark;

    p_oslipinseq        NUMBER(10, 0);

    p_plantcodeR        VARCHAR2(4);

    v_temp              NUMBER := 0;

    p_sendacc           VARCHAR2(50);
    p_tran_dt_seq       NUMBER(10, 0);
    p_group_nm          VARCHAR2(50);
    p_list_nm           VARCHAR2(100);
    p_crtslip           VARCHAR2(1) := '0';
BEGIN
    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';

    insert into atInfo(userid, reasondiv, reasontext)
    values(p_userid, p_reasondiv, p_reasontext);

    for rec in (
        select  case when value1 = 'Y' then '%' else ip_empcode end as empcode
        from    SYSPARAMETERMANAGE
        where   parametercode = 'accsliprpyview'
                and p_div in ('SM', 'SC'))
    loop
        ip_empcode := rec.empcode;
    end loop;

    for rec in (
        select  value2 as crtslip
        from    SYSPARAMETERMANAGE
        where   parametercode = 'accslipreqdate')
    loop
        p_crtslip := rec.crtslip;
    end loop;

    if (p_div = 'SM') then    -- 반제마스터내역 검색
        ip_startdate := p_expym || '-01';
        ip_enddate := to_char(add_months(to_date(ip_startdate, 'yyyy-MM-dd'), 1) - 1, 'yyyy-MM-dd');

        open IO_CURSOR for
        select  a.compcode, -- 회사코드
                a.slipinno, -- 전표번호
                a.slipinseq, -- 전표일번
                a.expdiv, -- 반제구분
                a.empcode, -- 등록사원
                a.startdate, -- 시작일자
                a.enddate, -- 종료일자
                a.createday, -- 생성일자
                a.repeatmon, -- 생성주기
                a.acccode, -- 상대계정
                a.remark, -- 반제비고
                a.endyn, -- 완료여부
                b.slipdate, -- 회계일자
                b.slipnum, -- 회계번호
                nvl(b.debamt + b.creamt, 0) as slipamt, -- 전표금액
                b.remark1 as sremark, -- 전표비고
                c.accname, -- 상대계정명
                d.accname as saccname, -- 전표계정명
                nvl(e.repayamt, 0) as repayamt, -- 반제금액
                b.plantcode
        from    ACORDRPYM a -- 반제마스터내역
                join ACORDD b
                    on a.compcode = b.compcode -- 전표상세내역
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
                    and b.plantcode like p_plantcode
                left join ACACCM c
                    on a.acccode = c.acccode -- 상대계정정보
                left join ACACCM d
                    on b.acccode = d.acccode -- 전표계정정보
                left join (
                    select  a.compcode,
                            a.slipinno,
                            a.slipinseq,
                            sum(b.repayamt) as repayamt
                    from    ACORDRPYM a
                            join ACORDRPYD b
                                on a.compcode = b.compcode
                                and a.slipinno = b.slipinno
                                and a.slipinseq = b.slipinseq
                            join ACORDM c
                                on b.compcode = c.compcode -- 전표내역
                                and b.crtslipinno = c.slipinno
                    where   a.compcode = p_compcode
                            and a.expdiv = p_expdiv
                            and a.empcode like ip_empcode
                            and a.startdate <= ip_enddate
                            and ip_startdate <= nvl(nullif(a.enddate, null), to_char(add_months(sysdate, 120), 'yyyy-MM-dd'))
                    group by a.compcode, a.slipinno, a.slipinseq
                ) e on a.compcode = e.compcode
                    and a.slipinno = e.slipinno
                    and a.slipinseq = e.slipinseq
        where   a.compcode = p_compcode
                and a.expdiv = p_expdiv
                and a.empcode like ip_empcode
                and a.startdate <= ip_enddate
                and ip_startdate <= nvl(nullif(a.enddate, null), to_char(add_months(sysdate, 120), 'yyyy-MM-dd'))
                and a.endyn = p_endyn
        order by b.slipdate, b.slipnum, a.slipinseq;

    elsif (p_div = 'SD') then   -- 반제상세내역 검색
        -- 전표가 없는 반제정보 갱신
        update  ACORDRPYM
        set     endyn = 'N'
        where   (compcode, slipinno, slipinseq) = ( select  a.compcode,
                                                            a.slipinno,
                                                            a.slipinseq
                                                    from    ACORDRPYM a
                                                            join ACORDRPYD b
                                                                on a.compcode = b.compcode -- 반제상세내역
                                                                and a.slipinno = b.slipinno
                                                                and a.slipinseq = b.slipinseq
                                                            left join ACORDM c
                                                                on b.compcode = c.compcode -- 전표내역
                                                                and b.crtslipinno = c.slipinno
                                                    where   a.compcode = p_compcode
                                                            and a.slipinno = p_slipinno
                                                            and a.slipinseq = p_slipinseq
                                                            and c.compcode is null);

        delete
        from    ACORDRPYD
        where   (compcode, slipinno, slipinseq, repaydate) = (select  a.compcode,
                                                                      a.slipinno,
                                                                      a.slipinseq,
                                                                      a.repaydate
                                                              from    ACORDRPYD a -- 반제상세내역
                                                                      left join ACORDM b
                                                                          on a.compcode = b.compcode -- 전표내역
                                                                          and a.crtslipinno = b.slipinno
                                                              where   a.compcode = p_compcode
                                                                      and a.slipinno = p_slipinno
                                                                      and a.slipinseq = p_slipinseq
                                                                      and a.autocrtyn = 'Y'
                                                                      and b.compcode is null);

        update  ACORDRPYD
        set     crtslipinno = ''
        where   (compcode, slipinno, slipinseq, repaydate) = (select  a.compcode,
                                                                      a.slipinno,
                                                                      a.slipinseq,
                                                                      a.repaydate
                                                              from    ACORDRPYD a -- 반제상세내역
                                                                      left join ACORDM b
                                                                          on a.compcode = b.compcode -- 전표내역
                                                                          and a.crtslipinno = b.slipinno
                                                              where   a.compcode = p_compcode
                                                                      and a.slipinno = p_slipinno
                                                                      and a.slipinseq = p_slipinseq
                                                                      and a.autocrtyn = 'N'
                                                                      and b.compcode is null);

        -- 반제상세내역 검색
        open IO_CURSOR for
        select  a.compcode, -- 회사코드
                a.slipinno, -- 전표번호
                a.slipinseq, -- 전표일번
                a.repaydate, -- 반제일자
                a.repayamt, -- 반제금액
                b.slipinno as crtslipinno, -- 생선전표번호
                b.slipdate, -- 회계일자
                b.slipnum, -- 회계번호
                c.endyn, -- 완료여부
                c.repayamt -- 반제금액
        from    ACORDRPYD a -- 반제상세내역
                left join ACORDM b
                    on a.compcode = b.compcode -- 전표내역
                    and a.crtslipinno = b.slipinno
                join (
                    select  max(a.endyn) as endyn,
                            nvl(sum(b.repayamt), 0) as repayamt
                    from    ACORDRPYM a
                            left join ACORDRPYD b
                                on a.compcode = b.compcode
                                and a.slipinno = b.slipinno
                                and a.slipinseq = b.slipinseq
                    where   a.compcode = p_compcode
                            and a.slipinno = p_slipinno
                            and a.slipinseq = p_slipinseq
                ) c on 1 = 1
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno
                and a.slipinseq = p_slipinseq
        order by a.repaydate;

    elsif (p_div = 'SS') then   -- 반제관리내역 검색
        open IO_CURSOR for
        select  a.compcode, -- 회사코드
                a.slipinno, -- 전표번호
                a.slipinseq, -- 전표일번
                a.seq, -- 일련번호
                a.mngclucode, -- 관리코드
                a.mngcluval, -- 항목코드
                a.mngcludec, -- 항목명
                nvl(c.mngcluname, '') as mngcluname, -- 관리명
                nvl(c.requireyn, '') as requireyn, -- 필수입력여부
                nvl(c.returnyn, '') as returnyn, -- 반제여부
                nvl(c.remainyn, '') as remainyn, -- 잔액관리여부
                nvl(d.mngcludiv, '') as mngcludiv, -- 관리항목형태
                nvl(d.codehelp, '') as codehelp, -- 코드헬프번호
                nvl(d.remark, '') as codermk -- 코드헬프비고
        from    ACORDRPYS a -- 반제관리내역
                join ACORDRPYM b
                    on a.compcode = b.compcode -- 반제마스터내역
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
                left join ACACCMNGM c
                    on b.acccode = c.acccode -- 관리항목필수여부
                    and case when b.expdiv = '1' then '2' else '1' end = c.dcdiv
                    and a.mngclucode = c.mngclucode
                left join ACMNGM d
                    on a.mngclucode = d.mngclucode -- 관리항목정보
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno
                and a.slipinseq = p_slipinseq
        order by a.seq;

    elsif (p_div = 'SA') then   -- 계정별 관리항목 검색
        for rec in (
            select  max(slipinseq) as slipinseq
            from    ACORDS
            where   compcode = p_compcode
                    and slipinno = p_slipinno
                    and slipinseq <> p_slipinseq)
        loop
            p_oslipinseq := rec.slipinseq;
        end loop;

        open IO_CURSOR for
        select  nvl(a.seq, 0) as seq, -- 일련번호
                nvl(a.mngclucode, '') as mngclucode, -- 관리항목코드
                coalesce(c.mngcluval, d.mngcluval, '') as mngcluval, -- 관리항목값
                coalesce(c.mngcludec, d.mngcludec, '') as mngcludec, -- 관리항목값명
                nvl(a.mngcluname, '') as mngcluname, -- 관리항목명
                nvl(a.requireyn, '') as requireyn, -- 필수입력여부
                nvl(a.returnyn, '') as returnyn, -- 반제여부
                nvl(a.remainyn, '') as remainyn, -- 잔액관리여부
                nvl(b.mngcludiv, '') as mngcludiv, -- 관리항목형태
                nvl(b.codehelp, '') as codehelp, -- 코드헬프번호
                nvl(b.remark, '') as codermk -- 코드헬프비고
        from    ACACCMNGM a -- 반제마스터내역
                left join ACMNGM b
                    on a.mngclucode = b.mngclucode -- 관리항목정보
                left join ACORDS c
                    on c.compcode = p_compcode -- 전표관리항목내역
                    and c.slipinno = p_slipinno
                    and c.slipinseq = p_slipinseq
                    and b.mngclucode = c.mngclucode
                left join ACORDS d
                    on d.compcode = p_compcode -- 전표관리항목내역
                    and d.slipinno = p_slipinno
                    and d.slipinseq = p_oslipinseq
                    and b.mngclucode = d.mngclucode
        where   a.acccode = p_acccode
                and a.dcdiv = case when p_expdiv = '1' then '2' else '1' end
        order by a.seq;

    elsif (p_div = 'SO') then   -- 회계전표내역 검색
        open IO_CURSOR for
        select  'N' as crtsel,
                a.slipinno,
                a.slipinseq,
                a.dcdiv,
                a.acccode,
                b.accname,
                a.debamt + a.creamt as slipamt,
                z.slipindate,
                z.slipinnum,
                a.slipdate,
                a.slipnum,
                a.remark1,
                c.mngcludec1,
                c.mngcludec2,
                c.mngcludec3
        from    ACORDD a
                join ACORDM z
                    on a.compcode = z.compcode
                    and a.slipinno = z.slipinno
                join ACACCM b
                    on a.acccode = b.acccode
                    and b.dcdiv = case when p_expdiv = '1' then '2' else '1' end
                    and b.returnyn = 'Y'
                left join (
                    select  compcode,
                            slipinno,
                            slipinseq,
                            max(case when seq = 1 then mngcludec else '' end) as mngcludec1,
                            max(case when seq = 2 then mngcludec else '' end) as mngcludec2,
                            max(case when seq = 3 then mngcludec else '' end) as mngcludec3,
                            max(case when seq = 4 then mngcludec else '' end) as mngcludec4,
                            max(case when seq = 5 then mngcludec else '' end) as mngcludec5,
                            max(case when seq = 6 then mngcludec else '' end) as mngcludec6
                    from (
                        select  a.compcode,
                                a.slipinno,
                                a.slipinseq,
                                row_number() over (partition by a.compcode, a.slipinno, a.slipinseq order by b.seq) as seq,
                                nvl(b.mngcludec, '') || ' : ' || nvl(b.mngcluval, '') ||
                                case when d.businessno is not null then '(' || d.businessno || ')' else '' end as mngcludec
                        from    ACORDD a
                                join ACORDS b
                                    on a.compcode = b.compcode
                                    and a.slipinno = b.slipinno
                                    and a.slipinseq = b.slipinseq
                                left join ACMNGM c
                                    on b.mngclucode = c.mngclucode
                                left join CMCUSTM d
                                    on b.mngclucode = 'S010'
                                    and b.mngcluval = d.custcode
                        where   a.compcode = p_compcode
                                and a.acccode like p_acccode || '%'
                                and a.slipdate between ip_startdate and ip_enddate
                                and (p_expdiv = '2' and a.dcdiv in ('1', '4')
                                     or p_expdiv = '1' and a.dcdiv in ('2', '3'))
                    ) a
                    group by compcode, slipinno, slipinseq
                ) c on a.compcode = c.compcode
                    and a.slipinno = c.slipinno
                    and a.slipinseq = c.slipinseq
                left join ACORDRPYM d
                    on a.compcode = d.compcode
                    and a.slipinno = d.slipinno
                    and a.slipinseq = d.slipinseq
                left join ACORDRPYP e
                    on a.compcode = e.compcode
                    and a.slipinno = e.slipinno
                    and a.slipinseq = e.slipinseq
        where   a.compcode = p_compcode
                and a.slipdate between ip_startdate and ip_enddate
                and (p_expdiv = '2' and a.dcdiv in ('1', '4')
                     or p_expdiv = '1' and a.dcdiv in ('2', '3'))
                and a.acccode like p_acccode || '%'
                and a.plantcode like p_plantcode
                and d.compcode is null
                and (a.remark1 like '%' || p_search || '%'
                     or a.remark2 like '%' || p_search || '%'
                     or c.mngcludec1 like '%' || p_search || '%'
                     or c.mngcludec2 like '%' || p_search || '%'
                     or c.mngcludec3 like '%' || p_search || '%'
                     or c.mngcludec4 like '%' || p_search || '%'
                     or c.mngcludec5 like '%' || p_search || '%'
                     or c.mngcludec6 like '%' || p_search || '%')
                and a.debamt + a.creamt between p_stramt and p_endamt
                and e.compcode is null
        order by a.slipdate, a.slipnum, a.slipinseq;

    elsif (p_div = 'SC') then   -- 반제전표생성 검색
        -- 전표가 없는 반제정보 갱신
        merge into ACORDRPYM a
        using (
            select  b.compcode,
                    b.slipinno,
                    b.slipinseq
            from    ACORDRPYD a -- 반제상세내역
                    join ACORDRPYM b -- 반제내역
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
                        and a.slipinseq = b.slipinseq
                    left join ACORDM c -- 전표내역
                        on a.compcode = c.compcode
                        and a.crtslipinno = c.slipinno
            where   a.compcode = p_compcode
                    and a.repaydate between p_startdate and p_enddate
                    and c.compcode is null
        ) src on (a.compcode = src.compcode
                  and a.slipinno = src.slipinno
                  and a.slipinseq = src.slipinseq)
        when matched
        then
            update set a.endyn = 'N';

        for rec in (
            select  a.compcode,
                    a.slipinno,
                    a.slipinseq,
                    a.repaydate
            from    ACORDRPYD a -- 반제상세내역
                    left join ACORDM b -- 전표내역
                        on a.compcode = b.compcode
                        and a.crtslipinno = b.slipinno
            where   a.compcode = p_compcode
                    and a.repaydate between p_startdate and p_enddate
                    and a.autocrtyn = 'Y'
                    and b.compcode is null)
        loop
            delete
            from    ACORDRPYD
            where   compcode = rec.compcode
                    and slipinno = rec.slipinno
                    and slipinseq = rec.slipinseq
                    and repaydate = rec.repaydate;
        end loop;

        merge into ACORDRPYD a
        using (
            select  a.compcode,
                    a.slipinno,
                    a.slipinseq,
                    a.repaydate
            from    ACORDRPYD a -- 반제상세내역
                    left join ACORDM b -- 전표내역
                        on a.compcode = b.compcode
                        and a.crtslipinno = b.slipinno
            where   a.compcode = p_compcode
                    and a.repaydate between p_startdate and p_enddate
                    and a.autocrtyn = 'N'
                    and b.compcode is null
        ) src on (a.compcode = src.compcode
                  and a.slipinno = src.slipinno
                  and a.slipinseq = src.slipinseq
                  and a.repaydate = src.repaydate)
        when matched
        then
            update set a.crtslipinno = '';

        p_plantcoder := '';

        for rec in (
            select  value2
            from    SYSPARAMETERMANAGE a
            where   parametercode = 'accsliprpyview')
        loop
            p_plantcoder := rec.value2;
        end loop;

        -- 반제전표생성 검색
        open IO_CURSOR for
        with TT_ACORDRPYD as (
            select  'N' crtsel, -- 출력여부
                    a.slipinno, -- 전표번호
                    a.slipinseq, -- 일련번호
                    c.slipdate, -- 전표일자
                    c.slipnum, -- 전표번호
                    f.accname as slipaccname, -- 전표계정명
                    c.remark1 as slipremark, -- 전표비고
                    a.repaydate, -- 생성일자
                    a.repayamt, -- 반제금액
                    a.repayamt as createamt, -- 생성금액
                    c.debamt + c.creamt - nvl(g.repayamt, 0) as restamt, -- 생성잔액
                    b.acccode, -- 상대계정코드
                    d.accname, -- 상대계정명
                    b.remark, -- 반제비고
                    coalesce(j.custname, m.custname, k.mngcludec, '') as custname, -- 거래처
                    coalesce(j.bankcode, m.bankcode, l.paybankdiv, '') as bankcode, -- 은행코드
                    coalesce(j.bankempname, m.bankempname, l.payaccempnm, '') as bankempname, -- 예금주
                    coalesce(j.accountno, m.accountno, l.payaccno, '') as accountno, -- 계좌번호
                    h.mngcluval as saccountno, -- 지급계좌번호
                    '1' as crediv, -- 생성구분
                    case when p_plantcoder is null then c.plantcode else p_plantcoder end as plantcode -- 사업장
            from    ACORDRPYD a -- 반제상세내역
                    join ACORDRPYM b
                        on a.compcode = b.compcode -- 반제마스터내역
                        and a.slipinno = b.slipinno
                        and a.slipinseq = b.slipinseq
                        and b.endyn = 'N'
                    join ACORDD c
                        on a.compcode = c.compcode -- 전표상세내역
                        and a.slipinno = c.slipinno
                        and a.slipinseq = c.slipinseq
                        and c.plantcode like p_plantcode
                        and nvl(c.acccode,' ') like p_acccode || '%'
                    join ACACCM d
                        on nvl(b.acccode,' ') = nvl(d.acccode,' ') -- 상대계정정보
                    left join ACORDM e
                        on a.compcode = e.compcode -- 전표내역
                        and a.crtslipinno = e.slipinno
                    left join ACACCM f
                        on nvl(c.acccode,' ') = nvl(f.acccode,' ') -- 전표계정정보
                    left join (
                        select  a.compcode,
                                a.slipinno,
                                a.slipinseq,
                                a.repaydate,
                                sum(c.repayamt) as repayamt
                        from    ACORDRPYD a
                                join ACORDRPYM b
                                    on a.compcode = b.compcode
                                    and a.slipinno = b.slipinno
                                    and a.slipinseq = b.slipinseq
                                join ACORDRPYD c
                                    on a.compcode = c.compcode
                                    and a.slipinno = c.slipinno
                                    and a.slipinseq = c.slipinseq
                                    and a.repaydate >= c.repaydate
                        where   a.compcode = p_compcode
                                and a.repaydate between ip_startdate and ip_enddate
                                and b.expdiv = p_expdiv
                                and b.empcode like ip_empcode
                        group by a.compcode, a.slipinno, a.slipinseq, a.repaydate
                    ) g on a.compcode = g.compcode
                        and a.slipinno = g.slipinno
                        and a.slipinseq = g.slipinseq
                        and a.repaydate = g.repaydate
                    left join ACORDRPYS h
                        on a.compcode = h.compcode
                        and a.slipinno = h.slipinno
                        and a.slipinseq = h.slipinseq
                        and h.mngclucode = 'S020'
                    left join ACORDRPYS i
                        on a.compcode = i.compcode
                        and a.slipinno = i.slipinno
                        and a.slipinseq = i.slipinseq
                        and i.mngclucode = 'S010'
                    left join CMCUSTM j
                        on i.mngcluval = j.custcode
                    left join ACORDRPYS k
                        on a.compcode = k.compcode
                        and a.slipinno = k.slipinno
                        and a.slipinseq = k.slipinseq
                        and k.mngclucode = 'S050'
                    left join PSEMPPAYBASEM l
                        on k.mngcluval = l.empcode
                    left join (
                        select  a.compcode,
                                a.slipinno,
                                a.slipinseq,
                                a.repaydate,
                                c.mngcluval as bankcode,
                                d.mngcluval as bankempname,
                                replace(e.mngcluval, '-', '') as accountno,
                                f.mngcluval as custname
                        from    ACORDRPYD a -- 반제상세내역
                                join ACORDRPYM b
                                    on a.compcode = b.compcode -- 반제마스터내역
                                    and a.slipinno = b.slipinno
                                    and a.slipinseq = b.slipinseq
                                    and b.endyn = 'N'
                                left join ACORDS c
                                    on a.compcode = c.compcode
                                    and a.slipinno = c.slipinno
                                    and a.slipinseq = c.slipinseq
                                    and c.mngclucode = 'S030'
                                    and c.mngcluval is not null
                                left join ACORDS d
                                    on a.compcode = d.compcode
                                    and a.slipinno = d.slipinno
                                    and a.slipinseq = d.slipinseq
                                    and d.mngclucode = 'U091'
                                    and d.mngcluval is not null
                                left join ACORDS e
                                    on a.compcode = e.compcode
                                    and a.slipinno = e.slipinno
                                    and a.slipinseq = e.slipinseq
                                    and e.mngclucode = 'U090'
                                    and e.mngcluval is not null
                                left join ACORDS f
                                    on a.compcode = f.compcode
                                    and a.slipinno = f.slipinno
                                    and a.slipinseq = f.slipinseq
                                    and f.mngclucode = 'U092'
                                    and f.mngcluval is not null
                        where   a.compcode = p_compcode
                                and a.repaydate between ip_startdate and ip_enddate
                                and b.expdiv = p_expdiv
                                and b.empcode like ip_empcode
                    ) m on a.slipinno = m.slipinno
                        and a.slipinseq = m.slipinseq
                        and a.repaydate = m.repaydate
            where   a.compcode = p_compcode
                    and a.repaydate between ip_startdate and ip_enddate
                    and b.expdiv = p_expdiv
                    and b.empcode like ip_empcode
                    and e.compcode is null
            union all
            select  'N' as crtsel, -- 출력여부
                    a.slipinno, -- 전표번호
                    a.slipinseq, -- 일련번호
                    c.slipdate, -- 전표일자
                    c.slipnum, -- 전표번호
                    e.accname as slipaccname, -- 전표계정명
                    c.remark1 as slipremark, -- 전표비고
                    '' repaydate, -- 생성일자
                    c.debamt + c.creamt - nvl(b.repayamt, 0) as repayamt, -- 반제금액
                    c.debamt + c.creamt - nvl(b.repayamt, 0) as createamt, -- 생성금액
                    0 restamt, -- 생성잔액
                    a.acccode, -- 상대계정코드
                    d.accname, -- 상대계정명
                    a.remark, -- 반제비고
                    coalesce(j.custname, m.custname, k.mngcludec, '') as custname, -- 거래처
                    coalesce(j.bankcode, m.bankcode, l.paybankdiv, '') as bankcode, -- 은행코드
                    coalesce(j.bankempname, m.bankempname, l.payaccempnm, '') as bankempname, -- 예금주
                    coalesce(j.accountno, m.accountno, l.payaccno, '') as accountno, -- 계좌번호
                    h.mngcluval as saccountno, -- 지급계좌번호
                    '2' as crediv, -- 생성구분
                    case when p_plantcoder is null then c.plantcode else p_plantcoder end as plantcode -- 사업장
            from    ACORDRPYM a -- 반제마스터내역
                    join (
                        select  a.slipinno,
                                a.slipinseq,
                                sum(b.repayamt) as repayamt
                        from    ACORDRPYM a -- 반제마스터내역
                                left join ACORDRPYD b
                                    on a.compcode = b.compcode -- 반제상세내역
                                    and a.slipinno = b.slipinno
                                    and a.slipinseq = b.slipinseq
                                    and b.crtslipinno is not null
                                left join ACORDRPYD c
                                    on a.compcode = c.compcode -- 반제상세내역
                                    and a.slipinno = c.slipinno
                                    and a.slipinseq = c.slipinseq
                                    and c.crtslipinno is null
                        where   a.compcode = p_compcode
                                and a.expdiv = p_expdiv
                                and a.empcode like ip_empcode
                                and a.startdate <= ip_enddate
                                and ip_startdate <= a.enddate
                                and a.endyn = 'N'
                                and c.compcode is null
                        group by a.slipinno, a.slipinseq
                    ) b on a.slipinno = b.slipinno
                        and a.slipinseq = b.slipinseq
                    join ACORDD c
                        on a.compcode = c.compcode -- 전표상세내역
                        and a.slipinno = c.slipinno
                        and a.slipinseq = c.slipinseq
                        and c.plantcode like p_plantcode
                        and nvl(c.acccode,' ') like p_acccode || '%'
                    join ACACCM d
                        on nvl(a.acccode,' ') = nvl(d.acccode,' ') -- 상대계정정보
                    left join ACACCM e
                        on nvl(c.acccode,' ') = nvl(e.acccode,' ') -- 전표계정정보
                    left join ACORDRPYS h
                        on a.compcode = h.compcode
                        and a.slipinno = h.slipinno
                        and a.slipinseq = h.slipinseq
                        and h.mngclucode = 'S020'
                    left join ACORDRPYS i
                        on a.compcode = i.compcode
                        and a.slipinno = i.slipinno
                        and a.slipinseq = i.slipinseq
                        and i.mngclucode = 'S010'
                    left join CMCUSTM j
                        on i.mngcluval = j.custcode
                    left join ACORDRPYS k
                        on a.compcode = k.compcode
                        and a.slipinno = k.slipinno
                        and a.slipinseq = k.slipinseq
                        and k.mngclucode = 'S050'
                    left join PSEMPPAYBASEM l
                        on k.mngcluval = l.empcode
                    left join (
                        select  a.compcode,
                                a.slipinno,
                                a.slipinseq,
                                c.mngcluval as bankcode,
                                d.mngcluval as bankempname,
                                replace(e.mngcluval, '-', '') as accountno,
                                f.mngcluval as custname
                        from    ACORDRPYM a -- 반제상세내역
                                left join ACORDS c
                                    on a.compcode = c.compcode
                                    and a.slipinno = c.slipinno
                                    and a.slipinseq = c.slipinseq
                                    and c.mngclucode = 'S030'
                                    and c.mngcluval is not null
                                left join ACORDS d
                                    on a.compcode = d.compcode
                                    and a.slipinno = d.slipinno
                                    and a.slipinseq = d.slipinseq
                                    and d.mngclucode = 'U091'
                                    and d.mngcluval is not null
                                left join ACORDS e
                                    on a.compcode = e.compcode
                                    and a.slipinno = e.slipinno
                                    and a.slipinseq = e.slipinseq
                                    and e.mngclucode = 'U090'
                                    and e.mngcluval is not null
                                left join ACORDS f
                                    on a.compcode = f.compcode
                                    and a.slipinno = f.slipinno
                                    and a.slipinseq = f.slipinseq
                                    and f.mngclucode = 'U092'
                                    and f.mngcluval is not null
                        where   a.compcode = p_compcode
                                and a.expdiv = p_expdiv
                                and a.empcode like ip_empcode
                                and a.startdate <= ip_enddate
                                and ip_startdate <= a.enddate
                                and a.endyn = 'N'
                    ) m on a.slipinno = m.slipinno
                        and a.slipinseq = m.slipinseq
            where   a.compcode = p_compcode
                    and a.expdiv = p_expdiv
                    and a.empcode like ip_empcode
                    and a.startdate <= ip_enddate
                    and ip_startdate <= a.enddate
                    and a.endyn = 'N'
        ) --with end
        select  a.*,
                b.mngcludec1,
                b.mngcludec2,
                b.mngcludec3,
                b.mngcludec4,
                b.mngcludec5,
                b.mngcludec6
        from    TT_ACORDRPYD a
                left join (
                    select  slipinno,
                            slipinseq,
                            max(case when seq = 1 then mngcludec else '' end) as mngcludec1,
                            max(case when seq = 2 then mngcludec else '' end) as mngcludec2,
                            max(case when seq = 3 then mngcludec else '' end) as mngcludec3,
                            max(case when seq = 4 then mngcludec else '' end) as mngcludec4,
                            max(case when seq = 5 then mngcludec else '' end) as mngcludec5,
                            max(case when seq = 6 then mngcludec else '' end) as mngcludec6
                    from (
                        select  b.slipinno,
                                b.slipinseq,
                                row_number() over (partition by b.slipinno, b.slipinseq order by c.seq) as seq,
                                nvl(c.mngcludec, '') || ' : ' || nvl(c.mngcluval, '') ||
                                case when d.businessno is not null then '(' || d.businessno || ')' else '' end as mngcludec
                        from    TT_ACORDRPYD a
                                join ACORDD b
                                    on b.compcode = p_compcode
                                    and a.slipinno = b.slipinno
                                    and a.slipinseq = b.slipinseq
                                join ACORDS c
                                    on b.compcode = c.compcode
                                    and b.slipinno = c.slipinno
                                    and b.slipinseq = c.slipinseq
                                left join CMCUSTM d
                                    on c.mngclucode = 'S010'
                                    and c.mngcluval = d.custcode
                    ) a
                    group by slipinno, slipinseq
                ) b on a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
        order by a.slipdate, a.slipinno, a.slipinseq, a.repaydate;

    elsif (p_div = 'IM') then   -- 반제마스터내역 입력
        insert into ACORDRPYM
            (
                compcode,
                slipinno,
                slipinseq,
                expdiv,
                empcode,
                startdate,
                enddate,
                createday,
                repeatmon,
                acccode,
                remark,
                endyn,
                insertdt,
                iempcode
            )
        values
            (
                p_compcode,
                p_slipinno,
                p_slipinseq,
                p_expdiv,
                ip_empcode,
                ip_startdate,
                ip_enddate,
                p_createday,
                p_repeatmon,
                p_acccode,
                ip_remark,
                p_endyn,
                sysdate,
                ip_empcode
            );

    elsif (p_div = 'UM') then   -- 반제마스터내역 수정
        update  ACORDRPYM
        set     expdiv = p_expdiv,
                empcode = ip_empcode,
                startdate = ip_startdate,
                enddate = ip_enddate,
                createday = p_createday,
                repeatmon = p_repeatmon,
                acccode = p_acccode,
                remark = ip_remark,
                endyn = p_endyn,
                updatedt = sysdate,
                uempcode = ip_empcode
        where   compcode = p_compcode
                and slipinno = p_slipinno
                and slipinseq = p_slipinseq;

    elsif (p_div = 'DM') then   -- 반제마스터내역 삭제
        for rec in (
            select  1 as alias1
            from    DUAL
            where   not exists (select  *
                                from    ACORDRPYD a
                                        join ACORDM b
                                            on a.compcode = b.compcode
                                            and a.crtslipinno = b.slipinno
                                where   a.compcode = p_compcode
                                        and a.slipinno = p_slipinno
                                        and a.slipinseq = p_slipinseq))
        loop
            v_temp := rec.alias1;
        end loop;

        if v_temp = 1
        then
            delete
            from    ACORDRPYS
            where   compcode = p_compcode
                    and slipinno = p_slipinno
                    and slipinseq = p_slipinseq;
    
            delete
            from    ACORDRPYD
            where   compcode = p_compcode
                    and slipinno = p_slipinno
                    and slipinseq = p_slipinseq;
    
            delete
            from    ACORDRPYM
            where   compcode = p_compcode
                    and slipinno = p_slipinno
                    and slipinseq = p_slipinseq;
        else
            MESSAGE := '';
        end if;

    elsif (p_div = 'ID') then   -- 반제상세내역 입력
        insert into ACORDRPYD
            (
                compcode,
                slipinno,
                slipinseq,
                repaydate,
                repayamt,
                crtslipinno,
                autocrtyn,
                insertdt,
                iempcode
            )
        values
            (
                p_compcode,
                p_slipinno,
                p_slipinseq,
                p_repaydate,
                p_repayamt,
                p_crtslipinno,
                'N',
                sysdate,
                ip_empcode
            );

    elsif (p_div = 'UD') then   -- 반제상세내역 수정
        update  ACORDRPYD
        set     repayamt = p_repayamt,
                autocrtyn = 'N',
                updatedt = sysdate,
                uempcode = ip_empcode
        where   compcode = p_compcode
                and slipinno = p_slipinno
                and slipinseq = p_slipinseq
                and repaydate = p_repaydate;

    elsif (p_div = 'DD') then   -- 반제상세내역 삭제
        for rec in (
            select  1 as alias1
            from    DUAL
            where   not exists (select  *
                                from    ACORDRPYD a
                                        join ACORDM b
                                            on a.compcode = b.compcode
                                            and a.crtslipinno = b.slipinno
                                where   a.compcode = p_compcode
                                        and a.slipinno = p_slipinno
                                        and a.slipinseq = p_slipinseq
                                        and a.repaydate = p_repaydate))
        loop
            v_temp := rec.alias1;
        end loop;

        if v_temp = 1
        then
            delete
            from    ACORDRPYD
            where   compcode = p_compcode
                    and slipinno = p_slipinno
                    and slipinseq = p_slipinseq
                    and repaydate = p_repaydate;
        else
            MESSAGE := '';
        end if;

    elsif (p_div = 'IS') then   -- 반제관리내역 입력
        insert into ACORDRPYS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        values
            (
                p_compcode,
                p_slipinno,
                p_slipinseq,
                p_mngclucode,
                p_seq,
                p_mngcluval,
                p_mngcludec,
                sysdate,
                ip_empcode
            );

    elsif (p_div = 'US') then   -- 반제관리내역 수정
        update  ACORDRPYS
        set     seq = p_seq,
                mngcluval = p_mngcluval,
                mngcludec = p_mngcludec,
                updatedt = sysdate,
                uempcode = ip_empcode
        where   compcode = p_compcode
                and slipinno = p_slipinno
                and slipinseq = p_slipinseq
                and mngclucode = p_mngclucode;

    elsif (p_div = 'DS') then   -- 반제관리내역 삭제
        delete
        from    ACORDRPYS
        where   compcode = p_compcode
                and slipinno = p_slipinno
                and slipinseq = p_slipinseq
                and mngclucode = p_mngclucode;

    elsif (p_div = 'CO') then   -- 반제관리내역 생성
        insert into ACORDRPYM
            (
                compcode,
                slipinno,
                slipinseq,
                expdiv,
                empcode,
                startdate,
                enddate,
                createday,
                repeatmon,
                acccode,
                remark,
                endyn,
                insertdt,
                iempcode
            )
        select  compcode,
                slipinno,
                slipinseq,
                p_expdiv,
                ip_empcode,
                slipdate,
                to_char(add_months(to_date(slipdate, 'yyyy-MM-dd'), 12), 'yyyy-MM-dd'),
                31,
                1,
                p_acccode,
                ip_remark,
                'N',
                sysdate,
                ip_empcode
        from    ACORDD a
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno
                and a.slipinseq = p_slipinseq;

        insert into ACORDRPYS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                p_slipinseq,
                a.mngclucode,
                a.seq,
                case when a.mngclucode = b.mngclucode and a.mngcluval is null then b.mngcluval
                     when a.mngclucode = c.mngclucode and a.mngcluval is null then c.mngcluval
                     when a.mngclucode = d.mngclucode and a.mngcluval is null then d.mngcluval
                     else a.mngcluval
                     end,
                case when a.mngclucode = b.mngclucode and a.mngcluval is null then b.mngcludec
                     when a.mngclucode = c.mngclucode and a.mngcluval is null then c.mngcludec
                     when a.mngclucode = d.mngclucode and a.mngcluval is null then d.mngcludec
                     else a.mngcludec
                     end,
                sysdate,
                ip_empcode
        from (
            select  a.mngclucode,
                    a.seq,
                    case when a.mngclucode = p_mngclucode then p_mngcluval when a.mngclucode = p_mngclucode2 then p_mngcluval2 else '' end as mngcluval,
                    case when a.mngclucode = p_mngclucode then p_mngcludec when a.mngclucode = p_mngclucode2 then p_mngcludec2 else '' end as mngcludec
            from    ACACCMNGM a -- 반제마스터내역
            where   a.acccode = p_acccode
                    and a.dcdiv = case when p_expdiv = '1' then '2' else '1' end
        ) a
                left join ACORDS b
                    on b.compcode = p_compcode
                    and b.slipinno = p_slipinno
                    and b.slipinseq = p_slipinseq
                    and b.mngclucode = 'S010'
                left join ACORDS c
                    on c.compcode = p_compcode
                    and c.slipinno = p_slipinno
                    and c.slipinseq = p_slipinseq
                    and c.mngclucode = 'S040'
                left join ACORDS d
                    on d.compcode = p_compcode
                    and d.slipinno = p_slipinno
                    and d.slipinseq = p_slipinseq
                    and d.mngclucode = 'S050';

    elsif (p_div = 'CC') then -- 반제전표 내역 생성
        -- 원인전표 생성
        insert into ACORDD
            (
                compcode,
                slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                taxno,
                datadiv,
                rptseq,
                insertdt,
                iempcode
            )
        select  a.compcode,
                p_slipno,
                p_slipseq + case when b.expdiv = '1' then 1 else 2 end,
                b.expdiv,
                a.acccode,
                c.plantcode,
                case when b.expdiv = '1' then p_repayamt else 0 end,
                case when b.expdiv = '1' then 0 else p_repayamt end,
                case when p_crtslip = '0' then '' else p_repaydate end,
                case when p_crtslip = '0' then '' else substr(p_slipno, -5) end,
                a.remark1,
                a.remark2,
                '',
                b.expdiv,
                p_slipseq + case when b.expdiv = '1' then 1 else 2 end,
                sysdate,
                ip_empcode
        from    ACORDD a
                join ACORDRPYM b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
                join ACORDM c
                    on a.compcode = c.compcode
                    and c.slipinno = p_slipno
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno
                and a.slipinseq = p_slipinseq;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  a.compcode,
                p_slipno,
                p_slipseq + case when b.expdiv = '1' then 1 else 2 end,
                a.mngclucode,
                a.seq,
                case when d.remainyn = 'Y' or p_crtmathod <> '2' then a.mngcluval else '' end,
                case when d.remainyn = 'Y' or p_crtmathod <> '2' then a.mngcludec else '' end,
                sysdate,
                ip_empcode
        from    ACORDS a
                join ACORDRPYM b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
                join ACORDD c
                    on a.compcode = c.compcode
                    and a.slipinno = c.slipinno
                    and a.slipinseq = c.slipinseq
                left join ACACCMNGM d
                    on c.acccode = d.acccode
                    and (c.dcdiv in ('1', '4') and d.dcdiv = '1'
                         or c.dcdiv in ('2', '3') and d.dcdiv = '2')
                    and a.mngclucode = d.mngclucode
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno
                and a.slipinseq = p_slipinseq;

        -- 반제전표 생성
        insert into ACORDD
            (
                compcode,
                slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                taxno,
                datadiv,
                rptseq,
                insertdt,
                iempcode
            )
        select  a.compcode,
                p_slipno,
                p_slipseq + case when b.expdiv = '1' then 2 else 1 end,
                case when b.expdiv = '1' then '2' else '1' end col,
                b.acccode,
                c.plantcode,
                case when b.expdiv = '1' then 0 else p_repayamt end col,
                case when b.expdiv = '1' then p_repayamt else 0 end col,
                case when p_crtslip = '0' then '' else p_repaydate end,
                case when p_crtslip = '0' then '' else substr(p_slipno, -5) end,
                a.remark1,
                a.remark2,
                '',
                case when b.expdiv = '1' then '2' else '1' end col,
                p_slipseq + case when b.expdiv = '1' then 2 else 1 end,
                sysdate,
                ip_empcode
        from    ACORDD a
                join ACORDRPYM b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
                join ACORDM c
                    on a.compcode = c.compcode
                    and c.slipinno = p_slipno
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno
                and a.slipinseq = p_slipinseq;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  a.compcode,
                p_slipno,
                p_slipseq + case when b.expdiv = '1' then 2 else 1 end,
                a.mngclucode,
                a.seq,
                case when d.remainyn = 'Y' or p_crtmathod <> '2'
                     then case when a.mngclucode = 'S020' then nvl(e.accountno, a.mngcluval) else a.mngcluval end
                     else ''
                     end,
                case when d.remainyn = 'Y' or p_crtmathod <> '2'
                     then case when a.mngclucode = 'S020' then nvl(e.accremark, a.mngcludec) else a.mngcludec end
                     else ''
                     end,
                sysdate,
                ip_empcode
        from    ACORDRPYS a
                join ACORDRPYM b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
                join ACORDD c
                    on a.compcode = c.compcode
                    and a.slipinno = c.slipinno
                    and a.slipinseq = c.slipinseq
                left join ACACCMNGM d
                    on b.acccode = d.acccode
                    and (c.dcdiv in ('1', '4') and d.dcdiv = '2'
                         or c.dcdiv in ('2', '3') and d.dcdiv = '1')
                    and a.mngclucode = d.mngclucode
                left join CMACCOUNTM e
                    on e.accountno = p_saccountno
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno
                and a.slipinseq = p_slipinseq
        order by a.seq;

        -- 반제상세 갱신
        for rec in (
            select  1 as alias1
            from    DUAL
            where   exists (select  *
                            from    ACORDRPYD
                            where   compcode = p_compcode
                                    and slipinno = p_slipinno
                                    and slipinseq = p_slipinseq
                                    and repaydate = p_repaydate))
        loop
            v_temp := rec.alias1;
        end loop;

        if v_temp = 1
        then
            update  ACORDRPYD
            set     crtslipinno = p_slipno
            where   compcode = p_compcode
                    and slipinno = p_slipinno
                    and slipinseq = p_slipinseq
                    and repaydate = p_repaydate;
        else
            insert into ACORDRPYD
                (
                    compcode,
                    slipinno,
                    slipinseq,
                    repaydate,
                    repayamt,
                    crtslipinno,
                    autocrtyn,
                    insertdt,
                    iempcode
                )
            select  p_compcode,
                    p_slipinno,
                    p_slipinseq,
                    p_repaydate,
                    p_repayamt,
                    p_slipno,
                    'Y',
                    sysdate,
                    ip_empcode
            from    DUAL;
        end if;

        update  ACORDRPYM
        set     endyn = 'Y'
        where   (compcode, slipinno, slipinseq) = ( select  a.compcode,
                                                            a.slipinno,
                                                            a.slipinseq
                                                    from    ACORDRPYM a
                                                            join ACORDD b
                                                                on a.compcode = b.compcode
                                                                and a.slipinno = b.slipinno
                                                                and a.slipinseq = b.slipinseq
                                                            join (
                                                                select  sum(a.repayamt) as repayamt
                                                                from    ACORDRPYD a
                                                                        join ACORDD b
                                                                            on a.compcode = b.compcode
                                                                            and a.slipinno = b.slipinno
                                                                            and a.slipinseq = b.slipinseq
                                                                where   a.compcode = p_compcode
                                                                        and a.slipinno = p_slipinno
                                                                        and a.slipinseq = p_slipinseq
                                                            ) c on 1 = 1
                                                    where   a.compcode = p_compcode
                                                            and a.slipinno = p_slipinno
                                                            and a.slipinseq = p_slipinseq
                                                            and (b.debamt + b.creamt) <= c.repayamt);

    MESSAGE := p_slipseq + 2;

    for rec in (
        select  value2
        from    SYSPARAMETERMANAGE
        where   parametercode = 'copercardpopup')
    loop
        p_sendacc := rec.value2;
    end loop;

    p_group_nm := 'ACACC0012P' || p_slipinno || fnlpad(p_slipinseq, 5, '0');

    p_list_nm := '';

    for rec in (
        select  mngcludec
        from    ACORDRPYS
        where   compcode = p_compcode
                and slipinno = p_slipinno
                and slipinseq = p_slipinseq
                and mngclucode = 'S010')
    loop
        p_list_nm := rec.mngcludec;
    end loop;

    if p_list_nm is null then
        for rec in (
            select  mngcludec
            from    ACORDRPYS
            where   compcode = p_compcode
                    and slipinno = p_slipinno
                    and slipinseq = p_slipinseq
                    and mngclucode = 'S050')
        loop
            p_list_nm := rec.mngcludec;
        end loop;
    end if;

    ip_remark := '';

    for rec in (
        select  remark
        from    ACORDRPYM
        where   compcode = p_compcode
                and slipinno = p_slipinno
                and slipinseq = p_slipinseq)
    loop
        ip_remark := rec.remark;
    end loop;

    for rec in (
        select  1 as alias1
        from    DUAL
        where   exists (select  *
                        from    ACORDRPYM
                        where   compcode = p_compcode
                                and slipinno = p_slipinno
                                and slipinseq = p_slipinseq
                                and acccode = p_sendacc
                                and expdiv = '1')
                and p_crttran = 'Y')
    loop
        v_temp := rec.alias1;
    end loop;
  /* 2016-12-14  : ERP_ICHE_DATA , ERP_ICHE_DATA 테이블이 없어서 주석 처리함
                  if v_temp = 1 then

                      -- 기업 ebranch
                      delete ERP_ICHE_DATA
                      where  erp_rec_no = p_group_nm;

                      for  rec in (   select  nvl(max(reg_seq) , 0) + 1  as alias1
                                      from    ERP_ICHE_DATA
                                      where   reg_date = p_reg_date
                                              and reg_time = p_reg_time
                                              and ext_1 = ip_empcode)
                      loop
                          p_tran_dt_seq := rec.alias1;
                      end loop;


                      insert into ERP_ICHE_DATA ( site_no,        reg_date,       reg_time,                   reg_seq,                                        iche_gb,
                                                  fl_seq,         rsrv_yn,        in_bank_cd,                 in_acct_no,                                     tran_amt,
                                                  pre_reci_man,   pay_gb,         in_prt,                     out_prt,                                        erp_rec_no,
                                                  ext_1)

                      ( select                    '1348115033' ,  p_reg_date ,    p_reg_time ,                p_tran_dt_seq ,                                 '4' ,

                                                  1 ,             '0' ,           substr(p_bankcode, 0, 3) ,  substr(replace(p_accountno, '-', ''), 0, 20) ,  p_repayamt ,
                                                  p_list_nm ,     '' ,            to_char(ip_remark) ,        p_list_nm ,                                     p_group_nm ,
                                                  ip_empcode
                      from DUAL);

                  end if;
          */

    end if;

    if (IO_CURSOR is null)
    then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;
END;
/
