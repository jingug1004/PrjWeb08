CREATE FUNCTION F_GET_WORK_DAYS_YMD(
        I_EMP_NO IN VARCHAR2
       ,I_OPTION IN VARCHAR2
       ,I_END_YMD IN VARCHAR2
)
RETURN VARCHAR2 IS
        v_encmpy_dt VARCHAR2(8);
        v_retir_dt  VARCHAR2(8);

        v_in_year number;
        v_in_month number;
        v_in_day number;
        v_out_year number;
        v_out_month number;
        v_out_day number;
        v_day_loop number;
        v_rtn_year number;
        v_rtn_month number;
        v_rtn_day number;

        v_cnt number;
        v_temp date;
BEGIN
        /*CHOE 20171214
        I_OPTION - 파라미터 추가
        YMD를 넘기는 경우 ex) 1년 10개월 3일
        Y - 실근무년수
        M - 실근무개월수
        D - 실근무일수
        넘긴다.

        CHOE  20160620
        I_END_YMD
        연차휴가 사용 통보서에는 지난해 연차일이 매우 중요한다.
        남은연차일 = 연차사용가능일 - 올해 사용일  : 2014년
        2014 -> 2015 -> 2016년에 계속 영향을 준다.
        */

        v_in_year := 0;
        v_in_month := 0;
        v_in_day := 0;
        v_out_year := 0;
        v_out_month :=0;
        v_out_day := 0;
        v_rtn_year := 0;
        v_rtn_month := 0;
        v_rtn_day := 0;

        ----- 입사일자,퇴사일자
        select REPLACE(ENTERDT ,'-' ,'') ,NVL(REPLACE(RETIREDT ,'-' ,'') ,TO_CHAR(sysdate,'yyyymmdd'))
        into v_encmpy_dt,v_retir_dt
        from ORAGMP.CMEMPM
        WHERE EMPCODE = I_EMP_NO;

        v_in_year := to_number(substr(v_encmpy_dt,1,4));
        v_in_month := to_number(substr(v_encmpy_dt,5,2));
        v_in_day := to_number(substr(v_encmpy_dt,7,2));


        -- 종료일이 있는 경우 그값을 처리
        IF I_END_YMD IS NOT NULL THEN
                --RETURN I_END_YMD;
                v_retir_dt := I_END_YMD;
        END IF;


        v_out_year  := to_number(substr(v_retir_dt,1,4));
        v_out_month := to_number(substr(v_retir_dt,5,2));
        v_out_day := to_number(substr(v_retir_dt,7,2));

        ----- 날짜 CHECK
        IF TO_dATE(v_encmpy_dt, 'YYYYMMDD') >= TO_DATE(v_retir_dt, 'YYYYMMDD') THEN
                RETURN '0 년  0 개월  0 일';
        END IF;

        ----- 일수 구하기
        IF v_out_day <= v_in_day THEN
                v_out_month := v_out_month - 1;
                IF v_out_month = 0 THEN
                        v_out_year := v_out_year - 1;
                        v_out_month := 12;
                END IF;

                --CHOE 2017.02.01한달이 되지 않은 경우 처리
                --IF (v_in_day - v_out_day) < 30 THEN
                    --v_out_day := v_in_day - v_out_day;
                --ELSE
                        v_cnt := 31;
                        WHILE v_cnt > 27 LOOP

                                BEGIN
                                        select to_date(trim(to_char(v_out_year,'0000'))||trim(to_char(v_out_month,'00'))||trim(to_char(v_cnt,'00')),'yyyymmdd' ) into v_temp from dual;
                                        v_out_day := v_out_day + v_cnt;
                                        EXIT;
                                EXCEPTION WHEN OTHERS THEN
                                        v_cnt := v_cnt - 1;
                                END;

                        END LOOP;
                --END IF;
        END IF;

        v_rtn_day := v_out_day - v_in_day + 1; --퇴사일 포함


        --월구하기
        IF v_out_month <= v_in_month THEN
                v_out_year  := v_out_year - 1;
                v_out_month := v_out_month + 12;
        END IF;

        v_rtn_month := v_out_month - v_in_month;

        IF v_rtn_month = 12 THEN
                v_rtn_month := 0;
                v_out_year := v_out_year + 1;
        END IF;

        --년 구하기
        v_rtn_year := NVL(v_out_year ,0) - NVL(v_in_year ,0);


        --CHIOE 20160525 I_OPTION 변경사항
        IF I_OPTION = 'YMD' THEN
                RETURN to_char(v_rtn_year)||' 년 '||to_char(v_rtn_month)||' 개월 '||to_char(v_rtn_day)||' 일';
        ELSIF I_OPTION = 'Y' THEN
                RETURN TO_CHAR(v_rtn_year);
        ELSIF I_OPTION = 'M' THEN
                RETURN TO_CHAR(v_rtn_month);
        ELSIF I_OPTION = 'D' THEN
                RETURN TO_CHAR(v_rtn_day);
        END IF;


EXCEPTION
    WHEN NO_DATA_FOUND THEN
    RETURN ' ';
    WHEN OTHERS THEN
    RETURN ' ';
END;

/*********************************************************************************/
/*                END  PROGRAM                                            */
/*********************************************************************************/
/
