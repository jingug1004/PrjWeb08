CREATE FUNCTION fnPrevWorkingDate
-- ---------------------------------------------------------------
 -- 함 수 명			: fnPrevWorkingDate
 -- 작 성 자         : 민승기
 -- 작성일자         : 2007-11-01
 -- 수정자         :  임 정호
 -- 수정일자         : 2017-01-11

 -- ---------------------------------------------------------------
 -- 함수설명			: 이전 근무일 계산
 -- ---------------------------------------------------------------

(
  p_daycnt IN NUMBER DEFAULT 0 ,
  ip_basedate IN DATE DEFAULT NULL
)
RETURN DATE
AS
   p_basedate DATE := ip_basedate;
   p_todate DATE;
   p_rowcnt NUMBER(10,0);

BEGIN
    p_basedate := NVL(p_basedate,sysdate);

    FOR  rec IN
    (
        SELECT  MIN(A.calymd)   AS alias1  ,
                COUNT(*)  - 1  AS alias2
        FROM    (
                    SELECT *
                    FROM    (
                                SELECT  calymd
                                FROM    PSCALM
                                WHERE   calymd BETWEEN to_char( (p_basedate - (ABS(p_daycnt) + 50)),'yyyy-mm-dd') AND to_char(p_basedate,'yyyy-mm-dd')
                                    AND NVL(caldiv, ' ') IN ( '01') -- 평일
                                ORDER BY calymd DESC
                            )
                    WHERE   ROWNUM <= ABS(NVL(p_daycnt, 0)) + 1
                ) A
    )
    LOOP
        p_todate := TO_DATE(rec.alias1,'YYYY-MM-DD')   ;
        p_rowcnt := rec.alias2   ;
    END LOOP;

    IF ( p_rowcnt <> p_daycnt ) THEN
        p_todate := (p_basedate  -ABS(p_daycnt));
    END IF;

    RETURN (p_todate);

EXCEPTION WHEN OTHERS THEN RETURN NULL;

END;
/
