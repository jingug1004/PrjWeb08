CREATE PROCEDURE spACacc0106R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0106R
	-- 작 성 자         : 배종성
	-- 작성일자         : 2010-12-17
	-- 2011-01-18 edit by 이영재 (현금계정, 집계출력 오류 수정)
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-20
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 일계표를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_startdt		IN	   VARCHAR2 DEFAULT '',
	p_enddt 		IN	   VARCHAR2 DEFAULT '',
	p_outputdiv 	IN	   NUMBER DEFAULT 0,
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	p_acccashcode	VARCHAR2(20);
	p_odiv1 		VARCHAR2(5);
	p_odiv2 		VARCHAR2(5);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	FOR rec IN (SELECT value1
				FROM   SYSPARAMETERMANAGE
				WHERE  parametercode = 'acccashcode')
	LOOP
		p_acccashcode := rec.value1;
	END LOOP;

	IF (p_outputdiv = '1')
	THEN
		--K-GAAP
		p_odiv1 := '20';
		p_odiv2 := 'F';
	ELSIF (p_outputdiv = '2')
	THEN
		--IFRS
		p_odiv1 := '30';
		p_odiv2 := 'K';
	END IF;

	IF (p_div = 'S')
	THEN
		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0106R_ACACC0106RBASE ';

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0106R_ACACC0106R1 ';

		INSERT INTO VGT.TT_ACACC0106R_ACACC0106RBASE
			(SELECT   SUM(debdcount) + SUM(debamt) debsumamt,
					  SUM(debdcount) debdcount,
					  SUM(debamt) debamt,
					  acccode,
					  SUM(cresumamt) cresumamt,
					  SUM(credcount) credcount,
					  SUM(cresumamt) + SUM(credcount) creamt
			 FROM	  ( --대체전표 조회
					   SELECT 0 debsumamt, -- 차변합계
							  NVL(debamt, 0) debdcount, -- 차변대체
							  0 debamt, -- 차변출금
							  acccode,
							  0 cresumamt, -- 대변입금
							  NVL(creamt, 0) credcount, -- 대변대체
							  0 creamt -- 대변합계
					   FROM   ACORDD a
							  JOIN ACORDM b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
					   WHERE  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipdate BETWEEN p_startdt AND p_enddt
							  AND (dcdiv = '1'
								   OR dcdiv = '2')
							  AND a.acccode <> p_acccashcode
							  AND b.slipdiv <> p_odiv2 -- K-GAAP <> 'F', IFRS <> 'K'
					   UNION ALL
					   SELECT 0 debsumamt, -- 차변합계
							  NVL(debamt, 0) * -1 debdcount, -- 차변대체
							  NVL(debamt, 0) debamt, -- 차변출금
							  acccode,
							  NVL(creamt, 0) cresumamt, -- 대변입금
							  NVL(creamt, 0) * -1 credcount, -- 대변대체
							  0 creamt -- 대변합계
					   FROM   ACORDD a,
							  (SELECT a.slipdate slipdate, a.slipnum slipnum
							   FROM   ACORDD a
									  JOIN ACORDM b
										  ON a.compcode = b.compcode
											 AND a.slipinno = b.slipinno
							   WHERE  a.compcode = p_compcode
									  AND a.plantcode LIKE p_plantcode
									  AND a.slipdate BETWEEN p_startdt AND p_enddt
									  AND (dcdiv = '1'
										   OR dcdiv = '2')
									  AND a.acccode = p_acccashcode
									  AND b.slipdiv <> p_odiv2) b -- K-GAAP <> 'F', IFRS <> 'K'
					   WHERE --a.compcode = @compcode
							  --and a.plantcode like @plantcode
							  a.slipdate = b.slipdate
							  AND a.slipnum = b.slipnum
							  AND a.acccode <> p_acccashcode
					   UNION ALL
					   SELECT 0 debsumamt, -- 차변합계
							  0 debdcount, -- 차변대체
							  NVL(debamt, 0) debamt, -- 차변출금
							  acccode,
							  NVL(creamt, 0) cresumamt, -- 대변입금
							  0 credcount, -- 대변대체
							  0 creamt -- 대변합계
					   FROM   ACORDD a
							  JOIN ACORDM b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
					   WHERE  a.compcode = p_compcode
							  AND a.plantcode LIKE p_plantcode
							  AND a.slipdate BETWEEN p_startdt AND p_enddt
							  AND (dcdiv = '3'
								   OR dcdiv = '4')
							  AND b.slipdiv <> p_odiv2) a -- K-GAAP <> 'F', IFRS <> 'K'
			 GROUP BY acccode);

		INSERT INTO VGT.TT_ACACC0106R_ACACC0106R1
			(SELECT SUM(bsdebamt) + SUM(debamt) - SUM(creamt) debsumamt, -- 차변합계
					0 debdcount, -- 차변대체
					SUM(bsdebamt) + SUM(debamt) - SUM(creamt) debamt, -- 차변출금
					'a' acccode,
					SUM(bsdebamt) cresumamt, -- 대변입금
					0 credcount, -- 대변대체
					SUM(bsdebamt) creamt
			 FROM	(SELECT NVL(bsdebamt - bscreamt, 0) bsdebamt, 0 debamt, 0 creamt
					 FROM	ACORDDMM
					 WHERE	compcode = p_compcode
							AND plantcode LIKE p_plantcode
							AND acccode = p_acccashcode
							AND slipym = SUBSTR(p_enddt, 1, 7)
							AND (closediv = '10'
								 OR closediv = p_odiv1 -- 출력구분 [K-GAAP, IFRS]
													  )
					 UNION ALL
					 SELECT CASE WHEN a.acccode = p_acccashcode THEN a.debamt - a.creamt ELSE a.creamt - a.debamt END bsdebamt, 0 debamt, 0 creamt
					 FROM	ACORDD a
							JOIN ACORDM b
								ON a.compcode = b.compcode
								   AND a.slipinno = b.slipinno
					 WHERE	a.compcode = p_compcode
							AND a.plantcode LIKE p_plantcode
							AND a.slipdate >= SUBSTR(p_startdt, 1, 7) || '-01'
							AND a.slipdate < p_startdt
							AND (a.acccode = p_acccashcode
								 AND (dcdiv = '1'
									  OR dcdiv = '2')
								 OR dcdiv = '3'
								 OR dcdiv = '4')
							AND b.slipdiv <> p_odiv2 -- K-GAAP <> 'F', IFRS <> 'K'
					 UNION ALL
					 SELECT 0 bsdebamt, -- 이월금액
									   CASE WHEN a.acccode = p_acccashcode THEN a.debamt ELSE a.creamt END debamt, CASE WHEN a.acccode = p_acccashcode THEN a.creamt ELSE a.debamt END creamt -- 대변금액
					 FROM	ACORDD a
							JOIN ACORDM b
								ON a.compcode = b.compcode
								   AND a.slipinno = b.slipinno
					 WHERE	a.compcode = p_compcode
							AND a.plantcode LIKE p_plantcode
							AND a.slipdate BETWEEN p_startdt AND p_enddt
							AND (a.acccode = p_acccashcode
								 AND (dcdiv = '1'
									  OR dcdiv = '2')
								 OR dcdiv = '3'
								 OR dcdiv = '4')
							AND b.slipdiv <> p_odiv2 -- K-GAAP <> 'F', IFRS <> 'K'
													) a);

		DELETE VGT.TT_ACACC0106R_ACACC0106RBASE
		WHERE  debsumamt = 0
			   AND debdcount = 0
			   AND debamt = 0
			   AND cresumamt = 0
			   AND credcount = 0
			   AND creamt = 0;

		--   IF utils.object_id('tempdb..#ACacc0106R2') IS NOT NULL
		--   THEN
		--    EXECUTE IMMEDIATE ' DELETE FROM tt_ACacc0106R2 ';
		--   END IF;
		--   DELETE FROM tt_spACacc0106R2;

		--회계일자
		--전표번호
		--결의번호

		OPEN IO_CURSOR FOR
			SELECT	 p_plantcode plantcode, p_startdt startdt, p_enddt enddt, p_outputdiv outputdiv, B.*
			FROM	 (SELECT acccode,
							 debsumamt, -- 차변합계
							 debdcount, -- 차변대체
							 debamt, -- 차변출금
							 accname,
							 cresumamt, -- 대변입금
							 credcount, -- 대변대체
							 creamt
					  FROM	 (SELECT a.acccode,
									 a.debsumamt, -- 차변합계
									 a.debdcount, -- 차변대체
									 a.debamt, -- 차변출금
									 b.accname,
									 a.cresumamt, -- 대변입금
									 a.credcount, -- 대변대체
									 a.creamt
							  FROM	 VGT.TT_ACACC0106R_ACACC0106RBASE a, ACACCM b
							  WHERE  a.acccode = b.acccode
							  UNION --and (a.debsumamt <> 0 and a.creamt <> 0)
								   ALL
							  SELECT 'aa' acccode,
									 SUM(debsumamt) debsumamt, -- 차변합계
									 SUM(debdcount) debdcount, -- 차변대체
									 SUM(debamt) debamt, -- 차변출금
									 '소             계' accname,
									 SUM(cresumamt) cresumamt, -- 대변입금
									 SUM(credcount) credcount, -- 대변대체
									 SUM(creamt) creamt
							  FROM	 VGT.TT_ACACC0106R_ACACC0106RBASE
							  UNION ALL
							  SELECT 'bb' acccode,
									 debsumamt, -- 차변합계
									 debdcount, -- 차변대체
									 debamt, -- 차변출금
									 '금일잔고/전일잔고' accname,
									 cresumamt, -- 대변입금
									 credcount, -- 대변대체
									 creamt
							  FROM	 VGT.TT_ACACC0106R_ACACC0106R1
							  UNION ALL
							  SELECT 'zz' acccode,
									 SUM(a.debsumamt) + MAX(b.debsumamt) debsumamt, -- 차변합계
									 SUM(a.debdcount) + MAX(b.debdcount) debdcount, -- 차변대체
									 SUM(a.debamt) + MAX(b.debamt) debamt, -- 차변출금
									 '합             계' accname,
									 SUM(a.cresumamt) + MAX(b.cresumamt) cresumamt, -- 대변입금
									 SUM(a.credcount) + MAX(b.credcount) credcount, -- 대변대체
									 SUM(a.creamt) + MAX(b.creamt) creamt
							  FROM	 VGT.TT_ACACC0106R_ACACC0106RBASE a, VGT.TT_ACACC0106R_ACACC0106R1 b)) B
			ORDER BY acccode;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
