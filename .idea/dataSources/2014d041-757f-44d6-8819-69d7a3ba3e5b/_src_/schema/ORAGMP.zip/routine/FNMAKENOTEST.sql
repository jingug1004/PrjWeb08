CREATE FUNCTION        fnMakeNoTest(
    --select dbo.fnMakeNoTest('2011-07-20','FC1005','')

    -- ---------------------------------------------------------------
    -- 함수명           : [fnMakeNoTest]
    -- 작 성 자         : 권도영
    -- 작성일자         : 2011-04-20
    -- 수 정 자       :   노영래
    -- 수정일자        :   2017-08-01
    -- ---------------------------------------------------------------
    -- 함수 설명        : 품질관리 관련 번호를 생성하는 함수이다.
    -- ---------------------------------------------------------------

     p_requestdate 	VARCHAR2 DEFAULT ''
    ,p_itemcode 	VARCHAR2 DEFAULT ''
    ,p_testdiv2 	VARCHAR2 DEFAULT ''
)
	RETURN VARCHAR2
AS
	p_testdiv		VARCHAR2(5);
	p_headervalue	VARCHAR2(10); --시험의뢰번호의 앞머리 글자 저장
	p_bodyvalue 	VARCHAR2(10); --시험의뢰번호의 구성값저장
	p_bodyvalue2	VARCHAR2(10); --시험의뢰번호의 구성형식결정
	p_nolength		INT; --시험의뢰번호 구성 일련번호길이 결정
	p_return		VARCHAR2(20); --생성된 시험의뢰번호
BEGIN
	FOR REC IN (SELECT a.stockwarehousediv C1
				  FROM (SELECT stockwarehousediv
							  ,CASE itembranch WHEN '05' THEN '700' WHEN '06' THEN '800' ELSE stockwarehousedivname END AS stockwarehousedivname
						  FROM nvItemRM
						 WHERE itemcode = p_itemcode
							   AND itemdiv IN ('01', '02')
						UNION
						SELECT stockwarehousediv
							  ,CASE itemformdiv WHEN '12' THEN '900' ELSE stockwarehousedivname END AS stockwarehousedivname
						  FROM nvItemGP
						 WHERE itemcode = p_itemcode) a)
	LOOP
		p_testdiv := REC.C1;
	END LOOP;

	IF (p_testdiv = '310')
	THEN
		FOR REC IN (SELECT CASE itemdiv WHEN '03' THEN '400' WHEN '04' THEN '310' END C1
					  FROM nvitemgp
					 WHERE itemcode = p_itemcode)
		LOOP
			p_testdiv := REC.C1;
		END LOOP;
	END IF;


	p_bodyvalue := 'C8';
	p_nolength := '3';

	FOR REC IN (SELECT (CASE
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '110'
							THEN
								'B' --원료시험
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '200'
							THEN
								'L' --부자재시험
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '210'
							THEN
								'M' --부자재시험
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '400'
							THEN
								'Q' --반제품시험
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '310'
							THEN
								'P' --완제품시험
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '330'
							THEN
								'P' --완제품시험(수탁)
							WHEN p_testdiv2 = 'R'
							THEN
								'R' --반품시험
							WHEN p_testdiv2 = 'H'
							THEN
								'H'
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '120'
							THEN
								'D' --원료시험(바이알)
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '220'
							THEN
								'N' --부자재시험(바이알)
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '900'
							THEN
								'T' --반제품시험
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '320'
							THEN
								'Z' --완제품시험
							WHEN p_testdiv2 = 'Y'
							THEN
								'Y'
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '100'
							THEN
								'A' --합성원료
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '300'
							THEN
								'J' --중간체 및 완제품
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '700'
							THEN
								'S' --회수용매
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '800'
							THEN
								'W' --용수
							WHEN p_testdiv2 IS NULL
								 AND NVL(p_testdiv, ' ') = '500'
							THEN
								'G' --상품
						END)
						   C1
				  FROM DUAL)
	LOOP
		p_headervalue := REC.C1;
	END LOOP;



	--시험의뢰번호 구성형식에 따라 구성값을 설정한다.
	FOR REC
		IN (SELECT (CASE
						WHEN p_bodyvalue = 'C1' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 1, 8) --yyyymmdd
						WHEN p_bodyvalue = 'C2' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 1, 4) --yyyy
						WHEN p_bodyvalue = 'C3' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 1, 6) --yyyymm
						WHEN p_bodyvalue = 'C4' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 3, 2) --yy
						WHEN p_bodyvalue = 'C5' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 3, 4) --yymm
						WHEN p_bodyvalue = 'C6' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 4, 6) --ymmdd
						WHEN p_bodyvalue = 'C7' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 5, 4) --mmdd
						WHEN p_bodyvalue = 'C8' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 3, 6) --yymmdd
						ELSE SUBSTR(TO_CHAR(REPLACE(p_requestdate, '-', ''), 'YYYYMMDD'), 1, 8) --yyyymmdd
					END)
					   C1
			  FROM DUAL)
	LOOP
		p_bodyvalue2 := REC.C1;
	END LOOP;

	FOR REC IN (SELECT NVL(p_headervalue, '') --앞머리 글자
											 || NVL(p_bodyvalue2, '') --중간구성값결정
																	 || SUBSTR(RPAD('0', 50, '0') || NVL(TO_CHAR(TO_NUMBER(MAX(SUBSTR(testrequestno, -p_nolength))) + 1), '00001'), -p_nolength) C1 -- 최신 시험의뢰번호 다음번호생성
				  FROM testmanage
				 WHERE testno LIKE NVL(p_headervalue, '') || NVL(p_bodyvalue2, '') || '%')
	LOOP
		p_return := REC.C1;
	END LOOP;

	RETURN (p_return);
EXCEPTION
	WHEN OTHERS
	THEN
		p_return := '';
END;
/
