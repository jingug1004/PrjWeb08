CREATE FUNCTION NUM_TO_HANGUL (
       ARG    NUMBER

) RETURN VARCHAR2 IS
/**********************************************************
 * @author  : samE
 * @date    : 2004-09-21
 * @summary : 숫자를 입력받아 한글로 돌려준다.
 **********************************************************/

return_Val  VARCHAR2(150);

arg_Str     VARCHAR2(20); -- 현재값을 문자열로 변경
str_One     VARCHAR2(1) ; -- 한글자로 자른값
arg_Length  NUMBER      ; -- 자리수
cut_Four    NUMBER      ; -- 네자리로 자를경우 몇개 나오는가
four_Mod    NUMBER      ; -- 처음 자른 자리수(나머지)는 몇개 인가
four_Len    NUMBER      ; -- 네자리로 자른 갯수(몫, 자리수)
isZero      VARCHAR2(1) ; -- '0' 인지 체크
str_Four    VARCHAR2(4) ; -- 네자리로 자른 값


BEGIN
    arg_Str     := TO_CHAR(arg)         ;
    arg_Length  := LENGTH(arg_Str)      ;
    cut_Four    := CEIL(arg_Length / 4) ;   -- 네자리로 자른 몫
    four_Mod    := MOD(arg_Length, 4)   ;   -- 네자리로 자른 나머지

    -- 몫으로 루프
    FOR i IN 1..cut_Four LOOP
        str_Four := '';

        IF four_Mod != 0 AND i = 1 THEN
            four_Len := four_Mod;
        ELSE
            four_Len := 4;
        END IF;

        -- 나머지값 or 4번씩 루프
        FOR j IN 1..four_Len LOOP
            IF i = 1 THEN
                str_One := SUBSTR(arg_Str, j, 1);
            ELSIF four_Mod = 0 THEN
                str_One := SUBSTR(arg_Str, ((i-2)*4) + (four_Mod+j) + 4, 1);
            ELSE
                str_One := SUBSTR(arg_Str, ((i-2)*4) + (four_Mod+j), 1);
            END IF;

            str_Four := str_Four || str_One;

            IF str_One = '0' THEN
                isZero := 'Y';

            ELSE
                isZero := 'N';

                IF str_One = '1' THEN
                    return_Val := return_Val || '일';
                ELSIF str_One = '2' THEN
                    return_Val := return_Val || '이';
                ELSIF str_One = '3' THEN
                    return_Val := return_Val || '삼';
                ELSIF str_One = '4' THEN
                    return_Val := return_Val || '사';
                ELSIF str_One = '5' THEN
                    return_Val := return_Val || '오';
                ELSIF str_One = '6' THEN
                    return_Val := return_Val || '육';
                ELSIF str_One = '7' THEN
                    return_Val := return_Val || '칠';
                ELSIF str_One = '8' THEN
                    return_Val := return_Val || '팔';
                ELSIF str_One = '9' THEN
                    return_Val := return_Val || '구';
                END IF;
            END IF;

            -- 0이면 천, 백, 십 단위 안 붙임
            IF isZero = 'N' THEN
                IF four_Len-j = 3 THEN
                    return_Val := return_Val || '천';
                ELSIF four_Len-j = 2 THEN
                    return_Val := return_Val || '백';
                ELSIF four_Len-j = 1 THEN
                    return_Val := return_Val || '십';
                END IF;
            END IF;
        END LOOP;

        -- 네자리가 0000이면 만, 억, 조, 경 안 붙임
        IF str_Four != '0000' THEN
            IF cut_Four-i = 1 THEN
                return_Val := return_Val || '만 ';
            ELSIF cut_Four-i = 2 THEN
                return_Val := return_Val || '억 ';
            ELSIF cut_Four-i = 3 THEN
                return_Val := return_Val || '조 ';
            ELSIF cut_Four-i = 4 THEN
                return_Val := return_Val || '경 ';
            END IF;
        END IF;
    END LOOP;

    RETURN trim(return_Val) || '원';

EXCEPTION WHEN OTHERS THEN
    RETURN null;
END;
/
