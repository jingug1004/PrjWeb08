CREATE FUNCTION        FNGETTEAMJANGCD(I_EMP_NO  VARCHAR2)
  RETURN VARCHAR2 IS
  V_TEAMJANG_CD    VARCHAR2(7);
  -- 사번으로 팀장,지점장,총괄팀장 사번 찾기
  --팀장,지점장,총괄팀장순으로 찾아야 함.
BEGIN

    begin
        select EMPCODE
          into V_TEAMJANG_CD
          from CMEMPM
         where DEPTCODE in (
                            select DEPTCODE 
                              from CMEMPM
                             where EMPCODE = I_EMP_NO
                          )
          and RETIREDT IS NULL
          and CLASSDIV  = '27030'  ;
          RETURN V_TEAMJANG_CD;
          
    exception when NO_DATA_FOUND then

        begin 
            select EMPCODE
              into V_TEAMJANG_CD
              from CMEMPM
             where DEPTCODE in (
                                select DEPTCODE 
                                  from CMEMPM
                                 where EMPCODE = I_EMP_NO
                              )
              and RETIREDT IS NULL
              and CLASSDIV  = '27027'  ;  
              RETURN V_TEAMJANG_CD;       

        exception when NO_DATA_FOUND then
            
                 select EMPCODE
                   into V_TEAMJANG_CD
                   from CMEMPM 
                  where DEPTCODE in (
                                    select DEPTCODE 
                                      from CMDEPTM
                                     connect by prior DEPTCODE = PREDEPTCODE
                                     start with DEPTCODE = (
                                                            select DEPTCODE 
                                                              from CMDEPTM
                                                             where level = 2
                                                             connect by prior PREDEPTCODE = DEPTCODE
                                                             start with DEPTCODE in (select DEPTCODE from CMEMPM where EMPCODE = I_EMP_NO)                                 
                                                          )  
                                  )
                  and RETIREDT IS NULL    
                  and CLASSDIV  in ('27025')       
                  ;    
                  RETURN V_TEAMJANG_CD;
        end; 
    
          
    end;                 
  
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    IF V_TEAMJANG_CD IS NULL THEN
       V_TEAMJANG_CD := '0000000';
    END IF;
    RETURN V_TEAMJANG_CD;
END;
/
