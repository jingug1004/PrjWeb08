CREATE PROCEDURE        spACbase0014P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbase0014P
	-- 작 성 자         : 홍지은
	-- 작성일자         : 2015-04-06
    -- 수정일자  		 :   노영래
	-- E-mail  		 :   0rae0926@gmail.com
	-- 수정일자  		 :   2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 자금양식설정을 관리하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_rptdiv		IN	   VARCHAR2 DEFAULT '',
	p_rptyear		IN	   VARCHAR2 DEFAULT '',
	p_seqline		IN	   VARCHAR2 DEFAULT '',
	p_fundcode		IN	   VARCHAR2 DEFAULT '',
	p_fundname		IN	   VARCHAR2 DEFAULT '',
	p_objdatadiv	IN	   VARCHAR2 DEFAULT '',
	p_calcdiv		IN	   VARCHAR2 DEFAULT '',
	p_sseqline		IN	   VARCHAR2 DEFAULT '',
	p_calcseq		IN	   NUMBER DEFAULT 0,
	p_remark		IN	   VARCHAR2 DEFAULT '',
	p_useyn 		IN	   VARCHAR2 DEFAULT '',
	p_empcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
BEGIN
	--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (UPPER(P_DIV) = 'S') THEN
		OPEN IO_CURSOR FOR
			SELECT	 seqline,																																																																		  --라인순서
					 fundcode,																																																																		  --자금코드
					 fundname,																																																																		  --자금명칭
					 objdatadiv,																																																																	  --항목구분
					 calcdiv,																																																																		  --계산수식
					 sseqline,																																																																		  --집계라인
					 calcseq,																																																																		  --계산순서
					 remark,																																																																			--비고
					 useyn																																																																			  --사용여부
			FROM	 ACFNDRPTM
			WHERE	 compcode = p_compcode
					 AND rptdiv = p_rptdiv
					 AND rptyear = p_rptyear
			ORDER BY seqline;

	ELSIF (UPPER(P_DIV) = 'SY') THEN
		OPEN IO_CURSOR FOR
			SELECT	 rptyear keyfield, rptyear displayfield
			FROM	 (SELECT DISTINCT TO_CHAR(SYSDATE, 'YYYY') rptyear
					  FROM	 CMCOMPM
					  WHERE  NOT EXISTS
								 (SELECT *
								  FROM	 ACFNDRPTM
								  WHERE  compcode = p_compcode
										 AND rptdiv = p_rptdiv)
					  UNION ALL
					  SELECT DISTINCT rptyear
					  FROM	 ACFNDRPTM
					  WHERE  compcode = p_compcode
							 AND rptdiv = p_rptdiv) a
			ORDER BY rptyear DESC;

	ELSIF (UPPER(P_DIV) = 'SC') THEN
		FOR rec IN (
        	SELECT COUNT(compcode) AS alias1
            FROM   ACFNDRPTM
            WHERE  compcode = p_compcode
                   AND rptdiv = p_rptdiv
                   AND rptyear = p_rptyear
                   AND seqline = p_seqline
        )
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;

	ELSIF (UPPER(P_DIV) = 'I') THEN
		INSERT INTO ACFNDRPTM(compcode,
							  rptdiv,
							  rptyear,
							  seqline,
							  fundcode,
							  fundname,
							  objdatadiv,
							  calcdiv,
							  sseqline,
							  calcseq,
							  remark,
							  useyn,
							  insertdt,
							  iempcode)
		VALUES		(p_compcode,
					 p_rptdiv,
					 p_rptyear,
					 p_seqline,
					 p_fundcode,
					 p_fundname,
					 p_objdatadiv,
					 p_calcdiv,
					 p_sseqline,
					 p_calcseq,
					 p_remark,
					 p_useyn,
					 SYSDATE,
					 p_empcode);

	ELSIF (UPPER(P_DIV) = 'U') THEN
		UPDATE ACFNDRPTM
		SET    fundcode = p_fundcode,
			   fundname = p_fundname,
			   objdatadiv = p_objdatadiv,
			   calcdiv = p_calcdiv,
			   sseqline = p_sseqline,
			   calcseq = p_calcseq,
			   remark = p_remark,
			   useyn = p_useyn,
			   updatedt = SYSDATE,
			   uempcode = p_empcode
		WHERE  compcode = p_compcode
			   AND rptdiv = p_rptdiv
			   AND rptyear = p_rptyear
			   AND seqline = p_seqline;

	ELSIF (UPPER(P_DIV) = 'D') THEN
		DELETE ACFNDRPTM
		WHERE  compcode = p_compcode
			   AND rptdiv = p_rptdiv
			   AND rptyear = p_rptyear
			   AND seqline = p_seqline;

	ELSIF (UPPER(P_DIV) = 'CP') THEN
		DELETE ACFNDRPTM
		WHERE  compcode = p_compcode
			   AND rptdiv = p_rptdiv
			   AND rptyear = p_seqline;

		INSERT INTO ACFNDRPTM
			SELECT	 compcode,
					 rptdiv,
					 p_seqline,
					 seqline,
					 fundcode,
					 fundname,
					 objdatadiv,
					 calcdiv,
					 sseqline,
					 calcseq,
					 remark,
					 useyn,
					 SYSDATE,
					 p_empcode,
					 NULL,
					 NULL
			FROM	 ACFNDRPTM
			WHERE	 compcode = p_compcode
					 AND rptdiv = p_rptdiv
					 AND rptyear = p_rptyear
			ORDER BY seqline;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
