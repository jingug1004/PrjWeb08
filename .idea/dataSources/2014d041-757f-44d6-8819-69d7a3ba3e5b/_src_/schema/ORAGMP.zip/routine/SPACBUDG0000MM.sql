CREATE PROCEDURE        spacbudg0000mm(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbudg0000MM
	-- 작 성 자         : 최용석
	-- 작성일자         : 2010-12-14
	-- 수정일자       :   노영래
	-- E-mail       :   0rae0926@gmail.com
	-- 수정일자       :   2016-12-13
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 결의전표 상신처리에 따른 집계처리하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT ''
   ,p_compcode		IN	   VARCHAR2 DEFAULT ''
   ,p_slipinno		IN	   VARCHAR2 DEFAULT ''
   ,p_strbudgym 	IN	   VARCHAR2 DEFAULT ''
   ,p_endbudgym 	IN	   VARCHAR2 DEFAULT ''
   ,p_userid		IN	   VARCHAR2 DEFAULT ''
   ,p_reasondiv 	IN	   VARCHAR2 DEFAULT ''
   ,p_reasontext	IN	   VARCHAR2 DEFAULT ''
   ,IO_CURSOR		   OUT TYPES.DATASET
   ,MESSAGE 		   OUT VARCHAR2
)
AS
	p_bdgcalc	 VARCHAR2(5);
	p_budgemp	 VARCHAR2(5);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(userid, reasondiv, reasontext)
		 VALUES (p_userid, p_reasondiv, p_reasontext);


	p_bdgcalc := '2';

	FOR rec IN (SELECT value1
				  FROM SYSPARAMETERMANAGE
				 WHERE parametercode = 'accslipbdgcalc')
	LOOP
		p_bdgcalc := rec.value1;
	END LOOP;

	p_budgemp := 'N';

	FOR rec IN (SELECT value1
				  FROM SYSPARAMETERMANAGE
				 WHERE parametercode = 'acempbudguse')
	LOOP
		p_budgemp := rec.value1;
	END LOOP;

	IF (p_div IN ('AD', 'MI'))
	THEN
		-- 결의전표상신/반려
		-- 부서예산 집계
		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACBUDG0000MM_ACBUDGMM1 ';

		INSERT INTO VGT.TT_ACBUDG0000MM_ACBUDGMM1
			(SELECT a.*
			   FROM (  SELECT a.compcode
							 ,SUBSTR(a.slipindate, 0, 7) budgym
							 ,CASE
								  WHEN g.grp =
										   CASE WHEN NULLIF(CASE WHEN e.deptcode IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval) IS NOT NULL THEN 2 ELSE 1 END
									   AND h.grp = CASE WHEN NULLIF(d.budgcode, b.acccode) IS NOT NULL THEN 2 ELSE 1 END
								  THEN
									  1
								  ELSE
									  2
							  END
								  realdiv
							 ,CASE WHEN g.grp = 1 THEN c.mngcluval ELSE CASE WHEN e.deptcode IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END END deptcode
							 ,CASE WHEN h.grp = 1 THEN b.acccode ELSE d.budgcode END acccode
							 ,SUM(CASE WHEN d.dcdiv = '1' THEN b.debamt ELSE b.creamt END) * CASE WHEN p_div = 'AD' THEN 1 ELSE -1 END restotamt
						 FROM ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
							  JOIN ACORDS c
								  ON b.compcode = c.compcode
									 AND b.slipinno = c.slipinno
									 AND b.slipinseq = c.slipinseq
									 AND c.mngclucode = 'S040'
									 AND c.mngcluval IS NOT NULL
							  JOIN ACACCM d
								  ON b.acccode = d.acccode
									 AND (b.dcdiv IN ('1', '4')
										  AND d.dcdiv = '1'
										  OR b.dcdiv IN ('2', '3')
											 AND d.dcdiv = '2')
							  LEFT JOIN ACBDGDPT e
								  ON a.compcode = e.compcode
									 AND SUBSTR(a.slipindate, 0, 4) || '-01' = e.budgym
									 AND c.mngcluval = e.deptcode
							  LEFT JOIN CMDEPTM f ON c.mngcluval = f.deptcode
							  LEFT JOIN (SELECT 1 grp FROM DUAL
										 UNION
										 SELECT 2 FROM DUAL) g
								  ON g.grp = 1
									 OR NULLIF(CASE WHEN e.deptcode IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval) IS NOT NULL
							  LEFT JOIN (SELECT 1 grp FROM DUAL
										 UNION
										 SELECT 2 FROM DUAL) h
								  ON h.grp = 1
									 OR NULLIF(d.budgcode, b.acccode) IS NOT NULL
						WHERE a.compcode = p_compcode
							  AND a.slipinno = p_slipinno
							  AND a.slipdiv <> 'F'
							  AND (p_bdgcalc = '1'
								   OR a.slipinstate NOT IN ('1', '6'))
					 GROUP BY a.compcode
							 ,SUBSTR(a.slipindate, 0, 7)
							 ,CASE
								  WHEN g.grp =
										   CASE WHEN NULLIF(CASE WHEN e.deptcode IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval) IS NOT NULL THEN 2 ELSE 1 END
									   AND h.grp = CASE WHEN NULLIF(d.budgcode, b.acccode) IS NOT NULL THEN 2 ELSE 1 END
								  THEN
									  1
								  ELSE
									  2
							  END
							 ,CASE WHEN g.grp = 1 THEN c.mngcluval ELSE CASE WHEN e.deptcode IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END END
							 ,CASE WHEN h.grp = 1 THEN b.acccode ELSE d.budgcode END) a
					JOIN ACACCM b
						ON a.acccode = b.acccode
						   AND (b.budglimityn = 'Y'
								OR b.budgmngyn = 'Y'));

		MERGE INTO ACBUDGMM b
			 USING (SELECT b.compcode
						  ,b.budgym
						  ,b.deptcode
						  ,b.acccode
						  ,b.restotamt + CASE WHEN realdiv = 1 THEN a.restotamt ELSE 0 END AS pos_2
						  ,b.inttotamt + CASE WHEN realdiv = 2 THEN a.restotamt ELSE 0 END AS pos_3
					  FROM VGT.TT_ACBUDG0000MM_ACBUDGMM1 a
						   JOIN ACBUDGMM b
							   ON a.compcode = b.compcode
								  AND a.budgym = b.budgym
								  AND a.deptcode = b.deptcode
								  AND a.acccode = b.acccode) src
				ON (b.compcode = src.compcode
					AND b.budgym = src.budgym
					AND b.deptcode = src.deptcode
					AND b.acccode = src.acccode)
		WHEN MATCHED
		THEN
			UPDATE SET b.restotamt = pos_2, b.inttotamt = pos_3;

		INSERT INTO ACBUDGMM
			(SELECT a.compcode
				   ,a.budgym
				   ,a.deptcode
				   ,a.acccode
				   ,0
				   ,CASE WHEN realdiv = 1 THEN a.restotamt ELSE 0 END col
				   ,CASE WHEN realdiv = 2 THEN a.restotamt ELSE 0 END col
				   ,''
				   ,''
				   ,SYSDATE
				   ,p_userid
				   ,NULL
				   ,NULL
			   FROM vgt.tt_acbudg0000mm_acbudgmm1 a
					LEFT JOIN ACBUDGMM b
						ON a.compcode = b.compcode
						   AND a.budgym = b.budgym
						   AND a.deptcode = b.deptcode
						   AND a.acccode = b.acccode
			  WHERE b.compcode IS NULL);


		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACBUDG0000MM_ACBUDGYYE1 ';

		-- 사원예산 집계
		INSERT INTO VGT.TT_ACBUDG0000MM_ACBUDGYYE1
			(SELECT a.*
			   FROM (  SELECT a.compcode
							 ,SUBSTR(a.slipindate, 0, 7) budgym
							 ,c.mngcluval empcode
							 ,NVL(d.ebdgcode, d.acccode) acccode
							 ,SUM(CASE WHEN d.dcdiv = '1' THEN b.debamt ELSE b.creamt END) * CASE WHEN p_div = 'AD' THEN 1 ELSE -1 END slipamt
						 FROM ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
							  JOIN ACORDS c
								  ON b.compcode = c.compcode
									 AND b.slipinno = c.slipinno
									 AND b.slipinseq = c.slipinseq
									 AND c.mngclucode = 'S050'
							  JOIN ACACCM d
								  ON b.acccode = d.acccode
									 AND (b.dcdiv IN ('1', '4')
										  AND d.dcdiv = '1'
										  OR b.dcdiv IN ('2', '3')
											 AND d.dcdiv = '2')
						WHERE a.compcode = p_compcode
							  AND a.slipinno = p_slipinno
							  AND a.slipdiv <> 'F'
							  AND (p_bdgcalc = '1'
								   OR a.slipinstate NOT IN ('1', '6'))
							  AND p_budgemp = 'Y'
					 GROUP BY a.compcode
							 ,SUBSTR(a.slipindate, 0, 7)
							 ,c.mngcluval
							 ,NVL(d.ebdgcode, d.acccode)) a
					JOIN ACACCM b
						ON a.acccode = b.acccode
						   AND (b.budglimityn = 'Y'
								OR b.budgmngyn = 'Y'));

		MERGE INTO ACBUDGYYE b
			 USING (SELECT b.compcode
						  ,b.budgym
						  ,b.empcode
						  ,b.acccode
						  ,b.slipamt + a.slipamt AS slipamt
					  FROM VGT.TT_ACBUDG0000MM_ACBUDGYYE1 a
						   JOIN ACBUDGYYE b
							   ON a.compcode = b.compcode
								  AND a.budgym = b.budgym
								  AND a.empcode = b.empcode
								  AND a.acccode = b.acccode) src
				ON (b.compcode = src.compcode
					AND b.budgym = src.budgym
					AND b.empcode = src.empcode
					AND b.acccode = src.acccode)
		WHEN MATCHED
		THEN
			UPDATE SET b.slipamt = src.slipamt;
	ELSIF (p_div = 'TO')
	THEN
		-- 예산내역재집계
		-- 부서예산 집계
		-- 예산 월 테이블 실적 0로 조정
		UPDATE acbudgmm
		   SET restotamt = 0, inttotamt = 0
		 WHERE compcode = p_compcode
			   AND budgym BETWEEN p_strbudgym AND p_endbudgym;

		DELETE FROM VGT.TT_ACBUDG0000MM_ACBUDGMM2;

		INSERT INTO VGT.TT_ACBUDG0000MM_ACBUDGMM2
			(SELECT a.*
			   FROM (  SELECT a.compcode
							 ,SUBSTR(a.slipindate, 0, 7) budgym
							 ,CASE
								  WHEN g.grp =
										   CASE WHEN NULLIF(CASE WHEN e.deptcode IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval) IS NOT NULL THEN 2 ELSE 1 END
									   AND h.grp = CASE WHEN NULLIF(d.budgcode, b.acccode) IS NOT NULL THEN 2 ELSE 1 END
								  THEN
									  1
								  ELSE
									  2
							  END
								  realdiv
							 ,CASE WHEN g.grp = 1 THEN c.mngcluval ELSE CASE WHEN e.deptcode IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END END deptcode
							 ,CASE WHEN h.grp = 1 THEN b.acccode ELSE d.budgcode END acccode
							 ,SUM(CASE WHEN d.dcdiv = '1' THEN b.debamt ELSE b.creamt END) restotamt
						 FROM ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
							  JOIN ACORDS c
								  ON b.compcode = c.compcode
									 AND b.slipinno = c.slipinno
									 AND b.slipinseq = c.slipinseq
									 AND c.mngclucode = 'S040'
									 AND c.mngcluval IS NOT NULL
							  JOIN ACACCM d
								  ON b.acccode = d.acccode
									 AND (b.dcdiv IN ('1', '4')
										  AND d.dcdiv = '1'
										  OR b.dcdiv IN ('2', '3')
											 AND d.dcdiv = '2')
							  LEFT JOIN ACBDGDPT e
								  ON a.compcode = e.compcode
									 AND SUBSTR(a.slipindate, 0, 4) || '-01' = e.budgym
									 AND c.mngcluval = e.deptcode
							  LEFT JOIN CMDEPTM f ON c.mngcluval = f.deptcode
							  LEFT JOIN (SELECT 1 grp FROM DUAL
										 UNION
										 SELECT 2 FROM DUAL) g
								  ON g.grp = 1
									 OR NULLIF(CASE WHEN e.deptcode IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval) IS NOT NULL
							  LEFT JOIN (SELECT 1 grp FROM DUAL
										 UNION
										 SELECT 2 FROM DUAL) h
								  ON h.grp = 1
									 OR NULLIF(d.budgcode, b.acccode) IS NOT NULL
						WHERE a.compcode = p_compcode
							  AND a.slipinno BETWEEN REPLACE(p_strbudgym, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_endbudgym || '-01', 'YYYY-MM-DD'), 1), 'YYYYMM')
							  AND a.slipdiv <> 'F'
							  AND (p_bdgcalc = '1'
								   OR a.slipinstate NOT IN ('1', '6'))
					 GROUP BY a.compcode
							 ,SUBSTR(a.slipindate, 0, 7)
							 ,CASE
								  WHEN g.grp =
										   CASE WHEN NULLIF(CASE WHEN e.deptcode IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval) IS NOT NULL THEN 2 ELSE 1 END
									   AND h.grp = CASE WHEN NULLIF(d.budgcode, b.acccode) IS NOT NULL THEN 2 ELSE 1 END
								  THEN
									  1
								  ELSE
									  2
							  END
							 ,CASE WHEN g.grp = 1 THEN c.mngcluval ELSE CASE WHEN e.deptcode IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END END
							 ,CASE WHEN h.grp = 1 THEN b.acccode ELSE d.budgcode END) a
					JOIN ACACCM b
						ON a.acccode = b.acccode
						   AND (b.budglimityn = 'Y'
								OR b.budgmngyn = 'Y'));

		MERGE INTO ACBUDGMM b
			 USING (SELECT b.compcode
						  ,b.budgym
						  ,b.deptcode
						  ,b.acccode
						  ,b.restotamt + CASE WHEN realdiv = 1 THEN a.restotamt ELSE 0 END AS pos_2
						  ,b.inttotamt + CASE WHEN realdiv = 2 THEN a.restotamt ELSE 0 END AS pos_3
					  FROM VGT.TT_ACBUDG0000MM_ACBUDGMM2 a
						   JOIN ACBUDGMM b
							   ON a.compcode = b.compcode
								  AND a.budgym = b.budgym
								  AND a.deptcode = b.deptcode
								  AND a.acccode = b.acccode) src
				ON (b.compcode = src.compcode
					AND b.budgym = src.budgym
					AND b.deptcode = src.deptcode
					AND b.acccode = src.acccode)
		WHEN MATCHED
		THEN
			UPDATE SET b.restotamt = pos_2, b.inttotamt = pos_3;

		INSERT INTO ACBUDGMM
			(SELECT a.compcode
				   ,a.budgym
				   ,a.deptcode
				   ,a.acccode
				   ,0
				   ,CASE WHEN realdiv = 1 THEN a.restotamt ELSE 0 END col
				   ,CASE WHEN realdiv = 2 THEN a.restotamt ELSE 0 END col
				   ,''
				   ,''
				   ,SYSDATE
				   ,p_userid
				   ,NULL
				   ,NULL
			   FROM VGT.TT_ACBUDG0000MM_ACBUDGMM2 a
					LEFT JOIN ACBUDGMM b
						ON a.compcode = b.compcode
						   AND a.budgym = b.budgym
						   AND a.deptcode = b.deptcode
						   AND a.acccode = b.acccode
			  WHERE b.compcode IS NULL);



		-- 사원예산 집계
		-- 예산 월 테이블 실적 0로 조정
		UPDATE acbudgyye
		   SET slipamt = 0
		 WHERE compcode = p_compcode
			   AND budgym BETWEEN p_strbudgym AND p_endbudgym;

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACBUDG0000MM_ACBUDGYYE2 ';

		INSERT INTO VGT.TT_ACBUDG0000MM_ACBUDGYYE2
			(SELECT a.*
			   FROM (  SELECT a.compcode
							 ,SUBSTR(a.slipindate, 0, 7) budgym
							 ,c.mngcluval empcode
							 ,NVL(d.ebdgcode, d.acccode) acccode
							 ,SUM(CASE WHEN d.dcdiv = '1' THEN b.debamt ELSE b.creamt END) slipamt
						 FROM ACORDM a
							  JOIN ACORDD b
								  ON a.compcode = b.compcode
									 AND a.slipinno = b.slipinno
							  JOIN ACORDS c
								  ON b.compcode = c.compcode
									 AND b.slipinno = c.slipinno
									 AND b.slipinseq = c.slipinseq
									 AND c.mngclucode = 'S050'
							  JOIN ACACCM d
								  ON b.acccode = d.acccode
									 AND (b.dcdiv IN ('1', '4')
										  AND d.dcdiv = '1'
										  OR b.dcdiv IN ('2', '3')
											 AND d.dcdiv = '2')
						WHERE a.compcode = p_compcode
							  AND a.slipinno BETWEEN REPLACE(p_strbudgym, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_endbudgym || '-01', 'YYYY-MM-DD'), 1), 'YYYYMM')
							  AND a.slipdiv <> 'F'
							  AND (p_bdgcalc = '1'
								   OR a.slipinstate NOT IN ('1', '6'))
							  AND p_budgemp = 'Y'
					 GROUP BY a.compcode
							 ,SUBSTR(a.slipindate, 0, 7)
							 ,c.mngcluval
							 ,NVL(d.ebdgcode, d.acccode)) a
					JOIN ACACCM b
						ON a.acccode = b.acccode
						   AND (b.budglimityn = 'Y'
								OR b.budgmngyn = 'Y'));

		MERGE INTO ACBUDGYYE b
			 USING (SELECT b.compcode
						  ,b.budgym
						  ,b.empcode
						  ,b.acccode
						  ,b.slipamt + a.slipamt AS slipamt
					  FROM VGT.TT_ACBUDG0000MM_ACBUDGYYE2 a
						   JOIN ACBUDGYYE b
							   ON a.compcode = b.compcode
								  AND a.budgym = b.budgym
								  AND a.empcode = b.empcode
								  AND a.acccode = b.acccode) src
				ON (b.compcode = src.compcode
					AND b.budgym = src.budgym
					AND b.empcode = src.empcode
					AND b.acccode = src.acccode)
		WHEN MATCHED
		THEN
			UPDATE SET b.slipamt = src.slipamt;
	END IF;

	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT code FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
