CREATE FUNCTION        fnGetBusinessno
-- -------------------------------------------------------------------------------
 -- 함 수 명          : fnGetBusinessno
 -- 작 성 자         : 김만수
 -- 작성일자         : 2017-12-29
 -- -------------------------------------------------------------------------------
 -- 함수설명         : 사업장마스터의 이력을 찾아 주문시점의 사업자번호를 검색
 -- -------------------------------------------------------------------------------
(
    p_mplantcode  IN VARCHAR2 DEFAULT '' ,
    p_orderdate   IN VARCHAR2 DEFAULT '' 
)
RETURN VARCHAR2
AS
    p_tostring VARCHAR2(20) :='';
BEGIN
   
    SELECT  REPLACE(BUSINESSNO, '-', '')
      INTO  p_tostring
      FROM  ORAGMP.ATCMPLANTM
     WHERE  PLANTCODE = p_mplantcode
       AND  AUDITDT = (
                        SELECT MAX(AUDITDT) 
                          FROM  ORAGMP.ATCMPLANTM 
                         WHERE PLANTCODE = p_mplantcode 
                           AND TO_CHAR(AUDITDT, 'YYYY-MM-DD') <= CASE WHEN p_orderdate < '2018-01-03' THEN '2018-01-03' ELSE p_orderdate END
                           AND AUDITDIV <> 'D');
   
   RETURN (p_tostring);

EXCEPTION WHEN OTHERS THEN RETURN (p_tostring);
END;
/
