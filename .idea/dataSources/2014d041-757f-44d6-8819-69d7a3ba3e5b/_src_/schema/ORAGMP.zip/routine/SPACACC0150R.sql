CREATE PROCEDURE spACacc0150R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0150R
 -- 작 성 자         : 배종성
 -- 작성일자         : 2010-12-08
 -- 작 성 자         : 임정호
 -- 작성일자         : 2016-12-21
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 관리항목원장을 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '' ,
    p_acccode       IN VARCHAR2 DEFAULT '' ,
    p_dcdiv         IN VARCHAR2 DEFAULT '' ,
    p_startdt       IN VARCHAR2 DEFAULT '' ,
    p_enddt         IN VARCHAR2 DEFAULT '' ,
    p_mngclucode    IN VARCHAR2 DEFAULT '' ,
    p_mngcluval1    IN VARCHAR2 DEFAULT '' ,
    p_mngcluval2    IN VARCHAR2 DEFAULT '' ,
    p_outputdiv     IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,
    IO_CURSOR       OUT TYPES.DataSet,
    MESSAGE         OUT VARCHAR2
)
AS

    p_colview       VARCHAR2(1);
    p_mngcluval     VARCHAR2(50);
    p_mngcludec     VARCHAR2(50);
    p_slipdate      VARCHAR2(13);
    p_slipnum       VARCHAR2(5);
    p_slipinseq     NUMBER;
    p_remark        VARCHAR2(100);
    p_debamt        FLOAT;
    p_creamt        FLOAT;
    p_fnamt         FLOAT;
    p_rows          NUMBER;
    p_odiv1         VARCHAR2(5);
    p_odiv2         VARCHAR2(5);
    ip_mngclucode   VARCHAR2(100);

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    FOR rec IN (
        SELECT  value1
        FROM    SYSPARAMETERMANAGE
        WHERE   UPPER(parametercode) = UPPER('accldgcolview')
    )
    LOOP
        p_colview := rec.value1 ;
    END LOOP ;


    IF (p_outputdiv = '1') THEN --K-GAAP

        p_odiv1 := '20';
        p_odiv2 := 'F';

    ELSIF (p_outputdiv = '2') THEN --IFRS

         p_odiv1 := '30';
         p_odiv2 := 'K';

    END IF;



    IF ( p_div = 'S' ) THEN

        -- @fnamt 나중에 이월의 잔액을 넣어줘야함.
        IF NVL(TRIM(p_fnamt), '') IS NULL THEN
            p_fnamt := 0 ;
        END IF;



        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0150R_DUAL';

        FOR rec IN (
            SELECT  mngclucode,
                    mngcluval,
                    mngcludec,
                    slipdate,
                    slipnum,
                    slipinseq,
                    remark,
                    debamt,
                    creamt
            FROM    (   SELECT  NVL(mngclucode, '') mngclucode,
                                NULL mngcluval,
                                NULL mngcludec,
                                '1000-00-00' slipdate,  -- 전표일자
                                NULL slipnum,           -- 전표번호
                                0 slipinseq,
                                NULL remark,            --적요
                                SUM(debamt) debamt,
                                SUM(creamt) creamt
                        FROM    (   SELECT  NULL mngclucode,
                                            NULL mngcluval,
                                            NULL mngcludec,
                                            '이월' slipdate,
                                            NULL slipnum,
                                            0 slipinseq,
                                            NULL remark,
                                            NVL(bsdebamt, 0) debamt,
                                            NVL(bscreamt, 0) creamt
                                    FROM    ACORDDMM
                                    WHERE   compcode = p_compcode
                                            AND plantcode LIKE p_plantcode
                                            AND slipym = SUBSTR(p_startdt, 0, 7)
                                            AND ( closediv = '10' OR closediv = p_odiv1 )
                                            AND acccode = p_acccode

                                    UNION ALL

                                    SELECT  NULL mngclucode,
                                            NULL mngcluval,
                                            NULL mngcludec,
                                            A.slipdate,
                                            A.slipnum,
                                            A.slipinseq,
                                            A.remark1 remark,
                                            NVL(A.debamt, 0) debamt,
                                            NVL(A.creamt, 0) creamt
                                    FROM    ACORDD A
                                            , ACORDM c
                                    WHERE   A.compcode = p_compcode
                                            AND A.plantcode LIKE p_plantcode
                                            AND A.acccode = p_acccode
                                            AND NVL(A.slipdate, ' ') < p_startdt
                                            AND NVL(A.slipdate, ' ') >= SUBSTR (p_startdt, 1, 7) || '-01'
                                            AND A.compcode = c.compcode
                                            AND A.plantcode = c.plantcode
                                            AND A.slipinno = c.slipinno
                                            AND c.slipdiv <> p_odiv2
                                            AND c.slipinstate = '4' ) A
                                    GROUP BY mngclucode

                                    UNION ALL

                                    SELECT  b.mngclucode,
                                            b.mngcluval,
                                            b.mngcludec,
                                            A.slipdate,
                                            A.slipnum,
                                            A.slipinseq,
                                            A.remark1  remark,
                                            NVL(A.debamt, 0) debamt,
                                            NVL(A.creamt, 0) creamt
                                    FROM    ACORDD A
                                            , ACORDS b
                                            , ACORDM c
                                    WHERE   A.compcode = p_compcode
                                            AND A.plantcode LIKE p_plantcode
                                            AND A.slipdate BETWEEN p_startdt AND p_enddt
                                            AND A.acccode = p_acccode
                                            AND A.compcode = b.compcode
                                            AND A.slipinno = b.slipinno
                                            AND A.slipinseq = b.slipinseq
                                            AND A.compcode = c.compcode
                                            AND A.plantcode = c.plantcode
                                            AND A.slipinno = c.slipinno
                                            AND b.mngclucode = p_mngclucode
                                            AND c.slipdiv <> p_odiv2
                                            AND c.slipinstate = '4'

                                    UNION ALL

                                    -- 월계
                                    SELECT  mngclucode mngclucode,  -- 관리항목코드
                                            NULL mngcluval,
                                            NULL mngcludec,         -- 관리항목명
                                            slipdate slipdate,      -- 전표일자
                                            NULL slipnum,           -- 전표번호
                                            0 slipinseq,
                                            NULL remark,            -- 적요
                                            SUM (A.debamt) debamt,  -- 차변금액
                                            SUM (A.creamt) creamt   --대변금액
                                    FROM    (   SELECT  b.mngclucode,           --관리항코드
                                                        NULL mngcluval,
                                                        NULL mngcludec,         --관리항목켱
                                                        SUBSTR (A.slipdate, 0, 7) || '-90-99' slipdate, --전표일자
                                                        NULL slipnum,--전표일자
                                                        0 slipinseq,
                                                        NULL remark,    --적요
                                                        debamt, --차변금액
                                                        creamt  --대변금액
                                                FROM    ACORDD A
                                                        LEFT JOIN ACORDS b ON A.compcode = b.compcode
                                                                              AND A.slipinno = b.slipinno
                                                                              AND A.slipinseq = b.slipinseq
                                                                              AND b.mngclucode = p_mngclucode
                                                        JOIN ACORDM c ON A.compcode = c.compcode
                                                                         AND A.plantcode = c.plantcode
                                                                         AND A.slipinno = c.slipinno
                                                WHERE   A.compcode = p_compcode
                                                        AND A.plantcode LIKE p_plantcode
                                                        AND A.acccode = p_acccode
                                                        AND A.slipdate BETWEEN p_startdt AND p_enddt
                                                        AND c.slipinstate = '4' ) A
                        GROUP BY A.mngclucode, slipdate ) A
            ORDER BY slipdate, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9'),slipnum, slipinseq
        )
        LOOP

            ip_mngclucode := rec.mngclucode;
            p_mngcluval   := rec.mngcluval;
            p_mngcludec   := rec.mngcludec;
            p_slipdate    := rec.slipdate;
            p_slipnum     := rec.slipnum;
            p_slipinseq   := rec.slipinseq;
            p_remark      := rec.remark;
            p_debamt      := rec.debamt;
            p_creamt      := rec.creamt;



            IF ( SUBSTR(p_slipdate, -2, 2) <> '99' ) THEN

                IF ( p_dcdiv = '1' ) THEN

                    p_fnamt := NVL(p_fnamt, 0) + NVL(p_debamt, 0) - NVL(p_creamt, 0) ;

                ELSIF ( p_dcdiv = '2' ) THEN

                    p_fnamt := NVL(p_fnamt, 0) + NVL(p_creamt, 0) - NVL(p_debamt, 0) ;

                END IF;

            END IF;



            INSERT INTO VGT.TT_ACACC0150R_DUAL
            VALUES (    ip_mngclucode,  p_mngcluval,    p_mngcludec,    p_slipdate, p_slipnum,
                        p_slipinseq,    p_remark,       p_debamt,       p_creamt,   p_fnamt );



            IF ( SUBSTR(p_slipdate, -5) = '90-99' ) THEN

                IF ( p_dcdiv = '1' ) THEN

                    INSERT INTO VGT.TT_ACACC0150R_DUAL
                        SELECT
                                ip_mngclucode ,
                                NULL ,
                                NULL ,
                                SUBSTR(p_slipdate, 0, 7) || '-99-99' ,
                                NULL slipnum  ,
                                0 slipinseq  ,
                                NULL remark  ,
                                SUM(debamt)  debamt  ,
                                SUM(creamt)  creamt  ,
                                SUM(debamt) - SUM(creamt)  fnamt
                        FROM    VGT.TT_ACACC0150R_DUAL
                        WHERE   NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                                AND slipdate BETWEEN '1000-00-00' AND p_slipdate ;


                ELSIF ( p_dcdiv = '2' ) THEN

                    INSERT INTO VGT.TT_ACACC0150R_DUAL
                        SELECT  ip_mngclucode ,
                                NULL ,
                                NULL ,
                                SUBSTR(p_slipdate, 0, 7) || '-99-99' ,
                                NULL ,
                                0 ,
                                NULL,
                                SUM(debamt)  debamt  ,
                                SUM(creamt)  creamt  ,
                                SUM(creamt) - SUM(debamt)  fnamt
                        FROM    VGT.TT_ACACC0150R_DUAL
                        WHERE   NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                                AND slipdate BETWEEN '1000-00-00' AND p_slipdate ;

                END IF;

            END IF;

        END LOOP;







        IF ( SUBSTR(p_slipdate, -2) != '99' ) THEN

            IF ( p_dcdiv = '1' ) THEN

                INSERT INTO VGT.TT_ACACC0150R_DUAL (
                    SELECT  ip_mngclucode ,
                            NULL ,
                            NULL ,
                            SUBSTR(p_slipdate, 0, 7) || '-99-99' ,
                            NULL slipnum  ,
                            0 slipinseq  ,
                            NULL remark  ,
                            SUM(debamt)  debamt  ,
                            SUM(creamt)  creamt  ,
                            SUM(debamt)  - SUM(creamt)  fnamt
                    FROM    VGT.TT_ACACC0150R_DUAL
                    WHERE   NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                            AND slipdate BETWEEN '1000-00-00' AND p_slipdate
                );

            ELSIF ( p_dcdiv = '2' ) THEN

                INSERT INTO VGT.TT_ACACC0150R_DUAL (
                    SELECT  ip_mngclucode ,
                            NULL ,
                            NULL ,
                            SUBSTR(p_slipdate, 0, 7) || '-99-99' ,
                            NULL ,
                            0,
                            NULL ,
                            SUM(debamt)  debamt  ,
                            SUM(creamt)  creamt  ,
                            SUM(creamt)  - SUM(debamt)  fnamt
                    FROM    VGT.TT_ACACC0150R_DUAL
                    WHERE   NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                            AND slipdate BETWEEN '1000-00-00' AND p_slipdate
                );

            END IF;

        END IF;






        FOR  rec IN (
            SELECT  COUNT(*)   AS alias1
            FROM    VGT.TT_ACACC0150R_DUAL
        )
        LOOP
            p_rows := rec.alias1   ;
        END LOOP;



        IF ( p_rows = 1 ) THEN

            IF ( p_dcdiv = '1' ) THEN

                INSERT INTO VGT.TT_ACACC0150R_DUAL (
                    SELECT  MAX(mngclucode)  mngclucode  ,
                            NULL mngcluval  ,
                            NULL mngcludec  ,
                            '1000-00-01' slipdate  ,
                            NULL slipnum  ,
                            0 slipinseq  ,
                            NULL remark  ,
                            SUM(debamt)  ,
                            SUM(creamt)  ,
                            SUM(debamt) - SUM(creamt)  fnamt
                    FROM VGT.TT_ACACC0150R_DUAL
                );

            ELSIF ( p_dcdiv = '2' ) THEN

                INSERT INTO VGT.TT_ACACC0150R_DUAL (
                    SELECT  MAX(mngclucode)  mngclucode  ,
                            NULL mngcluval  ,
                            NULL mngcludec  ,
                            '1000-00-01' slipdate  ,
                            NULL slipnum  ,
                            0 slipinseq  ,
                            NULL remark  ,
                            SUM(debamt)  ,
                            SUM(creamt)  ,
                            SUM(creamt) - SUM(debamt)  fnamt
                    FROM    VGT.TT_ACACC0150R_DUAL
                );

            END IF;



            OPEN  IO_CURSOR FOR

                SELECT  mngclucode mngclucode  ,
                        mngcluval  mngcluval  ,
                        mngcludec  mngcludec  ,
                        (CASE WHEN NVL(SUBSTR(slipdate, -5), ' ') = '90-99' THEN '이월'
                              WHEN NVL(SUBSTR(slipdate, -5), ' ') = '99-99' THEN '누계'
                              ELSE slipdate
                        END) slipdate  ,
                        slipdate slipdate2  ,
                        slipnum slipnum  ,
                        slipinseq  slipinseq  ,
                        remark  ,
                        debamt debamt  ,
                        creamt creamt  ,
                        (CASE WHEN NVL(SUBSTR(slipdate, -5), ' ') = '90-99' THEN 0
                              ELSE NVL(fnamt, 0)
                        END) fnamt
                FROM    VGT.TT_ACACC0150R_DUAL A
                ORDER BY slipdate2, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9'),slipnum , slipinseq ;

        ELSE  --IF ( p_rows = 1 ) THEN

            OPEN  IO_CURSOR FOR

                SELECT  mngclucode,
                        mngcluval,
                        mngcludec,
                        (CASE WHEN NVL(SUBSTR(slipdate, -5, 5), ' ') = '00-00' THEN '이월'
                              WHEN NVL(SUBSTR(slipdate, -5, 5), ' ') = '90-99' THEN '월계'
                              WHEN NVL(SUBSTR(slipdate, -5, 5), ' ') = '99-99' THEN '누계'
                              ELSE slipdate
                        END) slipdate  ,
                        slipdate slipdate2  ,
                        slipnum slipnum  ,
                        slipinseq ,
                        remark  ,
                        NVL(debamt, 0) debamt  ,
                        NVL(creamt, 0) creamt  ,
                        (CASE WHEN NVL(SUBSTR(slipdate, -5, 5), ' ') = '90-99' THEN 0
                              ELSE NVL(fnamt, 0)
                        END) fnamt
                FROM    VGT.TT_ACACC0150R_DUAL A
                ORDER BY slipdate2, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9'),slipnum, slipinseq ;

        END IF;



    ELSIF ( p_div = 'S1' ) THEN

        -- @fnamt 나중에 이월의 잔액을 넣어줘야함.
        IF NVL(TRIM(p_fnamt), '') IS NULL THEN
            p_fnamt := 0 ;
        END IF;



        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0150R_DUAL';

        FOR rec IN (
            SELECT  mngclucode,
                    mngcluval,
                    mngcludec,
                    slipdate,
                    slipnum,
                    slipinseq,
                    remark,
                    debamt,
                    creamt
            FROM    (   SELECT  NVL(mngclucode, '') mngclucode,
                                NULL mngcluval,
                                NULL mngcludec,
                                '1000-00-00' slipdate,
                                NULL slipnum,
                                0 slipinseq,
                                NULL remark,
                                SUM(debamt) debamt,
                                SUM(creamt) creamt
                        FROM    (   SELECT  NULL mngclucode,
                                            NULL mngcluval,
                                            NULL mngcludec,
                                            '이월' slipdate,
                                            NULL slipnum,
                                            0 slipinseq,
                                            NULL remark,
                                            NVL(bsdebamt, 0) debamt,
                                            NVL(bscreamt, 0) creamt
                                    FROM    ACORDDMM
                                    WHERE   compcode = p_compcode
                                            AND plantcode LIKE p_plantcode
                                            AND slipym = SUBSTR(p_startdt, 0, 7)
                                            AND (closediv = '10' OR closediv = p_odiv1)
                                            AND acccode = p_acccode

                                    UNION ALL

                                    SELECT  NULL mngclucode,
                                            NULL mngcluval,
                                            NULL mngcludec,
                                            NVL(A.slipdate, '') slipdate,
                                            NVL(A.slipnum, '') slipnum,
                                            NVL(A.slipinseq, 0) slipinseq,
                                            NVL(A.remark1, '') remark,
                                            NVL(A.debamt, 0) debamt,
                                            NVL(A.creamt, 0) creamt
                                    FROM    ACORDD A
                                            , ACORDM c
                                    WHERE   A.compcode = p_compcode
                                            AND A.plantcode LIKE p_plantcode
                                            AND A.acccode = p_acccode
                                            AND NVL(A.slipdate, ' ') < p_startdt
                                            AND NVL(A.slipdate, ' ') >= SUBSTR (p_startdt, 1, 7) || '-01'
                                            AND A.compcode = c.compcode
                                            AND A.plantcode = c.plantcode
                                            AND A.slipinno = c.slipinno
                                            AND c.slipdiv <> p_odiv2
                                            AND c.slipinstate = '4' ) A
                                    GROUP BY mngclucode

                                    UNION ALL

                                    SELECT  NVL(b.mngclucode, '') mngclucode,
                                            NVL(b.mngcluval, '') mngcluval,
                                            NVL(b.mngcludec, '') mngcludec,
                                            NVL(A.slipdate, '') slipdate,
                                            NVL(A.slipnum, '') slipnum,
                                            NVL(A.slipinseq, 0) slipinseq,
                                            NVL(A.remark1, '') remark,
                                            NVL(A.debamt, 0) debamt,
                                            NVL(A.creamt, 0) creamt
                                    FROM    ACORDD A
                                            , ACORDS b
                                            , ACORDM c
                                    WHERE   A.compcode = p_compcode
                                            AND A.plantcode LIKE p_plantcode
                                            AND A.slipdate BETWEEN p_startdt AND p_enddt
                                            AND A.acccode = p_acccode
                                            AND A.compcode = b.compcode
                                            AND A.slipinno = b.slipinno
                                            AND A.slipinseq = b.slipinseq
                                            AND A.compcode = c.compcode
                                            AND A.plantcode = c.plantcode
                                            AND A.slipinno = c.slipinno
                                            AND b.mngclucode = p_mngclucode
                                            AND c.slipdiv <> p_odiv2
                                            AND c.slipinstate = '4'

                                    UNION ALL

                                    -- 월계
                                    SELECT  mngclucode mngclucode,
                                            NULL mngcluval,
                                            NULL mngcludec,
                                            slipdate slipdate,
                                            NULL slipnum,
                                            0 slipinseq,
                                            NULL remark,
                                            SUM(A.debamt) debamt,
                                            SUM(A.creamt) creamt
                                    FROM    (   SELECT  b.mngclucode,
                                                        NULL mngcluval,
                                                        NULL mngcludec,
                                                        SUBSTR (A.slipdate, 0, 7) || '-90-99' slipdate,
                                                        NULL slipnum,
                                                        0 slipinseq,
                                                        NULL remark,
                                                        debamt,
                                                        creamt
                                                FROM    ACORDD A
                                                        LEFT JOIN ACORDS b ON A.compcode = b.compcode
                                                                              AND A.slipinno = b.slipinno
                                                                              AND A.slipinseq = b.slipinseq
                                                        JOIN ACORDM c ON A.compcode = c.compcode
                                                                         AND A.plantcode = c.plantcode
                                                                         AND A.slipinno = c.slipinno
                                                WHERE   A.compcode = p_compcode
                                                        AND A.plantcode LIKE p_plantcode
                                                        AND acccode = p_acccode
                                                        AND A.slipdate BETWEEN p_startdt AND p_enddt
                                                        AND A.acccode = p_acccode
                                                        AND b.mngclucode = p_mngclucode
                                                        AND c.slipinstate = '4' ) A
                                    GROUP BY A.mngclucode, slipdate) A
                                    ORDER BY slipdate, REPLACE (slipnum, 'C', p_colview), slipinseq
        )
        LOOP

            ip_mngclucode :=REC.mngclucode;
            p_mngcluval   :=REC.mngcluval;
            p_mngcludec   :=REC.mngcludec;
            p_slipdate    :=REC.slipdate;
            p_slipnum     :=REC.slipnum;
            p_slipinseq   :=REC.slipinseq;
            p_remark      :=REC.remark;
            p_debamt      :=REC.debamt;
            p_creamt      :=REC.creamt;


            IF ( SUBSTR(p_slipdate, -2, 2) <> '99' ) THEN

                IF ( p_dcdiv = '1' ) THEN

                    p_fnamt := NVL(p_fnamt, 0) + NVL(p_debamt, 0) - NVL(p_creamt, 0) ;

                ELSIF ( p_dcdiv = '2' ) THEN

                    p_fnamt := NVL(p_fnamt, 0) + NVL(p_creamt, 0) - NVL(p_debamt, 0) ;

                END IF;

            END IF;



            INSERT INTO VGT.TT_ACACC0150R_DUAL
            VALUES (    ip_mngclucode, p_mngcluval,  p_mngcludec,  p_slipdate,  p_slipnum,
                        p_slipinseq,  p_remark,     p_debamt,     p_creamt,    p_fnamt );



            IF ( SUBSTR(p_slipdate, -5, 5) = '90-99' ) THEN

                IF ( p_dcdiv = '1' ) THEN

                    INSERT INTO VGT.TT_ACACC0150R_DUAL (
                        SELECT  ip_mngclucode ,
                                NULL ,
                                NULL ,
                                SUBSTR(p_slipdate, 0, 7) || '-99-99' ,
                                NULL slipnum  ,
                                0 slipinseq  ,
                                NULL remark  ,
                                SUM(debamt)  debamt  ,
                                SUM(creamt)  creamt  ,
                                SUM(debamt) - SUM(creamt)  fnamt
                        FROM    VGT.TT_ACACC0150R_DUAL
                        WHERE   NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                                AND slipdate BETWEEN '1000-00-00' AND p_slipdate
                    );

                ELSIF ( p_dcdiv = '2' ) THEN

                    INSERT INTO VGT.TT_ACACC0150R_DUAL (
                        SELECT  ip_mngclucode ,
                                NULL ,
                                NULL ,
                                SUBSTR(p_slipdate, 0, 7) || '-99-99' ,
                                NULL ,
                                0 ,
                                NULL ,
                                SUM(debamt)  debamt  ,
                                SUM(creamt)  creamt  ,
                                SUM(creamt) - SUM(debamt)  fnamt
                        FROM    VGT.TT_ACACC0150R_DUAL
                        WHERE   NVL(SUBSTR(slipdate, 12, 2), ' ') <> '99'
                                AND slipdate BETWEEN '1000-00-00' AND p_slipdate
                    );

                END IF;

            END IF;

        END LOOP;



        FOR  rec IN (
            SELECT  COUNT(*) AS alias1
            FROM    VGT.TT_ACACC0150R_DUAL
        )
        LOOP
            p_rows := rec.alias1 ;
        END LOOP;



        IF ( p_rows = 1 ) THEN

            IF ( p_dcdiv = '1' ) THEN

                INSERT INTO VGT.TT_ACACC0150R_DUAL (
                    SELECT  MAX(mngclucode)  mngclucode  ,
                            NULL mngcluval  ,
                            NULL mngcludec  ,
                            '1000-99-99' slipdate  ,
                            NULL slipnum  ,
                            0 slipinseq  ,
                            NULL remark  ,
                            SUM(debamt)  ,
                            SUM(creamt)  ,
                            SUM(debamt) - SUM(creamt)  fnamt
                    FROM    VGT.TT_ACACC0150R_DUAL
                );

            ELSIF ( p_dcdiv = '2' ) THEN

                INSERT INTO VGT.TT_ACACC0150R_DUAL (
                    SELECT  MAX(mngclucode)  mngclucode  ,
                            NULL mngcluval  ,
                            NULL mngcludec  ,
                            '1000-99-99' slipdate  ,
                            NULL slipnum  ,
                            0 slipinseq  ,
                            NULL remark  ,
                            SUM(debamt)  ,
                            SUM(creamt)  ,
                            SUM(creamt) - SUM(debamt)  fnamt
                    FROM    VGT.TT_ACACC0150R_DUAL
                );

            END IF;



            OPEN IO_CURSOR FOR

                SELECT  NVL(mngclucode, '') mngclucode  ,
                        NVL(mngcluval, '') mngcluval  ,
                        NVL(mngcludec, '') mngcludec  ,
                        (CASE WHEN NVL(SUBSTR(slipdate, -5), ' ') = '00-00' THEN '이월'
                              WHEN NVL(SUBSTR(slipdate, -5), ' ') = '90-99' THEN '월계'
                              WHEN NVL(SUBSTR(slipdate, -5), ' ') = '99-99' THEN '누계'
                              ELSE NVL(slipdate, '')
                        END) slipdate  ,
                        NVL(slipdate, '') slipdate2  ,
                        NVL(slipnum, '') slipnum  ,
                        NVL(slipinseq, '') slipinseq  ,
                        NVL(remark, '') remark  ,
                        NVL(debamt, 0) debamt  ,
                        NVL(creamt, 0) creamt  ,
                        (CASE WHEN NVL(SUBSTR(slipdate, -5), ' ') = '90-99' THEN 0
                              ELSE NVL(fnamt, 0)
                        END) fnamt
                FROM    VGT.TT_ACACC0150R_DUAL A
                ORDER BY slipdate2, slipnum, slipinseq ;

        ELSE

            OPEN IO_CURSOR FOR

                SELECT  NVL(mngclucode, '') mngclucode  ,
                        NVL(mngcluval, '') mngcluval  ,
                        NVL(mngcludec, '') mngcludec  ,
                        (CASE WHEN NVL(SUBSTR(slipdate, -5, 5), ' ') = '00-00' THEN '이월'
                              WHEN NVL(SUBSTR(slipdate, -5, 5), ' ') = '90-99' THEN '월계'
                              WHEN NVL(SUBSTR(slipdate, -5, 5), ' ') = '99-99' THEN '누계'
                              ELSE NVL(slipdate, '')
                        END) slipdate  ,
                        NVL(slipdate, '') slipdate2  ,
                        NVL(slipnum, '') slipnum  ,
                        NVL(slipinseq, '') slipinseq  ,
                        NVL(remark, '') remark  ,
                        NVL(debamt, 0) debamt  ,
                        NVL(creamt, 0) creamt  ,
                        (CASE WHEN NVL(SUBSTR(slipdate, -5, 5), ' ') = '90-99' THEN 0
                              ELSE NVL(fnamt, 0)
                        END) fnamt
                FROM VGT.TT_ACACC0150R_DUAL A
                ORDER BY slipdate2, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9') ,slipnum, slipinseq ;

        END IF;

    ELSIF ( p_div = 'A1' ) THEN

      OPEN  IO_CURSOR FOR

         SELECT b.mngclucode keyfield  ,
                MAX(b.mngcluname)  displayfield
           FROM ACACCM A
                  LEFT JOIN ACACCMNGM b ON A.acccode = b.acccode
          WHERE  A.acccode = p_acccode
           GROUP BY b.mngclucode
           ORDER BY keyfield ;

    ELSIF ( p_div = 'A2' ) THEN

      OPEN  IO_CURSOR FOR

         SELECT A.mngclucode mngclucode  ,
                A.mngcluname mngcluname  ,
                A.mngcludiv mngcludiv  ,
                c.divname mngcludivnm  ,
                D.filter1 codeseek
           FROM ACMNGM A
                  LEFT JOIN CMCOMMONM c   ON A.mngcludiv = c.divcode
                  AND c.cmmcode = 'AC12'
                  LEFT JOIN CMCOMMONM D   ON A.mngclucode = D.divcode
                  AND D.cmmcode = 'CMHL'
          WHERE  A.mngclucode = p_mngclucode ;

    ELSIF ( p_div = 'A3' ) THEN

        OPEN    IO_CURSOR FOR

            SELECT  acccode ,
                    dcdiv
            FROM    ACACCM
            WHERE   acccode = p_acccode ;

    ELSIF ( p_div = 'RMK' ) THEN

    -- 코드헬프 검색
        OPEN    IO_CURSOR FOR

            SELECT  NVL(codehelp, '') codehelp ,-- 코드헬프번호
                    NVL(remark, '') codermk -- 코드헬프비고
            FROM    ACMNGM
            WHERE   mngclucode = p_mngclucode ;
    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
