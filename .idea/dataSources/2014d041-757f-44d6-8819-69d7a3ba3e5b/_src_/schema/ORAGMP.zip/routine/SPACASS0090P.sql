CREATE PROCEDURE        spACass0090P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACass0090P
	-- 작 성 자         : 이영재
	-- 작성일자         : 2011-03-08
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-27
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 자산 감가상각 처리
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '', --결산구분
	p_caldiv		IN	   VARCHAR2 DEFAULT 'CR', --계산구분
	p_assym 		IN	   VARCHAR2 DEFAULT '', --처리년월
	p_asscode		IN	   VARCHAR2 DEFAULT '', --자산코드
	p_depamt		IN	   FLOAT DEFAULT 0, --감가상각액
	p_iempcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'SM')
	THEN
		--자산마스터 조회
		OPEN IO_CURSOR FOR
			SELECT a.compcode compcode,
				   a.closediv closediv,
				   a.caldiv caldiv,
				   a.assym assym,
				   a.asscode asscode,
				   a.lifeyear lifeyear,
				   TO_NUMBER(SUBSTR(a.assym, 0, 4)) - TO_NUMBER(SUBSTR(M.strdate, 0, 4)) runlifeyear, --경과년수
				   a.curassamt - a.revamt - a.expamt + a.salamt fnassamt,
				   a.revamt + a.expamt incassamt,
				   a.salamt decassamt,
				   a.curassamt lsassamt,
				   a.predepamt bsdepramt,
				   a.depamt depamt,
				   a.drpamt drpamt,
				   a.predepamt + a.depamt - a.drpamt bedepramt,
				   a.deprdiv deprdiv,
				   a.deprate deprate,
				   M.assname assname,
				   M.plantcode plantcode,
				   M.acccode acccode,
				   M.dacccode dacccode,
				   ac02.divname closedivname,
				   ac78.divname caldivname,
				   ac74.divname deprdivname,
				   j.plantname plnatname,
				   acc.accname accname,
				   dacc.accname daccname
			FROM   ACASSDEPR a
				   LEFT JOIN ACASSM M
					   ON M.compcode = a.compcode
						  AND M.asscode = a.asscode
				   LEFT JOIN CMCOMMONM ac02
					   ON ac02.cmmcode = 'AC02'
						  AND ac02.divcode = a.closediv
				   LEFT JOIN CMCOMMONM ac78
					   ON ac78.cmmcode = 'AC78'
						  AND ac78.divcode = a.caldiv
				   LEFT JOIN ACDEPRM rate
					   ON rate.compcode = a.compcode
						  AND rate.lifeyear = a.lifeyear
						  AND rate.deprdiv = M.deprdiv
				   LEFT JOIN CMCOMMONM ac74
					   ON ac74.cmmcode = 'AC74' --자산상각방법
						  AND ac74.divcode = M.deprdiv
				   LEFT JOIN CMPLANTM j ON j.plantcode = M.plantcode
				   LEFT JOIN ACACCM acc ON acc.acccode = M.acccode
				   LEFT JOIN ACACCM dacc ON dacc.acccode = M.dacccode
			WHERE  a.compcode = p_compcode
				   AND a.closediv = p_closediv
				   AND a.caldiv = p_caldiv
				   AND a.assym = p_assym

            ORDER BY a.asscode ;

	ELSIF (p_div = 'SCAL')
	THEN
		DECLARE
			p_mathod	VARCHAR2(10);
			p_strym 	VARCHAR2(7);
			p_strdate	VARCHAR2(10);
			p_middate	VARCHAR2(10);
			p_enddate	VARCHAR2(10);
			p_month 	NUMBER(10, 0);
		--해당월의 감가상각 재계산
		BEGIN
			-- 상각방법 설정
			p_mathod := '년상각';

			FOR rec IN (SELECT value2
						FROM   SYSPARAMETERMANAGE a
						WHERE  parametercode = 'acassacc')
			LOOP
				p_mathod := rec.value2;
			END LOOP;

			-- 계산기간 설정
			p_strym := SUBSTR(p_assym, 0, 4) || '-01';

			FOR rec IN (SELECT MAX(SUBSTR(curstrdate, 0, 7)) AS alias1
						FROM   ACSESSION a
						WHERE  compcode = p_compcode
							   AND cyear <= SUBSTR(p_assym, 0, 4))
			LOOP
				p_strym := rec.alias1;
			END LOOP;

			IF SUBSTR(p_assym, -2, 2) < SUBSTR(p_strym, -2, 2)
			THEN
				p_strym := TO_CHAR(ADD_MONTHS(TO_DATE(p_assym, 'YYYY-MM'), -12), 'YYYY-') || SUBSTR(p_strym, -2, 2);
			ELSE
				p_strym := SUBSTR(p_assym, 0, 4) || SUBSTR(p_strym, -3, 3);
			END IF;

			p_strdate := p_strym || '-01';
			p_middate := p_assym || '-01';
			p_enddate := TO_CHAR(LAST_DAY(TO_DATE(p_assym, 'YYYY-MM')), 'YYYY-MM-DD');
			p_month := TRUNC(MONTHS_BETWEEN(TO_DATE(p_enddate, 'YYYY-MM-DD'), TO_DATE(p_strdate, 'YYYY-MM-DD'))) + 1;

			-- 기존 감가상각자료 삭제
			DELETE ACASSDEPR
			WHERE  compcode = p_compcode
				   AND closediv = p_closediv
				   AND caldiv = p_caldiv
				   AND assym = p_assym
				   AND asscode LIKE p_asscode || '%';

			-- 감가상각 계산
			INSERT INTO ACASSDEPR(compcode,
								  closediv,
								  caldiv,
								  assym,
								  asscode,
								  assstate,
								  deprdiv,
								  lifeyear,
								  deprate,
								  curassamt,
								  lstassamt,
								  yetdepamt,
								  prerevamt,
								  preexpamt,
								  presalqty,
								  presalamt,
								  predepamt,
								  revamt,
								  expamt,
								  salqty,
								  salamt,
								  depamt,
								  drpamt,
								  insertdt,
								  iempcode)
				(SELECT compcode,
						p_closediv,
						p_caldiv,
						p_assym,
						asscode,
						CASE
							WHEN deprendyn = 'Y'
								 OR curassamt - predepamt + drpamt - depramt <= lstassamt
							THEN
								'3'
							ELSE
								assstate
						END
							col,
						deprdiv,
						lifeyear,
						deprate,
						curassamt,
						lstassamt,
						CASE WHEN curassamt <= 0 THEN curassamt ELSE curassamt - predepamt + drpamt - depramt END col,
						prerevamt,
						preexpamt,
						presalqty,
						presalamt,
						predepamt,
						revamt,
						expamt,
						salqty,
						salamt,
						depramt,
						drpamt,
						SYSDATE,
						p_iempcode
				 FROM	(SELECT compcode,
								asscode,
								assstate,
								deprdiv,
								lifeyear,
								deprate,
								curassamt,
								lstassamt,
								prerevamt,
								preexpamt,
								presalqty,
								presalamt,
								predepamt,
								revamt,
								expamt,
								salqty,
								salamt,
								drpamt,
								deprendyn,
								NVL(  NVL(depamt2, 0)
									+ CASE
										  WHEN deprendyn = 'N'
											   AND curassamt > 0
										  THEN
											  FLOOR(CASE
														WHEN p_mathod = '월상각'
															 AND deprdiv = '1'
														THEN
															CASE WHEN deplstassamt - depamt * (p_month - minus_) / 12 > lstassamt THEN depamt * (p_month - minus_) / 12 ELSE deplstassamt - lstassamt END
														WHEN p_mathod = '월상각'
															 AND deprdiv = '2'
														THEN
															CASE WHEN limitAmt + lstassamt <= deplstassamt THEN depamt * (p_month - minus_) / 12 WHEN deplstassamt - deplstassamt * (p_month - minus_) / 12 > lstassamt THEN deplstassamt * (p_month - minus_) / 12 ELSE deplstassamt - lstassamt END
														ELSE
															CASE WHEN limitAmt + lstassamt <= deplstassamt THEN depamt ELSE CASE WHEN deplstassamt <= lstassamt THEN 0 ELSE deplstassamt - lstassamt END END * (p_month - minus_) / 12
													END)
										  ELSE
											  0
									  END,
									0)
									depramt
						 FROM	(SELECT compcode,
										asscode,
										assstate,
										deprdiv,
										lifeyear,
										deprate,
										curassamt,
										lstassamt,
										prerevamt,
										preexpamt,
										presalqty,
										presalamt,
										predepamt,
										revamt,
										expamt,
										salqty,
										salamt,
										drpamt,
										deplstassamt,
										minus_,
										deprendyn,
										CASE WHEN assstate = '0' THEN 0 WHEN deprdiv = '1' THEN (calcbuyamt) * deprate ELSE deplstassamt * deprate END depamt,
										depamt2, -- 상각액
										CASE WHEN assstate = '0' THEN 0 WHEN deprdiv = '1' THEN (calcbuyamt) * deprate ELSE deplstassamt * deprate + calcbuyamt * 0.05 - lstassamt END limitAmt -- 상각한도액
								 FROM	(SELECT a.compcode, -- 회사코드
												a.asscode, -- 자산코드
												CASE WHEN p_enddate < a.deprdate THEN '0' WHEN a.deprdate BETWEEN p_strdate AND p_enddate THEN '1' ELSE '2' END assstate, -- 상각상태
												a.deprdiv, -- 상각방법
												NVL(b.lifeyear, a.lifeyear) lifeyear, -- 내용년수
												NVL(b.deprate, a.deprate) deprate, -- 상각율
												COALESCE(b.curassamt, c.curassamt, a.curassamt) curassamt, -- 자산가액
												COALESCE(E.curassamt, b.curassamt, a.curassamt) calcbuyamt, -- 계산취득가액
												a.lstassamt, -- 비망가액
												a.deprendyn, -- 상각완료여부
												NVL(c.prerevamt + c.revamt, 0) prerevamt, -- 이전재평가금액
												NVL(c.preexpamt + c.expamt, 0) preexpamt, -- 이전자본적지출
												NVL(c.presalqty + c.salqty, 0) presalqty, -- 이전매각수량
												NVL(c.presalamt + c.salamt, 0) presalamt, -- 이전매각액
												NVL(c.predepamt + c.depamt - c.drpamt, 0) predepamt, -- 전기감가상각액
												NVL(f.depamt, 0) depamt2, -- 이전감가상각액
												NVL(D.revamt, 0) revamt, -- 계산재평가증감액
												NVL(D.expamt, 0) expamt, -- 계산자본적지출
												NVL(D.salqty, 0) salqty, -- 계산매각수량
												NVL(D.salamt, 0) salamt, -- 계산매각액
												NVL(D.drpamt, 0) drpamt, -- 계산감가상각감소액
												CASE WHEN c.asscode IS NULL THEN a.curassamt + NVL(D.revamt, 0) + NVL(D.expamt, 0) - NVL(D.salamt, 0) + NVL(D.drpamt, 0) ELSE c.yetdepamt + NVL(D.revamt, 0) + NVL(D.expamt, 0) - NVL(D.salamt, 0) + NVL(D.drpamt, 0) END deplstassamt, -- 미상각잔액
												  CASE WHEN a.deprdate BETWEEN p_strdate AND p_enddate THEN TRUNC(MONTHS_BETWEEN(TO_DATE(a.deprdate, 'YYYY-MM-DD'), TO_DATE(p_strdate, 'YYYY-MM-DD'))) ELSE 0 END
												+ CASE WHEN f.assym IS NULL THEN 0 ELSE TRUNC(MONTHS_BETWEEN(TO_DATE(f.assym || '-01', 'YYYY-MM-DD'), TO_DATE(p_strdate, 'YYYY-MM-DD'))) + 1 END
													minus_ -- 년계산시 -월처리
										 FROM	ACASSM a
												LEFT JOIN ( -- 최종변경내역
														   SELECT a.*
														   FROM   ACASSD a
																  JOIN (SELECT	 a.compcode, a.closediv, a.asscode, a.chgdate, MAX(seq) seq
																		FROM	 ACASSD a
																				 JOIN (SELECT	compcode, closediv, asscode, MAX(chgdate) chgdate
																					   FROM 	ACASSD
																					   WHERE	compcode = p_compcode
																								AND closediv = p_closediv
																								AND (chgdate BETWEEN p_strdate AND TO_CHAR(TO_DATE(p_middate, 'YYYY-MM-DD') - 1, 'YYYY-MM-DD')
																									 OR chgdate BETWEEN p_middate AND p_enddate
																										AND asschgdiv NOT IN ('03', '04'))
																					   GROUP BY compcode, closediv, asscode) b
																					 ON a.compcode = b.compcode
																						AND a.closediv = b.closediv
																						AND a.asscode = b.asscode
																						AND a.chgdate = b.chgdate
																		GROUP BY a.compcode, a.closediv, a.asscode, a.chgdate) b
																	  ON a.compcode = b.compcode
																		 AND a.closediv = b.closediv
																		 AND a.asscode = b.asscode
																		 AND a.chgdate = b.chgdate
																		 AND a.seq = b.seq) b
													ON a.compcode = b.compcode
													   AND a.asscode = b.asscode
												LEFT JOIN ( -- 이전기의 최종감가상각내역을 구함
														   SELECT a.*
														   FROM   ACASSDEPR a
																  JOIN (SELECT	 compcode, closediv, caldiv, asscode, MAX(assym) assym
																		FROM	 ACASSDEPR
																		WHERE	 compcode = p_compcode
																				 AND closediv = p_closediv
																				 AND caldiv = p_caldiv
																				 AND assym < p_strym
																		GROUP BY compcode, closediv, caldiv, asscode) b
																	  ON a.compcode = b.compcode
																		 AND a.closediv = b.closediv
																		 AND a.caldiv = b.caldiv
																		 AND a.assym = b.assym
																		 AND a.asscode = b.asscode) c
													ON a.compcode = c.compcode
													   AND a.asscode = c.asscode
												LEFT JOIN ( -- 변동내역을 집계
														   SELECT	compcode,
																	asscode,
																	SUM(chgqty) salqty,
																	SUM(CASE WHEN asschgdiv = '01' THEN chgamt ELSE 0 END) revamt,
																	SUM(CASE WHEN asschgdiv = '02' THEN chgamt ELSE 0 END) expamt,
																	SUM(CASE WHEN asschgdiv IN ('03', '04') THEN chgamt ELSE 0 END) salamt,
																	SUM(drpamt) drpamt
														   FROM 	ACASSD
														   WHERE	compcode = p_compcode
																	AND closediv = p_closediv
																	AND (chgdate BETWEEN p_strdate AND TO_CHAR(TO_DATE(p_middate, 'YYYY-MM-DD') - 1, 'YYYY-MM-DD')
																		 OR chgdate BETWEEN p_middate AND p_enddate
																			AND asschgdiv NOT IN ('03', '04'))
														   GROUP BY compcode, asscode) D
													ON a.compcode = D.compcode
													   AND a.asscode = D.asscode
												LEFT JOIN ( -- 최종 재평가내역
														   SELECT a.*
														   FROM   ACASSD a
																  JOIN (SELECT	 a.compcode, a.closediv, a.asscode, a.chgdate, MAX(seq) seq
																		FROM	 ACASSD a
																				 JOIN (SELECT	compcode, closediv, asscode, MAX(chgdate) chgdate
																					   FROM 	ACASSD
																					   WHERE	compcode = p_compcode
																								AND closediv = p_closediv
																								AND asschgdiv = '01'
																								AND chgdate BETWEEN p_strdate AND p_enddate
																					   GROUP BY compcode, closediv, asscode) b
																					 ON a.compcode = b.compcode
																						AND a.closediv = b.closediv
																						AND a.asscode = b.asscode
																						AND a.chgdate = b.chgdate
																		GROUP BY a.compcode, a.closediv, a.asscode, a.chgdate) b
																	  ON a.compcode = b.compcode
																		 AND a.closediv = b.closediv
																		 AND a.asscode = b.asscode
																		 AND a.chgdate = b.chgdate
																		 AND a.seq = b.seq) E
													ON a.compcode = E.compcode
													   AND a.asscode = E.asscode
												LEFT JOIN ( -- 이전의 최종감가상각내역을 구함
														   SELECT b.*
														   FROM   (SELECT a.*
																   FROM   ACASSD a
																		  JOIN (SELECT	 a.compcode, a.closediv, a.asscode, a.chgdate, MAX(seq) seq
																				FROM	 ACASSD a
																						 JOIN (SELECT	compcode, closediv, asscode, MAX(chgdate) chgdate
																							   FROM 	ACASSD
																							   WHERE	compcode = p_compcode
																										AND closediv = p_closediv
																										AND p_strdate <= chgdate
																										AND chgdate < p_middate
																										AND asschgdiv IN ('03', '04')
																							   GROUP BY compcode, closediv, asscode) b
																							 ON a.compcode = b.compcode
																								AND a.closediv = b.closediv
																								AND a.asscode = b.asscode
																								AND a.chgdate = b.chgdate
																				GROUP BY a.compcode, a.closediv, a.asscode, a.chgdate) b
																			  ON a.compcode = b.compcode
																				 AND a.closediv = b.closediv
																				 AND a.asscode = b.asscode
																				 AND a.chgdate = b.chgdate
																				 AND a.seq = b.seq) a
																  JOIN ACASSDEPR b
																	  ON a.compcode = b.compcode
																		 AND a.closediv = b.closediv
																		 AND b.caldiv = p_caldiv
																		 AND SUBSTR(a.chgdate, 0, 7) = b.assym
																		 AND a.asscode = b.asscode) f
													ON a.compcode = f.compcode
													   AND a.asscode = f.asscode
										 WHERE	a.compcode = p_compcode
												AND a.depryn = 'Y'
												AND a.strdate <= p_enddate
												AND SUBSTR(a.enddate, 0, 4) >= SUBSTR(p_enddate, 0, 4)
												AND a.asscode LIKE p_asscode || '%') a) a) a);

			MERGE INTO ACASSDEPR a
			USING	   (SELECT A.CALDIV,
							   A.ASSYM,
							   A.ASSCODE,
							   A.COMPCODE,
							   A.CLOSEDIV,
							   b.curassamt,
							   a.predepamt + a.depamt - c.drpamt AS pos_3,
							   c.salqty,
							   c.salamt,
							   c.drpamt
						FROM   ACASSDEPR a
							   JOIN ( -- 최종변경내역
									 SELECT a.*
									 FROM	ACASSD a
											JOIN (SELECT   a.compcode, a.closediv, a.asscode, a.chgdate, MAX(seq) seq
												  FROM	   ACASSD a
														   JOIN (SELECT   compcode, closediv, asscode, MAX(chgdate) chgdate
																 FROM	  ACASSD
																 WHERE	  compcode = p_compcode
																		  AND closediv = p_closediv
																		  AND chgdate BETWEEN p_middate AND p_enddate
																		  AND asschgdiv IN ('03', '04')
																 GROUP BY compcode, closediv, asscode) b
															   ON a.compcode = b.compcode
																  AND a.closediv = b.closediv
																  AND a.asscode = b.asscode
																  AND a.chgdate = b.chgdate
												  GROUP BY a.compcode, a.closediv, a.asscode, a.chgdate) b
												ON a.compcode = b.compcode
												   AND a.closediv = b.closediv
												   AND a.asscode = b.asscode
												   AND a.chgdate = b.chgdate
												   AND a.seq = b.seq) b
								   ON a.compcode = b.compcode
									  AND a.asscode = b.asscode
							   JOIN ( -- 변동내역을 집계
									 SELECT   compcode, asscode, SUM(chgqty) salqty, SUM(chgamt) salamt, SUM(drpamt) drpamt
									 FROM	  ACASSD
									 WHERE	  compcode = p_compcode
											  AND closediv = p_closediv
											  AND chgdate BETWEEN p_middate AND p_enddate
											  AND asschgdiv IN ('03', '04')
									 GROUP BY compcode, asscode) c
								   ON a.compcode = c.compcode
									  AND a.asscode = c.asscode
						WHERE  a.compcode = p_compcode
							   AND a.closediv = p_closediv
							   AND a.caldiv = p_caldiv
							   AND a.assym = p_assym
							   AND a.asscode LIKE p_asscode || '%') src
			ON		   (A.CALDIV = SRC.CALDIV
						AND A.ASSYM = SRC.ASSYM
						AND A.ASSCODE = SRC.ASSCODE
						AND A.COMPCODE = SRC.COMPCODE
						AND A.CLOSEDIV = SRC.CLOSEDIV)
			WHEN MATCHED
			THEN
				UPDATE SET a.curassamt = src.curassamt, a.yetdepamt = SRC.pos_3, a.salqty = src.salqty, a.salamt = src.salamt, a.drpamt = src.drpamt;

			UPDATE ACASSDEPR a
			SET    a.yetdepamt = a.lstassamt, a.depamt = a.depamt + a.yetdepamt - a.lstassamt
			WHERE  a.compcode = p_compcode
				   AND a.closediv = p_closediv
				   AND a.caldiv = p_caldiv
				   AND a.assym = p_assym
				   AND a.asscode LIKE p_asscode || '%'
				   AND a.yetdepamt <> a.lstassamt
				   AND a.yetdepamt < a.lstassamt + 10;
		END;
	ELSIF (p_div = 'SC')
	THEN
		FOR rec IN (SELECT COUNT(asscode) AS alias1
					FROM   ACASSDEPR
					WHERE  compcode = p_compcode
						   AND closediv = p_closediv
						   AND caldiv = p_caldiv
						   AND assym = p_assym
						   AND asscode = p_asscode)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;
	ELSIF (p_div = 'SCCAL')
	THEN
		--감가상각 재계산 인지 확인
		MESSAGE := 'N';

		FOR rec IN (SELECT COUNT(asscode) AS alias1
					FROM   ACASSDEPR
					WHERE  compcode = p_compcode
						   AND closediv = p_closediv
						   AND caldiv = p_caldiv
						   AND assym = p_assym)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;
	ELSIF (p_div = 'U')
	THEN
		UPDATE ACASSDEPR
		SET    yetdepamt = yetdepamt + depamt - p_depamt, depamt = p_depamt, updatedt = SYSDATE, uempcode = p_iempcode
		WHERE  compcode = p_compcode
			   AND closediv = p_closediv
			   AND caldiv = p_caldiv
			   AND assym = p_assym
			   AND asscode = p_asscode;
	ELSIF (p_div = 'D')
	THEN
		DELETE ACASSDEPR
		WHERE  compcode = p_compcode
			   AND closediv = p_closediv
			   AND caldiv = p_caldiv
			   AND assym = p_assym
			   AND asscode = p_asscode;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
