CREATE PROCEDURE spACacc0162R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0162R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2015-09-17
	-- 수 정 자         : 임정호
	-- 수 정 일         : 2016-12-21
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 전도금원장을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_strdate		IN	   VARCHAR2 DEFAULT '',
	p_enddate		IN	   VARCHAR2 DEFAULT '',
	p_acccode		IN	   VARCHAR2 DEFAULT '',
	p_outputdiv 	IN	   VARCHAR2 DEFAULT '',
	p_deptcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	IO_CURSOR		   OUT TYPES.DataSet,
	MESSAGE 		   OUT VARCHAR2
)
AS
	p_cashcode	  VARCHAR2(20);
	p_odiv1 	  VARCHAR2(5);
	p_odiv2 	  VARCHAR2(5);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);


	IF NVL(p_acccode, ' ') NOT LIKE '111380%'
	THEN
		GOTO LAST;
		RETURN;
	END IF;

	IF (p_div = 'S')
	THEN
		-- 결의전표내역 검색
		FOR rec IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'acccashcode')
		LOOP
			p_cashcode := rec.value1;
		END LOOP;

		IF (p_outputdiv = '1')
		THEN
			--K-GAAP
			p_odiv1 := '20';
			p_odiv2 := 'F';
		ELSIF (p_outputdiv = '2')
		THEN
			--IFRS
			p_odiv1 := '30';
			p_odiv2 := 'K';
		END IF;


		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0162R_ACORDM ';

		INSERT INTO VGT.TT_ACACC0162R_ACORDM
			SELECT DISTINCT A.compcode,
							A.slipinno,
							b.slipindate,
							b.slipinnum,
							b.slipdate,
							b.slipnum,
							b.slipdiv
			FROM   ACORDD A
				   JOIN ACORDM b
					   ON A.compcode = b.compcode
						  AND A.slipinno = b.slipinno
						  AND b.slipinstate = '4'
						  AND b.slipdiv <> p_odiv2
				   JOIN ACORDS c
					   ON A.compcode = c.compcode
						  AND A.slipinno = c.slipinno
						  AND A.slipinseq = c.slipinseq
						  AND c.mngclucode = 'S040'
						  AND c.mngcluval LIKE p_deptcode || '%'
			WHERE  A.compcode = p_compcode
				   AND A.plantcode LIKE p_plantcode || '%'
				   AND A.slipdate BETWEEN p_strdate AND p_enddate
				   AND A.acccode LIKE p_acccode || '%';

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0162R_ACORDD ';

		INSERT INTO VGT.TT_ACACC0162R_ACORDD
			SELECT	 NVL(b.grp, 0) grp,
					 CASE WHEN b.grp = 1 THEN A.slipdate || A.slipnum || LPAD(A.slipinseq, 5, '0') WHEN b.grp = 2 THEN SUBSTR(A.slipdate, 1, 7) || '98' WHEN b.grp = 3 THEN SUBSTR(A.slipdate, 1, 7) || '99' ELSE NULL END ord,
					 MAX(CASE WHEN b.grp = 1 THEN A.slipdate ELSE SUBSTR(A.slipdate, 1, 7) END) slipdate,
					 MAX(CASE WHEN b.grp = 1 THEN A.slipnum WHEN b.grp = 2 THEN '월계' WHEN b.grp = 3 THEN '누계' ELSE '이월' END) slipnum,
           MAX(CASE WHEN b.grp = 1 THEN A.slipindate END) slipindate,
           MAX(CASE WHEN b.grp = 1 THEN A.slipinnum END) slipinnum,
           MAX(CASE WHEN b.grp = 1 THEN A.slipinno END) slipinno,
           MAX(CASE WHEN b.grp = 1 THEN A.slipdiv END) slipdiv,
           MAX(CASE WHEN b.grp = 1 THEN A.slipinseq END) slipinseq,
           MAX(CASE WHEN b.grp = 1 THEN A.acccode END) acccode,
           MAX(CASE WHEN b.grp = 1 THEN A.accname END) accname,
           MAX(CASE WHEN b.grp = 1 THEN A.remark END) remark,
           SUM(A.debamt) debamt,
           SUM(A.creamt) creamt,
           SUM(A.debamt - A.creamt) fnamt
      FROM   (SELECT SUBSTR(p_strdate, 1, 7) || '-00' slipdate,
               NULL slipnum,
               NULL slipindate,
               NULL slipinnum,
               NULL slipinno,
               NULL slipdiv,
               NULL slipinseq,
               NULL acccode,
               NULL accname,
               NULL remark,
               A.bsdebamt debamt,
               A.bscreamt creamt
            FROM   ACORDSMM A
            WHERE  A.compcode = p_compcode
               AND A.plantcode LIKE p_plantcode || '%'
               AND A.slipym = SUBSTR(p_strdate, 1, 7)
               AND (closediv = '10'
                  OR closediv = p_odiv1)
               AND A.acccode LIKE p_acccode || '%'
               AND A.mngclucode = 'S040'
               AND A.mngcluval LIKE p_deptcode || '%'
            UNION ALL
            SELECT SUBSTR(p_strdate, 1, 7) || '-00' slipdate,
               NULL slipnum,
               NULL slipindate,
               NULL slipinnum,
               NULL slipinno,
               NULL slipdiv,
               NULL slipinseq,
               NULL acccode,
               NULL accname,
               NULL remark,
               A.debamt,
               A.creamt
            FROM   ACORDD A
               JOIN ACORDM b
                 ON A.compcode = b.compcode
                  AND A.slipinno = b.slipinno
                  AND b.slipinstate = '4'
                  AND b.slipdiv <> p_odiv2
               JOIN ACORDS c
                 ON A.compcode = c.compcode
                  AND A.slipinno = c.slipinno
                  AND A.slipinseq = c.slipinseq
                  AND c.mngclucode = 'S040'
                  AND c.mngcluval LIKE p_deptcode || '%'
            WHERE  A.compcode = p_compcode
               AND A.plantcode LIKE p_plantcode || '%'
               AND SUBSTR(p_strdate, 0, 7) || '-01' <= A.slipdate
               AND A.slipdate < p_strdate
               AND A.acccode LIKE p_acccode || '%'
            UNION ALL
            SELECT b.slipdate,
               b.slipnum,
               b.slipindate,
               b.slipinnum,
               b.slipinno,
               b.slipdiv,
               A.slipinseq,
               CASE WHEN A.dcdiv IN ('3', '4') THEN p_cashcode ELSE A.acccode END acccode,
               c.accname accname,
               A.remark1,
               A.creamt,
               A.debamt
            FROM   ACORDD A
               JOIN VGT.TT_ACACC0162R_ACORDM b
                 ON A.compcode = b.compcode
                  AND A.slipinno = b.slipinno
               LEFT JOIN ACACCM c ON CASE WHEN A.dcdiv IN ('3', '4') THEN p_cashcode ELSE A.acccode END = c.acccode
            WHERE  A.dcdiv IN ('3', '4')
               OR A.acccode NOT LIKE p_acccode || '%') A
           LEFT JOIN (SELECT 1 grp FROM DUAL
                UNION
                SELECT 2 FROM DUAL
                UNION
                SELECT 3 FROM DUAL) b
             ON A.slipdate >= p_strdate
      GROUP BY b.grp, CASE WHEN b.grp = 1 THEN A.slipdate || A.slipnum || LPAD(A.slipinseq, 5, '0') WHEN b.grp = 2 THEN SUBSTR(A.slipdate, 1, 7) || '98' WHEN b.grp = 3 THEN SUBSTR(A.slipdate, 1, 7) || '99' ELSE NULL END;


        MERGE INTO VGT.TT_ACACC0162R_ACORDD TG
        USING     (SELECT a.slipnum,
                           a.ord,
                           a.slipinno,
                           a.slipdiv,
                           a.acccode,
                           a.accname,
                           a.remark,
                           a.slipdate,
                           a.slipindate,
                           a.slipinnum,
                           a.grp,
                           a.slipinseq,
                           a.debamt,
                           a.creamt,
                           b.debamt - b.creamt AS fnamt
                    FROM   VGT.TT_ACACC0162R_ACORDD A
                           JOIN (SELECT   A.ord,
                                          SUM(b.debamt) debamt,
                                          SUM(b.creamt) creamt
                                 FROM    VGT.TT_ACACC0162R_ACORDD A
                                          JOIN VGT.TT_ACACC0162R_ACORDD b
                                              ON NVL(A.ord,' ') >= NVL(b.ord,' ')
                                                 AND b.grp IN (0, 1)
                                 WHERE    A.grp = 1
                                 GROUP BY A.ord) b
                               ON A.ord = b.ord) src
        ON       (NVL(tg.slipnum, ' ') = NVL(src.slipnum, ' ')
                    AND NVL(tg.ord, ' ') = NVL(src.ord, ' ')
                    AND NVL(tg.slipinno, ' ') = NVL(src.slipinno, ' ')
                    AND NVL(tg.slipdiv, ' ') = NVL(src.slipdiv, ' ')
                    AND NVL(tg.acccode, ' ') = NVL(src.acccode, ' ')
                    AND NVL(tg.accname, ' ') = NVL(src.accname, ' ')
                    AND NVL(tg.remark, ' ') = NVL(src.remark, ' ')
                    AND NVL(tg.slipdate, ' ') = NVL(src.slipdate, ' ')
                    AND NVL(tg.slipindate, ' ') = NVL(src.slipindate, ' ')
                    AND NVL(tg.slipinnum, ' ') = NVL(src.slipinnum, ' ')
                    AND NVL(tg.grp, 0) = NVL(src.grp, 0)
                    AND NVL(tg.slipinseq, 0) = NVL(src.slipinseq, 0)
                    AND NVL(tg.debamt, 0) = NVL(src.debamt, 0)
                    AND NVL(tg.creamt, 0) = NVL(src.creamt, 0))
        WHEN MATCHED
        THEN
            UPDATE SET tg.fnamt = src.fnamt;

    MERGE INTO VGT.TT_ACACC0162R_ACORDD tg
    USING     (SELECT A.ord,
               NVL(b.debamt, A.debamt) AS pos_2,
               NVL(b.creamt, A.creamt) AS pos_3,
               b.fnamt
          FROM   VGT.TT_ACACC0162R_ACORDD A
               LEFT JOIN (SELECT   A.ord,
                         SUM(b.debamt) debamt,
                         SUM(b.creamt) creamt,
                         SUM(b.fnamt) fnamt
                    FROM     VGT.TT_ACACC0162R_ACORDD A
                         JOIN VGT.TT_ACACC0162R_ACORDD b
                           ON A.ord >= NVL(b.ord, ' ')
                            AND b.grp IN (0, 2)
                    WHERE    A.grp = 3
                    GROUP BY A.ord) b
                 ON A.ord = b.ord
          WHERE  A.grp IN (2, 3)) src
    ON       (tg.ord = src.ord)
    WHEN MATCHED
    THEN
      UPDATE SET tg.debamt = src.pos_2, tg.creamt = src.pos_3, tg.fnamt = src.fnamt;


    OPEN IO_CURSOR FOR
      SELECT   A.slipdate,
           A.slipnum,
           A.slipindate,
           A.slipinnum,
           A.slipdiv,
           A.slipinseq,
           A.acccode,
           A.accname,
           A.remark,
           A.debamt,
           A.creamt,
           A.fnamt,
           b.mngcludec1,
           b.mngcludec2,
           b.mngcludec3,
           b.mngcludec4,
           b.mngcludec5,
           b.mngcludec6
      FROM   VGT.TT_ACACC0162R_ACORDD A
           LEFT JOIN (SELECT   slipinno,
                     slipinseq,
                     MAX(CASE WHEN seq = 1 THEN mngcludec ELSE '' END) mngcludec1,
                     MAX(CASE WHEN seq = 2 THEN mngcludec ELSE '' END) mngcludec2,
                     MAX(CASE WHEN seq = 3 THEN mngcludec ELSE '' END) mngcludec3,
                     MAX(CASE WHEN seq = 4 THEN mngcludec ELSE '' END) mngcludec4,
                     MAX(CASE WHEN seq = 5 THEN mngcludec ELSE '' END) mngcludec5,
                     MAX(CASE WHEN seq = 6 THEN mngcludec ELSE '' END) mngcludec6
                FROM   (SELECT A.slipinno,
                         A.slipinseq,
                         ROW_NUMBER() OVER (PARTITION BY A.slipinno, A.slipinseq ORDER BY b.seq) seq,
                         '[' || c.mngcluname || ']' || b.mngcluval || ' : ' || b.mngcludec || CASE WHEN D.custcode IS NULL THEN NULL ELSE ' (' || D.businessno || ')' END mngcludec
                      FROM   VGT.TT_ACACC0162R_ACORDD A
                         JOIN ACORDS b
                           ON b.compcode = p_compcode
                            AND A.slipinno = b.slipinno
                            AND A.slipinseq = b.slipinseq
                         LEFT JOIN ACMNGM c ON b.mngclucode = c.mngclucode
                         LEFT JOIN CMCUSTM D
                           ON b.mngclucode = 'S010'
                            AND b.mngcluval = D.custcode) A
                GROUP BY slipinno, slipinseq) b
             ON A.slipinno = b.slipinno
              AND A.slipinseq = b.slipinseq
      ORDER BY A.ord NULLS FIRST;
  END IF;

   <<LAST>>
  IF (IO_CURSOR IS NULL)
  THEN
    OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
  END IF;
END;
/
