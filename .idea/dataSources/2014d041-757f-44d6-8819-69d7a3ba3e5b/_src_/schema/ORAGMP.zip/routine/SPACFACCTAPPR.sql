CREATE PROCEDURE        spacfAcctAppr(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spacfAcctAppr
	-- 작 성 자         : 최용석
	-- 작성일자         : 2011-11-30
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 계좌 입출금 내역을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div				IN	   VARCHAR2 DEFAULT '',
	p_compcode			IN	   VARCHAR2 DEFAULT '',
	p_plantcode 		IN	   VARCHAR2 DEFAULT '1000',
	p_strdate			IN	   VARCHAR2 DEFAULT '',
	p_enddate			IN	   VARCHAR2 DEFAULT '',
	ip_acctno			IN	   VARCHAR2 DEFAULT '',
	p_slipdiv			IN	   VARCHAR2 DEFAULT '',
	p_slipinno			IN	   VARCHAR2 DEFAULT '',
	p_slipinseq 		IN	   NUMBER DEFAULT 0,
	p_acct_no			IN	   VARCHAR2 DEFAULT '',
	p_acct_txday		IN	   VARCHAR2 DEFAULT '',
	p_acct_txday_seq	IN	   NUMBER DEFAULT 0,
	p_userid			IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 		IN	   VARCHAR2 DEFAULT '',
	p_reasontext		IN	   VARCHAR2 DEFAULT '',
	MESSAGE 			   OUT VARCHAR2,
	IO_CURSOR			   OUT SYS_REFCURSOR
)
AS
	p_acctno   VARCHAR2(4000) := ip_acctno;
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

-- IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리
--	IF (p_div = 'S') THEN
--		-- 계좌입출금내역 검색
--		p_acctno := REPLACE(p_acctno, '-', '');
--
--		-- 기업은행
--		OPEN IO_CURSOR FOR
--			SELECT	 'N' seldiv,																																																																	 -- 선택여부
--					 c.slipdiv, 																																																															   -- 분개방법(AC68)
--					 NVL(j.divname, k.accname) slipdivname, 																																																										-- 분개방법명
--					 NVL(g.mngcluval, f.mngcluval) custcode,																																																										  -- 거래처
--					 NVL(g.mngcludec, f.mngcludec) custname,																																																										 -- 거래처명
--					 D.remark1, 																																																																	 -- 사용내역
--					 RTRIM(a.bank_cd) bank_cd,																																																														  -- 은행명
--					 NVL(i.accountno, RTRIM(a.acct_no)) acct_no,																																																									 -- 계좌번호
--					 FNSTUFF(FNSTUFF(RTRIM(a.acct_txday), 5, 0, '-'), 8, 0, '-') acct_txday,																																																 -- 거래일자
--					 a.acct_txday_seq,																																																																 -- 거래순번
--					 CASE WHEN a.inout_gubun = '2' THEN tx_amt END in_amt,																																																							  -- 입금액
--					 CASE WHEN a.inout_gubun = '1' THEN tx_amt END out_amt, 																																																						  -- 출금액
--					 RTRIM(a.jeokyo) jeokyo,																																																														   -- 적요
--					 FNSTUFF(FNSTUFF(RTRIM(a.acct_txtime), 3, 0, ':'), 6, 0, ':') acct_txtime,																																																 -- 거래시간
--					 NVL(i.accremark, '') accremark,																																																												 -- 계좌명칭
--					 e.slipindate,																																																																	 -- 전표일자
--					 e.slipinnum,																																																																	 -- 전표번호
--					 h.empname, 																																																																	 -- 작성사원
--					 CASE WHEN g.compcode IS NOT NULL THEN 'S020' ELSE 'S010' END mngpop																																																					 -- 관리항목
--			FROM	 IBKDB.EBRANCH.ISS_ACCT_HIS a
--					 --from IBKDB_ISS_ACCT_HIS a
--
--					 LEFT JOIN TABLE(fnSplit(p_acctno, ';')) b ON a.acct_no LIKE '%' || b.codes || '%'
--					 LEFT JOIN ACORDACCT c
--						 ON a.acct_no = c.acct_no
--							AND a.acct_txday = c.acct_txday
--							AND a.acct_txday_seq = c.acct_txday_seq
--					 LEFT JOIN ACORDD D
--						 ON c.compcode = D.compcode
--							AND c.slipinno = D.slipinno
--							AND c.slipinseq = D.slipinseq
--					 LEFT JOIN ACORDM e
--						 ON D.compcode = e.compcode
--							AND D.slipinno = e.slipinno
--					 LEFT JOIN ACORDS f
--						 ON c.compcode = f.compcode
--							AND c.slipinno = f.slipinno
--							AND c.slipinseq - 1 = f.slipinseq
--							AND f.mngclucode = 'S010'
--					 LEFT JOIN ACORDS g
--						 ON c.compcode = g.compcode
--							AND c.slipinno = g.slipinno
--							AND c.slipinseq - 1 = g.slipinseq
--							AND g.mngclucode = 'S020'
--					 LEFT JOIN CMEMPM h ON e.empcode = h.empcode
--					 LEFT JOIN CMACCOUNTM i ON a.acct_no = REPLACE(i.accountno, '-', '')
--					 LEFT JOIN CMCOMMONM j
--						 ON j.cmmcode = 'AC68'
--							AND c.slipdiv = j.divcode
--					 LEFT JOIN ACACCM k ON c.slipdiv = k.acccode
--					 LEFT JOIN IB_ACCT_COMP l
--						 ON a.acct_no = l.acct_no
--							AND a.acct_txday = l.acct_txday
--							AND a.acct_txday_seq = l.acct_txday_seq
--			WHERE	 a.acct_txday BETWEEN p_strdate AND p_enddate
--					 AND (p_acctno IS NULL OR b.codes IS NOT NULL)
--					 AND l.acct_no IS NULL
--					 AND a.site_no = (SELECT REPLACE(businessno, '-', '')
--									  FROM	 CMPLANTM
--									  WHERE  plantcode = p_plantcode)
--			ORDER BY a.acct_no, a.acct_txday, a.acct_txday_seq;
--
--	ELS
-- IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리

    IF (p_div = 'SA') THEN
		-- 계정과목 관리항목 검색
		OPEN IO_CURSOR FOR
			SELECT a.mngclucode
			FROM   ACACCMNGM a
				   JOIN (SELECT MIN(seq) seq
						 FROM	ACACCMNGM
						 WHERE	acccode = p_acctno
								AND dcdiv = '1'
								AND remainyn = 'Y') b
					   ON a.seq = b.seq
			WHERE  a.acccode = p_acctno
				   AND a.dcdiv = '1';

	ELSIF (p_div = 'SC') THEN
		-- 공통항목 관리항목 검색
		FOR rec IN (SELECT filter1
					FROM   CMCOMMONM
					WHERE  cmmcode = 'AC68'
						   AND divcode = p_acctno)
		LOOP
			p_acctno := rec.filter1;
		END LOOP;

		OPEN IO_CURSOR FOR
			SELECT a.mngclucode
			FROM   ACACCMNGM a
				   JOIN (SELECT MIN(seq) seq
						 FROM	ACACCMNGM
						 WHERE	acccode = p_acctno
								AND dcdiv = '1'
								AND remainyn = 'Y') b
					   ON a.seq = b.seq
			WHERE  a.acccode = p_acctno
				   AND a.dcdiv = '1';

	ELSIF (p_div = 'I') THEN
		-- 계좌입출금내역 전표번호생성
		INSERT INTO ACORDACCT(compcode,
							  slipinno,
							  slipinseq,
							  slipdiv,
							  acct_no,
							  acct_txday,
							  acct_txday_seq,
							  seldiv)
		VALUES		(p_compcode,
					 p_slipinno,
					 p_slipinseq,
					 p_slipdiv,
					 REPLACE(p_acct_no, '-', ''),
					 REPLACE(p_acct_txday, '-', ''),
					 p_acct_txday_seq,
					 'N');

	ELSIF (p_div = 'U') THEN
		-- 계좌입출금내역 전표번호갱신
		UPDATE ACORDACCT a
		SET    a.slipdiv = p_slipdiv, a.acct_no = REPLACE(p_acct_no, '-', ''), a.acct_txday = REPLACE(p_acct_txday, '-', ''), a.acct_txday_seq = p_acct_txday_seq
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq;

	ELSIF (p_div = 'D') THEN
		-- 계좌입출금내역 전표번호삭제
		DELETE ACORDACCT
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq;

	ELSIF (p_div = 'DA') THEN
		-- 계좌입출금내역 전표번호 전체삭제
		DELETE ACORDACCT
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
