CREATE PROCEDURE        spACass0010S(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACass0010S
	-- 작 성 자         : 배종성
	-- 작성일자         : 2010-11-19
	-- 수정일자      :   노영래
	-- E-mail      :   0rae0926@gmail.com
	-- 수정일자      :   2017-02-22
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : (팝업)자산 등록하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_asscode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S')
	THEN
		OPEN IO_CURSOR FOR
			SELECT a.compcode compcode,
				   a.asscode asscode,
				   a.assname assname,
				   a.assdiv assdiv,
				   a.asscls asscls,
				   a.strdate strdate,
				   a.enddate enddate,
				   NVL(a.lifeyear, 0) lifeyear,
				   a.plantcode plantcode,
				   a.mngdeptcode mngdeptcode,
				   a.acccode acccode,
				   a.gacccode gacccode,
				   a.dacccode dacccode,
				   a.keeprmk keeprmk,
				   a.workdiv workdiv,
				   a.masscode masscode,
				   a.acqdiv acqdiv,
				   a.deprdate deprdate,
				   a.depryn depryn,
				   a.deprdiv deprdiv,
				   a.remark remark,
				   a.deprendyn deprendyn,
				   a.assstate assstate,
				   NVL(a.curassqty, 0) curassqty,
				   NVL(a.curassamt, 0) curassamt,
				   NVL(a.lstassamt, 0) lstassamt,
				   a.subsidyn subsidyn,
				   a.subsidrmk subsidrmk,
				   NVL(a.subsidassamt, 0) subsidassamt,
				   b.plantname plantname,
				   c.deptname mngdeptname,
				   D.accname accname,
				   e.accname gaccname,
				   f.accname daccname,
				   h.equipmentkorname massname,
				   ac76.divname assstatename,
				   ac71.divname assclsname,
				   ac70.divname assdivname
			FROM   ACASSM a
				   LEFT JOIN CMPLANTM b ON a.plantcode = b.plantcode
				   LEFT JOIN CMDEPTM c ON a.mngdeptcode = c.deptcode
				   LEFT JOIN ACACCM D ON a.acccode = D.acccode
				   LEFT JOIN ACACCM e ON a.gacccode = e.acccode
				   LEFT JOIN ACACCM f ON a.dacccode = f.acccode
				   LEFT JOIN PDEQUIPMENTM h ON a.masscode = h.equipmentcode
				   LEFT JOIN CMCOMMONM ac76
					   ON ac76.cmmcode = 'AC76'
						  AND ac76.divcode = a.assstate
				   LEFT JOIN CMCOMMONM ac71 --자산분류
					   ON ac71.cmmcode = 'AC71'
						  AND ac71.divcode = a.asscls
				   LEFT JOIN CMCOMMONM ac70
					   ON ac70.cmmcode = 'AC70' --자산형태
						  AND ac70.divcode = a.assdiv
			WHERE  a.compcode = p_compcode
				   AND a.asscode = p_asscode;
	END IF;

	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
