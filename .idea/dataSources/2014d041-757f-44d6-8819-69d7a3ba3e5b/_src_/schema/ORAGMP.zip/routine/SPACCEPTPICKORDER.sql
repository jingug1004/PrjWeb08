CREATE PROCEDURE        spAcceptPickOrder(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spAcceptPickOrder
	-- 작 성 자         : 이세민
	-- 작성일자         : 2007-10-23
	-- 수 정 자     : 임 정호
	-- 수정일자      : 2017-01-16
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 시험접수와 검체지시 정보를 관리하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div						IN	   VARCHAR2 DEFAULT ''
   ,p_plantcode 				IN	   VARCHAR2 DEFAULT ''
   ,p_searchdiv 				IN	   VARCHAR2 DEFAULT '' --조회조건
   ,p_startdt					IN	   VARCHAR2 DEFAULT '' --조회일자
   ,p_enddt 					IN	   VARCHAR2 DEFAULT '' --조회일자
   ,p_testdiv					IN	   VARCHAR2 DEFAULT ''
   ,p_datediv					IN	   VARCHAR2 DEFAULT '' --일자조회구분
   ,p_testmanageid				IN	   NUMBER DEFAULT 0
   ,p_teststandardrevisionid	IN	   NUMBER DEFAULT 0
   ,p_itemcode					IN	   VARCHAR2 DEFAULT ''
   ,p_testrequestremark 		IN	   VARCHAR2 DEFAULT '' --삭제필요...
   ,p_testprogressstatus		IN	   VARCHAR2 DEFAULT ''
   ,p_testtype					IN	   VARCHAR2 DEFAULT ''
   ,p_requestdate				IN	   VARCHAR2 DEFAULT ''
   ,p_testno					IN	   VARCHAR2 DEFAULT ''
   ,p_receivedate				IN	   VARCHAR2 DEFAULT ''
   ,p_reportplandate			IN	   VARCHAR2 DEFAULT ''
   ,p_testchargeempcode 		IN	   VARCHAR2 DEFAULT ''
   ,p_testorderdate 			IN	   VARCHAR2 DEFAULT ''
   ,p_samplingexpectant 		IN	   VARCHAR2 DEFAULT ''
   ,p_processcode				IN	   VARCHAR2 DEFAULT ''
   ,p_rowbarcode				IN	   VARCHAR2 DEFAULT ''
   ,p_Warehousingno 			IN	   VARCHAR2 DEFAULT ''
        
   ,p_informaltest              IN       VARCHAR2 DEFAULT ''        --약식시험여부
   ,p_shadeyn                  IN       VARCHAR2 DEFAULT ''        --차광여부
   ,p_microorganismtest          IN       VARCHAR2 DEFAULT ''       --미생물시험
   ,p_keepingcontainer          IN       VARCHAR2 DEFAULT ''        --보관용기
   ,p_keepingtemperature        IN       VARCHAR2 DEFAULT ''        --보관온도
   ,p_containertest             IN       VARCHAR2 DEFAULT ''        --전용기확인시험
   
   ,p_userid					IN	   VARCHAR2 DEFAULT ''
   ,p_reasondiv 				IN	   VARCHAR2
   ,p_reasontext				IN	   VARCHAR2
   ,MESSAGE 					   OUT VARCHAR2
   ,IO_CURSOR					   OUT TYPES.DataSet
)
AS
	p_unitname				  VARCHAR2(10);
	p_totalwarehousingqty	  VARCHAR2(50);
	p_cnt					  NUMBER(10, 0);
	v_temp					  NUMBER(1, 0) := 0;


	p_unitname1 			  VARCHAR2(10);
	p_totalwarehousingqty1	  VARCHAR2(50);

	user_define_error		  EXCEPTION; -- STEP 1
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S') THEN
		OPEN IO_CURSOR FOR
			SELECT	 NVL(A.testmanageid, 0) testmanageid --시험관리번호
					,NVL(A.teststandardrevisionid, 0) teststandardrevisionid --개정관리일련번호
					,NVL(A.testrequestno, '') testrequestno --시험의뢰번호
					,NVL(E.deptname, '') requestdeptname --의뢰부서명
					,NVL(A.testdiv, '') testdiv --시험구분
					,NVL(b.itemkorname, ' ') || CASE
						 WHEN A.testdiv = '04'
					 AND b.packingunitqty > 1 THEN
						 LPAD					(' ', 1, ' ') || fnNumericToString(b.packingunitqty, 'S') || b.itemunit
						 ELSE
						 ''
					 END
						 itemname --품목명
					,NVL(A.itemcode, '') itemcode --품목코드
					,NVL(A.standardtype, '') standardtype --규격
					,NVL(A.processcode, '') processcode --공정, 제조용수포인트
					,NVL(A.productdate, '') productdate --제조(입고일자)
					,NVL(A.productno, '') productno --제조(입고번호)
					,NVL(A.manageno, '') manageno --관리번호(타회사제조번호)
					,fnNumericToString(A.testrequestqty, 'S2') || NVL(D.divname, ' ') testrequestqty
					,fnNumericToString(A.packingqty, 'S2') || 'EA' packingqty
					,NVL(A.validdate, '') validdate --유효일자
					,NVL(A.reportdemanddate, '') reportdemanddate --통보요청일
					,NVL(A.testprogressstatus, '') testprogressstatus --시험진행상태
					,NVL(A.requestdate, '') requestdate --의뢰일자
					,NVL(A.testno, '') testno --시험번호
					,NVL(A.receivedate, '') receivedate --시험접수일
					,NVL(A.reportplandate, '') reportplandate --통보예정일
					,NVL(A.testchargeempcode, '') testchargeempcode --시험담당자코드
					,NVL(A.testorderdate, '') testorderdate --검체지시일
					,NVL(A.samplingexpectant, '') samplingexpectant --검체예정자코드
					,NVL(c.empname, '') samplingexpectantname --검체예정자명
					,CASE WHEN NVL(G.itemcode, '') IS NULL THEN 'N' ELSE 'Y' END existstandardyn --시험규격존재여부(추가필요)
					,NVL(A.packingqty, 0) packingqtyint
					,i.custname manufacturename
					,NVL(j.divname, '') testtype
					,A.plantcode
					,b.typicalitemcode
                    ,CASE WHEN NVL(B.TESTPERIOD, '0') = '0' THEN NVL(k.filter2, '0')
                          ELSE TO_CHAR(B.TESTPERIOD)
                          END filter2 -- 통보예정일 계산값
                    
                    
--                    NVL(k.filter2, '0') filter2        -- 통보예정일 계산값
                    ,a.informaltest                     --약식시험여부
                    ,a.shadeyn              --차광여부
                    ,a.microorganismtest     --미생물시험
                    ,a.containertest        --전용기확인시험
                    ,a.keepingcontainer      --보관용기
                    ,a.keepingtemperature    --보관온도
                    ,l.keepexpertant                   --검체정보관리 검체자코드
                    ,m.empname keepexpertantname        --검체정보관리 검체자명
			FROM	 TestManage A
					 LEFT JOIN vnAllItemsLIMS b ON A.itemcode = b.itemcode
					 LEFT JOIN CMDEPTM E ON A.requestdeptcode = E.deptcode
					 LEFT JOIN CMEMPM c ON A.samplingexpectant = c.empcode
					 LEFT JOIN CMCOMMONM D
						 ON D.cmmcode = 'CMM02'
							AND A.testrequestunit = D.divcode
					 LEFT JOIN CMCOMMONM f
						 ON f.cmmcode = 'CMM02'
							AND A.packingunit = f.divcode
					 LEFT JOIN vnTestStandardMaster G
						 ON G.itemcode = (CASE WHEN NVL(A.testdiv, '') IN ('08', '14', '15', '07', '10') THEN b.typicalitemcode ELSE A.itemcode END)
							AND G.testdiv = CASE WHEN A.testdiv = '09' THEN '09' ELSE A.testdiv END
							AND NVL(A.standardtype, ' ') = NVL(G.standarddiv, ' ')
							AND NVL(A.processcode, ' ') = CASE WHEN A.testdiv IN ('08', '14', '15') THEN ' ' ELSE NVL(G.processcode, ' ') END
					 LEFT JOIN CMCUSTM i ON A.manufacturecode = i.custcode
					 LEFT JOIN CMCOMMONM j
						 ON j.cmmcode = 'CMM58'
							AND A.fasttestdiv = j.divcode
                     LEFT JOIN CMCOMMONM k          -- 시험종류
                         ON k.cmmcode = 'LMM04' 
                            AND b.itemdiv = k.divcode
                     LEFT JOIN PickingMaster l    --검체정보관리
                         ON a.ITEMCODE = l.itemcode
                         and nvl(a.processcode, ' ') = nvl(l.processcode, ' ')
                     LEFT JOIN CMEMPM m
                         ON  l.keepexpertant = m.empcode  
			WHERE	 A.testdiv LIKE p_testdiv || '%'
					 AND --조회구분
						((p_searchdiv = '0'
						  AND (UPPER(A.itemcode) LIKE UPPER(p_itemcode) || '%'
							   OR UPPER(b.itemkorname) LIKE UPPER(p_itemcode) || '%')) --품목조회
						 OR (p_searchdiv = '1'
							 AND UPPER(A.testrequestno) LIKE UPPER(p_itemcode) || '%') --의뢰번호
						 OR (p_searchdiv = '2'
							 AND UPPER(A.productno) LIKE UPPER(p_itemcode) || '%')) --제조번호
					 AND ((p_datediv = '0'
						   AND A.requestdate BETWEEN p_startdt AND p_enddt)
						  OR (p_datediv = '1'
							  AND A.receivedate BETWEEN p_startdt AND p_enddt))
					 AND A.testprogressstatus LIKE p_testprogressstatus || '%'
					 AND (A.itemcode || A.manageno) <> ('BWA01' || '01')
					 AND A.plantcode LIKE p_plantcode || '%'
			ORDER BY A.testdiv, A.testrequestno;
	ELSIF (p_div = 'US2') THEN
		FOR REC IN (SELECT DISTINCT b.standarddiv || ';' || b.standarddivname || ';' || CASE WHEN NVL(G.itemcode, '') IS NULL THEN 'N' ELSE 'Y' END alies1
					FROM   TestManage A
						   JOIN vnItemMaster b ON A.itemcode = b.itemcode
						   LEFT JOIN vnTestStandardMaster G
							   ON G.itemcode = (CASE WHEN NVL(A.testdiv, '') IN ('08', '14', '15', '07', '10') THEN b.typicalitemcode ELSE A.itemcode END)
								  AND TRIM(A.standardtype) = TRIM(G.standarddiv)
								  AND NVL(A.processcode, ' ') = CASE WHEN A.testdiv IN ('08', '14', '15') THEN ' ' ELSE NVL(G.processcode, ' ') END
					WHERE  A.testmanageid = p_testmanageid
						   AND a.plantcode = p_plantcode)
		LOOP
			MESSAGE := rec.alies1;
		END LOOP;
	ELSIF (p_div = 'U2') THEN
		--규격을 변경한다.


		MERGE INTO TestManage tg
		USING	   (SELECT standarddiv
						  ,itemcode
					FROM   vnItemMaster
					WHERE  plantcode = p_plantcode) src
		ON		   (tg.itemcode = src.itemcode
					AND tg.testmanageid = p_testmanageid)
		WHEN MATCHED THEN
			UPDATE SET tg.standardtype = src.standarddiv, tg.teststandardrevisionid = 0;



		----- 전자서명 key 복사
		EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACCEPTPICKORDER_TMPKEYS';


		INSERT INTO VGT.TT_ACCEPTPICKORDER_TMPKEYS
			(SELECT c.testdiv || c.itemcode || c.standarddiv || c.processcode || c.revisionno KEYS
				   ,c.testdiv || c.itemcode || b.standarddiv || c.processcode || c.revisionno newkeys
			 FROM	TestManage A
					JOIN vnItemMaster b ON A.itemcode = b.itemcode
					JOIN TestStandardRevision c
						ON A.testdiv = c.testdiv
						   AND A.itemcode = c.itemcode
						   AND NVL(A.processcode, ' ') = NVL(c.processcode, ' ')
						   AND A.standardtype != c.standarddiv
			 WHERE	A.testmanageid = p_testmanageid
					AND a.plantcode = p_plantcode);



		SELECT COUNT(A.KEYS)
		INTO   p_cnt
		FROM   ElectronicSignHistory A JOIN VGT.TT_ACCEPTPICKORDER_TMPKEYS b ON A.KEYS = b.newkeys
		WHERE  programcode = 'lmmTestStandardMaster'
			   AND a.plantcode = p_plantcode;

		IF (p_cnt = 0) THEN
			--시험규격 업데이트
			MERGE INTO TESTSTANDARDREVISION TG
			USING	   (SELECT A.TESTDIV
							  ,A.ITEMCODE
							  ,A.PROCESSCODE
							  ,B.STANDARDDIV
						FROM   TESTMANAGE A, VNITEMMASTER B
						WHERE  A.ITEMCODE = B.ITEMCODE
							   AND A.TESTMANAGEID = P_TESTMANAGEID
							   AND a.plantcode = p_plantcode) SRC
			ON		   (TG.TESTDIV = SRC.TESTDIV
						AND TG.ITEMCODE = SRC.ITEMCODE
						AND NVL(TG.PROCESSCODE, ' ') = NVL(SRC.PROCESSCODE, ' '))
			WHEN MATCHED THEN
				UPDATE SET TG.STANDARDDIV = SRC.STANDARDDIV;


			--전자서명 업데이트

			FOR REC IN (SELECT A.PROGRAMCODE
							  ,A.KEYS
							  ,A.REVISIONNO
							  ,A.SIGNSEQ
							  ,A.WORKSEQ
							  ,A.PLANTCODE
							  ,B.NEWKEYS
						FROM   ElectronicSignHistory A, VGT.TT_ACCEPTPICKORDER_TMPKEYS B
						WHERE  A.KEYS = B.KEYS
							   AND a.plantcode = p_plantcode)
			LOOP
				UPDATE ELECTRONICSIGNHISTORY
				SET    KEYS = REC.NEWKEYS
				WHERE  PROGRAMCODE = REC.PROGRAMCODE
					   AND KEYS = REC.KEYS
					   AND REVISIONNO = REC.REVISIONNO
					   AND SIGNSEQ = REC.SIGNSEQ
					   AND WORKSEQ = REC.WORKSEQ
					   AND PLANTCODE = REC.PLANTCODE;
			END LOOP;
		--         MERGE INTO ElectronicSignHistory TG
		--              USING (SELECT KEYS, NEWKEYS FROM VGT.TT_ACCEPTPICKORDER_TMPKEYS) SRC
		--                 ON (    TG.KEYS = SRC.KEYS
		--                     AND TG.programcode = 'lmmTestStandardMaster')
		--         WHEN MATCHED
		--         THEN
		--            UPDATE SET TG.KEYS = SRC.NEWKEYS;
		END IF;

		spAcceptPickOrder(p_div 		   => 'US2'
						 ,p_plantcode	   => p_plantcode
						 ,p_testmanageid   => p_testmanageid
						 ,p_userid		   => p_userid
						 ,p_reasondiv	   => p_reasondiv
						 ,p_reasontext	   => p_reasontext
						 ,MESSAGE		   => MESSAGE
						 ,IO_CURSOR 	   => IO_CURSOR);
	ELSIF (p_div = 'U') THEN
		SELECT COUNT(*)
		INTO   v_temp
		FROM   DUAL
		WHERE  ((SELECT testdiv
				 FROM	TestManage
				 WHERE	testmanageid = p_testmanageid
						AND plantcode = p_plantcode) IN ('08', '14', '15'));



		IF v_temp = 1 THEN
			MERGE INTO TESTMANAGE TG
			USING	   (SELECT TESTMANAGEID
							  ,C.TESTSTANDARDREVISIONID
						FROM   TESTMANAGE A
							   LEFT JOIN CMITEMM B ON A.ITEMCODE = B.ITEMCODE
							   LEFT JOIN VNTESTSTANDARDMASTER C
								   ON B.MITEMCODE = C.ITEMCODE
									  AND A.TESTDIV = C.TESTDIV
									  AND A.STANDARDTYPE = C.STANDARDDIV
									  AND A.PROCESSCODE = C.PROCESSCODE
						WHERE  A.TESTMANAGEID = P_TESTMANAGEID
							   AND a.plantcode = p_plantcode) SRC
			ON		   (TG.TESTMANAGEID = SRC.TESTMANAGEID)
			WHEN MATCHED THEN
				UPDATE SET TG.TESTNO = P_TESTNO
						  ,TG.REPORTPLANDATE = SUBSTR(P_REPORTPLANDATE, 0, 10)
						  ,TG.SAMPLINGEXPECTANT = P_SAMPLINGEXPECTANT
						  ,TG.RECEIVEDATE = P_RECEIVEDATE
						  ,TG.TESTORDERDATE = P_TESTORDERDATE
						  ,TG.TESTSTANDARDREVISIONID = SRC.TESTSTANDARDREVISIONID
                          ,TG.INFORMALTEST = p_informaltest
                          ,TG.SHADEYN = p_shadeyn
                          ,TG.MICROORGANISMTEST = p_microorganismtest
                          ,TG.KEEPINGCONTAINER = p_keepingcontainer
                          ,TG.KEEPINGTEMPERATURE = p_keepingtemperature
                          ,TG.CONTAINERTEST = p_containertest
                          ;
		ELSE
			--시험메인에 데이터를 등록한다.
			UPDATE TestManage
			SET    testno = p_testno
				  ,reportplandate = SUBSTR(P_REPORTPLANDATE, 0, 10)
				  ,samplingexpectant = p_samplingexpectant
				  ,receivedate = p_receivedate
				  ,testorderdate = p_testorderdate
				  ,teststandardrevisionid =
					   NVL((SELECT MAX(aa.teststandardrevisionid)
							FROM   TestStandardRevision aa
							WHERE  aa.itemcode = TestManage.itemcode
								   AND NVL(aa.processcode, ' ') = NVL(TestManage.processcode, ' ')
								   AND aa.useyn = 'Y'
								   AND aa.standarddiv = TestManage.standardtype
								   AND (CASE WHEN aa.testdiv = '09' THEN '09' ELSE aa.testdiv END) = TestManage.testdiv)
						  ,0)
                  ,informaltest = p_informaltest
                  ,shadeyn = p_shadeyn
                  ,microorganismtest = p_microorganismtest
                  ,keepingcontainer = p_keepingcontainer
                  ,keepingtemperature = p_keepingtemperature
                  ,containertest = p_containertest
			WHERE  testmanageid = p_testmanageid
				   AND plantcode = p_plantcode;
		END IF;

		DELETE TestMethodRecord
		WHERE  testmanageid = p_testmanageid
			   AND plantcode = p_plantcode;

		DELETE TestProgress
		WHERE  testmanageid = p_testmanageid
			   AND plantcode = p_plantcode;



		INSERT INTO TestProgress(
						testmanageid
					   ,teststandardrevisionid
					   ,standardmanageid
					   ,testprogressstatus
					   ,itemtester
					   ,testorderdt
					   ,testitemcode
					   ,searchseq
					   ,parentid
					   ,testseq
					   ,LEVEL_
					   ,compoundseq
					   ,groupcodediv
					   ,testbasis
					   ,testbasis2
					   ,resultdatadiv
					   ,testbasisdiv
					   ,minstandardvalue
					   ,MAXVALUE
					   ,minvalue2
					   ,maxvalue2
					   ,decimalciphernum
					   ,standarddiv
					   ,standardspendtime
					   ,standardtesttime
					   ,contentrateyn
					   ,equipmentcode
					   ,equipmenttesttime
					   ,testbasistype
					   ,resultunit
					   ,plantcode
					)
			(SELECT DISTINCT
					A.testmanageid
				   ,c.teststandardrevisionid
				   ,c.standardmanageid
				   ,'1' --생성 : 1, 시험완료 : 2
				   ,c.testeremployeecode
				   ,CASE WHEN c.groupcodediv = ('G') THEN NULL ELSE DECODE(A.receivedate, NULL, NULL, TO_CHAR((TO_DATE(receivedate, 'YYYY-MM-DD') + NVL(D.testspendtime, 0)), 'YYYY-MM-DD')) END col
				   ,c.testitemcode
				   ,c.searchseq
				   ,c.parentid
				   ,c.testseq
				   ,c.lvl
				   ,c.compoundseq
				   ,c.groupcodediv
				   ,c.testbasis
				   ,c.testbasis2
				   ,CASE WHEN NVL(c.resultdatadiv, '') IS NULL THEN 't' ELSE c.resultdatadiv END col
				   ,c.testbasisdiv
				   ,c.minstandardvalue
				   ,c.MAXVALUE
				   ,c.minvalue2
				   ,c.maxvalue2
				   ,c.decimalcipherno
				   ,D.standarddiv
				   ,c.standardspendtime
				   ,c.standardtesttime
				   ,c.contentrateyn
				   ,c.equipmentcode
				   ,c.equipmenttesttime
				   ,c.testbasistype
				   ,c.resultunit
				   ,p_plantcode
			 FROM	TestManage A
					JOIN TestStandardMaster c ON A.teststandardrevisionid = c.teststandardrevisionid
					JOIN TestItemMaster D ON c.testitemcode = D.testitemcode
			 WHERE	A.testmanageid = p_testmanageid
					AND a.plantcode = p_plantcode);

		IF (SQL%ROWCOUNT = 0) THEN
			IF (IO_CURSOR IS NULL) THEN
				OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
			END IF;


			RAISE user_define_error; -- STEP 2
		END IF;

		INSERT INTO TestMethodRecord(
						testmanageid
					   ,teststandardrevisionid
					   ,standardmanageid
					   ,methodmanageid
					   ,testmethodtext
					   ,plantcode
					)
			(SELECT A.testmanageid
				   ,c.teststandardrevisionid
				   ,c.standardmanageid
				   ,c.methodmanageid
				   ,c.testmethod
				   ,p_plantcode
			 FROM	TestManage A
					JOIN TestStandardMaster b ON A.teststandardrevisionid = b.teststandardrevisionid
					JOIN TestMethod c
						ON A.teststandardrevisionid = c.teststandardrevisionid
						   AND b.standardmanageid = c.standardmanageid
			 WHERE	A.testmanageid = p_testmanageid
					AND a.plantcode = p_plantcode);
	ELSIF (p_div = 'D') THEN
		OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
	ELSIF (p_div = 'US') THEN
		UPDATE TestManage
		SET    testprogressstatus = '04', receivedate = p_receivedate, testorderdate = TO_CHAR(SYSDATE + 1, 'YYYY-MM-DD') --우선은 오늘일자로 들어간다
		WHERE  testmanageid = p_testmanageid
			   AND plantcode = p_plantcode;
	ELSIF (p_div = 'CD') THEN
		-- 출퇴근시간에 대한 고려는 포함하지 않고 현시점에서 추가되는 시간에 대한
		-- 일자를 가져온다.
		FOR rec IN (SELECT TO_CHAR(SYSDATE + MAX(NVL(standardspendtime, 0)) / (24 * 60), 'YYYY-MM-DD') AS alias1
					FROM   TestStandardMaster
					WHERE  teststandardrevisionid = (SELECT A.teststandardrevisionid
													 FROM	TestManage A
													 WHERE	A.testmanageid = p_testmanageid)
						   AND plantcode = p_plantcode)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;
	ELSIF (p_div = 'Sl') THEN
		--UnderTestLabel 조회

		OPEN IO_CURSOR FOR
			SELECT A.itemcode
				  ,b.itemkorname itemname
				  ,A.testno
				  ,fnNumericToString(A.testrequestqty, 'S2') || NVL(h.divname, ' ') testrequestqty
				  ,c.custname manufacturename
				  ,A.productdate
				  ,'검체대상' samplingqty
				  ,A.validdate
				  ,A.testrequestremark
				  ,A.productno
				  ,D.processname
				  ,E.keepingmethod
				  ,f.divname keepingmethodname
				  ,A.testdiv
				  ,fnNumericToString(A.testrequestqty, 'S2') || ' g' packingqty --isnull(a.testrequestunit,'') as packingqty
			FROM   TestManage A
				   LEFT JOIN vnAllItemsLIMS b ON A.itemcode = b.itemcode
				   LEFT JOIN CMCUSTM c ON A.manufacturecode = c.custcode
				   LEFT JOIN ProcessMaster D ON A.processcode = D.processcode
				   LEFT JOIN MaterialsMaster E ON A.itemcode = E.itemcode
				   LEFT JOIN CMCOMMONM f
					   ON f.cmmcode = 'CMM30'
						  AND E.keepingmethod = f.divcode
				   LEFT JOIN CMCOMMONM G
					   ON G.cmmcode = 'CMM02'
						  AND A.samplingunit = G.divcode
				   LEFT JOIN CMCOMMONM h
					   ON h.cmmcode = 'CMM02'
						  AND A.testrequestunit = h.divcode
				   LEFT JOIN CMCOMMONM i
					   ON i.cmmcode = 'CMM02'
						  AND A.testrequestunit = i.divcode
			WHERE  A.testmanageid = p_testmanageid
				   AND a.plantcode = p_plantcode;
	--라벨인쇄용 (반제품)
	ELSIF (p_div = 'L2') THEN
		OPEN IO_CURSOR FOR
			SELECT A.itemcode --    품목코드
				  ,b.itemkorname --    품목명
				  ,A.productno lotno --    제조번호
				  ,A.productdate lotdate --  제조일자
				  ,A.testno --    시험의뢰번호
				  ,c.processname
				  ,fnNumericToString(A.testrequestqty, 'S') || A.testrequestunit testrequestqty
				  ,A.requestdate
				  ,A.testno rowbarcode
			FROM   TestManage A
				   LEFT JOIN MakingGoodsMaster b ON A.itemcode = b.itemcode
				   LEFT JOIN ProcessMaster c ON A.processcode = c.processcode
			WHERE  A.testmanageid = p_testmanageid
				   AND a.plantcode = p_plantcode;
	--라벨인쇄용 (원자재)
	ELSIF (p_div = 'L3') THEN
		FOR rec IN (SELECT f.divname AS alias1
					FROM   Warehousing A
						   JOIN nvItemRM b ON A.itemcode = b.itemcode
						   LEFT JOIN CMCOMMONM f
							   ON f.cmmcode = 'CMM02'
								  AND f.divcode = b.itemunit
					WHERE  warehousingno = p_warehousingno
						   AND a.plantcode = p_plantcode)
		LOOP
			p_unitname := rec.alias1;
		END LOOP;

		FOR rec IN (SELECT	 fnNumericToString(packwarehouseqty, 'S') || p_unitname || ' X ' || COUNT(packwarehouseqty) || 'EA' AS alias1
					FROM	 WarehousingDetail
					WHERE	 Warehousingno = p_Warehousingno
							 AND plantcode = p_plantcode
					GROUP BY packwarehouseqty
					HAVING	 COUNT(packwarehouseqty) > 1)
		LOOP
			p_totalwarehousingqty := rec.alias1;
		END LOOP;

		FOR rec IN (SELECT	 p_totalwarehousingqty || ' + ' || fnNumericToString(packwarehouseqty, 'S') || p_unitname AS alias1
					FROM	 WarehousingDetail
					WHERE	 Warehousingno = p_Warehousingno
							 AND plantcode = p_plantcode
					GROUP BY packwarehouseqty
					HAVING	 COUNT(packwarehouseqty) = 1)
		LOOP
			p_totalwarehousingqty := rec.alias1;
		END LOOP;

		OPEN IO_CURSOR FOR
			SELECT A.itemcode --    품목코드
				  ,b.itemname itemkorname --    품목명
				  ,A.lotno --    제조번호
				  ,A.lotdate -- 제조일자
				  ,A.validityperiod -- 사용기한
				  ,TO_CHAR(A.warehousingdt, 'YYYY-MM-DD') warehousingdt -- 입고일자
				  ,A.testno --    시험의뢰번호
				  ,G.custname --제조처
				  ,fnNumericToString(c.packwarehouseqty, 'S') || p_unitname packwarehouseqty -- 수량
				  , --,h.divname as keepingmethod                    -- 보관법
				   c.rowbarcode
				  ,c.warehousingpackseq -- 용기번호
				  ,(SELECT COUNT(warehousingpackseq)
					FROM   WarehousingDetail
					WHERE  warehousingno = A.warehousingno)
					   totalpackseq
				  ,c.sampleobjcheck
				  ,A.Warehousingno
				  ,p_totalwarehousingqty totalwarehousingqty
			FROM   Warehousing A
				   LEFT JOIN CMITEMM b ON A.itemcode = b.itemcode
				   LEFT JOIN CMCOMMONM f
					   ON f.cmmcode = 'CMM02'
						  AND f.divcode = b.itemunit
				   JOIN WarehousingDetail c ON A.warehousingno = c.warehousingno
				   LEFT JOIN CMCUSTM G ON A.manufacturecode = G.custcode
			WHERE  c.rowbarcode = p_rowbarcode
				   AND a.plantcode = p_plantcode;
	ELSIF (p_div = 'L4') THEN
		FOR rec IN (SELECT f.divname AS alias1
					FROM   Warehousing A
						   JOIN nvItemRM b ON A.itemcode = b.itemcode
						   LEFT JOIN CMCOMMONM f
							   ON f.cmmcode = 'CMM02'
								  AND f.divcode = b.itemunit
					WHERE  warehousingno = p_warehousingno
						   AND a.plantcode = p_plantcode)
		LOOP
			p_unitname1 := rec.alias1;
		END LOOP;

		FOR rec IN (SELECT	 fnNumericToString(packwarehouseqty, 'S') || p_unitname1 || ' X ' || COUNT(packwarehouseqty) || 'EA' AS alias1
					FROM	 WarehousingDetail
					WHERE	 Warehousingno = p_Warehousingno
							 AND plantcode = p_plantcode
					GROUP BY packwarehouseqty
					HAVING	 COUNT(packwarehouseqty) > 1)
		LOOP
			p_totalwarehousingqty1 := rec.alias1;
		END LOOP;

		FOR rec IN (SELECT	 p_totalwarehousingqty1 || ' + ' || fnNumericToString(packwarehouseqty, 'S') || p_unitname1 AS alias1
					FROM	 WarehousingDetail
					WHERE	 Warehousingno = p_Warehousingno
							 AND plantcode = p_plantcode
					GROUP BY packwarehouseqty
					HAVING	 COUNT(packwarehouseqty) = 1)
		LOOP
			p_totalwarehousingqty1 := rec.alias1;
		END LOOP;

		OPEN IO_CURSOR FOR
			SELECT A.itemcode --    품목코드
				  ,b.itemkorname --    품목명
				  ,A.lotno --    제조번호
				  ,A.lotdate -- 제조일자
				  ,A.validityperiod -- 사용기한
				  ,TO_CHAR(A.warehousingdt, 'YYYY-MM-DD') warehousingdt -- 입고일자
				  ,A.testno --    시험의뢰번호
				  ,G.custname --제조처
				  ,fnNumericToString(c.packwarehouseqty, 'S') || p_unitname1 packwarehouseqty -- 수량
				  ,c.rowbarcode
				  ,c.warehousingpackseq -- 용기번호
				  ,(SELECT COUNT(warehousingpackseq)
					FROM   WarehousingDetail
					WHERE  warehousingno = A.warehousingno)
					   totalpackseq
				  ,c.sampleobjcheck
				  ,A.Warehousingno
				  ,p_totalwarehousingqty1 totalwarehousingqty
			FROM   Warehousing A
				   LEFT JOIN nvItemMaster b ON A.itemcode = b.itemcode
				   LEFT JOIN CMCOMMONM f
					   ON f.cmmcode = 'CMM02'
						  AND f.divcode = b.itemunit
				   JOIN WarehousingDetail c ON A.warehousingno = c.warehousingno
				   LEFT JOIN CMCUSTM G ON A.manufacturecode = G.custcode
				   LEFT JOIN vnStockRMAll h ON A.retestno = h.testno
			WHERE  c.rowbarcode = p_rowbarcode
				   AND a.plantcode = p_plantcode;
                   
    ELSIF (p_div = 'DS') THEN --보관조건, 보관온도, 미생물시험, 약식시험 조회
        OPEN IO_CURSOR FOR
            SELECT  KEEPINGMETHOD       --보관조건
            ,       KEEPINGTEMPERATURE  --보관온도  
            ,       MGTEST             --미생물시험
            ,       INFORMALTEST        --약식시험
            ,       NVL(CONTAINERTEST, 'N')  CONTAINERTEST      --전용기확인시험
              FROM  CMITEMM
             WHERE  ITEMCODE = p_itemcode;            
--            WHERE   PLANTCODE = p_plantcode
--              AND   ITEMCODE = p_itemcode;
    
    ELSIF (p_div = 'LKN1')
    THEN
        OPEN IO_CURSOR FOR
            SELECT A.testmanageid,
                   NVL(A.testdiv, ' ') testdiv,
                   LMM04.divname testdivname,
                   'CERTIFICATE OF ANALYSIS' testeng,
                   CASE
                       WHEN A.testdiv = '04'
                            AND c.packingunitqty > 1
                       THEN
                           c.itemkorname || LPAD(' ', 1, ' ') || fnNumericToString(c.packingunitqty, 'S') || c.itemunit
                       ELSE
                           c.itemkorname
                   END
                       itemkorname,
                   LMM06.divname standarddivname,
                   A.testno,
                   A.testrequestno,
                   A.requestdate,
                   D.deptname requestdeptname,
                      fnNumericToString(A.testrequestqty, 'S')
                   || NVL((CASE WHEN c.itemdiv IN ('01', '02') THEN c.itemunit WHEN c.itemdiv = '03' THEN CASE WHEN A.processcode = 'MG300' THEN c.itemunit ELSE c.transunit END ELSE CMM02B.divname END), '')
                   || NVL(' / ' || (CASE WHEN NVL(A.testrequestea, 0) = 0 THEN NULL ELSE fnNumericToStringN(A.testrequestea, 'S') || NVL(CMM02B.divname, '') END), '')
                       testrequestqty,
                   e1.custname manufacturename,
                   e2.custname custname,
                   NVL(A.productno, '') lotno,
                   A.productdate lotdate,
                   A.validdate,
                   CASE WHEN A.testdiv = '06' THEN A.processcode ELSE A.itemcode END itemcode,
                   c.keepingmethod,
                   MPM11.divname samplingroom,
                   fnNumericToString(NVL(A.samplingqty, 0) + NVL(A.samplingqty2, 0) + NVL(A.samplingqty3, 0), 'S') || NVL(CMM02.divname, '') samplingqty,
                   (SELECT empname
                    FROM   CMEMPM
                    WHERE  empcode = A.samplingexpectant)
                       samplingemp,
                   A.testorderdate,
                   A.samplingdate,
                   A.receivedate,
                   (SELECT empname
                    FROM   CMEMPM
                    WHERE  empcode = h.signempcode)
                       receiveempname,
                   A.testresultcode, --적부여부 필수
                   A.receivedate workerdt,
                   A.testconfirmdate confirmdt,
                   A.testdate confirmdt2,
                   '' docno,
                   P.processname,
                   c.batchsizename || c.itemunit BATCHSIZE,
                   A.testresultremark,
                   e1.addr1 addr1
                   ,fnCommonNM('comm', 'CMM70', f.keepingmethod) keepingmethod              --보관조건
                   ,fnCommonNM('comm', 'CMM71', f.keepingtemperature) keepingtemperature      --보관온도
                   ,f.mgtest                                                              --미생물시험
                   ,fnCommonNM('emp', '', A.REQUESTEMPCODE) REQUESTEMPNAME                   --요청자
                   ,f.itemunit                                                            --포장(납품)단위
                   ,fnCommonNM('comm', 'CMM58', a.fasttestdiv) testtype                            --우선순위
            FROM   TestManage A
                   JOIN CMITEMM F ON A.ITEMCODE = F.ITEMCODE
                   LEFT JOIN vnAllItemsLIMS c ON A.itemcode = c.itemcode
                   LEFT JOIN CMCOMMONM LMM04 --시험종류
                       ON LMM04.cmmcode = 'LMM04'
                          AND LMM04.divcode = A.testdiv
                   LEFT JOIN CMCOMMONM CMM02
                       ON CMM02.cmmcode = 'CMM02'
                          AND CMM02.divcode = A.samplingunit
                   LEFT JOIN CMCOMMONM CMM02B
                       ON CMM02B.cmmcode = 'CMM02'
                          AND CMM02B.divcode = A.testrequestunit
                   LEFT JOIN CMCOMMONM LMM06 --시험규격
                       ON LMM06.cmmcode = 'LMM06'
                          AND LMM06.divcode = c.standarddiv
                   LEFT JOIN CMDEPTM D ON A.requestdeptcode = D.deptcode
                   LEFT JOIN CMCUSTM e1 ON A.manufacturecode = e1.custcode
                   LEFT JOIN CMCUSTM e2 ON A.custcode = e2.custcode
                   LEFT JOIN CMCOMMONM MPM11 --검체장소
                       ON MPM11.cmmcode = 'MPM11'
                          AND MPM11.divcode = A.samplingroom
                   LEFT JOIN ElectronicSignHistory h
                       ON h.programcode = 'lmnAcceptPickOrder'
                          AND h.KEYS = A.testmanageid
                          AND h.signseq = 1
                          AND h.STATUS = '03'
                   LEFT JOIN ProcessMaster P ON A.processcode = P.processcode
            WHERE  A.testmanageid = p_testmanageid;
--                   AND a.plantcode = p_plantcode;                       
	END IF;

	IF (IO_CURSOR IS NULL) THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
EXCEPTION -- 예외가 발생할 경우 해당 예외를 참조한다.
	WHEN user_define_error THEN -- STEP 3
		IF (IO_CURSOR IS NULL) THEN
			OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
		END IF;

		RAISE_APPLICATION_ERROR(-20000, '시험규격 등록상태를 확인하십시오.!!');
END;
/
