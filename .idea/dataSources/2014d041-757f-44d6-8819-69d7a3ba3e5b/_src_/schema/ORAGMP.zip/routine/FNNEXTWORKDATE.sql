CREATE FUNCTION fnNextWorkDate(
    p_basedate IN DATE DEFAULT NULL
)
	RETURN DATE
AS
	ip_basedate	 DATE;
    p_val		 VARCHAR2(10);
BEGIN
	IF p_basedate IS NULL THEN
    	ip_basedate := TO_DATE(SYSDATE);
    ELSE
    	ip_basedate := p_basedate;
    END IF;

	FOR rec IN (SELECT calymd
				FROM   (SELECT *
						FROM   (SELECT	 calymd
								FROM	 PSCALM a
										 JOIN CMCOMMONM b
											 ON b.cmmcode = 'PS06'
												AND a.caldiv = b.divcode
												--AND b.filter1 = 'W'
								WHERE	 plantcode = (SELECT MIN(plantcode) FROM CMPLANTM)
										 AND TO_CHAR(ip_basedate, 'YYYY-MM-DD') <= calymd
								ORDER BY calymd ASC)
						WHERE  ROWNUM <= 1))
	LOOP
    	p_val := rec.calymd;
	END LOOP;

	RETURN (TO_DATE(p_val,'YYYY-MM-DD'));
EXCEPTION
	WHEN OTHERS
	THEN
		RETURN NULL;
END;
/
