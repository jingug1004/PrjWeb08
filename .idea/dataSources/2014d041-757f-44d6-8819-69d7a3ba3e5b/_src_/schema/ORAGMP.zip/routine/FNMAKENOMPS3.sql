CREATE FUNCTION        fnMakeNoMPS3
-- ---------------------------------------------------------------
 -- 함 수 명			: fnMakeNo
 -- 작 성 자         : 최인범
 -- 작성일자         : 2007-10-25
 --수 정 자         : 임정호
 -- 수정일         : 2017-01-11
  -- ---------------------------------------------------------------
 -- 함수설명			: 전표번호 생성
 -- ---------------------------------------------------------------

(
  p_div IN VARCHAR2 DEFAULT ' ' ,
  p_itemcode IN VARCHAR2 DEFAULT ' ' ,
  p_pitemcode IN VARCHAR2 DEFAULT ' ' ,
  p_makedate IN VARCHAR2 DEFAULT ' ' ,
  p_plantcode IN VARCHAR2 DEFAULT ' ' 
)
RETURN VARCHAR2
AS
   p_tostring VARCHAR2(20);
   p_templotno VARCHAR2(2);

BEGIN
    IF ( p_div = 'lotno' ) THEN

        p_templotno := SUBSTR(p_makedate, 3, 2) ;-- 실제 제조지시일 항목이 사용
        
        FOR  rec IN 
        ( 
            SELECT  p_templotno || DECODE (lotno,NULL,'001', LPAD(TO_NUMBER(SUBSTR(lotno,3,3))+1,3,'0')  ) AS alias1
            FROM    ( 
                        SELECT  MAX(A.lotno)  lotno  
                        FROM    ( 
                                    SELECT  lotno 
                                    FROM    MakingOrders 
                                    WHERE   SUBSTR(lotno, 0, 2) = p_templotno
                                        AND itemcode = p_itemcode
                                        AND orderdiv NOT IN ( '05','06' )
                                    UNION 
                                    SELECT  lotno 
                                    FROM    ProductPlan 
                                    WHERE   SUBSTR(lotno, 0, 2) = p_templotno
                                        AND itemcode = p_pitemcode 
                                ) A 
                    ) A
        ) 
        LOOP
            p_tostring := rec.alias1   ;
        END LOOP;
    ELSE
        p_tostring := ' ' ;
    END IF;

    RETURN (p_tostring);

    EXCEPTION WHEN OTHERS THEN RETURN NULL;
    
    
END;
/
