CREATE PROCEDURE        col_Sal_Day_Conversion_Call
-- ---------------------------------------------------------------
-- 프로시저명        :
-- 작 성 자          :
-- 작성일자          :
-- ---------------------------------------------------------------
-- 프로시저 설명     : 가 오픈 시 사용하는 주문,수금 자료 생성 프로시저이다
--                가상계좌수금 과 전자어음은 별도로 반영되므로 여기서 생성하지 않음
-- ---------------------------------------------------------------
(
   p_div                IN    VARCHAR2 DEFAULT '',
   p_startdate           IN    VARCHAR2 DEFAULT '',
   p_enddate            IN    VARCHAR2 DEFAULT ''
)
AS

   p_plantcode                VARCHAR2(30);
   p_coldate                  VARCHAR2(30);
   p_coldiv                   VARCHAR2(30);
   p_coldtldiv                VARCHAR2(30);
   p_orderdiv                 VARCHAR2(30);
   p_tasooyn                  VARCHAR2(30);
   p_custcode                 VARCHAR2(30);
   p_deptcode                 VARCHAR2(30);
   p_empcode                  VARCHAR2(30);
   p_ecustcode                VARCHAR2(30);
   p_edeptcode                VARCHAR2(30);
   p_eempcode                 VARCHAR2(30);
   p_colamt                   FLOAT := 0;
   p_colvat                   FLOAT := 0;
   p_accountno                VARCHAR2(30);
   p_billno                   VARCHAR2(30);
   p_issdate                  VARCHAR2(30);
   p_expdate                  VARCHAR2(30);
   p_paybank                  VARCHAR2(30);
   p_paybankbr                VARCHAR2(30);
   p_issempnm                 VARCHAR2(30);
   p_baeseo                   VARCHAR2(30);
   p_cardcomp                 VARCHAR2(30);
   p_cardno                   VARCHAR2(50);
   p_cardokno                 VARCHAR2(30);
   p_carddate                 VARCHAR2(30);
   p_divmonth                 FLOAT := 0;
   p_autoyn                   VARCHAR2(30);
   p_appdate                  VARCHAR2(30);
   p_discntdate               VARCHAR2(30);
   p_custprtyn                VARCHAR2(30);
   p_remark                   VARCHAR2(30);
   p_apprstatus               VARCHAR2(30);
   p_moneycode                VARCHAR2(30);
   p_exrtrate                 FLOAT := 0;
   p_exrtamt                  FLOAT := 0;
   p_iempcode                 VARCHAR2(30);

   p_bill_gb                  VARCHAR2(10);

   v_spSLSALERESULT_N_param   VARCHAR2(256);

BEGIN
--    IF(p_div = 'COL')
--    THEN
--        FOR rec IN (
--                        SELECT IN_DATE
--                        FROM (
--                                    SELECT TO_CHAR(TO_DATE(p_startdate, 'YYYY-MM-DD') + LEVEL - 1, 'YYYY-MM-DD') AS IN_DATE
--                                        FROM   DUAL CONNECT BY LEVEL <= TO_DATE(p_enddate, 'YYYY-MM-DD') - TO_DATE(p_startdate, 'YYYY-MM-DD') + 1
--                                )
--                    )
--        LOOP
--            ORAGMP.col_Sal_Day_Conversion_loop(
--                                            p_ymd => rec.IN_DATE
--                                            );
--        END LOOP;

    IF(p_div = 'MIDORAE')
    THEN
        FOR rec IN (
                        SELECT IN_DATE
                        FROM (
                                    SELECT TO_CHAR(TO_DATE(p_startdate, 'YYYY-MM-DD') + LEVEL - 1, 'YYYY-MM-DD') AS IN_DATE
                                        FROM   DUAL CONNECT BY LEVEL <= TO_DATE(p_enddate, 'YYYY-MM-DD') - TO_DATE(p_startdate, 'YYYY-MM-DD') + 1
                                )
                    )
        LOOP
            MERGE INTO SLRESULTM A
            USING      (
                             SELECT SUBSTR(rec.IN_DATE, 1, 7)                YEARMONTH,
                                    B.CUST_ID                CUSTCODE,
                                    B.RCUST_ID               ECUSTCODE,
                                    SUM(CASE WHEN A.BILL_GB IN ('010','020','030') THEN A.AMT ELSE 0 END) AS JASUAMT, --자수어음
                                    SUM(CASE WHEN A.BILL_GB IN ('025','035','040') THEN A.AMT ELSE 0 END) AS TASUAMT  --타수어음
                               FROM SALE.SALE0402 A,
                                    SALE.SALE0401 B,
                                    SALE.SALE0001 C
                              WHERE A.JUNPYO_NO = B.JUNPYO_NO
                                AND A.YMD       = B.YMD
                                AND C.CODE_GB   = '0007'
                                AND A.BILL_GB   = C.CODE1
                                AND C.CODE1 NOT IN ('100','101','102')                 --신용카드,압인카드,수기카드
                                AND TO_CHAR(A.END_YMD,'YYYY-MM-DD')   >= rec.IN_DATE  --어음만기일
                                AND TO_CHAR(A.YMD    ,'YYYY-MM-DD')   <  rec.IN_DATE  --입력일자
                           GROUP BY B.CUST_ID, B.RCUST_ID
                        ) B
            ON          (
                            A.YEARMONTH = B.YEARMONTH
                        AND A.CUSTCODE = B.CUSTCODE
                        AND A.ECUSTCODE = B.ECUSTCODE
                        )
            WHEN MATCHED THEN
            UPDATE SET  A.PENDBILLCOL = (B.JASUAMT + B.TASUAMT)
            ,           A.PENDBILLCOLJ = B.JASUAMT
            ,           A.PENDBILLCOLT = B.TASUAMT;
        END LOOP;

    ELSIF(p_div = 'MAGAM')
    THEN
        FOR rec IN (
                        SELECT IN_DATE
                        FROM (
                                    SELECT TO_CHAR(TO_DATE(p_startdate, 'YYYY-MM-DD') + LEVEL - 1, 'YYYY-MM-DD') AS IN_DATE
                                        FROM   DUAL CONNECT BY LEVEL <= TO_DATE(p_enddate, 'YYYY-MM-DD') - TO_DATE(p_startdate, 'YYYY-MM-DD') + 1
                                )
                    )
        LOOP
            ORAGMP.spSLSALERESULT_M_LOOP(
                                        p_plantcode => '1000'
                                     ,  p_orderdate => rec.IN_DATE
                                     ,  p_iempcode => 'gmpit'
                                    );
        END LOOP;
        
    ELSIF(p_div = 'NC')
    THEN
        FOR rec IN (
                        SELECT CUSTCODE, ECUSTCODE
                          FROM vnCols
                        WHERE (('Y' = 'Y' AND expdate >= '2018-02-01')
                              AND ('Y' = 'Y' AND orderdate <= '2018-02-01')
                              OR   'Y' = 'N' AND 'Y' = 'N')
                              AND plantcode LIKE '%'
                              AND statediv = '09'
                              AND coldiv LIKE '3%'
                              AND tasooyn LIKE '%'
                              GROUP BY CUSTCODE, ECUSTCODE
                    /*
                     SELECT CUSTCODE
                     ,      ECUSTCODE
                       FROM SLRESULTM 
                      WHERE YEARMONTH = '2018-01'
                        AND CUSTCODE = '1110174'
                   GROUP BY CUSTCODE, ECUSTCODE 
                   */
                    )
        LOOP
            spSLSALERESULT_N_NC (p_div         => 'M',
                                 p_plantcode   => '1000',
                                 p_orderdate   => TO_CHAR(SYSDATE, 'YYYY-MM-DD'),
                                 p_iempcode    => 'cvs',
                                 p_custcode    => rec.custcode,
                                 p_ecustcode   => rec.ecustcode,
                                 p_deptcode    => '',
                                 p_userid      => '',
                                 p_reasondiv   => '',
                                 p_reasontext  => '',
                                 MESSAGE       => v_spSLSALERESULT_N_param);
        END LOOP;
    END IF;
END;
/
