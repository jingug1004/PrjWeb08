CREATE FUNCTION fnGetColDeptCode
-- ---------------------------------------------------------------
 -- 함 수 명            : fnGetColDeptCode
 -- 작 성 자         : 최용석
 -- 작성일자         : 2015-04-22
 -- ---------------------------------------------------------------
 -- 함수설명            : 수금부서 설정
 -- ---------------------------------------------------------------

(
  p_deptcode IN VARCHAR2 DEFAULT ''
)
RETURN VARCHAR2
AS
   p_returnresult VARCHAR2(20) := '';

BEGIN
   --if @deptcode like '006%'        -- 해외사업팀
   --begin
   --    set @returnresult = '006001'
   --end
   --else if @deptcode like '008%'    -- CA사업팀
   --begin
   --    set @returnresult = '008001'
   --end
   --else
   --begin
   --    set @returnresult = '005001'
   --end

   RETURN (p_returnresult);

--EXCEPTION WHEN OTHERS THEN utils.handleerror(SQLCODE,SQLERRM);
END;
/
