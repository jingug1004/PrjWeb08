CREATE PROCEDURE        spACbase0110P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbase0110P
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-07-06
	-- 수정일자     :   노영래
	-- E-mail     :   0rae0926@gmail.com
	-- 수정일자     :   2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 관리항목마스터를 등록,수정,삭제,조회하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			IN	   VARCHAR2 DEFAULT '',
	p_mngclucode	IN	   VARCHAR2 DEFAULT '',
	p_mngcluname	IN	   VARCHAR2 DEFAULT '',
	p_mngcludiv 	IN	   VARCHAR2 DEFAULT '',
	p_codehelp		IN	   VARCHAR2 DEFAULT '',
	p_sysuseyn		IN	   VARCHAR2 DEFAULT '',
	p_remark		IN	   VARCHAR2 DEFAULT '',
	p_iempcode		IN	   VARCHAR2 DEFAULT '',
	p_filter1		IN	   VARCHAR2 DEFAULT '',
	p_filter2		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	IF (UPPER(P_DIV) = 'S') THEN
		OPEN IO_CURSOR FOR
			SELECT NVL(A.mngclucode, '') mngclucode,
				   NVL(A.mngcluname, '') mngcluname,
				   NVL(A.mngcludiv, '') mngcludiv,
				   NVL(A.codehelp, '') codehelp,
				   NVL(A.sysuseyn, '') sysuseyn,
				   NVL(A.remark, '') remark,
				   A.insertdt insertdt,
				   NVL(A.iempcode, '') iempcode,
				   A.updatedt updatedt,
				   NVL(A.uempcode, '') uempcode,
				   NVL(B.filter1, '') filter1
			FROM   ACMNGM A
				   LEFT JOIN CMCOMMONM B
					   ON codehelp = B.divcode
						  AND UPPER(B.cmmcode) = 'CMHL'
			WHERE  NVL(UPPER(mngclucode), ' ') LIKE UPPER(p_mngclucode) || '%'
				   OR NVL(UPPER(mngcluname), ' ') LIKE UPPER(p_mngclucode) || '%'
            ORDER BY mngclucode ;


	-- 키중복체크
	ELSIF (UPPER(P_DIV) = 'SC') THEN
		FOR rec IN (SELECT COUNT(mngclucode) AS alias1
					FROM   ACMNGM
					WHERE  mngclucode = p_mngclucode)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;

	ELSIF (UPPER(P_DIV) = 'SD') THEN
		MESSAGE := '';

		FOR rec IN (SELECT COUNT(mngclucode) AS alias1
					FROM   ACORDS
					WHERE  mngclucode = p_mngclucode)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;

		IF (NVL(MESSAGE, '0') <> '0') THEN
			MESSAGE := '관리항목코드가 회계전표관리항목내역에서 사용중입니다.' || CHR(13) || CHR(10) || '삭제 및 수정이 제한됩니다.';
		ELSE
			FOR rec IN (SELECT COUNT(mngclucode) AS alias1
						FROM   ACACCMNGM
						WHERE  mngclucode = p_mngclucode)
			LOOP
				MESSAGE := rec.alias1;
			END LOOP;

			IF (NVL(MESSAGE, '0') <> '0') THEN
				MESSAGE := '관리항목코드가 계정별관리항목마스터에서 사용중입니다.' || CHR(13) || CHR(10) || '삭제 및 수정이 제한됩니다.';
			ELSE
				IF (NVL(MESSAGE, '0') <> '0')
				THEN
					MESSAGE := '관리항목코드가 회계전표관리항목월집계에서 사용중입니다.' || CHR(13) || CHR(10) || '삭제 및 수정이 제한됩니다.';
				ELSE
					MESSAGE := '';
				END IF;
			END IF;
		END IF;

	--코드헬프번호 검색(DBcolumn)
	ELSIF (UPPER(P_DIV) = 'S2') THEN
		OPEN IO_CURSOR FOR
			SELECT filter1, filter2, divcode
			FROM   CMCOMMONM
			WHERE  cmmcode = 'CMHL'
				   AND divcode = p_codehelp;

	ELSIF (UPPER(P_DIV) = 'I') THEN
		INSERT INTO ACMNGM(mngclucode,
						   mngcluname,
						   mngcludiv,
						   codehelp,
						   sysuseyn,
						   remark,
						   insertdt,
						   iempcode)
		VALUES		(p_mngclucode,
					 p_mngcluname,
					 p_mngcludiv,
					 p_codehelp,
					 p_sysuseyn,
					 p_remark,
					 SYSDATE,
					 p_iempcode);

	ELSIF (UPPER(P_DIV) = 'U') THEN
		UPDATE ACMNGM
		SET    mngcluname = p_mngcluname,
			   mngcludiv = p_mngcludiv,
			   codehelp = p_codehelp,
			   sysuseyn = p_sysuseyn,
			   remark = p_remark,
			   updatedt = SYSDATE,
			   uempcode = p_iempcode
		WHERE  mngclucode = p_mngclucode;

	ELSIF (UPPER(P_DIV) = 'D') THEN
		DELETE ACMNGM
		WHERE  mngclucode = p_mngclucode;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
