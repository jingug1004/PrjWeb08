CREATE PROCEDURE spACacc0030P
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0030P
-- 작 성 자         : 최용석
-- 작성일자         : 2012-11-08
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2016-12-13
-- ---------------------------------------------------------------
-- 프로시저 설명    : 카드매출정산을 관리하는 프로시저이다.
-- ---------------------------------------------------------------
(
    p_div			      IN VARCHAR2 DEFAULT '',

    p_compcode		  IN VARCHAR2 DEFAULT '',
    p_strdate		    IN VARCHAR2 DEFAULT '',
    p_enddate		    IN VARCHAR2 DEFAULT '',
    p_viewdiv		    IN VARCHAR2 DEFAULT '',
    p_cardcomp		  IN VARCHAR2 DEFAULT '%',
    p_plantcode 	  IN VARCHAR2 DEFAULT '',
    p_slipdate		  IN VARCHAR2 DEFAULT '',
    p_iempcode		  IN VARCHAR2 DEFAULT '',
    p_slipinno		  IN VARCHAR2 DEFAULT '',
    p_slipinseq	    IN NUMBER   DEFAULT 0,
    p_rpyslipinno	  IN VARCHAR2 DEFAULT '',
    p_rpyslipinseq	IN NUMBER   DEFAULT 0,
    p_feeamt		    IN FLOAT    DEFAULT 0,
    p_accountno 	  IN VARCHAR2 DEFAULT '',
    p_userid		    IN VARCHAR2 DEFAULT '',
    p_reasondiv 	  IN VARCHAR2 DEFAULT '',
    p_reasontext	  IN VARCHAR2 DEFAULT '',

    MESSAGE 		    OUT VARCHAR2,
    IO_CURSOR		    OUT TYPES.DataSet
)
AS
    ip_slipinseq 	  NUMBER := p_slipinseq;
    p_acccode		    VARCHAR2(20);
    p_acautorcode	  VARCHAR2(10);
    p_colautorcode	VARCHAR2(10);
    p_slipdiv		    VARCHAR2(5);
    p_deptcode		  VARCHAR2(20);
    p_remark		    VARCHAR2(100);
    p_slipnum       VARCHAR2(5);
    p_slipno        VARCHAR2(20);
    v_temp          NUMBER := 0;
    p_totamt        FLOAT(53);

BEGIN

    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    p_acautorcode := 'A04040';
    p_colautorcode := 'C01002';
    for rec in (
        select  accdiv
               ,remark2
        from    ACAUTORULE
        where   acautorcode = p_acautorcode)
    loop
        p_slipdiv := rec.accdiv;
        p_remark  := rec.remark2;
    end loop;

    for rec in (
        select  deptcode
        from    CMEMPM
        where   empcode = p_iempcode)
    loop
        p_deptcode := rec.deptcode;
    end loop;

    if (p_div = 'S') then
        p_acccode := '11108040';
        for rec in (
            select  filter1
            from    CMCOMMONM
            where   cmmcode = 'AC261'
                    and divcode = '11108040')
        loop
            p_acccode := rec.filter1;
        end loop;

        open IO_CURSOR for
        with TT_ACAUTOORDT as
        (
            select  a.cardno,
                    a.cardokno,
                    a.trn1amt amt,
                    a.custcode,
                    a.userdef6code custname,
                    d.businessno,
                    b.slipdate,
                    b.slipnum,
                    b.slipinno,
                    b.slipinseq
            from    ACAUTOORDT a
                    join ACORDD b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
                        and a.trn1amt = b.debamt
                        and b.acccode = p_acccode
                        and b.slipdate between to_char(add_months(to_date(p_strdate, 'yyyy-mm-dd'), -1), 'yyyy-mm-dd') and to_char(add_months(to_date(p_enddate, 'yyyy-mm-dd'), 1), 'yyyy-mm-dd')
                    left join CMCUSTM d
                        on a.custcode = d.custcode
            where   a.compcode = p_compcode
                    and a.acattype = 'C'
                    and a.acatrulecode = p_colautorcode
        ) --with end
        select  'N' seldiv,
                a.ipgumdate,
                a.trdate,
                a.amt,
                a.custcode,
                a.custname,
                a.businessno,
                a.cardno,
                a.appno,
                a.custname,
                a.cardcode,
                a.cardname,
                a.slipdate,
                a.slipnum,
                a.slipinno,
                a.slipinseq,
                b.rpyslipinno,
                0 feeamt,
                a.amt realamt,
                c.slipdate rpydate,
                c.slipnum rpynum
        from (
            select  substr(trim(a.ipgumdate), 1, 4) || '-' || substr(trim(a.ipgumdate), 5, 2) || '-' || substr(trim(a.ipgumdate), 7, 2) as ipgumdate,
                    a.cardno,
                    substr(trim(a.trdate), 1, 4) || '-' || substr(trim(a.trdate), 5, 2) || '-' || substr(trim(a.trdate), 7, 2) as trdate,
                    a.appno,
                    a.amt,
                    b.slipdate,
                    b.slipnum,
                    b.slipinno,
                    b.slipinseq,
                    b.custcode,
                    b.custname,
                    b.businessno,
                    d.divcode cardcode,
                    a.acq_card_cd cardname
            from    IBKDB_CSM_MS_TRAN a
                    left join TT_ACAUTOORDT b
                        on substr(replace(a.cardno, '-', ''), 0, 8) = substr(replace(b.cardno, '-', ''), 0, 8)
                        and substr(a.cardno, - length(a.cardno) - 12, length(a.cardno) - 12) = substr(b.cardno, -length(a.cardno) - 12, length(a.cardno) - 12)
                        and a.appno = b.cardokno
                        and a.amt = b.amt
                    left join CMCOMMONM c
                        on c.cmmcode = 'AC17'
                        and substr(a.acq_card_cd, -2, 2) = c.filter2
                    left join CMCOMMONM d
                        on c.hcmmcode = d.cmmcode
                        and c.hdivcode = d.divcode
            where   a.ipgumdate between replace(p_strdate, '-', '') and replace(p_enddate, '-', '')
                    and (p_cardcomp = '%' or a.acq_card_cd like '%' || (select  divname
                                                                        from    CMCOMMONM
                                                                        where   cmmcode = 'AC171'
                                                                                and divcode = p_cardcomp) || '%')
        ) a
                left join ACORDRPYP b
                    on b.compcode = p_compcode
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
                left join ACORDM c
                    on b.compcode = c.compcode
                    and b.rpyslipinno = c.slipinno
        where   (p_viewdiv = 0 or p_viewdiv = 1 and b.compcode is not null or p_viewdiv = 2 and b.compcode is null)
        order by a.ipgumdate, a.trdate, a.cardno, a.appno;

    elsif (p_div = 'IM') then
        for rec in (
            select  p_slipdiv || substr('0000' || to_char((nvl(substr(max(slipnum), -4, 4), 0) + 1)), -4, 4) as slipnum
            from    ACORDM a
            where   compcode = p_compcode
                    and slipno like replace(p_slipdate, '-', '') || rtrim(p_slipdiv) || '%')
        loop
            p_slipnum := rec.slipnum;
        end loop;

        p_slipno := replace(p_slipdate, '-', '') || p_slipnum;

        insert into ACORDM
            (
                compcode,
                slipinno,
                slipdiv,
                slipindate,
                slipinnum,
                deptcode,
                plantcode,
                empcode,
                eviddiv,
                slipinremark,
                slipno,
                slipdate,
                slipnum,
                slipdeptcode,
                slipempcode,
                skreqyn,
                skreqdiv,
                skreqdate,
                skreqdeptcode,
                skreqempcode,
                accountno,
                slipinstate,
                slipremark,
                acautorcode,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipno,
                p_slipdiv,
                p_slipdate,
                p_slipnum,
                p_deptcode,
                p_plantcode,
                p_iempcode,
                '99',
                p_remark,
                p_slipno,
                p_slipdate,
                p_slipnum,
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '',
                '4',
                '',
                acautorcode,
                sysdate,
                p_iempcode
        from    ACAUTORULE
        where   acautorcode = p_acautorcode;

        MESSAGE := p_slipno;

    elsif (p_div = 'ID') then
        insert into ACORDRPYP
            (
                compcode,
                slipinno,
                slipinseq,
                rpyslipinno,
                rpyslipinseq,
                repayamt
            )
        select  p_compcode,
                p_slipinno,
                ip_slipinseq,
                p_rpyslipinno,
                p_rpyslipinseq,
                p_feeamt
        from    DUAL;

        if p_slipinno <> '20000101R0001' then
            for rec in (
                select  1 as alias1
                from    DUAL
                where   exists (select  *
                                from    ACORDRPYR
                                where   compcode = p_compcode
                                        and slipinno = p_slipinno
                                        and slipinseq = ip_slipinseq))
            loop
                v_temp := rec.alias1;
            end loop;

            if v_temp = 1 then
                update  ACORDRPYR
                set     repayamt = repayamt + p_feeamt
                where   compcode = p_compcode
                        and slipinno = p_slipinno
                        and slipinseq = ip_slipinseq;
            else
                insert into ACORDRPYR
                    (
                        compcode,
                        slipinno,
                        slipinseq,
                        slipamt,
                        repayamt
                    )
                select  p_compcode,
                        p_slipinno,
                        ip_slipinseq,
                        p_feeamt,
                        p_feeamt
                from    DUAL;
            end if;
        end if;

    elsif ( upper(p_div) = upper('IC') ) then
        execute immediate 'delete from VGT.TT_ACACC0030P_ACORDRPYP';
        insert into VGT.TT_ACACC0030P_ACORDRPYP
        select  a.rpyslipinseq,
                max(case when a.slipinno = '20000101R0001' then '' else a.compcode end) compcode,
                sum(a.repayamt) creamt,
                max(nvl(e.divcode, c.mngcluval)) mngcluval,
                max(nvl(e.divname, c.mngcludec)) mngcludec,
                round(case when isnumeric(max(e.filter1)) = 1 then sum(a.repayamt) * max(e.filter1) / 100 else 0 end, 0) feeamt
        from    ACORDRPYP a
                left join ACORDD b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
                left join ACORDS c
                    on b.compcode = c.compcode
                    and b.slipinno = c.slipinno
                    and b.slipinseq = c.slipinseq
                    and c.mngclucode = 'U081'
                left join CMCOMMONM d
                    on d.cmmcode = 'AC17'
                    and case when a.slipinno = '20000101R0001' then a.compcode else c.mngcluval end = d.divcode
                left join CMCOMMONM e
                    on d.hcmmcode = e.cmmcode
                    and d.hdivcode = e.divcode
        where   a.rpyslipinno = p_slipinno
        group by a.rpyslipinseq;

        for rec in (
            select  1 as slipinseq,
                    sum(creamt - feeamt) as totamt
            from    VGT.TT_ACACC0030P_ACORDRPYP)
        loop
          ip_slipinseq := rec.slipinseq;
          p_totamt := rec.totamt;
        end loop;

        p_acccode := '11101031';
        for rec in (
            select  value2
            from    SYSPARAMETERMANAGE
            where   parametercode = 'copercardpopup')
        loop
            p_acccode := rec.value2;
        end loop;

        insert into ACORDD
            (
                compcode,
                slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                rptseq,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                ip_slipinseq,
                '1',
                p_acccode,
                plantcode,
                p_totamt,
                0,
                slipdate,
                slipnum,
                slipinremark,
                '',
                ip_slipinseq,
                sysdate,
                p_iempcode
        from    ACORDM
        where   compcode = p_compcode
                and slipinno = p_slipinno;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                p_slipinseq,
                a.mngclucode,
                a.seq,
                case when a.mngclucode = 'S020' then p_accountno else '' end col,
                case when a.mngclucode = 'S020' then nvl(b.accremark, '') else '' end col,
                sysdate,
                p_iempcode
        from    ACACCMNGM a
                left join CMACCOUNTM b
                    on b.accountno = p_accountno
        where   a.acccode = p_acccode
                and a.dcdiv = '1';

        p_acccode := '73310300';
        for rec in (
            select  filter1
            from    CMCOMMONM
            where   cmmcode = 'AC261'
                    and divcode = '73310300')
        loop
            p_acccode := rec.filter1;
        end loop;

        insert into ACORDD
            (
                compcode,
                slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                rptseq,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                ip_slipinseq + row_number() over(order by b.mngcluval),
                '1',
                p_acccode,
                max(a.plantcode),
                sum(b.feeamt),
                0,
                max(a.slipdate),
                max(a.slipnum),
                max(a.slipinremark),
                '',
                ip_slipinseq + row_number() over(order by b.mngcluval),
                sysdate,
                p_iempcode
        from    ACORDM a
                join VGT.TT_ACACC0030P_ACORDRPYP b
                    on 1 = 1
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno
        group by b.mngcluval;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                b.slipinseq,
                a.mngclucode,
                a.seq,
                case when a.mngclucode = 'S040' then nvl(d.deptcode, '')
                     when a.mngclucode = 'S050' then nvl(c.empcode, '')
                     when a.mngclucode = 'U081' then nvl(b.mngcluval, '')
                     else '' end,
                case when a.mngclucode = 'S040' then nvl(d.deptname, '')
                     when a.mngclucode = 'S050' then nvl(c.empname, '')
                     when a.mngclucode = 'U081' then nvl(b.mngcludec, '')
                     else '' end,
                sysdate,
                p_iempcode
        from    ACACCMNGM a
                join (
                    select  ip_slipinseq + row_number() over(order by mngcluval) as slipinseq, mngcluval, max(mngcludec) as mngcludec
                    from    VGT.TT_ACACC0030P_ACORDRPYP
                    group by mngcluval
                ) b on 1 = 1
                left join CMEMPM c
                    on c.empcode = p_iempcode
                left join CMDEPTM d
                    on c.deptcode = d.deptcode
        where   a.acccode = p_acccode
                and a.dcdiv = '1'
        order by b.slipinseq, a.seq;

        for rec in (
            select  max(slipinseq) as slipinseq
            from    ACORDD
            where   compcode = p_compcode
                    and slipinno = p_slipinno)
        loop
            ip_slipinseq := rec.slipinseq;
        end loop;

        delete
        from    ACORDRPYP
        where   slipinno = '20000101R0001'
                and rpyslipinno = p_slipinno;

        update  ACORDRPYP
        set     rpyslipinseq = rpyslipinseq + ip_slipinseq - 2
        where   compcode = p_compcode
                and rpyslipinno = p_slipinno;

        p_acccode := '11108040';
        for rec in (
            select  filter1
            from    CMCOMMONM
            where   cmmcode = 'AC261'
                    and divcode = '11108040')
        loop
            p_acccode := rec.filter1;
        end loop;

        insert into ACORDD
            (
                compcode,
                slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                rptseq,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                ip_slipinseq + row_number() over(order by b.mngcluval),
                '2',
                p_acccode,
                plantcode,
                0,
                b.creamt,
                slipdate,
                slipnum,
                slipinremark,
                '',
                ip_slipinseq + row_number() over(order by b.mngcluval),
                sysdate,
                p_iempcode
        from    ACORDM a
                join VGT.TT_ACACC0030P_ACORDRPYP b
                    on b.compcode is not null
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                b.slipinseq,
                a.mngclucode,
                a.seq,
                case when a.mngclucode = 'S040' then nvl(d.deptcode, '')
                when a.mngclucode = 'S050' then nvl(c.empcode, '')
                when a.mngclucode = 'U081' then nvl(b.mngcluval, '')
                else ''
                end,
                case when a.mngclucode = 'S040' then nvl(d.deptname, '')
                when a.mngclucode = 'S050' then nvl(c.empname, '')
                when a.mngclucode = 'U081' then nvl(b.mngcludec, '')
                else ''
                end,
                sysdate,
                p_iempcode
        from    ACACCMNGM a
                join (
                    select  ip_slipinseq + row_number() over(order by mngcluval) as slipinseq, mngcluval, mngcludec
                    from    VGT.TT_ACACC0030P_ACORDRPYP
                    where   compcode is not null
                ) b on 1 = 1
                left join CMEMPM c
                    on c.empcode = p_iempcode
                left join CMDEPTM d
                    on c.deptcode = d.deptcode
        where   a.acccode = p_acccode
                and a.dcdiv = '2'
        order by b.slipinseq, a.seq;

        for rec in (
            select  max(slipinseq) as slipinseq
            from    ACORDD
            where   compcode = p_compcode
                    and slipinno = p_slipinno)
        loop
            ip_slipinseq := rec.slipinseq;
        end loop;

        p_acccode := '21070000';
        for rec in (
            select  filter1
            from    CMCOMMONM
            where   cmmcode = 'AC261'
                    and divcode = '21070000')
        loop
            p_acccode := rec.filter1;
        end loop;

        insert into ACORDD
            (
                compcode,
                slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                rptseq,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                ip_slipinseq + row_number() over(order by b.mngcluval),
                '2',
                p_acccode,
                plantcode,
                0,
                b.creamt,
                slipdate,
                slipnum,
                slipinremark,
                '',
                ip_slipinseq + row_number() over(order by b.mngcluval),
                sysdate,
                p_iempcode
        from    ACORDM a
                join VGT.TT_ACACC0030P_ACORDRPYP b
                    on b.compcode is null
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  p_compcode,
                p_slipinno,
                b.slipinseq,
                a.mngclucode,
                a.seq,
                case when a.mngclucode = 'S040' then nvl(d.deptcode, '')
                     when a.mngclucode = 'S050' then nvl(c.empcode, '')
                     when a.mngclucode = 'U081' then nvl(b.mngcluval, '')
                     else '' end,
                case when a.mngclucode = 'S040' then nvl(d.deptname, '')
                     when a.mngclucode = 'S050' then nvl(c.empname, '')
                     when a.mngclucode = 'U081' then nvl(b.mngcludec, '')
                     else '' end,
                sysdate,
                p_iempcode
        from    ACACCMNGM a
                join (
                    select  ip_slipinseq + row_number() over(order by mngcluval) as slipinseq, mngcluval, mngcludec
                    from    VGT.TT_ACACC0030P_ACORDRPYP
                    where   compcode is null
                ) b on 1 = 1
                left join CMEMPM c
                    on c.empcode = p_iempcode
                left join CMDEPTM d
                    on c.deptcode = d.deptcode
        where   a.acccode = p_acccode
                and a.dcdiv = '2'
        order by b.slipinseq, a.seq;

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
