CREATE PROCEDURE        spACass0102R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACass0102R
 -- 작 성 자         : 최인범
 -- 작성일자         : 2010-10-04
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2017-01-02
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 자산취득현황을 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_plantcode     IN  VARCHAR2 DEFAULT '' ,
    p_assdiv        IN  VARCHAR2 DEFAULT '' ,
    p_asscls        IN  VARCHAR2 DEFAULT '' ,
    p_datediv       IN  VARCHAR2 DEFAULT '' ,--조회일자 기준(취득일자,처분일자)
    p_startdate     IN  VARCHAR2 DEFAULT '' ,
    p_enddate       IN  VARCHAR2 DEFAULT '' ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS

BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO   ATINFO (USERID, REASONDIV, REASONTEXT)
    VALUES (p_userid, p_reasondiv, p_reasontext);

    IF ( UPPER(p_div) = UPPER('S') ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  NVL(a.compcode, '')         compcode ,      --회사코드
                    NVL(trim(a.asscode), '')    asscode ,       --자산코드
                    NVL(a.assname, '')          assname ,       --자산명
                    NVL(a.assdiv, '')           assdiv ,        --자산구분 유,무형
                    NVL(a.asscls, '')           asscls ,        --토지,건물,건축물
                    NVL(a.strdate, '')          strdate ,       --취득일자
                    NVL(a.enddate, '')          enddate ,       --처분일자
                    NVL(a.lifeyear, 0)          lifeyear ,      --내용년수
                    NVL(a.plantcode, '')        plantcode ,     --사업장코드
                    NVL(a.mngdeptcode, '')      mngdeptcode ,   --관리부서
                    NVL(a.acccode, '')          acccode ,       --계정코드
                    NVL(a.keeprmk, '')          keeprmk ,       --비고
                    NVL(a.masscode, '')         masscode ,      --설비코드
                    NVL(a.acqdiv, '')           acqdiv ,        --취득방법
                    NVL(a.depryn, '')           depryn ,        --상각여부
                    NVL(a.deprdiv, '')          deprdiv ,       --상각방법
                    NVL(a.remark, '')           remark ,        --비고
                    NVL(a.deprendyn, '')        deprendyn ,     --감가상각종료여부
                    NVL(a.assstate, '')         assstate ,      --자산상태
                    NVL(a.curassamt, 0)         curassamt ,     --취득가액
                    NVL(a.lstassamt, 0)         lstassamt ,     --비망가액
                    NVL(a.subsidyn, '')         subsidyn ,      --정부지원여부
                    NVL(a.subsidrmk, '')        subsidrmk ,     --정부지원내용
                    NVL(a.subsidassamt, 0)      subsidassamt ,  --정보지원금액
                    NVL(E.deptname, '')         mngdeptname  ,
                    NVL(f.accname, '')          accname  ,
                    NVL(M.equipmentkorname, '') massname  ,
                    NVL(P.plantname, '')        plantname  ,
                    NVL(ac76.divname, '')       assstatename  ,
                    NVL(ac71.divname, '')       assclsname  ,
                    NVL(ac70.divname, '')       assdivname  ,
                    NVL(rate.deprerate, 0)      deprerate
                    , CASE WHEN NVL(trim(a.asscode), '') IS NULL THEN 0
                           ELSE 1
                    END i_order
            FROM    ACASSM a
                    LEFT JOIN CMDEPTM E      ON a.mngdeptcode = E.deptcode
                    LEFT JOIN ACACCM f       ON a.acccode = f.acccode
                    LEFT JOIN PDEQUIPMENTM M ON M.equipmentcode = a.masscode
                    LEFT JOIN CMPLANTM P     ON P.plantcode = a.plantcode
                    LEFT JOIN CMCOMMONM ac76 ON ac76.cmmcode = 'AC76'
                                                AND ac76.divcode = a.assstate
                    LEFT JOIN CMCOMMONM ac71 ON ac71.cmmcode = 'AC71' --자산분류
                                                AND ac71.divcode = a.asscls
                    LEFT JOIN CMCOMMONM ac70 ON ac70.cmmcode = 'AC70' --자산형태
                                                AND ac70.divcode = a.assdiv
                    LEFT JOIN ACDEPRM rate   ON rate.compcode = a.compcode
                                                AND rate.lifeyear = a.lifeyear
                                                AND rate.deprdiv = a.deprdiv
            WHERE   a.compcode = p_compcode
                    AND NVL(a.plantcode, ' ') LIKE p_plantcode || '%'
                    AND NVL(a.assdiv, ' ') LIKE p_assdiv || '%'
                    AND ( a.strdate BETWEEN p_startdate AND p_enddate AND p_datediv = '01' ) OR --취득일자기준
                        ( a.enddate BETWEEN p_startdate AND p_enddate AND p_datediv = '02' )    --처분일자기준

            ORDER BY i_order, a.asscode ;
    END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
    END IF;

END;
/
