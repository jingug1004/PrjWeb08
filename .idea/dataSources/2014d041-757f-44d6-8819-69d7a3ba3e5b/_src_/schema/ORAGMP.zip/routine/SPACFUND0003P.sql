CREATE PROCEDURE        spACfund0003P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACfund0003P
 -- 작 성 자         : 최용석
 -- 작성일자         : 2012-11-05
    --  수 정 자         : 임 정호
   --  수정일자          : 2016-12-27
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 미수이자를 관리하는 프로시저이다.
 -- ---------------------------------------------------------------

(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '' ,
    p_payym        IN VARCHAR2 DEFAULT '' ,
    p_payamt        IN FLOAT DEFAULT 0 ,
    p_iempcode      IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,
    IO_CURSOR         OUT TYPES.DataSet,
    MESSAGE           OUT VARCHAR2
)
AS
    ip_payym VARCHAR2(10) := p_payym;
    p_acautorcode VARCHAR2(10);
    p_acccode1 VARCHAR2(20); -- 단기금융상품_정기적금
    p_acccode2 VARCHAR2(20);-- 장기금융상품_정기적금
    p_slipdiv VARCHAR2(5);
    p_deptcode VARCHAR2(20);
    p_enddate VARCHAR2(10);
    p_remark VARCHAR2(100);
    p_yearcnt NUMBER(10,0);
    p_slipnum VARCHAR2(5);
    p_slipno VARCHAR2(20);
    p_minusdate VARCHAR2(10);
    p_slipseq NUMBER(10,0);-- 일련번호

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    p_acautorcode := 'A03220' ;
    FOR  rec IN
    (
        SELECT  accdiv  ,
                remark2
        FROM    ACAUTORULE
        WHERE   acautorcode = p_acautorcode
    )
    LOOP
        p_slipdiv := rec.accdiv   ;
        p_remark := rec.remark2   ;
    END LOOP;

    FOR  rec IN
    (
        SELECT  deptcode
        FROM    CMEMPM
        WHERE   empcode = p_iempcode
    )
    LOOP
        p_deptcode := rec.deptcode;
    END LOOP;

    p_acccode1 := '11105010' ;
    FOR  rec IN
    (
        SELECT  filter1
        FROM    CMCOMMONM
        WHERE   cmmcode = 'AC261'
            AND divcode = '11105010'
    )
    LOOP
        p_acccode1 := rec.filter1   ;
    END LOOP;

    p_acccode2 := '14101010' ;
    FOR  rec IN
    (
        SELECT  filter1
        FROM    CMCOMMONM
        WHERE   cmmcode = 'AC261'
            AND divcode = '14101010'
    )
    LOOP
        p_acccode2 := rec.filter1   ;
    END LOOP;

    p_enddate := TO_CHAR(LAST_DAY (TO_DATE ( substr(ip_payym,1,7) || '-01','YYYY-MM-DD' )),'YYYY-MM-DD');
    p_yearcnt := FNdatediff('DAY', SUBSTR(ip_payym, 1, 4) || '-01-01', SUBSTR(ip_payym, 1, 4) || '-12-31') + 1 ;

    IF ( p_div = 'S' ) THEN

        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACFUND0003P_CMACCOUNTM ';

        INSERT INTO VGT.TT_ACFUND0003P_CMACCOUNTM
        SELECT  a.accountno ,
                a.accremark ,
                b.divname deposdiv  ,
                a.strdate ,
                a.expdate ,
                a.mainamt ,
                a.interate ,
                CASE
                   WHEN b.filter2 = 'D' THEN a.mainamt
                   ELSE 0
                END payamt  ,
                b.filter2
          FROM  CMACCOUNTM a
                JOIN CMCOMMONM b
                    ON      b.cmmcode = 'AC40'
                        AND a.deposdiv = b.divcode
                        AND b.filter2 IN ( 'D','I' )
         WHERE  a.compcode = p_compcode
            AND a.plantcode = p_plantcode
            AND a.strdate <= substr(ip_payym,1,7) || '-01'
            AND nvl(p_enddate, ' ') < a.expdate ;

        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACFUND0003P_ACORDD';

        INSERT INTO VGT.TT_ACFUND0003P_ACORDD
      	SELECT a.accountno ,
               b.slipdate ,
               b.debamt
      	  FROM VGT.TT_ACFUND0003P_CMACCOUNTM  a
                JOIN ACORDD b   ON b.compcode = p_compcode
                AND b.plantcode = p_plantcode
                AND b.slipdate <= p_enddate
                AND b.acccode IN ( p_acccode1,p_acccode2 )
                AND b.debamt <> 0
                JOIN ACORDS c   ON b.compcode = c.compcode
                AND b.slipinno = c.slipinno
                AND b.slipinseq = c.slipinseq
                AND c.mngclucode = 'S020'
                AND a.accountno = c.mngcluval
                LEFT JOIN ACORDD D   ON b.compcode = D.compcode
                AND b.slipinno = D.slipinno
                AND D.acccode = p_acccode2
                AND b.debamt = D.creamt
      	 WHERE  a.filter2 = 'I'
            AND D.compcode IS NULL ;

        MERGE INTO VGT.TT_ACFUND0003P_CMACCOUNTM a
        USING (
                SELECT  a.accountno, b.payamt
                FROM    VGT.TT_ACFUND0003P_CMACCOUNTM a
                        JOIN (
                                SELECT  accountno ,
                                        SUM(debamt)  payamt
                                FROM VGT.TT_ACFUND0003P_ACORDD
                                GROUP BY accountno
                             ) b
                            ON a.accountno = b.accountno
             ) src
          ON ( a.accountno = src.accountno )
        WHEN MATCHED THEN
            UPDATE SET payamt = src.payamt;

        OPEN  IO_CURSOR FOR
        SELECT  a.accountno ,
                a.accremark ,
                a.deposdiv ,
                a.expdate ,
                a.mainamt ,
                a.payamt ,
                a.interate ,
                NVL(b.intamt, 0) intamt
        FROM    VGT.TT_ACFUND0003P_CMACCOUNTM a
                LEFT JOIN (
                            SELECT  a.accountno ,
                                    SUM(
                                            CASE
                                                WHEN filter2 = 'D' THEN ROUND(a.mainamt * a.interate * (FNdatediff('DAY', a.strdate, p_enddate)) / (p_yearcnt * 100), 0)
                                                ELSE ROUND(b.debamt * a.interate * (FNdatediff('DAY', b.slipdate, p_enddate)) / (p_yearcnt * 100), 0)
                                            END
                                        )  intamt
                            FROM    VGT.TT_ACFUND0003P_CMACCOUNTM a
                                    LEFT JOIN VGT.TT_ACFUND0003P_ACORDD b   ON a.accountno = b.accountno
                            WHERE  a.filter2 = 'D' OR b.accountno <> ' '
                            GROUP BY a.accountno
                         ) b
                ON a.accountno = b.accountno
        ORDER BY accountno ;

    ELSIF ( p_div = 'CS' ) THEN

       --미수이자결산전표 생성

         -- 미수이자결산전표 삭제
        FOR  rec IN
        (
            SELECT  slipno
            FROM    ACORDM a
            WHERE   compcode = p_compcode
                AND slipindate = p_enddate
                AND slipdiv = p_slipdiv
                AND acautorcode = p_acautorcode
        )
        LOOP
            p_slipno := rec.slipno   ;
        END LOOP;

              spACord0000MM(
                                'B',
                                p_compcode,
                                p_slipno,
                                NULL,
                                NULL,
                                NULL,
                                p_userid,
                                p_reasondiv,
                                p_reasontext,
                                MESSAGE,
                                IO_CURSOR
                            ) ;

        DELETE FROM ACORDS
        WHERE  (COMPCODE, SLIPINNO, SLIPINSEQ,MNGCLUCODE) IN  (
                                                                SELECT  B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ,B.MNGCLUCODE
                                                                FROM    ACORDM a
                                                                        JOIN ACORDS b
                                                                            ON      a.compcode = b.compcode
                                                                                AND a.slipinno = b.slipinno
                                                                WHERE   a.compcode = p_compcode
                                                                    AND a.slipindate = p_enddate
                                                                    AND a.slipdiv = p_slipdiv
                                                                    AND a.acautorcode = p_acautorcode
                                                           );


        DELETE FROM ACORDD
        WHERE (COMPCODE, SLIPINNO, SLIPINSEQ) IN              (
                                                                SELECT  B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ
                                                                FROM    ACORDM a
                                                                        JOIN ACORDD b
                                                                            ON      a.compcode = b.compcode
                                                                                AND a.slipinno = b.slipinno
                                                                WHERE  a.compcode = p_compcode
                                                                       AND a.slipindate = p_enddate
                                                                       AND a.slipdiv = p_slipdiv
                                                                       AND a.acautorcode = p_acautorcode
                                                           );

        DELETE FROM ACORDM
        WHERE   compcode    = p_compcode
            AND slipindate  = p_enddate
            AND slipdiv     = p_slipdiv
            AND acautorcode = p_acautorcode;

         -- 미수이자결산전표 저장
        FOR  rec IN
        (
            SELECT  p_slipdiv || SUBSTR('0000' || TO_CHAR((NVL(SUBSTR(MAX(slipnum) , -4), 0) + 1)), -4)  AS alias1
            FROM    ACORDM a
            WHERE   compcode = p_compcode
                AND slipno LIKE REPLACE(p_enddate, '-', '') || RTRIM(p_slipdiv) || '%'
        )
        LOOP
            p_slipnum := rec.alias1   ;
        END LOOP;

        p_slipno := REPLACE(p_enddate, '-', '') || p_slipnum ;

        INSERT INTO ACORDM
                                (   compcode, slipinno, slipdiv, slipindate, slipinnum, deptcode, plantcode,
                                    empcode, eviddiv, slipinremark, slipno, slipdate, slipnum, slipdeptcode,
                                    slipempcode, skreqyn, skreqdiv, skreqdate, skreqdeptcode, skreqempcode,
                                    accountno, slipinstate, slipremark, acautorcode, insertdt, iempcode )
             SELECT p_compcode , p_slipno , p_slipdiv , p_enddate , p_slipnum ,
                    p_deptcode , p_plantcode , p_iempcode , '99' , p_remark ,
                    p_slipno , p_enddate , p_slipnum , NULL , NULL , NULL ,
                    NULL , NULL , NULL , NULL , NULL , '4' ,
                    NULL , acautorcode , SYSDATE , p_iempcode
            FROM    ACAUTORULE
            WHERE   acautorcode = p_acautorcode ;


        INSERT INTO ACORDD
                                ( compcode, slipinno, slipinseq, dcdiv, acccode, plantcode,
                                   debamt, creamt, slipdate, slipnum, remark1, remark2, rptseq, insertdt, iempcode )
        SELECT      p_compcode ,
                  p_slipno ,
                  ROW_NUMBER() OVER ( ORDER BY a.acautoseq  ) ,
                  a.dcdiv ,
                  a.acacccode ,
                  p_plantcode ,
                  CASE WHEN a.dcdiv = '1' THEN p_payamt ELSE 0 END * CASE WHEN a.amtdiv = '+' THEN 1 ELSE -1 END col  ,
                  CASE WHEN a.dcdiv = '2' THEN p_payamt ELSE 0 END * CASE WHEN a.amtdiv = '+' THEN 1 ELSE -1END col  ,
                  p_enddate ,
                  p_slipnum ,
                  SUBSTR(ip_payym, 1, 4) || '년' || SUBSTR(ip_payym, -2) || '월 미수이자결산' ,
                  p_remark ,
                  ROW_NUMBER() OVER ( ORDER BY a.acautoseq  ) ,
                  SYSDATE ,
                  p_iempcode
        FROM ACAUTORULESM a
        WHERE  a.acautorcode = p_acautorcode
        ORDER BY a.acautoseq;

         spACord0000MM  (
                            'A',
                             p_compcode,
                             p_slipno,
                             ' ',
                             ' ',
                             ' ',
                             p_userid,
                             p_reasondiv,
                             p_reasontext,
                             MESSAGE,
                             IO_CURSOR
                        ) ;


    ELSIF ( p_div = 'CM' ) THEN
        p_minusdate :=  TO_CHAR(ADD_MONTHS (TO_DATE (substr(ip_payym,1,7) || '-01','YYYY-MM-DD') , 1 ),'YYYY-MM-DD');
        -- 기존자료 삭제
        DELETE FROM ACORDD
        WHERE  (COMPCODE, SLIPINNO, SLIPINSEQ) IN   (
                                                        SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ
                                                        FROM ACORDM a
                                                             JOIN ACORDD b   ON a.compcode = b.compcode
                                                             AND a.slipinno = b.slipinno
                                                        WHERE  a.compcode = p_compcode
                                                              AND a.plantcode LIKE p_plantcode
                                                              AND a.slipdiv = p_slipdiv
                                                              AND a.slipdate = p_minusdate
                                                              AND a.acautorcode = p_acautorcode
                                                    );

        DELETE FROM ACORDM
        WHERE   compcode = p_compcode
            AND plantcode LIKE p_plantcode
            AND slipdiv = p_slipdiv
            AND slipdate = p_minusdate
            AND acautorcode = p_acautorcode;

        FOR  rec IN
        (
            SELECT  NVL(SUBSTR(MAX(slipinnum) , -4, 4), 0)  AS alias1
            FROM    ACORDM a
            WHERE   compcode = p_compcode
                AND slipindate = p_minusdate
                AND slipdiv = p_slipdiv
        )
        LOOP
            p_slipseq := rec.alias1   ;
        END LOOP;

        INSERT INTO ACORDM
                            (   compcode, slipinno, slipdiv, slipindate, slipinnum, deptcode, plantcode,
                                empcode, eviddiv, slipinremark, slipno, slipdate, slipnum, slipdeptcode,
                                slipempcode, skreqyn, skreqdiv, skreqdate, skreqdeptcode, skreqempcode,
                                accountno, slipinstate, slipremark, acautorcode, insertdt, iempcode,
                                updatedt, uempcode )
              SELECT compcode ,
                     REPLACE(p_minusdate, '-', '') || p_slipdiv || SUBSTR('0000' || TO_CHAR(ROW_NUMBER() OVER ( ORDER BY slipinno  ) + p_slipseq), -4) ,
                     slipdiv ,
                     p_minusdate ,
                     p_slipdiv || SUBSTR('0000' || TO_CHAR(ROW_NUMBER() OVER ( ORDER BY slipinno  ) + p_slipseq), -4) ,
                     p_deptcode ,
                     plantcode ,
                     p_iempcode ,
                     '99' ,
                     slipinremark || '차감' ,
                     REPLACE(p_minusdate, '-', '') || p_slipdiv || SUBSTR('0000' || TO_CHAR(ROW_NUMBER() OVER ( ORDER BY slipinno  ) + p_slipseq), -4) ,
                     p_minusdate ,
                     p_slipdiv || SUBSTR('0000' || TO_CHAR(ROW_NUMBER() OVER ( ORDER BY slipinno  ) + p_slipseq), -4, 4) ,
                     slipdeptcode ,
                     slipempcode ,
                     skreqyn ,
                     skreqdiv ,
                     skreqdate ,
                     skreqdeptcode ,
                     skreqempcode ,
                     accountno ,
                     slipinstate ,
                     slipremark ,
                     acautorcode ,
                     SYSDATE ,
                     p_iempcode ,
                     NULL ,
                     NULL
                FROM ACORDM
               WHERE  compcode = p_compcode
                        AND plantcode LIKE p_plantcode
                        AND slipdiv = p_slipdiv
                        AND slipdate = p_enddate
                        AND acautorcode = p_acautorcode;





            INSERT INTO ACORDD
              ( compcode, slipinno, slipinseq, dcdiv, acccode, plantcode, debamt, creamt, slipdate, slipnum, remark1, remark2, taxno, datadiv, rptseq, insertdt, iempcode, updatedt, uempcode )
              ( SELECT b.compcode ,
                       newno ,
                       slipinseq ,
                       dcdiv ,
                       acccode ,
                       plantcode ,
                       -debamt ,
                       -creamt ,
                       p_minusdate ,
                       newnum ,
                       b.remark1 ,
                       b.remark2 ,
                       b.taxno ,
                       b.datadiv ,
                       b.rptseq ,
                       SYSDATE ,
                       p_iempcode ,
                       NULL ,
                       NULL
                FROM (
                -------------------
                        SELECT  compcode ,
                                slipinno ,
                                REPLACE(p_minusdate, '-', '') || p_slipdiv || SUBSTR('0000' || TO_CHAR(ROW_NUMBER() OVER ( ORDER BY slipinno  ) + p_slipseq), -4) newno  ,
                                p_slipdiv || SUBSTR('0000' || TO_CHAR(ROW_NUMBER() OVER ( ORDER BY slipinno  ) + p_slipseq), -4, 4) newnum
                        FROM    ACORDM
                        WHERE   compcode = p_compcode
                            AND plantcode LIKE p_plantcode
                            AND slipdiv = p_slipdiv
                            AND slipdate = p_enddate
                            AND acautorcode = p_acautorcode
                --------------------
                     ) a
                       JOIN ACORDD b   ON a.compcode = b.compcode
                       AND a.slipinno = b.slipinno );



            ip_payym := SUBSTR(p_minusdate, 1, 7) ;
            spACord0000MM(
                            'T',
                            p_compcode,
                            ' ',
                            '%',
                            ip_payym,
                            ip_payym,
                            p_userid,
                            p_reasondiv,
                            p_reasontext,
                            MESSAGE,
                            IO_CURSOR
                        ) ;




    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
