CREATE PROCEDURE spACacc0119R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0119R
	-- 작 성 자         : 배종성
	-- 작성일자         : 2010-12-08
	-- 수 정 자     : 강현호
	-- E-Mail       : roykang0722@gmail.com
	-- 수정일자      : 2016-12-20
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 관리항목원장을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------
(
	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_acccode		IN	   VARCHAR2 DEFAULT '',
	p_dcdiv 		IN	   VARCHAR2 DEFAULT '',
	p_startdt		IN	   VARCHAR2 DEFAULT '',
	p_enddt 		IN	   VARCHAR2 DEFAULT '',
	p_mngclucode	IN	   VARCHAR2 DEFAULT '',
	p_mngcluval1	IN	   VARCHAR2 DEFAULT '',
	p_mngcluval2	IN	   VARCHAR2 DEFAULT '',
	p_outputdiv 	IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		OUT    VARCHAR2,
	IO_CURSOR		OUT    TYPES.DataSet
)
AS
	p_colview	VARCHAR2(1);
	p_odiv1 	VARCHAR2(5);
	p_odiv2 	VARCHAR2(5);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	p_colview := '_';

	FOR rec IN (SELECT value1
				FROM   SYSPARAMETERMANAGE
				WHERE  parametercode = 'accldgcolview')
	LOOP
		p_colview := rec.value1;
	END LOOP;

	IF (p_colview = '_') THEN
    	p_colview := '0';
    END IF;

	IF (p_outputdiv = '1') THEN
		--K-GAAP
		p_odiv1 := '20';
		p_odiv2 := 'F';
	ELSIF (p_outputdiv = '2') THEN
        --IFRS
        p_odiv1 := '30';
        p_odiv2 := 'K';
	END IF;


	IF ( UPPER(p_div) = UPPER('S') OR UPPER(p_div) = UPPER('S1') ) THEN

        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0119R_ACORDD';

		INSERT INTO VGT.TT_ACACC0119R_ACORDD
			(SELECT   NVL(b.grp, 0) grp,
					  CASE WHEN b.grp = 1 THEN A.acccode || A.slipdate || REPLACE(A.slipnum, 'C', p_colview) || LPAD(A.slipinseq, 5, '0') WHEN b.grp = 2 THEN A.acccode || SUBSTR(A.slipdate, 0, 7) || '98' WHEN b.grp = 3 THEN A.acccode || SUBSTR(A.slipdate, 0, 7) || '99' ELSE A.acccode END ord,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipinno END) slipinno,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipinseq END) slipinseq,
					  A.acccode,
					  MAX(c.accname) accname,
					  A.mngclucode,
					  MAX(CASE  WHEN b.grp = 1 OR b.grp IS NULL AND p_mngcluval1 IS NOT NULL AND p_mngcluval1 = p_mngcluval2 THEN A.mngcluval END)
                      mngcluval,
					  MAX(CASE WHEN b.grp = 1 OR b.grp IS NULL AND p_mngcluval1 IS NOT NULL AND p_mngcluval1 = p_mngcluval2 THEN A.mngcludec END)
				      mngcludec,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipdate ELSE SUBSTR(A.slipdate, 0, 7) END) slipdate,
					  MAX(CASE WHEN b.grp = 1 THEN A.slipnum WHEN b.grp = 2 THEN '월계' WHEN b.grp = 3 THEN '누계' ELSE '이월' END) slipnum,
					  MAX(CASE WHEN b.grp = 1 THEN A.remark END) remark,
					  SUM(A.debamt) debamt,
					  SUM(A.creamt) creamt,
					  SUM(CASE WHEN p_dcdiv = '1' THEN A.debamt - A.creamt ELSE A.creamt - A.debamt END) fnamt
			 FROM	  (SELECT A.acccode,
							  A.mngclucode,
							  A.mngcluval,
							  A.mngcludec,
							  SUBSTR(p_startdt, 0, 7) || '-00' slipdate,
							  '' slipnum,
							  '' slipinno,
							  0 slipinseq,
							  '' remark,
							  A.bsdebamt debamt,
							  A.bscreamt creamt
					   FROM   ACORDSMM A
					   WHERE  A.compcode = p_compcode
							  AND A.plantcode LIKE p_plantcode || '%'
							  AND A.slipym = SUBSTR(p_startdt, 0, 7)
							  AND (closediv = '10' OR closediv = p_odiv1 ) -- 운영집계 / 출력구분 [K-GAAP, IFRS]
							  AND A.acccode = p_acccode
							  AND A.mngclucode = p_mngclucode
							  AND (p_mngcluval1 IS NULL AND p_mngcluval2 IS NULL OR A.mngcluval BETWEEN p_mngcluval1 AND p_mngcluval2)
					   UNION ALL
					   SELECT A.acccode,
							  p_mngclucode mngclucode,
							  NVL(b.mngcluval, '') mngcluval,
							  NVL(b.mngcludec, '') mngcludec,
							  CASE WHEN A.slipdate < p_startdt THEN SUBSTR(p_startdt, 0, 7) || '-00' ELSE A.slipdate END slipdate,
							  A.slipnum,
							  A.slipinno,
							  A.slipinseq,
							  A.remark1 remark,
							  A.debamt,
							  A.creamt
					   FROM   ACORDD A
							  LEFT JOIN ACORDS b ON A.compcode = b.compcode
									                AND A.slipinno = b.slipinno
									                AND A.slipinseq = b.slipinseq
							  JOIN ACORDM c ON A.compcode = c.compcode
									           AND A.slipinno = c.slipinno
					   WHERE  A.compcode = p_compcode
							  AND A.plantcode LIKE p_plantcode || '%'
							  AND A.slipdate BETWEEN SUBSTR(p_startdt, 0, 7) || '-01' AND p_enddt
							  AND A.acccode = p_acccode
							  AND b.mngclucode = p_mngclucode
							  AND (p_mngcluval1 IS NULL AND p_mngcluval2 IS NULL OR b.mngcluval BETWEEN p_mngcluval1 AND p_mngcluval2)
							  AND c.slipinstate = '4'
							  AND c.slipdiv <> p_odiv2 ) A  -- K-GAAP <> 'F', IFRS <> 'K'
					  LEFT JOIN (SELECT 1 grp FROM DUAL
								 UNION
								 SELECT 2 FROM DUAL
								 UNION
								 SELECT 3 FROM DUAL) b ON A.slipdate >= p_startdt
					  LEFT JOIN ACACCM c ON A.acccode = c.acccode
			 GROUP BY b.grp,
					  A.acccode,
					  A.mngclucode,
					  CASE WHEN b.grp = 1 THEN A.acccode || A.slipdate || REPLACE(A.slipnum, 'C', p_colview) || LPAD(A.slipinseq, 5, '0') WHEN b.grp = 2 THEN A.acccode || SUBSTR(A.slipdate, 0, 7) || '98' WHEN b.grp = 3 THEN A.acccode || SUBSTR(A.slipdate, 0, 7) || '99' ELSE A.acccode END);



        MERGE INTO VGT.TT_ACACC0119R_ACORDD A
        USING (
                SELECT  CASE WHEN p_dcdiv = '1' THEN b.debamt - b.creamt ELSE b.creamt - b.debamt END AS fnamt
                        , A.ord
                FROM    VGT.TT_ACACC0119R_ACORDD A
                        JOIN (  SELECT    A.ord
                                        , SUM(b.debamt) debamt
                                        , SUM(b.creamt) creamt
                                FROM	  VGT.TT_ACACC0119R_ACORDD A
                                        JOIN VGT.TT_ACACC0119R_ACORDD b ON  A.acccode = b.acccode
                                                                            AND A.ord >= b.ord
                                                                            AND b.grp IN (0, 1)
                                WHERE   A.grp = 1
                                GROUP BY A.ord ) b ON A.ord = b.ord
              ) b ON ( A.ord = b.ord )
        WHEN MATCHED THEN UPDATE SET A.fnamt = b.fnamt;




        MERGE INTO VGT.TT_ACACC0119R_ACORDD A
        USING (
                    SELECT  NVL(b.debamt, A.debamt) AS debamt
                            , NVL(b.creamt, A.creamt) AS creamt
                            , b.fnamt
                            , A.ord
                    FROM    VGT.TT_ACACC0119R_ACORDD A
                            LEFT JOIN ( SELECT  A.ord
                                                , SUM(b.debamt) debamt
                                                , SUM(b.creamt) creamt
                                                , SUM(b.fnamt) fnamt
                                        FROM    VGT.TT_ACACC0119R_ACORDD A
                                                JOIN VGT.TT_ACACC0119R_ACORDD b ON  A.acccode = b.acccode
                                                                                    AND A.ord >= b.ord
                                                                                    AND b.grp IN (0, 2)
                                        WHERE   A.grp = 3
                                        GROUP BY A.ord ) b ON A.ord = b.ord
                    WHERE  A.grp IN (2, 3)
              ) b ON ( A.ord = b.ord )
        WHEN MATCHED THEN UPDATE SET A.debamt = b.debamt
                                     , A.creamt = b.creamt
                                     , A.fnamt = b.fnamt ;



		OPEN IO_CURSOR FOR
			SELECT	 A.mngclucode,
					 A.mngcluval,
					 A.mngcludec,
					 c.businessno,
					 A.slipdate,
					 A.slipnum,
					 A.remark,
					 A.debamt,
					 A.creamt,
					 A.fnamt,
					 b.mngcludec2,
					 b.mngcludec3,
					 b.mngcludec4,
					 b.mngcludec5,
					 b.mngcludec6
			FROM	 VGT.TT_ACACC0119R_ACORDD A
					 LEFT JOIN
					 (SELECT   slipinno,
							   slipinseq,
							   MAX(CASE WHEN seq = 1 THEN mngcludec ELSE '' END) mngcludec2,
							   MAX(CASE WHEN seq = 2 THEN mngcludec ELSE '' END) mngcludec3,
							   MAX(CASE WHEN seq = 3 THEN mngcludec ELSE '' END) mngcludec4,
							   MAX(CASE WHEN seq = 4 THEN mngcludec ELSE '' END) mngcludec5,
							   MAX(CASE WHEN seq = 5 THEN mngcludec ELSE '' END) mngcludec6
					  FROM	   (SELECT A.slipinno,
									   A.slipinseq,
									   ROW_NUMBER() OVER (PARTITION BY A.slipinno, A.slipinseq ORDER BY b.seq) seq,
									   '[' || NVL(c.mngcluname, '') || ']' || NVL(b.mngcluval, '') || ' : ' || NVL(b.mngcludec, '') || CASE WHEN D.custcode IS NULL THEN '' ELSE ' (' || D.businessno || ')' END mngcludec
								FROM   VGT.TT_ACACC0119R_ACORDD A
									   JOIN ACORDS b
										   ON b.compcode = p_compcode
											  AND A.slipinno = b.slipinno
											  AND A.slipinseq = b.slipinseq
											  AND b.mngclucode <> p_mngclucode
									   LEFT JOIN ACMNGM c ON b.mngclucode = c.mngclucode
									   LEFT JOIN CMCUSTM D
										   ON b.mngclucode = 'S010'
											  AND b.mngcluval = D.custcode) A
					  GROUP BY slipinno, slipinseq) b
						 ON A.slipinno = b.slipinno
							AND A.slipinseq = b.slipinseq
					 LEFT JOIN CMCUSTM c
						 ON A.mngclucode = 'S010'
							AND A.mngcluval = c.custcode
			ORDER BY A.acccode, A.ord;


    ELSIF (p_div = 'A1') THEN

    	OPEN IO_CURSOR FOR

			SELECT	 b.mngclucode keyfield
                     , MAX(b.mngcluname) displayfield
			FROM	 ACACCM A
                     LEFT JOIN ACACCMNGM b ON A.acccode = b.acccode
			WHERE	 A.acccode = p_acccode
			GROUP BY b.mngclucode
			ORDER BY keyfield;

	ELSIF (p_div = 'A2') THEN

        OPEN IO_CURSOR FOR

			SELECT A.mngclucode mngclucode,
				   A.mngcluname mngcluname,
				   A.mngcludiv mngcludiv,
				   c.divname mngcludivnm,
				   D.filter1 codeseek,
				   A.remark codermk
			FROM   ACMNGM A
				   LEFT JOIN CMCOMMONM c ON A.mngcludiv = c.divcode
						                    AND c.cmmcode = 'AC12'
				   LEFT JOIN CMCOMMONM D ON A.codehelp = D.divcode
						                    AND D.cmmcode = 'CMHL'
			WHERE  A.mngclucode = p_mngclucode;

	ELSIF (p_div = 'A3') THEN

        OPEN IO_CURSOR FOR
			SELECT acccode, dcdiv
			FROM   ACACCM
			WHERE  acccode = p_acccode;

	ELSIF (p_div = 'RMK') THEN

        -- 코드헬프 검색
        OPEN IO_CURSOR FOR

            SELECT  NVL(codehelp, '') codehelp, -- 코드헬프번호
                    NVL(remark, '') codermk -- 코드헬프비고
            FROM    ACMNGM
            WHERE   mngclucode = p_mngclucode ;
	END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
