CREATE PROCEDURE        spACacc0216R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0216R
 -- 작 성 자         : 최용석
 -- 작성일자         : 2011-11-18
 -- 수정일         : 임정호
 -- 수정일자         : 2016-12-26

 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 순위별 매출실적이익 현황
 -- ---------------------------------------------------------------

(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '' ,
    p_strym         IN VARCHAR2 DEFAULT '' ,
    p_endym         IN VARCHAR2 DEFAULT '' ,
    p_datadiv       IN VARCHAR2 DEFAULT '1' ,
    p_amtgb         IN VARCHAR2 DEFAULT '' ,--실가/계산서가(0:실가, 1:계산서가)
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,
    IO_CURSOR       OUT TYPES.DataSet,
    IO_CURSOR2      OUT TYPES.DataSet,
    IO_CURSOR3      OUT TYPES.DataSet,
    IO_CURSOR4      OUT TYPES.DataSet,
    MESSAGE         OUT VARCHAR2
)
AS
   p_strdate VARCHAR2(10);
   p_enddate VARCHAR2(10);
   p_tmpcnt FLOAT(53);
   p_tmpamt FLOAT(53);

BEGIN

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    p_strdate := p_strym || '-01' ;
    p_enddate := TO_CHAR(LAST_DAY(TO_DATE(p_endym || '-01','YYYY-MM-DD')),'YYYY-MM-DD');

    -- 원가테이블에서 제품단가 검색

    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_CSJPSUM';

    INSERT INTO VGT.TT_ACACC0216R_CSJPSUM
    SELECT  A.itemcode ,
            DECODE (sum(chqty), 0, 0, TRUNC(sum(chamt) /sum(chqty),6) )  makingcost
    FROM    CSJPSUM A
    WHERE   A.compcode = p_compcode
        AND A.plantcode LIKE p_plantcode
        AND A.datadiv = p_datadiv
        AND A.costym = (
                            SELECT  MAX(costym)  costym
                            FROM    CSJPSUM
                            WHERE   plantcode LIKE p_plantcode
                                AND datadiv = '1'
                                AND costym <= p_endym
                        )
        AND A.chqty <> 0
        AND A.chamt <> 0
    GROUP BY A.itemcode
    HAVING SUM(A.chqty)  <> 0 ;


    -- 원가테이블에 없는 단가는 제품마스터에서 검색
    INSERT INTO VGT.TT_ACACC0216R_CSJPSUM
    SELECT  A.itemcode ,
            A.makingcost
    FROM    CMITEMM A
            LEFT JOIN VGT.TT_ACACC0216R_CSJPSUM  b   ON A.itemcode = b.itemcode
    WHERE   A.makingcost > 0
        AND b.itemcode IS NULL ;

   -- 영업부서 임시파일을 생성

    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_CMDEPTM';

    INSERT INTO VGT.TT_ACACC0216R_CMDEPTM
       SELECT  deptcode ,
            deptname ,
            predeptcode
    FROM    CMDEPTM
    WHERE  ( deptcode LIKE '12%' OR deptcode LIKE '13%' OR deptcode LIKE '17%' OR deptcode LIKE '18%')
        AND DEPTLEVEL IN ('2','3');
        --AND LENGTH(deptcode) >= 5 ;



    -- 영업사원 임시파일을 생성
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_CMEMPM ';

    INSERT INTO VGT.TT_ACACC0216R_CMEMPM
    SELECT  A.empcode ,
            A.empname ,
            A.deptcode ,
            b.predeptcode
    FROM    CMEMPM A
            JOIN VGT.TT_ACACC0216R_CMDEPTM b   ON A.deptcode = b.deptcode
    WHERE   A.responsibilitydiv = '0003' ;



    -- 거래처별 매출액 및 원가를 산출
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_SLORDM ';


    INSERT INTO VGT.TT_ACACC0216R_SLORDM
       SELECT  NVL(D.predeptcode, '') predeptcode  ,
            A.deptcode ,
            A.empcode ,
            A.custcode ,
            SUM (   CASE    WHEN p_amtgb = '0' THEN b.salamt1 *     CASE WHEN SUBSTR(A.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END
                            WHEN p_amtgb = '1' THEN b.salamt  *     CASE WHEN SUBSTR(A.saldiv, 0, 1) = 'A' THEN 1 ELSE -1 END
                            ELSE 0
                    END
                )  salesamt  ,
            TRUNC(NVL( SUM(    CASE
                            WHEN A.saldiv IN ( 'A01','A09','A21','A22','A61' ) AND b.outputqty > 0 THEN b.salqty
                            WHEN A.saldiv IN ( 'A03' ) THEN b.salqty
                            WHEN A.saldiv IN ( 'B01','B03','B21','B22','B61' ) THEN -b.salqty
                        END * E.makingcost
                    )
                    , 0
                ) ,0)makingamt
    FROM    SLORDM A
            JOIN SLORDD b
                ON      A.plantcode = b.plantcode
                    AND A.orderno = b.orderno
            JOIN SLTAXM c
                ON      A.plantcode = c.plantcode
                    AND A.taxdate = c.taxno
                    AND c.loadyn = 'Y'
                    AND NVL(c.deleteyn, ' ') <> 'Y'
            LEFT JOIN VGT.TT_ACACC0216R_CMDEPTM D   ON A.deptcode = D.deptcode
            LEFT JOIN VGT.TT_ACACC0216R_CSJPSUM E   ON b.itemcode = E.itemcode
    WHERE   A.plantcode LIKE p_plantcode
        AND A.appdate BETWEEN p_strdate AND p_enddate
        AND A.statediv = '09'
        AND TRIM(A.taxdate) IS NOT NULL
         GROUP BY NVL(D.predeptcode, ''),A.deptcode,A.empcode,A.custcode ;


   -- 사원의 인건비를 계산

    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_PSPAYM';

    INSERT INTO VGT.TT_ACACC0216R_PSPAYM
       SELECT  A.empcode ,
            SUM(totpay)  totpay
    FROM    PSPAYM A
            JOIN (
                    SELECT DISTINCT empcode
                    FROM    VGT.TT_ACACC0216R_CMEMPM
                 ) b  ON A.empcode = b.empcode
    WHERE   A.yearmonth BETWEEN p_strym AND p_endym
         GROUP BY A.empcode;


   -- 계정별 부서경비를 집계

    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_ACORDD1';

    INSERT INTO VGT.TT_ACACC0216R_ACORDD1

    SELECT  ROW_NUMBER() OVER ( ORDER BY grp, A.expensamt1 + A.expensamt2  ) ord  ,
            A.predeptcode ,
            A.deptcode ,
            A.empcnt ,
            A.expensamt1 ,
            A.expensamt2 ,
            0 expensamt3
    FROM (
            SELECT  CASE WHEN b.deptcode IS NULL THEN 1 ELSE 0 END grp  ,
                    MAX(NVL(b.predeptcode, ''))  predeptcode  ,
                    NVL(b.deptcode, '') deptcode  ,
                    SUM(A.empcnt)  empcnt  ,
                    SUM(A.expensamt1) expensamt1  ,
                    SUM(A.expensamt2) expensamt2
            FROM    (
                        SELECT  b.mngcluval deptcode  ,
                                0 empcnt  ,
                                0 expensamt1  ,
                                debamt expensamt2
                        FROM    ACORDD A
                                LEFT JOIN ACORDS b
                                    ON      A.compcode = b.compcode
                                        AND A.slipinno = b.slipinno
                                        AND A.slipinseq = b.slipinseq
                                        AND b.mngclucode = 'S040'
                        WHERE   A.compcode = p_compcode
                            AND A.acccode LIKE '73%'
                            AND A.acccode > '73100000'
                            AND A.slipdate BETWEEN p_strdate AND p_enddate
                            AND A.plantcode LIKE p_plantcode
                            AND A.dcdiv IN ( '1','4' )
                        UNION ALL
                        SELECT  b.deptcode ,
                                COUNT(*)  empcnt  ,
                                SUM(A.totpay)  expensamt1  ,
                                0 expensamt2
                        FROM    VGT.TT_ACACC0216R_PSPAYM A
                                JOIN VGT.TT_ACACC0216R_CMEMPM b   ON A.empcode = b.empcode
                        GROUP BY b.deptcode
                        UNION ALL
                        SELECT  NULL deptcode  ,
                                0 empcnt  ,
                                SUM(totpay*-1)  expensamt1  ,
                                0 expensamt2
                        FROM    VGT.TT_ACACC0216R_PSPAYM
                        UNION ALL
                        SELECT  NULL deptcode  ,
                                0 empcnt  ,
                                SUM(debamt)  payamt  ,
                                0 expensamt2
                        FROM    ACORDD
                        WHERE   compcode = p_compcode
                            AND acccode LIKE '73%'
                            AND acccode <= '73100000'
                            AND slipdate BETWEEN p_strdate AND p_enddate
                            AND plantcode LIKE p_plantcode
                            AND dcdiv IN ( '1','4' )
                    ) A
                    LEFT JOIN VGT.TT_ACACC0216R_CMDEPTM b   ON A.deptcode = b.deptcode
            GROUP BY CASE WHEN b.deptcode IS NULL THEN 1 ELSE 0 END,NVL(b.deptcode, '')
        ) A;



    FOR  rec IN
    (
        SELECT  SUM(expensamt1 + expensamt2)   AS alias1
        FROM    VGT.TT_ACACC0216R_ACORDD1
        WHERE   deptcode IS NULL
    )
    LOOP
        p_tmpamt := rec.alias1   ;
    END LOOP;

   EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_ACORDD11';


   INSERT INTO VGT.TT_ACACC0216R_ACORDD11
   SELECT   ROW_NUMBER() OVER ( ORDER BY A.expensamt3  ) ord  ,
            A.predeptcode ,
            A.deptcode ,
            A.expensamt3
    FROM (
            SELECT  A.deptcode ,
                    A.predeptcode ,
                    CASE WHEN b.salesamt <> 0 THEN ROUND(p_tmpamt * A.salesamt / b.salesamt, 0) ELSE 0 END expensamt3
               FROM (
                        SELECT  deptcode ,
                                MAX(predeptcode)  predeptcode  ,
                                SUM(salesamt)  salesamt
                        FROM    VGT.TT_ACACC0216R_SLORDM A
                        GROUP BY deptcode
                    ) A
                    JOIN (
                            SELECT  SUM(salesamt)  salesamt
                            FROM    VGT.TT_ACACC0216R_SLORDM
                         ) b
                    ON 1 = 1
         ) A;

   MERGE INTO VGT.TT_ACACC0216R_ACORDD11 TG
   USING (
            SELECT  ABS(b.diffamt) diffamt, A.expensamt3 + CASE WHEN b.diffamt < 0 THEN 1 ELSE -1 END AS expensamt3
            FROM    VGT.TT_ACACC0216R_ACORDD11 A
                    JOIN (
                            SELECT  p_tmpamt - SUM(expensamt3)  diffamt
                            FROM    VGT.TT_ACACC0216R_ACORDD11
                         ) b
                    ON A.ord <= ABS(b.diffamt)
         ) src
   ON ( TG.ord = src.diffamt )
   WHEN MATCHED THEN
   UPDATE   SET TG.expensamt3 = src.expensamt3;


   DELETE VGT.TT_ACACC0216R_ACORDD1
   WHERE  deptcode IS NULL ;

    MERGE INTO VGT.TT_ACACC0216R_ACORDD1 TG
    USING    (
                    SELECT  A.deptcode, b.expensamt3
                    FROM    VGT.TT_ACACC0216R_ACORDD1 A
                            JOIN VGT.TT_ACACC0216R_ACORDD11 b
                            ON A.deptcode = b.deptcode ) src
    ON      ( TG.deptcode = src.deptcode )
    WHEN MATCHED THEN
    UPDATE SET TG.expensamt3 = src.expensamt3;

    INSERT INTO VGT.TT_ACACC0216R_ACORDD1
    SELECT  A.ord ,
            A.predeptcode ,
            A.deptcode ,
            0 ,
            0 ,
            0 ,
            A.expensamt3
    FROM    VGT.TT_ACACC0216R_ACORDD11 A
            LEFT JOIN VGT.TT_ACACC0216R_ACORDD1 b   ON A.deptcode = b.deptcode
    WHERE   b.deptcode IS NULL;



   -- 계정별 사원경비를 집계
    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_ACORDD2';

    INSERT INTO VGT.TT_ACACC0216R_ACORDD2
    SELECT  ROW_NUMBER() OVER ( ORDER BY grp, expensamt1 + expensamt2  ) ord  ,
            A.empcode ,
            A.deptcode ,
            A.expensamt1 ,
            A.expensamt2 ,
            0 expensamt3
    FROM (
            SELECT  CASE WHEN c.empcode IS NULL THEN 1 ELSE 0 END grp  ,
                    NVL(b.deptcode, '')    deptcode  ,
                    NVL(c.empcode, '')     empcode  ,
                    SUM(A.expensamt1)       expensamt1  ,
                    SUM(A.expensamt2)       expensamt2
            FROM (
                    SELECT  CASE WHEN TRIM(c.mngcluval) IS NOT NULL THEN '' ELSE b.mngcluval END deptcode  ,
                            c.mngcluval empcode  ,
                            0 expensamt1  ,
                            debamt expensamt2
                    FROM    ACORDD A
                            LEFT JOIN ACORDS b
                                ON      A.compcode = b.compcode
                                    AND A.slipinno = b.slipinno
                                    AND A.slipinseq = b.slipinseq
                                    AND b.mngclucode = 'S040'
                            LEFT JOIN ACORDS c
                                ON      A.compcode = c.compcode
                                    AND A.slipinno = c.slipinno
                                    AND A.slipinseq = c.slipinseq
                                    AND c.mngclucode = 'S050'
                    WHERE   A.compcode = p_compcode
                        AND A.acccode LIKE '73%'
                        AND A.acccode > '73100000'
                        AND A.slipdate BETWEEN p_strdate AND p_enddate
                        AND A.plantcode LIKE p_plantcode
                        AND A.dcdiv IN ( '1','4' )
                    UNION ALL
                    SELECT  '' deptcode  ,
                            empcode ,
                            totpay expensamt1  ,
                            0 expensamt2
                    FROM    VGT.TT_ACACC0216R_PSPAYM
                    UNION ALL
                    SELECT  '' deptcode  ,
                            '' empcode  ,
                            SUM(-totpay)  expensamt1  ,
                            0 expensamt2
                    FROM    VGT.TT_ACACC0216R_PSPAYM
                    UNION ALL
                    SELECT  '' deptcode  ,
                            '' empcode  ,
                            SUM(debamt)  payamt  ,
                            0 expensamt2
                    FROM    ACORDD
                    WHERE   compcode = p_compcode
                        AND acccode LIKE '73%'
                        AND acccode <= '73100000'
                        AND slipdate BETWEEN p_strdate AND p_enddate
                        AND plantcode LIKE p_plantcode
                        AND dcdiv IN ( '1','4' )
                     ) A
                     LEFT JOIN VGT.TT_ACACC0216R_CMDEPTM b   ON A.deptcode = b.deptcode
                     LEFT JOIN VGT.TT_ACACC0216R_CMEMPM c   ON A.empcode = c.empcode
            GROUP BY CASE WHEN c.empcode IS NULL THEN 1 ELSE 0 END,
                     NVL(b.deptcode, ''),NVL(c.empcode, '')
         ) A;

   -- 영업부서의 경비를 영업사원으로 분배(매출액기준)

    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_ACORDD21';

    INSERT INTO VGT.TT_ACACC0216R_ACORDD21
    SELECT  ROW_NUMBER() OVER ( PARTITION BY A.deptcode ORDER BY c.salesamt DESC  ) ord  ,
            A.deptcode ,
            b.empcode ,
            CASE WHEN D.salesamt <> 0 THEN ROUND(A.expensamt2 * c.salesamt / D.salesamt, 0) ELSE 0 END expensamt2
    FROM    VGT.TT_ACACC0216R_ACORDD2 A
            JOIN VGT.TT_ACACC0216R_CMEMPM b   ON A.deptcode = b.deptcode
            JOIN ( SELECT   empcode ,
                            SUM(salesamt)  salesamt
                    FROM    VGT.TT_ACACC0216R_SLORDM
                    GROUP BY empcode
                 ) c  ON b.empcode = c.empcode
            JOIN ( SELECT   A.deptcode ,
                            SUM(salesamt)  salesamt
                    FROM    VGT.TT_ACACC0216R_ACORDD2 A
                            JOIN VGT.TT_ACACC0216R_CMEMPM b   ON A.deptcode = b.deptcode
                            JOIN VGT.TT_ACACC0216R_SLORDM c   ON b.empcode = c.empcode
                    WHERE   A.deptcode IS NOT NULL
                        AND A.empcode IS NULL
                    GROUP BY A.deptcode
                 ) D   ON A.deptcode = D.deptcode
       WHERE  TRIM(A.deptcode) IS NOT NULL
          AND TRIM(A.empcode) IS NULL;


    MERGE INTO VGT.TT_ACACC0216R_ACORDD21 TG
    USING (
            SELECT  B.diffamt,
                    A.expensamt2 + CASE WHEN b.diffamt < 0 THEN 1 ELSE -1 END AS expensamt2
            FROM    VGT.TT_ACACC0216R_ACORDD21 A
                    JOIN (
                            SELECT  A.deptcode ,
                                    MAX(A.expensamt2)  - SUM(b.expensamt2)  diffamt
                            FROM    VGT.TT_ACACC0216R_ACORDD2 A
                                    JOIN VGT.TT_ACACC0216R_ACORDD21 b   ON A.deptcode = b.deptcode
                            WHERE   A.empcode IS NULL
                            GROUP BY A.deptcode
                        ) b     ON  A.deptcode = b.deptcode
                                AND A.ord <= ABS(b.diffamt)
          ) src
    ON ( TG.ord <= ABS(src.diffamt) )
    WHEN MATCHED THEN
    UPDATE SET TG.expensamt2 = src.expensamt2;

    DELETE   VGT.TT_ACACC0216R_ACORDD2
    WHERE   TRIM(deptcode) IS NOT NULL
        AND TRIM(empcode) IS NULL;

    -- 공통사원의 경비를 영업사원으로 분배(매출액기준)
    FOR  rec IN
    (
        SELECT  SUM(expensamt1 + expensamt2)   AS alias1
        FROM    VGT.TT_ACACC0216R_ACORDD2
        WHERE   TRIM(empcode) IS NULL
    )
    LOOP
        p_tmpamt := rec.alias1   ;
    END LOOP;

    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_ACORDD22';
    INSERT INTO VGT.TT_ACACC0216R_ACORDD22
    SELECT  ROW_NUMBER() OVER ( ORDER BY A.expensamt3  ) ord  ,
            A.empcode ,
            A.deptcode ,
            A.expensamt3
    FROM (
            SELECT  A.empcode ,
                    A.deptcode ,
                    CASE WHEN b.salesamt <> 0 THEN round(p_tmpamt * A.salesamt / b.salesamt, 0) ELSE 0 END expensamt3
            FROM    (
                        SELECT  empcode ,
                                MAX(deptcode)  deptcode  ,
                                SUM(salesamt)  salesamt
                        FROM    VGT.TT_ACACC0216R_SLORDM A
                        GROUP BY empcode
                    ) A
                    JOIN (
                            SELECT SUM(salesamt)  salesamt
                            FROM VGT.TT_ACACC0216R_SLORDM
                         ) b
                        ON 1 = 1
        ) A;
    
    

    FOR REC IN 
    (
        SELECT  A.ORD, A.DEPTCODE, A.EMPCODE, B.DIFFAMT 
        FROM    VGT.TT_ACACC0216R_ACORDD22 A
                JOIN
                    (
                        SELECT  p_tmpamt - sum(expensamt3) AS diffamt
                        FROM    VGT.TT_ACACC0216R_ACORDD22
                    ) B
                      ON A.ord <= abs(b.diffamt)
              
    )
    LOOP
        UPDATE  VGT.TT_ACACC0216R_ACORDD22  
            SET expensamt3 = expensamt3 + CASE WHEN REC.DIFFAMT < 0 THEN 1 ELSE -1 END
        WHERE   ORD <= ABS(REC.DIFFAMT)
            AND ORD = REC.ORD 
            AND DEPTCODE =REC.DEPTCODE
            AND EMPCODE = REC.EMPCODE;
    END LOOP;


--    MERGE INTO VGT.TT_ACACC0216R_ACORDD22 TG
--    USING   (
--                SELECT  b.diffamt, A.expensamt3 + CASE WHEN b.diffamt < 0 THEN 1 ELSE -1 END AS expensamt3
--                FROM    VGT.TT_ACACC0216R_ACORDD22 A
--                        JOIN (
--                                SELECT  p_tmpamt - SUM(expensamt3)  diffamt
--                                FROM    VGT.TT_ACACC0216R_ACORDD22
--                             ) b   ON A.ord <= ABS(b.diffamt)
--            ) src
--    ON ( TG.ord <= src.diffamt )
--    WHEN MATCHED THEN
--    UPDATE SET TG.expensamt3 = src.expensamt3;

    DELETE VGT.TT_ACACC0216R_ACORDD2
    WHERE  TRIM(empcode) IS NULL;

    MERGE INTO VGT.TT_ACACC0216R_ACORDD2 TG
    USING (
            SELECT  b.empcode , b.expensamt3
            FROM    VGT.TT_ACACC0216R_ACORDD2 A
                    JOIN VGT.TT_ACACC0216R_ACORDD22 b
                        ON A.empcode = b.empcode
          ) src
    ON    ( TG.empcode = src.empcode )
    WHEN MATCHED THEN
        UPDATE SET TG.expensamt3 = src.expensamt3;


    INSERT INTO VGT.TT_ACACC0216R_ACORDD2
    SELECT  A.ord ,
            A.empcode ,
            A.deptcode ,
            0 ,
            0 ,
            A.expensamt3
    FROM    VGT.TT_ACACC0216R_ACORDD22 A
            LEFT JOIN VGT.TT_ACACC0216R_ACORDD2 b   ON A.empcode = b.empcode
    WHERE   b.empcode IS NULL ;


    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0216R_ACORDD3';

    INSERT INTO VGT.TT_ACACC0216R_ACORDD3
    SELECT  ROW_NUMBER() OVER ( PARTITION BY empcode ORDER BY expensamt1 + expensamt2 + expensamt3  ) ord  ,
            A.*
    FROM    (
                SELECT  A.empcode ,
                        b.custcode ,
                        CASE WHEN c.salesamt <> 0 THEN round(A.expensamt1 * b.salesamt / c.salesamt, 0) ELSE 0 END expensamt1  ,
                        CASE WHEN c.salesamt <> 0 THEN round(A.expensamt2 * b.salesamt / c.salesamt, 0) ELSE 0 END expensamt2  ,
                        CASE WHEN c.salesamt <> 0 THEN round(A.expensamt3 * b.salesamt / c.salesamt, 0) ELSE 0 END expensamt3
                FROM    VGT.TT_ACACC0216R_ACORDD2 A
                        JOIN VGT.TT_ACACC0216R_SLORDM b
                            ON      A.empcode = b.empcode
                                AND b.salesamt > 0
                        JOIN (
                                SELECT  empcode ,
                                        SUM(salesamt)  salesamt
                                FROM    VGT.TT_ACACC0216R_SLORDM
                                WHERE   salesamt > 0
                                GROUP BY empcode
                             ) c
                            ON A.empcode = c.empcode
            ) A;

   -- 매출이 없는 사원은 거래처로 분배
    INSERT INTO VGT.TT_ACACC0216R_ACORDD3
    SELECT  ROW_NUMBER() OVER ( PARTITION BY empcode ORDER BY expensamt1 + expensamt2 + expensamt3  ) ord  ,
            A.*
    FROM    (
                SELECT  A.empcode ,
                        b.custcode ,
                        CASE WHEN c.cnt <> 0 THEN round(A.expensamt1 / c.cnt, 0) ELSE 0 END expensamt1  ,
                        CASE WHEN c.cnt <> 0 THEN round(A.expensamt2 / c.cnt, 0) ELSE 0 END expensamt2  ,
                        CASE WHEN c.cnt <> 0 THEN round(A.expensamt3 / c.cnt, 0) ELSE 0 END expensamt3
                FROM    VGT.TT_ACACC0216R_ACORDD2 A
                        JOIN CMCUSTM b   ON A.empcode = b.empcode
                        JOIN (  SELECT  A.empcode ,
                                        COUNT(*)  cnt
                                FROM    VGT.TT_ACACC0216R_ACORDD2 A
                                        JOIN CMCUSTM b   ON A.empcode = b.empcode
                                GROUP BY A.empcode
                             ) c   ON A.empcode = c.empcode
                        LEFT JOIN VGT.TT_ACACC0216R_ACORDD3 D   ON A.empcode = D.empcode
                WHERE  D.empcode IS NULL
            ) A;

    INSERT INTO VGT.TT_ACACC0216R_ACORDD3
    SELECT  1 ,
            A.empcode ,
            A.empcode ,
            A.expensamt1 ,
            A.expensamt2 ,
            A.expensamt3
    FROM    VGT.TT_ACACC0216R_ACORDD2 A
            LEFT JOIN VGT.TT_ACACC0216R_ACORDD3 D   ON A.empcode = D.empcode
    WHERE  D.empcode IS NULL;


    MERGE INTO VGT.TT_ACACC0216R_ACORDD3 TG
    USING (
            SELECT  A.empcode, B.diffamt, A.expensamt1 + CASE WHEN b.diffamt < 0 THEN 1 ELSE -1 END AS expensamt1
            FROM    VGT.TT_ACACC0216R_ACORDD3 A
                    JOIN (
                            SELECT  A.empcode ,
                                    MAX(A.expensamt1)  - SUM(b.expensamt1)  diffamt
                            FROM    VGT.TT_ACACC0216R_ACORDD2 A
                                    JOIN VGT.TT_ACACC0216R_ACORDD3 b   ON A.empcode = b.empcode
                            GROUP BY A.empcode
                            HAVING MAX(A.expensamt1)  <> SUM(b.expensamt1)
                         ) b   ON       A.empcode = b.empcode
                                    AND A.ord <= ABS(b.diffamt)
          ) src
        ON ( TG.empcode = src.empcode AND TG.ord <=  ABS (SRC.diffamt) )
    WHEN MATCHED THEN
        UPDATE SET TG.expensamt1 = src.expensamt1;


    MERGE INTO VGT.TT_ACACC0216R_ACORDD3 TG
    USING (
            SELECT  B.empcode,B.diffamt , A.expensamt2 + CASE WHEN b.diffamt < 0 THEN 1 ELSE -1 END AS expensamt2
            FROM    VGT.TT_ACACC0216R_ACORDD3 A
                    JOIN (
                            SELECT  A.empcode,
                                    MAX(A.expensamt2)  - SUM(b.expensamt2)  diffamt
                            FROM    VGT.TT_ACACC0216R_ACORDD2 A
                                    JOIN VGT.TT_ACACC0216R_ACORDD3 b   ON A.empcode = b.empcode
                            GROUP BY A.empcode
                            HAVING MAX(A.expensamt2)  <> SUM(b.expensamt2)
                         ) b
                            ON      A.empcode = b.empcode
                                AND A.ord <= ABS(b.diffamt) ) src
    ON ( TG.empcode = src.empcode AND TG.ORD <= ABS (SRC.diffamt ) )
    WHEN MATCHED THEN
        UPDATE SET TG.expensamt2 = src.expensamt2;




   FOR REC IN
   (
        SELECT   b.empcode, b.diffamt,
                 A.expensamt3 + CASE WHEN b.diffamt < 0 THEN 1 ELSE -1 END AS expensamt3
        FROM    VGT.TT_ACACC0216R_ACORDD3 A
                JOIN (
                        SELECT  A.empcode ,
                                MAX(A.expensamt3)  - SUM(b.expensamt3)  diffamt
                        FROM    VGT.TT_ACACC0216R_ACORDD2 A
                                JOIN VGT.TT_ACACC0216R_ACORDD3 b   ON A.empcode = b.empcode
                        GROUP BY A.empcode
                        HAVING MAX(A.expensamt3)  <> SUM(b.expensamt3)
                    ) b   ON    A.empcode = b.empcode
                            AND A.ord <= ABS(b.diffamt)
   )
   LOOP
    UPDATE  VGT.TT_ACACC0216R_ACORDD3
    SET expensamt3 = REC.expensamt3
    WHERE  empcode = REC.empcode
        AND ord    <= ABS(REC.diffamt) ;

   END LOOP;






   -- 지점별 매출실적
    OPEN  IO_CURSOR FOR
    SELECT  A.predeptcode ,
            D.deptname predeptname  ,
            A.salesamt ,--매출액
             CASE  WHEN A.totsalesamt = 0 THEN 0 ELSE round(A.salesamt / A.totsalesamt * 100, 2) END salesfix ,--매출점유율
             RANK() OVER ( ORDER BY A.salesamt DESC  ) salesord ,--매출순위
             A.makingamt ,--매출원가
             CASE WHEN A.salesamt = 0 THEN 0 ELSE round(A.makingamt / A.salesamt * 100, 2) END makingrate ,--원가율
             A.salesamt - A.makingamt profit ,--매출이익
             CASE WHEN A.salesamt = 0 THEN 0 ELSE round((A.salesamt - A.makingamt) / A.salesamt * 100, 2) END salesprofitrate ,--매출이익율
             CASE WHEN A.totprofit = 0 THEN 0 ELSE round((A.salesamt - A.makingamt) / A.totprofit * 100, 2) END profitfix ,--이익점유율
             RANK() OVER ( ORDER BY A.salesamt - A.makingamt  ) profitord ,--이익순위
             NVL(b.expensamt1, 0) expensamt1 ,--인건비
             NVL(b.expensamt2, 0) expensamt2 ,--판매경비
             NVL(b.expensamt3, 0) expensamt3 ,--OH경비
             A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0) soonamt ,--순이익
             CASE   WHEN A.salesamt = 0 THEN 0
                    ELSE round((A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0)) / A.salesamt * 100, 2)
             END soonrate ,--순이익율
             CASE   WHEN c.totexpensamt = 0 THEN 0
                    ELSE round((A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0)) / c.totexpensamt * 100, 2)
             END soonfix ,--순이익점유율
             RANK() OVER ( ORDER BY A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0) DESC  ) sprofitord --순이익순위
    FROM (
                SELECT  predeptcode,
                        SUM(salesamt)  salesamt ,--매출액
                        SUM(totsalesamt)  totsalesamt ,--매출액합계
                        SUM(makingamt)  makingamt ,--매출원가
                        SUM(totmakingamt)  totmakingamt ,--매출원가합계
                        SUM (totprofit)  totprofit --이익합계
                FROM    (
                            SELECT  A.predeptcode ,
                                    SUM(A.salesamt)  salesamt ,--매출액
                                    MAX(b.totsalesamt)  totsalesamt ,--매출액합계
                                    SUM(A.makingamt)  makingamt ,--매출원가
                                    MAX(b.totmakingamt)  totmakingamt ,--매출원가합계
                                    MAX(b.totprofit)  totprofit --이익합계
                            FROM    VGT.TT_ACACC0216R_SLORDM A
                                    JOIN (
                                            SELECT  SUM(salesamt)  totsalesamt  ,
                                                    SUM(makingamt)  totmakingamt  ,
                                                    SUM(salesamt - makingamt)  totprofit
                                            FROM    VGT.TT_ACACC0216R_SLORDM
                                         ) b   ON 1 = 1
                            GROUP BY A.predeptcode
                            UNION
                            SELECT  DISTINCT A.predeptcode ,
                                    0 ,
                                    0 ,
                                    0 ,
                                    0 ,
                                    0
                            FROM    VGT.TT_ACACC0216R_ACORDD1 A
                                    LEFT JOIN VGT.TT_ACACC0216R_SLORDM b   ON A.predeptcode = b.predeptcode
                            WHERE   b.predeptcode IS NULL
                        )
               GROUP BY  predeptcode
            ) A
            LEFT JOIN (
                        SELECT  predeptcode ,
                                SUM(expensamt1)  expensamt1  ,
                                SUM(expensamt2)  expensamt2  ,
                                SUM(expensamt3)  expensamt3
                        FROM VGT.TT_ACACC0216R_ACORDD1
                        GROUP BY predeptcode
                      ) b   ON A.predeptcode = b.predeptcode
            LEFT JOIN (
                        SELECT SUM(expensamt1 + expensamt2 + expensamt3)  totexpensamt
                        FROM VGT.TT_ACACC0216R_ACORDD1
                      ) c   ON 1 = 1
            LEFT JOIN CMDEPTM D   ON TRIM(A.predeptcode) = TRIM(D.deptcode)
    ORDER BY sprofitord ;

    -- 부서별 매출실적
    OPEN  IO_CURSOR2 FOR
    SELECT  A.predeptcode ,
            E.deptname predeptname  ,
            A.deptcode ,
            D.deptname ,
            A.salesamt ,--매출액
            CASE   WHEN A.totsalesamt = 0 THEN 0
                   ELSE round(A.salesamt / A.totsalesamt * 100, 2)
            END salesfix ,--매출점유율
            RANK() OVER ( ORDER BY A.salesamt DESC  ) salesord ,--매출순위
            TRUNC(A.makingamt,0)  makingamt,--매출원가
            CASE   WHEN A.salesamt = 0 THEN 0
                    ELSE round(A.makingamt / A.salesamt * 100, 2)
            END makingrate ,--원가율
            A.salesamt - A.makingamt profit ,--매출이익
            CASE WHEN A.salesamt = 0 THEN 0
                 ELSE round((A.salesamt - A.makingamt) / A.salesamt * 100, 2)
            END salesprofitrate ,--매출이익율
            CASE WHEN A.totprofit = 0 THEN 0
                 ELSE round((A.salesamt - A.makingamt) / A.totprofit * 100, 2)
            END profitfix ,--이익점유율
            RANK() OVER ( ORDER BY A.salesamt - A.makingamt  DESC ) profitord ,--이익순위
            NVL(b.expensamt1, 0) expensamt1 ,--인건비
            NVL(b.expensamt2, 0) expensamt2 ,--판매경비
            NVL(b.expensamt3, 0) expensamt3 ,--OH경비
            A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0) soonamt ,--순이익
            CASE    WHEN A.salesamt = 0 THEN 0
                    ELSE round((A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0)) / A.salesamt * 100, 2)
            END soonrate ,--순이익율
            CASE
                 WHEN c.totexpensamt = 0 THEN 0
            ELSE round((A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0)) / c.totexpensamt * 100, 2)
            END soonfix ,--순이익점유율
            RANK() OVER ( ORDER BY A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0) DESC  ) sprofitord --순이익순위
    FROM    (
                SELECT  A.deptcode ,
                        MAX(A.predeptcode)  predeptcode ,--지점
                        SUM(A.salesamt)  salesamt ,--매출액
                        MAX(b.totsalesamt)  totsalesamt ,--매출액합계
                        SUM(A.makingamt)  makingamt ,--매출원가
                        MAX(b.totmakingamt)  totmakingamt ,--매출원가합계
                        MAX(b.totprofit)  totprofit --이익합계
                FROM    VGT.TT_ACACC0216R_SLORDM A
                        JOIN (
                                SELECT  SUM(salesamt)  totsalesamt  ,
                                        SUM(makingamt)  totmakingamt  ,
                                        SUM(salesamt - makingamt)  totprofit
                                FROM    VGT.TT_ACACC0216R_SLORDM
                             ) b
                             ON 1 = 1
                GROUP BY A.deptcode
                UNION
                SELECT  DISTINCT A.deptcode ,
                        A.predeptcode ,
                        0 ,
                        0 ,
                        0 ,
                        0 ,
                        0
                FROM    VGT.TT_ACACC0216R_ACORDD1 A
                        LEFT JOIN VGT.TT_ACACC0216R_SLORDM b   ON A.deptcode = b.deptcode
                WHERE   b.deptcode IS NULL
            ) A
            LEFT JOIN (
                        SELECT  deptcode ,
                                SUM(expensamt1)  expensamt1  ,
                                SUM(expensamt2)  expensamt2  ,
                                SUM(expensamt3)  expensamt3
                        FROM    VGT.TT_ACACC0216R_ACORDD1
                        GROUP BY deptcode
                     ) b
                    ON A.deptcode = b.deptcode
            LEFT JOIN (
                        SELECT  SUM(expensamt1 + expensamt2 + expensamt3)  totexpensamt
                        FROM    VGT.TT_ACACC0216R_ACORDD1
                      ) c
                    ON 1 = 1
            LEFT JOIN CMDEPTM D   ON TRIM(A.deptcode) = TRIM(D.deptcode)
            LEFT JOIN CMDEPTM E   ON TRIM(A.predeptcode) = TRIM(E.deptcode)
    ORDER BY sprofitord ;

   -- 사원별 매출실적
    OPEN  IO_CURSOR3 FOR
    SELECT   A.predeptcode ,
             f.deptname predeptname  ,
             A.deptcode ,
             E.deptname ,
             A.empcode ,
             D.empname ,
             G.divname jikwi  ,
             A.salesamt ,--매출액
             CASE
                  WHEN A.totsalesamt = 0 THEN 0
                  ELSE round(A.salesamt / A.totsalesamt * 100, 2)
             END salesfix ,--매출점유율
             RANK() OVER ( ORDER BY A.salesamt DESC  ) salesord ,--매출순위
             A.makingamt ,--매출원가
             CASE
                  WHEN A.salesamt = 0 THEN 0
                  ELSE round(A.makingamt / A.salesamt * 100, 2)
                END makingrate ,--원가율
             A.salesamt - A.makingamt profit ,--매출이익
             CASE
                  WHEN A.salesamt = 0 THEN 0
                  ELSE round((A.salesamt - A.makingamt) / A.salesamt * 100, 2)
             END salesprofitrate ,--매출이익율
             CASE
                  WHEN A.totprofit = 0 THEN 0
                  ELSE round((A.salesamt - A.makingamt) / A.totprofit * 100, 2)
             END profitfix ,--이익점유율
             RANK() OVER ( ORDER BY A.salesamt - A.makingamt DESC ) profitord ,--이익순위
             NVL(b.expensamt1, 0) expensamt1 ,--인건비
             NVL(b.expensamt2, 0) expensamt2 ,--판매경비
             NVL(b.expensamt3, 0) expensamt3 ,--OH경비
             A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0) soonamt ,--순이익
             CASE
                  WHEN A.salesamt = 0 THEN 0
             ELSE round((A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0)) / A.salesamt * 100, 2)
             END soonrate ,--순이익율
             CASE
                  WHEN c.totexpensamt = 0 THEN 0
             ELSE round((A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0)) / c.totexpensamt * 100, 2)
             END soonfix ,--순이익점유율
             RANK() OVER ( ORDER BY A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0) DESC  ) sprofitord --순이익순위
    FROM (
            SELECT  A.empcode ,
                    MAX(A.predeptcode)  predeptcode ,--지점
                    MAX(A.deptcode)  deptcode ,--부서
                    SUM(A.salesamt)  salesamt ,--매출액
                    MAX(b.totsalesamt)  totsalesamt ,--매출액합계
                    SUM(A.makingamt)  makingamt ,--매출원가
                    MAX(b.totmakingamt)  totmakingamt ,--매출원가합계
                    MAX(b.totprofit)  totprofit --이익합계
            FROM    VGT.TT_ACACC0216R_SLORDM A
                    JOIN (  SELECT  SUM(salesamt)  totsalesamt  ,
                                    SUM(makingamt)  totmakingamt  ,
                                    SUM(salesamt - makingamt)  totprofit
                            FROM    VGT.TT_ACACC0216R_SLORDM
                         ) b   ON 1 = 1
            GROUP BY A.empcode
            UNION
            SELECT DISTINCT A.empcode ,
                           c.predeptcode ,
                           c.deptcode ,
                           0 ,
                           0 ,
                           0 ,
                           0 ,
                           0
           FROM VGT.TT_ACACC0216R_ACORDD2 A
                  LEFT JOIN VGT.TT_ACACC0216R_SLORDM b   ON A.empcode = b.empcode
                  LEFT JOIN VGT.TT_ACACC0216R_CMEMPM c   ON A.empcode = c.empcode
            WHERE  b.empcode IS NULL ) A
           LEFT JOIN ( SELECT empcode ,
                              SUM(expensamt1)  expensamt1  ,
                              SUM(expensamt2)  expensamt2  ,
                              SUM(expensamt3)  expensamt3
                       FROM VGT.TT_ACACC0216R_ACORDD2
                         GROUP BY empcode ) b   ON A.empcode = b.empcode
           LEFT JOIN ( SELECT SUM(expensamt1 + expensamt2 + expensamt3)  totexpensamt
                       FROM VGT.TT_ACACC0216R_ACORDD2  ) c   ON 1 = 1
           LEFT JOIN CMEMPM D   ON A.empcode = D.empcode
           LEFT JOIN CMDEPTM E   ON TRIM(A.deptcode) = TRIM(E.deptcode)
           LEFT JOIN CMDEPTM f   ON TRIM(A.predeptcode) = TRIM(f.deptcode)
           LEFT JOIN CMCOMMONM G   ON G.cmmcode = 'PS29'
           AND D.positiondiv = G.divcode
    ORDER BY sprofitord ;
   -- 거래처별 매출실적
    OPEN  IO_CURSOR4 FOR
    SELECT   A.predeptcode ,
             G.deptname predeptname  ,
             A.deptcode ,
             f.deptname ,
             A.empcode ,
             E.empname ,
             h.divname jikwi  ,
             A.custcode ,
             D.custname ,
             A.salesamt ,--매출액
             CASE
                  WHEN A.totsalesamt = 0 THEN 0
                  ELSE round(A.salesamt / A.totsalesamt * 100, 2)
             END salesfix ,--매출점유율
             RANK() OVER ( ORDER BY A.salesamt DESC  ) salesord ,--매출순위
             A.makingamt ,--매출원가
             CASE
                  WHEN A.salesamt = 0 THEN 0
                  ELSE round(A.makingamt / A.salesamt * 100, 2)
             END makingrate ,--원가율
             A.salesamt - A.makingamt profit ,--매출이익
             CASE
                  WHEN A.salesamt = 0 THEN 0
                  ELSE round((A.salesamt - A.makingamt) / A.salesamt * 100, 2)
             END salesprofitrate ,--매출이익율
             CASE
                  WHEN A.totprofit = 0 THEN 0
                  ELSE round((A.salesamt - A.makingamt) / A.totprofit * 100, 2)
             END profitfix ,--이익점유율
             RANK() OVER ( ORDER BY A.salesamt - A.makingamt DESC ) profitord ,--이익순위
             NVL(b.expensamt1, 0) expensamt1 ,--인건비
             NVL(b.expensamt2, 0) expensamt2 ,--판매경비
             NVL(b.expensamt3, 0) expensamt3 ,--OH경비
             A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0) soonamt ,--순이익
             CASE
                  WHEN A.salesamt = 0 THEN 0
                  ELSE round((A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0)) / A.salesamt * 100, 2)
             END soonrate ,--순이익율
             CASE
                  WHEN c.totexpensamt = 0 THEN 0
                  ELSE round((A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0)) / c.totexpensamt * 100, 2)
             END soonfix ,--순이익점유율
             RANK() OVER ( ORDER BY A.salesamt - A.makingamt - NVL(b.expensamt1 + b.expensamt2 + b.expensamt3, 0) DESC  ) sprofitord --순이익순위
    FROM    (
                SELECT  A.custcode ,
                        MAX(A.predeptcode)  predeptcode ,--지점
                        MAX(A.deptcode)  deptcode ,--부서
                        MAX(A.empcode)  empcode ,--사원
                        SUM(A.salesamt)  salesamt ,--매출액
                        MAX(b.totsalesamt)  totsalesamt ,--매출액합계
                        SUM(A.makingamt)  makingamt ,--매출원가
                        MAX(b.totmakingamt)  totmakingamt ,--매출원가합계
                        MAX(b.totprofit)  totprofit --이익합계
               FROM     VGT.TT_ACACC0216R_SLORDM A
                        JOIN (
                                SELECT  SUM(salesamt)  totsalesamt  ,
                                        SUM(makingamt)  totmakingamt  ,
                                        SUM(salesamt - makingamt)  totprofit
                                FROM    VGT.TT_ACACC0216R_SLORDM  ) b   ON 1 = 1
                GROUP BY A.custcode
                UNION
                SELECT DISTINCT A.custcode ,
                               c.predeptcode ,
                               c.deptcode ,
                               A.empcode ,
                               0 ,
                               0 ,
                               0 ,
                               0 ,
                               0
               FROM VGT.TT_ACACC0216R_ACORDD3 A
                      LEFT JOIN VGT.TT_ACACC0216R_SLORDM b   ON A.custcode = b.custcode
                      LEFT JOIN VGT.TT_ACACC0216R_CMEMPM c   ON A.empcode = c.empcode
                WHERE  b.custcode IS NULL ) A
               LEFT JOIN ( SELECT custcode ,
                                  SUM(expensamt1)  expensamt1  ,
                                  SUM(expensamt2)  expensamt2  ,
                                  SUM(expensamt3)  expensamt3
                           FROM VGT.TT_ACACC0216R_ACORDD3
                             GROUP BY custcode ) b   ON A.custcode = b.custcode
               LEFT JOIN ( SELECT SUM(expensamt1 + expensamt2 + expensamt3)  totexpensamt
                            FROM  VGT.TT_ACACC0216R_ACORDD3  ) c   ON 1 = 1
               LEFT JOIN CMCUSTM D   ON A.custcode = D.custcode
               LEFT JOIN CMEMPM E   ON A.empcode = E.empcode
               LEFT JOIN CMDEPTM f   ON A.deptcode = f.deptcode
               LEFT JOIN CMDEPTM G   ON A.predeptcode = G.deptcode
               LEFT JOIN CMCOMMONM h   ON h.cmmcode = 'PS29'
               AND E.positiondiv = h.divcode
    ORDER BY sprofitord ;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

    IF (IO_CURSOR2 IS NULL) THEN
        OPEN IO_CURSOR2 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

    IF (IO_CURSOR3 IS NULL) THEN
        OPEN IO_CURSOR3 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

    IF (IO_CURSOR4 IS NULL) THEN
        OPEN IO_CURSOR4 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
