CREATE PROCEDURE        spACbudg0024P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbudg0024P
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-10-17
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2017-01-02
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 사원별월예산설정관리를 등록,수정,삭제,조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_budgym		IN	   VARCHAR2 DEFAULT '',
	p_deptcode		IN	   VARCHAR2 DEFAULT '',
	p_acccode		IN	   VARCHAR2 DEFAULT '',
	p_empcode		IN	   VARCHAR2 DEFAULT '',
	p_budgamt		IN	   FLOAT    DEFAULT 0,
	p_remark		IN	   VARCHAR2 DEFAULT '',
	p_iempcode		IN	   VARCHAR2 DEFAULT '',
	p_zero			IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	ip_deptcode   VARCHAR2(20) := p_deptcode;
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S')
	THEN
		OPEN IO_CURSOR FOR
			SELECT	 a.compcode,
					 a.budgym,
					 a.empcode,
					 b.empname empname,
					 c.deptname deptname,
					 a.acccode,
					 D.accname accname,
					 a.budgamt budgamt,
					 a.addamt addamt,
					 a.budgamt + a.addamt budgtot,
					 a.slipamt,
					 a.remark
			FROM	 ACBUDGYYE a
					 LEFT JOIN CMEMPM b ON a.empcode = b.empcode
					 LEFT JOIN CMDEPTM c ON b.deptcode = c.deptcode
					 LEFT JOIN ACACCM D ON a.acccode = D.acccode
			WHERE	 a.compcode = p_compcode
					 AND a.budgym = p_budgym
					 AND NVL(b.deptcode, ' ') LIKE ip_deptcode || '%'
					 AND a.acccode LIKE p_acccode || '%'
			ORDER BY a.empcode, a.acccode;
	ELSIF (p_div = 'SC')
	THEN
		FOR rec IN (SELECT COUNT(*) AS alias1
					FROM   ACBUDGYYE
					WHERE  compcode = p_compcode
						   AND budgym = p_budgym
						   AND empcode = p_empcode
						   AND acccode = p_acccode)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;
	ELSIF (p_div = 'I')
	THEN
		INSERT INTO ACBUDGYYE(compcode,
							  budgym,
							  empcode,
							  acccode,
							  budgamt,
							  addamt,
							  slipamt,
							  remark,
							  insertdt,
							  iempcode)
			(SELECT p_compcode,
					p_budgym,
					p_empcode,
					p_acccode,
					p_budgamt,
					0,
					0,
					p_remark,
					SYSDATE,
					p_iempcode
			 FROM	DUAL);
	ELSIF (p_div = 'U')
	THEN
		UPDATE ACBUDGYYE
		SET    budgamt = p_budgamt, remark = p_remark, updatedt = SYSDATE, uempcode = p_iempcode
		WHERE  compcode = p_compcode
			   AND budgym = p_budgym
			   AND empcode = p_empcode
			   AND acccode = p_acccode;
	ELSIF (p_div = 'D')
	THEN
		DELETE ACBUDGYYE
		WHERE  compcode = p_compcode
			   AND budgym = p_budgym
			   AND empcode = p_empcode
			   AND acccode = p_acccode;
	ELSIF (p_div = 'CM')
	THEN
		DELETE ACBUDGYYE
		WHERE  compcode = p_compcode
			   AND budgym = p_budgym;

		INSERT INTO ACBUDGYYE(compcode,
							  budgym,
							  empcode,
							  acccode,
							  budgamt,
							  addamt,
							  slipamt,
							  remark,
							  insertdt,
							  iempcode)
			(SELECT compcode,
					p_budgym,
					empcode,
					acccode,
					budgamt,
					addamt,
					slipamt,
					remark,
					SYSDATE,
					p_iempcode
			 FROM	ACBUDGYYE
			 WHERE	compcode = p_compcode
					AND budgym = TO_CHAR(ADD_MONTHS(TO_DATE(p_budgym, 'YYYY-MM'), -1), 'YYYY-MM'));
	ELSIF (p_div = 'SS')
	THEN
		OPEN IO_CURSOR FOR
			SELECT a.*
			FROM   ACBUDGYYE a
				   JOIN SYSPARAMETERMANAGE b
					   ON b.parametercode = 'acbudgsaleacc'
						  AND a.acccode IN (b.value1, b.value2, b.value3)
			WHERE  a.compcode = p_compcode
				   AND a.budgym = p_budgym;
	ELSIF (p_div = 'CS')
	THEN
		DECLARE
			p_preym 	   VARCHAR2(7);
			p_predate	   VARCHAR2(10);
			p_preym2	   VARCHAR2(7);
			p_value2	   VARCHAR2(20);
			p_value3	   VARCHAR2(20);
			p_basisym	   VARCHAR2(7);
			p_addper	   FLOAT(53);
			p_turncnt	   FLOAT(53);
			p_mtargetper   FLOAT(53);
			p_minusper	   FLOAT(53);
			-- 불량채권 집계
			p_dt		   DATE;
		BEGIN
			p_preym := TO_CHAR(ADD_MONTHS(TO_DATE(p_budgym, 'YYYY-MM'), -1), 'YYYY-MM');
			p_preym2 := TO_CHAR(ADD_MONTHS(TO_DATE(p_budgym, 'YYYY-MM'), -2), 'YYYY-MM');

			FOR rec IN (SELECT value2 --, @value3 = value3
						FROM   SYSPARAMETERMANAGE
						WHERE  parametercode = 'acbudgsaleacc')
			LOOP
				p_value2 := rec.value2;
			END LOOP;

			FOR rec IN (SELECT SUBSTR(value2, 1, INSTR(value2, ';', 0) - 1) AS alias1
						FROM   SYSPARAMETERMANAGE
						WHERE  parametercode = 'calprofitplant')
			LOOP
				ip_deptcode := rec.alias1;
			END LOOP;

			EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACBUDG0024P_CMEMPM ';

			-- 영업사원 임시파일을 생성
			INSERT INTO VGT.TT_ACBUDG0024P_CMEMPM
				(SELECT a.empcode, a.empname, a.deptcode, b.deptname, a.positiondiv
				 FROM	CMEMPM a
						JOIN (SELECT deptcode, deptname, predeptcode -- 영업부서 임시파일을 생성
							  FROM	 CMDEPTM
							  WHERE  deptcode LIKE ip_deptcode || '%'
									 AND LENGTH(RTRIM(deptcode)) >= 7
									 AND deptcode NOT IN ('M107010')) b
							ON a.deptcode = b.deptcode
				 WHERE	a.responsibilitydiv = '0003'
						--AND trim(a.retiredt) is null );
                        and NVL(outyn,'N') = 'N');

			-- 접대비 예산설정
			FOR rec IN (SELECT MAX(budgym) AS alias1
						FROM   ACBUDGYYES
						WHERE  compcode = p_compcode
							   AND budgym <= p_preym
							   AND targetdiv = '10')
			LOOP
				p_basisym := rec.alias1;
			END LOOP;

			p_addper := 0;
			p_turncnt := 0;
			p_mtargetper := 0;
			p_minusper := 0;

			FOR rec IN (SELECT addper, turncnt, mtargetper, minusper
						FROM   ACBUDGYYES
						WHERE  compcode = p_compcode
							   AND budgym = p_basisym
							   AND targetdiv = '10'
							   AND targetper = 100)
			LOOP
				p_addper := rec.addper;
				p_turncnt := rec.turncnt;
				p_mtargetper := rec.mtargetper;
				p_minusper := rec.minusper;
			END LOOP;

			EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0024P_SLTARGETSALEM';

			-- 전월 목표/수금실적 집계
			INSERT INTO VGT.TT_ACBUDG0024P_SLTARGETSALEM
				(SELECT   a.empcode, MAX(a.deptcode) deptcode, SUM(a.targetamt) targetamt
				 FROM	  SLTARGETSALEM a JOIN VGT.TT_ACBUDG0024P_CMEMPM b ON a.empcode = b.empcode
				 WHERE	  a.yearmonth = p_preym
						  AND a.saldiv = 'C'
				 GROUP BY a.empcode
				 HAVING   SUM(a.targetamt) > 0);

			INSERT INTO VGT.TT_ACBUDG0024P_SLCOLM
				(SELECT   a.empcode, MAX(a.deptcode) deptcode, SUM(a.colamt) colamt
				 FROM	  SLCOLM a JOIN VGT.TT_ACBUDG0024P_CMEMPM b ON a.empcode = b.empcode
				 WHERE	  a.saldiv = 'C01'
						  AND a.statediv = '09'
						  AND a.appdate LIKE p_preym || '%'
						  AND a.coldiv < '50'
				 GROUP BY a.empcode);

			EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0024P_ACBUDGYYES';

			INSERT INTO VGT.TT_ACBUDG0024P_ACBUDGYYES
				(SELECT a.deptcode,
						a.targetamt,
						NVL(b.colamt, 0) colamt,
						NVL(b.colamt, 0) / a.targetamt * 100 colper,
						0 targetper,
						0 applyper,
						0 addper,
						0 minusper
				 FROM	(SELECT   deptcode, SUM(targetamt) targetamt
						 FROM	  VGT.TT_ACBUDG0024P_SLTARGETSALEM
						 GROUP BY deptcode
						 HAVING   SUM(targetamt) > 0) a
						LEFT JOIN (SELECT	deptcode, SUM(colamt) colamt
								   FROM 	VGT.TT_ACBUDG0024P_SLCOLM
								   GROUP BY deptcode) b
							ON a.deptcode = b.deptcode);

			MERGE INTO VGT.TT_ACBUDG0024P_ACBUDGYYES a
			USING	   (SELECT A.DEPTCODE,
							   A.TARGETAMT,
							   A.COLAMT,
							   A.COLPER,
							   A.ADDPER,
							   A.MINUSPER,
							   b.targetper,
							   b.applyper
						FROM   VGT.TT_ACBUDG0024P_ACBUDGYYES a
							   JOIN (SELECT a.deptcode, b.*
									 FROM	(SELECT   a.deptcode, MAX(b.targetper) targetper
											 FROM	  VGT.TT_ACBUDG0024P_ACBUDGYYES a
													  JOIN ACBUDGYYES b
														  ON b.compcode = p_compcode
															 AND b.budgym = p_basisym
															 AND b.targetdiv = '10'
															 AND a.colper >= b.targetper
											 GROUP BY a.deptcode) a
											JOIN ACBUDGYYES b
												ON b.compcode = p_compcode
												   AND b.budgym = p_basisym
												   AND b.targetdiv = '10'
												   AND a.targetper = b.targetper) b
								   ON a.deptcode = b.deptcode) src
			ON		   (NVL(A.DEPTCODE, ' ') = NVL(SRC.DEPTCODE, ' ')
						AND NVL(A.TARGETAMT, 0) = NVL(SRC.TARGETAMT, 0)
						AND NVL(A.COLAMT, 0) = NVL(SRC.COLAMT, 0)
						AND NVL(A.COLPER, 0) = NVL(SRC.COLPER, 0)
						AND NVL(A.ADDPER, 0) = NVL(SRC.ADDPER, 0)
						AND NVL(A.MINUSPER, 0) = NVL(SRC.MINUSPER, 0))
			WHEN MATCHED
			THEN
				UPDATE SET a.targetper = src.targetper, a.applyper = src.applyper;

			-- 전전월 목표/수금실적 집계

			MERGE INTO VGT.TT_ACBUDG0024P_ACBUDGYYES a
			USING	   (SELECT A.DEPTCODE,
							   A.TARGETAMT,
							   A.COLAMT,
							   A.COLPER,
							   A.TARGETPER,
							   A.APPLYPER,
							   A.MINUSPER
						FROM   VGT.TT_ACBUDG0024P_ACBUDGYYES a
							   JOIN (SELECT   deptcode
									 FROM	  VGT.TT_ACBUDG0024P_ACBUDGYYES
									 GROUP BY deptcode
									 HAVING   SUM(targetamt) <= SUM(colamt)) b
								   ON a.deptcode = b.deptcode
							   JOIN (SELECT a.deptcode
									 FROM	(SELECT   deptcode, SUM(targetamt) targetamt
											 FROM	  (SELECT	a.empcode, MAX(a.deptcode) deptcode, SUM(a.targetamt) targetamt
													   FROM 	SLTARGETSALEM a JOIN VGT.TT_ACBUDG0024P_CMEMPM b ON a.empcode = b.empcode
													   WHERE	a.yearmonth = p_preym2
																AND a.saldiv = 'C'
													   GROUP BY a.empcode
													   HAVING	SUM(a.targetamt) > 0)
											 GROUP BY deptcode) a
											JOIN (SELECT   deptcode, SUM(colamt) colamt
												  FROM	   (SELECT	 a.empcode, MAX(a.deptcode) deptcode, SUM(a.colamt) colamt
															FROM	 SLCOLM a JOIN VGT.TT_ACBUDG0024P_CMEMPM b ON a.empcode = b.empcode
															WHERE	 a.saldiv = 'C01'
																	 AND a.statediv = '09'
																	 AND a.appdate LIKE p_preym2 || '%'
																	 AND a.coldiv < '50'
															GROUP BY a.empcode)
												  GROUP BY deptcode) b
												ON a.deptcode = b.deptcode
									 WHERE	a.targetamt <= b.colamt) c
								   ON b.deptcode = c.deptcode) src
			ON		   (NVL(A.DEPTCODE, ' ') = NVL(SRC.DEPTCODE, ' ')
						AND NVL(A.TARGETAMT, 0) = NVL(SRC.TARGETAMT, 0)
						AND NVL(A.COLAMT, 0) = NVL(SRC.COLAMT, 0)
						AND NVL(A.COLPER, 0) = NVL(SRC.COLPER, 0)
						AND NVL(A.TARGETPER, 0) = NVL(SRC.TARGETPER, 0)
						AND NVL(A.APPLYPER, 0) = NVL(SRC.APPLYPER, 0)
						AND NVL(A.MINUSPER, 0) = NVL(SRC.MINUSPER, 0))
			WHEN MATCHED
			THEN
				UPDATE SET a.addper = p_addper;

			IF p_preym = TO_CHAR(SYSDATE, 'YYYY-MM')
			THEN
				p_dt := TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD'), 'YYYY-MM-DD');
			ELSIF p_preym < TO_CHAR(SYSDATE, 'YYYY-MM')
			THEN
				p_dt := LAST_DAY(TO_DATE(p_preym, 'YYYY-MM')); -- 조회월의 마지막날
			END IF;

			EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0024P_GIGANAMT';

			-- 기간금액
			INSERT INTO VGT.TT_ACBUDG0024P_GIGANAMT
				(SELECT   a.custcode, NVL(SUM(CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN a.totamt WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -a.colamt ELSE -a.totamt END), 0) giganamt
				 FROM	  vnSalesResult a
						  JOIN (SELECT	 a.custcode, yearmonth, MAX(a.utdiv) utdiv, MAX(a.turncnt) turncnt
								FROM	 SLRESULTM a
										 JOIN CMCUSTM b
											 ON a.custcode = b.custcode
												AND b.custdiv NOT IN ('8', '9')
								WHERE	 yearmonth = p_preym
								GROUP BY a.custcode, a.yearmonth) b
							  ON a.custcode = b.custcode
								 AND b.yearmonth = p_preym
								 AND b.turncnt >= p_turncnt
				 WHERE	  SUBSTR(a.saldiv, 0, 1) = 'A'
						  AND SUBSTR(a.saldiv, -2, 2) < '60'
						  AND (TO_CHAR(p_dt - p_turncnt, 'YYYY-MM-DD') < appdate
							   AND a.appdate <= p_dt)
						  AND statediv = '09'
				 GROUP BY a.custcode);

			EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0024P_ACRTTEMP';

			-- 현재잔고
			INSERT INTO VGT.TT_ACBUDG0024P_ACRTTEMP
				(SELECT   a.custcode, MAX(a.deptcode) deptcode, MAX(a.empcode) empcode, MAX(NVL(c.giganamt, 0)) balance, SUM(a.balance) - MAX(NVL(c.giganamt, 0)) silbalance -- 실불량잔고
				 FROM	  vnResults a -- 마감
						  JOIN VGT.TT_ACBUDG0024P_CMEMPM b ON a.empcode = b.empcode
						  LEFT JOIN VGT.TT_ACBUDG0024P_GIGANAMT c ON a.custcode = c.custcode
				 WHERE	  a.yearmonth = p_preym
						  AND (turncnt >= p_turncnt)
						  AND custdiv NOT IN ('8', '9')
				 GROUP BY a.custcode);

			-- 부서별 잔고
			MERGE INTO VGT.TT_ACBUDG0024P_ACBUDGYYES a
			USING	   (SELECT A.ADDPER,
							   A.APPLYPER,
							   A.COLAMT,
							   A.COLPER,
							   A.DEPTCODE,
							   A.MINUSPER,
							   A.TARGETAMT,
							   A.TARGETPER
						FROM   VGT.TT_ACBUDG0024P_ACBUDGYYES a
							   JOIN (SELECT   deptcode,
											  SUM(totbalance) totbalance,
											  SUM(balance) balance,
											  SUM(silbalance) silbalance,
											  CASE WHEN NVL(SUM(totbalance), 0) <> 0 THEN ROUND(NVL(SUM(balance), 0) / NVL(SUM(totbalance), 0) * 100, 2) ELSE 0 END rate, --기간불량율
											  CASE WHEN NVL(SUM(totbalance), 0) <> 0 THEN ROUND(NVL(SUM(silbalance), 0) / NVL(SUM(totbalance), 0) * 100, 2) ELSE 0 END silrate --실불량율
									 FROM	  (SELECT a.deptcode, a.balance totbalance, 0 balance, 0 silbalance
											   FROM   vnResults a JOIN VGT.TT_ACBUDG0024P_CMEMPM b ON a.empcode = b.empcode
											   WHERE  a.yearmonth = p_preym
													  AND a.custdiv NOT IN ('8', '9')
											   UNION ALL
											   SELECT deptcode, 0 totbalance, balance, silbalance FROM VGT.TT_ACBUDG0024P_ACRTTEMP) a
									 GROUP BY deptcode) b
								   ON a.deptcode = b.deptcode
									  AND b.silrate >= p_mtargetper) src
			ON		   (NVL(A.ADDPER, 0) = NVL(SRC.ADDPER, 0)
						AND NVL(A.APPLYPER, 0) = NVL(SRC.APPLYPER, 0)
						AND NVL(A.COLAMT, 0) = NVL(SRC.COLAMT, 0)
						AND NVL(A.COLPER, 0) = NVL(SRC.COLPER, 0)
						AND NVL(A.DEPTCODE, ' ') = NVL(SRC.DEPTCODE, ' ')
						AND NVL(A.MINUSPER, 0) = NVL(SRC.MINUSPER, 0)
						AND NVL(A.TARGETAMT, 0) = NVL(SRC.TARGETAMT, 0)
						AND NVL(A.TARGETPER, 0) = NVL(SRC.TARGETPER, 0))
			WHEN MATCHED
			THEN
				UPDATE SET a.minusper = p_minusper;

			DELETE ACBUDGYYE
			WHERE  compcode = p_compcode
				   AND budgym = p_budgym
				   AND acccode IN (p_value2, p_value3);

			INSERT INTO ACBUDGYYE(compcode,
								  budgym,
								  empcode,
								  acccode,
								  budgamt,
								  addamt,
								  slipamt,
								  remark,
								  insertdt,
								  iempcode)
				SELECT	 p_compcode,
						 p_budgym,
						 a.empcode,
						 p_value2,
						 CASE
							 WHEN p_zero = 'Y'
							 THEN
								 0
							 ELSE
								 CASE a.empcode WHEN '193001' THEN 300000 WHEN '197001' THEN 300000 WHEN '204006' THEN 500000 WHEN '211009' THEN 200000 WHEN '212011' THEN 200000 WHEN '211005' THEN 300000 ELSE NVL(FLOOR(b.colamt * (100 - c.minusper) * (c.applyper + c.addper) / 10000000) * 1000, 0) END
						 END
							 col,
						 0,
						 0,
						 '영업사원예산 자동생성',
						 SYSDATE,
						 p_iempcode
				FROM	 VGT.TT_ACBUDG0024P_CMEMPM a
						 LEFT JOIN VGT.TT_ACBUDG0024P_SLCOLM b ON a.empcode = b.empcode
						 LEFT JOIN VGT.TT_ACBUDG0024P_ACBUDGYYES c ON b.deptcode = c.deptcode
				ORDER BY a.empcode;

		END;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
