CREATE FUNCTION fnsalpower_emplist /******
작 성 자: 이세민
작성일자: 2013-04-10
설    명: 영업에서 사용하는 관리 권한 처리를 위해 사용하는 테이블 반환함수
예    제: select * from dbo.fnsalpower_emplist('50') -- 영업본부 전체에 해당하는 사원 리스트 추출
          select * from dbo.fnsalpower_emplist('00062601') --사번이 00062601인 사람만 조회됨.

-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
--수정일자      : 2016-11-23

******/
(
  p_setvalues IN VARCHAR2 DEFAULT ''
)
RETURN FN_SALPOWER_EMPLIST_TABLE
AS

    i NUMBER := 1;

    --함수내에서 변수 저장용 변수 초기화
    salPowerEmpListRecode FN_SALPOWER_EMPLIST_TABLE := FN_SALPOWER_EMPLIST_TABLE();

BEGIN

    IF ( NVL(TRIM(p_setvalues),'') IS NULL OR p_setvalues = '%' ) THEN

        FOR  rec IN (
            SELECT empcode FROM CMEMPM ORDER BY empcode ASC
        )
        LOOP
            salPowerEmpListRecode.EXTEND;
            salPowerEmpListRecode(i) := FN_SALPOWER_EMPLIST_VARIABLE(rec.empcode);
            i := i+1;
        END LOOP;


    ELSE

        FOR  rec IN (   WITH CTEWORDERS(DEPTCODE, PREDEPTCODE, NAME, org_level) AS
                        (
                            SELECT DEPTCODE, PREDEPTCODE, deptname, 1  Org_Level
                                FROM CMDEPTM
                                    WHERE DEPTCODE = p_setvalues
                            UNION ALL

                            SELECT A.DEPTCODE, A.PREDEPTCODE, A.deptname, b.org_level + 1 org_level
                                FROM    CMDEPTM A
                                        INNER JOIN CTEWORDERS b ON A.PREDEPTCODE = b.DEPTCODE
                        )

                        SELECT  DISTINCT empcode

                        FROM (  SELECT  empcode
                                FROM    CMEMPM
                                WHERE   deptcode IN ( SELECT DEPTCODE FROM CTEWORDERS )

                                UNION ALL

                                SELECT p_setvalues FROM dual
                              ) A
                        ORDER BY empcode ASC
        )

        LOOP
            salPowerEmpListRecode.EXTEND;
            salPowerEmpListRecode(i) := FN_SALPOWER_EMPLIST_VARIABLE(rec.empcode);
            i := i+1;
        END LOOP;

    END IF;

    RETURN salPowerEmpListRecode;

END;
/
