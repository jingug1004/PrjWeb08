CREATE PROCEDURE        spACacc0900HP4
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0900HP4
 -- 작 성 자         : 최용석
 -- 작성일자         : 2014-05-22
 -- 수 정 자      : 강현호
 -- E-Mail     : roykang0722@gmail.com
 -- 수정일자      : 2016-12-19
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 급여회계로드
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,--법인코드
    p_plantcode     IN VARCHAR2 DEFAULT '' ,
    p_sym           IN VARCHAR2 DEFAULT '' ,--조회년월
    p_sdt           IN VARCHAR2 DEFAULT '' ,
    p_edt           IN VARCHAR2 DEFAULT '' ,
    p_loadstatus    IN VARCHAR2 DEFAULT '' ,
    p_paybonusdiv   IN VARCHAR2 DEFAULT '' ,
    p_accdate       IN VARCHAR2 DEFAULT '' ,--회계처리일자
    p_iempcode      IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,

    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)

AS
   v_temp NUMBER := 0;
BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    FOR rec IN (    SELECT  COUNT(*) AS alias1
                    FROM    DUAL
                    WHERE EXISTS (  SELECT  *
                                    FROM    CMCLOSEM
                                    WHERE   compcode = p_compcode
                                            AND closeym = p_sym
                                            AND accdiv = 'H'
                                            AND apprcloseyn = 'Y' )
    )
    LOOP
        v_temp := rec.alias1 ;
    END LOOP;

    IF v_temp = 1 THEN

        IF (IO_CURSOR IS NULL) THEN
           OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
        END IF;

        RETURN;

    END IF;



    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0900HP4_DUAL';
    
    
    
    INSERT INTO VGT.TT_ACACC0900HP4_DUAL (

        SELECT  p_compcode ,                            -- 회사
                A.plantcode ,                           -- 사업장
                'N' ,                                   -- 선택
                A.yearmonth ,                           -- 지급년월
                p_accdate ,                             -- 전표일자
                A.paydate ,                             -- 급여지급일자
                A.paybonusdiv ,                         -- 급상여구분
                NVL(c.divname, '' ) ,                   -- 급상여구분명(PS53)
                TO_CHAR(A.chasoo) ,                     -- 차수
                A.deptcode ,                            -- 부서코드
                NVL(b.deptname, '' ) ,                  -- 부서명
                A.empcode ,                             -- 사원코드
                A.empname ,                             -- 사원명
                A.baseamt ,                             -- 기본급
                A.suamt ,                               -- 수당
                A.totbaseamt ,                          -- 총급여액
                A.totpay1 ,                             -- 직원급여(판)
                A.totpay2 ,                             -- 임원급여(판)
                A.totpay3 ,                             -- 직원급여(제)
                A.totpay4 ,                             -- 직원급여(연)
                A.totpay ,                              -- 총지급액
                A.incometax ,                           -- 소득세
                A.resitax ,                             -- 주민세
                A.pensamt ,                             -- 국민연금
                A.insuamt ,                             -- 건강보험
                A.hireamt ,                             -- 고용보험
                A.etcgoamt ,                            -- 기타공제
                A.goamt ,                               -- 공제총액
                A.payamt ,                              -- 공제지급액
                A.acatrulecode ,                        -- 분계룰코드
                A.goamt01 ,                             -- 소득세
                A.goamt05 ,                             -- 주민세
                A.goamt10 ,                             -- 국민연금
                A.goamt11 ,                             -- 국민연금소급
                A.goamt15 ,                             -- 건강보험
                A.goamt16 ,                             -- 건강보험소급
                A.goamt20 ,                             -- 고용보험
                A.goamt45 ,                             -- 연말정산소득세
                A.goamt46 ,                             -- 연말정산주민세
                A.goamt47 ,                             -- 연말정산농특세
                A.goamt91 ,                             -- 예수금(기타)
                SUBSTR(A.yearmonth, -2, 2) || '월 ' || NVL(b.deptname, '') ,
                '1' ,                                   -- 자료상태(1신규 2완료 3수정 4삭제)
                acatrulecode ,                          -- 분계룰코드
                '신규로드전송전' ,                            -- 자료상태명
                '' ,                                    -- 전표번호
                'N'                                     -- 변경여부

        FROM    (   SELECT  A.yearmonth ,-- 지급년월
                            A.paydate ,-- 지급일자
                            A.paybonusdiv ,-- 급상여구분(PS53)
                            A.chasoo ,-- 차수
                            A.deptcode ,-- 부서코드
                            A.empcode ,-- 사원코드
                            MAX(D.empname)  empname ,-- 사원명
                            MAX(A.plantcode)  plantcode  ,
                            SUM(NVL(b.baseamt, 0))  baseamt ,-- 기본급
                            SUM(NVL(b.suamt, 0))  suamt ,-- 수당금액
                            SUM(NVL(CASE WHEN A.paybonusdiv = '01' THEN b.salaryamt   END, 0))  totbaseamt ,-- 급여합
                            SUM(CASE WHEN NOT ( D.workdiv = '01' AND NVL(D.classdiv,' ') IN ( '0001','0001' ) ) AND D.accpaydiv = '2' THEN b.salaryamt ELSE 0 END)  totpay1 ,-- 직원급여(판)
                            SUM(CASE WHEN D.workdiv = '01' AND NVL(D.classdiv,' ') IN ( '0001','0001' ) THEN b.salaryamt ELSE 0 END)  totpay2 ,-- 임원급여(판)
                            SUM(CASE WHEN NOT ( D.workdiv = '01' AND NVL(D.classdiv,' ') IN ( '0001','0001' ) ) AND D.accpaydiv = '1' THEN b.salaryamt ELSE 0 END)  totpay3 ,-- 직원급여(제)
                            SUM(CASE WHEN NOT ( D.workdiv = '01' AND NVL(D.classdiv,' ') IN ( '0001','0001' ) ) AND D.accpaydiv = '3' THEN b.salaryamt ELSE 0 END)  totpay4 ,-- 직원급여(연)
                            SUM(NVL(b.totpay, 0))  totpay ,-- 총지급액
                            SUM(NVL(b.goamt800, 0))  + SUM(NVL(b.goamt045, 0))  incometax ,-- 소득세
                            SUM(NVL(b.goamt805, 0))  + SUM(NVL(b.goamt046, 0))  resitax ,-- 주민세
                            SUM(NVL(b.goamt010, 0))  + SUM(NVL(b.goamt011, 0))  pensamt ,-- 국민연금
                            SUM(NVL(b.goamt015, 0))  + SUM(NVL(b.goamt515, 0))  insuamt ,-- 건강보험
                            SUM(NVL(b.goamt020, 0))  hireamt ,-- 고용보험
                            SUM(NVL(b.goamt030 + b.goamt035 + b.goamt700 + b.goamt810, 0))  etcgoamt ,-- 기타공제
                            SUM(NVL(b.goamt, 0))  goamt ,-- 공제총액
                            SUM(NVL(b.totpay, 0))  - SUM(NVL(b.goamt, 0))  payamt ,-- 공제지급액
                            'H01001' AS acatrulecode ,-- 분계룰코드
                            SUM(NVL(b.goamt800, 0))  goamt01 ,-- 소득세
                            SUM(NVL(b.goamt805, 0))  goamt05 ,-- 주민세
                            SUM(NVL(b.goamt010, 0))  goamt10 ,-- 국민연금
                            SUM(NVL(b.goamt011, 0))  goamt11 ,-- 국민연금소급
                            SUM(NVL(b.goamt015, 0))  goamt15 ,-- 건강보험
                            SUM(NVL(b.goamt515, 0))  goamt16 ,-- 건강보험소급
                            SUM(NVL(b.goamt020, 0))  goamt20 ,-- 고용보험
                            SUM(NVL(b.goamt045, 0))  goamt45 ,-- 연말정산소득세
                            SUM(NVL(b.goamt046, 0))  goamt46 ,-- 연말정산주민세
                            SUM(NVL(b.goamt047, 0))  goamt47 ,-- 연말정산농특세
                            SUM(NVL(b.goamt030 + b.goamt035 + b.goamt700 + b.goamt810, 0))  goamt91 -- 예수금(기타)
                    FROM    PSPAYM A
                            LEFT JOIN ( SELECT  A.plantcode ,
                                                A.yearmonth ,
                                                A.empcode ,
                                                A.paybonusdiv ,
                                                A.chasoo ,
                                                SUM(CASE WHEN A.sugodiv = 'su' AND A.sugocode = '001' THEN A.amt ELSE 0 END)  baseamt ,-- 기본급
                                                SUM(CASE WHEN A.sugodiv = 'su' AND A.sugocode NOT IN ( '001','700' ) THEN A.amt ELSE 0 END)  suamt ,-- 수당
                                                SUM(CASE WHEN A.sugodiv = 'su' AND A.sugocode NOT IN ( '700' ) THEN A.amt ELSE 0 END)  salaryamt ,-- 급여
                                                SUM(CASE WHEN A.sugodiv = 'su' AND A.sugocode IN ( '700' ) THEN A.amt ELSE 0 END)  bonusamt ,-- 상여
                                                SUM(CASE WHEN A.sugodiv = 'su' THEN A.amt ELSE 0 END)  totpay ,-- 총지급액
                                                SUM(CASE WHEN A.sugodiv = 'go' THEN A.amt ELSE 0 END)  goamt ,-- 공제총액
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '800' THEN A.amt ELSE 0 END)  goamt800 ,-- 소득세
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '805' THEN A.amt ELSE 0 END)  goamt805 ,-- 주민세(지방소득세)
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '010' THEN A.amt ELSE 0 END)  goamt010 ,-- 국민연금
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '01X' THEN A.amt ELSE 0 END)  goamt011 ,-- 국민연금소급
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode IN ( '015','025' ) THEN A.amt ELSE 0 END)  goamt015 ,-- 건강보험
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode IN ( '515','525','550' ) THEN A.amt ELSE 0 END)  goamt515 ,-- 건강보험소급
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '020' THEN A.amt ELSE 0 END)  goamt020 ,-- 고용보험
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '045' THEN A.amt ELSE 0 END)  goamt045 ,-- 연말정산소득세
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '046' THEN A.amt ELSE 0 END)  goamt046 ,-- 연말정산주민세
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '047' THEN A.amt ELSE 0 END)  goamt047 ,-- 연말정산농특세

                                                -- 21040000
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '030' THEN A.amt ELSE 0 END)  goamt030 ,-- 노동조합비
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '035' THEN A.amt ELSE 0 END)  goamt035 ,-- 재형저축
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '700' THEN A.amt ELSE 0 END)  goamt700 ,-- 기타
                                                SUM(CASE WHEN A.sugodiv = 'go' AND A.sugocode = '810' THEN A.amt ELSE 0 END)  goamt810 -- 농특세

                                        FROM    PSPAYD A
                                                JOIN PSSUGOITEMM b   ON A.sugodiv = b.sugodiv
                                                                        AND A.sugocode = b.sugocode
                                        WHERE   A.plantcode LIKE p_plantcode || '%'
                                                AND A.yearmonth = p_sym
                                        GROUP BY A.plantcode,A.yearmonth,A.empcode,A.paybonusdiv,A.chasoo ) b   ON  A.plantcode = b.plantcode
                                                                                                                    AND A.yearmonth = b.yearmonth
                                                                                                                    AND A.empcode = b.empcode
                                                                                                                    AND A.paybonusdiv = b.paybonusdiv
                                                                                                                    AND A.chasoo = b.chasoo
                    LEFT JOIN CMDEPTM c   ON A.deptcode = c.deptcode
                    LEFT JOIN CMEMPM D    ON A.empcode = D.empcode
                    LEFT JOIN CMCOMMONM E ON E.cmmcode = 'PS41'
                                             AND E.divcode = D.empdiv --사원구분 정보
                    LEFT JOIN CMCOMMONM f ON f.cmmcode = 'PS29'
                                             AND f.divcode = D.positiondiv --직위분류 정보
                    WHERE  A.plantcode LIKE p_plantcode || '%'
                            AND A.yearmonth = p_sym
                            AND A.paydate BETWEEN p_sdt AND p_edt
                    GROUP BY A.yearmonth,A.paydate,A.paybonusdiv,A.chasoo,A.deptcode,A.empcode ) A

                    LEFT JOIN CMDEPTM b   ON A.deptcode = b.deptcode
                    LEFT JOIN CMCOMMONM c   ON c.cmmcode = 'PS53'
                                                AND A.paybonusdiv = c.divcode );
                -- 기본 급여내역 템프테이블 저장 완료

    -- 전송완료상태 데이터 확인
    MERGE INTO VGT.TT_ACACC0900HP4_DUAL A
    USING (     SELECT  CASE WHEN b.actrnstate = '1' OR NVL(b.slipinno, '') IS NULL THEN '로드완료전표처리전'
                             WHEN NVL(TRIM(b.slipinno), '') IS NOT NULL AND b.slipinno = c.slipinno THEN '회계처리완료'
                             WHEN NVL(TRIM(b.slipinno), '') IS NOT NULL AND NVL(c.slipinno, '') IS NULL THEN '신규:회계전표삭제재전송'
                             ELSE '회계처리완료'
                        END AS acctrnchk,
                        CASE WHEN b.actrnstate = '1' OR NVL(b.slipinno, '') IS NULL THEN '3'
                             WHEN NVL(TRIM(b.slipinno), '') IS NOT NULL AND b.slipinno = c.slipinno THEN '2'
                             WHEN NVL(TRIM(b.slipinno), '') IS NOT NULL AND NVL(c.slipinno, '') IS NULL  THEN '3'
                             ELSE '2'
                        END AS actrnstate,
                        NVL(b.slipinno, '') AS slipinno,
                        b.slipindate ,
                        CASE WHEN NVL(TRIM(b.slipinno), '') IS NOT NULL AND NVL(TRIM(c.slipinno), '') IS NULL THEN 'Y'
                             ELSE 'N'
                        END AS newchk

                        , b.compcode
                        , b.acattype
                        , b.acatno

                FROM    ACAUTOORDT b -- 기존자료
                        LEFT JOIN ACORDM c ON b.compcode = c.compcode -- 회계전표
                                              AND b.slipinno = c.slipinno

            ) b ON ( A.compcode = b.compcode
                     AND b.acattype = 'H'
                     AND A.yearmonth || A.deptcode || A.empcode || A.paybonusdiv || A.chasoo = b.acatno )

    WHEN MATCHED THEN UPDATE SET    A.acctrnchk     = b.acctrnchk ,
                                    A.actrnstate    = b.actrnstate ,
                                    A.slipinno      = b.slipinno ,
                                    A.accdate       = CASE WHEN A.accdate <> b.slipindate THEN b.slipindate ELSE A.accdate END ,
                                    A.newchk        = b.newchk;


    -- 수정 데이터 확인
    FOR rec IN (
                    SELECT  --바꿀 데이터
                            CASE WHEN NVL(TRIM(b.slipinno), '') IS NOT NULL AND NVL(c.slipinno, '') IS NULL THEN '수정:회계전표삭제재전송'
                                 ELSE '수정전송필요'
                            END AS update_acctrnchk
                            , NVL(b.slipinno, '') AS update_slipinno

                            --비교 데이터
                            , A.COMPCODE
                            , A.PLANTCODE
                            --, a.COLCHK
                            , A.YEARMONTH
                            , A.ACCDATE
                            , A.PAYDATE
                            , A.PAYBONUSDIV
                            , A.PAYTYPENAME
                            , A.CHASOO
                            , A.DEPTCODE
                            , A.DEPTNAME
                            , A.EMPCODE
                            , A.EMPNAME
                            , A.BASEAMT
                            , A.SUAMT
                            , A.TOTBASEAMT
                            , A.TOTPAY1
                            , A.TOTPAY2
                            , A.TOTPAY3
                            , A.TOTPAY4
                            , A.TOTPAY
                            , A.INCOMETAX
                            , A.RESITAX
                            , A.PENSAMT
                            , A.INSUAMT
                            , A.HIREAMT
                            , A.ETCGOAMT
                            , A.GOAMT
                            , A.PAYAMT
                            , A.ACATRULECODE
                            , A.GOAMT1
                            , A.GOAMT2
                            , A.GOAMT3
                            , A.GOAMT4
                            , A.GOAMT5
                            , A.GOAMT6
                            , A.GOAMT7
                            , A.GOAMT8
                            , A.GOAMT9
                            , A.GOAMT10
                            , A.GOAMT11
                            , A.REMARK
                            --, a.ACTRNSTATE
                            , A.AUTORULECODE
                            --, a.ACCTRNCHK
                            --, a.SLIPINNO
                            , A.NEWCHK

                    FROM    VGT.TT_ACACC0900HP4_DUAL A
                            JOIN ACAUTOORDT b ON A.compcode = b.compcode
                                                 AND b.acattype = 'H'
                                                 AND A.yearmonth || A.deptcode || A.empcode || A.paybonusdiv || A.chasoo = b.acatno
                            LEFT JOIN ACORDM c ON b.compcode = c.compcode -- 회계전표
                                                  AND b.slipinno = c.slipinno

                    WHERE   NVL(A.plantcode,'')                  <> NVL(b.plantcode,'')
                            OR NVL(A.accdate,'')                 <> NVL(b.slipindate,'')
                            OR NVL(A.acatrulecode,'')            <> NVL(b.acatrulecode,'')
                            OR NVL(A.deptcode,'')                <> NVL(b.deptcode,'')
                            OR NVL(A.empcode,'')                 <> NVL(b.empcode,'')
                            OR NVL(A.remark,'')                  <> NVL(b.remark ,'')
                            OR NVL(A.totpay1,0)                  <> NVL(b.trn1amt,0)    -- 직원급여(판)
                            OR NVL(A.totpay2,0)                  <> NVL(b.trn2amt,0)    -- 임원급여(판)
                            OR NVL(A.totpay3,0)                  <> NVL(b.trn3amt,0)    -- 직원급여(제)
                            OR NVL(A.totpay4,0)                  <> NVL(b.trn4amt,0)    -- 직원급여(연)
                            OR NVL(A.goamt1,0)                   <> NVL(b.trn5amt,0)    -- 소득세
                            OR NVL(A.goamt2,0)                   <> NVL(b.trn6amt,0)    -- 주민세
                            OR NVL(A.goamt3,0) + NVL(A.goamt4,0) <> NVL(b.trn7amt,0)  -- 국민연금
                            OR NVL(A.goamt5,0) + NVL(A.goamt6,0) <> NVL(b.trn8amt,0)  -- 건강보험
                            OR NVL(A.goamt7,0)                   <> NVL(b.trn9amt,0)    -- 고용보험
                            OR NVL(A.goamt8,0)                   <> NVL(b.trn10amt,0)    -- 연말정산소득세
                            OR NVL(A.goamt9,0)                   <> NVL(b.trn11amt,0)    -- 연말정산주민세
                            OR NVL(A.goamt10,0)                  <> NVL(b.trn12amt,0)    -- 연말정산농특세
                            OR NVL(A.goamt11,0)                  <> NVL(b.trn13amt,0)    -- 예수금(기타)
    )
    LOOP

        UPDATE  VGT.TT_ACACC0900HP4_DUAL A

        SET     A.actrnstate = '3'
                , A.colchk = 'N'
                , A.acctrnchk = rec.update_acctrnchk
                , A.slipinno = rec.update_slipinno

        WHERE   A.COMPCODE          = rec.COMPCODE
                AND A.PLANTCODE     = rec.PLANTCODE
                --AND a.COLCHK        = rec.COLCHK
                AND A.YEARMONTH     = rec.YEARMONTH
                AND A.ACCDATE       = rec.ACCDATE
                AND A.PAYDATE       = rec.PAYDATE
                AND A.PAYBONUSDIV   = rec.PAYBONUSDIV
                AND A.PAYTYPENAME   = rec.PAYTYPENAME
                AND A.CHASOO        = rec.CHASOO
                AND A.DEPTCODE      = rec.DEPTCODE
                AND A.DEPTNAME      = rec.DEPTNAME
                AND A.EMPCODE       = rec.EMPCODE
                AND A.EMPNAME       = rec.EMPNAME
                AND A.BASEAMT       = rec.BASEAMT
                AND A.SUAMT         = rec.SUAMT
                AND A.TOTBASEAMT    = rec.TOTBASEAMT
                AND A.TOTPAY1       = rec.TOTPAY1
                AND A.TOTPAY2       = rec.TOTPAY2
                AND A.TOTPAY3       = rec.TOTPAY3
                AND A.TOTPAY4       = rec.TOTPAY4
                AND A.TOTPAY        = rec.TOTPAY
                AND A.INCOMETAX     = rec.INCOMETAX
                AND A.RESITAX       = rec.RESITAX
                AND A.PENSAMT       = rec.PENSAMT
                AND A.INSUAMT       = rec.INSUAMT
                AND A.HIREAMT       = rec.HIREAMT
                AND A.ETCGOAMT      = rec.ETCGOAMT
                AND A.GOAMT         = rec.GOAMT
                AND A.PAYAMT        = rec.PAYAMT
                AND A.ACATRULECODE  = rec.ACATRULECODE
                AND A.GOAMT1        = rec.GOAMT1
                AND A.GOAMT2        = rec.GOAMT2
                AND A.GOAMT3        = rec.GOAMT3
                AND A.GOAMT4        = rec.GOAMT4
                AND A.GOAMT5        = rec.GOAMT5
                AND A.GOAMT6        = rec.GOAMT6
                AND A.GOAMT7        = rec.GOAMT7
                AND A.GOAMT8        = rec.GOAMT8
                AND A.GOAMT9        = rec.GOAMT9
                AND A.GOAMT10       = rec.GOAMT10
                AND A.GOAMT11       = rec.GOAMT11
                AND A.REMARK        = rec.REMARK
                --AND a.ACTRNSTATE    = rec.ACTRNSTATE
                AND A.AUTORULECODE  = rec.AUTORULECODE
                --AND a.ACCTRNCHK     = rec.ACCTRNCHK
                --AND a.SLIPINNO      = rec.SLIPINNO
                AND A.NEWCHK        = rec.NEWCHK ;

    END LOOP;





    -- 삭제 상태 확인
    INSERT INTO VGT.TT_ACACC0900HP4_DUAL (
        SELECT  A.compcode ,-- 회사
                A.plantcode ,-- 사업장
                'N' ,-- 선택
                SUBSTR(A.acatno, 0, 7) ,-- 지급년월
                NVL(A.slipindate, '') ,-- 전표일자
                '삭제' ,-- 급여지급일자
                A.userdef21code ,-- 급상여구분
                c.divname ,-- 급상여구분명(PS53)
                A.userdef22code ,-- 급여차수
                A.deptcode ,-- 부서코드
                A.userdef4code ,-- 부서명
                A.empcode ,-- 사원코드
                A.userdef5code ,-- 사원명
                0 ,-- 기본급
                0 ,-- 수당
                A.trn1amt + A.trn2amt + A.trn3amt + A.trn4amt ,-- 총급여액
                A.trn1amt ,-- 직원급여(판)
                A.trn2amt ,-- 임원급여(판)
                A.trn3amt ,-- 직원급여(제)
                A.trn4amt ,-- 직원급여(연)
                A.trn18amt ,-- 총지급액
                A.trn5amt + A.trn10amt ,-- 소득세합
                A.trn6amt + A.trn11amt ,-- 주민세합
                A.trn7amt ,-- 국민연금
                A.trn8amt ,-- 건강보험
                A.trn9amt ,-- 고용보험
                A.trn12amt ,-- 기타공제
                A.trn19amt ,-- 공제총액
                A.trn20amt ,-- 공제지급액
                A.acatrulecode ,-- 분계룰코드
                A.trn5amt ,-- 소득세
                A.trn6amt ,-- 주민세
                A.trn7amt ,-- 국민연금
                0 ,-- 국민연금소급
                A.trn8amt ,-- 건강보험
                0 ,-- 건강보험소급
                A.trn9amt ,-- 고용보험
                A.trn10amt ,-- 연말정산소득세
                A.trn11amt ,-- 연말정산주민세
                A.trn12amt ,-- 연말정산농특세
                A.trn13amt ,-- 예수금(기타)
                A.remark ,-- 적요 (#월 + 급여 + (인원명) + 지급 +[수정,재전송]
                '4' ,-- 자료상태(1신규, 2완료 3수정, 4삭제)
                A.acatrulecode ,-- 분계룰코드
                '삭제전송필요' ,-- 자료상태명
                A.slipinno ,-- 전표번호
                'N' -- 변경여부

        FROM    ACAUTOORDT A
                LEFT JOIN VGT.TT_ACACC0900HP4_DUAL b   ON   A.compcode = b.compcode
                                                            AND A.acatno = b.yearmonth || b.deptcode || b.empcode || b.paybonusdiv || b.chasoo
                LEFT JOIN CMCOMMONM c   ON c.cmmcode = 'PS53'
                                            AND A.userdef21code = c.divcode
        WHERE   A.compcode = p_compcode
                AND A.acattype = 'H'
                AND A.acatno LIKE p_sym || '%'
                AND A.issdate BETWEEN p_sdt AND p_edt
                AND b.accdate IS NULL );





    IF ( p_loadstatus = '1' OR p_loadstatus = '2' OR p_loadstatus = '3' ) THEN

        --로드 상태를 선택
        DELETE FROM VGT.TT_ACACC0900HP4_DUAL A
        WHERE  A.actrnstate NOT IN ( ( SELECT  A.filter1
                                       FROM    CMCOMMONM A
                                       WHERE   A.cmmcode = 'AC082'
                                               AND A.divcode = p_loadstatus )

                                     , ( SELECT  A.filter2
                                         FROM    CMCOMMONM A
                                         WHERE   A.cmmcode = 'AC082'
                                                 AND A.divcode = p_loadstatus )
                                    ) ;

    END IF;




    IF ( p_paybonusdiv <> '%' ) THEN

        DELETE FROM VGT.TT_ACACC0900HP4_DUAL A
        WHERE  A.paybonusdiv <> p_paybonusdiv ;

    END IF;


    IF ( p_div = 'S' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  A.compcode ,
                    A.plantcode ,
                    A.colchk ,
                    A.yearmonth ,
                    A.accdate ,
                    A.paydate ,
                    A.paybonusdiv ,
                    A.paytypename ,
                    A.chasoo ,
                    A.deptcode ,
                    A.deptname ,
                    COUNT(*)  cntemp  ,
                    SUM(A.baseamt)  baseamt  ,
                    SUM(A.suamt)  suamt  ,
                    SUM(A.totbaseamt)  totbaseamt  ,
                    SUM(A.totpay1)  totpay1  ,
                    SUM(A.totpay2)  totpay2  ,
                    SUM(A.totpay3)  totpay3  ,
                    SUM(A.totpay4)  totpay4  ,
                    SUM(A.totpay)  totpay  ,
                    SUM(A.incometax)  incometax  ,
                    SUM(A.resitax)  resitax  ,
                    SUM(A.pensamt)  pensamt  ,
                    SUM(A.insuamt)  insuamt  ,
                    SUM(A.hireamt)  hireamt  ,
                    SUM(A.etcgoamt)  etcgoamt  ,
                    SUM(A.goamt)  goamt  ,
                    SUM(A.payamt)  payamt  ,
                    A.acatrulecode ,
                    SUM(A.goamt1)  goamt1  ,
                    SUM(A.goamt2)  goamt2  ,
                    SUM(A.goamt3)  goamt3  ,
                    SUM(A.goamt4)  goamt4  ,
                    SUM(A.goamt5)  goamt5  ,
                    SUM(A.goamt6)  goamt6  ,
                    SUM(A.goamt7)  goamt7  ,
                    SUM(A.goamt8)  goamt8  ,
                    SUM(A.goamt9)  goamt9  ,
                    SUM(A.goamt10)  goamt10  ,
                    MAX(A.remark)  remark  ,
                    CASE WHEN MIN(A.actrnstate)  = MAX(A.actrnstate)  THEN MIN(A.actrnstate) ELSE '3' END actrnstate  ,
                    CASE WHEN MIN(A.actrnstate)  = MAX(A.actrnstate)  THEN MIN(A.acctrnchk) ELSE '수정전송필요' END acctrnchk  ,
                    MAX(A.slipinno)  slipinno  ,
                    MAX(A.newchk)  newchk  ,
                    A.autorulecode ,
                    MAX(b.plantname)  plantname  ,
                    SUM(A.goamt10)  gorest  ,
                    SUM(A.totpay1 + A.totpay2 + A.totpay3 + A.totpay4 - A.goamt1 - A.goamt2 - A.goamt3 - A.goamt4 - A.goamt5 - A.goamt6 - A.goamt7 - A.goamt8 - A.goamt9 - A.goamt10 - A.totpay + A.goamt)  chkamt

            FROM    VGT.TT_ACACC0900HP4_DUAL A
                    LEFT JOIN CMPLANTM b   ON A.plantcode = b.plantcode

            GROUP BY A.compcode,A.plantcode,A.colchk,A.yearmonth,A.accdate,A.paydate,A.paybonusdiv,A.paytypename,A.chasoo,A.deptcode,A.deptname,A.acatrulecode,A.autorulecode

            ORDER BY A.plantcode, A.accdate, A.paydate, A.deptcode ;


    ELSIF ( p_div = 'load' ) THEN --일반 로드

        -- 기간동안의 모든 전표를 생성한다.
        INSERT INTO ACAUTOORDT (
            compcode --회사코드
            , acattype --전표유형(H)
            , acatno --급상여년월+부서+급상여구분+계정구분+차수
            , acatrulecode --분개률코드
            , actrnstate --실행상태
            , slipindate --전표일자
            , deptcode --부서
            , plantcode --사업장
            , empcode --사원
            , remark --비고
            , issdate --지급일
            , trn1amt --직원급여(판)
            , trn2amt --임원급여(판)
            , trn3amt --직원급여(제)
            , trn4amt --직원급여(연)
            , trn5amt --소득세
            , trn6amt --주민세
            , trn7amt --국민연금
            , trn8amt --건강보험
            , trn9amt --고용보험
            , trn10amt --연말정산소득세
            , trn11amt --연말정산주민세
            , trn12amt --연말정산농특세
            , trn13amt --예수금(기타)
            , trn18amt --총지급액
            , trn19amt --공제총액
            , trn20amt --공제지급액
            , userdef3code --사업장명
            , userdef4code --부서명
            , userdef5code --발의사원명
            , userdef21code --급상여구분
            , userdef22code --차수
            , insertdt --입력일자
            , iempcode --입력사원
        )
        (
            SELECT  A.compcode ,
                    'H' ,
                    A.yearmonth || A.deptcode || A.empcode || A.paybonusdiv || A.chasoo ,
                    A.acatrulecode ,
                    A.actrnstate ,
                    A.accdate ,
                    A.deptcode ,
                    A.plantcode ,
                    A.empcode ,
                    A.remark ,
                    A.paydate ,
                    A.totpay1 ,
                    A.totpay2 ,
                    A.totpay3 ,
                    A.totpay4 ,
                    A.goamt1 ,
                    A.goamt2 ,
                    A.pensamt ,
                    A.insuamt ,
                    A.hireamt ,
                    A.goamt8 ,
                    A.goamt9 ,
                    A.goamt10 ,
                    A.goamt11 ,
                    A.totpay ,
                    A.goamt ,
                    A.payamt ,
                    b.plantname ,
                    A.deptname ,
                    A.empname ,
                    A.paybonusdiv ,
                    A.chasoo ,
                    SYSDATE ,
                    p_iempcode

            FROM    VGT.TT_ACACC0900HP4_DUAL A
                    LEFT JOIN CMPLANTM b   ON A.plantcode = b.plantcode

            WHERE   A.actrnstate = '1'
                    AND A.acatrulecode <> '정의오류' );





        -- 수정,삭제 처리전에 메타에 있는 내용을 이력테이블에 저장한다.
        INSERT INTO ACAUTOORDH (
            SELECT  b.*
            FROM    VGT.TT_ACACC0900HP4_DUAL A
                    LEFT JOIN ACAUTOORDT b   ON A.compcode = b.compcode
                                                AND b.acattype = 'H'
                                                AND A.yearmonth || A.deptcode || A.empcode || A.paybonusdiv || A.chasoo = b.acatno
            WHERE  A.actrnstate IN ( '3','4' ) OR A.newchk = 'Y'
        );




        FOR rec IN (
                        SELECT  --업데이트 데이터
                                A.acatrulecode          --분개률코드
                                , CASE WHEN b.actrnstate = '1' THEN b.actrnstate ELSE A.actrnstate END actrnstate   --실행상태
                                , A.accdate             --전표일자
                                , A.deptcode            --부서코드
                                , A.plantcode           --사업장
                                , A.empcode             --사원코드
                                , A.remark              --비고
                                , A.paydate             --지급일
                                , A.totpay1             --직원급여(판)
                                , A.totpay2             --임원급여(판)
                                , A.totpay3             --직원급여(제)
                                , A.totpay4             --직원급여(연)
                                , A.goamt1              --소득세
                                , A.goamt2              --주민세
                                , A.pensamt             --국민연금
                                , A.insuamt             --건강보험
                                , A.hireamt             --고용보험
                                , A.goamt8              --연말정산소득세
                                , A.goamt9              --연말정산주민세
                                , A.goamt10             --연말정산농특세
                                , A.goamt11             --예수금(기타)
                                , A.totpay              --총지급액
                                , A.goamt               --공제총액
                                , A.payamt              --공제지급액
                                , c.plantname           --사업장명
                                , A.deptname            --부서명
                                , A.empname             --사원명
                                , A.paybonusdiv         --급상여구분
                                , A.chasoo              --차수
                                , SYSDATE updatedt      --수정일자
                                , p_iempcode uempcode   --수정사원

                                --비교 데이터
                                , b.compcode
                                , b.acattype
                                , b.acatno

                        FROM    VGT.TT_ACACC0900HP4_DUAL A
                                LEFT JOIN ACAUTOORDT b ON A.compcode = b.compcode
                                                          AND b.acattype = 'H'
                                                          AND A.yearmonth || A.deptcode || A.empcode || A.paybonusdiv || A.chasoo = b.acatno
                                LEFT JOIN CMPLANTM c ON A.plantcode = c.plantcode
        )
        LOOP

            UPDATE  ACAUTOORDT A
            SET     A.acatrulecode    = rec.acatrulecode   --분개률코드
                    , A.actrnstate    = rec.actrnstate     --실행상태
                    , A.slipindate    = rec.accdate        --전표일자
                    , A.deptcode      = rec.deptcode       --부서코드
                    , A.plantcode     = rec.plantcode      --사업장
                    , A.empcode       = rec.empcode        --사원코드
                    , A.remark        = rec.remark         --비고
                    , A.issdate       = rec.paydate        --지급일
                    , A.trn1amt       = rec.totpay1        --직원급여(판)
                    , A.trn2amt       = rec.totpay2        --임원급여(판)
                    , A.trn3amt       = rec.totpay3        --직원급여(제)
                    , A.trn4amt       = rec.totpay4        --직원급여(연)
                    , A.trn5amt       = rec.goamt1         --소득세
                    , A.trn6amt       = rec.goamt2         --주민세
                    , A.trn7amt       = rec.pensamt        --국민연금
                    , A.trn8amt       = rec.insuamt        --건강보험
                    , A.trn9amt       = rec.hireamt        --고용보험
                    , A.trn10amt      = rec.goamt8         --연말정산소득세
                    , A.trn11amt      = rec.goamt9         --연말정산주민세
                    , A.trn12amt      = rec.goamt10        --연말정산농특세
                    , A.trn13amt      = rec.goamt11        --예수금(기타)
                    , A.trn18amt      = rec.totpay         --총지급액
                    , A.trn19amt      = rec.goamt          --공제총액
                    , A.trn20amt      = rec.payamt         --공제지급액
                    , A.userdef3code  = rec.plantname      --사업장명
                    , A.userdef4code  = rec.deptname       --부서명
                    , A.userdef5code  = rec.empname        --사원명
                    , A.userdef21code = rec.paybonusdiv    --급상여구분
                    , A.userdef22code = rec.chasoo         --차수
                    , A.updatedt      = rec.updatedt       --수정일자
                    , A.uempcode      = rec.uempcode       --수정사원

            WHERE   A.compcode = rec.compcode
                    AND A.acattype = rec.acattype
                    AND A.acatno = rec.acatno ;

        END LOOP;

    END IF;



    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;



END;
/
