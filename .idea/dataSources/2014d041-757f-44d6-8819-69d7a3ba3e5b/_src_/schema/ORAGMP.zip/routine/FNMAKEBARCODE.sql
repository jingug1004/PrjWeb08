CREATE FUNCTION fnMakeBarcode(
    -- ---------------------------------------------------------------
    -- 함 수 명   : fnMakeBarcode
    -- 작 성 자         : 최인범
    -- 작성일자         : 2007-10-25
    -- 수정일자      :   노영래
	-- E-mail      :   0rae0926@gmail.com
	-- 수정일자      :   2016-01-12
    -- ---------------------------------------------------------------
    -- 함수설명   : 바코드번호 생성
    -- ---------------------------------------------------------------
	-- 주석부분 테이블 없음

    p_div 			IN 		VARCHAR2 	DEFAULT '',
    p_seq 			IN 		VARCHAR2	DEFAULT '0',
    p_objdiv1 		IN 		VARCHAR2 	DEFAULT '',
    p_objdiv2 		IN 		VARCHAR2 	DEFAULT '',
    p_makedate 		IN 		VARCHAR2 	DEFAULT ''
)

    RETURN VARCHAR2
AS
	p_tostring	  VARCHAR2(20);
    p_seqtonum	  int := 0;
BEGIN

	p_seqtonum := TO_NUMBER(p_seq);

	IF (p_div = 'WarehousingBarcode')
	THEN
		FOR rec IN (SELECT DECODE(rowbarcode, NULL, SUBSTR(REPLACE(p_makedate, '-', ''), 0, 6) || SUBSTR('0000' || p_seqtonum, -4, 4), SUBSTR(rowbarcode, 0, 6) || SUBSTR('0000' || (TO_NUMBER(SUBSTR(rowbarcode, -4, 4)) + p_seqtonum), -4, 4)) AS alias1
					FROM   (SELECT MAX(rowbarcode) rowbarcode
              FROM   PDWHSD
              WHERE  SUBSTR(rowbarcode, 0, 6) = SUBSTR(REPLACE(p_makedate, '-', ''), 0, 6)))
    LOOP
      p_tostring := rec.alias1;
    END LOOP;
--  ELSIF (p_div = 'Weighingmix')
--  THEN
--    FOR rec IN (SELECT 'M' || DECODE(mixbarcode, NULL, SUBSTR(REPLACE(p_makedate, '-', ''), 3, 6) || SUBSTR('0000' || p_seqtonum, -3, 3), SUBSTR(mixbarcode, 3, 6) || SUBSTR('0000' || (TO_NUMBER(SUBSTR(mixbarcode, -3, 3)) + p_seqtonum), -4, 4)) AS alias1
--          FROM   (SELECT MAX(mixbarcode) mixbarcode
--              FROM   weighingmix
--              WHERE  SUBSTR(mixbarcode, 0, 7) = 'M' || SUBSTR(REPLACE(p_makedate, '-', ''), 3, 6)) a)
--    LOOP
--      p_tostring := rec.alias1;
--    END LOOP;
--  ELSIF (p_div = 'Taremanage')
--  THEN
--    FOR rec IN (SELECT   TO_NUMBER((SELECT SUBSTR(MAX(tarebarcode), -3, 3)
--                            FROM   taremanage
--                            WHERE  tareusediv = p_objdiv1
--                               AND taretype = p_objdiv2)) + 1
--                 AS alias1,
--               REPLACE(utils.str(p_tostring, 3), '', '0') AS alias2,
--               p_objdiv1 || SUBSTR(p_objdiv2, -1, 1) || p_tostring AS alias3
--          FROM   DUAL)
--    LOOP
--      p_tostring := rec.alias1;
--      p_tostring := rec.alias2;
--      p_tostring := rec.alias3;
--    END LOOP;
  ELSIF (p_div = 'Semimanufactures')
  THEN
    p_tostring := 'T' || p_objdiv1 || p_objdiv2;
  ELSIF (p_div = 'PackingBarcode')
  THEN
    FOR rec IN (SELECT 'P' || SUBSTR(REPLACE(p_makedate, '-', ''), 3, 6) || SUBSTR('000' || NVL(TO_CHAR(TO_NUMBER(SUBSTR(packingbarcode, -3, 3)) + 1), '1'), -3, 3) AS alias1
          FROM   (SELECT MAX(packingbarcode) packingbarcode
              FROM   PackingResultLabel
              WHERE  SUBSTR(packingbarcode, 2, 6) = SUBSTR(REPLACE(p_makedate, '-', ''), 3, 6)))
    LOOP
      p_tostring := rec.alias1;
    END LOOP;
  ELSIF (p_div = 'SafeKeepingSample')
  THEN
    FOR rec IN (SELECT DECODE(barcodeno, NULL, SUBSTR(REPLACE(p_makedate, '-', ''), 3, 4) || SUBSTR('000' || p_seqtonum, -3, 3), SUBSTR(barcodeno, 0, 4) || SUBSTR('000' || (TO_NUMBER(SUBSTR(barcodeno, -3, 3)) + p_seqtonum), -3, 3)) AS alias1
          FROM   (SELECT MAX(barcodeno) barcodeno
              FROM   SafeKeepingSampleManage
              WHERE  SUBSTR(barcodeno, 0, 4) = SUBSTR(REPLACE(p_makedate, '-', ''), 3, 4)) a)
    LOOP
      p_tostring := rec.alias1;
    END LOOP;
  ELSIF (p_div = 'ReagentStandardItem')
  THEN
    FOR rec IN (SELECT DECODE(barcode, NULL, SUBSTR(REPLACE(p_makedate, '-', ''), 3, 4) || SUBSTR('000' || p_seqtonum, -3, 3), SUBSTR(barcode, 0, 4) || SUBSTR('000' || (SUBSTR(barcode, -3, 3) + p_seqtonum), -3, 3)) AS alias1
          FROM   (SELECT MAX(barcode) barcode
              FROM   ReagentStandardItem
              WHERE  SUBSTR(barcode, 0, 4) = SUBSTR(REPLACE(p_makedate, '-', ''), 3, 4)) a)
    LOOP
      p_tostring := rec.alias1;
    END LOOP;
  END IF;

  RETURN (p_tostring);
EXCEPTION
  WHEN OTHERS
  THEN NULL;
END;
/
