CREATE FUNCTION fnAcAutoORDval
-- ---------------------------------------------------------------
-- 함 수 명 : fnAcAutoORDval
-- 작 성 자 : 민승기
-- 작성일자 : 2010-12-03
-- ---------------------------------------------------------------
-- 함수설명 : 회계자동분개 관리항목값매핑
-- ---------------------------------------------------------------
(
    p_mngcludiv       IN VARCHAR2 DEFAULT ' ',

    p_userdef1code    IN VARCHAR2 DEFAULT NULL,
    p_userdef2code    IN VARCHAR2 DEFAULT NULL,
    p_userdef3code    IN VARCHAR2 DEFAULT NULL,
    p_userdef4code    IN VARCHAR2 DEFAULT NULL,
    p_userdef5code    IN VARCHAR2 DEFAULT NULL,
    p_userdef6code    IN VARCHAR2 DEFAULT NULL,
    p_userdef7code    IN VARCHAR2 DEFAULT NULL,
    p_userdef8code    IN VARCHAR2 DEFAULT NULL,
    p_userdef9code    IN VARCHAR2 DEFAULT NULL,
    p_userdef10code   IN VARCHAR2 DEFAULT NULL,
    p_userdef11code   IN VARCHAR2 DEFAULT NULL,
    p_userdef12code   IN VARCHAR2 DEFAULT NULL,
    p_userdef13code   IN VARCHAR2 DEFAULT NULL,
    p_userdef14code   IN VARCHAR2 DEFAULT NULL,
    p_userdef15code   IN VARCHAR2 DEFAULT NULL,
    p_userdef16code   IN VARCHAR2 DEFAULT NULL,
    p_userdef17code   IN VARCHAR2 DEFAULT NULL,
    p_userdef18code   IN VARCHAR2 DEFAULT NULL,
    p_userdef19code   IN VARCHAR2 DEFAULT NULL,
    p_userdef20code   IN VARCHAR2 DEFAULT NULL,
    p_userdef21code   IN VARCHAR2 DEFAULT NULL,
    p_userdef22code   IN VARCHAR2 DEFAULT NULL,
    p_userdef23code   IN VARCHAR2 DEFAULT NULL,
    p_userdef24code   IN VARCHAR2 DEFAULT NULL,
    p_userdef25code   IN VARCHAR2 DEFAULT NULL,
    p_userdef26code   IN VARCHAR2 DEFAULT NULL,
    p_userdef27code   IN VARCHAR2 DEFAULT NULL,
    p_userdef28code   IN VARCHAR2 DEFAULT NULL,
    p_userdef29code   IN VARCHAR2 DEFAULT NULL,
    p_userdef30code   IN VARCHAR2 DEFAULT NULL,
    p_deptcode        IN VARCHAR2 DEFAULT NULL, -- 부서코드
    p_custcode        IN VARCHAR2 DEFAULT NULL, -- 거래처코드
    p_taxno           IN VARCHAR2 DEFAULT NULL, -- 계산서번호
    p_billno          IN VARCHAR2 DEFAULT NULL, -- 어음번호
    p_issdate         IN VARCHAR2 DEFAULT NULL, -- 어음시작일자
    p_expdate         IN VARCHAR2 DEFAULT NULL, -- 어음만기일자
    p_cardno          IN VARCHAR2 DEFAULT NULL, -- 카드번호
    p_empcode         IN VARCHAR2 DEFAULT NULL, -- 사원번호
    p_cardokno        IN VARCHAR2 DEFAULT NULL, -- 카드승인번호
    p_bankcode        IN VARCHAR2 DEFAULT NULL  -- 은행코드
)
RETURN VARCHAR2
AS
   p_rtn VARCHAR2(100);
BEGIN

    p_rtn := case p_mngcludiv when '01' then p_deptcode
                              when '02' then p_custcode
                              when '03' then p_taxno
                              when '04' then p_billno
                              when '05' then p_expdate
                              when '06' then p_cardno
                              when '07' then p_empcode
                              when '08' then p_cardokno
                              when '10' then p_bankcode
                              when '11' then p_userdef1code
                              when '12' then p_userdef2code
                              when '13' then p_userdef3code
                              when '14' then p_userdef4code
                              when '15' then p_userdef5code
                              when '16' then p_userdef6code
                              when '17' then p_userdef7code
                              when '18' then p_userdef8code
                              when '19' then p_userdef9code
                              when '20' then p_userdef10code
                              when '21' then p_userdef11code
                              when '22' then p_userdef12code
                              when '23' then p_issdate
                              when '24' then p_userdef14code
                              when '25' then p_userdef15code
                              when '26' then p_userdef16code
                              when '27' then p_userdef17code
                              when '28' then p_userdef18code
                              when '29' then p_userdef19code
                              when '30' then p_userdef20code
                              when '31' then p_userdef21code
                              when '32' then p_userdef22code
                              when '33' then p_userdef23code
                              when '34' then p_userdef24code
                              when '35' then p_userdef25code
                              when '36' then p_userdef26code
                              when '37' then p_userdef27code
                              when '38' then p_userdef28code
                              when '39' then p_userdef29code
                              when '40' then p_userdef30code
                              else ''
                              end;

    return (p_rtn);
END;
/
