CREATE FUNCTION        fnsalpower_custlist /******
작 성 자: 이세민
작성일자: 2013-04-10
설    명: 영업에서 사용하는 관리 권한 처리를 위해 사용하는 테이블 반환함수
예    제: select * from dbo.fnsalpower_custlist('50') -- 도매부 전체에 해당하는 거래처 리스트 추출

-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
--수정일자      : 2016-11-23

******/
(
  p_setvalues IN VARCHAR2 DEFAULT ''
)
RETURN FN_SALPOWER_EMPLIST_TABLE
AS

    i NUMBER := 1;
    v_cnt NUMBER := 0;
    --함수내에서 변수 저장용 변수 초기화
    salPowerEmpListRecode FN_SALPOWER_EMPLIST_TABLE := FN_SALPOWER_EMPLIST_TABLE();

BEGIN
    
    FOR rec IN (
                    SELECT  COUNT(EMPCODE) CNT
                      FROM  CMEMPM
                     WHERE  DEPTCODE IN (SELECT DEPTCODE FROM CMDEPTM WHERE DEPTNAME LIKE '%도매%' AND USEYN = 'Y') AND RETIREDT IS NULL
                       AND  EMPCODE = p_setvalues
                )
    LOOP
        v_cnt := rec.cnt;
    END LOOP;
    
    IF ( v_cnt = 0) THEN

        FOR  rec IN (
            SELECT CUSTCODE FROM CMCUSTM WHERE CUSTDIV = 2 ORDER BY CUSTCODE ASC
        )
        LOOP
            salPowerEmpListRecode.EXTEND;
            salPowerEmpListRecode(i) := FN_SALPOWER_EMPLIST_VARIABLE(rec.custcode);
            i := i+1;
        END LOOP;


    ELSE

        FOR  rec IN (   
                        SELECT  CUSTCODE
                          FROM  CMCUSTM
                         WHERE  EMPCODE IN (
                                                SELECT  EMPCODE
                                                  FROM  CMEMPM
                                                 WHERE  DEPTCODE IN (SELECT DEPTCODE FROM CMDEPTM WHERE DEPTNAME LIKE '%도매%' AND USEYN = 'Y') AND RETIREDT IS NULL
                                            )
        )

        LOOP
            salPowerEmpListRecode.EXTEND;
            salPowerEmpListRecode(i) := FN_SALPOWER_EMPLIST_VARIABLE(rec.custcode);
            i := i+1;
        END LOOP;

    END IF;

    RETURN salPowerEmpListRecode;

END;
/
