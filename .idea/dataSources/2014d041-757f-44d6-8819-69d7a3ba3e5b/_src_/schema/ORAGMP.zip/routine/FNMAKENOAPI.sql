CREATE FUNCTION fnMakeNoAPI(
    -- ---------------------------------------------------------------
    -- 함 수 명			: fnMakeNoAPI
    -- 작 성 자         :
    -- 작성일자         : 2016-06-01
    -- 수 정 자       :   노영래
	-- 수정일자        :   2017-07-31
    -- ---------------------------------------------------------------
    -- 함수설명			: 일련번호 생성
    -- ---------------------------------------------------------------

    p_div               VARCHAR2 DEFAULT '',
    p_yymmdd            VARCHAR2 DEFAULT '',
    p_docdiv            VARCHAR2 DEFAULT ''
)
	RETURN VARCHAR2
AS
	p_docno   VARCHAR2(20);
BEGIN
	/*프로그램 일련번호 생성*/
	IF (UPPER(p_div) = 'ASQUOTNM')
	THEN
		IF (p_docdiv = '10')
		THEN --10내수 20로컬수출 30직수출
			FOR REC IN (SELECT 'KB-PO-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(quotationno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(quotationno), -2) + 1), -3)) C1
						  FROM ASQUOTNM
						 WHERE SUBSTR(quotationno, 1,12) = 'KB-PO-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
			LOOP
				p_docno := REC.C1;
			END LOOP;
		END IF;
	ELSIF (UPPER(p_div) = 'ASQUOTNM2')
	THEN --수출문서 채번
		IF (p_docdiv = '20')
		THEN --10내수 20로컬수출 30직수출
			FOR REC IN (SELECT 'KB-OS-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(quotationno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(quotationno), -2) + 1), -3)) C1
						  FROM ASQUOTNM
						 WHERE SUBSTR(exdocuno, 1,12) = 'KB-OS-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
			LOOP
				p_docno := REC.C1;
			END LOOP;
		ELSIF (p_docdiv = '30')
		THEN --10내수 20로컬수출 30직수출
			FOR REC IN (SELECT 'KB-PI-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(quotationno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(quotationno), -2) + 1), -3)) C1
						  FROM ASQUOTNM
						 WHERE SUBSTR(exdocuno, 1,12) = 'KB-PI-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
			LOOP
				p_docno := REC.C1;
			END LOOP;
		END IF;
	ELSIF (UPPER(p_div) = 'ASMQUOTNM')
	THEN
		IF (p_docdiv = '10')
		THEN --10내수 20로컬수출 30직수출
			FOR REC IN (SELECT 'KB-PO-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(quotationno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(quotationno), -2) + 1), -3)) C1
						  FROM ASMQUOTNM
						 WHERE SUBSTR(quotationno, 1,12) = 'KB-PO-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
			LOOP
				p_docno := REC.C1;
			END LOOP;
		END IF;
	ELSIF (UPPER(p_div) = 'ASMQUOTNM2')
	THEN --수출문서 채번
		IF (p_docdiv = '20')
		THEN --10내수 20로컬수출 30직수출
			FOR REC IN (SELECT 'KB-OS-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(quotationno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(quotationno), -2) + 1), -3)) C1
						  FROM ASMQUOTNM
						 WHERE SUBSTR(exdocuno, 1,12) = 'KB-OS-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
			LOOP
				p_docno := REC.C1;
			END LOOP;
		ELSIF (p_docdiv = '30')
		THEN --10내수 20로컬수출 30직수출
			FOR REC IN (SELECT 'KB-PI-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(quotationno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(quotationno), -2) + 1), -3)) C1
						  FROM ASMQUOTNM
						 WHERE SUBSTR(exdocuno, 1,12) = 'KB-PI-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
			LOOP
				p_docno := REC.C1;
			END LOOP;
		END IF;
	ELSIF (UPPER(p_div) = 'ASINORDERM')
	THEN
		FOR REC IN (SELECT 'KB-IO-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(inorderno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(inorderno), -2) + 1), -3)) C1
					  FROM ASInOrderM
					 WHERE SUBSTR(inorderno, 1,12) = 'KB-IO-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
		LOOP
			p_docno := REC.C1;
		END LOOP;
	ELSIF (UPPER(p_div) = 'ASORDERM')
	THEN
		IF (p_docdiv <> '100')
		THEN
			IF (UPPER(p_docdiv) = 'REV')
			THEN
				FOR REC IN (SELECT 'KB-RO-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(orderno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(orderno), -2) + 1), -3)) C1
							  FROM ASORDERM
							 WHERE SUBSTR(orderno, 1,12) = 'KB-RO-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
				LOOP
					p_docno := REC.C1;
				END LOOP;
			ELSE
				FOR REC IN (SELECT 'KB-SO-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(orderno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(orderno), -2) + 1), -3)) C1
                FROM ASORDERM
               WHERE SUBSTR(orderno, 1,12) = 'KB-SO-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
        LOOP
          p_docno := REC.C1;
        END LOOP;
      END IF;
    ELSE
      FOR REC IN (SELECT 'KB-SR-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(orderno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(orderno), -2) + 1), -3)) C1
              FROM ASORDERM
             WHERE SUBSTR(orderno, 1,12) = 'KB-SR-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
      LOOP
        p_docno := REC.C1;
      END LOOP;
    END IF;
  ELSIF (UPPER(p_div) = 'ASACREVM')
  THEN
    IF (UPPER(p_docdiv) = 'REV')
    THEN
      FOR REC IN (SELECT 'KB-RA-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(arno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(arno), -2) + 1), -3)) C1
              FROM ASACREVM
             WHERE SUBSTR(arno, 1,12) = 'KB-RA-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
      LOOP
        p_docno := REC.C1;
      END LOOP;
    ELSE
      FOR REC IN (SELECT 'KB-AR-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(arno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(arno), -2) + 1), -3)) C1
              FROM ASACREVM
             WHERE SUBSTR(arno, 1,12) = 'KB-AR-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
      LOOP
        p_docno := REC.C1;
      END LOOP;
    END IF;
  ELSIF (UPPER(p_div) = 'ASCOLM')
  THEN
    FOR REC IN (SELECT 'KB-CN-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(colno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(colno), -2) + 1), -3)) C1
            FROM ASCOLM
           WHERE SUBSTR(colno, 1,12) = 'KB-CN-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
    LOOP
      p_docno := REC.C1;
    END LOOP;
  ELSIF (UPPER(p_div) = 'ASINVOICEM')
  THEN
    FOR REC IN (SELECT 'EXP' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(exdocuno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(exdocuno), -2) + 1), -3)) C1
            FROM ASINVOICEM
           WHERE SUBSTR(exdocuno, 1,9) = 'EXP' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
    LOOP
      p_docno := REC.C1;
    END LOOP;
  ELSIF (UPPER(p_div) = 'ASEXPENSEM')
  THEN
    FOR REC IN (SELECT 'EXPENSE' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(expensedocno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(expensedocno), -2) + 1), -3)) C1
            FROM ASEXPENSEM
           WHERE SUBSTR(expensedocno, 1,13) = 'EXPENSE' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
    LOOP
      p_docno := REC.C1;
    END LOOP;
  ELSIF (UPPER(p_div) = 'ASEXCOSTM')
  THEN
    FOR REC IN (SELECT 'EXPDOC' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(costdocno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(costdocno), -2) + 1), -3)) C1
            FROM ASEXCOSTM
           WHERE SUBSTR(costdocno, 1,12) = 'EXPDOC' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
    LOOP
      p_docno := REC.C1;
    END LOOP;
  ELSIF (UPPER(p_div) = 'INVOICE2')
  THEN
    FOR REC IN (SELECT 'KB-CI-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(invoiceno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(invoiceno), -3) + 1), -3)) C1
            FROM ASINVOICEM
           WHERE SUBSTR(invoiceno, 1,12) = 'KB-CI-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
    LOOP
      p_docno := REC.C1;
    END LOOP;
  ELSIF (UPPER(p_div) = 'OFFER')
  THEN -- 판매오더의 판매유형이 로컬수출일 때 Offer 번호
    FOR REC IN (SELECT 'KB-OS-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(offerno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(offerno), -2) + 1), -3)) C1
            FROM ASORDERM
           WHERE SUBSTR(offerno, 1,12) = 'KB-OS-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
    LOOP
      p_docno := REC.C1;
    END LOOP;
  ELSIF (UPPER(p_div) = 'ASTRANSMNGM')
  THEN -- 거래처인수인계
    FOR REC IN (SELECT 'TRANS-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(entryno), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(entryno), -2) + 1), -3)) C1
            FROM ASTRANSMNGM
           WHERE SUBSTR(entryno, 1,12) = 'TRANS-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
    LOOP
      p_docno := REC.C1;
    END LOOP;
  -- 수출부대비용 / 비용번호
  ELSIF (UPPER(p_div) = 'EXPORTCOST')
  THEN
    FOR REC IN (SELECT 'EX-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || '-' || DECODE(MAX(costseq), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(costseq), -2) + 1), -3)) C1
            FROM ASEXPORTCOST
           WHERE SUBSTR(costseq, 1,9) = 'EX-' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
    LOOP
      p_docno := REC.C1;
    END LOOP;
  -- 라벨ID 채번규칙 추가 2016.12.13
  ELSIF (UPPER(p_div) = 'LABEL')
  THEN
    FOR REC IN (SELECT 'L' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6) || DECODE(MAX(labelid), NULL, '001', SUBSTR('000' || TO_CHAR(SUBSTR(MAX(labelid), -2) + 1), -3)) C1
            FROM ASREQUESTLABELM
           WHERE SUBSTR(labelid, 1,7) = 'L' || SUBSTR(REPLACE(p_yymmdd, '-', ''), -6))
    LOOP
      p_docno := REC.C1;
    END LOOP;
  -- Invoice 양식 등록 채번
  ELSIF (UPPER(p_div) = 'DOCUID')
  THEN
    FOR REC IN (SELECT 'E' || SUBSTR('000' || TO_CHAR(NVL(MAX(SUBSTR(docuid, -4)) + 1, 1)), -4) C1
            FROM ASINVDOCUM
           WHERE plantcode = '1002')
    LOOP
      p_docno := REC.C1;
    END LOOP;
  END IF;

  RETURN (p_docno);
EXCEPTION
  WHEN OTHERS
  THEN
    p_docno := '';
END;
/
