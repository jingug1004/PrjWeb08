CREATE PROCEDURE        spACacc0186R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0186R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2015-08-13
    -- 수 정 자     : 강현호
    -- E-Mail       : roykang0722@gmail.com
    -- 수정일자      : 2016-12-13
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 품목 구매내역 리스트 쿼리.
	-- ---------------------------------------------------------------
(
    p_div			  IN	 VARCHAR2 DEFAULT '',
    p_compcode		  IN	 VARCHAR2 DEFAULT '',
    p_plantcode 	  IN	 VARCHAR2 DEFAULT '%',
    p_purchaseym	  IN	 VARCHAR2 DEFAULT '',
    p_purchaseseq	  IN	 NUMBER   DEFAULT 0,
    p_purchasediv	  IN	 VARCHAR2 DEFAULT '',
    p_custcode		  IN	 VARCHAR2 DEFAULT '',
    p_itemname		  IN	 VARCHAR2 DEFAULT '',
    p_purchaseamt	  IN	 FLOAT    DEFAULT 0,
    p_paycondition	  IN	 VARCHAR2 DEFAULT '',
    p_paydate		  IN	 VARCHAR2 DEFAULT '',
    p_iempcode		  IN	 VARCHAR2 DEFAULT '',
    p_userid		  IN	 VARCHAR2 DEFAULT '',
    p_reasondiv 	  IN	 VARCHAR2 DEFAULT '',
    p_reasontext	  IN	 VARCHAR2 DEFAULT '',

    MESSAGE          OUT    VARCHAR2,
    IO_CURSOR        OUT    TYPES.DataSet
)
AS
	ip_purchaseseq	NUMBER(10, 0) := p_purchaseseq;

BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    IF ( UPPER(p_div) = UPPER('S') ) THEN

        OPEN IO_CURSOR FOR

            SELECT	 a.compcode,
                     a.plantcode,
                     a.purchaseym,
                     a.purchaseseq,
                     a.purchasediv,
                     a.custcode,
                     b.custname,
                     a.itemname,
                     a.purchaseamt,
                     a.paycondition,
                     a.paydate

            FROM	 ACPURCHASELIST a LEFT JOIN CMCUSTM b ON a.custcode = b.custcode

            WHERE	 a.compcode = p_compcode
                     AND a.plantcode LIKE p_plantcode
                     AND a.purchaseym = p_purchaseym
                     AND a.custcode LIKE p_custcode || '%'

            ORDER BY a.purchasediv, a.purchaseamt DESC, a.custcode;

    ELSIF ( UPPER(p_div) = UPPER('I') ) THEN

        FOR rec IN (SELECT NVL(MAX(purchaseseq) + 1, 1) AS alias1
                    FROM   ACPURCHASELIST
                    WHERE  compcode = p_compcode
                           AND plantcode = p_plantcode
                           AND purchaseym = p_purchaseym)
        LOOP
            ip_purchaseseq := rec.alias1;
        END LOOP;

        INSERT INTO ACPURCHASELIST(compcode,
                                   plantcode,
                                   purchaseym,
                                   purchaseseq,
                                   purchasediv,
                                   custcode,
                                   itemname,
                                   purchaseamt,
                                   paycondition,
                                   paydate,
                                   insertdt,
                                   iempcode)
            (SELECT p_compcode,
                    p_plantcode,
                    p_purchaseym,
                    ip_purchaseseq,
                    p_purchasediv,
                    p_custcode,
                    p_itemname,
                    p_purchaseamt,
                    p_paycondition,
                    p_paydate,
                    SYSDATE,
                    p_iempcode
             FROM	DUAL);

    ELSIF ( UPPER(p_div) = UPPER('U') ) THEN

        UPDATE ACPURCHASELIST a
        SET    a.purchasediv = p_purchasediv,
               a.custcode = p_custcode,
               a.itemname = p_itemname,
               a.purchaseamt = p_purchaseamt,
               a.paycondition = p_paycondition,
               a.paydate = p_paydate,
               a.updatedt = SYSDATE,
               a.iempcode = p_iempcode
        WHERE  a.compcode = p_compcode
               AND a.plantcode = p_plantcode
               AND a.purchaseym = p_purchaseym
               AND a.purchaseseq = ip_purchaseseq ;

    ELSIF ( UPPER(p_div) = UPPER('D') ) THEN

        DELETE ACPURCHASELIST
        WHERE  compcode = p_compcode
               AND plantcode = p_plantcode
               AND purchaseym = p_purchaseym
               AND purchaseseq = ip_purchaseseq ;

    ELSIF ( UPPER(p_div) = UPPER('C') ) THEN

        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0186R_ACPURCHASELIST';

        INSERT INTO VGT.TT_ACACC0186R_ACPURCHASELIST
            (SELECT *
             FROM	ACPURCHASELIST
             WHERE	compcode = p_compcode
                    AND plantcode = p_plantcode
                    AND purchaseym = p_purchaseym );


        DELETE ACPURCHASELIST
        WHERE  compcode = p_compcode
               AND plantcode = p_plantcode
               AND purchaseym = p_purchaseym;


        INSERT INTO ACPURCHASELIST(compcode,
                                   plantcode,
                                   purchaseym,
                                   purchaseseq,
                                   purchasediv,
                                   custcode,
                                   itemname,
                                   purchaseamt,
                                   paycondition,
                                   paydate,
                                   insertdt,
                                   iempcode)
            SELECT	 p_compcode,
                     a.plantcode,
                     p_purchaseym,
                     ROW_NUMBER() OVER (PARTITION BY a.plantcode ORDER BY a.custcode) purchaseseq,
                     CASE WHEN a.warehousingdiv = '03' THEN '03' WHEN a.warehousingdiv = '02' THEN '04' WHEN b.itemdiv = '01' THEN '01' ELSE '02' END purchasediv,
                     a.custcode,
                     MAX(b.itemname) || CASE WHEN COUNT(*) <= 1 THEN '' ELSE ' 외 ' || TO_CHAR(COUNT(*) - 1) END,
                     SUM(a.finishamt + a.vat),
                     COALESCE(NULLIF(MAX(D.paycondition), ''), MAX(c.paydiv), ''),
                     '',
                     SYSDATE,
                     p_iempcode
            FROM	 PDWAREHOUSINGM a
                     LEFT JOIN CMITEMM b ON a.itemcode = b.itemcode
                     LEFT JOIN CMCUSTM c ON a.custcode = c.custcode
                     LEFT JOIN VGT.TT_ACACC0186R_ACPURCHASELIST D ON CASE  WHEN a.warehousingdiv = '03' THEN '03'
                                                            WHEN a.warehousingdiv = '02' THEN '04'
                                                            WHEN b.itemdiv = '01' THEN '01'
                                                            ELSE '02'
                                                      END = D.purchasediv
                                                      AND a.custcode = D.custcode
            WHERE	 a.plantcode LIKE p_plantcode
                     AND a.accountday BETWEEN p_purchaseym || '-01' AND TO_CHAR(ADD_MONTHS(TO_DATE(p_purchaseym || '-01', 'YYYY-MM-DD'), 1) - 1, 'YYYY-MM-DD')
                     AND a.warehousingdiv IN ('01', '02', '03')
            GROUP BY a.plantcode
                     , CASE WHEN a.warehousingdiv = '03' THEN '03'
                            WHEN a.warehousingdiv = '02' THEN '04'
                            WHEN b.itemdiv = '01' THEN '01'
                            ELSE '02'
                      END
                    , a.custcode
            ORDER BY plantcode, purchasediv, custcode;

    ELSIF ( UPPER(p_div) = UPPER('P') ) THEN

        OPEN IO_CURSOR FOR

            SELECT	 a.purchasediv,
                     D.divname purchasename,
                     c.custname,
                     a.itemname,
                     a.purchaseamt,
                     E.divname paycondition,
                     SUBSTR(NULLIF(paydate, ' '), 6, 2) || '월 ' || SUBSTR(paydate, 9, 2) || '일 결제' paydate,
                     b.*

            FROM	 ACPURCHASELIST a
                     JOIN
                     (SELECT SUBSTR(p_purchaseym, 3, 2) || '년 ' || SUBSTR(p_purchaseym, 6, 2) || '월 구매 내역 리스트' title,
                             SUBSTR(p_purchaseym, 6, 2) || '월 지급 총액' colname,
                             SUM(CASE WHEN paycondition IS NOT NULL THEN purchaseamt ELSE 0 END) paysum,
                             SUM(CASE WHEN NVL(paycondition, '') IS NULL THEN purchaseamt ELSE 0 END) yetpaysum
                      FROM	 ACPURCHASELIST
                      WHERE  compcode = p_compcode
                             AND plantcode LIKE p_plantcode
                             AND purchaseym = p_purchaseym ) b ON 1 = 1
                     LEFT JOIN CMCUSTM c ON a.custcode = c.custcode
                     LEFT JOIN CMCOMMONM D ON D.cmmcode = 'AC863'
                                              AND a.purchasediv = D.divcode
                     LEFT JOIN CMCOMMONM E ON E.cmmcode = 'CM44'
                                              AND a.paycondition = E.divcode

            WHERE	 a.compcode = p_compcode
                     AND a.plantcode LIKE p_plantcode
                     AND a.purchaseym = p_purchaseym

            ORDER BY a.purchasediv, a.purchaseamt DESC, a.custcode;

	END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
