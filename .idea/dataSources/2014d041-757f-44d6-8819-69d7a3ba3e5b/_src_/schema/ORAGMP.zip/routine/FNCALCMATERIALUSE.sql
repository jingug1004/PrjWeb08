CREATE FUNCTION fnCalcMaterialUse(
	-- ---------------------------------------------------------------
	-- 함 수 명   : fnCalcMaterialUse
	-- 작 성 자         : 민승기
	-- 작성일자         : 2007-11-29
    -- 수정일자      :   노영래
	-- E-mail      :   0rae0926@gmail.com
	-- 수정일자      :   2016-01-11
	-- ---------------------------------------------------------------
	-- 함수설명   : 원자재 구매요청량 계산
	-- ---------------------------------------------------------------

	p_startqty		  IN NUMBER DEFAULT 0,
	p_requestqty	  IN NUMBER DEFAULT 0,
	p_orderqty		  IN NUMBER DEFAULT 0,
	p_outqty		  IN NUMBER DEFAULT 0,
	p_safestockqty	  IN NUMBER DEFAULT 0,
	p_minorderqty	  IN NUMBER DEFAULT 0
)
	RETURN NUMBER
AS
  p_todecimal    NUMBER(15, 4);
  p_stockqty     NUMBER(15, 4);
  p_useqty     NUMBER(15, 4);
BEGIN
  p_stockqty := NVL(p_startqty, 0) + NVL(p_requestqty, 0) + NVL(p_orderqty, 0);
  p_useqty := NVL(p_safestockqty, 0) + NVL(p_outqty, 0);
  p_todecimal := CASE WHEN p_stockqty >= p_useqty THEN 0 ELSE CASE WHEN ABS(p_stockqty - p_useqty) > NVL(p_minorderqty, 0) THEN ABS(p_stockqty - p_useqty) ELSE NVL(p_minorderqty, 0) END END;
  RETURN (p_todecimal);
EXCEPTION
  WHEN OTHERS
  THEN NULL;
END;
/
