CREATE PROCEDURE        spACacc0000
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0000
-- 작 성 자         : 민승기
-- 작성일자         : 2010-10-06
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2016-12-12
-- ---------------------------------------------------------------
-- 프로시저 설명    : 회계전표내역 검색 가능여부 체크하는 프로시저이다.
-- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '',
    p_iempcode      IN  VARCHAR2 DEFAULT '',
    p_userid        IN  VARCHAR2 DEFAULT '',
    p_reasondiv     IN  VARCHAR2 DEFAULT '',
    p_reasontext    IN  VARCHAR2 DEFAULT '',

    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_jurisdictionyn    VARCHAR2(5);
BEGIN
    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values(p_userid, p_reasondiv, p_reasontext);

    for rec in (
        select  case when upper(e.empcode) = upper('gmpit') or -- 슈퍼유저
                          nvl(trim(p1.parametercode), '') is not null or -- 회계슈퍼유저
                          nvl(trim(p2.parametercode), '') is not null -- 회계슈퍼부서
                     then '%'
                     else d.deptcode
                     end jurisdictionyn
        from    CMEMPM e
                join CMDEPTM d
                    on e.deptcode = d.deptcode
                left join SYSPARAMETERMANAGE p1
                    on p1.parametercode = 'slipsuperemp'
                    and (p1.value1 = e.empcode or p1.value2 = e.empcode or p1.value3 = e.empcode)
                left join SYSPARAMETERMANAGE p2
                    on p2.parametercode = 'slipsuperdept'
                    and (p2.value1 = e.deptcode or p2.value2 = e.deptcode or p2.value3 = e.deptcode)
        where  e.empcode = p_iempcode)
    loop
        p_jurisdictionyn := rec.jurisdictionyn;
    end loop;

    MESSAGE := p_jurisdictionyn;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;
END;
/
