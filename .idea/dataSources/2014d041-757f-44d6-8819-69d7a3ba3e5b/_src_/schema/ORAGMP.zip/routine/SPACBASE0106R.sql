CREATE PROCEDURE        spACbase0106R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbase0108P
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-09-14
    -- 수 정 자     : 강현호
    -- E-Mail       : roykang0722@gmail.com
    -- 수정일자      : 2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계거래처현황을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------
(
	p_div			   IN	  VARCHAR2 DEFAULT '',
	p_plantcode 	   IN	  VARCHAR2 DEFAULT '',
	p_custcode		   IN	  VARCHAR2 DEFAULT '',
	p_custname		   IN	  VARCHAR2 DEFAULT '',
	p_custsname 	   IN	  VARCHAR2 DEFAULT '',
	p_custename 	   IN	  VARCHAR2 DEFAULT '',
	p_custcondition    IN	  VARCHAR2 DEFAULT '',
	p_custitem		   IN	  VARCHAR2 DEFAULT '',
	p_custdiv		   IN	  VARCHAR2 DEFAULT '',
	p_custbuydiv	   IN	  VARCHAR2 DEFAULT '',
	p_businessno	   IN	  VARCHAR2 DEFAULT '',
	p_ceoname		   IN	  VARCHAR2 DEFAULT '',
	p_ceono 		   IN	  VARCHAR2 DEFAULT '',
	p_telno 		   IN	  VARCHAR2 DEFAULT '',
	p_faxno 		   IN	  VARCHAR2 DEFAULT '',
	p_custempname	   IN	  VARCHAR2 DEFAULT '',
	p_post			   IN	  VARCHAR2 DEFAULT '',
	p_addr1 		   IN	  VARCHAR2 DEFAULT '',
	p_addr2 		   IN	  VARCHAR2 DEFAULT '',
	p_addre 		   IN	  VARCHAR2 DEFAULT '',
	p_paydiv		   IN	  VARCHAR2 DEFAULT '',
	p_bankcode		   IN	  VARCHAR2 DEFAULT '',
	p_accountno 	   IN	  VARCHAR2 DEFAULT '',
	p_bankempname	   IN	  VARCHAR2 DEFAULT '',
	p_iempcode		   IN	  VARCHAR2 DEFAULT '',
	p_userid		   IN	  VARCHAR2 DEFAULT '',
	p_reasondiv 	   IN	  VARCHAR2 DEFAULT '',
	p_reasontext	   IN	  VARCHAR2 DEFAULT '',

    MESSAGE            OUT    VARCHAR2,
    IO_CURSOR          OUT    TYPES.DataSet
)
AS
BEGIN

	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	IF (UPPER(p_div) = 'S') THEN

        OPEN IO_CURSOR FOR

            SELECT	 NVL(A.plantcode, '') plantcode,
                     NVL(A.custcode, '') custcode,
                     NVL(A.custname, '') custname,
                     NVL(A.businessno, '') businessno,
                     NVL(A.ceoname, '') ceoname,
                     NVL(A.POST, '') POST,
                     NVL(A.addr1, '') addr,
                     NVL(A.custdiv, '') custdiv,
                     NVL(A.telno, '') telno,
                     NVL(A.faxno, '') faxno,
                     NVL(A.custempname, '') custempname,
                     NVL(A.custcondition, '') custcondition,
                     NVL(A.custitem, '') custitem,
                     NVL(c.empname, '') empname

            FROM	 CMCUSTM A
                     LEFT JOIN CMCOMMONM b ON A.custdiv = b.divcode
                                              AND b.cmmcode = 'CM11'																																																												 --거래처구분
                     LEFT JOIN CMEMPM c ON A.empcode = c.empcode

            WHERE	 A.plantcode = p_plantcode
                     AND (upper(A.custcode) LIKE upper(p_custcode) || '%' OR upper(A.custname) LIKE '%' || upper(p_custcode) || '%')

            ORDER BY A.custcode;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
