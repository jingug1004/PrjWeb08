CREATE PROCEDURE        spACbase0012P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbase0012P
	-- 작 성 자         : 홍지은
	-- 작성일자         : 2015-04-03
	-- 수정일자  		 :   노영래
	-- E-mail  		 :   0rae0926@gmail.com
	-- 수정일자  		 :   2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 자금마스터를 관리하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_fundcode		IN	   VARCHAR2 DEFAULT '',
	p_fundname		IN	   VARCHAR2 DEFAULT '',
	p_inoutdiv		IN	   VARCHAR2 DEFAULT '',
	p_remark		IN	   VARCHAR2 DEFAULT '',
	p_empcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	p_checkcnt2   NUMBER(10, 0) := 0;
BEGIN
	--SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTE
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	IF (UPPER(P_DIV) = 'S') THEN
		OPEN IO_CURSOR FOR
			SELECT	 fundcode,																																																																		  --자금코드
							  fundname, 																																																															  --자금명칭
									   inoutdiv,																																																													  --입출구분
												remark																																																													--비고
			FROM	 ACFUNDM
			WHERE	 compcode = p_compcode
					 AND NVL(fundcode, ' ') LIKE p_fundcode || '%'
			ORDER BY fundcode;

	ELSIF (UPPER(P_DIV) = 'SC') THEN
		FOR rec IN (SELECT COUNT(fundcode) AS alias1
					FROM   ACFUNDM
					WHERE  compcode = p_compcode
						   AND fundcode = p_fundcode)
		LOOP
			p_checkcnt2 := rec.alias1;
		END LOOP;

		MESSAGE := '';

		IF p_checkcnt2 > 0
		THEN
			BEGIN
				MESSAGE := '등록된 자금코드 입니다.';
			END;
		END IF;

	ELSIF (UPPER(P_DIV) = 'I') THEN
		INSERT INTO ACFUNDM(compcode,
							fundcode,
							fundname,
							inoutdiv,
							remark,
							insertdt,
							iempcode)
		VALUES		(p_compcode,
					 p_fundcode,
					 p_fundname,
					 p_inoutdiv,
					 p_remark,
					 SYSDATE,
					 p_empcode);

	ELSIF (UPPER(P_DIV) = 'U') THEN
		UPDATE ACFUNDM
		SET    fundname = p_fundname, inoutdiv = p_inoutdiv, remark = p_remark, updatedt = SYSDATE, uempcode = p_empcode
		WHERE  compcode = p_compcode
			   AND fundcode = p_fundcode;

	ELSIF (UPPER(P_DIV) = 'D') THEN
		DELETE ACFUNDM
		WHERE  compcode = p_compcode
			   AND fundcode = p_fundcode;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
