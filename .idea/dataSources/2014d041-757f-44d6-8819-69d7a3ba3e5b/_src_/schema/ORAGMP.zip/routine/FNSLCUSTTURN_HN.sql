CREATE FUNCTION        fnSLcustTURN_HN
-- ---------------------------------------------------------------
-- 함 수 명              : [dbo].[fnSLcustTURN_HN]
-- 작 성 자           : 민승기
-- 작성일자           : 2014-01-13

-- 수정내용              : turncnt - 여신회전일 , turndccnt - 잔고회전일 임 (KB Pharm 여신회전일이 주이다.
-- ---------------------------------------------------------------
-- 함수설명              : 지정일자기준의 거래처 회전일을
--                            계산하여 테이블로 리턴
--        수 정 일      : 2014-02-14
--                        영업영역 파라메터 추가
--                        잔고,미결어음,총잔고 추가
--                        회전일 변화 계산 추가
-- ---------------------------------------------------------------
-- select * from [dbo].[fnSLcustTURN_HN]('1002','%','%','%','2014-05-31',0)
/*

select    empcode, deptcode, *
    from    cmcustm
        where    custcode = '2000000131'

*/

(
   AS_YEARMONTH         IN    VARCHAR2,
   AS_FRCODE            IN    VARCHAR2
)
RETURN VARCHAR2
AS

    VS_YEARMONTH               VARCHAR2(20);
    VS_CUSTCODE                VARCHAR2(20);
    VS_PLANTCODE               VARCHAR2(20);
    VS_DEPTCODE                VARCHAR2(20);
    VS_EMPCODE                 VARCHAR2(20);

    VS_YYMMDD                  VARCHAR2(20);

    VN_JANGOAMT                NUMBER      ;
    VN_REAM_AMT                NUMBER      ;
    VN_RATEDAY                 NUMBER      ;

    VN_COUNT                   NUMBER      ;

    CURSOR JANGO_AMT IS

      SELECT YEARMONTH,
             CUSTCODE ,
             PLANTCODE,
             MAX(DEPTCODE) ,
             MAX(EMPCODE)  ,
             SUM(BALANCE)
        FROM SLRESULTM
       WHERE YEARMONTH = AS_YEARMONTH                          --2017-11'
         AND CUSTCODE = AS_FRCODE
    GROUP BY YEARMONTH, CUSTCODE, PLANTCODE
    ORDER BY CUSTCODE;

BEGIN

    --   DBMS_OUTPUT.ENABLE;

   -- 가상계좌 전자어음제외 처리
   OPEN JANGO_AMT;
   LOOP
      FETCH JANGO_AMT INTO VS_YEARMONTH, VS_CUSTCODE, VS_PLANTCODE, VS_DEPTCODE, VS_EMPCODE, VN_JANGOAMT ;
      EXIT WHEN JANGO_AMT%NOTFOUND ;

   --거래처 회전일계산 -------------------------------------------------------

      VN_REAM_AMT := VN_JANGOAMT; --금월잔액

      FOR C2 IN
            (SELECT A.YYMMDD,
                    SUM(A.SALE_AMT) SALE_AMT
               FROM
                  ( SELECT A.ORDERDATE                                                                AS YYMMDD,
                           -NVL(SUM(DECODE(A.SALDIV,'A01', NVL(B.SALAMT,0) + NVL(B.SALVAT,0), 0)),0)  AS SALE_AMT --판매
                      FROM SLORDM A, --SALE0207 A,
                           SLORDD B  --SALE0208 B
                     WHERE A.ORDERNO = B.ORDERNO
                       AND A.CUSTCODE IN (   SELECT CUSTCODE
                                               FROM CMCUSTM --SALE0003
                                         CONNECT BY CUSTCODE = PRIOR INGAE_CUST_ID
                                         START WITH CUSTCODE = VS_CUSTCODE )
                       AND A.ORDERDATE <= TO_CHAR(LAST_DAY(TO_DATE(AS_YEARMONTH||'-01','YYYY-MM-DD')),'YYYY-MM-DD')
                       AND A.STATEDIV = '09'
                  GROUP BY A.ORDERDATE
                  ) A
           GROUP BY A.YYMMDD
           ORDER BY A.YYMMDD DESC
      )
      LOOP

         --금월잔고가 0 이거나  마이너스면 회전일은 30일 이내로 한다.
         IF VN_JANGOAMT <= 0 THEN

            VS_YYMMDD := TO_CHAR(LAST_DAY(TO_DATE(AS_YEARMONTH||'01','YYYY/MM/DD')),'YYYY-MM-DD');
            EXIT;

         ELSE

            VN_REAM_AMT := VN_REAM_AMT + C2.SALE_AMT;
            VS_YYMMDD   := C2.YYMMDD;                  --회전일이 끝나는날

            IF VN_REAM_AMT <= 0 THEN                   --회전일이 끝나는날
               EXIT;
            END IF;

         END IF;

      END LOOP;


      --회전일계산
      --원내(의원),원외(약국)거래처는 30일을 뺀다.
      --윤홍주 2013.09.09

      SELECT LAST_DAY(TO_DATE(AS_YEARMONTH||'-01','YYYY-MM-DD')) - TO_DATE(VS_YYMMDD,'YYYY-MM-DD')
        INTO VN_RATEDAY
        FROM DUAL;

      IF SUBSTR(VS_CUSTCODE,1,1) IN ('3','4') THEN

         IF VN_JANGOAMT <= 0 THEN

            VN_RATEDAY := 0; --금월잔고가 0인경우 회전일은 0 으로 한다.-윤홍주 2013.10.16

         ELSE

            VN_RATEDAY :=  VN_RATEDAY - 30;

         END IF;

      END IF;

   END LOOP;
   CLOSE JANGO_AMT;

   RETURN (VN_RATEDAY);

   EXCEPTION WHEN OTHERS THEN RETURN (VN_RATEDAY);

END;
/
