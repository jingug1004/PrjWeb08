CREATE PROCEDURE spACacc0160R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0160R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-01-05
	-- 수정일자       :   노영래
	-- E-mail       :   0rae0926@gmail.com
	-- 수정일자       :   2016-12-14
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계전표의 반제처리내역을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------
(
	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_strdate		IN	   VARCHAR2 DEFAULT '',
	p_enddate		IN	   VARCHAR2 DEFAULT '',
	p_acccode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',

	MESSAGE 		OUT    VARCHAR2,
	IO_CURSOR		OUT    TYPES.DATASET
)
AS
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S') THEN

		-- 결의전표내역 검색
		OPEN IO_CURSOR FOR
			SELECT	 NVL(a.slipindate, '') slipindate,      -- 결의일자
					 NVL(a.slipinnum, '') slipinnum,        -- 결의번호
					 NVL(a.deptcode, '') deptcode,          -- 결의부서
					 NVL(D.deptname, '') deptname,          -- 결의부서명
					 NVL(a.empcode, '') empcode,            -- 결의사원
					 NVL(E.empname, '') empname,            -- 결의사원명
					 NVL(b.acccode, '') acccode,            -- 계정코드
					 NVL(c.accname, '') accname,            -- 계정명
					 NVL(b.debamt + b.creamt, 0) slipamt,   -- 발생금액
					 NVL(b.remark1, '') remark,             -- 결의내용
					 f.repaydate,                           -- 반제일자
					 f.repayamt,                            -- 반제금액
					 G.empcode repayempcode,                -- 승인사원
					 h.empname repayempname,                -- 승인사원명
					 NVL(a.slipdiv, '') slipdiv             -- 전표유형구분

			FROM	 ACORDM a
					 JOIN ACORDD b ON a.compcode = b.compcode
							          AND a.slipinno = b.slipinno
					 JOIN ACACCM c ON b.acccode = c.acccode
							          AND c.returnyn = 'Y'
					 LEFT JOIN CMDEPTM D ON a.deptcode = D.deptcode
					 LEFT JOIN CMEMPM E ON a.empcode = E.empcode
					 LEFT JOIN ACORDRPYD f ON b.compcode = f.compcode
                                              AND b.slipinno = f.slipinno
                                              AND b.slipinseq = f.slipinseq
					 LEFT JOIN ACORDM G ON f.compcode = G.compcode
							               AND f.crtslipinno = G.slipinno
					 LEFT JOIN CMEMPM h ON G.empcode = h.empcode

			WHERE	 a.compcode = p_compcode
					 AND a.plantcode LIKE p_plantcode
					 AND a.slipindate BETWEEN p_strdate AND p_enddate
					 AND b.acccode LIKE p_acccode || '%'

			ORDER BY a.slipindate, a.slipinno, b.slipinseq, f.crtslipinno;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
