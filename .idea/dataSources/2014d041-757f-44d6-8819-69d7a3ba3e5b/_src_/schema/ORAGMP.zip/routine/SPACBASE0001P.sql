CREATE PROCEDURE        spACbase0001P
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbase0001P
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-08-20
    -- 수 정 자     : 강현호
    -- E-Mail       : roykang0722@gmail.com
    -- 수정일자      : 2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계기수를 등록,수정,삭제,조회하는 프로시저이다.
	-- ---------------------------------------------------------------
(
	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_cyear 		IN	   VARCHAR2 DEFAULT NULL,
	p_sseq			IN	   NUMBER   DEFAULT NULL,
	p_curstrdate	IN	   VARCHAR2 DEFAULT '',
	p_curenddate	IN	   VARCHAR2 DEFAULT '',
	p_prvstrdate	IN	   VARCHAR2 DEFAULT '',
	p_prvenddate	IN	   VARCHAR2 DEFAULT '',
	p_reportdate	IN	   VARCHAR2 DEFAULT '',
	p_fixdate		IN	   VARCHAR2 DEFAULT '',
	p_iempcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',

    MESSAGE         OUT    VARCHAR2,
    IO_CURSOR       OUT    TYPES.DataSet
)
AS
BEGIN

	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (UPPER(p_div) = UPPER('S')) THEN

        OPEN IO_CURSOR FOR

            SELECT NVL(a.compcode, '') compcode,
                   NVL(a.cyear, '') cyear,
                   NVL(a.sseq, 0) sseq,
                   NVL(a.curstrdate, '') curstrdate,
                   NVL(a.curenddate, '') curenddate,
                   NVL(a.prvstrdate, '') prvstrdate,
                   NVL(a.prvenddate, '') prvenddate,
                   NVL(a.reportdate, '') reportdate,
                   NVL(a.fixdate, '') fixdate,
                   --NULLIF(a.insertdt, '') insertdt,
                   DECODE(a.insertdt, NULL, '', TO_CHAR(a.insertdt)),
                   NVL(a.iempcode, '') iempcode,
                   --NULLIF(a.updatedt, '') updatedt,
                   DECODE(a.updatedt, NULL, '', TO_CHAR(a.updatedt)),
                   NVL(a.uempcode, '') uempcode,
                   NVL(b.compname, '') compname

            FROM   ACSESSION a
                   LEFT JOIN CMCOMPM b ON a.compcode = b.compcode

            WHERE  a.compcode LIKE p_compcode || '%'
                   AND a.sseq = NVL(p_sseq, a.sseq)
                   AND a.cyear LIKE NVL(p_cyear, a.cyear) || '%';

	ELSIF (UPPER(p_div) = UPPER('SC')) THEN

        FOR rec IN (SELECT COUNT(compcode) AS alias1
                    FROM   ACSESSION
                    WHERE  compcode = p_compcode
                           AND cyear = p_cyear)
        LOOP
            MESSAGE := rec.alias1;
        END LOOP;

    ELSIF (UPPER(p_div) = UPPER('SI')) THEN

        FOR rec IN (SELECT NVL(MAX(sseq), 0) + 1 AS alias1
                    FROM   ACSESSION
                    WHERE  compcode = p_compcode)
        LOOP
            MESSAGE := rec.alias1;
        END LOOP;

    ELSIF (UPPER(p_div) = UPPER('I')) THEN

        INSERT INTO ACSESSION(compcode,
                              cyear,
                              sseq,
                              curstrdate,
                              curenddate,
                              prvstrdate,
                              prvenddate,
                              reportdate,
                              fixdate,
                              insertdt,
                              iempcode)
        VALUES		(p_compcode,
                     p_cyear,
                     p_sseq,
                     p_curstrdate,
                     p_curenddate,
                     p_prvstrdate,
                     p_prvenddate,
                     p_reportdate,
                     p_fixdate,
                     SYSDATE,
                     p_iempcode);

    ELSIF (UPPER(p_div) = UPPER('U')) THEN

        UPDATE ACSESSION
        SET    compcode = p_compcode,
               cyear = p_cyear,
               sseq = p_sseq,
               curstrdate = p_curstrdate,
               curenddate = p_curenddate,
               prvstrdate = p_prvstrdate,
               prvenddate = p_prvenddate,
               reportdate = p_reportdate,
               fixdate = p_fixdate,
               updatedt = SYSDATE,
               uempcode = p_iempcode
        WHERE  compcode = p_compcode
               AND cyear = p_cyear;

    ELSIF (UPPER(p_div) = UPPER('D')) THEN

        DELETE ACSESSION
        WHERE  compcode = p_compcode
               AND cyear = p_cyear;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
