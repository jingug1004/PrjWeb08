CREATE PROCEDURE spACacc0028R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0028R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-11-08
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 카드매출비교를 관리하는 프로시저이다.
	-- ---------------------------------------------------------------
(
	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_strdate		IN	   VARCHAR2 DEFAULT '',
	p_enddate		IN	   VARCHAR2 DEFAULT '',
	p_viewtype		IN	   VARCHAR2 DEFAULT '',
	p_cardcomp		IN	   VARCHAR2 DEFAULT '%',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		OUT    VARCHAR2,
	IO_CURSOR		OUT    TYPES.DataSet,
	IO_CURSOR2		OUT    TYPES.DataSet
)
AS
	p_coldiv   VARCHAR2(5);
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	p_coldiv := '21';

	IF ( UPPER(p_div) = UPPER('S') AND UPPER(p_viewtype) = UPPER('1') ) THEN

        OPEN IO_CURSOR FOR -- Start

            WITH TT_SLCOLM1 AS
            (
                SELECT a.custcode,
                        D.custname,
                        D.businessno,
                        c.slipdate coldate,
                        a.colamt,
                        a.cardno,
                        a.cardokno,
                        E.divname cardcomp,
                        a.autoyn

                 FROM	SLCOLM a JOIN ACAUTOORDT b ON b.compcode = p_compcode
                                                      AND b.acattype = 'C'
                                                      AND a.colno = b.acatno
                        JOIN ACORDM c ON b.compcode = c.compcode
                                         AND b.slipinno = c.slipinno
                        LEFT JOIN CMCUSTM D ON a.custcode = D.custcode
                        LEFT JOIN CMCOMMONM E ON E.cmmcode = 'AC17'
                                                 AND a.cardcomp = E.divcode
                        LEFT JOIN CMCOMMONM f ON E.hcmmcode = f.cmmcode
                                                 AND E.hdivcode = f.divcode

                 WHERE	c.slipdate BETWEEN p_strdate AND p_enddate
                        AND a.coldiv = p_coldiv
                        AND NVL(f.divcode, ' ') LIKE p_cardcomp
            )

            , TT_CSM_MS_TRAN1 AS
            (
                SELECT  SUBSTR(TRIM(a.TrDate), 1, 4) || '-' || SUBSTR(TRIM(a.TrDate), 5, 2) || '-' || SUBSTR(TRIM(a.TrDate), 7, 2) AS TrDate ,
                        a.CardNo,
                        a.AppNo,
                        SUBSTR(TRIM(a.IpGumDate), 1, 4) || '-' || SUBSTR(TRIM(a.IpGumDate), 5, 2) || '-' || SUBSTR(TRIM(a.IpGumDate), 7, 2) AS IpGumDate ,
                        a.Amt,
                        a.CatID,
                        NVL(a.ACQ_CARD_CD, '') cardcompC

                 FROM	IBKDB_CSM_MS_TRAN a
                        LEFT JOIN IBKDB_ISS_BANK b ON a.ACQ_CARD_CD = b.BANK_CD
                        LEFT JOIN CMCOMMONM c ON c.cmmcode = 'AC17'
                                                 AND SUBSTR(a.ACQ_CARD_CD, -2, 2) = c.filter2
                        LEFT JOIN CMCOMMONM D ON c.hcmmcode = D.cmmcode
                                                 AND c.hdivcode = D.divcode

                 WHERE	a.TrDate BETWEEN REPLACE(p_strdate, '-', '') AND REPLACE(p_enddate, '-', '')
                        AND a.IpGumDate IS NOT NULL
                        AND (p_cardcomp = '%' OR a.ACQ_CARD_CD LIKE '%' || (SELECT  divname
                                                                            FROM    CMCOMMONM
                                                                            WHERE   cmmcode = 'AC171'
                                                                                    AND divcode = p_cardcomp) || '%')
            ) --WITH END

            SELECT	 NVL(a.custcode, '') custcode,
                     NVL(a.custname, '') custname,
                     NVL(a.businessno, '') businessno,
                     a.coldate,
                     a.colamt,
                     a.cardcomp,
                     a.cardno,
                     a.cardokno,
                     b.TrDate,
                     b.Amt,
                     b.cardcompC,
                     b.CardNo CardNoC,
                     b.AppNo,
                     b.IpGumDate,
                     b.CatID,
                     NVL(a.colamt, 0) - NVL(b.Amt, 0) diffamt,
                     a.autoyn

            FROM	 TT_SLCOLM1 a
                     FULL JOIN TT_CSM_MS_TRAN1 b ON SUBSTR(REPLACE(a.cardno, '-', ''), 0, 8) = SUBSTR(REPLACE(b.CardNo, '-', ''), 0, 8)
                                                    AND SUBSTR(a.cardno, -LENGTH(b.CardNo) - 12, LENGTH(b.CardNo) - 12) = SUBSTR(b.CardNo, -LENGTH(b.CardNo) - 12, LENGTH(b.CardNo) - 12)
                                                    AND a.cardokno = b.AppNo
                                                    AND a.colamt = b.Amt
            ORDER BY businessno, NVL(a.coldate, b.TrDate), NVL(a.cardno, b.CardNo), NVL(a.cardokno, b.AppNo);

        -- OPEN IO_CURSOR FOR -- END





        OPEN IO_CURSOR2 FOR -- START

            WITH TT_SLCOLM1 AS
            (
                SELECT a.custcode,
                        D.custname,
                        D.businessno,
                        c.slipdate coldate,
                        a.colamt,
                        a.cardno,
                        a.cardokno,
                        E.divname cardcomp,
                        a.autoyn

                 FROM    SLCOLM a JOIN ACAUTOORDT b ON b.compcode = p_compcode
                                                       AND b.acattype = 'C'
                                                       AND a.colno = b.acatno
                        JOIN ACORDM c ON b.compcode = c.compcode
                                         AND b.slipinno = c.slipinno
                        LEFT JOIN CMCUSTM D ON a.custcode = D.custcode
                        LEFT JOIN CMCOMMONM E ON E.cmmcode = 'AC17'
                                                 AND a.cardcomp = E.divcode
                        LEFT JOIN CMCOMMONM f ON E.hcmmcode = f.cmmcode
                                                 AND E.hdivcode = f.divcode

                 WHERE    c.slipdate BETWEEN p_strdate AND p_enddate
                        AND a.coldiv = p_coldiv
                        AND NVL(f.divcode, ' ') LIKE p_cardcomp
            )

            , TT_CSM_MS_TRAN1 AS
            (
                SELECT  SUBSTR(TRIM(a.TrDate), 1, 4) || '-' || SUBSTR(TRIM(a.TrDate), 5, 2) || '-' || SUBSTR(TRIM(a.TrDate), 7, 2) AS TrDate ,
                        a.CardNo,
                        a.AppNo,
                        SUBSTR(TRIM(a.IpGumDate), 1, 4) || '-' || SUBSTR(TRIM(a.IpGumDate), 5, 2) || '-' || SUBSTR(TRIM(a.IpGumDate), 7, 2) AS IpGumDate ,
                        a.Amt,
                        a.CatID,
                        NVL(a.ACQ_CARD_CD, '') cardcompC

                 FROM    IBKDB_CSM_MS_TRAN a
                        LEFT JOIN IBKDB_ISS_BANK b ON a.ACQ_CARD_CD = b.BANK_CD
                        LEFT JOIN CMCOMMONM c ON c.cmmcode = 'AC17'
                                                 AND SUBSTR(a.ACQ_CARD_CD, -2, 2) = c.filter2
                        LEFT JOIN CMCOMMONM D ON c.hcmmcode = D.cmmcode
                                                 AND c.hdivcode = D.divcode

                 WHERE  a.TrDate BETWEEN REPLACE(p_strdate, '-', '') AND REPLACE(p_enddate, '-', '')
                        AND a.IpGumDate IS NOT NULL
                        AND (p_cardcomp = '%' OR a.ACQ_CARD_CD LIKE '%' || (SELECT  divname
                                                                            FROM    CMCOMMONM
                                                                            WHERE   cmmcode = 'AC171'
                                                                                    AND divcode = p_cardcomp) || '%')
            ) --WITH END

            SELECT	 NVL(a.cardno, b.CardNo) cardno,
                     a.coldate,
                     a.colamt,
                     a.cardcomp,
                     a.cardokno,
                     a.custcode,
                     a.custname,
                     a.businessno,
                     b.TrDate,
                     b.Amt,
                     b.cardcompC,
                     b.AppNo,
                     b.IpGumDate,
                     b.CatID,
                     NVL(a.colamt, 0) - NVL(b.Amt, 0) diffamt,
                     a.autoyn

            FROM	 TT_SLCOLM1 a
                     FULL JOIN TT_CSM_MS_TRAN1 b ON SUBSTR(REPLACE(a.cardno, '-', ''), 0, 8) = SUBSTR(REPLACE(b.CardNo, '-', ''), 0, 8)
                                                    AND SUBSTR(a.cardno, -LENGTH(b.CardNo) - 12, LENGTH(b.CardNo) - 12) = SUBSTR(b.CardNo, -LENGTH(b.CardNo) - 12, LENGTH(b.CardNo) - 12)
                                                    AND a.cardokno = b.AppNo
                                                    AND a.colamt = b.Amt

            ORDER BY SUBSTR(NVL(a.cardno, b.CardNo), 0, 8)
                     , CASE WHEN NVL(a.cardno, b.CardNo) IS NOT NULL THEN SUBSTR( NVL(a.cardno, b.CardNo), 0, 4 )
                            ELSE ''
                       END
                     , NVL(a.coldate, b.TrDate)
                     , NVL(a.cardokno, b.AppNo) ;

        --OPEN IO_CURSOR2 FOR -- END

  ELSIF ( UPPER(p_div) = UPPER('S') AND UPPER(p_viewtype) = UPPER('2') ) THEN

        OPEN IO_CURSOR FOR -- START

            WITH TT_SLCOLM2 AS
            (
                SELECT a.custcode,
                        D.custname,
                        D.businessno,
                        c.slipdate coldate,
                        a.colamt,
                        a.cardno,
                        a.cardokno,
                        E.divname cardcomp,
                        a.autoyn

                 FROM  SLCOLM a
                        JOIN ACAUTOORDT b ON b.compcode = p_compcode
                                             AND b.acattype = 'C'
                                             AND a.colno = b.acatno
                        JOIN ACORDM c ON b.compcode = c.compcode
                                         AND b.slipinno = c.slipinno
                        LEFT JOIN CMCUSTM D ON a.custcode = D.custcode
                        LEFT JOIN CMCOMMONM E ON E.cmmcode = 'AC17'
                                                 AND a.cardcomp = E.divcode
                        LEFT JOIN CMCOMMONM f ON E.hcmmcode = f.cmmcode
                                                 AND E.hdivcode = f.divcode

                 WHERE  c.slipdate BETWEEN p_strdate AND p_enddate
                        AND a.coldiv = p_coldiv
                        AND NVL(f.divcode, ' ') LIKE p_cardcomp
            )
            , TT_CSM_MS_TRAN2 AS
            (
                SELECT  SUBSTR(TRIM(a.TrDate), 1, 4) || '-' || SUBSTR(TRIM(a.TrDate), 5, 2) || '-' || SUBSTR(TRIM(a.TrDate), 7, 2) AS TrDate ,
                        a.CardNo,
                        a.AppNo,
                        SUBSTR(TRIM(a.IpGumDate), 1, 4) || '-' || SUBSTR(TRIM(a.IpGumDate), 5, 2) || '-' || SUBSTR(TRIM(a.IpGumDate), 7, 2) AS IpGumDate ,
                        a.Amt,
                        a.CatID,
                        NVL(a.ACQ_CARD_CD, '') cardcompC

                 FROM  IBKDB_CSM_MS_TRAN a
                        LEFT JOIN IBKDB_ISS_BANK b ON a.ACQ_CARD_CD = b.BANK_CD
                        LEFT JOIN CMCOMMONM c ON c.cmmcode = 'AC17'
                                                 AND SUBSTR(a.ACQ_CARD_CD, -2, 2) = c.filter2
                        LEFT JOIN CMCOMMONM D ON c.hcmmcode = D.cmmcode
                                                 AND c.hdivcode = D.divcode
                 WHERE  a.TrDate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), -3), 'YYYYMMDD') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), 3), 'YYYYMMDD')
                        AND a.IpGumDate IS NOT NULL
                        AND (p_cardcomp = '%' OR a.ACQ_CARD_CD LIKE '%' || (SELECT divname
                                                                            FROM   CMCOMMONM
                                                                            WHERE  cmmcode = 'AC171'
                                                                                   AND divcode = p_cardcomp) || '%')
            )

            SELECT   a.custcode,
                     a.custname,
                     a.businessno,
                     a.coldate,
                     a.colamt,
                     a.cardcomp,
                     a.cardno,
                     a.cardokno,
                     b.TrDate,
                     b.Amt,
                     b.cardcompC,
                     b.CardNo CardNoC,
                     b.AppNo,
                     b.IpGumDate,
                     b.CatID,
                     NVL(a.colamt, 0) - NVL(b.Amt, 0) diffamt,
                     a.autoyn
            FROM   TT_SLCOLM2 a
                     LEFT JOIN TT_CSM_MS_TRAN2 b
                         ON SUBSTR(REPLACE(a.cardno, '-', ''), 0, 8) = SUBSTR(REPLACE(b.CardNo, '-', ''), 0, 8)
                            AND SUBSTR(a.cardno, -LENGTH(b.CardNo) - 12, LENGTH(b.CardNo) - 12) = SUBSTR(b.CardNo, -LENGTH(b.CardNo) - 12, LENGTH(b.CardNo) - 12)
                            AND a.cardokno = b.AppNo
                            AND a.colamt = b.Amt
            ORDER BY a.businessno, a.coldate, a.cardno, a.cardokno;

        -- OPEN IO_CURSOR FOR -- END



        OPEN IO_CURSOR2 FOR --START

            WITH TT_SLCOLM2 AS
            (
                SELECT a.custcode,
                        D.custname,
                        D.businessno,
                        c.slipdate coldate,
                        a.colamt,
                        a.cardno,
                        a.cardokno,
                        E.divname cardcomp,
                        a.autoyn

                 FROM    SLCOLM a
                        JOIN ACAUTOORDT b ON b.compcode = p_compcode
                                             AND b.acattype = 'C'
                                             AND a.colno = b.acatno
                        JOIN ACORDM c ON b.compcode = c.compcode
                                         AND b.slipinno = c.slipinno
                        LEFT JOIN CMCUSTM D ON a.custcode = D.custcode
                        LEFT JOIN CMCOMMONM E ON E.cmmcode = 'AC17'
                                                 AND a.cardcomp = E.divcode
                        LEFT JOIN CMCOMMONM f ON E.hcmmcode = f.cmmcode
                                                 AND E.hdivcode = f.divcode

                 WHERE    c.slipdate BETWEEN p_strdate AND p_enddate
                        AND a.coldiv = p_coldiv
                        AND NVL(f.divcode, ' ') LIKE p_cardcomp
            )
            , TT_CSM_MS_TRAN2 AS
            (
                SELECT  SUBSTR(TRIM(a.TrDate), 1, 4) || '-' || SUBSTR(TRIM(a.TrDate), 5, 2) || '-' || SUBSTR(TRIM(a.TrDate), 7, 2) AS TrDate ,
                        a.CardNo,
                        a.AppNo,
                        SUBSTR(TRIM(a.IpGumDate), 1, 4) || '-' || SUBSTR(TRIM(a.IpGumDate), 5, 2) || '-' || SUBSTR(TRIM(a.IpGumDate), 7, 2) AS IpGumDate ,
                        a.Amt,
                        a.CatID,
                        NVL(a.ACQ_CARD_CD, '') cardcompC

                 FROM   IBKDB_CSM_MS_TRAN a
                        LEFT JOIN IBKDB_ISS_BANK b ON a.ACQ_CARD_CD = b.BANK_CD
                        LEFT JOIN CMCOMMONM c ON c.cmmcode = 'AC17'
                                                 AND SUBSTR(a.ACQ_CARD_CD, -2, 2) = c.filter2
                        LEFT JOIN CMCOMMONM D ON c.hcmmcode = D.cmmcode
                                                 AND c.hdivcode = D.divcode
                 WHERE  a.TrDate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), -3), 'YYYYMMDD') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), 3), 'YYYYMMDD')
                        AND a.IpGumDate IS NOT NULL
                        AND (p_cardcomp = '%' OR a.ACQ_CARD_CD LIKE '%' || (SELECT divname
                                                                            FROM   CMCOMMONM
                                                                            WHERE  cmmcode = 'AC171'
                                                                                   AND divcode = p_cardcomp) || '%')
            )

            SELECT   a.cardno,
                     a.coldate,
                     a.colamt,
                     a.cardcomp,
                     a.cardokno,
                     a.custcode,
                     a.custname,
                     a.businessno,
                     b.TrDate,
                     b.Amt,
                     b.cardcompC,
                     b.AppNo,
                     b.IpGumDate,
                     b.CatID,
                     NVL(a.colamt, 0) - NVL(b.Amt, 0) diffamt,
                     a.autoyn
            FROM   TT_SLCOLM2 a
                     LEFT JOIN TT_CSM_MS_TRAN2 b
                         ON SUBSTR(REPLACE(a.cardno, '-', ''), 0, 8) = SUBSTR(REPLACE(b.CardNo, '-', ''), 0, 8)
                            AND SUBSTR(a.cardno, -LENGTH(b.CardNo) - 12, LENGTH(b.CardNo) - 12) = SUBSTR(b.CardNo, -LENGTH(b.CardNo) - 12, LENGTH(b.CardNo) - 12)
                            AND a.cardokno = b.AppNo
                            AND a.colamt = b.Amt
            ORDER BY a.cardno, a.coldate, a.cardokno;

        -- OPEN IO_CURSOR2 FOR --END

    ELSIF ( UPPER(p_div) = UPPER('S') AND UPPER(p_viewtype) = UPPER('3') ) THEN

        OPEN IO_CURSOR FOR --START

            WITH TT_SLCOLM3 AS
            (
                SELECT a.custcode,
                        D.custname,
                        D.businessno,
                        c.slipdate coldate,
                        a.colamt,
                        a.cardno,
                        a.cardokno,
                        E.divname cardcomp,
                        a.autoyn

                 FROM  SLCOLM a
                        JOIN ACAUTOORDT b ON b.compcode = p_compcode
                                             AND b.acattype = 'C'
                                             AND a.colno = b.acatno
                        JOIN ACORDM c ON b.compcode = c.compcode
                                         AND b.slipinno = c.slipinno
                        LEFT JOIN CMCUSTM D ON a.custcode = D.custcode
                        LEFT JOIN CMCOMMONM E ON E.cmmcode = 'AC17'
                                                 AND a.cardcomp = E.divcode
                        LEFT JOIN CMCOMMONM f ON E.hcmmcode = f.cmmcode
                                                 AND E.hdivcode = f.divcode
                 WHERE  c.slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), -3), 'YYYY-MM-DD') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), 3), 'YYYY-MM-DD')
                        AND a.coldiv = p_coldiv
                        AND NVL(f.divcode, ' ') LIKE p_cardcomp
            )
            , TT_CSM_MS_TRAN3 AS
            (
                SELECT  SUBSTR(TRIM(a.TrDate), 1, 4) || '-' || SUBSTR(TRIM(a.TrDate), 5, 2) || '-' || SUBSTR(TRIM(a.TrDate), 7, 2) AS TrDate ,
                        a.CardNo,
                        a.AppNo,
                        SUBSTR(TRIM(a.IpGumDate), 1, 4) || '-' || SUBSTR(TRIM(a.IpGumDate), 5, 2) || '-' || SUBSTR(TRIM(a.IpGumDate), 7, 2) AS IpGumDate ,
                        a.Amt,
                        a.CatID,
                        NVL(a.ACQ_CARD_CD, '') cardcompC

                 FROM  IBKDB_CSM_MS_TRAN a
                        LEFT JOIN IBKDB_ISS_BANK b ON a.ACQ_CARD_CD = b.BANK_CD
                        LEFT JOIN CMCOMMONM c ON c.cmmcode = 'AC17'
                                                 AND SUBSTR(a.ACQ_CARD_CD, -2, 2) = c.filter2
                        LEFT JOIN CMCOMMONM D ON c.hcmmcode = D.cmmcode
                                                 AND c.hdivcode = D.divcode

                 WHERE  a.TrDate BETWEEN REPLACE(p_strdate, '-', '') AND REPLACE(p_enddate, '-', '')
                        AND a.IpGumDate IS NOT NULL
                        AND (p_cardcomp = '%' OR a.ACQ_CARD_CD LIKE '%' || (SELECT divname
                                                                            FROM   CMCOMMONM
                                                                            WHERE  cmmcode = 'AC171'
                                                                                   AND divcode = p_cardcomp) || '%')
            )

            SELECT   NVL(b.custcode, '') custcode,
                     NVL(b.custname, '') custname,
                     NVL(b.businessno, '') businessno,
                     b.coldate,
                     b.colamt,
                     b.cardcomp,
                     b.cardno,
                     b.cardokno,
                     a.TrDate,
                     a.Amt,
                     a.cardcompC,
                     a.CardNo CardNoC,
                     a.AppNo,
                     a.IpGumDate,
                     a.CatID,
                     NVL(b.colamt, 0) - NVL(a.Amt, 0) diffamt,
                     b.autoyn
            FROM   tt_CSM_MS_TRAN3 a
                     LEFT JOIN tt_SLCOLM3 b ON SUBSTR(REPLACE(a.CardNo, '-', ''), 0, 8) = SUBSTR(REPLACE(b.cardno, '-', ''), 0, 8)
                                               AND SUBSTR(a.CardNo, -LENGTH(a.CardNo) - 12, LENGTH(a.CardNo) - 12) = SUBSTR(b.cardno, -LENGTH(a.CardNo) - 12, LENGTH(a.CardNo) - 12)
                                               AND a.AppNo = b.cardokno
                                               AND a.Amt = b.colamt
            ORDER BY businessno, a.TrDate, a.CardNo, a.AppNo;

        -- OPEN IO_CURSOR FOR --START



        OPEN IO_CURSOR2 FOR --START

            WITH TT_SLCOLM3 AS
            (
                SELECT a.custcode,
                        D.custname,
                        D.businessno,
                        c.slipdate coldate,
                        a.colamt,
                        a.cardno,
                        a.cardokno,
                        E.divname cardcomp,
                        a.autoyn

                 FROM    SLCOLM a
                        JOIN ACAUTOORDT b ON b.compcode = p_compcode
                                             AND b.acattype = 'C'
                                             AND a.colno = b.acatno
                        JOIN ACORDM c ON b.compcode = c.compcode
                                         AND b.slipinno = c.slipinno
                        LEFT JOIN CMCUSTM D ON a.custcode = D.custcode
                        LEFT JOIN CMCOMMONM E ON E.cmmcode = 'AC17'
                                                 AND a.cardcomp = E.divcode
                        LEFT JOIN CMCOMMONM f ON E.hcmmcode = f.cmmcode
                                                 AND E.hdivcode = f.divcode
                 WHERE    c.slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), -3), 'YYYY-MM-DD') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), 3), 'YYYY-MM-DD')
                        AND a.coldiv = p_coldiv
                        AND NVL(f.divcode, ' ') LIKE p_cardcomp
            )
            , TT_CSM_MS_TRAN3 AS
            (
                SELECT  SUBSTR(TRIM(a.TrDate), 1, 4) || '-' || SUBSTR(TRIM(a.TrDate), 5, 2) || '-' || SUBSTR(TRIM(a.TrDate), 7, 2) AS TrDate ,
                        a.CardNo,
                        a.AppNo,
                        SUBSTR(TRIM(a.IpGumDate), 1, 4) || '-' || SUBSTR(TRIM(a.IpGumDate), 5, 2) || '-' || SUBSTR(TRIM(a.IpGumDate), 7, 2) AS IpGumDate ,
                        a.Amt,
                        a.CatID,
                        NVL(a.ACQ_CARD_CD, '') cardcompC

                 FROM    IBKDB_CSM_MS_TRAN a
                        LEFT JOIN IBKDB_ISS_BANK b ON a.ACQ_CARD_CD = b.BANK_CD
                        LEFT JOIN CMCOMMONM c ON c.cmmcode = 'AC17'
                                                 AND SUBSTR(a.ACQ_CARD_CD, -2, 2) = c.filter2
                        LEFT JOIN CMCOMMONM D ON c.hcmmcode = D.cmmcode
                                                 AND c.hdivcode = D.divcode

                 WHERE    a.TrDate BETWEEN REPLACE(p_strdate, '-', '') AND REPLACE(p_enddate, '-', '')
                        AND a.IpGumDate IS NOT NULL
                        AND (p_cardcomp = '%' OR a.ACQ_CARD_CD LIKE '%' || (SELECT divname
                                                                            FROM   CMCOMMONM
                                                                            WHERE  cmmcode = 'AC171'
                                                                                   AND divcode = p_cardcomp) || '%')
            )

            SELECT   NVL(b.cardno, a.CardNo) cardno,
                     b.coldate,
                     b.colamt,
                     b.cardcomp,
                     b.cardokno,
                     b.custcode,
                     b.custname,
                     b.businessno,
                     a.TrDate,
                     a.Amt,
                     a.cardcompC,
                     a.AppNo,
                     a.IpGumDate,
                     a.CatID,
                     NVL(b.colamt, 0) - NVL(a.Amt, 0) diffamt,
                     b.autoyn

            FROM   tt_CSM_MS_TRAN3 a
                     LEFT JOIN tt_SLCOLM3 b ON SUBSTR(REPLACE(a.CardNo, '-', ''), 0, 8) = SUBSTR(REPLACE(b.cardno, '-', ''), 0, 8)
                                                AND SUBSTR(a.CardNo, -LENGTH(a.CardNo) - 12, LENGTH(a.CardNo) - 12) = SUBSTR(b.cardno, -LENGTH(a.CardNo) - 12, LENGTH(a.CardNo) - 12)
                                                AND a.AppNo = b.cardokno
                                                AND a.Amt = b.colamt

            ORDER BY SUBSTR(NVL(b.cardno, a.CardNo), 0, 8), SUBSTR(NVL(b.cardno, a.CardNo), -LENGTH(NVL(b.cardno, a.CardNo)) - 12, LENGTH(NVL(b.cardno, a.CardNo)) - 12), a.TrDate, a.AppNo;

        -- OPEN IO_CURSOR2 FOR --START

  END IF;



    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

    IF (IO_CURSOR2 IS NULL) THEN
        OPEN IO_CURSOR2 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
