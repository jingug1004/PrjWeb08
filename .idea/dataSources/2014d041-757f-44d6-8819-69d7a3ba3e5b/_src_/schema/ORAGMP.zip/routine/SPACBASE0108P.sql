CREATE PROCEDURE        spACbase0108P
    -- ---------------------------------------------------------------
    -- 프로시저명       : spACbase0108P
    -- 작 성 자         : 민승기
    -- 작성일자         : 2009-07-09
    -- 수 정 자     : 강현호
    -- E-Mail       : roykang0722@gmail.com
    -- 수정일자      : 2016-12-12
    -- ---------------------------------------------------------------
    -- 프로시저 설명    : 회계관리용 거래처마스터 테이블 (CMCUSTM)을 등록,수정,삭제,조회하는 프로시저이다.
    -- ---------------------------------------------------------------
(
    p_div             IN  VARCHAR2 DEFAULT '',

    p_plantcode       IN  VARCHAR2 DEFAULT '',
    p_custcode        IN  VARCHAR2 DEFAULT '',
    p_custname        IN  VARCHAR2 DEFAULT '',
    p_custsname       IN  VARCHAR2 DEFAULT '',
    p_custename       IN  VARCHAR2 DEFAULT '',
    p_custcondition   IN  VARCHAR2 DEFAULT '',
    p_custitem        IN  VARCHAR2 DEFAULT '',
    p_custdiv         IN  VARCHAR2 DEFAULT '',
    p_custbuydiv      IN  VARCHAR2 DEFAULT '',
    p_businessno      IN  VARCHAR2 DEFAULT '',
    p_ceoname         IN  VARCHAR2 DEFAULT '',
    p_ceono           IN  VARCHAR2 DEFAULT '',
    p_telno           IN  VARCHAR2 DEFAULT '',
    p_faxno           IN  VARCHAR2 DEFAULT '',
    p_custempname     IN  VARCHAR2 DEFAULT '',
    p_post            IN  VARCHAR2 DEFAULT '',
    p_addr1           IN  VARCHAR2 DEFAULT '',
    p_addr2           IN  VARCHAR2 DEFAULT '',
    p_addre           IN  VARCHAR2 DEFAULT '',
    p_stopdate        IN  VARCHAR2 DEFAULT '',
    p_paydiv          IN  VARCHAR2 DEFAULT '',
    p_bankcode        IN  VARCHAR2 DEFAULT '',
    p_accountno       IN  VARCHAR2 DEFAULT '',
    p_bankempname     IN  VARCHAR2 DEFAULT '',
    p_iempcode        IN  VARCHAR2 DEFAULT '',
    p_taxdiv          IN  VARCHAR2 DEFAULT '',
    p_vatrate         IN  FLOAT DEFAULT 0,

    p_userid          IN  VARCHAR2 DEFAULT '',
    p_reasondiv       IN  VARCHAR2 DEFAULT '',
    p_reasontext      IN  VARCHAR2 DEFAULT '',
    MESSAGE           OUT VARCHAR2,
    IO_CURSOR         OUT TYPES.DataSet
)
AS
    ip_custcode           VARCHAR2(20);
    ip_custLen            NUMBER(10, 0);
    p_cnt                 NUMBER(10, 0);
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';
    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF (UPPER(p_div) = UPPER('S')) THEN
        OPEN IO_CURSOR FOR
        SELECT  NVL(a.plantcode, '') plantcode,
                NVL(a.custcode, '') custcode,
                NVL(a.custname, '') custname,
                NVL(a.custsname, '') custsname,
                NVL(a.custename, '') custename,
                NVL(a.custcondition, '') custcondition,
                NVL(a.custitem, '') custitem,
                NVL(a.custdiv, '') custdiv,
                NVL(a.custbuydiv, '') custbuydiv,
                NVL(a.businessno, '') businessno,
                NVL(a.ceoname, '') ceoname,
                NVL(a.ceono, '') ceono,
                NVL(a.telno, '') telno,
                NVL(a.faxno, '') faxno,
                NVL(a.custempname, '') custempname,
                NVL(a.POST, '') POST,
                NVL(a.addr1, '') addr1,
                NVL(a.addr2, '') addr2,
                NVL(a.addre, '') addre,
                NVL(a.stopdate, '') stopdate,
                NVL(a.paydiv, '') paydiv,
                NVL(a.bankcode, '') bankcode,
                NVL(a.accountno, '') accountno,
                NVL(a.bankempname, '') bankempname,
                NVL(a.taxdiv, '') taxdiv,
                NVL(a.vatrate, 0) vatrate,
                --NULLIF(a.insertdt, '') insertdt,
                DECODE(a.insertdt, NULL, '', TO_CHAR(a.insertdt)),
                NVL(a.iempcode, '') iempcode,
                --NULLIF(a.updatedt, '') updatedt,
                DECODE(a.updatedt, NULL, '', TO_CHAR(a.updatedt)),
                NVL(a.uempcode, '') uempcode,
                NVL(b.divname, '') custdivname,
                NVL(c.divname, '') custbuydivname

        FROM    CMCUSTM a
                LEFT JOIN CMCOMMONM b ON a.custdiv = b.divcode
                                         AND b.cmmcode = 'CM11'     --거래처구분                                                                                                                                                                                                                                                 --거래처구분
                LEFT JOIN CMCOMMONM c ON a.custbuydiv = c.divcode
                                         AND c.cmmcode = 'CM12'        --매입거래처구분                                                                                                                                                                                                                                       --매입거래처구분
                LEFT JOIN CMCOMMONM D ON a.paydiv = D.divcode
                                         AND D.cmmcode = 'CM44'
                LEFT JOIN CMBANKM E ON a.plantcode = E.plantcode
                                       AND a.bankcode = E.bankcode

        WHERE    a.custdiv LIKE NVL(p_custdiv,'%') || '%'
                AND REPLACE(NVL(a.businessno,' '), '-', '') LIKE NVL(p_businessno,'%') || '%'
                AND ((a.custcode LIKE NVL(p_custcode,'%') || '%') OR (NVL(a.custname,' ') LIKE  '%' || NVL(p_custcode,'%') || '%'))

        ORDER BY a.custcode;

    -- 키중복체크
    ELSIF (UPPER(p_div) = UPPER('SC')) THEN

        FOR rec IN (SELECT COUNT(custcode) AS alias1
                    FROM   CMCUSTM a
                    WHERE  a.custcode = p_custcode)
        LOOP
            MESSAGE := rec.alias1;
        END LOOP;

    -- 키중복체크
    ELSIF (UPPER(p_div) = UPPER('SC1')) THEN
        FOR rec IN ( SELECT COUNT(custcode) AS alias1
                     FROM   CMCUSTM a
                     WHERE  a.businessno = p_businessno )
        LOOP
            MESSAGE := rec.alias1;
        END LOOP;

    -- 키생성
    ELSIF (UPPER(p_div) = UPPER('CC')) THEN
    declare
        p_custcodelen   int;
    begin
        ip_custcode := '0';
        ip_custlen := 7;

        for rec in (
            select  value1 as custcode,
                    to_number(value2) as custlen
            from    SYSPARAMETERMANAGE
            where   parametercode = 'gencustcodecrt')
        loop
            ip_custcode := case when p_custcode is null then rec.custcode else p_custcode end;
            ip_custlen := rec.custlen;
        end loop;

        p_custcodelen := case when ip_custcode is null then 0 else length(ip_custcode) end;

        if ip_custlen <= p_custcodelen then
            MESSAGE := p_custcode;
        else
            for rec in (
                select  upper(ip_custcode) || substr('00000000000000000000' || to_char(nvl(max(substr(custcode, p_custcodelen + 1, 20 - p_custcodelen)), 0) + 1), - nvl(ip_custlen - p_custcodelen, 7)) as custcode
                from    CMCUSTM
                where   custcode like ip_custcode || '%'
                        and isnumeric(substr(custcode, p_custcodelen + 1, 20 - p_custcodelen)) = 1
                        and length(custcode) = ip_custlen)
            loop
                MESSAGE := rec.custcode;
            end loop;
        end if;
    end;

    ELSIF (UPPER(p_div) = UPPER('I')) THEN

        INSERT INTO CMCUSTM(plantcode,
                            custcode,
                            custoldcode,
                            custmajorcode,
                            custname,
                            custsname,
                            custename,
                            custcondition,
                            custitem,
                            custdiv,
                            custbuydiv,
                            businessno,
                            corporationno,
                            medicalcode,
                            ceoname,
                            ceono,
                            telno,
                            faxno,
                            licenseno,
                            custempname,
                            email,
                            domain,
                            POST,
                            addr1,
                            addr2,
                            addre,
                            opendate,
                            stopdate,
                            openbuydate,
                            stopbuydate,
                            deptcode,
                            empcode,
                            utdiv,
                            custclass,
                            taxdiv,
                            credityn,
                            sagodiv,
                            holddiv,
                            lastsaldate,
                            lastcoldate,
                            bondmovedate,
                            turncnt,
                            turndccnt,
                            creditlmt,
                            balancelmt,
                            nocollmt,
                            securitylmt,
                            avgamt,
                            salamtlmt,
                            turnlmt,
                            useyn,
                            prceditdiv,
                            giveditdiv,
                            paydiv,
                            drivingterm,
                            vatyn,
                            vatrate,
                            woncalcdiv,
                            countrycode,
                            moneycode,
                            bankcode,
                            accountno,
                            bankempname,
                            memo1,
                            memo2,
                            insertdt,
                            iempcode,
                            mediyn,
                            custemptel,
                            areadiv,
                            hinoutdiv   )
        VALUES        (p_plantcode,
                    p_custcode,
                    '',
                    p_custcode,
                    p_custname,
                    p_custsname,
                    p_custename,
                    p_custcondition,
                    p_custitem,
                    p_custdiv,
                    p_custbuydiv,
                    p_businessno,
                    '',
                    '',
                    p_ceoname,
                    p_ceono,
                    p_telno,
                    p_faxno,
                    '',
                    p_custempname,
                    '',
                    '',
                    p_post,
                    p_addr1,
                    p_addr2,
                    p_addre,
                    '',
                    p_stopdate,
                    '',
                    '',
                    '',
                    '',
                    '',
                    '',
                    p_taxdiv,
                    'N',
                    '',
                    '',
                    '',
                    '',
                    '',
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    0,
                    'N',
                    '',
                    '',
                    p_paydiv,
                    '',
                    'N',
                    p_vatrate,
                    '',
                    '',
                    '',
                    p_bankcode,
                    p_accountno,
                    p_bankempname,
                    '',
                    '',
                    SYSDATE,
                    p_iempcode,
                    'N',
                    '',
                    '',
                    '' );

    ELSIF (UPPER(p_div) = UPPER('U')) THEN

        UPDATE CMCUSTM a
        SET    custname = p_custname,
               custsname = p_custsname,
               custename = p_custename,
               custcondition = p_custcondition,
               custitem = p_custitem,
               custdiv = p_custdiv,
               custbuydiv = p_custbuydiv,
               businessno = p_businessno,
               ceoname = p_ceoname,
               ceono = p_ceono,
               telno = p_telno,
               faxno = p_faxno,
               custempname = p_custempname,
               POST = p_post,
               addr1 = p_addr1,
               addr2 = p_addr2,
               addre = p_addre,
               stopdate = p_stopdate,
               paydiv = p_paydiv,
               bankcode = p_bankcode,
               accountno = p_accountno,
               bankempname = p_bankempname,
               taxdiv = p_taxdiv,
               vatrate = p_vatrate,
               updatedt = SYSDATE,
               uempcode = p_iempcode
        WHERE  custcode = p_custcode;

    ELSIF (UPPER(p_div) = UPPER('D')) THEN

        DELETE CMCUSTM
        WHERE  custcode = p_custcode;

    ELSIF (UPPER(p_div) = UPPER('GB')) THEN

        p_cnt := 0;

        FOR rec IN (SELECT COUNT(*) AS alias1
                    FROM   CMCUSTM a
                    WHERE  a.custcode = p_custcode)
        LOOP
            p_cnt := rec.alias1;
        END LOOP;

        IF (NVL(p_cnt, 0) > 0) THEN
            MESSAGE := '';
        END IF;

    ELSIF (UPPER(p_div) = UPPER('SD')) THEN

        p_cnt := 0;

        FOR rec IN (    SELECT  COUNT(custcode) alias1
                        FROM(   SELECT plantcode, custcode FROM ACBILLM
                                UNION
                                SELECT plantcode, custcode FROM CMBANKM
                                UNION
                                SELECT plantcode, custcode FROM ACBONDM
                                UNION
                                SELECT plantcode, custcode FROM SLORDM
                                UNION
                                SELECT plantcode, custcode FROM SLCOLM  ) a
                        WHERE  custcode = p_custcode    )
        LOOP
            p_cnt := rec.alias1;
        END LOOP;

        IF (NVL(p_cnt, 0) > 0) THEN

            -- Carriage RETURN  CHR(13)
            -- Line feed       CHR(10)
            MESSAGE := '거래처코드가 시스템에서 사용중입니다.' || CHR(13) || CHR(10) || '수정 및 삭제가 제한됩니다.';
        ELSE
            MESSAGE := '';
        END IF;

    ELSIF (UPPER(p_div) = UPPER('NCODE')) THEN
        OPEN IO_CURSOR FOR
        SELECT  SUBSTR('000000000' || TO_CHAR((NVL(MAX(custcode), 0) + 1)), -7) as maxcust
        FROM    CMCUSTM
        WHERE   custcode LIKE NVL(p_custcode,'%') || '%';

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
