CREATE FUNCTION fnNextWorkingDate(
	-- ---------------------------------------------------------------
    -- 함 수 명   : fnNextWorkingDate
    -- 작 성 자         : 민승기
    -- 작성일자         : 2007-11-01
    -- 수정일자      :   노영래
	-- E-mail      :   0rae0926@gmail.com
	-- 수정일자      :   2016-01-11
    -- ---------------------------------------------------------------
    -- 함수설명   : 다음 근무일 계산
    -- ---------------------------------------------------------------

	p_daycnt 		IN 		NUMBER 	DEFAULT 0,
    ip_basedate 	IN 		DATE 	DEFAULT NULL
)
	RETURN DATE
AS
	p_basedate	 DATE := ip_basedate;
	p_todate	 DATE;
	p_rowcnt	 NUMBER(10, 0);
BEGIN
	p_basedate := NVL(p_basedate, TO_DATE(TO_CHAR(SYSDATE,'YYYY-MM-DD'),'YYYY-MM-DD'));

	FOR rec IN (SELECT MAX(a.calymd) AS alias1, COUNT(*) - 1 AS alias2
				FROM   (SELECT *
						FROM   (SELECT	 calymd
					      FROM   PSCALM
                WHERE   NVL(plantcode,' ') = NVL((SELECT MIN(plantcode) FROM CMPLANTM), ' ')
                     AND calymd BETWEEN TO_CHAR(p_basedate, 'YYYY-MM-DD') AND TO_CHAR(p_basedate + ABS(p_daycnt),'YYYY-MM-DD')
                     AND caldiv = '01'
                ORDER BY calymd ASC)
            WHERE  ROWNUM <= ABS(NVL(p_daycnt, 0)) + 1) a)
  LOOP
    p_todate := TO_DATE(rec.alias1,'YYYY-MM-DD');
    p_rowcnt := rec.alias2;
  END LOOP;

  IF (p_rowcnt <> p_daycnt)
  THEN
        p_todate := p_basedate + ABS(p_daycnt);
  END IF;

  RETURN (p_todate);
EXCEPTION
  WHEN OTHERS
  THEN RETURN NULL;
END;
/
