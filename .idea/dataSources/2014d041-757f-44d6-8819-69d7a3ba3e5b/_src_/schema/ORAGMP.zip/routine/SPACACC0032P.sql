CREATE PROCEDURE spACacc0032P
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0032P
	-- 작 성 자         : 최용석
	-- 작성일자         : 2014-05-08
	-- 수 정 자     : 강현호
	-- E-Mail       : roykang0722@gmail.com
	-- 수정일자      : 2016-12-13
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 기업은행 S-ERP 엑셀자료를 업로드하는 프로시저이다.
	-- ---------------------------------------------------------------
(
    p_div			 IN 	VARCHAR2 DEFAULT '',
    p_strdate1		 IN 	VARCHAR2 DEFAULT '',
    p_enddate1		 IN 	VARCHAR2 DEFAULT '',
    p_strdate2		 IN 	VARCHAR2 DEFAULT '',
    p_enddate2		 IN 	VARCHAR2 DEFAULT '',
    p_strdate3		 IN 	VARCHAR2 DEFAULT '',
    p_enddate3		 IN 	VARCHAR2 DEFAULT '',
    p_acct_txday	 IN 	VARCHAR2 DEFAULT '',
    p_acct_txtime	 IN 	VARCHAR2 DEFAULT '',
    p_bank_cd		 IN 	VARCHAR2 DEFAULT '',
    p_acct_no		 IN 	VARCHAR2 DEFAULT '',
    p_jeokyo		 IN 	VARCHAR2 DEFAULT '',
    p_in_amt		 IN 	FLOAT    DEFAULT 0,
    p_out_amt		 IN 	FLOAT    DEFAULT 0,
    p_rm_amt		 IN 	FLOAT    DEFAULT 0,
    p_branch		 IN 	VARCHAR2 DEFAULT '',
    p_girocode		 IN 	VARCHAR2 DEFAULT '',
    p_bigo			 IN 	VARCHAR2 DEFAULT '',
    p_TrDate		 IN 	VARCHAR2 DEFAULT '',
    p_AcqDate		 IN 	VARCHAR2 DEFAULT '',
    p_AppNo 		 IN 	VARCHAR2 DEFAULT '',
    p_ACQ_CARD_CD	 IN 	VARCHAR2 DEFAULT '',
    p_CardNo		 IN 	VARCHAR2 DEFAULT '',
    p_TrCode		 IN 	VARCHAR2 DEFAULT '',
    p_Amt			 IN 	FLOAT    DEFAULT 0,
    p_Tip			 IN 	FLOAT    DEFAULT 0,
    p_IpGumDate 	 IN 	VARCHAR2 DEFAULT '',
    p_card_no		 IN 	VARCHAR2 DEFAULT '',
    p_appr_date 	 IN 	VARCHAR2 DEFAULT '',
    p_appr_time	     IN 	VARCHAR2 DEFAULT '',
    p_chain_nm		 IN 	VARCHAR2 DEFAULT '',
    p_chain_id		 IN 	VARCHAR2 DEFAULT '',
    p_appr_amt		 IN 	FLOAT    DEFAULT 0,
    p_card_dept 	 IN 	VARCHAR2 DEFAULT '',
    p_use_cd		 IN 	VARCHAR2 DEFAULT '',
    p_userid		 IN 	VARCHAR2 DEFAULT '',
    p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
    p_reasontext	 IN 	VARCHAR2 DEFAULT '',

    MESSAGE          OUT    VARCHAR2,
    IO_CURSOR        OUT    TYPES.DataSet,
    IO_CURSOR2		 OUT    TYPES.DataSet,
    IO_CURSOR3		 OUT    TYPES.DataSet
)
AS
	ip_appr_time        VARCHAR2(8) := p_appr_time;
    p_acct_txday_seq    NUMBER(10, 0);
    v_temp              NUMBER(1, 0) := 0;

BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF UPPER(p_div) = UPPER('S') OR UPPER(p_div) = UPPER('S1') THEN

        OPEN IO_CURSOR FOR

            SELECT	 SUBSTR(TRIM(a.acct_txday), 1, 4) || '-' || SUBSTR(TRIM(a.acct_txday), 5, 2) || '-' || SUBSTR(TRIM(a.acct_txday), 7, 2) AS acct_txday ,  -- 거래일자
                     SUBSTR(TRIM(a.acct_txtime), 1, 2) || ':' || SUBSTR(TRIM(a.acct_txtime), 3, 2) || ':' || SUBSTR(TRIM(a.acct_txtime), 5, 2) AS acct_txtime ,		-- 거래시간
                     RTRIM(a.BANK_CD) BANK_CD,																-- 은행명
                     RTRIM(a.ACCT_NO) ACCT_NO,																-- 계좌번호
                     RTRIM(a.JEOKYO) JEOKYO,																-- 적요
                     CASE WHEN a.INOUT_GUBUN = '2' THEN tx_amt END in_amt,									-- 입금액
                     CASE WHEN a.INOUT_GUBUN = '1' THEN tx_amt END out_amt									-- 출금액
            FROM	 IBKDB_ISS_ACCT_HIS a
            WHERE	 a.ACCT_TXDAY BETWEEN REPLACE(p_strdate1, '-', '') AND REPLACE(p_enddate1, '-', '')
            ORDER BY a.ACCT_NO, a.ACCT_TXDAY, a.ACCT_TXTIME;

	END IF;



	IF UPPER(p_div) = UPPER('S') OR UPPER(p_div) = UPPER('S2') THEN

        OPEN IO_CURSOR2 FOR

            SELECT	 a.BANK_CD, 																					-- 카드사
                     SUBSTR(TRIM(a.card_no), 1, 4) || '-' || SUBSTR(TRIM(a.card_no), 5, 4) || '-' || SUBSTR(TRIM(a.card_no), 9, 4) || '-' || SUBSTR(TRIM(a.card_no), 13, 4) AS card_no ,-- 카드번호
                     SUBSTR(TRIM(a.appr_date), 1, 4) || '-' || SUBSTR(TRIM(a.appr_date), 5, 2) || '-' || SUBSTR(TRIM(a.appr_date), 7, 2) AS appr_date ,  -- 승인일자
                     SUBSTR(TRIM(a.appr_time), 1, 2) || ':' || SUBSTR(TRIM(a.appr_time), 3, 2) || ':' || SUBSTR(TRIM(a.appr_time), 5, 2) AS appr_time , -- 승인시간
                     RTRIM(a.CHAIN_NM) CHAIN_NM,																	-- 가맹점
                     SUBSTR(TRIM(a.chain_id), 1, 3) || '-' || SUBSTR(TRIM(a.chain_id), 4, 2) || '-' || SUBSTR(TRIM(a.chain_id), 6, 5) AS chain_id , -- 가맹점사업자번호
                     a.APPR_AMT,																					-- 승인금액
                     RTRIM(a.BIGO) BIGO,																			-- 비고
                     RTRIM(a.CARD_DEPT) CARD_DEPT,																	-- 카드별칭
                     RTRIM(a.USE_CD) USE_CD 																		-- 사용구분
            FROM	 IBKDB_CCM_APPR a
            WHERE	 a.APPR_DATE BETWEEN REPLACE(p_strdate2, '-', '') AND REPLACE(p_enddate2, '-', '')
            ORDER BY a.CARD_NO, a.APPR_DATE, a.APPR_TIME;
	END IF;



	IF UPPER(p_div) = UPPER('S') OR UPPER(p_div) = UPPER('S3') THEN

        OPEN IO_CURSOR3 FOR

            SELECT	 SUBSTR(TRIM(a.TrDate), 1, 4) || '-' || SUBSTR(TRIM(a.TrDate), 5, 2) || '-' || SUBSTR(TRIM(a.TrDate), 7, 2) AS TrDate ,  -- 거래일자
                     RTRIM(a.AppNo) AppNo,																			-- 승인번호
                     RTRIM(a.ACQ_CARD_CD) ACQ_CARD_CD,																-- 카드사
                     RTRIM(a.CardNo) CardNo,																		-- 카드번호
                     RTRIM(a.TrCode) TrCode,																		-- 카드종류
                     a.Amt, 																						-- 매입금액
                     a.Tip, 																						-- 수수료
                     a.Amt - a.Tip InAmt,																			-- 지급액
                     SUBSTR(TRIM(a.IpGumDate), 1, 4) || '-' || SUBSTR(TRIM(a.IpGumDate), 5, 2) || '-' || SUBSTR(TRIM(a.IpGumDate), 7, 2) AS IpGumDate  -- 입금일자

            FROM	 IBKDB_CSM_MS_TRAN a
            WHERE	 a.TrDate BETWEEN REPLACE(p_strdate3, '-', '') AND REPLACE(p_enddate3, '-', '')
            ORDER BY a.TrDate, a.AppNo, a.CardNo;

	ELSIF UPPER(p_div) = UPPER('I1') THEN

        p_acct_txday_seq := 1;

        FOR rec IN (SELECT NVL(MAX(acct_txday_seq) + 1, 1) AS alias1
                    FROM   IBKDB_ISS_ACCT_HIS
                    WHERE  acct_no = p_acct_no
                           AND acct_txday = REPLACE(p_acct_txday, '-', ''))
        LOOP
            p_acct_txday_seq := rec.alias1;
        END LOOP;

        INSERT INTO IBKDB_ISS_ACCT_HIS(acct_txday,
                                       acct_txday_seq,
                                       acct_txtime,
                                       bank_cd,
                                       acct_no,
                                       jeokyo,
                                       inout_gubun,
                                       tx_amt,
                                       tx_cur_bal,
                                       branch,
                                       girocode,
                                       bigo)
            (SELECT REPLACE(p_acct_txday, '-', ''),
                    p_acct_txday_seq,
                    REPLACE(p_acct_txtime, ':', ''),
                    p_bank_cd,
                    p_acct_no,
                    p_jeokyo,
                    CASE WHEN p_in_amt = 0 THEN '1' ELSE '2' END col,
                    p_in_amt + p_out_amt,
                    p_rm_amt,
                    p_branch,
                    p_girocode,
                    p_bigo
             FROM	DUAL);

    ELSIF UPPER(p_div) = UPPER('D1') THEN

        DELETE IBKDB_ISS_ACCT_HIS
        WHERE  acct_txday BETWEEN REPLACE(p_strdate1, '-', '') AND REPLACE(p_enddate1, '-', '');

    ELSIF UPPER(p_div) = UPPER('I2') THEN

        FOR rec IN (    SELECT 1 AS alias1
                        FROM   DUAL
                        WHERE  EXISTS
                                   (SELECT *
                                    FROM   IBKDB_CCM_APPR
                                    WHERE  card_no = REPLACE(p_card_no, '-', '')
                                           AND appr_date = REPLACE(p_appr_date, '-', '')
                                           AND appr_time = REPLACE(ip_appr_time, ':', '')
                                           AND appr_amt = p_appr_amt)
        )
        LOOP
            v_temp := rec.alias1 ;
        END LOOP;


        IF v_temp = 1 THEN
            RETURN;
        END IF;


        FOR rec IN (    SELECT 1 AS alias1
                        FROM   DUAL
                        WHERE  EXISTS
                                   (SELECT *
                                    FROM   IBKDB_CCM_APPR
                                    WHERE  card_no = REPLACE(p_card_no, '-', '')
                                           AND appr_date = REPLACE(p_appr_date, '-', '')
                                           AND appr_time = REPLACE(ip_appr_time, ':', '')
                                           AND appr_amt <> p_appr_amt )
        )
        LOOP

            v_temp := rec.alias1 ;

        END LOOP;


        IF v_temp = 1 THEN
            ip_appr_time := TO_CHAR(TO_DATE(p_appr_date || ' ' || ip_appr_time, 'YYYY-MM-DD hh24:mi:ss') - 1/24/60/60, 'hh24:mi:ss');
        END IF;


        INSERT INTO IBKDB_CCM_APPR(bank_cd,
                                   card_no,
                                   appr_date,
                                   appr_time,
                                   appr_no,
                                   chain_nm,
                                   chain_id,
                                   appr_amt,
                                   bigo,
                                   card_dept,
                                   use_cd)
            (SELECT p_bank_cd,
                    REPLACE(p_card_no, '-', ''),
                    REPLACE(p_appr_date, '-', ''),
                    REPLACE(ip_appr_time, ':', ''),
                    REPLACE(ip_appr_time, ':', ''),
                    p_chain_nm,
                    REPLACE(p_chain_id, '-', ''),
                    p_appr_amt,
                    p_bigo,
                    p_card_dept,
                    p_use_cd
             FROM	DUAL);



    ELSIF UPPER(p_div) = UPPER('D2') THEN

        DELETE IBKDB_CCM_APPR
        WHERE  appr_date BETWEEN REPLACE(p_strdate2, '-', '') AND REPLACE(p_enddate2, '-', '');


    ELSIF UPPER(p_div) = UPPER('I3') THEN

        INSERT INTO IBKDB_CSM_MS_TRAN(TrDate,
                                      AcqDate,
                                      AppNo,
                                      ACQ_CARD_CD,
                                      CardNo,
                                      TrCode,
                                      Amt,
                                      Tip,
                                      IpGumDate)
            (SELECT REPLACE(p_TrDate, '-', ''),
                    REPLACE(p_AcqDate, '-', ''),
                    p_AppNo,
                    p_ACQ_CARD_CD,
                    p_CardNo,
                    p_TrCode,
                    p_Amt,
                    p_Tip,
                    REPLACE(p_IpGumDate, '-', '')
             FROM	DUAL);

    ELSIF UPPER(p_div) = UPPER('D3') THEN

        DELETE IBKDB_CSM_MS_TRAN
        WHERE  TrDate BETWEEN REPLACE(p_strdate3, '-', '') AND REPLACE(p_enddate3, '-', '');

	END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

    IF (IO_CURSOR2 IS NULL) THEN
        OPEN IO_CURSOR2 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

    IF (IO_CURSOR3 IS NULL) THEN
        OPEN IO_CURSOR3 FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
