CREATE PROCEDURE spACacc0034P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0034P
 -- 작 성 자         : 최용석
 -- 작성일자         : 2014-06-02
 -- 수정자          : 임정호
 -- 작성일자         : 2016-12-20
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 엑셀자료를 회계전표로 업로드하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '' ,

    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_slipinno      IN  VARCHAR2 DEFAULT '' ,
    p_slipinseq     IN  NUMBER   DEFAULT 0 ,
    p_slipdate      IN  VARCHAR2 DEFAULT '' ,
    p_dcdiv         IN  VARCHAR2 DEFAULT '' ,
    p_acccode       IN  VARCHAR2 DEFAULT '' ,
    p_custcode      IN  VARCHAR2 DEFAULT '' ,
    p_custname      IN  VARCHAR2 DEFAULT '' ,
    p_remark        IN  VARCHAR2 DEFAULT '' ,
    p_debamt        IN  FLOAT    DEFAULT 0 ,
    p_creamt        IN  FLOAT    DEFAULT 0 ,
    p_empcode       IN  VARCHAR2 DEFAULT '' ,

    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    IO_CURSOR       OUT TYPES.DataSet,
    MESSAGE         OUT VARCHAR2
)
AS
    ip_acccode VARCHAR2(20) := p_acccode;

BEGIN

    MESSAGE := '데이터 확인' ;

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values(p_userid, p_reasondiv, p_reasontext);

    if p_div = 'SA' then
        open IO_CURSOR for
        select  acccode, altcode, accname
        from    ACACCM
        where   orduseyn = 'Y'
        order by acccode;

    elsif p_div = 'SC' then
        open IO_CURSOR for
        select  custcode, custname
        from    CMCUSTM
        where   stopdate is null
        order by custcode;

    elsif p_div = 'SM' then
        open IO_CURSOR for
        select  '2017' as year
                ,'12' as month
                ,'12' as day
                ,1 as seq
                ,'차변' as dcdiv
                ,'11108010' as acccode
                ,'외상매출금' as accname
                ,'200839' as custcode
                ,'조용길의원' as custname
                ,'이베자정300mg 외' as remark
                ,122023440 as debamt
                ,0 as creamt
        from    DUAL
        union all
        select  '2017' as year
                ,'12' as month
                ,'12' as day
                ,1 as seq
                ,'대변' as dcdiv
                ,'71040000' as acccode
                ,'제품매출액' as accname
                ,'200839' as custcode
                ,'조용길의원' as custname
                ,'이베자정300mg 외' as remark
                ,0 as debamt
                ,110930400 as creamt
        from    DUAL
        union all
        select  '2017' as year
                ,'12' as month
                ,'12' as day
                ,1 as seq
                ,'대변' as dcdiv
                ,'21050000' as acccode
                ,'부가세예수금' as accname
                ,'200839' as custcode
                ,'조용길의원' as custname
                ,'이베자정300mg 외' as remark
                ,0 as debamt
                ,11093040 as creamt
        from    DUAL
        union all
        select  '2017' as year
                ,'12' as month
                ,'12' as day
                ,2 as seq
                ,'입금' as dcdiv
                ,'11108010' as acccode
                ,'외상매출금' as accname
                ,'200839' as custcode
                ,'조용길의원' as custname
                ,'이베자정300mg 외' as remark
                ,0 as debamt
                ,122023440 as creamt
        from    DUAL
        union all
        select  '2017' as year
                ,'12' as month
                ,'12' as day
                ,3 as seq
                ,'출금' as dcdiv
                ,'73110000' as acccode
                ,'복리후생비(판관)' as accname
                ,'' as custcode
                ,'충남식당' as custname
                ,'홍길동외 3명 중식' as remark
                ,21000 as debamt
                ,0 as creamt
        from    DUAL;

    elsif p_div = 'I' then
        for rec in (
            select  acccode
            from    ACACCM
            where   acccode = ip_acccode
                    or altcode = ip_acccode)
        loop
            ip_acccode := rec.acccode;
        end loop;

        insert into ACORDD
            (
                compcode,
                slipinno,
                slipinseq,
                dcdiv,
                acccode,
                plantcode,
                debamt,
                creamt,
                slipdate,
                slipnum,
                remark1,
                remark2,
                taxno,
                datadiv,
                rptseq,
                insertdt,
                iempcode
            )
        select  compcode,
                slipinno,
                p_slipinseq,
                decode(p_dcdiv, '차변','1', '대변','2', '입금','3', '4'),
                ip_acccode,
                plantcode,
                p_debamt,
                p_creamt,
                slipdate,
                slipnum,
                p_remark,
                null,
                null,
                null,
                p_slipinseq,
                sysdate,
                p_empcode
        from    ACORDM
        where   compcode = p_compcode
                and slipinno = p_slipinno;

        insert into ACORDS
            (
                compcode,
                slipinno,
                slipinseq,
                mngclucode,
                seq,
                mngcluval,
                mngcludec,
                insertdt,
                iempcode
            )
        select  a.compcode,
                a.slipinno,
                p_slipinseq,
                b.mngclucode,
                row_number() over(order by b.seq),
                case b.mngclucode when 'S010' then p_custcode
                                  when 'S040' then d.deptcode
                                  when 'S050' then c.empcode
                                  end,
                case b.mngclucode when 'S010' then p_custname
                                  when 'S040' then d.deptname
                                  when 'S050' then c.empname
                                  end,
                sysdate,
                p_empcode
        from    ACORDM a
                left join ACACCMNGM b
                    on b.acccode = ip_acccode
                    and b.dcdiv = case when p_dcdiv in ('차변', '출금') then '1' else '2' end
                left join CMEMPM c
                    on c.empcode = p_empcode
                left join CMDEPTM d
                    on c.deptcode = d.deptcode
        where   a.compcode = p_compcode
                and a.slipinno = p_slipinno;

        MESSAGE := p_slipinseq + 1;

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;
END;
/
