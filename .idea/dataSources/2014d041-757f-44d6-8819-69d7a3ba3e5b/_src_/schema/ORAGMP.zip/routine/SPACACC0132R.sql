CREATE PROCEDURE spACacc0132R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0132R
	-- 작 성 자         : 배종성
	-- 작성일자         : 2010-12-21
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-20
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 법인카드사용내역서 조회하는 프로시저이다.
	-- 수정 : 2011-02-08 : 카드 사용자를 카드마스터의 주 사용자로 변경
	-- -------------------------------------------------------------
(
	p_div			   IN	  VARCHAR2 DEFAULT '',
	p_compcode		   IN	  VARCHAR2 DEFAULT '',
	p_plantcode 	   IN	  VARCHAR2 DEFAULT '',
	p_startdt		   IN	  VARCHAR2 DEFAULT '',
	p_enddt 		   IN	  VARCHAR2 DEFAULT '',
	p_paymonth		   IN	  VARCHAR2 DEFAULT '',
	p_btedeptcodeS1    IN	  VARCHAR2 DEFAULT '',
	p_btedeptcodeS2    IN	  VARCHAR2 DEFAULT '',
	p_cardno		   IN	  VARCHAR2 DEFAULT '',
	p_outputdiv 	   IN	  NUMBER   DEFAULT 0,
	p_slipinstate	   IN	  VARCHAR2 DEFAULT '',
	p_userid		   IN	  VARCHAR2 DEFAULT '',
	p_reasondiv 	   IN	  VARCHAR2 DEFAULT '',
	p_reasontext	   IN	  VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT    VARCHAR2,
	IO_CURSOR		   OUT    TYPES.DATASET
)
AS
	p_odiv1 	  VARCHAR2(5);
	p_odiv2 	  VARCHAR2(5);
	p_cardno1	  VARCHAR2(30) := '';
	p_apprday1	  VARCHAR2(2)  := '';
    p_order       NUMBER := 0;
    p_fcheck      NUMBER := 0;

BEGIN
	MESSAGE := '데이터 확인';


    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);
    IF (p_outputdiv = '1') THEN
		--K-GAAP
		p_odiv1 := '20';
		p_odiv2 := 'F';
	END IF;

	IF (p_outputdiv = '2') THEN
		--IFRS
		p_odiv1 := '30';
		p_odiv2 := 'K';
	END IF;




	IF ( UPPER(p_div) = UPPER('S') ) THEN

        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0132R_ACACC0132RBASE ';

		-- 결제 일자, 카드번호, 카드사용자, 사용일자, 전표번호, 계정과목, 금액, 적요
		INSERT INTO VGT.TT_ACACC0132R_ACACC0132RBASE

			SELECT	 apprday,
					 cardno,
					 cardcomp,
					 a.empcode,
					 b.empname,
					 slipdate,
					 a.slipnum,
					 a.acccode,
					 accname,
					 a.fnamt,
					 a.remark
			FROM	 (
                        SELECT   f.apprday apprday,
                                 f.cardno cardno,
                                 f.cardcustom cardcomp,
                                 f.empcode empcode,
                                 CASE WHEN p_slipinstate = '4' THEN a.slipdate ELSE D.slipindate END slipdate,
                                 CASE WHEN p_slipinstate = '4' THEN a.slipnum ELSE D.slipinnum END slipnum,
                                 a.acccode,
                                 a.creamt fnamt,
                                 a.remark1 remark
                        FROM	 ACORDD a
                                 JOIN ACORDS b ON a.compcode = b.compcode
                                                  AND a.slipinno = b.slipinno
                                                  AND a.slipinseq = b.slipinseq
                                                  AND b.mngclucode = 'S060'
                                 JOIN ACORDM D ON b.slipinno = D.slipinno -- 사용자
                                                  AND NVL(D.slipdiv,'') <> NVL(p_odiv2,'')
                                 JOIN ACCARDM f ON b.mngcluval = f.cardno
                                                   AND NVL(REPLACE(f.cardno, '-', ''), '') LIKE '%' || p_cardno || '%'
                                 LEFT JOIN CMCOMMONM G ON G.cmmcode = 'AC17'
                                                          AND f.cardcls = G.divcode
                        WHERE   a.compcode = p_compcode
                                 AND a.plantcode LIKE p_plantcode
                                 AND (p_slipinstate = '4'  AND a.slipdate   BETWEEN p_startdt AND p_enddt OR
                                      p_slipinstate <> '4' AND D.slipindate BETWEEN p_startdt AND p_enddt )
                                 AND D.slipinstate LIKE p_slipinstate
                                 AND a.creamt <> 0
                                 AND (NVL(p_btedeptcodeS1, ' ') > ' ' AND D.deptcode >= p_btedeptcodeS1 OR
                                      TRIM(p_btedeptcodeS1) IS NULL )
                                 AND (NVL(p_btedeptcodeS2, '') > ' ' AND D.deptcode <= p_btedeptcodeS2 OR
                                      TRIM(p_btedeptcodeS2) IS NULL )
                                 AND (NVL(p_paymonth, '') > ' ' AND f.apprday = p_paymonth OR
                                      TRIM(p_paymonth) IS NULL )
                    ) a
					 LEFT JOIN CMEMPM b ON a.empcode = b.empcode
					 LEFT JOIN ACACCM c ON a.acccode = c.acccode ;



		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0132R_DUAL ';

		FOR REC IN(
                    SELECT apprday,
                           cardno,
                           cardcomp,
                           empcode,
                           empname,
                           slipdate,
                           slipnum,
                           acccode,
                           accname,
                           fnamt,
                           remark
                    FROM   VGT.TT_ACACC0132R_ACACC0132RBASE
                    ORDER BY apprday, cardno, slipdate
        )
        LOOP

            IF p_fcheck = 0 THEN
                p_fcheck := 1;
            ELSE

                IF ( (p_cardno1 <> REC.cardno) ) THEN

                    INSERT INTO VGT.TT_ACACC0132R_DUAL (
                        SELECT  '' apprday,
                                '카드번호별 계' cardno,
                                '' cardcomp,
                                '' empcode,
                                '' empname,
                                '' slipdate,
                                '' slipnum,
                                '' acccode,
                                '' accname,
                                SUM(fnamt) fnamt,
                                '' remark,
                                p_order
                        FROM    VGT.TT_ACACC0132R_DUAL
                        WHERE   TRIM(cardno) = TRIM(p_cardno1)
                    );

                    p_order := p_order + 1;

                END IF;

                IF ( p_apprday1 <> REC.apprday  ) THEN

                    INSERT INTO VGT.TT_ACACC0132R_DUAL (

                        SELECT  MAX(apprday) apprday,
                                '결제일자별 계' cardno,
                                '' cardcomp,
                                '' empcode,
                                '' empname,
                                '' slipdate,
                                '' slipnum,
                                '' acccode,
                                '' accname,
                                SUM(fnamt) fnamt,
                                '' remark,
                                p_order
                         FROM   VGT.TT_ACACC0132R_DUAL
                         WHERE  TRIM(apprday) = TRIM(p_apprday1)
                    );

                    p_order := p_order + 1;

                END IF;

            END IF;


            INSERT INTO VGT.TT_ACACC0132R_DUAL
            VALUES (
                REC.apprday,
                REC.cardno,
                REC.cardcomp,
                REC.empcode,
                REC.empname,
                REC.slipdate,
                REC.slipnum,
                REC.acccode,
                REC.accname,
                REC.fnamt,
                REC.remark
                , p_order
            );
            p_order := p_order + 1;

            p_cardno1 := REC.cardno;
            p_apprday1 := REC.apprday;

        END LOOP;


        INSERT INTO VGT.TT_ACACC0132R_DUAL (
            SELECT  '' apprday,
                    '카드번호별 계' cardno,
                    '' cardcomp,
                    '' empcode,
                    '' empname,
                    '' slipdate,
                    '' slipnum,
                    '' acccode,
                    '' accname,
                    SUM(fnamt) fnamt,
                    '' remark,
                    p_order
            FROM    VGT.TT_ACACC0132R_DUAL
            WHERE   TRIM(cardno) = TRIM(p_cardno1)
        );

        p_order := p_order + 1;

        INSERT INTO VGT.TT_ACACC0132R_DUAL (

            SELECT  MAX(apprday) apprday,
                    '결제일자별 계' cardno,
                    '' cardcomp,
                    '' empcode,
                    '' empname,
                    '' slipdate,
                    '' slipnum,
                    '' acccode,
                    '' accname,
                    SUM(fnamt) fnamt,
                    '' remark,
                    p_order
             FROM   VGT.TT_ACACC0132R_DUAL
             WHERE  TRIM(apprday) = TRIM(p_apprday1)
        );

        p_order := p_order + 1;

        INSERT INTO VGT.TT_ACACC0132R_DUAL (
            SELECT  '' apprday,
                    '누계' cardno,
                    '' cardcomp,
                    '' empcode,
                    '' empname,
                    '' slipdate,
                    '' slipnum,
                    '' acccode,
                    '' accname,
                    SUM(fnamt) fnamt,
                    '' remark ,
                    p_order
            FROM    VGT.TT_ACACC0132R_DUAL
            WHERE   NVL(SUBSTR(cardno, -1, 1),'') != '계'
        );


		OPEN IO_CURSOR FOR
			SELECT apprday apprday,
				   cardno,
				   cardcomp,
				   empname empname,
				   slipdate,
				   slipnum,
				   accname accname,
				   NVL(fnamt, 0) fnamt,
				   remark
			FROM   VGT.TT_ACACC0132R_DUAL
            ORDER BY i_order ;

	END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
