CREATE PROCEDURE        spACacc0050P
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0050P
	-- 작 성 자         : 최용석
	-- 작성일자         : 2015-05-20
	-- 수 정 자     : 강현호
	-- E-Mail       : roykang0722@gmail.com
	-- 수정일자      : 2016-12-13
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 자금코드를 설정하는 프로시저이다.
	-- ---------------------------------------------------------------
(
	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_strdate		IN	   VARCHAR2 DEFAULT '',
	p_enddate		IN	   VARCHAR2 DEFAULT '',
	p_stracccode	IN	   VARCHAR2 DEFAULT '',
	p_endacccode	IN	   VARCHAR2 DEFAULT '',
	p_outputdiv 	IN	   VARCHAR2 DEFAULT '',
	p_funddiv		IN	   VARCHAR2 DEFAULT '',
	p_slipinno		IN	   VARCHAR2 DEFAULT '',
	p_slipinseq 	IN	   NUMBER   DEFAULT 0,
	p_fundcode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',

    MESSAGE         OUT    VARCHAR2,
    IO_CURSOR       OUT    TYPES.DataSet
)
AS

    p_slipdiv    VARCHAR2(5);

BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF p_div = 'S' THEN

        IF (p_outputdiv = '1') THEN --K-GAAP
            
            p_slipdiv := 'F';
        
        ELSIF (p_outputdiv = '2') THEN --IFRS
        
            
            p_slipdiv := 'K';
            
        END IF;


        -- 임시 테이블 데이터 삭제
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0050P_ACORDS';

        INSERT INTO VGT.TT_ACACC0050P_ACORDS
            SELECT	 slipinno,
                     slipinseq,
                     MAX(CASE WHEN seq = 1 THEN mngcludec ELSE '' END) mngcludec1,
                     MAX(CASE WHEN seq = 2 THEN mngcludec ELSE '' END) mngcludec2,
                     MAX(CASE WHEN seq = 3 THEN mngcludec ELSE '' END) mngcludec3,
                     MAX(CASE WHEN seq = 4 THEN mngcludec ELSE '' END) mngcludec4,
                     MAX(CASE WHEN seq = 5 THEN mngcludec ELSE '' END) mngcludec5,
                     MAX(CASE WHEN seq = 6 THEN mngcludec ELSE '' END) mngcludec6
            FROM	 (SELECT b.slipinno,
                             b.slipinseq,
                             ROW_NUMBER() OVER (PARTITION BY b.slipinno, b.slipinseq ORDER BY c.seq) seq,
                             '[' || NVL(D.mngcluname, '') || ']' || NVL(c.mngcluval, '') || ' : ' || NVL(c.mngcludec, '') || CASE WHEN E.custcode IS NULL THEN '' ELSE ' (' || E.businessno || ')' END mngcludec
                      FROM	 ACORDM A
                             JOIN ACORDD b ON A.compcode = b.compcode
                                              AND A.slipinno = b.slipinno
                                              AND NVL(b.fundcode,' ') LIKE p_funddiv
                             LEFT JOIN ACORDS c ON  b.compcode = c.compcode
                                                    AND b.slipinno = c.slipinno
                                                    AND b.slipinseq = c.slipinseq
                             LEFT JOIN ACMNGM D ON c.mngclucode = D.mngclucode
                             LEFT JOIN CMCUSTM E ON c.mngclucode = 'S010'
                                                    AND c.mngcluval = E.custcode
                      WHERE  A.compcode = p_compcode
                             AND A.slipdate BETWEEN p_strdate AND p_enddate
                             AND A.plantcode LIKE p_plantcode
                             AND A.slipdiv <> p_slipdiv
                             AND b.acccode BETWEEN p_stracccode AND p_endacccode ) A
            GROUP BY slipinno, slipinseq;


        OPEN IO_CURSOR FOR
            SELECT	 A.slipdate,
                     A.slipnum,
                     A.slipinno,
                     b.slipinseq,
                     b.dcdiv,
                     NVL(f.divname, b.dcdiv) dcname,
                     b.acccode,
                     D.accname,
                     b.debamt,
                     b.creamt,
                     b.remark1,
                     b.fundcode,
                     E.fundname,
                     c.mngcludec1,
                     c.mngcludec2,
                     c.mngcludec3,
                     c.mngcludec4,
                     c.mngcludec5,
                     c.mngcludec6
            FROM	 ACORDM A
                     JOIN ACORDD b ON A.compcode = b.compcode
                                      AND A.slipinno = b.slipinno
                                      AND NVL(b.fundcode,' ') LIKE p_funddiv
                     JOIN VGT.TT_ACACC0050P_ACORDS c ON b.slipinno = c.slipinno
                                                AND b.slipinseq = c.slipinseq
                     LEFT JOIN ACACCM D ON b.acccode = D.acccode
                     LEFT JOIN ACFUNDM E ON b.compcode = E.compcode
                                            AND b.fundcode = E.fundcode
                     LEFT JOIN CMCOMMONM f ON f.cmmcode = 'AC22'
                                              AND b.dcdiv = f.divcode
            WHERE	 A.compcode = p_compcode
                     AND A.slipdate BETWEEN p_strdate AND p_enddate
                     AND A.plantcode LIKE p_plantcode
                     AND A.slipdiv <> p_slipdiv
                     AND b.acccode BETWEEN p_stracccode AND p_endacccode
  
            ORDER BY A.slipdate, A.slipnum, b.slipinseq;



    ELSIF p_div = 'U' THEN

        UPDATE ACORDD A
        SET    fundcode = p_fundcode
        WHERE  compcode = p_compcode
               AND slipinno = p_slipinno
               AND slipinseq = p_slipinseq;

	END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
