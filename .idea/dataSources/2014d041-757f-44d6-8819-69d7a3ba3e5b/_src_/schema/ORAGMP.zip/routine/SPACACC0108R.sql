CREATE PROCEDURE spACacc0108R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0108R
	-- 작 성 자         : 배종성
	-- 작성일자         : 2010-12-17
	-- 수정내역         : 2011-01-19 이영재 집계,현금처리 수정
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-20
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 월계표를 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_yyyymm		IN	   VARCHAR2 DEFAULT '',
	p_outputdiv 	IN	   NUMBER DEFAULT 0,
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	p_odiv1 		 VARCHAR2(5);
	p_odiv2 		 VARCHAR2(5);
	p_acccashcode	 VARCHAR2(20);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);

	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0108R_ACACC0108RBASE ';

	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0108R_ACACC0108R1 ';

	IF (p_outputdiv = '1')
	THEN
		--K-GAAP
		p_odiv1 := '20';
		p_odiv2 := 'F';
	END IF;

	IF (p_outputdiv = '2')
	THEN
		--IFRS
		p_odiv1 := '30';
		p_odiv2 := 'K';
	END IF;

	IF (p_div = 'S')
	THEN
		NULL;
	END IF;

	FOR rec IN (SELECT value1
				FROM   SYSPARAMETERMANAGE
				WHERE  parametercode = 'acccashcode'
					   AND usediv = 'Y')
	LOOP
		p_acccashcode := rec.value1;
	END LOOP;


	-- DELETE FROM tt_spACacc0108Rbase;

	--compcode       varchar(3)  null,
	--plantcode      varchar(4)  null, --사업장코드
	--회계일자
	--전표번호
	--결의번호
	INSERT INTO VGT.TT_ACACC0108R_ACACC0108RBASE
		(SELECT   SUM(debdcount) + SUM(debamt) debsumamt,
				  SUM(debdcount) debdcount,
				  SUM(debamt) debamt,
				  acccode,
				  SUM(cresumamt) cresumamt,
				  SUM(credcount) credcount,
				  SUM(cresumamt) + SUM(credcount) creamt
		 FROM	  ( -- 대체 전표 조회
				   SELECT 0 debsumamt, -- 차변합계
						  NVL(debamt, 0) debdcount, -- 차변대체
						  0 debamt, -- 차변출금
						  acccode,
						  0 cresumamt, -- 대변입금
						  NVL(creamt, 0) credcount, -- 대변대체
						  0 creamt -- 대변합계
				   FROM   ACORDD a
						  JOIN ACORDM b
							  ON a.compcode = b.compcode
								 AND a.slipinno = b.slipinno
				   WHERE  (dcdiv = '1'
						   OR dcdiv = '2')
						  AND a.compcode = p_compcode
						  AND a.plantcode LIKE p_plantcode
						  AND a.slipdate BETWEEN p_yyyymm || '-01' AND TO_CHAR(LAST_DAY(TO_DATE(p_yyyymm, 'YYYY-MM')), 'YYYY-MM-DD')
						  AND a.acccode <> p_acccashcode
						  AND b.slipdiv <> p_odiv2 -- K-GAAP <> 'F', IFRS <> 'K'
				   UNION ALL
				   SELECT 0 debsumamt, -- 차변합계
						  NVL(debamt, 0) * -1 debdcount, -- 차변대체
						  NVL(debamt, 0) debamt, -- 차변출금
						  acccode,
						  NVL(creamt, 0) cresumamt, -- 대변입금
						  NVL(creamt, 0) * -1 credcount, -- 대변대체
						  0 creamt -- 대변합계
				   FROM   ACORDD a,
						  (SELECT a.slipdate slipdate,
								  a.slipnum slipnum
						   FROM   ACORDD a
								  JOIN ACORDM b
									  ON a.compcode = b.compcode
										 AND a.slipinno = b.slipinno
						   WHERE  a.compcode = p_compcode
								  AND a.plantcode LIKE p_plantcode
								  AND a.slipdate BETWEEN p_yyyymm || '-01' AND TO_CHAR(LAST_DAY(TO_DATE(p_yyyymm, 'YYYY-MM')), 'YYYY-MM-DD')
								  AND (dcdiv = '1'
									   OR dcdiv = '2')
								  AND a.acccode = p_acccashcode
								  AND b.slipdiv <> p_odiv2 -- K-GAAP <> 'F', IFRS <> 'K'
														  ) b
				   WHERE  a.slipdate = b.slipdate
						  AND a.slipnum = b.slipnum
						  AND a.acccode <> p_acccashcode
				   UNION ALL
				   SELECT 0 debsumamt, -- 차변합계
						  0 debdcount, -- 차변대체
						  NVL(debamt, 0) debamt, -- 차변출금
						  acccode,
						  NVL(creamt, 0) cresumamt, -- 대변입금
						  0 credcount, -- 대변대체
						  0 creamt -- 대변합계
				   FROM   ACORDD a
						  JOIN ACORDM b
							  ON a.compcode = b.compcode
								 AND a.slipinno = b.slipinno
				   WHERE  a.compcode = p_compcode
						  AND a.plantcode LIKE p_plantcode
						  AND a.slipdate BETWEEN p_yyyymm || '-01' AND TO_CHAR(LAST_DAY(TO_DATE(p_yyyymm, 'YYYY-MM')), 'YYYY-MM-DD')
						  AND (a.dcdiv = '3'
							   OR a.dcdiv = '4')
						  AND b.slipdiv <> p_odiv2 -- K-GAAP <> 'F', IFRS <> 'K'
												  ) a
		 GROUP BY acccode);

	-- DELETE FROM tt_spACacc0108R1;

	--회계일자
	--전표번호
	--결의번호
	--현금 금일/전일잔고

	INSERT INTO VGT.TT_ACACC0108R_ACACC0108R1
		(SELECT   SUM(NVL(totdebamt, 0)) - SUM(NVL(totcreamt, 0)) debsumamt, -- 차변합계
				  0 debdcount, -- 차변대체
				  SUM(NVL(totdebamt, 0)) - SUM(NVL(totcreamt, 0)) debamt, -- 차변출금 //현금의 조회기간의 마지막일자 잔고
				  '' acccode,
				  SUM(NVL(bsdebamt, 0)) - SUM(NVL(bscreamt, 0)) cresumamt, -- 대변입금 //현금의 초기일자 전일잔고
				  0 credcount, -- 대변대체
				  SUM(NVL(bsdebamt, 0)) - SUM(NVL(bscreamt, 0)) creamt -- 대변합계
		 FROM	  ACORDDMM
		 WHERE	  compcode = p_compcode
				  AND plantcode LIKE p_plantcode
				  AND slipym = p_yyyymm
				  AND acccode = p_acccashcode
				  AND (closediv = '10'
					   OR closediv = p_odiv1) -- 출력구분 [K-GAAP, IFRS]
		 GROUP BY acccode);

	-- 금액0인 계정과목 정리
	DELETE VGT.TT_ACACC0108R_ACACC0108RBASE
	WHERE  debsumamt = 0
		   AND debdcount = 0
		   AND debamt = 0
		   AND cresumamt = 0
		   AND credcount = 0
		   AND creamt = 0;

	OPEN IO_CURSOR FOR
		SELECT	 A.*
		FROM	 (SELECT p_plantcode plantcode,
						 p_yyyymm || '-01' startdt,
						 TO_CHAR(LAST_DAY(TO_DATE(p_yyyymm, 'YYYY-MM')), 'YYYY-MM-DD') enddt,
						 p_outputdiv outputdiv,
						 acccode,
						 debsumamt, -- 차변합계
						 debdcount, -- 차변대체
						 debamt, -- 차변출금
						 accname,
						 cresumamt, -- 대변입금
						 credcount, -- 대변대체
						 creamt
				  FROM	 (SELECT a.acccode,
								 a.debsumamt, -- 차변합계
								 a.debdcount, -- 차변대체
								 a.debamt, -- 차변출금
								 b.accname,
								 a.cresumamt, -- 대변입금
								 a.credcount, -- 대변대체
								 a.creamt
						  FROM	 VGT.TT_ACACC0108R_ACACC0108RBASE a, ACACCM b
						  WHERE  a.acccode = b.acccode
						  UNION ALL
						  SELECT 'aa' acccode,
								 SUM(debsumamt) debsumamt, -- 차변합계
								 SUM(debdcount) debdcount, -- 차변대체
								 SUM(debamt) debamt, -- 차변출금
								 '소             계' accname,
								 SUM(cresumamt) cresumamt, -- 대변입금
								 SUM(credcount) credcount, -- 대변대체
								 SUM(creamt) creamt
						  FROM	 VGT.TT_ACACC0108R_ACACC0108RBASE
						  UNION ALL
						  SELECT 'bb' acccode,
								 debsumamt, -- 차변합계
								 debdcount, -- 차변대체
								 debamt, -- 차변출금
								 '금일잔고/전일잔고' accname,
								 cresumamt, -- 대변입금
								 credcount, -- 대변대체
								 creamt
						  FROM	 VGT.TT_ACACC0108R_ACACC0108R1
						  UNION ALL
						  SELECT 'zzz' acccode,
								 SUM(a.debsumamt) + MAX(b.debsumamt) debsumamt, -- 차변합계
								 SUM(a.debdcount) + MAX(b.debdcount) debdcount, -- 차변대체
								 SUM(a.debamt) + MAX(b.debamt) debamt, -- 차변출금
								 '합             계' accname,
								 SUM(a.cresumamt) + MAX(b.cresumamt) cresumamt, -- 대변입금
								 SUM(a.credcount) + MAX(b.credcount) credcount, -- 대변대체
								 SUM(a.creamt) + MAX(b.creamt) creamt
						  FROM	 VGT.TT_ACACC0108R_ACACC0108RBASE a, VGT.TT_ACACC0108R_ACACC0108R1 b)) A
		ORDER BY acccode;

	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
