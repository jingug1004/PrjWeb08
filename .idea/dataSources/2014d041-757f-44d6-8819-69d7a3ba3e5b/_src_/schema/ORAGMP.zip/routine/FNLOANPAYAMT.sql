CREATE FUNCTION fnLoanPayAmt(
	-- ---------------------------------------------------------------
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2017-02-24
    -- ---------------------------------------------------------------
	p_compcode 	IN 	VARCHAR2, 	-- 회사코드
	p_loanno 	IN 	VARCHAR2, 	-- 차입금코드
	p_paydt 	IN 	VARCHAR2, 		-- 특정일자
	p_dayflag 	IN 	NUMBER
)
	RETURN NUMBER
AS
	p_payamt		NUMBER(17, 4); 	-- 차입금이자
	p_strdt 		VARCHAR2(10); 			-- 계산시작일
	p_enddt 		VARCHAR2(10); 			-- 계산종료일
	p_irrepaydiv	VARCHAR2(8); 	-- 이자지급방법
	p_loanamt		NUMBER(17, 4); 	-- 차입잔액
	p_interate		NUMBER(17, 6);   -- 이율
  p_irrepaysep  NUMBER(5, 0);   -- 이자납입주기
  p_tmppaydt    VARCHAR2(10);       -- 임시일자
  p_tmpinterate  NUMBER(17, 6);   -- 임시이율
  p_tmpplanamt  NUMBER(17, 4);   -- 임시금액
  p_strcnt    FLOAT(53);     -- 시작년일수
  p_endcnt    FLOAT(53);     -- 종료년일수
  -- 이자계산 시작일과 종료일 사이의 변경내역(이율변경, 원금상환)을 생성
    CURSOR SPACC_CURSOR IS
    SELECT   a.changedate, MAX(a.interate), SUM(a.repayamt)
            FROM   (SELECT   a.changedate, MAX(a.interate) interate, 0 repayamt
                      FROM     ACLOANC a
                      WHERE    a.compcode = p_compcode
                               AND a.loanno = p_loanno
                               AND a.changedate BETWEEN p_strdt AND p_enddt
                               AND a.interate > 0
                      GROUP BY a.changedate
                      UNION ALL
                      SELECT TO_CHAR(  TO_DATE((
                                                 CASE
                                                     WHEN NVL(a.prindate,' ') = ' '
                                                          AND NVL(a.prrepaydate,' ') <> ' '
                                                     THEN
                                                         a.prrepaydate
                                                     ELSE
                                                         fnDateConv2(fnNextDatetime(COALESCE(TRIM(a.prindate), TRIM(a.prrepaydate), a.strdate), a.prrepaysep, SUBSTR(p_enddt,0,7), 0) || SUBSTR(NVL(TRIM(a.prrepaydate), a.strdate), -3, 3))
                                                 END), 'YYYY-MM-DD') + 1,'YYYY-MM-DD') changedate,
                             0 interate,
                             FLOOR(a.loadamt / (TRUNC(MONTHS_BETWEEN(TO_DATE(a.expdate,'YYYY-MM-DD')+1, TO_DATE(a.strdate,'YYYY-MM-DD')))   / CASE a.prrepaysep WHEN '2' THEN 3 WHEN '3' THEN 6 ELSE 1 END) / 10) * 10 repayamt
                      FROM   ACLOANM a
                      WHERE  a.compcode = p_compcode
                             AND a.loanno = p_loanno
                             AND a.enddiv = '1'
                             AND a.loadamt - a.prsumamt > 0
                             AND a.prrepaydiv IN ('1', '3')
                             AND NVL(a.prrepaysep,' ') <> ' '
                             AND a.prindate < p_strdt
                             AND a.prrepaysep <> '4'
                             AND (NVL(a.prindate,' ') = ' '
                                  AND a.prrepaydate BETWEEN p_strdt AND p_enddt
                                  OR fnDateConv2(fnNextDatetime(COALESCE(TRIM(a.prindate), TRIM(a.prrepaydate), a.strdate), a.prrepaysep, SUBSTR(p_enddt,0,7), 0) || SUBSTR(NVL(TRIM(a.prrepaydate), a.strdate), -3, 3)) BETWEEN p_strdt AND p_enddt)
                             AND NOT EXISTS
                                     (SELECT *
                                      FROM   ACLOANR
                                      WHERE  compcode = a.compcode
                                             AND loanno = a.loanno)
                      UNION ALL
                      SELECT   TO_CHAR(TO_DATE(a.repaydate,'YYYY-MM-DD') + 1,'YYYY-MM-DD') changedate, 0 interate, SUM(repayamt) repayamt
                      FROM     ACLOANR a
                      WHERE    a.compcode = p_compcode
                               AND a.loanno = p_loanno
                               AND a.repaydate BETWEEN p_strdt AND p_enddt
                      GROUP BY a.repaydate) a
            GROUP BY a.changedate
            ORDER BY a.changedate;

BEGIN
  p_payamt := 0;

  -- 선납인경우 말일계산
  FOR rec IN (SELECT CASE
               WHEN a.irrepaysep = '4'
                OR NVL(b.expdate, a.expdate) <= fnDateConv2(TO_CHAR(ADD_MONTHS(TO_DATE(p_paydt,'YYYY-MM-DD'),CASE a.irrepaysep WHEN '2' THEN 3 WHEN '3' THEN 6 ELSE 1 END),'YYYY-MM') || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3))
               THEN
                 fnNextWorkingDateInVarchar(0, NVL(b.expdate, a.expdate))
               WHEN a.hrcalcdiv IN ('1', '2')
               THEN
                 TO_DATE(fnDateConv2(TO_CHAR(ADD_MONTHS(TO_DATE(p_paydt,'YYYY-MM-DD'),CASE a.irrepaysep WHEN '2' THEN 3 WHEN '3' THEN 6 ELSE 1 END),'YYYY-MM') || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3)),'YYYY-MM-DD')
               ELSE
                 fnNextWorkingDateInVarchar(0, fnDateConv2(TO_CHAR(ADD_MONTHS(TO_DATE(p_paydt,'YYYY-MM-DD'),CASE a.irrepaysep WHEN '2' THEN 3 WHEN '3' THEN 6 ELSE 1 END),'YYYY-MM') || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3)))
             END
               AS alias1
        FROM   ACLOANM a
             LEFT JOIN (SELECT a.compcode, a.loanno, a.expdate
                  FROM   ACLOANC a
                     JOIN (SELECT  compcode, loanno, MAX(changedate) changedate
                         FROM   ACLOANC
                         WHERE  compcode = p_compcode
                            AND changedate <= p_paydt
                            AND expdate <> ' '
                         GROUP BY compcode, loanno) b
                       ON a.compcode = b.compcode
                        AND a.loanno = b.loanno
                        AND a.changedate = b.changedate) b
               ON a.compcode = b.compcode
                AND a.loanno = b.loanno
        WHERE  a.compcode = p_compcode
             AND a.loanno = p_loanno)
  LOOP
    p_enddt := TO_CHAR(rec.alias1,'YYYY-MM-DD');
  END LOOP;

  -- 이자계산 시작일과 종료일 등을 산출
  FOR rec
    IN (SELECT CASE
             WHEN a.irrepaydiv = '1'
             THEN
               CASE
                 WHEN NVL(a.irindate,' ') = ' '
                  AND p_dayflag = 0
                 THEN
                   TO_DATE(a.strdate,'YYYY-MM-DD')
                 ELSE
                   TO_DATE(CASE WHEN a.hrcalcdiv <> '3' THEN fnDateConv2(SUBSTR(a.irindate, 0, 7) || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3)) ELSE a.irindate END, 'YYYY-MM-DD') + 1
               END
             WHEN a.irrepaydiv = '2'
             THEN
               CASE
                 WHEN NVL(a.irindate,' ') = ' '
                  AND p_dayflag = 0
                 THEN
                   TO_DATE(a.strdate,'YYYY-MM-DD')
                 ELSE
                   TO_DATE(CASE WHEN a.hrcalcdiv <> '3' THEN fnDateConv2(SUBSTR(a.irindate, 0, 7) || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3)) ELSE a.irindate END, 'YYYY-MM-DD')
               END
             WHEN a.irrepaydiv = '3'
             THEN
               CASE
                 WHEN NVL(a.irindate,' ') = ' '
                    AND p_dayflag = 0
                 THEN
                   TO_DATE(a.strdate,'YYYY-MM-DD')
                 ELSE
                   TO_DATE(CASE WHEN a.hrcalcdiv <> '3' THEN fnDateConv2(SUBSTR(a.irindate, 0, 7) || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3)) ELSE a.irindate END, 'YYYY-MM-DD')
               END
               + 1
             WHEN a.irrepaydiv = '4'
             THEN
               CASE
                 WHEN NVL(a.irindate,' ') = ' '
                  AND p_dayflag = 0
                 THEN
                   TO_DATE(a.strdate,'YYYY-MM-DD')
                 ELSE
                   TO_DATE(p_paydt,'YYYY-MM-DD') + 1
               END
             WHEN a.irrepaydiv = '5'
             THEN
               CASE
                 WHEN NVL(a.irindate,' ') = ' '
                  AND p_dayflag = 0
                 THEN
                   TO_DATE(a.strdate,'YYYY-MM-DD')
                 ELSE
                   TO_DATE(p_paydt,'YYYY-MM-DD')
               END
             WHEN a.irrepaydiv = '6'
             THEN
               CASE
                 WHEN NVL(a.irindate,' ') = ' '
                    AND p_dayflag = 0
                 THEN
                   TO_DATE(a.strdate,'YYYY-MM-DD')
                 ELSE
                   TO_DATE(p_paydt,'YYYY-MM-DD')
               END
               + 1
             WHEN a.irrepaydiv = '7'
             THEN
               CASE
                 WHEN NVL(a.irindate,' ') = ' '
                    AND p_dayflag = 0
                 THEN
                   TO_DATE(a.strdate,'YYYY-MM-DD')
                 ELSE
                   TO_DATE(a.irindate,'YYYY-MM-DD')
               END
               + 1
           END
             AS alias1,
           CASE
             WHEN a.irrepaydiv = '1'
             THEN
               CASE WHEN NVL(b.expdate, a.expdate) <= p_paydt THEN TO_DATE(p_paydt,'YYYY-MM-DD') - 1 ELSE TO_DATE(p_paydt,'YYYY-MM-DD') END
             WHEN a.irrepaydiv = '2'
             THEN
               TO_DATE(p_paydt,'YYYY-MM-DD') - 1
             WHEN a.irrepaydiv = '3'
             THEN
               TO_DATE(p_paydt,'YYYY-MM-DD')
             WHEN a.irrepaydiv = '4'
             THEN
               CASE WHEN NVL(b.expdate, a.expdate) < p_enddt THEN TO_DATE(NVL(b.expdate, a.expdate),'YYYY-MM-DD') ELSE TO_DATE(p_enddt,'YYYY-MM-DD') END
             WHEN a.irrepaydiv = '5'
             THEN
               TO_DATE(p_enddt,'YYYY-MM-DD') - 1
             WHEN a.irrepaydiv = '6'
             THEN
               TO_DATE(p_enddt,'YYYY-MM-DD')
             WHEN a.irrepaydiv = '7'
             THEN
               TO_DATE(p_paydt,'YYYY-MM-DD')
           END
             AS alias2,
           a.irrepaydiv AS alias3,
           a.loadamt - a.prsumamt AS alias4,
           a.interate AS alias5,
           CASE a.irrepaysep WHEN '2' THEN 3 WHEN '3' THEN 6 ELSE 1 END AS alias6
      FROM   ACLOANM a
           LEFT JOIN (SELECT a.compcode, a.loanno, a.expdate
                FROM   ACLOANC a
                   JOIN (SELECT  compcode, loanno, MAX(changedate) changedate
                       FROM   ACLOANC
                       WHERE  compcode = p_compcode
                          AND changedate <= p_paydt
                          AND NVL(expdate,' ') <> ' '
                       GROUP BY compcode, loanno) b
                     ON a.compcode = b.compcode
                      AND a.loanno = b.loanno
                      AND a.changedate = b.changedate) b
             ON a.compcode = b.compcode
              AND a.loanno = b.loanno
      WHERE  a.compcode = p_compcode
           AND a.loanno = p_loanno)
  LOOP
    p_strdt := TO_CHAR(rec.alias1,'YYYY-MM-DD');
    p_enddt := TO_CHAR(rec.alias2,'YYYY-MM-DD');
    p_irrepaydiv := rec.alias3;
    p_loanamt := rec.alias4;
    p_interate := rec.alias5;
    p_irrepaysep := rec.alias6;
  END LOOP;

  IF p_irrepaydiv = '7'
  THEN
    BEGIN
      p_payamt := p_loanamt * p_interate * p_irrepaysep / 1200;
    END;
  ELSE
    BEGIN
      -- 기준이율을 산출
      FOR rec IN (SELECT a.interate AS alias1
            FROM   ACLOANC a
                 JOIN (SELECT   compcode, loanno, MAX(changedate) changedate
                   FROM    ACLOANC
                   WHERE    compcode = p_compcode
                        AND loanno = p_loanno
                        AND changedate <= p_strdt
                        AND interate > 0
                   GROUP BY compcode, loanno) b
                   ON a.compcode = b.compcode
                    AND a.loanno = b.loanno
                    AND a.changedate = b.changedate
            WHERE  a.compcode = p_compcode
                 AND a.loanno = p_loanno)
      LOOP
        p_interate := rec.alias1;
      END LOOP;

      -- 후납인 경우에만 차입잔액을 산출 (선납은 현재잔액을 사용)
      IF p_irrepaydiv IN ('1', '2', '3')
      THEN
                FOR rec IN (SELECT p_loanamt + NVL(SUM(a.repayamt), 0) AS alias1
                            FROM   ACLOANR a
                            WHERE  a.compcode = p_compcode
                                   AND a.loanno = p_loanno
                                   AND a.repaydate BETWEEN p_strdt AND TO_CHAR(TO_DATE(p_enddt,'YYYY-MM-DD') - 1,'YYYY-MM-DD'))
                LOOP
                    p_loanamt := rec.alias1;
                END LOOP;
      END IF;

      OPEN spacc_cursor;
            LOOP
              FETCH spacc_cursor
        INTO p_tmppaydt, p_tmpinterate, p_tmpplanamt;
                EXIT WHEN spacc_cursor%NOTFOUND;

          p_strcnt := fndatediff('DAY', SUBSTR(p_strdt,0,4) || '-01-01', SUBSTR(p_strdt,0,4) || '-12-31') + 1;
          p_endcnt := fndatediff('DAY', SUBSTR(p_tmppaydt,0,4) || '-01-01', SUBSTR(p_tmppaydt,0,4) || '-12-31') + 1;

          IF p_strcnt = p_endcnt
          THEN
            BEGIN
              p_payamt := p_payamt + fndatediff('DAY', p_strdt, p_tmppaydt) * p_interate * p_loanamt / p_strcnt / 100;
            END;
          ELSE
            BEGIN
              p_payamt := p_payamt + (fndatediff('DAY', p_strdt, SUBSTR(p_strdt,0,4) || '-12-31') / p_strcnt + fndatediff('DAY', SUBSTR(p_tmppaydt,0,4) || '-01-01', p_tmppaydt) / p_endcnt) * p_interate * p_loanamt / 100;
            END;
          END IF;

          p_strdt := p_tmppaydt;

          IF p_tmpinterate > 0
          THEN
            p_interate := p_tmpinterate;
          END IF;

          p_loanamt := p_loanamt - p_tmpplanamt;

      END LOOP;
      CLOSE spacc_cursor;

      p_strcnt := fndatediff('DAY', SUBSTR(p_strdt,0,4) || '-01-01', SUBSTR(p_strdt,0,4) || '-12-31') + 1;
      p_endcnt := fndatediff('DAY', SUBSTR(p_enddt,0,4) || '-01-01', SUBSTR(p_enddt,0,4) || '-12-31') + 1;

      IF p_strcnt = p_endcnt
      THEN
                p_payamt := p_payamt + fndatediff('DAY', p_strdt, TO_CHAR(TO_DATE(p_enddt,'YYYY-MM-DD')+ 1,'YYYY-MM-DD')) * p_interate * p_loanamt / p_strcnt / 100;
      ELSE
                p_payamt := p_payamt + (fndatediff('DAY', p_strdt, SUBSTR(p_strdt,0,4) || '-12-31') / p_strcnt + fndatediff('DAY', SUBSTR(p_enddt,0,4) || '-01-01', p_enddt) / p_endcnt) * p_interate * p_loanamt / 100;
      END IF;

    END;
  END IF;

  p_payamt := FLOOR(p_payamt);
  RETURN (p_payamt);
EXCEPTION
  WHEN OTHERS
  THEN RETURN NULL;
END;
/
