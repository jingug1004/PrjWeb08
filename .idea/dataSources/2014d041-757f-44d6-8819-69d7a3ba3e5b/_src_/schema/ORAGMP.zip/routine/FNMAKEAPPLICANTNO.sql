CREATE FUNCTION fnMakeApplicantNo
-- ---------------------------------------------------------------
 -- 함수명           : fnMakeApplicantNo
 -- 작 성 자         : 이세민
 -- 작성일자         : 2015-08-11
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2016-11-22
 -- ---------------------------------------------------------------
 -- 함수 설명        : 지원 관리 번호를 생성하는 함수이다.
 -- ---------------------------------------------------------------
 /*
    select    dbo.fnMakeApplicantNo('2015-08-11')

*/
(
  p_setdate IN VARCHAR2 DEFAULT ''
)
RETURN VARCHAR2
AS
   p_tostring VARCHAR2(20);

BEGIN

    SELECT CASE WHEN LENGTH(TO_CHAR(NVL(MAX(a.applicantno), 0))) > 3 THEN
                      REPLACE(p_setdate, '-', '') || SUBSTR('0000' || SUBSTR(TO_CHAR(NVL(MAX(a.applicantno), 0) +1), -4), -4)
                   ELSE
                      REPLACE(p_setdate, '-', '') || SUBSTR('0000' || TO_CHAR(NVL(MAX(a.applicantno), 0) +1), -4)
            END
    INTO    p_tostring
    FROM    psapcinfo a
    WHERE   applidate = p_setdate;


    RETURN p_tostring;

END;
/
