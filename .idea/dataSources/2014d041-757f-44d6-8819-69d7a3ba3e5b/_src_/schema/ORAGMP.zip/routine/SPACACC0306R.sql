CREATE PROCEDURE        spACacc0306R
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACacc0306R
   -- 작 성 자         : 배종성
   -- 작성일자         : 2011-03-21
   -- 수정자         : 임 정호
   -- 수정일         : 2016-12-27

   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 부도어음명세서를 조회하는 프로시저이다.
   -- ---------------------------------------------------------------
(
   p_div            IN     VARCHAR2 DEFAULT '',
   p_compcode       IN     VARCHAR2 DEFAULT '',
   p_plantcode      IN     VARCHAR2 DEFAULT '',
   p_yymm           IN     VARCHAR2 DEFAULT '',
   p_viewdiv        IN     VARCHAR2 DEFAULT '',
   p_userid         IN     VARCHAR2 DEFAULT '',
   p_reasondiv      IN     VARCHAR2 DEFAULT '',
   p_reasontext     IN     VARCHAR2 DEFAULT '',
   IO_CURSOR        OUT TYPES.DataSet,
   MESSAGE          OUT VARCHAR2
)
AS
   p_enddate   VARCHAR2 (10);
BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF (p_div = 'S') THEN
      -- 부문별
        p_enddate := TO_CHAR (LAST_DAY (TO_DATE (p_yymm || '-01', 'YYYY-MM-DD')), 'YYYY-MM-DD');

        OPEN IO_CURSOR FOR
           SELECT seq,
                  a.plantcode,                                           --사업장
                  coldate,                                              --수취일자
                  billdiv,                                              --어음종류
                  CASE
                     WHEN seq = '1' THEN SL18.divname
                     WHEN seq = '2' THEN ' 합계'
                  END
                     billdivnm,
                  a.custcode,                                            --거래처
                  NVL (b.custname, '') custname,
                  billno,                                               --어음번호
                  expdate,                                              --만기일자
                  ruindate,
                  paybank,                                              --지급지점
                  issempnm,                                              --발행인
                  billamt                                               --어음금액
             FROM (SELECT '1' seq,
                          plantcode,                                     --사업장
                          NVL (coldate, '') coldate,                   --수취일자
                          billdiv,                                      --어음종류
                          NVL (custcode, '') custcode,                  --거래처
                          billno,                                       --어음번호
                          expdate,                                      --만기일자
                          ruindate,
                          NVL (paybank, '') paybank,                   --지급지점
                          NVL (issempnm, '') issempnm,                  --발행인
                          NVL (billamt, 0) billamt                      --어음금액
                     FROM (
                            ---------------------------------------------------
                            SELECT  a.compcode,
                                    a.plantcode,                                --사업장
                                    a.coldate coldate,                          --수취일자
                                    a.billdiv,                                  --어음종류
                                    a.custcode custcode,                        --거래처
                                    a.billno,                                   --어음번호
                                    a.expdate,                                  --만기일자
                                    c.slipdate ruindate,                        --부도일자
                                    a.paybank  paybank,                         --지급지점
                                    a.issempnm  issempnm,                       --발행인
                                    NVL (a.billamt, 0) billamt                  --어음금액
                            FROM    ACBILLM a
                                    LEFT JOIN (
                                                SELECT  a.billno, MAX (b.slipdate) slipdate
                                                FROM    ACAUTOORDT a
                                                        JOIN ACORDM b
                                                          ON     a.compcode = b.compcode
                                                             AND a.slipinno = b.slipinno
                                                             AND TRIM(b.slipdate) IS NOT NULL
                                                WHERE   a.compcode = p_compcode
                                                    AND a.acattype = 'C'
                                                    AND a.acatrulecode LIKE 'C03%'
                                                    AND a.slipindate BETWEEN TO_CHAR(ADD_MONTHS  (TO_DATE (p_enddate,'YYYY-MM-DD'), -12 ),'YYYY-MM-DD') AND TO_CHAR(ADD_MONTHS  (TO_DATE (p_enddate,'YYYY-MM-DD'), 72 ),'YYYY-MM-DD')
                                                GROUP BY a.billno
                                              ) b ON a.billno = b.billno
                                    LEFT JOIN ACORDM c
                                        ON      a.compcode = c.compcode
                                            AND a.chgslipno = c.slipinno
                                    LEFT JOIN ACORDM D
                                        ON      a.compcode = D.compcode
                                            AND a.rtnslipno = D.slipinno
                            WHERE   a.compcode = p_compcode
                                AND a.plantcode LIKE p_plantcode
                                AND NVL (b.slipdate, a.coldate) <= p_enddate
                                AND a.billcls = '1'                                   -- 받을어음
                                AND billstate = '7'                                     -- 부도
                                AND c.slipdate BETWEEN TO_CHAR(ADD_MONTHS  (TO_DATE (p_enddate,'YYYY-MM-DD'), -36 ),'YYYY-MM-DD') AND p_enddate
                                AND (trim(D.slipdate) IS NULL OR p_enddate < D.slipdate)
                            ---------------------------------------------------------
                           ) ACacc0306R
                   UNION ALL
                     SELECT '2' seq,
                            '' plantcode,                               --사업장
                            '' coldate,                                --수취일자
                            '99' billdiv,                               --어음종류
                            '' custcode,                                --거래처
                            '' billno,                                 --어음번호
                            '' expdate,                                --만기일자
                            '' ruindate,
                            '' paybank,                                --지급지점
                            '' issempnm,                                --발행인
                            SUM (NVL (billamt, 0)) billamt              --어음금액
                       FROM  (
                                --------------------------------------------------------
                                SELECT  a.compcode,
                                        a.plantcode,                                --사업장
                                        a.coldate coldate,                          --수취일자
                                        a.billdiv,                                  --어음종류
                                        a.custcode custcode,                        --거래처
                                        a.billno,                                   --어음번호
                                        a.expdate,                                  --만기일자
                                        c.slipdate ruindate,                        --부도일자
                                        a.paybank  paybank,                         --지급지점
                                        a.issempnm  issempnm,                       --발행인
                                        NVL (a.billamt, 0) billamt                  --어음금액
                                FROM    ACBILLM a
                                        LEFT JOIN (
                                                    SELECT  a.billno, MAX (b.slipdate) slipdate
                                                    FROM    ACAUTOORDT a
                                                            JOIN ACORDM b
                                                              ON     a.compcode = b.compcode
                                                                 AND a.slipinno = b.slipinno
                                                                 AND TRIM(b.slipdate) IS NOT NULL
                                                    WHERE   a.compcode = p_compcode
                                                        AND a.acattype = 'C'
                                                        AND a.acatrulecode LIKE 'C03%'
                                                        AND a.slipindate BETWEEN TO_CHAR(ADD_MONTHS  (TO_DATE (p_enddate,'YYYY-MM-DD'), -12 ),'YYYY-MM-DD') AND TO_CHAR(ADD_MONTHS  (TO_DATE (p_enddate,'YYYY-MM-DD'), 72 ),'YYYY-MM-DD')
                                                    GROUP BY a.billno
                                                  ) b ON a.billno = b.billno
                                        LEFT JOIN ACORDM c
                                            ON      a.compcode = c.compcode
                                                AND a.chgslipno = c.slipinno
                                        LEFT JOIN ACORDM D
                                            ON      a.compcode = D.compcode
                                                AND a.rtnslipno = D.slipinno
                                WHERE   a.compcode = p_compcode
                                    AND a.plantcode LIKE p_plantcode
                                    AND NVL (b.slipdate, a.coldate) <= p_enddate
                                    AND a.billcls = '1'                                   -- 받을어음
                                    AND billstate = '7'                                     -- 부도
                                    AND c.slipdate BETWEEN TO_CHAR(ADD_MONTHS  (TO_DATE (p_enddate,'YYYY-MM-DD'), -36 ),'YYYY-MM-DD') AND p_enddate
                                    AND (trim(D.slipdate) IS NULL OR p_enddate < D.slipdate)
                                -----------------------------------------------------------------
                             ) tt_ACacc0306R
                   GROUP BY compcode) a
                  LEFT JOIN CMCUSTM b ON a.custcode = b.custcode
                  LEFT JOIN CMCOMMONM SL18
                     ON SL18.cmmcode = 'SL181' AND a.billdiv = SL18.divcode
         ORDER BY billdiv, seq, expdate, coldate, billno;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
