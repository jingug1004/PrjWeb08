CREATE PROCEDURE        spACass0104R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACass0104R
 -- 작 성 자         : 최인범
 -- 작성일자         : 2010-10-04
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2017-01-02
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 유형자산명세서을 조회하는 프로시저이다.
 -- ---------------------------------------------------------------

(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_plantcode     IN  VARCHAR2 DEFAULT '' ,
    p_closediv      IN  VARCHAR2 DEFAULT '' ,
    p_caldiv        IN  VARCHAR2 DEFAULT '' ,
    p_assym         IN  VARCHAR2 DEFAULT '' ,
    p_asscls        IN  VARCHAR2 DEFAULT '' ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_strym   VARCHAR2(7);
    p_strdate VARCHAR2(10);
    p_enddate VARCHAR2(10);
BEGIN

   MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    -- 계산기간 설정
    p_strym := SUBSTR(p_assym, 0, 4) || '-01' ;

    FOR  rec IN (   SELECT  MAX(SUBSTR(curstrdate, 0, 7))   AS alias1
                    FROM    ACSESSION a
                    WHERE   compcode = p_compcode
                            AND cyear <= SUBSTR(p_assym, 0, 4)
    )
    LOOP
        p_strym := rec.alias1 ;
    END LOOP;

    IF SUBSTR(p_assym, -2, 2) < SUBSTR(p_strym, -2, 2) THEN
        p_strym := TO_CHAR(TO_NUMBER(SUBSTR(p_assym, 0, 4))-1, 4) || SUBSTR(p_strym, -3, 3) ;
    ELSE
        p_strym := SUBSTR(p_assym, 0, 4) || SUBSTR(p_strym, -3, 3) ;
    END IF;

    p_strdate := p_strym || '-01' ;
    p_enddate := TO_CHAR(ADD_MONTHS(TO_DATE(p_assym || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD') ;


    OPEN  IO_CURSOR FOR

        SELECT  b.acccode ,
                MAX(c.accname)  accname  ,
                CASE WHEN p_div = 'S1' THEN '' ELSE a.asscode END asscode  ,
                MAX(CASE WHEN p_div = 'S1' THEN '' ELSE b.assname END)  assname  ,
                SUM( a.curassamt
                     - a.revamt
                     - a.expamt
                     + a.salamt
                     - CASE WHEN b.strdate BETWEEN p_strdate AND p_enddate THEN a.curassamt ELSE 0 END )  fnassamt  ,
                SUM( a.revamt
                     + a.expamt
                     + CASE WHEN b.strdate BETWEEN p_strdate AND p_enddate THEN a.curassamt ELSE 0 END )  incassamt  ,
                SUM(a.salamt)  decassamt  ,
                SUM(a.curassamt)  lsassamt  ,
                SUM(a.predepamt)  bsdepramt  ,
                SUM(a.depamt)  depamt  ,
                SUM(a.drpamt)  drpamt  ,
                SUM(a.predepamt + a.depamt - a.drpamt)  bedepramt  ,
                SUM(a.curassamt - a.predepamt - a.depamt + a.drpamt)  yetassamt  ,
                MAX(CASE WHEN p_div = 'S1' THEN '' ELSE b.remark END)  bigo  ,
                MAX(CASE WHEN p_div = 'S1' THEN '' ELSE D.deptname END)  deptname
        FROM    ACASSDEPR a
                JOIN ACASSM b        ON a.compcode = b.compcode
                                        AND a.asscode = b.asscode
                LEFT JOIN ACACCM c   ON b.acccode = c.acccode
                LEFT JOIN CMDEPTM D  ON b.mngdeptcode = D.deptcode
        WHERE   a.compcode = p_compcode
                AND a.closediv = p_closediv
                AND a.caldiv = p_caldiv
                AND a.assym = p_assym
                AND b.plantcode LIKE p_plantcode
                AND b.asscls = p_asscls
        GROUP BY b.acccode, CASE WHEN p_div = 'S1' THEN '' ELSE a.asscode END
        ORDER BY acccode NULLS FIRST ;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
