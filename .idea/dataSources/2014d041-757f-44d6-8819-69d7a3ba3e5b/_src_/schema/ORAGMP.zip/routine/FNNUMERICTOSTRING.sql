CREATE FUNCTION FNNUMERICTOSTRING (
	-- ---------------------------------------------------------------
	-- 함 수 명            : fnNumericToString
	-- 작 성 자         : 최인범
	-- 작성일자         : 2007-10-15
    -- 수정자         :   노영래
    -- E-mail       :   0rae0926@gmail.com
    -- 수정일자        :   2016-11-30
	-- ---------------------------------------------------------------
	-- 함수설명            : 숫자를 여러 문자열형식으로 변환해주는 함수입니다.
	-- 예    제            : dbo.fnNumericToString(숫자, 변수)
	--                    : 변수 - S(0소거), Fn/Rn(소수점고정)
  --                    : dbo.fnNumericToString(10.212, 'S')
  --                    : dbo.fnNumericToString(10.212, 'F2')
  -- ---------------------------------------------------------------

  P_NUMERIC   IN NUMBER      DEFAULT 0,
  P_DIV     IN VARCHAR2    DEFAULT ''
)
  RETURN VARCHAR2
AS
  IP_NUMERIC         NUMBER (20, 5) := P_NUMERIC;
  P_MINUSCHECK       CHAR (1);
  P_KIND           CHAR (1);
  P_POINT          NUMBER (10, 0);
  P_INTEGER         NUMBER (20, 5);
  P_INTEGERSTRING      VARCHAR2 (20);
  P_MAGIN          NUMBER (20, 5);
  P_MAGINSTRING       VARCHAR2 (20);
  P_MAGINSTRINGLENGTH    NUMBER (10, 0);
  P_TOSTRING         VARCHAR2 (20);
    P_i                    int := 0;
BEGIN
  P_MINUSCHECK := CASE WHEN IP_NUMERIC < 0 THEN 'Y' ELSE 'N' END;

  IP_NUMERIC := CASE WHEN P_MINUSCHECK = 'Y'
                       THEN NVL (IP_NUMERIC, 0) * -1
                 ELSE NVL (IP_NUMERIC, 0) END;
  P_KIND := SUBSTR (P_DIV, 1, 1);

  P_KIND := CASE NVL(P_KIND, ' ') WHEN ' '
                          THEN 'S'
                          ELSE P_KIND END;

  P_POINT := TO_NUMBER(CASE LENGTH(P_DIV) WHEN 2 THEN SUBSTR (P_DIV, -1, 1) ELSE CASE P_DIV WHEN '1' THEN P_DIV ELSE '5' END END);

  IP_NUMERIC := CASE WHEN P_KIND = 'F'
                       THEN FLOOR (IP_NUMERIC * POWER (10, P_POINT)) * POWER (0.100000, P_POINT)
                       ELSE ROUND (IP_NUMERIC * POWER (10, P_POINT), 0) * POWER (0.100000 , P_POINT) END;

  P_INTEGER := FLOOR (IP_NUMERIC);

  P_INTEGERSTRING := REPLACE(TRIM(TO_CHAR(P_INTEGER,'99,999,999,999,999')), '.00', ' ');

  P_MAGIN := CASE WHEN IP_NUMERIC > 0
                    THEN IP_NUMERIC - P_INTEGER
              ELSE (IP_NUMERIC - P_INTEGER) * -1 END;

  P_MAGINSTRING := REPLACE(TO_CHAR(P_MAGIN), '.', '');

  P_MAGINSTRINGLENGTH := LENGTH (P_MAGINSTRING);

  IF (LENGTH (P_DIV) = 2) THEN
    P_MAGINSTRING := SUBSTR (P_MAGINSTRING || '000000', 0, P_POINT);

  ELSIF (LENGTH (P_DIV) = 1) THEN

        FOR i IN 0.. P_MAGINSTRINGLENGTH LOOP
            IF (SUBSTR (P_MAGINSTRING, -1, 1) = '0') THEN
                P_MAGINSTRING := SUBSTR (P_MAGINSTRING, 0, P_MAGINSTRINGLENGTH - 1);
            END IF;
        END LOOP;

    P_MAGINSTRING := SUBSTR (P_MAGINSTRING, 0, P_POINT);

  END IF;

  P_TOSTRING := P_INTEGERSTRING || '.' || P_MAGINSTRING || '*';
  P_TOSTRING := CASE P_KIND WHEN 'V' THEN REPLACE (REPLACE (REPLACE (REPLACE (REPLACE (REPLACE (P_TOSTRING, '0*', '*'),'0*','*'),'0*','*'),'0*','*'),'0*','*'),'0*','*')
                        WHEN 'S' THEN REPLACE (P_TOSTRING, '.' || LPAD ('0', P_POINT, '0'), ' ')
                        ELSE P_TOSTRING
               END;
  P_TOSTRING := REPLACE (REPLACE (REPLACE (P_TOSTRING, '.*', ' '), '*', ' '), ' ', '');
  P_TOSTRING := CASE WHEN P_MINUSCHECK = 'Y' THEN '-' || P_TOSTRING
                       ELSE P_TOSTRING
                   END;
  P_TOSTRING := CASE WHEN SUBSTR (P_DIV, 0, 1) = 'C' THEN REPLACE (P_TOSTRING, ',', ' ')
                 ELSE P_TOSTRING
               END;
  RETURN (P_TOSTRING);
END;
/
