CREATE FUNCTION DATEDIFF
(
    commomd   IN varchar2,
    startdate IN varchar2,
    enddate   IN varchar2
) RETURN int

IS
  v_value    NUMBER := 0;
    s_date    date;
    e_date    date;
BEGIN
  s_date := TO_DATE(startdate,'YYYY-MM-DD');
    e_date := TO_DATE(enddate,'YYYY-MM-DD');

  IF (UPPER(commomd) = 'DAY' OR UPPER(commomd) = 'D')
  THEN
    v_value := FLOOR(e_date - s_date); -- 일
  ELSIF (UPPER(commomd) = 'MINUTE')
  THEN
    v_value := (e_date - s_date) * 24 * 60;
  ELSIF (UPPER(commomd) = 'SECOND')
  THEN
    v_value := (e_date - s_date) * 24 * 60 * 60;
  ELSIF (UPPER(commomd) = 'M' OR UPPER(commomd) = 'MM' )
  THEN
    v_value := MONTHS_BETWEEN(e_date, s_date);
    ELSIF (UPPER(commomd) = 'MONTH')
    THEN
        v_value := MONTHS_BETWEEN(e_date, s_date);
    ELSIF (UPPER(commomd) = 'YEAR')
    THEN
        v_value := TO_CHAR(e_date, 'YYYY') - TO_CHAR(s_date, 'YYYY') ;

    END IF;

  RETURN v_value;
END;


/*
select datediff('minute',to_date('2016-02-25 17:00:00', 'YYYY-MM-DD hh24:mi:ss'), sysdate) from dual;

select datediff('day',sysdate-2, sysdate) from dual;

select mod(mod(sysdate - to_date('2016-02-25 14:00:00', 'YYYY-MM-DD hh24:mi:ss'),1)*24,1)*60  from dual;

select mod(sysdate - to_date('2016-02-25 14:00:00', 'YYYY-MM-DD hh24:mi:ss'),1)*24* 60 from dual;

select mod(sysdate - to_date('2016-02-25 14:00:00', 'YYYY-MM-DD hh24:mi:ss'),1) from dual;

select mod(mod(sysdate - to_date('2016-02-25 14:00:00', 'YYYY-MM-DD hh24:mi:ss'),1)*24,1) from dual;

select to_char(sysdate-1, 'YYYY-MM-DD hh24:mi:ss')  from dual

select (sysdate - to_date('2016-02-25 14:00:00', 'YYYY-MM-DD hh24:mi:ss')) * 24 * 60 from dual;
*/
/
