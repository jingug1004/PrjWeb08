CREATE PROCEDURE spACacc0118R(
    -- ---------------------------------------------------------------
    -- 프로시저명       : spACacc0118
    -- 작 성 자         : 최기홍
    -- 작성일자         : 2010-12-13
    -- 수 정 자     : 노영래
    -- E-Mail       : 0rae0926@gmail.com
    -- 수정일자      : 2016-12-20
    -- ---------------------------------------------------------------
    -- 프로시저 설명    : 거래처원장 조회하는 프로시저이다.
    -- ---------------------------------------------------------------

    p_div            IN       VARCHAR2 DEFAULT '',
    p_compcode        IN       VARCHAR2 DEFAULT '',
    p_plantcode     IN       VARCHAR2 DEFAULT '',
    p_startdt        IN       VARCHAR2 DEFAULT '',
    p_enddt         IN       VARCHAR2 DEFAULT '',
    p_acccode        IN       VARCHAR2 DEFAULT '',
    p_custcode1     IN       VARCHAR2 DEFAULT '',
    p_custcode2     IN       VARCHAR2 DEFAULT NULL,
    p_outputdiv     IN       VARCHAR2 DEFAULT '',
    p_zero            IN       VARCHAR2 DEFAULT '',
    p_userid        IN       VARCHAR2 DEFAULT '',
    p_reasondiv     IN       VARCHAR2 DEFAULT '',
    p_reasontext    IN       VARCHAR2 DEFAULT '',
    MESSAGE            OUT VARCHAR2,
    IO_CURSOR           OUT TYPES.DATASET
)
AS
    p_odiv1   VARCHAR2(5);
    p_odiv2   VARCHAR2(5);
BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    IF (p_div = 'S')
    THEN
        IF (p_outputdiv = '1')
        THEN
            --K-GAAP
            p_odiv1 := '20';
            p_odiv2 := 'F';
        END IF;

        IF (p_outputdiv = '2')
        THEN
            --IFRS
            p_odiv1 := '30';
            p_odiv2 := 'K';
        END IF;

        OPEN IO_CURSOR FOR
            SELECT     A.*
            FROM     (SELECT   acccode,
                               MAX(accname) accname,
                               mngclucode,
                               mngcluval,
                               MAX(custname) custname,
                               MAX(businessno) businessno,
                               SUM(bsamt) bsamt,
                               SUM(debamt) debamt,
                               SUM(creamt) creamt,
                               SUM(bsamt) + CASE WHEN MAX(dcdiv) = '1' THEN SUM(debamt) - SUM(creamt) ELSE SUM(creamt) - SUM(debamt) END fnamt
                      FROM       (--월집계 해당년월 데이터 가져오기
                                SELECT A.acccode,
                                       b.accname,
                                       b.dcdiv,
                                       A.mngclucode,
                                       A.mngcluval,
                                       NVL(c.custname, A.mngcludec) custname,
                                       c.businessno,
                                       CASE WHEN b.dcdiv = '1' THEN A.bsdebamt - A.bscreamt ELSE A.bscreamt - A.bsdebamt END bsamt, --전기이월
                                       0 debamt,
                                       0 creamt,
                                       0 fnamt
                                FROM   ACORDSMM A
                                       JOIN ACACCM b ON A.acccode = b.acccode
                                       LEFT JOIN CMCUSTM c ON A.mngcluval = c.custcode
                                WHERE  A.compcode = p_compcode
                                       AND A.plantcode LIKE p_plantcode
                                       AND A.acccode LIKE p_acccode || '%'
                                       AND slipym = SUBSTR(p_startdt, 1, 7)
                                       AND (closediv = '10'
                                            OR closediv = p_odiv1) -- 출력구분 [K-GAAP, IFRS]
                                       AND (bsdebamt <> 0
                                            OR bscreamt <> 0
                                            OR debamt <> 0
                                            OR creamt <> 0)
                                       AND A.mngclucode = 'S010'
                                       AND mngcluval BETWEEN NVL(p_custcode1, ' ') AND NVL(p_custcode2, 'ZZZZZZZZZZZZ')
                                UNION ALL
                                --조회시작월 1일부터 종료일까지 데이터 가져오기
                                SELECT A.acccode,
                                       D.accname,
                                       D.dcdiv,
                                       b.mngclucode,
                                       b.mngcluval,
                                       NVL(E.custname, b.mngcludec) custname,
                                       E.businessno,
                                       CASE WHEN p_startdt <= A.slipdate THEN 0 ELSE CASE WHEN D.dcdiv = '1' THEN A.debamt - A.creamt ELSE A.creamt - A.debamt END END bsamt, --전기잔액
                                       CASE WHEN p_startdt <= A.slipdate THEN A.debamt ELSE 0 END debamt,
                                       CASE WHEN p_startdt <= A.slipdate THEN A.creamt ELSE 0 END creamt,
                                       0 fnamt
                                FROM   ACORDD A
                                       JOIN ACORDS b
                                           ON A.compcode = b.compcode
                                              AND A.slipinno = b.slipinno
                                              AND A.slipinseq = b.slipinseq
                                       JOIN ACORDM c
                                           ON b.compcode = c.compcode
                                              AND b.slipinno = c.slipinno
                                       JOIN ACACCM D ON A.acccode = D.acccode
                                       LEFT JOIN CMCUSTM E ON b.mngcluval = E.custcode
                                WHERE  A.compcode = p_compcode
                                       AND A.plantcode LIKE p_plantcode
                                       AND A.slipdate BETWEEN SUBSTR(p_startdt, 1, 7) || '-01' AND p_enddt
                                       AND A.acccode LIKE NVL(p_acccode,'%') || '%'
                                       AND c.slipdiv <> p_odiv2 -- K-GAAP <> 'F', IFRS <> 'K'
                                       AND b.mngclucode = 'S010'
                                       AND NVL(mngcluval,' ') BETWEEN NVL(p_custcode1, ' ') AND NVL(p_custcode2, 'ZZZZZZZZZZZZ')) A
                      GROUP BY acccode, mngclucode, mngcluval) A
            WHERE     (bsamt <> 0
                      OR debamt <> 0
                      OR creamt <> 0)
                     AND (p_zero = 'Y'
                          OR fnamt <> 0)
            ORDER BY acccode, mngclucode, mngcluval NULLS first;
    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
