CREATE FUNCTION        fnSeek
-- ---------------------------------------------------------------
 -- 함 수 명            : fnSeek
 -- 작 성 자         : 최인범
 -- 작성일자         : 2007-10-26
 -- ---------------------------------------------------------------
 -- 함수설명            : 코드헬프 전용함수
 -- ---------------------------------------------------------------

(
    p_empcode       IN VARCHAR2 DEFAULT '' ,--사용자
    p_table         IN VARCHAR2 DEFAULT '' ,--검색테이블
    p_tablekey      IN VARCHAR2 DEFAULT '' ,--테이블키(복수일 경우 조합)
    p_tablecoloums  IN VARCHAR2 DEFAULT '' ,--컬럼배열
    p_coloumsetting IN VARCHAR2 DEFAULT '' 
)
RETURN VARCHAR2
AS
   p_tostring VARCHAR2(8000) := '';

 --컬럼속성배열
BEGIN
/*  
 p_tostring := '    select    case when favoritykey1 is null then ''N'' else ''Y'' end as ''√'', 
                               ' || LPAD(' ', 1, ' ') || p_tablecoloums || LPAD(' ', 1, ' ') || '
                               from ' || p_table || LPAD(' ', 1, ' ') || '
                                       left join (select favoritykey1 from sysseekfavority where empcode = ''' || p_empcode || ''' and seektable = ''' || p_table || ''') a
                                       on ' || p_tablekey || ' = favoritykey1
                               where    ' || p_tablekey || ' = ' || p_tablekey || ' ' ;
*/

p_tostring := 
                'SELECT CASE WHEN favoritykey1 IS NULL THEN ''N'' ELSE ''Y'' END "√"' 
                ||LPAD(' ', 1, ' ') || ', ' || p_tablecoloums || LPAD(' ', 1, ' ') 
                ||'FROM ' || p_table || LPAD(' ', 1, ' ') || 
                'LEFT JOIN (SELECT favoritykey1 FROM sysseekfavority WHERE  EMPCODE = ''' || p_empcode || ''' AND seektable = ''' || p_table || ''') a ON ' || p_tablekey || ' = favoritykey1
                WHERE ' || p_tablekey || ' = ' || p_tablekey || ' ' ;
                            
   RETURN (p_tostring);

EXCEPTION WHEN OTHERS THEN RETURN NULL;
END;
/
