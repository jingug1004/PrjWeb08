CREATE FUNCTION fnMakeNoTest2
-- ---------------------------------------------------------------
 -- 함수명           : fnMakeRequestNo2
 -- 작 성 자         : 이세민
 -- 작성일자         : 2007-10-19
 -- 수 정 자         : 임정호
 -- 수정일자         : 2017-01-12
 -- ---------------------------------------------------------------
 -- 함수 설명        : 품질관리 관련 번호를 생성하는 함수이다.
 -- ---------------------------------------------------------------

(
  p_requestdate IN VARCHAR2,
  p_testdiv IN VARCHAR2,
  p_testdiv2 IN VARCHAR2
)
RETURN VARCHAR2
AS
   p_headervalue  VARCHAR2(10);--시험의뢰번호의 앞머리 글자 저장
   p_bodyvalue  VARCHAR2(10);--시험의뢰번호의 구성값저장
   p_bodyvalue2  VARCHAR2(10);--시험의뢰번호의 구성형식결정
   p_nolength NUMBER(10,0);--시험의뢰번호 구성 일련번호길이 결정
   p_return VARCHAR2(20);--생성된 시험의뢰번호

BEGIN
   /*
   01	원료시험				=> 원료
   02	자재시험				=> 자재
   03	반제품시험			=> 공정	: 순번대로 번호 부여
   04	완제품시험			=> 포장제품 : 동일순번대로 부여
   05	밸리데이션 시험		=> 없음
   06	제조용수시험			=> 정제수 (PW), 주사용수(WFI)
   07	환경모니터링시험		=> 없음
   08	안정성시험			=> 없음
   09	반품시험				=> ???
   10	기타시험				=> 없음
   11	원료재시험			=> 원료
   */
   p_headervalue := (CASE
                          WHEN NVL(p_testdiv, ' ') = '01' THEN 'R'              --원료시험
                          WHEN NVL(p_testdiv, ' ') = '02' THEN 'M'              --자재시험
                          WHEN NVL(p_testdiv, ' ') = '03' THEN 'I'              --반제품시험
                          WHEN NVL(p_testdiv, ' ') = '04' THEN 'I'              --완제품시험
                          WHEN NVL(p_testdiv, ' ') = '06' THEN  p_testdiv2      --정제수시험
                          WHEN NVL(p_testdiv, ' ') = '09' THEN 'B'              --반품시험
                          WHEN NVL(p_testdiv, ' ') = '11' THEN 'R'              --원료재시험
                          ELSE 'S'
                    END) ;                                                      --특별시험


   --시험의뢰번호의 구성형식과 일련번호 길이를 결정한다.
   IF ( p_testdiv IN ( '03','04' ) ) THEN
      p_bodyvalue := 'C6' ;
      p_nolength := '4' ;
   ELSE
      p_bodyvalue := 'C6' ;
      p_nolength := '3' ;
   END IF;
   --시험의뢰번호 구성형식에 따라 구성값을 설정한다.
   p_bodyvalue2 := (CASE
                         WHEN p_bodyvalue = 'C1' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 1, 8 )--yyyymmdd
                         WHEN p_bodyvalue = 'C2' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 1, 4 )--yyyy
                         WHEN p_bodyvalue = 'C3' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 1, 6 )--yyyymm
                         WHEN p_bodyvalue = 'C4' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 3, 2 )--yy
                         WHEN p_bodyvalue = 'C5' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 3, 4 )--yymm
                         WHEN p_bodyvalue = 'C6' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 4, 6 )--ymmdd
                         WHEN p_bodyvalue = 'C7' THEN SUBSTR(REPLACE(p_requestdate, '-', ''), 5, 4) --mmdd
                         ELSE SUBSTR(REPLACE(p_requestdate, '-', ''), 1, 8)
                    END) ;--yyyymmdd
   IF ( p_testdiv IN ( '03','04' ) ) THEN
      --생성 이전의 시험번호를 불러와 다음 시험번호를 생성해준다.
       FOR  rec IN (
                        SELECT     NVL(p_headervalue, '' ) --앞머리 글자
                                || NVL(p_bodyvalue2, '' )  --중간구성값결정
                                || CASE WHEN p_nolength = '0' THEN '' ELSE '-' END
                                || SUBSTR( TRIM(LPAD(' ',51 ,'0')) || NVL(TO_CHAR(MAX(REPLACE(SUBSTR(TESTNO,8,P_NOLENGTH),'-',''))+1),'0001') ,  -P_NOLENGTH) -- 최신 시험의뢰번호 다음번호생성
                                || '-' || p_testdiv2  AS alias1
                        FROM    TestManage
                        WHERE   testrequestno LIKE NVL(p_headervalue, ' ') || NVL(SUBSTR(p_bodyvalue2, 0, 3), ' ') || '%'
                            AND LENGTH(testrequestno) = 13
                    )
        LOOP
            p_return := rec.alias1   ;
        END LOOP;
   ELSE
      --생성 이전의 시험번호를 불러와 다음 시험번호를 생성해준다.
       FOR  rec IN (
                        SELECT      NVL(p_headervalue, '' ) --앞머리 글자
                                ||  NVL(p_bodyvalue2, '' )--중간구성값결정
                                ||  CASE WHEN p_nolength = '0' THEN '' ELSE '-' END
                                ||  SUBSTR(TRIM(LPAD(' ',51 ,'0')) || NVL(MAX(SUBSTR(testno, -p_nolength ))+1,'001'),  -p_nolength) AS alias1 -- 최신 시험의뢰번호 다음번호생성
                        FROM    TestManage
                        WHERE   testrequestno LIKE NVL(p_headervalue, ' ') || NVL(SUBSTR(p_bodyvalue2, 0, p_nolength), ' ') || '%'
                    )
        LOOP
            p_return := rec.alias1   ;
        END LOOP;
   END IF;

   RETURN (p_return);

EXCEPTION WHEN OTHERS THEN RETURN NULL;
END;
/
