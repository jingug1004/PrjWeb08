CREATE FUNCTION zhana_crypt(
    -- ---------------------------------------------------------------
    -- 함 수 명   : zhana_encrypt
    -- 작 성 자         :
    -- 작성일자         :
    -- 수 정 자       :   김태안
    -- 수정일자        :   2017-09-29
    -- ---------------------------------------------------------------
    -- 함수설명   : 하나제약 암호화
    -- p_calltype : 호출구분 E -암호화 D-복호화
    --p_data :암호 또는 복호화할 문자
    -- ---------------------------------------------------------------
    p_calltype VARCHAR2
   ,p_data VARCHAR2
)
    RETURN VARCHAR2
AS
    p_return   VARCHAR(100);
BEGIN

    if p_calltype = 'E' then
      select SYS.PKG_ENCRYPT_DECRYPT.ENCRYPT(p_data,'hanapharm') into p_return from dual;
    elsif p_calltype = 'D' then
      select SYS.PKG_ENCRYPT_DECRYPT.DECRYPT(p_data,'hanapharm') into p_return from dual;
    end if;

    RETURN (p_return);
EXCEPTION
    WHEN OTHERS    THEN
        p_return := '';
END;
/
