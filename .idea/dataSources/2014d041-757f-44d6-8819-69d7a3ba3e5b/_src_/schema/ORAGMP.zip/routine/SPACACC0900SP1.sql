CREATE PROCEDURE        spACacc0900SP1
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0900SP1
 -- 작 성 자         : 최용석
 -- 작성일자         : 2011-12-13
 -- 수 정 자         : 임 정호
 -- 작성일자         : 2016-12-19
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 매출전표로드
 -- ---------------------------------------------------------------

(
  p_div IN VARCHAR2 DEFAULT '' ,
  p_compcode IN VARCHAR2 DEFAULT '' ,
  p_plantcode IN VARCHAR2 DEFAULT '' ,
  p_sdt IN VARCHAR2 DEFAULT '' ,
  p_edt IN VARCHAR2 DEFAULT '' ,
  p_loadstatus IN VARCHAR2 DEFAULT '' ,
  p_custcode IN VARCHAR2 DEFAULT '' ,
  p_taxno IN VARCHAR2 DEFAULT '' ,
  p_iempcode IN VARCHAR2 DEFAULT '' ,
  p_userid IN VARCHAR2 DEFAULT '' ,
  p_reasondiv IN VARCHAR2 DEFAULT '' ,
  p_reasontext IN VARCHAR2 DEFAULT '' ,
  IO_CURSOR      OUT TYPES.DataSet,
  message OUT VARCHAR2

)
AS
    v_temp NUMBER(1, 0) := 0;
    ip_taxno VARCHAR2(20) :=p_taxno;
    p_setplant VARCHAR2(4);
    p_crtdate VARCHAR2(8);
    p_crttime VARCHAR2(8);
    p_crtseq NUMBER(10,0);
    p_crttyp VARCHAR2(8);
    p_orderno VARCHAR2(20);
    p_orderseq NUMBER(10,0);
    p_deptcode VARCHAR2(20);




BEGIN

    MESSAGE := '데이터 확인';
    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    SELECT COUNT(*) INTO v_temp
    FROM DUAL
    WHERE EXISTS (
                    SELECT  *
                    FROM    CMCLOSEM
                    WHERE   compcode = p_compcode
                        AND closeym BETWEEN SUBSTR(p_sdt, 0, 7) AND SUBSTR(p_edt, 0, 7)
                        AND accdiv = 'S'
                        AND apprcloseyn = 'Y'
                );


    IF v_temp = 1 THEN

        IF (IO_CURSOR IS NULL) THEN
          OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
        END IF;

        RETURN;
    END IF;



    IF ( p_div = 'S' ) THEN
        SPINTERFACEDOWNLOAD(p_div => 'E_CUSTMASTER') ;
        MERGE INTO E_SLTAXD TG
             USING (SELECT A.CRTDATE,A.CRTTIME,A.CRTSEQ, b.orderseq
                      FROM E_SLTAXD A
                           JOIN
                           (SELECT crtdate,
                                   crttime,
                                   crtseq,
                                   ROW_NUMBER ()
                                   OVER (PARTITION BY taxno, orderno
                                         ORDER BY orderseq, salqty DESC)
                                      orderseq
                              FROM E_SLTAXD
                             WHERE E_SLTAXD.STATUS = 'N') b
                              ON     A.crtdate = b.crtdate
                                 AND A.crttime = b.crttime
                                 AND A.crtseq = b.crtseq) SRC
                ON (TG.CRTDATE=SRC.CRTDATE AND TG.CRTTIME=SRC.CRTDATE AND TG.CRTSEQ=SRC.CRTDATE)
        WHEN MATCHED THEN
           UPDATE SET ORDERSEQ = SRC.ORDERSEQ;

        FOR  rec IN
        (
            SELECT  MIN(plantcode)   AS alias1
            FROM    CMPLANTM
        )
        LOOP
            p_setplant := rec.alias1   ;
        END LOOP;


        FOR REC IN
        (
            SELECT  crtdate , crttime , crtseq , crttyp , taxno
            FROM    E_SLTAXM
            WHERE   STATUS = 'N'
            ORDER BY crtdate, crttime, crtseq
        )
        LOOP
            P_CRTDATE := REC.crtdate;
            P_CRTTIME := REC.crttime;
            P_CRTSEQ  := REC.crtseq;
            P_CRTTYP  := REC.crttyp;
            IP_TAXNO  := REC.taxno;


            v_temp := 0;

            SELECT COUNT(*) INTO v_temp
            FROM DUAL
            WHERE EXISTS    (
                                SELECT  *
                                FROM    SLTAXM
                                WHERE   taxno = ip_taxno
                            );


            IF v_temp = 1 THEN
                p_crttyp := 'U' ;
            END IF;

            IF p_crttyp = 'I' THEN

           -- 처리상태가 'I'인데 이미 계산서가 존재하는 경우
                MERGE INTO E_SLTAXM TG
                USING ( SELECT A.CRTDATE,A.CRTTIME, A.CRTSEQ, 'E', '계산서번호 중복' AS pos_3
                        FROM E_SLTAXM A JOIN SLTAXM b
                            ON      p_setplant = b.plantcode
                                AND A.taxno = b.taxno
                        WHERE A.crtdate = p_crtdate
                          AND A.crttime = p_crttime
                          AND A.crtseq = p_crtseq) src
                    ON (TG.CRTDATE =SRC.CRTDATE AND TG.CRTTIME=SRC.CRTTIME AND TG.CRTSEQ =SRC.CRTSEQ )
                WHEN MATCHED THEN
                UPDATE SET STATUS = 'E',
                           remarks = pos_3;

                IF SQL%ROWCOUNT = 0 THEN
                    INSERT INTO SLTAXM
                                        (   plantcode, taxno, custcode, taxdiv, taxcode, taxdt, saldiv,
                                            businessno, custcondition, custitem, ceoname, telno, post,
                                            addr1, addr2, addr, itemnm, salamt, salvat, totamt, loadyn,
                                            deleteyn, remark, purposediv, biznodiv, insertdt, iempcode )
                    (               SELECT  p_setplant ,
                                            A.TAXNO ,
                                            A.CUSTCODE ,
                                            NVL(b.taxdiv, '1') ,
                                            CASE
                                                WHEN A.VAT <> 0 THEN '1'
                                                WHEN A.CUSTCODE = '890001' THEN '4'
                                                ELSE '3'
                                            END col  ,
                                            FNstuff(FNstuff(A.TAXDATE, 5, 0, '-'), 8, 0, '-') ,
                                            '%' ,
                                            FNstuff(FNstuff(A.BUSINESSNO, 4, 0, '-'), 7, 0, '-') ,
                                            A.CUSTCONDITION ,
                                            A.CUSTITEM ,
                                            NVL(b.ceoname, '') ,
                                            NVL(b.telno, '') ,
                                            NVL(b.post, '') ,
                                            NVL(b.addr1, '') ,
                                            NVL(b.addr2, '') ,
                                            NVL(b.addr1, '') || NVL(b.addr2, '') ,
                                            A.REMARK ,
                                            A.AMT ,
                                            A.VAT ,
                                            A.AMT + A.VAT ,
                                            A.ELECTAXYN ,
                                            'N' ,
                                            '' ,
                                            '2' ,
                                            CASE
                                                WHEN LENGTH(A.BUSINESSNO) = 10 THEN '01'
                                                ELSE '02'
                                            END col  ,
                                            SYSDATE ,
                                            p_iempcode
                                    FROM    E_SLTAXM A
                                            LEFT JOIN CMCUSTM b   ON A.CUSTCODE = b.custcode
                                    WHERE  A.CRTDATE = p_crtdate
                                       AND A.CRTTIME = p_crttime
                                       AND A.CRTSEQ = p_crtseq
                    );
                    UPDATE  E_SLTAXM A
                        SET STATUS = 'Y'
                    WHERE   A.crtdate = p_crtdate
                        AND A.crttime = p_crttime
                        AND A.crtseq = p_crtseq;
                END IF;
            ELSIF p_crttyp = 'U' THEN
                -- 처리상태가 'U' 인데 계산서가 존재하는 않는경우
                MERGE INTO E_SLTAXM TG
                    USING  (
                                SELECT  A.CRTDATE, A.CRTTIME, A.CRTSEQ,
                                        'E', '계산서번호 없음' AS pos_3
                                FROM    E_SLTAXM A LEFT JOIN SLTAXM b
                                        ON  p_setplant = b.plantcode
                                        AND A.taxno = b.taxno
                                WHERE A.crtdate = p_crtdate
                                  AND A.crttime = p_crttime
                                  AND A.crtseq = p_crtseq
                                  AND b.taxno IS NULL
                            ) src
                        ON (TG.CRTDATE=SRC.CRTDATE AND TG.CRTTIME=SRC.CRTTIME AND TG.CRTSEQ=SRC.CRTSEQ  )
                WHEN MATCHED THEN
                    UPDATE SET STATUS = 'E',
                              REMARKS = POS_3;

                IF SQL%ROWCOUNT = 0 THEN

                    MERGE INTO SLTAXM TG
                        USING   (
                                    SELECT  B.PLANTCODE,B.TAXNO,
                                            A.custcode, NVL(c.taxdiv, '1') AS pos_3,
                                            CASE
                                                WHEN A.vat <> 0 THEN '1'
                                                WHEN A.custcode = '890001' THEN '4'
                                                ELSE '3'
                                            END AS pos_4,
                                            FNstuff(FNstuff(A.taxdate, 5, 0, '-'), 8, 0, '-') AS pos_5,
                                            FNstuff(FNstuff(A.businessno, 4, 0, '-'), 7, 0, '-') AS pos_6,
                                            A.custcondition,
                                            A.custitem,
                                            NVL(c.ceoname, '') AS pos_9,
                                            NVL(c.telno, '') AS pos_10,
                                            NVL(c.post, '') AS pos_11,
                                            NVL(c.addr1, '') AS pos_12,
                                            NVL(c.addr2, '') AS pos_13,
                                            NVL(c.addr1, '') || NVL(c.addr2, '') AS pos_14,
                                            A.remark,
                                            A.amt,
                                            A.vat,
                                            A.amt + A.vat AS pos_18,
                                            A.electaxyn,
                                            CASE
                                                WHEN LENGTH(A.businessno) = 10 THEN '01'
                                                ELSE '02'
                                            END AS pos_20,
                                            SYSDATE,
                                            p_iempcode
                                    FROM    E_SLTAXM A JOIN SLTAXM b
                                                ON      p_setplant = b.plantcode
                                                    AND A.taxno = b.taxno
                                            LEFT JOIN CMCUSTM c
                                                ON A.custcode = c.custcode
                                    WHERE   A.crtdate = p_crtdate
                                        AND A.crttime = p_crttime
                                        AND A.crtseq = p_crtseq ) src
                        ON  ( TG.PLANTCODE=SRC.PLANTCODE AND TG.TAXNO=SRC.TAXNO)
                    WHEN MATCHED THEN
                    UPDATE SET   TG.CUSTCODE = SRC.CUSTCODE,
                              TG.TAXDIV = SRC.POS_3,
                              TG.TAXCODE =SRC.POS_4,
                              TG.TAXDT = SRC.POS_5,
                              TG.BUSINESSNO = SRC.POS_6,
                              TG.CUSTCONDITION = SRC.CUSTCONDITION,
                              TG.CUSTITEM = SRC.CUSTITEM,
                              TG.CEONAME = SRC.POS_9,
                              TG.TELNO = SRC.POS_10,
                              TG.POST = SRC.POS_11,
                              TG.ADDR1 = SRC.POS_12,
                              TG.ADDR2 = SRC.POS_13,
                              TG.ADDR = SRC.POS_14,
                              TG.ITEMNM = SRC.REMARK,
                              TG.SALAMT = SRC.AMT,
                              TG.SALVAT = SRC.VAT,
                              TG.TOTAMT = SRC.POS_18,
                              TG.LOADYN = SRC.ELECTAXYN,
                              TG.BIZNODIV = SRC.POS_20,
                              TG.UPDATEDT = SYSDATE,
                              TG.UEMPCODE = P_IEMPCODE;

                    UPDATE  E_SLTAXM A
                        SET STATUS = 'Y'
                    WHERE   A.CRTDATE = P_CRTDATE
                        AND A.CRTTIME = P_CRTTIME
                        AND A.CRTSEQ = P_CRTSEQ;
                END IF;


            ELSIF p_crttyp = 'D' THEN

                -- 처리상태가 'D' 인데 계산서가 존재하는 않는경우
                MERGE INTO E_SLTAXM TG
                    USING  (
                                SELECT  A.CRTDATE, A.CRTTIME, A.CRTSEQ
                                FROM    E_SLTAXM A
                                        LEFT JOIN SLTAXM B
                                            ON      P_SETPLANT = B.PLANTCODE
                                                AND A.TAXNO = B.TAXNO
                                WHERE   A.CRTDATE = P_CRTDATE
                                    AND A.CRTTIME = P_CRTTIME
                                    AND A.CRTSEQ = P_CRTSEQ
                                    AND B.TAXNO IS NULL) SRC
                        ON (TG.CRTDATE=SRC.CRTDATE AND TG.CRTTIME=SRC.CRTTIME AND TG.CRTSEQ=SRC.CRTSEQ )
                WHEN MATCHED THEN
                    UPDATE SET TG.STATUS = 'E',
                              TG.REMARKS = '계산서번호 없음';

                IF SQL%ROWCOUNT = 0 THEN
                    DELETE SLTAXM TG
                    WHERE (TG.PLANTCODE, TG.TAXNO) IN
                                                            (
                                                                SELECT  B.PLANTCODE, B.TAXNO
                                                                FROM    E_SLTAXM A
                                                                        JOIN SLTAXM b
                                                                            ON      p_setplant = b.plantcode
                                                                                AND A.taxno = b.taxno
                                                                WHERE  A.crtdate = p_crtdate
                                                                    AND A.crttime = p_crttime
                                                                    AND A.crtseq = p_crtseq
                                                            );
                    UPDATE  E_SLTAXM A
                        SET STATUS = 'Y'
                    WHERE  A.crtdate = p_crtdate
                        AND A.crttime = p_crttime
                        AND A.crtseq = p_crtseq;
                END IF;

            END IF;

--            FETCH tax_cursor1 INTO p_crtdate,p_crttime,p_crtseq,p_crttyp,ip_taxno;


        END LOOP;


        FOR REC IN
        (
            SELECT crtdate , crttime , crtseq , crttyp , taxno , orderno , orderseq
            FROM E_SLTAXD
            WHERE  STATUS = 'N'
            ORDER BY crtdate, crttime, crtseq
        )
        LOOP

            p_crtdate := rec.crtdate;
            p_crttime := rec.crttime;
            p_crtseq  := rec.crtseq;
            p_crttyp  := rec.crttyp;
            ip_taxno  := rec.taxno;
            p_orderno := rec.orderno;
            p_orderseq:= rec.orderseq;

            v_temp := 0;

            SELECT COUNT(*) INTO v_temp
            FROM DUAL
            WHERE EXISTS ( SELECT *
                       FROM SLTAXD
                        WHERE  taxno = p_taxno
                                 AND orderno = p_orderno
                                 AND orderseq = p_orderseq );
            IF v_temp = 1 THEN
                p_crttyp := 'U' ;
            END IF;

            IF p_crttyp = 'I' THEN
               -- 처리상태가 'I'인데 이미 계산서가 존재하는 경우
                MERGE INTO E_SLTAXD TG
                USING   (
                            SELECT A.CRTDATE, A.CRTTIME, A.CRTSEQ
                            FROM    E_SLTAXD A
                                    JOIN SLTAXD b
                                        ON      p_setplant = b.plantcode
                                            AND A.taxno = b.taxno
                                            AND A.orderno = b.orderno
                                            AND A.orderseq = b.orderseq
                            WHERE A.crtdate = p_crtdate
                              AND A.crttime = p_crttime
                              AND A.crtseq = p_crtseq) src
                    ON ( TG.CRTDATE=SRC.CRTDATE AND TG.CRTTIME=SRC.CRTTIME AND TG.CRTSEQ=SRC.CRTSEQ )
                WHEN MATCHED THEN
                    UPDATE
                        SET     TG.STATUS = 'E',
                                TG.REMARKS = '주문번호 중복';

                IF SQL%ROWCOUNT = 0 THEN

                    INSERT INTO SLTAXD
                                            ( plantcode, taxno, orderno, orderseq, itemcode, salqty, price,
                                              salamt, salvat, purprc, puramt, insertdt, iempcode )
                            (       SELECT  p_setplant , A.TAXNO , A.ORDERNO , A.ORDERSEQ , A.ITEMCODE ,
                                            A.SALQTY , A.PRICE , A.SALAMT , A.SALVAT , 0 , 0 , SYSDATE ,p_iempcode
                                    FROM    E_SLTAXD A
                                            LEFT JOIN CMITEMM b
                                                ON  A.ITEMCODE = b.itemcode
                                    WHERE   A.CRTDATE = p_crtdate
                                        AND A.CRTTIME = p_crttime
                                        AND A.CRTSEQ = p_crtseq
                            );
                    UPDATE  E_SLTAXD A
                        SET STATUS = 'Y'
                    WHERE   A.crtdate = p_crtdate
                        AND A.crttime = p_crttime
                        AND A.crtseq = p_crtseq;
               END IF;

            ELSIF p_crttyp = 'U' THEN
                  -- 처리상태가 'U' 인데 계산서가 존재하는 않는경우
                MERGE INTO E_SLTAXD TG
                    USING (
                            SELECT  A.CRTDATE, A.CRTTIME,A.CRTSEQ
                            FROM    E_SLTAXD A
                                    LEFT JOIN SLTAXD B
                                        ON  P_SETPLANT = B.PLANTCODE
                                        AND A.TAXNO = B.TAXNO
                                        AND A.ORDERNO = B.ORDERNO
                                        AND A.ORDERSEQ = B.ORDERSEQ
                            WHERE   A.CRTDATE = P_CRTDATE
                                AND A.CRTTIME = P_CRTTIME
                                AND A.CRTSEQ = P_CRTSEQ
                                AND B.TAXNO IS NULL) SRC
                        ON ( TG.CRTDATE=SRC.CRTDATE AND TG.CRTTIME=SRC.CRTTIME AND TG.CRTSEQ=SRC.CRTSEQ )
                    WHEN MATCHED THEN
                         UPDATE
                            SET     TG.STATUS = 'E',
                                    TG.REMARKS = '주문번호 없음';

                IF SQL%ROWCOUNT = 0 THEN

                    MERGE INTO SLTAXD TG
                        USING   (
                                    SELECT  B.PLANTCODE, B.TAXNO, B.ORDERNO, B.ORDERSEQ,
                                            A.itemcode, A.salqty, A.price, A.salamt, A.salvat, SYSDATE, p_iempcode
                                    FROM    E_SLTAXD A
                                            JOIN SLTAXD b
                                                ON      p_setplant = b.plantcode
                                                    AND A.taxno = b.taxno
                                                    AND A.orderno = b.orderno
                                                    AND A.orderseq = b.orderseq
                                            LEFT JOIN CMITEMM c
                                                ON      A.itemcode = c.itemcode
                                    WHERE   A.crtdate = p_crtdate
                                        AND A.crttime = p_crttime
                                        AND A.crtseq = p_crtseq
                                ) src
                            ON ( TG.PLANTCODE=SRC.PLANTCODE AND TG.TAXNO=SRC.TAXNO AND TG.ORDERNO=SRC.ORDERNO AND TG.ORDERSEQ=SRC.ORDERSEQ )
                    WHEN MATCHED THEN
                         UPDATE
                            SET   TG.ITEMCODE = SRC.ITEMCODE,
                                  TG.SALQTY = SRC.SALQTY,
                                  TG.PRICE = SRC.PRICE,
                                  TG.SALAMT = SRC.SALAMT,
                                  TG.SALVAT = SRC.SALVAT,
                                  TG.UPDATEDT = SYSDATE,
                                  TG.UEMPCODE = P_IEMPCODE;

                    UPDATE E_SLTAXD A
                        SET STATUS = 'Y'
                    WHERE   A.crtdate = p_crtdate
                        AND A.crttime = p_crttime
                        AND A.crtseq = p_crtseq;
                END IF;


            ELSIF p_crttyp = 'D' THEN
                     -- 처리상태가 'D' 인데 계산서가 존재하는 않는경우
                MERGE INTO E_SLTAXD TG
                    USING   (
                            SELECT  A.CRTDATE, A.CRTTIME, A.CRTSEQ,
                                    'E', '주문번호 없음' AS pos_3
                            FROM    E_SLTAXD A
                                    LEFT JOIN SLTAXD b
                                        ON      p_setplant = b.plantcode
                                            AND A.taxno = b.taxno
                                            AND A.orderno = b.orderno
                                            AND A.orderseq = b.orderseq
                            WHERE   A.crtdate = p_crtdate
                               AND A.crttime = p_crttime
                               AND A.crtseq = p_crtseq
                               AND b.taxno IS NULL) src
                     ON ( TG.CRTDATE=SRC.CRTDATE AND TG.CRTTIME=SRC.CRTTIME AND TG.CRTSEQ=SRC.CRTSEQ  )
                     WHEN MATCHED THEN UPDATE
                        SET TG.STATUS = 'E',
                            TG.remarks = pos_3;
                IF SQL%ROWCOUNT = 0 THEN

                    DELETE FROM SLTAXD TG
                    WHERE (TG.PLANTCODE, TG.TAXNO,TG.ORDERNO,TG.ORDERSEQ) IN
                                                                                (   SELECT  B.PLANTCODE, B.TAXNO,B.ORDERNO,B.ORDERSEQ
                                                                                    FROM    E_SLTAXD A
                                                                                            JOIN SLTAXD b
                                                                                                ON      p_setplant = b.plantcode
                                                                                                    AND A.taxno = b.taxno
                                                                                                    AND A.orderno = b.orderno
                                                                                                    AND A.orderseq = b.orderseq
                                                                                    WHERE   A.crtdate = p_crtdate
                                                                                        AND A.crttime = p_crttime
                                                                                        AND A.crtseq = p_crtseq );
                    UPDATE E_SLTAXD A
                        SET STATUS = 'Y'
                    WHERE  A.crtdate = p_crtdate
                        AND A.crttime = p_crttime
                        AND A.crtseq = p_crtseq;
                END IF;


            END IF;

        END LOOP;



    END IF;

    IF ( p_div = 'S' OR p_div = 'loadall' ) THEN
      -- 이-글벳 부서구분

        FOR  rec IN
        (
            SELECT fnGetColDeptCode(deptcode)  AS alias1
            FROM CMEMPM
            WHERE  empcode = p_iempcode
        )
        LOOP
            p_deptcode := rec.alias1   ;
        END LOOP;



        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0900SP_DUAL';

        INSERT INTO VGT.TT_ACACC0900SP_DUAL
        ( SELECT p_compcode compcode  ,
                 'N' chk  ,
                 SUBSTR(b.taxdt, 1, 7) yymm ,-- 처리월
                 A.plantcode ,-- 사업장
                 b.taxdt appdate ,-- 세금계산서 일자
                 b.taxno taxno ,-- 세금계산서 번호
                 CASE
                      WHEN b.taxcode = '3' THEN '102' -- 매출-영세	계산서구분 AC60

                      WHEN b.taxcode = '4' THEN '104' -- 매출-수출
                 ELSE '101'
                    END taxdiv ,-- 매출-과세
                 '02' iotaxdiv ,-- 매입매출구분 AC61
                 b.ordernm ordno ,-- 주문번호
                 b.custcode custcode ,-- 거래처코드
                 NVL(c.custname, '') custname ,-- 거래처명
                 b.businessno businessno ,-- 사업자번호
                 NVL(b.ceoname, '') ceoname ,-- 거래처ceo
                 NVL(b.telno, '') telno ,-- 전화번호
                 NVL(b.post, '') post ,-- 우편번호
                 NVL(b.addr1, '') addr1 ,-- 주소1
                 NVL(b.addr2, '') addr2 ,-- 주소2
                 NVL(b.addr, '') addr ,-- 주소
                 NVL(E.deptcode, '') deptcode ,-- 부서코드
                 NVL(D.deptname, '') deptname ,-- 부서명
                 NVL(E.empcode, '') empcode ,-- 사원
                 NVL(E.empname, '') empname ,-- 사원명
                 b.itemnm itemnm ,-- 제품명
                 A.amt1 salamt1 ,-- 제품공급가액/매출할인
                 A.amt2 salamt2 ,-- 상품공급가액
                 A.amt1 + A.amt2 salamt ,-- 공급가액
                 A.vat salvat ,-- 부가세액
                 A.totamt totamt ,-- 합계금액
                 b.loadyn loadyn ,-- 전자세금계산서
                 '1' actrnstate ,-- 로드상태코드 1신규, 2완료 3수정, 4삭제
                 CASE
                      WHEN b.taxcode = '3' THEN 'S01003' -- 로컬수출
                      WHEN b.taxcode = '4' THEN 'S01004' -- 직수출
                      WHEN b.saldiv = 'M' THEN 'S01002' -- 매출할인
                      WHEN b.biznodiv <> '01' THEN 'S01005' -- 사원판매
                 ELSE 'S01001'
                    END autorulecode ,-- 일반매출
                 '신규로드전송전' acctrnchk ,-- 로드상태
                 '' slipinno ,-- 전표번호
                 'N' taxloadyn ,-- 계산서생성여부
                 '전송 필요' taxloadtatus ,-- 계산서생성여부명
                 'N' newchk -- 신규생성여부
          FROM ( SELECT A.plantcode ,
                        A.taxno ,
                        SUM(NVL(b.salamt, A.salamt))  amt  ,
                        SUM(CASE
                                 WHEN NVL(D.filter1, '05') <> '05' THEN NVL(b.salamt, A.salamt)
                            ELSE 0
                               END)  amt1  ,
                        SUM(CASE
                                 WHEN NVL(D.filter1, '05') = '05' THEN NVL(b.salamt, A.salamt)
                            ELSE 0
                               END)  amt2  ,
                        SUM(NVL(b.salvat, A.salvat))  vat  ,
                        SUM(NVL(b.salamt + b.salvat, A.salamt + A.salvat))  totamt
                 FROM   SLTAXM A
                        LEFT JOIN SLTAXD b
                            ON      A.plantcode = b.plantcode
                                AND A.taxno = b.taxno
                        LEFT JOIN CMITEMM c
                            ON      b.itemcode = c.itemcode
                        LEFT JOIN CMCOMMONM D
                            ON      D.cmmcode = 'CMM01'
                                AND c.itemdiv = D.divcode
                  WHERE  A.plantcode LIKE p_plantcode
                    AND  A.taxdt BETWEEN p_sdt AND p_edt
                    GROUP BY A.plantcode,A.taxno
                ) A
                JOIN SLTAXM b
                    ON      A.plantcode = b.plantcode
                        AND A.taxno = b.taxno
                LEFT JOIN CMCUSTM c   ON b.custcode = c.custcode
                LEFT JOIN CMEMPM E   ON E.empcode = p_iempcode
                LEFT JOIN CMDEPTM D   ON D.deptcode = E.deptcode
          WHERE  NVL(fnGetColDeptCode(E.deptcode),' ') = NVL(p_deptcode,' ') );

        -- 전송완료상태 데이터 확인
        MERGE INTO VGT.TT_ACACC0900SP_DUAL TG
            USING (
                    SELECT  A.COMPCODE, A.APPDATE, A.TAXNO,
                            CASE
                                WHEN b.actrnstate = '1' OR TRIM(b.slipinno) IS NULL THEN '로드완료전표처리전'
                                WHEN TRIM(b.slipinno) IS NOT NULL AND b.slipinno = c.slipinno THEN '회계처리완료'
                                WHEN TRIM(b.slipinno) IS NOT NULL AND TRIM(c.slipinno) IS NULL THEN '신규:회계전표삭제재전송'
                                ELSE '회계처리완료'
                            END AS pos_2,
                            CASE WHEN b.actrnstate = '1' OR TRIM(b.slipinno)IS NULL THEN '2'
                                 WHEN TRIM(b.slipinno) IS NOT NULL AND b.slipinno = c.slipinno THEN '2'
                                 WHEN TRIM(b.slipinno) IS NOT NULL AND TRIM(c.slipinno) IS NULL THEN '3'
                                 ELSE '2'
                            END AS pos_3,
                            TRIM(b.slipinno) AS pos_4,
                            CASE WHEN TRIM(b.slipinno) IS NOT NULL AND TRIM(c.slipinno) IS NULL  THEN 'Y'
                                 ELSE 'N'
                            END AS pos_5
                    FROM    VGT.TT_ACACC0900SP_DUAL A
                        JOIN ACAUTOORDT b -- 기존자료
                            ON      A.compcode = b.compcode
                                AND b.acattype = 'S'
                                AND A.appdate = b.slipindate
                                AND A.taxno = b.acatno
                        LEFT JOIN ACORDM c -- 회계전표
                            ON      b.compcode = c.compcode
                                AND b.slipinno = c.slipinno ) SRC
                ON (TG.COMPCODE=SRC.COMPCODE AND TG.APPDATE=SRC.APPDATE AND TG.TAXNO=SRC.TAXNO)
        WHEN MATCHED THEN UPDATE
                SET TG.ACCTRNCHK    = POS_2,
                    TG.ACTRNSTATE   = POS_3,
                    TG.SLIPINNO     = POS_4,
                    TG.NEWCHK       = POS_5;

        -- 수정 데이터 확인
        MERGE INTO VGT.TT_ACACC0900SP_DUAL TG
        USING (
                SELECT  A.COMPCODE,  A.APPDATE ,A.TAXNO,
                        '3',
                        'N',
                        CASE
                            WHEN TRIM(B.SLIPINNO) IS NOT NULL AND TRIM(C.SLIPINNO) IS NULL  THEN '수정:회계전표삭제재전송'
                            ELSE '수정전송필요'
                        END AS POS_4,
                        TRIM (B.SLIPINNO) AS POS_5
                FROM    VGT.TT_ACACC0900SP_DUAL A
                        JOIN    ACAUTOORDT B -- 기존자료
                            ON      A.COMPCODE = B.COMPCODE
                                AND B.ACATTYPE = 'S'
                                AND A.APPDATE = B.SLIPINDATE
                                AND A.TAXNO = B.ACATNO
                        LEFT JOIN ACORDM C -- 회계전표
                            ON      B.COMPCODE = C.COMPCODE
                                AND B.SLIPINNO = C.SLIPINNO
                WHERE   A.PLANTCODE <> B.PLANTCODE
                            OR A.AUTORULECODE <> B.ACATRULECODE
                            OR A.CUSTCODE <> B.CUSTCODE
                            OR A.SALAMT1 <> B.TRN1AMT
                            OR A.SALAMT2 <> B.TRN2AMT
                            OR A.SALVAT <> B.TRN3AMT
                            OR A.TOTAMT <> B.TRN4AMT) SRC
                ON ( TG.COMPCODE=SRC.COMPCODE AND TG.APPDATE=SRC.APPDATE AND TG.TAXNO=SRC.TAXNO )
        WHEN MATCHED THEN UPDATE
        SET TG.ACTRNSTATE = '3',
            TG.CHK = 'N',
            TG.ACCTRNCHK = POS_4,
            TG.SLIPINNO = POS_5;

      -- 삭제 상태 확인
        INSERT INTO VGT.TT_ACACC0900SP_DUAL
        (
            SELECT  p_compcode compcode  ,
                    'N' chk  ,
                    SUBSTR(A.slipindate, 0, 4) yymm  ,
                    A.plantcode ,
                    A.slipindate appdate  ,
                    A.taxno taxno  ,
                    CASE
                        WHEN A.acatrulecode = 'S01003' THEN '102'
                        WHEN A.acatrulecode = 'S01004' THEN '104'
                        ELSE '101'
                    END taxdiv  ,
                    '02' iotaxdiv  ,
                    '삭제됨' ordno  ,
                    NVL(A.custcode, '') custcode  ,
                    NVL(A.userdef6code, '') custname  ,
                    c.businessno businessno  ,
                    c.ceoname ceoname  ,
                    c.telno telno  ,
                    c.post post  ,
                    c.addr1 addr1  ,
                    c.addr2 addr2  ,
                    c.addre addr  ,
                    NVL(A.deptcode, '') deptcode  ,
                    NVL(A.userdef4code, '') deptname  ,
                    NVL(A.empcode, '') empcode  ,
                    NVL(A.userdef5code, '') empname  ,
                    A.remark itemnm  ,
                    A.trn1amt salamt1  ,
                    A.trn2amt salamt2  ,
                    A.trn1amt + A.trn2amt salamt  ,
                    A.trn3amt salvat  ,
                    A.trn4amt totamt  ,
                    '' loadyn  ,
                    '4' actrnstate  ,
                    A.acatrulecode ,
                    '삭제전송필요' acctrnchk  ,
                    A.slipinno slipinno  ,
                    'N' taxloadyn  ,
                    '' taxloadtatus  ,
                    'N' newchk
            FROM    ACAUTOORDT A
                    LEFT JOIN VGT.TT_ACACC0900SP_DUAL b
                        ON      A.compcode = b.compcode
                            AND A.slipindate = b.appdate
                            AND A.acatno = b.taxno
                    LEFT JOIN CMCUSTM c
                        ON A.custcode = c.custcode
            WHERE   A.compcode = p_compcode
                AND A.acattype = 'S'
                AND A.slipindate BETWEEN p_sdt AND p_edt
                AND b.taxno IS NULL
                AND NVL(fnGetColDeptCode(A.deptcode),' ') = NVL(p_deptcode, ' ') );


        IF ( p_loadstatus = '1' OR p_loadstatus = '2' OR p_loadstatus = '3' ) THEN
       --로드 상태를 선택
            DELETE FROM  VGT.TT_ACACC0900SP_DUAL
            WHERE   ACTRNSTATE NOT IN  (
                                            SELECT  FILTER1
                                            FROM    CMCOMMONM
                                            WHERE   CMMCODE = 'AC082'
                                                AND DIVCODE = P_LOADSTATUS
                                            UNION ALL
                                            SELECT  FILTER2
                                            FROM    CMCOMMONM
                                            WHERE   CMMCODE = 'AC082'
                                                AND DIVCODE = P_LOADSTATUS
                                        );

        END IF;

        IF ( p_plantcode <> '%' ) THEN
            DELETE  FROM VGT.TT_ACACC0900SP_DUAL
            WHERE   plantcode <> p_plantcode;
        END IF;

        IF ( TRIM(p_custcode) IS NOT NULL ) THEN
          DELETE FROM VGT.TT_ACACC0900SP_DUAL
          WHERE custcode <> p_custcode;
        END IF;

        --세금계산서 작업 확인
        MERGE INTO VGT.TT_ACACC0900SP_DUAL TG
        USING (
                SELECT  A.compcode , A.plantcode, A.taxno,
                        CASE
                            WHEN (TRIM(A.taxno) IS NOT NULL  AND TRIM(b.taxno) IS NULL ) OR (A.custcode <> b.custcode) OR (A.salamt <> b.amt) OR (A.salvat <> b.vat) THEN 'N'
                            ELSE 'Y'
                        END AS pos_2,   CASE  WHEN TRIM(A.taxno) IS NOT NULL  AND TRIM(b.taxno) IS NULL THEN '전송 필요'
                                              WHEN A.custcode <> b.custcode OR A.salamt <> b.amt OR A.salvat <> b.vat THEN '재전송 필요'
                                              ELSE '전송 완료'
                                        END AS pos_3
                FROM    VGT.TT_ACACC0900SP_DUAL A
                        LEFT JOIN ACTAXM b
                            ON      A.compcode = b.compcode
                                AND A.plantcode = b.plantcode
                                AND A.taxno = b.taxno ) src
            ON ( TG.COMPCODE=SRC.COMpCODE AND TG.PLANTCODE=SRC.PLANTCODE AND TG.TAXNO=SRC.TAXNO )
        WHEN MATCHED THEN
        UPDATE SET  TG.TAXLOADYN     = POS_2,
                    TG.TAXLOADTATUS  = POS_3;


        IF ( p_div = 'S' ) THEN

            OPEN  IO_CURSOR FOR
            SELECT  A.* ,
                    NVL(b.slipdate, '') accslipdate  ,
                    NVL(b.slipnum, '') accslipnum
            FROM    VGT.TT_ACACC0900SP_DUAL A
                    LEFT JOIN ACORDM b
                        ON      b.compcode = A.compcode
                            AND b.slipinno = A.slipinno
            ORDER BY A.compcode, A.plantcode, A.taxno ;

        ELSIF ( p_div = 'loadall' ) THEN

                -- 신규 작업
            INSERT INTO ACAUTOORDT
                                    ( compcode --회사코드
                                        , acattype --전표유형(S)
                                        , acatno --전표번호
                                        , acatrulecode --분개률코드
                                        , actrnstate --실행상태
                                        , slipindate --발의일자(세금계산서일자)
                                        , deptcode --영업부서
                                        , plantcode --사업장
                                        , empcode --영업사원
                                        , remark --비고
                                        , remark2 --비고2
                                        , custcode --거래처
                                        , taxno --세금계산서번호
                                        , trn1amt --제품공급가액/매출할인
                                        , trn2amt --상품공급가액
                                        , trn3amt --부가세
                                        , trn4amt --합계액
                                        , userdef4code --부서명
                                        , userdef5code --발의사원명
                                        , userdef6code --거래처명
                                        , insertdt --입력일자
                                        , iempcode --입력사원
                                    )
                            ( SELECT    compcode ,--회사
                                        'S' ,--전표유형
                                        taxno ,--세금계산서번호
                                        autorulecode ,--분개률코드
                                        actrnstate ,--실행상태
                                        appdate ,--발의일자(세금계산서일자)
                                        deptcode ,--영업부서
                                        plantcode ,--사업장
                                        empcode ,--영업사원
                                        itemnm ,--비고
                                        '' ,--비고2
                                        custcode ,--거래처
                                        taxno ,--세금계산서번호
                                        salamt1 ,--제품공급가액/매출할인
                                        salamt2 ,--상품공급가액
                                        salvat ,--부가세
                                        totamt ,--합계액
                                        deptname ,--부서명
                                        empname ,--발의사원명
                                        custname ,--거래처명
                                        SYSDATE , --입력일자
                                        p_iempcode --입력사원
                                FROM    VGT.TT_ACACC0900SP_DUAL
                                WHERE   actrnstate = '1' );
                -- 신규 세금계산서 작업
            DELETE FROM ACTAXD
            WHERE (COMPCODE,PLANTCODE,TAXNO,SEQ) IN  (
                                                        SELECT  B.COMPCODE, B.PLANTCODE, B.TAXNO, B.SEQ
                                                        FROM    VGT.TT_ACACC0900SP_DUAL A
                                                                JOIN ACTAXD b   ON A.taxno = b.taxno
                                                        WHERE    A.taxloadyn = 'N'
                                                     );
            DELETE FROM ACTAXM
            WHERE (COMPCODE,PLANTCODE,TAXNO) IN
                                                    (
                                                        SELECT  B.COMPCODE,B.PLANTCODE,B.TAXNO
                                                        FROM    VGT.TT_ACACC0900SP_DUAL A
                                                                JOIN ACTAXM b   ON A.taxno = b.taxno
                                                        WHERE   A.taxloadyn = 'N'
                                                    );
            INSERT INTO ACTAXM
                                (   compcode, plantcode, taxno, taxdiv --계산서 구분(  select * from cmcommonm where cmmcode = 'AC60'  )
                                  , iotaxdiv --매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
                                  , sdeptcode, taxdate, custcode, custname, businessno, biznotype --사업자구분( select * from cmcommonm where cmmcode = 'AC65'  )
                                  , blankcnt, amt, vat, vatamt, purposediv --영수청구구분(  select * from cmcommonm where cmmcode = 'AC62'   )
                                  , credittot, electaxyn --전자세금계산서여부
                                  , saleinyn --영업자동생성여부
                                  , insertdt, iempcode, updatedt, uempcode )
                        ( SELECT    compcode ,
                                    plantcode ,
                                    taxno ,
                                    taxdiv ,
                                    '02' ,
                                    deptcode ,
                                    appdate ,
                                    custcode ,
                                    custname ,
                                    businessno ,
                                    CASE
                                        WHEN autorulecode = 'S01005' THEN '02'
                                    ELSE '01'
                                      END col  ,
                                    0 ,
                                    salamt ,
                                    salvat ,
                                    totamt ,
                                    '02' ,
                                    totamt ,
                                    loadyn ,
                                    'Y' ,
                                    SYSDATE ,
                                    p_iempcode ,
                                    SYSDATE ,
                                    p_iempcode
                            FROM    VGT.TT_ACACC0900SP_DUAL
                            WHERE   taxloadyn = 'N' );

            INSERT INTO ACTAXD
                                (   compcode,   plantcode,  taxno,      seq,        itemnm,
                                    gyugeok,    qty,        prc,        amt,        vat,        vatamt,
                                    remark,     insertdt,   iempcode,   updatedt,   uempcode            )
                    ( SELECT        p_compcode ,
                                    plantcode ,
                                    taxno ,
                                    1 ,
                                    itemnm ,
                                    NULL ,
                                    0 ,
                                    0 ,
                                    salamt ,
                                    salvat ,
                                    totamt ,
                                    NULL ,
                                    SYSDATE ,
                                    p_iempcode ,
                                    SYSDATE ,
                                    p_iempcode
                        FROM        VGT.TT_ACACC0900SP_DUAL
                        WHERE       taxloadyn = 'N' );
                -- 수정,삭제 처리전에 메타에 있는 내용을 이력테이블에 저장한다.ACAUTOORDH
            INSERT INTO ACAUTOORDH
                    (       SELECT  b.*
                            FROM    VGT.TT_ACACC0900SP_DUAL A
                                    LEFT JOIN ACAUTOORDT b
                                        ON      A.compcode = b.compcode
                                            AND b.acattype = 'S'
                                            AND A.taxno = b.acatno
                            WHERE   A.actrnstate IN ( '3','4' ) OR A.newchk = 'Y' );
                --메타 테이블 저장
            MERGE INTO ACAUTOORDT TG
            USING   (
                        SELECT  B.COMPCODE, B.ACATTYPE, B.ACATNO,
                                A.autorulecode,
                                CASE
                                    WHEN b.actrnstate = '1' THEN b.actrnstate
                                    ELSE A.actrnstate
                                END AS pos_3,
                                A.appdate,
                                A.deptcode,
                                A.plantcode,
                                A.empcode,
                                NULL AS pos_8,
                                NULL AS pos_9,
                                A.custcode,
                                A.taxno,
                                A.salamt1,
                                A.salamt2,
                                A.salvat,
                                A.totamt,
                                A.deptname,
                                A.empname,
                                A.custname,
                                SYSDATE,
                                p_iempcode AS IEMPCODE
                        FROM    VGT.TT_ACACC0900SP_DUAL  A
                                LEFT JOIN ACAUTOORDT b
                                    ON      b.compcode = p_compcode
                                        AND b.acattype = 'S'
                                        AND b.acatno = A.taxno
                        WHERE   A.actrnstate IN ( '3','4' )
                    ) src
                ON ( TG.COMPCODE=SRC.COMPCODE AND TG.ACATTYPE=SRC.ACATTYPE AND TG.ACATNO=SRC.ACATNO)
            WHEN MATCHED THEN
                UPDATE SET  TG.ACATRULECODE = SRC.AUTORULECODE,
                            TG.ACTRNSTATE = POS_3,
                            TG.SLIPINDATE = SRC.APPDATE,
                            TG.DEPTCODE = SRC.DEPTCODE,
                            TG.PLANTCODE = SRC.PLANTCODE,
                            TG.EMPCODE = SRC.EMPCODE,
                            TG.REMARK = POS_8,
                            TG.REMARK2 = POS_9,
                            TG.CUSTCODE = SRC.CUSTCODE,
                            TG.TAXNO = SRC.TAXNO,
                            TG.TRN1AMT = SRC.SALAMT1,
                            TG.TRN2AMT = SRC.SALAMT2,
                            TG.TRN3AMT = SRC.SALVAT,
                            TG.TRN4AMT = SRC.TOTAMT,
                            TG.USERDEF4CODE = SRC.DEPTNAME,
                            TG.USERDEF5CODE = SRC.EMPNAME,
                            TG.USERDEF6CODE = SRC.CUSTNAME,
                            TG.UPDATEDT = SYSDATE,
                            TG.UEMPCODE = SRC.IEMPCODE;

            MERGE INTO ACTAXM TG
            USING   (
                        SELECT  B.COMPCODE, B.PLANTCODE, B.TAXNO,
                                A.taxdiv, '02', A.deptcode, A.appdate,
                                A.custcode, A.custname, A.businessno,
                                CASE
                                        WHEN A.autorulecode = 'S01005' THEN '02'
                                        ELSE '01'
                                END AS pos_9,

                                A.salamt, A.salvat, A.totamt, A.loadyn,  SYSDATE, p_iempcode AS iempcode
                        FROM    VGT.TT_ACACC0900SP_DUAL A
                                LEFT JOIN ACTAXM b
                                    ON      A.compcode = b.compcode
                                        AND A.plantcode = b.plantcode
                                        AND A.taxno = b.taxno
                        WHERE   A.actrnstate IN ( '3','4' )
                            AND A.taxloadyn = 'Y') src
                ON ( TG.COMPCODE = SRC.COMPCODE AND TG.PLANTCODE=SRC.PLANTCODE AND TG.TAXNO=SRC.TAXNO )
            WHEN MATCHED THEN
                UPDATE SET  TG.TAXDIV       = SRC.TAXDIV,
                            TG.IOTAXDIV     = '02',
                            TG.SDEPTCODE    = SRC.DEPTCODE,
                            TG.TAXDATE      = SRC.APPDATE,
                            TG.CUSTCODE     = SRC.CUSTCODE,
                            TG.CUSTNAME     = SRC.CUSTNAME,
                            TG.BUSINESSNO   = SRC.BUSINESSNO,
                            TG.BIZNOTYPE    = SRC.POS_9,
                            TG.BLANKCNT     = 0,
                            TG.AMT          = SRC.SALAMT,
                            TG.VAT          = SRC.SALVAT,
                            TG.VATAMT       = SRC.TOTAMT,
                            TG.PURPOSEDIV   = '02',
                            TG.ELECTAXYN    = SRC.LOADYN,
                            TG.SALEINYN     = 'Y',
                            TG.UPDATEDT     = SYSDATE,
                            TG.UEMPCODE     = src.IEMPCODE;

            MERGE INTO ACTAXD TG
            USING (
                        SELECT  B.COMPCODE, B.PLANTCODE, B.TAXNO,B.SEQ,
                                A.itemnm, NULL AS pos_3,  A.salamt, A.salvat, A.totamt, NULL AS pos_9, SYSDATE
                        FROM    VGT.TT_ACACC0900SP_DUAL A
                                LEFT JOIN ACTAXD b
                                    ON      A.compcode = b.compcode
                                        AND A.plantcode = b.plantcode
                                        AND A.taxno = b.taxno
                                        AND b.seq = 1
                        WHERE A.actrnstate IN ( '3','4' )
                            AND A.taxloadyn = 'Y') src
                ON ( TG.COMPCODE = SRC.COMPCODE AND TG.PLANTCODE=SRC.PLANTCODE AND TG.TAXNO=SRC.TAXNO AND TG.SEQ=SRC.SEQ )
            WHEN MATCHED THEN
                UPDATE SET   TG.itemnm = src.itemnm,
                             TG.gyugeok = pos_3,
                             TG.qty = 0,
                             TG.prc = 0,
                             TG.amt = src.salamt,
                             TG.vat = src.salvat,
                             TG.vatamt = src.totamt,
                             TG.remark = pos_9,
                             TG.updatedt = SYSDATE,
                             TG.uempcode = p_iempcode;

            DELETE FROM ACTAXD
            WHERE  ( COMPCODE,PLANTCODE, TAXNO,SEQ ) IN
                                                        (   SELECT  B.COMPCODE, B.PLANTCODE, B.TAXNO,B.SEQ
                                                            FROM    VGT.TT_ACACC0900SP_DUAL A
                                                                    LEFT JOIN ACTAXD b
                                                                        ON      A.compcode = b.compcode
                                                                            AND A.plantcode = b.plantcode
                                                                            AND A.taxno = b.taxno
                                                            WHERE   A.actrnstate = '4'
                                                                AND A.taxloadyn = 'Y' );
            DELETE FROM ACTAXM
            WHERE   (COMPCODE,PLANTCODE, TAXNO) IN  (
                                                        SELECT  B.COMPCODE,B.PLANTCODE, B.TAXNO
                                                        FROM    VGT.TT_ACACC0900SP_DUAL A
                                                                LEFT JOIN ACTAXM b
                                                                    ON      A.compcode = b.compcode
                                                                        AND A.plantcode = b.plantcode
                                                                        AND A.taxno = b.taxno
                                                        WHERE  A.actrnstate = '4'
                                                        AND A.taxloadyn = 'Y' );

        END IF;

    ELSIF ( p_div = 'taxdtl' ) THEN

       --영업 회계로드에서 세금계산서별 상세 매출 내역 확인

        OPEN  IO_CURSOR FOR
        SELECT  A.taxno taxno  ,
                FNstuff(FNstuff(SUBSTR(b.orderno, 0, 8), 5, 0, '-'), 8, 0, '-') orderdate  ,
                b.orderno orderno  ,
                b.orderseq orderseq  ,
                b.itemcode itemcode  ,
                c.itemname itemname  ,
                b.salqty salqty  ,
                b.price salprc  ,
                b.salamt salamt  ,
                CASE
                    WHEN NVL(D.filter1, '05') <> '05' THEN b.salamt
                ELSE 0
                  END amt1  ,
                CASE
                    WHEN NVL(D.filter1, '05') = '05' THEN b.salamt
                ELSE 0
                  END amt2  ,
                b.salvat salvat  ,
                b.salamt + b.salvat totamt
        FROM    SLTAXM A
                JOIN SLTAXD b
                    ON      A.plantcode = b.plantcode
                        AND A.taxno = b.taxno
                LEFT JOIN CMITEMM c
                    ON b.itemcode = c.itemcode
                LEFT JOIN CMCOMMONM D
                    ON      D.cmmcode = 'CMM01'
                        AND c.itemdiv = D.divcode
        WHERE  A.plantcode LIKE p_plantcode
            AND A.taxdt BETWEEN p_sdt AND p_edt
            AND NVL(A.taxno, ' ') = p_taxno 
        ORDER BY  FNstuff(FNstuff(SUBSTR(b.orderno, 0, 8), 5, 0, '-'), 8, 0, '-') , b.orderno, b.orderseq           
            ;
    END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
