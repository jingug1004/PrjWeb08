CREATE PROCEDURE        spACbudg0000P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbudg0000P
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-11-10
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2017-01-02
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 부서예산통제 수정,삭제,조회하는 프로시저이다.
	-- ---------------------------------------------------------------


	p_div			 IN 	VARCHAR2 DEFAULT '',
	p_compcode		 IN 	VARCHAR2 DEFAULT '',
	p_deptcode		 IN 	VARCHAR2 DEFAULT '',
	p_acccode		 IN 	VARCHAR2 DEFAULT '',
	p_budglimityn	 IN 	VARCHAR2 DEFAULT '',
	p_insertdt		 IN 	DATE 	 DEFAULT NULL,
	p_iempcode		 IN 	VARCHAR2 DEFAULT '',
	p_updatedt		 IN 	DATE 	 DEFAULT NULL,
	p_uempcode		 IN 	VARCHAR2 DEFAULT '',
	p_userid		 IN 	VARCHAR2 DEFAULT '',
	p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
	p_reasontext	 IN 	VARCHAR2 DEFAULT '',
	MESSAGE 			OUT VARCHAR2,
	IO_CURSOR			OUT TYPES.DATASET
)
AS
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S')
	THEN
		OPEN IO_CURSOR FOR
			SELECT a.compcode compcode,
				   a.deptcode deptcode,
				   a.acccode acccode,
				   a.budglimityn budglimityn,
				   b.deptname deptname,
				   c.accname accname
			FROM   ACBUDGM a
				   LEFT JOIN CMDEPTM b ON a.deptcode = b.deptcode
				   LEFT JOIN ACACCM c ON a.acccode = c.acccode
			WHERE  compcode = p_compcode
				   AND a.deptcode LIKE p_deptcode || '%'
				   AND a.acccode LIKE p_acccode || '%';
	ELSIF (p_div = 'SC')
	THEN
		FOR rec IN (SELECT COUNT(compcode) AS alias1
					FROM   ACBUDGM
					WHERE  compcode = p_compcode
						   AND deptcode = p_deptcode
						   AND acccode = p_acccode)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;
	ELSIF (p_div = 'I')
	THEN
		INSERT INTO ACBUDGM(compcode,
							deptcode,
							acccode,
							budglimityn,
							insertdt,
							iempcode)
		VALUES		(p_compcode,
					 p_deptcode,
					 p_acccode,
					 p_budglimityn,
					 SYSDATE,
					 p_iempcode);
	ELSIF (p_div = 'U')
	THEN
		UPDATE ACBUDGM
		SET    compcode = p_compcode,
			   deptcode = p_deptcode,
			   acccode = p_acccode,
			   budglimityn = p_budglimityn,
			   updatedt = SYSDATE,
			   uempcode = p_iempcode
		WHERE  compcode = p_compcode
			   AND deptcode = p_deptcode
			   AND acccode = p_acccode;
	ELSIF (p_div = 'D')
	THEN
		DELETE ACBUDGM
		WHERE  compcode = p_compcode
			   AND deptcode = p_deptcode
			   AND acccode = p_acccode;
	END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
