CREATE PROCEDURE spACacc0000P(
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0000P
-- 작 성 자         : 민승기
-- 작성일자         : 2010-10-06
--수정자          : 임정호
-- 작성일자         : 2016-12-15
-- ---------------------------------------------------------------
-- 프로시저 설명    : 회계전표 테이블 내역을 조회하는 프로시저이다.
-- ---------------------------------------------------------------
    p_div           IN  VARCHAR2 DEFAULT '',

    p_compcode      IN  VARCHAR2 DEFAULT '',
    p_plantcode     IN  VARCHAR2 DEFAULT '',
    p_slipsdate     IN  VARCHAR2 DEFAULT '',
    p_slipedate     IN  VARCHAR2 DEFAULT '',
    p_deptcode      IN  VARCHAR2 DEFAULT '',
    p_empcode       IN  VARCHAR2 DEFAULT '',
    p_slipdiv       IN  VARCHAR2 DEFAULT '',
    p_slipinno      IN  VARCHAR2 DEFAULT '',
    p_acccode       IN  VARCHAR2 DEFAULT '',
    p_dcdiv         IN  VARCHAR2 DEFAULT '',
    p_slipinremark  IN  VARCHAR2 DEFAULT '', --결의내용 검색 조건

    p_userid        IN  VARCHAR2 DEFAULT '',
    p_reasondiv     IN  VARCHAR2 DEFAULT '',
    p_reasontext    IN  VARCHAR2 DEFAULT '',
    IO_CURSOR       OUT TYPES.DataSet,
    MESSAGE         OUT VARCHAR2
)
AS
    p_strmon            VARCHAR2(2); -- 회기시작월
    p_month             VARCHAR2(7); -- 전표년월
    p_month1            VARCHAR2(7); -- 당기시작년월
    p_month2            VARCHAR2(7); -- 당기종료년월
    p_month3            VARCHAR2(7); -- 분기시작년월
    p_month4            VARCHAR2(7); -- 분기종료년월
    p_month5            VARCHAR2(7); -- 반기시작년월
    p_month6            VARCHAR2(7); -- 반기종료년월
    p_budgemp           VARCHAR2(5);
    p_value1            VARCHAR2(30);
BEGIN
    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values(p_userid, p_reasondiv, p_reasontext);

    -- 결의전표내역 검색
    if (p_div = 'SM') then
        open IO_CURSOR for
        with TT_ACORDM as (
            select  a.compcode, -- 회사코드
                    a.slipinno  -- 전표번호
            from    ACORDM a
            where   a.compcode = p_compcode
                    and a.slipdiv <> 'A'
                    and (p_slipinno is not null
                         and a.slipinno = upper(trim(p_slipinno))
                         and a.deptcode like p_deptcode || '%'
                         or
                         p_slipinno is null
                         and a.plantcode like p_plantcode || '%'
                         and a.slipdiv like p_slipdiv || '%'
                         and a.slipindate between p_slipsdate and p_slipedate
                         and (p_empcode = p_userid
                              and a.empcode = p_empcode
                              or
                              a.deptcode like p_deptcode || '%'
                              and a.empcode like p_empcode || '%')
                         and (a.slipinremark like '%' || p_slipinremark || '%' or
                              a.slipincomment like '%' || p_slipinremark || '%'))
            union
            select  a.compcode, -- 회사코드
                    a.slipinno  -- 전표번호
            from    ACORDM a
                    join ACORDD b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
            where   a.compcode = p_compcode
                    and a.slipdiv <> 'A'
                    and p_slipinno is null
                    and a.plantcode like p_plantcode || '%'
                    and a.slipdiv like p_slipdiv || '%'
                    and a.slipindate between p_slipsdate and p_slipedate
                    and (p_empcode = p_userid
                         and a.empcode = p_empcode
                         or
                         a.deptcode like p_deptcode || '%'
                         and a.empcode like p_empcode || '%')
                    and (b.remark1 like '%' || p_slipinremark || '%' or
                         b.remark2 like '%' || p_slipinremark || '%')
            union
            select  a.compcode, -- 회사코드
                    a.slipinno -- 전표번호
            from    ACORDM a
                    join ACORDS b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
            where   a.compcode = p_compcode
                    and a.slipdiv <> 'A'
                    and p_slipinno is null
                    and a.plantcode like p_plantcode || '%'
                    and a.slipdiv like p_slipdiv || '%'
                    and a.slipindate between p_slipsdate and p_slipedate
                    and (p_empcode = p_userid
                         and a.empcode = p_empcode
                         or
                         a.deptcode like p_deptcode || '%'
                         and a.empcode like p_empcode || '%')
                    and (b.mngcluval like '%' || p_slipinremark || '%' or
                         b.mngcludec like '%' || p_slipinremark || '%')
        )
        select  a.compcode as compcode,             -- 회사코드
                a.slipinno as slipinno,             -- 전표번호
                a.slipdiv as slipdiv,               -- 전표유형
                a.slipindate as slipindate,         -- 발의일자
                a.slipinnum as slipinnum,           -- 전표넘버
                a.deptcode as deptcode,             -- 발의부서
                a.plantcode as plantcode,           -- 사업장
                a.empcode as empcode,               -- 발의자
                a.eviddiv as eviddiv,               -- 증빙구분
                a.slipinremark as slipinremark,     -- 발의내용
                a.slipincomment as slipincomment,   -- 특이사항
                a.slipno as slipno,                 -- 승인번호
                a.slipdate as slipdate,             -- 회계일자
                a.slipnum as slipnum,               -- 승인넘버
                a.slipdeptcode as slipdeptcode,     -- 승인부서
                a.slipempcode as slipempcode,       -- 승인자
                a.skreqyn as skreqyn,               -- 송금의뢰여부
                a.skreqdiv as skreqdiv,             -- 송금의뢰유형
                a.skreqdate as skreqdate,           -- 송금의뢰일자
                a.skreqdeptcode as skreqdeptcode,   -- 송금의뢰부서
                a.skreqempcode as skreqempcode,     -- 송금의뢰자
                a.accountno as accountno,           -- 송금계좌코드
                a.slipinstate as slipinstate,       -- 발의진행상태
                a.slipremark as slipremark,         -- 발려사유
                c.deptname as deptname,             -- 발의부서명
                d.empname as empname,               -- 발의자명
                e.deptname as slipdeptname,         -- 승인부서명
                f.empname as slipempname,           -- 승인자명
                g.deptname as skreqdeptname,        -- 송금의뢰부서명
                h.empname as skreqempname,          -- 송금의뢰자명
                i.divname as skreqdivname           -- 송금의뢰유형명
        from    ACORDM a
                join TT_ACORDM b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                left join CMDEPTM c   -- 발의부서
                    on a.deptcode = c.deptcode
                left join CMEMPM d    -- 발의자
                    on a.empcode = d.empcode
                left join CMDEPTM e   -- 승인부서
                    on a.slipdeptcode = e.deptcode
                left join CMEMPM f    -- 승인자
                    on a.slipempcode = f.empcode
                left join CMDEPTM g   -- 송금의뢰부서
                    on a.skreqdeptcode = g.deptcode
                left join CMEMPM h    -- 송금의뢰자
                    on a.skreqempcode = h.empcode
                left join CMCOMMONM i -- 송금의뢰유형
                    on i.cmmcode = 'AC27'
                    and a.skreqdiv = i.divcode
        order by a.slipinno;

    -- 결의전표상태 검색
    elsif (p_div = 'ST') then
        MESSAGE := '';

        for rec in (
            select  slipinstate
            from    ACORDM
            where   compcode = p_compcode
                    and slipinno = upper(trim(p_slipinno)))
        loop
            MESSAGE := rec.slipinstate;
        end loop;

    -- 회계전표내역 검색
    elsif (p_div = 'SN') then
        open IO_CURSOR for
        with TT_ACORDRPY as (
            select  distinct a.compcode,
                    nvl(b.slipinno, c.slipinno) as slipinno
            from    ACORDM a
                    left join ACORDRPYR b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
                    left join ACORDRPYD c
                        on a.compcode = c.compcode
                        and a.slipinno = c.slipinno
                        and c.crtslipinno is not null
            where   a.compcode = p_compcode
                    and a.slipinstate = '4'
                    and (p_slipinno is not null
                         and a.slipno = upper(trim(p_slipinno))
                         and nvl(a.deptcode, ' ') like p_deptcode || '%'
                         or
                         p_slipinno is null
                         and a.plantcode like p_plantcode || '%'
                         and a.slipdiv like p_slipdiv || '%'
                         and a.slipdate between p_slipsdate and p_slipedate
                         and nvl(a.deptcode, ' ') like p_deptcode || '%'
                         and a.empcode like p_empcode || '%'
                         and (upper(a.slipinremark) like upper('%' || p_slipinremark || '%') or
                              upper(a.slipincomment) like upper('%' || p_slipinremark || '%')))
        ),
        TT_ACORDM2 as (
            select  a.compcode, -- 회사코드
                    a.slipinno  -- 전표번호
            from    ACORDM a
            where   a.compcode = p_compcode
                    and a.slipinstate = '4'
                    and (p_slipinno is not null
                         and a.slipno = upper(trim(p_slipinno))
                         and nvl(a.deptcode, ' ') like p_deptcode || '%'
                         or
                         p_slipinno is null
                         and a.plantcode like p_plantcode || '%'
                         and a.slipdiv like p_slipdiv || '%'
                         and a.slipdate between p_slipsdate and p_slipedate
                         and nvl(a.deptcode, ' ') like p_deptcode || '%'
                         and a.empcode like p_empcode || '%'
                         and (upper(a.slipinremark) like upper('%' || p_slipinremark || '%') or
                              upper(a.slipincomment) like upper('%' || p_slipinremark || '%')))
            union
            select  a.compcode, -- 회사코드
                    a.slipinno  -- 전표번호
            from    ACORDM a
                    join ACORDD b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
            where   a.compcode = p_compcode
                    and a.slipinstate = '4'
                    and p_slipinno is null
                    and a.plantcode like p_plantcode || '%'
                    and a.slipdiv like p_slipdiv || '%'
                    and a.slipdate between p_slipsdate and p_slipedate
                    and nvl(a.deptcode, ' ') like p_deptcode || '%'
                    and a.empcode like p_empcode || '%'
                    and (upper(b.remark1) like upper('%' || p_slipinremark || '%') or
                         upper(b.remark2) like upper('%' || p_slipinremark || '%'))
            union
            select  a.compcode, -- 회사코드
                    a.slipinno  -- 전표번호
            from    ACORDM a
                    join ACORDS b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
            where   a.compcode = p_compcode
                    and a.slipinstate = '4'
                    and p_slipinno is null
                    and a.plantcode like p_plantcode || '%'
                    and a.slipdiv like p_slipdiv || '%'
                    and a.slipdate between p_slipsdate and p_slipedate
                    and nvl(a.deptcode, ' ') like p_deptcode || '%'
                    and a.empcode like p_empcode || '%'
                    and (upper(b.mngcluval) like upper('%' || p_slipinremark || '%') or
                         upper(b.mngcludec) like upper('%' || p_slipinremark || '%'))
        )
        select  nvl(a.compcode, '') as compcode,            -- 회사코드
                nvl(a.slipinno, '') as slipinno,            -- 전표번호
                nvl(a.slipdiv, '') as slipdiv,              -- 전표유형
                nvl(a.slipindate, '') as slipindate,        -- 발의일자
                nvl(a.slipinnum, '') as slipinnum,          -- 전표넘버
                nvl(a.deptcode, '') as deptcode,            -- 발의부서
                nvl(a.plantcode, '') as plantcode,          -- 사업장
                nvl(a.empcode, '') as empcode,              -- 발의자
                nvl(a.eviddiv, '') as eviddiv,              -- 증빙구분
                nvl(a.slipinremark, '') as slipinremark,    -- 발의내용
                nvl(a.slipincomment, '') as slipincomment,  -- 특이사항
                nvl(a.slipno, '') as slipno,                -- 승인번호
                nvl(a.slipdate, '') as slipdate,            -- 회계일자
                nvl(a.slipnum, '') as slipnum,              -- 승인넘버
                nvl(a.slipdeptcode, '') as slipdeptcode,    -- 승인부서
                nvl(a.slipempcode, '') as slipempcode,      -- 승인자
                nvl(a.skreqyn, '') as skreqyn,              -- 송금의뢰여부
                nvl(a.skreqdiv, '') as skreqdiv,            -- 송금의뢰유형
                nvl(a.skreqdate, '') as skreqdate,          -- 송금의뢰일자
                nvl(a.skreqdeptcode, '') as skreqdeptcode,  -- 송금의뢰부서
                nvl(a.skreqempcode, '') as skreqempcode,    -- 송금의뢰자
                nvl(a.accountno, '') as accountno,          -- 송금계좌코드
                nvl(a.slipinstate, '') as slipinstate,      -- 발의진행상태
                nvl(d.deptname, '') as deptname,            -- 발의부서명
                nvl(e.empname, '') as empname,              -- 발의자명
                nvl(f.deptname, '') as slipdeptname,        -- 승인부서명
                nvl(g.empname, '') as slipempname,          -- 승인자명
                nvl(h.deptname, '') as skreqdeptname,       -- 송금의뢰부서명
                nvl(i.empname, '') as skreqempname,         -- 송금의뢰자명
                nvl(j.divname, '') as skreqdivname,         -- 송금의뢰유형명
                case when nvl(c.slipinno, ' ') <> ' ' then 'Y' else 'N' end as rpyyn  -- 반제처리여부
        from    ACORDM a
                join TT_ACORDM2 b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                left join TT_ACORDRPY c   -- 반제전표
                    on a.compcode = c.compcode
                    and a.slipinno = c.slipinno
                left join CMDEPTM d       -- 발의부서
                    on a.deptcode = d.deptcode
                left join CMEMPM e        -- 발의자
                    on a.empcode = e.empcode
                left join CMDEPTM f       -- 승인부서
                    on a.slipdeptcode = f.deptcode
                left join CMEMPM g        -- 승인자
                    on a.slipempcode = g.empcode
                left join CMDEPTM h       -- 송금의뢰부서
                    on a.skreqdeptcode = h.deptcode
                left join CMEMPM i        -- 송금의뢰자
                    on a.skreqempcode = i.empcode
                left join CMCOMMONM j     -- 송금의뢰유형
                    on j.cmmcode = 'AC27'
                    and a.skreqdiv = j.divcode
        order by a.slipno;

    -- 회계전표상세내역 검색
    elsif (p_div = 'SD') then
        open IO_CURSOR for
        select  nvl(a.compcode, '') as compcode,    -- 회사코드
                nvl(a.slipinno, '') as slipinno,    -- 전표번호
                nvl(a.slipinseq, 0) as slipinseq,   -- 순번
                nvl(a.dcdiv, '') as dcdiv,          -- 차대구분
                nvl(a.acccode, '') as acccode,      -- 계정코드
                nvl(a.plantcode, '') as plantcode,  -- 사업장
                nvl(a.debamt, 0) as debamt,         -- 차변금액
                nvl(a.creamt, 0) as creamt,         -- 대변금액
                nvl(a.slipdate, '') as slipdate,    -- 회계일자
                nvl(a.slipnum, '') as slipnum,      -- 승인넘버
                nvl(a.remark1, '') as remark1,      -- 적요
                nvl(a.fundcode, '') as fundcode,    -- 자금구분
                nvl(f.fundname, '') as fundname,    -- 자금구분명
                nvl(a.remark2, '') as remark2,      -- 적요2
                nvl(a.taxno, '') as taxno,          -- 계산서번호
                nvl(a.datadiv, '') as datadiv,      -- 외부연동
                nvl(a.rptseq, '') as rptseq,        -- 출력순번
                nvl(b.accname, '') as accname,      -- 계정명
                nvl(c.usediv, '9') as usediv,       -- 팝업
                nvl(c.popdiv, '') as popdiv,        -- 팝업종류
                '' as popname,                      -- 팝업명
                nvl(c.accdiv, '') as accdiv,        -- 팝업구분
                nvl(b.dcdiv, '') as adcdiv,         -- 계정차대구분
                nvl(d.appr_date, '') as extr_date,  -- 사이버브랜치 거래일자
                nvl(d.appr_time, '') as extr_bank,  -- 사이버브랜치 거래시간
                nvl(d.appr_nb, '') as extr_no,      -- 사이버브랜치 승인번호
                nvl(d.slipdiv, '') as extr_div,     -- 사이버브랜치 분개방법
                nvl(e.sliptot, 0) as sliptot,       -- 반제원전표금액
                nvl(e.repaytot, 0) as repaytot,     -- 반제총금액
                nvl(e.repayamt, 0) as repayamt,     -- 반제금액
                nvl(b.returnyn, '') as returnyn     -- 반제여부
        from    ACORDD a
                left join ACACCM b -- 계정과목
                    on a.acccode = b.acccode
                left join (
                    select  nvl(a.filter1, '') as acccode,
                            nvl(a.filter2, '') as accdiv,
                            decode(b.filter1, null, null, b.filter1) as usediv,
                            nvl(b.filter2, '') as popdiv,
                            case when (b.filter1 = '3' or p_slipdiv = 'R') and (b.filter1 = '4' or p_slipdiv = 'A') and (b.filter1 = '5') then b.divname else null end as popname
                    from    CMCOMMONM a
                            join CMCOMMONM b
                                on a.hcmmcode = b.cmmcode
                                and a.hdivcode = b.divcode
                                and b.usediv = 'Y'
                    where   a.cmmcode = 'AC251'
                            and a.usediv = 'Y'
                ) c on a.acccode like c.acccode || '%'
                left join (
                    select  *
                    from    ACORDCARD
                    where   compcode = p_compcode
                            and slipinno = upper(trim(p_slipinno))
                ) d on a.compcode = d.compcode
                    and a.slipinno = d.slipinno
                    and a.slipinseq = d.slipinseq
                left join (
                    select  a.rpyslipinno,
                            a.rpyslipinseq,
                            sum(a.repayamt) as repayamt,
                            max(b.slipamt) as sliptot,
                            max(b.repayamt) as repaytot
                    from    ACORDRPYP a
                            join ACORDRPYR b
                                on a.compcode = b.compcode
                                and a.slipinno = b.slipinno
                                and a.slipinseq = b.slipinseq
                    where    a.compcode = p_compcode
                             and a.rpyslipinno = upper(trim(p_slipinno))
                    group by a.rpyslipinno, a.rpyslipinseq
                    union
                    select  a.slipinno,
                            a.slipinseq,
                            max(a.debamt + a.creamt) as repayamt,
                            max(a.debamt + a.creamt) as sliptot,
                            max(a.debamt + a.creamt) as repaytot
                    from    ACORDD a
                            join ACORDRPYD b
                                on a.compcode = b.compcode
                                and a.slipinno = b.crtslipinno
                            join ACACCM c
                                on a.acccode = c.acccode
                                and c.returnyn = 'Y'
                            left join (
                                select  a.rpyslipinno,
                                        a.rpyslipinseq
                                from    ACORDRPYP a
                                        join ACORDRPYR b
                                            on a.compcode = b.compcode
                                            and a.slipinno = b.slipinno
                                            and a.slipinseq = b.slipinseq
                                where   a.compcode = p_compcode
                                        and a.rpyslipinno = upper(trim(p_slipinno))
                                group by a.rpyslipinno, a.rpyslipinseq
                            ) d on a.slipinno = d.rpyslipinno
                                and a.slipinseq = d.rpyslipinseq
                    where   a.compcode = p_compcode
                            and a.slipinno = upper(trim(p_slipinno))
                            and d.rpyslipinno is null
                    group by a.slipinno, a.slipinseq
                ) e on a.slipinno = e.rpyslipinno
                    and a.slipinseq = e.rpyslipinseq
                left join ACFUNDM f
                    on a.compcode = f.compcode
                    and a.fundcode = f.fundcode
        where   a.compcode = p_compcode
                 and a.slipinno = upper(trim(p_slipinno))
        order by a.rptseq;

    -- 회계전표관리항목내역 검색
    elsif (p_div = 'SS') then
        open IO_CURSOR for
        select  nvl(a.compcode, '') as compcode,      -- 회사코드
                nvl(a.slipinno, '') as slipinno,      -- 전표번호
                nvl(a.slipinseq, 0) as slipinseq,     -- 순번
                nvl(a.seq, 0) as seq,                 -- 일련번호
                nvl(a.mngclucode, '') as mngclucode,  -- 관리항목코드
                nvl(a.mngcluval, '') as mngcluval,    -- 관리항목값
                nvl(a.mngcludec, '') as mngcludec,    -- 관리항목값명
                nvl(d.mngcluname, '') as mngcluname,  -- 관리항목명
                nvl(c.requireyn, '') as requireyn,    -- 필수입력여부
                nvl(c.returnyn, '') as returnyn,      -- 반제여부
                nvl(c.remainyn, '') as remainyn,      -- 잔액관리여부
                nvl(d.mngcludiv, '') as mngcludiv,    -- 관리항목형태
                nvl(d.codehelp, '') as codehelp,      -- 코드헬프번호
                nvl(d.remark, '') as codermk          -- 코드헬프비고
        from    ACORDS a
                join ACORDD b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
                left join ACACCMNGM c -- 관리항목필수여부
                    on b.acccode = c.acccode
                    and case when b.dcdiv in ('1', '4') then '1' else '2' end = c.dcdiv
                    and a.mngclucode = c.mngclucode
                left join ACMNGM -- 관리항목정보
                    d on a.mngclucode = d.mngclucode
        where   a.compcode = p_compcode
                and a.slipinno = upper(trim(p_slipinno))
        order by a.slipinseq, c.seq;

    -- 회계전표반제내역 검색
    elsif (p_div = 'SR') then
        open IO_CURSOR for
        select  a.compcode,
                a.rpyslipinno as slipinno,
                a.rpyslipinseq as slipinseq,
                a.slipinno as rpyslipinno,
                a.slipinseq as rpyslipinseq,
                a.repayamt,
                b.slipamt as sliptot,
                b.repayamt as repaytot
        from    ACORDRPYP a
                join ACORDRPYR b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq
        where   a.compcode = p_compcode
                and a.rpyslipinno = upper(trim(p_slipinno))
        order by a.rpyslipinno, a.rpyslipinseq, a.slipinno, a.slipinseq;

    -- 회계영업비용내역 검색
    elsif (p_div = 'SP') then
        open IO_CURSOR for
        select  a.compcode,
                a.slipinno,
                a.slipinseq,
                a.sctdiv,
                a.seqno,
                a.sectorcode,
                coalesce(b.deptname, c.empname, d.custname, e.itemname, '') as sectorname,
                a.applyper,
                a.remark
        from    SFORDEP a
                left join CMDEPTM b
                    on a.sctdiv = '2'
                    and a.sectorcode = b.deptcode
                left join CMEMPM c
                    on a.sctdiv = '3'
                    and a.sectorcode = c.empcode
                left join CMCUSTM d
                    on a.sctdiv = '4'
                    and a.sectorcode = d.custcode
                left join CMITEMM e
                    on a.sctdiv = '5'
                    and a.sectorcode = e.itemcode
        where   a.compcode = p_compcode
                and a.slipinno = upper(trim(p_slipinno))
        order by a.slipinno, a.slipinseq, seqno;

    -- 계정별 관리항목 검색
    elsif (p_div = 'SA') then
        open IO_CURSOR for
        select  nvl(a.seq, 0) as seq,                 -- 일련번호
                nvl(a.mngclucode, '') as mngclucode,  -- 관리항목코드
                '' as mngcluval,                      -- 관리항목값
                '' as mngcludec,                      -- 관리항목값명
                nvl(a.mngcluname, '') as mngcluname,  -- 관리항목명
                nvl(a.requireyn, '') as requireyn,    -- 필수입력여부
                nvl(a.returnyn, '') as returnyn,      -- 반제여부
                nvl(a.remainyn, '') as remainyn,      -- 잔액관리여부
                nvl(b.mngcludiv, '') as mngcludiv,    -- 관리항목형태
                nvl(b.codehelp, '') as codehelp,      -- 코드헬프번호
                nvl(b.remark, '') as codermk,         -- 코드헬프비고
                nvl(c.usediv, '9') as usediv,         -- 팝업
                nvl(c.popdiv, '') as popdiv,          -- 팝업종류
                nvl(c.popname, '') as popname,        -- 팝업명
                nvl(c.accdiv, '') as accdiv,          -- 팝업구분
                nvl(d.dcdiv, '') as adcdiv,           -- 계정차대구분
                nvl(d.returnyn, '') as returnynd      -- 전표반제여부
        from    ACACCMNGM a
                left join ACMNGM b -- 관리항목정보
                    on a.mngclucode = b.mngclucode
                left join (
                    select  nvl(a.filter1, '') as acccode,
                            nvl(a.filter2, '') as accdiv,
                            nvl(nullif(b.filter1, null), '0') as usediv,
                            nvl(b.filter2, '') as popdiv,
                            case when b.filter1 = '3' or p_slipdiv = 'R' and b.filter1 = '4' or p_slipdiv = 'A' and b.filter1 = '5' then b.divname else '' end as popname
                    from    CMCOMMONM a
                            join CMCOMMONM b
                                on a.hcmmcode = b.cmmcode
                                and a.hdivcode = b.divcode
                                and b.usediv = 'Y'
                    where   a.cmmcode = 'AC251'
                            and a.usediv = 'Y'
                ) c on a.acccode like c.acccode || '%'
                left join ACACCM d
                    on a.acccode = d.acccode
        where   a.acccode = p_acccode
                and a.dcdiv = case when p_dcdiv in ('1', '4') then '1' else '2' end
        order by a.seq;

    -- 계정팝업 검색
    elsif (p_div = 'AP') then
        open IO_CURSOR for
        select  nvl(a.acccode, '') as acccode,    -- 계정코드
                nvl(a.accname, '') as accname,    -- 계정명
                nvl(a.dcdiv, '') as adcdiv,       -- 계정차대구분
                nvl(b.usediv, '9') as usediv,     -- 팝업
                nvl(b.popdiv, '') as popdiv,      -- 팝업종류
                nvl(b.popname, '') as popname,    -- 팝업명
                nvl(b.accdiv, '') as accdiv,      -- 팝업구분
                nvl(a.returnyn, '') as returnyn   -- 반제여부
        from    ACACCM a
                left join (
                    select  nvl(a.filter1, '') as acccode,
                            nvl(a.filter2, '') as accdiv,
                            nvl(nullif(b.filter1, ' '), '0') as usediv,
                            nvl(b.filter2, '') as popdiv,
                            case when b.filter1 = '3' or p_slipdiv = 'R' and b.filter1 = '4' or p_slipdiv = 'A' and b.filter1 = '5' then b.divname else '' end as popname
                    from    CMCOMMONM a
                            join CMCOMMONM b
                                on a.hcmmcode = b.cmmcode
                                and a.hdivcode = b.divcode
                                and b.usediv = 'Y'
                    where   a.cmmcode = 'AC251'
                            and a.usediv = 'Y'
                ) b on a.acccode like b.acccode || '%'
        where   a.acccode = p_acccode;

    -- 매입부가세외상매입계정 검색
    elsif (p_div = 'AC25D') then
        open IO_CURSOR for
        select  divcode,
                divname,
                filter1
        from    CMCOMMONM
        where   cmmcode = 'AC25D'
                and divcode = p_acccode;

    -- 증빙구분 검색
    elsif (p_div = 'AC29') then
        open IO_CURSOR for
        select  divcode,
                divname,
                filter1,
                filter2
        from    CMCOMMONM
        where   cmmcode = 'AC29'
                and divcode = p_slipdiv;

    -- 법인카드사용계정 검색
    elsif (p_div = 'AC68') then
        open IO_CURSOR for
        select  a.divcode,
                d.acccode,
                d.accname,
                e.acccode as acccode2,
                e.accname as accname2,
                f.acccode as acccode3,
                f.accname as accname3
        from    CMCOMMONM a
                left join SYSPARAMETERMANAGE b
                    on b.parametercode = 'cardacccode'
                left join SYSPARAMETERMANAGE c
                    on c.parametercode = 'accountpopup'
                left join ACACCM d
                    on a.filter1 = d.acccode
                left join ACACCM e
                    on b.value1 = e.acccode
                left join ACACCM f
                    on c.value2 = f.acccode
        where  a.cmmcode = 'AC68';

    elsif (p_div = 'SB') then
        p_value1 := '';
        for rec in (
            select  value1
            from    SYSPARAMETERMANAGE
            where   parametercode = 'budgetacccode')
        loop
            p_value1 := rec.value1;
        end loop;

        execute immediate 'delete from VGT.TT_ACACC0000P_AACBUDGYY';
        insert into VGT.TT_ACACC0000P_AACBUDGYY
        select  a.compcode,
                substr(a.slipindate, 0, 7) || '-01' as slipindate,
                nvl(case when trim(e.deptcode) is not null then nvl(e.bdgdeptcode, f.bdgdeptcode) else f.bdgdeptcode end, c.mngcluval) as deptcode,
                nvl(d.budgcode, d.acccode) as acccode,
                nvl(max(i.budgctldiv), '2') as budgctldiv,
                min(b.slipinseq) as slipinseq
        from    ACORDM a
                join ACORDD b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                join ACORDS c
                    on b.compcode = c.compcode
                    and b.slipinno = c.slipinno
                    and b.slipinseq = c.slipinseq
                    and c.mngclucode = 'S040'
                join ACACCM d
                    on nvl(b.acccode,' ') = nvl(d.acccode,' ')
                    and (b.dcdiv in ('1', '4') and d.dcdiv = '1' or
                         b.dcdiv in ('2', '3') and d.dcdiv = '2')
                left join ACBDGDPT e
                    on a.compcode = e.compcode
                    and substr(a.slipindate, 0, 4) || '-01' = e.budgym
                    and c.mngcluval = e.deptcode
                left join CMDEPTM f
                    on c.mngcluval = f.deptcode
                left join ACBUDGM g
                    on a.compcode = g.compcode
                    and nvl(case when trim(e.deptcode) is not null then nvl(e.bdgdeptcode, f.bdgdeptcode) else f.bdgdeptcode end, c.mngcluval) = g.deptcode
                    and g.acccode = p_value1
                left join ACBUDGM h
                    on a.compcode = h.compcode
                    and nvl(case when trim(e.deptcode) is not null then nvl(e.bdgdeptcode, f.bdgdeptcode) else f.bdgdeptcode end, c.mngcluval) = h.deptcode
                    and nvl(d.budgcode, d.acccode) = h.acccode
                left join ACBUDGYY i
                    on a.compcode = i.compcode
                    and substr(a.slipinno, 0, 4) = i.cyear
                    and nvl(case when trim(e.deptcode) is not null then nvl(e.bdgdeptcode, f.bdgdeptcode) else f.bdgdeptcode end, c.mngcluval) = i.deptcode
                    and nvl(d.budgcode, d.acccode) = i.acccode
        where   a.compcode = p_compcode
                and a.slipinno = upper(trim(p_slipinno))
                and a.slipdiv <> 'F'
        group by a.compcode, substr(a.slipindate, 0, 7) || '-01', nvl(case when trim(e.deptcode) is not null then nvl(e.bdgdeptcode, f.bdgdeptcode) else f.bdgdeptcode end, c.mngcluval), nvl(d.budgcode, d.acccode)
        having max(coalesce(h.budglimityn, g.budglimityn, d.budglimityn, 'N')) = 'Y'
               and sum(case when d.dcdiv = '1' then b.debamt else b.creamt end) > 0;

        -- 회계시작월 설정
        p_strmon := '01';
        for rec in (
            select  *
            from (
                select  substr(curstrdate, 6, 2) as curstrdate
                from    ACSESSION
                where   compcode = p_compcode
                        and cyear <= (select  substr(slipindate, 0, 4)
                                      from    ACORDM
                                      where   compcode = p_compcode
                                              and slipinno = upper(trim(p_slipinno)))
                order by cyear desc
            )
            where  rownum = 1)
        loop
            p_strmon := rec.curstrdate;
        end loop;

        for rec in (
            select  substr(slipindate, 0, 7) as month0,
                    case when substr(slipindate, 6, 2) < p_strmon then to_char(add_months(to_date(slipindate, 'yyyy-MM-dd'), -12), 'yyyy-') || p_strmon else substr(slipindate, 0, 5) || p_strmon end month1
            from    VGT.TT_ACACC0000P_AACBUDGYY)
        loop
            p_month := rec.month0;
            p_month1 := rec.month1;
        end loop;

        p_month2 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 11), 'yyyy-MM');
        if p_month between p_month1 and to_char(add_months(to_date(p_month1, 'yyyy-MM'), 2), 'yyyy-MM') then
            p_month3 := p_month1;
            p_month4 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 2), 'yyyy-MM');
            p_month5 := p_month1;
            p_month6 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 5), 'yyyy-MM');
        elsif p_month between to_char(add_months(to_date(p_month1, 'yyyy-MM'), 3), 'yyyy-MM') and to_char(add_months(to_date(p_month1, 'yyyy-MM'), 5), 'yyyy-MM') then
            p_month3 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 3), 'yyyy-MM');
            p_month4 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 5), 'yyyy-MM');
            p_month5 := p_month1;
            p_month6 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 5), 'yyyy-MM');
        elsif p_month between to_char(add_months(to_date(p_month1, 'yyyy-MM'), 6), 'yyyy-MM') and to_char(add_months(to_date(p_month1, 'yyyy-MM'), 8), 'yyyy-MM') then
            p_month3 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 6), 'yyyy-MM');
            p_month4 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 8), 'yyyy-MM');
            p_month5 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 6), 'yyyy-MM');
            p_month6 := p_month2;
        else
            p_month3 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 9), 'yyyy-MM');
            p_month4 := p_month2;
            p_month5 := to_char(add_months(to_date(p_month1, 'yyyy-MM'), 6), 'yyyy-MM');
            p_month6 := p_month2;
        end if;

        p_budgemp := 'N';
        for rec in (
            select  value1
            from    SYSPARAMETERMANAGE
            where   parametercode = 'acempbudguse')
        loop
            p_budgemp := rec.value1;
        end loop;

        -- 부서예산체크
        MESSAGE := '';
        for rec in (
            select  *
            from (
                select  to_char(a.slipinseq) || ';' || fncomma(trunc(sum(b.restotamt - b.budgamt))) || ';' || case when p_budgemp = 'Y' then '부서' else '' end as rtnvalue
                from    VGT.TT_ACACC0000P_AACBUDGYY a
                        join ACBUDGMM b
                            on a.compcode = b.compcode
                            and a.deptcode = b.deptcode
                            and a.acccode = b.acccode
                            and b.budgym between case a.budgctldiv when '1' then p_month when '2' then p_month1 when '3' then p_month3 when '4' then p_month5 else p_month1 end
                                             and case a.budgctldiv when '1' then p_month when '2' then p_month when '3' then p_month4 when '4' then p_month6 else p_month2 end
                group by a.slipinseq
                having sum(b.restotamt - b.budgamt) > 0
            )
            where  rownum = 1)
        loop
            MESSAGE := rec.rtnvalue;
        end loop;

        -- 사원예산체크
        if trim(MESSAGE) is null and p_budgemp = 'Y' then
            execute immediate 'delete from VGT.TT_ACACC0000P_AACBUDGYYE';
            insert into VGT.TT_ACACC0000P_AACBUDGYYE
            select  a.compcode,
                    substr(a.slipindate, 0, 7) as budgym,
                    c.mngcluval as empcode,
                    nvl(d.ebdgcode, d.acccode) as acccode,
                    min(b.slipinseq) as slipinseq
            from    ACORDM a
                    join ACORDD b
                        on a.compcode = b.compcode
                        and a.slipinno = b.slipinno
                    join ACORDS c
                        on b.compcode = c.compcode
                        and b.slipinno = c.slipinno
                        and b.slipinseq = c.slipinseq
                        and c.mngclucode = 'S050'
                    join ACACCM d
                        on b.acccode = d.acccode
                        and (b.dcdiv in ('1', '4') and d.dcdiv = '1' or
                             b.dcdiv in ('2', '3') and d.dcdiv = '2')
            where   a.compcode = p_compcode
                    and a.slipinno = upper(trim(p_slipinno))
                    and a.slipdiv <> 'F'
            group by a.compcode, substr(a.slipindate, 0, 7), c.mngcluval, nvl(d.ebdgcode, d.acccode)
            having sum(case when d.dcdiv = '1' then b.debamt else b.creamt end) > 0;

            for rec in (
                select  *
                from (
                    select  to_char(a.slipinseq) || ';' || fncomma(trunc(b.slipamt - b.budgamt - b.addamt)) || ';' || '사원' as rtnvalue
                    from    VGT.TT_ACACC0000P_AACBUDGYYE a
                            join ACBUDGYYE b
                                on a.compcode = b.compcode
                                and a.budgym = b.budgym
                                and a.empcode = b.empcode
                                and a.acccode = b.acccode
                    where   b.slipamt - b.budgamt - b.addamt > 0
                )
                where  rownum = 1)
            loop
                MESSAGE := rec.rtnvalue;
            end loop;
        end if;

    -- 계정별 예산체크
    elsif (p_div = 'SBA') then
--        execute immediate 'delete from VGT.TT_ACACC0000P_AACBUDGYY';
--        insert into VGT.TT_ACACC0000P_AACBUDGYY
--        select  nvl(case when b.deptcode is not null then nvl(nullif(b.bdgdeptcode, null), c.bdgdeptcode) else c.bdgdeptcode end,  p_deptcode) as deptcode,
--                nvl(a.budgcode, a.acccode) as acccode,
--                nvl(f.budgctldiv, '2') as budgctldiv
--        from    ACACCM a
--                left join ACBDGDPT b
--                    on b.compcode = p_compcode
--                    and substr(p_slipsdate, 0, 4) || '-01' = b.budgym
--                    and b.deptcode = p_deptcode
--                left join CMDEPTM c
--                    on c.deptcode = p_deptcode
--                left join ACBUDGM d
--                    on d.compcode = p_compcode
--                    and nvl(case when trim(b.deptcode) is not null then nvl(b.bdgdeptcode, c.bdgdeptcode) else c.bdgdeptcode end, p_deptcode) = d.deptcode
--                left join ACBUDGM e
--                    on e.compcode = p_compcode
--                    and nvl(case when trim(b.deptcode) is not null then nvl(b.bdgdeptcode, c.bdgdeptcode) else c.bdgdeptcode end, p_deptcode) = e.deptcode
--                    and nvl(a.budgcode,a.acccode) = e.acccode
--                left join ACBUDGYY f
--                    on f.compcode = p_compcode
--                    and substr(p_slipsdate, 0, 4) = f.cyear
--                    and nvl(case when trim(b.deptcode) is not null then nvl(b.bdgdeptcode, c.bdgdeptcode) else c.bdgdeptcode end, p_deptcode) = f.deptcode
--                    and nvl(a.budgcode, a.acccode) = f.acccode
--                left join (
--                    select  value1
--                    from    SYSPARAMETERMANAGE
--                    where  upper(parametercode) = 'budgetacccode'
--                ) g on d.acccode = g. value1
--        where   a.acccode = p_acccode
--                and (p_dcdiv in ('1', '4') and a.dcdiv = '1' or
--                     p_dcdiv in ('2', '3') and a.dcdiv = '2')
--                and coalesce(e.budglimityn, d.budglimityn, d.budglimityn, 'N') = 'Y';

        -- 회계시작월 설정
        p_strmon := '01';
        for rec in (
            select  *
            from (
                select  substr(curstrdate, 6, 2) as strmon
                from    ACSESSION
                where   compcode = p_compcode
                        and cyear <= substr(p_slipsdate, 0, 4)
                order by cyear desc
            )
            where  rownum = 1)
        loop
            p_strmon := rec.strmon;
        end loop;

        if p_strmon is not null and p_slipsdate is not null then
            p_month := substr(p_slipsdate, 1, 7);
            p_month1 := case when substr(p_slipsdate, 6, 2) < p_strmon then to_char(add_months(to_date(p_slipsdate, 'yyyy-MM-dd'), -12), 'yyyy') || '-' || p_strmon else substr(p_slipsdate, 1, 5) || p_strmon end;
            p_month2 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 11), 'yyyy-MM');

            if p_month between p_month1 and to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 2), 'yyyy-MM') then
                p_month3 := p_month1;
                p_month4 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 2), 'yyyy-MM');
                p_month5 := p_month1;
                p_month6 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 5), 'yyyy-MM');
            elsif p_month between to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 3), 'yyyy-MM') and to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 5), 'yyyy-MM') then
                p_month3 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 3), 'yyyy-MM');
                p_month4 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 5), 'yyyy-MM');
                p_month5 := p_month1;
                p_month6 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 5), 'yyyy-MM');
            elsif p_month between to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 6), 'yyyy-MM') and to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 8), 'yyyy-MM') then
                p_month3 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 6), 'yyyy-MM');
                p_month4 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 8), 'yyyy-MM');
                p_month5 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 6), 'yyyy-MM');
                p_month6 := p_month2;
            else
                p_month3 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 9), 'yyyy-MM');
                p_month4 := p_month2;
                p_month5 := to_char(add_months(to_date(p_month1 || '-01', 'yyyy-MM-dd'), 6), 'yyyy-MM');
                p_month6 := p_month2;
            end if;
        end if;

        open IO_CURSOR for
        select  nvl(sum(b.budgamt - b.restotamt), 0) budgamt
        from (
            select  nvl(case when b.deptcode is not null then nvl(nullif(b.bdgdeptcode, null), c.bdgdeptcode) else c.bdgdeptcode end, p_deptcode) as deptcode,
                    nvl(a.budgcode, a.acccode) as acccode,
                    nvl(f.budgctldiv, '2') as budgctldiv
            from    ACACCM a
                    left join ACBDGDPT b
                        on b.compcode = p_compcode
                        and substr(p_slipsdate, 0, 4) || '-01' = b.budgym
                        and b.deptcode = p_deptcode
                    left join CMDEPTM c
                        on c.deptcode = p_deptcode
                    left join ACBUDGM d
                        on d.compcode = p_compcode
                        and nvl(case when trim(b.deptcode) is not null then nvl(b.bdgdeptcode, c.bdgdeptcode) else c.bdgdeptcode end, p_deptcode) = d.deptcode
                    left join ACBUDGM e
                        on e.compcode = p_compcode
                        and nvl(case when trim(b.deptcode) is not null then nvl(b.bdgdeptcode, c.bdgdeptcode) else c.bdgdeptcode end, p_deptcode) = e.deptcode
                        and nvl(a.budgcode, a.acccode) = e.acccode
                    left join ACBUDGYY f
                        on f.compcode = p_compcode
                        and substr(p_slipsdate, 0, 4) = f.cyear
                        and nvl(case when trim(b.deptcode) is not null then nvl(b.bdgdeptcode, c.bdgdeptcode) else c.bdgdeptcode end, p_deptcode) = f.deptcode
                        and nvl(a.budgcode, a.acccode) = f.acccode
                    left join (
                        select  value1
                        from    SYSPARAMETERMANAGE
                        where   upper(parametercode) = 'budgetacccode'
                    ) g on d.acccode = g.value1
            where   a.acccode = p_acccode
                    and (p_dcdiv in ('1', '4') and a.dcdiv = '1' or
                         p_dcdiv in ('2', '3') and a.dcdiv = '2')
                   and coalesce(e.budglimityn, d.budglimityn, d.budglimityn, 'N') = 'Y'
        ) a
                join ACBUDGMM b
                    on b.compcode = p_compcode
                    and a.deptcode = b.deptcode
                    and a.acccode = b.acccode
                    and b.budgym between case a.budgctldiv when '1' then p_month when '2' then p_month1 when '3' then p_month3 when '4' then p_month5 else p_month1 end
                                     and case a.budgctldiv when '1' then p_month when '2' then p_month when '3' then p_month4 when '4' then p_month6 else p_month2 end;

    end if;

    if (IO_CURSOR is null)
    then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;
END;
/
