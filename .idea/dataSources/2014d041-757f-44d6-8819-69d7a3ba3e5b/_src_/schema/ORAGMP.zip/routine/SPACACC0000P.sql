CREATE PROCEDURE        spACacc0000P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0000P
	-- 작 성 자         : 민승기
	-- 작성일자         : 2010-10-06
	--수정자          : 임정호
	-- 작성일자         : 2016-12-15
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 회계전표 테이블 내역을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------
	p_div			  IN	 VARCHAR2 DEFAULT '',
	p_compcode		  IN	 VARCHAR2 DEFAULT '',
	p_plantcode 	  IN	 VARCHAR2 DEFAULT '',
	p_slipsdate 	  IN	 VARCHAR2 DEFAULT '',
	p_slipedate 	  IN	 VARCHAR2 DEFAULT '',
	p_deptcode		  IN	 VARCHAR2 DEFAULT '',
	p_empcode		  IN	 VARCHAR2 DEFAULT '',
	p_slipdiv		  IN	 VARCHAR2 DEFAULT '',
	p_slipinno		  IN	 VARCHAR2 DEFAULT '',
	p_acccode		  IN	 VARCHAR2 DEFAULT '',
	p_dcdiv 		  IN	 VARCHAR2 DEFAULT '',
	p_slipinremark	  IN	 VARCHAR2 DEFAULT '', --결의내용 검색 조건
	p_userid		  IN	 VARCHAR2 DEFAULT '',
	p_reasondiv 	  IN	 VARCHAR2 DEFAULT '',
	p_reasontext	  IN	 VARCHAR2 DEFAULT '',
	IO_CURSOR			 OUT TYPES.DataSet,
	MESSAGE 			 OUT VARCHAR2
)
AS
	p_strmon	 VARCHAR2(2); -- 회기시작월
	p_month 	 VARCHAR2(7); -- 전표년월
	p_month1	 VARCHAR2(7); -- 당기시작년월
	p_month2	 VARCHAR2(7); -- 당기종료년월
	p_month3	 VARCHAR2(7); -- 분기시작년월
	p_month4	 VARCHAR2(7); -- 분기종료년월
	p_month5	 VARCHAR2(7); -- 반기시작년월
	p_month6	 VARCHAR2(7); -- 반기종료년월
	p_budgemp	 VARCHAR2(5);

	p_value1	 VARCHAR2(30);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);


	IF (UPPER(TRIM(p_div)) = 'SM')
	THEN
		OPEN IO_CURSOR FOR
			WITH TT_ACORDM
				 AS (SELECT a.compcode, -- 회사코드
							a.slipinno -- 전표번호
					 FROM	ACORDM a
					 WHERE	a.compcode = p_compcode
							AND a.slipdiv <> 'A'
							AND (p_slipinno IS NOT NULL
								 AND a.slipinno = upper(trim(p_slipinno))
								 AND a.deptcode LIKE p_deptcode || '%'
								 OR p_slipinno IS NULL
									AND a.plantcode LIKE p_plantcode || '%'
									AND a.slipdiv LIKE p_slipdiv || '%'
									AND a.slipindate BETWEEN p_slipsdate AND p_slipedate
									AND (p_empcode = p_userid
										 AND a.empcode = p_empcode
										 OR a.deptcode LIKE p_deptcode || '%'
											AND a.empcode LIKE p_empcode || '%')
									AND (a.slipinremark LIKE '%' || p_slipinremark || '%'
										 OR a.slipincomment LIKE '%' || p_slipinremark || '%'))
					 UNION
					 SELECT a.compcode, -- 회사코드
							a.slipinno -- 전표번호
					 FROM	ACORDM a
							JOIN ACORDD b
								ON a.compcode = b.compcode
								   AND a.slipinno = b.slipinno
					 WHERE	a.compcode = p_compcode
							AND a.slipdiv <> 'A'
							AND p_slipinno IS NULL
							AND a.plantcode LIKE p_plantcode || '%'
							AND a.slipdiv LIKE p_slipdiv || '%'
							AND a.slipindate BETWEEN p_slipsdate AND p_slipedate
							AND (p_empcode = p_userid
								 AND a.empcode = p_empcode
								 OR a.deptcode LIKE p_deptcode || '%'
									AND a.empcode LIKE p_empcode || '%')
							AND (b.remark1 LIKE '%' || p_slipinremark || '%'
								 OR b.remark2 LIKE '%' || p_slipinremark || '%')
					 UNION
					 SELECT a.compcode, -- 회사코드
							a.slipinno -- 전표번호
					 FROM	ACORDM a
							JOIN ACORDS b
								ON a.compcode = b.compcode
								   AND a.slipinno = b.slipinno
					 WHERE	a.compcode = p_compcode
							AND a.slipdiv <> 'A'
							AND p_slipinno IS NULL
							AND a.plantcode LIKE p_plantcode || '%'
							AND a.slipdiv LIKE p_slipdiv || '%'
							AND a.slipindate BETWEEN p_slipsdate AND p_slipedate
							AND (p_empcode = p_userid
								 AND a.empcode = p_empcode
								 OR a.deptcode LIKE p_deptcode || '%'
									AND a.empcode LIKE p_empcode || '%')
							AND (b.mngcluval LIKE '%' || p_slipinremark || '%'
								 OR b.mngcludec LIKE '%' || p_slipinremark || '%'))
			SELECT	 a.compcode compcode, -- 회사코드
					 a.slipinno slipinno, -- 전표번호
					 a.slipdiv slipdiv, -- 전표유형
					 a.slipindate slipindate, -- 발의일자
					 a.slipinnum slipinnum, -- 전표넘버
					 a.deptcode deptcode, -- 발의부서
					 a.plantcode plantcode, -- 사업장
					 a.empcode empcode, -- 발의자
					 a.eviddiv eviddiv, -- 증빙구분
					 a.slipinremark slipinremark, -- 발의내용
					 a.slipincomment slipincomment, -- 특이사항
					 a.slipno slipno, -- 승인번호
					 a.slipdate slipdate, -- 회계일자
					 a.slipnum slipnum, -- 승인넘버
					 a.slipdeptcode slipdeptcode, -- 승인부서
					 a.slipempcode slipempcode, -- 승인자
					 a.skreqyn skreqyn, -- 송금의뢰여부
					 a.skreqdiv skreqdiv, -- 송금의뢰유형
					 a.skreqdate skreqdate, -- 송금의뢰일자
					 a.skreqdeptcode skreqdeptcode, -- 송금의뢰부서
					 a.skreqempcode skreqempcode, -- 송금의뢰자
					 a.accountno accountno, -- 송금계좌코드
					 a.slipinstate slipinstate, -- 발의진행상태
					 a.slipremark slipremark, -- 발려사유
					 c.deptname deptname, -- 발의부서명
					 D.empname empname, -- 발의자명
					 E.deptname slipdeptname, -- 승인부서명
					 f.empname slipempname, -- 승인자명
					 G.deptname skreqdeptname, -- 송금의뢰부서명
					 h.empname skreqempname, -- 송금의뢰자명
					 i.divname skreqdivname -- 송금의뢰유형명
			FROM	 ACORDM a
					 JOIN TT_ACORDM b
						 ON a.compcode = b.compcode
							AND a.slipinno = b.slipinno
					 LEFT JOIN CMDEPTM c -- 발의부서
										ON a.deptcode = c.deptcode
					 LEFT JOIN CMEMPM D ON a.empcode = D.empcode -- 발의자
					 LEFT JOIN CMDEPTM E -- 승인부서
										ON a.slipdeptcode = E.deptcode
					 LEFT JOIN CMEMPM f -- 승인자
									   ON a.slipempcode = f.empcode
					 LEFT JOIN CMDEPTM G -- 송금의뢰부서
										ON a.skreqdeptcode = G.deptcode
					 LEFT JOIN CMEMPM h -- 송금의뢰자
									   ON a.skreqempcode = h.empcode
					 LEFT JOIN CMCOMMONM i -- 송금의뢰유형
						 ON i.cmmcode = 'AC27'
							AND a.skreqdiv = i.divcode
			ORDER BY a.slipinno;
	ELSIF (p_div = 'ST')
	THEN
		-- 결의전표상태 검색

		MESSAGE := '';

		FOR rec IN (SELECT SLIPINSTATE
					FROM   ACORDM
					WHERE  compcode = p_compcode
						   AND slipinno = upper(trim(p_slipinno)))
		LOOP
			MESSAGE := rec.slipinstate;
		END LOOP;
	ELSIF (p_div = 'SN')
	THEN
		-- 회계전표내역 검색

		OPEN IO_CURSOR FOR
			WITH TT_ACORDRPY
				 AS (SELECT DISTINCT a.compcode,
									 NVL(b.slipinno, c.slipinno) slipinno
					 FROM	ACORDM a
							LEFT JOIN ACORDRPYR b
								ON a.compcode = b.compcode
								   AND a.slipinno = b.slipinno
							LEFT JOIN ACORDRPYD c
								ON a.compcode = c.compcode
								   AND a.slipinno = c.slipinno
								   AND c.crtslipinno IS NOT NULL
					 WHERE	a.compcode = p_compcode
							AND a.slipinstate = '4'
							AND (p_slipinno IS NOT NULL
								 AND a.slipno = upper(trim(p_slipinno))
								 AND NVL(a.deptcode, ' ') LIKE p_deptcode || '%'
								 OR p_slipinno IS NULL
									AND a.plantcode LIKE p_plantcode || '%'
									AND a.slipdiv LIKE p_slipdiv || '%'
									AND a.slipdate BETWEEN p_slipsdate AND p_slipedate
									AND NVL(a.deptcode, ' ') LIKE p_deptcode || '%'
									AND a.empcode LIKE p_empcode || '%'
									AND (UPPER(a.slipinremark) LIKE UPPER('%' || p_slipinremark || '%')
										 OR UPPER(a.slipincomment) LIKE UPPER('%' || p_slipinremark || '%')))),
				 TT_ACORDM2
				 AS (SELECT a.compcode, -- 회사코드
							a.slipinno -- 전표번호
					 FROM	ACORDM a
					 WHERE	a.compcode = p_compcode
							AND a.slipinstate = '4'
							AND (p_slipinno IS NOT NULL
								 AND a.slipno = upper(trim(p_slipinno))
								 AND NVL(a.deptcode, ' ') LIKE p_deptcode || '%'
								 OR p_slipinno IS NULL
									AND a.plantcode LIKE p_plantcode || '%'
									AND a.slipdiv LIKE p_slipdiv || '%'
									AND a.slipdate BETWEEN p_slipsdate AND p_slipedate
									AND NVL(a.deptcode, ' ') LIKE p_deptcode || '%'
									AND a.empcode LIKE p_empcode || '%'
									AND (UPPER(a.slipinremark) LIKE UPPER('%' || p_slipinremark || '%')
										 OR UPPER(a.slipincomment) LIKE UPPER('%' || p_slipinremark || '%')))
					 UNION
					 SELECT a.compcode, -- 회사코드
							a.slipinno -- 전표번호
					 FROM	ACORDM a
							JOIN ACORDD b
								ON a.compcode = b.compcode
								   AND a.slipinno = b.slipinno
					 WHERE	a.compcode = p_compcode
							AND a.slipinstate = '4'
							AND p_slipinno IS NULL
							AND a.plantcode LIKE p_plantcode || '%'
							AND a.slipdiv LIKE p_slipdiv || '%'
							AND a.slipdate BETWEEN p_slipsdate AND p_slipedate
							AND NVL(a.deptcode, ' ') LIKE p_deptcode || '%'
							AND a.empcode LIKE p_empcode || '%'
							AND (UPPER(b.remark1) LIKE UPPER('%' || p_slipinremark || '%')
								 OR UPPER(b.remark2) LIKE UPPER('%' || p_slipinremark || '%'))
					 UNION
					 SELECT a.compcode, -- 회사코드
							a.slipinno -- 전표번호
					 FROM	ACORDM a
							JOIN ACORDS b
								ON a.compcode = b.compcode
								   AND a.slipinno = b.slipinno
					 WHERE	a.compcode = p_compcode
							AND a.slipinstate = '4'
							AND p_slipinno IS NULL
							AND a.plantcode LIKE p_plantcode || '%'
							AND a.slipdiv LIKE p_slipdiv || '%'
							AND a.slipdate BETWEEN p_slipsdate AND p_slipedate
							AND NVL(a.deptcode, ' ') LIKE p_deptcode || '%'
							AND a.empcode LIKE p_empcode || '%'
							AND (UPPER(b.mngcluval) LIKE UPPER('%' || p_slipinremark || '%')
								 OR UPPER(b.mngcludec) LIKE UPPER('%' || p_slipinremark || '%')))
			SELECT	 NVL(a.compcode, '') compcode, -- 회사코드
					 NVL(a.slipinno, '') slipinno, -- 전표번호
					 NVL(a.slipdiv, '') slipdiv, -- 전표유형
					 NVL(a.slipindate, '') slipindate, -- 발의일자
					 NVL(a.slipinnum, '') slipinnum, -- 전표넘버
					 NVL(a.deptcode, '') deptcode, -- 발의부서
					 NVL(a.plantcode, '') plantcode, -- 사업장
					 NVL(a.empcode, '') empcode, -- 발의자
					 NVL(a.eviddiv, '') eviddiv, -- 증빙구분
					 NVL(a.slipinremark, '') slipinremark, -- 발의내용
					 NVL(a.slipincomment, '') slipincomment, -- 특이사항
					 NVL(a.slipno, '') slipno, -- 승인번호
					 NVL(a.slipdate, '') slipdate, -- 회계일자
					 NVL(a.slipnum, '') slipnum, -- 승인넘버
					 NVL(a.slipdeptcode, '') slipdeptcode, -- 승인부서
					 NVL(a.slipempcode, '') slipempcode, -- 승인자
					 NVL(a.skreqyn, '') skreqyn, -- 송금의뢰여부
					 NVL(a.skreqdiv, '') skreqdiv, -- 송금의뢰유형
					 NVL(a.skreqdate, '') skreqdate, -- 송금의뢰일자
					 NVL(a.skreqdeptcode, '') skreqdeptcode, -- 송금의뢰부서
					 NVL(a.skreqempcode, '') skreqempcode, -- 송금의뢰자
					 NVL(a.accountno, '') accountno, -- 송금계좌코드
					 NVL(a.slipinstate, '') slipinstate, -- 발의진행상태
					 NVL(D.deptname, '') deptname, -- 발의부서명
					 NVL(E.empname, '') empname, -- 발의자명
					 NVL(f.deptname, '') slipdeptname, -- 승인부서명
					 NVL(G.empname, '') slipempname, -- 승인자명
					 NVL(h.deptname, '') skreqdeptname, -- 송금의뢰부서명
					 NVL(i.empname, '') skreqempname, -- 송금의뢰자명
					 NVL(j.divname, '') skreqdivname, -- 송금의뢰유형명
					 CASE WHEN NVL(c.slipinno, ' ') <> ' ' THEN 'Y' ELSE 'N' END rpyyn -- 반제처리여부
			FROM	 ACORDM a
					 JOIN TT_ACORDM2 b
						 ON a.compcode = b.compcode
							AND a.slipinno = b.slipinno
					 LEFT JOIN tt_ACORDRPY c -- 반제전표
						 ON a.compcode = c.compcode
							AND a.slipinno = c.slipinno
					 LEFT JOIN CMDEPTM D -- 발의부서
										ON a.deptcode = D.deptcode
					 LEFT JOIN CMEMPM E -- 발의자
									   ON a.empcode = E.empcode
					 LEFT JOIN CMDEPTM f -- 승인부서
										ON a.slipdeptcode = f.deptcode
					 LEFT JOIN CMEMPM G -- 승인자
									   ON a.slipempcode = G.empcode
					 LEFT JOIN CMDEPTM h -- 송금의뢰부서
										ON a.skreqdeptcode = h.deptcode
					 LEFT JOIN CMEMPM i -- 송금의뢰자
									   ON a.skreqempcode = i.empcode
					 LEFT JOIN CMCOMMONM j -- 송금의뢰유형
						 ON j.cmmcode = 'AC27'
							AND a.skreqdiv = j.divcode
			ORDER BY a.slipno;
	ELSIF (p_div = 'SD')
	THEN
		-- 회계전표상세내역 검색
		OPEN IO_CURSOR FOR
			SELECT	 NVL(a.compcode, '') compcode, -- 회사코드
					 NVL(a.slipinno, '') slipinno, -- 전표번호
					 NVL(a.slipinseq, 0) slipinseq, -- 순번
					 NVL(a.dcdiv, '') dcdiv, -- 차대구분
					 NVL(a.acccode, '') acccode, -- 계정코드
					 NVL(a.plantcode, '') plantcode, -- 사업장
					 NVL(a.debamt, 0) debamt, -- 차변금액
					 NVL(a.creamt, 0) creamt, -- 대변금액
					 NVL(a.slipdate, '') slipdate, -- 회계일자
					 NVL(a.slipnum, '') slipnum, -- 승인넘버
					 NVL(a.remark1, '') remark1, -- 적요
					 NVL(a.fundcode, '') fundcode, -- 자금구분
					 NVL(f.fundname, '') fundname, -- 자금구분명
					 NVL(a.remark2, '') remark2, -- 적요2
					 NVL(a.taxno, '') taxno, -- 계산서번호
					 NVL(a.datadiv, '') datadiv, -- 외부연동
					 NVL(a.rptseq, '') rptseq, -- 출력순번
					 NVL(b.accname, '') accname, -- 계정명
					 NVL(c.usediv, '9') usediv, -- 팝업
					 NVL(c.popdiv, '') popdiv, -- 팝업종류
					 '' popname, -- 팝업명
					 NVL(c.accdiv, '') accdiv, -- 팝업구분
					 NVL(b.dcdiv, '') adcdiv, -- 계정차대구분
					 NVL(D.appr_date, '') extr_date, -- 사이버브랜치 거래일자
					 NVL(D.appr_time, '') extr_bank, -- 사이버브랜치 거래시간
					 NVL(D.appr_nb, '') extr_no, -- 사이버브랜치 승인번호
					 NVL(D.slipdiv, '') extr_div, -- 사이버브랜치 분개방법
					 NVL(E.sliptot, 0) sliptot, -- 반제원전표금액
					 NVL(E.repaytot, 0) repaytot, -- 반제총금액
					 NVL(E.repayamt, 0) repayamt, -- 반제금액
					 NVL(b.returnyn, '') returnyn -- 반제여부
			FROM	 ACORDD a
					 LEFT JOIN ACACCM b -- 계정과목
									   ON a.acccode = b.acccode
					 LEFT JOIN (SELECT NVL(a.filter1, '') acccode,
									   NVL(a.filter2, '') accdiv,
									   DECODE(B.filter1, NULL, NULL, B.filter1) usediv,
									   NVL(b.filter2, '') popdiv,
									   CASE
										   WHEN (b.filter1 = '3'
												 OR p_slipdiv = 'R')
												AND (b.filter1 = '4'
													 OR p_slipdiv = 'A')
												AND (b.filter1 = '5')
										   THEN
											   b.divname
										   ELSE
											   NULL
									   END
										   popname
								FROM   CMCOMMONM a
									   JOIN CMCOMMONM b
										   ON a.hcmmcode = b.cmmcode
											  AND a.hdivcode = b.divcode
											  AND b.usediv = 'Y'
								WHERE  a.cmmcode = 'AC251'
									   AND a.usediv = 'Y') c
						 ON a.acccode LIKE c.acccode || '%'
					 LEFT JOIN (SELECT *
								FROM   ACORDCARD
								WHERE  compcode = p_compcode
									   AND slipinno = upper(trim(p_slipinno))) D
						 ON a.compcode = D.compcode
							AND a.slipinno = D.slipinno
							AND a.slipinseq = D.slipinseq
					 LEFT JOIN (SELECT	 a.rpyslipinno,
										 a.rpyslipinseq,
										 SUM(a.repayamt) repayamt,
										 MAX(b.slipamt) sliptot,
										 MAX(b.repayamt) repaytot
								FROM	 ACORDRPYP a
										 JOIN ACORDRPYR b
											 ON a.compcode = b.compcode
												AND a.slipinno = b.slipinno
												AND a.slipinseq = b.slipinseq
								WHERE	 a.compcode = p_compcode
										 AND a.rpyslipinno = upper(trim(p_slipinno))
								GROUP BY a.rpyslipinno, a.rpyslipinseq
								UNION
								SELECT	 a.slipinno,
										 a.slipinseq,
										 MAX(a.debamt + a.creamt) repayamt,
										 MAX(a.debamt + a.creamt) sliptot,
										 MAX(a.debamt + a.creamt) repaytot
								FROM	 ACORDD a
										 JOIN ACORDRPYD b
											 ON a.compcode = b.compcode
												AND a.slipinno = b.crtslipinno
										 JOIN ACACCM c
											 ON a.acccode = c.acccode
												AND c.returnyn = 'Y'
										 LEFT JOIN (SELECT	 a.rpyslipinno,
															 a.rpyslipinseq
													FROM	 ACORDRPYP a
															 JOIN ACORDRPYR b
																 ON a.compcode = b.compcode
																	AND a.slipinno = b.slipinno
																	AND a.slipinseq = b.slipinseq
													WHERE	 a.compcode = p_compcode
															 AND a.rpyslipinno = upper(trim(p_slipinno))
													GROUP BY a.rpyslipinno, a.rpyslipinseq) D
											 ON a.slipinno = D.rpyslipinno
												AND a.slipinseq = D.rpyslipinseq
								WHERE	 a.compcode = p_compcode
										 AND a.slipinno = upper(trim(p_slipinno))
										 AND D.rpyslipinno IS NULL
								GROUP BY a.slipinno, a.slipinseq) E
						 ON a.slipinno = E.rpyslipinno
							AND a.slipinseq = E.rpyslipinseq
					 LEFT JOIN ACFUNDM f
						 ON a.compcode = f.compcode
							AND a.fundcode = f.fundcode
			WHERE	 a.compcode = p_compcode
					 AND a.slipinno = upper(trim(p_slipinno))
			ORDER BY a.rptseq;
	ELSIF (p_div = 'SS')
	THEN
		-- 회계전표관리항목내역 검색

		OPEN IO_CURSOR FOR
			SELECT	 NVL(a.compcode, '') compcode, -- 회사코드
					 NVL(a.slipinno, '') slipinno, -- 전표번호
					 NVL(a.slipinseq, 0) slipinseq, -- 순번
					 NVL(a.seq, 0) seq, -- 일련번호
					 NVL(a.mngclucode, '') mngclucode, -- 관리항목코드
					 NVL(a.mngcluval, '') mngcluval, -- 관리항목값
					 NVL(a.mngcludec, '') mngcludec, -- 관리항목값명
					 NVL(D.mngcluname, '') mngcluname, -- 관리항목명
					 NVL(c.requireyn, '') requireyn, -- 필수입력여부
					 NVL(c.returnyn, '') returnyn, -- 반제여부
					 NVL(c.remainyn, '') remainyn, -- 잔액관리여부
					 NVL(D.mngcludiv, '') mngcludiv, -- 관리항목형태
					 NVL(D.codehelp, '') codehelp, -- 코드헬프번호
					 NVL(D.remark, '') codermk -- 코드헬프비고
			FROM	 ACORDS a
					 JOIN ACORDD b
						 ON a.compcode = b.compcode
							AND a.slipinno = b.slipinno
							AND a.slipinseq = b.slipinseq
					 LEFT JOIN ACACCMNGM c -- 관리항목필수여부
						 ON b.acccode = c.acccode
							AND CASE WHEN b.dcdiv IN ('1', '4') THEN '1' ELSE '2' END = c.dcdiv
							AND a.mngclucode = c.mngclucode
					 LEFT JOIN ACMNGM -- 관리항목정보
									 D ON a.mngclucode = D.mngclucode
			WHERE	 a.compcode = p_compcode
					 AND a.slipinno = upper(trim(p_slipinno))
			ORDER BY a.slipinseq, c.seq;
	ELSIF (p_div = 'SR')
	THEN
		-- 회계전표반제내역 검색


		OPEN IO_CURSOR FOR
			SELECT	 a.compcode,
					 a.rpyslipinno slipinno,
					 a.rpyslipinseq slipinseq,
					 a.slipinno rpyslipinno,
					 a.slipinseq rpyslipinseq,
					 a.repayamt,
					 b.slipamt sliptot,
					 b.repayamt repaytot
			FROM	 ACORDRPYP a
					 JOIN ACORDRPYR b
						 ON a.compcode = b.compcode
							AND a.slipinno = b.slipinno
							AND a.slipinseq = b.slipinseq
			WHERE	 a.compcode = p_compcode
					 AND a.rpyslipinno = upper(trim(p_slipinno))
			ORDER BY a.rpyslipinno, a.rpyslipinseq, a.slipinno, a.slipinseq;
	ELSIF (p_div = 'SP')
	THEN
		-- 회계영업비용내역 검색
		OPEN IO_CURSOR FOR
			SELECT	 a.compcode,
					 a.slipinno,
					 a.slipinseq,
					 a.sctdiv,
					 a.seqno,
					 a.sectorcode,
					 COALESCE(b.deptname, c.empname, D.custname, E.itemname, '') sectorname,
					 a.applyper,
					 a.remark
			FROM	 SFORDEP a
					 LEFT JOIN CMDEPTM b
						 ON a.sctdiv = '2'
							AND a.sectorcode = b.deptcode
					 LEFT JOIN CMEMPM c
						 ON a.sctdiv = '3'
							AND a.sectorcode = c.empcode
					 LEFT JOIN CMCUSTM D
						 ON a.sctdiv = '4'
							AND a.sectorcode = D.custcode
					 LEFT JOIN CMITEMM E
						 ON a.sctdiv = '5'
							AND a.sectorcode = E.itemcode
			WHERE	 a.compcode = p_compcode
					 AND a.slipinno = upper(trim(p_slipinno))
			ORDER BY a.slipinno, a.slipinseq, seqno;
	ELSIF (p_div = 'SA')
	THEN
		-- 계정별 관리항목 검색
		OPEN IO_CURSOR FOR
			SELECT	 NVL(a.seq, 0) seq, -- 일련번호
					 NVL(a.mngclucode, '') mngclucode, -- 관리항목코드
					 '' mngcluval, -- 관리항목값
					 '' mngcludec, -- 관리항목값명
					 NVL(a.mngcluname, '') mngcluname, -- 관리항목명
					 NVL(a.requireyn, '') requireyn, -- 필수입력여부
					 NVL(a.returnyn, '') returnyn, -- 반제여부
					 NVL(a.remainyn, '') remainyn, -- 잔액관리여부
					 NVL(b.mngcludiv, '') mngcludiv, -- 관리항목형태
					 NVL(b.codehelp, '') codehelp, -- 코드헬프번호
					 NVL(b.remark, '') codermk, -- 코드헬프비고
					 NVL(c.usediv, '9') usediv, -- 팝업
					 NVL(c.popdiv, '') popdiv, -- 팝업종류
					 NVL(c.popname, '') popname, -- 팝업명
					 NVL(c.accdiv, '') accdiv, -- 팝업구분
					 NVL(D.dcdiv, '') adcdiv, -- 계정차대구분
					 NVL(D.returnyn, '') returnynD -- 전표반제여부
			FROM	 ACACCMNGM a
					 LEFT JOIN ACMNGM b -- 관리항목정보
									   ON a.mngclucode = b.mngclucode
					 LEFT JOIN (SELECT NVL(a.filter1, '') acccode,
									   NVL(a.filter2, '') accdiv,
									   NVL(NULLIF(b.filter1, NULL), '0') usediv,
									   NVL(b.filter2, '') popdiv,
									   CASE
										   WHEN b.filter1 = '3'
												OR p_slipdiv = 'R'
												   AND b.filter1 = '4'
												OR p_slipdiv = 'A'
												   AND b.filter1 = '5'
										   THEN
											   b.divname
										   ELSE
											   ''
									   END
										   popname
								FROM   CMCOMMONM a
									   JOIN CMCOMMONM b
										   ON a.hcmmcode = b.cmmcode
											  AND a.hdivcode = b.divcode
											  AND b.usediv = 'Y'
								WHERE  a.cmmcode = 'AC251'
									   AND a.usediv = 'Y') c
						 ON a.acccode LIKE c.acccode || '%'
					 LEFT JOIN ACACCM D ON a.acccode = D.acccode
			WHERE	 a.acccode = p_acccode
					 AND a.dcdiv = CASE WHEN p_dcdiv IN ('1', '4') THEN '1' ELSE '2' END
			ORDER BY a.seq;
	ELSIF (p_div = 'AP')
	THEN
		-- 계정팝업 검색
		OPEN IO_CURSOR FOR
			SELECT NVL(a.acccode, '') acccode, -- 계정코드
				   NVL(a.accname, '') accname, -- 계정명
				   NVL(a.dcdiv, '') adcdiv, -- 계정차대구분
				   NVL(b.usediv, '9') usediv, -- 팝업
				   NVL(b.popdiv, '') popdiv, -- 팝업종류
				   NVL(b.popname, '') popname, -- 팝업명
				   NVL(b.accdiv, '') accdiv, -- 팝업구분
				   NVL(a.returnyn, '') returnyn -- 반제여부
			FROM   ACACCM a
				   LEFT JOIN (SELECT NVL(a.filter1, '') acccode,
									 NVL(a.filter2, '') accdiv,
									 NVL(NULLIF(b.filter1, ' '), '0') usediv,
									 NVL(b.filter2, '') popdiv,
									 CASE
										 WHEN b.filter1 = '3'
											  OR p_slipdiv = 'R'
												 AND b.filter1 = '4'
											  OR p_slipdiv = 'A'
												 AND b.filter1 = '5'
										 THEN
											 b.divname
										 ELSE
											 ''
									 END
										 popname
							  FROM	 CMCOMMONM a
									 JOIN CMCOMMONM b
										 ON a.hcmmcode = b.cmmcode
											AND a.hdivcode = b.divcode
											AND b.usediv = 'Y'
							  WHERE  a.cmmcode = 'AC251'
									 AND a.usediv = 'Y') b
					   ON a.acccode LIKE b.acccode || '%'
			WHERE  a.acccode = p_acccode;
	ELSIF (p_div = 'AC29')
	THEN
		-- 공통항목 검색

		OPEN IO_CURSOR FOR
			SELECT divcode,
				   divname,
				   filter1,
				   filter2
			FROM   CMCOMMONM
			WHERE  cmmcode = 'AC29'
				   AND divcode = p_slipdiv;
	ELSIF (p_div = 'AC68')
	THEN
		-- 공통항목 검색
		OPEN IO_CURSOR FOR
			SELECT a.divcode,
				   D.acccode,
				   D.accname,
				   E.acccode acccode2,
				   E.accname accname2,
				   f.acccode acccode3,
				   f.accname accname3
			FROM   CMCOMMONM a
				   LEFT JOIN SYSPARAMETERMANAGE b ON b.parametercode = 'cardacccode'
				   LEFT JOIN SYSPARAMETERMANAGE c ON c.parametercode = 'accountpopup'
				   LEFT JOIN ACACCM D ON a.filter1 = D.acccode
				   LEFT JOIN ACACCM E ON b.value1 = E.acccode
				   LEFT JOIN ACACCM f ON c.value2 = f.acccode
			WHERE  a.cmmcode = 'AC68';
	ELSIF (p_div = 'SB')
	THEN
		p_value1 := '';

		FOR REC IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'budgetacccode')
		LOOP
			p_value1 := REC.value1;
		END LOOP;

		EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0000P_AACBUDGYY';

		INSERT INTO VGT.TT_ACACC0000P_AACBUDGYY
			(SELECT   a.compcode,
					  SUBSTR(a.slipindate, 0, 7) || '-01' slipindate,
					  NVL(CASE WHEN TRIM(e.deptcode) IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval) deptcode,
					  NVL(d.budgcode, d.acccode) acccode,
					  NVL(MAX(i.budgctldiv), '2') budgctldiv,
					  MIN(b.slipinseq) slipinseq
			 FROM	  ACORDM a
					  JOIN ACORDD b
						  ON a.compcode = b.compcode
							 AND a.slipinno = b.slipinno
					  JOIN ACORDS c
						  ON b.compcode = c.compcode
							 AND b.slipinno = c.slipinno
							 AND b.slipinseq = c.slipinseq
							 AND c.mngclucode = 'S040'
					  JOIN ACACCM d
						  ON NVL(b.acccode,' ') = NVL(d.acccode,' ')
							 AND (b.dcdiv IN ('1', '4')
								  AND d.dcdiv = '1'
								  OR b.dcdiv IN ('2', '3')
									 AND d.dcdiv = '2')
					  LEFT JOIN ACBDGDPT e
						  ON a.compcode = e.compcode
							 AND SUBSTR(a.slipindate, 0, 4) || '-01' = e.budgym
							 AND c.mngcluval = e.deptcode
					  LEFT JOIN CMDEPTM f ON c.mngcluval = f.deptcode
					  LEFT JOIN ACBUDGM g
						  ON a.compcode = g.compcode
							 AND NVL(CASE WHEN TRIM(e.deptcode) IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval) = g.deptcode
							 AND g.acccode = p_value1
					  LEFT JOIN ACBUDGM h
						  ON a.compcode = h.compcode
							 AND NVL(CASE WHEN TRIM(e.deptcode) IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval) = h.deptcode
							 AND NVL(d.budgcode, d.acccode) = h.acccode
					  LEFT JOIN ACBUDGYY i
						  ON a.compcode = i.compcode
							 AND SUBSTR(a.slipinno, 0, 4) = i.cyear
							 AND NVL(CASE WHEN TRIM(e.deptcode) IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval) = i.deptcode
							 AND NVL(d.budgcode, d.acccode) = i.acccode
			 WHERE	  a.compcode = p_compcode
					  AND a.slipinno = upper(trim(p_slipinno))
					  AND a.slipdiv <> 'F'
			 GROUP BY a.compcode, SUBSTR(a.slipindate, 0, 7) || '-01', NVL(CASE WHEN TRIM(e.deptcode) IS NOT NULL THEN NVL(e.bdgdeptcode, f.bdgdeptcode) ELSE f.bdgdeptcode END, c.mngcluval), NVL(d.budgcode, d.acccode)
			 HAVING   MAX(COALESCE(h.budglimityn, g.budglimityn, d.budglimityn, 'N')) = 'Y'
					  AND SUM(CASE WHEN d.dcdiv = '1' THEN b.debamt ELSE b.creamt END) > 0);

		-- 회계시작월 설정
		p_strmon := '01';

		FOR REC IN (SELECT *
					FROM   (SELECT	 SUBSTR(curstrdate, 6, 2) curstrdate
							FROM	 ACSESSION
							WHERE	 compcode = p_compcode
									 AND cyear <= (SELECT SUBSTR(slipindate, 0, 4)
												   FROM   ACORDM
												   WHERE  compcode = p_compcode
														  AND slipinno = upper(trim(p_slipinno)))
							ORDER BY cyear DESC)
					WHERE  ROWNUM = 1)
		LOOP
			p_strmon := REC.curstrdate;
		END LOOP;

		FOR REC IN (SELECT SUBSTR(slipindate, 0, 7) slipindate,
						   CASE WHEN SUBSTR(slipindate, 6, 2) < p_strmon THEN TO_CHAR(ADD_MONTHS(TO_DATE(slipindate, 'YYYY-MM-DD'), -12), 'YYYY-') || p_strmon ELSE SUBSTR(slipindate, 0, 5) || p_strmon END T2
					FROM   VGT.TT_ACACC0000P_AACBUDGYY)
		LOOP
			p_month := REC.slipindate;
			p_month1 := REC.T2;
		END LOOP;



		p_month2 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 11), 'YYYY-MM');


		IF p_month BETWEEN p_month1 AND TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 2), 'YYYY-MM')
		THEN
			p_month3 := p_month1;
			p_month4 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 2), 'YYYY-MM');
			p_month5 := p_month1;
			p_month6 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 5), 'YYYY-MM');
		ELSIF p_month BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 3), 'YYYY-MM') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 5), 'YYYY-MM')
		THEN
			p_month3 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 3), 'YYYY-MM');
			p_month4 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 5), 'YYYY-MM');
			p_month5 := p_month1;
			p_month6 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 5), 'YYYY-MM');
		ELSIF p_month BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 6), 'YYYY-MM') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 8), 'YYYY-MM')
		THEN
			p_month3 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 6), 'YYYY-MM');
			p_month4 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 8), 'YYYY-MM');
			p_month5 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 6), 'YYYY-MM');
			p_month6 := p_month2;
		ELSE
			p_month3 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 9), 'YYYY-MM');
			p_month4 := p_month2;
			p_month5 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1, 'YYYY-MM'), 6), 'YYYY-MM');
			p_month6 := p_month2;
		END IF;

		p_budgemp := 'N';

		FOR REC IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'acempbudguse')
		LOOP
			p_budgemp := REC.value1;
		END LOOP;

		-- 부서예산체크
		MESSAGE := '';

		FOR REC
			IN (SELECT *
				FROM   (SELECT	 TO_CHAR(a.slipinseq) || ';' || FNCOMMA(TRUNC(SUM(b.restotamt - b.budgamt))) || ';' || CASE WHEN p_budgemp = 'Y' THEN '부서' ELSE '' END T1
						FROM	 VGT.TT_ACACC0000P_AACBUDGYY a
								 JOIN
								 ACBUDGMM b
									 ON a.compcode = b.compcode
										AND a.deptcode = b.deptcode
										AND a.acccode = b.acccode
										AND b.budgym BETWEEN CASE a.budgctldiv WHEN '1' THEN p_month WHEN '2' THEN p_month1 WHEN '3' THEN p_month3 WHEN '4' THEN p_month5 ELSE p_month1 END
														 AND CASE a.budgctldiv WHEN '1' THEN p_month WHEN '2' THEN p_month WHEN '3' THEN p_month4 WHEN '4' THEN p_month6 ELSE p_month2 END
						GROUP BY a.slipinseq
						HAVING	 SUM(b.restotamt - b.budgamt) > 0)
				WHERE  ROWNUM = 1)
		LOOP
			MESSAGE := REC.T1;
		END LOOP;

		-- 사원예산체크
		IF TRIM(MESSAGE) IS NULL
		   AND p_budgemp = 'Y'
		THEN
			EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0000P_AACBUDGYYE';

			INSERT INTO VGT.TT_ACACC0000P_AACBUDGYYE
				(SELECT   a.compcode,
						  SUBSTR(a.slipindate, 0, 7) budgym,
						  c.mngcluval empcode,
						  NVL(d.ebdgcode, d.acccode) acccode,
						  MIN(b.slipinseq) slipinseq
				 FROM	  ACORDM a
						  JOIN ACORDD b
							  ON a.compcode = b.compcode
								 AND a.slipinno = b.slipinno
						  JOIN ACORDS c
							  ON b.compcode = c.compcode
								 AND b.slipinno = c.slipinno
								 AND b.slipinseq = c.slipinseq
								 AND c.mngclucode = 'S050'
						  JOIN ACACCM d
							  ON b.acccode = d.acccode
								 AND (b.dcdiv IN ('1', '4')
									  AND d.dcdiv = '1'
									  OR b.dcdiv IN ('2', '3')
										 AND d.dcdiv = '2')
				 WHERE	  a.compcode = p_compcode
						  AND a.slipinno = upper(trim(p_slipinno))
						  AND a.slipdiv <> 'F'
				 GROUP BY a.compcode, SUBSTR(a.slipindate, 0, 7), c.mngcluval, NVL(d.ebdgcode, d.acccode)
				 HAVING   SUM(CASE WHEN d.dcdiv = '1' THEN b.debamt ELSE b.creamt END) > 0);

			FOR REC IN (SELECT *
						FROM   (SELECT TO_CHAR(a.slipinseq) || ';' || FNCOMMA(TRUNC(b.slipamt - b.budgamt - b.addamt)) || ';' || '사원' T1
								FROM   VGT.TT_ACACC0000P_AACBUDGYYE a
									   JOIN ACBUDGYYE b
										   ON a.compcode = b.compcode
											  AND a.budgym = b.budgym
											  AND a.empcode = b.empcode
											  AND a.acccode = b.acccode
								WHERE  b.slipamt - b.budgamt - b.addamt > 0)
						WHERE  ROWNUM = 1)
			LOOP
				MESSAGE := REC.T1;
			END LOOP;
		END IF;
	ELSIF (p_div = 'SBA')
	THEN
		-- 계정별 예산체크
		--        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0000P_AACBUDGYY ';
		--
		--        INSERT INTO VGT.TT_ACACC0000P_AACBUDGYY
		--
		--        SELECT  NVL(CASE WHEN b.deptcode IS NOT NULL THEN NVL(NULLIF(b.bdgdeptcode, NULL), c.bdgdeptcode) ELSE c.bdgdeptcode END,  p_deptcode) deptcode,
		--                NVL(a.budgcode, a.acccode) acccode,
		--                NVL(f.budgctldiv, '2') budgctldiv
		--        FROM    ACACCM a
		--                LEFT JOIN ACBDGDPT b
		--                    ON b.compcode = p_compcode
		--                       AND SUBSTR(p_slipsdate, 0, 4) || '-01' = b.budgym
		--                       AND b.deptcode = p_deptcode
		--                LEFT JOIN CMDEPTM c ON c.deptcode = p_deptcode
		--                LEFT JOIN ACBUDGM D
		--                    ON D.compcode = p_compcode
		--                       AND NVL(CASE WHEN trim(b.deptcode) IS NOT NULL THEN NVL(b.bdgdeptcode, c.bdgdeptcode) ELSE c.bdgdeptcode END, p_deptcode) = D.deptcode
		--                LEFT JOIN ACBUDGM E
		--                    ON E.compcode = p_compcode
		--                       AND NVL(CASE WHEN trim(b.deptcode) IS NOT NULL THEN NVL(b.bdgdeptcode, c.bdgdeptcode) ELSE c.bdgdeptcode END, p_deptcode) = E.deptcode
		--                       AND NVL(a.budgcode,a.acccode) = E.acccode
		--                LEFT JOIN ACBUDGYY f
		--                    ON f.compcode = p_compcode
		--                       AND SUBSTR(p_slipsdate, 0, 4) = f.cyear
		--                       AND NVL(CASE WHEN trim(b.deptcode) IS NOT NULL THEN NVL(b.bdgdeptcode, c.bdgdeptcode) ELSE c.bdgdeptcode END, p_deptcode) = f.deptcode
		--                       AND NVL(a.budgcode, a.acccode) = f.acccode
		--                LEFT JOIN (
		--                            SELECT value1
		--                            FROM   SYSPARAMETERMANAGE
		--                            WHERE  UPPER(parametercode) = 'BUDGETACCCODE'
		--                           ) G
		--                      ON D.acccode = G. value1
		--        WHERE    a.acccode = p_acccode
		--            AND (p_dcdiv IN ('1', '4')
		--                 AND a.dcdiv = '1'
		--                 OR p_dcdiv IN ('2', '3')
		--                    AND a.dcdiv = '2')
		--            AND COALESCE(E.budglimityn, D.budglimityn, D.budglimityn, 'N') = 'Y';

		-- 회계시작월 설정
		p_strmon := '01';

		FOR rec IN (SELECT *
					FROM   (SELECT	 SUBSTR(curstrdate, 6, 2) alias1
							FROM	 ACSESSION
							WHERE	 compcode = p_compcode
									 AND cyear <= SUBSTR(p_slipsdate, 0, 4)
							ORDER BY cyear DESC)
					WHERE  ROWNUM = 1)
		LOOP
			p_strmon := rec.alias1;
		END LOOP;

		-- p_strmon ='01'

		IF (p_strmon IS NOT NULL)
		   AND (p_slipsdate IS NOT NULL)
		THEN
			p_month := SUBSTR(p_slipsdate, 1, 7);
			p_month1 := CASE WHEN SUBSTR(p_slipsdate, 6, 2) < p_strmon THEN TO_CHAR(ADD_MONTHS(TO_DATE(p_slipsdate, 'YYYY-MM-DD'), -12), 'YYYY') || '-' || p_strmon ELSE SUBSTR(p_slipsdate, 1, 5) || p_strmon END;
			p_month2 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 11), 'YYYY-MM');


			IF p_month BETWEEN p_month1 AND TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 2), 'YYYY-MM')
			THEN
				p_month3 := p_month1;
				p_month4 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 2), 'YYYY-MM');
				p_month5 := p_month1;
				p_month6 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 5), 'YYYY-MM');
			ELSIF p_month BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 3), 'YYYY-MM') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 5), 'YYYY-MM')
			THEN
				p_month3 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 3), 'YYYY-MM');
				p_month4 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 5), 'YYYY-MM');
				p_month5 := p_month1;
				p_month6 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 5), 'YYYY-MM');
			ELSIF p_month BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 6), 'YYYY-MM') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 8), 'YYYY-MM')
			THEN
				p_month3 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 6), 'YYYY-MM');
				p_month4 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 8), 'YYYY-MM');
				p_month5 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 6), 'YYYY-MM');
				p_month6 := p_month2;
			ELSE
				p_month3 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 9), 'YYYY-MM');
				p_month4 := p_month2;
				p_month5 := TO_CHAR(ADD_MONTHS(TO_DATE(p_month1 || '-01', 'YYYY-MM-DD'), 6), 'YYYY-MM');
				p_month6 := p_month2;
			END IF;
		END IF;

		OPEN IO_CURSOR FOR
			SELECT NVL(SUM(b.budgamt - b.restotamt), 0) budgamt
			FROM   (SELECT NVL(CASE WHEN b.deptcode IS NOT NULL THEN NVL(NULLIF(b.bdgdeptcode, NULL), c.bdgdeptcode) ELSE c.bdgdeptcode END, p_deptcode) deptcode,
						   NVL(a.budgcode, a.acccode) acccode,
						   NVL(f.budgctldiv, '2') budgctldiv
					FROM   ACACCM a
						   LEFT JOIN ACBDGDPT b
							   ON b.compcode = p_compcode
								  AND SUBSTR(p_slipsdate, 0, 4) || '-01' = b.budgym
								  AND b.deptcode = p_deptcode
						   LEFT JOIN CMDEPTM c ON c.deptcode = p_deptcode
						   LEFT JOIN ACBUDGM D
							   ON D.compcode = p_compcode
								  AND NVL(CASE WHEN TRIM(b.deptcode) IS NOT NULL THEN NVL(b.bdgdeptcode, c.bdgdeptcode) ELSE c.bdgdeptcode END, p_deptcode) = D.deptcode
						   LEFT JOIN ACBUDGM E
							   ON E.compcode = p_compcode
								  AND NVL(CASE WHEN TRIM(b.deptcode) IS NOT NULL THEN NVL(b.bdgdeptcode, c.bdgdeptcode) ELSE c.bdgdeptcode END, p_deptcode) = E.deptcode
								  AND NVL(a.budgcode, a.acccode) = E.acccode
						   LEFT JOIN ACBUDGYY f
							   ON f.compcode = p_compcode
								  AND SUBSTR(p_slipsdate, 0, 4) = f.cyear
								  AND NVL(CASE WHEN TRIM(b.deptcode) IS NOT NULL THEN NVL(b.bdgdeptcode, c.bdgdeptcode) ELSE c.bdgdeptcode END, p_deptcode) = f.deptcode
								  AND NVL(a.budgcode, a.acccode) = f.acccode
						   LEFT JOIN (SELECT value1
									  FROM	 SYSPARAMETERMANAGE
									  WHERE  UPPER(parametercode) = 'BUDGETACCCODE') G
							   ON D.acccode = G.value1
					WHERE  a.acccode = p_acccode
						   AND (p_dcdiv IN ('1', '4')
								AND a.dcdiv = '1'
								OR p_dcdiv IN ('2', '3')
								   AND a.dcdiv = '2')
						   AND COALESCE(E.budglimityn, D.budglimityn, D.budglimityn, 'N') = 'Y') a
				   JOIN
				   ACBUDGMM b
					   ON b.compcode = p_compcode
						  AND a.deptcode = b.deptcode
						  AND a.acccode = b.acccode
						  AND b.budgym BETWEEN (CASE a.budgctldiv WHEN '1' THEN p_month WHEN '2' THEN p_month1 WHEN '3' THEN p_month3 WHEN '4' THEN p_month5 ELSE p_month1 END)
										   AND (CASE a.budgctldiv WHEN '1' THEN p_month WHEN '2' THEN p_month WHEN '3' THEN p_month4 WHEN '4' THEN p_month6 ELSE p_month2 END);
	END IF;


	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
