CREATE PROCEDURE        SPACACC0900NP(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0900NP
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-08-22
	-- 수정내역         : 2011-01-19 이영재 집계,현금처리 수정
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-20
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 수입비용회계로드
	-- ---------------------------------------------------------------

	p_div		   IN	  VARCHAR2 DEFAULT ''
    
   ,p_compcode	   IN	  VARCHAR2 DEFAULT '' --법인코드
   ,p_plantcode    IN	  VARCHAR2 DEFAULT ''
   ,p_sdt		   IN	  VARCHAR2 DEFAULT ''
   ,p_edt		   IN	  VARCHAR2 DEFAULT ''
   ,p_loadstatus   IN	  VARCHAR2 DEFAULT ''
   ,p_custcode	   IN	  VARCHAR2 DEFAULT ''
   ,p_importshtno  IN	  VARCHAR2 DEFAULT ''
   ,p_iempcode	   IN	  VARCHAR2 DEFAULT ''
   
   ,p_taxno 	   IN	  VARCHAR2 DEFAULT ''
   ,p_buydiv	   IN	  VARCHAR2 DEFAULT ''
   ,p_custname	   IN	  VARCHAR2 DEFAULT ''
   ,p_businessno   IN	  VARCHAR2 DEFAULT ''
   ,p_taxamt1	   IN	  FLOAT    DEFAULT 0
   ,p_taxamt2	   IN	  FLOAT    DEFAULT 0
   ,p_taxamt3	   IN	  FLOAT    DEFAULT 0
   ,p_itemnm	   IN	  VARCHAR2 DEFAULT '' --매입 적요와 상품명(세금계산서)
   ,p_deptcode	   IN	  VARCHAR2 DEFAULT ''
   ,p_actrnstate   IN	  VARCHAR2 DEFAULT ''
   ,p_acatrulecode IN	  VARCHAR2 DEFAULT ''
   ,p_agencode	   IN	  VARCHAR2 DEFAULT ''
   ,p_expamt1	   IN	  FLOAT    DEFAULT 0
   ,p_expamt2	   IN	  FLOAT    DEFAULT 0
   ,p_expamt3	   IN	  FLOAT    DEFAULT 0
   ,p_expamt4	   IN	  FLOAT    DEFAULT 0
   ,p_expamt5	   IN	  FLOAT    DEFAULT 0
   ,p_expamt6	   IN	  FLOAT    DEFAULT 0
   ,p_expamt	   IN	  FLOAT    DEFAULT 0
   ,p_expvat	   IN	  FLOAT    DEFAULT 0
   ,p_electaxyn    IN	  VARCHAR2 DEFAULT ''
   ,p_lccode	   IN	  VARCHAR2 DEFAULT ''
   ,p_lcname	   IN	  VARCHAR2 DEFAULT ''
   
   ,p_slipindate   IN	  VARCHAR2 DEFAULT ''
   ,p_slipinseq    IN	  NUMBER   DEFAULT 0
   
   ,p_userid	   IN	  VARCHAR2 DEFAULT ''
   ,p_reasondiv    IN	  VARCHAR2 DEFAULT ''
   ,p_reasontext   IN	  VARCHAR2 DEFAULT ''
   ,MESSAGE 		  OUT VARCHAR2
   ,IO_CURSOR		  OUT TYPES.DATASET
)
AS
	
    v_temp		 NUMBER       := 0;
	p_slipno	 VARCHAR2(20) := '';


	ip_taxno	 VARCHAR2(20) := p_taxno;

	p_chktaxno	 VARCHAR2(20) := '';
    
BEGIN
	
    MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
		 VALUES (p_userid, p_reasondiv, p_reasontext);


    FOR rec IN (

        SELECT  COUNT(compcode) AS cnt
        FROM    CMCLOSEM
        WHERE   compcode = p_compcode
                AND closeym BETWEEN SUBSTR(p_sdt, 0, 7) AND SUBSTR(p_edt, 0, 7)
                AND accdiv = 'N'
                AND apprcloseyn = 'Y'

    )
    LOOP

        v_temp := rec.cnt ;

    END LOOP ;


	IF v_temp > 0 THEN
		GOTO LAST;
	END IF;



	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0900NP_PDCOSTM ';

	INSERT INTO VGT.TT_ACACC0900NP_PDCOSTM (
        SELECT  ROW_NUMBER() OVER (ORDER BY a.acccode) AS ord
                , a.acccode
                , b.accname
        FROM    (   SELECT  dracccode AS acccode FROM PDCOSTM
                    UNION
                    SELECT  dracccode2 FROM PDCOSTM
                    UNION
                    SELECT  cracccode FROM PDCOSTM
                    UNION
                    SELECT  cracccode2 FROM PDCOSTM 
                ) a
                JOIN ACACCM b ON a.acccode = b.acccode
    ) ;



	EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0900NP_ACACC0900NP ';

	IF (UPPER(P_DIV) = 'T') THEN
		
        OPEN IO_CURSOR FOR
        
            SELECT  acccode
                    , accname
            FROM    VGT.TT_ACACC0900NP_PDCOSTM
            ORDER BY acccode ;

		GOTO LAST;
        
        
	ELSIF( UPPER(P_DIV) = 'S' ) THEN
    
		-- 기본 세금계산서 자료 조회
		INSERT INTO VGT.TT_ACACC0900NP_ACACC0900NP
            SELECT  p_compcode -- 회사코드
                    , NVL(b.plantcode, a.plantcode) plantcode -- 사업장코드
                    , NVL(c.plantname, '') -- 사업장명
                    , 'N' chkyn -- 선택
                    , a.taxdate -- 발행일자
                    , a.taxseq -- 발행순번
                    , a.custcode -- 거래처코드
                    , NVL(D.custname, '') -- 거래처명
                    , a.agencode -- 대행처코드
                    , NVL(j.custname, '') -- 대행처명
                    , NVL(a.buydiv, '04') -- 매입구분
                    , NVL(e.divname, '') -- 매입구분명
                    , NVL(f.deptcode, '') -- 부서코드
                    , NVL(g.deptname, '') -- 부서명
                    , CASE WHEN TRIM(a.buydiv) IS NULL THEN a.importshtno || a.costseq ELSE a.taxno END -- 계산서번호, 
                    , a.importshtno
                    , NVL(k.lccode, '')
                    , NVL(k.lcname, '')
                    , TO_NUMBER(NVL(a.expamt1, 0))
                    , TO_NUMBER(NVL(a.expamt2, 0))
                    , TO_NUMBER(NVL(a.expamt3, 0))
                    , TO_NUMBER(NVL(a.expamt4, 0))
                    , TO_NUMBER(NVL(a.expamt5, 0))
                    , TO_NUMBER(NVL(a.expamt6, 0))
                    , TO_NUMBER(NVL(a.amt, 0))
                    , TO_NUMBER(NVL(a.vat, 0))
                    , NVL(k.lcname, '') || NVL(' / ' || a.costname, '')
                    , NVL(D.businessno, '') -- 사업자번호
                    , a.icntitem -- 품목건수
                    , NVL(NULLIF(b.importsdate, NULL), p_sdt) -- 시작일
                    , NVL(NULLIF(b.importedate, NULL), p_edt) -- 종료일
                    , CASE WHEN LENGTH(RTRIM(c.businessno)) = 12 THEN '01' ELSE '02' END -- 사업자구분
                    , NVL(a.itemname, '') || CASE WHEN a.icntitem > 1 THEN + ' 외' || TO_CHAR(a.icntitem - 1) || '건' ELSE '' END || ' 수입비용' -- 적요
                    , 'N010' || NVL(a.buydiv, '04') -- 자동분계코드
                    , CASE WHEN TRIM(h.acatno)   IS NULL THEN '1'
                           WHEN TRIM(h.slipinno) IS NULL THEN '2'
                           WHEN i.slipinno IS NULL OR (SELECT SUM(creamt) FROM ACORDD WHERE compcode = i.compcode AND slipinno = i.slipinno) - a.expamt1 <> 0 THEN '3'
                           ELSE '2' END -- 전표자료상태
                    , CASE WHEN h.acatno IS NULL THEN '신규로드전송전'
                           WHEN h.slipinno IS NULL THEN '로드완료전표처리전'
                           WHEN i.slipinno IS NULL OR ( SELECT SUM(creamt) FROM ACORDD WHERE compcode = i.compcode AND slipinno = i.slipinno ) - a.expamt1 <> 0 AND i.slipinstate <> '4' THEN '회계전표재전송'
                           WHEN ( SELECT SUM(creamt) FROM ACORDD WHERE compcode = i.compcode AND slipinno = i.slipinno ) - a.expamt1 <> 0 AND i.slipinstate = '4' THEN '회계전표재전송(승인)'
                           
                           
                           -- 2017 - 08 - 07 : 확인해야 될 부분 시작
                           
                           -- WHEN j.slipinstate = '4' THEN '전표처리완료(승인)'
                           
                           -- 2017 - 08 - 07 : 확인해야 될 부분 끝
                                                      
                           
                           ELSE '전표처리완료' END -- 전표자료상태명
                    , h.slipinno
                    ,CASE WHEN TRIM(a.buydiv) IS NULL THEN '4'
                          WHEN TRIM(a.taxno) IS NULL THEN '1'
                          WHEN b.taxno IS NULL OR a.vat - b.vat <> 0 THEN '3'
                          ELSE '2' END -- 계산서자료상태
                    , CASE WHEN TRIM(a.buydiv) IS NULL THEN '계산서미전송'
                           WHEN TRIM(a.taxno) IS NULL THEN '신규로드전송전'
                           WHEN b.taxno IS NULL OR a.vat - b.vat <> 0 THEN '계산서재전송'
                           ELSE '계산서처리완료' END -- 계산서자료상태명
                    , CASE WHEN h.slipinno IS NULL THEN 'N' WHEN i.slipinno IS NULL THEN 'Y' ELSE 'N' END -- 전표처리여부
                    , NVL(a.electaxyn, 'N') electaxyn
                    
            FROM    (	
                        SELECT  b.plantcode -- 사업장코드
                                , a.custcost custcode -- 거래처코드
                                , a.accountday taxdate -- 세금계산서일자
                                , NVL(a.accountseq, 0) taxseq -- 세금계산서순번
                                , NVL(a.accountno, '') taxno -- 세금계산서번호
                                , MAX(a.importshtno) importshtno -- 수입전표번호
                                , MAX(c.lccode) lccode -- LC코드
                                , MAX(e.costname) costname -- 비용명
                                , MIN('-' || SUBSTR('00' || TO_CHAR(a.costseq), -2, 2)) costseq -- 수입일련번호
                                , MAX(a.custcode) agencode -- 대행처
                                , MAX(CASE WHEN a.accountyn = 'Y' THEN a.accountdiv END) buydiv -- 매입구분(MPM17) 01:과세 02:면세 03:영세율
                                , MAX(CASE WHEN a.accountyn = 'Y' THEN a.elcaccount END) electaxyn -- 전자세금계산서여부
                                , SUM(CASE WHEN D.grp = 1 AND f.ord = 1 THEN a.costamt
                                           WHEN D.grp = 2 AND g.ord = 1 THEN a.costamt + a.vat
                                           ELSE 0 END ) expamt1
                                , SUM(CASE WHEN D.grp = 1 AND f.ord = 2 THEN a.costamt
                                           WHEN D.grp = 2 AND g.ord = 2 THEN a.costamt + a.vat
                                           ELSE 0 END ) expamt2
                                , SUM(CASE WHEN D.grp = 1 AND f.ord = 3 THEN a.costamt
                                           WHEN D.grp = 2 AND g.ord = 3 THEN a.costamt + a.vat
                                           ELSE 0 END ) expamt3
                                , SUM(CASE WHEN D.grp = 1 AND f.ord = 4 THEN a.costamt
                                           WHEN D.grp = 2 AND g.ord = 4 THEN a.costamt + a.vat
                                           ELSE 0 END ) expamt4
                                , SUM(CASE WHEN D.grp = 1 AND f.ord = 5 THEN a.costamt
                                           WHEN D.grp = 2 AND g.ord = 5 THEN a.costamt + a.vat
                                           ELSE 0 END ) expamt5
                                , SUM(CASE WHEN D.grp = 1 AND f.ord = 6 THEN a.costamt
                                           WHEN D.grp = 2 AND g.ord = 6 THEN a.costamt + a.vat
                                           ELSE 0 END ) expamt6
                                , SUM(CASE WHEN a.accountyn = 'Y' THEN a.costamt ELSE 0 END) / 2 amt -- 경비금액
                                , SUM(CASE WHEN a.accountyn = 'Y' THEN a.vat ELSE 0 END) / 2 vat -- 부가세
                                , MAX(NVL(h.itemname, '')) itemname -- 품목명
                                , MAX(NVL(b.icntitem, 1)) icntitem -- 품목건수
                                , MAX(NVL(a.accountcheck, '')) accountcheck -- 회계전표 연결 확인
                                , MIN(a.remark) || CASE WHEN MIN(a.remark) <> MAX(a.remark) THEN ', ' || MAX(a.remark) ELSE '' END remark

                        FROM    PDIMPORTCOSTM a
                                JOIN (  SELECT  a.importshtno
                                                , MAX(c.plantcode) plantcode
                                                , MAX(c.itemcode) itemcode
                                                , MAX(c.purchaseorderdiv) purchaseorderdiv
                                                , COUNT(DISTINCT c.orderno) icntitem
                                        FROM    PDIMPORTCOSTM a
                                                JOIN PDIMPORTSHEETD b ON a.importshtno = b.importshtno
                                                JOIN PDPURCHASEORDERM c ON b.requestno = c.orderno
                                                                           AND b.itemcode = c.itemcode
                                        WHERE a.accountday BETWEEN p_sdt AND p_edt
                                        GROUP BY a.importshtno ) b ON a.importshtno = b.importshtno
                                JOIN PDIMPORTSHEETM c ON a.importshtno = c.importshtno
                                JOIN (  SELECT 1 grp FROM DUAL
                                        UNION
                                        SELECT 2 FROM DUAL) D ON 1 = 1
                                JOIN PDCOSTM e ON a.costcode = e.costcode
                                LEFT JOIN VGT.TT_ACACC0900NP_PDCOSTM f ON CASE WHEN b.purchaseorderdiv = '01' THEN e.dracccode ELSE e.dracccode2 END = f.acccode
                                LEFT JOIN VGT.TT_ACACC0900NP_PDCOSTM g ON CASE WHEN b.purchaseorderdiv = '01' THEN e.cracccode ELSE e.cracccode2 END = g.acccode
                                LEFT JOIN CMITEMM h ON b.itemcode = h.itemcode

                        WHERE   NVL(a.importshtno, ' ') LIKE p_importshtno || '%'
                                AND a.accountday BETWEEN p_sdt AND p_edt
                                
                        GROUP BY b.plantcode, a.custcost, a.accountday, NVL(a.accountseq, 0), NVL(a.accountno, '')
                    ) a
                    LEFT JOIN ACTAXM b ON b.compcode = p_compcode
                                          AND a.taxno = b.taxno
                    LEFT JOIN CMPLANTM c ON NVL(b.plantcode, a.plantcode) = c.plantcode
                    LEFT JOIN CMCUSTM D ON a.custcode = D.custcode
                    LEFT JOIN CMCOMMONM e ON e.cmmcode = 'MPM17'
                                             AND NVL(a.buydiv, '04') = e.divcode
                    LEFT JOIN CMEMPM f ON f.empcode = p_iempcode
                    LEFT JOIN CMDEPTM g ON f.deptcode = g.deptcode
                    LEFT JOIN ACAUTOORDT h ON h.compcode = p_compcode
                                              AND h.acatrulecode = 'N010' || NVL(a.buydiv, '04')
                                              AND CASE WHEN TRIM(a.buydiv) IS NULL THEN a.importshtno || a.costseq ELSE a.taxno END = h.acatno
                    LEFT JOIN ACORDM i ON h.compcode = i.compcode
                                          AND h.slipinno = i.slipinno
                    LEFT JOIN CMCUSTM j ON a.agencode = j.custcode
                    LEFT JOIN ACLCM k ON a.lccode = k.lccode
            ORDER BY a.custcode ;



        -- 삭제 상태 확인
        INSERT INTO VGT.TT_ACACC0900NP_ACACC0900NP ( 
            SELECT  NVL(a.compcode, '') compcode
                    , NVL(a.plantcode, '') plantcode
                    , NVL(c.plantname, '') plantname
                    , 'N' chkyn
                    , NVL(a.slipindate, '') slipindate
                    , 1 slipinseq
                    , NVL(a.custcode, '') custcode
                    , NVL(a.userdef6code, '') custname
                    , NVL(a.userdef1code, '') agencode
                    , NVL(a.userdef7code, '') agenname
                    , g.divcode buydiv
                    , g.divname buydivname
                    , NVL(a.deptcode, '') deptcode
                    , NVL(a.userdef4code, '') deptname
                    , NVL(a.taxno, '') taxno
                    , NVL(a.billno, '') importshtno
                    , NVL(a.userdef9code, '') lccode
                    , NVL(a.userdef10code, '') lcname
                    , NVL(a.trn1amt, 0) expamt1
                    , NVL(a.trn2amt, 0) expamt2
                    , NVL(a.trn3amt, 0) expamt3
                    , NVL(a.trn4amt, 0) expamt4
                    , NVL(a.trn5amt, 0) expamt5
                    , NVL(a.trn6amt, 0) expamt6
                    , NVL(a.trn11amt, 0) expamt
                    , NVL(a.trn12amt, 0) expvat
                    , a.remark || '[삭제]' remark
                    , D.businessno businessno
                    , 0 icntitem
                    , NVL(e.importsdate, '') sdt
                    , NVL(e.importedate, '') edt
                    , CASE WHEN LENGTH(RTRIM(D.businessno)) = 12 THEN '01' ELSE '02' END -- 사업자구분 
                    , a.remark || '[삭제]' itemnm
                    , NVL(a.acatrulecode, '') autorulecode
                    , CASE WHEN TRIM(f.slipinno) IS NOT NULL THEN '4' ELSE '2' END acctrnchk
                    , CASE WHEN TRIM(f.slipinno) IS NOT NULL THEN '전표삭제전송필요' ELSE '' END acctrnchk2
                    , f.slipinno
                    , CASE WHEN TRIM(e.taxno) IS NOT NULL THEN '4' ELSE '2' END taxloadyn
                    , CASE WHEN TRIM(e.taxno) IS NOT NULL THEN '계산서삭제전송필요' ELSE '' END taxloadtatus
                    , 'N' newchk
                    , NVL(e.electaxyn, 'N') electaxyn
            FROM    ACAUTOORDT a
                    LEFT JOIN VGT.TT_ACACC0900NP_ACACC0900NP b ON a.acatno = b.taxno
                    LEFT JOIN CMPLANTM c ON a.plantcode = c.plantcode
                    LEFT JOIN CMCUSTM D ON a.custcode = D.custcode
                    LEFT JOIN ACTAXM e ON a.compcode = e.compcode
                                          AND a.taxno = e.taxno
                    LEFT JOIN ACORDM f ON a.compcode = f.compcode
                                          AND a.slipinno = f.slipinno
                    LEFT JOIN CMCOMMONM g ON g.cmmcode = 'MPM17'
                                             AND SUBSTR(a.acatrulecode, -2, 2) = g.divcode
            WHERE   a.compcode = p_compcode
                    AND a.acattype = 'N'
                    AND a.acatrulecode LIKE 'N010%'
                    AND a.slipindate BETWEEN p_sdt AND p_edt
                    AND b.taxno IS NULL
                    AND TRIM(p_importshtno) IS NULL 
        ) ;



		IF (p_loadstatus = '1' OR p_loadstatus = '2' OR p_loadstatus = '3') THEN
        
			--로드 상태를 선택
			FOR REC IN (
            
                SELECT  A.COMPCODE
                        , A.PLANTCODE
                        , A.PLANTNAME
                        , A.CHKYN
                        , A.SLIPINDATE
                        , A.SLIPINSEQ
                        , A.CUSTCODE
                        , A.CUSTNAME
                        , A.AGENCODE
                        , A.AGENNAME
                        , A.BUYDIV
                        , A.BUYDIVNAME
                        , A.DEPTCODE
                        , A.DEPTNAME
                        , A.TAXNO
                        , A.IMPORTSHTNO
                        , A.LCCODE
                        , A.LCNAME
                        , A.EXPAMT1
                        , A.EXPAMT2
                        , A.EXPAMT3
                        , A.EXPAMT4
                        , A.EXPAMT5
                        , A.EXPAMT6
                        , A.EXPAMT
                        , A.EXPVAT
                        , A.REMARK
                        , A.BUSINESSNO
                        , A.ICNTITEM
                        , A.SDT
                        , A.EDT
                        , A.BIZNOTYPE
                        , A.ITEMNM
                        , A.AUTORULECODE
                        , A.ACTRNSTATE
                        , A.ACCTRNCHK
                        , A.SLIPINNO
                        , A.TAXLOADYN
                        , A.TAXLOADSTATUS
                        , A.NEWCHK
                        , A.ELECTAXYN
                FROM    VGT.TT_ACACC0900NP_ACACC0900NP a
                        JOIN CMCOMMONM b ON b.cmmcode = 'AC082'
                                            AND b.divcode = p_loadstatus
                WHERE   a.actrnstate NOT IN (b.filter1, b.filter2)
            )                         
			LOOP
            
                DELETE FROM VGT.TT_ACACC0900NP_ACACC0900NP a
                WHERE   A.COMPCODE          = REC.COMPCODE
                        AND A.PLANTCODE     = REC.PLANTCODE
                        AND A.PLANTNAME     = REC.PLANTNAME
                        AND A.CHKYN         = REC.CHKYN
                        AND A.SLIPINDATE    = REC.SLIPINDATE
                        AND A.SLIPINSEQ     = REC.SLIPINSEQ
                        AND A.CUSTCODE      = REC.CUSTCODE
                        AND A.CUSTNAME      = REC.CUSTNAME
                        AND A.AGENCODE      = REC.AGENCODE
                        AND A.AGENNAME      = REC.AGENNAME
                        AND A.BUYDIV        = REC.BUYDIV
                        AND A.BUYDIVNAME    = REC.BUYDIVNAME
                        AND A.DEPTCODE      = REC.DEPTCODE
                        AND A.DEPTNAME      = REC.DEPTNAME
                        AND A.TAXNO         = REC.TAXNO
                        AND A.IMPORTSHTNO   = REC.IMPORTSHTNO
                        AND A.LCCODE        = REC.LCCODE
                        AND A.LCNAME        = REC.LCNAME
                        AND A.EXPAMT1       = REC.EXPAMT1
                        AND A.EXPAMT2       = REC.EXPAMT2
                        AND A.EXPAMT3       = REC.EXPAMT3
                        AND A.EXPAMT4       = REC.EXPAMT4
                        AND A.EXPAMT5       = REC.EXPAMT5
                        AND A.EXPAMT6       = REC.EXPAMT6
                        AND A.EXPAMT        = REC.EXPAMT
                        AND A.EXPVAT        = REC.EXPVAT
                        AND A.REMARK        = REC.REMARK
                        AND A.BUSINESSNO    = REC.BUSINESSNO
                        AND A.ICNTITEM      = REC.ICNTITEM
                        AND A.SDT           = REC.SDT
                        AND A.EDT           = REC.EDT
                        AND A.BIZNOTYPE     = REC.BIZNOTYPE
                        AND A.ITEMNM        = REC.ITEMNM
                        AND A.AUTORULECODE  = REC.AUTORULECODE
                        AND A.ACTRNSTATE    = REC.ACTRNSTATE
                        AND A.ACCTRNCHK     = REC.ACCTRNCHK
                        AND A.SLIPINNO      = REC.SLIPINNO
                        AND A.TAXLOADYN     = REC.TAXLOADYN
                        AND A.TAXLOADSTATUS = REC.TAXLOADSTATUS
                        AND A.NEWCHK        = REC.NEWCHK
                        AND A.ELECTAXYN     = REC.ELECTAXYN ;
                            
			END LOOP;
            
		END IF;



		IF (p_plantcode <> '%') THEN
		
            DELETE FROM VGT.TT_ACACC0900NP_ACACC0900NP a
            WHERE   a.plantcode <> p_plantcode ;
                  
		END IF;



		IF (TRIM(p_custcode) IS NOT NULL) THEN
			
            DELETE FROM VGT.TT_ACACC0900NP_ACACC0900NP a
            WHERE   a.custcode <> p_custcode ;
                  
		END IF;



        OPEN IO_CURSOR FOR
        
            SELECT  A.*
                    , A.expamt + A.expvat expsum
            FROM    VGT.TT_ACACC0900NP_ACACC0900NP A
            ORDER BY plantcode, custcode, slipindate, slipinseq ;
                    
                    
	ELSIF (UPPER(P_DIV) = 'SD') THEN
            
        --상세 내용 정보 확인
        OPEN IO_CURSOR FOR
                
            SELECT  NVL(a.importshtno, '') importshtno
                    , NVL(a.costcode, '') costcode
                    , NVL(D.costname, '') costname
                    , NVL(a.costamt, 0) costamt
                    , NVL(a.vat, 0) vat
                    , NVL(a.costamt, 0) + NVL(a.vat, 0) sumamt
                    , NVL(b.orderno, '') orderno
                    , NVL(b.itemcode, '') itemcode
                    , NVL(c.itemname, '') itemname
                    , NVL(c.itemdiv, '') itemdiv
                    , NVL(e.divname, '') itemdivname
            FROM    PDIMPORTCOSTM a
                    JOIN (  SELECT  a.importshtno
                                    , MAX(b.orderno) orderno
                                    , MAX(b.itemcode) itemcode
                            FROM    PDIMPORTCOSTM a 
                                    JOIN PDPURCHASEORDERM b ON a.importshtno = b.importshtno
                            WHERE   b.plantcode = p_plantcode
                                    AND a.custcost = p_custcode
                                    AND a.accountday = p_slipindate
                                    AND NVL(a.accountseq, 0) = p_slipinseq
                            GROUP BY a.importshtno ) b ON a.importshtno = b.importshtno
                    LEFT JOIN CMITEMM c ON b.itemcode = c.itemcode
                    LEFT JOIN PDCOSTM D ON a.costcode = D.costcode
                    LEFT JOIN CMCOMMONM e ON e.cmmcode = 'CMM01'
                                             AND c.itemdiv = e.divcode
            WHERE   a.custcost = p_custcode
                    AND a.accountday = p_slipindate
                    AND NVL(a.accountseq, 0) = p_slipinseq ;
                   
                   
	ELSIF (UPPER(P_DIV) = 'CTAX') THEN --세금계산서 존재확인. 매입로드에서 사용
        
		p_chktaxno := '';

        FOR rec IN (

            SELECT  NVL(taxno, '') AS alias1
            FROM    ACTAXM
            WHERE   compcode = p_compcode
                    AND taxno = p_taxno
                    
        )
        LOOP

            p_chktaxno := rec.alias1;
            
        END LOOP;


		IF TRIM(p_chktaxno) IS NULL OR TRIM(p_chktaxno) = '' THEN
			
            MESSAGE := 'NO';
            
		ELSE
			
            MESSAGE := 'YES';
            
		END IF;
        
        
	ELSIF (UPPER(P_DIV) = 'ITAX') THEN
		
        --세금계산서 생성.
		ip_taxno := SUBSTR(REPLACE(p_slipindate, '-', ''), 0, 6) || '05'; --매입구분 수입비용자동생성구분


		FOR rec IN (
            
            SELECT  ip_taxno || SUBSTR('00000' || TO_CHAR((NVL(SUBSTR(MAX(taxno), -5, 5), 0) + 1)), -5, 5) AS alias1
            FROM    ACTAXM
            WHERE   compcode = p_compcode
                    AND taxno LIKE ip_taxno || '%'
                    AND LENGTH(taxno) = 13
                    AND iotaxdiv = '01'
                    AND saleinyn = 'Y'
            
        )
		LOOP
        
			ip_taxno := rec.alias1; --수입비용 구분 매입세금계산서
            
		END LOOP; 



        INSERT INTO ACTAXM (
            compcode
            , plantcode
            , taxno -- yyyymm03nnnnn
            , taxdiv --계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
            , iotaxdiv --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
            , sdeptcode
            , taxdate
            , custcode
            , custname
            , businessno
            , biznotype --사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
            , blankcnt
            , amt
            , vat
            , vatamt
            , purposediv --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
            , credittot
            , importsdate
            , importedate
            , electaxyn --전자세금계산서여부
            , purdiv
            , saleinyn --수입자동생성여부
            , insertdt
            , iempcode
        )
        VALUES (
            p_compcode
            , p_plantcode
            , ip_taxno -- yyyymm03nnnnn  번호 생성
            , CASE WHEN p_buydiv = '01' THEN '201' --매입-과세 계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                   WHEN p_buydiv = '02' THEN '203' --매입-계산서 계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                   WHEN p_buydiv = '03' THEN '202' --매입-영세 계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                   ELSE '201' END --계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
            , '01' --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
            , ''
            , p_slipindate
            , p_custcode
            , p_custname
            , p_businessno
            , '01' --사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
            , 0
            , CASE WHEN p_taxamt1 = 0 AND p_buydiv = '01' THEN p_taxamt2 * 10 ELSE p_taxamt1 END
            , p_taxamt2
            , CASE WHEN p_taxamt1 = 0 AND p_buydiv = '01' THEN p_taxamt2 * 10 + p_taxamt2 ELSE p_taxamt3 END
            , '02' --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
            , p_taxamt3
            , p_slipindate
            , p_slipindate
            , p_electaxyn --전자세금계산서여부
            , '0'
            , 'Y' --수입자동생성여부
            , SYSDATE
            , p_iempcode
        ) ;



        INSERT INTO ACTAXD (
            compcode
            , plantcode
            , taxno -- yyyymm03nnnnn
            , seq
            , itemnm -- ITEM
            , amt
            , vat
            , vatamt
            , insertdt
            , iempcode
        )
        VALUES (
            p_compcode
            , p_plantcode
            , ip_taxno -- yyyymm03nnnnn  번호 생성
            , 1
            , p_itemnm -- + ' 외'
            , CASE WHEN p_taxamt1 = 0 AND p_buydiv = '01' THEN p_taxamt2 * 10 ELSE p_taxamt1 END
            , p_taxamt2
            , CASE WHEN p_taxamt1 = 0 AND p_buydiv = '01' THEN p_taxamt2 * 10 + p_taxamt2 ELSE p_taxamt3 END
            , SYSDATE
            , p_iempcode
        );



        MERGE INTO PDIMPORTCOSTM a
        USING (
                
                SELECT  A.IMPORTSHTNO
                        , A.COSTSEQ
                FROM    PDIMPORTCOSTM a 
                        JOIN PDPURCHASEORDERM b ON a.importshtno = b.importshtno
                WHERE   b.plantcode = p_plantcode
                        AND a.custcost = p_custcode
                        AND a.accountday = p_slipindate
                        AND NVL(a.accountseq, 0) = p_slipinseq
                        
        ) src ON (  A.IMPORTSHTNO = SRC.IMPORTSHTNO
                    AND A.COSTSEQ = SRC.COSTSEQ )
        WHEN MATCHED THEN
                            UPDATE SET A.accountno = ip_taxno ;
            
            
	ELSIF (UPPER(P_DIV) = 'UTAX') THEN --세금계산서 수정.
		
        MERGE INTO ACTAXM a
        USING (
                SELECT  A.COMPCODE
                        , A.PLANTCODE
                        , A.TAXNO
                        , CASE WHEN p_buydiv = '01' THEN '201' --매입-과세 계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                               WHEN p_buydiv = '02' THEN '203' --매입-계산서 계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                               WHEN p_buydiv = '03' THEN '202' --매입-영세 계산서 구분(  select * from CMCOMMONM where cmmcode = 'AC60'  )
                               ELSE '201' END AS pos_2
                        , CASE WHEN p_taxamt1 = 0 AND p_buydiv = '01' THEN p_taxamt2 * 10 ELSE p_taxamt1 END AS pos_10
                        , CASE WHEN p_taxamt1 = 0 AND p_buydiv = '01' THEN p_taxamt2 * 10 + p_taxamt2 ELSE p_taxamt3 END AS pos_12
                FROM    ACTAXM a 
                        LEFT JOIN CMCUSTM c ON c.custcode = p_custcode
                WHERE   a.compcode = p_compcode
                        AND a.taxno = ip_taxno
                
        ) src ON (  A.COMPCODE = SRC.COMPCODE
                    AND A.PLANTCODE = SRC.PLANTCODE
                    AND A.TAXNO = SRC.TAXNO
                 )
        WHEN MATCHED THEN
                            UPDATE SET  a.taxdiv = pos_2
                                        , a.iotaxdiv = '01' --매입매출구분( select * from CMCOMMONM where cmmcode = 'AC61'  )
                                        , a.sdeptcode = p_deptcode
                                        , a.taxdate = p_slipindate --회계처리일자
                                        , a.custcode = p_custcode
                                        , a.custname = p_custname
                                        , a.businessno = p_businessno
                                        , a.biznotype = '01' -- 사업자등록번호 사업자구분( select * from CMCOMMONM where cmmcode = 'AC65'  )
                                        , a.amt = pos_10
                                        , a.vat = p_taxamt2
                                        , a.vatamt = pos_12
                                        , a.purposediv = '02' --영수청구구분(  select * from CMCOMMONM where cmmcode = 'AC62'   )
                                        , a.electaxyn = p_electaxyn --전자세금계산서여부
                                        , a.saleinyn = 'Y' --수입 자동생성여부
                                        , a.purdiv = '0'
                                        , a.updatedt = SYSDATE
                                        , a.uempcode = p_iempcode
                                        , a.importsdate = p_slipindate
                                        , a.importedate = p_slipindate ;



        UPDATE  ACTAXD a
        SET     a.itemnm = p_itemnm
                , a.gyugeok = ''
                , a.qty = 0
                , a.prc = 0
                , a.amt = CASE WHEN p_taxamt1 = 0 AND p_buydiv = '01' THEN p_taxamt2 * 10 ELSE p_taxamt1 END
                , a.vat = p_taxamt2
                , a.vatamt = CASE WHEN p_taxamt1 = 0 AND p_buydiv = '01' THEN p_taxamt2 * 10 + p_taxamt2 ELSE p_taxamt3 END
                , a.remark = ''
                , a.updatedt = SYSDATE
                , a.uempcode = p_iempcode
        WHERE   compcode = p_compcode
                AND taxno = ip_taxno
                AND seq = 1 ;



        MERGE INTO PDIMPORTCOSTM a
        USING (

            SELECT  A.IMPORTSHTNO
                    ,A.COSTSEQ
            FROM    PDIMPORTCOSTM a 
                    JOIN PDPURCHASEORDERM b ON a.importshtno = b.importshtno
            WHERE   b.plantcode = p_plantcode
                    AND a.custcost = p_custcode
                    AND a.accountday = p_slipindate
                    AND NVL(a.accountseq, 0) = p_slipinseq
                
        ) src ON (  A.IMPORTSHTNO = SRC.IMPORTSHTNO
                    AND A.COSTSEQ = SRC.COSTSEQ
                 )
        WHEN MATCHED THEN
                            UPDATE SET A.accountno = ip_taxno ;
            
            
	ELSIF (UPPER(P_DIV) = 'DTAX' OR UPPER(P_DIV) = 'DTAXNO') THEN --세금계산서 삭제.
	
		-- 회계전표 삭제
        FOR rec IN (

            SELECT  slipno
            FROM    ACAUTOORDT a
                    JOIN ACORDM b ON a.compcode = b.compcode
                                     AND a.slipinno = b.slipinno
            WHERE   a.compcode = p_compcode
                    AND a.acattype = 'N'
                    AND a.acatno = ip_taxno
        )
        LOOP
            
            p_slipno := rec.slipno;
            
        END LOOP;



		IF TRIM(p_slipno) IS NOT NULL OR p_slipno = '' THEN 
		
			SPACORD0000MM(
				'B'
			   ,p_compcode
			   ,p_slipno
			   ,''
			   ,''
			   ,''
			   ,p_userid
			   ,p_reasondiv
			   ,p_reasontext
			   ,MESSAGE
			   ,IO_CURSOR
			) ;
            
		END IF;



		-- 회계전표 관리항목
		FOR REC IN (
            SELECT  B.COMPCODE
                    , B.SLIPINNO
                    , B.SLIPINSEQ
                    , B.MNGCLUCODE
            FROM    ACAUTOORDT a
                    JOIN ACORDS b ON a.compcode = b.compcode
                                     AND a.slipinno = b.slipinno
            WHERE   a.compcode = p_compcode
                    AND a.acattype = 'N'
                    AND a.acatno = ip_taxno
        )
		LOOP
			DELETE FROM ACORDS b
				  WHERE B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO
						AND B.SLIPINSEQ = REC.SLIPINSEQ
						AND B.MNGCLUCODE = REC.MNGCLUCODE;
		END LOOP;



		-- 회계전표 계정과목
		FOR REC IN (SELECT B.COMPCODE
						  ,B.SLIPINNO
						  ,B.SLIPINSEQ
					  FROM ACAUTOORDT a
						   JOIN ACORDD b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno
					 WHERE a.compcode = p_compcode
						   AND a.acattype = 'N'
						   AND a.acatno = ip_taxno)
		LOOP
			DELETE FROM ACORDD b
				  WHERE B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO
						AND B.SLIPINSEQ = REC.SLIPINSEQ;
		END LOOP;



		-- 회계전표 마스터
		FOR REC IN (SELECT B.COMPCODE
						  ,B.SLIPINNO
					  FROM ACAUTOORDT a
						   JOIN ACORDM b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno
					 WHERE a.compcode = p_compcode
						   AND a.acattype = 'N'
						   AND a.acatno = ip_taxno)
		LOOP
			DELETE FROM ACORDM b
				  WHERE B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO;
		END LOOP;



		-- 자동분개 삭제
		DELETE ACAUTOORDT
		 WHERE compcode = p_compcode
			   AND acattype = 'N'
			   AND acatno = ip_taxno;



		-- 세금계산서 삭제
		DELETE ACTAXD
		 WHERE compcode = p_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno;

		DELETE ACTAXM
		 WHERE compcode = p_compcode
			   AND plantcode = p_plantcode
			   AND taxno = ip_taxno;



        MERGE INTO PDIMPORTCOSTM a
        USING (

                SELECT  A.IMPORTSHTNO
                        , A.COSTSEQ
                FROM    PDIMPORTCOSTM a 
                        JOIN PDPURCHASEORDERM b ON a.importshtno = b.importshtno
                WHERE   b.plantcode = p_plantcode
                        AND NVL(a.custcost, ' ') = p_custcode
                        AND a.accountday = p_slipindate
                        AND NVL(a.accountseq, 0) = p_slipinseq
                
        ) src ON (  A.IMPORTSHTNO = SRC.IMPORTSHTNO
                    AND A.COSTSEQ = SRC.COSTSEQ
                 )
        WHEN MATCHED THEN
                            UPDATE SET  A.accountno = ''
                                        , A.accountcheck = '';
            
            
	ELSIF (UPPER(P_DIV) = 'LOAD')
	THEN
		
        IF p_actrnstate = '1' THEN --신규 생성
			
            -- 기간동안의 모든 전표를 생성한다.
            INSERT INTO ACAUTOORDT (
                compcode --회사코드
                , acattype --전표유형(N)
                , acatno --taxno
                , slipindate --발의일자(세금계산서일자)
                , acatrulecode --분개률코드(N01001)
                , deptcode --부서
                , plantcode --사업장
                , empcode --발의사원코드
                , remark
                , custcode --거래처코드
                , taxno --계산서번호
                , billno --수입전표번호
                , trn1amt --비용금액1
                , trn2amt --비용금액2
                , trn3amt --비용금액3
                , trn4amt --비용금액4
                , trn5amt --비용금액5
                , trn6amt --비용금액6
                , trn11amt --비용금액
                , trn12amt --부가세
                , actrnstate --실행상태
                , userdef1code --대행처코드
                , userdef3code --사업장명
                , userdef4code --부서명
                , userdef5code --발의사원명
                , userdef6code --거래처명
                , userdef7code --대행처명
                , userdef9code --LC코드
                , userdef10code --LC명
                , insertdt --입력일자
                , iempcode --입력사원
            )           
            SELECT  p_compcode --회사코드
                    , 'N' --전표유형(N)
                    , ip_taxno --적요@itemnm
                    , p_slipindate --발의일자(세금계산서일자)
                    , p_acatrulecode --분개률코드(N01001)
                    , ( SELECT deptcode FROM CMEMPM WHERE empcode = p_iempcode ) --부서
                    , p_plantcode --사업장
                    , p_iempcode --발의사원코드
                    , p_itemnm --적요
                    , p_custcode --거래처코드
                    , CASE WHEN p_acatrulecode <> 'N01004' THEN ip_taxno ELSE '' END --계산서번호
                    , p_importshtno --수입전표번호
                    , p_expamt1 --비용금액1
                    , p_expamt2 --비용금액2
                    , p_expamt3 --비용금액3
                    , p_expamt4 --비용금액4
                    , p_expamt5 --비용금액5
                    , p_expamt6 --비용금액6
                    , p_expamt --비용금액
                    , p_expvat --부가세
                    , '1' --실행상태 신규
                    , p_agencode --대행처코드
                    , ( SELECT plantname  FROM CMPLANTM WHERE plantcode = p_plantcode ) --사업장명
                    , ( SELECT D.deptname FROM CMEMPM e 
                            JOIN CMDEPTM D ON D.deptcode = e.deptcode WHERE e.empcode = p_iempcode ) --부서명
                    , ( SELECT e.empname  FROM CMEMPM e WHERE e.empcode = p_iempcode ) --발의사원명
                    , ( SELECT  custname  FROM CMCUSTM  WHERE custcode = p_custcode ) --거래처명
                    , ( SELECT  custname  FROM CMCUSTM  WHERE custcode = p_agencode ) --대행처명
                    , p_lccode --LC코드
                    , p_lcname --LC명
                    , SYSDATE --입력일자
                    , p_iempcode --입력사원
            FROM DUAL ;
        


			MERGE INTO PDIMPORTCOSTM a
				 USING (SELECT A.IMPORTSHTNO
							  ,A.COSTSEQ
						  FROM PDIMPORTCOSTM a JOIN PDPURCHASEORDERM b ON a.importshtno = b.importshtno
						 WHERE b.plantcode = p_plantcode
							   AND a.custcost = p_custcode
							   AND a.accountno = ip_taxno) src
					ON (A.IMPORTSHTNO = SRC.IMPORTSHTNO
						AND A.COSTSEQ = SRC.COSTSEQ)
			WHEN MATCHED
			THEN
				UPDATE SET A.accountcheck = 'Y' ;



			MERGE INTO PDIMPORTCOSTM a
				 USING (SELECT A.IMPORTSHTNO
							  ,A.COSTSEQ
						  FROM PDIMPORTCOSTM a JOIN PDPURCHASEORDERM b ON a.importshtno = b.importshtno
						 WHERE b.plantcode = p_plantcode
							   AND a.custcost = p_custcode
							   AND TRIM(a.accountno) IS NULL
							   AND a.importshtno = ip_taxno) src
					ON (A.IMPORTSHTNO = SRC.IMPORTSHTNO
						AND A.COSTSEQ = SRC.COSTSEQ)
			WHEN MATCHED
			THEN
				UPDATE SET A.accountcheck = 'Y'
                           , A.accountno = ip_taxno ;
                
                
		ELSIF (p_actrnstate = '3') THEN
        
            --수정
            UPDATE  ACAUTOORDT b
            SET     b.slipindate = p_slipindate
                    ,b.acatrulecode = p_acatrulecode --분개률코드(N01001)
                    , b.deptcode = ( SELECT deptcode FROM CMEMPM WHERE empcode = p_iempcode ) --부서
                    , b.plantcode = p_plantcode --사업장
                    , b.empcode = p_iempcode --발의사원코드
                    , b.remark = p_itemnm
                    , b.custcode = p_custcode --거래처코드
                    , b.taxno = CASE WHEN p_acatrulecode <> 'N01004' THEN ip_taxno ELSE '' END --계산서번호
                    , b.billno = p_importshtno --수입전표번호
                    , b.trn1amt = p_expamt1 --비용금액1
                    , b.trn2amt = p_expamt2 --비용금액2
                    , b.trn3amt = p_expamt3 --비용금액3
                    , b.trn4amt = p_expamt4 --비용금액4
                    , b.trn5amt = p_expamt5 --비용금액5
                    , b.trn6amt = p_expamt6 --비용금액6
                    , b.trn11amt = p_expamt --비용금액
                    , b.trn12amt = p_expvat --부가세
                    , b.actrnstate = p_actrnstate --실행상태
                    , b.userdef1code = p_agencode --대행처코드
                    , b.userdef3code = (  SELECT plantname  FROM CMPLANTM WHERE plantcode = p_plantcode ) --사업장명
                    , b.userdef4code = (  SELECT D.deptname FROM CMEMPM e 
                                                 LEFT JOIN CMDEPTM D ON D.deptcode = e.deptcode 
                                          WHERE e.empcode = p_iempcode ) --부서명
                    , b.userdef5code = (  SELECT e.empname FROM CMEMPM e WHERE e.empcode = p_iempcode ) --사원명
                    , b.userdef6code = (  SELECT custname  FROM CMCUSTM  WHERE custcode = p_custcode ) --거래처명
                    , b.userdef7code = (  SELECT custname  FROM CMCUSTM  WHERE custcode = p_agencode ) --대행처명
                    , b.userdef9code = p_lccode --LC코드
                    , b.userdef10code = p_lcname --LC명
                    , b.updatedt = SYSDATE --입력일자
                    , b.uempcode = p_iempcode
            WHERE   b.compcode = p_compcode
                    AND b.acattype = 'N'
                    AND b.acatno = ip_taxno ;
                   
		ELSIF (p_actrnstate = '4') THEN
        
            UPDATE  ACAUTOORDT b
            SET     b.actrnstate = p_actrnstate --실행상태
                    , b.remark = p_itemnm
                    , b.updatedt = SYSDATE --입력일자
                    , b.uempcode = p_iempcode
            WHERE   b.compcode = p_compcode
                    AND b.acattype = 'N'
                    AND b.acatno = ip_taxno ;
                   
		END IF;
        
	END IF;


   <<LAST>>
	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
