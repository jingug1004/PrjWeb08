CREATE PROCEDURE spACacc0104R(
    -- ---------------------------------------------------------------
    -- 프로시저명       : spACacc0104R
    -- 수 정 자   : 배종성
    -- 수정일자   : 2010-12-02
    -- 수 정 자     : 노영래
    -- E-Mail       : 0rae0926@gmail.com
    -- 수정일자      : 2016-12-20
    -- ---------------------------------------------------------------
    -- 프로시저 설명    : 현금출납장을 조회하는 프로시저이다.
    -- ---------------------------------------------------------------
    -- 수정내용   : 전면 수정
    -- ---------------------------------------------------------------

    p_div            IN       VARCHAR2 DEFAULT '',
    p_compcode        IN       VARCHAR2 DEFAULT '', --회사코드
    p_plantcode     IN       VARCHAR2 DEFAULT '', --사업장코드
    p_acccode        IN       VARCHAR2 DEFAULT '',
    p_startdt        IN       VARCHAR2 DEFAULT '',
    p_enddt         IN       VARCHAR2 DEFAULT '',
    p_outputdiv     IN       VARCHAR2 DEFAULT '',
    p_userid        IN       VARCHAR2 DEFAULT '',
    p_reasondiv     IN       VARCHAR2 DEFAULT '',
    p_reasontext    IN       VARCHAR2 DEFAULT '',
    MESSAGE            OUT VARCHAR2,
    IO_CURSOR           OUT TYPES.DATASET
)
AS
    ip_acccode      VARCHAR2(20) := p_acccode;
    p_colview      VARCHAR2(1);
    p_slipdate      VARCHAR2(13); --전표번호
    p_slipnum      VARCHAR2(5); --회계일자
    p_slipinno      VARCHAR2(20);
    p_remark      VARCHAR2(100);
    p_debamt      FLOAT(53);
    p_creamt      FLOAT(53);
    p_fnamt       FLOAT(53);
    p_odiv1       VARCHAR2(5);
    p_odiv2       VARCHAR2(5); -- @fnamt 나중에 이월의 잔액을 넣어줘야함.
    p_float1      FLOAT(53);
    p_rows          NUMBER(10, 0);

    spsl_cursor   SYS_REFCURSOR;
--compcode       varchar(3)  null,
--plantcode      varchar(4)  null, --사업장코드
--회계일자
--전표번호
--결의번호
--insert into  VGT.TT_SPACACC0104R_SPACACC0104R values ('','이월',0,'',0,0,0)

BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    p_colview := '_';

    FOR rec IN (SELECT value1
                FROM   SYSPARAMETERMANAGE
                WHERE  parametercode = 'accldgcolview')
    LOOP
        p_colview := rec.value1;
    END LOOP;

	IF(p_colview = '_') THEN
    	p_colview := '0';
    END IF;

    IF (p_div = 'S')
    THEN
        ip_acccode := '';

        FOR rec IN (SELECT value1
                    FROM   SYSPARAMETERMANAGE
                    WHERE  parametercode = 'acccashcode')
        LOOP
            ip_acccode := rec.value1;
        END LOOP;

        IF (p_outputdiv = '1')
        THEN
            --K-GAAP
            BEGIN
                p_odiv1 := '20';
                p_odiv2 := 'F';
            END;
        END IF;

        IF (p_outputdiv = '2')
        THEN
            --IFRS
            p_odiv1 := '30';
            p_odiv2 := 'K';
        END IF;

        -- 전표일자(회계일자)
        -- 전표순번
        -- 결의번호
        --  적요
        -- 차변금액
        -- 대변금액
        -- 전표일자(회계일자)
        -- 전표순번
        -- 결의번호
        --  적요
        -- 차변금액
        -- 대변금액
        -- 출력구분 [K-GAAP, IFRS]
        -- 전표일자(회계일자)
        -- 전표순번
        -- 결의번호
        --  적요
        -- 차변금액
        -- 대변금액
        -- K-GAAP <> 'F', IFRS <> 'K'
        -- 전표일자(회계일자)
        -- 전표순번
        -- 결의번호
        --  적요
        -- 차변금액
        -- 대변금액
        -- K-GAAP <> 'F', IFRS <> 'K'
        -- 전표일자(회계일자)
        --'순번' as slipnum--a.slipnum -- 전표순번
        -- 결의번호
        --  적요
        -- 대변금액
        -- 차변금액
        --select * from  ACORDD
        -- K-GAAP <> 'F', IFRS <> 'K'
        -- 전표일자(회계일자)
        -- 전표순번
        -- 결의번호
        --  적요
        -- 차변금액
        -- 대변금액
        -- K-GAAP <> 'F', IFRS <> 'K'
        ----월계
        --select      slipym + '-90-99' as slipdate -- 전표일자(회계일자)
        --   ,'' as slipnum -- 전표순번
        --   ,'' as slipinno -- 결의번호
        --   ,'' as remark --  적요
        --   ,sum(isnull(debamt,0)) as debamt -- 차변금액
        --   ,sum(isnull(creamt,0)) as creamt -- 대변금액
        --from        ACORDDMM
        --where  compcode = @compcode
        --   and plantcode like @plantcode
        --   and acccode = @acccode
        --   and slipym >= left(@startdt,7)
        --   and ((slipym < left(@enddt,7)) or
        --    ((slipym = left(@enddt,7)) and ((substring(CONVERT(VARCHAR(10),DATEADD(dd,1,CONVERT(DATETIME,@enddt)),121),6,2)
        --    != substring(@enddt,6,2)))))
        --   and (closediv = '10' or closediv = @odiv1)  -- 출력구분 [K-GAAP, IFRS]
        --group by slipym
        --월계
        -- 전표일자(회계일자)
        -- 전표순번
        -- 결의번호
        --  적요
        -- 대변금액
        -- 차변금액
        -- 전표일자(회계일자)
        -- 전표순번
        -- 결의번호
        --  적요
        -- 차변금액
        -- 대변금액
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0104R_DUAL ';

        OPEN spsl_cursor FOR
            SELECT     slipdate,
                     slipnum,
                     slipinno,
                     remark,
                     debamt,
                     creamt
            FROM     (SELECT '1000-00-00' slipdate,
                             '' slipnum,
                             '' slipinno,
                             '' remark,
                             SUM(debamt) debamt,
                             SUM(creamt) creamt
                      FROM     (SELECT '' slipdate,
                                     '' slipnum,
                                     '이월' slipinno,
                                     '' remark,
                                     bsdebamt debamt,
                                     bscreamt creamt
                              FROM     ACORDDMM
                              WHERE  compcode = p_compcode
                                     AND plantcode LIKE p_plantcode
                                     AND slipym = NVL(SUBSTR(p_startdt, 1, 7),' ')
                                     AND acccode = ip_acccode
                                     AND (closediv = '10'
                                          OR closediv = p_odiv1)
                              UNION ALL
                              SELECT '' slipdate,
                                     '' slipnum,
                                     '이월' slipinno,
                                     '' remark,
                                     NVL(creamt, 0) debamt,
                                     NVL(debamt, 0) creamt
                              FROM     ACORDD A, ACORDM b
                              WHERE  A.slipinno = b.slipinno
                                     AND A.compcode = b.compcode
                                     AND A.compcode = p_compcode
                                     AND A.plantcode LIKE p_plantcode
                                     AND (dcdiv = '3'
                                          OR dcdiv = '4')
                                     AND A.slipdate < p_startdt
                                     AND A.slipdate >= SUBSTR(p_startdt, 1, 7) || '-01'
                                     AND b.slipdiv <> p_odiv2
                              UNION ALL
                              SELECT SUBSTR(A.slipdate, 0, 7) || '-90-99' slipdate,
                                     '' slipnum,
                                     '이월' slipinno,
                                     remark1 remark,
                                     NVL(debamt, 0) debamt,
                                     NVL(creamt, 0) creamt
                              FROM     ACORDD A, ACORDM b
                              WHERE  A.compcode = b.compcode
                                     AND A.slipinno = b.slipinno
                                     AND A.compcode = p_compcode
                                     AND A.plantcode LIKE p_plantcode
                                     AND (dcdiv = '1'
                                          OR dcdiv = '2')
                                     AND A.acccode = ip_acccode
                                     AND A.slipdate < p_startdt
                                     AND A.slipdate >= SUBSTR(p_startdt, 1, 7) || '-01'
                                     AND b.slipdiv <> p_odiv2) A
                      UNION ALL
                      SELECT A.slipdate,
                             A.slipnum slipnum,
                             A.slipinno,
                             remark1 remark,
                             NVL(creamt, 0) debamt,
                             NVL(debamt, 0) creamt
                      FROM     ACORDD A
                             LEFT JOIN ACORDM b
                                 ON A.compcode = b.compcode
                                    AND A.slipinno = b.slipinno
                      WHERE  A.compcode = p_compcode
                             AND A.plantcode LIKE p_plantcode
                             AND A.slipdate BETWEEN p_startdt AND p_enddt
                             AND (dcdiv = '3'
                                  OR dcdiv = '4')
                             AND b.slipdiv <> p_odiv2
                      UNION ALL
                      SELECT A.slipdate,
                             A.slipnum,
                             A.slipinno,
                             remark1 remark,
                             NVL(debamt, 0) debamt,
                             NVL(creamt, 0) creamt
                      FROM     ACORDD A, ACORDM b
                      WHERE  A.compcode = b.compcode
                             AND A.slipinno = b.slipinno
                             AND A.compcode = p_compcode
                             AND A.plantcode LIKE p_plantcode
                             AND A.slipdate BETWEEN p_startdt AND p_enddt
                             AND (dcdiv = '1'
                                  OR dcdiv = '2')
                             AND acccode = ip_acccode
                             AND b.slipdiv <> p_odiv2
                      UNION ALL
                      SELECT   slipdate,
                               '' slipnum,
                               '' slipinno,
                               '' remark,
                               SUM(debamt) debamt,
                               SUM(creamt) creamt
                      FROM       (SELECT SUBSTR(slipdate, 0, 7) || '-90-99' slipdate,
                                       slipnum,
                                       slipinno,
                                       remark1 remark,
                                       NVL(creamt, 0) debamt,
                                       NVL(debamt, 0) creamt
                                FROM   ACORDD
                                WHERE  compcode = p_compcode
                                       AND plantcode LIKE p_plantcode
                                       AND slipdate BETWEEN p_startdt AND p_enddt
                                       AND (dcdiv = '3'
                                            OR dcdiv = '4')
                                UNION ALL
                                SELECT SUBSTR(slipdate, 0, 7) || '-90-99' slipdate,
                                       slipnum,
                                       slipinno,
                                       remark1 remark,
                                       NVL(debamt, 0) debamt,
                                       NVL(creamt, 0) creamt
                                FROM   ACORDD
                                WHERE  compcode = p_compcode
                                       AND plantcode LIKE p_plantcode
                                       AND slipdate BETWEEN p_startdt AND p_enddt
                                       AND (dcdiv = '1'
                                            OR dcdiv = '2')
                                       AND acccode = ip_acccode) b
                      GROUP BY slipdate) A
            ORDER BY slipdate, REPLACE(slipnum, 'C', p_colview) , remark;

        IF p_fnamt IS NULL
        THEN
            p_fnamt := 0;
        END IF;

        p_float1 := 0;

        LOOP
            FETCH spsl_cursor
                INTO p_slipdate, p_slipnum, p_slipinno, p_remark, p_debamt, p_creamt;

            EXIT WHEN spsl_cursor%NOTFOUND;

            IF (NVL(SUBSTR(p_slipdate, 12, 2),' ') <> '99')
            THEN
                p_fnamt := NVL(p_fnamt, 0) + NVL(p_debamt, 0) - NVL(p_creamt, 0);
            END IF;

            INSERT INTO VGT.TT_ACACC0104R_DUAL
            VALUES        (p_slipdate,
                         p_slipnum,
                         p_slipinno,
                         p_remark,
                         p_debamt,
                         p_creamt,
                         p_fnamt);

            IF (NVL(SUBSTR(p_slipdate, -5, 5),' ') = '90-99')
            THEN
                INSERT INTO VGT.TT_ACACC0104R_DUAL
                    (SELECT SUBSTR(p_slipdate, 0, 7) || '-99-99',
                            '' slipnum,
                            '' slipinno,
                            '' remark,
                            SUM(debamt) debamt,
                            SUM(creamt) creamtm,
                            SUM(debamt) - SUM(creamt) fnamt
                     FROM    VGT.TT_ACACC0104R_DUAL
                     WHERE    NVL(SUBSTR(slipdate, 12, 2),' ') <> '99'
                            AND slipdate BETWEEN '1000-00-00' AND p_slipdate);
            END IF;
        END LOOP;

        CLOSE spsl_cursor;

        IF (NVL(SUBSTR(p_slipdate, -2, 2),' ') != '99')
        THEN
            INSERT INTO VGT.TT_ACACC0104R_DUAL
                (SELECT SUBSTR(p_slipdate, 0, 7) || '-99-99',
                        '' slipnum,
                        '' slipinno,
                        '' remark,
                        SUM(debamt) debamt,
                        SUM(creamt) creamtm,
                        SUM(debamt) - SUM(creamt) fnamt
                 FROM    VGT.TT_ACACC0104R_DUAL
                 WHERE    NVL(SUBSTR(slipdate, 12, 2),' ') <> '99'
                        AND slipdate BETWEEN '1000-00-00' AND p_slipdate);
        END IF;



        FOR rec IN (SELECT COUNT(*) AS alias1 FROM VGT.TT_ACACC0104R_DUAL)
        LOOP
            p_rows := rec.alias1;
        END LOOP;

        IF (p_rows = 1)
        THEN
            INSERT INTO VGT.TT_ACACC0104R_DUAL
                (SELECT '1000-00-01' slipdate,
                        '' slipnum,
                        '' slipinno,
                        '' remark,
                        SUM(debamt),
                        SUM(creamt),
                        SUM(debamt) - SUM(creamt) fnamt
                 FROM    VGT.TT_ACACC0104R_DUAL);

            OPEN IO_CURSOR FOR
                SELECT     (CASE SUBSTR(slipdate, -5, 5) WHEN '00-00' THEN '이월' WHEN '00-01' THEN '누계' ELSE slipdate END) slipdate,
                         NVL(slipdate, '') slipdate2,
                         NVL(slipnum, '') slipnum,
                         NVL(slipinno, '') slipinno,
                         NVL(remark, '') remark,
                         NVL(debamt, 0) debamt,
                         NVL(creamt, 0) creamt,
                         NVL(fnamt, 0) fnamt
                FROM     VGT.TT_ACACC0104R_DUAL A
                ORDER BY slipdate2, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9'),slipnum  ;
        ELSE
            OPEN IO_CURSOR FOR
                SELECT     (CASE SUBSTR(slipdate, -5, 5) WHEN '00-00' THEN '이월' WHEN '90-99' THEN '월계' WHEN '99-99' THEN '누계' ELSE slipdate END) slipdate,
                         NVL(slipdate, '') slipdate2,
                         NVL(slipnum, '') slipnum,
                         NVL(slipinno, '') slipinno,
                         NVL(remark, '') remark,
                         NVL(debamt, 0) debamt,
                         NVL(creamt, 0) creamt,
                         (CASE SUBSTR(slipdate, -5, 5) WHEN '90-99' THEN 0 ELSE NVL(fnamt, 0) END) fnamt
                FROM     VGT.TT_ACACC0104R_DUAL A
                ORDER BY slipdate2, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9'),slipnum, remark;
        END IF;
    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
