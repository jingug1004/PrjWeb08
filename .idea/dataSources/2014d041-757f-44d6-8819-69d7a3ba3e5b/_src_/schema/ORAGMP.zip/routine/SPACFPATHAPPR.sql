CREATE PROCEDURE        spacfPathAppr
-- ---------------------------------------------------------------
 -- 프로시저명       : spacfPathAppr
 -- 작 성 자         : 최용석
 -- 작성일자         : 2011-12-19
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 결의전표 결제라인을 조회하는 프로시저이다.
 -- ---------------------------------------------------------------

(
  p_div IN VARCHAR2 DEFAULT '' ,
  p_compcode IN VARCHAR2 DEFAULT '' ,
  p_deptcode IN VARCHAR2 DEFAULT ' ' ,
  p_pathname0 IN VARCHAR2 DEFAULT '' ,
  p_pathname1 IN VARCHAR2 DEFAULT '' ,
  p_pathname2 IN VARCHAR2 DEFAULT '' ,
  p_pathname3 IN VARCHAR2 DEFAULT '' ,
  p_pathname4 IN VARCHAR2 DEFAULT '' ,
  p_pathname5 IN VARCHAR2 DEFAULT '' ,
  p_pathname6 IN VARCHAR2 DEFAULT '' ,
  p_pathname7 IN VARCHAR2 DEFAULT '' ,
  p_pathname8 IN VARCHAR2 DEFAULT '' ,
  p_pathname9 IN VARCHAR2 DEFAULT '' ,
  p_pathname10 IN VARCHAR2 DEFAULT '' ,
  p_pathname11 IN VARCHAR2 DEFAULT '' ,
  p_pathname12 IN VARCHAR2 DEFAULT '' ,
  p_pathname13 IN VARCHAR2 DEFAULT '' ,
  p_pathname14 IN VARCHAR2 DEFAULT '' ,
  p_userid IN VARCHAR2 DEFAULT '' ,
  p_reasondiv IN VARCHAR2 DEFAULT '' ,
  p_reasontext IN VARCHAR2 DEFAULT '' ,
  IO_CURSOR         OUT TYPES.DataSet,
  MESSAGE           OUT VARCHAR2
)
AS
   ip_deptcode VARCHAR2(20) := p_deptcode;
   v_temp NUMBER(1, 0) := 0;
BEGIN

    MESSAGE := '데이터 확인' ;



    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO   ATINFO (USERID, REASONDIV, REASONTEXT)
                  VALUES (p_userid, p_reasondiv, p_reasontext);

    IF ( p_div = 'S' ) THEN

        BEGIN
            SELECT 1 INTO v_temp
              FROM DUAL
             WHERE NOT EXISTS
                      (
                           SELECT *
                             FROM ACORPATH
                            WHERE compcode = p_compcode AND TRIM(nvl(deptcode,'')) = ip_deptcode
                      );

            EXCEPTION
                WHEN NO_DATA_FOUND THEN NULL;
                WHEN OTHERS THEN NULL;
        END;
        IF v_temp = 1 THEN
            ip_deptcode := NULL ;
        END IF;

        OPEN  IO_CURSOR FOR
        SELECT  *
        FROM    ACORPATH
        WHERE   compcode = p_compcode
            AND deptcode = ip_deptcode ;


    ELSIF ( p_div = 'I' ) THEN

        v_temp := 0;

        SELECT  1 INTO v_temp
        FROM    DUAL
        WHERE EXISTS (
                        SELECT  *
                        FROM    ACORPATH
                        WHERE   compcode = p_compcode
                            AND deptcode = ip_deptcode
                     );



        MERGE INTO ACORPATH A
            USING  DUAL
                ON (A.compcode = p_compcode AND A.deptcode = ip_deptcode)
        WHEN MATCHED THEN
            UPDATE
                SET a.pathname0 = p_pathname0,
                   a.pathname1 = p_pathname1,
                   a.pathname2 = p_pathname2,
                   a.pathname3 = p_pathname3,
                   a.pathname4 = p_pathname4,
                   a.pathname5 = p_pathname5,
                   a.pathname6 = p_pathname6,
                   a.pathname7 = p_pathname7,
                   a.pathname8 = p_pathname8,
                   a.pathname9 = p_pathname9,
                   a.pathname10 = p_pathname10,
                   a.pathname11 = p_pathname11,
                   a.pathname12 = p_pathname12,
                   a.pathname13 = p_pathname13,
                   a.pathname14 = p_pathname14
        WHEN NOT MATCHED THEN
            INSERT         ( compcode, deptcode, pathname0, pathname1, pathname2, pathname3, pathname4, pathname5, pathname6, pathname7, pathname8, pathname9, pathname10, pathname11, pathname12, pathname13, pathname14 )
                    VALUES ( p_compcode, ip_deptcode, p_pathname0, p_pathname1, p_pathname2, p_pathname3, p_pathname4, p_pathname5, p_pathname6, p_pathname7, p_pathname8, p_pathname9, p_pathname10, p_pathname11, p_pathname12, p_pathname13, p_pathname14 );


    END IF;


    IF (IO_CURSOR IS NULL) THEN
      OPEN IO_CURSOR FOR SELECT 1 FROM DUAL;
    END IF;

END;
/
