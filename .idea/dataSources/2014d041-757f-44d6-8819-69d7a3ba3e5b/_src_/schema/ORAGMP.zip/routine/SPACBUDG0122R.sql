CREATE PROCEDURE        spACbudg0122R
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACbudg0122R
   -- 작 성 자         : 최용석
   -- 작성일자         : 2012-10-24
   -- 수 정 자         : 임 정호
   -- 수정일자         : 2017-01-02
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 사원별예산대비실적현황을 조회하는 프로시저이다.
   -- ---------------------------------------------------------------
(
  p_div          IN      VARCHAR2 DEFAULT '',
   p_compcode     IN     VARCHAR2 DEFAULT '',
   p_budgym       IN     VARCHAR2 DEFAULT '',
   p_empcode1     IN     VARCHAR2 DEFAULT '',
   p_empcode2     IN     VARCHAR2 DEFAULT '',
   p_userid       IN     VARCHAR2 DEFAULT '',
   p_reasondiv    IN     VARCHAR2 DEFAULT '',
   p_reasontext   IN     VARCHAR2 DEFAULT '',
   IO_CURSOR         OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2
)
AS
BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    OPEN IO_CURSOR FOR
    SELECT CASE WHEN p_div = 'S' OR grp = 3 THEN ' ' ELSE a.empcode END empcode,
           MAX ( CASE WHEN p_div = 'S' OR grp = 3 THEN ' ' ELSE c.empname END) empname,
           CASE WHEN grp = 1 THEN a.acccode ELSE ' ' END acccode,
           MAX ( CASE
                      WHEN grp = 1 THEN D.accname
                      WHEN p_div = 'S' AND grp = 2 OR p_div = 'S1' AND grp = 3 THEN '합계'
                      ELSE '소계'
                 END) accname,
           SUM (NVL (a.budgamt, 0)) ybudgamt,
           SUM (NVL (a.budgamt1, 0)) lastmbudgamt,
           SUM (NVL (a.restotamt1, 0)) lastmrestotamt,
           SUM (NVL (a.budgamt2, 0)) pmbudgamt,
           SUM (NVL (a.restotamt2, 0)) pmrestotamt,
           SUM (NVL (a.budgamt2, 0)) - SUM (NVL (a.restotamt2, 0)) pmdiffamt,
           SUM (NVL (a.budgamt3, 0)) budgamt,
           SUM (NVL (a.restotamt3, 0)) restotamt,
           SUM (NVL (a.budgamt3, 0)) - SUM (NVL (a.restotamt3, 0)) diffamt,
           p_budgym || '-01' startdt,
           TO_CHAR(ADD_MONTHS ( to_date (p_budgym || '-01','YYYY-MM-DD' ), 1) -1,'YYYY-MM-DD') enddt,
           MAX ( CASE WHEN p_div = 'S' AND grp = 2 OR p_div = 'S1' AND grp = 3 THEN 'zzzzzzz' ELSE a.empcode END) ord
      FROM (  SELECT empcode,
                     acccode,
                     SUM (budgamt + addamt) budgamt,              -- 수정년예산
                     SUM (slipamt) restotamt,                     -- 전표년실적
                     SUM ( CASE WHEN budgym < p_budgym THEN budgamt + addamt ELSE 0 END) budgamt1,
                     SUM ( CASE WHEN budgym < p_budgym THEN slipamt ELSE 0 END) restotamt1,
                     SUM ( CASE WHEN budgym = p_budgym THEN budgamt + addamt ELSE 0 END) budgamt2,
                     SUM ( CASE WHEN budgym = p_budgym THEN slipamt ELSE 0 END) restotamt2,
                     SUM ( CASE WHEN budgym <= p_budgym THEN budgamt + addamt ELSE 0 END) budgamt3,
                     SUM ( CASE WHEN budgym <= p_budgym THEN slipamt ELSE 0 END) restotamt3
                FROM ACBUDGYYE
               WHERE     compcode = p_compcode
                     AND budgym LIKE SUBSTR (p_budgym, 0, 4) || '%'
                     AND (p_empcode1 IS NULL  OR empcode >= p_empcode1)
                     AND (p_empcode2 IS NULL  OR empcode <= p_empcode2)
            GROUP BY empcode, acccode
              HAVING    SUM (budgamt) <> 0
                     OR SUM (slipamt) <> 0
                     OR SUM ( CASE WHEN budgym <= p_budgym THEN budgamt + addamt ELSE 0 END) <> 0
                     OR SUM ( CASE WHEN budgym <= p_budgym THEN slipamt ELSE 0 END) <> 0
            ) a
           JOIN (SELECT 1 grp FROM DUAL
                 UNION
                 SELECT 2 FROM DUAL
                 UNION
                 SELECT 3 FROM DUAL) b
              ON p_div = 'S1' OR b.grp <> 3
           LEFT JOIN CMEMPM c ON a.empcode = c.empcode
           LEFT JOIN ACACCM D ON a.acccode = D.acccode
    GROUP BY CASE WHEN p_div = 'S' OR grp = 3 THEN ' ' ELSE a.empcode END,
           CASE WHEN grp = 1 THEN a.acccode ELSE ' ' END,
           b.grp
    ORDER BY ord, empcode, grp, acccode;



    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
