CREATE PROCEDURE        spACacc0206R
-- ---------------------------------------------------------------
-- 프로시저명       : spACacc0206R
-- 작 성 자         : 최기홍
-- 작성일자         : 2010-10-08
-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2016-12-21
-- ---------------------------------------------------------------
-- 프로시저 설명    : 손익계산서를 조회하는 프로시저이다.
-- ---------------------------------------------------------------
-- select * from CMCOMMONM where cmmcode = 'AC85' --전기기준
(
	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_rptdiv		IN	   VARCHAR2 DEFAULT '',
	p_closediv		IN	   VARCHAR2 DEFAULT '',
	p_basisym		IN	   VARCHAR2 DEFAULT '',
	p_viewyn		IN	   VARCHAR2 DEFAULT 'Y',
	p_pretype		IN	   VARCHAR2 DEFAULT '1',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		OUT    VARCHAR2,
	IO_CURSOR		OUT    TYPES.DataSet
)
AS
    p_basisyy    VARCHAR2(4);
    p_beyymm     VARCHAR2(7);
    p_yyyy01     VARCHAR2(7);
    p_beyy01     VARCHAR2(7);
    p_cashcode   VARCHAR2(20);

    -- 임시테이블의 calcseq의 최대값을 조회
    p_maxseq     NUMBER;
    p_curseq     NUMBER;

    p_seqNext    INTEGER := 0;
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S' OR p_div = 'P') THEN

        -- 기간 설정
        p_yyyy01 := SUBSTR(p_basisym, 0, 4) || '-01';

        FOR rec IN (SELECT SUBSTR(curstrdate, 0, 7) AS alias1
                    FROM   ACSESSION
                    WHERE  compcode = p_compcode
                           AND cyear <= SUBSTR(p_basisym, 0, 4) )
        LOOP
            p_yyyy01 := rec.alias1;
        END LOOP;


        IF SUBSTR(p_basisym, -2, 2) < SUBSTR(p_yyyy01, -2, 2) THEN
            p_yyyy01 := TO_CHAR(add_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), -12), 'YYYY-') || SUBSTR(p_yyyy01, -2, 2);
        ELSE
            p_yyyy01 := SUBSTR(p_basisym, 0, 5) || SUBSTR(p_yyyy01, -2, 2);
        END IF;


        IF p_pretype = '1' THEN
            p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), -12), 'YYYY-MM');
        ELSIF p_pretype = '2' OR p_pretype = '3' AND SUBSTR(p_basisym, -2, 2) = SUBSTR(p_yyyy01, -2, 2) THEN
            p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01 || '-01', 'YYYY-MM-DD'), -1), 'YYYY-MM');
        ELSE
            p_beyymm := TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), -1), 'YYYY-MM');
        END IF;


        IF p_pretype = '3' AND SUBSTR(p_basisym, -2, 2) <> SUBSTR(p_yyyy01, -2, 2) THEN
            p_beyy01 := p_yyyy01;
        ELSE
            p_beyy01 := TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyy01 || '-01', 'YYYY-MM-DD'), -12), 'YYYY-MM');
        END IF;


        p_cashcode := '11101010';

        FOR rec IN (SELECT value1
                    FROM   SYSPARAMETERMANAGE
                    WHERE  parametercode = 'acccashcode')
        LOOP
            p_cashcode := rec.value1;
        END LOOP;


        -- 보고서 조회년도 설정
        FOR rec IN (SELECT  MAX(rptyear) AS alias1
                    FROM    ACRPTM
                    WHERE   compcode = p_compcode
                            AND rptdiv = p_rptdiv
                            AND rptyear <= SUBSTR(p_basisym, 0, 4) )
        LOOP
            p_basisyy := rec.alias1;
        END LOOP;




        -- 전표에서 월집계 임시파일을 생성
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0206R_ACORDDMM ';

        INSERT INTO VGT.TT_ACACC0206R_ACORDDMM (
            SELECT  p_compcode compcode,
                    p_plantcode plantcode,
                    p_basisym slipym,
                    CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
                    acccode,
                    SUM(totdebamt) totdebamt,
                    SUM(totcreamt) totcreamt
            FROM    (   SELECT  b.acccode
                                , b.debamt totdebamt
                                , b.creamt totcreamt
                        FROM    ACORDM a
                                JOIN ACORDD b ON a.compcode = b.compcode
                                                 AND a.slipinno = b.slipinno
                        WHERE   a.compcode = p_compcode
                                AND a.plantcode LIKE p_plantcode
                                AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), 1), 'YYYYMM')
                                AND a.slipinstate = '4'
                                AND (a.slipdiv NOT IN ('K', 'F') OR p_closediv = '1' AND  a.slipdiv = 'K' OR p_closediv = '2' AND  a.slipdiv = 'F')
                        UNION ALL
                        SELECT  p_cashcode acccode
                                , b.creamt totdebamt
                                , b.debamt totcreamt
                        FROM    ACORDM a
                                JOIN ACORDD b ON a.compcode = b.compcode
                                                 AND a.slipinno = b.slipinno
                                                 AND b.dcdiv IN ('3', '4')
                        WHERE   a.compcode = p_compcode
                                AND a.plantcode LIKE p_plantcode
                                AND a.slipno BETWEEN REPLACE(p_yyyy01, '-', '') AND TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), 1), 'YYYYMM')
                                AND a.slipinstate = '4'
                                AND (a.slipdiv NOT IN ('K', 'F') OR p_closediv = '1' AND a.slipdiv = 'K' OR p_closediv = '2' AND a.slipdiv = 'F')
                        UNION ALL
                        SELECT  acccode
                                , bsdebamt totdebamt
                                , bscreamt totcreamt
                        FROM    ACORDDMM
                        WHERE   compcode = p_compcode
                                AND plantcode LIKE p_plantcode
                                AND slipym = p_yyyy01
                                AND (p_closediv = '1' AND closediv IN ('10', '20') OR p_closediv = '2' AND closediv IN ('10', '30'))) a
                        GROUP BY acccode
        );



        INSERT INTO VGT.TT_ACACC0206R_ACORDDMM (
            SELECT  p_compcode compcode,
                    p_plantcode plantcode,
                    p_beyymm slipym,
                    CASE WHEN p_closediv = '1' THEN '20' ELSE '30' END closediv,
                    acccode,
                    SUM(totdebamt) totdebamt,
                    SUM(totcreamt) totcreamt
            FROM    ACORDDMM
            WHERE   compcode = p_compcode
                    AND plantcode LIKE p_plantcode
                    AND slipym = p_beyymm
                    AND (p_closediv = '1' AND closediv IN ('10', '20') OR p_closediv = '2' AND closediv IN ('10', '30'))
            GROUP BY acccode
        );



        -- 계정별 월별합계테이블에서 기초데이터를 조회(잔액, 차변, 대변, 당기차변, 당기대변)하여 임시테이블에 insert
        EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0206R_ACC206A';

        INSERT INTO VGT.TT_ACACC0206R_ACC206A(seqline,
                                              acccode,
                                              accrname,
                                              acckname,
                                              lrdiv,
                                              prtyn,
                                              prtdiv,
                                              prtbold,
                                              sseqline,
                                              calcseq,
                                              calcdiv,
                                              cseqline,
                                              cgb,
                                              objdatadiv,
                                              amt,
                                              beamt)
            SELECT	 a.seqline,
                     MAX(a.acccode),
                     MAX(a.accrname),
                     MAX(a.acckname),
                     MAX(a.lrdiv),
                     MAX(a.prtyn),
                     MAX(a.prtdiv),
                     MAX(a.prtbold),
                     MAX(a.sseqline),
                     MAX(a.calcseq),
                     MAX(a.calcdiv),
                     MAX(a.cseqline),
                     '1',
                     MAX(a.objdatadiv),
                     NVL(SUM(CASE WHEN c.slipym = p_basisym THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt
                                                                      WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt
                                                                      WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt
                                                                                                        ELSE c.totcreamt - c.totdebamt
                                                                                                   END
                                                                 END
                             END), 0 ) amt2,
                     NVL(SUM(CASE WHEN c.slipym = p_beyymm THEN CASE WHEN a.objdatadiv IN ('D', 'F') THEN c.totdebamt
                                                                     WHEN a.objdatadiv IN ('C', 'E') THEN c.totcreamt
                                                                     WHEN a.objdatadiv = 'J' THEN CASE WHEN b.dcdiv = '1' THEN c.totdebamt - c.totcreamt
                                                                                                       ELSE c.totcreamt - c.totdebamt
                                                                                                  END
                                                                 END
                            END), 0 ) amt4
            FROM	 ACRPTM a
                     LEFT JOIN ACACCM b ON NVL(a.acccode,' ') = NVL(b.acccode,' ')
                     LEFT JOIN VGT.TT_ACACC0206R_ACORDDMM c ON a.compcode = c.compcode
                            AND c.plantcode LIKE p_plantcode
                            AND c.slipym IN (p_basisym, p_beyymm)
                            AND (p_closediv = '1' AND c.closediv IN ('10', '20') OR
                                 p_closediv = '2' AND c.closediv IN ('10', '30'))
                            AND NVL(a.acccode,' ') = NVL(c.acccode,' ')
            WHERE	 a.compcode = p_compcode
                     AND a.rptdiv = p_rptdiv
                     AND a.rptyear = p_basisyy
                     AND a.useyn = 'Y'
            GROUP BY a.seqline
            ORDER BY a.seqline;



        -- 계정별 월별합계테이블에서 기초데이터를 조회(기초, 당기차변, 당기대변)하여 임시테이블에 update
        MERGE INTO VGT.TT_ACACC0206R_ACC206A a
        USING (
                SELECT  CASE WHEN a.objdatadiv = 'A' THEN b.amt
                             ELSE a.amt - b.amt
                        END AS amt
                        , CASE WHEN a.objdatadiv = 'A' THEN b.beamt
                               ELSE a.beamt - b.beamt
                        END AS beamt
                        , a.seqline
                FROM    VGT.TT_ACACC0206R_ACC206A a
                JOIN    (   SELECT  a.seqline,
                                    NVL(SUM(CASE WHEN c.slipym = p_yyyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt
                                                                                    WHEN a.objdatadiv = 'E' THEN c.bscreamt
                                                                                    WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt
                                                                                                                      ELSE c.bscreamt - c.bsdebamt
                                                                                                                 END
                                                                               END
                                            END), 0 ) amt,
                                    NVL(SUM(CASE WHEN c.slipym = p_beyy01 THEN CASE WHEN a.objdatadiv = 'F' THEN c.bsdebamt
                                                                                    WHEN a.objdatadiv = 'E' THEN c.bscreamt
                                                                                    WHEN a.objdatadiv = 'A' THEN CASE WHEN b.dcdiv = '1' THEN c.bsdebamt - c.bscreamt
                                                                                                                      ELSE c.bscreamt - c.bsdebamt
                                                                                                                 END
                                                                               END
                                            END), 0 ) beamt
                            FROM    ACRPTM a
                                    LEFT JOIN ACACCM b ON NVL(a.acccode,' ') = NVL(b.acccode,' ')
                                    LEFT JOIN ACORDDMM c ON a.compcode = c.compcode
                                                            AND c.plantcode LIKE p_plantcode
                                                            AND c.slipym IN (p_yyyy01, p_beyy01)
                                                            AND (p_closediv = '1' AND c.closediv IN ('10', '20') OR p_closediv = '2' AND c.closediv IN ('10', '30'))
                                                            AND NVL(a.acccode,' ') = NVL(c.acccode,' ')
                            WHERE	a.compcode = p_compcode
                                    AND a.rptdiv = p_rptdiv
                                    AND a.rptyear = p_basisyy
                                    AND a.useyn = 'Y'
                                    AND a.objdatadiv IN ('A', 'E', 'F')
                            GROUP BY a.seqline  ) b ON a.seqline = b.seqline
        ) b ON ( a.seqline = b.seqline )
        WHEN MATCHED THEN UPDATE SET    a.amt = b.amt
                                        , a.beamt = b.beamt ;



        -- 당기제품제조원가를 구함
        spACacc0208R(p_div => 'S',
                            p_compcode => p_compcode,
                            p_plantcode => p_plantcode,
                            p_rptdiv => '9',
                            p_closediv => p_closediv,
                            p_basisym => p_basisym,
                            p_viewyn => 'N',
                            MESSAGE => MESSAGE,
                            IO_CURSOR => IO_CURSOR );



        IF MESSAGE <> '데이터 확인' THEN

            MERGE INTO VGT.TT_ACACC0206R_ACC206A a
            USING (
                        SELECT  TO_NUMBER(SUBSTR(MESSAGE, 0, INSTR(MESSAGE, ';') - 1)) AS amt
                                , TO_NUMBER(SUBSTR(MESSAGE, -(LENGTH(MESSAGE) - INSTR(MESSAGE, ';')))) AS beamt
                                , a.seqline
                        FROM    VGT.TT_ACACC0206R_ACC206A a
                                JOIN ACRPTM b ON b.compcode = p_compcode
                                                 AND b.rptdiv = p_rptdiv
                                                 AND b.rptyear = p_basisyy
                                                 AND a.seqline = b.seqline
                        WHERE   b.remark = '당기제품제조원가'
                    ) b ON ( a.seqline = b.seqline )
            WHEN MATCHED THEN   UPDATE SET  a.amt = b.amt
                                            , a.beamt = b.beamt ;

        END IF;


        -- 임시테이블의 calcseq의 최대값을 조회
        p_curseq := 0;

        FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0206R_ACC206A)
        LOOP
            p_maxseq := rec.alias1;
        END LOOP;


        -- 각 레벨별로 sum을하여 update
        WHILE p_curseq <= p_maxseq LOOP

            MERGE INTO VGT.TT_ACACC0206R_ACC206A a
            USING (
                    SELECT  a.amt + b.amt AS amt
                            , a.beamt + b.beamt AS beamt
                            , a.seqline
                    FROM    VGT.TT_ACACC0206R_ACC206A a
                            JOIN ( SELECT   a.sseqline
                                            , SUM(CASE WHEN a.calcdiv = '+' THEN a.amt ELSE -a.amt END) amt
                                            , SUM(CASE WHEN a.calcdiv = '+' THEN a.beamt ELSE -a.beamt END) beamt
                                   FROM	  VGT.TT_ACACC0206R_ACC206A a
                                   WHERE	  a.calcseq = p_curseq
                                            AND NVL(a.sseqline, '') IS NOT NULL
                                   GROUP BY a.sseqline ) b ON a.seqline = b.sseqline ) b
            ON ( a.seqline = b.seqline)
            WHEN MATCHED THEN UPDATE SET    a.amt = b.amt
                                            , a.beamt = b.beamt;

            p_curseq := p_curseq + 1;

        END LOOP;



        --임시테이블 데이터 삭제
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0206R_ACC206B';

        INSERT INTO VGT.TT_ACACC0206R_ACC206B
            SELECT   a.cseqline,
                     a.seqline,
                     a.amt,
                     a.beamt,
                     0,
                     0,
                     b.amt,
                     b.beamt,
                     0,
                     ROWNUM
            FROM    VGT.TT_ACACC0206R_ACC206A a
                    JOIN VGT.TT_ACACC0206R_ACC206A b ON a.cseqline = b.seqline
            WHERE   (a.amt <> 0 OR a.beamt <> 0)
            ORDER BY a.cseqline, a.seqline DESC ;



        MERGE INTO VGT.TT_ACACC0206R_ACC206B a
        USING (
                SELECT  a.ord - b.minNo + 1 AS num
                        , a.cseqline
                FROM    VGT.TT_ACACC0206R_ACC206B a
                        JOIN (  SELECT  cseqline
                                        , MIN(ord) minNo
                                FROM    VGT.TT_ACACC0206R_ACC206B
                                GROUP BY VGT.TT_ACACC0206R_ACC206B.cseqline ) b ON a.cseqline = b.cseqline
              ) b ON ( a.cseqline = b.cseqline )
        WHEN MATCHED THEN UPDATE SET    a.num = b.num
                                        , a.amt2 = 0
                                        , a.beamt2 = 0 ;


        MERGE INTO VGT.TT_ACACC0206R_ACC206B a
        USING (
                SELECT  b.amt
                        , b.beamt
                        , a.cseqline
                FROM    VGT.TT_ACACC0206R_ACC206B a
                        JOIN (  SELECT  cseqline
                                        , SUM(amt) amt
                                        , SUM(beamt) beamt
                                FROM    VGT.TT_ACACC0206R_ACC206B
                                GROUP BY cseqline ) b ON a.cseqline = b.cseqline
                                                         AND a.num = 1
              ) b ON ( a.cseqline = b.cseqline AND a.num = 1 )
        WHEN MATCHED THEN UPDATE SET a.amt2 = b.amt
                                     , a.beamt2 = b.beamt ;


        MERGE INTO VGT.TT_ACACC0206R_ACC206A a
        USING (
                SELECT  a.cseqline
                FROM    VGT.TT_ACACC0206R_ACC206A a
                        JOIN (  SELECT DISTINCT a.cseqline FROM VGT.TT_ACACC0206R_ACC206B a
                                UNION
                                SELECT a.seqline FROM VGT.TT_ACACC0206R_ACC206B a ) b ON a.seqline = b.cseqline
        ) b ON ( a.seqline = b.cseqline )
        WHEN MATCHED THEN UPDATE SET a.lrdiv = 'L' ;



        MERGE INTO VGT.TT_ACACC0206R_ACC206A a
        USING (
                SELECT  b.amt3 - amt2 AS calcamt
                        , b.beamt3 - beamt2 AS becalcamt
                        , a.seqline
                FROM    VGT.TT_ACACC0206R_ACC206A a
                        JOIN (  SELECT   a.seqline
                                        , a.amt2
                                        , a.amt3
                                        , a.beamt2
                                        , a.beamt3
                                FROM	VGT.TT_ACACC0206R_ACC206B a
                                WHERE	a.num = 1 ) b ON a.seqline = b.seqline
              ) b ON (  a.seqline = b.seqline )
        WHEN MATCHED THEN UPDATE SET a.calcamt = b.calcamt
                                     , a.becalcamt = b.becalcamt
                                     , a.cgb = '2' ;


        -- 최종조회
        IF ( UPPER(p_div) = UPPER('P') ) THEN

            OPEN IO_CURSOR FOR

                SELECT  NULLIF(CASE WHEN a.lrdiv = 'L' AND a.prtyn = 'Y' THEN a.amt END, 0) baldramt,
                        NULLIF(CASE WHEN a.cgb = '2' AND a.prtyn = 'Y' THEN a.calcamt
                                    WHEN a.cgb <> '2' AND a.lrdiv = 'R' AND a.prtyn = 'Y' THEN a.amt
                                END, 0) dramt,
                        NULL mondramt,
                        CASE WHEN a.amt >= 0 THEN a.accrname ELSE a.acckname END accname,
                        NULL moncramt,
                        NULLIF(CASE WHEN a.lrdiv = 'L' AND a.prtyn = 'Y' THEN a.beamt END, 0) cramt,
                        NULLIF(CASE WHEN a.cgb = '2' AND a.prtyn = 'Y' THEN a.becalcamt
                                    WHEN a.cgb <> '2' AND a.lrdiv = 'R' AND a.prtyn = 'Y' THEN a.beamt
                               END, 0) balcramt,
                        a.prtbold,
                        D.session1 || SUBSTR(p_basisym, 0, 4) || '년  ' || SUBSTR(p_basisym, 6, 2) || '월  ' || SUBSTR(TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), 1), 'YYYY-MM-DD'), -2, 2) || '일  현재' title1,
                        D.session2 || SUBSTR(p_beyymm, 0, 4) || '년  ' || SUBSTR(p_beyymm, 6, 2) || '월  ' || SUBSTR(TO_CHAR(ADD_MONTHS(TO_DATE(p_beyymm || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD'), -2, 2) || '일  현재' title2,
                        CASE WHEN p_plantcode = '%' THEN '회사명 : ' || b.compname ELSE '사업장명 : ' || NVL(NULLIF(c.plantfullname, NULL), c.plantname) END compname,
                        '(단위 : 원)' prtunit,
                        NULL baldramt2,
                        NULL dramt2,
                        NULL mondramt2,
                        NULL accname2,
                        NULL moncramt2,
                        NULL cramt2,
                        NULL balcramt2
                FROM    VGT.TT_ACACC0206R_ACC206A a
                        LEFT JOIN CMCOMPM b ON b.compcode = p_compcode
                        LEFT JOIN CMPLANTM c ON c.plantcode = p_plantcode
                        LEFT JOIN ( SELECT  MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_basisym, 0, 4) THEN sseq END) || '기  ') session1,
                                            MAX('제 ' || TO_CHAR(CASE WHEN cyear = SUBSTR(p_beyymm, 0, 4) THEN sseq END) || '기  ') session2
                                    FROM    ACSESSION
                                    WHERE   compcode = p_compcode
                                            AND cyear IN (SUBSTR(p_basisym, 0, 4), SUBSTR(p_beyymm, 0, 4))) D ON 1 = 1
                WHERE   a.prtdiv <> 'C'
                        AND ( a.amt <> 0 OR a.calcamt <> 0 OR a.beamt <> 0 OR a.becalcamt <> 0 OR a.prtdiv = 'A' )
				ORDER BY a.seqline;

        ELSIF (p_viewyn = 'Y') THEN

            OPEN IO_CURSOR FOR

                SELECT  CASE WHEN amt >= 0 THEN accrname ELSE acckname END accname,
                        NULLIF(CASE WHEN lrdiv = 'L' AND prtyn = 'Y' THEN amt END, 0) amt1,
                        NULLIF(CASE WHEN cgb = '2' AND prtyn = 'Y' THEN calcamt
                                    WHEN cgb <> '2' AND lrdiv = 'R' AND prtyn = 'Y' THEN amt
                               END, 0) amt2,
                        NULLIF(CASE WHEN lrdiv = 'L' AND prtyn = 'Y' THEN beamt END, 0) amt3,
                        NULLIF(CASE WHEN cgb = '2' AND prtyn = 'Y' THEN becalcamt
                                    WHEN cgb <> '2' AND lrdiv = 'R' AND prtyn = 'Y' THEN beamt
                               END, 0) amt4,
                        p_plantcode plantcode,
                        p_yyyy01 || '-01' strdate,
                        TO_CHAR(ADD_MONTHS(TO_DATE(p_basisym || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD') enddate,
                        acccode,
                        p_closediv closediv,
                        prtbold
                FROM    VGT.TT_ACACC0206R_ACC206A
                WHERE   prtdiv <> 'C'
                        AND (amt <> 0 OR calcamt <> 0 OR beamt <> 0 OR becalcamt <> 0 OR prtdiv = 'A' )
				ORDER BY seqline;

        END IF;

        FOR rec IN (SELECT TO_CHAR(TRUNC(NVL(amt, 0))) || ';' || TO_CHAR(TRUNC(NVL(beamt, 0))) AS alias1
                    FROM   VGT.TT_ACACC0206R_ACC206A
                    WHERE  seqline = (SELECT MAX(seqline) FROM VGT.TT_ACACC0206R_ACC206A)
        )
        LOOP
            MESSAGE := rec.alias1;
        END LOOP;


    ELSIF (p_div = 'Y') THEN

        OPEN IO_CURSOR FOR
            SELECT *
            FROM   (SELECT   CASE WHEN cyear = SUBSTR(p_basisym, 0, 4) THEN sseq
                                  ELSE sseq - TO_NUMBER(cyear) + TO_NUMBER(SUBSTR(p_basisym, 0, 4))
                             END sseq
                    FROM     ACSESSION
                    WHERE    compcode = p_compcode
                             AND cyear <= SUBSTR(p_basisym, 0, 4)
                    ORDER BY cyear DESC)
            WHERE  ROWNUM <= 1;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
