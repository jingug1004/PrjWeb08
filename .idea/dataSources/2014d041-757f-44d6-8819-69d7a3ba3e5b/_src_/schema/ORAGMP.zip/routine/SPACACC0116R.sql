CREATE PROCEDURE spACacc0116R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0116R
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-10-05
	-- 수 정 자     : 강현호
	-- E-Mail       : roykang0722@gmail.com
	-- 수정일자      : 2016-12-20
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 계정별원장을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------
	-- spACacc0116R 'S','100','%','2011-01-01','2011-04-30','11108010','11108010','1', '','','','N'
(
    p_div			IN	   VARCHAR2 DEFAULT '',
    p_compcode		IN	   VARCHAR2 DEFAULT '',
    p_plantcode 	IN	   VARCHAR2 DEFAULT '',
    p_strdate		IN	   VARCHAR2 DEFAULT '',
    p_enddate		IN	   VARCHAR2 DEFAULT '',
    p_stracccode	IN	   VARCHAR2 DEFAULT '',
    p_endacccode	IN	   VARCHAR2 DEFAULT '',
    p_outputdiv 	IN	   VARCHAR2 DEFAULT '',
    p_downview		IN	   VARCHAR2 DEFAULT '',
    p_userid		IN	   VARCHAR2 DEFAULT '',
    p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
    p_reasontext	IN	   VARCHAR2 DEFAULT '',

    MESSAGE         OUT    VARCHAR2,
    IO_CURSOR       OUT    TYPES.DataSet
)
AS
	p_cashcode	 VARCHAR2(20);
	p_colview	 VARCHAR2(1);

    p_odiv1      VARCHAR2(5);
    p_odiv2      VARCHAR2(5);
    p_ii         NUMBER := 1;
    p_max        NUMBER;
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    p_cashcode := '11101010';

    FOR  rec IN (   SELECT  value1
                    FROM    SYSPARAMETERMANAGE
                    WHERE   parametercode = 'acccashcode' )
    LOOP
        p_cashcode := rec.value1;
    END LOOP;

    p_colview := '_';

    FOR  rec IN (   SELECT  value1
                    FROM    SYSPARAMETERMANAGE
                    WHERE   upper(parametercode) = 'ACCLDGCOLVIEW' )
    LOOP
        p_colview := rec.value1;
    END LOOP;

	IF(p_colview = '_') THEN
    	p_colview := '0';
    END IF;

    IF ( UPPER(p_div) = UPPER('S') ) THEN

        IF ( p_outputdiv = '1' ) THEN
            --K-GAAP
            p_odiv1 := '20';
            p_odiv2 := 'F';
        ELSIF ( p_outputdiv = '2' ) THEN
            --IFRS
            p_odiv1 := '30';
            p_odiv2 := 'K';
        END IF;

		DELETE FROM VGT.TT_ACACC0116R_ACACCM;

        INSERT INTO VGT.TT_ACACC0116R_ACACCM
            (SELECT A.acccode,
                    A.accname,
                    A.dcdiv,
                    COALESCE(c.acccode, b.acccode, A.acccode) downcode
             FROM	ACACCM A
                    LEFT JOIN ACACCM b
                        ON (A.acccode = b.acccode
                            OR A.acccode = b.hacccode)
                           AND p_downview = 'Y'
                    LEFT JOIN ACACCM c
                        ON A.acccode <> b.acccode
                           AND b.acccode = c.hacccode
                           AND p_downview = 'Y'
             WHERE	A.acccode BETWEEN NVL(p_stracccode, ' ') AND NVL(NULLIF(p_endacccode, NULL), 'zzzzzzzz'));

        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0116R_ACORDD';

        INSERT INTO VGT.TT_ACACC0116R_ACORDD

            SELECT  A.acccode ,
                    grp ,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN slipinno
                             ELSE ''
                        END)  slipinno ,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN slipinseq
                             ELSE NULL
                        END)  slipinseq  ,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN slipindate
                             ELSE ''
                        END)  slipindate  ,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN slipinnum
                             ELSE ''
                        END)  slipinnum  ,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN slipno
                             ELSE ''
                        END)  slipno  ,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN slipdate
                             ELSE SUBSTR(slipdate, 0, 7)
                        END)  slipdate	,
                    MAX(CASE WHEN grp = 0 AND slipdate < p_strdate THEN '이월'
                             WHEN grp = 0 AND slipdate >= p_strdate THEN slipnum
                             WHEN grp = 1 THEN '월계' ELSE '누계'
                        END)  slipnum  ,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN A.remark
                             ELSE ''
                        END)  remark  ,
                    SUM(debamt)  debamt  ,
                    SUM(creamt)  creamt  ,
                    SUM(CASE WHEN NVL(c.dcdiv, '1') = '1' THEN debamt - creamt
                             ELSE creamt - debamt
                        END)  fnamt  ,
                    ROW_NUMBER() OVER ( PARTITION BY A.acccode ORDER BY CASE WHEN grp = 0 AND slipdate < p_strdate THEN SUBSTR(slipdate, 0, 7)
                                                                             WHEN grp = 0 AND slipdate >= p_strdate THEN slipdate
                                                                             ELSE SUBSTR(slipdate, 0, 7) || '-99'
                                                                         END, grp ,
                                                                         CASE WHEN grp = 0 AND slipdate < p_strdate THEN '이월'
                                                                              WHEN grp = 0 AND slipdate >= p_strdate THEN REPLACE(slipnum, 'C', p_colview)
                                                                              WHEN grp = 1 THEN '월계'
                                                                              ELSE '누계'
                                                                         END,
                                                                         CASE WHEN grp = 0 AND slipdate < p_strdate THEN 0
                                                                              WHEN grp = 0 AND slipdate >= p_strdate THEN slipinseq
                                                                              WHEN grp = 1 THEN 8888
                                                                              ELSE 9999
                                                                         END  ) ord
            FROM    (   SELECT  '' slipinno  ,
                                0 slipinseq  ,
                                '' slipindate  ,
                                '' slipinnum  ,
                                '' slipno  ,
                                A.slipym || '-00' slipdate  ,
                                '' slipnum  ,
                                b.acccode ,
                                '' remark  ,
                                NVL(A.bsdebamt, 0) debamt  ,
                                NVL(A.bscreamt, 0) creamt
                        FROM    ACORDDMM A
                                JOIN    VGT.TT_ACACC0116R_ACACCM b   ON A.acccode = b.downcode

                        WHERE   A.compcode = p_compcode
                                AND A.plantcode LIKE p_plantcode
                                AND A.slipym = SUBSTR(p_strdate, 0, 7)
                                AND ( A.closediv = '10' OR closediv = p_odiv1 )
                        UNION ALL
                        SELECT  A.slipinno ,
                                A.slipinseq ,
                                b.slipindate ,
                                b.slipinnum ,
                                b.slipno ,
                                A.slipdate ,
                                A.slipnum ,
                                c.acccode ,
                                A.remark1 remark  ,
                                NVL(A.debamt, 0) debamt  ,
                                NVL(A.creamt, 0) creamt
                        FROM    ACORDD A
                                JOIN ACORDM b   ON A.slipinno = b.slipinno AND b.slipdiv <> p_odiv2
                                JOIN    VGT.TT_ACACC0116R_ACACCM c   ON A.acccode = c.downcode
                        WHERE   A.compcode = p_compcode
                                AND A.plantcode LIKE p_plantcode
                                AND A.slipdate BETWEEN SUBSTR(p_strdate, 0, 8) || '01' AND p_enddate
                        UNION ALL
                        SELECT  A.slipinno ,
                                A.slipinseq ,
                                b.slipindate ,
                                b.slipinnum ,
                                b.slipno ,
                                A.slipdate ,
                                A.slipnum ,
                                p_cashcode ,
                                A.remark1 remark  ,
                                NVL(A.creamt, 0) debamt  ,
                                NVL(A.debamt, 0) creamt
                        FROM    ACORDD A
                                JOIN ACORDM b   ON A.slipinno = b.slipinno AND b.slipdiv <> p_odiv2
                                JOIN    VGT.TT_ACACC0116R_ACACCM c   ON c.downcode = p_cashcode
                        WHERE   A.compcode = p_compcode
                                AND A.plantcode LIKE p_plantcode
                                AND A.slipdate BETWEEN SUBSTR(p_strdate, 0, 8) || '01' AND p_enddate
                                AND A.dcdiv IN ( '3','4' )
                                AND p_cashcode BETWEEN NVL(p_stracccode, ' ') AND NVL(NULLIF(p_endacccode, NULL), 'zzzzzzzz') ) A
            JOIN (  SELECT  0 grp FROM DUAL
                    UNION
                    SELECT  1 FROM DUAL
                    UNION
                    SELECT  2 FROM DUAL  ) b  ON b.grp = 0 OR A.slipdate >= p_strdate
            JOIN ACACCM c   ON A.acccode = c.acccode
            GROUP BY    A.acccode ,
                        grp ,
                        (CASE WHEN grp = 0 AND slipdate < p_strdate THEN SUBSTR(slipdate, 0, 7)
                                WHEN grp = 0 AND slipdate >= p_strdate THEN slipdate
                                ELSE SUBSTR(slipdate, 0, 7) || '-99'
                        END ,
                        CASE WHEN grp = 0 AND slipdate < p_strdate THEN '이월'
                             WHEN grp = 0 AND slipdate >= p_strdate THEN REPLACE(slipnum, 'C', p_colview)
                             WHEN grp = 1 THEN '월계'
                             ELSE '누계'
                        END ,
                        CASE WHEN grp = 0 AND slipdate < p_strdate THEN 0
                             WHEN grp = 0 AND slipdate >= p_strdate THEN slipinseq
                             WHEN grp = 1 THEN 8888
                             ELSE 9999
                        END)
            ORDER BY acccode, slipdate, grp, DECODE (SUBSTR(slipnum,0,1),'C','1','A','2','9') ;

        FOR  rec IN (    SELECT MAX(ord) AS alias1
                        FROM VGT.TT_ACACC0116R_ACORDD )
        LOOP
            p_max := rec.alias1;
        END LOOP;


        WHILE p_ii <= p_max LOOP

            MERGE INTO VGT.TT_ACACC0116R_ACORDD A
            USING     (SELECT a.SLIPINNUM,
                               a.SLIPNUM,
                               a.ACCCODE,
                               a.SLIPINNO,
                               a.SLIPNO,
                               a.REMARK,
                               a.SLIPINDATE,
                               a.SLIPDATE,
                               a.GRP,
                               a.SLIPINSEQ,
                               a.DEBAMT,
                               a.CREAMT,
                               a.ORD,
                               b.fnamt + CASE WHEN a.grp = 0 THEN a.fnamt ELSE 0 END fnamt
                        FROM   VGT.TT_ACACC0116R_ACORDD a
                               JOIN VGT.TT_ACACC0116R_ACORDD b
                                   ON a.acccode = b.acccode
                                      AND a.ord - 1 = b.ord
                        WHERE  a.ord = p_ii) SRC
            ON       (NVL(a.slipinnum, ' ') = NVL(src.slipinnum, ' ')
                        AND NVL(a.slipnum, ' ') = NVL(src.slipnum, ' ')
                        AND NVL(a.acccode, ' ') = NVL(src.acccode, ' ')
                        AND NVL(a.slipinno, ' ') = NVL(src.slipinno, ' ')
                        AND NVL(a.slipno, ' ') = NVL(src.slipno, ' ')
                        AND NVL(a.remark, ' ') = NVL(src.remark, ' ')
                        AND NVL(a.slipindate, ' ') = NVL(src.slipindate, ' ')
                        AND NVL(a.slipdate, ' ') = NVL(src.slipdate, ' ')
                        AND NVL(a.grp, 0) = NVL(src.grp, 0)
                        AND NVL(a.slipinseq, 0) = NVL(src.slipinseq, 0)
                        AND NVL(a.debamt, 0) = NVL(src.debamt, 0)
                        AND NVL(a.creamt, 0) = NVL(src.creamt, 0)
                        AND NVL(a.ord, 0) = NVL(src.ord, 0))
            WHEN MATCHED THEN
                UPDATE SET A.fnamt = SRC.fnamt;

            p_ii := p_ii + 1;

        END LOOP;

        UPDATE  VGT.TT_ACACC0116R_ACORDD A
        SET     A.fnamt = NULL
        WHERE   A.grp = 1;



        MERGE INTO VGT.TT_ACACC0116R_ACORDD A
        USING (
                SELECT  b.debamt
                        , b.creamt
                        , A.ord
                        , A.acccode
                FROM    VGT.TT_ACACC0116R_ACORDD A
                        JOIN (  SELECT  A.acccode ,
                                        A.ord ,
                                        SUM(b.debamt)  debamt  ,
                                        SUM(b.creamt)  creamt
                                FROM    VGT.TT_ACACC0116R_ACORDD A
                                        JOIN VGT.TT_ACACC0116R_ACORDD b  ON A.acccode = b.acccode
                                                                            AND A.ord >= b.ord
                                                                            AND ( b.grp = 0 AND NVL(TRIM(b.slipinno), '') IS NULL OR b.grp = 1 )
                WHERE   A.grp = 2
                GROUP BY A.acccode, A.ord ) b   ON A.acccode = b.acccode
                                                    AND A.ord = b.ord
        ) b ON ( A.ord = b.ord AND A.acccode = b.acccode )
        WHEN MATCHED THEN UPDATE SET    A.debamt = b.debamt
                                        , A.creamt = b.creamt;



        OPEN  IO_CURSOR FOR

            SELECT  A.slipinno ,
                    A.slipinseq ,
                    A.slipindate ,
                    A.slipinnum ,
                    A.slipno ,
                    A.slipdate ,
                    A.slipnum ,
                    A.acccode ,
                    b.accname ,
                    A.remark ,
                    A.debamt ,
                    A.creamt ,
                    A.fnamt ,
                    A.acccode || ' : ' || b.accname acccodename
            FROM    VGT.TT_ACACC0116R_ACORDD A
                    LEFT JOIN ACACCM b   ON A.acccode = b.acccode
            ORDER BY A.acccode, A.ord;

    ELSIF ( p_div = 'P' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  A.acccode ,
                    A.accname
            FROM    ACACCM A
                    JOIN (  SELECT  MAX(A.acccode)  acccode
                            FROM    ACACCM A
                                    LEFT JOIN ACACCM b  ON A.acccode = b.hacccode
                                                           AND b.orduseyn = 'Y'
                            WHERE   A.acccode < p_stracccode
                                    AND ( p_downview = 'N'
                                    AND A.orduseyn = 'Y' OR p_downview = 'Y'
                                    AND SUBSTR(A.acccode, -5, 5) <> '00000'
                                    AND ( A.orduseyn = 'Y' OR b.orduseyn = 'Y' ) ) ) b  ON A.acccode = b.acccode;

    ELSIF ( p_div = 'N' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  A.acccode ,
                    A.accname
            FROM    ACACCM A
                    JOIN (  SELECT  MIN(A.acccode)  acccode
                            FROM    ACACCM A
                                    LEFT JOIN ACACCM b   ON A.acccode = b.hacccode
                                                            AND b.orduseyn = 'Y'
                            WHERE   A.acccode > p_stracccode
                                    AND ( p_downview = 'N'
                                          AND A.orduseyn = 'Y' OR p_downview = 'Y'
                                          AND SUBSTR(A.acccode, -5, 5) <> '00000'
                                          AND ( A.orduseyn = 'Y' OR b.orduseyn = 'Y' ) ) ) b   ON A.acccode = b.acccode;

   END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
