CREATE PROCEDURE        spACass0030P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACass0030P
 -- 작 성 자         : 이영재
 -- 작성일자         : 2011-03-08
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-27
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 자산변경등록을 등록,수정,삭제,조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div               IN VARCHAR2 DEFAULT '' ,
    p_asscodeS          IN VARCHAR2 DEFAULT '' ,
    p_assdivS           IN VARCHAR2 DEFAULT '' ,
    p_assclsS           IN VARCHAR2 DEFAULT '' ,
    p_plantcodeS        IN VARCHAR2 DEFAULT '' ,
    p_assstateS         IN VARCHAR2 DEFAULT '' ,
    p_compcode          IN VARCHAR2 DEFAULT '' ,
    p_asscode           IN VARCHAR2 DEFAULT '' ,
    p_closediv          IN VARCHAR2 DEFAULT '' ,--결산구분
    p_chgdate           IN VARCHAR2 DEFAULT '' ,--변경일자
    p_seq               IN NUMBER   DEFAULT 0 ,
    p_asschgdiv         IN VARCHAR2 DEFAULT '' ,--자산변경구분
    p_custcode          IN VARCHAR2 DEFAULT '' ,--거래처코드
    p_deptcode          IN VARCHAR2 DEFAULT '' ,--부서코드
    p_empcode           IN VARCHAR2 DEFAULT '' ,
    p_deprdiv           IN VARCHAR2 DEFAULT '' ,
    p_acccode           IN VARCHAR2 DEFAULT '' ,
    p_curassqty         IN FLOAT    DEFAULT 0 ,
    p_keeprmk           IN VARCHAR2 DEFAULT '' ,
    p_gucurassamt       IN FLOAT    DEFAULT 0 ,
    p_curassamt         IN FLOAT    DEFAULT 0 ,
    p_rejudvaryqty      IN FLOAT    DEFAULT 0 ,
    p_rejudvaryamt      IN FLOAT    DEFAULT 0 ,
    p_decslipinno       IN VARCHAR2 DEFAULT '' ,
    p_deprate           IN FLOAT    DEFAULT 0 ,
    p_salepro           IN FLOAT    DEFAULT 0 ,
    p_drpamt            IN FLOAT    DEFAULT 0 ,
    p_saleamt           IN FLOAT    DEFAULT 0 ,
    p_lifeyear          IN NUMBER   DEFAULT 0 ,
    p_runlifeyear       IN NUMBER   DEFAULT 0 ,
    p_iempcode          IN VARCHAR2 DEFAULT '' ,
    p_userid            IN VARCHAR2 DEFAULT '' ,
    p_reasondiv         IN VARCHAR2 DEFAULT '' ,
    p_reasontext        IN VARCHAR2 DEFAULT '' ,
    MESSAGE             OUT VARCHAR2,
    IO_CURSOR           OUT TYPES.DataSet
)
AS
    p_assym     VARCHAR2(7);
    p_iseq      NUMBER := 0;
    v_temp      NUMBER := 0;
    ip_compcode VARCHAR2(3) := p_compcode;

BEGIN

    MESSAGE := '데이터 확인' ;


    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    FOR  rec IN (   SELECT  compcode -- 법인코드 확인
                    FROM    CMPLANTM
                    WHERE   plantcode LIKE '%' AND ROWNUM <= 1
    )
    LOOP
        ip_compcode := rec.compcode ;
    END LOOP;


    IF ( UPPER(p_div) = UPPER('SM') ) THEN --자산마스터 조회

        OPEN  IO_CURSOR FOR

            SELECT  NVL(a.compcode, '') compcode  ,
                    NVL(trim(a.asscode), '') asscode  ,
                    NVL(a.assname, '') assname  ,
                    NVL(a.assdiv, '') assdiv  ,
                    NVL(a.asscls, '') asscls  ,
                    NVL(a.strdate, '') strdate  ,
                    NVL(a.lifeyear, 0) lifeyear  ,
                    NVL(a.plantcode, '') plantcode  ,
                    NVL(a.mngdeptcode, '') mngdeptcode  ,
                    NVL(a.acccode, '') acccode  ,
                    NVL(a.keeprmk, '') keeprmk  ,
                    NVL(a.masscode, '') masscode  ,
                    NVL(a.acqdiv, '') acqdiv  ,
                    NVL(a.depryn, '') depryn  ,
                    NVL(a.deprdiv, '') deprdiv  ,
                    NVL(a.remark, '') remark  ,
                    NVL(a.deprendyn, '') deprendyn  ,
                    NVL(a.assstate, '') assstate  ,
                    NVL(a.curassqty, 0) curassqty  ,
                    NVL(a.curassamt, 0) curassamt  ,
                    NVL(a.lstassamt, 0) lstassamt  ,
                    NVL(a.subsidyn, '') subsidyn  ,
                    NVL(a.subsidrmk, '') subsidrmk  ,
                    NVL(a.subsidassamt, 0) subsidassamt  ,
                    NVL(E.deptname, '') mngdeptname  ,
                    NVL(f.accname, '') accname  ,
                    NVL(M.equipmentkorname, '') massname  ,
                    NVL(P.plantname, '') plantname  ,
                    NVL(ac76.divname, '') assstatename  ,
                    NVL(ac71.divname, '') assclsname  ,
                    NVL(ac70.divname, '') assdivname  ,NVL(ac74.divname, '') deprdivname  ,
                    NVL(a.deprate, 0) deprrate
            FROM    ACASSM a
                    LEFT JOIN CMDEPTM E        ON a.mngdeptcode = E.deptcode
                    LEFT JOIN ACACCM f         ON a.acccode = f.acccode
                    LEFT JOIN PDEQUIPMENTM M   ON M.equipmentcode = a.masscode
                    LEFT JOIN CMPLANTM P       ON P.plantcode = a.plantcode
                    LEFT JOIN CMCOMMONM ac76   ON ac76.cmmcode = 'AC76'
                                                  AND ac76.divcode = a.assstate
                    LEFT JOIN CMCOMMONM ac71   ON ac71.cmmcode = 'AC71' --자산분류
                                                  AND ac71.divcode = a.asscls
                    LEFT JOIN CMCOMMONM ac70   ON ac70.cmmcode = 'AC70' --자산형태
                                                  AND ac70.divcode = a.assdiv
                    LEFT JOIN CMCOMMONM ac74   ON ac74.cmmcode = 'AC74' --자산상각방법
                                                  AND ac74.divcode = a.deprdiv
            WHERE   a.compcode = ip_compcode
                    AND nvl(a.asscode,' ')   LIKE p_asscodeS   || '%'
                    AND nvl(a.asscls, ' ')    LIKE p_assclsS    || '%'
                    AND nvl(a.assdiv, ' ')    LIKE p_assdivS    || '%'
                    AND nvl(a.assstate, ' ')  LIKE p_assstateS  || '%'
                    AND nvl(a.plantcode, ' ') LIKE p_plantcodeS || '%'
            ORDER BY a.asscode  NULLS first ;

    ELSIF ( UPPER(p_div) = UPPER('S1') ) THEN --자산변경내역 조회

        OPEN  IO_CURSOR FOR

            SELECT  a.asscode asscode  ,
                    NVL(a.closediv, '') closediv  ,
                    NVL(ac02.divname, '') closedivname  ,
                    NVL(a.chgdate, '') chgdate  ,
                    NVL(a.seq, 0) seq  ,
                    NVL(a.asschgdiv, '') asschgdiv  ,
                    NVL(ac77.divname, '') asschgdivname  ,
                    NVL(a.keeprmk, '') keeprmk  ,
                    NVL(a.custcode, '') custcode  ,
                    NVL(c.custname, '') custname  ,
                    NVL(a.deptcode, '') deptcode  ,
                    NVL(D.deptname, '') deptname  ,
                    NVL(a.deprdiv, '') deprdiv  ,
                    NVL(ac74.divname, '') deprname ,--상각방법
                    NVL(a.curassqty, 0) rejudvaryqty ,-- 구해야 함
                    NVL(a.curassamt, 0) rejudvaryamt  ,
                    NVL(a.decslipinno, '') decslipinno  ,
                    NVL(a.lifeyear, 0) lifeyear  ,
                    NVL(a.curassqty, 0) + NVL(chgqty, 0) * CASE WHEN a.asschgdiv IN ( '03','04' ) THEN 1 ELSE -1 END gucurassqty  ,
                    NVL(a.curassamt, 0) + NVL(chgamt, 0) * CASE WHEN a.asschgdiv IN ( '03','04' ) THEN 1 ELSE -1 END gucurassamt  ,
                    NVL(chgqty, 0) curassqty  ,
                    NVL(chgamt, 0) curassamt  ,
                    NVL(saleamt, 0) saleamt  ,
                    NVL(salepro, 0) salepro  ,
                    NVL(drpamt, 0) drpamt  ,
                    NVL(deprate, 0) deprate  ,
                    NVL(keeprmk, 0) keeprmk
            FROM    ACASSD a
                    LEFT JOIN CMCOMMONM ac02   ON ac02.cmmcode = 'AC02'
                                                  AND ac02.divcode = a.closediv
                    LEFT JOIN CMCOMMONM ac77   ON ac77.cmmcode = 'AC77'
                                                  AND ac77.divcode = a.asschgdiv
                    LEFT JOIN CMCOMMONM ac74   ON ac74.cmmcode = 'AC74'
                                                  AND ac74.divcode = a.deprdiv
                    LEFT JOIN CMCUSTM c        ON c.custcode = a.custcode
                    LEFT JOIN CMDEPTM D        ON D.deptcode = a.deptcode
            WHERE   a.compcode = ip_compcode
                    AND nvl(a.asscode,' ') = p_asscode
                    AND nvl(a.closediv, ' ') LIKE p_closediv || '%'
                    AND nvl(a.asschgdiv, ' ') LIKE p_asschgdiv || '%'
            ORDER BY asscode NULLS first   ;


    ELSIF ( UPPER(p_div) = UPPER('SC') ) THEN

        FOR  rec IN (   SELECT  COUNT(asscode)   AS alias1
                        FROM    ACASSD
                        WHERE   compcode = ip_compcode
                                AND asscode = p_asscode
                                AND closediv = p_closediv
                                AND chgdate = p_chgdate
                                AND seq = p_seq
        )
        LOOP
            MESSAGE := rec.alias1 ;
        END LOOP;

    ELSIF ( UPPER(p_div) = UPPER('I') ) THEN

        p_iseq := 0 ;

        FOR  rec IN (   SELECT  NVL(MAX(seq) , 0) + 1 AS alias1 --신규번호
                        FROM    ACASSD
                        WHERE   compcode = ip_compcode
                                AND asscode = p_asscode
                                AND closediv = p_closediv
                                AND chgdate = p_chgdate
                    )
        LOOP
            p_iseq := rec.alias1 ;
        END LOOP;

        INSERT INTO ACASSD(
            compcode,
            closediv,
            asscode,
            chgdate,
            seq,
            asschgdiv,
            deprdiv,
            lifeyear,
            deprate,
            curassqty,
            curassamt,
            chgqty,
            chgamt,
            saleamt,
            salepro,
            drpamt,
            custcode,
            deptcode,
            keeprmk,
            decslipinno,
            insertdt,
            iempcode )
        VALUES (
            ip_compcode,
            p_closediv,
            p_asscode,
            p_chgdate,
            p_iseq,
            p_asschgdiv,
            p_deprdiv,
            p_lifeyear,
            p_deprate,
            p_rejudvaryqty,
            p_rejudvaryamt,
            p_curassqty,
            p_curassamt,
            p_saleamt,
            p_salepro,
            p_drpamt,
            p_custcode,
            p_deptcode,
            p_keeprmk,
            p_decslipinno,
            SYSDATE,
            p_iempcode );


        IF UPPER(p_asschgdiv) = UPPER('03') OR UPPER(p_asschgdiv) = UPPER('04') THEN

            --폐기또는 매각이면
            UPDATE  ACASSM a
            SET     a.assstate = CASE WHEN p_asschgdiv = '03' THEN '2'
                                      WHEN p_asschgdiv = '04' THEN '3'
                                      ELSE '3'
                                 END,
                    a.enddate = p_chgdate
            WHERE   compcode = ip_compcode
                    AND asscode = p_asscode;

        END IF;


    ELSIF ( UPPER(p_div) = UPPER('U') ) THEN

        UPDATE  ACASSD
        SET     compcode = ip_compcode,
                closediv = p_closediv,
                asscode = p_asscode,
                chgdate = p_chgdate,
                seq = p_seq,
                asschgdiv = p_asschgdiv,
                deprdiv = p_deprdiv,
                lifeyear = p_lifeyear,
                deprate = p_deprate,
                curassqty = p_rejudvaryqty,
                curassamt = p_rejudvaryamt,
                chgqty = p_curassqty,
                chgamt = p_curassamt,
                saleamt = p_saleamt,
                salepro = p_salepro,
                drpamt = p_drpamt,
                custcode = p_custcode,
                deptcode = p_deptcode,
                keeprmk = p_keeprmk,
                decslipinno = p_decslipinno,
                updatedt = SYSDATE,
                uempcode = p_iempcode
        WHERE   compcode = ip_compcode
                AND asscode = p_asscode
                AND closediv = p_closediv
                AND chgdate = p_chgdate
                AND seq = p_seq;

        IF UPPER(p_asschgdiv) = UPPER('03') OR UPPER(p_asschgdiv) = UPPER('04') THEN

            --폐기또는 매각이면
            UPDATE  ACASSM a
            SET     a.assstate = CASE WHEN p_asschgdiv = '03' THEN '2'
                                      WHEN p_asschgdiv = '04' THEN '3'
                                      ELSE '3'
                                 END,
                    a.enddate = p_chgdate
            WHERE   compcode = ip_compcode
                    AND asscode = p_asscode ;

        END IF;


    ELSIF ( UPPER(p_div) = UPPER('D') ) THEN

        FOR rec IN (
            SELECT  COUNT(*) AS alias1
            FROM    DUAL
            WHERE EXISTS (  SELECT  *
                            FROM    ACASSD
                            WHERE   compcode = ip_compcode
                                    AND asscode = p_asscode
                                    AND closediv = p_closediv
                                    AND chgdate = p_chgdate
                                    AND seq = p_seq
                                    AND asschgdiv IN ( '03','04' )  )
        )
        LOOP
            v_temp := rec.alias1 ;
        END LOOP;


        IF v_temp = 1 THEN

            UPDATE  ACASSM a
            SET     a.assstate = '1',
                    a.enddate = '2300-12-31'
            WHERE   compcode = ip_compcode
                    AND asscode = p_asscode;

        END IF;


        DELETE  ACASSD
        WHERE   compcode = ip_compcode
                AND asscode = p_asscode
                AND closediv = p_closediv
                AND chgdate = p_chgdate
                AND seq = p_seq;

    ELSIF ( UPPER(p_div) = UPPER('SCHD') ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  a.asscode asscode  ,
                    a.strdate strdate ,                 --구매일자
                    a.curassamt curassamt1 ,            --구매금액
                    a.lifeyear lifeyear1  ,
                    NVL(b.chgdate, '') chgdate  ,
                    NVL(b.seq, 0) seq  ,
                    NVL(b.custcode, '') custcode  ,
                    NVL(b.deptcode, '') deptcode  ,
                    NVL(b.deprdiv, '') deprdiv ,       --감가상각구분
                    NVL(b.curassamt, 0) curassamt2 ,    --변경금액
                    NVL(b.lifeyear, '') lifeyear2
            FROM    ACASSM a
                    LEFT JOIN ACASSD b ON b.compcode = a.compcode
                                          AND b.closediv = p_closediv
                                          AND b.chgdate <= p_chgdate
                                          AND b.asscode = a.asscode
                                          AND b.asschgdiv = p_asschgdiv --변경구분
            WHERE   a.compcode = ip_compcode
                    AND a.asscode = p_asscode
            ORDER BY a.asscode, b.chgdate DESC, b.seq DESC ;


    ELSIF ( UPPER(p_div) = UPPER('amt') ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  a.curassqty ,
                    a.curassamt ,
                    a.deprdiv ,
                    a.lifeyear ,
                    a.deprate ,
                    a.deptcode
            FROM    ACASSD a
                    JOIN (  SELECT  a.compcode ,
                                    a.closediv ,
                                    a.asscode ,
                                    a.chgdate ,
                                    MAX(seq)  seq
                            FROM    ACASSD a
                                    JOIN (  SELECT  compcode ,
                                                    closediv ,
                                                    asscode ,
                                                    MAX(chgdate)  chgdate
                                            FROM    ACASSD
                                            WHERE   compcode = ip_compcode
                                                    AND closediv = p_closediv
                                                    AND asscode = p_asscode
                                                    AND chgdate <= p_chgdate
                                            GROUP BY compcode, closediv, asscode ) b  ON a.compcode = b.compcode
                                                                                         AND a.closediv = b.closediv
                                                                                         AND a.asscode = b.asscode
                                                                                         AND a.chgdate = b.chgdate
                            GROUP BY a.compcode, a.closediv, a.asscode, a.chgdate ) b ON a.compcode = b.compcode
                                                                                         AND a.closediv = b.closediv
                                                                                         AND a.asscode = b.asscode
                                                                                         AND a.chgdate = b.chgdate
                                                                                         AND a.seq = b.seq ;

    ELSIF ( UPPER(p_div) = UPPER('sam') ) THEN

        FOR rec IN (
                        SELECT  COUNT(*) AS alias1
                        FROM    DUAL
                        WHERE NOT EXISTS (  SELECT  *
                                            FROM    ACASSDEPR
                                            WHERE   compcode = ip_compcode
                                                    AND closediv = p_closediv
                                                    AND caldiv = 'CR'
                                                    AND assym = SUBSTR(p_chgdate, 0, 7)
                                                    AND asscode = p_asscode )
        )
        LOOP
            v_temp := rec.alias1 ;
        END LOOP;


        IF v_temp = 1 THEN

            p_assym := SUBSTR(p_chgdate, 0, 7) ;

            spACass0090P(
                                    p_div        => 'SCAL',
                                    p_compcode   => ip_compcode,
                                    p_closediv   => p_closediv,
                                    p_caldiv     => 'CR',
                                    p_assym      => p_assym,
                                    p_asscode    => p_asscode,
                                    p_iempcode   => p_userid,
                                    p_userid     => p_userid,
                                    p_reasondiv  => p_reasondiv,
                                    p_reasontext => p_reasontext,
                                    MESSAGE      => MESSAGE,
                                    IO_CURSOR    => IO_CURSOR
            ) ;

        END IF;


        OPEN  IO_CURSOR FOR

            SELECT  predepamt + depamt fassamt
            FROM    ACASSDEPR
            WHERE   compcode = ip_compcode
                    AND closediv = p_closediv
                    AND caldiv = 'CR'
                    AND assym = SUBSTR(p_chgdate, 0, 7)
                    AND asscode = p_asscode ;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
