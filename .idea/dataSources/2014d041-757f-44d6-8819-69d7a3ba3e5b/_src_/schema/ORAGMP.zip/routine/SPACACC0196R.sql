CREATE PROCEDURE spACacc0196R
-- ---------------------------------------------------------------
-- 프로시저명      : spACacc0194R
-- 작 성 자      : 최용석
-- 작성일자       : 2017-07-14
-- 프로시저 설명    : 채권채무 내역을 조회하는 프로시저이다.
-- ---------------------------------------------------------------
(
    p_div                   IN VARCHAR2 DEFAULT '',

    p_compcode		          IN VARCHAR2 DEFAULT '',
    p_plantcode 	          IN VARCHAR2 DEFAULT '',
    p_slipym  		          IN VARCHAR2 DEFAULT '',
    p_outputdiv		          IN VARCHAR2 DEFAULT '',

    p_userid		            IN VARCHAR2 DEFAULT '',
    p_reasondiv 	          IN VARCHAR2 DEFAULT '',
    p_reasontext	          IN VARCHAR2 DEFAULT '',
    MESSAGE 		            OUT VARCHAR2,
    IO_CURSOR		            OUT TYPES.DataSet
)
AS
    p_odiv1                 VARCHAR2(5);
    p_odiv2	                VARCHAR2(5);
    p_strdate	              VARCHAR2(10);
    p_enddate	              VARCHAR2(10);
BEGIN

  MESSAGE := '데이터 확인';

  execute immediate 'delete from ATINFO';

  insert into ATINFO(userid, reasondiv, reasontext)
  values (p_userid, p_reasondiv, p_reasontext);

  if (p_outputdiv = '1') then
      p_odiv1 := '20';
      p_odiv2 := 'F';
  elsif (p_outputdiv = '2') then
      p_odiv1 := '30';
      p_odiv2 := 'K';
  end if;

  p_strdate := substr(p_slipym,1,4) || '-01-01';
  p_enddate := to_char(last_day(to_date(p_slipym,'yyyy-mm')), 'yyyy-mm-dd');

	if (p_div = 'T') then   -- 계정명칭 조회
      open IO_CURSOR for
      select   max(case when ord =  1 then divname else '' end) as slipamt01
              ,max(case when ord =  2 then divname else '' end) as slipamt02
              ,max(case when ord =  3 then divname else '' end) as slipamt03
              ,max(case when ord =  4 then divname else '' end) as slipamt04
              ,max(case when ord =  5 then divname else '' end) as slipamt05
              ,max(case when ord =  6 then divname else '' end) as slipamt06
              ,max(case when ord =  7 then divname else '' end) as slipamt07
              ,max(case when ord =  8 then divname else '' end) as slipamt08
              ,max(case when ord =  9 then divname else '' end) as slipamt09
              ,max(case when ord = 10 then divname else '' end) as slipamt10
              ,max(case when ord = 11 then divname else '' end) as slipamt11
              ,max(case when ord = 12 then divname else '' end) as slipamt12
              ,max(case when ord = 13 then divname else '' end) as slipamt13
              ,max(case when ord = 14 then divname else '' end) as slipamt14
              ,max(case when ord = 15 then divname else '' end) as slipamt15
              ,max(case when ord = 16 then divname else '' end) as slipamt16
              ,max(case when ord = 17 then divname else '' end) as slipamt17
              ,max(case when ord = 18 then divname else '' end) as slipamt18
              ,max(case when ord = 19 then divname else '' end) as slipamt19
              ,max(case when ord = 20 then divname else '' end) as slipamt20
      from (
          select  divcode, divname, filter1 as dcdiv, row_number() over(order by filter1, divcode) as ord
          from    CMCOMMONM
          where   cmmcode = 'AC263'
                  and hcmmcode is null
                  and usediv = 'Y'
      ) a;

  elsif (p_div = 'S') then   -- 채권채무현황 조회
      open IO_CURSOR for
      select   a.custcode
              ,max(b.custname) as custname
              ,max(b.businessno) as businessno
              ,max(b.post) as post
              ,max(nvl(b.addr1 || ' ','') || nvl(b.addr2,'')) as addr
              ,max(b.telno) as telno
              ,sum(case when a.dcdiv = '1' then a.slipamt else -a.slipamt end) as slipamt
              ,sum(case when a.dcdiv = '1' then a.slipamt else 0 end) as slipamt1
              ,sum(case when a.dcdiv = '2' then a.slipamt else 0 end) as slipamt2
              ,sum(case when a.ord =  1 then a.slipamt else 0 end) as slipamt01
              ,sum(case when a.ord =  2 then a.slipamt else 0 end) as slipamt02
              ,sum(case when a.ord =  3 then a.slipamt else 0 end) as slipamt03
              ,sum(case when a.ord =  4 then a.slipamt else 0 end) as slipamt04
              ,sum(case when a.ord =  5 then a.slipamt else 0 end) as slipamt05
              ,sum(case when a.ord =  6 then a.slipamt else 0 end) as slipamt06
              ,sum(case when a.ord =  7 then a.slipamt else 0 end) as slipamt07
              ,sum(case when a.ord =  8 then a.slipamt else 0 end) as slipamt08
              ,sum(case when a.ord =  9 then a.slipamt else 0 end) as slipamt09
              ,sum(case when a.ord = 10 then a.slipamt else 0 end) as slipamt10
              ,sum(case when a.ord = 11 then a.slipamt else 0 end) as slipamt11
              ,sum(case when a.ord = 12 then a.slipamt else 0 end) as slipamt12
              ,sum(case when a.ord = 13 then a.slipamt else 0 end) as slipamt13
              ,sum(case when a.ord = 14 then a.slipamt else 0 end) as slipamt14
              ,sum(case when a.ord = 15 then a.slipamt else 0 end) as slipamt15
              ,sum(case when a.ord = 16 then a.slipamt else 0 end) as slipamt16
              ,sum(case when a.ord = 17 then a.slipamt else 0 end) as slipamt17
              ,sum(case when a.ord = 18 then a.slipamt else 0 end) as slipamt18
              ,sum(case when a.ord = 19 then a.slipamt else 0 end) as slipamt19
              ,sum(case when a.ord = 20 then a.slipamt else 0 end) as slipamt20
      from (
          select  a.mngcluval as custcode
                  ,c.ord
                  ,c.dcdiv
                  ,case when c.dcdiv = '1' then a.bsdebamt - a.bscreamt else a.bscreamt - a.bsdebamt end as slipamt
          from    ACORDSMM a
                  join (
                      select  hdivcode as divcode, filter1 as acccode
                      from    CMCOMMONM
                      where   cmmcode = 'AC263'
                              and filter1 is not null
                              and usediv = 'Y'
                  ) b on a.acccode like b.acccode || '%'
                  join (
                      select  divcode, divname, filter1 as dcdiv, row_number() over(order by filter1, divcode) as ord
                      from    CMCOMMONM
                      where   cmmcode = 'AC263'
                              and hcmmcode is null
                              and usediv = 'Y'
                  ) c on b.divcode = c.divcode
          where a.compcode = p_compcode
                and a.plantcode like p_plantcode
                and a.slipym = substr(p_strdate,1,7)
                and (a.closediv = '10' or closediv = p_odiv1)
                and a.mngclucode = 'S010'
                and a.bsdebamt <> a.bscreamt

          union all

          select	b.mngcluval as custcode
                  ,e.ord
                  ,e.dcdiv
                  ,case when e.dcdiv = '1' then a.debamt - a.creamt else a.creamt - a.debamt end as slipamt
          from    ACORDD a
                  join ACORDS b
                  on a.compcode = b.compcode
                  and a.slipinno = b.slipinno
                  and a.slipinseq = b.slipinseq
                  and b.mngclucode = 'S010'
                  join (
                      select  hdivcode as divcode, filter1 as acccode
                      from    CMCOMMONM
                      where   cmmcode = 'AC263'
                              and filter1 is not null
                              and usediv = 'Y'
                  ) c on a.acccode like c.acccode || '%'
                  join ACORDM d
                      on a.compcode = d.compcode
                      and a.slipinno = d.slipinno
                      and d.slipdiv <> p_odiv2
                  join (
                      select  divcode, divname, filter1 as dcdiv, row_number() over(order by filter1, divcode) as ord
                      from    CMCOMMONM
                      where   cmmcode = 'AC263'
                              and hcmmcode is null
                              and usediv = 'Y'
                  ) e on c.divcode = e.divcode
          where   a.compcode = p_compcode
                  and a.plantcode like p_plantcode
                  and a.slipdate between substr(p_strdate,1,8) || '01' and p_enddate
      ) a
          left join CMCUSTM b
              on a.custcode = b.custcode
      group by a.custcode
      order by a.custcode;

  end if;

  if (IO_CURSOR is null) then
      open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
  end if;

END;
/
