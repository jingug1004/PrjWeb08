CREATE FUNCTION fnsalwhere_deptlist
/******
작 성 자: 이세민
작성일자: 2014-01-27
설    명: 영업에서 사용하는 부서조회 처리를 위해 사용하는 테이블 반환함수
예    제: select * from dbo.fnsalwhere_deptlist('2000') -- 영업본부 전체에 해당하는 부서 리스트 추출
		  select * from dbo.fnsalwhere_deptlist('221403') --부서가 221403인 부서만 조회됨.
******/

-- 수 정 자     : 강현호
-- E-Mail       : roykang0722@gmail.com
-- 수정일자      : 2017-02-01

(
  p_setvalues IN VARCHAR2 DEFAULT ''
)
RETURN FN_SALWHERE_DEPTLIST_TABLE
AS
    i NUMBER := 1;

    --함수내에서 변수 저장용 변수 초기화
    salWhereDeptListRecode FN_SALWHERE_DEPTLIST_TABLE := FN_SALWHERE_DEPTLIST_TABLE();

BEGIN

    IF ( NVL(TRIM(p_setvalues), '') IS NULL OR p_setvalues = '%' ) THEN

        FOR  rec IN (
            SELECT  DISTINCT deptcode
            FROM    CMDEPTM
            ORDER BY  deptcode
        )
        LOOP
            salWhereDeptListRecode.EXTEND;
            salWhereDeptListRecode(i) := FN_SALWHERE_DEPTLIST_VARIABLE(rec.deptcode);
            i := i+1;
        END LOOP;

    ELSE

        FOR rec IN (    WITH CTEWORDERS AS (
                            SELECT  DEPTCODE
                                    , PREDEPTCODE
                                    , deptname
                                    , 1 Org_Level
                            FROM    CMDEPTM
                            WHERE   ( DEPTCODE LIKE p_setvalues || '%' ) OR ( deptname LIKE '%' || p_setvalues || '%' )

                            UNION ALL

                            SELECT  A.DEPTCODE
                                    , A.PREDEPTCODE
                                    , A.deptname
                                    , b.org_level + 1 org_level
                            FROM    CMDEPTM A
                                    INNER JOIN ( SELECT  DEPTCODE
                                                         , PREDEPTCODE
                                                         , deptname
                                                         , 1 Org_Level
                                                 FROM    CMDEPTM
                                                 WHERE   ( DEPTCODE LIKE p_setvalues || '%' ) OR ( deptname LIKE '%' || p_setvalues || '%' ) ) B   ON A.PREDEPTCODE = B.DEPTCODE
                        ) --WITH END
                        SELECT  DISTINCT    A.deptcode
                        FROM    (   SELECT  deptcode
                                    FROM    CMDEPTM
                                    WHERE   deptcode IN (   SELECT  DEPTCODE
                                                            FROM    CTEWORDERS  ) ) A
        )
        LOOP

            salWhereDeptListRecode.EXTEND;
            salWhereDeptListRecode(i) := FN_SALWHERE_DEPTLIST_VARIABLE(rec.deptcode);
            i := i+1;

        END LOOP ;

   END IF;


    RETURN salWhereDeptListRecode;

END;
/
