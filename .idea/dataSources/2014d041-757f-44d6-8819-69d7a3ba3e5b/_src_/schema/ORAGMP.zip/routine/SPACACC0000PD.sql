CREATE PROCEDURE spACacc0000PD
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0000PD
 -- 작 성 자         : 민승기
 -- 작성일자         : 2010-10-06
 -- 작 성 자         : 임 정호
 -- 작성일자         : 2016-12-13
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 회계전표상세내역 테이블 (ACORDD)을 등록,수정,삭제하는 프로시저이다.
 -- ---------------------------------------------------------------

(
  p_div IN VARCHAR2 DEFAULT '' ,
  p_compcode IN VARCHAR2 DEFAULT '' ,
  p_slipinno IN VARCHAR2 DEFAULT '' ,
  p_slipinseq IN NUMBER DEFAULT 0 ,
  p_dcdiv IN VARCHAR2 DEFAULT '' ,
  p_acccode IN VARCHAR2 DEFAULT '' ,
  p_plantcode IN VARCHAR2 DEFAULT '' ,
  p_debamt IN FLOAT DEFAULT 0 ,
  p_creamt IN FLOAT DEFAULT 0 ,
  p_slipdate IN VARCHAR2 DEFAULT '' ,
  p_slipnum IN VARCHAR2 DEFAULT '' ,
  p_remark1 IN VARCHAR2 DEFAULT '' ,
  p_remark2 IN VARCHAR2 DEFAULT '' ,
  p_taxno IN VARCHAR2 DEFAULT '' ,
  p_datadiv IN VARCHAR2 DEFAULT '' ,
  p_fundcode IN VARCHAR2 DEFAULT '' ,
  p_rptseq IN NUMBER DEFAULT 0 ,
  p_iempcode IN VARCHAR2 DEFAULT '' ,
  p_userid IN VARCHAR2 DEFAULT '' ,
  p_reasondiv IN VARCHAR2 DEFAULT '' ,
  p_reasontext IN VARCHAR2 DEFAULT '' ,
  IO_CURSOR         OUT TYPES.DataSet,
  MESSAGE           OUT VARCHAR2
)
AS
   ip_taxno VARCHAR2(20) := p_taxno;
   p_acccode1 VARCHAR2(20); -- 선급부가세
   p_acccode2 VARCHAR2(20); -- 예수부가세
   p_taxdel VARCHAR2(5);
BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    p_acccode1 := '11135' ;

    FOR  rec IN
    (
        SELECT  filter1
        FROM    CMCOMMONM
        WHERE   cmmcode = 'AC261'
            AND divcode = '11135'
    )
    LOOP
        p_acccode1 := rec.filter1   ;
    END LOOP;

    p_acccode2 := '21050' ;

    FOR  rec IN
    (
        SELECT  filter1
        FROM    CMCOMMONM
        WHERE   cmmcode = 'AC261'
            AND divcode = '21050'
    )
    LOOP
        p_acccode2 := rec.filter1   ;
    END LOOP;

    FOR  rec IN
    (
        SELECT  value1
        FROM    SYSPARAMETERMANAGE
        WHERE   parametercode = 'accsliptaxdel'
    )
    LOOP
        p_taxdel := rec.value1;
    END LOOP;

    IF ( p_div = 'I' ) THEN
        -- 회계전표상세내역 등록
        ip_taxno :=  CASE
                        WHEN  (p_acccode LIKE p_acccode1 || '%' OR p_acccode LIKE p_acccode2 || '%') THEN
                            ip_taxno
                        ELSE
                            ''
                    END ;

        INSERT INTO ACORDD
                            ( compcode,   slipinno,   slipinseq,   dcdiv,   acccode,   plantcode,   debamt,   creamt,   slipdate,   slipnum,   remark1,   remark2,   taxno,   datadiv,   fundcode,   rptseq,   insertdt,  iempcode   )
                VALUES      ( p_compcode ,p_slipinno ,p_slipinseq ,p_dcdiv ,p_acccode ,p_plantcode ,p_debamt ,p_creamt ,p_slipdate ,p_slipnum ,p_remark1 ,p_remark2 ,ip_taxno ,p_datadiv ,p_fundcode ,p_rptseq ,SYSDATE ,  p_iempcode );

    ELSIF ( p_div = 'U' ) THEN
       -- 회계전표상세내역 수정
         UPDATE ACORDD
            SET dcdiv = p_dcdiv,
                acccode = p_acccode,
                plantcode = p_plantcode,
                debamt = p_debamt,
                creamt = p_creamt,
                slipdate = p_slipdate,
                slipnum = p_slipnum,
                remark1 = p_remark1,
                remark2 = p_remark2,
                taxno = ip_taxno,
                datadiv = p_datadiv,
                fundcode = p_fundcode,
                rptseq = p_rptseq,
                updatedt = SYSDATE,
                uempcode = p_iempcode
          WHERE  compcode = p_compcode
           AND slipinno = p_slipinno
           AND slipinseq = p_slipinseq;

        IF p_taxdel = 'Y' THEN

            DELETE FROM  ACTAXD TG
            WHERE ( TG.COMPCODE,TG.PLANTCODE,TG.TAXNO,TG.SEQ ) IN  (
                                                                        SELECT   b.COMPCODE,b.PLANTCODE,b.TAXNO,b.SEQ
                                                                        FROM      ACORDD a
                                                                                 JOIN ACTAXD b
                                                                                    ON      a.compcode = b.compcode
--                                                                                        AND a.plantcode = b.plantcode
                                                                                        AND a.taxno = b.taxno
                                                                        WHERE   a.compcode = p_compcode
                                                                            AND a.slipinno = p_slipinno
                                                                            AND a.slipinseq = p_slipinseq
                                                                            AND a.acccode NOT LIKE p_acccode1 || '%'
                                                                            AND a.acccode NOT LIKE p_acccode2 || '%'
                                                                   );



            DELETE FROM  ACTAXM TG
            WHERE ( TG.COMPCODE,TG.PLANTCODE,TG.TAXNO ) IN  (
                                                                SELECT B.COMPCODE,B.PLANTCODE,B.TAXNO
                                                                  FROM ACORDD a
                                                                         JOIN ACTAXM b   ON a.compcode = b.compcode
--                                                                         AND a.plantcode = b.plantcode
                                                                         AND a.taxno = b.taxno
                                                                 WHERE  a.compcode = p_compcode
                                                                          AND a.slipinno = p_slipinno
                                                                          AND a.slipinseq = p_slipinseq
                                                                          AND a.acccode NOT LIKE p_acccode1 || '%'
                                                                          AND a.acccode NOT LIKE p_acccode2 || '%'
                                                            );

            UPDATE ACORDD
               SET taxno = NULL
             WHERE  compcode = p_compcode
              AND slipinno = p_slipinno
              AND slipinseq = p_slipinseq
              AND acccode NOT LIKE p_acccode1 || '%'
              AND acccode NOT LIKE p_acccode2 || '%';

         END IF;


    ELSIF ( p_div = 'D' ) THEN

        -- 회계전표상세내역 삭제
        IF p_taxdel = 'Y' THEN

            DELETE FROM ACTAXD TG
                WHERE (TG.COMPCODE,TG.PLANTCODE,TG.TAXNO,TG.SEQ) IN (
                                                                        SELECT  B.COMPCODE,B.PLANTCODE,B.TAXNO,B.SEQ
                                                                         FROM   ACORDD a
                                                                                JOIN ACTAXD b
                                                                                    ON      a.compcode = b.compcode
--                                                                                        AND a.plantcode = b.plantcode
                                                                                        AND a.taxno = b.taxno
                                                                        WHERE   a.compcode = p_compcode
                                                                            AND a.slipinno = p_slipinno
                                                                            AND a.slipinseq = p_slipinseq
                                                                    );

            DELETE FROM ACTAXM TG
                WHERE (TG.COMPCODE,TG.PLANTCODE,TG.TAXNO) IN (
                                                                SELECT  B.COMPCODE,B.PLANTCODE,B.TAXNO
                                                                 FROM   ACORDD a
                                                                        JOIN ACTAXM b
                                                                            ON      a.compcode = b.compcode
--                                                                                AND a.plantcode = b.plantcode
                                                                                AND a.taxno = b.taxno
                                                                WHERE  a.compcode = p_compcode
                                                                         AND a.slipinno = p_slipinno
                                                                         AND a.slipinseq = p_slipinseq
                                                             );




        END IF;

        DELETE  ACORDS
        WHERE   compcode = p_compcode
            AND slipinno = p_slipinno
            AND slipinseq = p_slipinseq;


        DELETE  ACORDD
        WHERE   compcode = p_compcode
            AND slipinno = p_slipinno
            AND slipinseq = p_slipinseq;


    ELSIF ( p_div = 'DT' ) THEN
    -- 세금계산서 삭제
        IF p_taxdel = 'Y' THEN

            DELETE FROM ACTAXD TG
            WHERE (TG.COMPCODE,TG.PLANTCODE,TG.TAXNO,TG.SEQ) IN  (
                                                                    SELECT A.COMPCODE,A.PLANTCODE,A.TAXNO,A.SEQ
                                                                    FROM ACTAXD a
                                                                           LEFT JOIN ACORDD b   ON a.compcode = b.compcode
--                                                                           AND a.plantcode = b.plantcode
                                                                           AND a.taxno = b.taxno
                                                                    WHERE  a.compcode = p_compcode
--                                                                            AND a.plantcode = p_plantcode
                                                                            AND a.taxno = ip_taxno
                                                                            AND b.compcode IS NULL
                                                                 );
            DELETE FROM ACTAXM TG
            WHERE (TG.COMPCODE,TG.PLANTCODE,TG.TAXNO) IN    (
                                                                SELECT a.COMPCODE,a.PLANTCODE,a.TAXNO
                                                                FROM    ACTAXM a
                                                                        LEFT JOIN ACORDD b
                                                                            ON      a.compcode = b.compcode
--                                                                                AND a.plantcode = b.plantcode
                                                                                AND a.taxno = b.taxno
                                                               WHERE  a.compcode = p_compcode
--                                                                        AND a.plantcode = p_plantcode
                                                                        AND a.taxno = ip_taxno
                                                                        AND b.compcode IS NULL
                                                            );

        END IF;
      END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
