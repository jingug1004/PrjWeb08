CREATE PROCEDURE        spACbudg0050P
  -- ---------------------------------------------------------------
  -- 프로시저명       : spACbudg0050P
  -- 작 성 자         : 박유진
  -- 작성일자         : 2017-08-11
  -- ---------------------------------------------------------------
  -- 프로시저 설명    : 부서별 예산계획을 설정하는 프로시저이다.
  -- ---------------------------------------------------------------
(
    p_div           IN     VARCHAR2 DEFAULT '',

    p_compcode      IN  VARCHAR2 DEFAULT '',
    p_plantcode     IN  VARCHAR2 DEFAULT '',
    p_deptcode      IN  VARCHAR2 DEFAULT '',
    p_budgdate      IN  VARCHAR2 DEFAULT '',
    p_abstract      IN  VARCHAR2 DEFAULT '',
    p_budgamt       IN  FLOAT    DEFAULT '0',
    p_iempcode      IN  VARCHAR2 DEFAULT '',
    p_deptseq       IN  NUMBER   DEFAULT '0',
    p_budgym        IN  VARCHAR2 DEFAULT '',
    p_remark        IN  VARCHAR2 DEFAULT '',

    p_userid        IN  VARCHAR2 DEFAULT '',
    p_reasondiv     IN  VARCHAR2 DEFAULT '',
    p_reasontext    IN  VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
BEGIN

    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values(p_userid, p_reasondiv, p_reasontext);

    if p_div = 'S' then
        open IO_CURSOR for
        select  a.budgdate,       -- 계획금액
                a.deptcode,       -- 부서코드
                b.deptname,       -- 부서명
                a.abstract,       -- 적요
                a.deptseq,        -- 순번
                a.budgamt,        -- 계획금액
                a.remark          -- 비고

        from    ACBUDGDEPTM a
                join CMDEPTM b
                    on a.deptcode = b.deptcode

        where   a.compcode = p_compcode
                and a.plantcode like p_plantcode
                and substr(a.budgdate, 1, 7) = p_budgym
                and a.deptcode like p_deptcode || '%'

        order by a.budgdate, a.deptcode, a.deptseq;

    elsif p_div = 'SC' then
        open IO_CURSOR for
        select  distinct fixyn

        from    ACBUDGDEPTM

        where   compcode = p_compcode
                and plantcode like p_plantcode
                and substr(budgdate, 1, 7) = p_budgym;

    elsif p_div = 'I' then
        insert into ACBUDGDEPTM
            (
                compcode,
                plantcode,
                budgdate,
                deptcode,
                deptseq,
                abstract,
                budgamt,
                remark,
                fixyn,
                insertdt,
                iempcode
            )
        values
            (
                p_compcode,
                p_plantcode,
                p_budgdate,
                p_deptcode,
                ACBUDGDEPTM_seq.nextval,
                p_abstract,
                p_budgamt,
                p_remark,
                'N',
                sysdate,
                p_iempcode
            );

    elsif p_div = 'U' then
        update  ACBUDGDEPTM
        set     abstract = p_abstract,
                budgamt = p_budgamt,
                remark = p_remark,
                updatedt = sysdate,
                uempcode = p_iempcode

        where   compcode = p_compcode
                and plantcode = p_plantcode
                and budgdate = p_budgdate
                and deptcode = p_deptcode
                and deptseq = p_deptseq;

    elsif p_div = 'D' then
        delete
        from    ACBUDGDEPTM
        where   compcode = p_compcode
                and plantcode = p_plantcode
                and budgdate = p_budgdate
                and deptcode = p_deptcode
                and deptseq = p_deptseq;

    elsif p_div = 'UF' then
        update  ACBUDGDEPTM
        set     fixyn = case when fixyn = 'N' then 'Y' else 'N' end

        where   compcode = p_compcode
                and plantcode = p_plantcode
                and budgdate like p_budgym || '%';

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;
END;
/
