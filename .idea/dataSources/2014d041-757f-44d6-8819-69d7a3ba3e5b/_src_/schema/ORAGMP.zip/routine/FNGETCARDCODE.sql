CREATE FUNCTION fnGetCardCode(p_cardcomp IN VARCHAR2 DEFAULT '')
	RETURN VARCHAR2
AS
	p_cardcode	 VARCHAR2(20) := '';
BEGIN
	FOR rec IN (SELECT divcode
				FROM   CMCOMMONM
				WHERE  cmmcode = 'AC17'
					   AND p_cardcomp LIKE '%' || divname || '%'
					   AND usediv = 'Y')
	LOOP
		p_cardcode := rec.divcode;
	END LOOP;

	IF NVL(p_cardcode, '') IS NULL THEN
		p_cardcode :=
			CASE
				WHEN p_cardcomp LIKE '%비씨%' THEN '070'
				WHEN p_cardcomp LIKE '%기업%' THEN '070'
				WHEN p_cardcomp LIKE '%하나%' THEN '140'
				WHEN p_cardcomp LIKE '%외환%' THEN '140'
				WHEN p_cardcomp LIKE '%NH%' THEN '200'
				WHEN p_cardcomp LIKE '%시티%' THEN '110'
				WHEN p_cardcomp LIKE '%KB%' THEN '010'
				WHEN p_cardcomp LIKE '%제일%' THEN '999'
				WHEN p_cardcomp LIKE '%개인레드%' THEN '999'
        WHEN p_cardcomp LIKE '%새마을%' THEN '999'
        ELSE p_cardcomp
      END;
  END IF;

  RETURN p_cardcode;

EXCEPTION WHEN OTHERS THEN RETURN p_cardcode;
END;
/
