CREATE PROCEDURE spACacc0008P
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACacc0008P
   -- 작 성 자         : 민승기
   -- 작성일자         : 2010-12-15
   -- 수 정 자         : 임 정호
   -- 작성일자         : 2016-12-19
   -- 수      정       : 2011-01-21 이영재 AC06 '9' 오류코드 저장 처리점검, 예산집계 추가
   --                  : 2011-01-24 이영재 회기 시작월에 대한 기초차변,대변금액은 집계시 이월 제외.
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 회계전표 집계처리를 조회하는 프로시저이다.
   -- ---------------------------------------------------------------
(
    p_div          IN     VARCHAR2 DEFAULT '',
    p_compcode     IN     VARCHAR2 DEFAULT '',
    p_strym        IN     VARCHAR2 DEFAULT '',
    p_endym        IN     VARCHAR2 DEFAULT '',
    p_accdiv       IN     VARCHAR2 DEFAULT '',
    p_iempcode     IN     VARCHAR2 DEFAULT '',
    p_userid       IN     VARCHAR2 DEFAULT '',
    p_reasondiv    IN     VARCHAR2 DEFAULT '',
    p_reasontext   IN     VARCHAR2 DEFAULT '',
    IO_CURSOR      OUT TYPES.DataSet,
    MESSAGE        OUT VARCHAR2
)
AS
    p_tempym      VARCHAR2(7);
    p_nxttempym   VARCHAR2(7);
    p_chkrmk      VARCHAR2(1);
    v_temp        NUMBER  := 0;
    v_rowcount    NUMBER  := 0;
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF (p_div = 'S') THEN

        OPEN IO_CURSOR FOR

            SELECT  NVL (A.compcode, '') compcode,
                    NVL (A.closeym, '') closeym,
                    NVL (A.accdiv, '') accdiv,
                    NVL (A.apprcloseyn, '') apprcloseyn,
                    NVL (A.apprclosedate, '') apprclosedate,
                    NVL (A.apprempcode, '') apprempcode,
                    NVL (A.accsumdate, '') accsumdate,
                    NVL (A.accsumstate, '') accsumstate,
                    NVL (A.remark, '') remark,
                    NVL (b.empname, '') apprempname,
                    NVL (ac20.divname, '') accdivname,
                    NVL (ac06.divname, '') accsumstatename
            FROM    CMCLOSEM A
                    LEFT JOIN CMEMPM b       ON UPPER(A.apprempcode) = UPPER(b.empcode)
                    LEFT JOIN CMCOMMONM ac20 ON UPPER(A.accdiv) = UPPER(ac20.divcode)
                                                AND UPPER(ac20.cmmcode) = 'AC20'
                    LEFT JOIN CMCOMMONM ac06 ON UPPER(A.accsumstate) = UPPER(ac06.divcode)
                                                AND UPPER(ac06.cmmcode) = 'AC06'
            WHERE   A.compcode = p_compcode
                    AND A.closeym BETWEEN p_strym AND p_endym
                    AND ( A.accdiv = p_accdiv OR
                          NVL(TRIM(p_accdiv), ' ') IN (' ', '%')
                          AND A.accdiv IN ('A', 'K', 'F')
                        )
            ORDER BY closeym, accdiv ;

    ELSIF (p_div = 'T') THEN -- 집계 처리

        p_tempym := p_strym;

        WHILE p_tempym <= p_endym
        LOOP

            SELECT  COUNT (*)
            INTO    v_temp
            FROM    DUAL
            WHERE NOT EXISTS (  SELECT  compcode
                                FROM    CMCLOSEM
                                WHERE   compcode = p_compcode
                                        AND closeym = p_tempym
                                        AND accdiv IN ('A', 'F', 'K')
                                        AND accdiv LIKE NVL(TRIM(p_accdiv), ' ') || '%' ) ;


            IF v_temp = 1   THEN

                INSERT INTO CMCLOSEM (
                    compcode
                    , closeym
                    , accdiv
                    , accsumdate
                    , accsumstate
                    , insertdt
                    , iempcode )
                (
                    SELECT  p_compcode,
                            p_tempym,
                            'A',
                            TO_CHAR(SYSDATE,'YYYY-MM-DD'),
                            '1',
                            SYSDATE,
                            p_iempcode
                    FROM    DUAL
                    WHERE   NVL(TRIM(p_accdiv), ' ') IN ('A', '%', ' ')

                    UNION

                    SELECT  p_compcode,
                            p_tempym,
                            'F',
                            TO_CHAR(SYSDATE,'YYYY-MM-DD'),
                            '1',
                            SYSDATE,
                            p_iempcode
                    FROM    DUAL
                    WHERE   NVL(TRIM(p_accdiv), ' ') IN ('F', '%', ' ')

                    UNION ALL

                    SELECT  p_compcode,
                            p_tempym,
                            'K',
                            TO_CHAR(SYSDATE,'YYYY-MM-DD'),
                            '1',
                            SYSDATE,
                            p_iempcode
                    FROM    DUAL
                    WHERE   NVL(TRIM(p_accdiv), ' ') IN ('K', '%', ' ')
                );

            ELSE

                UPDATE  CMCLOSEM A
                SET     A.accsumdate =
                        TO_CHAR(SYSDATE,'YYYY-MM-DD'),
                        A.accsumstate = '1'
                WHERE   A.compcode = p_compcode
                        AND A.closeym = p_tempym
                        AND A.accdiv IN ('A', 'F', 'K')
                        AND A.accdiv LIKE NVL(TRIM(p_accdiv), ' ') || '%' ;

             END IF;

             -- 회계전표 집계처리(전체집계)
             spACord0000MM (p_div          => 'T',
                            p_compcode => p_compcode,                -- 회사코드
                            p_closediv => p_accdiv,                -- 결산구분
                            p_strslipym => p_tempym,                -- 시작년월
                            p_endslipym => p_tempym,                -- 종료년월
                            p_userid => p_userid,
                            p_reasondiv => p_reasondiv,
                            p_reasontext => p_reasontext,
                            MESSAGE        => MESSAGE,
                            IO_CURSOR      => IO_CURSOR);

             MESSAGE := NULL;

             -- 회계전표 예산집계처리(전체집계)
             spACbudg0000MM (p_div          => 'TO',
                             p_compcode     => p_compcode,            -- 회사코드
                             p_slipinno     => '',                        --
                             p_strbudgym    => p_tempym,              -- 시작년월
                             p_endbudgym    => p_tempym,              -- 종료년월
                             p_userid       => p_userid,
                             p_reasondiv    => p_reasondiv,
                             p_reasontext   => p_reasontext,
                             MESSAGE        => MESSAGE,
                             IO_CURSOR      => IO_CURSOR);

            UPDATE  CMCLOSEM A
            SET     A.accsumstate = CASE WHEN MESSAGE IS NULL THEN '9' ELSE '3' END
            WHERE   A.compcode = p_compcode
                    AND A.closeym = p_tempym
                    AND A.accdiv IN ('A', 'F', 'K')
                    AND A.accdiv LIKE NVL(TRIM(p_accdiv), ' ') || '%' ;

             p_tempym := TO_CHAR(ADD_MONTHS (TO_DATE(p_tempym||'-01','YYYY-MM-DD'),1 ),'YYYY-MM');

        END LOOP;

        MESSAGE := NULL;

    ELSIF( p_div = 'C' ) THEN

        p_tempym := p_strym;

        WHILE p_tempym <= p_endym
        LOOP

DBMS_OUTPUT.PUT_LINE('p_tempym:' || p_tempym );

            v_temp := 0;

            SELECT  COUNT(*)
            INTO    v_temp
            FROM    DUAL
            WHERE NOT EXISTS (  SELECT  compcode
                                FROM    CMCLOSEM
                                WHERE   compcode = p_compcode
                                        AND closeym = p_tempym
                                        AND accdiv IN ('A', 'F', 'K')
                                        AND accdiv LIKE NVL(TRIM(p_accdiv), ' ') || '%' ) ;

            IF v_temp = 0 THEN

                UPDATE  CMCLOSEM A
                SET     A.remark = NULL
                WHERE   A.compcode = p_compcode
                        AND A.closeym = p_tempym
                        AND A.accdiv IN ('A', 'F', 'K')
                        AND A.accdiv LIKE NVL(TRIM(p_accdiv),' ') || '%' ;

            ELSE

                INSERT INTO CMCLOSEM (
                    compcode
                    , closeym
                    , accdiv
                    , accsumdate
                    , accsumstate
                    , insertdt
                    , iempcode )
                (
                    SELECT  p_compcode,
                            p_tempym,
                            'A',
                            TO_CHAR(SYSDATE,'YYYY-MM-DD'),
                            '1',
                            SYSDATE,
                            p_iempcode
                    FROM    DUAL
                    WHERE   NVL(TRIM(p_accdiv),' ') IN ('A', '%', ' ')

                    UNION

                    SELECT  p_compcode,
                            p_tempym,
                            'F',
                            TO_CHAR(SYSDATE,'YYYY-MM-DD'),
                            '1',
                            SYSDATE,
                            p_iempcode
                    FROM    DUAL
                    WHERE   NVL(TRIM(p_accdiv), ' ') IN ('F', '%', ' ')

                    UNION ALL

                    SELECT  p_compcode,
                            p_tempym,
                            'K',
                            TO_CHAR(SYSDATE,'YYYY-MM-DD'),
                            '1',
                            SYSDATE,
                            p_iempcode
                    FROM    DUAL
                    WHERE   NVL(TRIM(p_accdiv), ' ') IN ('K', '%', ' ')
                ) ;

             END IF;


            p_nxttempym := TO_CHAR(ADD_MONTHS(TO_DATE(p_tempym||'-01','YYYY-MM-DD'), 1), 'YYYY-MM');

            p_chkrmk := NULL;

            ---------------------------------------
            -- 계정별 비교
            ---------------------------------------

            -- 계정별 집계비교(1)
            OPEN IO_CURSOR FOR

                SELECT  A.acccode
                FROM    ACORDDMM A
                        LEFT JOIN ACORDDMM b ON b.compcode      = A.compcode
                                                AND b.plantcode = A.plantcode
                                                AND b.slipym    = p_nxttempym
                                                AND b.closediv  = A.closediv
                                                AND b.acccode   = A.acccode
                WHERE   A.compcode = p_compcode
                        AND A.slipym = p_tempym
                        AND A.closediv LIKE CASE WHEN NVL(TRIM(p_accdiv), ' ') = 'A' THEN '10'
                                                 WHEN NVL(TRIM(p_accdiv), ' ') = 'K' THEN '20'
                                                 WHEN NVL(TRIM(p_accdiv), ' ') = 'F' THEN '30'
                                                 ELSE '%'
                                            END
                        AND (NVL(A.totdebamt, 0) - NVL(A.totcreamt, 0)) <> (NVL(b.bsdebamt, 0) - NVL(b.bscreamt, 0))
                        AND ROWNUM <= 1 ;


            v_rowcount := 0;
            FOR rec IN (
                SELECT  COUNT(A.acccode) AS alias1
                FROM    ACORDDMM A
                        LEFT JOIN ACORDDMM b ON b.compcode      = A.compcode
                                                AND b.plantcode = A.plantcode
                                                AND b.slipym    = p_nxttempym
                                                AND b.closediv  = A.closediv
                                                AND b.acccode   = A.acccode
                WHERE   A.compcode = p_compcode
                        AND A.slipym = p_tempym
                        AND A.closediv LIKE CASE WHEN NVL(TRIM(p_accdiv), ' ') = 'A' THEN '10'
                                                 WHEN NVL(TRIM(p_accdiv), ' ') = 'K' THEN '20'
                                                 WHEN NVL(TRIM(p_accdiv), ' ') = 'F' THEN '30'
                                                 ELSE '%'
                                            END
                        AND (NVL(A.totdebamt, 0) - NVL(A.totcreamt, 0)) <> (NVL(b.bsdebamt, 0) - NVL(b.bscreamt, 0))
                        AND ROWNUM <= 1
            )
            LOOP

                v_rowcount := rec.alias1;

            END LOOP ;



            IF (v_rowcount > 0) THEN

                UPDATE  CMCLOSEM A
                SET     A.remark = '차기월 초기금액과 차이 발생'
                WHERE   A.compcode = p_compcode
                        AND A.closeym = p_tempym
                        AND A.accdiv IN ('A', 'F', 'K')
                        AND NVL(TRIM(A.accdiv), ' ') LIKE p_accdiv || '%' ;

                p_chkrmk := '*';

            ELSE

                UPDATE  CMCLOSEM A
                SET     A.remark = NULL
                WHERE   A.compcode = p_compcode
                        AND A.closeym = p_tempym
                        AND A.accdiv IN ('A', 'F', 'K')
                        AND NVL(TRIM(A.accdiv), ' ') LIKE p_accdiv || '%' ;

            END IF;



            -- 계정별 집계비교(2)
            IF (p_chkrmk IS NULL) THEN

                OPEN IO_CURSOR FOR

                    SELECT  A.acccode
                    FROM    ACORDDMM A
                            LEFT JOIN ACORDDMM b ON b.compcode = A.compcode
                                                    AND b.plantcode = A.plantcode
                                                    AND b.slipym = p_tempym
                                                    AND b.closediv = A.closediv
                                                    AND b.acccode = A.acccode
                    WHERE   A.compcode = p_compcode
                            AND A.slipym = p_nxttempym
                            AND A.closediv LIKE CASE WHEN NVL(TRIM(p_accdiv), ' ') = 'A' THEN '10'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'K' THEN '20'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'F' THEN '30'
                                                     ELSE '%'
                                                END
                            AND (NVL(b.totdebamt, 0) - NVL(b.totcreamt, 0)) <> (NVL(A.bsdebamt, 0) - NVL(A.bscreamt, 0))
                            AND ROWNUM = 1 ;


                v_rowcount := 0;
                FOR rec IN (
                    SELECT  COUNT(A.acccode) AS alias1
                    FROM    ACORDDMM A
                            LEFT JOIN ACORDDMM b ON b.compcode = A.compcode
                                                    AND b.plantcode = A.plantcode
                                                    AND b.slipym = p_tempym
                                                    AND b.closediv = A.closediv
                                                    AND b.acccode = A.acccode
                    WHERE   A.compcode = p_compcode
                            AND A.slipym = p_nxttempym
                            AND A.closediv LIKE CASE WHEN NVL(TRIM(p_accdiv), ' ') = 'A' THEN '10'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'K' THEN '20'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'F' THEN '30'
                                                     ELSE '%'
                                                END
                            AND (NVL(b.totdebamt, 0) - NVL(b.totcreamt, 0)) <> (NVL(A.bsdebamt, 0) - NVL(A.bscreamt, 0))
                            AND ROWNUM = 1
                )
                LOOP

                    v_rowcount := rec.alias1;

                END LOOP ;



                IF ( v_rowcount > 0) THEN

                    UPDATE  CMCLOSEM A
                    SET     A.remark = '차기월 초기금액과 차이 발생'
                    WHERE   A.compcode = p_compcode
                            AND A.closeym = p_tempym
                            AND A.accdiv IN ('A', 'F', 'K')
                            AND A.accdiv LIKE NVL(TRIM(p_accdiv), ' ') || '%' ;

                    p_chkrmk := '*';

                ELSE

                    UPDATE  CMCLOSEM A
                    SET     A.remark = ''
                    WHERE   A.compcode = p_compcode
                            AND A.closeym = p_tempym
                            AND A.accdiv IN ('A', 'F', 'K')
                            AND A.accdiv LIKE NVL(TRIM(p_accdiv), ' ') || '%' ;

                END IF;

             END IF;


            ---------------------------------------
            -- 계정 관리항목별 비교
            ---------------------------------------
            -- 관리항목별 집계비교(1)
            IF (p_chkrmk IS NULL) THEN

                OPEN IO_CURSOR FOR

                    SELECT  A.acccode
                    FROM    ACORDSMM A
                            JOIN ACACCM c    ON c.acccode = A.acccode
                            JOIN ACACCMNGM D ON D.acccode = c.acccode
                                                AND D.dcdiv = c.dcdiv
                                                AND D.mngclucode = A.mngclucode
                                                AND D.remainyn = 'Y'
                            LEFT JOIN ACORDSMM b ON b.compcode = A.compcode
                                                    AND b.plantcode = A.plantcode
                                                    AND b.slipym = p_nxttempym
                                                    AND b.closediv = A.closediv
                                                    AND b.acccode = A.acccode
                                                    AND b.mngclucode = A.mngclucode
                                                    AND b.mngcluval = A.mngcluval
                    WHERE   A.compcode = p_compcode
                            AND A.slipym = p_tempym
                            AND A.closediv LIKE CASE WHEN NVL(TRIM(p_accdiv), ' ') = 'A' THEN '10'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'K' THEN '20'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'F' THEN '30'
                                                     ELSE '%'
                                                END
                            AND (NVL(A.totdebamt, 0) - NVL(A.totcreamt, 0)) <> (NVL(b.bsdebamt, 0) - NVL(b.bscreamt, 0))
                    AND ROWNUM = 1;


                v_rowcount := 0;
                FOR rec IN (
                    SELECT  COUNT(A.acccode) AS alias1
                    FROM    ACORDSMM A
                            JOIN ACACCM c    ON c.acccode = A.acccode
                            JOIN ACACCMNGM D ON D.acccode = c.acccode
                                                AND D.dcdiv = c.dcdiv
                                                AND D.mngclucode = A.mngclucode
                                                AND D.remainyn = 'Y'
                            LEFT JOIN ACORDSMM b ON b.compcode = A.compcode
                                                    AND b.plantcode = A.plantcode
                                                    AND b.slipym = p_nxttempym
                                                    AND b.closediv = A.closediv
                                                    AND b.acccode = A.acccode
                                                    AND b.mngclucode = A.mngclucode
                                                    AND b.mngcluval = A.mngcluval
                    WHERE   A.compcode = p_compcode
                            AND A.slipym = p_tempym
                            AND A.closediv LIKE CASE WHEN NVL(TRIM(p_accdiv), ' ') = 'A' THEN '10'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'K' THEN '20'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'F' THEN '30'
                                                     ELSE '%'
                                                END
                            AND (NVL(A.totdebamt, 0) - NVL(A.totcreamt, 0)) <> (NVL(b.bsdebamt, 0) - NVL(b.bscreamt, 0))
                    AND ROWNUM = 1
                )
                LOOP

                    v_rowcount := rec.alias1;

                END LOOP ;


                IF ( v_rowcount > 0) THEN

                    UPDATE  CMCLOSEM A
                    SET     A.remark = '차기월 초기금액과 차이 발생'
                    WHERE   A.compcode = p_compcode
                            AND A.closeym = p_tempym
                            AND A.accdiv IN ('A', 'F', 'K')
                            AND A.accdiv LIKE NVL(TRIM(p_accdiv), ' ') || '%' ;

                    p_chkrmk := '*';

                ELSE

                    UPDATE  CMCLOSEM A
                    SET     A.remark = ''
                    WHERE   A.compcode = p_compcode
                            AND A.closeym = p_tempym
                            AND A.accdiv IN ('A', 'F', 'K')
                            AND A.accdiv LIKE NVL(TRIM(p_accdiv), ' ') || '%';

                END IF;

            END IF;



            -- 관리항목별 집계비교(2)
            IF (p_chkrmk IS NULL) THEN

                OPEN IO_CURSOR FOR

                    SELECT  A.acccode
                    FROM    ACORDSMM A
                            JOIN ACACCM c    ON c.acccode = A.acccode
                            JOIN ACACCMNGM D ON D.acccode = c.acccode
                                                AND D.dcdiv = c.dcdiv
                                                AND D.mngclucode = A.mngclucode
                                                AND D.remainyn = 'Y'
                            LEFT JOIN ACORDSMM b ON b.compcode = A.compcode
                                                    AND b.plantcode = A.plantcode
                                                    AND b.slipym = p_tempym
                                                    AND b.closediv = A.closediv
                                                    AND b.acccode = A.acccode
                                                    AND b.mngclucode = A.mngclucode
                                                    AND b.mngcluval = A.mngcluval
                    WHERE   A.compcode = p_compcode
                            AND A.slipym = p_nxttempym
                            AND A.closediv LIKE CASE WHEN NVL(TRIM(p_accdiv), ' ') = 'A' THEN '10'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'K' THEN '20'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'F' THEN '30'
                                                     ELSE '%'
                                                END
                            AND (NVL (b.totdebamt, 0) - NVL (b.totcreamt, 0)) <> (NVL (A.bsdebamt, 0) - NVL (A.bscreamt, 0))
                    AND ROWNUM = 1 ;


                v_rowcount := 0;
                FOR rec IN (
                    SELECT  COUNT(A.acccode) AS alias1
                    FROM    ACORDSMM A
                            JOIN ACACCM c    ON c.acccode = A.acccode
                            JOIN ACACCMNGM D ON D.acccode = c.acccode
                                                AND D.dcdiv = c.dcdiv
                                                AND D.mngclucode = A.mngclucode
                                                AND D.remainyn = 'Y'
                            LEFT JOIN ACORDSMM b ON b.compcode = A.compcode
                                                    AND b.plantcode = A.plantcode
                                                    AND b.slipym = p_tempym
                                                    AND b.closediv = A.closediv
                                                    AND b.acccode = A.acccode
                                                    AND b.mngclucode = A.mngclucode
                                                    AND b.mngcluval = A.mngcluval
                    WHERE   A.compcode = p_compcode
                            AND A.slipym = p_nxttempym
                            AND A.closediv LIKE CASE WHEN NVL(TRIM(p_accdiv), ' ') = 'A' THEN '10'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'K' THEN '20'
                                                     WHEN NVL(TRIM(p_accdiv), ' ') = 'F' THEN '30'
                                                     ELSE '%'
                                                END
                            AND (NVL (b.totdebamt, 0) - NVL (b.totcreamt, 0)) <> (NVL (A.bsdebamt, 0) - NVL (A.bscreamt, 0))
                    AND ROWNUM = 1
                )
                LOOP

                    v_rowcount := rec.alias1;

                END LOOP ;


                IF ( v_rowcount > 0) THEN


                    UPDATE  CMCLOSEM A
                    SET     A.remark = '차기월 초기금액과 차이 발생'
                    WHERE   A.compcode = p_compcode
                            AND A.closeym = p_tempym
                            AND A.accdiv IN ('A', 'F', 'K')
                            AND A.accdiv LIKE NVL(TRIM(p_accdiv), ' ') || '%' ;

                    p_chkrmk := '*';

                ELSE

                    UPDATE  CMCLOSEM A
                    SET     A.remark = ''
                    WHERE   A.compcode = p_compcode
                            AND A.closeym = p_tempym
                            AND A.accdiv IN ('A', 'F', 'K')
                            AND A.accdiv LIKE NVL(TRIM(p_accdiv), ' ') || '%' ;

                END IF;

            END IF;

            p_tempym := TO_CHAR(ADD_MONTHS(TO_DATE(p_tempym||'-01','YYYY-MM-DD'), 1),'YYYY-MM');

        END LOOP;

        MESSAGE := NULL;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
