CREATE PROCEDURE        spACbudg0014P
   -- ---------------------------------------------------------------
   -- 프로시저명       : spACbudg0014P
   -- 작 성 자         : 배종성
   -- 작성일자         : 2010-02-08
   -- 수 정 자         : 임 정호
   -- 수정일자         : 2017-01-02
   -- ---------------------------------------------------------------
   -- 프로시저 설명    : 예산조회권한을 조회 및 입력하는 프로시저이다.
   -- ---------------------------------------------------------------
   -- select * from ACBUDGAM
   -- select * from CMCOMMONM where cmmcode = 'AC93'
   -- exec spACbudg0014P 'S', '100', '%', '%','','','','','','','','','','', '','','','N'
(
   p_div          IN     VARCHAR2 DEFAULT '',
   p_compcode     IN     VARCHAR2 DEFAULT '',
   p_empcode      IN     VARCHAR2 DEFAULT '',
   p_audittype    IN     VARCHAR2 DEFAULT '',
   p_deptcode1    IN     VARCHAR2 DEFAULT '',
   p_deptcode2    IN     VARCHAR2 DEFAULT '',
   p_deptcode3    IN     VARCHAR2 DEFAULT '',
   p_deptcode4    IN     VARCHAR2 DEFAULT '',
   p_deptcode5    IN     VARCHAR2 DEFAULT '',
   p_remark       IN     VARCHAR2 DEFAULT '',
   p_insertdt     IN     DATE DEFAULT NULL,
   p_iempcode     IN     VARCHAR2 DEFAULT '',
   p_updatedt     IN     DATE DEFAULT NULL,
   p_uempcode     IN     VARCHAR2 DEFAULT '',
   p_userid       IN     VARCHAR2 DEFAULT '',
   p_reasondiv    IN     VARCHAR2 DEFAULT '',
   p_reasontext   IN     VARCHAR2 DEFAULT '',
   IO_CURSOR         OUT TYPES.DataSet,
   MESSAGE           OUT VARCHAR2
)
AS
BEGIN
   MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);



   IF (p_div = 'S')    THEN

      OPEN IO_CURSOR FOR
           SELECT a.compcode,
                  a.empcode,
                  c.empname empname,
                  D.deptcode,
                  E.deptname,
                  a.audittype,
                  b.divname audittypenm,
                  deptcode1 deptcode1,
                  NVL (e1.deptname, '') deptname1,
                  deptcode2 deptcode2,
                  NVL (e2.deptname, '') deptname2,
                  deptcode3 deptcode3,
                  NVL (e3.deptname, '') deptname3,
                  deptcode4 deptcode4,
                  NVL (e4.deptname, '') deptname4,
                  deptcode5 deptcode5,
                  NVL (e5.deptname, '') deptname5,
                  NVL (a.remark, '') remark
             FROM ACBUDGAM a
                  LEFT JOIN CMCOMMONM b
                     ON a.audittype = b.divcode AND b.cmmcode = 'AC93'
                  LEFT JOIN CMEMPM c ON a.empcode = c.empcode
                  LEFT JOIN CMDEPTM e1 ON a.deptcode1 = e1.deptcode
                  LEFT JOIN CMDEPTM e2 ON a.deptcode2 = e2.deptcode
                  LEFT JOIN CMDEPTM e3 ON a.deptcode3 = e3.deptcode
                  LEFT JOIN CMDEPTM e4 ON a.deptcode4 = e4.deptcode
                  LEFT JOIN CMDEPTM e5 ON a.deptcode5 = e5.deptcode
                  LEFT JOIN CMEMPM D ON a.empcode = D.empcode
                  LEFT JOIN CMDEPTM E ON D.deptcode = E.deptcode
            WHERE     a.compcode = p_compcode
                  AND a.empcode LIKE p_empcode || '%'
                  AND a.audittype LIKE p_audittype || '%'
         ORDER BY empcode;
   ELSIF (p_div = 'SC') THEN

      FOR rec IN
      ( SELECT COUNT (*) AS alias1
        FROM ACBUDGAM
        WHERE compcode = p_compcode AND empcode LIKE p_empcode || '%'
      )
      LOOP
         MESSAGE := rec.alias1;
      END LOOP;

   ELSIF (p_div = 'I') THEN
      INSERT INTO ACBUDGAM (compcode, empcode, audittype, deptcode1, deptcode2,deptcode3,
                            deptcode4,deptcode5,remark,   insertdt,  iempcode)
                   VALUES  (p_compcode, p_empcode, p_audittype, p_deptcode1,p_deptcode2,
                            p_deptcode3,p_deptcode4, p_deptcode5, p_remark,SYSDATE, p_iempcode);

   ELSIF (p_div = 'U') THEN
      UPDATE ACBUDGAM
         SET compcode = p_compcode,
             empcode = p_empcode,
             audittype = p_audittype,
             deptcode1 = p_deptcode1,
             deptcode2 = p_deptcode2,
             deptcode3 = p_deptcode3,
             deptcode4 = p_deptcode4,
             deptcode5 = p_deptcode5,
             remark = p_remark,
             updatedt = SYSDATE,
             uempcode = p_iempcode
       WHERE compcode = p_compcode AND empcode = p_empcode;

   ELSIF (p_div = 'D') THEN
      DELETE ACBUDGAM
       WHERE compcode = p_compcode AND empcode = p_empcode;
   END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
