CREATE PROCEDURE        spACbudg0026P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbudg0026P
	-- 작 성 자         : 최용석
	-- 작성일자         : 2012-10-18
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2017-01-02
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 사원별월예산변경관리에서 원예산변경을 조회 및 원예산을 입력하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			 IN 	VARCHAR2 DEFAULT '',
	p_compcode		 IN 	VARCHAR2 DEFAULT '',
	p_cyear 		 IN 	VARCHAR2 DEFAULT '',
	p_dedate1		 IN 	VARCHAR2 DEFAULT '',
	p_dedate2		 IN 	VARCHAR2 DEFAULT '',
	p_deptcodeS 	 IN 	VARCHAR2 DEFAULT '',
	p_acccodeS		 IN 	VARCHAR2 DEFAULT '',
	p_chgdiv		 IN 	VARCHAR2 DEFAULT '',
	p_budgym		 IN 	VARCHAR2 DEFAULT '',
	p_seq			 IN 	NUMBER   DEFAULT 0,
	p_chgdate		 IN 	VARCHAR2 DEFAULT '',
	p_empcode		 IN 	VARCHAR2 DEFAULT '',
	p_remark		 IN 	VARCHAR2 DEFAULT '',
	p_frmbudgym 	 IN 	VARCHAR2 DEFAULT '',
	p_frmacccode	 IN 	VARCHAR2 DEFAULT '',
	p_frm1budgamt	 IN 	FLOAT    DEFAULT 0,
	p_aft1budgamt	 IN 	FLOAT    DEFAULT 0,
	p_aftbudgym 	 IN 	VARCHAR2 DEFAULT '',
	p_aftacccode	 IN 	VARCHAR2 DEFAULT '',
	p_frm2budgamt	 IN 	FLOAT    DEFAULT 0,
	p_aft2budgamt	 IN 	FLOAT    DEFAULT 0,
	p_iempcode		 IN 	VARCHAR2 DEFAULT '',
	p_userid		 IN 	VARCHAR2 DEFAULT '',
	p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
	p_reasontext	 IN 	VARCHAR2 DEFAULT '',
	MESSAGE 			OUT VARCHAR2,
	IO_CURSOR			OUT TYPES.DATASET
)
AS
	ip_seq	 NUMBER(10, 0) := p_seq;
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S')
	THEN
		OPEN IO_CURSOR FOR
			SELECT	 a.seq,
					 a.empcode,
					 b.empname,
					 a.chgdate,
					 a.chgdiv,
					 c.divname chgdivnm,
					 a.remark,
					 a.frmbudgym,
					 a.frmacccode,
					 f.accname frmaccname,
					 a.frm1budgamt,
					 a.aft1budgamt,
					 a.aft1budgamt - a.frm1budgamt frmbudgdiff,
					 NVL(h.slipamt, 0) frmslipamt,
					 a.aft1budgamt - NVL(h.slipamt, 0) frmdiffamt,
					 a.aftbudgym,
					 a.aftacccode,
					 g.accname aftaccname,
					 a.frm2budgamt,
					 a.aft2budgamt,
					 NVL(i.slipamt, 0) aftslipamt,
					 a.aft2budgamt - NVL(i.slipamt, 0) aftdiffamt,
					 CASE
						 WHEN a.seq = D.seq
							  AND (trim(a.aftacccode) is null
								   OR a.seq = e.seq)
						 THEN
							 0
						 ELSE
							 1
					 END
						 nxtseq
			FROM	 ACBUDGYHE a
					 LEFT JOIN CMEMPM b ON a.empcode = b.empcode
					 LEFT JOIN CMCOMMONM c
						 ON a.chgdiv = c.divcode
							AND c.cmmcode = 'AC90'
					 LEFT JOIN (SELECT	 empcode, frmbudgym, frmacccode, MAX(seq) seq
								FROM	 (SELECT empcode, frmbudgym, frmacccode, seq
										  FROM	 ACBUDGYHE
										  WHERE  compcode = p_compcode
												 AND cyear = p_cyear
										  UNION ALL
										  SELECT empcode, aftbudgym, aftacccode, seq
										  FROM	 ACBUDGYHE
										  WHERE  compcode = p_compcode
												 AND cyear = p_cyear
												 AND trim(aftacccode) is not null) a
								GROUP BY empcode, frmbudgym, frmacccode) D
						 ON a.empcode = D.empcode
							AND a.frmbudgym = D.frmbudgym
							AND a.frmacccode = D.frmacccode
					 LEFT JOIN (SELECT	 empcode, frmbudgym, frmacccode, MAX(seq) seq
								FROM	 (SELECT empcode, frmbudgym, frmacccode, seq
										  FROM	 ACBUDGYHE
										  WHERE  compcode = p_compcode
												 AND cyear = p_cyear
										  UNION ALL
										  SELECT empcode, aftbudgym, aftacccode, seq
										  FROM	 ACBUDGYHE
										  WHERE  compcode = p_compcode
												 AND cyear = p_cyear
												 AND trim(aftacccode) is not null ) a
								GROUP BY empcode, frmbudgym, frmacccode) e
						 ON a.empcode = e.empcode
							AND a.aftbudgym = e.frmbudgym
							AND a.aftacccode = e.frmacccode
					 LEFT JOIN ACACCM f ON a.frmacccode = f.acccode
					 LEFT JOIN ACACCM g ON a.aftacccode = g.acccode
					 LEFT JOIN ACBUDGYYE h
						 ON a.compcode = h.compcode
							AND a.frmbudgym = h.budgym
							AND a.empcode = h.empcode
							AND a.frmacccode = h.acccode
					 LEFT JOIN ACBUDGYYE i
						 ON a.compcode = i.compcode
							AND a.aftbudgym = i.budgym
							AND a.empcode = i.empcode
							AND a.aftacccode = i.acccode
			WHERE	 a.compcode = p_compcode
					 AND a.cyear = p_cyear
					 AND a.chgdate BETWEEN p_dedate1 AND p_dedate2
					 AND (trim(p_deptcodeS) is null
						  OR NVL(b.deptcode, ' ') = NVL(p_deptcodeS, ' '))
					 AND (trim(p_acccodeS) is null
						  OR a.frmacccode = p_acccodeS)
					 AND a.chgdiv LIKE p_chgdiv
			ORDER BY a.seq;
	ELSIF (p_div = 'S1')
	THEN
		OPEN IO_CURSOR FOR
			SELECT budgamt + addamt budgamt, slipamt, remark
			FROM   ACBUDGYYE
			WHERE  compcode = p_compcode
				   AND budgym = p_budgym
				   AND empcode = p_empcode
				   AND acccode = p_acccodeS;
	ELSIF (p_div = 'I')
	THEN
		DECLARE
			v_temp	 NUMBER(1, 0) := 0;
		BEGIN
			FOR rec IN (SELECT NVL(MAX(seq), 0) + 1 AS alias1
						FROM   ACBUDGYHE
						WHERE  compcode = p_compcode
							   AND cyear = p_cyear)
			LOOP
				ip_seq := rec.alias1;
			END LOOP;

			INSERT INTO ACBUDGYHE(compcode,
								  cyear,
								  seq,
								  empcode,
								  chgdate,
								  chgdiv,
								  remark,
								  frmbudgym,
								  frmacccode,
								  frm1budgamt,
								  aft1budgamt,
								  aftbudgym,
								  aftacccode,
								  frm2budgamt,
								  aft2budgamt,
								  insertdt,
								  iempcode)
				(SELECT p_compcode,
						p_cyear,
						ip_seq,
						p_empcode,
						p_chgdate,
						p_chgdiv,
						p_remark,
						p_frmbudgym,
						p_frmacccode,
						p_frm1budgamt,
						p_aft1budgamt,
						p_aftbudgym,
						p_aftacccode,
						p_frm2budgamt,
						p_aft2budgamt,
						SYSDATE,
						p_iempcode
				 FROM	DUAL);

			SELECT COUNT(*)
			INTO   v_temp
			FROM   DUAL
			WHERE  EXISTS
					   (SELECT *
						FROM   ACBUDGYYE
						WHERE  compcode = p_compcode
							   AND budgym = p_frmbudgym
							   AND empcode = p_empcode
							   AND acccode = p_frmacccode);


			IF v_temp = 1
			THEN
				UPDATE ACBUDGYYE a
				SET    a.addamt = a.addamt + p_aft1budgamt - p_frm1budgamt, a.updatedt = SYSDATE, a.uempcode = p_iempcode
				WHERE  compcode = p_compcode
					   AND budgym = p_frmbudgym
					   AND empcode = p_empcode
					   AND acccode = p_frmacccode;
			ELSE
				INSERT INTO ACBUDGYYE(compcode,
									  budgym,
									  empcode,
									  acccode,
									  budgamt,
									  addamt,
									  slipamt,
									  remark,
									  insertdt,
									  iempcode)
					(SELECT p_compcode,
							p_frmbudgym,
							p_empcode,
							p_frmacccode,
							0,
							p_aft1budgamt - p_frm1budgamt,
							0,
							'사원별예산변경관리에서 추가',
							SYSDATE,
							p_iempcode
					 FROM	DUAL);
			END IF;

			SELECT COUNT(*)
			INTO   v_temp
			FROM   DUAL
			WHERE  EXISTS
					   (SELECT *
						FROM   ACBUDGYYE
						WHERE  compcode = p_compcode
							   AND budgym = p_aftbudgym
							   AND empcode = p_empcode
							   AND acccode = p_aftacccode);


			IF v_temp = 1
			THEN
				UPDATE ACBUDGYYE a
				SET    a.addamt = a.addamt + p_aft2budgamt - p_frm2budgamt, a.updatedt = SYSDATE, a.uempcode = p_iempcode
				WHERE  compcode = p_compcode
					   AND budgym = p_aftbudgym
					   AND empcode = p_empcode
					   AND acccode = p_aftacccode;
			ELSIF trim(p_aftacccode) is not null
			THEN
				INSERT INTO ACBUDGYYE(compcode,
									  budgym,
									  empcode,
									  acccode,
									  budgamt,
									  addamt,
									  slipamt,
									  remark,
									  insertdt,
									  iempcode)
					(SELECT p_compcode,
							p_aftbudgym,
							p_empcode,
							p_aftacccode,
							0,
							p_aft2budgamt - p_frm2budgamt,
							0,
							'사원별예산변경관리에서 추가',
							SYSDATE,
							p_iempcode
					 FROM	DUAL);
			END IF;
		END;
	ELSIF (p_div = 'U')
	THEN
		DECLARE
			v_temp	 NUMBER(1, 0) := 0;
		BEGIN
			MERGE INTO ACBUDGYYE b
			USING	   (SELECT B.COMPCODE, B.BUDGYM, B.EMPCODE, B.ACCCODE, addamt - a.aft1budgamt + a.frm1budgamt pos_2
						FROM   ACBUDGYHE a
							   JOIN ACBUDGYYE b
								   ON a.compcode = b.compcode
									  AND a.frmbudgym = b.budgym
									  AND a.empcode = b.empcode
									  AND a.frmacccode = b.acccode
						WHERE  a.compcode = p_compcode
							   AND a.cyear = p_cyear
							   AND a.seq = ip_seq) src
			ON		   (B.COMPCODE = SRC.COMPCODE
						AND B.BUDGYM = SRC.BUDGYM
						AND B.EMPCODE = SRC.EMPCODE
						AND B.ACCCODE = SRC.ACCCODE)
			WHEN MATCHED
			THEN
				UPDATE SET b.addamt = pos_2, b.updatedt = SYSDATE, b.uempcode = p_iempcode;

			MERGE INTO ACBUDGYYE b
			USING	   (SELECT B.COMPCODE, B.BUDGYM, B.EMPCODE, B.ACCCODE, addamt - a.aft2budgamt + a.frm2budgamt AS pos_2
						FROM   ACBUDGYHE a
							   JOIN ACBUDGYYE b
								   ON a.compcode = b.compcode
									  AND a.aftbudgym = b.budgym
									  AND a.empcode = b.empcode
									  AND a.aftacccode = b.acccode
						WHERE  a.compcode = p_compcode
							   AND a.cyear = p_cyear
							   AND a.seq = ip_seq) src
			ON		   (B.COMPCODE = SRC.COMPCODE
						AND B.BUDGYM = SRC.BUDGYM
						AND B.EMPCODE = SRC.EMPCODE
						AND B.ACCCODE = SRC.ACCCODE)
			WHEN MATCHED
			THEN
				UPDATE SET b.addamt = pos_2, b.updatedt = SYSDATE, b.uempcode = p_iempcode;

			UPDATE ACBUDGYHE a
			SET    empcode = p_empcode,
				   chgdate = p_chgdate,
				   chgdiv = p_chgdiv,
				   remark = p_remark,
				   frmbudgym = p_frmbudgym,
				   frmacccode = p_frmacccode,
				   frm1budgamt = p_frm1budgamt,
				   aft1budgamt = p_aft1budgamt,
				   aftbudgym = p_aftbudgym,
				   aftacccode = p_aftacccode,
				   frm2budgamt = p_frm2budgamt,
				   aft2budgamt = p_aft2budgamt,
				   updatedt = SYSDATE,
				   uempcode = p_iempcode
			WHERE  compcode = p_compcode
				   AND cyear = p_cyear
				   AND seq = ip_seq;

			SELECT COUNT(*)
			INTO   v_temp
			FROM   DUAL
			WHERE  EXISTS
					   (SELECT *
						FROM   ACBUDGYYE
						WHERE  compcode = p_compcode
							   AND budgym = p_frmbudgym
							   AND empcode = p_empcode
							   AND acccode = p_frmacccode);


			IF v_temp = 1
			THEN
				UPDATE ACBUDGYYE a
				SET    a.addamt = a.addamt + p_aft1budgamt - p_frm1budgamt, a.updatedt = SYSDATE, a.uempcode = p_iempcode
				WHERE  compcode = p_compcode
					   AND budgym = p_frmbudgym
					   AND empcode = p_empcode
					   AND acccode = p_frmacccode;
			ELSE
				INSERT INTO ACBUDGYYE(compcode,
									  budgym,
									  empcode,
									  acccode,
									  budgamt,
									  addamt,
									  slipamt,
									  remark,
									  insertdt,
									  iempcode)
					(SELECT p_compcode,
							p_frmbudgym,
							p_empcode,
							p_frmacccode,
							0,
							p_aft1budgamt - p_frm1budgamt,
							0,
							'사원별예산변경관리에서 추가',
							SYSDATE,
							p_iempcode
					 FROM	DUAL);
			END IF;

			SELECT COUNT(*)
			INTO   v_temp
			FROM   DUAL
			WHERE  EXISTS
					   (SELECT *
						FROM   ACBUDGYYE
						WHERE  compcode = p_compcode
							   AND budgym = p_aftbudgym
							   AND empcode = p_empcode
							   AND acccode = p_aftacccode);


			IF v_temp = 1
			THEN
				UPDATE ACBUDGYYE a
				SET    a.addamt = a.addamt + p_aft2budgamt - p_frm2budgamt, a.updatedt = SYSDATE, a.uempcode = p_iempcode
				WHERE  compcode = p_compcode
					   AND budgym = p_aftbudgym
					   AND empcode = p_empcode
					   AND acccode = p_aftacccode;
			ELSIF trim(p_aftacccode) is not null
			THEN
				INSERT INTO ACBUDGYYE(compcode,
									  budgym,
									  empcode,
									  acccode,
									  budgamt,
									  addamt,
									  slipamt,
									  remark,
									  insertdt,
									  iempcode)
					(SELECT p_compcode,
							p_aftbudgym,
							p_empcode,
							p_aftacccode,
							0,
							p_aft2budgamt - p_frm2budgamt,
							0,
							'사원별예산변경관리에서 추가',
							SYSDATE,
							p_iempcode
					 FROM	DUAL);
			END IF;
		END;
	ELSIF (p_div = 'D')
	THEN
		MERGE INTO ACBUDGYYE b
		USING	   (SELECT B.COMPCODE, B.BUDGYM, B.EMPCODE, B.ACCCODE, addamt - a.aft1budgamt + a.frm1budgamt AS pos_2
					FROM   ACBUDGYHE a
						   JOIN ACBUDGYYE b
							   ON a.compcode = b.compcode
								  AND a.frmbudgym = b.budgym
								  AND a.empcode = b.empcode
								  AND a.frmacccode = b.acccode
					WHERE  a.compcode = p_compcode
						   AND a.cyear = p_cyear
						   AND a.seq = ip_seq) src
		ON		   (B.COMPCODE = SRC.COMPCODE
					AND B.BUDGYM = SRC.BUDGYM
					AND B.EMPCODE = SRC.EMPCODE
					AND B.ACCCODE = SRC.ACCCODE)
		WHEN MATCHED
		THEN
			UPDATE SET b.addamt = pos_2, b.updatedt = SYSDATE, b.uempcode = p_iempcode;

		MERGE INTO ACBUDGYYE b
		USING	   (SELECT B.COMPCODE, B.BUDGYM, B.EMPCODE, B.ACCCODE, addamt - a.aft2budgamt + a.frm2budgamt AS pos_2
					FROM   ACBUDGYHE a
						   JOIN ACBUDGYYE b
							   ON a.compcode = b.compcode
								  AND a.aftbudgym = b.budgym
								  AND a.empcode = b.empcode
								  AND a.aftacccode = b.acccode
					WHERE  a.compcode = p_compcode
						   AND a.cyear = p_cyear
						   AND a.seq = ip_seq) src
		ON		   (B.COMPCODE = SRC.COMPCODE
					AND B.BUDGYM = SRC.BUDGYM
					AND B.EMPCODE = SRC.EMPCODE
					AND B.ACCCODE = SRC.ACCCODE)
		WHEN MATCHED
		THEN
			UPDATE SET b.addamt = pos_2, b.updatedt = SYSDATE, b.uempcode = p_iempcode;

		DELETE ACBUDGYHE
		WHERE  compcode = p_compcode
			   AND cyear = p_cyear
			   AND seq = ip_seq;
	ELSIF (p_div = 'SC')
	THEN
		DECLARE
			p_preym   VARCHAR2(7);
		BEGIN
			p_preym := TO_CHAR(ADD_MONTHS(TO_DATE(p_budgym, 'YYYY-MM'), -1), 'YYYY-MM');
			-- 이전월의 예산을 재집계
			spACbudg0000MM('TO',
								 p_compcode,
								 '',
								 p_preym,
								 p_preym,
								 p_userid,
								 p_reasondiv,
								 p_reasontext,
								 IO_CURSOR,
								 MESSAGE);

			-- 이전월의 잉여예산을 해당월로 이월
			FOR rec IN (SELECT NVL(MAX(seq), 0) AS alias1
						FROM   ACBUDGYHE
						WHERE  compcode = p_compcode
							   AND cyear = SUBSTR(p_budgym, 0, 4))
			LOOP
				ip_seq := rec.alias1;
			END LOOP;

			EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACBUDG0026P_ACBUDGYYE';

			INSERT INTO VGT.TT_ACBUDG0026P_ACBUDGYYE
				SELECT ROW_NUMBER() OVER (ORDER BY a.empcode, a.acccode) + ip_seq seq, a.empcode, a.acccode, a.budgamt + a.addamt - a.slipamt addamt, NVL(b.budgamt, 0) budgamt
				FROM   ACBUDGYYE a
					   LEFT JOIN ACBUDGYYE b
						   ON a.compcode = b.compcode
							  AND b.budgym = p_budgym
							  AND a.empcode = b.empcode
							  AND a.acccode = b.acccode
				WHERE  a.compcode = p_compcode
					   AND a.budgym = p_preym
					   AND a.budgamt + a.addamt - a.slipamt > 0;

			INSERT INTO ACBUDGYHE(compcode,
								  cyear,
								  seq,
								  empcode,
								  chgdate,
								  chgdiv,
								  remark,
								  frmbudgym,
								  frmacccode,
								  frm1budgamt,
								  aft1budgamt,
								  aftbudgym,
								  aftacccode,
								  frm2budgamt,
								  aft2budgamt,
								  insertdt,
								  iempcode)
				SELECT	 p_compcode,
						 SUBSTR(p_budgym, 0, 4),
						 seq,
						 empcode,
						 p_budgym || '-01',
						 '3', -- 예산조정
						 '전월 잉여예산 이월',
						 p_budgym,
						 acccode,
						 budgamt,
						 budgamt + addamt,
						 p_budgym,
						 '',
						 0,
						 0,
						 SYSDATE,
						 p_iempcode
				FROM	 VGT.TT_ACBUDG0026P_ACBUDGYYE
				ORDER BY seq;

			MERGE INTO ACBUDGYYE b
			USING	   (SELECT B.COMPCODE, B.BUDGYM, B.EMPCODE, B.ACCCODE, a.addamt + b.addamt AS pos_2
						FROM   VGT.TT_ACBUDG0026P_ACBUDGYYE a
							   JOIN ACBUDGYYE b
								   ON b.compcode = p_compcode
									  AND b.budgym = p_budgym
									  AND a.empcode = b.empcode
									  AND a.acccode = b.acccode) src
			ON		   (B.COMPCODE = SRC.COMPCODE
						AND B.BUDGYM = SRC.BUDGYM
						AND B.EMPCODE = SRC.EMPCODE
						AND B.ACCCODE = SRC.ACCCODE)
			WHEN MATCHED
			THEN
				UPDATE SET b.addamt = pos_2, b.updatedt = SYSDATE, b.uempcode = p_iempcode;

			INSERT INTO ACBUDGYYE(compcode,
								  budgym,
								  empcode,
								  acccode,
								  budgamt,
								  addamt,
								  slipamt,
								  remark,
								  insertdt,
								  iempcode)
				(SELECT p_compcode,
						p_budgym,
						a.empcode,
						a.acccode,
						0,
						a.addamt,
						0,
						'사원별예산변경관리에서 추가',
						SYSDATE,
						p_iempcode
				 FROM	VGT.TT_ACBUDG0026P_ACBUDGYYE a
						JOIN ACBUDGYYE b
							ON b.compcode = p_compcode
							   AND b.budgym = p_budgym
							   AND a.empcode = b.empcode
							   AND a.acccode = b.acccode
				 WHERE	b.compcode IS NULL);
		END;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
