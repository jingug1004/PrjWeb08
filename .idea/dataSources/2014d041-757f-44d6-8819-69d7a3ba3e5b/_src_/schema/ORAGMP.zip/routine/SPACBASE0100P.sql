CREATE PROCEDURE        spACbase0100P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACbase0100P
	-- 작 성 자         : 최기홍
	-- 작성일자         : 2010-07-07
	-- 수정일자     :   노영래
	-- E-mail     :   0rae0926@gmail.com
	-- 수정일자     :   2016-12-12
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 계정과목마스터테이블를 등록,수정,삭제,조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			 IN 	VARCHAR2 DEFAULT '',
	p_acccode		 IN 	VARCHAR2 DEFAULT '',
	p_accname		 IN 	VARCHAR2 DEFAULT '',
	p_altcode		 IN 	VARCHAR2 DEFAULT '',
	p_dcdiv 		 IN 	VARCHAR2 DEFAULT '',
	p_hacccode		 IN 	VARCHAR2 DEFAULT '',
	p_budgcode		 IN 	VARCHAR2 DEFAULT '',
	p_ebdgcode		 IN 	VARCHAR2 DEFAULT '',
	p_orduseyn		 IN 	VARCHAR2 DEFAULT '',
	p_remainyn		 IN 	VARCHAR2 DEFAULT '',
	p_returnyn		 IN 	VARCHAR2 DEFAULT '',
	p_budgmngyn 	 IN 	VARCHAR2 DEFAULT '',
	p_budglimityn	 IN 	VARCHAR2 DEFAULT '',
	p_foreignyn 	 IN 	VARCHAR2 DEFAULT '',
	p_prepayyn		 IN 	VARCHAR2 DEFAULT '',
	p_mainyn		 IN 	VARCHAR2 DEFAULT '',
	p_sysuseyn		 IN 	VARCHAR2 DEFAULT '',
	p_judgeyn		 IN 	VARCHAR2 DEFAULT '',
	p_costyn		 IN 	VARCHAR2 DEFAULT '',
	p_reserveyn 	 IN 	VARCHAR2 DEFAULT '',
	p_deleteyn		 IN 	VARCHAR2 DEFAULT '',
	p_remark		 IN 	VARCHAR2 DEFAULT '',
	p_iempcode		 IN 	VARCHAR2 DEFAULT '',
	p_acclevel		 IN 	VARCHAR2 DEFAULT '',
	p_mngclucode	 IN 	VARCHAR2 DEFAULT '',
	p_seq			 IN 	NUMBER DEFAULT 0,
	p_mngcluname	 IN 	VARCHAR2 DEFAULT '',
	p_requireyn 	 IN 	VARCHAR2 DEFAULT '',
	p_userid		 IN 	VARCHAR2 DEFAULT '',
	p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
	p_reasontext	 IN 	VARCHAR2 DEFAULT '',
	MESSAGE 			OUT VARCHAR2,
	IO_CURSOR			OUT TYPES.DATASET
)
AS
	ip_acclevel   VARCHAR2(5) := p_acclevel;
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (UPPER(P_DIV) = 'S1') THEN
		OPEN IO_CURSOR FOR
			SELECT NVL(a.acccode, '') acccode,
				   NVL(a.accname, '') accname,
				   NVL(a.altcode, '') altcode,
				   NVL(a.dcdiv, '') dcdiv,
				   NVL(a.hacccode, '') hacccode,
				   NVL(a.budgcode, '') budgcode,
				   NVL(a.ebdgcode, '') ebdgcode,
				   NVL(a.orduseyn, 'N') orduseyn,
				   NVL(a.remainyn, 'N') remainyn,
				   NVL(a.returnyn, 'N') returnyn,
				   NVL(a.budgmngyn, 'N') budgmngyn,
				   NVL(a.budglimityn, 'N') budglimityn,
				   a.foreignyn, -- (보류) 외화관리여부
				   a.prepayyn, -- (보류) 선급비용관리여부
				   NVL(a.mainyn, 'N') mainyn,
				   a.sysuseyn, -- (보류) 시스템관리여부
				   a.judgeyn, -- (보류) 평가계정여부
				   NVL(a.costyn, 'N') costyn,
				   NVL(a.reserveyn, 'N') reserveyn,
				   a.deleteyn, -- (보류) 삭제여부
				   NVL(a.remark, '') remark,
				   a.insertdt insertdt,
				   NVL(a.iempcode, '') iempcode,
				   a.updatedt updatedt,
				   NVL(a.uempcode, '') uempcode,
				   a.acccode ID,
				   a.hacccode ParentID,
				   b.accname haccname,
				   c.accname budgname,
				   D.accname ebdgname,
				   NVL(a.acclevel, 0) acclevel
			FROM   ACACCM a
				   LEFT JOIN ACACCM b ON a.hacccode = b.acccode
				   LEFT JOIN ACACCM c ON a.budgcode = c.acccode
				   LEFT JOIN ACACCM D ON a.ebdgcode = D.acccode
			WHERE  NVL(a.acccode, ' ') LIKE p_acccode || '%'
				   OR NVL(a.accname, ' ') LIKE '%' || p_acccode || '%'
            ORDER BY  acccode ;


	ELSIF (UPPER(P_DIV) = 'SC') THEN
		OPEN IO_CURSOR FOR
			SELECT NVL(a.acccode, '') acccode,
				   NVL(a.accname, '') accname,
				   NVL(a.altcode, '') altcode,
				   NVL(a.dcdiv, '') dcdiv,
				   NVL(a.hacccode, '') hacccode,
				   NVL(a.budgcode, '') budgcode,
				   NVL(a.ebdgcode, '') ebdgcode,
				   NVL(a.orduseyn, 'N') orduseyn,
				   NVL(a.remainyn, 'N') remainyn,
				   NVL(a.returnyn, 'N') returnyn,
				   NVL(a.budgmngyn, 'N') budgmngyn,
				   NVL(a.budglimityn, 'N') budglimityn,
				   a.foreignyn,
				   a.prepayyn,
				   NVL(a.mainyn, 'N') mainyn,
				   a.sysuseyn,
				   a.judgeyn,
				   NVL(a.costyn, 'N') costyn,
				   NVL(a.reserveyn, 'N') reserveyn,
				   a.deleteyn,
				   NVL(a.remark, '') remark,
				   a.insertdt insertdt,
				   NVL(a.iempcode, '') iempcode,
				   a.updatedt updatedt,
				   NVL(a.uempcode, '') uempcode,
				   a.acccode ID,
				   a.hacccode ParentID,
				   b.accname haccname,
				   '' budgname
			FROM   ACACCM a LEFT JOIN ACACCM b ON a.hacccode = b.acccode
			WHERE  a.acccode = p_acccode;



	ELSIF (UPPER(P_DIV) = 'S2') THEN
		OPEN IO_CURSOR FOR
			SELECT	 NVL(acccode, '') acccode,
					 NVL(mngclucode, '') mngclucode,
					 NVL(dcdiv, '') dcdiv,
					 seq seq,
					 NVL(mngcluname, '') mngcluname,
					 NVL(requireyn, 'N') requireyn,
					 NVL(returnyn, 'N') returnyn,
					 NVL(remainyn, 'N') remainyn,
					 insertdt insertdt,
					 NVL(iempcode, '') iempcode,
					 updatedt updatedt,
					 NVL(uempcode, '') uempcode
			FROM	 ACACCMNGM
			WHERE	 acccode = p_acccode
					 AND dcdiv = '1' -- 차변
			ORDER BY seq;

	ELSIF (UPPER(P_DIV) = 'S3') THEN
		OPEN IO_CURSOR FOR
			SELECT	 NVL(acccode, '') acccode,
					 NVL(mngclucode, '') mngclucode,
					 NVL(dcdiv, '') dcdiv,
					 seq seq,
					 NVL(mngcluname, '') mngcluname,
					 NVL(requireyn, 'N') requireyn,
					 NVL(returnyn, 'N') returnyn,
					 NVL(remainyn, 'N') remainyn,
					 insertdt insertdt,
					 NVL(iempcode, '') iempcode,
					 updatedt updatedt,
					 NVL(uempcode, '') uempcode
			FROM	 ACACCMNGM
			WHERE	 acccode = p_acccode
					 AND dcdiv = '2' -- 대변
			ORDER BY seq;

	-- 키중복체크
	ELSIF (UPPER(P_DIV) = 'SI') THEN
    	SELECT 	COUNT(acccode)
        INTO 	MESSAGE
        FROM   	ACACCM
        WHERE  	acccode = p_acccode;

	-- 단축키중복체크
	ELSIF (UPPER(P_DIV) = 'SALT') THEN
		FOR rec IN (SELECT COUNT(acccode) AS alias1
					FROM   ACACCM
					WHERE  altcode = p_altcode
						   AND NVL(altcode, ' ') > ' '
						   AND acccode <> p_acccode)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;

	-- 키중복체크
	ELSIF (UPPER(P_DIV) = 'SC2') THEN
		FOR rec IN (SELECT COUNT(acccode) AS alias1
					FROM   ACACCMNGM
					WHERE  acccode = p_acccode
						   AND mngclucode = p_mngclucode
						   AND dcdiv = p_dcdiv)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;

	ELSIF (UPPER(P_DIV) = 'SC3') THEN
		--마스터부분 삭제검사
		FOR rec IN (SELECT COUNT(hacccode) AS alias1
					FROM   ACACCM
					WHERE  hacccode = p_hacccode)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;

	ELSIF (UPPER(P_DIV) = 'SB') THEN
		--부서예산과목이 자신계정의 상위계정인지 여부 판단
		FOR rec IN (SELECT COUNT(a.cnt) AS alias1
					FROM   (SELECT 1 cnt
							FROM   ACACCM a
							WHERE  a.acccode = p_hacccode
								   AND a.acccode = p_budgcode
							UNION
							SELECT 1 cnt
							FROM   ACACCM a JOIN ACACCM b ON a.hacccode = b.acccode
							WHERE  a.acccode = p_hacccode
								   AND b.acccode = p_budgcode
							UNION
							SELECT 1
							FROM   ACACCM a
								   JOIN ACACCM b ON a.hacccode = b.acccode
								   JOIN ACACCM c ON b.hacccode = c.acccode
							WHERE  a.acccode = p_hacccode
								   AND c.acccode = p_budgcode
							UNION
							SELECT 1
							FROM   ACACCM a
								   JOIN ACACCM b ON a.hacccode = b.acccode
								   JOIN ACACCM c ON b.hacccode = c.acccode
								   JOIN ACACCM D ON c.hacccode = D.acccode
							WHERE  a.acccode = p_hacccode
								   AND D.acccode = p_budgcode
							UNION
							SELECT 1
							FROM   ACACCM a
								   JOIN ACACCM b ON a.hacccode = b.acccode
								   JOIN ACACCM c ON b.hacccode = c.acccode
								   JOIN ACACCM D ON c.hacccode = D.acccode
								   JOIN ACACCM E ON D.hacccode = E.acccode
							WHERE  a.acccode = p_hacccode
								   AND E.acccode = p_budgcode) a)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;

	ELSIF (UPPER(P_DIV) = 'SE') THEN
		--사원예산과목이 자신계정의 상위계정인지 여부 판단
		FOR rec IN (SELECT COUNT(a.cnt) AS alias1
					FROM   (SELECT 1 cnt
							FROM   ACACCM a
							WHERE  a.acccode = p_hacccode
								   AND a.acccode = p_ebdgcode
							UNION
							SELECT 1 cnt
							FROM   ACACCM a JOIN ACACCM b ON a.hacccode = b.acccode
							WHERE  a.acccode = p_hacccode
								   AND b.acccode = p_ebdgcode
							UNION
							SELECT 1
							FROM   ACACCM a
								   JOIN ACACCM b ON a.hacccode = b.acccode
								   JOIN ACACCM c ON b.hacccode = c.acccode
							WHERE  a.acccode = p_hacccode
								   AND c.acccode = p_ebdgcode
							UNION
							SELECT 1
							FROM   ACACCM a
								   JOIN ACACCM b ON a.hacccode = b.acccode
								   JOIN ACACCM c ON b.hacccode = c.acccode
								   JOIN ACACCM D ON c.hacccode = D.acccode
							WHERE  a.acccode = p_hacccode
								   AND D.acccode = p_ebdgcode
							UNION
							SELECT 1
							FROM   ACACCM a
								   JOIN ACACCM b ON a.hacccode = b.acccode
								   JOIN ACACCM c ON b.hacccode = c.acccode
								   JOIN ACACCM D ON c.hacccode = D.acccode
								   JOIN ACACCM E ON D.hacccode = E.acccode
							WHERE  a.acccode = p_hacccode
								   AND E.acccode = p_ebdgcode) a)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;

	ELSIF (UPPER(P_DIV) = 'I1') THEN
		FOR rec IN (SELECT acclevel + 1 AS alias1
					FROM   ACACCM
					WHERE  acccode = p_hacccode)
		LOOP
			ip_acclevel := rec.alias1;
		END LOOP;

		INSERT INTO ACACCM(acccode,
						   accname,
						   altcode,
						   dcdiv,
						   acclevel,
						   hacccode,
						   budgcode,
						   ebdgcode,
						   orduseyn,
						   remainyn,
						   returnyn,
						   budgmngyn,
						   budglimityn,
						   foreignyn,
						   prepayyn,
						   mainyn,
						   sysuseyn,
						   judgeyn,
						   costyn,
						   reserveyn,
						   deleteyn,
						   remark,
						   insertdt,
						   iempcode)
		VALUES		(p_acccode,
					 p_accname,
					 p_altcode,
					 p_dcdiv,
					 ip_acclevel,
					 p_hacccode,
					 p_budgcode,
					 p_ebdgcode,
					 p_orduseyn,
					 p_remainyn,
					 p_returnyn,
					 p_budgmngyn,
					 p_budglimityn,
					 p_foreignyn,
					 p_prepayyn,
					 p_mainyn,
					 p_sysuseyn,
					 p_judgeyn,
					 p_costyn,
					 p_reserveyn,
					 'N', --isnull(NULLIF(@deleteyn,''),'N')
					 p_remark,
					 SYSDATE,
					 p_iempcode);

	ELSIF (UPPER(P_DIV) = 'I2') THEN
		INSERT INTO ACACCMNGM(acccode,
							  mngclucode,
							  dcdiv,
							  seq,
							  mngcluname,
							  requireyn,
							  returnyn,
							  remainyn,
							  insertdt,
							  iempcode)
		VALUES		(p_acccode,
					 p_mngclucode,
					 p_dcdiv,
					 p_seq,
					 p_mngcluname,
					 p_requireyn,
					 p_returnyn,
					 p_remainyn,
					 SYSDATE,
					 p_iempcode);

	ELSIF (UPPER(P_DIV) = 'U1') THEN
		FOR rec IN (SELECT acclevel + 1 AS alias1
					FROM   ACACCM
					WHERE  acccode = p_hacccode)
		LOOP
			ip_acclevel := rec.alias1;
		END LOOP;

		UPDATE ACACCM
		SET    accname = p_accname,
			   altcode = p_altcode,
			   dcdiv = p_dcdiv,
			   acclevel = ip_acclevel,
			   hacccode = p_hacccode,
			   budgcode = p_budgcode,
			   ebdgcode = p_ebdgcode,
			   orduseyn = p_orduseyn,
			   remainyn = p_remainyn,
			   returnyn = p_returnyn,
			   budgmngyn = p_budgmngyn,
			   budglimityn = p_budglimityn,
			   foreignyn = p_foreignyn,
			   prepayyn = p_prepayyn,
			   mainyn = p_mainyn,
			   sysuseyn = p_sysuseyn,
			   judgeyn = p_judgeyn,
			   costyn = p_costyn,
			   reserveyn = p_reserveyn,
			   deleteyn = p_deleteyn,
			   remark = p_remark,
			   updatedt = SYSDATE,
			   uempcode = p_iempcode
		WHERE  acccode = p_acccode;

	ELSIF (UPPER(P_DIV) = 'U2') THEN
		UPDATE ACACCMNGM
		SET    seq = p_seq,
			   mngcluname = p_mngcluname,
			   requireyn = p_requireyn,
			   returnyn = p_returnyn,
			   remainyn = p_remainyn,
			   updatedt = SYSDATE,
			   uempcode = p_iempcode
		WHERE  acccode = p_acccode
			   AND mngclucode = p_mngclucode
			   AND dcdiv = p_dcdiv;

	ELSIF (UPPER(P_DIV) = 'D1') THEN
		DELETE ACACCM
		WHERE  acccode = p_acccode;

	ELSIF (UPPER(P_DIV) = 'D2') THEN
		DELETE ACACCMNGM
		WHERE  acccode = p_acccode;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
