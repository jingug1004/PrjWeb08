CREATE PROCEDURE        spACass0010P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACass0010P
 -- 작 성 자         : 이영재
 -- 작성일자         : 2011-03-08
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-27
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 자산등록을 등록,수정,삭제,조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_plantcode     IN  VARCHAR2 DEFAULT '' ,
    p_asscode       IN  VARCHAR2 DEFAULT '' ,
    p_assname       IN  VARCHAR2 DEFAULT '' ,
    p_assdiv        IN  VARCHAR2 DEFAULT '' ,
    p_asscls        IN  VARCHAR2 DEFAULT '' ,
    p_strdate       IN  VARCHAR2 DEFAULT '' ,
    p_enddate       IN  VARCHAR2 DEFAULT '' ,
    p_lifeyear      IN  NUMBER   DEFAULT 0 ,
    p_deprate       IN  FLOAT    DEFAULT 0 ,
    p_mngdeptcode   IN  VARCHAR2 DEFAULT '' ,
    p_acccode       IN  VARCHAR2 DEFAULT '' ,
    p_dacccode      IN  VARCHAR2 DEFAULT '' ,
    p_gacccode      IN  VARCHAR2 DEFAULT '' ,
    p_keeprmk       IN  VARCHAR2 DEFAULT '' ,
    p_workdiv       IN  VARCHAR2 DEFAULT '' ,
    p_masscode      IN  VARCHAR2 DEFAULT '' ,
    p_acqdiv        IN  VARCHAR2 DEFAULT '' ,
    p_deprdate      IN  VARCHAR2 DEFAULT '' ,
    p_depryn        IN  VARCHAR2 DEFAULT '' ,
    p_deprdiv       IN  VARCHAR2 DEFAULT '' ,
    p_remark        IN  VARCHAR2 DEFAULT '' ,
    p_deprendyn     IN  VARCHAR2 DEFAULT '' ,
    p_assstate      IN  VARCHAR2 DEFAULT '' ,
    p_curassqty     IN  FLOAT    DEFAULT 0 ,
    p_curassamt     IN  FLOAT    DEFAULT 0 ,
    p_lstassamt     IN  FLOAT    DEFAULT 0 ,
    p_subsidyn      IN  VARCHAR2 DEFAULT '' ,
    p_subsidrmk     IN  VARCHAR2 DEFAULT '' ,
    p_subsidacccode IN  VARCHAR2 DEFAULT '' ,
    p_subsidassamt  IN  FLOAT    DEFAULT 0 ,
    p_closediv      IN  VARCHAR2 DEFAULT '' ,
    p_asschgdiv     IN  VARCHAR2 DEFAULT '' ,
    p_iempcode      IN  VARCHAR2 DEFAULT '' ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    ip_compcode VARCHAR2(3)  := p_compcode;
    ip_asscode  VARCHAR2(30) := p_asscode;

    p_ichkassm NUMBER;
    p_ichkassd NUMBER;
    p_ichkdepr NUMBER;

    r_message VARCHAR(100) := '';

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    FOR  rec IN (   SELECT  compcode -- 법인코드 확인
                    FROM    CMPLANTM
                    WHERE   plantcode LIKE '%' AND ROWNUM <= 1
    )
    LOOP
        ip_compcode := rec.compcode ;
    END LOOP;


    IF ( UPPER(p_div) = UPPER('S') ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  NVL(a.compcode, '') compcode  ,
                    NVL(a.asscode,'') asscode  ,
                    NVL(a.assname, '') assname  ,
                    NVL(a.assdiv, '') assdiv  ,
                    NVL(a.asscls, '') asscls  ,
                    NVL(a.strdate, '') strdate  ,
                    NVL(a.enddate, '') enddate  ,
                    NVL(a.lifeyear, 0) lifeyear  ,
                    NVL(a.deprate, 0) deprate  ,
                    NVL(a.plantcode, '') plantcode  ,
                    NVL(a.mngdeptcode,  '') mngdeptcode  ,
                    NVL(a.acccode, '') acccode  ,
                    NVL(a.dacccode, '') dacccode  ,
                    NVL(a.gacccode, '') gacccode  ,
                    NVL(a.keeprmk, '') keeprmk  ,
                    NVL(a.workdiv, '') workdiv  ,
                    NVL(a.masscode, '') masscode  ,
                    NVL(a.acqdiv, '') acqdiv  ,
                    NVL(a.deprdate, '') deprdate  ,
                    NVL(a.depryn, '') depryn  ,
                    NVL(a.deprdiv, '') deprdiv  ,
                    NVL(a.remark, '') remark  ,
                    NVL(a.deprendyn, '') deprendyn  ,
                    NVL(a.assstate, '') assstate  ,
                    NVL(a.curassqty, 0) curassqty  ,
                    NVL(a.curassamt, 0) curassamt  ,
                    NVL(a.lstassamt, 0) lstassamt  ,
                    NVL(a.subsidyn, '') subsidyn  ,
                    NVL(a.subsidrmk, '') subsidrmk  ,
                    NVL(a.subsidacccode, '') subsidacccode  ,
                    NVL(a.subsidassamt, 0) subsidassamt  ,
                    NVL(E.deptname, '') mngdeptname  ,
                    NVL(f.accname, '') accname  ,
                    NVL(M.equipmentkorname, '') massname  ,
                    NVL(P.plantname, '') plantname  ,
                    NVL(ac76.divname, '') assstatename  ,
                    NVL(ac71.divname, '') assclsname  ,
                    NVL(ac70.divname, '') assdivname  ,
                    NVL(accd.accname, '') daccname  ,
                    NVL(accg.accname, '') gaccname
            FROM    ACASSM a
                    LEFT JOIN CMDEPTM E          ON a.mngdeptcode = E.deptcode
                    LEFT JOIN ACACCM f           ON a.acccode = f.acccode
                    LEFT JOIN PDEQUIPMENTM M     ON M.equipmentcode = a.masscode
                    LEFT JOIN CMPLANTM P         ON P.plantcode = a.plantcode
                    LEFT JOIN CMCOMMONM ac76     ON ac76.cmmcode = 'AC76'
                                                    AND ac76.divcode = a.assstate
                    LEFT JOIN CMCOMMONM ac71     ON ac71.cmmcode = 'AC71' --자산분류
                                                    AND ac71.divcode = a.asscls
                    LEFT JOIN CMCOMMONM ac70     ON ac70.cmmcode = 'AC70' --자산형태
                                                    AND ac70.divcode = a.assdiv
                    LEFT JOIN ACACCM accd        ON accd.acccode = a.dacccode
                    LEFT JOIN ACACCM accg        ON accg.acccode = a.gacccode
            WHERE   a.compcode = ip_compcode
                    AND a.asscls LIKE p_asscls || '%'
                    AND a.assdiv LIKE p_assdiv || '%'
                    AND a.assstate LIKE p_assstate || '%'
            ORDER BY a.assdiv, a.asscode ;

    ELSIF ( UPPER(p_div) = UPPER('ASS') ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  divcode ,
                    cmmname ,
                    NVL(filter1, '') acccode  ,
                    NVL(filter2, '') gacccode
            FROM    CMCOMMONM
            WHERE   cmmcode = 'AC70'
                    AND divcode = p_assdiv ;

    ELSIF ( UPPER(p_div) = UPPER('SC') ) THEN

        MESSAGE := '' ;

        FOR  rec IN (   SELECT  COUNT(asscode)   AS alias1
                       FROM    ACASSM
                       WHERE   compcode = ip_compcode
                                AND asscode = ip_asscode
        )
        LOOP
            MESSAGE := rec.alias1 ;
        END LOOP;

    ELSIF ( UPPER(p_div) = UPPER('CN') ) THEN

        MESSAGE := '' ;

        FOR  rec IN (   SELECT  divcode || '-' || SUBSTR(p_strdate, 0, 4) || '-'  AS alias1
                        FROM    CMCOMMONM
                        WHERE   cmmcode = 'AC70'
                                AND divcode = p_assdiv
        )
        LOOP
            ip_asscode := rec.alias1 ;
        END LOOP;

        FOR  rec IN (   SELECT  ip_asscode || SUBSTR('00' || TO_CHAR(NVL(MAX(SUBSTR(asscode, -3, 3))  + 1, 1)), -3, 3)  AS alias1
                        FROM    ACASSM
                        WHERE   compcode = ip_compcode
                                AND asscode LIKE ip_asscode || '%'
        )
        LOOP
            MESSAGE := rec.alias1 ;
        END LOOP;

    ELSIF ( UPPER(p_div) = UPPER('I') ) THEN

        INSERT INTO ACASSM (
            compcode
            , asscode
            , assname
            , assdiv
            , asscls
            , strdate
            , enddate
            , lifeyear
            , deprate
            , plantcode
            , mngdeptcode
            , acccode
            , dacccode
            , gacccode
            , keeprmk
            , workdiv
            , masscode
            , acqdiv
            , deprdate
            , depryn
            , deprdiv
            , remark
            , deprendyn
            , assstate
            , curassqty
            , curassamt
            , lstassamt
            , subsidyn
            , subsidrmk
            , subsidacccode
            , subsidassamt
            , insertdt
            , iempcode )
        VALUES (
            ip_compcode
            , ip_asscode
            , p_assname
            , p_assdiv
            , p_asscls
            , p_strdate
            , p_enddate
            , p_lifeyear
            , p_deprate
            , p_plantcode
            , p_mngdeptcode
            , p_acccode
            , p_dacccode
            , p_gacccode
            , p_keeprmk
            , p_workdiv
            , p_masscode
            , p_acqdiv
            , p_deprdate
            , p_depryn
            , p_deprdiv
            , p_remark
            , p_deprendyn
            , p_assstate
            , p_curassqty
            , p_curassamt
            , p_lstassamt
             , p_subsidyn
             , p_subsidrmk
             , p_subsidacccode
             , p_subsidassamt
             , SYSDATE
             , p_iempcode );

    ELSIF ( UPPER(p_div) = UPPER('U') ) THEN

        UPDATE  ACASSM
        SET     compcode = ip_compcode,
                asscode = ip_asscode,
                assname = p_assname,
                assdiv = p_assdiv,
                asscls = p_asscls,
                strdate = p_strdate,
                enddate = p_enddate,
                lifeyear = p_lifeyear,
                deprate = p_deprate,
                plantcode = p_plantcode,
                mngdeptcode = p_mngdeptcode,
                acccode = p_acccode,
                dacccode = p_dacccode,
                gacccode = p_gacccode,
                keeprmk = p_keeprmk,
                workdiv = p_workdiv,
                masscode = p_masscode,
                acqdiv = p_acqdiv,
                deprdate = p_deprdate,
                depryn = p_depryn,
                deprdiv = p_deprdiv,
                remark = p_remark,
                deprendyn = p_deprendyn,
                assstate = p_assstate,
                curassqty = p_curassqty,
                curassamt = p_curassamt,
                lstassamt = p_lstassamt,
                subsidyn = p_subsidyn,
                subsidrmk = p_subsidrmk,
                subsidacccode = p_subsidacccode,
                subsidassamt = p_subsidassamt,
                updatedt = SYSDATE,
                uempcode = p_iempcode
        WHERE   compcode = ip_compcode
                AND asscode = ip_asscode;

    ELSIF ( UPPER(p_div) = UPPER('SCD') ) THEN

        -- 삭제 시 점검
        FOR  rec IN (   SELECT  COUNT(asscode)   AS alias1
                        FROM    ACASSM
                        WHERE   compcode = ip_compcode
                                AND asscode = ip_asscode) LOOP
        p_ichkassm := rec.alias1   ;
        END LOOP;


        FOR  rec IN (   SELECT  COUNT(asscode)   AS alias1
                        FROM    ACASSD
                        WHERE   compcode = ip_compcode
                                AND asscode = ip_asscode) LOOP
        p_ichkassd := rec.alias1   ;
        END LOOP;


        FOR  rec IN (   SELECT  COUNT(asscode)   AS alias1
                        FROM    ACASSDEPR
                        WHERE   compcode = ip_compcode
                                AND asscode = ip_asscode) LOOP
        p_ichkdepr := rec.alias1   ;
        END LOOP;


        IF ( p_ichkassd > 0 OR p_ichkdepr > 0 ) THEN
            MESSAGE := 'N' ;
        ELSE
            MESSAGE := 'Y' ;
        END IF;

    ELSIF ( UPPER(p_div) = UPPER('D') ) THEN

        DELETE  ACASSDEPR
        WHERE   compcode = ip_compcode
                AND asscode = ip_asscode;


        DELETE  ACASSD
        WHERE   compcode = ip_compcode
                AND asscode = ip_asscode;


        DELETE  ACASSM
        WHERE   compcode = ip_compcode
                AND asscode = ip_asscode;

    ELSIF ( UPPER(p_div) = UPPER('SSCH') ) THEN

        --변동내역 확인
        OPEN  IO_CURSOR FOR

            SELECT  a.asscode asscode  ,
                    a.closediv closediv  ,
                    ac02.divname closedivname  ,
                    a.chgdate chgdate  ,
                    a.seq seq  ,
                    ac77.divname asschgdivname  ,
                    a.keeprmk keeprmk  ,
                    a.custcode custcode  ,
                    c.custname custname  ,
                    a.deptcode deptcode  ,
                    D.deptname deptname  ,
                    a.curassamt + CASE WHEN a.asschgdiv IN ( '01','02' ) THEN -a.chgamt ELSE a.chgamt END gucurassamt  ,
                    a.chgamt ,
                    a.curassamt curassamt  ,
                    a.decslipinno decslipinno
            FROM    ACASSD a
                    LEFT JOIN CMCOMMONM ac02 ON ac02.cmmcode = 'AC02'
                                                AND ac02.divcode = a.closediv
                    LEFT JOIN CMCOMMONM ac77 ON ac77.cmmcode = 'AC77'
                                                AND ac77.divcode = a.asschgdiv
                    LEFT JOIN CMCUSTM c      ON c.custcode = a.custcode
                    LEFT JOIN CMDEPTM D      ON D.deptcode = a.deptcode
            WHERE   a.compcode = ip_compcode
                    AND a.asscode = ip_asscode
                    AND a.closediv LIKE p_closediv || '%'
                    AND a.asschgdiv LIKE p_asschgdiv || '%' ;

    ELSIF ( UPPER(p_div) = UPPER('SSDE') ) THEN

        --상각내역 확인
        OPEN  IO_CURSOR FOR

            SELECT  a.closediv closediv  ,
                    ac02.divname closedivname  ,
                    a.assym assym  ,
                    a.caldiv caldiv  ,
                    ac78.divname caldivname  ,
                    a.lifeyear lifeyear  ,
                    a.curassamt - a.revamt - a.expamt + a.salamt fnassamt  ,
                    a.revamt + a.expamt incassamt  ,
                    a.salamt decassamt  ,
                    a.curassamt lsassamt  ,
                    a.predepamt bsdepramt  ,
                    a.depamt depamt  ,
                    a.drpamt drpamt  ,
                    a.predepamt + a.depamt - a.drpamt bedepramt  ,
                    a.curassamt - a.predepamt - a.depamt + a.drpamt assamt  ,
                    a.decslipinno decslipinno
            FROM    ACASSDEPR a
                    LEFT JOIN CMCOMMONM ac02 ON ac02.cmmcode = 'AC02'
                                                AND ac02.divcode = a.closediv
                    LEFT JOIN CMCOMMONM ac78 ON ac78.cmmcode = 'AC78'
                                                AND ac78.divcode = a.caldiv
            WHERE   a.compcode = ip_compcode
                    AND a.asscode = ip_asscode
                    AND a.closediv LIKE p_closediv || '%'
                    AND SUBSTR(a.assym, -2, 2) = '12' ;

    END IF;


    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
