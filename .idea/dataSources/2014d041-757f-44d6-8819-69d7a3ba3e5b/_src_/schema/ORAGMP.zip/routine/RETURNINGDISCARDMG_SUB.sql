CREATE PROCEDURE ReturningDiscardMG_Sub 
(
    p_div           IN      VARCHAR2    := '', 
    p_plantcode     IN      VARCHAR2    := '',
    p_frdate       IN      VARCHAR2    := '',
    p_todate        IN      VARCHAR2    := '',
    
    p_userid         IN     VARCHAR2 DEFAULT '',
    p_reasondiv      IN     VARCHAR2 DEFAULT '',
    p_reasontext     IN     VARCHAR2 DEFAULT '',
    MESSAGE             OUT VARCHAR2,
    IO_CURSOR            OUT TYPES.DATASET
)
AS
    ip_frdate   VARCHAR2(10)    := replace(p_frdate, '-', '');
    ip_todate   VARCHAR2(10)    := replace(p_todate, '-', '');
BEGIN
    
    MESSAGE := '데이터 확인';

    INSERT INTO ATINFO(userid, reasondiv, reasontext)
         VALUES (p_userid, p_reasondiv, p_reasontext);
   
   IF(p_div = 'S') THEN
    
        OPEN IO_CURSOR FOR
   
           SELECT A.BANPUM_YMD ,      --반품일자
                  A.CUST_ID    ,      --거래처코드
                  A.ITEM_ID    ,      --제품코드
                  A.PROD_NO    ,      --제조번호
                  A.EXPIRY_YMD ,      --유효일자(시용기한)
                  A.BANPUM_TYPE,      --반품유형
                  A.BANPUM_QTY ,      --반품수량
                  A.BARCODE_QTY,      --바코드수량
                  A.MANUAL_QTY        --수기수량
             FROM RFID_USER.BANPUM_INFO A,
                  SALE0003 B,
                  SALE0004 C
            WHERE A.CUST_ID = B.CUST_ID
              AND A.ITEM_ID = C.ITEM_ID
              AND A.DELETE_MARK = '0'
              AND A.BANPUM_YMD BETWEEN ip_frdate AND ip_todate
              AND A.PAEGI_YMD IS NULL
         ORDER BY A.ITEM_ID, A.PROD_NO, A.BANPUM_YMD, A.CUST_ID;
         
   END IF;
END ReturningDiscardMG_Sub;
/
