CREATE PROCEDURE        ReturningDiscardMG_Sub 
(
    p_div           IN      VARCHAR2    := '', 
    p_plantcode     IN      VARCHAR2    := '',
    p_frdate       IN      VARCHAR2    := '',
    p_todate        IN      VARCHAR2    := '',
    
    p_userid         IN     VARCHAR2 DEFAULT '',
    p_reasondiv      IN     VARCHAR2 DEFAULT '',
    p_reasontext     IN     VARCHAR2 DEFAULT '',
    MESSAGE             OUT VARCHAR2,
    IO_CURSOR            OUT TYPES.DATASET
)
AS
    
BEGIN
    
    MESSAGE := '데이터 확인';

    INSERT INTO ATINFO(userid, reasondiv, reasontext)
         VALUES (p_userid, p_reasondiv, p_reasontext);
         
   IF(p_div = 'S')    THEN
    
      OPEN IO_CURSOR FOR
         SELECT A.BANPUM_YMD , --반품일자
                A.CUST_ID , --거래처코드
                A.ITEM_ID , --제품코드
                A.PROD_NO , --제조번호
                A.EXPIRY_YMD , --사용기한
                A.BANPUM_TYPE , --반품유형
                A.BANPUM_QTY , --반품수량
                A.BARCODE_QTY , --바코드수량
                A.MANUAL_QTY , --수기수량
                B.CUSTNAME , --상호
                C.ITEMNAME --제품명
                FROM RFID_USER.BANPUM_INFO A, --반품처리
                CMCUSTM B, --거래처코드
                CMITEMM C --제품코드
                WHERE A.CUST_ID = B.CUSTCODE
                  AND A.ITEM_ID = C.ITEMCODE
                  AND A.DELETE_MARK = '0'
                  AND A.BANPUM_YMD BETWEEN replace(p_frdate,'-','') AND replace(p_todate,'-','') --(20170101 형식)
                  AND A.PAEGI_YMD IS NULL
             ORDER BY A.ITEM_ID, A.PROD_NO, A.EXPIRY_YMD, A.CUST_ID;

    
    END IF;
    
    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
   
END ReturningDiscardMG_Sub;
/
