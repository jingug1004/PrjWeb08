CREATE FUNCTION fnLoanPayAmt_DayCnt(
	-- ---------------------------------------------------------------
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2017-02-24
    -- ---------------------------------------------------------------
	p_compcode 	IN 	VARCHAR2, 	-- 회사코드
	p_loanno 	IN 	VARCHAR2, 	-- 차입금코드
	p_paydt 	IN 	VARCHAR2, 		-- 특정일자
	p_dayflag 	IN 	NUMBER
)
	RETURN NUMBER
AS
	p_strdt 	VARCHAR2(10);		-- 계산시작일
	p_enddt  	VARCHAR2(10);		-- 계산종료일
	p_daycnt   	NUMBER; 	-- 이자계산일수
	ip_paydt	VARCHAR2(10);
-- 시작일자생성flag
BEGIN


	-- 선납인경우 말일계산
	FOR rec IN (SELECT CASE
						   WHEN a.irrepaysep = '4'
								OR NVL(b.expdate, a.expdate) <= fnDateConv2(TO_CHAR(ADD_MONTHS(TO_DATE(p_paydt,'YYYY-MM-DD'),CASE a.irrepaysep WHEN '2' THEN 3 WHEN '3' THEN 6 ELSE 1 END),'YYYY-MM') || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3))
						   THEN
							   fnNextWorkingDateInVarchar(0, NVL(b.expdate, a.expdate))
						   WHEN a.hrcalcdiv IN ('1', '2')
						   THEN
							   TO_DATE(fnDateConv2(TO_CHAR(ADD_MONTHS(TO_DATE(p_paydt,'YYYY-MM-DD'),CASE a.irrepaysep WHEN '2' THEN 3 WHEN '3' THEN 6 ELSE 1 END),'YYYY-MM') || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3)),'YYYY-MM-DD')
						   ELSE
							   fnNextWorkingDateInVarchar(0, fnDateConv2(TO_CHAR(ADD_MONTHS(TO_DATE(p_paydt,'YYYY-MM-DD'),CASE a.irrepaysep WHEN '2' THEN 3 WHEN '3' THEN 6 ELSE 1 END),'YYYY-MM') || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3)))
					   END
						   AS alias1
				FROM   ACLOANM a
					   LEFT JOIN (SELECT a.compcode, a.loanno, a.expdate
								  FROM	 ACLOANC a
										 JOIN (SELECT	compcode, loanno, MAX(changedate) changedate
											   FROM 	ACLOANC
											   WHERE	compcode = p_compcode
														AND changedate <= p_paydt
														AND NVL(expdate,' ') <> ' '
											   GROUP BY compcode, loanno) b
											 ON a.compcode = b.compcode
												AND a.loanno = b.loanno
												AND a.changedate = b.changedate) b
						   ON a.compcode = b.compcode
							  AND a.loanno = b.loanno
				WHERE  a.compcode = p_compcode
					   AND a.loanno = p_loanno)
	LOOP
		p_enddt := TO_CHAR(rec.alias1,'YYYY-MM-DD');
	END LOOP;

	-- 이자계산 시작일과 종료일 등을 산출
	FOR rec
		IN (SELECT CASE
					   WHEN a.irrepaydiv = '1'
					   THEN
						   CASE
							   WHEN NVL(a.irindate,' ') = ' '
									AND p_dayflag = 0
							   THEN
								   TO_DATE(a.strdate,'YYYY-MM-DD')
							   ELSE
								   TO_DATE(CASE WHEN a.hrcalcdiv <> '3' THEN fnDateConv2(SUBSTR(a.irindate, 0, 7) || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3)) ELSE a.irindate END,'YYYY-MM-DD') + 1
						   END
					   WHEN a.irrepaydiv = '2'
					   THEN
						   CASE
							   WHEN NVL(a.irindate,' ') = ' '
									AND p_dayflag = 0
							   THEN
								   TO_DATE(a.strdate,'YYYY-MM-DD')
							   ELSE
								   TO_DATE(CASE WHEN a.hrcalcdiv <> '3' THEN fnDateConv2(SUBSTR(a.irindate, 0, 7) || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3)) ELSE a.irindate END,'YYYY-MM-DD')
						   END
					   WHEN a.irrepaydiv = '3'
					   THEN
							 CASE
								 WHEN NVL(a.irindate,' ') = ' '
									  AND p_dayflag = 0
								 THEN
									 TO_DATE(a.strdate,'YYYY-MM-DD')
								 ELSE
									 TO_DATE(CASE WHEN a.hrcalcdiv <> '3' THEN fnDateConv2(SUBSTR(a.irindate, 0, 7) || SUBSTR(NVL(TRIM(a.irrepaydate), a.strdate), -3, 3)) ELSE a.irindate END,'YYYY-MM-DD')
							 END
						   + 1
					   WHEN a.irrepaydiv = '4'
					   THEN
						   CASE
							   WHEN NVL(a.irindate,' ') = ' '
									AND p_dayflag = 0
							   THEN
								   TO_DATE(a.strdate,'YYYY-MM-DD')
							   ELSE
								   TO_DATE(p_paydt,'YYYY-MM-DD') + 1
						   END
					   WHEN a.irrepaydiv = '5'
					   THEN
						   CASE
							   WHEN NVL(a.irindate,' ') = ' '
									AND p_dayflag = 0
							   THEN
								   TO_DATE(a.strdate,'YYYY-MM-DD')
							   ELSE
								   TO_DATE(p_paydt,'YYYY-MM-DD')
						   END
					   WHEN a.irrepaydiv = '6'
					   THEN
							 CASE
								 WHEN NVL(a.irindate,' ') = ' '
									  AND p_dayflag = 0
								 THEN
									 TO_DATE(a.strdate,'YYYY-MM-DD')
								 ELSE
									 TO_DATE(p_paydt,'YYYY-MM-DD')
							 END
						   + 1
					   WHEN a.irrepaydiv = '7'
					   THEN
							 CASE
								 WHEN NVL(a.irindate,' ') = ' '
									  AND p_dayflag = 0
								 THEN
									 TO_DATE(a.strdate,'YYYY-MM-DD')
								 ELSE
									 TO_DATE(a.irindate,'YYYY-MM-DD')
							 END
						   + 1
				   END
					   AS alias1,
				   CASE
					   WHEN a.irrepaydiv = '1'
					   THEN
						   CASE WHEN NVL(b.expdate, a.expdate) <= p_paydt THEN TO_DATE(p_paydt,'YYYY-MM-DD') - 1 ELSE TO_DATE(p_paydt,'YYYY-MM-DD') END
					   WHEN a.irrepaydiv = '2'
					   THEN
						   TO_DATE(p_paydt,'YYYY-MM-DD') - 1
					   WHEN a.irrepaydiv = '3'
					   THEN
						   TO_DATE(p_paydt,'YYYY-MM-DD')
					   WHEN a.irrepaydiv = '4'
					   THEN
						   CASE WHEN NVL(b.expdate, a.expdate) < p_enddt THEN TO_DATE(NVL(b.expdate, a.expdate),'YYYY-MM-DD') ELSE TO_DATE(p_enddt,'YYYY-MM-DD') END
					   WHEN a.irrepaydiv = '5'
					   THEN
						   TO_DATE(p_enddt,'YYYY-MM-DD') - 1
					   WHEN a.irrepaydiv = '6'
					   THEN
						   TO_DATE(p_enddt,'YYYY-MM-DD')
					   WHEN a.irrepaydiv = '7'
					   THEN
						   TO_DATE(p_paydt,'YYYY-MM-DD')
				   END
					   AS alias2
			FROM   ACLOANM a
				   LEFT JOIN (SELECT a.compcode, a.loanno, a.expdate
							  FROM	 ACLOANC a
									 JOIN (SELECT	compcode, loanno, MAX(changedate) changedate
										   FROM 	ACLOANC
										   WHERE	compcode = p_compcode
													AND changedate <= p_paydt
													AND expdate <> ' '
										   GROUP BY compcode, loanno) b
										 ON a.compcode = b.compcode
											AND a.loanno = b.loanno
											AND a.changedate = b.changedate) b
					   ON a.compcode = b.compcode
						  AND a.loanno = b.loanno
			WHERE  a.compcode = p_compcode
				   AND a.loanno = p_loanno)
	LOOP
		p_strdt := TO_CHAR(rec.alias1,'YYYY-MM-DD');
		p_enddt := TO_CHAR(rec.alias2,'YYYY-MM-DD');
	END LOOP;

	p_daycnt := fndatediff('DAY', p_strdt, TO_CHAR(TO_DATE(p_enddt,'YYYY-MM-DD') + 1,'YYYY-MM-DD'));
	RETURN (p_daycnt);
EXCEPTION
	WHEN OTHERS
	THEN RETURN NULL;
END;
/
