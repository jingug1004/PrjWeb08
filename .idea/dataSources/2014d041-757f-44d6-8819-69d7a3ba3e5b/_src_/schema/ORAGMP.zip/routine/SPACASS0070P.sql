CREATE PROCEDURE        spACass0070P(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACass0070P
	-- 작 성 자         : 최용석
	-- 작성일자         : 2011-10-08
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-27
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 고정자산 감가상각 전표처리
	-- ---------------------------------------------------------------

	p_div			IN	VARCHAR2 DEFAULT '',
	p_compcode		IN	VARCHAR2 DEFAULT '',
	p_plantcode 	IN	VARCHAR2 DEFAULT '',
	p_closediv		IN	VARCHAR2 DEFAULT '', --결산구분
	p_caldiv		IN	VARCHAR2 DEFAULT '', --계산구분
	p_assym 		IN	VARCHAR2 DEFAULT '', --처리년월
	p_iempcode		IN	VARCHAR2 DEFAULT '',
	p_userid		IN	VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	VARCHAR2 DEFAULT '',
	p_reasontext	IN	VARCHAR2 DEFAULT '',
	MESSAGE 		OUT VARCHAR2,
	IO_CURSOR		OUT TYPES.DATASET
)
AS
	-- 조회기간 설정
	p_mathod		VARCHAR2(10);
	p_strym 		VARCHAR2(7);
	p_strdate		VARCHAR2(10);
	p_enddate		VARCHAR2(10);
	p_acautorcode	VARCHAR2(10);
	p_crttype		VARCHAR2(10);
	p_mngclucode	VARCHAR2(5);

	p_slipdiv		VARCHAR2(5);
	p_slipnum		VARCHAR2(5);
	p_slipno		VARCHAR2(20);
	p_deptcode		VARCHAR2(20);
	p_remark		VARCHAR2(100);
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


	-- 상각방법 설정
	p_mathod := '년상각';

	FOR rec IN (SELECT value2
				FROM   SYSPARAMETERMANAGE a
				WHERE  parametercode = 'acassacc')
	LOOP
		p_mathod := rec.value2;
	END LOOP;



	-- 계산기간 설정
	p_strym := SUBSTR(p_assym, 0, 4) || '-01';

	FOR rec IN (SELECT MAX(SUBSTR(curstrdate, 0, 7)) AS alias1
				FROM   ACSESSION a
				WHERE  compcode = p_compcode
					   AND cyear <= SUBSTR(p_assym, 0, 4))
	LOOP
		p_strym := rec.alias1;
	END LOOP;



	IF SUBSTR(p_assym, -2, 2) < SUBSTR(p_strym, -2, 2) THEN
		p_strym := TO_CHAR(ADD_MONTHS(TO_DATE(p_assym, 'YYYY-MM'), -12), 'YYYY-') || SUBSTR(p_strym, -2, 2);
	ELSE
		p_strym := SUBSTR(p_assym, 0, 4) || SUBSTR(p_strym, -3, 3);
	END IF;


	p_strdate     := CASE WHEN p_mathod = '년상각' THEN p_strym || '-01' ELSE p_assym || '-01' END;
  p_enddate     := TO_CHAR(LAST_DAY(TO_DATE(p_assym, 'YYYY-MM')), 'YYYY-MM-DD');
	p_acautorcode := 'A04010';
	p_crttype     := 'assdiv';



	FOR rec IN (SELECT value1
				FROM   SYSPARAMETERMANAGE
				WHERE  parametercode = 'deprtosliptype')
	LOOP
		p_crttype := rec.value1;
	END LOOP;

	p_mngclucode := 'S040';



    EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACASS0070P_ACASSDEPR';

    INSERT INTO VGT.TT_ACASS0070P_ACASSDEPR

        SELECT  CASE WHEN D.grp = 1 THEN '' ELSE c.assdiv END assdiv,
                CASE WHEN D.grp = 2 AND c.acccode = c.gacccode THEN '1' ELSE '2' END samediv,
                CASE WHEN D.grp = 1 THEN c.dacccode ELSE c.gacccode END acccode,
                CASE WHEN p_crttype = 'assdiv' THEN '' ELSE c.mngdeptcode END deptcode,
                SUM(a.depamt - NVL(b.depamt, 0)) depamt
        FROM    ACASSDEPR a
                LEFT JOIN ACASSDEPR b ON a.compcode = b.compcode
                                         AND a.closediv = b.closediv
                                         AND a.caldiv = b.caldiv
                                         AND TO_CHAR(ADD_MONTHS(TO_DATE(a.assym, 'YYYY-MM'), -1), 'YYYY-MM') = b.assym
                                         AND p_strym <= TO_CHAR(ADD_MONTHS(TO_DATE(a.assym, 'YYYY-MM'), -1), 'YYYY-MM')
                                         AND a.asscode = b.asscode
                                         AND p_mathod <> '년상각'
                JOIN ACASSM c ON a.asscode = c.asscode
                JOIN ( SELECT 1 grp FROM DUAL
                       UNION
                       SELECT 2 FROM DUAL) D ON 1 = 1
        WHERE   a.compcode = p_compcode
                AND a.closediv = p_closediv
                AND a.caldiv = p_caldiv
                AND a.assym = p_assym
                AND c.plantcode = p_plantcode
        GROUP BY CASE WHEN D.grp = 1 THEN '' ELSE c.assdiv END ,
                 CASE WHEN D.grp = 2 AND c.acccode = c.gacccode THEN '1' ELSE '2' END,
                 CASE WHEN D.grp = 1 THEN c.dacccode ELSE c.gacccode END,
                 CASE WHEN p_crttype = 'assdiv' THEN '' ELSE c.mngdeptcode END
        HAVING   SUM(a.depamt - NVL(b.depamt, 0)) <> 0 ;



	EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACASS0070P_ACORDD';

    INSERT INTO VGT.TT_ACASS0070P_ACORDD (
        SELECT  a.assdiv,
                c.divname assdivname,
                a.acccode,
                D.accname,
                a.deptcode,
                E.deptname deptname,
                CASE WHEN D.dcdiv = '1' AND a.samediv = '2' OR
                          D.dcdiv = '2' AND a.samediv = '1' THEN a.depamt
                     ELSE 0
                END ddebamt,
                CASE WHEN D.dcdiv = '2' AND a.samediv = '2' OR
                          D.dcdiv = '1' AND a.samediv = '1' THEN a.depamt
                     ELSE 0
                END dcreamt,
                NVL(b.debamt, 0) debamt,
                NVL(b.creamt, 0) creamt,
                a.depamt - NVL(b.debamt, 0) - NVL(b.creamt, 0) diffamt
        FROM	VGT.TT_ACASS0070P_ACASSDEPR a
                LEFT JOIN ( SELECT  a.acccode
                                    , NVL(b.mngcluval, '') deptcode
                                    , SUM(a.debamt) debamt
                                    , SUM(a.creamt) creamt
                            FROM 	ACORDD a
                                    LEFT JOIN ACORDS b ON a.compcode = b.compcode
                                                          AND a.slipinno = b.slipinno
                                                          AND a.slipinseq = b.slipinseq
                                                          AND b.mngclucode = p_mngclucode
                                    JOIN VGT.TT_ACASS0070P_ACASSDEPR c ON a.acccode = c.acccode
                                                                          AND NVL(b.mngcluval, '') = c.deptcode
                                    JOIN ACORDM D ON a.compcode = D.compcode
                                                     AND a.slipinno = D.slipinno
                                                     AND ( p_closediv = '10' AND D.slipdiv NOT IN ('F', 'K') OR
                                                           p_closediv = '20' AND D.slipdiv = 'K' OR
                                                           p_closediv = '30' AND D.slipdiv = 'F' )
                                                     AND D.acautorcode = p_acautorcode
                                    JOIN ACACCM E ON a.acccode = E.acccode
                                                     AND (  c.samediv = '2' AND E.dcdiv = '1' AND a.debamt <> 0 OR
                                                            c.samediv = '2' AND E.dcdiv = '2' AND a.creamt <> 0 OR
                                                            c.samediv = '1' AND E.dcdiv = '2' AND a.debamt <> 0 OR
                                                            c.samediv = '1' AND E.dcdiv = '1' AND a.creamt <> 0 )
                            WHERE	a.compcode = p_compcode
                                    AND a.plantcode = p_plantcode
                                    AND a.slipdate BETWEEN p_strdate AND p_enddate
                                    AND a.acccode IN (  SELECT  acccode
                                                        FROM	VGT.TT_ACASS0070P_ACASSDEPR )
                                                        GROUP BY a.acccode, b.mngcluval ) b ON a.acccode = b.acccode
                                                                                                        AND a.deptcode = b.deptcode
                LEFT JOIN CMCOMMONM c ON c.cmmcode = 'AC70'
                                        AND a.assdiv = c.divcode
                LEFT JOIN ACACCM D ON a.acccode = D.acccode
                LEFT JOIN CMDEPTM E ON a.deptcode = E.deptcode
    );


	IF (p_div = 'S') THEN

        --감가상각내용 조회
        OPEN IO_CURSOR FOR
            SELECT	 ASSDIV
                    , ASSDIVNAME
                    , ACCCODE
                    , ACCNAME
                    , DEPTCODE
                    , DEPTNAME
                    , DDEBAMT
                    , DCREAMT
                    , DEBAMT
                    , CREAMT
                    , DIFFAMT
                    , CASE WHEN NVL(TRIM(ACCCODE), '') IS NULL THEN 0 ELSE 1 END AS i_order
            FROM	 VGT.TT_ACASS0070P_ACORDD
            ORDER BY i_order, deptcode, assdiv, acccode;

    ELSIF (p_div = 'I') THEN

    	--감가상각전표 생성
		FOR rec IN (SELECT accdiv, remark2
					FROM   ACAUTORULE
					WHERE  acautorcode = p_acautorcode)
		LOOP
			p_slipdiv := rec.accdiv;
			p_remark := rec.remark2;
		END LOOP;

		FOR rec IN (SELECT p_slipdiv || SUBSTR('0000' || TO_CHAR(NVL(TO_NUMBER(SUBSTR(MAX(slipnum), -4, 4)), 0) + 1), -4, 4) AS alias1
					FROM   ACORDM a
					WHERE  compcode = p_compcode
						   AND slipno LIKE REPLACE(p_enddate, '-', '') || RTRIM(p_slipdiv) || '%')
		LOOP
			p_slipnum := rec.alias1;
		END LOOP;

		p_slipno := REPLACE(p_enddate, '-', '') || p_slipnum;

		FOR rec IN (SELECT deptcode
					FROM   CMEMPM
					WHERE  empcode = p_iempcode)
		LOOP
			p_deptcode := rec.deptcode;
		END LOOP;

		INSERT INTO ACORDM(compcode,
						   slipinno,
						   slipdiv,
						   slipindate,
						   slipinnum,
						   deptcode,
						   plantcode,
						   empcode,
						   eviddiv,
						   slipinremark,
						   slipno,
						   slipdate,
						   slipnum,
						   slipdeptcode,
						   slipempcode,
						   skreqyn,
						   skreqdiv,
						   skreqdate,
						   skreqdeptcode,
						   skreqempcode,
						   accountno,
						   slipinstate,
						   slipremark,
						   acautorcode,
						   insertdt,
						   iempcode)
			(SELECT p_compcode,
					p_slipno,
					p_slipdiv,
					p_enddate,
					p_slipnum,
					p_deptcode,
					p_plantcode,
					p_iempcode,
					'99',
					p_remark,
					p_slipno,
					p_enddate,
					p_slipnum,
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'',
					'4',
					'',
					acautorcode,
					SYSDATE,
					p_iempcode
			 FROM	ACAUTORULE
			 WHERE	acautorcode = p_acautorcode);


		INSERT INTO ACORDD(compcode,
						   slipinno,
						   slipinseq,
						   dcdiv,
						   acccode,
						   plantcode,
						   debamt,
						   creamt,
						   slipdate,
						   slipnum,
						   remark1,
						   remark2,
						   rptseq,
						   insertdt,
						   iempcode)
			SELECT	 p_compcode,
					 p_slipno,
					 slipinseq,
					 dcdiv,
					 acccode,
					 p_plantcode,
					 debamt,
					 creamt,
					 p_enddate,
					 p_slipnum,
					 remark1,
					 remark2,
					 slipinseq,
					 SYSDATE,
					 p_iempcode
			FROM	 (SELECT   ROW_NUMBER() OVER (ORDER BY deptcode, assdiv, acccode) slipinseq,
							   CASE WHEN assdiv = '' THEN '1' ELSE '2' END dcdiv,
							   acccode,
							   ddebamt - debamt debamt,
							   dcreamt - creamt creamt,
							   SUBSTR(p_assym, 0, 4) || '년' || SUBSTR(p_assym, -2, 2) || '월 ' || accname || ' 계상' remark1,
							   'a' remark2,
							   deptcode,
							   deptname
					  FROM	   VGT.TT_ACASS0070P_ACORDD
					  WHERE    ddebamt - debamt <> 0
							   OR dcreamt - creamt <> 0
					  ORDER BY deptcode, assdiv, acccode) a
			ORDER BY a.slipinseq;


		INSERT INTO ACORDS(compcode,
						   slipinno,
						   slipinseq,
						   mngclucode,
						   seq,
						   mngcluval,
						   mngcludec,
						   insertdt,
						   iempcode)
			(SELECT p_compcode,
					p_slipno,
					a.slipinseq,
					b.mngclucode,
					b.seq,
					CASE WHEN b.mngclucode = p_mngclucode THEN deptcode ELSE '' END col,
					CASE WHEN b.mngclucode = p_mngclucode THEN deptname ELSE '' END col,
					SYSDATE,
					p_iempcode
			 FROM	(SELECT   ROW_NUMBER() OVER (ORDER BY deptcode, assdiv, acccode) slipinseq,
							  CASE WHEN assdiv = '' THEN '1' ELSE '2' END dcdiv,
							  acccode,
							  ddebamt - debamt debamt,
							  dcreamt - creamt creamt,
							  SUBSTR(p_assym, 0, 4) || '년' || SUBSTR(p_assym, -2, 2) || '월 ' || accname || ' 계상' remark1,
							  'a' remark2,
							  deptcode,
							  deptname
					 FROM	  VGT.TT_ACASS0070P_ACORDD
					 WHERE	  ddebamt - debamt <> 0
							  OR dcreamt - creamt <> 0
					 ORDER BY deptcode, assdiv, acccode) a
					JOIN ACACCMNGM b
						ON a.acccode = b.acccode
						   AND a.dcdiv = b.dcdiv);


		spACord0000MM('A',
							p_compcode,
							p_slipno,
							'',
							'',
							'',
							p_userid,
							p_reasondiv,
							p_reasontext,
							MESSAGE,
							IO_CURSOR);

	ELSIF (p_div = 'D') THEN

		spACord0000MM('B',
							p_compcode,
							p_slipno,
							'',
							'',
							'',
							p_userid,
							p_reasondiv,
							p_reasontext,
							MESSAGE,
							IO_CURSOR);


		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ, B.MNGCLUCODE
					FROM   ACORDM a
						   JOIN ACORDS b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno
					WHERE  a.compcode = p_compcode
						   AND a.slipindate = p_enddate
						   AND a.acautorcode = p_acautorcode)
		LOOP
			DELETE FROM ACORDS b
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO
						AND B.SLIPINSEQ = REC.SLIPINSEQ
						AND B.MNGCLUCODE = REC.MNGCLUCODE;
		END LOOP;


		FOR REC IN (SELECT B.COMPCODE, B.SLIPINNO, B.SLIPINSEQ
					FROM   ACORDM a
						   JOIN ACORDD b
							   ON a.compcode = b.compcode
								  AND a.slipinno = b.slipinno
					WHERE  a.compcode = p_compcode
						   AND a.slipindate = p_enddate
						   AND a.acautorcode = p_acautorcode)
		LOOP
			DELETE FROM ACORDD b
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.SLIPINNO = REC.SLIPINNO
						AND B.SLIPINSEQ = REC.SLIPINSEQ;
		END LOOP;


		FOR REC IN (SELECT A.COMPCODE, A.SLIPINNO
					FROM   ACORDM a
					WHERE  a.compcode = p_compcode
						   AND a.slipindate = p_enddate
						   AND a.acautorcode = p_acautorcode)
		LOOP
			DELETE FROM ACORDM a
			WHERE		A.COMPCODE = REC.COMPCODE
						AND A.SLIPINNO = REC.SLIPINNO;
		END LOOP;

	END IF;



    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;



END;
/
