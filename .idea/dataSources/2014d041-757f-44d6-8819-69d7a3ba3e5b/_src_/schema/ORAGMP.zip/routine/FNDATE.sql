CREATE FUNCTION fnDate(
    -- ---------------------------------------------------------------
    -- 함 수 명   : fnDate
    -- 작 성 자         :
    -- 작성일자         :
    -- 수 정 자       :   노영래
	-- 수정일자        :   2017-07-31
    -- ---------------------------------------------------------------
    -- 함수설명   : date함수
    -- ---------------------------------------------------------------
    p_date VARCHAR2 DEFAULT ''
)
	RETURN VARCHAR2
AS
	p_conv_date   VARCHAR(20);
BEGIN

	p_conv_date :=
		CASE SUBSTR(p_date, 6, 2)
			WHEN '01' THEN 'Jan. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
			WHEN '02' THEN 'Feb. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
			WHEN '03' THEN 'Mar. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
			WHEN '04' THEN 'Apr. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
			WHEN '05' THEN 'May. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
			WHEN '06' THEN 'Jun. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
			WHEN '07' THEN 'Jul. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
			WHEN '08' THEN 'Aug. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
			WHEN '09' THEN 'Sep. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
      WHEN '10' THEN 'Oct. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
      WHEN '11' THEN 'Nov. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
      WHEN '12' THEN 'Dec. ' || SUBSTR(p_date, -2) || ',' || SUBSTR(p_date, 1, 4)
    END;

  RETURN (p_conv_date);
EXCEPTION
  WHEN OTHERS
  THEN
    p_conv_date := '';
END;
/
