CREATE FUNCTION fnDateHan
-- ---------------------------------------------------------------
 -- 함 수 명            : fnDateHan
 -- 작 성 자         : 김  훈
 -- 작성일자         : 2010-04-23
 -- ---------------------------------------------------------------
 -- 함수설명            :    날짜 한글 &
 --                    :    근무 기간
 -- ---------------------------------------------------------------
 --
 --          select DATEDIFF(month, '2005-06-19', '2010-06-02')

(
  p_gb          IN VARCHAR2 DEFAULT 'workdate' ,
  p_string1     IN VARCHAR2 DEFAULT '2004-03-02' ,
  p_string2     IN VARCHAR2 DEFAULT '2010-05-03'
)
RETURN VARCHAR2
AS
    ip_string1 VARCHAR2(30) := p_string1;
    ip_string2 VARCHAR2(30) := p_string2;

    p_tostring VARCHAR2(20);

    p_year11  VARCHAR2(10);
    p_month11 VARCHAR2(10);
    p_day11   VARCHAR2(10);

BEGIN

--    IF ( NVL(TRIM(ip_string1), '') IS NULL ) THEN
--        ip_string1 := '1900-01-01' ;
--    END IF ;


    IF ( UPPER(p_gb) = 'DATEHANGLE' )THEN
        p_tostring := '';
        p_tostring := SUBSTR (ip_string1, 0, 4)
                      || '년'
                      || SUBSTR (ip_string1, 6, 2)
                      || '월'
                      || SUBSTR (ip_string1, 9, 2)
                      || '일';

    ELSIF ( UPPER(p_gb) = 'DATEHANGLE2' )THEN

        p_tostring := '';
        p_tostring := SUBSTR (ip_string1, 0, 4) || '년'
                      || CASE WHEN SUBSTR(ip_string1, 6, 2) < '10' THEN ' ' || SUBSTR(ip_string1, 6, 2)
                              ELSE SUBSTR(ip_string1, 6, 2)
                         END  || '월'
                      || CASE WHEN SUBSTR(ip_string1, -2, 2) < '10' THEN ' ' || SUBSTR (ip_string1, -2, 2)
                              ELSE SUBSTR(ip_string1, -2, 2)
                         END  || '일';

    ELSIF ( UPPER(p_gb) = 'WORKDATE' )THEN

        BEGIN
            p_tostring := '';

            IF (NVL(ip_string2, '') IS NULL) THEN
                ip_string2 :=TO_CHAR(SYSDATE,'YYYY-MM-DD');
            END IF;

            p_tostring := ' ';

            p_year11  := TRUNC((TRUNC(MONTHS_BETWEEN (TO_DATE(ip_string2,'YYYY-MM-DD'), TO_DATE(ip_string1,'YYYY-MM-DD')),0) -1 ) /12)  ;
            p_month11 := TRUNC(MOD(TRUNC((TRUNC(MONTHS_BETWEEN (TO_DATE(ip_string2,'YYYY-MM-DD'), TO_DATE(ip_string1,'YYYY-MM-DD'))) -1 )),12));

            p_day11 :='0';

            IF  (SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2)) < SUBSTR (ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1)) ) THEN
                p_day11 :=
                              SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) )
                           +
                              TO_CHAR(LAST_DAY(TO_DATE(ip_string1,'YYYY-MM-DD')),'DD')
                           -
                              SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1) )
                           +
                              1;
            ELSE

                p_day11 :=
                             SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) )
                           -
                             SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1) )
                           +
                             1 ;
            END IF;

            IF ( SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1)) <=  SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) ) ) THEN
                p_month11 := p_month11 + 1;

            ELSE
                p_month11 := p_month11;

            END IF;

            IF (TO_CHAR(LAST_DAY(TO_DATE(ip_string1,'YYYY-MM-DD')),'DD') =p_day11 OR  TO_CHAR(LAST_DAY(TO_DATE(ip_string2,'YYYY-MM-DD')),'DD') = p_day11 ) THEN
                p_month11 := p_month11 + 1;
                p_day11 :='0';
            END IF;
            IF (p_month11 = '12') THEN
                p_month11 :=0;
                p_year11  := p_year11 +1;
            END IF;
            IF (p_year11 >= 1)  THEN
                p_tostring := p_tostring || p_year11 || '년 ';
            END IF;

            IF (p_month11 >= 1)  THEN
                p_tostring := p_tostring || p_month11 || '개월 ';
            END IF;

            IF (p_day11 >= 1)  THEN
                p_tostring := p_tostring || p_day11 || '일';
            END IF;

            p_tostring :=p_tostring;

        EXCEPTION
                WHEN ZERO_DIVIDE THEN
                    p_tostring :='EXCEPTION WHEN ZERO_DIVIDE';
                WHEN OTHERS THEN
                    p_tostring :='EXCEPTION WHEN OTHERS';
        END;


    ELSIF ( UPPER(p_gb)  = 'WORKDT')    THEN

        IF NVL(TRIM(ip_string2), '') IS NULL THEN
            ip_string2 := TO_CHAR(SYSDATE, 'YYYY-MM-DD');
        END IF;


        IF ( NVL(TRIM(p_string1), '') IS NULL AND NVL(TRIM(p_string2), '') IS NULL ) THEN

            p_tostring := TO_CHAR(ADD_MONTHS(SYSDATE, -1) + 1 , 'YYMMDD') ;

        ELSE
            p_year11  := TRUNC((TRUNC(MONTHS_BETWEEN (TO_DATE(ip_string2,'YYYY-MM-DD'), TO_DATE(ip_string1,'YYYY-MM-DD'))) -1 ) / 12) ;

            IF ( NVL(TRIM(p_string1), '') IS NULL AND NVL(TRIM(p_string2), '') IS NULL ) THEN
                p_month11 := '-1';
            ELSE
                p_month11 := MOD(TRUNC((TRUNC(MONTHS_BETWEEN (TO_DATE(ip_string2,'YYYY-MM-DD'), TO_DATE(ip_string1,'YYYY-MM-DD'))) -1 )), 12);
            END IF;


            p_day11 := '0';


            IF  (SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2)) < SUBSTR (ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1)) ) THEN

                p_day11 :=
                              SUBSTR(ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) )
                           +
                              TO_CHAR(LAST_DAY(TO_DATE(ip_string1,'YYYY-MM-DD')),'DD')
                           -
                              SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1) )
                           +
                              1;

            ELSE

                p_day11 :=
                             SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) )
                           -
                             SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1) )
                           +
                             1 ;
            END IF;




            IF ( SUBSTR(ip_string1, LENGTH(ip_string1) -1, LENGTH(ip_string1)) <=  SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) ) ) THEN

                p_month11 := p_month11 + 1;

            ELSE
                p_month11 := p_month11;

            END IF;


            IF ( SUBSTR( fnFunction('lastdate', ip_string1,''), -2, 2) = p_day11  OR  SUBSTR( fnFunction('lastdate', ip_string2,''), -2, 2) = p_day11 ) THEN

                p_month11 := p_month11 + 1;
                p_day11 := '0';
            END IF;

            IF (p_month11 = '12') THEN
                p_month11 := 0;
                p_year11  := p_year11 +1;
            END IF;

            p_tostring := SUBSTR('00' || p_year11, -2, 2) || SUBSTR('00' || p_month11, -2, 2) || SUBSTR('00' || p_day11, -2, 2) ;

        END IF ;


    ELSIF ( UPPER(p_gb) = 'WORKDATE1' )    THEN

        p_tostring := '';
        p_tostring := '';
        IF (ip_string2 IS NULL ) THEN
            ip_string2 :=TO_CHAR(SYSDATE,'YYYY-MM-DD');
        END IF;
        p_tostring := ' ';
                    p_year11  := TRUNC((TRUNC(MONTHS_BETWEEN (TO_DATE(ip_string2,'YYYY-MM-DD'), TO_DATE(ip_string1,'YYYY-MM-DD'))) -1 ) /12)  ;
            p_month11 := TRUNC(MOD(TRUNC((TRUNC(MONTHS_BETWEEN (TO_DATE(ip_string2,'YYYY-MM-DD'), TO_DATE(ip_string1,'YYYY-MM-DD'))) -1 )),12));

            p_day11 :='0';


            IF  (SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2)) < SUBSTR (ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1)) ) THEN
                p_day11 :=
                              SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) )
                           +
                              TO_CHAR(LAST_DAY(TO_DATE(ip_string1,'YYYY-MM-DD')),'DD')
                           -
                              SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1) )
                           +
                              1;
            ELSE

                p_day11 :=
                             SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) )
                           -
                             SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1) )
                           +
                             1 ;
            END IF;

            IF ( SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1)) <=  SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) ) ) THEN
                p_month11 := p_month11 + 1;

            ELSE
                p_month11 := p_month11;

            END IF;

            IF (TO_CHAR(LAST_DAY(TO_DATE(ip_string1,'YYYY-MM-DD')),'DD') =p_day11 OR  TO_CHAR(LAST_DAY(TO_DATE(ip_string2,'YYYY-MM-DD')),'DD') = p_day11 ) THEN
                p_month11 := p_month11 + 1;
                p_day11 :='0';
            END IF;
            IF (p_month11 = '12') THEN
                p_month11 :=0;
                p_year11  := p_year11 +1;
            END IF;


        IF (p_year11 >= 1)  THEN
            p_tostring := p_tostring || LPAD(p_year11,2,'0') || '년 ';
        ELSE
            p_tostring := p_tostring || '00년 ';
        END IF;

        IF (p_month11 >= 1)  THEN
            p_tostring := p_tostring || LPAD(p_month11,2,'0') || '개월 ';
        ELSE
           p_tostring := p_tostring || '00개월 ';

        END IF;

        IF (p_day11 >= 1)  THEN
            p_tostring := p_tostring || LPAD(p_day11,2,'0') || '일';
        ELSE
            p_tostring := p_tostring || '00일';
        END IF;

    ELSIF ( UPPER(p_gb) = 'yeardate' )    THEN
        p_tostring := '';

                    p_year11  := TRUNC((TRUNC(MONTHS_BETWEEN (TO_DATE(ip_string2,'YYYY-MM-DD'), TO_DATE(ip_string1,'YYYY-MM-DD'))) -1 ) /12)  ;
            p_month11 := TRUNC(MOD(TRUNC((TRUNC(MONTHS_BETWEEN (TO_DATE(ip_string2,'YYYY-MM-DD'), TO_DATE(ip_string1,'YYYY-MM-DD'))) -1 )),12));

            p_day11 :='0';


            IF  (SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2)) < SUBSTR (ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1)) ) THEN
                p_day11 :=
                              SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) )
                           +
                              TO_CHAR(LAST_DAY(TO_DATE(ip_string1,'YYYY-MM-DD')),'DD')
                           -
                              SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1) )
                           +
                              1;
            ELSE

                p_day11 :=
                             SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) )
                           -
                             SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1) )
                           +
                             1 ;
            END IF;

            IF ( SUBSTR(ip_string1,LENGTH(ip_string1) -1, LENGTH(ip_string1)) <=  SUBSTR (ip_string2,LENGTH(ip_string2) -1, LENGTH(ip_string2) ) ) THEN
                p_month11 := p_month11 + 1;

            ELSE
                p_month11 := p_month11;

            END IF;

            IF (TO_CHAR(LAST_DAY(TO_DATE(ip_string1,'YYYY-MM-DD')),'DD') =p_day11 OR  TO_CHAR(LAST_DAY(TO_DATE(ip_string2,'YYYY-MM-DD')),'DD') = p_day11 ) THEN
                p_month11 := p_month11 + 1;
                p_day11 :='0';
            END IF;
            IF (p_month11 = '12') THEN
                p_month11 :=0;
                p_year11  := p_year11 +1;
            END IF;

        p_tostring := p_year11;

    END IF;

    RETURN p_tostring;


EXCEPTION
    WHEN ZERO_DIVIDE THEN
        p_month11 :=0;
    WHEN OTHERS THEN
        p_month11 :=0;
        p_tostring :=' ';



    IF p_tostring IS NULL THEN
        p_tostring :='오류';
    END IF;

END;
/
