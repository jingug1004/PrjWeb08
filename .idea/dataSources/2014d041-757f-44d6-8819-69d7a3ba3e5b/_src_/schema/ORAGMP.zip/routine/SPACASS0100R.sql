CREATE PROCEDURE        spACass0100R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACass0100R
	-- 작 성 자         : 최인범
	-- 작성일자         : 2010-10-04
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-27
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 자산대장을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_plantcode 	IN	   VARCHAR2 DEFAULT '',
	p_assdiv		IN	   VARCHAR2 DEFAULT '',
	p_asscls		IN	   VARCHAR2 DEFAULT '',
	p_assstate		IN	   VARCHAR2 DEFAULT '',
	p_sasscode		IN	   VARCHAR2 DEFAULT '',
	p_easscode		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S')
	THEN
		OPEN IO_CURSOR FOR
			SELECT a.compcode compcode, --회사코드
				   a.asscode asscode, --자산코드
				   a.assname assname, --자산명
				   a.assdiv assdiv, --자산구분 유,무형
				   a.asscls asscls, --토지,건물,건축물
				   a.strdate strdate, --취득일자
				   NVL(a.lifeyear, 0) lifeyear, -- 내용년수
				   a.plantcode plantcode, --사업장코드
				   a.mngdeptcode mngdeptcode, --관리부서
				   a.acccode acccode, --계정코드
				   a.keeprmk keeprmk, --비고
				   a.masscode masscode, --설비코드
				   a.acqdiv acqdiv, --취득방법
				   a.depryn depryn, --상각여부
				   a.deprdiv deprdiv, --상각방법
				   a.remark remark, --비고
				   a.deprendyn deprendyn, --감가상각종료여부
				   a.assstate assstate, --자산상태
				   NVL(a.curassamt, 0) curassamt, --취득가액
				   NVL(a.lstassamt, 0) lstassamt, --비망가액
				   a.subsidyn subsidyn, --정부지원여부
				   a.subsidrmk subsidrmk, --정부지원내용
				   NVL(a.subsidassamt, 0) subsidassamt, --정보지원금액
				   E.deptname mngdeptname,
				   f.accname accname,
				   M.equipmentkorname massname,
				   P.plantname plantname,
				   ac76.divname assstatename,
				   ac71.divname assclsname,
				   ac70.divname assdivname,
				   NVL(rate.deprerate, 0) deprerate
			FROM   ACASSM a
				   LEFT JOIN CMDEPTM E ON a.mngdeptcode = E.deptcode
				   LEFT JOIN ACACCM f ON a.acccode = f.acccode
				   LEFT JOIN PDEQUIPMENTM M ON M.equipmentcode = a.masscode
				   LEFT JOIN CMPLANTM P ON P.plantcode = a.plantcode
				   LEFT JOIN CMCOMMONM ac76
					   ON ac76.cmmcode = 'AC76'
						  AND ac76.divcode = a.assstate
				   LEFT JOIN CMCOMMONM ac71 --자산분류
					   ON ac71.cmmcode = 'AC71'
						  AND ac71.divcode = a.asscls
				   LEFT JOIN CMCOMMONM ac70
					   ON ac70.cmmcode = 'AC70' --자산형태
						  AND ac70.divcode = a.assdiv
				   LEFT JOIN ACDEPRM rate
					   ON rate.compcode = a.compcode
						  AND rate.lifeyear = a.lifeyear
						  AND rate.deprdiv = a.deprdiv
			WHERE  a.compcode = p_compcode
				   AND (NVL(p_sasscode,' ') > ' '
						AND a.asscode >= p_sasscode
						OR trim(p_sasscode) is null )
				   AND (NVL(p_easscode,' ') > ' '
						AND a.asscode <= p_easscode
						OR trim(p_easscode) is null )
				   AND a.plantcode LIKE p_plantcode || '%'
				   AND a.assdiv LIKE p_assdiv || '%'
				   AND a.asscls LIKE p_asscls || '%'
				   AND a.assstate LIKE p_assstate || '%'
            ORDER BY a.asscode ;
	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
