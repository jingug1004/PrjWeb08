CREATE PROCEDURE spACacc0109R(
    -- ---------------------------------------------------------------
    -- 프로시저명      : spACacc0109R
    -- 작 성 자      : 최기홍
    -- 작성일자       : 2011-01-07
    -- 수 정 자      : 강현호
    -- E-Mail     : roykang0722@gmail.com
    -- 수정일자      : 2016-12-12
    -- ---------------------------------------------------------------
    -- 프로시저 설명    : 회계전표집계를 조회하는 프로시저이다.
    -- ---------------------------------------------------------------

    p_div             IN     VARCHAR2 DEFAULT '',
    p_compcode         IN     VARCHAR2 DEFAULT '',
    p_plantcode      IN     VARCHAR2 DEFAULT '',
    p_slipdate         IN     VARCHAR2 DEFAULT '',
    p_slipdiv         IN     VARCHAR2 DEFAULT '',
    p_headdiv         IN     VARCHAR2 DEFAULT '',
    p_acautorcode     IN     VARCHAR2 DEFAULT '%',
    p_rptname         IN     VARCHAR2 DEFAULT '',
    p_rptsize         IN     VARCHAR2 DEFAULT '1',
    p_userid         IN     VARCHAR2 DEFAULT '',
    p_reasondiv      IN     VARCHAR2 DEFAULT '',
    p_reasontext     IN     VARCHAR2 DEFAULT '',
    MESSAGE             OUT VARCHAR2,
    IO_CURSOR            OUT TYPES.DataSet
)
AS
    ip_rptsize      VARCHAR2(5) := p_rptsize;

    p_rowcnt1      NUMBER; --첫장갯수
    p_rowcnt2      NUMBER; --뒷장갯수
    p_formtype      NUMBER; -- 폼형태

    p_pathcode      VARCHAR2(10);

    iplantcode      VARCHAR2(4) := '';
    ip_temp			VARCHAR2(20);
BEGIN
    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF (p_div = 'L1'
        OR UPPER(p_rptname) IN ('ACACC0100CR', 'ACACC0102CR', 'ACACC0102CR2'))
    THEN -- 가로 리포트
        p_rowcnt1 := 7;
        p_rowcnt2 := 7;
        p_formtype := 0;
    ELSIF (p_div = 'L2')
    THEN -- A5 리포트
        p_rowcnt1 := 4;
        p_rowcnt2 := 4;
        p_formtype := 1;
        ip_rptsize := '1';
    ELSIF (p_div = 'L3'
           OR UPPER(p_rptname) IN ('ACACC0100CR2', 'ACACC0102CR3'))
    THEN -- 세로 리포트
        p_rowcnt1 := 8;
        p_rowcnt2 := 11;
        p_formtype := 1;
    ELSIF (UPPER(p_rptname) IN ('ACACC0100CR1', 'ACACC0102CR1'))
    THEN
        IF (ip_rptsize = '1')
        THEN -- A5
            p_rowcnt1 := 4;
            p_rowcnt2 := 4;
            p_formtype := 1;
        ELSE
            p_rowcnt1 := 13;
            p_rowcnt2 := 13;
            p_formtype := 1;
        END IF;
    ELSIF (UPPER(p_rptname) IN ('ACACC0100CR4', 'ACACC0102CR4'))
    THEN
        IF (ip_rptsize = '1')
        THEN
            -- A5
            p_rowcnt1 := 6;
            p_rowcnt2 := 6;
            p_formtype := 1;
        ELSE
            p_rowcnt1 := 20;
            p_rowcnt2 := 20;
            p_formtype := 1;
        END IF;
    END IF;

    --SUB QUERY에 조건을 주기 위함
    SELECT MIN(plantcode)
    INTO   iplantcode
    FROM   CMPLANTM
    WHERE  plantcode LIKE p_plantcode;

    DELETE FROM VGT.TT_ACACC0109R_ACORDD;



    INSERT INTO VGT.TT_ACACC0109R_ACORDD
        (SELECT ROW_NUMBER() OVER (PARTITION BY slipno, slipdiv, deptcode, dcname ORDER BY deptcodeg, slipinno, slipinseq, dcdiv, acccode) prnseq,
                A.*
         FROM    (SELECT   A.compcode,
                          MAX(A.plantcode) plantcode,
                          MAX(COALESCE(NULLIF(D.plantfullname, ''), D.plantname, '')) plantname,
                          A.slipdate slipno,
                          A.slipdiv,
                          MAX(E.divname) slipdivname,
                          CASE WHEN p_div IN ('S1', 'S3', 'S4') THEN A.deptcode ELSE '' END deptcodeg,
                          MAX(CASE WHEN p_div IN ('S1', 'S4') THEN A.deptcode ELSE '' END) deptcode,
                          MAX(CASE WHEN p_div IN ('S1', 'S4') THEN f.deptname ELSE '' END) deptname,
                          CASE WHEN b.dcdiv IN ('1', '2') THEN '대체' WHEN b.dcdiv = '3' THEN '입금' ELSE '출금' END dcname,
                          CASE WHEN p_div IN ('S1', 'S2', 'S3') THEN '' ELSE A.slipinno END slipinno,
                          CASE WHEN p_div IN ('S1', 'S2', 'S3') THEN 0 ELSE b.slipinseq END slipinseq,
                          b.dcdiv,
                          b.acccode,
                          MAX(G.accname) accname,
                          SUM(b.debamt) debamt,
                          SUM(b.creamt) creamt,
                          MAX(b.remark1) remark1,
                          MAX(CASE WHEN p_div IN ('S1', 'S2') THEN '' ELSE b.taxno END) taxno,
                          MAX(CASE WHEN p_div = 'S3' THEN A.deptcode || ' : ' || f.deptname ELSE c.mngcludec1 END) mngcludec1,
                          MAX(c.mngcludec2) mngcludec2,
                          MAX(c.mngcludec3) mngcludec3
                 FROM      ACORDM A
                          JOIN ACORDD b
                              ON A.compcode = b.compcode
                                 AND A.slipinno = b.slipinno
                          LEFT JOIN (SELECT   slipinno,
                                              slipinseq,
                                              MAX(CASE WHEN seq = 1 THEN mngcludec ELSE '' END) mngcludec1,
                                              MAX(CASE WHEN seq = 2 THEN mngcludec ELSE '' END) mngcludec2,
                                              MAX(CASE WHEN seq = 3 THEN mngcludec ELSE '' END) mngcludec3
                                     FROM      (SELECT A.slipinno,
                                                      b.slipinseq,
                                                      ROW_NUMBER() OVER (PARTITION BY A.slipinno, b.slipinseq ORDER BY b.seq) seq,
                                                      NVL(b.mngcluval, '') || ' : ' || NVL(b.mngcludec, '') || CASE WHEN c.custcode IS NULL THEN '' ELSE ' (' || c.businessno || ')' END mngcludec
                                               FROM   ACORDM A
                                                      JOIN ACORDS b
                                                          ON A.compcode = b.compcode
                                                             AND A.slipinno = b.slipinno
                                                      LEFT JOIN CMCUSTM c
                                                          ON b.mngclucode = 'S010'
                                                             AND b.mngcluval = c.custcode
                                               WHERE  A.compcode = p_compcode
                                                      AND A.plantcode LIKE p_plantcode
                                                      AND A.slipdate = SUBSTR(p_slipdate, 1, 10)
                                                      AND A.slipdiv LIKE p_slipdiv) A
                                     GROUP BY slipinno, slipinseq) c
                              ON b.slipinno = c.slipinno
                                 AND b.slipinseq = c.slipinseq
                                 AND p_div IN ('S4', 'S5')
                          LEFT JOIN CMPLANTM D ON D.plantcode = iplantcode
                          LEFT JOIN CMCOMMONM E
                              ON E.cmmcode = 'AC20'
                                 AND A.slipdiv = E.divcode
                          LEFT JOIN CMDEPTM f ON A.deptcode = f.deptcode
                          LEFT JOIN ACACCM G ON b.acccode = G.acccode
                 WHERE      A.compcode = p_compcode
                          AND A.plantcode LIKE p_plantcode
                          AND A.slipdate = substr(p_slipdate,1,10)
                          AND A.slipdiv LIKE p_slipdiv
                          AND NVL(A.acautorcode, ' ') LIKE p_acautorcode || '%'
                 GROUP BY A.compcode,
                          A.slipdate,
                          A.slipdiv,
                          CASE WHEN p_div IN ('S1', 'S3', 'S4') THEN A.deptcode ELSE '' END,
                          CASE WHEN b.dcdiv IN ('1', '2') THEN '대체' WHEN b.dcdiv = '3' THEN '입금' ELSE '출금' END,
                          CASE WHEN p_div IN ('S1', 'S2', 'S3') THEN '' ELSE A.slipinno END,
                          CASE WHEN p_div IN ('S1', 'S2', 'S3') THEN 0 ELSE b.slipinseq END,
                          b.dcdiv,
                          b.acccode
                 HAVING   SUM(b.debamt) <> 0
                          OR SUM(b.creamt) <> 0) A);




    DELETE FROM VGT.TT_ACACC0109R_ACORDM;

    INSERT INTO VGT.TT_ACACC0109R_ACORDM
        (SELECT ROW_NUMBER() OVER (ORDER BY slipno, slipdiv, deptcode, dcname) slipseq,
                A.*
         FROM    (SELECT   MAX(plantname) plantname,
                          slipno,
                          slipdiv,
                          MAX(slipdivname) slipdivname,
                          deptcode,
                          MAX(deptname) deptname,
                          dcname,
                          SUM(debamt) debamt,
                          SUM(creamt) creamt,
                          CASE WHEN COUNT(*) <= p_rowcnt1 THEN p_rowcnt1 ELSE (TRUNC((COUNT(*) - p_rowcnt1 - 1) / p_rowcnt2) + 1) * p_rowcnt2 + p_rowcnt1 END AS ROWNUMS
                 FROM      VGT.TT_ACACC0109R_ACORDD
                 GROUP BY slipno, slipdiv, deptcode, dcname) A);




    IF (p_headdiv = 'H')
    THEN
        -- 검색자료 Head형태
        OPEN IO_CURSOR FOR
            SELECT     'N' chkprint,
                     A.*
            FROM     VGT.TT_ACACC0109R_ACORDM A
            ORDER BY slipseq;
    ELSIF (p_headdiv = 'D')
    THEN
        -- 검색자료 Detail형태
        FOR rec IN (SELECT value3
                    FROM   SYSPARAMETERMANAGE
                    WHERE  parametercode = 'accsliprptposs')
        LOOP
            p_pathcode := rec.value3;
        END LOOP;

    DELETE FROM VGT.TT_ACACC0109R_SYS;

        INSERT INTO VGT.TT_ACACC0109R_SYS
            (SELECT A.*,
                    b.seq prnseq
             FROM  VGT.TT_ACACC0109R_ACORDM A JOIN SYSCALENDARMASTER b ON A.ROWNUMS >= seq);

    FOR REC IN(
          SELECT CASE WHEN p_pathcode = 'emp' THEN empcode ELSE deptcode END col
            FROM   CMEMPM
            WHERE  empcode = p_userid
        )
        LOOP
          ip_temp := REC.col;
        END LOOP;

        OPEN IO_CURSOR FOR
            SELECT     NVL(b.compcode, '') compcode,
                     TO_CHAR(A.slipseq) slipinno,
                     NVL(b.deptcode, '') deptcode,
                     NVL(b.acccode, '') acccode,
                     NVL(b.accname, '') accname,
                     NVL(b.creamt, 0) creamt,
                     NVL(b.debamt, 0) debamt,
                     NVL(b.remark1, '') remark1,
                     NVL(b.dcdiv, '') dcdiv,
                     NVL(b.deptname, '') deptname,
                     NVL(b.prnseq, 0) prnseq,
                     CASE
                         WHEN A.prnseq <= p_rowcnt1
                              OR p_formtype = 0
                         THEN
                             0
                         ELSE
                             1 + TRUNC((A.prnseq - p_rowcnt1 - 1) / p_rowcnt2)
                     END
                         seq,
                     NVL(b.mngcludec1, '') mngcludec1,
                     NVL(b.mngcludec2, '') mngcludec2,
                     NVL(b.mngcludec3, '') mngcludec3,
                     NVL(A.plantname, '') plantname,
                     --2012-12-12 밑에 문자은 자료형 보고 이상하게 나오TEST 해야 됨
                     CASE WHEN NVL(TRIM(b.taxno), '') IS NOT NULL THEN b.taxno || ';' || REPLACE(TO_CHAR(c.amt), '.00', '') || ';' || REPLACE(TO_CHAR(c.vat), '.00', '') ELSE '' END taxno,
                     b.taxno taxno,
                     b.slipno,
                     SUBSTR('0000' || TO_CHAR(A.slipseq), -5, 5) || TO_CHAR(CASE WHEN A.prnseq <= p_rowcnt1 THEN 0 ELSE 1 + (A.prnseq - p_rowcnt1 - 1) / p_rowcnt2 END) gubun,
                     TO_CHAR(CASE WHEN A.prnseq <= p_rowcnt1 THEN 1 ELSE 2 + TRUNC((A.prnseq - p_rowcnt1 - 1) / p_rowcnt2) END) || ' / ' || TO_CHAR(CASE WHEN A.ROWNUMS <= p_rowcnt1 THEN 1 ELSE 2 + TRUNC((A.ROWNUMS - p_rowcnt1 - 1) / p_rowcnt2) END) pageno,
                     '' empname,
                     A.slipseq,
                     NVL(D.pathname0, E.pathname0) pathname0,
                     NVL(D.pathname1, E.pathname1) pathname1,
                     NVL(D.pathname2, E.pathname2) pathname2,
                     NVL(D.pathname3, E.pathname3) pathname3,
                     NVL(D.pathname4, E.pathname4) pathname4,
                     NVL(D.pathname5, E.pathname5) pathname5,
                     NVL(D.pathname6, E.pathname6) pathname6,
                     NVL(D.pathname7, E.pathname7) pathname7,
                     NVL(D.pathname8, E.pathname8) pathname8,
                     NVL(D.pathname9, E.pathname9) pathname9,
                     NVL(D.pathname10, E.pathname10) pathname10,
                     NVL(D.pathname11, E.pathname11) pathname11,
                     NVL(D.pathname12, E.pathname12) pathname12,
                     NVL(D.pathname13, E.pathname13) pathname13,
                     NVL(D.pathname14, E.pathname14) pathname14,
                     ip_rptsize rptsize
            FROM     VGT.TT_ACACC0109R_SYS A
                     LEFT JOIN VGT.TT_ACACC0109R_ACORDD b
                         ON A.slipno = b.slipno
                            AND A.slipdiv = b.slipdiv
                            AND NVL(A.deptcode,' ') = NVL(b.deptcode,' ')
                            AND NVL(A.dcname,' ') = NVL(b.dcname,' ')
                            AND A.prnseq = b.prnseq
                     LEFT JOIN ACTAXM c
                         ON b.compcode = c.compcode
                            AND b.plantcode = c.plantcode
                            AND NVL(b.taxno,' ') = NVL(c.taxno,' ')
                     LEFT JOIN ACORPATH D
                         ON b.compcode = D.compcode
                            AND ip_temp = D.deptcode
                     LEFT JOIN ACORPATH E
                         ON b.compcode = E.compcode
                            AND E.deptcode IS NULL
            ORDER BY A.slipseq, A.prnseq;
    END IF;


    IF (IO_CURSOR IS NULL)
    THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
