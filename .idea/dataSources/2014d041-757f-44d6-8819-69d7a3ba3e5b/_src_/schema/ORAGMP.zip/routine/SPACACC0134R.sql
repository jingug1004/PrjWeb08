CREATE PROCEDURE spACacc0134R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0134R
	-- 작 성 자         : 배종성
	-- 작성일자         : 2010-01-12
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-21
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 자금일보출력을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			 IN 	VARCHAR2 DEFAULT '',
	p_compcode		 IN 	VARCHAR2 DEFAULT '',
	p_plantcode 	 IN 	VARCHAR2 DEFAULT '',
	p_startdt		 IN 	VARCHAR2 DEFAULT '',
	p_enddt 		 IN 	VARCHAR2 DEFAULT '',
	p_chshacccode	 IN 	VARCHAR2 DEFAULT '',
	p_userid		 IN 	VARCHAR2 DEFAULT '',
	p_reasondiv 	 IN 	VARCHAR2 DEFAULT '',
	p_reasontext	 IN 	VARCHAR2 DEFAULT '',
	MESSAGE 			OUT VARCHAR2,
	IO_CURSOR			OUT TYPES.DATASET
)
AS
	ip_chshacccode	 VARCHAR2(20) := p_chshacccode;
	p_acccode		 VARCHAR2(20) := '';
	p_outtype		 VARCHAR2(20) := '';
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	-- 파라메터 현금계정코드 정보조회
	FOR rec IN (SELECT value1
				FROM   SYSPARAMETERMANAGE
				WHERE  parametercode = 'acccashcode')
	LOOP
		ip_chshacccode := rec.value1;
	END LOOP;

	IF (p_div = 'S')
	THEN
		p_outtype := '1';

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0134R_ACACC0134R1 ';

		INSERT INTO VGT.TT_ACACC0134R_ACACC0134R1
			SELECT	 acccode,
					 accname,
					 TRIM(mngcluval) mngcluval,
					 baseamt,
					 debamt,
					 creamt,
					 balamt,
					 bigo,
					 frmdebamt,
					 frmcreamt,
					 toddebamt,
					 todcreamt
			FROM	 (SELECT   A.acccode acccode,
							   c.accname accname,
							   TRIM(A.mngcluval) mngcluval,
							   SUM(A.baseamt) baseamt,
							   SUM(A.debamt) debamt,
							   SUM(A.creamt) creamt,
							   SUM(A.baseamt + A.debamt - A.creamt) balamt,
							   '' bigo,
							   SUM(A.frmdebamt) frmdebamt,
							   SUM(A.frmcreamt) frmcreamt,
							   SUM(A.toddebamt) toddebamt,
							   SUM(A.todcreamt) todcreamt
					  FROM	   ( --  이월
								SELECT	 A.acccode acccode,
										 '' accname,
										 TRIM(A.mngcluval) mngcluval,
										 SUM(NVL(A.debamt, 0)) - SUM(NVL(A.creamt, 0)) baseamt,
										 0 debamt,
										 0 creamt,
										 0 balamt,
										 '' bigo,
										 SUM(NVL(A.frmdebamt, 0)) frmdebamt, --전일까지 차변누계
										 SUM(NVL(A.frmcreamt, 0)) frmcreamt, --전일까지 대변누계
										 0 toddebamt,
										 0 todcreamt
								FROM	 (SELECT A.acccode acccode,
												 '' mngcluval,
												 NVL(bsdebamt, 0) debamt,
												 NVL(bscreamt, 0) creamt,
												 0 frmdebamt,
												 0 frmcreamt
										  FROM	 ACORDDMM A
										  WHERE  plantcode LIKE p_plantcode
												 AND slipym = SUBSTR(p_startdt, 0, 7)
												 AND A.acccode = ip_chshacccode
										  UNION ALL-- 현금계정

										  --현금계정 3,4 현금입금출금 이월조회
										  SELECT ip_chshacccode acccode,
												 '' mngcluval,
												 SUM(NVL(A.creamt, 0)) debamt, -- 차변금액
												 SUM(NVL(A.debamt, 0)) creamt, -- 대변금액
												 SUM(NVL(A.creamt, 0)) frmdebamt, -- 차변금액
												 SUM(NVL(A.debamt, 0)) frmcreamt -- 대변금액
										  FROM	 ACORDD A
										  WHERE  A.compcode = p_compcode
												 AND A.plantcode LIKE p_plantcode
												 AND A.slipdate < p_startdt
												 AND A.slipdate >= SUBSTR(p_startdt, 1, 7) || '-01'
												 AND (A.dcdiv = '3' OR A.dcdiv = '4')
										  UNION ALL
										  --현금계정 1,2 이월 조회
										  SELECT ip_chshacccode acccode,
												 '' mngcluval,
												 SUM(NVL(A.debamt, 0)) debamt, -- 차변금액
												 SUM(NVL(A.creamt, 0)) creamt, -- 대변금액
												 SUM(NVL(A.debamt, 0)) frmdebamt, -- 차변금액
												 SUM(NVL(A.creamt, 0)) frmcreamt -- 대변금액
										  FROM	 ACORDD A
										  WHERE  A.compcode = p_compcode
												 AND A.plantcode LIKE p_plantcode
												 AND A.slipdate < p_startdt
												 AND A.slipdate >= SUBSTR(p_startdt, 1, 7) || '-01'
												 AND A.acccode = ip_chshacccode
                                                 --and (a.dcdiv = '1' or a.dcdiv = '2')
										  UNION ALL
										  SELECT A.acccode acccode,
												 '' mngcluval,
												 CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN NVL(bsdebamt, 0) ELSE NVL(bscreamt, 0) END debamt,
												 CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN NVL(bscreamt, 0) ELSE NVL(bsdebamt, 0) END creamt,
												 0 frmdebamt,
												 0 creamt
										  FROM	 ACORDDMM A
												 JOIN CMCOMMONM b
													 ON b.cmmcode = 'AC151' -- 자금일보계정
														AND b.usediv = 'Y'
										  WHERE  plantcode LIKE p_plantcode
												 AND slipym = SUBSTR(p_startdt, 0, 7)
												 AND A.acccode LIKE b.filter1 || '%'
										  UNION ALL-- 이월 관리항목 월집계
										  SELECT   D.acccode acccode,
												   TRIM(D.mngcluval) mngcluval,
												   CASE WHEN SUBSTR(D.acccode, 0, 1) = '1' THEN SUM(NVL(D.bsdebamt, 0)) ELSE SUM(NVL(D.bscreamt, 0)) END debamt,
												   CASE WHEN SUBSTR(D.acccode, 0, 1) = '1' THEN SUM(NVL(D.bscreamt, 0)) ELSE SUM(NVL(D.bsdebamt, 0)) END creamt,
												   CASE WHEN SUBSTR(D.acccode, 0, 1) = '1' THEN SUM(NVL(D.bsdebamt, 0)) ELSE SUM(NVL(D.bscreamt, 0)) END frmdebamt,
												   CASE WHEN SUBSTR(D.acccode, 0, 1) = '1' THEN SUM(NVL(D.bscreamt, 0)) ELSE SUM(NVL(D.bsdebamt, 0)) END frmcreamt
										  FROM	   ACORDSMM D
												   JOIN CMCOMMONM b
													   ON b.cmmcode = 'AC151' -- 자금일보계정
														  AND b.usediv = 'Y'
										  WHERE    D.plantcode LIKE p_plantcode
												   AND D.slipym = SUBSTR(p_startdt, 0, 7)
												   AND D.acccode LIKE b.filter1 || '%'
												   AND D.mngclucode = b.filter2
										  GROUP BY D.acccode, D.mngcluval
										  UNION ALL
										  SELECT   A.acccode acccode,
												   '' mngcluval,
												   --,'' as mngcludec
												   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.debamt, 0)) ELSE SUM(NVL(A.creamt, 0)) END debamt, -- 차변금액
												   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.creamt, 0)) ELSE SUM(NVL(A.debamt, 0)) END creamt, -- 대변금액
												   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.debamt, 0)) ELSE SUM(NVL(A.creamt, 0)) END frmdebamt, -- 차변금액
												   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.creamt, 0)) ELSE SUM(NVL(A.debamt, 0)) END frmcreamt -- 대변금액
										  FROM	   ACORDD A
												   JOIN CMCOMMONM b
													   ON b.cmmcode = 'AC151' -- 자금일보계정
														  AND b.usediv = 'Y'
										  WHERE    A.compcode = p_compcode
												   AND A.plantcode LIKE p_plantcode
												   AND A.slipdate < p_startdt
												   AND A.slipdate >= SUBSTR(p_startdt, 1, 7) || '-01'
												   AND A.acccode LIKE b.filter1 || '%'
										  GROUP BY A.acccode
										  UNION ALL
										  SELECT   A.acccode acccode,
												   TRIM(c.mngcluval) mngcluval,
												   --,c.mngcludec as mngcludec
												   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.debamt, 0)) ELSE SUM(NVL(A.creamt, 0)) END debamt, -- 차변금액
												   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.creamt, 0)) ELSE SUM(NVL(A.debamt, 0)) END creamt, -- 대변금액
												   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.debamt, 0)) ELSE SUM(NVL(A.creamt, 0)) END frmdebamt, -- 차변금액
												   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.creamt, 0)) ELSE SUM(NVL(A.debamt, 0)) END frmcreamt -- 대변금액
										  FROM	   ACORDD A,
												   ACORDS c JOIN CMCOMMONM b ON b.cmmcode = 'AC151' -- 자금일보계정
																				AND b.usediv = 'Y'
										  WHERE    A.compcode = c.compcode
												   AND A.slipinno = c.slipinno
												   AND A.slipinseq = c.slipinseq
												   AND A.compcode = p_compcode
												   AND A.plantcode LIKE p_plantcode
												   AND A.slipdate < p_startdt
												   AND A.slipdate >= SUBSTR(p_startdt, 1, 7) || '-01'
												   AND A.acccode LIKE b.filter1 || '%'
												   AND c.mngclucode = b.filter2
										  GROUP BY A.acccode, c.mngcluval) A
								GROUP BY A.acccode, A.mngcluval -- , mngcludec
								UNION ALL
								-- 차변/대변 실적금액
								SELECT	 b.acccode acccode,
										 '' accname,
										 b.mngcluval mngcluval,
										 --,b.mngcludec as mngcludec
										 0 baseamt,
										 SUM(NVL(b.debamt, 0)) debamt,
										 SUM(NVL(b.creamt, 0)) creamt,
										 0 balamt,
										 '' bigo,
										 0 frmdebamt,
										 0 frmcreamt,
										 SUM(NVL(b.debamt, 0)) toddebamt,
										 SUM(NVL(b.creamt, 0)) todcreamt
								FROM	 ( -- 공통코드 자금일보계정 실적
										  SELECT   A.acccode acccode, '' mngcluval, --,'' as mngcludec
											       CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.debamt, 0)) ELSE SUM(NVL(A.creamt, 0)) END debamt, --sum(isnull(a.debamt,0)) as debamt -- 차변금액
                                                   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.creamt, 0)) ELSE SUM(NVL(A.debamt, 0)) END creamt
										  FROM	   ACORDD A
												   JOIN CMCOMMONM b
													   ON b.cmmcode = 'AC151' -- 자금일보계정
														  AND b.usediv = 'Y'
										  WHERE    A.compcode = p_compcode
												   AND A.plantcode LIKE p_plantcode
												   AND A.slipdate BETWEEN p_startdt AND p_enddt
												   AND A.acccode LIKE b.filter1 || '%'
										  GROUP BY acccode
										  UNION ALL
										  -- 공통코드 자금일보계정 실적
										  SELECT   A.acccode acccode, c.mngcluval mngcluval, --, c.mngcludec as mngcludec
                                                   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.debamt, 0)) ELSE SUM(NVL(A.creamt, 0)) END debamt, --sum(isnull(a.debamt,0)) as debamt -- 차변금액
                                                   CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN SUM(NVL(A.creamt, 0)) ELSE SUM(NVL(A.debamt, 0)) END creamt
                      FROM     ACORDD A,
                           ACORDS c JOIN CMCOMMONM b ON b.cmmcode = 'AC151' -- 자금일보계정
                                        AND b.usediv = 'Y'
                      WHERE    A.compcode = c.compcode
                           AND A.slipinno = c.slipinno
                           AND A.slipinseq = c.slipinseq
                           AND A.compcode = p_compcode
                           AND A.plantcode LIKE p_plantcode
                           AND A.slipdate BETWEEN p_startdt AND p_enddt
                           AND A.acccode LIKE b.filter1 || '%'
                           AND c.mngclucode = b.filter2
                      GROUP BY acccode, mngcluval, mngcludec
                      UNION ALL
                      --현금계정 3,4 현금입금출금
                      SELECT    ip_chshacccode acccode, '' mngcluval, --, '' as mngcludec
                                                    SUM(NVL(A.creamt, 0)) debamt, -- 차변금액
                                                    SUM(NVL(A.debamt, 0)) creamt -- 대변금액
                      FROM     ACORDD A
                      WHERE    A.compcode = p_compcode
                           AND A.plantcode LIKE p_plantcode
                           AND A.slipdate BETWEEN p_startdt AND p_enddt
                           AND (A.dcdiv = '3'
                            OR A.dcdiv = '4')
                      GROUP BY acccode
                      UNION ALL
                      --현금계정 1,2 차대
                      SELECT   ip_chshacccode acccode, '' mngcluval, --, '' as mngcludec
                                                   SUM(NVL(A.debamt, 0)) debamt, -- 차변금액
                                                   SUM(NVL(A.creamt, 0)) creamt -- 대변금액
                      FROM     ACORDD A
                      WHERE    A.compcode = p_compcode
                           AND A.plantcode LIKE p_plantcode
                           AND A.slipdate BETWEEN p_startdt AND p_enddt
                           AND A.acccode = ip_chshacccode
                           AND (A.dcdiv = '1' OR A.dcdiv = '2')
                      GROUP BY acccode) b
                GROUP BY acccode, mngcluval ) A,

                 ACACCM c
            WHERE    A.acccode = c.acccode
            GROUP BY A.acccode, c.accname, A.mngcluval ) A
      ORDER BY A.acccode;


    p_acccode := '1110806';

    FOR rec IN (SELECT filter1
          FROM   CMCOMMONM
          WHERE  cmmcode = 'AC261'
               AND divcode = '1110806')
    LOOP
      p_acccode := rec.filter1;
    END LOOP;

    DELETE VGT.TT_ACACC0134R_ACACC0134R1
    WHERE  (baseamt = 0
        AND debamt = 0
        AND creamt = 0
        AND balamt = 0)
         OR (acccode LIKE p_acccode || '%'
           AND debamt = 0
           AND creamt = 0);

    FOR rec IN (SELECT acccode
          FROM   VGT.TT_ACACC0134R_ACACC0134R1
          WHERE  acccode LIKE '2%')
    LOOP
      p_outtype := rec.acccode;
    END LOOP;

    OPEN IO_CURSOR FOR
      SELECT   A.acccode,
           accname,
           NVL(b.filter2, '') slipnum,
           mngcluval,
           CASE b.filter2 WHEN 'S010' THEN NVL(c.custname, ' ') WHEN 'S020' THEN NVL(D.accremark, ' ') WHEN 'S030' THEN NVL(E.bankname, ' ') WHEN 'S040' THEN NVL(f.deptname, ' ') WHEN 'S050' THEN NVL(G.empname, ' ') ELSE '' END mngcludec,
           baseamt,
           debamt,
           creamt,
           balamt,
           bigo
      FROM   (SELECT acccode,
               accname,
               mngcluval,
               baseamt,
               debamt,
               creamt,
               balamt,
               bigo
            FROM   (SELECT acccode,
                   CASE WHEN mngcluval  IS NULL THEN accname ELSE '    ' || accname END accname,
                   CASE WHEN mngcluval  IS NULL THEN '계' ELSE mngcluval END mngcluval,
                   baseamt,
                   debamt,
                   creamt,
                   balamt,
                   bigo
                FROM   VGT.TT_ACACC0134R_ACACC0134R1
                UNION ALL
                SELECT acccode,
                   CASE WHEN mngcluval  IS NULL THEN accname ELSE '    ' || accname END accname,
                   CASE WHEN mngcluval  IS NULL THEN '누적액' ELSE mngcluval END mngcluval,
                   frmdebamt baseamt,
                   (frmdebamt + toddebamt) debamt,
                   (frmcreamt + todcreamt) creamt,
                   frmcreamt balamt,
                   bigo
                FROM   VGT.TT_ACACC0134R_ACACC0134R1
                WHERE  TRIM(mngcluval) IS NULL
                UNION ALL
                SELECT '운영채권' acccode,
                   '운영채권 합계' accname,
                   '' mngcluval,
                   SUM(NVL(baseamt, 0)) baseamt,
                   SUM(NVL(debamt, 0)) debamt,
                   SUM(NVL(creamt, 0)) creamt,
                   SUM(NVL(balamt, 0)) balamt,
                   '' bigo
                FROM   VGT.TT_ACACC0134R_ACACC0134R1
                WHERE  acccode LIKE '1%'
                   AND TRIM(mngcluval) IS NULL
                UNION ALL
                SELECT '운영채무' acccode,
                   '운영채무 합계' accname,
                   '' mngcluval,
                   SUM(NVL(baseamt, 0)) baseamt,
                   SUM(NVL(debamt, 0)) debamt,
                   SUM(NVL(creamt, 0)) creamt,
                   SUM(NVL(balamt, 0)) balamt,
                   '' bigo
                FROM   VGT.TT_ACACC0134R_ACACC0134R1
                WHERE  acccode LIKE '2%'
                   AND TRIM(mngcluval) IS NULL
                UNION ALL
                SELECT '운영합계' acccode,
                   '운영자금 합계' accname,
                   '' mngcluval,
                   SUM(baseamt1 - baseamt2) baseamt,
                   SUM(debamt1 - debamt2) debamt,
                   SUM(creamt1 - creamt2) creamt,
                   SUM(balamt1 - balamt2) balamt,
                   '' bigo
                FROM   (SELECT   SUM(CASE WHEN SUBSTR(acccode, 0, 1) = '1' THEN NVL(baseamt, 0) END) baseamt1,
                         SUM(CASE WHEN SUBSTR(acccode, 0, 1) = '2' THEN NVL(baseamt, 0) END) baseamt2,
                         SUM(CASE WHEN SUBSTR(acccode, 0, 1) = '1' THEN NVL(debamt, 0) END) debamt1,
                         SUM(CASE WHEN SUBSTR(acccode, 0, 1) = '2' THEN NVL(debamt, 0) END) debamt2,
                         SUM(CASE WHEN SUBSTR(acccode, 0, 1) = '1' THEN NVL(creamt, 0) END) creamt1,
                         SUM(CASE WHEN SUBSTR(acccode, 0, 1) = '2' THEN NVL(creamt, 0) END) creamt2,
                         SUM(CASE WHEN SUBSTR(acccode, 0, 1) = '1' THEN NVL(balamt, 0) END) balamt1,
                         SUM(CASE WHEN SUBSTR(acccode, 0, 1) = '2' THEN NVL(balamt, 0) END) balamt2
                    FROM     VGT.TT_ACACC0134R_ACACC0134R1
                    WHERE    TRIM(mngcluval) IS NULL
                    GROUP BY mngcluval) A)) A
           LEFT JOIN CMCOMMONM b
             ON A.acccode LIKE filter1 || '%'
              AND cmmcode = 'AC151'
           LEFT JOIN CMCUSTM c    ON nvl(A.mngcluval,' ') = nvl(c.custcode,' ')
           LEFT JOIN CMACCOUNTM D ON nvl(A.mngcluval,' ') = nvl(D.accountno,' ')
           LEFT JOIN CMBANKM E    ON nvl(A.mngcluval,' ') = nvl(E.bankcode,' ')
           LEFT JOIN CMDEPTM f    ON nvl(A.mngcluval,' ') = nvl(f.deptcode,' ')
           LEFT JOIN CMEMPM G     ON nvl(A.mngcluval,' ') = nvl(G.empcode,' ')
      ORDER BY acccode, mngcluval;
  ELSIF (p_div = 'S2')
  THEN
    EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0134R_ACORDD ';

    INSERT INTO VGT.TT_ACACC0134R_ACORDD
      SELECT   A.acccode,
           A.mngcluval mngcluval,
           grp,
           MAX(A.mngcluval2) mngcluval2,
           MAX(A.mngcludec) mngcludec,
           MAX(CASE
               WHEN grp = 0
                  AND slipdate >= p_startdt
               THEN
                 slipinno
               ELSE
                 ''
             END)
             slipinno,
           MAX(CASE
               WHEN grp = 0
                  AND slipdate >= p_startdt
               THEN
                 slipinseq
               ELSE
                 0
             END)
             slipinseq,
           MAX(CASE
               WHEN grp = 0
                  AND slipdate >= p_startdt
               THEN
                 slipindate
               ELSE
                 ''
             END)
             slipindate,
           MAX(CASE
               WHEN grp = 0
                  AND slipdate >= p_startdt
               THEN
                 slipinnum
               ELSE
                 ''
             END)
             slipinnum,
           MAX(CASE
               WHEN grp = 0
                  AND slipdate >= p_startdt
               THEN
                 slipno
               ELSE
                 ''
             END)
             slipno,
           MAX(CASE
               WHEN grp = 0
                  AND slipdate >= p_startdt
               THEN
                 slipdate
               ELSE
                 SUBSTR(slipdate, 0, 7)
             END)
             slipdate,
           CASE
             WHEN grp = 0
                AND slipdate < p_startdt
             THEN
               '이월'
             WHEN grp = 0
                AND slipdate >= p_startdt
             THEN
               slipnum
             WHEN grp = 1
             THEN
               '월계'
             ELSE
               '당일입출누계'
           END
             slipnum,
           MAX(CASE
               WHEN grp = 0
                  AND slipdate >= p_startdt
               THEN
                 A.remark
               ELSE
                 ''
             END)
             remark,
           SUM(CASE
               WHEN grp = 0
                  AND slipdate < p_startdt
                  AND NVL(c.dcdiv, '1') = '1'
               THEN
                 debamt - creamt
               WHEN grp = 0
                  AND slipdate >= p_startdt
               THEN
                 debamt
             END)
             debamt,
           SUM(CASE
               WHEN grp = 0
                  AND slipdate < p_startdt
                  AND NVL(c.dcdiv, '1') = '2'
               THEN
                 creamt - debamt
               WHEN grp = 0
                  AND slipdate >= p_startdt
               THEN
                 creamt
             END)
             creamt,
           SUM(CASE WHEN NVL(c.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END) fnamt,
           ROW_NUMBER()
             OVER (PARTITION BY A.acccode || A.mngcluval
                 ORDER BY
                   CASE
                     WHEN grp = 0
                      AND slipdate < p_startdt
                     THEN
                       SUBSTR(slipdate, 0, 7)
                     WHEN grp = 0
                      AND slipdate >= p_startdt
                     THEN
                       slipdate
                     ELSE
                       SUBSTR(slipdate, 0, 7) || '-99'
                   END,
                   grp,
                   CASE
                     WHEN grp = 0
                      AND slipdate < p_startdt
                     THEN
                       '이월'
                     WHEN grp = 0
                      AND slipdate >= p_startdt
                     THEN
                       slipnum
                     WHEN grp = 1
                     THEN
                       '월계'
                     ELSE
                       '당일입출누계'
                   END,
                   CASE
                     WHEN grp = 0
                      AND slipdate < p_startdt
                     THEN
                       0
                     WHEN grp = 0
                      AND slipdate >= p_startdt
                     THEN
                       slipinseq
                     WHEN grp = 1
                     THEN
                       8888
                     ELSE
                       9999
                   END)
             ord
      FROM   (SELECT '' slipinno,
               0 slipinseq,
               '' slipindate,
               '' slipinnum,
               '' slipno,
               A.slipym || '-00' slipdate,
               '' slipnum,
               A.acccode,
               '' mngcluval,
               '' mngcluval2,
               '' mngcludec,
               '' remark,
               CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN NVL(A.bsdebamt, 0) - NVL(A.bscreamt, 0) ELSE 0 END debamt,
               CASE WHEN SUBSTR(A.acccode, 0, 1) = '2' THEN NVL(A.bscreamt, 0) - NVL(A.bsdebamt, 0) ELSE 0 END creamt
            FROM   ACORDDMM A
            WHERE  A.compcode = p_compcode
               AND A.plantcode LIKE p_plantcode
               AND A.slipym = SUBSTR(p_startdt, 0, 7)
               --and (a.closediv = '10' or a.closediv = @odiv1)
               AND A.acccode = ip_chshacccode
            UNION ALL
            SELECT '' slipinno,
               0 slipinseq,
               '' slipindate,
               '' slipinnum,
               '' slipno,
               A.slipym || '-00' slipdate,
               '' slipnum,
               A.acccode,
               '' mngcluval,
               '' mngcluval2,
               '' mngcludec,
               '' remark,
               CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN NVL(A.bsdebamt, 0) - NVL(A.bscreamt, 0) ELSE 0 END debamt,
               CASE WHEN SUBSTR(A.acccode, 0, 1) = '2' THEN NVL(A.bscreamt, 0) - NVL(A.bsdebamt, 0) ELSE 0 END creamt
            FROM   ACORDDMM A
               JOIN CMCOMMONM AC151
                 ON AC151.cmmcode = 'AC151'
                  AND AC151.usediv = 'Y'
                  AND AC151.divcode NOT IN ('1010', '1020', '1030', '1040', '1070')
            WHERE  A.compcode = p_compcode
               AND A.plantcode LIKE p_plantcode
               AND A.slipym = SUBSTR(p_startdt, 0, 7)
               --and (a.closediv = '10' or a.closediv = @odiv1)
               AND A.acccode LIKE AC151.filter1 || '%'
            UNION ALL
            SELECT '' slipinno,
               0 slipinseq,
               '' slipindate,
               '' slipinnum,
               '' slipno,
               A.slipym || '-00' slipdate,
               '' slipnum,
               A.acccode,
               A.mngcluval mngcluval,
               A.mngcluval mngcluval2,
               A.mngcludec mngcludec,
               '' remark,
               CASE WHEN SUBSTR(A.acccode, 0, 1) = '1' THEN NVL(A.bsdebamt, 0) - NVL(A.bscreamt, 0) ELSE 0 END debamt,
               CASE WHEN SUBSTR(A.acccode, 0, 1) = '2' THEN NVL(A.bscreamt, 0) - NVL(A.bsdebamt, 0) ELSE 0 END creamt
            FROM   ACORDSMM A
               JOIN CMCOMMONM AC151
                 ON AC151.cmmcode = 'AC151'
                  AND AC151.usediv = 'Y'
                  AND AC151.divcode IN ('1010', '1020', '1030', '1040', '1070')
                  AND A.mngclucode = AC151.filter2
            WHERE  A.compcode = p_compcode
               AND A.plantcode LIKE p_plantcode
               AND A.slipym = SUBSTR(p_startdt, 0, 7)
               --and (a.closediv = '10' or a.closediv = @odiv1)
               AND A.acccode LIKE AC151.filter1 || '%'
            UNION ALL -- 현금전표
            SELECT A.slipinno,
               A.slipinseq,
               b.slipindate,
               b.slipinnum,
               b.slipno,
               A.slipdate,
               A.slipnum,
               CASE
                 WHEN A.dcdiv = '3'
                    OR A.dcdiv = '4'
                 THEN
                   ip_chshacccode
                 ELSE
                   ''
               END
                 acccode,
               '' mngcluval,
               '' mngcluval2,
               '' mngcludec,
               A.remark1 remark,
               CASE WHEN A.dcdiv = '3' THEN NVL(A.creamt, 0) WHEN A.dcdiv = '4' THEN 0 END debamt,
               CASE WHEN A.dcdiv = '4' THEN NVL(A.debamt, 0) WHEN A.dcdiv = '3' THEN 0 END creamt
            FROM   ACORDD A JOIN ACORDM b ON A.slipinno = b.slipinno
            --and b.slipdiv <> @odiv2 -- K-GAAP <> 'F', IFRS <> 'K'
            WHERE  A.compcode = p_compcode
               AND A.plantcode LIKE p_plantcode
               AND A.slipdate BETWEEN SUBSTR(p_startdt, 0, 8) || '01' AND p_enddt
               AND A.dcdiv IN ('3', '4')
            UNION ALL
            SELECT A.slipinno,
               A.slipinseq,
               b.slipindate,
               b.slipinnum,
               b.slipno,
               A.slipdate,
               A.slipnum,
               A.acccode acccode,
               '' mngcluval,
               '' mngcluval2,
               '' mngcludec,
               A.remark1 remark,
               NVL(A.debamt, 0) debamt,
               NVL(A.creamt, 0) creamt
            FROM   ACORDD A JOIN ACORDM b ON A.slipinno = b.slipinno
            --and b.slipdiv <> @odiv2 -- K-GAAP <> 'F', IFRS <> 'K'
            WHERE  A.compcode = p_compcode
               AND A.plantcode LIKE p_plantcode
               AND A.slipdate BETWEEN SUBSTR(p_startdt, 0, 8) || '01' AND p_enddt
               AND A.acccode = ip_chshacccode
            UNION ALL
            SELECT A.slipinno,
               A.slipinseq,
               b.slipindate,
               b.slipinnum,
               b.slipno,
               A.slipdate,
               A.slipnum,
               A.acccode acccode,
               CASE WHEN AC151.divcode IN ('1010', '1020', '1030', '1040', '1070') THEN c.mngcluval ELSE '' END mngcluval,
               c.mngcluval mngcluval2,
               c.mngcludec mngcludec,
               A.remark1 remark,
               NVL(A.debamt, 0) debamt,
               NVL(A.creamt, 0) creamt
            FROM   ACORDD A
               JOIN CMCOMMONM AC151 --select * from CMCOMMONM
                 ON AC151.cmmcode = 'AC151'
                  AND AC151.usediv = 'Y'
               JOIN ACORDM b
                 ON A.compcode = b.compcode
                  AND A.plantcode = b.plantcode
                  AND A.slipinno = b.slipinno
               LEFT JOIN ACORDS c
                 ON c.compcode = A.compcode
                  AND c.slipinno = A.slipinno
                  AND c.slipinseq = A.slipinseq
                  AND NVL(AC151.filter2, ' ') = c.mngclucode
            WHERE  A.compcode = p_compcode
               AND A.plantcode LIKE p_plantcode
               AND A.slipdate BETWEEN SUBSTR(p_startdt, 0, 8) || '01' AND p_enddt
               AND A.acccode LIKE AC151.filter1 || '%') A
           JOIN (SELECT 0 grp FROM DUAL
               UNION
               SELECT 1 FROM DUAL
               UNION
               SELECT 2 FROM DUAL) b
             ON b.grp = 0
              OR A.slipdate >= p_startdt
           JOIN ACACCM c ON A.acccode = c.acccode
      GROUP BY A.acccode,
           A.mngcluval,
           grp,
           CASE
             WHEN grp = 0
                AND slipdate < p_startdt
             THEN
               SUBSTR(slipdate, 0, 7)
             WHEN grp = 0
                AND slipdate >= p_startdt
             THEN
               slipdate
             ELSE
               SUBSTR(slipdate, 0, 7) || '-99'
           END,
           CASE
             WHEN grp = 0
                AND slipdate < p_startdt
             THEN
               '이월'
             WHEN grp = 0
                AND slipdate >= p_startdt
             THEN
               slipnum
             WHEN grp = 1
             THEN
               '월계'
             ELSE
               '당일입출누계'
           END,
           CASE
             WHEN grp = 0
                AND slipdate < p_startdt
             THEN
               0
             WHEN grp = 0
                AND slipdate >= p_startdt
             THEN
               slipinseq
             WHEN grp = 1
             THEN
               8888
             ELSE
               9999
           END
      ORDER BY acccode, slipdate, grp, slipnum;



        FOR REC IN (
            SELECT   A.grp, A.acccode,A.mngcluval, A.ord, B.debamt, B.creamt, B.fnamt
            FROM    VGT.TT_ACACC0134R_ACORDD A,
                    (
                        SELECT    A.acccode,NVL(A.mngcluval,' ') mngcluval , A.ord,
                                  SUM(b.debamt) AS debamt, SUM(b.creamt) AS creamt, SUM(b.fnamt) AS fnamt
                        FROM    VGT.TT_ACACC0134R_ACORDD A
                                JOIN VGT.TT_ACACC0134R_ACORDD b
                                    ON  A.acccode = b.acccode
                                    AND NVL(A.mngcluval,' ') = NVL(b.mngcluval,' ')
                                    AND A.ord >= b.ord
                                    AND b.grp = 0
                        GROUP BY A.acccode, NVL(A.mngcluval,' ') , A.ord
                    ) B
            WHERE   A.acccode = B.acccode
                AND nvl(A.mngcluval,' ')= nvl(B.mngcluval,' ')
                AND A.ord =B.ORD
        )
        LOOP
            UPDATE  VGT.TT_ACACC0134R_ACORDD A
                SET A.debamt = CASE WHEN A.GRP = 2 THEN REC.debamt ELSE A.debamt END,
                    A.creamt = CASE WHEN A.GRP = 2 THEN REC.creamt ELSE A.creamt END,
                    A.fnamt = CASE WHEN  A.GRP <> 1 THEN REC.fnamt END
            WHERE   A.acccode = REC.acccode
                AND NVL(A.mngcluval,' ')= NVL(REC.mngcluval,' ')
                AND A.ord      = REC.ord;
        END LOOP;
--



--    MERGE INTO VGT.TT_ACACC0134R_ACORDD A
--    USING     (SELECT A.ACCCODE,
--               A.MNGCLUVAL,
--               A.GRP,
--               A.MNGCLUVAL2,
--               A.MNGCLUDEC,
--               A.SLIPINNO,
--               A.SLIPINSEQ,
--               A.SLIPINDATE,
--               A.SLIPINNUM,
--               A.SLIPNO,
--               A.SLIPDATE,
--               A.SLIPNUM,
--               A.REMARK,
--               A.ORD,
--               CASE WHEN A.grp = 2 THEN b.debamt ELSE A.debamt END AS pos_2,
--               CASE WHEN A.grp = 2 THEN b.creamt ELSE A.creamt END AS pos_3,
--               CASE WHEN A.grp <> 1 THEN b.fnamt END AS pos_4
--          FROM   VGT.TT_ACACC0134R_ACORDD A
--               JOIN (SELECT   A.acccode,
--                      A.mngcluval,
--                      A.ord,
--                      SUM(b.debamt) debamt,
--                      SUM(b.creamt) creamt,
--                      SUM(b.fnamt) fnamt
--                 FROM    VGT.TT_ACACC0134R_ACORDD A
--                      JOIN VGT.TT_ACACC0134R_ACORDD b
--                        ON A.acccode = b.acccode
--                         AND NVL(A.mngcluval,' ') = NVL(b.mngcluval,' ')
--                         AND A.ord >= b.ord
--                         AND b.grp = 0
--                 GROUP BY A.acccode, A.mngcluval, A.ord) b
--                 ON A.acccode = b.acccode
--                  AND NVL(A.mngcluval,' ') = NVL(b.mngcluval,' ')
--                  AND A.ord = b.ord) src
--    ON       (A.ACCCODE = SRC.ACCCODE
--          AND NVL(A.MNGCLUVAL,' ') = NVL(SRC.MNGCLUVAL,' ')
--          AND A.GRP = SRC.GRP
--          AND A.MNGCLUVAL2 = SRC.MNGCLUVAL2
--          AND A.MNGCLUDEC = SRC.MNGCLUDEC
--          AND A.SLIPINNO = SRC.SLIPINNO
--          AND A.SLIPINSEQ = SRC.SLIPINSEQ
--          AND A.SLIPINDATE = SRC.SLIPINDATE
--          AND A.SLIPINNUM = SRC.SLIPINNUM
--          AND A.SLIPNO = SRC.SLIPNO
--          AND A.SLIPDATE = SRC.SLIPDATE
--          AND A.SLIPNUM = SRC.SLIPNUM
--          AND A.REMARK = SRC.REMARK
--          AND A.ORD = SRC.ORD)
--    WHEN MATCHED
--    THEN
--      UPDATE SET A.debamt = SRC.pos_2, A.creamt = SRC.pos_3, A.fnamt = SRC.pos_4;
--
--
--               DELETE FROM TT_ACACC0134R_ACORDD2;
--        INSERT INTO  TT_ACACC0134R_ACORDD2
--        SELECT * FROM TT_ACACC0134R_ACORDD2;


    DELETE VGT.TT_ACACC0134R_ACORDD
    WHERE  slipnum = '월계';




    OPEN IO_CURSOR FOR
      SELECT   A.ord,
           A.slipinno,
           A.slipinseq,
           A.slipindate,
           A.slipinnum,
           A.slipno,
           A.slipdate,
           A.slipnum,
           A.acccode,
           b.accname,
           A.mngcluval mngcluval,
           A.mngcluval2 mngcluval2,
           A.mngcludec mngcludec,
           A.remark,
           A.debamt,
           A.creamt,
           A.fnamt,
           A.acccode || ' : ' || b.accname acccodename,
           c.mngcluval mngcustcode,
           c.mngcludec mngcustname
      FROM   VGT.TT_ACACC0134R_ACORDD A
           LEFT JOIN ACACCM b ON A.acccode = b.acccode
           LEFT JOIN ACORDS c
             ON c.compcode = p_compcode
              AND c.slipinno = A.slipinno
              AND c.slipinseq = A.slipinseq
              AND c.mngclucode = 'S010'
      ORDER BY A.acccode, A.mngcluval, A.ord;
  END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
