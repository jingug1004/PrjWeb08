CREATE PROCEDURE        col_vir_Day_Conversion
-- ---------------------------------------------------------------
-- 프로시저명        :
-- 작 성 자        :
-- 작성일자         :
-- ---------------------------------------------------------------
-- 프로시저 설명     : SALE_ON.TRADEDATA_VTPMS 의 자료를 가져와서 수금처리함
--               JOB 스케줄로 5분마다 실행함
-- ---------------------------------------------------------------
(
   p_ymd                IN    VARCHAR2 DEFAULT ''
)
AS

   p_plantcode                VARCHAR2(30);
   p_coldate                  VARCHAR2(30);
   p_coldiv                   VARCHAR2(30);
   p_coldtldiv                VARCHAR2(30);
   p_orderdiv                 VARCHAR2(30);
   p_tasooyn                  VARCHAR2(30);
   p_custcode                 VARCHAR2(30);
   p_deptcode                 VARCHAR2(30);
   p_empcode                  VARCHAR2(30);
   p_ecustcode                VARCHAR2(30);
   p_edeptcode                VARCHAR2(30);
   p_eempcode                 VARCHAR2(30);
   p_colamt                   FLOAT := 0;
   p_colvat                   FLOAT := 0;
   p_accountno                VARCHAR2(50);
   p_billno                   VARCHAR2(30);
   p_issdate                  VARCHAR2(30);
   p_expdate                  VARCHAR2(30);
   p_paybank                  VARCHAR2(30);
   p_paybankbr                VARCHAR2(30);
   p_issempnm                 VARCHAR2(30);
   p_baeseo                   VARCHAR2(30);
   p_cardcomp                 VARCHAR2(30);
   p_cardno                   VARCHAR2(50);
   p_cardokno                 VARCHAR2(30);
   p_carddate                 VARCHAR2(30);
   p_divmonth                 FLOAT := 0;
   p_autoyn                   VARCHAR2(30);
   p_appdate                  VARCHAR2(30);
   p_discntdate               VARCHAR2(30);
   p_custprtyn                VARCHAR2(30);
   p_bigo                     VARCHAR2(30);
   p_remark                   VARCHAR2(30);
   p_apprstatus               VARCHAR2(30);
   p_moneycode                VARCHAR2(30);
   p_exrtrate                 FLOAT := 0;
   p_exrtamt                  FLOAT := 0;
   p_iempcode                 VARCHAR2(30);
   p_orderdate                VARCHAR2(30);
   p_cmsno                    VARCHAR2(50);

   v_custcode                 VARCHAR2(30);
   
   v_cnt                      number;

   CURSOR CARD_SUGUM_READ IS
      select TO_CHAR(TO_DATE(DEAL_STAR_DATE,'YYYYMMDD'),'YYYY-MM-DD')  --p_coldate  거래일자
            ,TO_NUMBER(TOTAL_AMT)                                      --p_colamt   금액
            ,CMS_NO                                                    --p_cmsno    CMS_NO(가상계좌)
            ,SUBSTR(ACCO_NUMB,1,3)||'-'||SUBSTR(ACCO_NUMB,4,6)||'-'||SUBSTR(ACCO_NUMB,10,2)||'-'||SUBSTR(ACCO_NUMB,12,3)  --p_accountno  계좌번호
            ,BANK_CD                                                   --p_paybank   은행코(R)
            ,COMP_CODE                                                 --p_paybankbr 업체코드
            ,SEQ_NO                                                    --p_issempnm  전문번호
            ,TRAN_DATE                                                 --p_baeseo    전송일자
            ,TRAN_TIME                                                 --p_cardcomp  전송시간
            ,DEAL_SELE                                                 --p_cardno    거래구분
        from SALE_ON.TRADEDATA_VTPMS
       where tran_date >= to_char(to_date(p_ymd,'yyyymmdd') - 20,'yyyymmdd')  --휴가등을 감안하여 20정도 잡음 
         and junpyo_no is null;

begin

   -- 가상계좌 처리
   OPEN CARD_SUGUM_READ;
   LOOP
      FETCH CARD_SUGUM_READ INTO p_coldate, p_colamt, p_cmsno, p_accountno, p_paybank, p_paybankbr, p_issempnm, p_baeseo, p_cardcomp, p_cardno;
      EXIT WHEN CARD_SUGUM_READ%NOTFOUND ;

         -- 가상계좌정보가 없으면 오류테이블에 저장하고 skip
         BEGIN 
            SELECT custcode INTO v_custcode FROM oragmp.cmcustm a WHERE  a.virtualaccount = TRIM(p_cmsno) ;
         EXCEPTION WHEN OTHERS THEN
         
             v_cnt := 0;
             select count(*) into v_cnt
               from SALE_ON.TRADEDATA_VTPMS_ERROR
              where YMD like TO_CHAR(SYSDATE,'YYYYMMDD')||'%'
                and CMS_NO = TRIM(p_cmsno)
                and COMMENTS like '가상계좌테이블(SALE.SALE0003VN)에'||'%' ;
             if v_cnt = 0 then    
                INSERT INTO SALE_ON.TRADEDATA_VTPMS_ERROR (YMD,CMS_NO,YMDTS,COMMENTS)
                VALUES (p_coldate,TRIM(p_cmsno),TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),'가상계좌테이블(SALE.SALE0003VN)에 정보가 없습니다. 가상계좌::'||TRIM(p_cmsno) );
                commit;
                continue;
             end if;
         END;

         BEGIN 
         --거래처코드로 거래처의 담당사원과 부서정보 없으면  오류테이블에 저장하고 skip
             SELECT A.EMPCODE , B.DEPTCODE
               INTO p_empcode , p_deptcode
               FROM ORAGMP.CMCUSTM A,
                    ORAGMP.CMEMPM  B
              WHERE a.empcode = b.empcode
                AND a.custcode = v_custcode;
         EXCEPTION WHEN OTHERS THEN
             v_cnt := 0;
             select count(*) into v_cnt
               from SALE_ON.TRADEDATA_VTPMS_ERROR
              where YMD like TO_CHAR(SYSDATE,'YYYYMMDD')||'%'
                and CMS_NO = TRIM(p_cmsno)
                and COMMENTS like '가상계좌의 거래처정보로 사원정보가 없음'||'%' ;
             if v_cnt = 0 then    
                INSERT INTO SALE_ON.TRADEDATA_VTPMS_ERROR (YMD,CMS_NO,YMDTS,COMMENTS)
                VALUES (p_coldate,TRIM(p_cmsno),TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS'),'가상계좌의 거래처정보로 사원정보가 없음  가상계좌::'||TRIM(p_cmsno)||' 거래처코드::'||v_custcode||' 사번:'||p_empcode||' 부서코드:'||p_deptcode );
                commit;
                continue;
             end if;                
            
         END; 

         p_custcode := v_custcode ; 

         p_carddate := p_coldate;
         p_appdate  := p_coldate;

         p_plantcode  := '1000';
--         p_coldate    := TO_CHAR(TO_DATE(:NEW.DEAL_STAR_DATE),'YYYY-MM-DD');
         p_coldiv     := '10';   --통장입금
         p_orderdiv   := '4';
         p_tasooyn    := 'N';
         p_custcode   := p_custcode;
         p_deptcode   := p_deptcode;
         p_empcode    := p_empcode ;
         p_ecustcode  := p_custcode;
         p_edeptcode  := p_deptcode;
         p_eempcode   := p_empcode;
--         p_colamt     := TO_NUMBER(:NEW.TOTAL_AMT);
         p_colvat     := 0;
--         p_accountno  := :NEW.ACCO_NUMB;                 --계좌번호
         p_billno     := '';
         p_issdate    := '';
         p_expdate    := '';
--         p_paybank    := :NEW.BANK_CD;                --은행코드
--         p_paybankbr  := :NEW.COMP_CODE;
--         p_issempnm   := :NEW.SEQ_NO;--
--         p_baeseo     := :NEW.TRAN_DATE;
--         p_cardcomp   := :NEW.TRAN_TIME;
--         p_cardno     := :NEW.DEAL_SELE;
         p_cardokno   := '';
         p_divmonth   := 0;
--         p_carddate   := TO_CHAR(TO_DATE(:NEW.DEAL_STAR_DATE),'YYYY-MM-DD');
         p_autoyn     := 'N';
--         p_appdate    := p_coldate;
         p_discntdate := '';
         p_custprtyn  := 'N';
         p_bigo       := '가상계좌';
         p_remark     := '가상계좌No:'||p_cmsno;   --가상계좌(CMS_NO)
         p_apprstatus := '00';
         p_exrtrate   := 0;
         p_exrtamt    := 0;
         p_iempcode   := 'TRADEDATA_VTPMS';

      ORAGMP.COL_SAL_spSLcol0099P (p_plantcode   => p_plantcode
                          ,p_coldate     => p_coldate
                          ,p_coldiv      => p_coldiv
                          ,p_coldtldiv   => p_coldtldiv
                          ,p_orderdiv    => p_orderdiv
                          ,p_tasooyn     => p_tasooyn
                          ,p_custcode    => p_custcode
                          ,p_deptcode    => p_deptcode
                          ,p_empcode     => p_empcode
                          ,p_ecustcode   => p_ecustcode
                          ,p_edeptcode   => p_edeptcode
                          ,p_eempcode    => p_eempcode
                          ,p_colamt      => p_colamt
                          ,p_colvat      => p_colvat
                          ,p_accountno   => '068-021768-01-053' /*p_accountno*/
                          ,p_billno      => p_billno
                          ,p_issdate     => p_issdate
                          ,p_expdate     => p_expdate
                          ,p_paybank     => p_paybank
                          ,p_paybankbr   => p_paybankbr
                          ,p_issempnm    => p_issempnm
                          ,p_baeseo      => p_baeseo
                          ,p_cardcomp    => p_cardcomp
                          ,p_cardno      => p_cardno
                          ,p_cardokno    => p_cardokno
                          ,p_carddate    => p_carddate
                          ,p_divmonth    => p_divmonth
                          ,p_autoyn      => p_autoyn
                          ,p_discntdate  => p_discntdate
                          ,p_custprtyn   => p_custprtyn
                          ,p_bigo        => p_bigo
                          ,p_remark      => p_remark
                          ,p_apprstatus  => p_apprstatus
                          ,p_moneycode   => p_moneycode
                          ,p_exrtrate    => p_exrtrate
                          ,p_exrtamt     => p_exrtamt
                          ,p_iempcode    => p_iempcode
--                          ,MESSAGE       => v_spSLSALERESULT_N_param
--                          ,IO_CURSOR     => IO_CURSOR
                          );

   END LOOP;
   CLOSE CARD_SUGUM_READ;

END;
/
