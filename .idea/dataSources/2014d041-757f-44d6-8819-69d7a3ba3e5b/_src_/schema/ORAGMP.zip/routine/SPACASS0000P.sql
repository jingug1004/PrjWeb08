CREATE PROCEDURE        spACass0000P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACass0000P
 -- 작 성 자         : 최용석
 -- 작성일자         : 2010-12-22
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-27
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 감가상각율을 등록,수정,삭제,조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_lifeyear      IN  NUMBER   DEFAULT 0 ,
    p_deprdiv       IN  VARCHAR2 DEFAULT '' ,
    p_deprerate     IN  FLOAT    DEFAULT 0 ,
    p_iempcode      IN  VARCHAR2 DEFAULT '' ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    ip_compcode VARCHAR2(3) := p_compcode;
    v_temp NUMBER := 0;

BEGIN

   MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    FOR  rec IN (   SELECT  compcode -- 법인코드 확인
                    FROM    CMPLANTM
                    WHERE   plantcode LIKE '%' AND ROWNUM <= 1
    )
    LOOP
        ip_compcode := rec.compcode ;
    END LOOP;


    IF ( p_div = 'S' ) THEN

        OPEN  IO_CURSOR FOR

            SELECT  ip_compcode compcode  ,
                    a.seq lifeyear  ,
                    p_deprdiv deprdiv  ,
                    NVL(b.deprerate, '0') deprerate
            FROM    SYSCALENDARMASTER a
                    LEFT JOIN ACDEPRM b   ON a.seq = b.lifeyear
                                             AND b.compcode = ip_compcode
                                             AND b.deprdiv = p_deprdiv
            WHERE  a.seq BETWEEN 2 AND 60 ;

    ELSIF ( p_div = 'I' ) THEN

        INSERT INTO ACDEPRM ( compcode, lifeyear, deprdiv, deprerate, insertdt, iempcode )
        VALUES ( ip_compcode, p_lifeyear, p_deprdiv, p_deprerate, SYSDATE, p_iempcode );

    ELSIF ( p_div = 'U' ) THEN

        FOR rec IN (
                        SELECT  COUNT(*) AS alias1
                        FROM    DUAL
                        WHERE NOT EXISTS (  SELECT  *
                                            FROM    ACDEPRM
                                            WHERE   compcode = ip_compcode
                                                    AND lifeyear = p_lifeyear
                                                    AND deprdiv = p_deprdiv )
        )
        LOOP
            v_temp := rec.alias1 ;
        END LOOP;


        IF v_temp = 1 THEN

            INSERT INTO ACDEPRM ( compcode, lifeyear, deprdiv, deprerate, insertdt, iempcode )
            VALUES ( ip_compcode, p_lifeyear, p_deprdiv, p_deprerate, SYSDATE, p_iempcode );

        ELSE

            UPDATE ACDEPRM
            SET deprerate = p_deprerate,
            updatedt = SYSDATE,
            uempcode = p_iempcode
            WHERE  compcode = ip_compcode
            AND lifeyear = p_lifeyear
            AND deprdiv = p_deprdiv;

        END IF;


    ELSIF ( p_div = 'D' ) THEN

        DELETE  ACDEPRM
        WHERE   compcode = ip_compcode
                AND lifeyear = p_lifeyear
                AND deprdiv = p_deprdiv;

    ELSIF ( p_div = 'SRATE' ) THEN

        MESSAGE := '';

        -- 감가상각율 조회
        FOR  rec IN (   SELECT  deprerate
                        FROM    ACDEPRM
                        WHERE   compcode = ip_compcode
                                AND lifeyear = p_lifeyear
                                AND deprdiv = p_deprdiv
        )
        LOOP
            MESSAGE := rec.deprerate ;
        END LOOP;

        IF ( MESSAGE IS NULL OR MESSAGE = '' OR MESSAGE < '0' ) THEN
            MESSAGE := '0' ;
        END IF;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
