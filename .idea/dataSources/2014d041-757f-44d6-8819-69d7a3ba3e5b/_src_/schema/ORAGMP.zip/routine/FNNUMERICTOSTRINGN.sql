CREATE FUNCTION fnNumericToStringN
-- ---------------------------------------------------------------
 -- 함 수 명			: fnNumericToStringN
 -- 작 성 자         : 강현철
 -- 작성일자         : 2007-10-15
 -- 작 성 자         : 임정호
 -- ---------------------------------------------------------------
 -- 함수설명			: Null 일때 null을 반환한다.
 -- 뭐하는 함수 인지 잘 모르겠음.
 -- ---------------------------------------------------------------

(
  ip_numeric IN NUMBER,
  p_div IN VARCHAR2 DEFAULT ' '
)
RETURN VARCHAR2
AS
   p_numeric NUMBER(20,5) := ip_numeric;
   p_minuscheck CHAR(1);
   p_kind CHAR(1);
   p_point NUMBER(10,0);
   p_integer NUMBER(20,5);
   p_integerstring VARCHAR2(20);
   p_magin NUMBER(20,5);
   p_maginstring VARCHAR2(20);
   p_maginstringlength NUMBER(10,0);
   p_tostring VARCHAR2(20);

BEGIN
   IF ( p_numeric IS NULL ) THEN


      RETURN NULL;


   END IF;


   p_minuscheck := CASE  WHEN p_numeric < 0 THEN 'Y' ELSE 'N' END ;



   p_numeric := CASE WHEN p_minuscheck = 'Y' THEN NVL(p_numeric, 0) * -1 ELSE NVL(p_numeric, 0) END ;



   p_kind := SUBSTR(p_div, 0, 1) ;
   p_kind := CASE  WHEN p_kind IS NULL THEN 'S' ELSE p_kind END ;


   p_point := CASE  WHEN LENGTH(p_div)= 2 THEN
                        SUBSTR(p_div, -1)
                    ELSE
                        CASE  WHEN isnumeric(p_div)= 1 THEN p_div ELSE 4 END
              END ;

   p_numeric := CASE WHEN p_kind = 'F' THEN FLOOR(p_numeric * POWER(10, p_point)) * POWER(0.1000, p_point)
                     ELSE round(p_numeric * POWER(10, p_point), 0) * POWER(0.1000, p_point)
                END ;

   p_integer := FLOOR(p_numeric) ;

   p_integerstring := TRIM(TO_CHAR(p_integer,'999,999,999,999,999'));


   p_magin := CASE  WHEN p_numeric > 0 THEN p_numeric - p_integer ELSE (p_numeric - p_integer) * -1 END ;
   p_maginstring := REPLACE(p_magin, '0.', '') ;
   p_maginstringlength := LENGTH(p_maginstring) ;

   IF ( LENGTH(p_div) = 2 ) THEN
      p_maginstring := SUBSTR(p_maginstring || '00000', 1, p_point) ;
   ELSIF ( LENGTH(p_div) = 1 ) THEN
         WHILE ( p_maginstringlength > 0 )
         LOOP
               IF ( SUBSTR(p_maginstring, -1) = '0' ) THEN
                  p_maginstring := SUBSTR(p_maginstring, 1, p_maginstringlength - 1) ;
               END IF;
               p_maginstringlength := p_maginstringlength - 1 ;
         END LOOP;

         p_maginstring := SUBSTR(p_maginstring, 1, p_point) ;
   END IF;

   p_tostring := p_integerstring || '.' || p_maginstring || '*' ;
   p_tostring := CASE p_kind
                            WHEN 'V' THEN REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(p_tostring, '0*', '*'), '0*', '*'), '0*', '*'), '0*', '*'), '0*', '*'), '0*', '*')
                            WHEN 'S' THEN REPLACE(p_tostring, '.' || TRIM(LPAD(' ',p_point+1,'0')), '')
                            ELSE p_tostring
                 END ;



   p_tostring := REPLACE(REPLACE(REPLACE(p_tostring, '.*', ''), '*', ''), ' ', '') ;
   p_tostring := CASE WHEN p_minuscheck = 'Y' THEN '-' || p_tostring ELSE p_tostring END ;
   p_tostring := CASE WHEN SUBSTR(p_div, 0, 1) = 'C' THEN REPLACE(p_tostring, ',', '') ELSE p_tostring END ;



   RETURN (p_tostring);

EXCEPTION WHEN OTHERS THEN RETURN NULL;
END;
/
