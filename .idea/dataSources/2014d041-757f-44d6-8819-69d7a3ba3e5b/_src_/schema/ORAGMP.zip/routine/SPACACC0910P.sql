CREATE PROCEDURE        spACacc0910P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0910P
 -- 작 성 자         : 최용석
 -- 작성일자         : 2011-11-16
  -- 수 정 자      : 강현호
 -- E-Mail     : roykang0722@gmail.com
 -- 수정일자      : 2016-12-19
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 대손충당금회계로드
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '' ,
    p_compcode      IN VARCHAR2 DEFAULT '' ,
    p_plantcode     IN VARCHAR2 DEFAULT '' ,
    p_yearmonth     IN VARCHAR2 DEFAULT '2013-01' ,
    p_custcode      IN VARCHAR2 DEFAULT '' ,
    p_colday        IN FLOAT    DEFAULT 180 ,
    p_accdiv        IN VARCHAR2 DEFAULT '' ,
    p_rate30        IN FLOAT    DEFAULT 100 ,
    p_rate60        IN FLOAT    DEFAULT 100 ,
    p_rate90        IN FLOAT    DEFAULT 100 ,
    p_rate120       IN FLOAT    DEFAULT 100 ,
    p_rate150       IN FLOAT    DEFAULT 100 ,
    p_rate180       IN FLOAT    DEFAULT 100 ,
    p_rate210       IN FLOAT    DEFAULT 100 ,
    p_rate240       IN FLOAT    DEFAULT 100 ,
    p_rate270       IN FLOAT    DEFAULT 100 ,
    p_rate300       IN FLOAT    DEFAULT 100 ,
    p_rate330       IN FLOAT    DEFAULT 100 ,
    p_rate360       IN FLOAT    DEFAULT 100 ,
    p_rate390       IN FLOAT    DEFAULT 100 ,
    p_slipamt       IN FLOAT    DEFAULT 0 ,
    p_iempcode      IN VARCHAR2 DEFAULT '' ,
    p_userid        IN VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN VARCHAR2 DEFAULT '' ,
    p_reasontext    IN VARCHAR2 DEFAULT '' ,

    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    ip_slipamt FLOAT := p_slipamt;
    p_strdate  VARCHAR2(10);
    p_enddate  VARCHAR2(10);
    p_acccode1 VARCHAR2(20); -- 외상매출금
    p_acccode2 VARCHAR2(20);-- 받을어음

    p_dt  DATE;
    p_sdt VARCHAR2(10);
    p_edt VARCHAR2(10);
    p_j_ym CHAR(7);

    v_temp NUMBER := 0;

    p_acautorcode VARCHAR2(10);
    p_slipdiv VARCHAR2(5);
    p_slipnum VARCHAR2(5);
    p_slipinno VARCHAR2(20);
    p_empname VARCHAR2(50);
    p_deptcode VARCHAR2(20);
    p_deptname VARCHAR2(50);
    p_remark VARCHAR2(100);


    ip_custcode VARCHAR2(50);
    ip_seq NUMBER;

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    p_strdate := SUBSTR(p_yearmonth, 0, 5) || '01-01' ;

    p_enddate := TO_CHAR(ADD_MONTHS(TO_DATE(p_yearmonth|| '-01', 'YYYY-MM-DD'), 1) - 1,'YYYY-MM-DD') ;

    p_acccode1 := '11108010' ;

    FOR  rec IN (   SELECT  filter1
                    FROM    CMCOMMONM
                    WHERE   cmmcode = 'AC261'
                            AND divcode = '11108010' )
    LOOP
        p_acccode1 := rec.filter1 ;
    END LOOP;

    p_acccode2 := '1110806' ;

    FOR  rec IN (   SELECT  filter1
                    FROM    CMCOMMONM
                    WHERE   cmmcode = 'AC261'
                    AND divcode = '1110806' )
    LOOP
        p_acccode2 := rec.filter1 ;
    END LOOP;


    IF ( p_div = 'SB' AND p_accdiv = '1' ) THEN


        IF p_yearmonth = TO_CHAR(SYSDATE, 'YYYY-MM') THEN                                                   -- 조회년월이 현재월과 동일하면
            p_dt := SYSDATE ;                                                                               -- @dt는 오늘일자
        ELSIF p_yearmonth < TO_CHAR(SYSDATE, 'YYYY-MM') THEN                                                -- 조회년월이 현재월보다 작으면
            p_dt := ADD_MONTHS(TO_DATE(p_yearmonth || '-01', 'YYYY-MM-DD'), 1) -1 ;   -- 조회년월의 마지막 일자
        END IF;


        p_sdt := TO_CHAR(ADD_MONTHS(TO_DATE(p_yearmonth || '-01', 'YYYY-MM-DD'), -12*2)-1, 'YYYY-MM-DD') ;  -- 조회년월의 2년 전 일자
        p_edt := TO_CHAR(ADD_MONTHS(TO_DATE(p_yearmonth || '-01', 'YYYY-MM-DD'), 1) -1, 'YYYY-MM-DD') ;     -- 조회년월의 마지막 일자
        p_j_ym := TO_CHAR(TO_DATE(p_yearmonth || '-01', 'YYYY-MM-DD') -1, 'YYYY-MM') ;                      -- 조회년월의 전월





        -- 회전일별 매출,잔고이월
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_RESULT1';

        INSERT INTO VGT.TT_ACACC0910P_RESULT1
            SELECT  custcode ,
                    NVL(SUM(CASE WHEN appdate <= TO_CHAR(p_dt, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 30, 'YYYY-MM-DD') THEN --    1 ~ 30
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt30  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 30, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 60, 'YYYY-MM-DD') THEN -- 31 ~ 60
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt60  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 60, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 90, 'YYYY-MM-DD') THEN -- 61 ~ 90
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt90  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 90, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 120, 'YYYY-MM-DD') THEN -- 91 ~ 120
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt120  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 120, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 150, 'YYYY-MM-DD') THEN -- 121 ~ 150
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt150  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 150, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 180, 'YYYY-MM-DD') THEN -- 151 ~ 180
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt180  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 180, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 210, 'YYYY-MM-DD') THEN -- 181 ~ 210
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt210  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 210, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 240, 'YYYY-MM-DD') THEN -- 211 ~ 240
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt240  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 240, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 270, 'YYYY-MM-DD') THEN -- 241 ~ 270
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt270  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 270, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 300, 'YYYY-MM-DD') THEN -- 271 ~ 300
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt300  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 300, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 330, 'YYYY-MM-DD') THEN -- 301 ~ 330
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt330  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 330, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 360, 'YYYY-MM-DD') THEN -- 331 ~ 360
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                                 WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                                 ELSE -totamt
                                            END
                                 ELSE 0
                            END) , 0) amt360  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 360, 'YYYY-MM-DD') THEN -- 361 ~
                                        CASE WHEN SUBSTR(saldiv, 0, 1) = 'A' THEN totamt
                                             WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN -colamt
                                             ELSE -totamt
                                        END
                                 ELSE 0
                            END) , 0) amt390

            FROM    vnSalesMagam

            WHERE   ( SUBSTR(saldiv, -2, 2) < '60' AND saldiv <> 'C01' OR
                       saldiv = 'C01' AND coldiv = '55' AND colamt < 0 ) --잔고이월을 매출일자로 본다
                    AND SUBSTR(saldiv, 0, 1) <> 'B'
                    AND statediv = '09'
                    AND plantcode LIKE p_plantcode
                    AND appdate <= TO_CHAR(p_dt, 'YYYY-MM-DD')

            GROUP BY custcode ;


            
            

        -- 180일이내 수금구하기
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_RESULT2';

        INSERT INTO VGT.TT_ACACC0910P_RESULT2
            SELECT  custcode ,
                    SUM(colamt)  colamt
            FROM    vnSalesMagam
            WHERE   SUBSTR(saldiv, 0, 1) = 'C'
                    AND coldiv <> '55' --잔고이월 제외
                    AND statediv = '09'
                    AND plantcode LIKE p_plantcode
                    AND appdate BETWEEN TO_CHAR(p_dt - p_colday + 1, 'YYYY-MM-DD') AND TO_CHAR(p_dt, 'YYYY-MM-DD')
            GROUP BY custcode ;





        -- 현재 잔고구하기
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_RESULT3';

        INSERT INTO VGT.TT_ACACC0910P_RESULT3
            SELECT  custcode ,
                    MAX(custname)  custname  ,
                    MAX(utdiv)  utdiv  ,
                    MAX(utdivnm)  utdivnm  ,
                    SUM(pendbillcol)  bill  ,
                    SUM(balance)  jango  ,
                    SUM(pendbillcol + balance)  totjango  ,
                    MAX(turncnt)  turncnt
            FROM    vnResultm
            WHERE   yearmonth = p_yearmonth
                    AND plantcode LIKE p_plantcode
                    AND ( custcode LIKE NVL(TRIM(p_custcode), ' ') || '%'
                    OR custname LIKE '%' || NVL(TRIM(p_custcode), '') || '%' )
            GROUP BY custcode ;

            

        -- 회전일 임시파일생성
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_RESULTS';

        INSERT INTO VGT.TT_ACACC0910P_RESULTS
            SELECT  A.utdiv ,
                    A.utdivnm ,
                    A.custcode ,
                    A.custname ,
                    NVL(A.totjango, 0) totjango ,   --총잔고(jango+미도래어음)
                    NVL(A.jango, 0) jango ,         --jango
                    NVL(A.bill, 0) bill ,           --미도래어음
                    NVL(A.turncnt, 0) turncnt ,     --회전일
                    CASE WHEN A.turncnt <= 0 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) THEN NVL(b.amt30, 0)
                                   ELSE A.jango
                              END
                    END amt30  ,

                    CASE WHEN A.turncnt <= 30 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) THEN NVL(b.amt60, 0)
                                   ELSE A.jango - NVL(b.amt30, 0)
                              END
                    END amt60  ,

                    CASE WHEN A.turncnt <= 60 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) THEN NVL(b.amt90, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0)
                              END
                    END amt90  ,

                    CASE WHEN A.turncnt <= 90 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) + NVL(b.amt120, 0) THEN NVL(b.amt120, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0) - NVL(b.amt90, 0)
                              END
                    END amt120  ,

                    CASE WHEN A.turncnt <= 120 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) + NVL(b.amt120, 0) + NVL(b.amt150, 0) THEN NVL(b.amt150, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0) - NVL(b.amt90, 0) - NVL(b.amt120, 0)
                              END
                    END amt150  ,

                    CASE WHEN A.turncnt <= 150 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) + NVL(b.amt120, 0) + NVL(b.amt150, 0) + NVL(b.amt180, 0) THEN NVL(b.amt180, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0) - NVL(b.amt90, 0) - NVL(b.amt120, 0) - NVL(b.amt150, 0)
                              END
                    END amt180  ,

                    CASE WHEN A.turncnt <= 180 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) + NVL(b.amt120, 0) + NVL(b.amt150, 0) + NVL(b.amt180, 0) + NVL(b.amt210, 0) THEN NVL(b.amt210, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0) - NVL(b.amt90, 0) - NVL(b.amt120, 0) - NVL(b.amt150, 0) - NVL(b.amt180, 0)
                              END
                    END amt210  ,

                    CASE WHEN A.turncnt <= 210 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) + NVL(b.amt120, 0) + NVL(b.amt150, 0) + NVL(b.amt180, 0) + NVL(b.amt210, 0) + NVL(b.amt240, 0) THEN NVL(b.amt240, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0) - NVL(b.amt90, 0) - NVL(b.amt120, 0) - NVL(b.amt150, 0) - NVL(b.amt180, 0) - NVL(b.amt210, 0)
                              END
                    END amt240  ,

                    CASE WHEN A.turncnt <= 240 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) + NVL(b.amt120, 0) + NVL(b.amt150, 0) + NVL(b.amt180, 0) + NVL(b.amt210, 0) + NVL(b.amt240, 0) + NVL(b.amt270, 0) THEN NVL(b.amt270, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0) - NVL(b.amt90, 0) - NVL(b.amt120, 0) - NVL(b.amt150, 0) - NVL(b.amt180, 0) - NVL(b.amt210, 0) - NVL(b.amt240, 0)
                              END
                    END amt270  ,

                    CASE WHEN A.turncnt <= 270 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) + NVL(b.amt120, 0) + NVL(b.amt150, 0) + NVL(b.amt180, 0) + NVL(b.amt210, 0) + NVL(b.amt240, 0) + NVL(b.amt270, 0) + NVL(b.amt300, 0) THEN NVL(b.amt300, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0) - NVL(b.amt90, 0) - NVL(b.amt120, 0) - NVL(b.amt150, 0) - NVL(b.amt180, 0) - NVL(b.amt210, 0) - NVL(b.amt240, 0) - NVL(b.amt270, 0)
                              END
                    END amt300  ,

                    CASE WHEN A.turncnt <= 300 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) + NVL(b.amt120, 0) + NVL(b.amt150, 0) + NVL(b.amt180, 0) + NVL(b.amt210, 0) + NVL(b.amt240, 0) + NVL(b.amt270, 0) + NVL(b.amt300, 0) + NVL(b.amt330, 0) THEN NVL(b.amt330, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0) - NVL(b.amt90, 0) - NVL(b.amt120, 0) - NVL(b.amt150, 0) - NVL(b.amt180, 0) - NVL(b.amt210, 0) - NVL(b.amt240, 0) - NVL(b.amt270, 0) - NVL(b.amt300, 0)
                              END
                    END amt330  ,

                    CASE WHEN A.turncnt <= 330 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) + NVL(b.amt120, 0) + NVL(b.amt150, 0) + NVL(b.amt180, 0) + NVL(b.amt210, 0) + NVL(b.amt240, 0) + NVL(b.amt270, 0) + NVL(b.amt300, 0) + NVL(b.amt330, 0) + NVL(b.amt360, 0) THEN NVL(b.amt360, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0) - NVL(b.amt90, 0) - NVL(b.amt120, 0) - NVL(b.amt150, 0) - NVL(b.amt180, 0) - NVL(b.amt210, 0) - NVL(b.amt240, 0) - NVL(b.amt270, 0) - NVL(b.amt300, 0) - NVL(b.amt330, 0)
                              END
                    END amt360  ,

                    CASE WHEN A.turncnt <= 360 THEN 0
                         ELSE CASE WHEN A.jango > NVL(b.amt30, 0) + NVL(b.amt60, 0) + NVL(b.amt90, 0) + NVL(b.amt120, 0) + NVL(b.amt150, 0) + NVL(b.amt180, 0) + NVL(b.amt210, 0) + NVL(b.amt240, 0) + NVL(b.amt270, 0) + NVL(b.amt300, 0) + NVL(b.amt330, 0) + NVL(b.amt360, 0) + NVL(b.amt390, 0) THEN NVL(b.amt390, 0)
                                   ELSE A.jango - NVL(b.amt30, 0) - NVL(b.amt60, 0) - NVL(b.amt90, 0) - NVL(b.amt120, 0) - NVL(b.amt150, 0) - NVL(b.amt180, 0) - NVL(b.amt210, 0) - NVL(b.amt240, 0) - NVL(b.amt270, 0) - NVL(b.amt300, 0) - NVL(b.amt330, 0) - NVL(b.amt360, 0)
                              END
                    END amt390
            FROM    VGT.TT_ACACC0910P_RESULT3 A
                    LEFT JOIN VGT.TT_ACACC0910P_RESULT1 b ON A.custcode = b.custcode
                    LEFT JOIN VGT.TT_ACACC0910P_RESULT2 c ON A.custcode = c.custcode
            WHERE   NVL(c.colamt, 0) = 0 ;





        -- 거래처별 수금현황
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_RESULT4';

        INSERT INTO VGT.TT_ACACC0910P_RESULT4
            SELECT  custcode ,
                    NVL(SUM(CASE WHEN appdate <= TO_CHAR(p_dt, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 30, 'YYYY-MM-DD') THEN --    1 ~ 30
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN colamt ELSE 0 END
                                  ELSE 0
                            END) , 0) col30  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 30, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 60, 'YYYY-MM-DD') THEN -- 31 ~ 60
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN colamt ELSE 0 END
                                 ELSE 0
                            END) , 0) col60  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 60, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 90, 'YYYY-MM-DD') THEN -- 61 ~ 90
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN colamt ELSE 0 END
                                 ELSE 0
                            END) , 0) col90  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 90, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 120, 'YYYY-MM-DD') THEN -- 91 ~ 120
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN colamt ELSE 0 END
                                 ELSE 0
                            END) , 0) col120  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 120, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 150, 'YYYY-MM-DD') THEN -- 121 ~ 150
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN colamt ELSE 0 END
                                 ELSE 0
                            END) , 0) col150  ,

                    NVL(SUM(CASE WHEN appdate < TO_CHAR(p_dt - 150, 'YYYY-MM-DD')
                                      AND appdate >= TO_CHAR(p_dt - 180, 'YYYY-MM-DD') THEN -- 151 ~ 180
                                            CASE WHEN SUBSTR(saldiv, 0, 1) = 'C' THEN colamt ELSE 0 END
                                 ELSE 0
                            END) , 0) col180

            FROM    vnSalesMagam
            WHERE   saldiv = 'C01'
                    AND coldiv <> '55'
                    AND statediv = '09'
                    AND plantcode LIKE p_plantcode
                    AND appdate <= TO_CHAR(p_dt, 'YYYY-MM-DD')
            GROUP BY custcode ;





        OPEN  IO_CURSOR FOR

            SELECT  CASE WHEN NVL(TRIM(c.custcode), '') IS NOT NULL THEN 'Y' ELSE 'N' END chk  ,
                    A.utdiv ,
                    A.custcode ,
                    A.custname ,
                    A.utdivnm ,
                    A.totjango ,--총잔고(jango+미도래어음)
                    A.jango ,--jango
                    A.bill ,--미도래어음
                    A.amt30 ,
                    A.amt60 ,
                    A.amt90 ,
                    A.amt120 ,
                    A.amt150 ,
                    A.amt180 ,
                    A.amt210 ,
                    A.amt240 ,
                    A.amt270 ,
                    A.amt300 ,
                    A.amt330 ,
                    A.amt360 ,
                    A.amt390 ,
                    NVL(c.rate390, 0) rate390  ,
                    A.turncnt ,
                    NVL(b.col30, 0) col30  ,
                    NVL(b.col60, 0) col60  ,
                    NVL(b.col90, 0) col90  ,
                    NVL(b.col120, 0) col120  ,
                    NVL(b.col150, 0) col150  ,
                    NVL(b.col180, 0) col180

            FROM    VGT.TT_ACACC0910P_RESULTS A
                    LEFT JOIN VGT.TT_ACACC0910P_RESULT4 B ON A.custcode = b.custcode
                    LEFT JOIN ACBADSETD c ON c.yearmonth = p_yearmonth
                                             AND A.custcode = c.custcode

            ORDER BY A.utdiv, A.custcode ;


    ELSIF ( p_div = 'SB' AND p_accdiv = '2' ) THEN

        -- 임시 테이블 삭제
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_ACORDSMM1';

        -- 1. 거래처별 잔액구하기
        INSERT INTO VGT.TT_ACACC0910P_ACORDSMM1 (
            
            SELECT  SUBSTR(A.acccode, 0, 7) || '0' acccode  ,
                    A.custcode ,
                    SUM(A.bsdebamt - A.bscreamt)  jango
            FROM (  SELECT  A.acccode ,
                            A.mngcluval custcode  ,
                            A.bsdebamt ,
                            A.bscreamt
                    FROM    ACORDSMM A
                    WHERE   A.compcode = p_compcode
                            AND A.plantcode LIKE p_plantcode
                            AND A.slipym = SUBSTR(p_yearmonth, 0, 5) || '01'
                            AND A.closediv IN ( '10','20' )
                            AND ( A.acccode = p_acccode1 OR NVL(A.acccode, ' ') LIKE p_acccode2 || '%' )
                            AND NVL(A.mngclucode,' ') = 'S010'
                            AND NVL(A.mngcluval,' ') LIKE p_custcode || '%'
                            AND NVL(TRIM(A.mngcluval), '') IS NOT NULL
                    
                    UNION ALL
                    
                    SELECT  A.acccode ,
                            b.mngcluval custcode  ,
                            A.debamt ,
                            A.creamt
                    FROM    ACORDD A
                            JOIN ACORDS b   ON A.compcode = b.compcode
                                                AND A.slipinno = b.slipinno
                                                AND A.slipinseq = b.slipinseq
                                                AND b.mngclucode = 'S010'
                                                AND NVL(b.mngcluval, ' ') LIKE p_custcode || '%'
                                                AND NVL(TRIM(b.mngcluval), '') IS NOT NULL
                            JOIN ACORDM c   ON A.compcode = c.compcode
                                                AND A.slipinno = c.slipinno
                                                AND c.slipdiv <> 'F'
                            WHERE   A.compcode = p_compcode
                                    AND A.plantcode LIKE p_plantcode
                                    AND ( A.acccode = p_acccode1 OR NVL(A.acccode,' ') LIKE p_acccode2 || '%' )
                                    AND A.slipdate BETWEEN p_strdate AND p_enddate ) A
            GROUP BY SUBSTR(A.acccode, 0, 7), A.custcode
            HAVING SUM(A.bsdebamt - A.bscreamt)  <> 0

        ) ;



        --임시 테이블 삭제
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_ACORDSMM2';

        INSERT INTO VGT.TT_ACACC0910P_ACORDSMM2 (

            SELECT  D.custcode ,
                    ROW_NUMBER() OVER ( PARTITION BY D.custcode ORDER BY A.slipno DESC, b.slipinseq DESC  ) seq  ,
                    A.slipdate ,
                    A.slipno ,
                    b.slipinseq ,
                    b.debamt + b.creamt slipamt  ,
                    0 sumamt
            FROM    ACORDM A
                    JOIN ACORDD b   ON A.compcode = b.compcode
                                        AND A.slipinno = b.slipinno
                                        AND b.acccode = p_acccode1
                                        AND b.slipdate BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_enddate, 'YYYY-MM-DD'), -12*3), 'YYYY-MM-DD') AND p_enddate
                    JOIN ACORDS c   ON b.compcode = c.compcode
                                        AND b.slipinno = c.slipinno
                                        AND b.slipinseq = c.slipinseq
                                        AND c.mngclucode = 'S010'
                    JOIN VGT.TT_ACACC0910P_ACORDSMM1 D   ON D.acccode = p_acccode1
                                        AND c.mngcluval = D.custcode
                                        AND b.dcdiv IN ( '1','4' )
                                        AND b.debamt > 0
                                        AND D.jango > 0
        ) ;


        


        FOR rec IN (        
            SELECT  --COMPARE DATA
                    A.custcode ,
                    A.seq ,
                    --UPDATE DATA
                    SUM(b.slipamt)  sumamt
            FROM    VGT.TT_ACACC0910P_ACORDSMM2 A
                    LEFT JOIN VGT.TT_ACACC0910P_ACORDSMM2 b ON A.custcode = b.custcode AND A.seq > b.seq
            GROUP BY A.custcode,A.seq 
        )
        LOOP
            
            UPDATE  VGT.TT_ACACC0910P_ACORDSMM2 A
            SET     sumamt = rec.sumamt
            WHERE   A.custcode = rec.custcode AND A.seq = rec.seq ;
            
        END LOOP ; 



       


        FOR rec IN (   
        
            SELECT  A.custcode
                    , A.seq
            FROM    VGT.TT_ACACC0910P_ACORDSMM2 A
                    JOIN (  SELECT  A.custcode
                                    , MIN(A.seq) AS seq
                            FROM    VGT.TT_ACACC0910P_ACORDSMM2 A
                                    JOIN VGT.TT_ACACC0910P_ACORDSMM1 b ON b.acccode = p_acccode1
                                                                          AND A.custcode = b.custcode
                                                                          AND A.sumamt >= b.jango
                            GROUP BY A.custcode ) b ON A.custcode = b.custcode
                                                       AND A.seq >= b.seq
        )
        LOOP
            ip_custcode := rec.custcode ;
            ip_seq := rec.seq ;

            DELETE FROM VGT.TT_ACACC0910P_ACORDSMM2 A
            WHERE   A.custcode = ip_custcode
                    AND A.seq >= ip_seq ;

        END LOOP;


        
       
        FOR rec IN ( 
            SELECT  --COMAPRE DATA
                    A.custcode
                    , A.seq
                    --UPDATE DATA
                    , CASE WHEN NVL(b.jango,0) - NVL(A.sumamt,0) >= NVL(A.slipamt,0) THEN NVL(A.slipamt,0)
                           ELSE NVL(b.jango,0) - NVL(A.sumamt,0)
                    END AS slipamt
            FROM    VGT.TT_ACACC0910P_ACORDSMM2 A
                    JOIN (  SELECT  A.custcode ,
                                    MAX(b.seq)  seq ,
                                    MAX(A.jango)  jango
                            FROM    VGT.TT_ACACC0910P_ACORDSMM1 A
                                    JOIN VGT.TT_ACACC0910P_ACORDSMM2 b ON A.custcode = b.custcode
                            WHERE   A.acccode = p_acccode1
                                    AND A.jango > 0
                            GROUP BY A.custcode ) B ON A.custcode = b.custcode
                                                       AND A.seq = b.seq                 
        )
        LOOP
        
            UPDATE  VGT.TT_ACACC0910P_ACORDSMM2 A
            SET     A.slipamt = rec.slipamt 
            WHERE   A.custcode = rec.custcode AND A.seq = rec.seq ;
            
        END LOOP ;  


        



        --임시 테이블 삭제
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_AGING';

        INSERT INTO VGT.TT_ACACC0910P_AGING (

            SELECT  A.custcode ,
                    b.custname ,
                    b.utdiv ,
                    c.divname utdivnm  ,
                    A.jango ,
                    A.amt30 ,
                    A.amt60 ,
                    A.amt90 ,
                    A.amt120 ,
                    A.amt150 ,
                    A.amt180 ,
                    A.amt210 ,
                    A.amt240 ,
                    A.amt270 ,
                    A.amt300 ,
                    A.amt330 ,
                    A.amt360 ,
                    A.amt390 ,
                    DATEDIFF('DAY', To_DATE(slipdate, 'YYYY-MM-DD'), TO_DATE(p_enddate, 'YYYY-MM-DD') ) turncnt

            FROM (  SELECT  A.custcode ,
                            MAX(A.jango)  jango  ,
                            SUM(CASE WHEN b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -30, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt30  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -30, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -60, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt60  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -60, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -90, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt90  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -90, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -120, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt120  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -120, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -150, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt150  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -150, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -180, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt180  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -180, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -210, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt210  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -210, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -240, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt240  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -240, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -270, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt270  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -270, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -300, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt300  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -300, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -330, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt330  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -330, 'YYYY-MM-DD')
                                          AND b.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -360, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt360  ,

                            SUM(CASE WHEN b.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -360, 'YYYY-MM-DD') THEN b.slipamt
                                     ELSE 0
                                END)  amt390  ,

                            MIN(b.slipdate)  slipdate

                    FROM    VGT.TT_ACACC0910P_ACORDSMM1 A
                            LEFT JOIN VGT.TT_ACACC0910P_ACORDSMM2 b   ON A.custcode = b.custcode
                    WHERE   A.acccode = p_acccode1
                            AND A.jango > 0
                    GROUP BY A.custcode

                    UNION

                    SELECT  A.custcode ,
                            A.jango ,
                            A.jango ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            0 ,
                            NULL
                    FROM    VGT.TT_ACACC0910P_ACORDSMM1 A
                    WHERE   A.acccode = p_acccode1
                            AND A.jango <= 0 ) A
            LEFT JOIN CMCUSTM b   ON A.custcode = b.custcode
            LEFT JOIN CMCOMMONM c   ON b.utdiv = c.divcode
                                        AND c.cmmcode = 'CM15'

        );

        
        



        UPDATE VGT.TT_ACACC0910P_AGING A
        SET amt390 = jango - amt30 - amt60 - amt90 - amt120 - amt150 - amt180 - amt210 - amt240 - amt270 - amt300 - amt330 - amt360;


        


        --임시 테이블 삭제
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_ACORDSMM3';

        INSERT INTO VGT.TT_ACACC0910P_ACORDSMM3 (
            SELECT  b.mngcluval custcode  ,
                    SUM(CASE WHEN A.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 30 , 'YYYY-MM-DD') THEN A.creamt
                             ELSE 0
                        END)  col30  ,
                    SUM(CASE WHEN A.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 30 , 'YYYY-MM-DD')
                                    AND A.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 60 , 'YYYY-MM-DD') THEN A.creamt
                             ELSE 0
                        END)  col60  ,
                    SUM(CASE WHEN A.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 60 , 'YYYY-MM-DD')
                                    AND A.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 90 , 'YYYY-MM-DD') THEN A.creamt
                             ELSE 0
                        END)  col90  ,
                    SUM(CASE WHEN A.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 90 , 'YYYY-MM-DD')
                                    AND A.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 120 , 'YYYY-MM-DD') THEN A.creamt
                             ELSE 0
                        END)  col120  ,
                    SUM(CASE WHEN A.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 120 , 'YYYY-MM-DD')
                                    AND A.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 150 , 'YYYY-MM-DD') THEN A.creamt
                             ELSE 0
                        END)  col150  ,
                    SUM(CASE WHEN A.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 150 , 'YYYY-MM-DD') THEN A.creamt
                             ELSE 0
                        END)  col180
            FROM    ACORDD A
                    JOIN ACORDS b   ON A.compcode = b.compcode
                                        AND A.slipinno = b.slipinno
                                        AND A.slipinseq = b.slipinseq
                                        AND b.mngclucode = 'S010'
                                        AND b.mngcluval LIKE p_custcode || '%'
            WHERE   A.compcode = p_compcode
                    AND A.plantcode LIKE p_plantcode
                    AND A.acccode = p_acccode1
                    AND A.slipdate BETWEEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 120, 'YYYY-MM-DD') AND p_enddate
                    AND A.dcdiv IN ( '2', '3' )
            GROUP BY b.mngcluval
        );

        
       
        


--        --임시 테이블 삭제
--        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_ACORDSMM3';
--
--        INSERT INTO VGT.TT_ACACC0910P_ACORDSMM3 (
--            SELECT  b.mngcluval custcode  ,
--                    SUM(CASE WHEN A.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 30 , 'YYYY-MM-DD') THEN A.creamt
--                             ELSE 0
--                        END)  col30  ,
--                    SUM(CASE WHEN A.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 30 , 'YYYY-MM-DD')
--                                    AND A.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 60 , 'YYYY-MM-DD') THEN A.creamt
--                             ELSE 0
--                        END)  col60  ,
--                    SUM(CASE WHEN A.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 60 , 'YYYY-MM-DD')
--                                    AND A.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 90 , 'YYYY-MM-DD') THEN A.creamt
--                             ELSE 0
--                        END)  col90  ,
--                    SUM(CASE WHEN A.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 90 , 'YYYY-MM-DD')
--                                    AND A.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 120 , 'YYYY-MM-DD') THEN A.creamt
--                             ELSE 0
--                        END)  col120  ,
--                    SUM(CASE WHEN A.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 120 , 'YYYY-MM-DD')
--                                    AND A.slipdate >= TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 150 , 'YYYY-MM-DD') THEN A.creamt
--                             ELSE 0
--                        END)  col150  ,
--                    SUM(CASE WHEN A.slipdate < TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 150 , 'YYYY-MM-DD') THEN A.creamt
--                             ELSE 0
--                        END)  col180
--            FROM    ACORDD A
--                    JOIN ACORDS b   ON A.compcode = b.compcode
--                                        AND A.slipinno = b.slipinno
--                                        AND A.slipinseq = b.slipinseq
--                                        AND b.mngclucode = 'S010'
--                                        AND b.mngcluval LIKE NVL(TRIM(p_custcode), ' ') || '%'
--            WHERE   A.compcode = p_compcode
--                    AND A.plantcode LIKE p_plantcode
--                    AND A.acccode = p_acccode1
--                    AND A.slipdate BETWEEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') - 120, 'YYYY-MM-DD') AND p_enddate
--                    AND A.dcdiv IN ( '2', '3' )
--            GROUP BY b.mngcluval
--        );





        --임시 테이블 삭제
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_ACORDSMM4';

        INSERT INTO VGT.TT_ACACC0910P_ACORDSMM4 (
            SELECT  b.mngcluval custcode  ,
                    SUM(A.creamt)  colamt
            FROM    ACORDD A
                    JOIN ACORDS b   ON A.compcode = b.compcode
                                        AND A.slipinno = b.slipinno
                                        AND A.slipinseq = b.slipinseq
                                        AND b.mngclucode = 'S010'
                                        AND b.mngcluval LIKE NVL(TRIM(p_custcode), ' ') || '%'
            WHERE   A.compcode = p_compcode
                    AND A.plantcode LIKE p_plantcode
                    AND A.acccode = p_acccode1
                    AND A.slipdate BETWEEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD') -p_colday + 1, 'YYYY-MM-DD') AND p_enddate
                    AND A.dcdiv IN ( '2', '3' )
            GROUP BY b.mngcluval       
        );
        





        INSERT INTO VGT.TT_ACACC0910P_AGING (
            SELECT  A.custcode ,
                    c.custname ,
                    c.utdiv ,
                    D.divname utdivnm  ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    NULL
            FROM    VGT.TT_ACACC0910P_ACORDSMM1 A
                    LEFT JOIN VGT.TT_ACACC0910P_AGING b  ON A.custcode = b.custcode
                    LEFT JOIN CMCUSTM c     ON A.custcode = c.custcode
                    LEFT JOIN CMCOMMONM D   ON UPPER(c.utdiv) = UPPER(D.divcode)
                                               AND UPPER(D.cmmcode) = UPPER('CM15')
            WHERE   NVL(TRIM(b.custcode), '') IS NULL
        );





        INSERT INTO VGT.TT_ACACC0910P_AGING (
            SELECT  A.custcode ,
                    c.custname ,
                    c.utdiv ,
                    D.divname utdivnm  ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    0 ,
                    NULL
            FROM    VGT.TT_ACACC0910P_ACORDSMM3 A
                    LEFT JOIN VGT.TT_ACACC0910P_AGING b ON A.custcode = b.custcode
                    LEFT JOIN CMCUSTM c    ON A.custcode = c.custcode
                    LEFT JOIN CMCOMMONM D  ON UPPER(c.utdiv) = UPPER(D.divcode)
                                              AND UPPER(D.cmmcode) = UPPER('CM15')
            WHERE  NVL(TRIM(b.custcode), '') IS NULL
        );





        --임시 테이블 삭제
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0910P_ACBILLM';

        INSERT INTO VGT.TT_ACACC0910P_ACBILLM        
            SELECT  CUSTCODE
                    , SUM(billamt) billamt
            FROM    ACBILLM
            WHERE   billcls = '1'
                    AND coldate <= p_enddate
                    AND p_enddate < expdate
                    AND p_plantcode = '1000'
            GROUP BY custcode ;





        OPEN  IO_CURSOR FOR

            SELECT  CASE WHEN NVL(TRIM(E.custcode), '') IS NOT NULL THEN 'Y'
                         ELSE 'N'
                    END chk  ,
                    A.utdiv ,
                    A.custcode ,
                    A.custname ,
                    A.utdivnm ,
                    A.jango + NVL(b.billamt, 0) totjango ,  --총잔고(jango+미도래어음)
                    A.jango ,                               --jango
                    NVL(b.billamt, 0) bill ,                --미도래어음
                    A.amt30 ,
                    A.amt60 ,
                    A.amt90 ,
                    A.amt120 ,
                    A.amt150 ,
                    A.amt180 ,
                    A.amt210 ,
                    A.amt240 ,
                    A.amt270 ,
                    A.amt300 ,
                    A.amt330 ,
                    A.amt360 ,
                    A.amt390 ,
                    NVL(E.rate390, 0) rate390  ,
                    A.turncnt ,
                    NVL(c.col30, 0) col30  ,
                    NVL(c.col60, 0) col60  ,
                    NVL(c.col90, 0) col90  ,
                    NVL(c.col120, 0) col120  ,
                    NVL(c.col150, 0) col150  ,
                    NVL(c.col180, 0) col180

            FROM    VGT.TT_ACACC0910P_AGING A
                    LEFT JOIN VGT.TT_ACACC0910P_ACBILLM   b ON A.custcode = b.custcode
                    LEFT JOIN VGT.TT_ACACC0910P_ACORDSMM3 c ON A.custcode = c.custcode
                    LEFT JOIN VGT.TT_ACACC0910P_ACORDSMM4 D ON A.custcode = c.custcode
                    LEFT JOIN ACBADSETD E                   ON E.yearmonth = p_yearmonth
                                                               AND A.custcode = E.custcode
            WHERE   NVL(D.colamt, 0) = 0

            UNION ALL

            SELECT  CASE WHEN NVL(TRIM(E.custcode), '') IS NOT NULL THEN 'Y'
                         ELSE 'N'
                    END chk  ,
                    c.utdiv ,
                    A.custcode ,
                    c.custname ,
                    D.divname utdivnm  ,
                    A.billamt totjango ,    --총잔고(jango+미도래어음)
                    0 jango ,               --jango
                    A.billamt bill ,        --미도래어음
                    0 amt30  ,
                    0 amt60  ,
                    0 amt90  ,
                    0 amt120  ,
                    0 amt150  ,
                    0 amt180  ,
                    0 amt210  ,
                    0 amt240  ,
                    0 amt270  ,
                    0 amt300  ,
                    0 amt330  ,
                    0 amt360  ,
                    0 amt390  ,
                    NVL(E.rate390, 0) rate390  ,
                    0 turncnt  ,
                    0 col30  ,
                    0 col60  ,
                    0 col90  ,
                    0 col120  ,
                    0 col150  ,
                    0 col180
            FROM    (   SELECT  custcode ,
                                SUM(billamt)  billamt
                        FROM    ACBILLM
                        WHERE   billcls = '1'
                                AND coldate <= p_enddate
                                AND p_enddate < expdate
                                AND p_plantcode = '1000'
                        GROUP BY custcode
                    ) A
                    LEFT JOIN VGT.TT_ACACC0910P_AGING b   ON A.custcode = b.custcode
                    LEFT JOIN CMCUSTM c                   ON A.custcode = c.custcode
                    LEFT JOIN CMCOMMONM D                 ON D.cmmcode = 'CM15'
                                                             AND c.utdiv = D.divcode
                    LEFT JOIN ACBADSETD E                 ON E.yearmonth = p_yearmonth
                                                             AND A.custcode = E.custcode
            WHERE   b.custcode IS NULL

            ORDER BY utdiv, custcode ;

    ELSIF ( p_div = 'IM' ) THEN

        MESSAGE := '' ;
        p_acautorcode := 'A04020' ;


        FOR  rec IN (   SELECT  accdiv  ,
                                remark2
                        FROM    ACAUTORULE
                        WHERE   UPPER(acautorcode) = UPPER(p_acautorcode) )
        LOOP
            p_slipdiv := rec.accdiv ;
            p_remark := rec.remark2 ;
        END LOOP;



        FOR  rec IN (   SELECT  p_slipdiv || SUBSTR('0000' || TO_CHAR((NVL(SUBSTR(MAX(slipnum) , -4, 4), 0) + 1)), -4, 4)  AS alias1
                        FROM    ACORDM A
                        WHERE   compcode = p_compcode
                                AND slipno LIKE REPLACE(p_enddate, '-', '') || RTRIM(p_slipdiv) || '%' )
        LOOP
            p_slipnum := rec.alias1 ;
        END LOOP;


        p_slipinno := REPLACE(p_enddate, '-', '') || p_slipnum ;


        FOR  rec IN (   SELECT  A.empname   AS empname  ,
                                A.deptcode  AS deptcode  ,
                                b.deptname  AS deptname
                        FROM    CMEMPM A
                                LEFT JOIN CMDEPTM b   ON A.deptcode = b.deptcode
                        WHERE   A.empcode = p_iempcode )
        LOOP
            p_empname  := rec.empname ;
            p_deptcode := rec.deptcode ;
            p_deptname := rec.deptname ;
        END LOOP;




        INSERT INTO ACORDM ( compcode, slipinno, slipdiv, slipindate, slipinnum,
                             deptcode, plantcode, empcode, eviddiv, slipinremark,
                             slipno, slipdate, slipnum, slipdeptcode, slipempcode,
                             skreqyn, skreqdiv, skreqdate, skreqdeptcode, skreqempcode,
                             accountno, slipinstate, slipremark, acautorcode, insertdt,
                             iempcode )

        ( SELECT            p_compcode , p_slipinno , p_slipdiv , p_enddate , p_slipnum ,
                            p_deptcode , p_plantcode , p_iempcode , '99' , p_remark ,
                            p_slipinno , p_enddate , p_slipnum , '' , '' ,
                            '' , '' , '' , '' , '' ,
                            '' , '4' , '' , acautorcode , SYSDATE ,
                            p_iempcode
          FROM      ACAUTORULE
          WHERE     acautorcode = p_acautorcode );


        FOR  rec IN (   SELECT  p_slipamt - totcreamt + totdebamt  AS alias1
                        FROM    ACORDDMM
                        WHERE   compcode = p_compcode
                                AND plantcode = p_plantcode
                                AND slipym = p_yearmonth
                                AND closediv = '10'
                                AND acccode = ( SELECT  acacccode
                                                FROM    ACAUTORULESM
                                                WHERE   acautorcode = p_acautorcode
                                                        AND dcdiv = '2'
                                                        AND accamtdiv = '01' ) )
        LOOP
            ip_slipamt := rec.alias1 ;
        END LOOP;


        p_remark := SUBSTR(p_yearmonth, 0, 4) || '년 ' || SUBSTR(p_yearmonth, -2, 2) || '월 ' || ' 대손처리' ;



        INSERT INTO ACORDD ( compcode, slipinno, slipinseq, dcdiv, acccode, plantcode, debamt, creamt, slipdate, slipnum, remark1, remark2, rptseq, insertdt, iempcode )
        ( SELECT    p_compcode ,
                    p_slipinno ,
                    acautoseq ,
                    dcdiv ,
                    acacccode ,
                    p_plantcode ,
                    CASE WHEN dcdiv = '1' THEN p_slipamt ELSE 0 END col  ,
                    CASE WHEN dcdiv = '2' THEN p_slipamt ELSE 0 END col  ,
                    p_enddate ,
                    p_slipnum ,
                    p_remark ,
                    '대손충당금A04020 자동분개' ,
                    acautoseq ,
                    SYSDATE ,
                    p_iempcode
          FROM      ACAUTORULESM
          WHERE     acautorcode = p_acautorcode );



        INSERT INTO ACORDS ( compcode, slipinno, slipinseq, mngclucode, seq, mngcluval, mngcludec, insertdt, iempcode )
        ( SELECT  p_compcode ,
                  p_slipinno ,
                  acautoseq ,
                  mngclucode ,
                  acautoseq ,
                  CASE WHEN mngclucode = 'S040' THEN p_deptcode
                       WHEN mngclucode = 'S050' THEN p_iempcode
                       ELSE ''
                  END ,
                  CASE WHEN mngclucode = 'S040' THEN p_deptname
                       WHEN mngclucode = 'S050' THEN p_empname
                       ELSE ''
                  END ,
                  SYSDATE ,
                  p_iempcode
          FROM    ACAUTORULEDS
          WHERE   acautorcode = p_acautorcode );

        MESSAGE := p_slipinno ;

    ELSIF ( p_div = 'SS' ) THEN

        OPEN  IO_CURSOR FOR
            SELECT  compcode ,
                    colday ,
                    rate30 ,
                    rate60 ,
                    rate90 ,
                    rate120 ,
                    rate150 ,
                    rate180 ,
                    rate210 ,
                    rate240 ,
                    rate270 ,
                    rate300 ,
                    rate330 ,
                    rate360 ,
                    rate390
            FROM    ACBADSET
            WHERE   compcode = p_compcode ;

    ELSIF ( p_div = 'IS' ) THEN

        FOR rec IN (    SELECT  COUNT(*) AS alias1
                        FROM    DUAL
                        WHERE EXISTS (  SELECT  *
                                        FROM    ACBADSET
                                        WHERE   compcode = p_compcode )
        )
        LOOP
            v_temp := rec.alias1 ;
        END LOOP ;

        IF v_temp > 0 THEN

            UPDATE ACBADSET A
            SET colday = p_colday,
                rate30 = p_rate30,
                rate60 = p_rate60,
                rate90 = p_rate90,
                rate120 = p_rate120,
                rate150 = p_rate150,
                rate180 = p_rate180,
                rate210 = p_rate210,
                rate240 = p_rate240,
                rate270 = p_rate270,
                rate300 = p_rate300,
                rate330 = p_rate330,
                rate360 = p_rate360,
                rate390 = p_rate390,
                updatedt = SYSDATE,
                uempcode = p_iempcode
            WHERE  compcode = p_compcode;

        ELSE

            INSERT INTO ACBADSET (  compcode,       colday,         rate30,         rate60,         rate90,
                                    rate120,        rate150,        rate180,        rate210,        rate240,
                                    rate270,        rate300,        rate330,        rate360,        rate390,
                                    insertdt,       iempcode )

            ( SELECT                p_compcode ,    p_colday ,      p_rate30 ,      p_rate60 ,      p_rate90 ,
                                    p_rate120 ,     p_rate150 ,     p_rate180 ,     p_rate210 ,     p_rate240 ,
                                    p_rate270 ,     p_rate300 ,     p_rate330 ,     p_rate360 ,     p_rate390 ,
                                    SYSDATE ,       p_iempcode FROM DUAL  );

        END IF;

    ELSIF ( p_div = 'ID' ) THEN

        INSERT INTO ACBADSETD ( compcode, yearmonth, custcode, rate390, insertdt, iempcode )
        ( SELECT p_compcode , p_yearmonth , p_custcode , p_rate390 , SYSDATE , p_iempcode FROM DUAL  );

    ELSIF ( p_div = 'DD' ) THEN

        DELETE  ACBADSETD
        WHERE   compcode = p_compcode
                AND yearmonth = p_yearmonth;

    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
