CREATE PROCEDURE        spACbudg0100R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACbudg0100R
 -- 작 성 자         : 배종성
 -- 작성일자         : 2010-12-23
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2017-01-02
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 예산대비실적현황을 조회하는 프로시저이다.
 -- ---------------------------------------------------------------

(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_btedeptcodeS1 IN  VARCHAR2 DEFAULT '' ,
    p_btedeptcodeS2 IN  VARCHAR2 DEFAULT '' ,
    p_yyyymm        IN  VARCHAR2 DEFAULT '' ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    OPEN  IO_CURSOR FOR

        SELECT  CASE WHEN p_div = 'S' OR grp = 3 THEN '' ELSE a.deptcode END deptcode  ,
                MAX(CASE WHEN p_div = 'S' OR grp = 3 THEN '' ELSE D.deptname END)  deptname  ,
                CASE WHEN grp = 1 THEN a.acccode ELSE '' END acccode  ,
                MAX(CASE WHEN grp = 1 THEN E.accname WHEN p_div = 'S' AND grp = 2 OR p_div = 'S1' AND grp = 3 THEN '합계' ELSE '소계' END)  accname  ,
                SUM(NVL(a.budgamt, 0))  ybudgamt ,
                SUM(NVL(a.budgamt1, 0))  lastmbudgamt  ,
                SUM(NVL(a.restotamt1, 0))  lastmrestotamt  ,
                SUM(NVL(a.budgamt2, 0))  pmbudgamt  ,
                SUM(NVL(a.restotamt2, 0))  pmrestotamt  ,
                SUM(NVL(a.budgamt2, 0))  - SUM(NVL(a.restotamt2, 0))  pmdiffamt  ,
                SUM(NVL(a.budgamt3, 0))  budgamt  ,
                SUM(NVL(a.restotamt3, 0))  restotamt  ,
                SUM(NVL(a.budgamt3, 0))  - SUM(NVL(a.restotamt3, 0))  diffamt  ,
                p_yyyymm || '-01' startdt  ,
                TO_CHAR(ADD_MONTHS(TO_DATE(p_yyyymm || '-01', 'YYYY-MM-DD'), 1)-1, 'YYYY-MM-DD') enddt  ,
                MAX(CASE WHEN p_div = 'S' AND grp = 2 OR p_div = 'S1' AND grp = 3 THEN 'zzzzzzz' ELSE a.deptcode END)  ord
        FROM
                -- 월예산
                (   SELECT  compcode ,
                            SUBSTR(p_yyyymm, 0, 4) cyear  ,
                            deptcode ,
                            acccode ,
                            SUM(budgamt)  budgamt ,-- 수정년예산
                            SUM(restotamt)  restotamt ,-- 전표년실적
                            SUM(CASE WHEN budgym  < p_yyyymm THEN budgamt   ELSE 0 END)  budgamt1  ,
                            SUM(CASE WHEN budgym  < p_yyyymm THEN restotamt ELSE 0 END)  restotamt1  ,
                            SUM(CASE WHEN budgym  = p_yyyymm THEN budgamt   ELSE 0 END)  budgamt2  ,
                            SUM(CASE WHEN budgym  = p_yyyymm THEN restotamt ELSE 0 END)  restotamt2  ,
                            SUM(CASE WHEN budgym <= p_yyyymm THEN budgamt   ELSE 0 END)  budgamt3  ,
                            SUM(CASE WHEN budgym <= p_yyyymm THEN restotamt ELSE 0 END)  restotamt3
                FROM    ACBUDGMM
                WHERE   compcode = p_compcode
                        AND budgym LIKE SUBSTR(p_yyyymm, 0, 4) || '%'
                        AND ( p_btedeptcodeS1 IS NULL OR p_btedeptcodeS1 > ' ' AND deptcode >= p_btedeptcodeS1 )
                        AND ( p_btedeptcodeS2 IS NULL OR p_btedeptcodeS2 > ' ' AND deptcode <= p_btedeptcodeS2 )
                GROUP BY compcode,deptcode,acccode
                HAVING  SUM(budgamt)  <> 0 OR
                        SUM(restotamt)  <> 0 OR
                        SUM(CASE WHEN budgym <= p_yyyymm THEN budgamt ELSE 0 END) <> 0 OR
                        SUM(CASE WHEN budgym <= p_yyyymm THEN restotamt ELSE 0 END) <> 0 ) a
                -- 년예산
                LEFT JOIN ACBUDGYY b ON a.compcode = b.compcode
                                        AND a.cyear = b.cyear
                                        AND a.deptcode = b.deptcode
                                        AND a.acccode = b.acccode
                JOIN (  SELECT 1 grp FROM DUAL
                        UNION
                        SELECT 2 FROM DUAL
                        UNION
                        SELECT 3 FROM DUAL  ) c ON p_div = 'S1' OR c.grp <> 3
                LEFT JOIN CMDEPTM D  ON a.deptcode = D.deptcode
                LEFT JOIN ACACCM E   ON a.acccode = E.acccode
        GROUP BY CASE WHEN p_div = 'S' OR grp = 3 THEN '' ELSE a.deptcode END
                 , CASE WHEN grp = 1 THEN a.acccode ELSE '' END,c.grp
        ORDER BY ord, deptcode, grp, acccode ;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
