CREATE PROCEDURE        spACacc0036P
	-- ---------------------------------------------------------------
	-- 프로시저명     : spACacc0036P
	-- 작 성 자      : 최용석
	-- 작성일자      : 2017-09-07
	-- ---------------------------------------------------------------
	-- 프로시저 설명  : 전표정보를 조회/변경하는 프로시저이다.
	-- ---------------------------------------------------------------
(
    p_div             IN  VARCHAR2 DEFAULT '',

    p_compcode        IN 	VARCHAR2 DEFAULT '',
    p_plantcode       IN 	VARCHAR2 DEFAULT '',
    p_slipsdate       IN 	VARCHAR2 DEFAULT '',
    p_slipedate       IN 	VARCHAR2 DEFAULT '' ,
    p_deptcode        IN 	VARCHAR2 DEFAULT '',
    p_empcode		      IN 	VARCHAR2 DEFAULT '',
    p_slipdiv		      IN 	VARCHAR2 DEFAULT '',
    p_eviddiv	        IN 	VARCHAR2 DEFAULT '',
    p_stracccode      IN 	VARCHAR2 DEFAULT '',
    p_endacccode      IN 	VARCHAR2 DEFAULT '',
    p_stramt		      IN 	FLOAT DEFAULT -999999999,
    p_endamt		      IN 	FLOAT DEFAULT 999999999,
    p_search		      IN 	VARCHAR2 DEFAULT '',

    p_slipinno        IN  VARCHAR2 DEFAULT '',
    p_slipinseq       IN  NUMBER   DEFAULT 0,
    p_acccode         IN  VARCHAR2 DEFAULT '',
    p_remark          IN  VARCHAR2 DEFAULT '',

    p_userid		      IN 	VARCHAR2 DEFAULT '',
    p_reasondiv 	    IN 	VARCHAR2 DEFAULT '',
    p_reasontext	    IN 	VARCHAR2 DEFAULT '',
    MESSAGE           OUT VARCHAR2,
    IO_CURSOR         OUT TYPES.DataSet
)
AS
BEGIN

    MESSAGE := '데이터 확인';
    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    -- 결의전표내역 검색
    if (p_div = 'S') then
        execute immediate 'delete from VGT.TT_ACACC0170R_ACORDM7';

        insert into VGT.TT_ACACC0170R_ACORDM7
        select  nvl(a.slipindate, '') as slipindate,          -- 결의일자
                nvl(a.slipinnum, '') as slipinnum,            -- 결의번호
                nvl(a.deptcode, '') as deptcode,              -- 결의부서
                nvl(d.deptname, '') as deptname,              -- 발의부서명
                nvl(a.empcode, '') as empcode,                -- 결의사원
                nvl(e.empname, '') as empname,                -- 발의자명
                nvl(b.acccode, '') as acccode,                -- 계정코드
                nvl(f.accname, '') as accname,                -- 계정명
                nvl(b.dcdiv, '') as dcdiv,                    -- 차대구분
                nvl(ac22.divname, '') as dcdivnm,             -- 전표유형명
                nvl(b.debamt, 0) as debamt,                   -- 차변금액
                nvl(b.creamt, 0) as creamt,                   -- 대변금액
                nvl(b.remark1, '') as remark,                 -- 적요
                nvl(a.skreqdate, '') as skreqdate,            -- 송금의뢰일자
                nvl(a.slipinstate, '') as slipinstate,        -- 전표상태
                nvl(ac21.divname, '') as slipinstatenm,       -- 전표상태
                nvl(a.slipdate, '') as slipdate,              -- 회계일자
                nvl(a.slipnum, '') as slipnum,                -- 회계번호
                nvl(a.slipempcode, '') as slipempcode,        -- 승인자
                nvl(es.empname, '') as slipempname,           -- 승인자명
                nvl(a.slipdiv, '') as slipdiv,                -- 전표유형구분
                nvl(ac20.divname, '') as slipdivnm,           -- 전표유형
                nvl(a.slipremark, '') as slipremark,          -- 처리사유
                nvl(b.slipinno, '') as slipinno,              -- 전표번호
                nvl(b.slipinseq, 0) as slipinseq,             -- 전표순번
                nvl(a.slipinremark, '') as slipinremark,      -- 결의내용
                nvl(b.remark2, '') as remark2                 -- 적요2
        from    ACORDM a
                join ACORDD b
                    on a.compcode = b.compcode
                    and a.slipinno = b.slipinno
                left join ACORDS c1
                    on b.compcode = c1.compcode
                    and b.slipinno = c1.slipinno
                    and b.slipinseq = c1.slipinseq
                    and c1.mngclucode = 'S040'
                left join ACORDS c2
                    on b.compcode = c2.compcode
                    and b.slipinno = c2.slipinno
                    and b.slipinseq = c2.slipinseq
                    and c2.mngclucode = 'S050'
                left join CMDEPTM d
                    on a.deptcode = d.deptcode          -- 발의부서
                left join CMEMPM e
                    on a.empcode = e.empcode             -- 발의자
                left join CMEMPM es
                    on a.slipempcode = es.empcode       -- 승인자
                left join ACACCM f
                    on b.acccode = f.acccode
                left join CMCOMMONM ac20
                    on ac20.cmmcode = 'AC20'       -- 전표유형
                    and a.slipdiv = ac20.divcode
                left join CMCOMMONM ac21
                    on ac21.cmmcode = 'AC21'       -- 전표상태
                    and a.slipinstate = ac21.divcode
                left join CMCOMMONM ac22
                    on ac22.cmmcode = 'AC22'       -- 전표유형(차변,대변,입금,출금)
                    and b.dcdiv = ac22.divcode
        where   a.compcode = p_compcode
                and a.plantcode like p_plantcode
                and a.slipindate between p_slipsdate and p_slipedate
                and a.deptcode like p_deptcode || '%'
                and a.empcode like p_empcode || '%'
                and a.slipdiv like p_slipdiv || '%'
                and a.eviddiv like p_eviddiv || '%'
                and a.slipinstate = '4'
                and (trim(p_stracccode) is null or p_stracccode <= b.acccode)
                and (trim(p_endacccode) is null or b.acccode <= p_endacccode)
                and b.debamt + b.creamt between p_stramt and p_endamt;

        open IO_CURSOR for
        select  'N' as selcol,      -- 선택
                '' as chgcode,			-- 변경코드
                '' as chgname,			-- 변경코드명
                '' as cempcode,     -- 변경사원
                '' as cempname,     -- 변경사원명
                '' as cremark,      -- 변경적요
                a.*,
                mod(b.cnt, 2) ord,
                c.mngcludec1,
                c.mngcludec2,
                c.mngcludec3,
                c.mngcludec4,
                c.mngcludec5,
                c.mngcludec6

        from    VGT.TT_ACACC0170R_ACORDM7 a
                join (
                    select  slipinno, row_number() over(order by slipinno) as cnt
                    from    VGT.TT_ACACC0170R_ACORDM7
                    group by slipinno
                ) b on a.slipinno = b.slipinno
                left join (
                    select  slipinno,
                            slipinseq,
                            max(case when seq = 1 then mngcludec else '' end) as mngcludec1,
                            max(case when seq = 2 then mngcludec else '' end) as mngcludec2,
                            max(case when seq = 3 then mngcludec else '' end) as mngcludec3,
                            max(case when seq = 4 then mngcludec else '' end) as mngcludec4,
                            max(case when seq = 5 then mngcludec else '' end) as mngcludec5,
                            max(case when seq = 6 then mngcludec else '' end) as mngcludec6
                    from (
                        select  a.slipinno,
                                a.slipinseq,
                                row_number() over(partition by a.slipinno, a.slipinseq order by b.seq) as seq,
                                '[' || nvl(c.mngcluname, '') || ']' || nvl(b.mngcluval, '') || ' : ' || nvl(b.mngcludec, '') || case when d.custcode is null then '' else ' (' || d.businessno || ')' end as mngcludec
                        from    VGT.TT_ACACC0170R_ACORDM7 a
                                join ACORDS b
                                    on b.compcode = p_compcode
                                    and a.slipinno = b.slipinno
                                    and a.slipinseq = b.slipinseq
                                left join ACMNGM c
                                    on b.mngclucode = c.mngclucode
                                left join CMCUSTM d
                                    on b.mngclucode = 'S010'
                                    and b.mngcluval = d.custcode
                    ) a
                    group by slipinno, slipinseq
                ) c on a.slipinno = c.slipinno
                    and a.slipinseq = c.slipinseq

        where   p_search = ''
                or a.slipremark like '%' || p_search || '%'
                or a.slipinremark like '%' || p_search || '%'
                or a.remark like '%' || p_search || '%'
                or a.remark2 like '%' || p_search || '%'
                or c.mngcludec1 like '%' || p_search || '%'
                or c.mngcludec2 like '%' || p_search || '%'
                or c.mngcludec3 like '%' || p_search || '%'
                or c.mngcludec4 like '%' || p_search || '%'
                or c.mngcludec5 like '%' || p_search || '%'
                or c.mngcludec6 like '%' || p_search || '%'

        order by a.slipindate, a.slipinnum, a.slipinseq;

    elsif (p_div = 'C') then
        update  ACORDD
        set     acccode = p_acccode
                ,remark1 = p_remark
        where   compcode = p_compcode
                and slipinno = p_slipinno
                and slipinseq = p_slipinseq;

        update  ACORDM
        set     printdate = null
        where   compcode = p_compcode
                and slipinno = p_slipinno;

        merge into ACORDM a
        using (
            select	empcode, deptcode
            from    CMEMPM
            where   empcode = p_empcode
        ) b on (a.compcode = p_compcode and
                a.slipinno = p_slipinno)
        when matched
        then
            update set a.empcode = b.empcode,
                       a.deptcode = b.deptcode;

    elsif (p_div = 'R') then
        -- 회계전표 잔액 집계처리
        spACord0000MM('T', p_compcode, null, '%', substr(p_slipsdate, 1, 7), substr(p_slipedate, 1, 7), p_userid, p_reasondiv, p_reasontext, MESSAGE, IO_CURSOR);

        -- 회계전표 예산 집계처리
        spACbudg0000MM('TO', p_compcode, null, substr(p_slipsdate, 1, 7), substr(p_slipedate, 1, 7), p_userid, p_reasondiv, p_reasontext, IO_CURSOR, MESSAGE);

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
