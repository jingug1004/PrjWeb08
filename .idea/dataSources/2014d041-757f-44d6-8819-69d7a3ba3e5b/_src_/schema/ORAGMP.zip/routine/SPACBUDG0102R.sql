CREATE PROCEDURE        spACbudg0102R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACbudg0102R
 -- 작 성 자         : 배종성
 -- 작성일자         : 2011-02-10
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2017-01-02
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 월별예산편성현황을 조회하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN  VARCHAR2 DEFAULT '' ,
    p_compcode      IN  VARCHAR2 DEFAULT '' ,
    p_btedeptcodeS1 IN  VARCHAR2 DEFAULT '' ,
    p_btedeptcodeS2 IN  VARCHAR2 DEFAULT '' ,
    p_yyyy          IN  VARCHAR2 DEFAULT '' ,
    p_viewtype      IN  VARCHAR2 DEFAULT '1' ,
    p_userid        IN  VARCHAR2 DEFAULT '' ,
    p_reasondiv     IN  VARCHAR2 DEFAULT '' ,
    p_reasontext    IN  VARCHAR2 DEFAULT '' ,
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);


    OPEN  IO_CURSOR FOR

            SELECT  CASE WHEN p_div = 'S' OR grp = 3 THEN '' ELSE a.deptcode END deptcode  ,
                    MAX(CASE WHEN p_div = 'S' OR grp = 3 THEN '' ELSE G.deptname END)  deptname  ,
                    CASE WHEN grp = 1 THEN a.acccode ELSE '' END acccode  ,
                    MAX(CASE WHEN grp = 1 THEN h.accname
                             WHEN p_div = 'S' AND grp = 2 OR p_div = 'S1' AND grp = 3 THEN '합계'
                             ELSE '소계'
                        END)  accname  ,
                    SUM(NVL(c.budgamt, 0))  lastybudgamt ,
                    SUM(NVL(c.restotamt, 0))  restotamt  ,
                    SUM(NVL(E.budgamt, 0))  ybudgamt ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.qurt1budgamt
                                 ELSE E.budgamt01 + E.budgamt02 + E.budgamt03
                            END, 0))  qurt1budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.qurt2budgamt
                                 ELSE E.budgamt04 + E.budgamt05 + E.budgamt06
                            END, 0))  qurt2budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.qurt3budgamt
                                 ELSE E.budgamt07 + E.budgamt08 + E.budgamt09
                            END, 0))  qurt3budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.qurt4budgamt
                                 ELSE E.budgamt10 + E.budgamt11 + E.budgamt12
                            END, 0))  qurt4budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m1budgamt
                                 ELSE E.budgamt01
                            END, 0))  m1budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m2budgamt
                                 ELSE E.budgamt02
                            END, 0))  m2budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m3budgamt
                                 ELSE E.budgamt03
                            END, 0))  m3budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m4budgamt
                                 ELSE E.budgamt04
                            END, 0))  m4budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m5budgamt
                                 ELSE E.budgamt05
                            END, 0))  m5budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m6budgamt
                                 ELSE E.budgamt06
                            END, 0))  m6budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m7budgamt
                                 ELSE E.budgamt07
                            END, 0))  m7budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m8budgamt
                                 ELSE E.budgamt08
                            END, 0))  m8budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m9budgamt
                                 ELSE E.budgamt09
                            END, 0))  m9budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m10budgamt
                                 ELSE E.budgamt10
                            END, 0))  m10budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m11budgamt
                                 ELSE E.budgamt11
                            END, 0))  m11budgamt  ,
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m12budgamt
                                 ELSE E.budgamt12
                            END, 0))  m12budgamt  ,
                    MAX(CASE WHEN p_div = 'S' AND grp = 2 OR p_div = 'S1' AND grp = 3 THEN 'zzzzzzz'
                             ELSE a.deptcode
                        END)  ord
            FROM
                    (
                        SELECT  compcode ,
                                deptcode ,
                                acccode
                        FROM    ACBUDGMM
                        WHERE   compcode = p_compcode
                                AND budgym BETWEEN TO_CHAR(TO_NUMBER(p_yyyy) - 1) || '-01' AND p_yyyy || '-12'
                                AND ( p_btedeptcodeS1 IS NULL OR p_btedeptcodeS1 > ' '
                                AND deptcode >= p_btedeptcodeS1 )
                                AND ( p_btedeptcodeS2 IS NULL OR p_btedeptcodeS2 > ' ' AND deptcode <= p_btedeptcodeS2 )
                        GROUP BY compcode,deptcode,acccode
                    ) a
                    LEFT JOIN ACBUDGYY b ON a.compcode = b.compcode -- 전년년예산
                                            AND b.cyear = TO_CHAR(TO_NUMBER(p_yyyy) - 1)
                                            AND a.deptcode = b.deptcode
                                            AND a.acccode = b.acccode
                    LEFT JOIN (  -- 전년월예산
                                SELECT  compcode ,
                                        deptcode ,
                                        acccode ,
                                        SUM(budgamt)  budgamt ,-- 수정년예산
                                        SUM(restotamt)  restotamt -- 전표년실적
                                FROM    ACBUDGMM
                                WHERE   compcode = p_compcode
                                        AND budgym LIKE TO_CHAR(TO_NUMBER(p_yyyy - 1)) || '%'
                                        AND ( p_btedeptcodeS1 IS NULL OR p_btedeptcodeS1 > ' ' AND deptcode >= p_btedeptcodeS1 )
                                        AND ( p_btedeptcodeS2 IS NULL OR p_btedeptcodeS2 > ' '
                                        AND deptcode <= p_btedeptcodeS2 )
                                GROUP BY compcode,deptcode,acccode ) c ON a.compcode = c.compcode
                                                                          AND a.deptcode = c.deptcode
                                                                          AND a.acccode = c.acccode
                    LEFT JOIN ACBUDGYY D ON a.compcode = D.compcode -- 금년년예산
                                            AND D.cyear = p_yyyy
                                            AND a.deptcode = D.deptcode
                                            AND a.acccode = D.acccode
                    LEFT JOIN (  -- 금년월예산
                                SELECT  compcode ,
                                        deptcode ,
                                        acccode ,
                                        SUM(budgamt)  budgamt ,                                                         -- 수정년예산
                                        SUM(restotamt)  restotamt ,                                                     -- 전표년실적
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '01' THEN budgamt ELSE 0 END)  budgamt01 ,-- 수정01월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '02' THEN budgamt ELSE 0 END)  budgamt02 ,-- 수정02월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '03' THEN budgamt ELSE 0 END)  budgamt03 ,-- 수정03월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '04' THEN budgamt ELSE 0 END)  budgamt04 ,-- 수정04월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '05' THEN budgamt ELSE 0 END)  budgamt05 ,-- 수정05월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '06' THEN budgamt ELSE 0 END)  budgamt06 ,-- 수정06월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '07' THEN budgamt ELSE 0 END)  budgamt07 ,-- 수정07월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '08' THEN budgamt ELSE 0 END)  budgamt08 ,-- 수정08월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '09' THEN budgamt ELSE 0 END)  budgamt09 ,-- 수정09월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '10' THEN budgamt ELSE 0 END)  budgamt10 ,-- 수정10월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '11' THEN budgamt ELSE 0 END)  budgamt11 ,-- 수정11월예산
                                        SUM(CASE WHEN SUBSTR(budgym, -2, 2) = '12' THEN budgamt ELSE 0 END)  budgamt12 -- 수정12월예산
                                FROM    ACBUDGMM
                                WHERE   compcode = p_compcode
                                        AND budgym LIKE p_yyyy || '%'
                                        AND ( p_btedeptcodeS1 IS NULL OR p_btedeptcodeS1 > ' ' AND deptcode >= p_btedeptcodeS1 )
                                        AND ( p_btedeptcodeS2 IS NULL OR p_btedeptcodeS2 > ' ' AND deptcode <= p_btedeptcodeS2 )
                                GROUP BY compcode,deptcode,acccode ) E ON a.compcode = E.compcode
                                                                          AND a.deptcode = E.deptcode
                                                                          AND a.acccode = E.acccode
                    JOIN (  SELECT 1 grp FROM DUAL
                            UNION
                            SELECT 2 FROM DUAL
                            UNION
                            SELECT 3 FROM DUAL  ) f ON p_div = 'S1' OR f.grp <> 3
                    LEFT JOIN CMDEPTM G   ON a.deptcode = G.deptcode
                    LEFT JOIN ACACCM h   ON a.acccode = h.acccode
            GROUP BY CASE WHEN p_div = 'S' OR grp = 3 THEN '' ELSE a.deptcode END
                     , CASE WHEN grp = 1 THEN a.acccode ELSE '' END
                     , f.grp
            HAVING  SUM(NVL(b.ybudgamt, 0))  <> 0 OR
                    SUM(NVL(c.budgamt, 0))   <> 0 OR
                    SUM(NVL(c.restotamt, 0)) <> 0 OR
                    SUM(NVL(D.ybudgamt, 0))  <> 0 OR
                    SUM(NVL(E.budgamt, 0))   <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m1budgamt ELSE E.budgamt01 END, 0)) <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m2budgamt ELSE E.budgamt02 END, 0))  <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m3budgamt ELSE E.budgamt03 END, 0))  <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m4budgamt ELSE E.budgamt04 END, 0))  <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m5budgamt ELSE E.budgamt05 END, 0))  <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m6budgamt ELSE E.budgamt06 END, 0))  <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m7budgamt ELSE E.budgamt07 END, 0))  <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m8budgamt ELSE E.budgamt08 END, 0))  <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m9budgamt ELSE E.budgamt09 END, 0))  <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m10budgamt ELSE E.budgamt10 END, 0)) <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m11budgamt ELSE E.budgamt11 END, 0)) <> 0 OR
                    SUM(NVL(CASE WHEN p_viewtype = '0' THEN D.m12budgamt ELSE E.budgamt12 END, 0))  <> 0
            ORDER BY ord, deptcode, grp, acccode ;




    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;


END;
/
