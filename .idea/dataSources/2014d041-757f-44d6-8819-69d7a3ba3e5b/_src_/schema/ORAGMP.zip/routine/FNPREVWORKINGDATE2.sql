CREATE FUNCTION fnPrevWorkingDate2(
    -- ---------------------------------------------------------------
    -- 함 수 명			: fnPrevWorkingDate2
    -- 작 성 자         : 민승기
    -- 작성일자         : 2007-11-01
    -- ---------------------------------------------------------------
    -- 함수설명			: 이전 근무일 계산
    -- ---------------------------------------------------------------

    p_daycnt 	IN 		VARCHAR2	DEFAULT '0',
    ip_basedate IN 		VARCHAR2 	DEFAULT NULL
)
	RETURN DATE
AS
	p_basedate	  VARCHAR2(10);
	p_todate	  DATE;
	p_rowcnt	  NUMBER(10, 0);
BEGIN
	p_basedate := SUBSTR(ip_basedate,0,10);
    IF(LENGTH(p_basedate) = 6) THEN
    	p_basedate := TO_CHAR(TO_DATE(p_basedate,'YYYYMMDD'),'YYYY-MM-DD');
    ELSE
    	p_basedate := NVL(p_basedate, TO_CHAR(SYSDATE, 'YYYY-MM-DD'));
    END IF;


	FOR rec IN (SELECT MIN(a.calymd) AS alias1,
					   COUNT(*) - 1 AS alias2
				FROM   (SELECT *
						FROM   (SELECT	 calymd
								FROM	 PSCALM
								WHERE	 calymd BETWEEN TO_CHAR(TO_DATE(p_basedate,'YYYY-MM-DD')-(ABS(p_daycnt) + 50), 'YYYY-MM-DD') AND p_basedate
								ORDER BY calymd DESC)
						WHERE  ROWNUM <= ABS(p_daycnt) + 1) a)
	LOOP
		p_todate := TO_DATE(rec.alias1,'YYYY-MM-DD');
		p_rowcnt := rec.alias2;
	END LOOP;

	IF (p_rowcnt <> p_daycnt)
	THEN
        p_todate := TO_DATE(p_basedate,'YYYY-MM-DD') - ABS(p_daycnt);
	END IF;

	RETURN (p_todate);
EXCEPTION
	WHEN OTHERS
	THEN NULL;
END;
/
