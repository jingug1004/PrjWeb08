CREATE PROCEDURE        spACacc0900SP3(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0900SP3
	-- 작 성 자         : 이영재
	-- 작성일자         : 2010-11-25
	-- 수 정 자     : 노영래
	-- E-Mail       : 0rae0926@gmail.com
	-- 수정일자      : 2016-12-19
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 매출전표로드-역발행(직수출부분)
	-- 수정 : 2011-02-09 이영재 영업 매출전표로드 처리를 회계모듈로 변경 작업
	-- ---------------------------------------------------------------

	p_div			  IN	 VARCHAR2 DEFAULT '',
	p_compcode		  IN	 VARCHAR2 DEFAULT '',
	p_plantcode 	  IN	 VARCHAR2 DEFAULT '',
	p_plantcode2	  IN	 VARCHAR2 DEFAULT '',
	p_sdt			  IN	 VARCHAR2 DEFAULT '',
	p_edt			  IN	 VARCHAR2 DEFAULT '',
	p_taxno 		  IN	 VARCHAR2 DEFAULT '',
	p_appdate		  IN	 VARCHAR2 DEFAULT '',
	p_custcode		  IN	 VARCHAR2 DEFAULT '',
	p_iempcode		  IN	 VARCHAR2 DEFAULT '',
	p_loadstatus	  IN	 VARCHAR2 DEFAULT '',
	p_actrnstate	  IN	 VARCHAR2 DEFAULT '',
	p_autorulecode	  IN	 VARCHAR2 DEFAULT '',
	p_userid		  IN	 VARCHAR2 DEFAULT '',
	p_reasondiv 	  IN	 VARCHAR2 DEFAULT '',
	p_reasontext	  IN	 VARCHAR2 DEFAULT '',
	MESSAGE 			 OUT VARCHAR2,
	IO_CURSOR			 OUT TYPES.DataSet
)
AS
	ip_compcode 	VARCHAR2(4) := p_compcode;
	v_temp			NUMBER(1, 0) := 0;
	p_sactstate1	VARCHAR2(2);
	p_sactstate2	VARCHAR2(2);
	p_at			VARCHAR2(10);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);

	FOR rec IN (SELECT compcode -- 법인코드 확인
				FROM   CMPLANTM
				WHERE  plantcode LIKE p_plantcode || '%'
					   AND ROWNUM <= 1)
	LOOP
		ip_compcode := rec.compcode;
	END LOOP;

	SELECT COUNT(*)
	INTO   v_temp
	FROM   DUAL
	WHERE  EXISTS
			   (SELECT *
				FROM   CMCLOSEM
				WHERE  compcode = p_compcode
					   AND closeym BETWEEN SUBSTR(p_sdt, 0, 7) AND SUBSTR(p_edt, 0, 7)
					   AND accdiv = 'S'
					   AND apprcloseyn = 'Y');

	IF v_temp = 1
	THEN
		GOTO LAST;
	END IF;

	--판매 회계로드 템프테이블
	--taxdt
	--계산서 구분(  select * from cmcommonm where cmmcode = 'AC60'  )
	--매입매출구분( select * from cmcommonm where cmmcode = 'AC61'  )
	--
	-- 세금계산서의 공급가액
	-- 세금계산서의 공급가액
	-- 세금계산서의 공급가액
	-- 세금계산서의 부가세
	-- 세금계산서의 합계액
	--1신규, 2완료 3수정, 4삭제
	-- 기본 세금계산서 자료 조회

	INSERT INTO VGT.TT_ACACC0900SP3_ACACC0900SP3
		(SELECT ip_compcode compcode,
				'N' chk, -- ?
				SUBSTR(A.slipindate, 0, 7) yymm, -- 처리월
				A.plantcode plantcode,
				A.slipindate slipindate, -- 발행일자
				A.taxno taxno,
				'106' taxdiv, -- 매출-수출 세금계산서
				'02' iotaxdiv, --매출
				A.custcode custcode, -- 거래처코드    --select * from cmcustm
				c.custname custname, -- 거래처명
				c.businessno businessno, --
				c.ceoname ceoname,
				c.telno telno,
				c.POST POST,
				c.addr1 addr1,
				c.addr2 addr2,
				c.addre addr,
				A.deptcode deptcode,
				D.deptname deptname, -- 부서명 확인
				A.empcode empcode,
				G.empname empname,
				CASE WHEN A.itemcnt > 1 THEN A.itemname || ' 외 ' || TO_CHAR(A.itemcnt - 1) || '건' ELSE A.itemname END remark,
				A.amt salamt,
				A.amt1 salamt1,
				A.amt2 salamt2,
				A.vat salvat,
				A.totamt totamt,
				CASE WHEN TRIM(tt.importsdate) IS NULL THEN p_sdt ELSE tt.importsdate END sdate,
				CASE WHEN TRIM(tt.importedate) IS NULL THEN p_edt ELSE tt.importedate END edate,
				'1' actrnstate,
				'S01004' autorulecode,
				'신규로드전송전' acctrnchk,
				'' slipinno,
				'N' taxloadyn,
				'전송 필요' taxloadtatus,
				'N' newchk
		 FROM	(SELECT   CASE WHEN TRIM(tt.taxdate) IS NULL THEN SUBSTR(p_appdate, 0, 7) ELSE SUBSTR(NVL(tt.taxdate, ''), 0, 7) END yymm, -- 처리월
						  CASE WHEN TRIM(tt.taxdate) IS NULL THEN p_appdate ELSE tt.taxdate END slipindate, -- 발행일자
						  A.plantcode plantcode,
						  CASE WHEN TRIM(A.taxdate) IS NOT NULL AND NVL(A.taxdate, ' ') = NVL(tt.taxno, ' ') THEN tt.taxno
							   ELSE ''
						  END taxno, -- 발행일자
						  A.custcode custcode, -- 거래처코드    --select * from cmcustm
						  A.deptcode deptcode,
						  A.empcode empcode,
						  MAX(D.itemname) itemname,
						  COUNT(z.itemcode) itemcnt,
						  SUM(NVL(z.salamt, 0)) amt,
						  SUM(CASE WHEN NVL(D.itempart, ' ') NOT IN ('02', '08') THEN CASE WHEN SUBSTR(A.saldiv, 0, 1) = 'A' THEN z.salamt ELSE (-1) * z.salamt END ELSE 0 END) amt1,
						  SUM(CASE WHEN NVL(D.itempart, ' ') IN ('02', '08') THEN CASE WHEN SUBSTR(A.saldiv, 0, 1) = 'A' THEN z.salamt ELSE (-1) * z.salamt END ELSE 0 END) amt2,
						  SUM(CASE WHEN SUBSTR(A.saldiv, 0, 1) = 'A' THEN z.salvat ELSE (-1) * z.salvat END) vat,
						  SUM(CASE WHEN SUBSTR(A.saldiv, 0, 1) = 'A' THEN z.totamt ELSE (-1) * z.totamt END) totamt
				 FROM	  SLORDM A --select top 1 * from slordd
						  JOIN SLORDD z ON A.orderno = z.orderno
						  LEFT JOIN ACTAXM tt
							  ON tt.compcode = ip_compcode
								 AND tt.plantcode = A.plantcode
								 AND tt.taxno = A.taxdate
						  JOIN CMCUSTM c ON A.custcode = c.custcode
						  LEFT JOIN CMITEMM --select * from CMITEMM
										   D ON D.itemcode = z.itemcode
				 WHERE	  NVL(A.appdate, ' ') BETWEEN p_sdt AND p_edt
						  AND NVL(A.statediv, ' ') = '09'
						  AND NVL(A.saldiv, ' ') = 'A22'
				 GROUP BY CASE WHEN TRIM(tt.taxdate) IS NULL THEN SUBSTR(p_appdate, 0, 7) ELSE SUBSTR(tt.taxdate, 0, 7) END,
						  CASE WHEN TRIM(tt.taxdate) IS NULL THEN p_appdate ELSE tt.taxdate END,
						  A.plantcode,
						  CASE
							  WHEN TRIM(A.taxdate) IS NOT NULL
								   AND NVL(A.taxdate, ' ') = NVL(tt.taxno, ' ')
							  THEN
								  NVL(tt.taxno, '')
							  ELSE
								  ''
						  END,
						  A.custcode,
						  A.deptcode,
						  A.empcode) A
				LEFT JOIN ACTAXM tt
					ON tt.compcode = ip_compcode
					   AND tt.plantcode = A.plantcode
					   AND tt.taxno = A.taxno
				JOIN CMCUSTM c ON A.custcode = c.custcode
				LEFT JOIN CMDEPTM D ON A.deptcode = D.deptcode
				LEFT JOIN CMDEPTM E ON D.predeptcode = E.deptcode
				LEFT JOIN CMDEPTM f ON E.predeptcode = f.deptcode
				LEFT JOIN CMEMPM G ON A.empcode = G.empcode
				LEFT JOIN CMCOMMONM j
					ON G.positiondiv = j.divcode
					   AND j.cmmcode = 'PS29');

	--select * from tt_ACacc0900SP3  --##ACacc0900CP
	-- 전송완료상태 데이터 확인// 신규.  --1신규, 2완료 3수정, 4삭제
	--tt_ACacc0900SP3  --##ACacc0900CP      --,'1'   as  actrnstate
	MERGE INTO VGT.TT_ACACC0900SP3_ACACC0900SP3 A
	USING	   (SELECT A.COMPCODE,
					   A.CHK,
					   A.YYMM,
					   A.PLANTCODE,
					   A.SLIPINDATE,
					   A.TAXNO,
					   A.TAXDIV,
					   A.IOTAXDIV,
					   A.CUSTCODE,
					   A.CUSTNAME,
					   A.BUSINESSNO,
					   A.CEONAME,
					   A.TELNO,
					   A.POST,
					   A.ADDR1,
					   A.ADDR2,
					   A.ADDR,
					   A.DEPTCODE,
					   A.DEPTNAME,
					   A.EMPCODE,
					   A.EMPNAME,
					   A.REMARK,
					   A.SALAMT,
					   A.SALAMT1,
					   A.SALAMT2,
					   A.SALVAT,
					   A.TOTAMT,
					   A.SDATE,
					   A.EDATE,
					   A.AUTORULECODE,
					   A.TAXLOADYN,
					   A.TAXLOADTATUS,
					   CASE
						   WHEN b.actrnstate = '1'
								OR TRIM(b.slipinno) IS NULL
						   THEN
							   '로드완료전표처리전'
						   WHEN TRIM(b.slipinno) IS NOT NULL
								AND NVL(b.slipinno, ' ') = NVL(acc.slipinno, ' ')
						   THEN
							   '회계처리완료'
						   WHEN TRIM(b.slipinno) IS NOT NULL
								AND NVL(b.slipinno, ' ') <> NVL(acc.slipinno, ' ')
						   THEN
							   '신규:회계전표삭제재전송'
						   ELSE
							   '회계처리완료'
					   END
						   AS pos_2,
					   CASE
						   WHEN b.actrnstate = '1'
								OR TRIM(b.slipinno) IS NULL
						   THEN
							   '3'
						   WHEN TRIM(b.slipinno) IS NOT NULL
								AND NVL(b.slipinno, ' ') = NVL(acc.slipinno, ' ')
						   THEN
							   '2'
						   WHEN TRIM(b.slipinno) IS NOT NULL
								AND NVL(b.slipinno, ' ') <> NVL(acc.slipinno, ' ')
						   THEN
							   '3'
						   ELSE
							   '2'
					   END
						   AS pos_3,
					   NVL(b.slipinno, '') AS pos_4,
					   CASE
						   WHEN TRIM(b.slipinno) IS NOT NULL
								AND NVL(b.slipinno, ' ') <> NVL(acc.slipinno, ' ')
						   THEN
							   'Y'
						   ELSE
							   'N'
					   END
						   AS pos_5
				FROM   VGT.TT_ACACC0900SP3_ACACC0900SP3 A --##ACacc0900CP a
					   JOIN ACAUTOORDT b -- 수정상태  select * from ACAUTOORDT where acattype = 'S'
						   ON NVL(b.compcode, ' ') = ip_compcode
							  AND NVL(b.acattype, ' ') = 'S'
							  AND NVL(b.slipindate, ' ') = A.slipindate --승인일자  세금계산서일자
							  AND NVL(b.acatno, ' ') = NVL(A.taxno, ' ')
							  AND NVL(b.acatrulecode, ' ') = 'S01004' --역발행 매출
					   LEFT JOIN ACORDM acc --select * from acordm
						   ON NVL(acc.compcode, ' ') = ip_compcode
							  AND NVL(acc.slipinno, ' ') = NVL(b.slipinno, ' ') --회계전표 조회
				WHERE  NVL(ip_compcode, ' ') = NVL(b.compcode, ' ')
					   AND NVL(A.taxno, ' ') = NVL(b.acatno, ' ')
					   AND NVL(b.acattype, ' ') = 'S') src
	ON		   (A.COMPCODE = SRC.COMPCODE
				AND A.CHK = SRC.CHK
				AND A.YYMM = SRC.YYMM
				AND A.PLANTCODE = SRC.PLANTCODE
				AND A.SLIPINDATE = SRC.SLIPINDATE
				AND A.TAXNO = SRC.TAXNO
				AND A.TAXDIV = SRC.TAXDIV
				AND A.IOTAXDIV = SRC.IOTAXDIV
				AND A.CUSTCODE = SRC.CUSTCODE
				AND A.CUSTNAME = SRC.CUSTNAME
				AND A.BUSINESSNO = SRC.BUSINESSNO
				AND A.CEONAME = SRC.CEONAME
				AND A.TELNO = SRC.TELNO
				AND A.POST = SRC.POST
				AND A.ADDR1 = SRC.ADDR1
				AND A.ADDR2 = SRC.ADDR2
				AND A.ADDR = SRC.ADDR
				AND A.DEPTCODE = SRC.DEPTCODE
				AND A.DEPTNAME = SRC.DEPTNAME
				AND A.EMPCODE = SRC.EMPCODE
				AND A.EMPNAME = SRC.EMPNAME
				AND A.REMARK = SRC.REMARK
				AND A.SALAMT = SRC.SALAMT
				AND A.SALAMT1 = SRC.SALAMT1
				AND A.SALAMT2 = SRC.SALAMT2
				AND A.SALVAT = SRC.SALVAT
				AND A.TOTAMT = SRC.TOTAMT
				AND A.SDATE = SRC.SDATE
				AND A.EDATE = SRC.EDATE
				AND A.AUTORULECODE = SRC.AUTORULECODE
				AND A.TAXLOADYN = SRC.TAXLOADYN
				AND A.TAXLOADTATUS = SRC.TAXLOADTATUS)
	WHEN MATCHED
	THEN
		UPDATE SET A.acctrnchk = src.pos_2, A.actrnstate = src.pos_3, A.slipinno = src.pos_4, A.newchk = src.pos_5;

	-- 수정 데이터 확인// 신규.  --1신규, 2완료 3수정, 4삭제
	--#ACacc0900CP  --##ACacc0900CP  --,'1'   as  actrnstate
	MERGE INTO VGT.TT_ACACC0900SP3_ACACC0900SP3 A --##ACacc0900CP a
	USING	   (SELECT A.COMPCODE,
					   A.YYMM,
					   A.PLANTCODE,
					   A.SLIPINDATE,
					   A.TAXNO,
					   A.TAXDIV,
					   A.IOTAXDIV,
					   A.CUSTCODE,
					   A.CUSTNAME,
					   A.BUSINESSNO,
					   A.CEONAME,
					   A.TELNO,
					   A.POST,
					   A.ADDR1,
					   A.ADDR2,
					   A.ADDR,
					   A.DEPTCODE,
					   A.DEPTNAME,
					   A.EMPCODE,
					   A.EMPNAME,
					   A.REMARK,
					   A.SALAMT,
					   A.SALAMT1,
					   A.SALAMT2,
					   A.SALVAT,
					   A.TOTAMT,
					   A.SDATE,
					   A.EDATE,
					   A.AUTORULECODE,
					   A.TAXLOADYN,
					   A.TAXLOADTATUS,
					   A.NEWCHK,
					   CASE
						   WHEN TRIM(b.slipinno) IS NOT NULL
								AND NVL(b.slipinno, ' ') <> NVL(acc.slipinno, ' ')
						   THEN
							   '수정:회계전표삭제재전송'
						   ELSE
							   '수정전송필요'
					   END
						   AS pos_4,
					   NVL(b.slipinno, '') AS pos_5
				FROM   VGT.TT_ACACC0900SP3_ACACC0900SP3 A --##ACacc0900CP a
					   JOIN ACAUTOORDT b -- 수정상태
						   ON b.compcode = ip_compcode
							  AND b.acattype = 'S'
							  AND b.slipindate = A.slipindate --승인일자
							  AND b.acatno = A.taxno
							  AND NVL(b.acatrulecode, ' ') = 'S01004' --역발행 매출
					   LEFT JOIN ACORDM acc --select * from acordm
						   ON acc.compcode = ip_compcode
							  AND acc.slipinno = b.slipinno --회계전표 조회
				WHERE  ip_compcode <> b.compcode
					   OR A.plantcode <> b.plantcode
					   OR A.slipindate <> b.slipindate
					   OR A.taxno <> b.acatno
					   OR A.autorulecode <> b.acatrulecode
					   OR b.acattype <> 'S'
					   OR A.deptcode <> b.deptcode
					   OR A.custcode <> b.custcode
					   --or a.empcode <> b.empcode
					   OR A.salamt1 <> b.trn1amt
					   OR A.salamt2 <> b.trn2amt
					   OR A.salvat <> b.trn3amt
					   OR A.totamt <> b.trn4amt
					   OR A.deptname <> b.userdef4code -- 부서명
					   OR A.empname <> b.userdef5code -- 사원명
					   OR A.custname <> b.userdef6code) src
	ON		   (A.COMPCODE = SRC.COMPCODE
				AND A.YYMM = SRC.YYMM
				AND A.PLANTCODE = SRC.PLANTCODE
				AND A.SLIPINDATE = SRC.SLIPINDATE
				AND A.TAXNO = SRC.TAXNO
				AND A.TAXDIV = SRC.TAXDIV
				AND A.IOTAXDIV = SRC.IOTAXDIV
				AND A.CUSTCODE = SRC.CUSTCODE
				AND A.CUSTNAME = SRC.CUSTNAME
				AND A.BUSINESSNO = SRC.BUSINESSNO
				AND A.CEONAME = SRC.CEONAME
				AND A.TELNO = SRC.TELNO
				AND A.POST = SRC.POST
				AND A.ADDR1 = SRC.ADDR1
				AND A.ADDR2 = SRC.ADDR2
				AND A.ADDR = SRC.ADDR
				AND A.DEPTCODE = SRC.DEPTCODE
				AND A.DEPTNAME = SRC.DEPTNAME
				AND A.EMPCODE = SRC.EMPCODE
				AND A.EMPNAME = SRC.EMPNAME
				AND A.REMARK = SRC.REMARK
				AND A.SALAMT = SRC.SALAMT
				AND A.SALAMT1 = SRC.SALAMT1
				AND A.SALAMT2 = SRC.SALAMT2
				AND A.SALVAT = SRC.SALVAT
				AND A.TOTAMT = SRC.TOTAMT
				AND A.SDATE = SRC.SDATE
				AND A.EDATE = SRC.EDATE
				AND A.AUTORULECODE = SRC.AUTORULECODE
				AND A.TAXLOADYN = SRC.TAXLOADYN
				AND A.TAXLOADTATUS = SRC.TAXLOADTATUS
				AND A.NEWCHK = SRC.NEWCHK)
	WHEN MATCHED
	THEN
		UPDATE SET A.actrnstate = '3', A.chk = 'N', A.acctrnchk = src.pos_4, A.slipinno = src.pos_5; -- 거래처명

	-- 삭제 상태 확인
	INSERT INTO VGT.TT_ACACC0900SP3_ACACC0900SP3 --##ACacc0900CP
		(SELECT ip_compcode compcode,
				'N' chk,
				SUBSTR(NVL(A.slipindate, ''), 0, 4) yymm,
				NVL(A.plantcode, '') plantcode,
				NVL(A.slipindate, '') slipindate, --승인일자
				NVL(A.taxno, '') taxno,
				'' taxdiv, -- 세금계산서 구분
				'02' iotaxdiv,
				NVL(A.custcode, '') custcode,
				NVL(A.userdef6code, '') custname,
				c.businessno businessno,
				c.ceoname ceoname,
				c.telno telno,
				c.POST POST,
				c.addr1 addr1,
				c.addr2 addr2,
				c.addre addr,
				NVL(A.deptcode, '') deptcode,
				NVL(A.userdef4code, '') deptname,
				NVL(A.empcode, '') empcode,
				NVL(A.userdef5code, '') empname,
				NVL(A.remark, '') remark,
				trn1amt + trn2amt salamt,
				trn1amt salamt1,
				trn2amt salamt2,
				trn3amt salvat,
				trn4amt totamt,
				NVL(T.importsdate, '') sdate,
				NVL(T.importedate, '') edate,
				'4' actrnstate, --1신규, 2완료 3수정, 4삭제
				NVL(A.acatrulecode, '') autorulecode,
				'삭제전송필요' acctrnchk,
				A.slipinno slipinno,
				CASE WHEN NVL(T.taxno, ' ') = NVL(A.acatno, ' ') THEN 'Y' ELSE 'N' END taxloadyn,
				'세금계산서삭제필요' taxloadtatus,
				'N' newchk
		 FROM	ACAUTOORDT A
				LEFT JOIN VGT.TT_ACACC0900SP3_ACACC0900SP3 b
					ON A.slipindate = b.slipindate
					   AND A.acatno = b.taxno
				LEFT JOIN CMCUSTM c ON c.custcode = A.custcode
				LEFT JOIN ACTAXM T
					ON T.compcode = ip_compcode
					   AND T.plantcode = A.plantcode
					   AND T.taxno = A.acatno
		 WHERE	NVL(A.compcode, ' ') = NVL(ip_compcode, ' ')
				AND NVL(A.acattype, ' ') = 'S'
				AND NVL(A.slipindate, ' ') BETWEEN p_sdt AND p_edt
				AND NVL(A.acatrulecode, ' ') = 'S01004' --역발행 매출
				AND b.taxno IS NULL);

	FOR rec IN (SELECT filter1,
					   filter2
				FROM   CMCOMMONM
				WHERE  cmmcode = 'AC082'
					   AND divcode = p_loadstatus)
	LOOP
		p_sactstate1 := rec.filter1;
		p_sactstate2 := rec.filter2;
	END LOOP;

	IF (p_loadstatus = '1'
		OR p_loadstatus = '2'
		OR p_loadstatus = '3')
	THEN
		--로드 상태를 선택
		FOR REC IN (SELECT A.COMPCODE,
						   A.CHK,
						   A.YYMM,
						   A.PLANTCODE,
						   A.SLIPINDATE,
						   A.TAXNO,
						   A.TAXDIV,
						   A.IOTAXDIV,
						   A.CUSTCODE,
						   A.CUSTNAME,
						   A.BUSINESSNO,
						   A.CEONAME,
						   A.TELNO,
						   A.POST,
						   A.ADDR1,
						   A.ADDR2,
						   A.ADDR,
						   A.DEPTCODE,
						   A.DEPTNAME,
						   A.EMPCODE,
						   A.EMPNAME,
						   A.REMARK,
						   A.SALAMT,
						   A.SALAMT1,
						   A.SALAMT2,
						   A.SALVAT,
						   A.TOTAMT,
						   A.SDATE,
						   A.EDATE,
						   A.ACTRNSTATE,
						   A.AUTORULECODE,
						   A.ACCTRNCHK,
						   A.SLIPINNO,
						   A.TAXLOADYN,
						   A.TAXLOADTATUS,
						   A.NEWCHK
					FROM   VGT.TT_ACACC0900SP3_ACACC0900SP3 A
					WHERE  A.actrnstate NOT IN (p_sactstate1, p_sactstate2))
		LOOP
			DELETE FROM VGT.TT_ACACC0900SP3_ACACC0900SP3 A
			WHERE		A.COMPCODE = REC.COMPCODE
						AND A.CHK = REC.CHK
						AND A.YYMM = REC.YYMM
						AND A.PLANTCODE = REC.PLANTCODE
						AND A.SLIPINDATE = REC.SLIPINDATE
						AND A.TAXNO = REC.TAXNO
						AND A.TAXDIV = REC.TAXDIV
						AND A.IOTAXDIV = REC.IOTAXDIV
						AND A.CUSTCODE = REC.CUSTCODE
						AND A.CUSTNAME = REC.CUSTNAME
						AND A.BUSINESSNO = REC.BUSINESSNO
						AND A.CEONAME = REC.CEONAME
						AND A.TELNO = REC.TELNO
						AND A.POST = REC.POST
						AND A.ADDR1 = REC.ADDR1
						AND A.ADDR2 = REC.ADDR2
						AND A.ADDR = REC.ADDR
						AND A.DEPTCODE = REC.DEPTCODE
						AND A.DEPTNAME = REC.DEPTNAME
						AND A.EMPCODE = REC.EMPCODE
						AND A.EMPNAME = REC.EMPNAME
						AND A.REMARK = REC.REMARK
						AND A.SALAMT = REC.SALAMT
						AND A.SALAMT1 = REC.SALAMT1
						AND A.SALAMT2 = REC.SALAMT2
						AND A.SALVAT = REC.SALVAT
						AND A.TOTAMT = REC.TOTAMT
						AND A.SDATE = REC.SDATE
						AND A.EDATE = REC.EDATE
						AND A.ACTRNSTATE = REC.ACTRNSTATE
						AND A.AUTORULECODE = REC.AUTORULECODE
						AND A.ACCTRNCHK = REC.ACCTRNCHK
						AND A.SLIPINNO = REC.SLIPINNO
						AND A.TAXLOADYN = REC.TAXLOADYN
						AND A.TAXLOADTATUS = REC.TAXLOADTATUS
						AND A.NEWCHK = REC.NEWCHK;
		END LOOP;
	END IF;

	--세금계산서 작업 확인
	--VGT.TT_ACACC0900SP3_ACACC0900SP3  --##ACacc0900CP      --,'1'   as  actrnstate
	MERGE INTO VGT.TT_ACACC0900SP3_ACACC0900SP3 A --##ACacc0900CP a
	USING	   (SELECT A.COMPCODE,
					   A.CHK,
					   A.YYMM,
					   A.PLANTCODE,
					   A.SLIPINDATE,
					   A.TAXNO,
					   A.TAXDIV,
					   A.IOTAXDIV,
					   A.CUSTCODE,
					   A.CUSTNAME,
					   A.BUSINESSNO,
					   A.CEONAME,
					   A.TELNO,
					   A.POST,
					   A.ADDR1,
					   A.ADDR2,
					   A.ADDR,
					   A.DEPTCODE,
					   A.DEPTNAME,
					   A.EMPCODE,
					   A.EMPNAME,
					   A.REMARK,
					   A.SALAMT,
					   A.SALAMT1,
					   A.SALAMT2,
					   A.SALVAT,
					   A.TOTAMT,
					   A.SDATE,
					   A.EDATE,
					   A.ACTRNSTATE,
					   A.AUTORULECODE,
					   A.ACCTRNCHK,
					   A.SLIPINNO,
					   A.NEWCHK,
					   CASE
						   WHEN TRIM(A.taxno) IS NOT NULL
								AND NVL(A.taxno, ' ') = NVL(tax.taxno, ' ')
						   THEN
							   'Y'
						   ELSE
							   'N'
					   END
						   AS pos_2,
					   CASE
						   WHEN TRIM(A.taxno) IS NOT NULL
								AND NVL(A.taxno, ' ') = NVL(tax.taxno, ' ')
						   THEN
							   '전송 완료'
						   ELSE
							   '전송 필요'
					   END
						   AS pos_3
				FROM   VGT.TT_ACACC0900SP3_ACACC0900SP3 A
					   LEFT JOIN ACTAXM tax
						   ON tax.compcode = ip_compcode
							  AND tax.plantcode = A.plantcode
							  AND tax.taxno = A.taxno) src
	ON		   (A.COMPCODE = SRC.COMPCODE
				AND A.CHK = SRC.CHK
				AND A.YYMM = SRC.YYMM
				AND A.PLANTCODE = SRC.PLANTCODE
				AND A.SLIPINDATE = SRC.SLIPINDATE
				AND A.TAXNO = SRC.TAXNO
				AND A.TAXDIV = SRC.TAXDIV
				AND A.IOTAXDIV = SRC.IOTAXDIV
				AND A.CUSTCODE = SRC.CUSTCODE
				AND A.CUSTNAME = SRC.CUSTNAME
				AND A.BUSINESSNO = SRC.BUSINESSNO
				AND A.CEONAME = SRC.CEONAME
				AND A.TELNO = SRC.TELNO
				AND A.POST = SRC.POST
				AND A.ADDR1 = SRC.ADDR1
				AND A.ADDR2 = SRC.ADDR2
				AND A.ADDR = SRC.ADDR
				AND A.DEPTCODE = SRC.DEPTCODE
				AND A.DEPTNAME = SRC.DEPTNAME
				AND A.EMPCODE = SRC.EMPCODE
				AND A.EMPNAME = SRC.EMPNAME
				AND A.REMARK = SRC.REMARK
				AND A.SALAMT = SRC.SALAMT
				AND A.SALAMT1 = SRC.SALAMT1
				AND A.SALAMT2 = SRC.SALAMT2
				AND A.SALVAT = SRC.SALVAT
				AND A.TOTAMT = SRC.TOTAMT
				AND A.SDATE = SRC.SDATE
				AND A.EDATE = SRC.EDATE
				AND A.ACTRNSTATE = SRC.ACTRNSTATE
				AND A.AUTORULECODE = SRC.AUTORULECODE
				AND A.ACCTRNCHK = SRC.ACCTRNCHK
				AND A.SLIPINNO = SRC.SLIPINNO
				AND A.NEWCHK = SRC.NEWCHK)
	WHEN MATCHED
	THEN
		UPDATE SET A.taxloadyn = src.pos_2, A.taxloadtatus = src.pos_3;

	IF (p_plantcode2 = '%'
		OR TRIM(p_plantcode2) IS NULL)
	THEN
		p_at := 'Y';
	ELSE
		FOR REC IN (SELECT A.COMPCODE,
						   A.CHK,
						   A.YYMM,
						   A.SLIPINDATE,
						   A.TAXNO,
						   A.TAXDIV,
						   A.IOTAXDIV,
						   A.CUSTCODE,
						   A.CUSTNAME,
						   A.BUSINESSNO,
						   A.CEONAME,
						   A.TELNO,
						   A.POST,
						   A.ADDR1,
						   A.ADDR2,
						   A.ADDR,
						   A.DEPTCODE,
						   A.DEPTNAME,
						   A.EMPCODE,
						   A.EMPNAME,
						   A.REMARK,
						   A.SALAMT,
						   A.SALAMT1,
						   A.SALAMT2,
						   A.SALVAT,
						   A.TOTAMT,
						   A.SDATE,
						   A.EDATE,
						   A.ACTRNSTATE,
						   A.AUTORULECODE,
						   A.ACCTRNCHK,
						   A.SLIPINNO,
						   A.TAXLOADYN,
						   A.TAXLOADTATUS,
						   A.NEWCHK
					FROM   VGT.TT_ACACC0900SP3_ACACC0900SP3 A
					WHERE  A.plantcode <> p_plantcode2)
		LOOP
			DELETE FROM VGT.TT_ACACC0900SP3_ACACC0900SP3 A
			WHERE		A.COMPCODE = REC.COMPCODE
						AND A.CHK = REC.CHK
						AND A.YYMM = REC.YYMM
						AND A.SLIPINDATE = REC.SLIPINDATE
						AND A.TAXNO = REC.TAXNO
						AND A.TAXDIV = REC.TAXDIV
						AND A.IOTAXDIV = REC.IOTAXDIV
						AND A.CUSTCODE = REC.CUSTCODE
						AND A.CUSTNAME = REC.CUSTNAME
						AND A.BUSINESSNO = REC.BUSINESSNO
						AND A.CEONAME = REC.CEONAME
						AND A.TELNO = REC.TELNO
						AND A.POST = REC.POST
						AND A.ADDR1 = REC.ADDR1
						AND A.ADDR2 = REC.ADDR2
						AND A.ADDR = REC.ADDR
						AND A.DEPTCODE = REC.DEPTCODE
						AND A.DEPTNAME = REC.DEPTNAME
						AND A.EMPCODE = REC.EMPCODE
						AND A.EMPNAME = REC.EMPNAME
						AND A.REMARK = REC.REMARK
						AND A.SALAMT = REC.SALAMT
						AND A.SALAMT1 = REC.SALAMT1
						AND A.SALAMT2 = REC.SALAMT2
						AND A.SALVAT = REC.SALVAT
						AND A.TOTAMT = REC.TOTAMT
						AND A.SDATE = REC.SDATE
						AND A.EDATE = REC.EDATE
						AND A.ACTRNSTATE = REC.ACTRNSTATE
						AND A.AUTORULECODE = REC.AUTORULECODE
						AND A.ACCTRNCHK = REC.ACCTRNCHK
						AND A.SLIPINNO = REC.SLIPINNO
						AND A.TAXLOADYN = REC.TAXLOADYN
						AND A.TAXLOADTATUS = REC.TAXLOADTATUS
						AND A.NEWCHK = REC.NEWCHK;
		END LOOP;
	END IF;

	IF (p_custcode = '%'
		OR TRIM(p_custcode) IS NULL)
	THEN
		p_at := 'Y';
	ELSE
		FOR REC IN (SELECT A.COMPCODE,
						   A.CHK,
						   A.YYMM,
						   A.PLANTCODE,
						   A.SLIPINDATE,
						   A.TAXNO,
						   A.TAXDIV,
						   A.IOTAXDIV,
						   A.CUSTNAME,
						   A.BUSINESSNO,
						   A.CEONAME,
						   A.TELNO,
						   A.POST,
						   A.ADDR1,
						   A.ADDR2,
						   A.ADDR,
						   A.DEPTCODE,
						   A.DEPTNAME,
						   A.EMPCODE,
						   A.EMPNAME,
						   A.REMARK,
						   A.SALAMT,
						   A.SALAMT1,
						   A.SALAMT2,
						   A.SALVAT,
						   A.TOTAMT,
						   A.SDATE,
						   A.EDATE,
						   A.ACTRNSTATE,
						   A.AUTORULECODE,
						   A.ACCTRNCHK,
						   A.SLIPINNO,
						   A.TAXLOADYN,
						   A.TAXLOADTATUS,
						   A.NEWCHK
					FROM   VGT.TT_ACACC0900SP3_ACACC0900SP3 A
					WHERE  A.custcode <> p_custcode)
		LOOP
			DELETE FROM VGT.TT_ACACC0900SP3_ACACC0900SP3 A
			WHERE		A.COMPCODE = REC.COMPCODE
						AND A.CHK = REC.CHK
						AND A.YYMM = REC.YYMM
						AND A.PLANTCODE = REC.PLANTCODE
						AND A.SLIPINDATE = REC.SLIPINDATE
						AND A.TAXNO = REC.TAXNO
						AND A.TAXDIV = REC.TAXDIV
						AND A.IOTAXDIV = REC.IOTAXDIV
						AND A.CUSTNAME = REC.CUSTNAME
						AND A.BUSINESSNO = REC.BUSINESSNO
						AND A.CEONAME = REC.CEONAME
						AND A.TELNO = REC.TELNO
						AND A.POST = REC.POST
						AND A.ADDR1 = REC.ADDR1
						AND A.ADDR2 = REC.ADDR2
						AND A.ADDR = REC.ADDR
						AND A.DEPTCODE = REC.DEPTCODE
						AND A.DEPTNAME = REC.DEPTNAME
						AND A.EMPCODE = REC.EMPCODE
						AND A.EMPNAME = REC.EMPNAME
						AND A.REMARK = REC.REMARK
						AND A.SALAMT = REC.SALAMT
						AND A.SALAMT1 = REC.SALAMT1
						AND A.SALAMT2 = REC.SALAMT2
						AND A.SALVAT = REC.SALVAT
						AND A.TOTAMT = REC.TOTAMT
						AND A.SDATE = REC.SDATE
						AND A.EDATE = REC.EDATE
						AND A.ACTRNSTATE = REC.ACTRNSTATE
						AND A.AUTORULECODE = REC.AUTORULECODE
						AND A.ACCTRNCHK = REC.ACCTRNCHK
						AND A.SLIPINNO = REC.SLIPINNO
						AND A.TAXLOADYN = REC.TAXLOADYN
						AND A.TAXLOADTATUS = REC.TAXLOADTATUS
						AND A.NEWCHK = REC.NEWCHK;
		END LOOP;
	END IF;

	IF (p_autorulecode = '%'
		OR TRIM(p_autorulecode) IS NULL)
	THEN
		p_at := 'Y';
	ELSE
		FOR REC IN (SELECT A.COMPCODE,
						   A.CHK,
						   A.YYMM,
						   A.PLANTCODE,
						   A.SLIPINDATE,
						   A.TAXNO,
						   A.TAXDIV,
						   A.IOTAXDIV,
						   A.CUSTCODE,
						   A.CUSTNAME,
						   A.BUSINESSNO,
						   A.CEONAME,
						   A.TELNO,
						   A.POST,
						   A.ADDR1,
						   A.ADDR2,
						   A.ADDR,
						   A.DEPTCODE,
						   A.DEPTNAME,
						   A.EMPCODE,
						   A.EMPNAME,
						   A.REMARK,
						   A.SALAMT,
						   A.SALAMT1,
						   A.SALAMT2,
						   A.SALVAT,
						   A.TOTAMT,
						   A.SDATE,
						   A.EDATE,
						   A.ACTRNSTATE,
						   A.ACCTRNCHK,
						   A.SLIPINNO,
						   A.TAXLOADYN,
						   A.TAXLOADTATUS,
						   A.NEWCHK
					FROM   VGT.TT_ACACC0900SP3_ACACC0900SP3 A
					WHERE  A.autorulecode <> p_autorulecode)
		LOOP
			DELETE FROM VGT.TT_ACACC0900SP3_ACACC0900SP3 A
			WHERE		A.COMPCODE = REC.COMPCODE
						AND A.CHK = REC.CHK
						AND A.YYMM = REC.YYMM
						AND A.PLANTCODE = REC.PLANTCODE
						AND A.SLIPINDATE = REC.SLIPINDATE
						AND A.TAXNO = REC.TAXNO
						AND A.TAXDIV = REC.TAXDIV
						AND A.IOTAXDIV = REC.IOTAXDIV
						AND A.CUSTCODE = REC.CUSTCODE
						AND A.CUSTNAME = REC.CUSTNAME
						AND A.BUSINESSNO = REC.BUSINESSNO
						AND A.CEONAME = REC.CEONAME
						AND A.TELNO = REC.TELNO
						AND A.POST = REC.POST
						AND A.ADDR1 = REC.ADDR1
						AND A.ADDR2 = REC.ADDR2
						AND A.ADDR = REC.ADDR
						AND A.DEPTCODE = REC.DEPTCODE
						AND A.DEPTNAME = REC.DEPTNAME
						AND A.EMPCODE = REC.EMPCODE
						AND A.EMPNAME = REC.EMPNAME
						AND A.REMARK = REC.REMARK
						AND A.SALAMT = REC.SALAMT
						AND A.SALAMT1 = REC.SALAMT1
						AND A.SALAMT2 = REC.SALAMT2
						AND A.SALVAT = REC.SALVAT
						AND A.TOTAMT = REC.TOTAMT
						AND A.SDATE = REC.SDATE
						AND A.EDATE = REC.EDATE
						AND A.ACTRNSTATE = REC.ACTRNSTATE
						AND A.ACCTRNCHK = REC.ACCTRNCHK
						AND A.SLIPINNO = REC.SLIPINNO
						AND A.TAXLOADYN = REC.TAXLOADYN
						AND A.TAXLOADTATUS = REC.TAXLOADTATUS
						AND A.NEWCHK = REC.NEWCHK;
		END LOOP;
	END IF;

	IF (UPPER(P_DIV) = 'S')
	THEN
		-- 영업에서 발생된 세금계산서 기준으로 조회
		OPEN IO_CURSOR FOR
			SELECT	 *
			FROM	 VGT.TT_ACACC0900SP3_ACACC0900SP3
			ORDER BY compcode, plantcode, taxno;
	ELSIF (UPPER(P_DIV) = 'LOADALL')
	THEN
		-- 전체 선택 일반 로드 처리
		-- 신규 작업
		INSERT INTO ACAUTOORDT(compcode, --회사코드
							   acattype, --전표유형(S)
							   acatno, --전표번호
							   acatrulecode, --분개률코드(S01001)
							   actrnstate, --실행상태
							   slipindate, --발의일자(세금계산서일자)
							   deptcode, --영업부서
							   plantcode, --사업장
							   empcode, --영업사원
							   remark, --비고
							   remark2, --비고2
							   custcode, --거래처
							   taxno,
							   trn1amt, --제품 또는 공급가액
							   trn2amt, --상품 또는 부가세
							   trn3amt, --부가세 또는 합계액
							   trn4amt, --합계액 또는 0
							   --,userdef3code   --사업장명
							   userdef4code, --부서명
							   userdef5code, --발의사원명
							   userdef6code, --거래처명
							   insertdt, --입력일자
							   iempcode) --입력사원
			(SELECT ip_compcode, --@compcode  as compcode --@compcode    --회사코드
					'S', --전표유형(C)
					taxno, --사용자정의2(수금번호)
					autorulecode, --분개률코드(S01001)
					actrnstate, --실행상태
					slipindate, --발의일자(세금계산서일자)
					deptcode, --영업부서
					plantcode, --사업장
					empcode, --영업사원
					remark, --remark     --비고
					'', --remark2    --비고2
					custcode, --거래처
					taxno,
					salamt1,
					salamt2,
					salvat,
					totamt,
					deptname,
					empname,
					custname,
					SYSDATE,
					p_iempcode
			 FROM	VGT.TT_ACACC0900SP3_ACACC0900SP3 --##ACacc0900CP --select * from #ACacc0900CP  --##ACacc0900CP
			 WHERE	actrnstate = '1'
					AND taxloadyn = 'Y');

		-- 수정,삭제 처리전에 메타에 있는 내용을 이력테이블에 저장한다.ACAUTOORDH
		INSERT INTO ACAUTOORDH --select * from ACAUTOORDH
			(SELECT b.*
			 FROM	VGT.TT_ACACC0900SP3_ACACC0900SP3 A --##ACacc0900CP  a --select * from #ACacc0900CP  --##ACacc0900CP
					LEFT JOIN ACAUTOORDT b
						ON b.compcode = ip_compcode
						   AND b.acattype = 'S'
						   AND b.acatno = A.taxno
			 WHERE	A.actrnstate = '3'
					OR A.actrnstate = '4'
					OR A.newchk = 'Y'
					   AND taxloadyn = 'Y');

		--메타 테이블 저장
		--ACAUTOORDT
		MERGE INTO ACAUTOORDT b -- select * from ACAUTOORDT
		USING	   (SELECT B.COMPCODE,
						   B.ACATTYPE,
						   B.ACATNO,
						   S.acatrulecode,
						   CASE WHEN b.actrnstate = '1' THEN b.actrnstate ELSE S.actrnstate END AS pos_3,
						   S.slipindate, --발의일자(세금계산서일자)
						   S.deptcode, --영업부서
						   S.plantcode, --사업장
						   S.empcode, --영업사원
						   S.remark, --remark     --비고
						   S.remark2, --비고2
						   S.custcode, --거래처
						   S.taxno,
						   S.trn1amt, --trn1amt    --합계
						   S.trn2amt, --trn1amt    --합계
						   S.trn3amt, --trn1amt    --합계
						   S.trn4amt, --trn1amt    --합계
						   S.userdef4code, --부서명
						   S.userdef5code, --발의사원명
						   S.userdef6code,
						   SYSDATE,
						   p_iempcode --= uempcode
					FROM   (SELECT A.taxno taxno,
								   A.autorulecode acatrulecode, --분개률코드(S01001)
								   A.actrnstate actrnstate,
								   A.slipindate slipindate, --발의일자(세금계산서일자)
								   A.deptcode deptcode, --영업부서
								   A.plantcode plantcode, --사업장
								   A.empcode empcode, --영업사원
								   '' remark, --remark     --비고
								   '' remark2, --비고2
								   custcode custcode, --거래처
								   salamt1 trn1amt,
								   salamt2 trn2amt,
								   salvat trn3amt,
								   totamt trn4amt,
								   A.deptname userdef4code, --부서명
								   A.empname userdef5code, --발의사원명
								   A.custname userdef6code
							FROM   VGT.TT_ACACC0900SP3_ACACC0900SP3 A --##ACacc0900CP a
							WHERE  A.actrnstate = '3'
								   OR A.actrnstate = '4'
									  AND taxloadyn = 'Y') S
						   LEFT JOIN ACAUTOORDT b -- select * from ACAUTOORDT
							   ON b.compcode = ip_compcode
								  AND b.acattype = 'S'
								  AND b.acatno = S.taxno) src
		ON		   (B.COMPCODE = SRC.COMPCODE
					AND B.ACATTYPE = SRC.ACATTYPE
					AND B.ACATNO = SRC.ACATNO)
		WHEN MATCHED
		THEN
			UPDATE SET --select
					  acatrulecode = src.acatrulecode,
					   actrnstate = pos_3,
					   slipindate = src.slipindate,
					   deptcode = src.deptcode,
					   plantcode = src.plantcode,
					   empcode = src.empcode,
					   remark = src.remark,
					   remark2 = src.remark2,
					   custcode = src.custcode,
					   taxno = src.taxno,
					   trn1amt = src.trn1amt,
					   trn2amt = src.trn2amt,
					   trn3amt = src.trn3amt,
					   trn4amt = src.trn4amt,
					   userdef4code = src.userdef4code,
					   userdef5code = src.userdef5code,
					   userdef6code = src.userdef6code,
					   updatedt = SYSDATE,
					   uempcode = p_iempcode;

		FOR REC IN (SELECT B.COMPCODE,
						   B.PLANTCODE,
						   B.TAXNO,
						   B.SEQ
					FROM   VGT.TT_ACACC0900SP3_ACACC0900SP3 A
						   LEFT JOIN ACTAXD b
							   ON b.compcode = A.compcode
								  AND b.plantcode = A.plantcode
								  AND b.taxno = A.taxno
					WHERE  A.actrnstate = '4'
						   AND A.taxloadyn = 'Y')
		LOOP
			DELETE FROM ACTAXD B
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.PLANTCODE = REC.PLANTCODE
						AND B.TAXNO = REC.TAXNO
						AND B.SEQ = REC.SEQ;
		END LOOP;


		FOR REC IN (SELECT B.COMPCODE,
						   B.PLANTCODE,
						   B.TAXNO
					FROM   VGT.TT_ACACC0900SP3_ACACC0900SP3 A
						   LEFT JOIN ACTAXM b
							   ON b.compcode = A.compcode
								  AND b.plantcode = A.plantcode
								  AND b.taxno = A.taxno
					WHERE  A.actrnstate = '4'
						   AND A.taxloadyn = 'Y')
		LOOP
			DELETE FROM ACTAXM B
			WHERE		B.COMPCODE = REC.COMPCODE
						AND B.PLANTCODE = REC.PLANTCODE
						AND B.TAXNO = REC.TAXNO;
		END LOOP;
	END IF;

   <<LAST>>
	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
