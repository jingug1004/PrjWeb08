CREATE PROCEDURE        spacfCardAppr(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spacfCardAppr
	-- 작 성 자         : 최용석
	-- 작성일자         : 2011-11-30
	-- 수정일자       :   노영래
	-- E-mail       :   0rae0926@gmail.com
	-- 수정일자       :   2016-12-13
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 법인카드 사용내역(신한 인사이드뱅크)을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_strdate		IN	   VARCHAR2 DEFAULT '',
	p_enddate		IN	   VARCHAR2 DEFAULT '',
	p_cardno		IN	   VARCHAR2 DEFAULT '',
	p_empcode		IN	   VARCHAR2 DEFAULT '',
	p_slipinno		IN	   VARCHAR2 DEFAULT '',
	p_slipinseq 	IN	   NUMBER DEFAULT 0,
	p_slipdiv		IN	   VARCHAR2 DEFAULT '',
	p_appr_date 	IN	   VARCHAR2 DEFAULT '',
	p_appr_time 	IN	   VARCHAR2 DEFAULT '',
	p_appr_nb		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	MESSAGE 		   OUT VARCHAR2,
	IO_CURSOR		   OUT TYPES.DATASET
)
AS
	ip_cardno	VARCHAR2(4000) := p_cardno;
BEGIN
	MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

-- IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리
--	IF (UPPER(P_DIV) = 'S') THEN
--		DECLARE
--			p_deptcode	 VARCHAR2(20);
--			p_custcode	 VARCHAR2(20);
--		-- 법인카드승인내역 검색
--		BEGIN
--			ip_cardno := REPLACE(ip_cardno, '-', '');
--			p_deptcode := '';
--
--			FOR rec IN (SELECT '%' AS alias1
--						FROM   SYSPARAMETERMANAGE
--						WHERE  parametercode = 'slipsuperemp'
--							   AND (value1 = p_empcode
--									OR value2 = p_empcode
--									OR value3 = p_empcode))
--			LOOP
--				p_deptcode := rec.alias1;
--			END LOOP;
--
--			FOR rec IN (SELECT '%' AS alias1
--						FROM   SYSPARAMETERMANAGE a JOIN CMEMPM b ON b.empcode = p_empcode
--						WHERE  a.parametercode = 'slipsuperdept'
--							   AND (a.value1 = b.deptcode
--									OR a.value2 = b.deptcode
--									OR a.value3 = b.deptcode))
--			LOOP
--				p_deptcode := rec.alias1;
--			END LOOP;
--
--			p_deptcode := '%';
--
--			--where @empcode = 'gmpit'
--			IF p_deptcode = ''
--			THEN
--				FOR rec IN (SELECT deptcode
--							FROM   CMEMPM
--							WHERE  empcode = p_empcode)
--				LOOP
--					p_deptcode := rec.deptcode;
--				END LOOP;
--			END IF;
--
--			p_custcode := '';
--
--			FOR rec IN (SELECT NVL(value3, '') AS alias1
--						FROM   SYSPARAMETERMANAGE
--						WHERE  parametercode = 'cardacccode'
--							   AND value3 <> '미정')
--			LOOP
--				p_custcode := rec.alias1;
--			END LOOP;
--
--
--
--			OPEN IO_CURSOR FOR
--				WITH tt_CMCUSTM_5
--					 AS (SELECT a.custcode, a.custname, REPLACE(a.businessno, '-', '') businessno
--						 FROM	CMCUSTM a
--								JOIN (SELECT   businessno, MIN(custcode) custcode
--									  FROM	   CMCUSTM
--									  WHERE    REPLACE(businessno, '-', '') <> ''
--									  GROUP BY businessno) b
--									ON a.custcode = b.custcode)
--				SELECT	 'N' seldiv,																																																																				 -- 선택여부
--                         FNSTUFF(FNSTUFF(FNSTUFF(a.card_no, 5, 0, '-'), 10, 0, '-'), 15, 0, '-') card_nb,																																																 -- 카드번호
--                         NVL(g.cardname, '') card_nm,																																																																 -- 카드명칭
--                         FNSTUFF(FNSTUFF(RTRIM(a.appr_date), 5, 0, '-'), 8, 0, '-') appr_date,																																																				 -- 승인일자
--                         RTRIM(a.appr_time) appr_time,																																																																 -- 승인시간
--                         RTRIM(a.appr_no) appr_nb,																																																																	 -- 승인번호
--                         NVL(k.custname, a.chain_nm) fr_nm, 																																																														  -- 가맹점
--                         a.won_amt appr_amt,																																																											 -- 승인금액
--                         RTRIM(a.branchtype) fr_upjong_nm,																																																															   -- 업종
--                         RTRIM(a.branch_addr1) fr_addr, 																																																															   -- 주소
--                         FNSTUFF(FNSTUFF(RTRIM(a.chain_id), 4, 0, '-'), 7, 0, '-') fr_co_reg_nb,																																																			-- 사업자번호
--                         RTRIM(a.cancel_yn) appr_cancel_yn, 																																																														 -- 취소여부
--                         RTRIM(a.bank_cd) bank_nm,																																																																	 -- 카드사명
--                         c.slipdiv, 																																																																		   -- 분개방법(AC68)
--                         NVL(i.divname, j.accname) slipdivname, 																																																													-- 분개방법명
--                         D.remark1, 																																																																				 -- 사용내역
--                         e.slipindate,																																																																				 -- 전표일자
--                         e.slipinnum,																																																																				 -- 전표번호
--                         f.empname, 																																																																				 -- 작성사원
--                         NVL(k.custcode, p_custcode) custcode,																																																														-- 거래처코드
--                         M.divcode cardcode,
--                         M.divname cardname,
--                         N.custcode cardcustcode,
--                         N.custname cardcustname
--                FROM	 IBKDB.EBRANCH.TCARD_APPR a
--                         LEFT JOIN TABLE(FNSPLIT(ip_cardno, ';')) b ON a.card_no LIKE '%' || b.codes || '%'
--                         LEFT JOIN ACORDCARD c
--                             ON a.appr_date = c.appr_date
--                                AND a.appr_time = c.appr_time
--                                AND a.appr_no = c.appr_nb
--                         LEFT JOIN ACORDD D
--                             ON c.compcode = D.compcode
--                                AND c.slipinno = D.slipinno
--                                AND c.slipinseq = D.slipinseq
--                         LEFT JOIN ACORDM e
--                             ON D.compcode = e.compcode
--                                AND D.slipinno = e.slipinno
--                         LEFT JOIN CMEMPM f ON e.empcode = f.empcode
--                         LEFT JOIN ACCARDM g
--                             ON SUBSTR(a.CARD_NO, 0, 4) = SUBSTR(REPLACE(g.cardno, '-', ''), 0, 4)
--                                AND SUBSTR(a.CARD_NO, -4, 4) = SUBSTR(REPLACE(g.cardno, '-', ''), -4, 4)
--                         LEFT JOIN CMEMPM h ON g.empcode = h.empcode
--                         LEFT JOIN CMCOMMONM i
--                             ON i.cmmcode = 'AC68'
--                                AND c.slipdiv = i.divcode
--                         LEFT JOIN ACACCM j ON c.slipdiv = j.acccode
--                         LEFT JOIN tt_CMCUSTM_5 k ON RTRIM(a.chain_id) = k.businessno
--                         LEFT JOIN IB_CARD_COMP l
--                             ON a.card_no = l.CARD_SEQ
--                                AND a.appr_date = l.APPR_DATE
--                                AND a.appr_seq = l.APPR_DATE_SEQ
--                         LEFT JOIN CMCOMMONM M
--                             ON M.cmmcode = 'AC17'
--                                AND g.cardcls = M.divcode
--                         LEFT JOIN CMCUSTM N ON g.custcode = N.custcode
--                WHERE	 a.appr_date BETWEEN p_strdate AND p_enddate
--                         AND (ip_cardno IS NULL
--                              OR b.codes IS NOT NULL)
--                         AND COALESCE(h.deptcode, g.deptcode, p_deptcode) LIKE p_deptcode
--                         AND l.APPR_DATE IS NULL
--                ORDER BY a.card_no, a.appr_date, a.appr_time;
--		END;
--	ELS
-- IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리 IBK은행 데이터베이스 관련 주석 처리

    IF (UPPER(P_DIV) = 'SC') THEN
		-- 법인카드번호 조회
		FOR rec
			IN (SELECT NVL(
							  MAX(CASE WHEN seq = 1 THEN cardno || ';' ELSE '' END)
						   || MAX(CASE WHEN seq = 2 THEN cardno || ';' ELSE '' END)
                           || MAX(CASE WHEN seq = 3 THEN cardno || ';' ELSE '' END)
                           || MAX(CASE WHEN seq = 4 THEN cardno || ';' ELSE '' END)
                           || MAX(CASE WHEN seq = 5 THEN cardno || ';' ELSE '' END)
                           || MAX(CASE WHEN seq = 6 THEN cardno || ';' ELSE '' END)
                           || MAX(CASE WHEN seq = 7 THEN cardno || ';' ELSE '' END)
                           || MAX(CASE WHEN seq = 8 THEN cardno || ';' ELSE '' END)
                           || MAX(CASE WHEN seq = 9 THEN cardno || ';' ELSE '' END),
						   '')
						   AS alias1
				FROM   (SELECT ROW_NUMBER() OVER (ORDER BY cardno) seq, cardno
						FROM   ACCARDM
						WHERE  compcode = p_compcode
							   AND empcode = p_empcode) a)
		LOOP
			MESSAGE := rec.alias1;
		END LOOP;

	ELSIF (UPPER(P_DIV) = 'I') THEN
		-- 법인카드승인내역 전표번호생성
		INSERT INTO ACORDCARD(compcode,
							  slipinno,
							  slipinseq,
							  slipdiv,
							  appr_date,
							  appr_time,
							  appr_nb,
							  seldiv)
		VALUES		(p_compcode,
					 p_slipinno,
					 p_slipinseq,
					 p_slipdiv,
					 REPLACE(p_appr_date, '-', ''),
					 p_appr_time,
					 p_appr_nb,
					 'N');

	ELSIF (UPPER(P_DIV) = 'U') THEN
		-- 법인카드승인내역 전표번호갱신
		UPDATE ACORDCARD a
		SET    a.slipdiv = p_slipdiv, a.appr_date = REPLACE(p_appr_date, '-', ''), a.appr_time = p_appr_time--,appr_time = replace(@appr_time,':','')
			   , a.appr_nb = p_appr_nb
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq;

	ELSIF (UPPER(P_DIV) = 'D') THEN
		-- 법인카드승인내역 전표번호삭제
		DELETE ACORDCARD
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno
			   AND slipinseq = p_slipinseq;

	ELSIF (UPPER(P_DIV) = 'DA') THEN
		-- 법인카드승인내역 전표번호 전체삭제
		DELETE ACORDCARD
		WHERE  compcode = p_compcode
			   AND slipinno = p_slipinno;

	END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
