CREATE PROCEDURE spACacc0148R
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0148R
	-- 작 성 자         : 최용석
	-- 작성일자         : 2013-01-24
	-- 수 정 자     : 강현호
	-- E-Mail       : roykang0722@gmail.com
	-- 수정일자      : 2016-12-20
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 받을어음원장을 조회하는 프로시저이다.
	-- ---------------------------------------------------------------
(
    p_div			IN	   VARCHAR2 DEFAULT '',
    p_compcode		IN	   VARCHAR2 DEFAULT '',
    p_plantcode 	IN	   VARCHAR2 DEFAULT '',
    p_strdate		IN	   VARCHAR2 DEFAULT '',
    p_enddate		IN	   VARCHAR2 DEFAULT '',
    p_outputdiv 	IN	   VARCHAR2 DEFAULT '',
    p_userid		IN	   VARCHAR2 DEFAULT '',
    p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
    p_reasontext	IN	   VARCHAR2 DEFAULT '',

    MESSAGE         OUT    VARCHAR2,
    IO_CURSOR       OUT    TYPES.DataSet
)
AS
    p_acccode   VARCHAR2(20);
    p_odiv1     VARCHAR2(5);
    p_odiv2     VARCHAR2(5);
BEGIN

    MESSAGE := '데이터 확인';

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

	IF (p_div = 'S') THEN

        p_acccode := '1110806';

        FOR rec IN (SELECT filter1
                    FROM   CMCOMMONM
                    WHERE  cmmcode = 'AC261'
                           AND divcode = '1110806')
        LOOP
            p_acccode := rec.filter1 ;
        END LOOP;

        IF (p_outputdiv = '1') THEN
            --K-GAAP
            p_odiv1 := '20';
            p_odiv2 := 'F';
        ELSIF (p_outputdiv = '2') THEN
            --IFRS
            p_odiv1 := '30';
            p_odiv2 := 'K';
        END IF;


        --임시테이블 초기화
        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0148R_ACORDD';

        INSERT INTO VGT.TT_ACACC0148R_ACORDD
            SELECT  grp,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN slipdate ELSE slipdate END ) slipdate,
                    CASE WHEN grp = 0 AND slipdate < p_strdate THEN '이월'
                         WHEN grp = 0 AND slipdate >= p_strdate THEN slipnum
                         WHEN grp = 1 THEN '일계'
                         ELSE '누계'
                    END slipnum,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN slipinseq ELSE NULL END) slipinseq,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN a.remark ELSE '' END) remark,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN billdiv ELSE '' END) billdiv,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN custcode ELSE '' END) custcode,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN custname ELSE '' END) custname,
                    SUM(debamt) debamt,
                    SUM(creamt) creamt,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN slipindate ELSE '' END) slipindate,
                    MAX(CASE WHEN grp = 0 AND slipdate >= p_strdate THEN slipinnum ELSE '' END) slipinnum,
                    SUM(CASE WHEN NVL(c.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END) fnamt,
                    ROW_NUMBER() OVER (ORDER BY CASE WHEN grp = 0 AND slipdate < p_strdate THEN SUBSTR(slipdate, 0, 7) || '-00' ELSE slipdate END,
                                                grp,
                                                CASE WHEN grp = 0 AND slipdate >= p_strdate THEN SUBSTR(slipnum, 0, 1) ELSE '' END DESC,
                                                CASE WHEN grp = 0 AND slipdate < p_strdate THEN '이월'
                                                     WHEN grp = 0 AND slipdate >= p_strdate THEN slipnum
                                                     WHEN grp = 1 THEN '일계'
                                                     ELSE '누계' END,
                                                CASE WHEN grp = 0 AND slipdate < p_strdate THEN 0
                                                     WHEN grp = 0 AND slipdate >= p_strdate THEN slipinseq
                                                     WHEN grp = 1 THEN 8888
                                                     ELSE 9999 END ) ord

            FROM    (   SELECT  slipym || '-00' slipdate,
                                '' slipnum,
                                0 slipinseq,
                                '' remark,
                                '' billdiv,
                                '' custcode,
                                '' custname,
                                NVL(bsdebamt, 0) debamt,
                                NVL(bscreamt, 0) creamt,
                                '' slipindate,
                                '' slipinnum,
                                acccode
                        FROM    ACORDDMM
                        WHERE   compcode = p_compcode
                                AND plantcode LIKE p_plantcode
                                AND slipym = SUBSTR(p_strdate, 0, 7)
                                AND (closediv = '10' OR closediv = p_odiv1)
                                AND acccode LIKE p_acccode || '%'
                        UNION ALL
                        SELECT  a.slipdate,
                                a.slipnum,
                                a.slipinseq,
                                NVL(c.mngcluval, '') || '-' || NVL(f.divname, '') || '-만기:' || E.expdate remark,
                                NVL(G.divname, '') billdiv,
                                NVL(D.mngcluval, '') custcode,
                                NVL(D.mngcludec, '') custname,
                                NVL(a.debamt, 0) debamt,
                                NVL(a.creamt, 0) creamt,
                                b.slipindate,
                                b.slipinnum,
                                a.acccode
                        FROM    ACORDD a
                                JOIN ACORDM b ON a.compcode = b.compcode
                                                 AND a.slipinno = b.slipinno
                                                 AND b.slipdiv <> p_odiv2
                                LEFT JOIN ACORDS c ON a.compcode = c.compcode
                                                      AND a.slipinno = c.slipinno
                                                      AND a.slipinseq = c.slipinseq
                                                      AND c.mngclucode = 'S110'
                                LEFT JOIN ACORDS D ON a.compcode = D.compcode
                                                      AND a.slipinno = D.slipinno
                                                      AND a.slipinseq = D.slipinseq
                                                      AND D.mngclucode = 'S010'
                                LEFT JOIN ACBILLM E ON c.compcode = E.compcode
                                                       AND c.mngcluval = E.billno
                                LEFT JOIN CMCOMMONM f ON f.cmmcode = 'AC53'
                                                         AND CASE WHEN a.slipinno LIKE '%C%' THEN '1' ELSE E.billstate END = f.divcode
                                LEFT JOIN CMCOMMONM G ON G.cmmcode = 'SL181'
                                                         AND E.billdiv = G.divcode
                        WHERE   a.compcode = p_compcode
                                AND a.plantcode LIKE p_plantcode
                                AND a.slipdate BETWEEN SUBSTR(p_strdate, 0, 8) || '01' AND p_enddate
                                AND a.acccode LIKE p_acccode || '%' ) a

                    JOIN (  SELECT 0 grp FROM DUAL
                            UNION
                            SELECT 1 FROM DUAL
                            UNION
                            SELECT 2 FROM DUAL ) b ON b.grp = 0 OR a.slipdate >= p_strdate

                    JOIN ACACCM c ON a.acccode = c.acccode

            GROUP BY grp,
                     CASE WHEN grp = 0 AND slipdate < p_strdate THEN SUBSTR(slipdate, 0, 7) || '-00' ELSE slipdate END,
                     CASE WHEN grp = 0 AND slipdate >= p_strdate THEN SUBSTR(slipnum, 0, 1) ELSE '' END,
                     CASE WHEN grp = 0 AND slipdate < p_strdate THEN '이월'
                          WHEN grp = 0 AND slipdate >= p_strdate THEN slipnum
                          WHEN grp = 1 THEN '일계'
                          ELSE '누계'
                     END,
                     CASE WHEN grp = 0 AND slipdate < p_strdate THEN 0
                          WHEN grp = 0 AND slipdate >= p_strdate THEN slipinseq
                          WHEN grp = 1 THEN 8888
                          ELSE 9999
                     END ;



        MERGE INTO VGT.TT_ACACC0148R_ACORDD a
        USING (
                SELECT  CASE WHEN a.grp = 2 THEN b.debamt ELSE a.debamt END AS debamt
                        , CASE WHEN a.grp = 2 THEN b.creamt ELSE a.creamt END AS creamt
                        , CASE WHEN a.grp <> 1 THEN b.fnamt END AS fnamt
                        , a.ord
                FROM   VGT.TT_ACACC0148R_ACORDD a
                JOIN (
                        SELECT  a.ord
                                , SUM(b.debamt) debamt
                                , SUM(b.creamt) creamt
                                , SUM(b.fnamt) fnamt
                        FROM    VGT.TT_ACACC0148R_ACORDD a
                                JOIN VGT.TT_ACACC0148R_ACORDD b ON a.ord >= b.ord
                                                       AND b.grp = 0
                        GROUP BY a.ord ) b ON a.ord = b.ord
             ) b ON ( a.ord = b.ord )
        WHEN MATCHED THEN UPDATE SET    a.debamt = b.debamt
                                        , a.creamt = b.creamt
                                        , a.fnamt = b.fnamt ;


        OPEN IO_CURSOR FOR
            SELECT  a.slipdate,
                    a.slipnum,
                    a.slipinseq,
                    a.remark,
                    a.billdiv,
                    a.custcode,
                    a.custname,
                    a.debamt,
                    a.creamt,
                    a.fnamt
            FROM    VGT.TT_ACACC0148R_ACORDD a
            ORDER BY a.ord;

  END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;

END;
/
