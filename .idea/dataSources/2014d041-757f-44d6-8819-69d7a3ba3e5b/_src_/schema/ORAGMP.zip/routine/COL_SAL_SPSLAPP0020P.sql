CREATE PROCEDURE        COL_SAL_SPSLAPP0020P
-- ---------------------------------------------------------------
-- 프로시저명       : spSLapp0020P
-- 작 성 자         : 조성희
-- 작성일자         : 2008-11-14
-- 수 정 자            : 이세민
-- 수정일자            : 2014-01-16
-- 수정내용            : 최종결재이후 appdate갱신은 없음.(최초 수금 등록시 매출일은 확정된 상태임.)
-- ---------------------------------------------------------------
-- 프로시저 설명    : 수금테이블(SLCOLM)을 등록,수정,삭제,조회하는 프로시저이다.
-- ---------------------------------------------------------------
(
    p_div                      IN     VARCHAR2 DEFAULT '',

    p_plantcode                IN     VARCHAR2 DEFAULT '',
    p_coldate                  IN     VARCHAR2 DEFAULT '',
    p_colsdate                 IN     VARCHAR2 DEFAULT '',
    p_coledate                 IN     VARCHAR2 DEFAULT '',
    p_colseq                   IN     VARCHAR2 DEFAULT '',
    p_saldiv                   IN     VARCHAR2 DEFAULT '',
    p_coldiv                   IN     VARCHAR2 DEFAULT '',
    p_orderdiv                 IN     VARCHAR2 DEFAULT '',
    p_tasooyn                           IN     VARCHAR2 DEFAULT '',
    p_custcode                 IN     VARCHAR2 DEFAULT '',
    p_deptcode                 IN     VARCHAR2 DEFAULT '',
    p_empcode                  IN     VARCHAR2 DEFAULT '',
    p_ecustcode                IN     VARCHAR2 DEFAULT '',
    p_edeptcode                IN     VARCHAR2 DEFAULT '',
    p_eempcode                 IN     VARCHAR2 DEFAULT '',
    p_utdiv                    IN     VARCHAR2 DEFAULT '',
    p_eutdiv                   IN     VARCHAR2 DEFAULT '',
    p_colamt                   float DEFAULT 0,
    p_colvat                             float DEFAULT 0,
    p_accountno                IN     VARCHAR2 DEFAULT '',
    p_billno                   IN     VARCHAR2 DEFAULT '',
    p_issdate                  IN     VARCHAR2 DEFAULT '',
    p_expdate                  IN     VARCHAR2 DEFAULT '',
    p_paybank                  IN     VARCHAR2 DEFAULT '',
    p_paybankbr                         IN     VARCHAR2 DEFAULT '',
    p_issempnm                 IN     VARCHAR2 DEFAULT '',
    p_baeseo                             IN     VARCHAR2 DEFAULT '',
    p_cardcomp                 IN     VARCHAR2 DEFAULT '',
    p_cardno                   IN     VARCHAR2 DEFAULT '',
    p_cardokno                 IN     VARCHAR2 DEFAULT '',
    p_carddate                         IN     VARCHAR2 DEFAULT '',
    p_autoyn                             IN     VARCHAR2 DEFAULT '',
    p_divmonth                 float DEFAULT 0,
    p_enuriyn                  IN     VARCHAR2 DEFAULT '',
    p_appdate                  IN     VARCHAR2 DEFAULT '',
    p_discntdate               IN     VARCHAR2 DEFAULT '',
    p_custprtyn                         IN     VARCHAR2 DEFAULT '',
    p_remark                             IN     VARCHAR2 DEFAULT '',
    p_statediv                 IN     VARCHAR2 DEFAULT '',
    p_iempcode                 IN     VARCHAR2 DEFAULT '',
    p_uempcode                 IN     VARCHAR2 DEFAULT '',
    p_salpower                         IN     VARCHAR2 DEFAULT '',
    p_colno                               IN     VARCHAR2 DEFAULT '',
    p_classdiv                         IN     VARCHAR2 DEFAULT '',
    p_coldtldiv                         IN     VARCHAR2 DEFAULT '',
    p_edimanageno                     char DEFAULT '',
    p_edidt                    IN     VARCHAR2 DEFAULT '',
    p_ediyymm                  IN     VARCHAR2 DEFAULT '',
    p_apprseq                           int DEFAULT 0,
    p_apprlastseq                     int DEFAULT 0,
    p_apprremark                       IN     VARCHAR2 DEFAULT '',
    p_apprstatus                       IN     VARCHAR2 DEFAULT '',

    p_userid                   IN     VARCHAR2 DEFAULT '',
    p_reasondiv                         IN     VARCHAR2 DEFAULT '',
    p_reasontext                       IN     VARCHAR2 DEFAULT ''
)
AS
    ip_plantcode   VARCHAR2(4);
    ip_minseq      INT;
    ip_empcode     VARCHAR2(20);

    vDebug         VARCHAR2(4000) := '';

BEGIN

    vDebug := vDebug || '============================================='                   || chr(10);
    vDebug := vDebug || 'Procedure Name : COL_SAL_SPSLAPP0020P'                           || chr(10);
    vDebug := vDebug || 'Procedure Time : ' || TO_CHAR(SYSDATE(),'YYYY-MM-DD HH24:MI:SS') || chr(10);
    vDebug := vDebug || '============================================='                   || chr(10);

    vDebug := vDebug || '[Parameter Info]'                         || chr(10);
    vDebug := vDebug || '  p_div            = ' || p_div           || chr(10);
    vDebug := vDebug || '  p_plantcode   = ' || p_plantcode        || chr(10);
    vDebug := vDebug || '  p_coldate     = ' || p_coldate          || chr(10);
    vDebug := vDebug || '  p_colsdate    = ' || p_colsdate         || chr(10);
    vDebug := vDebug || '  p_coledate    = ' || p_coledate         || chr(10);
    vDebug := vDebug || '  p_colseq      = ' || p_colseq           || chr(10);
    vDebug := vDebug || '  p_saldiv      = ' || p_saldiv           || chr(10);
    vDebug := vDebug || '  p_coldiv      = ' || p_coldiv           || chr(10);
    vDebug := vDebug || '  p_orderdiv    = ' || p_orderdiv         || chr(10);
    vDebug := vDebug || '  p_tasooyn     = ' || p_tasooyn          || chr(10);
    vDebug := vDebug || '  p_custcode    = ' || p_custcode         || chr(10);
    vDebug := vDebug || '  p_deptcode    = ' || p_deptcode         || chr(10);
    vDebug := vDebug || '  p_empcode     = ' || p_empcode          || chr(10);
    vDebug := vDebug || '  p_ecustcode   = ' || p_ecustcode        || chr(10);
    vDebug := vDebug || '  p_edeptcode   = ' || p_edeptcode        || chr(10);
    vDebug := vDebug || '  p_eempcode    = ' || p_eempcode         || chr(10);
    vDebug := vDebug || '  p_utdiv       = ' || p_utdiv            || chr(10);
    vDebug := vDebug || '  p_eutdiv      = ' || p_eutdiv           || chr(10);
    vDebug := vDebug || '  p_colamt      = ' || p_colamt           || chr(10);
    vDebug := vDebug || '  p_colvat      = ' || p_colvat           || chr(10);
    vDebug := vDebug || '  p_accountno   = ' || p_accountno        || chr(10);
    vDebug := vDebug || '  p_billno      = ' || p_billno           || chr(10);
    vDebug := vDebug || '  p_issdate     = ' || p_issdate          || chr(10);
    vDebug := vDebug || '  p_expdate     = ' || p_expdate          || chr(10);
    vDebug := vDebug || '  p_paybank     = ' || p_paybank          || chr(10);
    vDebug := vDebug || '  p_paybankbr   = ' || p_paybankbr        || chr(10);
    vDebug := vDebug || '  p_issempnm    = ' || p_issempnm         || chr(10);
    vDebug := vDebug || '  p_baeseo      = ' || p_baeseo           || chr(10);
    vDebug := vDebug || '  p_cardcomp    = ' || p_cardcomp         || chr(10);
    vDebug := vDebug || '  p_cardno      = ' || p_cardno           || chr(10);
    vDebug := vDebug || '  p_cardokno    = ' || p_cardokno         || chr(10);
    vDebug := vDebug || '  p_carddate    = ' || p_carddate         || chr(10);
    vDebug := vDebug || '  p_autoyn      = ' || p_autoyn           || chr(10);
    vDebug := vDebug || '  p_divmonth    = ' || p_divmonth         || chr(10);
    vDebug := vDebug || '  p_enuriyn     = ' || p_enuriyn          || chr(10);
    vDebug := vDebug || '  p_appdate     = ' || p_appdate          || chr(10);
    vDebug := vDebug || '  p_discntdate  = ' || p_discntdate       || chr(10);
    vDebug := vDebug || '  p_custprtyn   = ' || p_custprtyn        || chr(10);
    vDebug := vDebug || '  p_remark      = ' || p_remark           || chr(10);
    vDebug := vDebug || '  p_statediv    = ' || p_statediv         || chr(10);
    vDebug := vDebug || '  p_iempcode    = ' || p_iempcode         || chr(10);
    vDebug := vDebug || '  p_uempcode    = ' || p_uempcode         || chr(10);
    vDebug := vDebug || '  p_salpower    = ' || p_salpower         || chr(10);
    vDebug := vDebug || '  p_colno       = ' || p_colno            || chr(10);
    vDebug := vDebug || '  p_classdiv    = ' || p_classdiv         || chr(10);
    vDebug := vDebug || '  p_coldtldiv   = ' || p_coldtldiv        || chr(10);
    vDebug := vDebug || '  p_edimanageno = ' || p_edimanageno      || chr(10);
    vDebug := vDebug || '  p_edidt       = ' || p_edidt            || chr(10);
    vDebug := vDebug || '  p_ediyymm     = ' || p_ediyymm          || chr(10);
    vDebug := vDebug || '  p_apprseq     = ' || p_apprseq          || chr(10);
    vDebug := vDebug || '  p_apprlastseq = ' || p_apprlastseq      || chr(10);
    vDebug := vDebug || '  p_apprremark  = ' || p_apprremark       || chr(10);
    vDebug := vDebug || '  p_apprstatus  = ' || p_apprstatus       || chr(10);

    vDebug := vDebug || '[Debug Info]' || chr(10);


    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF(p_div = 'U')  THEN

      UPDATE      SLCOLM
      SET         coldiv = p_coldiv
      ,           tasooyn = p_tasooyn
      ,           custcode = p_custcode
      ,           empcode = p_empcode
      ,           deptcode = p_deptcode
      ,           ecustcode = p_ecustcode
      ,           edeptcode = p_edeptcode
      ,           eempcode = p_eempcode
      ,           utdiv = p_utdiv
      ,           eutdiv = p_eutdiv
      ,           colamt = p_colamt
      ,           colvat = p_colvat
      ,           accountno = p_accountno
      ,           billno = p_billno
      ,           issdate = p_issdate
      ,           expdate = p_expdate
      ,           paybank = p_paybank
      ,           issempnm = p_issempnm
      ,           cardcomp = p_cardcomp
      ,           cardno = p_cardno
      ,           cardokno = p_cardokno
      ,           divmonth = p_divmonth
      ,           enuriyn = p_enuriyn
      ,           apprstatus=p_apprstatus
      --,appdate = p_appdate
      ,           appdate = p_carddate --화면상의 매출일은 카드 매출일이었고 매출확정과 동일하게 넣어주고 추후에는 분리해서 처리하도록 한다(20140116:이세민)
      ,           discntdate = p_discntdate
      ,           bigo   = p_remark
      ,           remark = p_remark
      ,           statediv = p_statediv
      ,           updatedt = SYSDATE
      ,           uempcode = p_uempcode
      ,           paybankbr = p_paybankbr
      ,           baeseo = p_baeseo
      ,           carddate = p_carddate
      ,           autoyn = p_autoyn
      ,           coldtldiv = p_coldtldiv
      WHERE        coldate = p_coldate
        AND   colseq = p_colseq;


      vDebug := vDebug || 'UPDATE SLCOLM : ' || SQL%ROWCOUNT || chr(10);

  ELSIF(p_div = 'AC') THEN

      --파라미터 오류 처리
      ip_empcode := p_iempcode;

      -- 결재자 업데이트
      UPDATE    SLAPPRHDCOL
      SET        apprempcode = p_empcode
      ,          appr_dt = SYSDATE
      ,          appryn = 'Y'
      ,          apprremark = p_apprremark
      WHERE      colno = p_colno
        AND   apprseq = p_apprseq;

      --EDI 데이터 최종 사용 처리
      IF(p_apprseq <> p_apprlastseq) THEN

        --결재중으로 업데이트
        UPDATE SLCOLM
           SET apprstatus = '02'
              ,statediv   = '07'
         WHERE coldate = p_coldate
           AND colseq  = p_colseq;


        vDebug := vDebug || 'UPDATE SLCOLM apprstatus = 02 : ' || SQL%ROWCOUNT || chr(10);

      ELSE
        --결재완료 처리
        UPDATE SLCOLM
           SET apprstatus = '03'
              ,statediv   = '09'
              ,appdate    = p_coldate   --TO_CHAR(SYSDATE, 'YYYY-MM-DD')
         WHERE coldate    = p_coldate
           AND colseq     = p_colseq;

        vDebug := vDebug || 'UPDATE SLCOLM apprstatus = 03 : ' || SQL%ROWCOUNT || chr(10);

        ORAGMP.COL_SAL_spSLSALERESULT_N ('M',
                                         p_plantcode,
                                         p_appdate,
                                         p_iempcode,
                                         p_custcode,
                                         p_ecustcode,
                                         p_deptcode,
                                         p_userid,
                                         p_reasondiv,
                                         p_reasontext);


      END IF;

      SELECT  min(apprseq)
      INTO    ip_minseq
            FROM      SLAPPRHDCOL
            WHERE        colno = p_colno
        AND   apprseq = p_apprseq
        AND   appryn = 'N';




      UPDATE    SLAPPRHCOL
            SET       apprworkseq = (case when ip_minseq is null  then p_apprlastseq else ip_minseq end)
            WHERE        colno = p_colno;

      vDebug := vDebug || 'UPDATE SLAPPRHCOL SET apprworkseq = ' || ip_minseq || ' : ' || SQL%ROWCOUNT || chr(10);

  ELSIF(p_div = 'AD') THEN

    --파라미터 오류 처리
        ip_empcode := p_iempcode;

        -- 결재자 업데이트
        UPDATE    SLAPPRHDCOL
    SET        apprempcode = ip_empcode
    ,          appr_dt = SYSDATE
    ,          appryn = 'Y'
    ,          apprremark = p_apprremark
    WHERE      colno = p_colno
      AND   apprseq = p_apprseq
        AND   plantcode = p_plantcode;

      vDebug := vDebug || 'UPDATE SLAPPRHDCOL SET apprempcode = ' || ip_empcode || ' : ' || SQL%ROWCOUNT || chr(10);


        --반려로 업데이트
        UPDATE    SLCOLM
    SET        apprstatus = '04'
    ,       statediv = '99'
        WHERE      coldate = p_coldate
      AND   colseq = p_colseq;

      vDebug := vDebug || 'UPDATE SLCOLM SET apprstatus = 04 : ' || SQL%ROWCOUNT || chr(10);

  END IF;


  INSERT INTO SPDEBUG(SPNAME, DIV, TEXT, USERID)
  VALUES('COL_SAL_SPSLAPP0020P', p_div, vDebug, p_iempcode);

END;
/
