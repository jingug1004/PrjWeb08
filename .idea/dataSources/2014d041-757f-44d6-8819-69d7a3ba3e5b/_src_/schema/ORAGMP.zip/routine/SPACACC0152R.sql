CREATE PROCEDURE spACacc0152R(
	-- ---------------------------------------------------------------
	-- 프로시저명       : spACacc0152R
	-- 작 성 자         : 홍지은
	-- 작성일자         : 2015-04-07
	-- 작 성 자         : 임 정호
	-- 작성일자         : 2016-12-21
	-- ---------------------------------------------------------------
	-- 프로시저 설명    : 자금수지내역을 관리하는 프로시저이다.
	-- ---------------------------------------------------------------

	p_div			IN	   VARCHAR2 DEFAULT '',
	p_compcode		IN	   VARCHAR2 DEFAULT '',
	p_fundym		IN	   VARCHAR2 DEFAULT '',
	p_amtunit		IN	   VARCHAR2 DEFAULT '',
	p_userid		IN	   VARCHAR2 DEFAULT '',
	p_reasondiv 	IN	   VARCHAR2 DEFAULT '',
	p_reasontext	IN	   VARCHAR2 DEFAULT '',
	IO_CURSOR		   OUT TYPES.DataSet,
	MESSAGE 		   OUT VARCHAR2
)
AS
	p_rptdiv	  VARCHAR2(10);
	p_rptyear	  VARCHAR2(4);
	p_strdate	  VARCHAR2(10);
	p_enddate	  VARCHAR2(10);
	p_unitamt	  FLOAT(53);
	p_cashcode	  VARCHAR2(20);
	-- 임시테이블의 calcseq의 최대값을 조회
	p_maxseq	  NUMBER(10, 0);
	p_curseq	  NUMBER(10, 0);
BEGIN
	MESSAGE := '데이터 확인';

	EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

	INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
	VALUES		(p_userid, p_reasondiv, p_reasontext);


	IF (p_div = 'S')
	THEN
		p_rptdiv := '01';

		FOR rec IN (SELECT MAX(rptyear) AS alias1
					FROM   ACFNDRPTM
					WHERE  compcode = p_compcode
						   AND rptdiv = p_rptdiv
						   AND rptyear <= SUBSTR(p_fundym, 0, 4))
		LOOP
			p_rptyear := rec.alias1;
		END LOOP;

		p_strdate := SUBSTR(p_fundym, 0, 4) || '-01-01';
		p_enddate := TO_CHAR(ADD_MONTHS(TO_DATE(p_fundym || '-01', 'YYYY-MM-DD'), 1) - 1, 'YYYY-MM-DD');

		p_unitamt := 1000;

		FOR rec IN (SELECT filter2 AS alias1
					FROM   CMCOMMONM
					WHERE  cmmcode = 'SL40'
						   AND divcode = p_amtunit
						   AND isnumeric(filter2) = 1)
		LOOP
			p_unitamt := rec.alias1;
		END LOOP;

		p_cashcode := '11101010';

		FOR rec IN (SELECT value1
					FROM   SYSPARAMETERMANAGE
					WHERE  parametercode = 'acccashcode')
		LOOP
			p_cashcode := rec.value1;
		END LOOP;

		FOR rec IN (SELECT MAX(acccode) AS alias1
					FROM   (SELECT seqline,
								   remark acccode
							FROM   ACFNDRPTM
							WHERE  compcode = p_compcode
								   AND rptdiv = p_rptdiv
								   AND rptyear = p_rptyear
								   AND objdatadiv = 'C')
					WHERE  acccode = p_cashcode)
		LOOP
			p_cashcode := rec.alias1;
		END LOOP;

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0152R_ACORDDMM ';

		INSERT INTO VGT.TT_ACACC0152R_ACORDDMM
			SELECT	 A.SEQLINE,
					 SUM(CASE WHEN slipdate < p_strdate THEN CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END ELSE 0 END) AS amt01,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 1
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt02,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 2
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 2), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt03,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 3
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 3), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt04,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 4
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 4), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt05,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 5
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 5), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt06,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 6
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 6), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt07,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 7
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 7), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt08,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 8
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 7), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt09,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 9
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 9), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt10,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 10
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 10), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt11,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') > 11
								  AND slipdate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 11), 'YYYY-MM-DD')
							 THEN
								 CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END
							 ELSE
								 0
						 END)
						 AS amt12,
					 SUM(CASE WHEN slipdate < p_strdate THEN CASE WHEN NVL(b.dcdiv, '1') = '1' THEN debamt - creamt ELSE creamt - debamt END ELSE 0 END) AS amt99
			FROM	 (SELECT A.seqline,
							 A.acccode,
							 b.slipym || '-00' slipdate,
							 b.bsdebamt debamt,
							 b.bscreamt creamt
					  FROM	 (SELECT seqline,
									 remark acccode
							  FROM	 ACFNDRPTM
							  WHERE  compcode = p_compcode
									 AND rptdiv = p_rptdiv
									 AND rptyear = p_rptyear
									 AND objdatadiv = 'C') /*TW_ACACCM*/
														  A
							 JOIN ACORDDMM b
								 ON b.compcode = p_compcode
									AND b.slipym = SUBSTR(p_strdate, 0, 7)
									AND b.closediv = '10'
									AND A.acccode = b.acccode
					  UNION ALL
					  SELECT (SELECT seqline
							  FROM	 (SELECT seqline,
											 remark acccode
									  FROM	 ACFNDRPTM
									  WHERE  compcode = p_compcode
											 AND rptdiv = p_rptdiv
											 AND rptyear = p_rptyear
											 AND objdatadiv = 'C') /*TW_ACACCM */
							  WHERE  acccode = CASE WHEN b.grp = 2 THEN p_cashcode ELSE A.acccode END),
							 CASE WHEN b.grp = 2 THEN p_cashcode ELSE A.acccode END col,
							 A.slipdate,
							 CASE WHEN b.grp = 2 THEN A.creamt ELSE A.debamt END col,
							 CASE WHEN b.grp = 2 THEN A.debamt ELSE A.creamt END col
					  FROM	 ACORDD A
							 LEFT JOIN (SELECT 1 grp FROM DUAL
										UNION
										SELECT 2 FROM DUAL) b
								 ON b.grp = 1
									AND A.acccode IN (SELECT acccode
													  FROM	 (SELECT seqline,
																	 remark acccode
															  FROM	 ACFNDRPTM
															  WHERE  compcode = p_compcode
																	 AND rptdiv = p_rptdiv
																	 AND rptyear = p_rptyear
																	 AND objdatadiv = 'C'))
									OR b.grp = 2
									   AND p_cashcode IS NOT NULL
									   AND A.dcdiv IN ('3', '4')
					  WHERE  A.compcode = p_compcode
							 AND (A.acccode IN (SELECT acccode
												FROM   (SELECT seqline,
															   remark acccode
														FROM   ACFNDRPTM
														WHERE  compcode = p_compcode
															   AND rptdiv = p_rptdiv
															   AND rptyear = p_rptyear
															   AND objdatadiv = 'C'))
								  OR p_cashcode <> ' '
									 AND A.dcdiv IN ('3', '4'))
							 AND A.slipdate BETWEEN p_strdate AND p_enddate) A
					 LEFT JOIN ACACCM b ON A.acccode = b.acccode
			GROUP BY A.seqline;



		/*
            TW_ACFUNDM
        */

		EXECUTE IMMEDIATE ' DELETE FROM VGT.TT_ACACC0152R_ACFUNDM ';

		INSERT INTO VGT.TT_ACACC0152R_ACFUNDM
			SELECT	 B.SEQLINE,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 1
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 1
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt01,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 2
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 2
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt02,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 3
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 3
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt03,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 4
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 4
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt04,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 5
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 5
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt05,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 6
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 6
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt06,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 7
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 7
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt07,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 8
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 8
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt08,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 9
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 9
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt09,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 10
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 10
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt10,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 11
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 11
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt11,
					 SUM(CASE
							 WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 12
								  AND TO_CHAR(TO_DATE(A.slipdate, 'YYYY-MM-DD'), 'MM') = 12
							 THEN
								 CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END
							 ELSE
								 0
						 END)
						 AS amt12,
					 SUM(CASE WHEN b.objdatadiv = 'I' THEN A.creamt ELSE A.debamt END) AS amt99
			FROM	 ACORDD A
					 JOIN (SELECT seqline,
								  fundcode,
								  objdatadiv
						   FROM   ACFNDRPTM
						   WHERE  compcode = p_compcode
								  AND rptdiv = p_rptdiv
								  AND rptyear = p_rptyear
								  AND objdatadiv IN ('I', 'O')) b
						 ON A.fundcode = b.fundcode
							AND (b.objdatadiv = 'I'
								 AND creamt <> 0
								 OR b.objdatadiv = 'O'
									AND debamt <> 0)
			WHERE	 A.compcode = p_compcode
					 AND A.slipdate BETWEEN p_strdate AND p_enddate
					 AND TRIM(A.fundcode) IS NOT NULL
			GROUP BY B.SEQLINE;

		EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0152R_ACBILLM';

		INSERT INTO VGT.TT_ACACC0152R_ACBILLM
			SELECT SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 1
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 1), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 1), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt01,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 2
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 2), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 2), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 2), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt02,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 3
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 3), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 3), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 3), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt03,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 4
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 4), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 4), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 4), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt04,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 5
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 5), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 5), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 5), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt05,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 6
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 6), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 6), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 6), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt06,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 7
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 7), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 7), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 7), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt07,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 8
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 8), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 8), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 8), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt08,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 9
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 9), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 9), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 9), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt09,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 10
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 10), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 10), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 10), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt10,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 11
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 11), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 11), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 11), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt11,
				   SUM(CASE
						   WHEN TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM') >= 12
								AND A.coldate < TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 12), 'YYYY-MM-DD')
								AND A.expdate <= TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 12), 'YYYY-MM-DD')
								AND (b.billno IS NOT NULL
									 OR TO_CHAR(ADD_MONTHS(TO_DATE(p_strdate, 'YYYY-MM-DD'), 12), 'YYYYMMDD') <= NVL(A.chgslipno, '29991231'))
						   THEN
							   A.billamt - NVL(b.chgamt, 0)
						   ELSE
							   0
					   END)
					   AS amt12,
				   SUM(A.billamt) - NVL(SUM(b.chgamt), 0) AS amt99
			FROM   ACBILLM A
				   LEFT JOIN (SELECT   A.billno,
									   SUM(b.chgamt) AS chgamt
							  FROM	   ACBILLM A
									   JOIN ACBILLP b
										   ON A.compcode = b.compcode
											  AND A.billno = b.billno
							  WHERE    A.compcode = p_compcode
									   AND A.billcls = '1'
									   AND A.coldate <= p_enddate
									   AND p_strdate <= A.expdate
									   AND A.rtnslipno IS NULL
									   AND SUBSTR(b.chgslipno,1, 8) <= REPLACE(p_enddate, '-', '')
							  GROUP BY A.billno) b
					   ON A.billno = b.billno
			WHERE  A.compcode = p_compcode
				   AND A.billcls = '1'
				   AND A.coldate <= p_enddate
				   AND p_strdate <= A.expdate;


		UPDATE VGT.TT_ACACC0152R_ACBILLM
		SET    amt99 =
				   CASE TO_NUMBER(TO_CHAR(TO_DATE(p_enddate, 'YYYY-MM-DD'), 'MM')) WHEN 1 THEN amt01 WHEN 2 THEN amt02 WHEN 3 THEN amt03 WHEN 4 THEN amt04 WHEN 5 THEN amt05 WHEN 6 THEN amt06 WHEN 7 THEN amt07 WHEN 8 THEN amt08 WHEN 9 THEN amt09 WHEN 10 THEN amt10 WHEN 11 THEN amt11 ELSE amt12 END;

		EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0152R_ACFNDRPTM';

		INSERT INTO VGT.TT_ACACC0152R_ACFNDRPTM
			SELECT A.seqline,
				   A.fundcode,
				   A.fundname,
				   A.calcdiv,
				   A.sseqline,
				   A.calcseq,
				   A.useyn,
				   NVL(b.amt01, 0) + NVL(c.amt01, 0) + NVL(D.amt01, 0) amt01,
				   NVL(b.amt02, 0) + NVL(c.amt02, 0) + NVL(D.amt02, 0) amt02,
				   NVL(b.amt03, 0) + NVL(c.amt03, 0) + NVL(D.amt03, 0) amt03,
				   NVL(b.amt04, 0) + NVL(c.amt04, 0) + NVL(D.amt04, 0) amt04,
				   NVL(b.amt05, 0) + NVL(c.amt05, 0) + NVL(D.amt05, 0) amt05,
				   NVL(b.amt06, 0) + NVL(c.amt06, 0) + NVL(D.amt06, 0) amt06,
				   NVL(b.amt07, 0) + NVL(c.amt07, 0) + NVL(D.amt07, 0) amt07,
				   NVL(b.amt08, 0) + NVL(c.amt08, 0) + NVL(D.amt08, 0) amt08,
				   NVL(b.amt09, 0) + NVL(c.amt09, 0) + NVL(D.amt09, 0) amt09,
				   NVL(b.amt10, 0) + NVL(c.amt10, 0) + NVL(D.amt10, 0) amt10,
				   NVL(b.amt11, 0) + NVL(c.amt11, 0) + NVL(D.amt11, 0) amt11,
				   NVL(b.amt12, 0) + NVL(c.amt12, 0) + NVL(D.amt12, 0) amt12,
				   NVL(b.amt99, 0) + NVL(c.amt99, 0) + NVL(D.amt99, 0) amt99
			FROM   ACFNDRPTM A
				   LEFT JOIN VGT.TT_ACACC0152R_ACORDDMM b
					   ON A.objdatadiv = 'C'
						  AND A.seqline = b.seqline
				   LEFT JOIN VGT.TT_ACACC0152R_ACFUNDM c
					   ON A.objdatadiv IN ('I', 'O')
						  AND A.seqline = c.seqline
				   LEFT JOIN VGT.TT_ACACC0152R_ACBILLM D ON A.objdatadiv = 'B'
			WHERE  A.compcode = p_compcode
				   AND A.rptdiv = p_rptdiv
				   AND A.rptyear = p_rptyear;



		p_curseq := 0;

		FOR rec IN (SELECT MAX(calcseq) AS alias1 FROM VGT.TT_ACACC0152R_ACFNDRPTM)
		LOOP
			p_maxseq := rec.alias1;
		END LOOP;

		-- 각 레벨별로 sum을하여 update
		WHILE p_curseq <= p_maxseq
		LOOP
            MERGE INTO VGT.TT_ACACC0152R_ACFNDRPTM tg
            USING	   (SELECT a.FUNDNAME,
                               a.SEQLINE,
                               a.FUNDCODE,
                               a.CALCDIV,
                               a.SSEQLINE,
                               a.USEYN,
                               a.CALCSEQ,
                               A.amt01 + b.amt01 AS pos_2,
                               A.amt02 + b.amt02 AS pos_3,
                               A.amt03 + b.amt03 AS pos_4,
                               A.amt04 + b.amt04 AS pos_5,
                               A.amt05 + b.amt05 AS pos_6,
                               A.amt06 + b.amt06 AS pos_7,
                               A.amt07 + b.amt07 AS pos_8,
                               A.amt08 + b.amt08 AS pos_9,
                               A.amt09 + b.amt09 AS pos_10,
                               A.amt10 + b.amt10 AS pos_11,
                               A.amt11 + b.amt11 AS pos_12,
                               A.amt12 + b.amt12 AS pos_13,
                               A.amt99 + b.amt99 AS pos_14
                        FROM   VGT.TT_ACACC0152R_ACFNDRPTM A
                               JOIN (SELECT   sseqline,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt01 ELSE -amt01 END) AS amt01,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt02 ELSE -amt02 END) AS amt02,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt03 ELSE -amt03 END) AS amt03,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt04 ELSE -amt04 END) AS amt04,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt05 ELSE -amt05 END) AS amt05,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt06 ELSE -amt06 END) AS amt06,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt07 ELSE -amt07 END) AS amt07,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt08 ELSE -amt08 END) AS amt08,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt09 ELSE -amt09 END) AS amt09,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt10 ELSE -amt10 END) AS amt10,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt11 ELSE -amt11 END) AS amt11,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt12 ELSE -amt12 END) AS amt12,
                                              SUM(CASE WHEN calcdiv = '+' THEN amt99 ELSE -amt99 END) AS amt99
                                     FROM	  VGT.TT_ACACC0152R_ACFNDRPTM
                                     WHERE	  calcseq = p_curseq
                                              AND sseqline IS NOT NULL
                                     GROUP BY sseqline) b
                                   ON A.seqline = b.sseqline) src
            ON		   (NVL(tg.FUNDNAME, ' ') = NVL(src.FUNDNAME, ' ')
                        AND NVL(tg.SEQLINE, ' ') = NVL(src.SEQLINE, ' ')
                        AND NVL(tg.FUNDCODE, ' ') = NVL(src.FUNDCODE, ' ')
                        AND NVL(tg.CALCDIV, ' ') = NVL(src.CALCDIV, ' ')
                        AND NVL(tg.SSEQLINE, ' ') = NVL(src.SSEQLINE, ' ')
                        AND NVL(tg.USEYN, ' ') = NVL(src.USEYN, ' ')
                        AND NVL(tg.CALCSEQ, 0) = NVL(src.CALCSEQ, 0))
            WHEN MATCHED
            THEN
                UPDATE SET TG.amt01 = SRC.pos_2,
                           TG.amt02 = SRC.pos_3,
                           TG.amt03 = SRC.pos_4,
                           TG.amt04 = SRC.pos_5,
                           TG.amt05 = SRC.pos_6,
                           TG.amt06 = SRC.pos_7,
                           TG.amt07 = SRC.pos_8,
                           TG.amt08 = SRC.pos_9,
                           TG.amt09 = SRC.pos_10,
                           TG.amt10 = SRC.pos_11,
                           TG.amt11 = SRC.pos_12,
                           TG.amt12 = SRC.pos_13,
                           TG.amt99 = SRC.pos_14;

			p_curseq := p_curseq + 1;
		END LOOP;

		OPEN IO_CURSOR FOR
			SELECT	 seqline,
					 fundcode,
					 fundname,
					 NULLIF(ROUND(amt01 / p_unitamt, 0), 0) amt01,
					 NULLIF(ROUND(amt02 / p_unitamt, 0), 0) amt02,
					 NULLIF(ROUND(amt03 / p_unitamt, 0), 0) amt03,
					 NULLIF(ROUND(amt04 / p_unitamt, 0), 0) amt04,
					 NULLIF(ROUND(amt05 / p_unitamt, 0), 0) amt05,
					 NULLIF(ROUND(amt06 / p_unitamt, 0), 0) amt06,
					 NULLIF(ROUND(amt07 / p_unitamt, 0), 0) amt07,
					 NULLIF(ROUND(amt08 / p_unitamt, 0), 0) amt08,
					 NULLIF(ROUND(amt09 / p_unitamt, 0), 0) amt09,
					 NULLIF(ROUND(amt10 / p_unitamt, 0), 0) amt10,
					 NULLIF(ROUND(amt11 / p_unitamt, 0), 0) amt11,
					 NULLIF(ROUND(amt12 / p_unitamt, 0), 0) amt12,
					 NULLIF(ROUND(amt99 / p_unitamt, 0), 0) amt99
			FROM	 VGT.TT_ACACC0152R_ACFNDRPTM
			WHERE	 useyn = 'Y'
			ORDER BY seqline;
	END IF;

	IF (IO_CURSOR IS NULL)
	THEN
		OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
	END IF;
END;
/
