CREATE PROCEDURE spACacc0016P
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0016P
 -- 작 성 자         : 최용석
 -- 작성일자         : 2011-12-05
 -- 수 정 자     : 강현호
 -- E-Mail       : roykang0722@gmail.com
 -- 수정일자      : 2016-12-12
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 법인카드 정산을 관리하는 프로시저이다.
 -- ---------------------------------------------------------------
(
    p_div           IN VARCHAR2 DEFAULT '',

    p_compcode      IN VARCHAR2 DEFAULT '',
    p_plantcode     IN VARCHAR2 DEFAULT '',
    p_slipsdate     IN VARCHAR2 DEFAULT '',
    p_slipedate     IN VARCHAR2 DEFAULT '',
    p_slipinstate   IN VARCHAR2 DEFAULT '',
    p_stracccode    IN VARCHAR2 DEFAULT '',
    p_endacccode    IN VARCHAR2 DEFAULT '',
    p_seldiv        IN VARCHAR2 DEFAULT '',
    p_slipinno      IN VARCHAR2 DEFAULT '',
    p_slipinseq     IN NUMBER   DEFAULT 0,
    p_slipdate      IN VARCHAR2 DEFAULT '',
    p_iempcode      IN VARCHAR2 DEFAULT '',

    p_userid        IN VARCHAR2 DEFAULT '',
    p_reasondiv     IN VARCHAR2 DEFAULT '',
    p_reasontext    IN VARCHAR2 DEFAULT '',
    MESSAGE         OUT VARCHAR2,
    IO_CURSOR       OUT TYPES.DataSet
)
AS
    p_acautorcode   VARCHAR2(10);
    p_slipdiv       VARCHAR2(5);
    p_slipnum       VARCHAR2(5);
    p_slipno        VARCHAR2(20);
    p_deptcode      VARCHAR2(20);
    p_acccode       VARCHAR2(20);
    p_custcode      VARCHAR2(20);
    p_remark        VARCHAR2(100);

    -- 세금계산서상세 삭제
    ip_compcode     VARCHAR(3);
    ip_plantcode    VARCHAR(4);
    ip_taxno        VARCHAR(20);
    ip_seq          NUMBER;

    ip_slipinno     VARCHAR(20);
    ip_slipinseq    NUMBER;
    ip_mngclucode   VARCHAR(20);

    ip_taxym        VARCHAR(6);
    ip_num          VARCHAR(6);

BEGIN

    MESSAGE := '데이터 확인';

    execute immediate 'delete from atInfo';
    insert into atInfo(userid, reasondiv, reasontext)
    values (p_userid, p_reasondiv, p_reasontext);

    if ( p_div = 'S') then -- 카드전표내역 검색
        -- 기업은행
        open  IO_CURSOR for
        select  nvl(b.seldiv, 'N') as seldiv,         -- 선택여부
                nvl(c.remark1, '') as remark1,        -- 사용내역
                substr(trim(a.card_no), 1, 4) || '-' || substr(trim(a.card_no), 5, 4) || '-' || substr(trim(a.card_no), 9, 4) || '-' || substr(trim(a.card_no), 13, 4) as card_nb,  -- 카드번호
                substr(trim(a.appr_date), 1, 4) || '-' || substr(trim(a.appr_date), 5, 2) || '-' || substr(trim(a.appr_date), 7, 2) as appr_date,   -- 승인일자
                a.appr_time as appr_time,             -- 승인시간
                rtrim(a.appr_no) as appr_nb,          -- 승인번호
                rtrim(a.chain_nm) as fr_nm,           -- 가맹점
                a.appr_amt,                           -- 승인금액
                rtrim(a.branchtype) as fr_upjong_nm,  -- 업종
                rtrim(a.branch_addr1) as fr_addr,     -- 주소
                substr(trim(a.chain_id), 1, 3) || '-' || substr(trim(a.chain_id), 4, 2) || '-' || substr(trim(a.chain_id), 6, 5) as fr_co_reg_nb,   -- 사업자번호
                rtrim(a.cancel_yn) as appr_cancel_yn, -- 취소여부
                g.accname,                            -- 분개계정
                d.slipdate,                           -- 전표일자
                d.slipnum,                            -- 전표번호
                f.empname,                            -- 작성사원
                b.slipinno,                           -- 전표일자
                b.slipinseq                           -- 전표순번

        from    IBKDB_CCM_APPR a
                left join ACORDCARD b
                    on b.compcode = p_compcode
                    and a.appr_date = b.appr_date
                    and a.appr_time = replace(b.appr_time, ':')
                    and a.appr_no = b.appr_nb
                left join ACORDD c
                    on b.compcode = c.compcode
                    and b.slipinno = c.slipinno
                    and b.slipinseq = c.slipinseq
                left join ACORDM d
                    on c.compcode = d.compcode
                    and c.slipinno = d.slipinno
                left join ACCARDM e
                    on a.card_no = replace(e.cardno, '-', '')
                left join CMEMPM f
                    on d.empcode = f.empcode
                left join ACACCM g
                    on c.acccode = g.acccode
                left join IB_CARD_COMP h
                    on a.card_no = h.card_seq
                    and a.appr_date = h.appr_date
                    and to_char(a.appr_seq) = h.appr_date_seq

        where   a.appr_date between replace(p_slipsdate, '-', '') and replace(p_slipedate, '-', '')
                and ( nvl(trim(p_stracccode), '') is null or c.acccode >= p_stracccode)
                and ( nvl(trim(p_endacccode), '') is null or c.acccode <= p_endacccode)
                and nvl(trim(d.slipinstate), ' ') like p_slipinstate
                and nvl(c.plantcode, p_plantcode) = p_plantcode
                and h.appr_date is null

        order by a.appr_date, a.appr_time, a.card_no;

    elsif ( p_div = 'U') then
        -- 카드전표내역 선택저장
        update  ACORDCARD a
        set     a.seldiv = p_seldiv
        where   compcode = p_compcode
                and slipinno = p_slipinno
                and slipinseq = p_slipinseq;

    elsif ( p_div = 'I') then
        -- 카드전표내역 정산전표저장
        p_acautorcode := 'A04030';-- 법인카드정산 자동분개
        p_acccode := '11135060';-- 선급부가세_카드매입
        p_custcode := '0000000';-- 일반거래처

        for rec in (
            select  nvl(value2, '') as acccode,
                    nvl(value3, '') as custcode
            from    SYSPARAMETERMANAGE
            where   parametercode = 'cardacccode')  -- 법인카드 미수금 계정코드
        loop
            p_acccode := rec.acccode;
            p_custcode := rec.custcode;
        end loop;

        for rec in (
            select  accdiv,
                    remark2
            from    ACAUTORULE
            where   acautorcode = p_acautorcode)
        loop
            p_slipdiv := rec.accdiv;
            p_remark := rec.remark2;
        end loop;

        for rec in (
            select  p_slipdiv || substr('0000' || to_char((nvl(substr(max(slipnum), -4, 4), 0) + 1)), -4, 4) as slipnum
            from    ACORDM a
            where   compcode = p_compcode
                    and slipno like replace(p_slipdate, '-', '') || rtrim(p_slipdiv) || '%')
        loop
            p_slipnum := rec.slipnum;
        end loop;

        p_slipno := replace(p_slipdate, '-', '') || p_slipnum;

        for rec in (
            select  deptcode
            from    CMEMPM
            where   empcode = p_iempcode)
        loop
            p_deptcode := rec.deptcode;
        end loop;

        -- 기존전표 삭제
        -- 세금계산서상세 삭제
        delete
        from    ACTAXD a
        where   (a.compcode, a.plantcode, a.taxno, a.seq) in (select  c.compcode, c.plantcode, c.taxno, c.seq
                                                              from    ACORDM a
                                                                      join ACORDD b
                                                                          on a.compcode = b.compcode
                                                                          and a.slipinno = b.slipinno
                                                                      join ACTAXD c
                                                                          on b.compcode = c.compcode
                                                                          and b.plantcode = c.plantcode
                                                                          and b.taxno = c.taxno
                                                              where   a.compcode = p_compcode
                                                                      and a.slipdate = p_slipdate
                                                                      and a.acautorcode = p_acautorcode);

        -- 세금계산서 삭제
        delete
        from    ACTAXM a
        where   (a.compcode, a.plantcode, a.taxno) in ( select  c.compcode, c.plantcode, c.taxno
                                                        from    ACORDM a
                                                                join ACORDD b
                                                                    on a.compcode = b.compcode
                                                                    and a.slipinno = b.slipinno
                                                                join ACTAXM c
                                                                    on b.compcode = c.compcode
                                                                    and b.plantcode = c.plantcode
                                                                    and b.taxno = c.taxno
                                                        where   a.compcode = p_compcode
                                                                and a.slipdate = p_slipdate
                                                                and a.acautorcode = p_acautorcode);

        -- 전표관리항목 삭제
        delete
        from    ACORDS a
        where   (a.compcode, a.slipinno, a.slipinseq, a.mngclucode) in (select  b.compcode, b.slipinno, b.slipinseq, b.mngclucode
                                                                        from    ACORDM a
                                                                                join ACORDS b
                                                                                    on a.compcode = b.compcode
                                                                                    and a.slipinno = b.slipinno
                                                                        where   a.compcode = p_compcode
                                                                                and a.slipdate = p_slipdate
                                                                                and a.acautorcode = p_acautorcode);

        -- 전표상세 삭제
        delete
        from    ACORDD a
        where   (a.compcode, a.slipinno, a.slipinseq) in (select  b.compcode, b.slipinno, b.slipinseq
                                                          from    ACORDM a
                                                                  join ACORDD b
                                                                      on a.compcode = b.compcode
                                                                      and a.slipinno = b.slipinno
                                                          where   a.compcode = p_compcode
                                                                  and a.slipdate = p_slipdate
                                                                  and a.acautorcode = p_acautorcode);

        -- 전표 삭제
        delete
        from    ACORDM a
        where   (a.compcode, a.slipinno) in ( select  a.compcode, a.slipinno
                                              from    ACORDM a
                                              where   a.compcode = p_compcode
                                                      and a.slipdate = p_slipdate
                                                      and a.acautorcode = p_acautorcode);

        -- 전표저장
        insert into ACORDM
            (   compcode,       slipinno,       slipdiv,        slipindate,       slipinnum,
                deptcode,       plantcode,      empcode,        eviddiv,          slipinremark,
                slipno,         slipdate,       slipnum,        slipdeptcode,     slipempcode,
                skreqyn,        skreqdiv,       skreqdate,      skreqdeptcode,    skreqempcode,
                accountno,      slipinstate,    slipremark,     acautorcode,      insertdt,
                iempcode  )
        select  p_compcode,     p_slipno,       p_slipdiv,      p_slipdate,       p_slipnum,
                p_deptcode,     p_plantcode,    p_iempcode,     '99',             p_remark,
                p_slipno,       p_slipdate,     p_slipnum,      '',               '',
                '',             '',             '',             '',               '',
                '',             '4',            '',             acautorcode,      sysdate,
                p_iempcode
        from    ACAUTORULE
        where   acautorcode = p_acautorcode;

        execute immediate 'delete from VGT.TT_ACACC0016P_ACORDD4';
        insert into VGT.TT_ACACC0016P_ACORDD4
        select  row_number() over(order by c.slipinno, c.slipinseq) - 1 as seq,
                a.appr_date,
                to_number(b.appr_amt_supply) as supply,
                to_number(b.appr_amt_surtax) as surtax,
                rtrim(b.appr_nb) as appr_nb,
                c.acccode,
                c.remark1,
                c.remark2,
                c.slipinno,
                c.slipinseq,
                nvl(d.mngcluval, p_custcode) as custcode,
                nvl(d.mngcludec, rtrim(b.fr_nm)) as custname,
                substr(trim(b.fr_co_reg_nb), 1, 3) || '-' || substr(trim(b.fr_co_reg_nb), 4, 2) || '-' || substr(trim(b.fr_co_reg_nb), 6, 5) as businessno,
                nvl(e.mngcluval, '') as deptcode,
                substr(trim(b.card_nb), 1, 4) || '-' || substr(trim(b.card_nb), 5, 4) || '-' || substr(trim(b.card_nb), 9, 4) || '-' || substr(trim(b.card_nb), 13, 4) as card_nb,
                nvl(f.cardname, rtrim(b.card_nm)) as card_nm
        from    ACORDCARD a
                join IB_CARD_APPR b
                    on a.appr_date = b.appr_date
                    and a.appr_time = b.appr_time
                    and a.appr_nb = b.appr_nb
                join ACORDD c
                    on a.compcode = c.compcode
                    and a.slipinno = c.slipinno
                    and a.slipinseq = c.slipinseq
                    and c.plantcode = p_plantcode
                left join ACORDS d
                    on c.compcode = d.compcode
                    and c.slipinno = d.slipinno
                    and c.slipinseq = d.slipinseq
                    and d.mngclucode = 'S010'
                left join ACORDS e
                    on c.compcode = e.compcode
                    and c.slipinno = e.slipinno
                    and c.slipinseq = e.slipinseq
                    and e.mngclucode = 'S040'
                left join ACCARDM f
                    on b.card_nb = replace(f.cardno, '-', '')
        where   a.compcode = p_compcode
                and a.appr_date between replace(p_slipsdate, '-', '') and replace(p_slipedate, '-', '')
                and a.seldiv = 'Y';

        execute immediate 'delete from VGT.TT_ACACC0016P_TAXNO';
        insert into VGT.TT_ACACC0016P_TAXNO
        select  substr(appr_date, 0, 6) as taxym,
                1 as num
        from    VGT.TT_ACACC0016P_ACORDD4
        group by substr(appr_date, 0, 6);

        for rec in (
            select  substr(b.taxno, 0, 6) as taxym,
                    substr(max(b.taxno), -5, 5) || 1 as num
            from    VGT.TT_ACACC0016P_TAXNO a
                    join ACTAXM b
                        on b.compcode = p_compcode
                        and b.taxno like a.taxym || '01%'
                        and b.saleinyn = 'N'
            group by substr(b.taxno, 0, 6))
        loop
            ip_taxym := rec.taxym;
            ip_num   := rec.num;
        end loop;

        update  VGT.TT_ACACC0016P_TAXNO a
        set     num = ip_num
        where   a.taxym = ip_taxym;

        execute immediate 'delete from VGT.TT_ACACC0016P_ACTAXM';
        insert into VGT.TT_ACACC0016P_ACTAXM
        select  b.taxym || '01' || substr('00000' || to_char(row_number() over ( partition by substr(appr_date, 0, 6) order by slipinno, slipinseq) + b.num), -5, 5) as taxno,
                deptcode,
                substr(trim(a.appr_date), 1, 4) || '-' || substr(trim(a.appr_date), 5, 2) || '-' || substr(trim(a.appr_date), 7, 2) as taxdate,
                custcode,
                custname,
                businessno,
                supply,
                surtax,
                supply + surtax as vatamt,
                appr_nb,
                slipinno,
                slipinseq
        from    VGT.TT_ACACC0016P_ACORDD4 a
                join VGT.TT_ACACC0016P_TAXNO b
                    on substr(a.appr_date, 0, 6) = b.taxym;

        -- 계산서 저장
        insert into ACTAXM
            (   compcode,       plantcode,        taxno,        taxdiv,       iotaxdiv,
                sdeptcode,      taxdate,          custcode,     custname,     businessno,
                biznotype,      amt,              vat,          vatamt,       remark,
                rremark,        recogno,          purposediv,   cashtot,      checktot,
                notetot,        credittot,        electaxyn,    purdiv,       saleinyn,
                insertdt,       iempcode)
        select  p_compcode,     p_plantcode,      taxno,        '207',        '01',
                deptcode,       taxdate,          custcode,     custname,     businessno,
                '01',           supply,           surtax,       vatamt,       '',
                '',             appr_nb,          '01',         0,            0,
                0,              vatamt,           'N',          '0',          'N',
                sysdate,        p_iempcode
        from    VGT.TT_ACACC0016P_ACTAXM;

        -- 계산서상세 저장
        insert into ACTAXD
            (   compcode,       plantcode,        taxno,        seq,        itemnm,
                gyugeok,        qty,              prc,          amt,        vat,
                vatamt,         remark,           insertdt,     iempcode)
        select  p_compcode,     p_plantcode,      taxno,        1,          custname,
                '',             0,                0,            supply,     surtax,
                vatamt,         '',               sysdate,      p_iempcode
        from VGT.TT_ACACC0016P_ACTAXM;

        -- 전표상세 저장
        insert into ACORDD
            (
                compcode
                ,slipinno
                ,slipinseq
                ,dcdiv
                ,acccode
                ,plantcode
                ,debamt
                ,creamt
                ,slipdate
                ,slipnum
                ,remark1
                ,remark2
                ,taxno
                ,rptseq
                ,insertdt
                ,iempcode
            )
        select  p_compcode
                ,p_slipno
                ,seq * 2 + grp
                ,'1'
                ,case when grp = 1 then acccode else p_acccode end
                ,p_plantcode
                ,a.surtax * case when grp = 1 then -1 else 1 end
                ,0
                ,p_slipdate
                ,p_slipnum
                ,remark1
                ,remark2
                ,nvl(taxno, '')
                ,seq * 2 + grp
                ,sysdate
                ,p_iempcode
        from    VGT.TT_ACACC0016P_ACORDD4 a
                join (
                    select  1 grp
                    from    DUAL
                    union
                    select  2
                    from    DUAL
                ) b on 1 = 1
                left join VGT.TT_ACACC0016P_ACTAXM c
                    on a.slipinno = c.slipinno
                    and a.slipinseq = c.slipinseq
                    and b.grp = 2;

        -- 전표관리항목 저장
        insert into ACORDS
            (
                compcode
                ,slipinno
                ,slipinseq
                ,mngclucode
                ,seq
                ,mngcluval
                ,mngcludec
                ,insertdt
                ,iempcode
            )
        select  p_compcode
                ,p_slipno
                ,a.seq * 2 + 1
                ,mngclucode
                ,b.seq
                ,mngcluval
                ,mngcludec
                ,sysdate
                ,p_iempcode
        from    VGT.TT_ACACC0016P_ACORDD4 a
                join ACORDS b
                    on b.compcode = p_compcode
                    and a.slipinno = b.slipinno
                    and a.slipinseq = b.slipinseq;

        -- 전표관리항목 저장
        insert into ACORDS
            (
                compcode
                ,slipinno
                ,slipinseq
                ,mngclucode
                ,seq
                ,mngcluval
                ,mngcludec
                ,insertdt
                ,iempcode
            )
        select  p_compcode
                ,p_slipno
                ,a.seq * 2 + 2
                ,b.mngclucode
                ,b.seq
                ,case when b.mngclucode = 'S010' then a.custcode
                      when b.mngclucode = 'S060' then a.card_nb
                      else c.mngcluval end
                ,case when b.mngclucode = 'S010' then a.custname
                      when b.mngclucode = 'S060' then a.card_nm
                      else c.mngcludec end
                ,sysdate
                ,p_iempcode
        from    VGT.TT_ACACC0016P_ACORDD4 a
                join ACACCMNGM b
                    on b.acccode = p_acccode
                    and b.dcdiv = '1'
                left join ACORDS c
                    on c.compcode = p_compcode
                    and a.slipinno = c.slipinno
                    and a.slipinseq = c.slipinseq
                    and b.mngclucode = c.mngclucode;

    end if;

    if (IO_CURSOR is null) then
        open IO_CURSOR for select code from VGT.TT_TABEL_EMPTY;
    end if;

END;
/
