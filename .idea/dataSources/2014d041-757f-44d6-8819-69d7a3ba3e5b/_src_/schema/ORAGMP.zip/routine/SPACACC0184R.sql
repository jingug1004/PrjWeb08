CREATE PROCEDURE spACacc0184R
-- ---------------------------------------------------------------
 -- 프로시저명       : spACacc0184R
 -- 작 성 자         : 최용석
 -- 작성일자         : 2015-02-25
 -- 수정자         : 임 정호
 --수정일          : 2016-12-20
 -- ---------------------------------------------------------------
 -- 프로시저 설명    : 구매원장
 -- ---------------------------------------------------------------

(
    p_div IN VARCHAR2 DEFAULT '' ,
    p_compcode IN VARCHAR2 DEFAULT '' ,
    p_plantcode IN VARCHAR2 DEFAULT '%' ,
    p_strdate IN VARCHAR2 DEFAULT '' ,
    p_enddate IN VARCHAR2 DEFAULT '' ,
    p_acccode IN VARCHAR2 DEFAULT '' ,
    p_custcode IN VARCHAR2 DEFAULT '' ,
    p_userid IN VARCHAR2 DEFAULT '' ,
    p_reasondiv IN VARCHAR2 DEFAULT '' ,
    p_reasontext IN VARCHAR2 DEFAULT '' ,
    IO_CURSOR         OUT TYPES.DataSet,
    MESSAGE           OUT VARCHAR2
)
AS
    p_acccode1 VARCHAR2(20);-- 외상매입금
    p_acccode2 VARCHAR2(20);-- 지급어음
    p_acccode3 VARCHAR2(20);-- 선급부가세

BEGIN

    MESSAGE := '데이터 확인' ;

    EXECUTE IMMEDIATE 'DELETE FROM ATINFO';

    INSERT INTO ATINFO(USERID, REASONDIV, REASONTEXT)
    VALUES        (p_userid, p_reasondiv, p_reasontext);

    IF ( p_div = 'S' ) THEN
        p_acccode1 := '21010100' ;

        FOR  rec IN
        (
            SELECT filter1
            FROM CMCOMMONM
            WHERE  cmmcode = 'AC261'
                AND divcode = '21010100'
        )
        LOOP
            p_acccode1 := rec.filter1   ;
        END LOOP;

        p_acccode2 := '21030200' ;
        FOR  rec IN
        (
            SELECT  filter1
            FROM    CMCOMMONM
            WHERE   cmmcode = 'AC261'
                AND divcode = '21030200'
        )
        LOOP
            p_acccode2 := rec.filter1   ;
        END LOOP;

        p_acccode3 := '11135' ;
        FOR  rec IN
        (
            SELECT filter1
            FROM CMCOMMONM
            WHERE  cmmcode = 'AC261'
                AND divcode = '11135'
        )
        LOOP
            p_acccode3 := rec.filter1   ;
        END LOOP;

        EXECUTE IMMEDIATE 'DELETE FROM VGT.TT_ACACC0184R_DUAL';

        INSERT INTO VGT.TT_ACACC0184R_DUAL
          SELECT b.grp,
                 MAX ( CASE WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.slipinno ELSE NULL END) slipinno,
                 MAX ( CASE WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.slipinseq ELSE NULL END) slipinseq,
                 MAX ( CASE WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.slipindate ELSE NULL END) slipindate,
                 MAX ( CASE WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.slipinnum ELSE NULL END) slipinnum,
                 MAX ( CASE WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.slipno ELSE NULL END) slipno,
                 MAX ( CASE WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.slipdate ELSE SUBSTR (a.slipdate, 0, 7) END) slipdate,
                 MAX ( CASE WHEN b.grp = 0 AND a.slipdate < p_strdate THEN '이월'
                            WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN slipnum
                            WHEN b.grp = 1 THEN '월계'
                            ELSE '누계'
                        END) slipnum,
                 MAX ( CASE WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.remark ELSE '' END) remark,
                 SUM (a.debamt) debamt,
                 SUM (a.creamt) creamt,
                 SUM ( CASE WHEN NVL (c.dcdiv, '1') = '1' THEN a.debamt - a.creamt ELSE a.creamt - a.debamt END) fnamt,
                 ROW_NUMBER () OVER   (
                                            ORDER BY
                                               CASE
                                                  WHEN b.grp = 0 AND a.slipdate < p_strdate THEN
                                                     SUBSTR (a.slipdate, 0, 7)
                                                  WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN
                                                     a.slipdate
                                                  ELSE
                                                     SUBSTR (a.slipdate, 0, 7) || '-99'
                                               END,
                                               b.grp,
                                               CASE
                                                  WHEN b.grp = 0 AND a.slipdate < p_strdate THEN '이월'
                                                  WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.slipnum
                                                  WHEN b.grp = 1 THEN '월계'
                                                  ELSE '누계'
                                               END,
                                               CASE
                                                  WHEN b.grp = 0 AND a.slipdate < p_strdate THEN 0
                                                  WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.slipinseq
                                                  WHEN b.grp = 1 THEN 8888
                                                  ELSE 9999
                                               END
                                        ) ord
            FROM (SELECT NULL slipinno,
                         0 slipinseq,
                         NULL slipindate,
                         NULL slipinnum,
                         NULL slipno,
                         slipym || '-00' slipdate,
                         NULL slipnum,
                         acccode,
                         NULL remark,
                         NVL (bsdebamt, 0) debamt,
                         NVL (bscreamt, 0) creamt
                    FROM ACORDSMM
                   WHERE     compcode = p_compcode
                         AND plantcode LIKE p_plantcode
                         AND slipym = SUBSTR (p_strdate, 0, 7)
                         AND closediv IN ('10', '20')
                         AND (       p_acccode IS NULL
                                 AND acccode IN (p_acccode1, p_acccode2)
                              OR p_acccode IS NOT NULL AND acccode = p_acccode)
                         AND mngclucode = 'S010'
                         AND mngcluval = p_custcode
                         AND trim(mngcluval) IS NOT NULL
                  UNION ALL
                  SELECT c.slipinno,
                         NVL (D.slipinseq, a.slipinseq),
                         c.slipindate,
                         c.slipinnum,
                         c.slipno,
                         c.slipdate,
                         c.slipnum,
                         a.acccode,
                         NVL ( D.remark1 || CASE WHEN D.acccode LIKE p_acccode3 || '%' THEN ' 부가세' ELSE '' END, a.remark1),
                         a.debamt,
                         NVL (D.debamt, a.creamt)
                    FROM ACORDD a
                         JOIN
                         ACORDS b
                            ON     a.compcode = b.compcode
                               AND a.slipinno = b.slipinno
                               AND a.slipinseq = b.slipinseq
                               AND b.mngclucode = 'S010'
                               AND b.mngcluval = p_custcode
                               AND trim(b.mngcluval) IS NOT NULL
                         JOIN
                         ACORDM c
                            ON     a.compcode = c.compcode
                               AND a.slipinno = c.slipinno
                               AND c.slipdiv <> 'F'
                         LEFT JOIN
                         ACORDD D
                            ON     a.compcode = D.compcode
                               AND a.slipinno = D.slipinno
                               AND a.slipinseq <> D.slipinseq
                               AND a.creamt <> 0
                         LEFT JOIN
                         ACORDS E
                            ON     D.compcode = E.compcode
                               AND D.slipinno = E.slipinno
                               AND D.slipinseq = E.slipinseq
                               AND E.mngclucode = 'S010'
                               AND b.mngcluval = E.mngcluval
                   WHERE     a.compcode = p_compcode
                         AND a.plantcode LIKE p_plantcode
                         AND (       p_acccode IS NULL
                                 AND a.acccode IN (p_acccode1, p_acccode2)
                              OR p_acccode IS NOT NULL AND a.acccode = p_acccode)
                         AND a.slipdate BETWEEN SUBSTR (p_strdate, 0, 8) || '01'
                                            AND p_enddate) a
                 JOIN (SELECT 0 grp FROM DUAL
                       UNION
                       SELECT 1 FROM DUAL
                       UNION
                       SELECT 2 FROM DUAL) b
                    ON b.grp = 0 OR a.slipdate >= p_strdate
                 JOIN ACACCM c ON a.acccode = c.acccode
        GROUP BY b.grp,
                 CASE
                    WHEN b.grp = 0 AND a.slipdate < p_strdate THEN
                       SUBSTR (a.slipdate, 0, 7)
                    WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN
                       a.slipdate
                    ELSE
                       SUBSTR (a.slipdate, 0, 7) || '-99'
                 END,
                 CASE
                    WHEN b.grp = 0 AND a.slipdate < p_strdate THEN '이월'
                    WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.slipnum
                    WHEN b.grp = 1 THEN '월계'
                    ELSE '누계'
                 END,
                 CASE
                    WHEN b.grp = 0 AND a.slipdate < p_strdate THEN 0
                    WHEN b.grp = 0 AND a.slipdate >= p_strdate THEN a.slipinseq
                    WHEN b.grp = 1 THEN 8888
                    ELSE 9999
                 END;

        MERGE INTO VGT.TT_ACACC0184R_DUAL a
        USING	   (SELECT CASE WHEN a.grp = 2 THEN b.debamt ELSE a.debamt END debamt,
                           CASE WHEN a.grp = 2 THEN b.creamt ELSE a.creamt END creamt,
                           CASE WHEN a.grp <> 1 THEN b.fnamt END fnamt,
                           a.ord
                    FROM   VGT.TT_ACACC0184R_DUAL a
                           JOIN (SELECT   a.ord,
                                          SUM(b.debamt) debamt,
                                          SUM(b.creamt) creamt,
                                          SUM(b.fnamt) fnamt
                                 FROM	  VGT.TT_ACACC0184R_DUAL a
                                          JOIN VGT.TT_ACACC0184R_DUAL b
                                              ON a.ord >= b.ord
                                                 AND b.grp = 0
                                 GROUP BY a.ord) b
                               ON a.ord = b.ord) src
        ON		   (a.ord = src.ord)
        WHEN MATCHED THEN
            UPDATE SET
                a.debamt = src.debamt,
                a.creamt = src.creamt,
                a.fnamt = src.fnamt;

      OPEN  IO_CURSOR FOR
         SELECT a.slipinno ,
                a.slipinseq ,
                a.slipindate ,
                a.slipinnum ,
                a.slipno ,
                a.slipdate,
                a.slipnum ,
                a.remark ,
                a.debamt ,
                a.creamt ,
                a.fnamt ,
                '구매원장' || NVL('(' || b.accname || ')', '') title1  ,
                c.value2 title2  ,
                '거래처 : ' || D.custname || '(' || D.custcode || '), 기간 : ' || p_strdate || ' ~ ' || p_enddate title3
           FROM VGT.TT_ACACC0184R_DUAL a
                  LEFT JOIN ACACCM b   ON b.acccode = p_acccode
                  LEFT JOIN SYSPARAMETERMANAGE c   ON c.parametercode = 'acrpttitle'
                  LEFT JOIN CMCUSTM D   ON D.custcode = p_custcode
           ORDER BY a.ord;



    END IF;

    IF (IO_CURSOR IS NULL) THEN
        OPEN IO_CURSOR FOR SELECT CODE FROM VGT.TT_TABEL_EMPTY;
    END IF;
END;
/
