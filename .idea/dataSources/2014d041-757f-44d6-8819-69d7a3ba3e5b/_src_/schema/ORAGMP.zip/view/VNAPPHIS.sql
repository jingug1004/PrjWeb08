CREATE VIEW VNAPPHIS AS SELECT a.plantcode
          , -- isnull(a.plantcode,'') as plantcode
           a.appdate
          , -- nullif(a.appdate,'') as appdate
           a.cstno
          , -- isnull(a.cstno,'') as cstno
           NVL(a.accountdiv, ' ') accountdiv
          ,NVL(D.divname, ' ') accountdivnm
          ,a.empcode
          , -- isnull(a.empcode,'') as empcode
           NVL(b.empname, ' ') empname
          ,NVL(b.positiondiv, ' ') positiondiv
          ,NVL(c.divname, ' ') jikwi
          ,NVL(a.appdiv, ' ') appdiv
          ,NVL(e.divname, ' ') appdivnm
          ,NVL(a.appseq, 0) appseq
          ,NVL(a.resdiv, ' ') resdiv
          ,NVL(f.divname, ' ') resdivnm
      FROM SLAPPHISM a
           LEFT JOIN vnEMP b ON a.empcode = b.empcode
           LEFT JOIN (SELECT *
                        FROM CMCOMMONM
                       WHERE cmmcode = 'PS29'
                             AND usediv = 'Y') c
               ON b.positiondiv = c.divcode
           LEFT JOIN (SELECT *
                        FROM CMCOMMONM
                       WHERE cmmcode = 'SL80'
                             AND usediv = 'Y') D
               ON a.accountdiv = D.divcode
           LEFT JOIN (SELECT *
                        FROM CMCOMMONM
                       WHERE cmmcode = 'SL83'
                             AND usediv = 'Y') e
               ON a.appdiv = e.divcode
           LEFT JOIN (SELECT *
                        FROM CMCOMMONM
                       WHERE cmmcode = 'SL84'
                             AND usediv = 'Y') f
               ON a.resdiv = f.divcode
/
