CREATE VIEW VNRESULTS AS SELECT a.plantcode,
          a.yearmonth,
          a.custcode,
          NVL (b.custname, '') custname,
          CASE
             WHEN NVL (b.addr1, '') IS NULL AND NVL (b.addr2, '') IS NULL
             THEN
                ''
             WHEN NVL (b.addr1, '') IS NOT NULL AND NVL (b.addr2, '') IS NULL
             THEN
                NVL (b.addr1, '')
             WHEN NVL (b.addr1, '') IS NULL AND NVL (b.addr2, '') IS NOT NULL
             THEN
                NVL (b.addr2, '')
             WHEN NVL (b.addr1, '') IS NOT NULL
                  AND NVL (b.addr2, '') IS NOT NULL
             THEN
                NVL (b.addr1, '') || ' ' || NVL (b.addr2, '')
          END
             AS addr,
          NVL (b.ceoname, '') ceoname,
          NVL (b.telno, '') telno,
          NVL (b.faxno, '') faxno,
          NVL (b.businessno, '') businessno,
          a.ecustcode,
          NVL (E.custname, '') ecustname,
          NVL (a.orderdiv, '') orderdiv,
          NVL (c.topdeptcode, '') topdeptcode,
          NVL (c.topdeptname, '') topdeptname,
          NVL (c.predeptcode, '') predeptcode,
          NVL (c.predeptname, '') predeptname,
          a.deptcode,
          NVL (c.deptname, '') deptname,
          NVL (c.findname, '') findname,
          a.empcode,
          NVL (D.empname, '') empname,
          NVL (D.positiondiv, '') positiondiv,
          NVL (j.divname, '') jikwi,
          NVL (a.utdiv, '') utdiv,
          NVL (h.divname, '') utdivnm,
          NVL (f.topdeptcode, '') etopdeptcode,
          NVL (f.topdeptname, '') etopdeptname,
          NVL (f.predeptcode, '') epredeptcode,
          NVL (f.predeptname, '') epredeptname,
          a.edeptcode,
          NVL (f.deptname, '') edeptname,
          NVL (f.findname, '') efindname,
          a.eempcode,
          NVL (G.empname, '') eempname,
          NVL (G.positiondiv, '') epositiondiv,
          NVL (K.divname, '') ejikwi,
          NVL (a.eutdiv, '') eutdiv,
          NVL (i.divname, '') eutdivnm,
          NVL (a.drugamt, 0) drugamt,
          NVL (a.salamt, 0) salamt,
          NVL (a.salvat, 0) salvat,
          NVL (a.totamt, 0) totamt,
          NVL (a.returnamt, 0) returnamt,
          NVL (a.returnvat, 0) returnvat,
          NVL (a.returntotamt, 0) returntotamt,
          NVL (a.cashcol, 0) cashcol,
          NVL (a.cardcol, 0) cardcol,
          NVL (a.billcol, 0) billcol,
          NVL (a.etccol, 0) etccol,
          NVL (a.totcol, 0) totcol,
          NVL (a.pendbillcol, 0) pendbillcol,
          NVL (a.pendbillcolj, 0) pendbillcolj,
          NVL (a.pendbillcolt, 0) pendbillcolt,
          NVL (a.balance, 0) balance,
          NVL (a.turncnt, 0) turncnt,
          NVL (a.turndccnt, 0) turndccnt,
          NVL (a.colcnt, 0) colcnt,
          NVL (a.salcnt, 0) salcnt,
          NVL (a.returncnt, 0) returncnt,
          NVL (b.areadiv, '') areadiv,
          NVL (M.divname, '') areadivnm,
          NVL (D.retiredt, '') retiredt,
          NVL (G.retiredt, '') eretiredt,
          NVL (c.deptgroup, '') deptgroup,
          NVL (f.deptgroup, '') edeptgroup,
          a.balanceetc,
          a.balanceotc,
          NVL (b.stopdate, '') stopdate,
          NVL (b.opendate, '') opendate,
          SUBSTR (b.opendate, 0, 7) openyymm,
          NVL (b.ascustcheck, 'N') ascustcheck,
          NVL (b.sagodiv, '') sagodiv,                          --사고처구분(거래처상태)
          NVL (N.divname, '') sagodivnm,                              --거래처상태명
          NVL (E.stopdate, '') estopdate,
          NVL (E.opendate, '') eopendate,
          NVL (E.ascustcheck, 'N') eascustcheck,
          NVL (b.custdiv, '') custdiv,
          NVL (E.custdiv, '') ecustdiv,
          c.seqtopdeptcode,
          c.seqpredeptcode,
          c.seqdeptcode,
          f.seqtopdeptcode eseqtopdeptcode,
          f.seqpredeptcode eseqpredeptcode,
          f.seqdeptcode eseqdeptcode,
          E.sagodiv esagodiv,
          G.partdiv partdiv
     FROM SLRESULTM a
          JOIN CMCUSTM b
             ON a.custcode = b.custcode
          JOIN vnDEPT c
             ON a.deptcode = c.deptcode
          JOIN CMEMPM D
             ON a.empcode = D.empcode
          JOIN CMCUSTM E
             ON a.ecustcode = E.custcode
          JOIN vnDEPT f
             ON a.edeptcode = f.deptcode
          JOIN CMEMPM G
             ON a.eempcode = G.empcode
          LEFT JOIN CMCOMMONM h
             ON a.utdiv = h.divcode AND h.cmmcode = 'CM15'
          LEFT JOIN CMCOMMONM i
             ON a.eutdiv = i.divcode AND i.cmmcode = 'CM15'
          LEFT JOIN CMCOMMONM j
             ON D.positiondiv = j.divcode AND j.cmmcode = 'PS29'
          LEFT JOIN CMCOMMONM K
             ON G.positiondiv = K.divcode AND K.cmmcode = 'PS29'
          LEFT JOIN CMCOMMONM M
             ON b.areadiv = M.divcode AND M.cmmcode = 'CM03'
          LEFT JOIN CMCOMMONM N
             ON b.sagodiv = N.divcode AND N.cmmcode = 'CM20'    --사고구분(거래처상태);
/
