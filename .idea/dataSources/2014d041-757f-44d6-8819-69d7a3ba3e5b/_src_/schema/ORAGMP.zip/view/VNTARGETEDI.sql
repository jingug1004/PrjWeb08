CREATE VIEW VNTARGETEDI AS SELECT	 NVL(a.plantcode, ' ') plantcode,
			 NVL(a.yearmonth, ' ') yearmonth,
			 NVL(a.deptcode, ' ') deptcode,
			 NVL(b.deptname, ' ') deptname,
			 NVL(b.predeptcode, ' ') predeptcode,
			 NVL(b.predeptname, ' ') predeptname,
			 NVL(b.topdeptcode, ' ') topdeptcode,
			 NVL(b.topdeptname, ' ') topdeptname,
			 NVL(b.findname, ' ') findname,
			 NVL(a.empcode, ' ') empcode,
			 NVL(c.empname, ' ') empname,
			 NVL(c.positiondiv, ' ') positiondiv,
			 NVL(e.divname, ' ') jikwi,
			 NVL(a.targetamt, 0) targetamt,
			 NVL(c.retiredt, ' ') retiredt,
			 NVL(b.deptgroup, ' ') deptgroup
	FROM	 SLTARGETEDIM a
			 LEFT JOIN vnDEPT b ON a.deptcode = b.deptcode
			 LEFT JOIN CMEMPM c ON a.empcode = c.empcode
			 LEFT JOIN CMCOMMONM e
				 ON c.positiondiv = e.divcode
					AND e.cmmcode = 'PS29'
	ORDER BY plantcode, yearmonth, deptcode, empcode
/
