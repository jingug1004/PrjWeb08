CREATE VIEW VNEMPSALESCHONGPAN AS SELECT NVL(b.plantcode, U'') plantcode,
		   NVL(a.yymm, ' ') yymm, --사업장 코드
		   NVL(a.orderdate, U'') orderdate, --주문일자
		   NVL(a.orderseq, U'') orderseq,
		   NVL(a.orderno, U'') orderno, --주문구분
		   NVL(a.saldiv, U'') saldiv, --판매구분
		   CASE
			   WHEN (NVL(a.saldiv, ' ') = 'CC')
					AND (NVL(a.tasooyn, 'N') = 'N')
			   THEN
				   NVL(SL18.divname, ' ')
			   WHEN (NVL(a.saldiv, ' ') = 'CC')
					AND (NVL(a.tasooyn, 'N') = 'Y')
			   THEN
				   NVL(SL18.divname, ' ') || '(타)'
			   ELSE
				   NVL(D.divname, ' ')
		   END
			   saldivnm,
		   NVL(a.tasooyn, 'N') tasooyn,
		   NVL(a.datadiv, U'') datadiv,
		   NVL(E.divname, U'') datadivnm,
		   NVL(a.coldiv, U'') coldiv,
		   NVL(a.orderdiv, U'') orderdiv,
		   NVL(a.outputdiv, U'') outputdiv,
		   NVL(f.divname, U'') outputdivnm,
		   NVL(a.transferdiv, U'') transferdiv,
		   NVL(G.divname, U'') transferdivnm,
		   NVL(b.telno, ' ') telno,
		   NVL(b.faxno, ' ') faxno,
		   NVL(b.ceoname, U'') ceoname,
		   NVL(b.businessno, U'') businessno,
		   NVL(b.POST, U'') POST,
		   NVL(b.addr1, U'') addr1,
		   NVL(b.addr2, U'') addr2,
		   NVL(b.addr1, U'') || ' ' || NVL(b.addr2, U'') addr,
		   CASE WHEN b.custdiv = '8' THEN NVL(b.custmajorcode, ' ') ELSE NVL(a.custcode, ' ') END custcode,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.custname, ' ') ELSE NVL(b.custname, ' ') END custname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.utdiv, ' ') ELSE NVL(a.utdiv, ' ') END utdiv,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.utdivnm, ' ') ELSE NVL(o.divname, ' ') END utdivnm,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.findname, ' ') ELSE NVL(h.findname, ' ') END findname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.topdeptcode, ' ') ELSE NVL(h.topdeptcode, ' ') END topdeptcode,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.topdeptname, ' ') ELSE NVL(h.topdeptname, ' ') END topdeptname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.predeptcode, ' ') ELSE NVL(h.predeptcode, ' ') END predeptcode,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.predeptname, ' ') ELSE NVL(h.predeptname, ' ') END predeptname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.deptcode, ' ') ELSE NVL(a.deptcode, ' ') END deptcode,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.deptname, ' ') ELSE NVL(h.deptname, ' ') END deptname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.empcode, ' ') ELSE NVL(a.empcode, ' ') END empcode,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.empname, ' ') ELSE NVL(i.empname, ' ') END empname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.positiondiv, ' ') ELSE NVL(i.positiondiv, ' ') END positiondiv,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.jikwi, ' ') ELSE NVL(U.divname, ' ') END jikwi,
		   CASE WHEN b.custdiv = '8' THEN NVL(b.custmajorcode, ' ') ELSE NVL(a.ecustcode, ' ') END ecustcode,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.custname, ' ') ELSE NVL(c.custname, ' ') END ecustname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.utdiv, ' ') ELSE NVL(a.eutdiv, ' ') END eutdiv,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.utdivnm, ' ') ELSE NVL(P.divname, ' ') END eutdivnm,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.findname, ' ') ELSE NVL(j.findname, ' ') END efindname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.topdeptcode, ' ') ELSE NVL(j.topdeptcode, ' ') END etopdeptcode,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.topdeptname, ' ') ELSE NVL(j.topdeptname, ' ') END etopdeptname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.predeptcode, ' ') ELSE NVL(j.predeptcode, ' ') END epredeptcode,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.predeptname, ' ') ELSE NVL(j.predeptname, ' ') END epredeptname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.deptcode, ' ') ELSE NVL(a.edeptcode, ' ') END edeptcode,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.deptname, ' ') ELSE NVL(j.deptname, ' ') END edeptname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.empcode, ' ') ELSE NVL(a.eempcode, ' ') END eempcode,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.empname, ' ') ELSE NVL(K.empname, ' ') END eempname,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.positiondiv, ' ') ELSE NVL(K.positiondiv, ' ') END epositiondiv,
		   CASE WHEN b.custdiv = '8' THEN NVL(bb.jikwi, ' ') ELSE NVL(v.divname, ' ') END ejikwi,
		   NVL(a.bnorderno, U'') bnorderno,
		   NVL(a.taxdate, U'') taxdate,
		   NVL(a.tradedate, U'') tradedate,
		   NVL(a.appdate, U'') appdate,
		   NVL(a.statediv, U'') statediv,
		   NVL(l.divname, U'') statedivnm,
		   NVL(a.remark, U'') remark,
		   NVL(a.seq, 0) seq,
		   NVL(a.itemcode, U'') itemcode,
		   NVL(M.itemname, U'') itemname,
		   NVL(M.itemunit, ' ') unit,
		   NVL(M.drugdiv, U'') drugdiv,
		   NVL(W.divname, ' ') drugdivnm,
		   NVL(M.medimaxprc, ' ') medimaxprc,
		   NVL(M.mitemcode, ' ') mitemcode,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salqty, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salqty, 0) ELSE 0 END salqty,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.givqty, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.givqty, 0) ELSE 0 END givqty,
		   NVL(a.drugprc, 0) drugprc,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.drugamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.drugamt, 0) ELSE 0 END drugamt,
		   NVL(a.makingcost, 0) makingcost,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.makingamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.makingamt, 0) ELSE 0 END makingamt,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.makinggivamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.makinggivamt, 0) ELSE 0 END makinggivamt,
		   NVL(a.salprc, 0) salprc,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salamt, 0) ELSE 0 END salamt,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salvat, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salvat, 0) ELSE 0 END salvat,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.totamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.totamt, 0) ELSE 0 END totamt,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.befamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.befamt, 0) ELSE 0 END befamt,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.aftamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.aftamt, 0) ELSE 0 END aftamt,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.incamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.incamt, 0) ELSE 0 END incamt,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.totdiscount, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.totdiscount, 0) ELSE 0 END totdiscount,
		   NVL(a.givrate, 0) givrate,
		   NVL(a.befrate, 0) befrate,
		   NVL(a.aftrate, 0) aftrate,
		   NVL(a.incrate, 0) incrate,
		   NVL(a.salprc1, 0) salprc1,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salamt1, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salamt1, 0) ELSE 0 END salamt1,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salvat1, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salvat1, 0) ELSE 0 END salvat1,
		   CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.totamt1, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.totamt1, 0) ELSE 0 END totamt1,
		   CASE
			   WHEN a.saldiv = 'CC'
					AND a.coldiv IN ('01')
			   THEN
				   NVL(a.colamt, 0)
			   ELSE
				   0
		   END
			   cashcol, --현금수금
		   CASE
			   WHEN a.saldiv = 'CC'
					AND a.coldiv IN ('02')
			   THEN
				   NVL(a.colamt, 0)
			   ELSE
				   0
		   END
			   changecol, --채권상계
		   CASE
			   WHEN a.saldiv = 'CC'
					AND SUBSTR(a.coldiv, 0, 1) = '1'
			   THEN
				   NVL(a.colamt, 0)
			   ELSE
				   0
		   END
			   bankcol, --은행입금
		   CASE
			   WHEN a.saldiv = 'CC'
					AND SUBSTR(a.coldiv, 0, 1) = '2'
			   THEN
				   NVL(a.colamt, 0)
			   ELSE
				   0
		   END
			   cardcol, --카드수금
		   CASE
			   WHEN a.saldiv = 'CC'
					AND SUBSTR(a.coldiv, 0, 1) = '3'
			   THEN
				   NVL(a.colamt, 0)
			   ELSE
				   0
		   END
			   billcol, --어음수금
		   CASE
			   WHEN a.saldiv = 'CC'
					AND a.coldiv > '39'
			   THEN
				   NVL(a.colamt, 0)
			   ELSE
				   0
		   END
			   etccol, --기타수금
		   NVL(a.colamt, 0) colamt,
		   NVL(a.custprtyn, U'') custprtyn,
		   NVL(a.outputqty, 0) outputqty,
		   NVL(a.recalldiv, U'') recalldiv,
		   NVL(x.divname, ' ') recalldivnm,
		   NVL(a.absyn, U'') absyn,
		   NVL(a.pieceyn, U'') pieceyn,
		   NVL(a.enuriyn, U'') eruriyn,
		   CASE
			   WHEN a.coldiv LIKE '3%'
			   THEN
				   NVL(a.paybank, ' ' --지금은행
									 )
			   WHEN SUBSTR(a.coldiv, 0, 1) = '1'
			   THEN
				   NVL(T.bankname, U'') || ' ' || NVL(T.branchname, U'' --계좌은행
																	   )
			   WHEN (SUBSTR(a.coldiv, 0, 1) = '2')
					AND (NVL(a.divmonth, 0) = 0)
			   THEN
				   NVL(AC17.divname, U'' --카드사
										)
			   WHEN (SUBSTR(a.coldiv, 0, 1) = '2')
					AND (NVL(a.divmonth, 0) > 0)
			   THEN
				   NVL(AC17.divname, U'') || ' ' || TO_CHAR(divmonth) || '개월' --카드사
			   ELSE
				   ' '
		   END
			   gubun,
		   NVL(a.billno, U'') billno,
		   NVL(a.accountno, U'') accountno,
		   CASE WHEN a.coldiv LIKE '3%' THEN NVL(a.issdate, U'') ELSE ' ' END issdate,
		   CASE WHEN a.coldiv LIKE '3%' THEN NVL(a.expdate, U'') ELSE ' ' END expdate,
		   CASE WHEN a.coldiv LIKE '3%' THEN NVL(a.discntdate, U'') ELSE ' ' END discntdate,
		   NVL(a.paybank, U'') paybank,
		   NVL(a.cardcomp, U'') cardcomp,
		   NVL(AC17.divname, U'') cardcompnm,
		   NVL(a.cardno, U'') cardno,
		   NVL(a.cardokno, U'') cardokno,
		   NVL(T.bankname, U'') || ' ' || NVL(T.branchname, U'') accountbanknm,
		   NVL(a.pda, ' ') pda,
		   NVL(b.areadiv, ' ') areadiv,
		   NVL(uu.divname, ' ') areadivnm,
       NVL(i.retiredt, ' ') retiredt,
       NVL(K.retiredt, ' ') eretiredt,
       NVL(h.deptgroup, ' ') deptgroup,
       NVL(j.deptgroup, ' ') edeptgroup,
       NVL(b.custmajorcode, ' ') custmajorcode,
       NVL(b.opendate, ' ') opendate,
       NVL(b.stopdate, ' ') stopdate,
       h.seqtopdeptcode,
       h.seqpredeptcode,
       h.seqdeptcode,
       j.seqtopdeptcode eseqtopdetpcode,
       j.seqpredeptcode eseqpredeptcode,
       j.seqdeptcode eseqdeptcode,
       a.sagock sagodiv
  FROM   vnSalesEnd a
       JOIN CMCUSTM b ON a.custcode = b.custcode
       JOIN CMCUSTM c ON a.ecustcode = c.custcode
       JOIN vnCUST bb ON b.custmajorcode = bb.custcode
       LEFT JOIN CMCOMMONM D
         ON a.saldiv = D.divcode
          AND D.cmmcode = 'SL10'
       LEFT JOIN CMCOMMONM E
         ON a.datadiv = E.divcode
          AND E.cmmcode = 'SL11'
       LEFT JOIN CMCOMMONM f
         ON a.outputdiv = f.divcode
          AND f.cmmcode = 'SL12'
       LEFT JOIN CMCOMMONM G
         ON a.transferdiv = G.divcode
          AND G.cmmcode = 'SL14'
       JOIN vnDEPT h ON b.deptcode = h.deptcode
       JOIN CMEMPM i ON b.empcode = i.empcode
       JOIN vnDEPT j ON c.deptcode = j.deptcode
       JOIN CMEMPM K ON c.empcode = K.empcode
       LEFT JOIN CMCOMMONM l
         ON a.statediv = l.divcode
          AND l.cmmcode = 'SL17'
       LEFT JOIN CMITEMM M ON a.itemcode = M.itemcode
       LEFT JOIN CMCOMMONM N
         ON M.unit = N.divcode
          AND N.cmmcode = 'CM38'
       LEFT JOIN CMCOMMONM o
         ON a.utdiv = o.divcode
          AND o.cmmcode = 'CM15'
       LEFT JOIN CMCOMMONM P
         ON a.eutdiv = P.divcode
          AND P.cmmcode = 'CM15'
       LEFT JOIN CMCOMMONM SL18
         ON a.coldiv = SL18.divcode
          AND SL18.cmmcode = 'SL18'
       LEFT JOIN CMCOMMONM AC17
         ON a.cardcomp = AC17.divcode
          AND AC17.cmmcode = 'AC17'
       LEFT JOIN CMACCOUNTM S ON a.accountno = S.accountno
       LEFT JOIN CMBANKM T ON S.bankcode = T.bankcode
       LEFT JOIN CMCOMMONM U
         ON i.positiondiv = U.divcode
          AND U.cmmcode = 'PS29'
       LEFT JOIN CMCOMMONM v
         ON K.positiondiv = v.divcode
          AND v.cmmcode = 'PS29'
       LEFT JOIN CMCOMMONM W
         ON M.drugdiv = W.divcode
          AND W.cmmcode = 'CM23'
       LEFT JOIN CMCOMMONM x
         ON a.recalldiv = x.divcode
          AND x.cmmcode = 'SL16'
       LEFT JOIN CMCOMMONM uu
         ON b.areadiv = uu.divcode
          AND uu.cmmcode = 'CM03'
/
