CREATE VIEW VNORDERMASTER AS SELECT a.plantcode, -- ISNULL(a.plantcode, N'') AS plantcode,
		   a.orderdate, -- ISNULL(a.orderdate, N'') AS orderdate,
		   a.orderseq, -- ISNULL(a.orderseq, N'') AS orderseq,
		   a.orderno, -- ISNULL(a.orderno, N'') AS orderno,
		   NVL(a.saldiv, u'') saldiv,
		   NVL(a.yymm, u'') yymm,
		   NVL(D.divname, ' ') saldivnm,
		   NVL(a.datadiv, u'') datadiv,
		   NVL(e.divname, u'') datadivnm,
		   NVL(a.orderdiv, u'') orderdiv,
		   NVL(a.outputdiv, u'') outputdiv,
		   NVL(S.divname, u'') outputdivnm,
		   NVL(a.transferdiv, u'') transferdiv,
		   NVL(t.divname, u'') transfernm,
		   a.custcode, -- ISNULL(a.custcode, N'') AS custcode,
		   NVL(b.custname, u'') custname,
		   NVL(b.addr1, u'') addr1,
		   NVL(b.addr2, u'') addr2,
		   NVL(b.addr1, u'') || ' ' || NVL(b.addr2, u'') addr,
		   NVL(b.telno, u'') telno,
		   NVL(b.POST, u'') POST,
		   NVL(b.ceoname, ' ') ceoname,
		   NVL(b.custcondition, ' ') custcondition,
		   NVL(b.custitem, ' ') custitem,
		   NVL(b.businessno, ' ') businessno,
		   a.deptcode, -- ISNULL(a.deptcode, N'') AS deptcode,
		   NVL(h.predeptcode, u'') predeptcode,
		   NVL(h.predeptname, u'') predeptname,
		   NVL(h.topdeptcode, u'') topdeptcode,
		   NVL(h.topdeptname, u'') topdeptname,
		   NVL(h.topdeptname, ' ') || NVL(h.predeptname, ' ') || NVL(h.deptname, ' ') findname,
		   NVL(h.deptname, u'') deptname,
		   a.empcode, -- ISNULL(a.empcode, N'') AS empcode,
		   NVL(i.positiondiv, u'') positiondiv,
		   NVL(Q.divname, u'') jikwi,
		   NVL(i.empname, u'') empname,
		   a.ecustcode, -- ISNULL(a.ecustcode, N'') AS ecustcode,
		   NVL(c.custname, u'') ecustname,
		   NVL(c.addr1, ' ') eaddr1,
		   NVL(c.addr2, ' ') eaddr2,
		   NVL(c.addr1, u'') || ' ' || NVL(c.addr2, u'') eaddr,
		   NVL(c.telno, u'') etelno,
		   NVL(c.POST, u'') epost,
		   a.edeptcode, -- ISNULL(a.edeptcode, N'') AS edeptcode,
		   NVL(j.predeptcode, u'') epredeptcode,
		   NVL(j.predeptname, u'') epredeptname,
		   NVL(j.topdeptcode, u'') etopdeptcode,
		   NVL(h.topdeptname, u'') etopdeptname,
		   NVL(j.deptname, u'') edeptname,
		   NVL(j.topdeptname, ' ') || NVL(j.predeptname, ' ') || NVL(j.deptname, ' ') efindname,
		   a.eempcode, -- ISNULL(a.eempcode, N'') AS eempcode,
		   NVL(k.positiondiv, u'') epositiondiv,
		   NVL(r.divname, u'') ejikwi,
		   NVL(k.empname, u'') eempname,
		   NVL(a.utdiv, u'') utdiv,
		   NVL(o.divname, u'') utdivnm,
		   NVL(a.eutdiv, u'') eutdiv,
		   NVL(p.divname, u'') eutdivnm,
		   NVL(a.remark, u'') remark,
		   NVL(a.taxdate, ' ') taxdate,
		   NVL(a.tradedate, ' ') tradedate,
		   NVL(a.statediv, ' ') statediv,
		   NVL(u.divname, ' ') statedivnm,
		   a.appdate, -- isnull(a.appdate,'') as appdate,
		   NVL(a.fixdate, ' ') fixdate,
		   NVL(a.fixseq, ' ') fixseq,
		   NVL(a.pda, ' ') pda,
		   h.seqtopdeptcode,
		   h.seqpredeptcode,
		   h.seqdeptcode,
		   j.seqtopdeptcode eseqtopdetpcode,
		   j.seqpredeptcode eseqpredeptcode,
		   j.seqdeptcode eseqdeptcode,
		   b.custmajorcode,
           a.warehouse,
           a.bnorderno
	FROM   SLORDM a
		   JOIN CMCUSTM b ON a.custcode = b.custcode
		   JOIN CMCUSTM c ON a.ecustcode = c.custcode
		   JOIN vnDEPT h ON a.deptcode = h.deptcode
		   JOIN CMEMPM i ON a.empcode = i.empcode
		   JOIN vnDEPT j ON a.edeptcode = j.deptcode
		   JOIN CMEMPM k ON a.eempcode = k.empcode
		   JOIN (SELECT divcode,
						divname
				 FROM	CMCOMMONM
				 WHERE	cmmcode = 'SL10') D
			   ON a.saldiv = D.divcode
		   JOIN (SELECT divcode,
						divname
				 FROM	CMCOMMONM
				 WHERE	cmmcode = 'SL11') e
			   ON a.datadiv = e.divcode
		   LEFT JOIN (SELECT divcode,
							 divname
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'sl17') u
			   ON a.statediv = u.divcode
		   LEFT JOIN (SELECT divcode,
							 divname
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'CM15') o
			   ON a.utdiv = o.divcode
		   LEFT JOIN (SELECT divcode,
							 divname
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'CM15') p
			   ON a.eutdiv = p.divcode
		   LEFT JOIN (SELECT divcode,
							 divname
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'PS29') Q
			   ON i.positiondiv = Q.divcode
		   LEFT JOIN (SELECT divcode,
							 divname
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'PS29') r
			   ON k.positiondiv = r.divcode
		   LEFT JOIN (SELECT divcode,
							 divname
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'SL12') S
			   ON a.outputdiv = S.divcode
		   LEFT JOIN (SELECT divcode,
							 divname
					  FROM	 CMCOMMONM
					  WHERE  cmmcode = 'SL14') t
			   ON a.transferdiv = t.divcode
/
