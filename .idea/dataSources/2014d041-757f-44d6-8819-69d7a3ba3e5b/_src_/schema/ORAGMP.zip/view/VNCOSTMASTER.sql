CREATE VIEW VNCOSTMASTER AS SELECT a.costcode costcode, --비용코드
		   a.costname costname, --비용명
		   a.costgroup costgroup, --비용그룹구분코드
		   b.divname costgroupname, --비용그룹구분
		   a.costdivisioncode costdivisioncode, --분배기준코드
		   c.divname costdivisionname, --분배기준
		   a.dracccode dracccode, --차변계정
		   a.cracccode cracccode, --대변계정
		   a.chapter chapter, --정산서구분
		   D.divname chaptername, --정산서구분
		   a.billingtype billingtype --계산서그룹
	  FROM PDCOSTM a
       JOIN CommonMaster b
         ON b.cmmcode = 'MPM73'
          AND b.divcode = a.costgroup
       JOIN CommonMaster c
         ON c.cmmcode = 'MPM26'
          AND c.divcode = a.costdivisioncode
       LEFT JOIN CommonMaster D
         ON D.cmmcode = 'ACC09'
          AND D.divcode = a.chapter
/
