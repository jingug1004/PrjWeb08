CREATE VIEW VNPSEMPORDERM2 AS SELECT NVL(a.plantcode, ' ') plantcode, --사업장
		   NVL(a.orderdate, ' ') orderdate, --발령일자
		   NVL(a.seq, 0) seq,
		   NVL(b.topdeptcode, ' ') topdeptcode, --현부서
		   NVL(b.topdeptname, ' ') topdeptname, --현부서명
		   NVL(b.predeptcode, ' ') predeptcode, --현지점
		   NVL(b.predeptname, ' ') predeptname, --현지점명
		   NVL(b.deptcode, ' ') deptcode, --현팀
		   NVL(b.deptname, ' ') deptname, --현팀명
		   NVL(b.workdiv, ' ') workdiv, --현근무지
		   NVL(b.findname, ' ') findname, --발령부서조회용
		   NVL(a.empcode, ' ') empcode, --사원코드
		   NVL(b.empname, ' ') empname, --사원
		   NVL(a.orddiv, ' ') orddiv, --발령구분
		   NVL(e.divname, ' ') orddivnm, --발령구분명
		   NVL(a.ordsdt, ' ') ordsdt, --발령기간시작
		   NVL(a.ordedt, ' ') ordedt, --발령기간종료
		   NVL(a.plantcodeold, ' ') plantcodeold, --구사업장
		   NVL(Q.plantname, ' ') plantcodeoldnm, --구사업장명
		   NVL(a.deptcodeold, ' ') deptcodeold, --구부서
		   NVL(c.topdeptcode, ' ') topdeptcodeold, --구부서
		   NVL(c.topdeptname, ' ') topdeptnameold, --구부서명
		   NVL(c.predeptcode, ' ') predeptcodeold, --구지점
		   NVL(c.predeptname, ' ') predeptnameold, --구지점명
		   NVL(c.deptname, ' ') deptnameold, --구팀명
		   NVL(c.findname, ' ') findnameold, --구부서조회용
		   NVL(a.workdivold, ' ') workdivold, --구근무지
		   NVL(f.divname, ' ') workdivoldnm, --구근무지명
		   NVL(a.orderdateold, ' ') orderdateold, --구발령일자
		   NVL(a.ordsdtold, ' ') ordsdtold, --구발령기간시작
		   NVL(a.ordedtold, ' ') ordedtold, --구발령기간종료
		   NVL(a.positiondivold, ' ') positiondivold, --구직위
		   NVL(g.divname, ' ') jikwiold, --구직위명
		   NVL(a.responsibilitydivold, ' ') responsibilitydivold, --구직종
		   NVL(h.divname, ' ') responsibilitydivoldnm, --구직종명
		   NVL(a.classdivold, ' ') classdivold, --구직책
		   NVL(i.divname, ' ') classdivoldnm, --구직책명
		   NVL(a.gradedivold, ' ') gradedivold, --직급
		   NVL(j.divname, ' ') gradedivoldnm, --직급명
		   NVL(a.empstepold, ' ') empstepold, --호봉
		   NVL(a.dutydivold, ' ') dutydivold, --발령직무
		   NVL(S.divname, ' ') dutydivoldnm, --발령직무명
		   NVL(a.ordplantcode, ' ') ordplantcode, --발령사업장
		   NVL(r.plantname, ' ') ordplantcodenm, --발령사업장명
		   NVL(a.deptcode, ' ') deptcodenew, --발령부서
		   NVL(D.topdeptcode, ' ') topdeptcodenew, --발령부서
		   NVL(D.topdeptname, ' ') topdeptnamenew, --발령부서명
		   NVL(D.predeptcode, ' ') predeptcodenew, --발령지점
		   NVL(D.predeptname, ' ') predeptnamenew, --발령지점명
		   NVL(D.deptname, ' ') deptnamenew, --발령팀명
		   NVL(a.workdiv, ' ') workdivnew, --발령근무지
		   NVL(k.divname, ' ') workdivnmnew, --발령근무지명
		   NVL(a.positiondiv, ' ') positiondiv, --발령직위
		   NVL(l.divname, ' ') jikwi, --발령직위명
		   NVL(a.responsibilitydiv, ' ') responsibilitydiv, --발령직종
		   NVL(M.divname, ' ') responsibilitydivnm, --발령직종명
		   NVL(a.classdiv, ' ') classdiv, --발령직책
		   NVL(N.divname, ' ') classdivnm, --발령직책명
		   NVL(a.gradediv, ' ') gradediv, --발령직급
		   NVL(o.divname, ' ') gradedivnm, --발령직급명
		   NVL(a.empstep, ' ') empstep, --호봉
		   NVL(a.dutydiv, ' ') dutydiv, --발령직무
		   NVL(t.divname, ' ') dutydivnm, --발령직무명
		   NVL(a.remark, ' ') remark, --비고
		   NVL(a.statediv, ' ') statediv, --상태
		   NVL(p.divname, ' ') statedivnm, --상태명
		   NVL(a.appdate, ' ') appdate, --승인일자
		   NVL(a.appno, ' ') appno,
       NVL(a.retirereason, ' ') retirereason
	FROM   CMEMPORDERM a
		   JOIN vnEMP b ON a.empcode = b.empcode
		   LEFT JOIN vnDEPT c ON a.deptcodeold = c.deptcode
		   LEFT JOIN vnDEPT D ON a.deptcode = D.deptcode
		   LEFT JOIN CMCOMMONM e
			   ON a.orddiv = e.divcode
				  AND e.cmmcode = 'PS15'
		   LEFT JOIN CMCOMMONM f
			   ON a.workdivold = f.divcode
				  AND f.cmmcode = 'PS26'
		   LEFT JOIN CMCOMMONM g
			   ON a.positiondivold = g.divcode
				  AND g.cmmcode = 'PS29'
		   LEFT JOIN CMCOMMONM h
			   ON a.responsibilitydivold = h.divcode
				  AND h.cmmcode = 'PS07'
		   LEFT JOIN CMCOMMONM i
			   ON a.classdivold = i.divcode
				  AND i.cmmcode = 'PS42'
		   LEFT JOIN CMCOMMONM j
			   ON a.gradedivold = j.divcode
				  AND j.cmmcode = 'PS01'
		   LEFT JOIN CMCOMMONM k
			   ON a.workdiv = k.divcode
				  AND k.cmmcode = 'PS26'
		   LEFT JOIN CMCOMMONM l
			   ON a.positiondiv = l.divcode
				  AND l.cmmcode = 'PS29'
		   LEFT JOIN CMCOMMONM M
			   ON a.responsibilitydiv = M.divcode
				  AND M.cmmcode = 'PS07'
		   LEFT JOIN CMCOMMONM N
			   ON a.classdiv = N.divcode
				  AND N.cmmcode = 'PS42'
		   LEFT JOIN CMCOMMONM o
			   ON a.gradediv = o.divcode
				  AND o.cmmcode = 'PS01'
		   LEFT JOIN CMCOMMONM p
			   ON a.statediv = p.divcode
				  AND p.cmmcode = 'PS90'
		   LEFT JOIN CMPLANTM Q ON a.plantcodeold = Q.plantcode
		   LEFT JOIN CMPLANTM r ON a.ordplantcode = r.plantcode
		   LEFT JOIN CMCOMMONM S
			   ON a.dutydivold = S.divcode
				  AND S.cmmcode = 'PS93'
		   LEFT JOIN CMCOMMONM t
			   ON a.dutydiv = t.divcode
				  AND t.cmmcode = 'PS93'
/
