CREATE VIEW VNEMPORDERAMT AS SELECT a.plantcode, -- ISNULL(a.plantcode, N'') AS plantcode,
		   a.orderdate, -- ISNULL(a.orderdate, N'') AS orderdate,
		   a.orderseq, -- ISNULL(a.orderseq, N'') AS orderseq,
		   a.orderno, -- ISNULL(a.orderno, N'') AS orderno,
		   NVL(a.saldiv, u'') saldiv,
		   NVL(a.yymm, ' ') yymm,
		   NVL(D.divname, ' ') saldivnm,
		   NVL(a.datadiv, u'') datadiv,
		   NVL(e.divname, u'') datadivnm,
		   NVL(a.orderdiv, u'') orderdiv,
       NVL(a.outputdiv, u'') outputdiv,
       NVL(S.divname, u'') outputdivnm,
       NVL(a.transferdiv, u'') transferdiv,
       NVL(t.divname, u'') transfernm,
       a.custcode, -- ISNULL(a.custcode, N'') AS custcode,
       NVL(b.custname, u'') custname,
       NVL(b.addr1, u'') addr1,
       NVL(b.addr2, u'') addr2,
       NVL(b.addr1, u'') || ' ' || NVL(b.addr2, u'') addr,
       NVL(b.telno, u'') telno,
       NVL(b.POST, u'') POST,
       b.deptcode, -- ISNULL(b.deptcode, N'') AS deptcode,
       NVL(h.predeptcode, u'') predeptcode,
       NVL(h.predeptname, u'') predeptname,
       NVL(h.topdeptcode, u'') topdeptcode,
       NVL(h.topdeptname, u'') topdeptname,
       NVL(h.findname, ' ') findname,
       NVL(h.deptname, u'') deptname,
       b.empcode, -- ISNULL(b.empcode, N'') AS empcode,
       NVL(i.positiondiv, u'') positiondiv,
       NVL(Q.divname, u'') jikwi,
       NVL(i.empname, u'') empname,
       a.ecustcode, -- ISNULL(a.ecustcode, N'') AS ecustcode,
       NVL(c.custname, u'') ecustname,
       NVL(c.addr1, u'') eaddr1,
       NVL(c.addr2, u'') eaddr2,
       NVL(c.addr1, u'') || ' ' || NVL(c.addr2, u'') eaddr,
       NVL(c.telno, u'') etelno,
       NVL(c.POST, u'') epost,
       c.deptcode edeptcode, -- ISNULL(c.deptcode, N'') AS edeptcode,
       NVL(j.predeptcode, u'') epredeptcode,
       NVL(j.predeptname, u'') epredeptname,
       NVL(j.topdeptcode, u'') etopdeptcode,
       NVL(j.topdeptname, u'') etopdeptname,
       NVL(j.deptname, u'') edeptname,
       NVL(j.findname, ' ') efindname,
       c.empcode eempcode, -- ISNULL(c.empcode, N'') AS eempcode,
       NVL(k.positiondiv, u'') epositiondiv,
       NVL(r.divname, u'') ejikwi,
       NVL(k.empname, u'') eempname,
       NVL(a.utdiv, u'') utdiv,
       NVL(o.divname, u'') utdivnm,
       NVL(a.eutdiv, u'') eutdiv,
       NVL(p.divname, u'') eutdivnm,
       NVL(a.remark, u'') remark,
       NVL(a.seq, 0) seq,
       a.itemcode, -- ISNULL(a.itemcode, N'') AS itemcode,
       NVL(M.itemname, u'') itemname,
       NVL(M.mitemcode, u'') mitemcode,
       NVL(M.unitqty, 0) unitqty,
       NVL(M.itemunit, ' ') unit,
       NVL(a.taxdate, ' ') taxdate,
       NVL(a.tradedate, ' ') tradedate,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salqty, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salqty, 0) ELSE 0 END salqty,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.givqty, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.givqty, 0) ELSE 0 END givqty,
       NVL(a.drugprc, 0) drugprc,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.drugamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.drugamt, 0) ELSE 0 END drugamt,
       NVL(a.makingcost, 0) makingcost,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.makingamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.makingamt, 0) ELSE 0 END makingamt,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.makinggivamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.makinggivamt, 0) ELSE 0 END makinggivamt,
       NVL(a.salprc, 0) salprc,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salamt, 0) ELSE 0 END salamt,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salvat, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salvat, 0) ELSE 0 END salvat,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.totamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.totamt, 0) ELSE 0 END totamt,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.befamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.befamt, 0) ELSE 0 END befamt,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.aftamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.aftamt, 0) ELSE 0 END aftamt,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.incamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.incamt, 0) ELSE 0 END incamt,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.totdiscount, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.totdiscount, 0) ELSE 0 END totdiscount,
       NVL(a.givrate, 0) givrate,
       NVL(a.befrate, 0) befrate,
       NVL(a.aftrate, 0) aftrate,
       NVL(a.incrate, 0) incrate,
       NVL(a.salprc1, 0) salprc1,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salamt1, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salamt1, 0) ELSE 0 END salamt1,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salvat1, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salvat1, 0) ELSE 0 END salvat1,
       CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.totamt1, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.totamt1, 0) ELSE 0 END totamt1,
       NVL(a.custprtyn, u'') custprtyn,
       NVL(a.outputqty, 0) outputqty,
       NVL(a.pieceyn, u'') pieceyn,
       NVL(a.enuriyn, u'') enuriyn,
       NVL(a.statediv, ' ') statediv,
       NVL(z.divname, ' ') statedivnm,
       a.appdate, -- isnull(a.appdate,'') as appdate,
       NVL(a.fixdate, ' ') fixdate,
       NVL(a.fixseq, ' ') fixseq,
       NVL(a.pda, ' ') pda,
       NVL(M.itemdiv, ' ') itemdiv,
       NVL(i.retiredt, ' ') retiredt,
       NVL(k.retiredt, ' ') eretiredt,
       NVL(h.deptgroup, ' ') deptgroup,
       NVL(j.deptgroup, ' ') edeptgroup,
       NVL(a.warehouse, ' ') warehouse,
       NVL(i.workdiv, ' ') workdiv,
       b.areadiv,
       NVL(QQ.divname, ' ') areadivnm,
       c.areadiv eareadiv,
       NVL(rr.divname, ' ') eareadivnm,
       h.seqtopdeptcode,
       h.seqpredeptcode,
       h.seqdeptcode,
       j.seqtopdeptcode eseqtopdeptcode,
       j.seqpredeptcode eseqpredeptcode,
       j.seqdeptcode eseqdeptcode,
       M.empcode_pm --PM담당 추가 20140114:이세민
  FROM   vnOrdersEnd a
       JOIN CMCUSTM b ON a.custcode = b.custcode
       JOIN CMCUSTM c ON a.ecustcode = c.custcode
       LEFT JOIN CMCOMMONM D
         ON a.saldiv = D.divcode
          AND D.cmmcode = 'SL10'
       LEFT JOIN CMCOMMONM e
         ON a.datadiv = e.divcode
          AND e.cmmcode = 'SL11'
       JOIN vnDEPT h ON b.deptcode = h.deptcode
       JOIN CMEMPM i ON b.empcode = i.empcode
       JOIN vnDEPT j ON c.deptcode = j.deptcode
       LEFT JOIN CMEMPM k ON c.empcode = k.empcode
       JOIN CMITEMM M ON a.itemcode = M.itemcode --and itemdiv <> '3'--판매제품
       LEFT JOIN CMCOMMONM o
         ON a.utdiv = o.divcode
          AND o.cmmcode = 'CM15'
       LEFT JOIN CMCOMMONM p
         ON a.eutdiv = p.divcode
          AND p.cmmcode = 'CM15'
       LEFT JOIN CMCOMMONM Q
         ON i.positiondiv = Q.divcode
          AND Q.cmmcode = 'PS29'
       LEFT JOIN CMCOMMONM r
         ON k.positiondiv = r.divcode
          AND r.cmmcode = 'PS29'
       LEFT JOIN CMCOMMONM S
         ON a.outputdiv = S.divcode
          AND S.cmmcode = 'SL12'
       LEFT JOIN CMCOMMONM t
         ON a.transferdiv = t.divcode
          AND t.cmmcode = 'SL14'
       LEFT JOIN CMCOMMONM z
         ON a.statediv = z.divcode
          AND z.cmmcode = 'SL17'
       LEFT JOIN CMCOMMONM QQ
         ON b.areadiv = QQ.divcode
          AND QQ.cmmcode = 'CM03'
       LEFT JOIN CMCOMMONM rr
         ON c.areadiv = rr.divcode
          AND rr.cmmcode = 'CM03'
/
