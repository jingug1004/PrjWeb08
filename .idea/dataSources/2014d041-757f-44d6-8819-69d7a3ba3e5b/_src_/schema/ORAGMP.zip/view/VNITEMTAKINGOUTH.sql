CREATE VIEW VNITEMTAKINGOUTH AS SELECT	 a.plantcode, -- isnull(a.plantcode,'') as plantcode
			 a.outdate, -- isnull(a.outdate,'') as outdate
			 a.chasoo, -- isnull(a.chasoo,0) as chasoo
			 a.orderno, -- isnull(a.orderno,'') as orderno
			 MAX(b.orderdate) orderdate,
			 MAX(b.orderseq) orderseq,
			 MAX(b.outputdiv) outputdiv,
			 MAX(b.outputdivnm) outputdivnm,
			 MAX(b.transferdiv) transferdiv,
			 MAX(b.transfernm) transfernm,
			 MAX(NVL(b.saldiv, ' ')) saldiv,
			 MAX(NVL(b.saldivnm, ' ')) saldivnm,
			 a.custcode, -- isnull(a.custcode,'') as custcode
			 MAX(NVL(b.custname, ' ')) custname,
			 a.ecustcode, -- ISNULL(a.ecustcode,'') as ecustcode
			 MAX(NVL(b.ecustname, ' ')) ecustname,
			 MAX(NVL(b.empcode, ' ')) empcode,
			 MAX(NVL(b.empname, ' ')) empname,
			 MAX(NVL(b.positiondiv, ' ')) positiondiv,
			 MAX(NVL(b.jikwi, ' ')) jikwi,
			 MAX(NVL(b.topdeptcode, ' ')) topdeptcode,
			 MAX(NVL(b.topdeptname, ' ')) topdeptname,
			 MAX(NVL(b.predeptcode, ' ')) predeptcode,
			 MAX(NVL(b.predeptname, ' ')) predeptname,
			 MAX(NVL(b.deptcode, ' ')) deptcode,
			 MAX(NVL(b.deptname, ' ')) deptname,
			 MAX(NVL(b.findname, ' ')) findname,
			 MAX(NVL(b.addr1, ' ')) addr1,
			 MAX(NVL(b.addr2, ' ')) addr2,
			 MAX(NVL(b.addr, ' ')) addr,
			 MAX(NVL(b.telno, ' ')) telno,
			 MAX(NVL(b.POST, ' ')) POST,
			 MAX(NVL(b.eaddr1, ' ')) eaddr1,
			 MAX(NVL(b.eaddr2, ' ')) eaddr2,
			 MAX(NVL(b.eaddr, ' ')) eaddr,
			 MAX(NVL(b.etelno, ' ')) etelno,
			 MAX(NVL(b.epost, ' ')) epost,
			 MAX(NVL(b.fixdate, ' ')) fixdate,
			 MAX(NVL(b.fixseq, ' ')) fixseq,
			 MAX(NVL(b.remark, ' ')) remark,
			 MAX(NVL(a.boxcnt, 1)) boxcnt,
			 MAX(NVL(a.paydiv, '01')) paydiv,
			 MAX(NVL(D.divname, '01')) paydivnm,
			 MAX(NVL(b.warehouse, ' ')) warehouse,
			 MAX(NVL(c.ordyn, 'N')) ordyn, --운송장발행여부(N:발행, Y:미발행)
			 MAX(NVL(b.custmajorcode, ' ')) custmajorcode
	--이전소스 20131126: 이세민===================================

	--from        SLITEMTAKINGOUTH (nolock) as a

	--left join vnOrderMaster (nolock) as b on

	-- a.orderno = b.orderno

	-- and b.saldiv like 'A%'

	--join SLSTOREHOUSEM (nolock) as c

	-- on a.warehouse = c.warehouse

	--left join CMCOMMONM (nolock) as d

	-- on a.paydiv = d.divcode

	-- and d.cmmcode = 'SL79'
	FROM	 SLITEMTAKINGOUTH a
			 LEFT JOIN vnOrderMaster b
				 ON a.orderno = b.bnorderno
					AND b.saldiv LIKE 'A%'
			 JOIN SLSTOREHOUSEM c ON b.warehouse = c.warehouse
			 LEFT JOIN CMCOMMONM D
				 ON a.paydiv = D.divcode
					AND D.cmmcode = 'SL79'
	--=============================================================
	GROUP BY a.plantcode,
			 a.outdate,
			 a.chasoo,
			 a.orderno,
			 a.custcode,
			 a.ecustcode
--select * from CMCOMMONM where cmmcode = 'SL86'
/
