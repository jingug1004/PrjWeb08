CREATE VIEW VNORDERS AS (SELECT a.plantcode,
           a.orderdate,
           a.orderseq,
           a.orderno,
           a.saldiv saldiv,
           a.yymm yymm,
           d.divname saldivnm,
           a.datadiv datadiv,
           e.divname datadivnm,
           a.orderdiv orderdiv,
           b.telno telno,
           a.custcode,                                                  -- 거래처
           b.custname custname,                                        -- 거래처명
           b.ceoname ceoname,                                      -- 거래처 대표자명
           b.businessno businessno,                               -- 거래처 사업자번호
           b.POST POST,                                            -- 거래처 우편번호
           b.addr1 addr1,                                           -- 거래처 주소1
           b.addr2 addr2,                                           -- 거래처 주소2
           b.addr1 || ' ' || b.addr2 addr,                           -- 거래처 주소
           a.deptcode,                                              -- 거래처 영업소
           h.predeptcode predeptcode,                                -- 거래처 지점
           h.predeptname predeptname,                               -- 거래처 지점명
           h.topdeptcode topdeptcode,                                -- 거래처 본부
           h.topdeptname topdeptname,                               -- 거래처 본부명
           h.findname findname,                                     -- 거래처 조직명
           h.deptname deptname,                                    -- 거래처 영업소명
           a.empcode,                                                -- 거래처 사원
           i.positiondiv positiondiv,                              -- 거래처 사원직위
           q.divname jikwi,                                       -- 거래처 사원직위명
           i.empname empname,                                       -- 거래처 사원명
           a.utdiv utdiv,                                            -- 거래처 유통
           o.divname utdivnm,                                       -- 거래처 유통명
           a.ecustcode,                                                 -- 간납처
           c.custname ecustname,                                       -- 간납처명
           c.ceoname eceoname,                                     -- 간납처 대표자명
           c.businessno ebusinessno,                              -- 간납처 사업자번호
           c.POST epost,                                           -- 간납처 우편번호
           c.addr1 eaddr1,                                          -- 간납처 주소1
           c.addr2 eaddr2,                                          -- 간납처 주소2
           c.addr1 || ' ' || c.addr2 eaddr,                          -- 간납처 주소
           a.edeptcode,                                             -- 간납처 영업소
           j.predeptcode epredeptcode,                               -- 간납처 지점
           j.predeptname epredeptname,                              -- 간납처 지점명
           j.topdeptcode etopdeptcode,                               -- 간납처 본부
           j.topdeptname etopdeptname,                              -- 간납처 본부명
           j.findname efindname,                                    -- 간납처 조직명
           j.deptname edeptname,                                   -- 간납처 영업소명
           a.eempcode,                                               -- 간납처 사원
           k.positiondiv epositiondiv,                             -- 간납처 사원직위
           r.divname ejikwi,                                      -- 간납처 사원직위명
           k.empname eempname,                                      -- 간납처 사원명
           a.eutdiv eutdiv,                                          -- 간납처 유통
           p.divname eutdivnm,                                      -- 간납처 유통명
           a.bnorderno bnorderno,
           a.taxdate taxdate,
           a.tradedate tradedate,
           a.taxmanagedate taxmanagedate,
           a.trademanagedate trademanagedate,
           a.fixdate fixdate,
           NVL (a.fixseq, 0) fixseq,
           a.statediv,
           l.divname statedivnm,
           a.remark remark,
           a.seq,
           a.itemcode,
           m.itemname itemname,
           m.mitemcode mitemcode,
           NVL (m.unitqty, 0) unitqty,
           m.itemunit unit,
           m.drugdiv drugdiv,                                 --의약구분(전문,일반...)
           m.drugdivnm drugdivnm,
           m.formdiv formdiv,                                 --제형(정제, 주사제...)
           m.formdivnm formdivnm,
           m.itempart itempart,                               --제품종류(제품,상품...)
           m.itempartnm itempartnm,
           m.effectdiv effectdiv,                         --주효능(호흡기용, 소화기용...)
           m.effectdivnm effectdivnm,
           m.itemgbdiv itemgbdiv,                           --제품분류(일반,향정신성,마약)
           m.itemgbdivnm itemgbdivnm,
           m.incentiveyn incentiveyn,                                   --인센티브
           m.mainitemyn mainitemyn,                                     --대표제품
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN a.salqty
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -a.salqty
              ELSE 0
           END
              salqty,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN a.givqty
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -a.givqty
              ELSE 0
           END
              givqty,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN a.bonusqty
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -a.bonusqty
              ELSE 0
           END
              bonusqty,
           NVL (a.drugprc, 0) drugprc,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.drugamt, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.drugamt, 0)
              ELSE 0
           END
              drugamt,
           NVL (a.makingcost, 0) makingcost,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.makingamt, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.makingamt, 0)
              ELSE 0
           END
              makingamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A'
              THEN
                 NVL (a.makinggivamt, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B'
              THEN
                 -NVL (a.makinggivamt, 0)
              ELSE
                 0
           END
              makinggivamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A'
              THEN
                 NVL (a.makingbonusamt, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B'
              THEN
                 -NVL (a.makingbonusamt, 0)
              ELSE
                 0
           END
              makingbonusamt,
           NVL (a.salprc, 0) salprc,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.salamt, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.salamt, 0)
              ELSE 0
           END
              salamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.salvat, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.salvat, 0)
              ELSE 0
           END
              salvat,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.totamt, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.totamt, 0)
              ELSE 0
           END
              totamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.befamt, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.befamt, 0)
              ELSE 0
           END
              befamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.aftamt, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.aftamt, 0)
              ELSE 0
           END
              aftamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.incamt, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.incamt, 0)
              ELSE 0
           END
              incamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.totdiscount, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.totdiscount, 0)
              ELSE 0
           END
              totdiscount,
           NVL (a.givrate, 0) givrate,
           NVL (a.befrate, 0) befrate,
           NVL (a.aftrate, 0) aftrate,
           NVL (a.incrate, 0) incrate,
           NVL (a.salprc1, 0) salprc1,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.salamt1, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.salamt1, 0)
              ELSE 0
           END
              salamt1,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.salvat1, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.salvat1, 0)
              ELSE 0
           END
              salvat1,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN NVL (a.totamt1, 0)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -NVL (a.totamt1, 0)
              ELSE 0
           END
              totamt1,
           a.custprtyn custprtyn,
           NVL (a.outputqty, 0) outputqty,
           a.recalldiv recalldiv,
           v.divname recalldivnm,
           a.pieceyn pieceyn,
           a.enuriyn eruriyn,
           a.appdate,
           a.outputdiv outputdiv,
           s.divname outputdivnm,
           a.transferdiv transferdiv,
           t.divname transfernm,
           a.pda pda,
           a.lotno lotno,
           m.itemdiv itemdiv,
           i.retiredt retiredt,
           k.retiredt eretiredt,
           h.deptgroup deptgroup,
           j.deptgroup edeptgroup,
           b.custmajorcode custmajorcode,
           a.bigo,
           a.warehouse warehouse,
           w.whname warehousenm,
           i.ratediv ratediv,
           k.ratediv eratediv,
           oo.divname ratedivnm,
           pp.divname eratedivnm,
           a.juordno juordno,
           a.expdate,
           a.insertdt,
           a.iempcode,
           a.updatedt,
           a.uempcode,
           ie.empname insertempname,
           ue.empname updateempname,
           h.seqtopdeptcode,
           h.seqpredeptcode,
           h.seqdeptcode,
           j.seqtopdeptcode eseqtopdeptcode,
           j.seqpredeptcode eseqpredeptcode,
           j.seqdeptcode eseqdeptcode,
           ss.divname orderdivnm,                           -- 추가 20131120:이세민
           m.itemtype,
           a.orderkind,
           a.factorycode,
           cm.mplantcode
      FROM vnOrdersend a
           INNER JOIN CMCUSTM b
              ON a.custcode = b.custcode      -- and a.plantcode = b.plantcode
           INNER JOIN CMCUSTM c
              ON a.ecustcode = c.custcode     -- and a.plantcode = c.plantcode
           LEFT JOIN CMCOMMONM d
              ON a.saldiv = d.divcode AND d.cmmcode = 'SL10'
           LEFT JOIN CMCOMMONM e
              ON a.datadiv = e.divcode AND e.cmmcode = 'SL11'
           LEFT JOIN vnDEPT h
              ON a.deptcode = h.deptcode      -- and a.plantcode = h.plantcode
           LEFT JOIN CMEMPM i
              ON a.empcode = i.empcode        -- and a.plantcode = i.plantcode
           LEFT JOIN vnDEPT j
              ON a.edeptcode = j.deptcode     -- and a.plantcode = j.plantcode
           LEFT JOIN CMEMPM k
              ON a.eempcode = k.empcode       -- and a.plantcode = k.plantcode
           LEFT JOIN CMCOMMONM l
              ON a.statediv = l.divcode AND l.cmmcode = 'SL17'
           LEFT JOIN vnItem m
              ON a.itemcode = m.itemcode -- and itemdiv <> '3' -- AND a.plantcode = m.plantcode --판매제품
           LEFT JOIN CMCOMMONM n
              ON m.unit = n.divcode AND n.cmmcode = 'CM38'
           LEFT JOIN CMCOMMONM o
              ON a.utdiv = o.divcode AND o.cmmcode = 'CM15'
           LEFT JOIN CMCOMMONM p
              ON a.eutdiv = p.divcode AND p.cmmcode = 'CM15'
           LEFT JOIN CMCOMMONM q
              ON i.positiondiv = q.divcode AND q.cmmcode = 'PS29'
           LEFT JOIN CMCOMMONM r
              ON k.positiondiv = r.divcode AND r.cmmcode = 'PS29'
           LEFT JOIN CMCOMMONM s
              ON a.outputdiv = s.divcode AND s.cmmcode = 'SL12'
           LEFT JOIN CMCOMMONM t
              ON a.transferdiv = t.divcode AND t.cmmcode = 'SL14'
           LEFT JOIN CMCOMMONM v
              ON a.recalldiv = v.divcode AND v.cmmcode = 'SL16'
           LEFT JOIN SLSTOREHOUSEM w
              ON a.warehouse = w.warehouse
           LEFT JOIN CMCOMMONM oo
              ON i.ratediv = oo.divcode AND oo.cmmcode = 'SL50'
           LEFT JOIN CMCOMMONM pp
              ON k.ratediv = pp.divcode AND pp.cmmcode = 'SL50'
           LEFT JOIN CMEMPM ie
              ON a.iempcode = ie.empcode
           LEFT JOIN CMEMPM ue
              ON a.uempcode = ue.empcode
           LEFT JOIN CMCOMMONM ss
              ON a.orderdiv = ss.divcode AND ss.cmmcode = 'SL43'
           LEFT JOIN CMITEMM cm
              ON a.itemcode = cm.itemcode)
/
