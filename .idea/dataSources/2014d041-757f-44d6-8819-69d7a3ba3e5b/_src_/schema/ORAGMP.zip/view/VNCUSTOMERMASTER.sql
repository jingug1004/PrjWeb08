CREATE VIEW VNCUSTOMERMASTER AS SELECT custcode, --거래처코드
		   custname, --거래처명
		   custename custengname, --거래처명(영문)
		   custcondition businessstatus, --업태
		   custitem businesscategory, --업종
		   ceoname OWNER, --대표자명
		   ceono ownerno, -- 대표자주민번호
		   businessno establishmentregistno, --사업자번호
		   POST postcode, --우편번호
		   addr1 ADDRESS, --주소
		   addr2 detailaddress, --상세주소
		   telno telephone, --대표전화번호
		   faxno, --팩스번호
		   opendate registdate, --등록일자
		   'N' manufacturediv, --제조처yn
		   CASE WHEN custdiv IN ('1', '3') THEN '01' WHEN custdiv IN ('2', '3') THEN 'Y' ELSE 'N' END sellingdiv, --판매처구분(-------)
		   'N' ascustcheck, --as업체yn
		   ' ' buydiv, --과세 면세 영세율 MPM17       --매입구분코드(과세,명세)
		   CASE WHEN custdiv IN ('1', '3') THEN '01' WHEN custdiv IN ('2', '3') THEN '02' ELSE ' ' END custdiv, --01매입 --02매출 --03제조 MPM01  --거래처구분(----------)
		   CASE WHEN stopdate IS NULL THEN 'Y' ELSE 'N' END usediv, --사용구분
		   custclass abc, --ABC
		   custempname official, --담당자
		   ' ' express, --운송사(--------)
		   memo1 remark, --비고
		   ' ' interviewpoint, --업체방문평가(--------)
		   a.email --이메일
	FROM   CMCUSTM a
/
