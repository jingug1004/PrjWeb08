CREATE VIEW E_ITEMSTOCK2 AS SELECT	 b.itemoldcode itemcode,
			 SUM(a.qty) qty,
			 SUM(a.qty) useqty
	FROM	 SLWAREHOUSEM a JOIN CMITEMM b ON a.itemcode = b.itemcode
	GROUP BY b.itemoldcode
--select	itemcode, lotno, max(lotdate) as lotdate, max(expdate) as expdate, sum(qty) as qty
--from	SLWAREHOUSEM
--group by itemcode, lotno
/
