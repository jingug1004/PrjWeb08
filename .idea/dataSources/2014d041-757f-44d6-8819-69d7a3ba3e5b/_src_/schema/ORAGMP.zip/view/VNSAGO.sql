CREATE VIEW VNSAGO AS SELECT a.plantcode,
		   a.custcode,
		   NVL(b.custname, '') AS custname,
		   NVL(b.ceoname, '') AS ceoname,
		   CASE
			   WHEN NVL(TRIM(b.addr1), '') IS NULL
					AND NVL(TRIM(b.addr2), '') IS NULL
			   THEN
				   ''
			   ELSE
				   NVL(b.addr1, '') || ' ' || NVL(b.addr2, '')
		   END
			   AS addr,
		   NVL(a.sagodate, '') AS sagodate,
		   NVL(a.balance, 0) AS balance,
		   NVL(a.billamt, 0) AS billamt,
		   NVL(a.totamt, 0) AS totamt,
		   NVL(z.balanceloss, 0) AS balanceloss,
		   NVL(z.billamtloss, 0) AS billamtloss,
		   NVL(z.balancerecall, 0) AS balancerecall,
		   NVL(z.billamtrecall, 0) AS billamtrecall,
		   NVL(a.sagotype, '') AS sagotype,
		   NVL(f.divname, '') AS sagotypenm,
		   NVL(a.sagodiv, '') AS sagodiv,
		   NVL(G.divname, '') AS sagodivnm,
		   NVL(a.flowdiv, '') AS flowdiv,
		   NVL(h.divname, '') AS flowdivnm,
		   NVL(a.lawdate, '') AS lawdate,
		   NVL(a.eventsummary, '') AS eventsummary,
		   NVL(a.lawremark, '') AS lawremark,
		   NVL(a.recallremark, '') AS recallremark,
		   NVL(a.remark, '') AS remark,
		   NVL(a.fixdate, '') AS fixdate,
		   NVL(a.stopdate, '') AS stopdate,
		   NVL(c.topdeptcode, '') AS topdeptcode,
		   NVL(c.topdeptname, '') AS topdeptname,
		   NVL(c.predeptcode, '') AS predeptcode,
		   NVL(c.predeptname, '') AS predeptname,
		   NVL(a.deptcode, '') AS deptcode,
		   NVL(c.deptname, '') AS deptname,
		   NVL(c.findname, '') AS findname,
		   NVL(E.positiondiv, '') AS positiondiv,
		   NVL(i.divname, '') AS jikwi,
		   NVL(a.empcode, '') AS empcode,
		   NVL(E.empname, '') AS empname,
		   c.seqtopdeptcode,
		   c.seqpredeptcode,
		   c.seqdeptcode
	FROM   SLSAGOM a
		   JOIN CMCUSTM b ON a.custcode = b.custcode
		   JOIN vndept c ON a.deptcode = c.deptcode
		   JOIN CMEMPM E ON a.empcode = E.empcode
		   LEFT JOIN cmcommonm f
			   ON a.sagotype = f.divcode
				  AND f.cmmcode = 'SL07' --사고유형
		   LEFT JOIN cmcommonm G
			   ON a.sagodiv = G.divcode
				  AND G.cmmcode = 'CM20' --거래처상태
		   LEFT JOIN cmcommonm h
			   ON a.flowdiv = h.divcode
				  AND h.cmmcode = 'SL08' --사고진행상태
		   LEFT JOIN CMCOMMONM i
			   ON E.positiondiv = i.divcode
	        AND i.cmmcode = 'PS29'
       LEFT JOIN (SELECT   custcode,
                 SUM(CASE WHEN processdiv = '5' THEN processamt ELSE 0 END) AS balanceloss --잔고대손
                                                    ,
                 SUM(CASE WHEN processdiv = '4' THEN processamt ELSE 0 END) AS billamtloss --어음대손
                                                    ,
                 SUM(CASE
                     WHEN (processdiv = '2')
                      OR (processdiv = '3')
                      OR (processdiv = '6')
                     THEN
                       processamt
                     ELSE
                       0
                   END)
                   AS balancerecall --잔고회수  대손회수  물품회수
                           ,
                 SUM(CASE WHEN processdiv = '1' THEN processamt ELSE 0 END) AS billamtrecall --어음회수
            FROM     SLSAGOD
            GROUP BY custcode) z
         ON a.custcode = z.custcode
/
