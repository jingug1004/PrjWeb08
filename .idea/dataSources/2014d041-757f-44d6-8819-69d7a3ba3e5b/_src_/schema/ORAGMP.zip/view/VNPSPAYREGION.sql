CREATE VIEW VNPSPAYREGION AS SELECT a.plantcode plantcode
          , -- 사업장
           a.yearmonth
          , -- 급여년월
           a.paybonusdiv
          , -- 급/상여구분
           NVL(l.divname, ' ') paybonusdivnm
          ,a.chasoo
          , -- 차수
           -- 2017-=09-04 아래와 같이 되어 있어서 수정함
           -- SUBSTR(a.yearmonth, 1, 4) || '년 ' || SUBSTR(a.yearmonth, 6, 2) || '월-' || UTILS.CONVERT_TO_VARCHAR2(a.chasoo, 30) || '차' yeargb
          SUBSTR(a.yearmonth, 1, 4) || '년 ' || SUBSTR(a.yearmonth, 6, 2) || '월-' || TO_CHAR(a.chasoo) || '차' yeargb
          ,NVL(D.enterdt, ' ') enterdt
          , -- 입사일자
           NVL(D.retiredt, ' ') retiredt
          , -- 퇴사일자
           NVL(e.topdeptcode, ' ') topdeptcode
          , -- 부서
           NVL(e.predeptcode, ' ') predeptcode
          , -- 지점
           D.deptcode
          , -- 팀
           NVL(e.topdeptname, ' ') topdeptname
          , -- 부서명
           NVL(e.predeptname, ' ') predeptname
          , -- 지점명
           NVL(e.deptname, ' ') deptname
          , -- 팀명
           NVL(e.findname, ' ') findname
          , -- 부서검색
           a.empcode
          , -- 사원
           D.empname
          , -- 사원명
           D.workdiv
          , -- 근무지
           NVL(S.divname, ' ') workdivnm
          , -- 근무지명
           D.sexdiv
          , -- 성별
           NVL(h.divname, ' ') sexdivnm
          ,D.empdiv
          , -- 사원구분
           NVL(i.divname, ' ') empdivnm
          ,D.enterdiv
          , -- 입사구분
           NVL(p.divname, ' ') enterdivnm
          ,D.positiondiv
          , -- 직위
           NVL(f.divname, ' ') jikwi
          ,D.gradediv
          , -- 직급
           NVL(j.divname, ' ') gradedivnm
          ,D.empstep
          , -- 호봉
           D.responsibilitydiv
          , -- 직종
           NVL(g.divname, ' ') responsibilitydivnm
          ,D.classdiv
          , -- 직책
           NVL(Q.divname, ' ') classdivnm
          ,NVL(a.regcode, ' ') regcode
          , -- 기준코드
           NVL(c.regname, 0) regname
          , -- 기준항목
           NVL(a.regamt, 0) regamt
          , -- 기준금
           NVL(a.regcnt, 0) regcnt
          , -- 횟수
           NVL(a.regionamt, 0) regionamt -- 지방수당액
      FROM PSPAYREGIONM a
           JOIN PSREGIONAMTM c ON a.regcode = c.regcode
           JOIN CMEMPM D
               ON a.empcode = D.empcode
                  AND D.empdiv <> '09'
           LEFT JOIN vnDEPT e ON D.deptcode = e.deptcode
           LEFT JOIN CMCOMMONM f
               ON D.positiondiv = f.divcode
                  AND f.cmmcode = 'ps29'
           LEFT JOIN CMCOMMONM g
               ON D.responsibilitydiv = g.divcode
                  AND g.cmmcode = 'ps07'
           LEFT JOIN CMCOMMONM h
               ON D.sexdiv = h.divcode
                  AND h.cmmcode = 'ps30'
           LEFT JOIN CMCOMMONM i
               ON D.empdiv = i.divcode
                  AND i.cmmcode = 'ps41'
           LEFT JOIN CMCOMMONM j
               ON D.gradediv = j.divcode
                  AND j.cmmcode = 'PS01'
           LEFT JOIN CMCOMMONM l
               ON a.paybonusdiv = l.divcode
                  AND l.cmmcode = 'PS53'
           LEFT JOIN CMCOMMONM p
               ON D.enterdiv = p.divcode
                  AND p.cmmcode = 'ps09'
           LEFT JOIN CMCOMMONM Q
               ON D.classdiv = Q.divcode
                  AND Q.cmmcode = 'ps42'
           LEFT JOIN CMCOMMONM S
               ON D.workdiv = S.divcode
                  AND S.cmmcode = 'ps26'
--        select * from vnPSPay
/
