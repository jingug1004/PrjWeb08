CREATE VIEW VNTESTSTANDARDMASTER AS SELECT a.teststandardrevisionid,
		   a.itemcode,
		   a.testdiv,
		   a.standarddiv,
		   a.processcode,
		   a.revisionno
	FROM   TestStandardRevision a
		   JOIN (SELECT   testdiv,
						  itemcode,
						  standarddiv,
						  processcode,
						  MAX(revisionno) revisionno
				 FROM	  TestStandardRevision
				 WHERE	  NVL(useyn, 'N') = 'Y'
				 GROUP BY testdiv, itemcode, standarddiv, processcode) b
			   ON a.testdiv = b.testdiv
				  AND a.itemcode = b.itemcode
				  AND NVL(a.standarddiv, ' ') = NVL(b.standarddiv, ' ')
				  AND NVL(a.processcode, ' ') = NVL(b.processcode, ' ')
				  AND NVL(a.revisionno, ' ') = NVL(b.revisionno, ' ')
/
