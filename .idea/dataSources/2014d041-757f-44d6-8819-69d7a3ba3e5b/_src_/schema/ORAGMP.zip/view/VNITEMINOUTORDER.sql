CREATE VIEW VNITEMINOUTORDER AS SELECT a.plantcode,
		   NVL(gubun, ' ') gubun,
		   NVL(gubunnm, ' ') gubunnm,
		   a.inoutdate, -- isnull(a.inoutdate,'') as inoutdate
		   NVL(a.inoutseq, 0) inoutseq,
		   NVL(a.orderno, ' ') inoutno,
		   a.inoutdiv, -- isnull(a.inoutdiv,'') as inoutdiv
		   NVL(c.divname, ' ') inoutdivnm,
		   a.itemcode, -- isnull(a.itemcode,'') as itemcode
		   NVL(b.itemname, ' ') itemname,
		   NVL(b.itemunit, ' ') unit,
		   NVL(b.drugdiv, ' ') drugdiv, --의약구분(전문,일반...)
		   NVL(b.drugdivnm, ' ') drugdivnm,
		   NVL(b.formdiv, ' ') formdiv, --제형(정제, 주사제...)
		   NVL(b.formdivnm, ' ') formdivnm,
		   NVL(b.itempart, ' ') itempart, --제품종류(제품,상품...)
		   NVL(b.itempartnm, ' ') itempartnm,
		   NVL(b.effectdiv, ' ') effectdiv, --주효능(호흡기용, 소화기용...)
		   NVL(b.effectdivnm, ' ') effectdivnm,
		   NVL(a.lotno, ' ') lotno,
		   NVL(a.qty, 0) qty,
		   NVL(a.lotdate, ' ') lotdate,
		   NVL(a.expdate, ' ') expdate,
		   NVL(a.warehouse, ' ') warehouse,
		   NVL(D.whname, ' ') whname,
		   NVL(a.location, ' ') location,
		   NVL(a.custcode, ' ') custcode,
		   NVL(e.custname, ' ') custname,
		   NVL(e.addr1, ' ') addr1,
		   NVL(e.addr2, ' ') addr2,
		   NVL(a.inamt, 0) inamt
	FROM   (SELECT a.plantcode,
				   'out' gubun,
				   '출고' gubunnm,
				   --,a.outdate as inoutdate
				   a.outdate inoutdate,
				   a.outseq inoutseq,
				   a.orderno,
				   a.outdiv inoutdiv,
				   a.custcode,
				   a.itemcode,
				   a.lotno,
				   a.lotdate,
				   a.expdate,
				   a.outqty qty,
				   a.warehouse,
				   a.location,
				   0 inamt
			FROM   SLITEMTAKINGOUT a --MES 연동 처리 20131126:이세민
				   LEFT JOIN vnOrderAmt b
					   ON a.orderno = b.orderno
						  AND a.itemcode = b.itemcode
			UNION -- and left(b.saldiv,1) <> 'B'
				 ALL
			SELECT a.plantcode,
				   'in' gubun,
				   '입고' gubunnm,
				   a.indate,
				   a.inseq,
				   a.inputno,
				   a.indiv,
				   a.custcode,
				   a.itemcode,
				   a.lotno,
				   a.lotdate,
				   a.expdate,
				   a.inqty,
				   a.warehouse,
				   a.location,
				   a.inqty * NVL(b.drugprc, 0) inamt
			FROM   SLITEMWAREHOUSING a --MES 연동 처리 20131126:이세민
									  JOIN CMITEMM b ON a.itemcode = b.itemcode) a
		   LEFT JOIN vnItem b ON a.itemcode = b.itemcode
		   LEFT JOIN CMCOMMONM c
			   ON a.inoutdiv = c.divcode
				  AND c.cmmcode = 'SL25'
		   --left join slstorehousem (nolock) as d

		   LEFT JOIN SLSTOREHOUSEM -->>연동처리 20131127:이세민
								  D ON a.warehouse = D.warehouse
		   LEFT JOIN CMCUSTM e ON a.custcode = e.custcode
/
