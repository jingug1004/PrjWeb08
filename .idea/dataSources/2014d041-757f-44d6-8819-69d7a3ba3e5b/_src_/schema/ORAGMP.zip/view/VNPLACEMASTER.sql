CREATE VIEW VNPLACEMASTER AS SELECT deptcode,
		   deptname,
		   plantcode
	FROM   vnDEPT a
/
