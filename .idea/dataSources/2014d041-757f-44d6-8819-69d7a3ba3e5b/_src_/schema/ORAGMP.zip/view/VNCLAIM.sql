CREATE VIEW VNCLAIM AS SELECT	 a.plantcode,
			 MAX(a.orderdate) orderdate, -- isnull(max(a.orderdate),'') as orderdate
			 MAX(a.appdate) appdate, -- isnull(max(a.appdate),'') as appdate
			 a.orderno,
			 SUBSTR(a.orderno, 1, 8) || '-' || SUBSTR(a.orderno, 9, 4) ordno,
			 NVL(MAX(a.saldiv), ' ') saldiv,
			 NVL(MAX(b.divname), ' ') saldivnm,
			 NVL(MAX(a.outputdiv), ' ') outputdiv,
			 NVL(MAX(h.divname), ' ') outputdivnm,
			 NVL(MAX(a.transferdiv), ' ') transferdiv,
			 NVL(MAX(i.divname), ' ') transferdivnm,
			 MAX(a.custcode) custcode, -- isnull(max(a.custcode),'') as custcode
			 NVL(MAX(c.custname), ' ') custname,
			 NVL(MAX(c.custcondition), ' ') custcondition,
			 NVL(MAX(c.custitem), ' ') custitem,
			 NVL(MAX(c.businessno), ' ') businessno,
			 NVL(MAX(c.ceoname), ' ') ceoname,
			 NVL(MAX(c.addr1), ' ') addr1,
			 NVL(MAX(c.addr2), ' ') addr2,
			 NVL(MAX(c.addr1 || ' ' || c.addr2), ' ') addr,
			 MAX(a.ecustcode) ecustcode, -- isnull(max(a.ecustcode),'') as ecustcode
			 NVL(MAX(N.custname), ' ') ecustname,
			 NVL(MAX(a.utdiv), ' ') utdiv,
			 NVL(MAX(M.divname), ' ') utdivnm,
			 MAX(a.deptcode) deptcode, -- isnull(max(a.deptcode),'') as deptcode
			 NVL(MAX(D.predeptname), ' ') || ' ' || NVL(MAX(D.deptname), ' ') deptname,
			 NVL(MAX(D.predeptcode), ' ') predeptcode,
			 NVL(MAX(D.predeptname), ' ') predeptname,
			 NVL(MAX(D.topdeptcode), ' ') topdeptcode,
			 NVL(MAX(D.topdeptname), ' ') topdeptname,
			 NVL(MAX(D.findname), ' ') findname,
			 NVL(MAX(g.positiondiv), ' ') positiondiv,
			 MAX(a.empcode) empcode, -- isnull(max(a.empcode),'') as empcode
			 NVL(MAX(g.empname), ' ') empname,
			 MAX(a.eempcode) eempcode, -- ISNULL(max(a.eempcode),'') as eempcode
       NVL(MAX(j.divname), ' ') jikwi,
       MAX(a.statediv) statediv, -- isnull(max(a.statediv),'') as statediv
       NVL(MAX(k.divname), ' ') statedivnm,
       NVL(SUM(z.salamt), 0) salamt,
       NVL(SUM(z.salvat), 0) salvat,
       NVL(SUM(z.totamt), 0) totamt,
       CASE WHEN NVL(MAX(a.creditck), ' ') = '*' THEN '불량' WHEN NVL(MAX(a.creditck), ' ') = 'N' THEN '정상' WHEN NVL(MAX(a.creditck), ' ') = 'Y' THEN '승인' ELSE '정상' END credit,
       CASE WHEN NVL(MAX(a.sagock), ' ') = '*' THEN '불량' WHEN NVL(MAX(a.sagock), ' ') = 'N' THEN '정상' WHEN NVL(MAX(a.sagock), ' ') = 'Y' THEN '승인' ELSE '정상' END sago,
       CASE WHEN NVL(MAX(a.loanlmtck), ' ') = '*' THEN '불량' WHEN NVL(MAX(a.loanlmtck), ' ') = 'N' THEN '정상' WHEN NVL(MAX(a.loanlmtck), ' ') = 'Y' THEN '승인' ELSE '정상' END loan,
       CASE WHEN NVL(MAX(a.balancelmtck), ' ') = '*' THEN '불량' WHEN NVL(MAX(a.balancelmtck), ' ') = 'N' THEN '정상' WHEN NVL(MAX(a.balancelmtck), ' ') = 'Y' THEN '승인' ELSE '정상' END balance,
       CASE WHEN NVL(MAX(a.nocollmtck), ' ') = '*' THEN '불량' WHEN NVL(MAX(a.nocollmtck), ' ') = 'N' THEN '정상' WHEN NVL(MAX(a.nocollmtck), ' ') = 'Y' THEN '승인' ELSE '정상' END nocol,
       CASE WHEN NVL(MAX(a.securitylmtck), ' ') = '*' THEN '불량' WHEN NVL(MAX(a.securitylmtck), ' ') = 'N' THEN '정상' WHEN NVL(MAX(a.securitylmtck), ' ') = 'Y' THEN '승인' ELSE '정상' END securitylmt,
       CASE WHEN NVL(MAX(a.avgamtlmtck), ' ') = '*' THEN '불량' WHEN NVL(MAX(a.avgamtlmtck), ' ') = 'N' THEN '정상' WHEN NVL(MAX(a.avgamtlmtck), ' ') = 'Y' THEN '승인' ELSE '정상' END avgamt,
       CASE WHEN NVL(MAX(a.sampck), ' ') = '*' THEN '불량' WHEN NVL(MAX(a.sampck), ' ') = 'N' THEN '정상' WHEN NVL(MAX(a.sampck), ' ') = 'Y' THEN '승인' ELSE '정상' END avgqty,
       CASE WHEN NVL(MAX(a.turnlmtck), ' ') = '*' THEN '불량' WHEN NVL(MAX(a.turnlmtck), ' ') = 'N' THEN '정상' WHEN NVL(MAX(a.turnlmtck), ' ') = 'Y' THEN '승인' ELSE '정상' END turn,
             CASE WHEN NVL(MAX(a.THREEAVGCK), ' ') = '*' THEN '불량' WHEN NVL(MAX(a.THREEAVGCK), ' ') = 'N' THEN '정상' WHEN NVL(MAX(a.THREEAVGCK), ' ') = 'Y' THEN '승인' ELSE '정상' END THREEAVGCK,
       MAX(a.remark) remark,
       MAX(D.seqtopdeptcode) seqtopdeptcode,
       MAX(D.seqpredeptcode) seqpredeptcode,
       MAX(D.seqdeptcode) seqdeptcode,
       MAX(a.apprstatus) apprstatus, --필드추가 2013-10-23 :이세민
       MAX(a.edeptcode) edeptcode, --필드추가 2013-10-24 :이세민
       MAX(c.orderctrlyn) orderctrlyn, --필드추가 2013-10-24 :이세민
             MAX(a.orderdiv) orderdiv
  FROM   SLORDM a
       LEFT JOIN SLORDD z ON a.orderno = z.orderno
       LEFT JOIN CMCOMMONM b
         ON a.saldiv = b.divcode
          AND b.cmmcode = 'SL10'
       LEFT JOIN CMCUSTM c ON a.custcode = c.custcode
       LEFT JOIN vnDEPT D ON a.deptcode = D.deptcode
       LEFT JOIN CMEMPM g ON a.empcode = g.empcode
       LEFT JOIN CMCOMMONM j
         ON g.positiondiv = j.divcode
          AND j.cmmcode = 'PS29'
       LEFT JOIN CMCOMMONM h
         ON a.outputdiv = h.divcode
          AND h.cmmcode = 'SL12'
       LEFT JOIN CMCOMMONM i
         ON a.transferdiv = i.divcode
          AND i.cmmcode = 'SL14'
       LEFT JOIN CMCOMMONM k
         ON a.statediv = k.divcode
          AND k.cmmcode = 'SL17'
       LEFT JOIN CMCOMMONM M
         ON a.utdiv = M.divcode
          AND M.cmmcode = 'CM15'
       LEFT JOIN CMCUSTM N ON a.ecustcode = N.custcode
  WHERE   a.statediv <> '99' --in ('03', '07', '09')
       AND a.saldiv LIKE 'A%'
  GROUP BY a.plantcode, a.orderno
/
