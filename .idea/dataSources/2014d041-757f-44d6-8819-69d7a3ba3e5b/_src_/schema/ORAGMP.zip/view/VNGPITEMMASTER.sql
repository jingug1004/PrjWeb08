CREATE VIEW VNGPITEMMASTER AS SELECT A.itemcode itemcode, --품목코드
		   b.itemkorname itemkorname, --품목명(국문)
		   A.revisionno revisionno, --품목허가개정번호
		   c.divcode itemdiv, --품목구분
		   c.managecode managecode, --품목구분(시스템)
		   c.divname itemdivname, --품목구분명
		   b.itemshortname itemshortname, --품목명(약명)
		   b.itemengname itemengname, --품목명(영문)
		   b.standarddiv standarddiv, --시험규격코드
		   D.divname standarddivname, --시험규격명
		   b.validityperiod validityperiod, --유통기한(월)
		   b.itemunit itemunit, --단위코드
		   E.divname itemunitname, --단위명
		   b.keepingmethod keepingmethod, --보관방법
		   b.itemdiv itembranch, --품목분류코드
		   f.divname itembranchname, --품목분류명
		   b.keepingwarehouse keepingwarehouse, --보관창고코드
		   G.divname keepingwarehousename, --보관창고명
		   NULL internaldiv, --국내외구분코드(원자재/상품)
		   NULL internaldivname, --국내외구분(*)
		   NULL enteringrackdiv, --입고랙종류코드(원자재/상품)
		   NULL enteringrackdivname, --입고랙종류(*)
		   NULL enteringrackqty, --입고랙적재량(원자재/상품)
		   'Y' testcheck, --시험여부
		   NULL safestockqty, --안전재고량
		   NULL properstockqty, --적정재고량
		   NULL buyperiod, --구매기간
		   A.usediv usediv, --사용여부
		   CASE A.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
		   NULL notusediv, --미사용원인코드
		   NULL notusedivname, --미사용원인(*)
		   b.revisionno itemrevisionid, --관리번호(제조제품)--수정되여야 한다.
		   b.contentqty contentqty, --함량Num(제조제품)
		   b.contentunit contentunit, --함량단위코드(제조제품)
		   h.divname contentunitname, --함량단위(*)
		   TO_CHAR(b.contentqty) || h.divname contentqtyname, --함량Text(*)
		   b.BATCHSIZE BATCHSIZE, --배치크기Num(제조제품)
		   TO_CHAR(b.BATCHSIZE) || E.divname batchsizename, --배치크기Text(*)
		   --,b.usage    as usage    --용법.용량(제조제품)
		   --,b.efficacy    as efficacy    --효능/효과(제조제품)
		   --,b.attention   as attention   --주의사항(제조제품)
		   b.itemformdiv itemformdiv, --제품유형코드(제조제품)
		   i.divname itemformdivname, --제품유형(*)
		   --,b.standardyield  as standardyield  --표준수율(제조제품)
		   b.maxmanageyield maxmanageyield, --관리수율(상한)(제조제품)
		   b.minmanageyield minmanageyield, --관리수율(하한)(제조제품)
		   b.makingcost makingcost, --제조원가(제조,포장)
		   b.docuno docuno, --문서번호(제조,포장)
		   b.productcheck productcheck, --생산여부(제조,포장)
		   b.notproductdiv notproductdiv, --미생산원인코드(제조,포장)
		   j.divname notproductdivname, --미생산원인(*)
		   NULL typicalitemcode, --대표제품코드(포장제품)
		   NULL typicalitemname, --대표제품명(*)
		   NULL packingunitqty, --포장단위량Num(포장제품)
		   NULL packingunitqtyname, --포장단위Text(*)
		   NULL packingtypediv, --포장타입코드(포장제품)
		   NULL packingtypedivname, --포장타입(*)
		   NULL typicalpackingcheck, --포장대표여부(포장제품)
		   NULL cartondiv, --지함종류코드(포장제품)
		   NULL cartondivname, --지함종류(*)
		   NULL cartonqty, --지함적재량(포장제품)
		   NULL barcode, --바코드(포장제품)
		   NULL minpackingcheck,
		   b.productiondiv productiondiv,
		   K.divname productiondivname,
		   K.remark productiontype,
		   A.approvalcheck approvalcheck,
		   A.plantcode plantcode,
		   b.transqty,
		   NVL(M.divname, ' ') transunitname
	FROM   GoodsStandardRevision A
		   JOIN MakingGoodsMaster b
			   ON A.itemcode = b.itemcode
				  AND A.itemrevisionid = b.revisionno
		   JOIN CommonMaster c
			   ON c.cmmcode = 'CMM01'
				  AND b.itemdiv = c.divcode
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'LMM06'
				  AND b.standarddiv = D.divcode
		   LEFT JOIN CommonMaster E
			   ON E.cmmcode = 'CMM02'
				  AND b.itemunit = E.divcode
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'MPM23'
				  AND b.itemdiv = f.divcode
		   LEFT JOIN CommonMaster G
			   ON G.cmmcode = 'MPM11'
				  AND b.keepingwarehouse = G.divcode
		   LEFT JOIN CommonMaster h
			   ON h.cmmcode = 'CMM02'
				  AND b.contentunit = h.divcode
		   LEFT JOIN CommonMaster i
			   ON i.cmmcode = 'MPM29'
				  AND b.itemformdiv = i.divcode
		   LEFT JOIN CommonMaster j
			   ON j.cmmcode = 'MPM24'
				  AND b.notproductdiv = j.divcode
		   JOIN CommonMaster K
			   ON K.cmmcode = 'CMM55'
				  AND b.productiondiv = K.divcode
		   LEFT JOIN CommonMaster M
			   ON M.cmmcode = 'CMM02'
				  AND b.transunit = M.divcode
	UNION
	--  where  a.approvalcheck = 'Y'  -- 승인완료된 항목조회

	--     and a.usediv = 'Y'   -- 사용중인 항목조회

	--포장제품
	SELECT A.itemcode itemcode, --품목코드
		   A.itemkorname itemkorname, --품목명(국문)
		   M.revisionno revisionno, --품목허가개정번호
		   b.divcode itemdiv, --품목구분
		   b.managecode managecode, --품목구분(시스템)
		   b.divname itemdivname, --품목구분명(*)
		   A.itemshortname itemshortname, --품목명(약명)
		   A.itemengname itemengname, --품목명(영문)
		   c.standarddiv standarddiv, --시험규격코드
		   D.divname standarddivname, --시험규격(*)
		   c.validityperiod validityperiod, --유통기한(월)
		   c.itemunit itemunit, --단위코드
		   E.divname itemunitname, --단위(*)
		   c.keepingmethod keepingmethod, --보관방법
		   A.itemdiv itembranch, --품목분류코드
		   f.divname itembranchname, --품목분류(*)
		   A.keepingwarehouse keepingwarehouse, --보관창고코드
		   G.divname keepingwarehousename, --보관창고(*)
		   NULL internaldiv, --국내외구분코드(원자재/상품)
		   NULL internaldivname, --국내외구분(*)
		   A.enteringrackdiv enteringrackdiv, --입고랙종류코드(원자재/상품)
		   h.divname enteringrackdivname, --입고랙종류(*)
		   A.enteringrackqty enteringrackqty, --입고랙적재량(원자재/상품)
		   'Y' testcheck, --시험여부
		   A.safestockqty safestockqty, --안전재고량
		   A.properstockqty properstockqty, --적정재고량
		   NULL buyperiod, --구매기간
		   M.usediv usediv, --사용여부
		   CASE M.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
		   NULL notusediv, --미사용원인코드
		   NULL notusedivname, --미사용원인(*)
		   A.revisionno itemrevisionid, --관리번호(제조제품)
		   c.contentqty contentqty, --함량Num(제조제품)
		   c.contentunit contentunit, --함량단위코드(제조제품)
		   i.divname contentunitname, --함량단위(*)
		   TO_CHAR(c.contentqty) || i.divname contentqtyname, --함량Text(*)
		   c.BATCHSIZE BATCHSIZE, --배치크기Num(제조제품)
		   TO_CHAR(c.BATCHSIZE) || E.divname batchsizename, --배치크기Text(*)
		   c.itemformdiv itemformdiv, --제품유형코드(제조제품)
		   o.divname itemformdivname, --제품유형(*)
		   c.maxmanageyield maxmanageyield, --관리수율(상한)(제조제품)
		   c.minmanageyield minmanageyield, --관리수율(하한)(제조제품)
		   NULL makingcost, --제조원가(제조,포장)
		   A.docuno docuno, --문서번호(제조,포장)
		   A.productcheck productcheck, --생산여부(제조,포장)
		   A.notproductdiv notproductdiv, --미생산원인코드(제조,포장)
		   j.divname notproductdivname, --미생산원인(*)
		   A.typicalitemcode typicalitemcode, --대표제품코드(포장제품)
		   c.itemkorname typicalitemname, --대표제품명(*)
		   A.packingunitqty packingunitqty, --포장단위량Num(포장제품)
		   TO_CHAR(A.packingunitqty) || E.divname packingunitqtyname, --포장단위Text(*)
		   A.packingtypediv packingtypediv, --포장타입코드(포장제품)
		   K.divname packingtypedivname, --포장타입(*)
		   A.typicalpackingcheck typicalpackingcheck, --포장대표여부(포장제품)
		   A.cartondiv cartondiv, --지함종류코드(포장제품)
		   l.divname cartondivname, --지함종류(*)
		   A.cartonqty cartonqty, --지함적재량(포장제품)
		   A.barcode barcode, --바코드(포장제품)
		   A.minpackingcheck minpackingcheck,
		   c.productiondiv productiondiv,
		   N.divname productiondivname,
		   N.remark productiontype,
		   M.approvalcheck approvalcheck,
		   M.plantcode,
		   c.transqty,
		   NVL(P.divname, ' ') transunitname
	FROM   GoodsStandardRevision M
		   JOIN PackingGoodsMaster A
			   ON M.itemcode = A.typicalitemcode --A.itemcode
				  AND M.itemrevisionid = A.revisionno
		   JOIN CommonMaster b
			   ON b.cmmcode = 'CMM01'
				  AND b.divcode = A.itemdiv
		   JOIN MakingGoodsMaster c
			   ON A.typicalitemcode = c.itemcode
				  AND c.revisionno = (SELECT MAX(MakingGoodsMaster.revisionno)
									  FROM	 MakingGoodsMaster
									  WHERE  MakingGoodsMaster.itemcode = c.itemcode)
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'LMM06'
				  AND D.divcode = c.standarddiv
		   LEFT JOIN CommonMaster E
			   ON E.cmmcode = 'CMM02'
				  AND E.divcode = c.itemunit
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'MPM23'
				  AND f.divcode = c.itemdiv
		   LEFT JOIN CommonMaster G
			   ON G.cmmcode = 'MPM11'
				  AND G.divcode = A.keepingwarehouse
		   LEFT JOIN CommonMaster h
			   ON h.cmmcode = 'MPM08'
				  AND h.divcode = A.enteringrackdiv
		   LEFT JOIN CommonMaster i
			   ON i.cmmcode = 'CMM02'
				  AND i.divcode = c.contentunit
		   LEFT JOIN CommonMaster j
			   ON j.cmmcode = 'MPM24'
				  AND j.divcode = A.notproductdiv
		   LEFT JOIN CommonMaster K
			   ON K.cmmcode = 'MPM72'
				  AND K.divcode = A.packingtypediv
		   LEFT JOIN CommonMaster l
			   ON l.cmmcode = 'MPM67'
				  AND l.divcode = A.cartondiv
		   JOIN CommonMaster N
			   ON N.cmmcode = 'CMM55'
				  AND c.productiondiv = N.divcode
		   LEFT JOIN CommonMaster o
			   ON o.cmmcode = 'MPM29'
				  AND c.itemformdiv = o.divcode
		   LEFT JOIN CommonMaster P
			   ON P.cmmcode = 'CMM02'
				  AND c.transunit = P.divcode
--        where        c.usediv = 'Y'
/
