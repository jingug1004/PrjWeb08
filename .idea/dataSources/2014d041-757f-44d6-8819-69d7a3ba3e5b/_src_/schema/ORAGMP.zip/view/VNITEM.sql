CREATE VIEW VNITEM AS (SELECT a.plantcode,
			a.itemcode,
			NVL(a.itemoldcode, '') AS itemoldcode,
			NVL(a.itemname, '') AS itemname,
			NVL(a.itemsname, '') AS itemsname,
			NVL(a.mitemcode, '') AS mitemcode,
			NVL(a.barcode, '') AS barcode,
			NVL(a.barcodeold, '') AS barcodeold,
			NVL(a.barcodebox, '') AS barcodebox,
			NVL(a.unitqty, 0) AS unitqty,
			NVL(a.unit, '') AS unit,
			NVL(n.divname, '') AS unitnm,
			NVL(a.itemunit, '') AS itemunit,
			NVL(a.firstsaldate, '') AS firstsaldate,
			NVL(a.itemdiv, '') AS itemdiv,
			NVL(b.divname, '') AS itemdivnm,
			NVL(a.drugdiv, '') AS drugdiv,
			NVL(c.divname, '') AS drugdivnm,
			NVL(a.bohdiv, '') AS bohdiv,
			NVL(d.divname, '') AS bohdivnm,
			NVL(a.chbdiv, '') AS chbdiv,
			NVL(E.divname, '') AS chbdivnm,
			NVL(a.formdiv, '') AS formdiv,
			NVL(f.filter2, '') AS formseq --순서
										 ,
			NVL(f.divname, '') AS formdivnm,
			NVL(a.productdiv, '') AS productdiv,
			NVL(G.divname, '') AS productdivnm,
			NVL(a.itemtype, '') AS itemtype,
			NVL(h.divname, '') AS itemtypenm,
			NVL(a.classdiv, '') AS classdiv,
			NVL(i.divname, '') AS classdivnm,
			NVL(a.effectdiv, '') AS effectdiv,
			NVL(j.divname, '') AS effectdivnm,
			NVL(a.itempart, '') AS itempart,
			NVL(K.divname, '') AS itempartnm,
			NVL(a.itemgbdiv, '') AS itemgbdiv,
			NVL(l.divname, '') AS itemgbdivnm,
			NVL(a.groupdiv, '') AS groupdiv,
			NVL(P.divname, '') AS groupdivnm,
			NVL(a.incentiveyn, '') AS incentiveyn,
			NVL(a.mainitemyn, '') AS mainitemyn,
			CASE WHEN NVL(a.incentiveyn, 'N') = 'Y' THEN '인센티브' ELSE '일반' END AS incentiveynnm --인센티브
																										  ,
			CASE WHEN NVL(a.mainitemyn, 'N') = 'Y' THEN '주력' ELSE '일반' END AS mainitemynnm --주력구분
																								  ,
			NVL(a.drugprc, 0) AS drugprc,
			NVL(a.makingcost, 0) AS makingcost,
			COALESCE(M.makediv, a.makediv, '') AS makediv,
			NVL(o.divname, '') AS makedivnm,
			NVL(a.medimaxprc, '') AS medimaxprc,
			NVL(a.medicode, '') AS medicode,
			NVL(a.mediyn, 'N') AS mediyn,
			NVL(a.mediunitqty, 0) AS mediunitqty,
			NVL(a.medichgqty, 0) AS medichgqty,
			CASE WHEN NVL(a.pieceyn, 'N') = '' THEN 'N' ELSE NVL(a.pieceyn, 'N') END AS pieceyn,
			NVL(a.boxcnt, 0) AS boxcnt,
      NVL(a.safeqty, 0) AS safeqty,
      NVL(a.validityperiod, 0) AS validityperiod,
      NVL(a.dyn, 'N') AS dyn --도매가능
                  ,
      NVL(a.yyn, 'N') AS yyn --약국가능
                  ,
      NVL(a.wyn, 'N') AS wyn --의원가능
                  ,
      NVL(a.seq, 999) AS seq,
      NVL(a.buyperiod, 0) AS buyperiod,
      NVL(a.makercode, '') AS maker,
      NVL(uu.custname, NVL(a.makercode, '')) AS makername,
      NVL(a.inboxbarcode, '') AS inboxbarcode,
      a.repreitemcode,
      a.changerate,
      a.empcode_pm
   FROM  CMITEMM a
      LEFT JOIN CMITEMM M ON a.mitemcode = M.itemcode 
                            and a.plantcode = m.plantcode
      LEFT JOIN CMCOMMONM b
        ON a.itemdiv = b.divcode
           AND b.cmmcode = 'CMM01' --제품구분
      LEFT JOIN CMCOMMONM c
        ON a.drugdiv = c.divcode
           AND c.cmmcode = 'CM23' --의약구분
      LEFT JOIN CMCOMMONM d
        ON a.bohdiv = d.divcode
           AND d.cmmcode = 'CM30' --의보구분
      LEFT JOIN CMCOMMONM E
        ON a.chbdiv = E.divcode
           AND E.cmmcode = 'CM28' --처방구분
      LEFT JOIN CMCOMMONM f
        ON a.formdiv = f.divcode
           AND f.cmmcode = 'CM25' --제형
      LEFT JOIN CMCOMMONM G
        ON a.productdiv = G.divcode
           AND G.cmmcode = 'CM40' --생산구분
      LEFT JOIN CMCOMMONM h
        ON a.itemtype = h.divcode
           AND h.cmmcode = 'CM55' --제품유형
      LEFT JOIN CMCOMMONM i
        ON a.classdiv = i.divcode
           AND i.cmmcode = 'CM39' --의약분류
      LEFT JOIN CMCOMMONM j
        ON a.effectdiv = j.divcode
           AND j.cmmcode = 'CM57' --세부구분
      LEFT JOIN CMCOMMONM K
        ON a.itempart = K.divcode
           AND K.cmmcode = 'CM41' --제품종류
      LEFT JOIN CMCOMMONM l
        ON a.itemgbdiv = l.divcode
           AND l.cmmcode = 'CM27' --제품분류
      LEFT JOIN cmcommonm n
        ON a.unit = n.divcode
           AND n.cmmcode = 'CMM02'
      LEFT JOIN cmcommonm o
        ON COALESCE(M.makediv, a.makediv) = o.divcode --제조구분
           AND o.cmmcode = 'CMM55'
      LEFT JOIN cmcommonm P
        ON a.groupdiv = P.divcode --성분구분
           AND P.cmmcode = 'CM29'
      LEFT JOIN CMCUSTM uu ON a.makercode = uu.custcode
   WHERE  a.itemdiv IN ('03', '04', '05'))
/
