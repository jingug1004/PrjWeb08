CREATE VIEW NVMAKINGORDERS AS SELECT a."PLANTCODE",
		   a."ORDERNO",
		   a."ITEMCODE",
		   a."ORDERDIV",
		   a."REVISIONNO",
		   a."LOTNO",
		   a."MANUFACTUREQTY",
		   a."ORDERDATE",
		   a."LOTDATE",
		   a."ORDERDT",
		   a."PRODUCTPREDT",
		   a."VALIDITYPERIOD",
		   a."MANUFACTURESTATUS",
		   a."REQUESTNO",
		   a."TRANSQTY",
		   a."ERPORDERNO",
		   a."SOPREVISIONNO",
		   a."APIPRODUCTIONDIV",
		   a."CHARGEQTY",
		   a."REMARK",
		   a."NOTE",
		   TO_CHAR(b.processenddt, 'YYYY-MM-DD') processenddt
	FROM   MakingOrders a
		   LEFT JOIN (SELECT a.orderno,
							 processenddt
					  FROM	 WorkFlow a
							 JOIN (SELECT	orderno,
											MAX(processseq) maxprocessseq
								   FROM 	WorkFlow
								   GROUP BY orderno) b
								 ON a.orderno = b.orderno
									AND a.processseq = b.maxprocessseq) b
			   ON a.orderno = b.orderno
/
