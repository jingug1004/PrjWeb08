CREATE VIEW VNCUSTSCRT AS SELECT a.plantcode,
		   a.custcode,
		   b.custname custname,
		   b.utdiv utdiv,
		   b.utdivnm utdivnm,
		   e.topdeptcode topdeptcode,
		   e.topdeptname topdeptname,
		   e.predeptcode predeptcode,
       e.predeptname predeptname,
       b.deptcode deptcode,
       e.deptname deptname,
       e.seqtopdeptcode,
       e.seqpredeptcode,
       e.seqdeptcode,
       e.findname findname,
       D.positiondiv positiondiv,
       b.empcode empcode,
       D.empname empname,
       f.divname jikwi,
       NVL(a.seq, 0) seq,
       a.scrtdiv scrtdiv,
       c.divname scrtdivnm,
       a.fixdate fixdate,
       a.expdate expdate,
       a.returndate returndate,
       NVL(a.scrtamt, 0) scrtamt,
       a.guarantor guarantor,
       a.guarantorno guarantorno,
       a.guarantoraddr guarantoraddr,
       a.objectaddr objectaddr,
       a.billno billno,
       a.signyn signyn,
       a.duplicateyn duplicateyn,
       a.taxyn taxyn,
       a.returnyn returnyn,
       a.remark remark,
       a.bankcode bankcode,
       g.divname bankname,
       a.baeseo1 baeseo1,
       a.baeseo2 baeseo2,
       c.filter1 wooryang,
       b.stopdate stopdate,
       b.ceoname ceoname, -- 필드 추가 20140205:이세민
           a.guarantydiv       --보증구분 추가 by 김만수 2017.07.28
  FROM   CMCUSTSCRTD a
       LEFT JOIN vnCUST b ON a.custcode = b.custcode
       LEFT JOIN CMCOMMONM c
         ON a.scrtdiv = c.divcode
          AND c.cmmcode = 'SL04' -- 담보구분
       LEFT JOIN CMEMPM D ON b.empcode = D.empcode
       LEFT JOIN vnDEPT e ON b.deptcode = e.deptcode
       LEFT JOIN CMCOMMONM f
         ON D.positiondiv = f.divcode
          AND f.cmmcode = 'PS29'
       LEFT JOIN CMCOMMONM g
         ON a.bankcode = g.divcode
          AND g.cmmcode = 'PS32'
/
