CREATE VIEW VNPSPAYM AS SELECT D.plantcode plantcode, -- 사업장
		   a.yearmonth, -- 급여년월
		   a.paybonusdiv, -- 급/상여구분
		   NVL(l.divname, '') paybonusdivnm,
		   a.chasoo, -- 차수
		   SUBSTR(a.yearmonth, 1, 4) || '년 ' || SUBSTR(a.yearmonth, 6, 2) || '월-' || TO_CHAR(a.chasoo) || '차' yeargb,
		   a.paybankdiv, -- 지급은행
		   NVL(r.divname, '') paybankdivnm,
		   NVL(D.personid, '') personid,
		   a.payaccno, -- 계좌번호
		   a.payaccempnm, -- 예금주
		   NVL(D.enterdt, '') enterdt, -- 입사일자
		   NVL(D.retiredt, '') retiredt, -- 퇴사일자
		   NVL(E.topdeptcode, '') topdeptcode, -- 부서
		   NVL(E.predeptcode, '') predeptcode, -- 지점
		   a.deptcode, -- 팀
		   NVL(E.topdeptname, '') topdeptname, -- 부서명
		   NVL(E.predeptname, '') predeptname, -- 지점명
		   NVL(E.deptname, '') deptname, -- 팀명
		   NVL(E.findname, '') findname, -- 부서검색
		   a.empcode, -- 사원
		   D.empname, -- 사원명
		   D.workdiv, -- 근무지
		   NVL(S.divname, '') workdivnm, -- 근무지명
		   D.sexdiv, -- 성별
		   NVL(h.divname, '') sexdivnm,
		   a.empdiv, -- 사원구분
		   NVL(i.divname, '') empdivnm,
		   a.paydiv, -- 임금구분
		   NVL(K.divname, '') paydivnm,
		   D.enterdiv, -- 입사구분
		   NVL(P.divname, '') enterdivnm,
		   a.positiondiv, -- 직위
		   NVL(f.divname, '') jikwi,
		   NVL(a.gradediv, '') gradediv, -- 직급
		   NVL(j.divname, '') gradedivnm,
		   a.empstep, -- 호봉
		   a.responsibilitydiv, -- 직종
		   NVL(G.divname, '') responsibilitydivnm,
		   a.classdiv, -- 직책
		   NVL(Q.divname, '') classdivnm,
		   a.familycnt, -- 공제대상가족수
		   a.familycnt20, -- 20세이하 자녀수
		   a.paydate, -- 지급일
		   c.worksdate, -- 근태시작일
		   c.workedate, -- 근태종료일
		   c.bonusrate, -- 상여율
		   c.basepaydiv, -- 상여계산기준임금
		   c.bonussmonth, -- 상여기준시작
		   c.bonusemonth, -- 상여기준종료
		   c.bonususeyn, -- 연봉자일괄상여유무
		   c.bonusempuseyn, -- 연봉자개별상여유무
		   c.bonusratey, -- 연봉자상여율
		   c.bonussmonthy, -- 연봉자상여기준시작
		   c.bonusemonthy, -- 연봉자상여기준종료
		   c.statediv, -- 상태
		   NVL(M.divname, '') statedivnm,
		   a.baseamt, -- 기본급
		   a.bonusamt, -- 상여금
		   a.bonusinamt, -- 인정상여
		   a.suamt, -- 총수당\
		   a.salaryamt, -- 급여
		   a.totpay, -- 총지급액
		   a.ntaxpay, -- 비과세액
		   a.commtimeamt, -- 통상시급
		   a.commdayamt, -- 통상일급
		   a.taxpay, -- 과세대상액
		   a.monpayamt, -- 월정액급여
		   a.dutyday, -- 근무/배송일
		   a.yjhour, -- 연장시간
		   a.yghour, -- 야간시간
		   a.hihour, -- 특근시간
		   a.hiyjhour, -- 특근연장시간
		   a.hiexhour, -- 특근초과시간
		   a.yjamt, -- 연장금액
		   a.ygamt, -- 야간금액
		   a.hiamt, -- 휴일금액
		   a.hiyjamt, -- 휴일초과금액
		   a.hiexamt, -- 휴일초과금액
		   a.ntaxyj, -- 시간외비과세
		   a.ntaxeat, -- 식사비과세
		   a.ntaxcar, -- 차량비과세
		   a.ntaxedu, -- 학자금비과세
		   a.ntaxstu, -- 연구비과세
		   a.ntaxfor, -- 외국인비과세
		   a.ntaxbor, -- 출산보육비과세
		   a.ntaxarea, -- 벽지비과세
		   a.ntaxoutside, -- 외국근로비과세
		   a.pensamt, -- 국민연금
		   a.insuamt, -- 건강보험
		   a.hireamt, -- 고용보험
		   a.incometax, -- 소득세
       a.resitax, -- 주민세
       a.goamt, -- 공제총액
       NVL(a.cashamt, 0) cashamt, -- 현금지급액
       a.payamt, -- 차인지급액
       a.payamt - NVL(cashamt, 0) accamt, -- 계좌이체액
       a.fixyn,
       NVL(a.remark, '') remark,
       NVL(a.trandate, '') trandate,
       NVL(a.transeq, 0) transeq
  FROM   PSPAYM a
       left JOIN PSPAYBONUSM c
         ON a.yearmonth = c.yearmonth
          AND a.paybonusdiv = c.paybonusdiv
          AND a.chasoo = c.chasoo
       left JOIN CMEMPM D
         ON a.empcode = D.empcode
          AND D.empdiv <> '09'
       LEFT JOIN vnDEPT E ON a.deptcode = E.deptcode
       LEFT JOIN CMCOMMONM f
         ON a.positiondiv = f.divcode
          AND UPPER(f.cmmcode) = 'PS29'
       LEFT JOIN CMCOMMONM G
         ON a.responsibilitydiv = G.divcode
          AND UPPER(G.cmmcode) = 'PS07'
       LEFT JOIN CMCOMMONM h
         ON D.sexdiv = h.divcode
          AND UPPER(h.cmmcode) = 'PS30'
       LEFT JOIN CMCOMMONM i
         ON a.empdiv = i.divcode
          AND UPPER(i.cmmcode) = 'PS41'
       LEFT JOIN CMCOMMONM j
         ON a.gradediv = j.divcode
          AND UPPER(j.cmmcode) = 'PS01'
       LEFT JOIN CMCOMMONM K
         ON a.paydiv = K.divcode
          AND UPPER(K.cmmcode) = 'PS50'
       LEFT JOIN CMCOMMONM l
         ON a.paybonusdiv = l.divcode
          AND UPPER(l.cmmcode) = 'PS53'
       LEFT JOIN CMCOMMONM M
         ON c.statediv = M.divcode
          AND UPPER(M.cmmcode) = 'PS55'
       LEFT JOIN CMCOMMONM P
         ON D.enterdiv = P.divcode
          AND UPPER(P.cmmcode) = 'PS09'
       LEFT JOIN CMCOMMONM Q
         ON a.classdiv = Q.divcode
          AND UPPER(Q.cmmcode) = 'PS42'
       LEFT JOIN CMCOMMONM r
         ON a.paybankdiv = r.divcode
          AND UPPER(r.cmmcode) = 'PS32'
       LEFT JOIN CMCOMMONM S
         ON D.workdiv = S.divcode
          AND UPPER(S.cmmcode) = 'PS26'
--        select * from vnPSPayM
/
