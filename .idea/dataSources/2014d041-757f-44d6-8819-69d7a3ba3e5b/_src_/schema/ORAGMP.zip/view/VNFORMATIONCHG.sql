CREATE VIEW VNFORMATIONCHG AS SELECT NVL(a.plantcode, ' ') plantcode,
		   NVL(a.chgdate, ' ') chgdate,
		   NVL(a.predeptcode, ' ') predeptcode,
		   NVL(b.topdeptname, ' ') || ' ' || NVL(b.predeptname, ' ') || ' ' || NVL(b.deptname, ' ') predeptname,
		   NVL(b.findname, ' ') prefindname,
		   NVL(a.chgdeptcode, ' ') chgdeptcode,
		   NVL(c.topdeptname, ' ') || ' ' || NVL(c.predeptname, ' ') || ' ' || NVL(c.deptname, ' ') chgdeptname,
		   NVL(c.findname, ' ') chgfindname,
		   NULLIF(a.insertdt, ' ') insertdt,
		   NVL(a.iempcode, ' ') iempcode
	FROM   SLFORMATIONCHG a
		   LEFT JOIN vnDEPT b
			   ON a.plantcode = b.plantcode
				  AND a.predeptcode = b.deptcode
		   LEFT JOIN vnDEPT c
			   ON a.plantcode = c.plantcode
				  AND a.chgdeptcode = c.deptcode
/
