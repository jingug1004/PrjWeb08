CREATE VIEW VNSTOCKRMALL AS SELECT a.itemcode
		  , --품목코드
		   a.itemkorname
		  , --품목명
		   a.warehousingdate
		  , --입고일자
		   a.warehousingno
		  , --입고번호
		   a.manufacturecode
		  , --제조처코드
		   a.lotno
		  , --제조번호
		   a.lotdate
		  , --제조일자
		   a.validityperiod
		  , --유효일자
		   a.retestdate
		  , --재시험기한
		   a.warehousingstate
		  , --입고상태
		   a.itemunit
		  , --단위
		   a.itemunitname
		  ,a.testno
		  , --시험번호
		   a.cjrate
		  , --시험함량/역가
		   a.cjrateB
		  , --시험함량/역가B
		   a.itemdiv
		  , --원부자재구분
		   a.itemdivname
		  ,a.itembranch
		  , --원부자재분류
		   a.itembranchname
		  ,a.testresult
		  , --시험결과(Y/N/Blank:적합/부적합/진행)
		   a.retestno
		  ,a.inputqty
		  , --입고수량
		   a.inputetcqty
		  , --기타입고량
		   a.outqty
		  , --일반출고량
		   a.weighinguseqty
		  , --칭량작업량
		   a.outwaitqty
		  , --출고대기량
		   a.outputetcqty
		  , --기타출고량(폐기포함)
		   a.unuseqty
		  ,a.asstock
		  , --가용재고
		   a.nowstock
		  , --현재재고
		   a.outrockdiv
		  ,a.testcheck
		  ,a.itemdetaildiv
		  ,a.requestcheck
		  ,a.requestperiod
		  ,a.returnqty
		  , --폐기량
		   a.custcode
		  ,a.testno2
		  ,a.retestcheck
		  ,'Y' usediv
		  ,a.warehousediv
		  ,a.costcenter
          ,a.plantcode
	FROM   nvStockItemAll a
	WHERE  a.itemdiv IN ('01', '02', '03')

--select        a.itemcode                 --품목코드
--            ,a.itemkorname            --품목명
--            ,a.warehousingdate        --입고일자
--            ,a.warehousingno         --입고번호
--            ,a.manufacturecode       --제조처코드
--            ,a.lotno                --제조번호
--            ,a.lotdate                --제조일자
--            ,a.validityperiod        --유효일자
--            ,a.retestdate            --재시험기한
--            ,a.warehousingstate     --입고상태
--            ,a.itemunit                --단위
--            ,a.itemunitname
--            ,a.testno                --시험번호
--            ,a.classifyjudgerate as cjrate        --시험함량/역가
--            ,a.classifyjudgerateB as cjrateB    --시험함량/역가B
--            ,a.itemdiv                --원부자재구분
--            ,a.itemdivname
--            ,a.itembranch            --원부자재분류
--            ,a.itembranchname
--            ,a.testresult            --시험결과(Y/N/Blank:적합/부적합/진행)
--            ,a.retestno
--            ,a.totalwarehousingqty    as inputqty            --입고수량
--            ,isnull(b.inputetcqty,0) as inputetcqty        --기타입고량
--            ,isnull(c.outqty,0) as outqty                --일반출고량
--            ,isnull(e.weighinguseqty,0) as weighinguseqty    --칭량작업량
--            ,isnull(c.outwaitqty,0) as outwaitqty        --출고대기량
--            ,isnull(d.outputetcqty,0) + isnull(f.returnqty,0) as outputetcqty    --기타출고량(폐기포함)
--            ,a.totalwarehousingqty + isnull(b.inputetcqty,0)
--                - isnull(c.outqty,0) - isnull(c.outwaitqty,0) - isnull(d.outputetcqty,0) - isnull(f.returnqty,0)
--                as asstock                                --가용재고
--            ,a.totalwarehousingqty + isnull(b.inputetcqty,0)
--                - isnull(c.outqty,0) - isnull(d.outputetcqty,0) - isnull(f.returnqty,0)
--                as nowstock                                --현재재고
--            ,a.outrockdiv
--            ,a.testcheck
--            ,a.itemdetaildiv
--            ,a.requestcheck
--            ,a.requestperiod
--            ,isnull(f.returnqty,0) as returnqty        --폐기량
--            ,a.custcode
--            ,a.testno2
--            ,isnull(a.retestcheck,'N') as retestcheck
--            ,a.usediv
--from
--    --입고자료(일반)
--    (    select        a.itemcode                 --품목코드
--                    ,b.itemkorname            --품목명
--                    ,convert(nvarchar(10), a.warehousingdt, 121) as warehousingdate    --입고일자
--                    ,a.warehousingno         --입고번호
--                    ,a.manufacturecode       --제조처코드
--                    ,a.lotno                --제조번호
--                    ,a.lotdate                --제조일자
--                    ,a.validityperiod        --유효일자
--                    ,a.retestdate
--                    ,a.warehousingstate     --입고상태
--                    ,b.itemunit                --단위
--                    ,isnull(d.divname,'') as itemunitname
--                    ,a.testno                --시험번호
--                    ,a.classifyjudgerate    --시험함량/역가
--                    ,a.classifyjudgerateB    --시험함량/역가B
--                    ,a.totalwarehousingqty    --입고수량
--                    ,b.itemdiv                --원부자재구분
--                    ,isnull(e.divname,'') as itemdivname
--                    ,b.itembranch            --원부자재분류
--                    ,isnull(f.divname,'') as itembranchname
--                    ,a.testresult            --시험결과
--                    ,a.retestno
--                    ,isnull(a.outrockdiv,'Y') as outrockdiv
--                    ,isnull(b.testcheck,'N') as testcheck
--                    ,f.remark as itemdetaildiv
--                    ,isnull(b.requestcheck,'') as requestcheck
--                    ,isnull(b.requestperiod,0) as requestperiod
--                    ,isnull(a.custcode,'') as custcode
--                    ,isnull(a.testno2,'') as testno2
--                    ,case when isnull(b.requestperiod,'') = '' then 'N' else 'Y' end as  retestcheck
--                    ,b.usediv
--        from         warehousing a
--                    inner join nvItemRM b
--                        on a.itemcode = b.itemcode
--                            and a.warehousingtestresult = 'Y'   --입고검수(적합)
--                    inner join commonmaster d
--                        on b.itemunit = d.divcode and d.cmmcode = 'CMM02'
--                    inner join commonmaster e
--                        on b.itemdiv = e.divcode and e.cmmcode = 'CMM01'
--                    inner join commonmaster f
--                        on b.itembranch = f.divcode and f.cmmcode = 'MPM09'
--                            and f.divcode not in ('10')
--    ) a
--    left join
--    --입고자료(기타)
--    (     select        warehousingno
--                    ,sum(etcinoutnoqty) as inputetcqty
--        from         MaterialEtcInOut
--        where        left(inoutdiv,1) = 'I'
--        group by    warehousingno
--    ) b
--    on a.warehousingno = b.warehousingno
--    left join
--    --출고자료(일반,출고대기)
--    (     select        a.warehousingno
--                    ,sum(a.outqty) as outqty            --출고수량
--                    ,sum(a.outwaitqty) as outwaitqty    --출고대기수량
--        from    (    select        warehousingno
--                                ,case when rowoutstate = '04' then  rowoutorderqty else 0 end as outqty            --출고완료
--                                ,case when rowoutstate <> '04' then  rowoutorderqty else 0 end as outwaitqty    --출고대기
--                    from        TakingOutRowDetail
--                    union        all
--                    select        warehousingno
--                                ,case when materialoutstate = '04' then  materialoutorderqty else 0 end as outqty
--                                ,case when materialoutstate <> '04' then  materialoutorderqty else 0 end as outwaitqty
--                    from        TakingOutMaterialDetail
--                ) a
--        group by    a.warehousingno
--    ) c
--    on a.warehousingno = c.warehousingno
--    left join
--    --출고자료(기타)
--    (     select        warehousingno
--                    ,sum(etcinoutnoqty) as outputetcqty
--        from         MaterialEtcInOut
--        where        left(inoutdiv,1) = 'O'
--        group by    warehousingno
--    ) d
--    on a.warehousingno = d.warehousingno
--    left join
--    --칭량자료(실시간재고)
--    (
--        select        warehousingno
--                    ,sum(subdetailqty) as weighinguseqty
--        from        WeighingSubDetail
--        group by    warehousingno
--    ) e
--    on a.warehousingno = e.warehousingno
--    left join
--    --폐기자료(기타)
--    (
--        select        warehousingno
--                    ,sum(totalwarehousingreturnqty) as returnqty
--        from        WarehousingReturning
--        group by    warehousingno
--    ) f
--    on a.warehousingno = f.warehousingno
--    where a.usediv = 'Y'
/
