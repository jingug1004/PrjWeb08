CREATE VIEW VNPSPAYD AS SELECT D.plantcode plantcode
          , -- 사업장
           a.yearmonth
          , -- 급여년월
           a.paybonusdiv
          , -- 급/상여구분
           NVL(l.divname, ' ') paybonusdivnm
          ,a.chasoo
          , -- 차수
           -- 2017-09-04 아래와 같이 되어 있어서 수정함
           -- SUBSTR(a.yearmonth, 1, 4) || '년 ' || SUBSTR(a.yearmonth, 6, 2) || '월-' || UTILS.CONVERT_TO_VARCHAR2(a.chasoo, 30) || '차' yeargb
           SUBSTR(a.yearmonth, 1, 4) || '년 ' || SUBSTR(a.yearmonth, 6, 2) || '월-' || TO_CHAR(a.chasoo) || '차' yeargb

          ,NVL(e.topdeptcode, ' ') topdeptcode
          , -- 부서
           NVL(e.predeptcode, ' ') predeptcode
          , -- 지점
           a.deptcode
          , -- 팀
           NVL(e.topdeptname, ' ') topdeptname
          , -- 부서명
           NVL(e.predeptname, ' ') predeptname
          , -- 지점명
           NVL(e.deptname, ' ') deptname
          , -- 팀명
           NVL(e.findname, ' ') findname
          , -- 부서검색
           a.empcode
          , -- 사원
           D.empname
          , -- 사원명
           D.workdiv
          , -- 근무지
           NVL(S.divname, ' ') workdivnm
          , -- 근무지명
           D.sexdiv
          , -- 성별
           NVL(h.divname, ' ') sexdivnm
          ,D.enterdiv
          , -- 입사구분
           NVL(p.divname, ' ') enterdivnm
          ,c.paydate
          , -- 지급일
           c.worksdate
          , -- 근태시작일
           c.workedate
          , -- 근태종료일
           c.bonusrate
          , -- 상여율
           c.basepaydiv
          , -- 상여계산기준임금
           c.bonussmonth
          , -- 상여기준시작
           c.bonusemonth
          , -- 상여기준종료
           c.bonususeyn
          , -- 연봉자일괄상여유무
           c.bonusempuseyn
          , -- 연봉자개별상여유무
           c.bonusratey
          , -- 연봉자상여율
           c.bonussmonthy
          , -- 연봉자상여기준시작
           c.bonusemonthy
          , -- 연봉자상여기준종료
           c.statediv
          , -- 상태
           NVL(M.divname, ' ') statedivnm
          ,a.sugodiv
          , -- 수당공제구분
           NVL(N.divname, ' ') sugodivnm
          ,a.sugocode
          , -- 수당공제항목
           o.sugoname
          ,a.amt -- 수당공제액
      FROM PSPAYD a
           JOIN PSPAYBONUSM c
               ON a.yearmonth = c.yearmonth
                  AND a.paybonusdiv = c.paybonusdiv
                  AND a.chasoo = c.chasoo
           JOIN CMEMPM D
               ON a.empcode = D.empcode
                  AND D.empdiv <> '09'
           LEFT JOIN vnDEPT e ON a.deptcode = e.deptcode
           LEFT JOIN CMCOMMONM h
               ON D.sexdiv = h.divcode
                  AND h.cmmcode = 'ps30'
           LEFT JOIN CMCOMMONM l
               ON a.paybonusdiv = l.divcode
                  AND l.cmmcode = 'PS53'
           LEFT JOIN CMCOMMONM M
               ON c.statediv = M.divcode
                  AND M.cmmcode = 'PS55'
           LEFT JOIN CMCOMMONM N
               ON a.sugodiv = N.divcode
                  AND N.cmmcode = 'PS56'
           LEFT JOIN PSSUGOITEMM o
               ON a.sugodiv = o.sugodiv
                  AND a.sugocode = o.sugocode
           LEFT JOIN CMCOMMONM p
               ON D.enterdiv = p.divcode
                  AND p.cmmcode = 'ps09'
           LEFT JOIN CMCOMMONM S
               ON D.workdiv = S.divcode
                  AND S.cmmcode = 'ps26'
--        select * from vnPSPay
/
