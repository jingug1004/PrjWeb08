CREATE VIEW VNRMPITEMMASTER AS SELECT a.itemcode AS itemcode --품목코드
		  ,a.itemdiv AS itemdiv --품목구분
		  ,b.managecode AS managecode --품목구분(시스템)
		  ,b.divname AS itemdivname --품목구분명(*)
		  ,a.itemkorname AS itemkorname --품목명(국문)
		  ,a.itemshortname AS itemshortname --품목명(약명)
		  ,a.itemengname AS itemengname --품목명(영문)
		  ,a.standarddiv AS standarddiv --시험규격코드
		  ,c.divname AS standarddivname --시험규격(*)
		  ,a.validityperiod AS validityperiod --유통기한(월)
		  ,a.itemunit AS itemunit --단위코드
		  ,d.divname AS itemunitname --단위(*)
		  ,a.keepingmethod AS keepingmethod --보관방법
		  ,a.itembranch AS itembranch --품목분류코드
		  ,e.divname AS itembranchname --품목분류(*)
		  ,a.keepingwarehouse AS keepingwarehouse --보관창고코드
		  ,f.divname AS keepingwarehousename --보관창고(*)
		  ,a.internaldiv AS internaldiv --국내외구분코드(원자재/상품)
		  ,g.divname AS internaldivname --국내외구분(*)
		  ,a.enteringrackdiv AS enteringrackdiv --입고랙종류코드(원자재/상품)
		  ,h.divname AS enteringrackdivname --입고랙종류(*)
		  ,a.enteringrackqty AS enteringrackqty --입고랙적재량(원자재/상품)
		  ,a.testcheck AS testcheck --시험여부
		  ,a.safestockqty AS safestockqty --안전재고량
		  ,a.properstockqty AS properstockqty --적정재고량
		  ,a.buyperiod AS buyperiod --구매기간
		  ,a.usediv AS usediv --사용여부
		  ,CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END AS usedivname --사용여부(*)
		  ,a.notusediv AS notusediv --미사용원인코드
		  ,i.usediv AS notusedivname --미사용원인(*)
		  ,e.managecode AS itemdetaildiv
		  ,CASE e.managecode WHEN 'A' THEN '01' WHEN 'B' THEN '02' ELSE '03' END AS itemdetaildiv2
		  ,a.buyunit AS buyunit
		  ,a.customcode AS customcode
		  ,a.orderprice AS orderprice
		  ,a.exchangeunit AS exchangeunit
		  ,a.paydiv AS paydiv
		  ,a.offer AS offer
          ,a.plantcode
	FROM   MaterialsMaster a
		   INNER JOIN CommonMaster b
			   ON b.cmmcode = 'CMM01'
				  AND b.divcode = a.itemdiv
		   LEFT JOIN CommonMaster c
			   ON c.cmmcode = 'LMM06'
				  AND c.divcode = a.standarddiv
		   INNER JOIN CommonMaster d
			   ON d.cmmcode = 'CMM02'
				  AND d.divcode = a.itemunit
		   INNER JOIN CommonMaster e
			   ON e.cmmcode = 'MPM09'
				  AND e.divcode = a.itembranch
       LEFT JOIN CommonMaster f
         ON f.cmmcode = 'MPM11'
          AND f.divcode = a.keepingwarehouse
       INNER JOIN CommonMaster g
         ON g.cmmcode = 'MPM15'
          AND g.divcode = a.internaldiv
       LEFT JOIN CommonMaster h
         ON h.cmmcode = 'MPM08'
          AND h.divcode = a.enteringrackdiv
       LEFT JOIN CommonMaster i
         ON i.cmmcode = 'MPM12'
          AND i.divcode = a.notusediv
  WHERE  e.managecode IN ('A', 'B', 'C')
/
