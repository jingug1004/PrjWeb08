CREATE VIEW VNSALES AS (SELECT a.plantcode,
           a.yymm,
           a.orderdate,
           a.orderseq,
           a.orderno,
           a.saldiv,
           CASE
              WHEN (NVL (a.saldiv, ' ') = 'C01')
                   AND (NVL (a.tasooyn, 'N') = 'N')
              THEN
                 SL18.divname
              WHEN (NVL (a.saldiv, ' ') = 'C01')
                   AND (NVL (a.tasooyn, 'N') = 'Y')
              THEN
                 SL18.divname || '(타)'
              ELSE
                 d.divname
           END
              saldivnm,
           a.tasooyn,
           a.datadiv,
           (e.divname) datadivnm,
           a.coldiv,
           a.orderdiv,
           a.outputdiv,
           (f.divname) outputdivnm,
           a.transferdiv,
           (g.divname) transferdivnm,
           a.custcode,
           (b.custname) custname,
           (b.telno) telno,
           (b.faxno) faxno,
           (b.ceoname) ceoname,
           (b.businessno) businessno,
           (b.POST) POST,
           (b.addr1) addr1,
           (b.addr2) addr2,
           (b.addr1) || ' ' || (b.addr2) addr,
           a.deptcode,
           (h.deptname) deptname,
           a.empcode,
           (h.topdeptcode) topdeptcode,
           (j.topdeptcode) etopdeptcode,
           (h.topdeptname) topdeptname,
           (j.topdeptname) etopdeptname,
           (h.predeptcode) predeptcode,
           (j.predeptcode) epredeptcode,
           (h.predeptname) predeptname,
           (j.predeptname) epredeptname,
           (h.findname) findname,
           (j.findname) efindname,
           (i.positiondiv) positiondiv,
           (u.divname) jikwi,
           (i.empname) empname,
           a.ecustcode,
           (c.custname) ecustname,
           a.edeptcode,
           (j.deptname) edeptname,
           a.eempcode,
           (k.positiondiv) epositiondiv,
           (v.divname) ejikwi,
           (k.empname) eempname,
           a.utdiv,
           (o.divname) utdivnm,
           a.eutdiv,
           (p.divname) eutdivnm,
           a.bnorderno,
           a.taxdate,
           a.tradedate,
           a.appdate,
           a.statediv,
           (l.divname) statedivnm,
           a.remark,
           a.seq,
           a.itemcode,
           (m.itemname) itemname,
           (m.itemunit) unit,
           (m.drugdiv) drugdiv,
           (w.divname) drugdivnm,
           (m.medimaxprc) medimaxprc,
           (m.mitemcode) mitemcode,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN a.salqty
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -a.salqty
              ELSE 0
           END
              salqty,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN a.givqty
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -a.givqty
              ELSE 0
           END
              givqty,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN a.bonusqty
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN -a.bonusqty
              ELSE 0
           END
              bonusqty,
           a.drugprc,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.drugamt)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.drugamt)
              ELSE 0
           END
              drugamt,
           a.makingcost,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.makingamt)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.makingamt)
              ELSE 0
           END
              makingamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.makinggivamt)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.makinggivamt)
              ELSE 0
           END
              makinggivamt,
           a.salprc,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.salamt)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.salamt)
              ELSE 0
           END
              salamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.salvat)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.salvat)
              ELSE 0
           END
              salvat,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.totamt)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.totamt)
              ELSE 0
           END
              totamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.befamt)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.befamt)
              ELSE 0
           END
              befamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.aftamt)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.aftamt)
              ELSE 0
           END
              aftamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.incamt)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.incamt)
              ELSE 0
           END
              incamt,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.totdiscount)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.totdiscount)
              ELSE 0
           END
              totdiscount,
           a.givrate,
           a.befrate,
           a.aftrate,
           a.incrate,
           a.salprc1,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.salamt1)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.salamt1)
              ELSE 0
           END
              salamt1,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.salvat1)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.salvat1)
              ELSE 0
           END
              salvat1,
           CASE
              WHEN SUBSTR (a.saldiv, 0, 1) = 'A' THEN (a.totamt1)
              WHEN SUBSTR (a.saldiv, 0, 1) = 'B' THEN - (a.totamt1)
              ELSE 0
           END
              totamt1,
           CASE
              WHEN a.saldiv = 'C01' AND a.coldiv IN ('01', '02')
              THEN
                 NVL (a.colamt, 0)
              ELSE
                 0
           END
              cashcol,                                                 -- 현금수금
           CASE
              WHEN a.saldiv = 'C01' AND a.coldiv IN ('XZ')
              THEN
                 NVL (a.colamt, 0)
              ELSE
                 0
           END
              changecol,                                               -- 물품대체
           CASE
              WHEN a.saldiv = 'C01' AND a.coldiv IN ('10')
              THEN
                 NVL (a.colamt, 0)
              ELSE
                 0
           END
              bankcol,                                                 -- 은행입금
           CASE
              WHEN a.saldiv = 'C01' AND a.coldiv IN ('21')
              THEN
                 NVL (a.colamt, 0)
              ELSE
                 0
           END
              cardcol,                                                 -- 카드수금
           CASE
              WHEN a.saldiv = 'C01' AND a.coldiv IN ('37', '38')
              THEN
                 NVL (a.colamt, 0)
              ELSE
                 0
           END
              billcol,                                                  --어음수금
           CASE
              WHEN a.saldiv = 'C01' AND condr.divcode IS NULL
              THEN
                 NVL (a.colamt, 0)
              ELSE
                 0
           END
              etccol,                                                   --기타수금
           a.colamt,
           a.sampck,
           a.custprtyn,
           a.outputqty,
           a.recalldiv,
           (x.divname) recalldivnm,
           a.absyn,
           a.pieceyn,
           a.enuriyn,
           CASE
              WHEN a.coldiv LIKE '3%'
              THEN
                 a.paybank                                              --지금은행
              WHEN SUBSTR (a.coldiv, 0, 1) = '1'
              THEN
                 t.bankname || ' ' || t.branchname                      --계좌은행
              WHEN SUBSTR (a.coldiv, 0, 1) = '2' AND NVL (a.divmonth, 0) = 0
              THEN
                 AC17.divname                                            --카드사
              WHEN SUBSTR (a.coldiv, 0, 1) = '2' AND NVL (a.divmonth, 0) > 0
              THEN
                 AC17.divname || ' ' || TO_CHAR (divmonth) || '개월'   --카드사
              ELSE
                 ''
           END
              gubun,
           a.billno,
           a.accountno,
           CASE WHEN a.coldiv LIKE '3%' THEN a.issdate ELSE '' END issdate,
           CASE WHEN a.coldiv LIKE '3%' THEN a.expdate ELSE '' END expdate,
           CASE WHEN a.coldiv LIKE '3%' THEN a.discntdate ELSE '' END
              discntdate,
           a.paybank,
           a.cardcomp,
           AC17.divname cardcompnm,
           a.cardno,
           a.cardokno,
           t.bankname || ' ' || t.branchname accountbanknm,
           a.pda,
           b.areadiv areadiv,
           uu.divname areadivnm,
           (i.retiredt) retiredt,
           (k.retiredt) eretiredt,
           (h.deptgroup) deptgroup,
           (j.deptgroup) edeptgroup,
           (b.custmajorcode) custmajorcode,
           (b.opendate) opendate,
           (b.stopdate) stopdate,
           (c.opendate) eopendate,
           (c.stopdate) estopdate,
           (i.ratediv) ratediv,
           (k.ratediv) eratediv,
           (oo.divname) ratedivnm,
           (pp.divname) eratedivnm,
           (b.ascustcheck) ascustcheck,
           (c.ascustcheck) eascustcheck,
           (h.seqtopdeptcode) seqtopdeptcode,
           (h.seqpredeptcode) seqpredeptcode,
           (h.seqdeptcode) seqdeptcode,
           (j.seqtopdeptcode) eseqtopdeptcode,
           (j.seqpredeptcode) eseqpredeptcode,
           (j.seqdeptcode) eseqdeptcode,
           (ss.divname) orderdivnm,                           --추가 20131120:이세민
           I.PARTDIV    partdiv
      FROM vnSalesend a
           INNER JOIN CMCUSTM b
              ON a.custcode = b.custcode
           INNER JOIN CMCUSTM c
              ON a.ecustcode = c.custcode
           LEFT JOIN CMCOMMONM d
              ON a.saldiv = d.divcode AND d.cmmcode = 'SL10'
           LEFT JOIN CMCOMMONM e
              ON a.datadiv = e.divcode AND e.cmmcode = 'SL11'
           LEFT JOIN CMCOMMONM f
              ON a.outputdiv = f.divcode AND f.cmmcode = 'SL12'
           LEFT JOIN CMCOMMONM g
              ON a.transferdiv = g.divcode AND g.cmmcode = 'SL14'
           left JOIN vnDEPT h
              ON a.deptcode = h.deptcode
           left JOIN CMEMPM i
              ON a.empcode = i.empcode
           left JOIN vnDEPT j
              ON a.edeptcode = j.deptcode
           left JOIN CMEMPM k
              ON a.eempcode = k.empcode
           LEFT JOIN CMCOMMONM l
              ON a.statediv = l.divcode AND l.cmmcode = 'SL17'
           LEFT JOIN CMITEMM m
              ON a.itemcode = m.itemcode
           LEFT JOIN CMCOMMONM n
              ON m.unit = n.divcode AND n.cmmcode = 'CM38'
           LEFT JOIN CMCOMMONM o
              ON a.utdiv = o.divcode AND o.cmmcode = 'CM15'
           LEFT JOIN CMCOMMONM p
              ON a.eutdiv = p.divcode AND p.cmmcode = 'CM15'
           LEFT JOIN CMCOMMONM SL18
              ON a.coldiv = SL18.divcode AND SL18.cmmcode = 'SL18'
           LEFT JOIN CMCOMMONM AC17
              ON a.cardcomp = AC17.divcode AND AC17.cmmcode = 'AC17'
           LEFT JOIN CMACCOUNTM s
              ON a.accountno = s.accountno
           LEFT JOIN CMBANKM t
              ON s.bankcode = t.bankcode
           LEFT JOIN CMCOMMONM u
              ON i.positiondiv = u.divcode AND u.cmmcode = 'PS29'
           LEFT JOIN CMCOMMONM v
              ON k.positiondiv = v.divcode AND v.cmmcode = 'PS29'
           LEFT JOIN CMCOMMONM w
              ON m.drugdiv = w.divcode AND w.cmmcode = 'CM23'
           LEFT JOIN CMCOMMONM x
              ON a.recalldiv = x.divcode AND x.cmmcode = 'SL16'
           LEFT JOIN CMCOMMONM uu
              ON b.areadiv = uu.divcode AND uu.cmmcode = 'CM03'
           LEFT JOIN CMCOMMONM oo
              ON i.ratediv = oo.divcode AND oo.cmmcode = 'SL50'
           LEFT JOIN CMCOMMONM pp
              ON k.ratediv = pp.divcode AND pp.cmmcode = 'SL50'
           LEFT JOIN CMCOMMONM ss
              ON ss.cmmcode = 'SL43' AND a.orderdiv = ss.divcode
           LEFT JOIN (SELECT divcode FROM SLCONDRESULT) condr
              ON a.coldiv = condr.divcode)
/
