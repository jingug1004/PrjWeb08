CREATE VIEW VNPACKINGPRODUCT AS SELECT a.itemcode itemcode, --품목코드
		   a.itemdiv itemdiv, --품목구분
		   b.managecode managecode, --품목구분(시스템)
		   b.divname itemdivname, --품목구분명(*)
		   a.itemkorname itemkorname, --품목명(국문)
		   a.itemshortname itemshortname, --품목명(약명)
		   a.itemengname itemengname, --품목명(영문)
		   c.standarddiv standarddiv, --시험규격코드
		   D.divname standarddivname, --시험규격(*)
		   c.validityperiod validityperiod, --유통기한(월)
		   c.itemunit itemunit, --단위코드
		   e.divname itemunitname, --단위(*)
		   c.keepingmethod keepingmethod, --보관방법
		   c.itemdiv itembranch, --품목분류코드
		   f.divname itembranchname, --품목분류(*)
		   a.keepingwarehouse keepingwarehouse, --보관창고코드
		   g.divname keepingwarehousename, --보관창고(*)
		   NULL internaldiv, --국내외구분코드(원자재/상품)
		   NULL internaldivname, --국내외구분(*)
		   --,a.enteringrackdiv  as enteringrackdiv  --입고랙종류코드(원자재/상품)
		   --,h.divname    as enteringrackdivname --입고랙종류(*)
		   --,a.enteringrackqty  as enteringrackqty  --입고랙적재량(원자재/상품)
		   'Y' testcheck, --시험여부
		   --,a.safestockqty   as safestockqty   --안전재고량
		   --,a.properstockqty  as properstockqty  --적정재고량
		   NULL buyperiod, --구매기간
		   c.usediv usediv, --사용여부
		   CASE c.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
		   NULL notusediv, --미사용원인코드
		   NULL notusedivname, --미사용원인(*)
		   c.revisionno revisionno, --관리번호(제조제품)
		   c.contentqty contentqty, --함량Num(제조제품)
		   c.contentunit contentunit, --함량단위코드(제조제품)
		   i.divname contentunitname, --함량단위(*)
		   fnNumericToString(c.contentqty, 'S') || i.divname contentqtyname, --함량Text(*)
		   c.BATCHSIZE BATCHSIZE, --배치크기Num(제조제품)
		   fnNumericToString(c.BATCHSIZE, 'S') || e.divname batchsizename, --배치크기Text(*)
		   c.itemformdiv itemformdiv, --제품유형코드(제조제품)
		   M.divname itemformdivname, --제품유형(*)
		   c.maxmanageyield maxmanageyield, --관리수율(상한)(제조제품)
		   c.minmanageyield minmanageyield, --관리수율(하한)(제조제품)
		   NULL makingcost, --제조원가(제조,포장)
		   a.docuno docuno, --문서번호(제조,포장)
		   a.productcheck productcheck, --생산여부(제조,포장)
		   a.notproductdiv notproductdiv, --미생산원인코드(제조,포장)
		   j.divname notproductdivname, --미생산원인(*)
		   a.typicalitemcode typicalitemcode, --대표제품코드(포장제품)
		   c.itemkorname typicalitemname, --대표제품명(*)
		   a.packingunitqty packingunitqty, --포장단위량Num(포장제품)
		   fnNumericToString(a.packingunitqty, 'S') || e.divname packingunitqtyname, --포장단위Text(*)
		   a.packingtypediv packingtypediv, --포장타입코드(포장제품)
		   k.divname packingtypedivname, --포장타입(*)
		   a.typicalpackingcheck typicalpackingcheck, --포장대표여부(포장제품)
		   --,a.cartondiv   as cartondiv   --지함종류코드(포장제품)
		   --,l.divname    as cartondivname  --지함종류(*)
		   --,a.cartonqty   as cartonqty   --지함적재량(포장제품)
		   a.barcode barcode, --바코드(포장제품)
		   c.productiondiv productiondiv,
		   a.plantcode
	FROM   PDPACKINGGM a
		   LEFT JOIN (SELECT divcode,
							 divname,
							 managecode
					  FROM	 CommonMaster
					  WHERE  cmmcode = 'CMM01'
							 AND managecode = '04') b
			   ON a.itemcode NOT IN (b.divcode)
		   LEFT JOIN PDMAKINGGM c ON a.typicalitemcode = c.itemcode
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'LMM06'
				  AND D.divcode = c.standarddiv
		   LEFT JOIN CommonMaster e
			   ON e.cmmcode = 'CMM02'
				  AND e.divcode = a.packingunit
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'MPM23'
				  AND f.divcode = c.itemdiv
		   LEFT JOIN CommonMaster g
			   ON g.cmmcode = 'MPM11'
				  AND g.divcode = a.keepingwarehouse
		   --left join CommonMaster h on h.cmmcode = 'MPM08' and h.divcode = a.enteringrackdiv

		   LEFT JOIN CommonMaster i
			   ON i.cmmcode = 'CMM02'
				  AND i.divcode = c.contentunit
		   LEFT JOIN CommonMaster j
			   ON j.cmmcode = 'MPM24'
				  AND j.divcode = a.notproductdiv
		   LEFT JOIN CommonMaster k
			   ON k.cmmcode = 'MPM72'
				  AND k.divcode = a.packingtypediv
		   --left join CommonMaster l on l.cmmcode = 'MPM67' and l.divcode = a.cartondiv

		   LEFT JOIN CommonMaster M
			   ON M.cmmcode = 'CM25'
				  AND M.divcode = c.itemformdiv
	UNION
	--where  a.usediv = 'Y'  --생산중인 항목만 조회

	--상품
	SELECT a.itemcode itemcode, --품목코드
		   a.itemdiv itemdiv, --품목구분
		   b.managecode managecode, --품목구분(시스템)
		   b.divname itemdivname, --품목구분명(*)
		   a.itemkorname itemkorname, --품목명(국문)
		   a.itemshortname itemshortname, --품목명(약명)
		   a.itemengname itemengname, --품목명(영문)
		   NULL standarddiv, --시험규격코드
		   NULL standarddivname, --시험규격(*)
		   a.validityperiod validityperiod, --유통기한(월)
		   a.itemunit itemunit, --단위코드
		   e.divname itemunitname, --단위(*)
		   NULL keepingmethod, --보관방법
		   a.itemdiv itembranch, --품목분류코드
		   NULL itembranchname, --품목분류(*)
		   a.keepingwarehouse keepingwarehouse, --보관창고코드
		   g.divname keepingwarehousename, --보관창고(*)
		   NULL internaldiv, --국내외구분코드(원자재/상품)
		   NULL internaldivname, --국내외구분(*)
		   --,NULL     as enteringrackdiv  --입고랙종류코드(원자재/상품)
		   --,''      as enteringrackdivname --입고랙종류(*)
		   --,NULL     as enteringrackqty  --입고랙적재량(원자재/상품)
		   'N' testcheck, --시험여부
		   --,a.safestockqty   as safestockqty   --안전재고량
		   a.buyperiod buyperiod, --구매기간
		   a.usediv usediv, --사용여부
		   CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
		   NULL notusediv, --미사용원인코드
		   NULL notusedivname, --미사용원인(*)
		   NULL revisionno, --관리번호(제조제품)
		   NULL contentqty, --함량Num(제조제품)
		   NULL contentunit, --함량단위코드(제조제품)
		   NULL contentunitname, --함량단위(*)
		   NULL contentqtyname, --함량Text(*)
       NULL BATCHSIZE, --배치크기Num(제조제품)
       NULL batchsizename, --배치크기Text(*)
       NULL itemformdiv, --제품유형코드(제조제품)
       NULL itemformdivname, --제품유형(*)
       NULL maxmanageyield, --관리수율(상한)(제조제품)
       NULL minmanageyield, --관리수율(하한)(제조제품)
       NULL makingcost, --제조원가(제조,포장)
       NULL docuno, --문서번호(제조,포장)
       NULL productcheck, --생산여부(제조,포장)
       NULL notproductdiv, --미생산원인코드(제조,포장)
       NULL notproductdivname, --미생산원인(*)
       NULL typicalitemcode, --대표제품코드(포장제품)
       NULL typicalitemname, --대표제품명(*)
       a.packingcnt packingunitqty, --포장단위량Num(포장제품)
       fnNumericToString(a.packingcnt, 'S') || g.divname packingunitqtyname, --포장단위Text(*)
       NULL packingtypediv, --포장타입코드(포장제품)
       NULL packingtypedivname, --포장타입(*)
       NULL typicalpackingcheck, --포장대표여부(포장제품)
       --,null     as cartondiv   --지함종류코드(포장제품)
       --,null     as cartondivname  --지함종류(*)
       --,null     as cartonqty   --지함적재량(포장제품)
       NULL barcode, --바코드(포장제품)
       NULL productiondiv,
       a.plantcode
  FROM   ProductMaster a
       LEFT JOIN (SELECT divcode,
               divname,
               managecode
            FROM   CommonMaster
            WHERE  cmmcode = 'CMM01'
               AND managecode = '05') b
         ON a.itemcode NOT IN (b.divcode)
       LEFT JOIN CommonMaster c
         ON c.cmmcode = 'CMM02'
          AND c.divcode = a.itemunit
       LEFT JOIN CommonMaster D
         ON D.cmmcode = 'MPM11'
          AND D.divcode = a.keepingwarehouse
       LEFT JOIN CommonMaster e
         ON e.cmmcode = 'MPM15'
          AND e.divcode = a.internaldiv
       --left join CommonMaster f on f.cmmcode = 'MPM08' and f.divcode = a.enteringrackdiv

       LEFT JOIN CommonMaster g
         ON g.cmmcode = 'CMM02'
          AND g.divcode = a.itemunit
/
