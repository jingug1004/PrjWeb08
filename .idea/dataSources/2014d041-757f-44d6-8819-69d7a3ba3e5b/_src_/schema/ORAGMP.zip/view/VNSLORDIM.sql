CREATE VIEW VNSLORDIM AS SELECT a.plantcode,
		   a.orderdate,
		   a.seq,
		   NVL(a.saldiv, ' ') saldiv,
		   NVL(e.divname, ' ') saldivnm,
		   a.custcode, -- 거래처
		   NVL(b.custname, ' ') custname, -- 거래처명
		   NVL(b.utdiv, ' ') utdiv, -- 거래처 유통
		   NVL(b.utdivnm, ' ') utdivnm, -- 거래처 유통명
		   NVL(b.ceoname, ' ') ceoname, -- 거래처 대표자
		   NVL(b.addr, ' ') addr, -- 거래처 주소
		   NVL(b.topdeptcode, ' ') topdeptcode, -- 거래처 본부
		   NVL(b.topdeptname, ' ') topdeptname, -- 거래처 본부명
		   NVL(b.predeptcode, ' ') predeptcode, -- 거래처 지점
		   NVL(b.predeptname, ' ') predeptname, -- 거래청 지점명
		   b.deptcode, -- 거래처 영업소
		   NVL(b.deptname, ' ') deptname, -- 거래처 영업소명
		   NVL(b.positiondiv, ' ') positiondiv, -- 거래처 사원직위
		   b.empcode, -- 거래처 사원
		   NVL(b.empname, ' ') empname, -- 거래처 사원명
		   NVL(b.jikwi, ' ') jikwi, -- 거래처 사원직위명
		   a.ecustcode, -- 간납처
		   NVL(f.custname, ' ') ecustname, -- 간납처명
		   NVL(f.utdiv, ' ') eutdiv, -- 간납처 유통
		   NVL(f.utdivnm, ' ') eutdivnm, -- 간납처 유통명
		   NVL(f.ceoname, ' ') eceoname, -- 간납처 대표자
		   NVL(f.addr, ' ') eaddr, -- 간납처 주소
		   NVL(f.topdeptcode, ' ') etopdeptcode, -- 간납처 본부
		   NVL(f.topdeptname, ' ') etopdeptname, -- 간납처 본부명
		   NVL(f.predeptcode, ' ') epredeptcode, -- 간납처 지점
		   NVL(f.predeptname, ' ') epredeptname, -- 간납처 지점명
		   f.deptcode edeptcode, -- 간납처 영업소
		   NVL(f.deptname, ' ') edeptname, -- 간납처 영업소명
		   NVL(f.positiondiv, ' ') epositiondiv, -- 간납처 사원직위
		   f.empcode eempcode, -- 간납처 사원
		   NVL(f.empname, ' ') eempname, -- 간납처 사원명
		   NVL(f.jikwi, ' ') ejikwi, -- 간납처 사원직위명
		   a.itemcode,
		   NVL(c.itemname, ' ') itemname,
		   NVL(c.itemunit, ' ') itemunit,
		   NVL(M.drugdiv, ' ') drugdiv, --의약구분(전문,일반...)
		   NVL(M.drugdivnm, ' ') drugdivnm,
		   NVL(M.formdiv, ' ') formdiv, --제형(정제, 주사제...)
		   NVL(M.formdivnm, ' ') formdivnm,
		   NVL(M.itempart, ' ') itempart, --제품종류(제품,상품...)
		   NVL(M.itempartnm, ' ') itempartnm,
		   NVL(M.effectdiv, ' ') effectdiv, --주효능(호흡기용, 소화기용...)
       NVL(M.effectdivnm, ' ') effectdivnm,
       NVL(M.itemgbdiv, ' ') itemgbdiv, --제품분류(일반,향정신성,마약)
       NVL(M.itemgbdivnm, ' ') itemgbdivnm,
       NVL(M.incentiveyn, ' ') incentiveyn,
       NVL(M.mainitemyn, 'N') mainitemyn,
       NVL(M.medimaxprc, ' ') medimaxprc, --주력품목 / 상한금액
       NVL(a.warehouse, ' ') warehouse,
       NVL(a.transferdiv, ' ') transferdiv,
       NVL(a.drugprc, 0) drugprc,
       NVL(a.drugamt, 0) drugamt,
       NVL(c.unitqty, 0) * NVL(salqty, 0) tsalqty,
       NVL(a.salqty, 0) salqty,
       NVL(a.salprc, 0) salprc,
       NVL(a.salamt, 0) salamt,
       NVL(a.salvat, 0) salvat,
       NVL(a.totamt, 0) totamt,
       NVL(a.befrate, 0) befrate,
       NVL(a.aftrate, 0) aftrate,
       NVL(a.befamt, 0) befamt,
       NVL(a.aftamt, 0) aftamt,
       NVL(a.salprc1, 0) salprc1,
       NVL(a.salamt1, 0) salamt1,
       NVL(a.salvat1, 0) salvat1,
       NVL(a.totamt1, 0) totamt1,
       NVL(a.remark, ' ') remark,
       a.statediv,
       NVL(D.divname, ' ') statedivnm,
       a.appdate,
       a.orderno,
       NVL(b.prceditdiv, ' ') prceditdiv,
       NVL(a.pda, 'N') pda,
       NVL(b.findname, ' ') findname,
       NVL(f.findname, ' ') efindname,
       NVL(b.opendate, ' ') opendate,
       NVL(f.opendate, ' ') eopendate,
       NVL(b.deptgroup, ' ') deptgroup,
       NVL(f.deptgroup, ' ') edeptgroup,
       NVL(b.ascustcheck, ' ') ascustcheck,
       NVL(f.ascustcheck, ' ') eascustcheck,
       NVL(t.divname, ' ') transferdivnm
  FROM   SLORDMIM a
       JOIN vnCUST b ON a.custcode = b.custcode
       JOIN CMITEMM c ON a.itemcode = c.itemcode
       LEFT JOIN CMCOMMONM D
         ON a.statediv = D.divcode
          AND D.cmmcode = 'SL17'
       LEFT JOIN CMCOMMONM e
         ON a.saldiv = e.divcode
          AND e.cmmcode = 'SL10'
       LEFT JOIN vnCUST f ON a.ecustcode = f.custcode
       LEFT JOIN vnItem M ON a.itemcode = M.itemcode
       LEFT JOIN CMCOMMONM t
         ON a.transferdiv = t.divcode
          AND t.cmmcode = 'SL14'
/
