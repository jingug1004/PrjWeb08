CREATE VIEW VNAPP AS SELECT a.plantcode, -- isnull(a.plantcode,'') as plantcode
		   a.accountdiv, -- isnull(a.accountdiv,'') as accountdiv
		   NVL(c.divname, ' ') accountdivnm,
		   NVL(D.divname, ' ') GB,
		   a.seq, -- isnull(a.seq,0) as seq
		   NVL(a.resdiv, ' ') resdiv,
		   NVL(e.divname, ' ') resdivnm,
		   (a.deptcode) resdeptcode,
		   NVL(f.deptname, ' ') resdeptname,
		   NVL(f.predeptname, ' ') respredeptname,
		   NVL(b.topdeptcode, ' ') topdeptcode,
		   NVL(b.topdeptname, ' ') topdeptname,
		   NVL(b.predeptcode, ' ') predeptcode,
		   NVL(b.predeptname, ' ') predeptname,
		   NVL(b.deptname, ' ') deptname,
		   NVL(a.empcode, ' ') empcode,
		   NVL(b.empname, ' ') empname,
		   NVL(b.positiondiv, ' ') positiondiv,
		   NVL(b.jikwi, ' ') jikwi
	FROM   SLAPPM a
		   LEFT JOIN vnEMP b ON a.empcode = b.empcode
		   LEFT JOIN CMCOMMONM c
			   ON a.accountdiv = c.divcode
				  AND c.cmmcode = 'SL80'
				  AND c.usediv = 'Y'
		   LEFT JOIN CMCOMMONM D
			   ON c.filter1 = D.divcode
				  AND D.cmmcode = 'SL81'
				  AND D.usediv = 'Y'
		   LEFT JOIN CMCOMMONM e
			   ON a.resdiv = e.divcode
				  AND e.cmmcode = 'SL84'
				  AND e.usediv = 'Y'
		   LEFT JOIN vnDEPT f ON a.deptcode = f.deptcode
/
