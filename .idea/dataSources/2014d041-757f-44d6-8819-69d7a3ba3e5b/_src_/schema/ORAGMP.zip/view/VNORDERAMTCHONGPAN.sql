CREATE VIEW VNORDERAMTCHONGPAN AS (SELECT a.plantcode,
			a.orderdate,
			a.orderseq,
			a.orderno,
			a.saldiv saldiv,
			a.yymm yymm,
			d.divname saldivnm,
			a.datadiv datadiv,
			e.divname datadivnm,
			a.orderdiv orderdiv,
			a.outputdiv outputdiv,
			s.divname outputdivnm,
			a.transferdiv transferdiv,
			t.divname transfernm,
			CASE WHEN b.custdiv = '8' THEN b.custmajorcode ELSE a.custcode END custcode,
			CASE WHEN b.custdiv = '8' THEN bb.custname ELSE b.custname END custname,
			CASE WHEN b.custdiv = '8' THEN bb.addr1 ELSE b.addr1 END addr1,
			CASE WHEN b.custdiv = '8' THEN bb.addr2 ELSE b.addr2 END addr2,
			CASE WHEN b.custdiv = '8' THEN bb.addr1 || ' ' || bb.addr2 ELSE b.addr1 || ' ' || b.addr2 END addr,
			CASE WHEN b.custdiv = '8' THEN bb.telno ELSE b.telno END telno,
			CASE WHEN b.custdiv = '8' THEN bb.POST ELSE b.POST END POST,
			CASE WHEN b.custdiv = '8' THEN bb.utdiv ELSE a.utdiv END utdiv,
			CASE WHEN b.custdiv = '8' THEN bb.utdivnm ELSE o.divname END utdivnm,
			CASE WHEN b.custdiv = '8' THEN bb.findname ELSE h.findname END findname,
			CASE WHEN b.custdiv = '8' THEN bb.topdeptcode ELSE h.topdeptcode END topdeptcode,
			CASE WHEN b.custdiv = '8' THEN bb.topdeptname ELSE h.topdeptname END topdeptname,
			CASE WHEN b.custdiv = '8' THEN bb.predeptcode ELSE h.predeptcode END predeptcode,
			CASE WHEN b.custdiv = '8' THEN bb.predeptname ELSE h.predeptname END predeptname,
			CASE WHEN b.custdiv = '8' THEN bb.deptcode ELSE a.deptcode END deptcode,
			CASE WHEN b.custdiv = '8' THEN bb.deptname ELSE h.deptname END deptname,
			CASE WHEN b.custdiv = '8' THEN bb.empcode ELSE a.empcode END empcode,
			CASE WHEN b.custdiv = '8' THEN bb.empname ELSE i.empname END empname,
			CASE WHEN b.custdiv = '8' THEN bb.positiondiv ELSE i.positiondiv END positiondiv,
			CASE WHEN b.custdiv = '8' THEN bb.jikwi ELSE q.divname END jikwi,
			CASE WHEN b.custdiv = '8' THEN b.custmajorcode ELSE a.ecustcode END ecustcode,
			CASE WHEN b.custdiv = '8' THEN bb.custname ELSE c.custname END ecustname,
			CASE WHEN b.custdiv = '8' THEN bb.addr1 ELSE c.addr1 END eaddr1,
			CASE WHEN b.custdiv = '8' THEN bb.addr2 ELSE c.addr2 END eaddr2,
			CASE WHEN b.custdiv = '8' THEN bb.addr1 || ' ' || bb.addr2 ELSE c.addr1 || ' ' || c.addr2 END eaddr,
			CASE WHEN b.custdiv = '8' THEN bb.telno ELSE c.telno END etelno,
			CASE WHEN b.custdiv = '8' THEN bb.POST ELSE c.POST END epost,
			CASE WHEN b.custdiv = '8' THEN bb.utdiv ELSE a.eutdiv END eutdiv,
			CASE WHEN b.custdiv = '8' THEN bb.utdivnm ELSE p.divname END eutdivnm,
			CASE WHEN b.custdiv = '8' THEN bb.findname ELSE j.findname END efindname,
			CASE WHEN b.custdiv = '8' THEN bb.topdeptcode ELSE j.topdeptcode END etopdeptcode,
			CASE WHEN b.custdiv = '8' THEN bb.topdeptname ELSE j.topdeptname END etopdeptname,
			CASE WHEN b.custdiv = '8' THEN bb.predeptcode ELSE j.predeptcode END epredeptcode,
			CASE WHEN b.custdiv = '8' THEN bb.predeptname ELSE j.predeptname END epredeptname,
			CASE WHEN b.custdiv = '8' THEN bb.deptcode ELSE a.edeptcode END edeptcode,
			CASE WHEN b.custdiv = '8' THEN bb.deptname ELSE j.deptname END edeptname,
			CASE WHEN b.custdiv = '8' THEN bb.empcode ELSE a.eempcode END eempcode,
			CASE WHEN b.custdiv = '8' THEN bb.empname ELSE k.empname END eempname,
			CASE WHEN b.custdiv = '8' THEN bb.positiondiv ELSE k.positiondiv END epositiondiv,
			CASE WHEN b.custdiv = '8' THEN bb.jikwi ELSE r.divname END ejikwi,
			NVL(a.remark, '') remark,
			a.seq,
			a.itemcode,
			m.itemname itemname,
			m.mitemcode mitemcode,
			NVL(m.unitqty, 0) unitqty,
			m.itemunit unit,
			a.taxdate taxdate,
			a.tradedate tradedate,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salqty, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salqty, 0) ELSE 0 END salqty,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.givqty, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.givqty, 0) ELSE 0 END givqty,
			NVL(a.drugprc, 0) drugprc,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.drugamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.drugamt, 0) ELSE 0 END drugamt,
			NVL(a.makingcost, 0) makingcost,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.makingamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.makingamt, 0) ELSE 0 END makingamt,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.makinggivamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.makinggivamt, 0) ELSE 0 END makinggivamt,
			NVL(a.salprc, 0) salprc,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salamt, 0) ELSE 0 END salamt,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salvat, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salvat, 0) ELSE 0 END salvat,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.totamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.totamt, 0) ELSE 0 END totamt,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.befamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.befamt, 0) ELSE 0 END befamt,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.aftamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.aftamt, 0) ELSE 0 END aftamt,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.incamt, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.incamt, 0) ELSE 0 END incamt,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.totdiscount, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.totdiscount, 0) ELSE 0 END totdiscount,
			NVL(a.givrate, 0) givrate,
			NVL(a.befrate, 0) befrate,
			NVL(a.aftrate, 0) aftrate,
			NVL(a.incrate, 0) incrate,
			NVL(a.salprc1, 0) salprc1,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salamt1, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salamt1, 0) ELSE 0 END salamt1,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.salvat1, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.salvat1, 0) ELSE 0 END salvat1,
			CASE WHEN SUBSTR(a.saldiv, 0, 1) = 'A' THEN NVL(a.totamt1, 0) WHEN SUBSTR(a.saldiv, 0, 1) = 'B' THEN -NVL(a.totamt1, 0) ELSE 0 END totamt1,
			a.custprtyn custprtyn,
			NVL(a.outputqty, 0) outputqty,
			a.pieceyn pieceyn,
			a.enuriyn enuriyn,
			a.statediv,
			z.divname statedivnm,
			a.appdate,
			a.fixdate fixdate,
			a.fixseq fixseq,
			a.pda pda,
			m.itemdiv itemdiv,
			i.retiredt retiredt,
			k.retiredt eretiredt,
			h.deptgroup deptgroup,
			j.deptgroup edeptgroup,
			a.warehouse warehouse,
			i.workdiv workdiv,
			CASE WHEN b.custdiv = '8' THEN bb.stopdate ELSE b.stopdate END stopdate,
			CASE WHEN b.custdiv = '8' THEN bb.stopdate ELSE c.stopdate END estopdate,
			b.ascustcheck ascustcheck,
			c.ascustcheck eascustcheck,
			CASE WHEN b.custdiv = '8' THEN bb.opendate ELSE b.opendate END opendate,
			CASE WHEN b.custdiv = '8' THEN bb.opendate ELSE c.opendate END eopendate,
			m.makercode maker,
			uu.custname makername,
			a.lotno lotno,
			a.expdate expdate,
			b.areadiv areadiv,
			qq.divname areadivnm,
			c.areadiv eareadiv,
			rr.divname eareadivnm,
			b.custdiv,
			h.seqtopdeptcode,
			h.seqpredeptcode,
			h.seqdeptcode,
			j.seqtopdeptcode eseqtopdeptcode,
			j.seqpredeptcode eseqpredeptcode,
			j.seqdeptcode eseqdeptcode,
			b.sagodiv, --필드추가 20131220:이세민
			c.sagodiv esagodiv --필드추가 20131220:이세민
	 FROM	vnOrdersEnd a
			LEFT JOIN CMCUSTM b ON a.custcode = b.custcode
			LEFT JOIN CMCUSTM c ON a.ecustcode = c.custcode
			LEFT JOIN vnCUST bb ON b.custmajorcode = bb.custcode
			LEFT JOIN CMCOMMONM d
				ON a.saldiv = d.divcode
				   AND d.cmmcode = 'SL10'
			LEFT JOIN CMCOMMONM e
				ON a.datadiv = e.divcode
				   AND e.cmmcode = 'SL11'
			LEFT JOIN vndept h ON a.deptcode = h.deptcode
			LEFT JOIN CMEMPM i ON a.empcode = i.empcode
			LEFT JOIN vndept j ON a.edeptcode = j.deptcode
			LEFT JOIN CMEMPM k ON a.eempcode = k.empcode
			LEFT JOIN CMITEMM m ON a.itemcode = m.itemcode --and itemdiv <> '3'--판매제품
			LEFT JOIN CMCOMMONM o
				ON a.utdiv = o.divcode
				   AND o.cmmcode = 'CM15'
			LEFT JOIN CMCOMMONM p
				ON a.eutdiv = p.divcode
				   AND p.cmmcode = 'CM15'
			LEFT JOIN CMCOMMONM q
				ON i.positiondiv = q.divcode
				   AND q.cmmcode = 'PS29'
      LEFT JOIN CMCOMMONM r
        ON k.positiondiv = r.divcode
           AND r.cmmcode = 'PS29'
      LEFT JOIN CMCOMMONM s
        ON a.outputdiv = s.divcode
           AND s.cmmcode = 'SL12'
      LEFT JOIN CMCOMMONM t
        ON a.transferdiv = t.divcode
           AND t.cmmcode = 'SL14'
      LEFT JOIN CMCOMMONM z
        ON a.statediv = z.divcode
           AND z.cmmcode = 'SL17'
      LEFT JOIN CMCUSTM uu ON m.makercode = uu.custcode
      LEFT JOIN CMCOMMONM qq
        ON b.areadiv = qq.divcode
           AND qq.cmmcode = 'CM03'
      LEFT JOIN CMCOMMONM rr
        ON c.areadiv = rr.divcode
           AND rr.cmmcode = 'CM03')
/
