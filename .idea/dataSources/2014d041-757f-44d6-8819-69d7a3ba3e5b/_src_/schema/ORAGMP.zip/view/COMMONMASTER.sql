CREATE VIEW COMMONMASTER AS SELECT cmmcode,
		   divcode,
		   filter1 managecode,
		   cmmname,
		   divname,
		   remark,
		   usediv,
		   majorname
	FROM   CMCOMMONM
/
