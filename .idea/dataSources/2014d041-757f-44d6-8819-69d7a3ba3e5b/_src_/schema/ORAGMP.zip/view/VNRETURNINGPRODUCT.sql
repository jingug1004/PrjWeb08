CREATE VIEW VNRETURNINGPRODUCT AS SELECT a.itemcode itemcode, --품목코드
		   a.itemkorname itemkorname, --품목명(국문)
		   a.itemengname itemengname, --품목명(영문)
		   c.standarddiv standarddiv, --시험규격코드
		   D.divname standarddivname, --시험규격(*)
		   c.validityperiod validityperiod, --유통기한(월)
		   c.itemunit itemunit, --단위코드
		   e.divname itemunitname, --단위(*)
		   a.usediv usediv, --사용여부
		   CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
		   a.revisionno itemrevisionid, --관리번호(제조제품)
		   c.contentqty contentqty, --함량Num(제조제품)
		   c.contentunit contentunit, --함량단위코드(제조제품)
		   c.itemformdiv itemformdiv, --제품유형코드(제조제품)
		   o.divname itemformdivname, --제품유형(*)
		   a.typicalitemcode typicalitemcode, --대표제품코드(포장제품)
		   a.packingunitqty packingunitqty, --포장단위량Num(포장제품)
		   fnNumericToString(a.packingunitqty, 'S') + a.packingunit packingunitqtyname, --포장단위Text(*)
		   a.packingtypediv packingtypediv, --포장타입코드(포장제품)
		   k.divname packingtypedivname, --포장타입(*)
		   a.typicalpackingcheck typicalpackingcheck, --포장대표여부(포장제품)
		   a.barcode barcode, --바코드(포장제품)
		   c.productiondiv productiondiv,
		   N.divname productiondivname,
		   'N' minunitgoods
	FROM   PDPACKINGGM a
		   LEFT JOIN PDGSTANDARDREVISIOND M
			   ON M.itemcode = a.itemcode
				  AND M.itemrevisionid = a.revisionno
		   JOIN PDMAKINGGM c
			   ON a.typicalitemcode = c.itemcode
				  AND c.revisionno = (SELECT MAX(PDMAKINGGM.revisionno)
									  FROM	 PDMAKINGGM
									  WHERE  PDMAKINGGM.itemcode = c.itemcode)
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'LMM06'
				  AND D.divcode = c.standarddiv
		   LEFT JOIN CommonMaster e
			   ON e.cmmcode = 'CMM02'
				  AND e.divcode = c.itemunit
		   LEFT JOIN CommonMaster o
			   ON o.cmmcode = 'MPM29'
				  AND c.itemformdiv = o.divcode
		   LEFT JOIN CommonMaster k
			   ON k.cmmcode = 'MPM72'
				  AND k.divcode = a.packingtypediv
		   JOIN CommonMaster N
			   ON N.cmmcode = 'CMM55'
				  AND c.productiondiv = N.divcode
	UNION
	SELECT a.itemcode itemcode, --품목코드
		   a.itemkorname itemkorname, --품목명(국문)
		   a.itemengname itemengname, --품목명(영문)
		   NULL standarddiv, --시험규격코드
		   NULL standarddivname, --시험규격(*)
		   a.validityperiod validityperiod, --유통기한(월)
		   a.itemunit itemunit, --단위코드
		   b.divname itemunitname, --단위(*)
		   'Y' usediv, --사용여부
		   '사용중' usedivname, --사용여부(*)
		   NULL itemrevisionid, --관리번호(제조제품)
		   NULL contentqty, --함량Num(제조제품)
		   NULL contentunit, --함량단위코드(제조제품)
		   NULL itemformdiv, --제품유형코드(제조제품)
		   NULL itemformdivname, --제품유형(*)
		   NULL typicalitemcode, --대표제품코드(포장제품)
		   a.packingcnt packingunitqty, --포장단위량Num(포장제품)
		   fnNumericToString(a.packingcnt, 'S') + a.itemunit packingunitqtyname, --포장단위Text(*)
		   a.packingtypediv packingtypediv, --포장타입코드(포장제품)
		   c.divname packingtypedivname, --포장타입(*)
		   NULL typicalpackingcheck, --포장대표여부(포장제품)
		   a.barcode barcode, --바코드(포장제품)
		   NULL productiondiv,
		   NULL productiondivname,
		   NULL minunitgoods
	FROM   ProductMaster a
		   LEFT JOIN CommonMaster b
			   ON b.cmmcode = 'CMM02'
				  AND a.itemunit = b.divcode
		   LEFT JOIN CommonMaster c
			   ON c.cmmcode = 'MPM72'
				  AND a.packingtypediv = c.divcode
	WHERE  SUBSTR(itemcode, 0, 1) NOT IN ('999999998', '999999999')
/
