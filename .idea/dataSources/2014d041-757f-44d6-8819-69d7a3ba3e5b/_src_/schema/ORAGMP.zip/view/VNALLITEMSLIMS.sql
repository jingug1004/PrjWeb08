CREATE VIEW VNALLITEMSLIMS AS SELECT a.itemcode
		  , --품목코드
		   a.itemdiv
		  , --품목구분
		   a.itemcode typicalitemcode
		  , --대표품목코드
		   a.itemkorname
		  , --품목명
		   a.itemshortname
		  , --품목명(약명)
		   a.itemengname
		  , --품목명
		   a.itemunit
		  , --단위
		   '' transunit
		  , --제재단위(제조)
		   a.standarddiv
		  , --규격
		   a.validityperiod
		  , --사용기간(월)
		   '' batchsizename
		  , --배치사이즈명(포장)
		   0 packingunitqty
		  , --포장단위량
		   '' itemformdiv
		  , --제형(제조)
		   itembranch itembranchdiv
		  , --분류
		   b.divname keepingmethod
		  ,0 soprevisionid
		  , --제품표준서관리번호(표준운영절차)
		   0 itemrevisionid
		  , --제품표준서관리번호(허가사항)
		   0 prescriptionid
		  , --제품표준서관리번호(BOM)
		   0 teststandardid
		  , --제품표준서관리번호(시험규격)
		   a.itemdivname itemdivname
		  ,'' packingunit
		  ,W.workroomname keepingwarehouse
          ,a.plantcode
          ,a.informaltest              --약식시험여부
          ,a.testperiod
	FROM   nvItemRM a
		   LEFT JOIN CMCOMMONM b
			   ON b.cmmcode = 'CMM30'
				  AND a.keepingmethod = b.divcode
		   LEFT JOIN (SELECT workroomcode
							,workroomname
					  FROM	 WorkroomMaster
					  WHERE  SUBSTR(workroomcode, 0, 1) = '0'
							 AND workroomdiv IN ('23', '52', '53', '55')) W
			   ON a.keepingwarehouse = W.workroomcode
	WHERE  a.itemdiv IN ('01', '02')
	UNION ALL
	--제조제품
	--제품표준서에 의한 조회가 이루어 지도록 수정해야 한다.
	--제품표준서에 등록이 안된 항목은 조회할 수 없도록 수정한다.

	SELECT b.itemcode
		  ,b.itemdiv
		  ,b.itemcode
		  ,b.itemkorname
		  ,b.itemengname
		  ,b.itemshortname
		  ,b.itemunit
		  ,b.transunit
		  ,b.standarddiv
		  ,b.validityperiod
		  ,fnNumericToString(b.BATCHSIZE, 'S')
		  ,0
		  ,b.itemformdiv
		  ,b.itemdiv
		  ,c.divname keepingmethod
		  ,0
		  ,0
		  ,0
		  ,0
		  ,b.itemdivname
		  ,''
		  ,W.workroomname keepingwarehouse
          ,b.plantcode
          ,b.informaltest              --약식시험여부
          ,0 testperiod
	FROM   nvItemGP b
		   LEFT JOIN CMCOMMONM c
			   ON c.cmmcode = 'CMM30'
				  AND b.keepingmethod = c.divcode
		   LEFT JOIN (SELECT workroomcode
							,workroomname
					  FROM	 WorkroomMaster
					  WHERE  SUBSTR(workroomcode, 0, 1) = '0'
							 AND workroomdiv IN ('23', '52', '53', '55')) W
			   ON b.keepingwarehouse = W.workroomcode
	WHERE  b.itemdiv IN ('03')
	UNION ALL
	--포장제품
	SELECT a.itemcode
		  ,a.itemdiv
		  ,a.typicalitemcode
		  ,a.itemkorname
		  ,a.itemengname
		  ,a.itemshortname
		  ,c.itemunit
		  ,''
		  ,c.standarddiv
		  ,c.validityperiod
		  ,fnNumericToString(a.packingunitqty, 'S2')
		  ,a.packingunitqty
		  ,''
		  ,c.itemdiv
		  ,D.divname keepingmethod
		  ,0
		  ,0
		  ,0
		  ,0
		  ,a.itemdivname
		  ,c.itemunit
		  ,W.workroomname keepingwarehouse
          ,a.plantcode
          ,a.informaltest              --약식시험여부
          ,0 testperiod
	FROM   nvItemGP a
		   JOIN nvItemGP c
			   ON a.typicalitemcode = c.itemcode
				  AND a.itemdiv = '04'
				  AND c.itemdiv = '03'
		   LEFT JOIN CMCOMMONM D
			   ON D.cmmcode = 'CMM30'
				  AND c.keepingmethod = D.divcode
		   LEFT JOIN (SELECT workroomcode
							,workroomname
					  FROM	 WorkroomMaster
					  WHERE  SUBSTR(workroomcode, 0, 1) = '0'
							 AND workroomdiv IN ('23', '52', '53', '55')) W
			   ON c.keepingwarehouse = W.workroomcode
	UNION ALL
	--상품
	SELECT a.itemcode
		  ,a.itemdiv
		  ,a.typicalitemcode
		  ,a.itemkorname
		  ,a.itemengname
		  ,a.itemshortname
		  ,a.itemunit
		  ,''
		  ,a.standarddiv
		  ,a.validityperiod
		  ,fnNumericToString(a.packingunitqty, 'S2')
		  ,a.packingunitqty
		  ,''
		  ,a.itemdiv
		  ,D.divname keepingmethod
		  ,0
		  ,0
		  ,0
		  ,0
		  ,a.itemdivname
		  ,a.itemunit
		  ,W.workroomname keepingwarehouse
          ,a.plantcode
          ,a.informaltest              --약식시험여부
          ,0 testperiod
	FROM   nvItemGP a
		   LEFT JOIN CMCOMMONM D
			   ON D.cmmcode = 'CMM30'
				  AND a.keepingmethod = D.divcode
		   LEFT JOIN (SELECT workroomcode
							,workroomname
					  FROM	 WorkroomMaster
					  WHERE  SUBSTR(workroomcode, 0, 1) = '0'
							 AND workroomdiv IN ('23', '52', '53', '55')) W
			   ON a.keepingwarehouse = W.workroomcode
	WHERE  a.itemdiv = '05'
/
