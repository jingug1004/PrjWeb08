CREATE VIEW VNPSYEARBASEM AS SELECT NVL(a.plantcode, '') plantcode,
		   NVL(a.taxyear, '') taxyear,
		   NVL(a.yeardiv, '') yeardiv, -- 0:연말정산, 1:중도퇴사
		   NVL(a.empcode, '') empcode,
		   NVL(D.enterdt, '') enterdt, -- 입사일자
		   NVL(D.retiredt, '') retiredt, -- 퇴사일자
		   NVL(e.topdeptcode, '') topdeptcode, -- 부서
		   NVL(e.predeptcode, '') predeptcode, -- 지점
		   D.deptcode, -- 팀
		   NVL(e.topdeptname, '') topdeptname, -- 부서명
		   NVL(e.predeptname, '') predeptname, -- 지점명
		   NVL(e.deptname, '') deptname, -- 팀명
		   NVL(e.findname, '') findname, -- 부서검색
		   D.empname, -- 사원명
		   D.workdiv, -- 근무지
		   NVL(S.divname, '') workdivnm, -- 근무지명
		   D.sexdiv, -- 성별
		   NVL(h.divname, '') sexdivnm,
		   D.empdiv, -- 사원구분
		   NVL(i.divname, '') empdivnm,
		   D.enterdiv, -- 입사구분
		   NVL(p.divname, '') enterdivnm,
		   D.positiondiv, -- 직위
		   NVL(f.divname, '') jikwi,
		   D.gradediv, -- 직급
		   NVL(j.divname, '') gradedivnm,
		   D.empstep, -- 호봉
		   D.responsibilitydiv, -- 직종
		   NVL(g.divname, '') responsibilitydivnm,
		   D.classdiv, -- 직책
		   NVL(Q.divname, '') classdivnm,
		   NVL(a.receiptdt, '') receiptdt,
		   NVL(a.liveyn, '') liveyn,
		   NVL(a.nationyn, '') nationyn,
		   NVL(a.fixtaxyn, '') fixtaxyn,
		   NVL(a.nationcode, '') nationcode,
		   NVL(a.worksdt, '') worksdt,
		   NVL(a.workedt, '') workedt,
		   NVL(a.reducesdt, '') reducesdt,
		   NVL(a.reduceedt, '') reduceedt,
		   NVL(a.payamt, 0) payamt,
		   NVL(a.bonusamt, 0) bonusamt,
		   NVL(a.bonusinamt, 0) bonusinamt,
		   NVL(a.stockamt, 0) stockamt,
		   NVL(a.wooriinamt, 0) wooriinamt,
		   NVL(a.ntaxyj, 0) ntaxyj,
		   NVL(a.ntaxeat, 0) ntaxeat,
		   NVL(a.ntaxcar, 0) ntaxcar,
		   NVL(a.ntaxedu, 0) ntaxedu,
		   NVL(a.ntaxstu, 0) ntaxstu,
		   NVL(a.ntaxfor, 0) ntaxfor,
		   NVL(a.ntaxbor, 0) ntaxbor,
		   NVL(a.ntaxarea, 0) ntaxarea,
		   NVL(a.ntaxoutside, 0) ntaxoutside,
		   NVL(a.ntaxetc, 0) ntaxetc,
		   CASE WHEN NVL(a.pensamt, 0) < 0 THEN 0 ELSE NVL(a.pensamt, 0) END pensamt,
		   CASE WHEN NVL(a.insuamt, 0) < 0 THEN 0 ELSE NVL(a.insuamt, 0) END insuamt,
		   CASE WHEN NVL(a.hireamt, 0) < 0 THEN 0 ELSE NVL(a.hireamt, 0) END hireamt,
		   NVL(a.retireamt, 0) retireamt,
		   NVL(a.incometax, 0) incometax,
		   NVL(a.resitax, 0) resitax,
		   NVL(a.houseimamt, 0) houseimamt, --주택임차차입금원리금상환액 주택임차차입금원리금상환액 대출기관(2011년)
		   NVL(a.houseimamtg, 0) houseimamtg, --없음       주택임차차입금원리금상환액 거주자
		   NVL(a.housejuamt15, 0) housejuamt15, --장기주택저당차입금이자상환액 15~29년
		   NVL(a.housejuamt30, 0) housejuamt30, --30년 이상
		   NVL(a.housejuamt, 0) housejuamt, --15년 미만
		   NVL(a.housegoamt, 0) housegoamt, --
		   NVL(a.houseetcamt, 0) houseetcamt, --
		   NVL(a.penspersamt, 0) penspersamt,
		   NVL(a.penssaveamt, 0) penssaveamt,
		   NVL(a.corpsubamt, 0) corpsubamt,
		   NVL(a.corpinvamt09, 0) corpinvamt09, --중소기업창업투자조합출자등 소득공제2009년이전
		   NVL(a.corpinvamt, 0) corpinvamt, --중소기업창업투자조합출자등 소득공제
		   NVL(a.corpinvamt1, 0) corpinvamt1, --중소기업창업투자조합출자등 소득공제2013
		   NVL(a.corpinvamt2, 0) corpinvamt2, --중소기업창업투자조합출자등 소득공제2014
		   NVL(a.corpinvdamt, 0) corpinvdamt, --중소기업창업투자조합출자등 직접투자
		   NVL(a.corpinvdamt1, 0) corpinvdamt1, --중소기업창업투자조합출자등 직접투자2013
		   NVL(a.corpinvdamt2, 0) corpinvdamt2, --중소기업창업투자조합출자등 직접투자2014
		   NVL(a.woorioutamt, 0) woorioutamt,
		   NVL(a.employmaintain, 0) employmaintain, --고용유지
		   NVL(a.longtermstock, 0) longtermstock, --장기집합투자증권
		   NVL(a.housebondamt, 0) housebondamt, --청약저축
		   NVL(a.houseworkamt, 0) houseworkamt, --근로자주택마련저축
		   NVL(a.houseallamt, 0) houseallamt, --주택청약종합저축
		   NVL(a.housesaveamt, 0) housesaveamt, --장기주택마련저축
		   NVL(a.stocksaveamt1, 0) stocksaveamt1,
		   NVL(a.stocksaveamt2, 0) stocksaveamt2,
		   NVL(a.stocksaveamt3, 0) stocksaveamt3,
		   NVL(a.houseloanamt, 0) houseloanamt,
		   NVL(a.taxcombamt, 0) taxcombamt,
		   NVL(a.fortaxamt, 0) fortaxamt,
		   NVL(a.fortax, 0) fortax,
		   NVL(a.cnreduceamt, 0) cnreduceamt, -- 청년취업세액공제
		   NVL(a.cnreduceamt1, 0) cnreduceamt1, -- 청년취업세액공제
		   NVL(a.cnpayamt, 0) cnpayamt, -- 청년취업세액공제
		   NVL(a.repayamt, 0) repayamt, -- 주택임차상환금공제
		   NVL(a.householder, '') householder
	FROM   PSYEARBASEM a
		   JOIN CMEMPM D ON a.empcode = D.empcode
		   LEFT JOIN vnDEPT e ON D.deptcode = e.deptcode
		   LEFT JOIN CMCOMMONM f
			   ON D.positiondiv = f.divcode
				  AND UPPER(f.cmmcode) = 'PS29'
		   LEFT JOIN CMCOMMONM g
			   ON D.responsibilitydiv = g.divcode
				  AND UPPER(g.cmmcode) = 'PS07'
		   LEFT JOIN CMCOMMONM h
			   ON D.sexdiv = h.divcode
				  AND UPPER(h.cmmcode) = 'PS30'
		   LEFT JOIN CMCOMMONM i
			   ON D.empdiv = i.divcode
				  AND UPPER(i.cmmcode) = 'PS41'
		   LEFT JOIN CMCOMMONM j
			   ON D.gradediv = j.divcode
				  AND UPPER(j.cmmcode) = 'PS01'
		   LEFT JOIN CMCOMMONM p
			   ON D.enterdiv = p.divcode
				  AND UPPER(p.cmmcode) = 'PS09'
		   LEFT JOIN CMCOMMONM Q
			   ON D.classdiv = Q.divcode
				  AND UPPER(Q.cmmcode) = 'PS42'
		   LEFT JOIN CMCOMMONM S
			   ON D.workdiv = S.divcode
				  AND UPPER(S.cmmcode) = 'PS26'
/
