CREATE VIEW VNWAREHOUSESUM AS SELECT	 a.plantcode,
			 a.warehouse,
			 MAX(c.whname) whname,
			 a.LOCATION,
			 MAX(b.mitemcode) mitemcode,
			 a.itemcode,
			 MAX(b.itemname) itemname,
			 MAX(b.itemunit) unit,
			 MAX(NVL(b.drugdiv, '')) drugdiv, --의약구분(전문,일반...)
			 MAX(NVL(b.drugdivnm, '')) drugdivnm,
			 MAX(NVL(b.formdiv, '')) formdiv, --제형(정제, 주사제...)
			 MAX(NVL(b.formdivnm, '')) formdivnm,
			 MAX(NVL(b.itempart, '')) itempart, --제품종류(제품,상품...)
			 MAX(NVL(b.itempartnm, '')) itempartnm,
			 MAX(NVL(b.effectdiv, '')) effectdiv, --주효능(호흡기용, 소화기용...)
			 MAX(NVL(b.effectdivnm, '')) effectdivnm,
			 lotno,
			 lotdate,
			 expdate,
			 SUM(qty) qty,
			 SUM(qty) * MAX(NVL(b.drugprc, 0)) amt,
			 '' specdiv,
			 '' specdivnm,
			 '' skipyn,
			 MAX(b.productdiv) productdiv,
			 MAX(b.drugprc) drugprc,
			 MAX(b.makingcost) makingcost,
			 MAX(c.workdiv) workdiv,
			 MAX(NVL(E.divname, '')) workdivnm,
			 MAX(NVL(b.maker, '')) maker,
			 MAX(NVL(b.makername, '')) makername,
			 MAX(NVL(f.locname, '')) locname
             ,A.STOPYN
	FROM	 SLWAREHOUSEM a
			 JOIN vnItem b ON a.itemcode = b.itemcode
			 LEFT JOIN SLSTOREHOUSEM c ON a.warehouse = c.warehouse
			 LEFT JOIN CMCOMMONM E
				 ON c.workdiv = E.divcode
					AND E.cmmcode = 'PS26'
			 LEFT JOIN SLLOCATIONM f
				 ON a.warehouse = f.warehouse
					AND RTRIM(a.LOCATION) = RTRIM(f.LOCATION)
	GROUP BY a.plantcode,
			 a.warehouse,
			 a.LOCATION,
			 a.itemcode,
			 a.lotno,
			 a.lotdate,
			 a.expdate,
             a.stopyn
/
