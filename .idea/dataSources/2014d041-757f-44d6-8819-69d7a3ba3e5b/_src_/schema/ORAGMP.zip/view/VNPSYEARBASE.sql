CREATE VIEW VNPSYEARBASE AS SELECT NVL(a.plantcode, '') plantcode,
		   NVL(d.nationdiv, '') nationdiv,
		   NVL(a.taxyear, '') taxyear,
		   NVL(a.yeardiv, '') yeardiv, -- 0:연말정산, 1:중도퇴사
		   NVL(a.empcode, '') empcode,
		   --NVL(d.personid, '') personid,
       NVL(utl_i18n.raw_to_char(d.personid ,'AL32UTF8'),'') personid,
		   NVL(d.enterdt, '') enterdt, -- 입사일자
		   NVL(d.retiredt, '') retiredt, -- 퇴사일자
		   NVL(e.topdeptcode, '') topdeptcode, -- 부서
		   NVL(e.predeptcode, '') predeptcode, -- 지점
		   d.deptcode, -- 팀
		   NVL(e.topdeptname, '') topdeptname, -- 부서명
		   NVL(e.predeptname, '') predeptname, -- 지점명
		   NVL(e.deptname, '') deptname, -- 팀명
		   NVL(e.findname, '') findname, -- 부서검색
		   d.empname, -- 사원명
		   d.workdiv, -- 근무지
		   NVL(s.divname, '') workdivnm, -- 근무지명
		   d.sexdiv, -- 성별
		   NVL(h.divname, '') sexdivnm,
		   d.empdiv, -- 사원구분
		   NVL(i.divname, '') empdivnm,
		   d.enterdiv, -- 입사구분
		   NVL(p.divname, '') enterdivnm,
		   d.positiondiv, -- 직위
		   NVL(f.divname, '') jikwi,
		   d.gradediv, -- 직급
		   NVL(j.divname, '') gradedivnm,
		   d.empstep, -- 호봉
		   d.responsibilitydiv, -- 직종
		   NVL(g.divname, '') responsibilitydivnm,
		   d.classdiv, -- 직책
		   NVL(q.divname, '') classdivnm,
		   NVL(a.receiptdt, '') receiptdt,
		   NVL(a.liveyn, '') liveyn,
		   NVL(a.nationyn, '') nationyn,
		   NVL(a.fixtaxyn, '') fixtaxyn,
		   NVL(a.nationcode, '') nationcode,
		   NVL(a.worksdt, '') worksdt,
		   NVL(a.workedt, '') workedt,
		   NVL(a.reducesdt, '') reducesdt,
		   NVL(a.reduceedt, '') reduceedt,
		   NVL(qq.precompcnt, 0) precompcnt,
		   NVL(a.payamt, 0) + NVL(qq.taxpay, 0) AS payamt,
		   NVL(a.bonusamt, 0) + NVL(qq.bonusamt, 0) AS bonusamt,
		   NVL(a.bonusinamt, 0) + NVL(qq.bonusinamt, 0) bonusinamt,
		   NVL(a.stockamt, 0) + NVL(qq.stockamt, 0) stockamt,
		   NVL(a.wooriinamt, 0) + NVL(qq.wooriinamt, 0) wooriinamt,
		   NVL(a.dretoverlmtamt, 0) + NVL(qq.dretoverlmtamt, 0) dretoverlmtamt,
		   NVL(a.payamt, 0) payamtju,
		   NVL(a.bonusamt, 0) bonusamtju,
		   NVL(a.bonusinamt, 0) bonusinamtju,
		   NVL(a.stockamt, 0) stockamtju,
		   NVL(a.wooriinamt, 0) wooriinamtju,
		   NVL(a.dretoverlmtamt, 0) dretoverlmtamtju,
		   NVL(qq.taxpay, 0) payamtjo,
		   NVL(qq.bonusamt, 0) bonusamtjo,
		   NVL(qq.bonusinamt, 0) bonusinamtjo,
		   NVL(qq.stockamt, 0) stockamtjo,
		   NVL(qq.wooriinamt, 0) wooriinamtjo,
		   NVL(qq.dretoverlmtamt, 0) dretoverlmtamtjo,
			 NVL(a.ntaxyj, 0)
		   + NVL(qq.ntaxyj, 0)
		   + NVL(a.ntaxeat, 0)
		   + NVL(qq.ntaxeat, 0)
		   + NVL(a.ntaxcar, 0)
		   + NVL(qq.ntaxcar, 0)
		   + NVL(a.ntaxedu, 0)
		   + NVL(qq.ntaxedu, 0)
		   + NVL(a.ntaxstu, 0)
		   + NVL(qq.ntaxstu, 0)
		   + NVL(a.ntaxfor, 0)
		   + NVL(qq.ntaxfor, 0)
		   + NVL(a.ntaxbor, 0)
		   + NVL(qq.ntaxbor, 0)
		   + NVL(a.ntaxarea, 0)
		   + NVL(qq.ntaxarea, 0)
		   + NVL(a.ntaxoutside, 0)
		   + NVL(qq.ntaxoutside, 0)
		   + NVL(a.ntaxetc, 0)
		   + NVL(qq.ntaxetc, 0)
			   ntaxtot,
		   NVL(a.ntaxyj, 0) + NVL(a.ntaxeat, 0) + NVL(a.ntaxcar, 0) + NVL(a.ntaxedu, 0) + NVL(a.ntaxstu, 0) + NVL(a.ntaxfor, 0) + NVL(a.ntaxbor, 0) + NVL(a.ntaxarea, 0) + NVL(a.ntaxoutside, 0) + NVL(a.ntaxetc, 0) ntaxtotju,
		   NVL(qq.ntaxyj, 0) + NVL(qq.ntaxeat, 0) + NVL(qq.ntaxcar, 0) + NVL(qq.ntaxedu, 0) + NVL(qq.ntaxstu, 0) + NVL(qq.ntaxfor, 0) + NVL(qq.ntaxbor, 0) + NVL(qq.ntaxarea, 0) + NVL(qq.ntaxoutside, 0) + NVL(qq.ntaxetc, 0) ntaxtotjo,
		   NVL(a.pensamt, 0) pensamtju,
		   NVL(qq.pensamt, 0) pensamtjo,
		   NVL(a.insuamt, 0) insuamtju,
		   NVL(qq.insuamt, 0) insuamtjo,
		   NVL(a.hireamt, 0) hireamtju,
		   NVL(qq.hireamt, 0) hireamtjo,
		   NVL(a.retireamt, 0) retireamtju,
		   NVL(qq.retireamt, 0) retireamtjo,
		   CASE WHEN (NVL(a.pensamt, 0) + NVL(qq.pensamt, 0)) < 0 THEN 0 ELSE (NVL(a.pensamt, 0) + NVL(qq.pensamt, 0)) END pensamt, --국민연금
		   CASE WHEN (NVL(a.insuamt, 0) + NVL(qq.insuamt, 0)) < 0 THEN 0 ELSE (NVL(a.insuamt, 0) + NVL(qq.insuamt, 0)) END insuamt, --건강보험
		   CASE WHEN (NVL(a.hireamt, 0) + NVL(qq.hireamt, 0)) < 0 THEN 0 ELSE (NVL(a.hireamt, 0) + NVL(qq.hireamt, 0)) END hireamt, --고용보험
		   NVL(a.retireamt, 0) + NVL(qq.retireamt, 0) retireamt, --퇴직연금
		   NVL(a.incometax, 0) + NVL(qq.incometax, 0) incometax, -- 소득세
		   NVL(a.resitax, 0) + NVL(qq.resitax, 0) resitax, -- 주민세
		   NVL(a.incometax, 0) incometaxju, -- 주근무처소득세
		   NVL(qq.incometax, 0) incometaxjo, -- 종근무처소득세
		   NVL(a.resitax, 0) resitaxju, -- 주근무처주민세
		   NVL(qq.resitax, 0) resitaxjo, -- 종근무처주민세
		   NVL(qq.farmtax, 0) farmtaxjo, -- 종근무처농특세
		   NVL(bonin, 0) bonin, -- 본인
		   NVL(wife, 0) wife, -- 배우자
		   NVL(boo, 0) boo, -- 부양
		   NVL(kyung, 0) kyung, -- 경로
		   NVL(jang, 0) jang, -- 장애
		   NVL(yang, 0) yang, -- 양육
		   NVL(chul, 0) chul, -- 출산
		   NVL(single, 0) single, -- 한부모
		   NVL(woman, 0) woman, --  부녀자
		   NVL(familycnt20, 0) familycnt20, -- 다자녀추가
		   NVL(insu, 0) insu, --보험료
		   NVL(insuobs, 0) insuobs, --장애보험료
		   NVL(medibonin, 0) medibonin, -- 본인/장애/65이상 의료비
		   NVL(medigibon, 0) medigibon, -- 그외 기본공제자 의료비
		   NVL(mediboninobs, 0) + NVL(medigibonobs, 0) mediobs, -- 그외 기본공제자 의료비 장애
		   NVL(edubonin, 0) edubonin, --본인교육비
		   NVL(eduuniv, 0) eduuniv, --대학생교육비
		   NVL(eduhigh, 0) eduhigh, --초중고
		   NVL(edumi, 0) edumi, --미취학
		   NVL(eduobs, 0) eduobs, --장애인
		   NVL(eduunivcnt, 0) eduunivcnt, --대학생교육비
		   NVL(eduhighcnt, 0) eduhighcnt, --초중고
		   NVL(edumicnt, 0) edumicnt, --미취학
		   NVL(eduobscnt, 0) eduobscnt, --장애인
		   NVL(cardamt, 0) cardamt, -- 카드
		   NVL(cardjik, 0) cardjik, -- 직불/선불카드
		   NVL(cash, 0) cash, -- 현금영수증
		   NVL(jiro, 0) jiro, -- 지로납부
		   NVL(jeontong, 0) jeontong, -- 전통시장
		   NVL(publictran, 0) publictran, -- 전통시장
		   NVL(a.houseimamt, 0) houseimamt, --주택임차차입금원리금상환액 주택임차차입금원리금상환액 대출기관(2011년)
		   CASE WHEN NVL(a.houseimamtg, 0) = 0 THEN NVL(hh.houseimamtg, 0) ELSE NVL(a.houseimamtg, 0) END houseimamtg, --없음 주택임차차입금원리금상환액 거주자
		   CASE WHEN NVL(a.housemonamt, 0) = 0 THEN NVL(hh.housemonamt, 0) ELSE NVL(a.housemonamt, 0) END housemonamt, --없음 월세공제
		   NVL(a.housejuamt15, 0) housejuamt15, --장기주택저당차입금이자상환액 15~29년
		   NVL(a.housejuamt30, 0) housejuamt30, --30년 이상
		   0 housejuamt0410, -- 없음 (2011)
		   NVL(a.housejuamt, 0) housejuamt, --15년 미만
		   NVL(a.housegoamt, 0) housegoamt, -- (2012년 이후 차입분)고정금리？비거치상환 대출
		   NVL(a.houseetcamt, 0) houseetcamt, -- (2012년 이후 차입분)기타 대출
		   NVL(a.housegobiamt151, 0) housegobiamt151, --2015년 이후 15년 이상 (고정금리이면서 비거치상환대출)
		   NVL(a.housegobiamt152, 0) housegobiamt152, --2015년 이후 15년 이상 (고정금리이거나 비거치상환대출)
		   NVL(a.houseetcamt15, 0) houseetcamt15, --2015년 이후 15년 이상 (그밖의 대출)
		   NVL(a.housegobiamt153, 0) housegobiamt153, --2015년 이후 10년~15년(고정금리이거나 비거치상환대출)
		   NVL(givebub, 0) givebub, -- 법정기부금
		   NVL(givejung, 0) givejung, -- 정치자금
		   NVL(givemoon, 0) givemoon, -- 문화예술
		   NVL(givetuk, 0) givetuk, -- 특례(50%)
		   NVL(givegong, 0) givegong, --  공익법인신탁기부
		   NVL(givewoori, 0) givewoori, -- 우리사주(30%)
		   NVL(givejong, 0) givejong, -- 종교단체
		   NVL(givejongno, 0) givejongno, -- 비종교단체
		   NVL(giveetc, 0) giveetc, -- 기타
		   NVL(a.penspersamt, 0) penspersamt, -- 개인연금저축
		   NVL(a.penssaveamt, 0) penssaveamt, -- 연금저축
		   NVL(a.corpsubamt, 0) corpsubamt,
		   NVL(a.corpinvamt09, 0) corpinvamt09, --중소기업창업투자조합출자등 소득공제2009년이전
		   NVL(a.corpinvamt, 0) corpinvamt, --중소기업창업투자조합출자등 소득공제
		   NVL(a.corpinvamt1, 0) corpinvamt1, --중소기업창업투자조합출자등 소득공제2013
		   NVL(a.corpinvamt2, 0) corpinvamt2, --중소기업창업투자조합출자등 소득공제2014
		   NVL(a.corpinvdamt, 0) corpinvdamt, --중소기업창업투자조합출자등 직접투자
		   NVL(a.corpinvdamt1, 0) corpinvdamt1, --중소기업창업투자조합출자등 직접투자2013
		   NVL(a.corpinvdamt2, 0) corpinvdamt2, --중소기업창업투자조합출자등 직접투자2014
		   NVL(a.woorioutamt, 0) woorioutamt, --우리사주조합출연금
		   NVL(a.employmaintain, 0) employmaintain, --고용유지
		   NVL(a.longtermstock, 0) longtermstock, --장기집합투자증권
		   NVL(a.housebondamt, 0) housebondamt, --청약저축
		   NVL(a.houseworkamt, 0) houseworkamt, --근로자주택마련저축
		   NVL(a.houseallamt, 0) houseallamt, --주택청약종합저축
		   NVL(a.housesaveamt, 0) housesaveamt, --장기주택마련저축
		   NVL(a.stocksaveamt1, 0) stocksaveamt1,
		   NVL(a.stocksaveamt2, 0) stocksaveamt2,
		   NVL(a.stocksaveamt3, 0) stocksaveamt3,
		   NVL(a.houseloanamt, 0) houseloanamt,
		   NVL(a.taxcombamt, 0) taxcombamt,
		   NVL(a.fortaxamt, 0) fortaxamt,
		   NVL(a.fortax, 0) fortax,
		   NVL(a.cnreduceamt, 0) + NVL(qq.cnreduceamt, 0) cnreduceamt,
		   NVL(a.cnreduceamt1, 0) + NVL(qq.cnreduceamt1, 0) cnreduceamt1, -- 청년취업세액공제
		   NVL(a.cnreduceamt2, 0) + NVL(qq.cnreduceamt2, 0) cnreduceamt2,
		   NVL(a.cnreduceamt, 0) cnreduceamtju,
		   NVL(a.cnreduceamt1, 0) cnreduceamt1ju,
		   NVL(a.cnreduceamt2, 0) cnreduceamt2ju,
		   NVL(qq.cnreduceamt, 0) cnreduceamtjo,
		   NVL(qq.cnreduceamt1, 0) cnreduceamt1jo,
		   NVL(qq.cnreduceamt2, 0) cnreduceamt2jo,
		   NVL(a.cnpayamt, 0) + NVL(qq.cnpayamt, 0) cnpayamt,
		   NVL(a.cnpayamt, 0) cnpayamtju,
		   NVL(qq.cnpayamt, 0) cnpayamtjo,
		   NVL(a.householder, '') householder,
		   NVL(d.birthday, '') birthday,
		   NVL(a.repayamt, '') repayamt, -- 주택임차상환금공제
		   NVL(b.useamtl, 0) useamtl,
		   NVL(b.useamt, 0) AS useamt,
		   NVL(b.useamt15, 0) useamt15,
		   NVL(b.taxcreditamtl, 0) AS taxcreditamtl,
		   NVL(b.taxcreditamth, 0) AS taxcreditamth,
		   NVL(b.taxcreditamt14, 0) taxcreditamt14,
		   NVL(b.taxcreditamt15, 0) taxcreditamt15
	FROM   PSYEARBASEM a
		   LEFT JOIN (SELECT   plantcode,
							   taxyear,
							   empcode,
							   SUM(CASE WHEN famdiv = 'K01' THEN 1 ELSE 0 END) bonin -- 본인
																					,
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND wifeyn = 'Y'
									   THEN
										   1
									   ELSE
										   0
								   END)
								   wife, -- 배우자
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND famdiv NOT IN ('K01', 'K02')
									   THEN
										   1
									   ELSE
										   0
								   END)
								   boo, -- 부양
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND oldyn = 'Y'
									   THEN
										   1
									   ELSE
										   0
								   END)
								   kyung, -- 경로
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND obsyn = 'Y'
									   THEN
										   1
									   ELSE
										   0
								   END)
								   jang, -- 장애
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND bringyn = 'Y'
											AND NVL(famdiv, '') IN ('K05', 'K50')
									   THEN
										   1
									   ELSE
										   0
								   END)
								   yang, -- 양육
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND bornyn = 'Y'
											AND NVL(famdiv, '') IN ('K05', 'K50')
									   THEN
										   1
									   ELSE
										   0
								   END)
								   chul, -- 출산
							   SUM(CASE
									   WHEN famdiv = 'K01'
											AND singleparentyn = 'Y'
									   THEN
										   1
									   ELSE
										   0
								   END)
								   single, -- 한부모
							   SUM(CASE
									   WHEN famdiv = 'K01'
											AND womanyn = 'Y'
											AND NVL(singleparentyn, '') <> 'Y'
									   THEN
										   1
									   ELSE
										   0
								   END)
								   woman, --  부녀자
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND NVL(famdiv, '') IN ('K05', 'K50')
									   THEN
										   1
									   ELSE
										   0
								   END)
								   familycnt20, -- 다자녀추가
							   SUM(CASE WHEN baseyn = 'Y' THEN NVL(insuamtnat, 0) + NVL(insuamtetc, 0) ELSE 0 END) insu, --보험료
							   SUM(CASE WHEN baseyn = 'Y' THEN NVL(insuobsamtnat, 0) + NVL(insuobsamtetc, 0) ELSE 0 END) insuobs, --장애보험료
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND famdiv = 'K01'
											AND edudiv = '1'
									   THEN
										   NVL(eduamtnat, 0) + NVL(eduamtetc, 0)
									   ELSE
										   0
								   END)
								   edubonin, --본인교육비
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND famdiv <> 'K01'
											AND edudiv = '2'
									   THEN
										   NVL(eduamtnat, 0) + NVL(eduamtetc, 0)
									   ELSE
										   0
								   END)
								   eduuniv, --대학생교육비
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND famdiv <> 'K01'
											AND edudiv = '2'
									   THEN
										   1
									   ELSE
										   0
								   END)
								   eduunivcnt, --대학생교육비수
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND famdiv <> 'K01'
											AND edudiv = '3'
									   THEN
										   NVL(eduamtnat, 0) + NVL(eduamtetc, 0)
									   ELSE
										   0
								   END)
								   eduhigh, --초중고
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND famdiv <> 'K01'
											AND edudiv = '3'
									   THEN
										   1
									   ELSE
										   0
								   END)
								   eduhighcnt, --초중고수
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND famdiv <> 'K01'
											AND edudiv = '4'
									   THEN
										   NVL(eduamtnat, 0) + NVL(eduamtetc, 0)
									   ELSE
										   0
								   END)
								   edumi, --미취학
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND famdiv <> 'K01'
											AND edudiv = '4'
									   THEN
										   1
									   ELSE
										   0
								   END)
								   edumicnt, --미취학수
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND famdiv <> 'K01'
											AND obsyn = 'Y'
											AND edudiv = '5'
									   THEN
										   NVL(eduamtnat, 0) + NVL(eduamtetc, 0)
									   ELSE
										   0
								   END)
								   eduobs, --장애인
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND famdiv <> 'K01'
											AND obsyn = 'Y'
											AND edudiv = '5'
									   THEN
										   1
									   ELSE
										   0
								   END)
								   eduobscnt, --장애인수
							   SUM(NVL(cardamtnat, 0) + NVL(cardamtetc, 0)) cardamt, -- 카드
							   SUM(NVL(cardamtjiknat, 0) + NVL(cardamtjiketc, 0)) cardjik, -- 직불/선불카드
							   SUM(NVL(cashamtnat, 0)) cash, -- 현금영수증
							   SUM(NVL(giroamt, 0)) jiro, -- 지로납부
							   SUM(NVL(jeontongamtnat, 0) + NVL(jeontongamtetc, 0)) jeontong, -- 전통시장
							   SUM(NVL(publicamtnat, 0) + NVL(publicamtetc, 0)) publictran, -- 대중교통
							   SUM(CASE WHEN famdiv = 'K01' THEN NVL(useamtl, 0) ELSE 0 END) useamtl, -- 본인
							   SUM(CASE WHEN famdiv = 'K01' THEN NVL(useamt, 0) ELSE 0 END) useamt, -- 본인
							   SUM(CASE WHEN famdiv = 'K01' THEN NVL(useamt15, 0) ELSE 0 END) useamt15, -- 본인
							   SUM(CASE WHEN famdiv = 'K01' THEN NVL(taxcreditamtl, 0) ELSE 0 END) taxcreditamtl, -- 본인
							   SUM(CASE WHEN famdiv = 'K01' THEN NVL(taxcreditamth, 0) ELSE 0 END) taxcreditamth, -- 본인
							   SUM(CASE WHEN famdiv = 'K01' THEN NVL(taxcreditamt14, 0) ELSE 0 END) taxcreditamt14, -- 본인
							   SUM(CASE WHEN famdiv = 'K01' THEN NVL(taxcreditamt15, 0) ELSE 0 END) taxcreditamt15 -- 본인
					  FROM	   PSYEARFAMM
					  GROUP BY plantcode, taxyear, empcode) b
			   ON a.taxyear = b.taxyear
				  AND a.empcode = b.empcode
		   LEFT JOIN (SELECT   a.plantcode,
							   a.taxyear,
							   a.empcode,
							   SUM(CASE
									   WHEN nvl(persondiv,'1') = '1'
											AND obsyn <> 'Y'
									   THEN
										   mediamt
									   ELSE
										   0
								   END)
								   medibonin, -- 본인/65이상 의료비
							   SUM(CASE
									   WHEN persondiv = '1'
											AND obsyn = 'Y'
									   THEN
										   mediamt
									   ELSE
										   0
								   END)
								   mediboninobs, -- 본인/65이상 의료비 장애
							   SUM(CASE
									   WHEN persondiv = '2'
											AND obsyn <> 'Y'
									   THEN
										   mediamt
									   ELSE
										   0
								   END)
								   medigibon, -- 그외 기본공제자
							   SUM(CASE
									   WHEN persondiv = '2'
											AND obsyn = 'Y'
									   THEN
										   mediamt
									   ELSE
										   0
								   END)
								   medigibonobs -- 그외 기본공제자 장애
					  FROM	   PSYEARMEDIM a
							   JOIN PSYEARFAMM b
								   ON a.taxyear = b.taxyear
									  AND a.personid = b.fampersonid
									  AND a.empcode = b.empcode
					  GROUP BY a.plantcode, a.taxyear, a.empcode) c
			   ON a.taxyear = c.taxyear
				  AND a.empcode = c.empcode
		   LEFT JOIN (SELECT   a.plantcode,
							   a.taxyear,
							   a.empcode,
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND givediv = '10'
									   THEN
										   NVL(a.giveamt, 0) + NVL(a.giveamtnat, 0)
									   ELSE
										   0
								   END)
								   givebub, -- 법정기부금
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND givediv = '20'
									   THEN
										   NVL(a.giveamt, 0) + NVL(a.giveamtnat, 0)
									   ELSE
										   0
								   END)
								   givejung, -- 정치자금
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND givediv = '21'
									   THEN
										   NVL(a.giveamt, 0) + NVL(a.giveamtnat, 0)
									   ELSE
										   0
								   END)
								   givemoon, -- 문화예술
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND givediv IN ('30')
									   THEN
										   NVL(a.giveamt, 0) + NVL(a.giveamtnat, 0)
									   ELSE
										   0
								   END)
								   givetuk, -- 특례(50%)
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND givediv IN ('31')
									   THEN
										   NVL(a.giveamt, 0) + NVL(a.giveamtnat, 0)
									   ELSE
										   0
								   END)
								   givegong, -- 공익법인신탁
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND givediv IN ('42')
									   THEN
										   NVL(a.giveamt, 0) + NVL(a.giveamtnat, 0)
									   ELSE
										   0
								   END)
								   givewoori, -- 우리사주(30%)
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND givediv IN ('41')
									   THEN
										   NVL(a.giveamt, 0) + NVL(a.giveamtnat, 0)
									   ELSE
										   0
								   END)
								   givejong, -- 종교단체
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND givediv IN ('40')
									   THEN
										   NVL(a.giveamt, 0) + NVL(a.giveamtnat, 0)
									   ELSE
										   0
								   END)
								   givejongno -- 비종교단체
											 ,
							   SUM(CASE
									   WHEN baseyn = 'Y'
											AND givediv IN ('50')
									   THEN
										   NVL(a.giveamt, 0) + NVL(a.giveamtnat, 0)
									   ELSE
										   0
								   END)
								   giveetc -- 기타
					  FROM	   PSYEARGIVEM a
							   JOIN PSYEARFAMM b
								   ON a.taxyear = b.taxyear
									  AND a.personid = b.fampersonid
									  AND a.empcode = b.empcode
					  GROUP BY a.plantcode, a.taxyear, a.empcode) zz
			   ON a.taxyear = zz.taxyear
				  AND a.empcode = zz.empcode
		   LEFT JOIN (SELECT   plantcode,
							   taxyear,
							   empcode,
							   COUNT(*) precompcnt,
							   SUM(NVL(payamt, 0)) payamt,
							   SUM(NVL(payamt, 0)) - (SUM(NVL(ntaxyj, 0)) + SUM(NVL(ntaxeat, 0)) + SUM(NVL(ntaxcar, 0)) + SUM(NVL(ntaxedu, 0)) + SUM(NVL(ntaxstu, 0)) + SUM(NVL(ntaxfor, 0)) + SUM(NVL(ntaxbor, 0)) + SUM(NVL(ntaxarea, 0)) + SUM(NVL(ntaxoutside, 0)) + SUM(NVL(ntaxetc, 0))) taxpay, --+sum
							   SUM(NVL(bonusamt, 0)) bonusamt,
							   SUM(NVL(bonusinamt, 0)) bonusinamt,
							   SUM(NVL(stockamt, 0)) stockamt,
							   SUM(NVL(wooriamt, 0)) wooriinamt,
							   SUM(NVL(dretoverlmtamt, 0)) dretoverlmtamt,
							   SUM(NVL(ntaxyj, 0)) ntaxyj,
							   SUM(NVL(ntaxeat, 0)) ntaxeat,
							   SUM(NVL(ntaxcar, 0)) ntaxcar,
							   SUM(NVL(ntaxedu, 0)) ntaxedu,
							   SUM(NVL(ntaxstu, 0)) ntaxstu,
							   SUM(NVL(ntaxfor, 0)) ntaxfor,
							   SUM(NVL(ntaxbor, 0)) ntaxbor,
							   SUM(NVL(ntaxarea, 0)) ntaxarea,
							   SUM(NVL(ntaxoutside, 0)) ntaxoutside,
							   SUM(NVL(ntaxetc, 0)) ntaxetc,
							   SUM(NVL(pensamt, 0)) pensamt,
							   SUM(NVL(insuamt, 0)) insuamt,
							   SUM(NVL(hireamt, 0)) hireamt,
							   SUM(NVL(retireamt, 0)) retireamt,
							   SUM(NVL(incometax, 0)) incometax,
							   SUM(NVL(resitax, 0)) resitax,
							   SUM(NVL(farmtax, 0)) farmtax,
							   SUM(NVL(cnreduceamt, 0)) cnreduceamt,
							   SUM(NVL(cnreduceamt1, 0)) cnreduceamt1,
							   SUM(NVL(cnreduceamt2, 0)) cnreduceamt2,
							   SUM(NVL(cnpayamt, 0)) cnpayamt
					  FROM	   PSYEARPRECOMPM
					  GROUP BY plantcode, taxyear, empcode) qq
			   ON a.taxyear = qq.taxyear
				  AND a.empcode = qq.empcode
		   LEFT JOIN (SELECT   a.plantcode,
							   a.taxyear,
							   a.empcode,
							   SUM(CASE WHEN housediv = '1' THEN payamt ELSE 0 END) housemonamt,
							   SUM(CASE WHEN housediv = '2' THEN payamt + interest ELSE 0 END) houseimamtg
					  FROM	   PSYEARHOUSEM a
					  GROUP BY a.plantcode, a.taxyear, a.empcode) hh
			   ON a.taxyear = hh.taxyear
				  AND a.empcode = hh.empcode
		   JOIN CMEMPM d ON a.empcode = d.empcode
		   LEFT JOIN vndept e ON d.deptcode = e.deptcode
		   LEFT JOIN cmcommonm f
			   ON d.positiondiv = f.divcode
				  AND UPPER(f.cmmcode) = 'PS29'
		   LEFT JOIN cmcommonm g
			   ON d.responsibilitydiv = g.divcode
				  AND UPPER(g.cmmcode) = 'PS07'
		   LEFT JOIN cmcommonm h
			   ON d.sexdiv = h.divcode
				  AND UPPER(h.cmmcode) = 'PS30'
		   LEFT JOIN cmcommonm i
			   ON d.empdiv = i.divcode
				  AND UPPER(i.cmmcode) = 'PS41'
		   LEFT JOIN CMCOMMONM j
			   ON d.gradediv = j.divcode
				  AND UPPER(j.cmmcode) = 'PS01'
		   LEFT JOIN cmcommonm p
			   ON d.enterdiv = p.divcode
				  AND UPPER(p.cmmcode) = 'PS09'
		   LEFT JOIN cmcommonm q
			   ON d.classdiv = q.divcode
				  AND UPPER(q.cmmcode) = 'PS42'
		   LEFT JOIN CMCOMMONM s
			   ON d.workdiv = s.divcode
				  AND UPPER(s.cmmcode) = 'PS26'
/
