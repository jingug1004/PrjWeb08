CREATE VIEW VNTARGETRULE AS SELECT a.plantcode, -- isnull(a.plantcode,'') as plantcode
		   a.yearmonth, -- isnull(a.yearmonth,'') as yearmonth
		   NVL(a.rulediv, ' ') rulediv,
		   NVL(b.divname, ' ') ruledivnm,
		   NVL(f.mitemcode, ' ') mitemcode,
		   a.itemcode, -- isnull(a.itemcode,'') as itemcode
		   NVL(f.itemname, ' ') itemname,
		   NVL(f.itemunit, ' ') itemunit,
		   NVL(a.seq, 0) seq,
		   NVL(f.unitqty, 0) unitqty,
		   NVL(f.drugdiv, ' ') drugdiv,
		   NVL(f.drugdivnm, ' ') drugdivnm,
		   NVL(f.formdiv, ' ') formdiv,
		   NVL(f.formdivnm, ' ') formdivnm,
		   NVL(f.itempart, ' ') itempart,
		   NVL(f.itempartnm, ' ') itempartnm,
		   NVL(f.effectdiv, ' ') effectdiv,
		   NVL(f.effectdivnm, ' ') effectdivnm,
		   NVL(f.mainitemyn, ' ') mainitemyn,
		   NVL(f.medimaxprc, ' ') medimaxprc,
		   CASE WHEN NVL(f.mainitemyn, ' ') = 'Y' THEN '주력' ELSE ' ' END mainitemynnm
	FROM   SLTARGETRULEM a
		   LEFT JOIN CMCOMMONM b
			   ON a.rulediv = b.divcode
				  AND b.cmmcode = 'SL73' --정책구분
		   LEFT JOIN vnItem f ON a.itemcode = f.itemcode
/
