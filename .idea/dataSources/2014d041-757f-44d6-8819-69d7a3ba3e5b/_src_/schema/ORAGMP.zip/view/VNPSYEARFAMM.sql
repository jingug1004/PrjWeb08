CREATE VIEW VNPSYEARFAMM AS SELECT NVL(a.plantcode, ' ') plantcode,
		   NVL(a.taxyear, ' ') taxyear,
		   NVL(a.empcode, ' ') empcode,
		   NVL(D.enterdt, ' ') enterdt, -- 입사일자
		   NVL(D.retiredt, ' ') retiredt, -- 퇴사일자
		   NVL(e.topdeptcode, ' ') topdeptcode, -- 부서
		   NVL(e.predeptcode, ' ') predeptcode, -- 지점
		   D.deptcode, -- 팀
		   NVL(e.topdeptname, ' ') topdeptname, -- 부서명
		   NVL(e.predeptname, ' ') predeptname, -- 지점명
		   NVL(e.deptname, ' ') deptname, -- 팀명
		   NVL(e.findname, ' ') findname, -- 부서검색
		   D.empname, -- 사원명
		   D.workdiv, -- 근무지
		   NVL(S.divname, ' ') workdivnm, -- 근무지명
       D.sexdiv, -- 성별
       NVL(h.divname, ' ') sexdivnm,
       D.empdiv, -- 사원구분
       NVL(i.divname, ' ') empdivnm,
       D.enterdiv, -- 입사구분
       NVL(p.divname, ' ') enterdivnm,
       D.positiondiv, -- 직위
       NVL(f.divname, ' ') jikwi,
       D.gradediv, -- 직급
       NVL(j.divname, ' ') gradedivnm,
       D.empstep, -- 호봉
       D.responsibilitydiv, -- 직종
       NVL(g.divname, ' ') responsibilitydivnm,
       D.classdiv, -- 직책
       NVL(a.famseq, 0) famseq, -- 순번
       NVL(a.famname, ' ') famname, -- 성명
       NVL(a.fampersonid, ' ') fampersonid, -- 주민번호
       NVL(a.famdiv, ' ') famdiv, -- 관계
       NVL(c.divname, ' ') famdivnm, -- 관계명
       NVL(c.filter1, ' ') famdivcode, -- 가족관계
       NVL(c.filter2, ' ') famdivcodenm, -- 가족관계명
       NVL(a.wifeyn, 'N') wifeyn, -- 배우자구분
       NVL(a.obsyn, 'N') obsyn, -- 장애구분
       NVL(a.obsdiv, ' ') obsdiv, -- 장애자구분
       NVL(a.singleparentyn, 'N') singleparentyn, -- 한부모가족
       NVL(a.baseyn, 'N') baseyn, -- 기본구분
       NVL(a.womanyn, 'N') womanyn, -- 여성근로자(부녀자)구분
       NVL(a.bringyn, 'N') bringyn, -- 양육구분
       NVL(a.bornyn, 'N') bornyn, -- 출산/보육구분
       NVL(a.oldyn, 'N') oldyn, -- 경로구분
       NVL(a.insuamtnat, 0) insuamtnat, -- 보험료(국세청)
       NVL(a.insuamtetc, 0) insuamtetc, -- 보험료
       NVL(a.insuobsamtnat, 0) insuobsamtnat, --  장애보험료(국세청)
       NVL(a.insuobsamtetc, 0) insuobsamtetc, -- 장애보험료(국세청외)
       NVL(a.mediamtnat, 0) mediamtnat, -- 의료비(국세청)
       NVL(a.mediamtetc, 0) mediamtetc, -- 의료비
       NVL(a.edudiv, ' ') edudiv, -- 교육비구분
       NVL(k.divname, ' ') edudivnm, -- 교육비명
       NVL(a.eduamtnat, 0) eduamtnat, -- 교육비(국세청)
       NVL(a.eduamtetc, 0) eduamtetc, -- 교육비
       NVL(a.cardamtnat, 0) cardamtnat, -- 카드(국세청)
       NVL(a.cardamtetc, 0) cardamtetc, -- 카드
       NVL(a.cardamtjiknat, 0) cardamtjiknat, -- 직불/선불카드(국세청)
       NVL(a.cardamtjiketc, 0) cardamtjiketc, -- 직불/선불카드
       NVL(a.giroamt, 0) giroamt, -- 지로
       NVL(a.cashamtnat, 0) cashamtnat, -- 현금영수증
       NVL(a.jeontongamtnat, 0) jeontongamtnat, -- 전통시장(국세청)
       NVL(a.jeontongamtetc, 0) jeontongamtetc, -- 전통시장
       NVL(a.giveamtnat, 0) giveamtnat, -- 기부금(국세청)
       NVL(a.giveamtetc, 0) giveamtetc, -- 기부금
       NVL(a.publicamtnat, 0) publicamtnat, -- 대중교통(국세청)
       NVL(a.publicamtetc, 0) publicamtetc, -- 대중교통
       CASE
         WHEN (NVL(D.nationdiv, 'N') = 'N')
          OR (NVL(D.nationdiv, ' ') = ' ')
         THEN
           '1'
         ELSE
           '9'
       END
         nationyn, --내/외국인
       NVL(useamtl, 0) useamtl,
       NVL(useamt, 0) useamt,
       NVL(taxcreditamtl, 0) taxcreditamtl,
       NVL(taxcreditamth, 0) taxcreditamth,
       NVL(useamt15, 0) useamt15, --2015년 신용카드 등
       NVL(taxcreditamt14, 0) taxcreditamt14, --2014년 추가공제율
       NVL(taxcreditamt15, 0) taxcreditamt15 --2015년 하반기 추가공제율
  FROM   PSYEARFAMM a
       LEFT JOIN CMCOMMONM c
         ON a.famdiv = c.divcode
          AND c.cmmcode = 'ps04'
       JOIN CMEMPM D ON a.empcode = D.empcode
       LEFT JOIN vnDEPT e ON D.deptcode = e.deptcode
       LEFT JOIN CMCOMMONM f
         ON D.positiondiv = f.divcode
          AND f.cmmcode = 'ps29'
       LEFT JOIN CMCOMMONM g
         ON D.responsibilitydiv = g.divcode
          AND g.cmmcode = 'ps07'
       LEFT JOIN CMCOMMONM h
         ON D.sexdiv = h.divcode
          AND h.cmmcode = 'ps30'
       LEFT JOIN CMCOMMONM i
         ON D.empdiv = i.divcode
          AND i.cmmcode = 'ps41'
       LEFT JOIN CMCOMMONM j
         ON D.gradediv = j.divcode
          AND j.cmmcode = 'PS01'
       LEFT JOIN CMCOMMONM k
         ON a.edudiv = k.divcode
          AND k.cmmcode = 'PS69'
       LEFT JOIN CMCOMMONM p
         ON D.enterdiv = p.divcode
          AND p.cmmcode = 'ps09'
       LEFT JOIN CMCOMMONM Q
         ON D.classdiv = Q.divcode
          AND Q.cmmcode = 'ps42'
       LEFT JOIN CMCOMMONM S
         ON D.workdiv = S.divcode
          AND S.cmmcode = 'ps26'
/
