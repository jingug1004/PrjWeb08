CREATE VIEW VNELECTRONICSIGNHISTORY AS SELECT A.programcode,
		   A.KEYS,
		   A.signseq,
		   A.status,
		   A.deptcode,
		   D.deptname,
		   A.signempcode,
		   b.empname signempname,
		   A.signdt,
		   TO_CHAR(A.signdt, 'yyyy-mm-dd') signdate,
		   A.signtext,
		   CASE A.status WHEN '03' THEN NVL(c.emppicture, HEXTORAW('424d42000000000000003e0000002800000001000000010000000100010000000000040000000000000000000000000000000000000000000000ffffff0080000000')) ELSE NULL END emppicture
	FROM   SYSELECTRONICSIGNHISTORY A
		   LEFT JOIN CMEMPM b ON A.signempcode = b.empcode
		   LEFT JOIN SYSSIGNPICTURE c ON b.empcode = c.empcode
		   LEFT JOIN CMDEPTM D ON b.deptcode = D.deptcode
/
