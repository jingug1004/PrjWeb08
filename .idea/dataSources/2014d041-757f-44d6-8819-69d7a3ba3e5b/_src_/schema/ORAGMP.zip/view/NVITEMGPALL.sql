CREATE VIEW NVITEMGPALL AS SELECT b.itemcode itemcode, --품목코드
       b.itemkorname itemkorname, --품목명(국문)
       NVL(a.revisionno, '-1') revisionno, --품목허가개정번호
       c.divcode itemdiv, --품목구분
       c.filter1 managecode, --품목구분(시스템)
       c.divname itemdivname, --품목구분명
       b.itemshortname itemshortname, --품목명(약명)
       b.itemengname itemengname, --품목명(영문)
       b.standarddiv standarddiv, --시험규격코드
       D.divname standarddivname, --시험규격명
       b.validityperiod validityperiod, --유통기한(월)
       b.itemunit itemunit, --단위코드
       E.divname itemunitname, --단위명
       b.keepingmethod keepingmethod, --보관방법
       b.itemdiv itembranch, --품목분류코드
       c.divname itembranchname, --품목분류명
       b.keepingwarehouse keepingwarehouse, --보관창고코드
       G.whname keepingwarehousename, --보관창고명
       NULL internaldiv, --국내외구분코드(원자재/상품)
       NULL internaldivname, --국내외구분(*)
       NULL enteringrackdiv, --입고랙종류코드(원자재/상품)
       NULL enteringrackdivname, --입고랙종류(*)
       NULL enteringrackqty, --입고랙적재량(원자재/상품)
       'Y' testcheck, --시험여부
       NULL safestockqty, --안전재고량
       NULL properstockqty, --적정재고량
       NULL buyperiod, --구매기간
       b.usediv usediv, --사용여부
       CASE b.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
       NULL notusediv, --미사용원인코드
       NULL notusedivname, --미사용원인(*)
       b.revisionno itemrevisionid, --관리번호(제조제품)--수정되여야 한다.
       b.contentqty contentqty, --함량Num(제조제품)
       b.contentunit contentunit, --함량단위코드(제조제품)
       h.divname contentunitname, --함량단위(*)
       fnNumericToString(b.contentqty, 'S') || h.divname contentqtyname, --함량Text(*)
       b.BATCHSIZE BATCHSIZE, --배치크기Num(제조제품)
       fnNumericToString(b.BATCHSIZE, 'S') || E.divname batchsizename, --배치크기Text(*)
       b.itemformdiv itemformdiv, --제품유형코드(제조제품)
       i.divname itemformdivname, --제품유형(*)
       b.maxmanageyield maxmanageyield, --관리수율(상한)(제조제품)
       b.minmanageyield minmanageyield, --관리수율(하한)(제조제품)
       b.makingcost makingcost, --제조원가(제조,포장)
       b.docuno docuno, --문서번호(제조,포장)
       b.productcheck productcheck, --생산여부(제조,포장)
       b.notproductdiv notproductdiv, --미생산원인코드(제조,포장)
       j.divname notproductdivname, --미생산원인(*)
       NULL typicalitemcode, --대표제품코드(포장제품)
       NULL typicalitemname, --대표제품명(*)
       NULL packingunitqty, --포장단위량Num(포장제품)
       NULL packingunitqtyname, --포장단위Text(*)
       NULL packingtypediv, --포장타입코드(포장제품)
       NULL packingtypedivname, --포장타입(*)
       NULL typicalpackingcheck, --포장대표여부(포장제품)
       NULL cartondiv, --지함종류코드(포장제품)
       NULL cartondivname, --지함종류(*)
       NULL cartonqty, --지함적재량(포장제품)
       NULL barcode, --바코드(포장제품)
       NULL minpackingcheck,
       b.productiondiv productiondiv,
       K.divname productiondivname,
       K.remark productiontype,
       a.approvalcheck approvalcheck,
       a.permissionnum permissionnum,
       a.permissiondate permissiondate,
       b.transunit transunit,
       b.shape shape,
       b.transqty transqty,
       NVL(M.divname, '') transunitname,
       a.plantcode plantcode,
       b.costcenter costcenter,
       l.divname costcentername,
       b.stockwarehousediv stockwarehousediv,
       f.divname stockwarehousedivname,
       b.keepingwarehouse warehouse,
       b.factorydiv factorydiv
  FROM   MakingGoodsMaster b
       LEFT JOIN GoodsStandardRevision a
         ON a.itemcode = b.itemcode
          AND a.itemrevisionid = b.revisionno
          AND a.usediv = 'Y'
       JOIN CMCOMMONM c
         ON c.cmmcode = 'CMM01'
          AND b.itemdiv = c.divcode
       LEFT JOIN CMCOMMONM D
         ON D.cmmcode = 'LMM06'
          AND b.standarddiv = D.divcode
       LEFT JOIN CMCOMMONM E
         ON E.cmmcode = 'CMM02'
          AND b.itemunit = E.divcode
       LEFT JOIN SLSTOREHOUSEM G ON G.warehouse = b.keepingwarehouse
       LEFT JOIN CMCOMMONM h
         ON h.cmmcode = 'CMM02'
          AND b.contentunit = h.divcode
       LEFT JOIN CMCOMMONM i
         ON i.cmmcode = 'MPM29'
          AND b.itemformdiv = i.divcode
       LEFT JOIN CMCOMMONM j
         ON j.cmmcode = 'MPM24'
          AND b.notproductdiv = j.divcode
       JOIN CMCOMMONM K
         ON K.cmmcode = 'CMM55'
          AND b.productiondiv = K.divcode
       LEFT JOIN CMCOMMONM M
         ON M.cmmcode = 'CMM02'
          AND b.transunit = M.divcode
       LEFT JOIN CMCOMMONM l
         ON l.cmmcode = 'CMM61'
          AND b.costcenter = l.divcode
       LEFT JOIN CommonMaster f
         ON b.stockwarehousediv = f.divcode
          AND f.cmmcode = 'CMM64'
  UNION
  --포장제품(제제,원료의약품)
  SELECT a.itemcode itemcode, --품목코드
       a.itemkorname itemkorname, --품목명(국문)
       NVL(M.revisionno, '-1') revisionno, --품목허가개정번호
       b.divcode itemdiv, --품목구분
       b.filter1 managecode, --품목구분(시스템)
       b.divname itemdivname, --품목구분명(*)
       a.itemshortname itemshortname, --품목명(약명)
       a.itemengname itemengname, --품목명(영문)
       c.standarddiv standarddiv, --시험규격코드
       D.divname standarddivname, --시험규격(*)
       NVL(c.validityperiod, 0) validityperiod, --유통기한(월)
       c.itemunit itemunit, --단위코드
       E.divname itemunitname, --단위(*)
       c.keepingmethod keepingmethod, --보관방법
       a.itemdiv itembranch, --품목분류코드
       b.divname itembranchname, --품목분류(*)
       a.keepingwarehouse keepingwarehouse, --보관창고코드
       G.whname keepingwarehousename, --보관창고(*)
       NULL internaldiv, --국내외구분코드(원자재/상품)
       NULL internaldivname, --국내외구분(*)
       a.enteringrackdiv enteringrackdiv, --입고랙종류코드(원자재/상품)
       NULL enteringrackdivname, --입고랙종류(*)
       a.enteringrackqty enteringrackqty, --입고랙적재량(원자재/상품)
       'Y' testcheck, --시험여부
       a.safestockqty safestockqty, --안전재고량
       a.properstockqty properstockqty, --적정재고량
       NULL buyperiod, --구매기간
       a.usediv usediv, --사용여부
       CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
       NULL notusediv, --미사용원인코드
       NULL notusedivname, --미사용원인(*)
       a.revisionno itemrevisionid, --관리번호(제조제품)
       c.contentqty contentqty, --함량Num(제조제품)
       c.contentunit contentunit, --함량단위코드(제조제품)
       i.divname contentunitname, --함량단위(*)
       fnNumericToString(c.contentqty, 'S') || i.divname contentqtyname, --함량Text(*)
       c.BATCHSIZE BATCHSIZE, --배치크기Num(제조제품)
       fnNumericToString(c.BATCHSIZE, 'S') || E.divname batchsizename, --배치크기Text(*)
       c.itemformdiv itemformdiv, --제품유형코드(제조제품)
       o.divname itemformdivname, --제품유형(*)
       c.maxmanageyield maxmanageyield, --관리수율(상한)(제조제품)
       c.minmanageyield minmanageyield, --관리수율(하한)(제조제품)
       c.makingcost makingcost, --제조원가(제조,포장)
       a.docuno docuno, --문서번호(제조,포장)
       a.productcheck productcheck, --생산여부(제조,포장)
       a.notproductdiv notproductdiv, --미생산원인코드(제조,포장)
       j.divname notproductdivname, --미생산원인(*)
       a.typicalitemcode typicalitemcode, --대표제품코드(포장제품)
       c.itemkorname typicalitemname, --대표제품명(*)
       a.packingunitqty packingunitqty, --포장단위량Num(포장제품)
       fnNumericToString(a.packingunitqty, 'S') || E.divname packingunitqtyname, --포장단위Text(*)
       a.packingtypediv packingtypediv, --포장타입코드(포장제품)
       K.divname packingtypedivname, --포장타입(*)
       a.typicalpackingcheck typicalpackingcheck, --포장대표여부(포장제품)
       a.cartondiv cartondiv, --지함종류코드(포장제품)
       l.divname cartondivname, --지함종류(*)
       a.cartonqty cartonqty, --지함적재량(포장제품)
       a.barcode barcode, --바코드(포장제품)
       a.minpackingcheck minpackingcheck,
       c.productiondiv productiondiv,
       N.divname productiondivname,
       N.remark productiontype,
       M.approvalcheck approvalcheck,
       M.permissionnum permissionnum,
       M.permissiondate permissiondate,
       c.transunit,
       c.shape,
       c.transqty,
       NVL(P.divname, '') transunitname,
       a.plantcode,
       a.costcenter costcenter,
       Q.divname costcentername,
       a.stockwarehousediv stockwarehousediv,
       f.divname stockwarehousedivname,
       a.keepingwarehouse warehouse,
       c.factorydiv factorydiv
  FROM   PackingGoodsMaster a
       LEFT JOIN GoodsStandardRevision M
         ON M.itemcode = a.itemcode
          AND M.itemrevisionid = a.revisionno
          AND M.usediv = 'Y'
       JOIN CMCOMMONM b
         ON b.cmmcode = 'CMM01'
          AND b.divcode = a.itemdiv
       JOIN MakingGoodsMaster c ON a.typicalitemcode = c.itemcode
       LEFT JOIN CMCOMMONM D
         ON D.cmmcode = 'LMM06'
          AND D.divcode = c.standarddiv
       LEFT JOIN CMCOMMONM E
         ON E.cmmcode = 'CMM02'
          AND E.divcode = c.itemunit
       LEFT JOIN SLSTOREHOUSEM G ON G.warehouse = a.keepingwarehouse
       LEFT JOIN CMCOMMONM i
         ON i.cmmcode = 'CMM02'
          AND i.divcode = c.contentunit
       LEFT JOIN CMCOMMONM j
         ON j.cmmcode = 'MPM24'
          AND j.divcode = a.notproductdiv
       LEFT JOIN CMCOMMONM K
         ON K.cmmcode = 'MPM72'
          AND K.divcode = a.packingtypediv
       LEFT JOIN CMCOMMONM l
         ON l.cmmcode = 'MPM67'
          AND l.divcode = a.cartondiv
       JOIN CMCOMMONM N
         ON N.cmmcode = 'CMM55'
          AND c.productiondiv = N.divcode
       LEFT JOIN CMCOMMONM o
         ON o.cmmcode = 'MPM29'
          AND c.itemformdiv = o.divcode
       LEFT JOIN CMCOMMONM P
         ON P.cmmcode = 'CMM02'
          AND c.transunit = P.divcode
       LEFT JOIN CMCOMMONM Q
         ON Q.cmmcode = 'CMM61'
          AND a.costcenter = Q.divcode
       LEFT JOIN CommonMaster f
         ON a.stockwarehousediv = f.divcode
          AND f.cmmcode = 'CMM64'
  UNION
  --상품(내자,외자)
  SELECT a.itemcode itemcode, --품목코드
       a.itemname itemkorname, --품목명(국문)
       TO_CHAR(a.revisionno) revisionno, --품목허가개정번호
       b.divcode itemdiv, --품목구분
       b.filter1 managecode, --품목구분(시스템)
       b.divname itemdivname, --품목구분명(*)
       a.itemsname itemshortname, --품목명(약명)
       a.itemname itemengname, --품목명(영문)
       a.standarddiv standarddiv, --시험규격코드
       D.divname standarddivname, --시험규격(*)
       a.validityperiod validityperiod, --유통기한(월)
       a.unit itemunit, --단위코드
       E.divname itemunitname, --단위(*)
       a.keepingmethod keepingmethod, --보관방법
       a.itemdiv itembranch, --품목분류코드
       b.divname itembranchname, --품목분류(*)
       a.warehouse keepingwarehouse, --보관창고코드
       G.whname keepingwarehousename, --보관창고(*)
       a.internaldiv internaldiv, --국내외구분코드(원자재/상품)
       M.divname internaldivname, --국내외구분(*)
       a.enteringrackdiv enteringrackdiv, --입고랙종류코드(원자재/상품)
       NULL enteringrackdivname, --입고랙종류(*)
       a.enteringrackqty enteringrackqty, --입고랙적재량(원자재/상품)
       NVL(a.testcheck, 'n') testcheck, --시험여부
       a.safeqty safestockqty, --안전재고량
       a.properstockqty properstockqty, --적정재고량
       a.buyperiod buyperiod, --구매기간
       a.usediv usediv, --사용여부
       CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
       NULL notusediv, --미사용원인코드
       NULL notusedivname, --미사용원인(*)
       TO_CHAR(a.revisionno) itemrevisionid, --관리번호(제조제품)
       a.contentqty contentqty, --함량Num(제조제품)
       a.contentunit contentunit, --함량단위코드(제조제품)
       i.divname contentunitname, --함량단위(*)
       fnNumericToString(a.contentqty, 'S') || i.divname contentqtyname, --함량Text(*)
       a.BATCHSIZE BATCHSIZE, --배치크기Num(제조제품)
       fnNumericToString(a.BATCHSIZE, 'S') || E.divname batchsizename, --배치크기Text(*)
       a.formdiv itemformdiv, --제품유형코드(제조제품)
       o.divname itemformdivname, --제품유형(*)
       a.maxmanageyield maxmanageyield, --관리수율(상한)(제조제품)
       a.minmanageyield minmanageyield, --관리수율(하한)(제조제품)
       a.makingcost makingcost, --제조원가(제조,포장)
       a.docuno docuno, --문서번호(제조,포장)
       a.productcheck productcheck, --생산여부(제조,포장)
       a.notproductdiv notproductdiv, --미생산원인코드(제조,포장)
       j.divname notproductdivname, --미생산원인(*)
       a.mitemcode typicalitemcode, --대표제품코드(포장제품)
       a.itemname typicalitemname, --대표제품명(*)
       a.unitqty packingunitqty, --포장단위량Num(포장제품)
       fnNumericToString(a.unitqty, 'S') || E.divname packingunitqtyname, --포장단위Text(*)
       a.packingtypediv packingtypediv, --포장타입코드(포장제품)
       K.divname packingtypedivname, --포장타입(*)
       a.typicalpackingcheck typicalpackingcheck, --포장대표여부(포장제품)
       a.cartondiv cartondiv, --지함종류코드(포장제품)
       l.divname cartondivname, --지함종류(*)
       a.cartonqty cartonqty, --지함적재량(포장제품)
       a.barcode barcode, --바코드(포장제품)
       a.minpackingcheck minpackingcheck,
       a.makediv productiondiv,
       N.divname productiondivname,
       N.remark productiontype,
       'Y' approvalcheck,
       '-' permissionnum,
       NULL permissiondate,
       a.packingtypediv,
       a.shape,
       1 transqty,
       NULL transunitname,
       a.plantcode,
       a.costcenter costcenter,
       Q.divname costcentername,
       a.stockwarehousediv stockwarehousediv,
       f.divname stockwarehousedivname,
       a.warehouse,
       a.factorydiv factorydiv
  FROM   CMITEMM a
       JOIN CMCOMMONM b
         ON b.cmmcode = 'CMM01'
          AND b.divcode = a.itemdiv
       LEFT JOIN CMCOMMONM D
         ON D.cmmcode = 'LMM06'
          AND D.divcode = a.standarddiv
       LEFT JOIN CMCOMMONM E
         ON E.cmmcode = 'CMM02'
          AND E.divcode = a.unit
       LEFT JOIN SLSTOREHOUSEM G ON G.warehouse = a.warehouse
       LEFT JOIN CMCOMMONM i
         ON i.cmmcode = 'CMM02'
          AND i.divcode = a.contentunit
       LEFT JOIN CMCOMMONM j
         ON j.cmmcode = 'MPM24'
          AND j.divcode = a.notproductdiv
       LEFT JOIN CMCOMMONM K
         ON K.cmmcode = 'MPM72'
          AND K.divcode = a.packingtypediv
       LEFT JOIN CMCOMMONM l
         ON l.cmmcode = 'MPM67'
          AND l.divcode = a.cartondiv
       LEFT JOIN CMCOMMONM o
         ON o.cmmcode = 'MPM29'
          AND a.formdiv = o.divcode
       LEFT JOIN CMCOMMONM Q
         ON Q.cmmcode = 'CMM61'
          AND a.costcenter = Q.divcode
       LEFT JOIN CMCOMMONM N
         ON N.cmmcode = 'CMM55'
          AND a.makediv = N.divcode
       LEFT JOIN CMCOMMONM M
         ON M.cmmcode = 'MPM15'
          AND a.internaldiv = M.divcode
       LEFT JOIN CommonMaster f
         ON a.stockwarehousediv = f.divcode
          AND f.cmmcode = 'CMM64'
  WHERE  a.itemdiv IN ('05' --상품
               )
/
