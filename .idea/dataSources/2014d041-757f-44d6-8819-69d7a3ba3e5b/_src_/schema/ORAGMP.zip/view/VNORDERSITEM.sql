CREATE VIEW VNORDERSITEM AS (SELECT a.plantcode,
			a.orderdate,
			a.orderseq,
			a.orderno,
			NVL(a.saldiv, '') AS saldiv,
			NVL(a.yymm, '') AS yymm,
			NVL(d.divname, '') AS saldivnm,
			NVL(a.datadiv, '') AS datadiv,
			NVL(E.divname, '') AS datadivnm,
			NVL(a.orderdiv, '') AS orderdiv,
			a.custcode,
			NVL(b.custname, '') AS custname,
			NVL(b.opendate, '') AS opendate,
			SUBSTR(NVL(b.opendate, ''), 1, 7) AS openyymm,
			NVL(b.ascustcheck, 'N') AS ascustcheck,
			a.deptcode,
			NVL(h.predeptcode, '') AS predeptcode,
			NVL(h.predeptname, '') AS predeptname,
			NVL(h.topdeptcode, '') AS topdeptcode,
			NVL(h.topdeptname, '') AS topdeptname,
			NVL(h.findname, '') AS findname,
			NVL(h.deptname, '') AS deptname,
			a.empcode,
			NVL(i.positiondiv, '') AS positiondiv,
			NVL(q.divname, '') AS jikwi,
			NVL(i.empname, '') AS empname,
			a.ecustcode,
			NVL(c.custname, '') AS ecustname,
			NVL(c.opendate, '') AS eopendate,
			NVL(c.ascustcheck, 'N') AS eascustcheck,
			a.edeptcode,
			NVL(j.findname, '') AS efindname,
			NVL(j.predeptcode, '') AS epredeptcode,
			NVL(j.predeptname, '') AS epredeptname,
			NVL(j.topdeptcode, '') AS etopdeptcode,
			NVL(j.topdeptname, '') AS etopdeptname,
			NVL(j.deptname, '') AS edeptname,
			a.eempcode,
			NVL(K.positiondiv, '') AS epositiondiv,
			NVL(r.divname, '') AS ejikwi,
			NVL(K.empname, '') AS eempname,
			NVL(a.utdiv, '') AS utdiv,
			NVL(o.divname, '') AS utdivnm,
			NVL(a.eutdiv, '') AS eutdiv,
			NVL(P.divname, '') AS eutdivnm,
			a.statediv,
			NVL(l.divname, '') AS statedivnm,
			NVL(a.remark, '') AS remark,
			a.seq,
			a.itemcode,
			NVL(M.itemname, '') AS itemname,
			NVL(M.mitemcode, '') AS mitemcode,
			NVL(mm.itemname, '') AS mitemname,
			NVL(M.unitqty, 0) AS unitqty,
			NVL(M.itemunit, '') AS unit,
			NVL(M.drugdiv, '') AS drugdiv, -- 의약구분(전문,일반...)
			NVL(M.drugdivnm, '') AS drugdivnm,
			NVL(M.formdiv, '') AS formdiv, -- 제형(정제, 주사제...)
			NVL(M.formdivnm, '') AS formdivnm,
			NVL(M.itempart, '') AS itempart, -- 제품종류(제품,상품...)
			NVL(M.itempartnm, '') AS itempartnm,
			NVL(M.effectdiv, '') AS effectdiv, -- 주효능(호흡기용, 소화기용...)
			NVL(M.effectdivnm, '') AS effectdivnm,
			NVL(M.itemgbdiv, '') AS itemgbdiv, -- 제품분류(일반,향정신성,마약)
			NVL(M.itemgbdivnm, '') AS itemgbdivnm,
			NVL(M.incentiveyn, '') AS incentiveyn,
			NVL(M.mainitemyn, 'N') AS mainitemyn, -- 주력품목
			NVL(M.medimaxprc, '') AS medimaxprc, -- 상한금액
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN a.salqty WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -a.salqty ELSE 0 END AS salqty,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN a.givqty WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -a.givqty ELSE 0 END AS givqty,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN a.bonusqty WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -a.bonusqty ELSE 0 END AS bonusqty,
			NVL(a.drugprc, 0) AS drugprc,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.drugamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.drugamt, 0) ELSE 0 END AS drugamt,
			NVL(a.makingcost, 0) AS makingcost,
			CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.makingamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.makingamt, 0) ELSE 0 END AS makingamt,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.makinggivamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.makinggivamt, 0) ELSE 0 END AS makinggivamt,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.makingbonusamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.makingbonusamt, 0) ELSE 0 END AS makingbonusamt,
      NVL(a.salprc, 0) AS salprc,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.salamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.salamt, 0) ELSE 0 END AS salamt,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.salvat, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.salvat, 0) ELSE 0 END AS salvat,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.totamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.totamt, 0) ELSE 0 END AS totamt,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.befamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.befamt, 0) ELSE 0 END AS befamt,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.aftamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.aftamt, 0) ELSE 0 END AS aftamt,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.incamt, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.incamt, 0) ELSE 0 END AS incamt,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.totdiscount, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.totdiscount, 0) ELSE 0 END AS totdiscount,
      NVL(a.givrate, 0) AS givrate,
      NVL(a.befrate, 0) AS befrate,
      NVL(a.aftrate, 0) AS aftrate,
      NVL(a.incrate, 0) AS incrate,
      NVL(a.salprc1, 0) AS salprc1,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.salamt1, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.salamt1, 0) ELSE 0 END AS salamt1,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.salvat1, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.salvat1, 0) ELSE 0 END AS salvat1,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(a.totamt1, 0) WHEN SUBSTR(a.saldiv, 1, 1) = 'B' THEN -NVL(a.totamt1, 0) ELSE 0 END AS totamt1,
      NVL(a.custprtyn, '') AS custprtyn,
      NVL(a.outputqty, 0) AS outputqty,
      NVL(a.pieceyn, '') AS pieceyn,
      NVL(a.enuriyn, '') AS eruriyn,
      a.appdate,
      NVL(a.pda, '') AS pda,
      NVL(M.itemdiv, '') AS itemdiv,
      NVL(M.productdiv, '') AS productdiv,
      NVL(i.retiredt, '') AS retiredt,
      NVL(K.retiredt, '') AS eretiredt,
      NVL(h.deptgroup, '') AS deptgroup,
      NVL(j.deptgroup, '') AS edeptgroup,
      NVL(i.ratediv, '') AS ratediv,
      NVL(a.warehouse, '') AS warehouse,
      NVL(a.lotno, '') AS lotno,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(M.unitqty, 0) * salqty WHEN SUBSTR(a.saldiv, 1) = 'B' THEN NVL(M.unitqty, 0) * (-salqty) ELSE 0 END AS tsalqty,
      CASE WHEN SUBSTR(a.saldiv, 1, 1) = 'A' THEN NVL(M.unitqty, 0) * givqty WHEN SUBSTR(a.saldiv, 1) = 'B' THEN NVL(M.unitqty, 0) * (-givqty) ELSE 0 END AS tgivqty,
      c.custitem AS ecustitem,
      b.custitem AS custitem,
      M.itemsname,
      M.groupdiv,
      M.groupdivnm,
      b.addr1 || ' ' || b.addr1 AS addr,
      h.seqtopdeptcode,
      h.seqpredeptcode,
      h.seqdeptcode,
      j.seqtopdeptcode AS eseqtopdeptcode,
      j.seqpredeptcode AS eseqpredeptcode,
      j.seqdeptcode AS eseqdeptcode,
      M.repreitemcode --대표제품코드
               ,
      M.changerate --환산율
            ,
      M.empcode_pm
   FROM  vnOrdersend a
      INNER JOIN CMCUSTM b ON a.custcode = b.custcode
      INNER JOIN CMCUSTM c ON a.ecustcode = c.custcode
      LEFT JOIN CMCOMMONM d
        ON a.saldiv = d.divcode
           AND d.cmmcode = 'SL10'
      LEFT JOIN CMCOMMONM E
        ON a.datadiv = E.divcode
           AND E.cmmcode = 'SL11'
      LEFT JOIN vnDEPT h ON a.deptcode = h.deptcode
      INNER JOIN CMEMPM i ON a.empcode = i.empcode
      LEFT JOIN vnDEPT j ON a.edeptcode = j.deptcode
      INNER JOIN CMEMPM K ON a.eempcode = K.empcode
      LEFT JOIN CMCOMMONM l
        ON a.statediv = l.divcode
           AND l.cmmcode = 'SL17'
      INNER JOIN vnItem M ON a.itemcode = M.itemcode
      LEFT JOIN CMITEMM mm ON M.mitemcode = mm.itemcode
      LEFT JOIN CMCOMMONM n
        ON M.unit = n.divcode
           AND n.cmmcode = 'CM38'
      LEFT JOIN CMCOMMONM o
        ON a.utdiv = o.divcode
           AND o.cmmcode = 'CM15'
      LEFT JOIN CMCOMMONM P
        ON a.eutdiv = P.divcode
           AND P.cmmcode = 'CM15'
      LEFT JOIN CMCOMMONM q
        ON i.positiondiv = q.divcode
           AND q.cmmcode = 'PS29'
      LEFT JOIN CMCOMMONM r
        ON K.positiondiv = r.divcode
           AND r.cmmcode = 'PS29')
/
