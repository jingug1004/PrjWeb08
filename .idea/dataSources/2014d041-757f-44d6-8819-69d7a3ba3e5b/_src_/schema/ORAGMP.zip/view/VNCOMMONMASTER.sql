CREATE VIEW VNCOMMONMASTER AS SELECT cmmcode,
		   divcode,
		   filter1 managecode,
		   cmmname,
		   divname,
		   remark,
		   usediv,
		   majorname
	FROM   CMCOMMONM
	WHERE  usediv = 'Y'
		   AND cmmcode = 'CMM01'
		   AND NVL(filter1, ' ') <> ' '
	UNION ALL
	--단위
	SELECT cmmcode,
		   divcode,
		   filter1 managecode,
		   cmmname,
		   divname,
		   remark,
		   usediv,
		   majorname
	FROM   CMCOMMONM
	WHERE  usediv = 'Y'
		   AND cmmcode = 'CMM02'
		   AND NVL(filter1, ' ') <> ' '
	UNION ALL
	--매입구분
	SELECT cmmcode,
		   divcode,
		   filter1 managecode,
		   cmmname,
		   divname,
		   remark,
		   usediv,
		   majorname
	FROM   CMCOMMONM
	WHERE  usediv = 'Y'
		   AND cmmcode = 'MPM17'
		   AND NVL(filter1, ' ') <> ' '
	UNION ALL
	SELECT cmmcode,
       divcode,
       filter1 managecode,
       cmmname,
       divname,
       remark,
       usediv,
       majorname
  FROM   CMCOMMONM
  WHERE  usediv = 'Y'
       AND cmmcode NOT IN ('CMM01', 'CMM02', 'MPM17')
/
