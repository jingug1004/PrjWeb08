CREATE VIEW VNRESULTM AS SELECT A.plantcode,
          A.yearmonth,
          A.custcode,
          NVL (b.custname, '') AS custname,
          NVL (b.addr1 || ' ' || b.addr2, '') AS addr,
          NVL (b.ceoname, '') AS ceoname,
          A.ecustcode,
          NVL (E.custname, '') AS ecustname,
          NVL (A.orderdiv, '') AS orderdiv,
          NVL (c.topdeptcode, '') AS topdeptcode,
          NVL (c.topdeptname, '') AS topdeptname,
          NVL (c.predeptcode, '') AS predeptcode,
          NVL (c.predeptname, '') AS predeptname,
          b.deptcode,
          NVL (c.deptname, '') AS deptname,
          NVL (c.findname, '') AS findname,
          b.empcode,
          NVL (d.empname, '') AS empname,
          NVL (d.positiondiv, '') AS positiondiv,
          NVL (j.divname, '') AS jikwi,
          NVL (b.utdiv, '') AS utdiv,
          NVL (h.divname, '') AS utdivnm,
          NVL (f.topdeptcode, '') AS etopdeptcode,
          NVL (f.topdeptname, '') AS etopdeptname,
          NVL (f.predeptcode, '') AS epredeptcode,
          NVL (f.predeptname, '') AS epredeptname,
          E.deptcode AS edeptcode,
          NVL (f.deptname, '') AS edeptname,
          NVL (f.findname, '') AS efindname,
          E.empcode AS eempcode,
          NVL (G.empname, '') AS eempname,
          NVL (G.positiondiv, '') AS epositiondiv,
          NVL (K.divname, '') AS ejikwi,
          NVL (E.utdiv, '') AS eutdiv,
          NVL (i.divname, '') AS eutdivnm,
          NVL (A.drugamt, 0) AS drugamt,
          NVL (A.salamt, 0) AS salamt,
          NVL (A.salvat, 0) AS salvat,
          NVL (A.totamt, 0) AS totamt,
          NVL (A.returnamt, 0) AS returnamt,
          NVL (A.returnvat, 0) AS returnvat,
          NVL (A.returntotamt, 0) AS returntotamt,
          NVL (A.cashcol, 0) AS cashcol,
          NVL (A.cardcol, 0) AS cardcol,
          NVL (A.billcol, 0) AS billcol,
          NVL (A.etccol, 0) AS etccol,
          NVL (A.totcol, 0) AS totcol,
          NVL (A.pendbillcol, 0) AS pendbillcol,
          NVL (A.pendbillcolj, 0) AS pendbillcolj,
          NVL (A.pendbillcolt, 0) AS pendbillcolt,
          NVL (A.balance, 0) AS balance,
          NVL (A.turncnt, 0) AS turncnt,
          NVL (A.turndccnt, 0) AS turndccnt,
          NVL (A.colcnt, 0) AS colcnt,
          NVL (A.salcnt, 0) AS salcnt,
          NVL (A.returncnt, 0) AS returncnt,
          NVL (d.retiredt, '') AS retiredt,
          NVL (G.retiredt, '') AS eretiredt,
          NVL (c.deptgroup, '') AS deptgroup,
          NVL (f.deptgroup, '') AS edeptgroup,
          NVL (b.stopdate, '') AS stopdate,
          NVL (b.opendate, '') AS opendate,
          SUBSTR (b.opendate, 0, 7) AS openyymm,
          NVL (b.custmajorcode, '') AS custmajorcode,
          NVL (E.custmajorcode, '') AS ecustmajorcode,
          NVL (b.custdiv, '') AS custdiv,
          NVL (E.custdiv, '') AS ecustdiv,
          c.seqtopdeptcode,
          c.seqpredeptcode,
          c.seqdeptcode,
          f.seqtopdeptcode AS eseqtopdetpcode,
          f.seqpredeptcode AS eseqpredeptcode,
          f.seqdeptcode AS eseqdeptcode,
          b.sagodiv,
          d.partdiv
     FROM SLRESULTM A
          LEFT JOIN CMCUSTM b
             ON A.custcode = b.custcode
          LEFT JOIN vnDEPT c
             ON b.deptcode = c.deptcode
          LEFT JOIN CMEMPM d
             ON b.empcode = d.empcode
          LEFT JOIN CMCUSTM E
             ON A.ecustcode = E.custcode
          LEFT JOIN vnDEPT f
             ON E.deptcode = f.deptcode
          LEFT JOIN CMEMPM G
             ON E.empcode = G.empcode
          LEFT JOIN CMCOMMONM h
             ON A.utdiv = h.divcode AND h.cmmcode = 'CM15'
          LEFT JOIN CMCOMMONM i
             ON A.eutdiv = i.divcode AND i.cmmcode = 'CM15'
          LEFT JOIN CMCOMMONM j
             ON d.positiondiv = j.divcode AND j.cmmcode = 'PS29'
          LEFT JOIN CMCOMMONM K
             ON G.positiondiv = K.divcode AND K.cmmcode = 'PS29'
/
