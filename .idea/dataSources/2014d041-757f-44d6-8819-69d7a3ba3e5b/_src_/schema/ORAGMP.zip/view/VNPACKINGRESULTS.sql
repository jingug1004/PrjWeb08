CREATE VIEW VNPACKINGRESULTS AS SELECT a.packingorderno, -- 포장지시번호
		   a.itemcode, -- 포장제품코드
		   --,b.ritemcode as itemcode  -- 영업포장제품코드
		   a.workdt, -- 입고일시
		   a.lotdate, -- 제조일자
		   a.batchno, -- 제조번호
		   a.validityperiod, -- 유통기한
		   NVL(a.warehousepackqty, 0) warehousepackqty, -- 입고수량
		   a.warehousestate, -- 입고상태
		   a.goodstestrequestno, -- 시험의뢰번호
		   a.plantcode, -- 사업장코드
		   A.goodstestresult, -- 시험결과
		   a.productdiv
	FROM   PackingResults a
		   LEFT JOIN PackingOrders x ON a.packingorderno = x.packingorderno
		   JOIN CMITEMM b ON a.itemcode = b.itemcode
	WHERE  a.warehousestate = '01'
		   AND a.goodstestresult = 'Y'
/
