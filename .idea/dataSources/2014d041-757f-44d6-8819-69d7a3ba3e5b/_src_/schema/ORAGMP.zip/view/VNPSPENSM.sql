CREATE VIEW VNPSPENSM AS SELECT NVL(b.plantcode, ' ') plantcode,
		   NVL(a.yearmonth, ' ') yearmonth,
		   NVL(b.topdeptcode, ' ') topdeptcode,
		   NVL(b.topdeptname, ' ') topdeptname,
		   NVL(b.predeptcode, ' ') predeptcode,
		   NVL(b.predeptname, ' ') predeptname,
		   NVL(b.deptcode, ' ') deptcode,
		   NVL(b.deptname, ' ') deptname,
		   NVL(b.findname, ' ') findname,
		   NVL(a.empcode, ' ') empcode,
		   NVL(b.empname, ' ') empname,
		   NVL(b.positiondiv, ' ') positiondiv,
		   NVL(b.jikwi, ' ') jikwi,
		   NVL(c.pensratep, 0) pensratep,
		   NVL(c.pensratec, 0) pensratec,
		   NVL(a.taxamt, 0) taxamt,
		   NVL(a.taxmonth, 0) taxmonth,
		   NVL(a.fixamt, 0) fixamt,
		   NVL(a.pensamtp, 0) pensamtp,
		   NVL(a.pensamtc, 0) pensamtc,
		   NVL(b.enterdt, ' ') enterdt,
		   NVL(b.retiredt, ' ') retiredt
	FROM   PSPENSM a
		   JOIN vnEMP b ON a.empcode = b.empcode
		   LEFT JOIN PSTAXRATEM c
			   ON a.yearmonth = c.yearmonth
				  AND 1 = 1
--				select * from vndept
/
