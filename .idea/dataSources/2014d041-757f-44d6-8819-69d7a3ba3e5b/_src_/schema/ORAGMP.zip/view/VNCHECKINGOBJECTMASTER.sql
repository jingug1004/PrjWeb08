CREATE VIEW VNCHECKINGOBJECTMASTER AS SELECT MEM12.divcode objdiv,
		   MEM12.divname objdivname,
		   equipmentcode objcode,
		   NVL(equipmentkorname, equipmentengname) objname,
		   modelno,
		   a.edayperiod1,
		   a.edayperiod5,
		   a.fdayperiod1,
		   a.fdayperiod5,
		   a.qdayperiod5,
		   a.cdayperiod5,
		   CASE WHEN NVL(MEM35.managecode, ' ') = ' ' THEN 'E' ELSE MEM35.managecode END detaildiv, --칭량구분(W)
		   b.workroomcode,
		   a.plantcode
	FROM   EquipmentMaster a
		   LEFT JOIN WorkroomMaster b ON a.workroomcode = b.workroomcode
		   LEFT JOIN CommonMaster MEM35
			   ON MEM35.cmmcode = 'MEM35'
				  AND b.workroomdiv = MEM35.divcode
		   LEFT JOIN CommonMaster MEM12
			   ON MEM12.cmmcode = 'MEM12'
				  AND MEM12.divcode = '01'
	UNION
	SELECT MEM12.divcode,
		   MEM12.divname,
		   equipmentcode,
		   NVL(equipmentkorname, equipmentengname) equipmentname,
		   modelno,
		   0,
		   a.edayperiod5,
		   0,
		   a.fdayperiod5,
		   a.qdayperiod5,
		   a.cdayperiod5,
		   CASE WHEN NVL(MEM35.managecode, ' ') = ' ' THEN 'T' ELSE MEM35.managecode END detaildiv, --칭량구분(W)
		   b.workroomcode,
		   a.plantcode
	FROM   TestEquipmentMaster a
		   LEFT JOIN WorkroomMaster b ON a.workroomcode = b.workroomcode
		   LEFT JOIN CommonMaster MEM35
			   ON MEM35.cmmcode = 'MEM35'
				  AND b.workroomdiv = MEM35.divcode
		   LEFT JOIN CommonMaster MEM12
			   ON MEM12.cmmcode = 'MEM12'
				  AND MEM12.divcode = '01'
	UNION
	SELECT MEM12.divcode objdiv,
		   MEM12.divname objname,
		   workroomcode,
		   workroomname,
		   '' modelno,
		   a.edayperiod1,
		   a.edayperiod5,
		   a.fdayperiod1,
		   a.fdayperiod5,
		   0,
		   0,
		   MEM35.managecode detaildiv,
		   a.workroomcode,
		   TO_CHAR(a.plantcode)
	FROM   WorkroomMaster a
		   LEFT JOIN CommonMaster MEM35
			   ON MEM35.cmmcode = 'MEM35'
				  AND a.workroomdiv = MEM35.divcode
		   LEFT JOIN CommonMaster MEM12
			   ON MEM12.cmmcode = 'MEM12'
				  AND MEM12.divcode = '02'
/
