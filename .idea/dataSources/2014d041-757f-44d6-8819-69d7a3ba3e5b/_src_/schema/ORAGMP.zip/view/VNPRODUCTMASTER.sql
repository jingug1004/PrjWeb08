CREATE VIEW VNPRODUCTMASTER AS SELECT a.itemcode itemcode, --품목코드
		   a.itemdiv itemdiv, --품목구분
		   b.managecode managecode, --품목구분(시스템)
		   b.divname itemdivname, --품목구분명(*)
		   a.itemkorname itemkorname, --품목명(국문)
		   a.itemshortname itemshortname, --품목명(약명)
		   a.itemengname itemengname, --품목명(영문)
		   NULL standarddiv, --시험규격코드
		   NULL standarddivname, --시험규격(*)
		   a.validityperiod validityperiod, --유통기한(월)
		   a.itemunit itemunit, --단위코드
		   c.divname itemunitname, --단위(*)
		   NULL keepingmethod, --보관방법
		   a.itemgbdiv itembranch, --품목분류코드
		   h.divname itembranchname, --품목분류(*)
		   a.keepingwarehouse keepingwarehouse, --보관창고코드
		   D.divname keepingwarehousename, --보관창고(*)
		   a.internaldiv internaldiv, --국내외구분코드(원자재/상품)
		   e.divname internaldivname, --국내외구분(*)
		   a.testcheck testcheck, --시험여부
		   a.safestockqty safestockqty, --안전재고량
		   a.buyperiod buyperiod, --구매기간
		   a.usediv usediv, --사용여부
		   CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
		   NULL notusediv, --미사용원인코드
		   NULL notusedivname, --미사용원인(*)
		   NULL revisionno, --관리번호(제조제품)
		   NULL contentqty, --함량Num(제조제품)
		   NULL contentunit, --함량단위코드(제조제품)
		   NULL unitweight, --단위중량(제조제품)
		   NULL contentunitname, --함량단위(*)
		   NULL contentqtyname, --함량Text(*)
		   NULL BATCHSIZE, --배치크기Num(제조제품)
		   NULL batchsizename, --배치크기Text(*)
		   NULL usage, --용법.용량(제조제품)
		   NULL efficacy, --효능/효과(제조제품)
		   NULL attention, --주의사항(제조제품)
		   NULL itemformdiv, --제품유형코드(제조제품)
		   NULL itemformdivname, --제품유형(*)
		   NULL standardyield, --표준수율(제조제품)
		   NULL maxmanageyield, --관리수율(상한)(제조제품)
		   NULL minmanageyield, --관리수율(하한)(제조제품)
		   NULL makingcost, --제조원가(제조,포장)
		   NULL docuno, --문서번호(제조,포장)
		   NULL productcheck, --생산여부(제조,포장)
		   NULL notproductdiv, --미생산원인코드(제조,포장)
		   NULL notproductdivname, --미생산원인(*)
		   NULL typicalitemcode, --대표제품코드(포장제품)
		   NULL typicalitemname, --대표제품명(*)
		   a.packingcnt packingunitqty, --포장단위량Num(포장제품)
		   fnNumericToString(a.packingcnt, 'S') + g.divname packingunitqtyname, --포장단위Text(*)
		   NULL packingtypediv, --포장타입코드(포장제품)
		   NULL packingtypedivname, --포장타입(*)
		   NULL typicalpackingcheck, --포장대표여부(포장제품)
		   NULL cartondiv, --지함종류코드(포장제품)
		   NULL cartondivname, --지함종류(*)
		   NULL cartonqty, --지함적재량(포장제품)
		   NULL barcode, --바코드(포장제품)
		   a.plantcode plantcode
	FROM   ProductMaster a
		   LEFT JOIN (SELECT divcode,
							 divname,
							 managecode
					  FROM	 vnCommonMaster
					  WHERE  cmmcode = 'CMM01'
							 AND managecode = '05') b
			   ON a.itemcode NOT IN (b.divcode)
		   LEFT JOIN vnCommonMaster c
			   ON c.cmmcode = 'CMM02'
				  AND c.divcode = a.itemunit
		   LEFT JOIN vnCommonMaster D
			   ON D.cmmcode = 'MPM11'
				  AND D.divcode = a.keepingwarehouse
		   LEFT JOIN vnCommonMaster e
			   ON e.cmmcode = 'MPM15'
				  AND e.divcode = a.internaldiv
		   --left join vnCommonMaster f on f.cmmcode = 'MPM08' and f.divcode = a.enteringrackdiv

		   LEFT JOIN vnCommonMaster g
			   ON g.cmmcode = 'CMM02'
				  AND g.divcode = a.itemunit
		   LEFT JOIN CommonMaster h
			   ON a.itemgbdiv = h.divcode
				  AND h.cmmcode = 'CM27'
/
