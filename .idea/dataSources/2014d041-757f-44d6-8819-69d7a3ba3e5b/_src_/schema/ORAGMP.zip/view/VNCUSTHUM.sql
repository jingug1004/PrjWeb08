CREATE VIEW VNCUSTHUM AS SELECT a.plantcode, -- isnull(a.plantcode,'') as plantcode
		   NVL(b.empcode, ' ') empcode,
		   NVL(b.empname, ' ') || ' ' || NVL(b.jikwi, ' ') empname,
		   NVL(b.topdeptcode, ' ') topdeptcode,
		   NVL(b.topdeptname, ' ') topdeptname,
		   NVL(b.predeptcode, ' ') predeptcode,
		   NVL(b.predeptname, ' ') predeptname,
		   NVL(b.deptcode, ' ') deptcode,
		   NVL(b.deptname, ' ') deptname,
		   a.custcode, -- isnull(a.custcode,'') as custcode
		   NVL(b.custname, ' ') custname,
		   NVL(b.utdiv, ' ') utdiv,
		   NVL(b.utdivnm, ' ') utdivnm,
		   NVL(e.divname, ' ') sagodivnm,
		   NVL(a.seq, 0) seq,
		   NVL(a.relname, ' ') relname,
		   NVL(a.relation, ' ') relation,
		   NVL(a.position, ' ') position,
		   NVL(a.office, ' ') office,
		   NVL(a.fmsex, ' ') fmsex,
		   NVL(c.divname, ' ') fmsexnm,
		   NVL(a.birthday, ' ') birthday,
		   NVL(a.birthdaydiv, ' ') birthdaydiv,
		   NVL(D.divname, ' ') birthdaydivnm,
		   NVL(a.postcode, ' ') postcode,
		   NVL(a.addr1, ' ') addr1,
		   NVL(a.addr2, ' ') addr2,
		   NVL(b.POST, ' ') custpost,
		   NVL(b.addr1, ' ') custaddr1,
		   NVL(b.addr2, ' ') custaddr2,
		   NVL(b.telno, ' ') custtelno,
		   NVL(a.telno, ' ') telno,
		   NVL(a.hpno, ' ') hpno,
		   NVL(a.email, ' ') email,
		   NVL(a.highschool, ' ') highschool,
		   NVL(a.university, ' ') university,
		   NVL(a.majorstudy, ' ') majorstudy,
		   NVL(a.majorstudyd, ' ') majorstudyd,
		   NVL(a.weddingday, ' ') weddingday,
		   NVL(a.interestremark, ' ') interestremark,
		   NVL(a.specialremark, ' ') specialremark,
		   NVL(a.noticeremark, ' ') noticeremark,
		   NVL(a.charremark, ' ') charremark,
		   NVL(a.bedcnt, 0) bedcnt,
		   NVL(a.jongcnt, 0) jongcnt,
		   NVL(a.doctorcnt, 0) doctorcnt,
		   NVL(a.sickcnt, 0) sickcnt,
		   NVL(a.opendate, ' ') opendate,
		   NVL(b.opendate, ' ') custopendate,
		   NVL(b.stopdate, ' ') stopdate,
		   NVL(b.custdiv, ' ') custdiv,
		   NVL(b.hinoutdiv, ' ') hinoudiv,
		   NVL(b.findname, ' ') findname
	FROM   CMCUSTHUMD a
		   JOIN vnCUST b ON a.custcode = b.custcode
		   LEFT JOIN CMCOMMONM c
			   ON a.fmsex = c.divcode
				  AND c.cmmcode = 'SL32'
		   LEFT JOIN CMCOMMONM D
			   ON a.birthdaydiv = D.divcode
				  AND D.cmmcode = 'SL33'
		   LEFT JOIN CMCOMMONM e
			   ON b.sagodiv = e.divcode
				  AND e.cmmcode = 'CM20'
/
