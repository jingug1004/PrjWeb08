CREATE VIEW VNPSYEAR AS SELECT NVL(a.plantcode, '') plantcode,
		   NVL(a.taxyear, '') taxyear,
		   NVL(a.calcyymm, '') calcyymm, --  정산년월
		   NVL(a.empcode, '') empcode,
		   NVL(b.householder, '') householder, -- 세대주여부
		   NVL(a.yeardiv, '') yeardiv, -- 0:연말정산, 1:중도퇴사
		   NVL(T.divname, '') yeardivnm, --
		   NVL(b.liveyn, 'N') liveyn, -- 거주구분  N:거주자, Y:비거주자
		   NVL(b.nationyn, 'N') nationyn, -- 외국인구분  N:내국인, Y:외국인
		   NVL(b.nationcode, '') nationcode, -- 국적코드
		   NVL(b.fixtaxyn, 'N') fixtaxyn, -- 외국인단일세율 적용
		   NVL(b.worksdt, '') worksdt, -- 근무시작일
		   NVL(b.workedt, '') workedt, -- 근무종료일
		   NVL(b.reducesdt, '') reducesdt, -- 감면기간시작
		   NVL(b.reduceedt, '') reduceedt, -- 감면기간종료
		   NVL(D.enterdt, '') enterdt, -- 입사일자
		   NVL(D.retiredt, '') retiredt, -- 퇴사일자
		   NVL(D.personid, '') personid, -- 주민번호
		   NVL(E.topdeptcode, '') topdeptcode, -- 부서
		   NVL(E.predeptcode, '') predeptcode, -- 지점
		   D.deptcode, -- 팀
		   NVL(E.topdeptname, '') topdeptname, -- 부서명
		   NVL(E.predeptname, '') predeptname, -- 지점명
		   NVL(E.deptname, '') deptname, -- 팀명
		   NVL(E.findname, '') findname, -- 부서검색
		   D.empname, -- 사원명
		   D.workdiv, -- 근무지
		   NVL(S.divname, '') workdivnm, -- 근무지명
		   D.sexdiv, -- 성별
		   NVL(h.divname, '') sexdivnm,
		   D.empdiv, -- 사원구분
		   NVL(i.divname, '') empdivnm,
		   D.enterdiv, -- 입사구분
		   NVL(P.divname, '') enterdivnm,
		   D.positiondiv, -- 직위
		   NVL(f.divname, '') jikwi,
		   D.gradediv, -- 직급
		   NVL(j.divname, '') gradedivnm,
		   D.empstep, -- 호봉
		   D.responsibilitydiv, -- 직종
		   NVL(G.divname, '') responsibilitydivnm,
		   D.classdiv, -- 직책
		   NVL(D.address || '' || D.detailaddress, '') ADDRESS, -- 주소
		   NVL(Q.divname, '') classdivnm,
		   NVL(a.precompcnt, 0) precompcnt, -- 종전근무처수
		   NVL(a.payamt, 0) payamt, -- 주현총액
		   NVL(b.payamt, 0) salaryamt, -- 급여총액
		   NVL(b.bonusamt, 0) bonusamt, -- 상여총액
		   NVL(b.bonusinamt, 0) bonusinamt, -- 인정상여
		   NVL(b.stockamt, 0) stockamt, -- 주민매수선택권행사이익
		   NVL(b.wooriinamt, 0) wooriinamt, -- 우리사주조합인출금
		   NVL(a.precompamt, 0) precompamt, -- 종전총액
		   NVL(a.ntaxamt, 0) ntaxamt, -- 주현비과세
		   NVL(a.precompntaxamt, 0) precompntaxamt, -- 종전비과세
		   NVL(a.totpayamt, 0) totpayamt, -- 총급여액
		   NVL(a.totamt, 0) totamt, -- 총액(비과세포함)
		   NVL(a.incomsub, 0) incomsub, -- 근로소득공제
		   NVL(a.incomamt, 0) incomamt, -- 근로소득금액
		   NVL(a.boninsub, 0) boninsub, -- 본인공제
		   NVL(a.wifesub, 0) wifesub, -- 배우자공제
		   NVL(a.familycnt, 0) familycnt, -- 부양가족공제인원
		   NVL(a.familysub, 0) familysub, -- 부양가족공제
		   NVL(a.oldcnt, 0) oldcnt, -- 경로우대인원
		   NVL(a.oldsub, 0) oldsub, -- 경로우대공제
		   NVL(a.obscnt, 0) obscnt, -- 장애인인원
		   NVL(a.obssub, 0) obssub, -- 장애인공제
		   NVL(a.womansub, 0) womansub, -- 부녀자공제
		   NVL(a.bringcnt, 0) bringcnt, -- 자녀양육비인원
		   NVL(a.bringsub, 0) bringsub, -- 자녀양육비공제
		   NVL(a.borncnt, 0) borncnt, -- 출산입양인원
		   NVL(a.bornsub, 0) bornsub, -- 출산입양공제
		   NVL(a.manysoncnt, 0) manysoncnt, -- 다자녀인원
		   NVL(a.manysonsub, 0) manysonsub, -- 다자녀공제
		   NVL(a.penssub, 0) penssub, -- 국민연금공제
		   NVL(a.etcpenssub, 0) etcpenssub, -- 기타연금공제
		   NVL(a.retiresub, 0) retiresub, -- 퇴직연금공제
		   NVL(a.insusub, 0) insusub, -- 보험료공제
		   NVL(a.medisub, 0) medisub, -- 의료비공제
		   NVL(a.edusub, 0) edusub, -- 교육비공제
		   NVL(a.houseimsub, 0) houseimsub, -- 주택임차차임금원리금상환액공제_대출기관
		   NVL(a.houseimgsub, 0) houseimgsub, -- 주택임차차임금원리금상환액공제_거주자
		   NVL(a.housejusub, 0) housejusub, -- 장기주택저당차입금이자상환액공제_15년미만
		   NVL(a.houseju15sub, 0) houseju15sub, -- 장기주택저당차입금이자상환액공제_15~29년
		   NVL(a.houseju30sub, 0) houseju30sub, -- 장기주택저당차입금이자상환액공제_30년이상
		   NVL(a.housegosub, 0) housegosub, -- (2012년 이후 차입분)고정금리?비거치 상환 대출
		   NVL(a.houseetcsub, 0) houseetcsub, -- (2012년 이후 차입분)기타 대출
		   NVL(a.housemonsub, 0) housemonsub, -- 월세공제   계산변경
		   NVL(a.givesub, 0) givesub, -- 기부금공제
		   NVL(a.spesubtot, 0) spesubtot, -- 특별공제계
		   NVL(a.stdsub, 0) stdsub, -- 표준공제
		   NVL(a.subincomamt, 0) subincomamt, -- 차감소득금액
		   NVL(a.pensperssub, 0) pensperssub, -- 개인연금저축공제
		   NVL(a.penssavesub, 0) penssavesub, -- 연금저축공제
		   NVL(a.mincorpsub, 0) mincorpsub, -- 소기업/소상공인공제부금
		   NVL(a.housesavesub, 0) housesavesub, -- 주택마련저축공제
		   NVL(a.invcorpsub, 0) invcorpsub, -- 중소기업창업투자조합출자등 소득공제
		   NVL(a.cardsub, 0) cardsub, -- 신용카드등사용금액공제
		   NVL(a.woorisub, 0) woorisub, -- 우리사주조합출연금공제
		   NVL(a.stocksavesub, 0) stocksavesub, -- 장기주식형저축소득공제
		   NVL(a.empleadsub, 0) empleadsub, -- 고용유지중소기업근로자공제
		   NVL(a.etcsubtot, 0) etcsubtot, -- 그밖의 소득공제계
		   NVL(a.stdtaxamt, 0) stdtaxamt, -- 종합소득과세표준
		   NVL(a.calctaxamt, 0) calctaxamt, -- 산출세액
		   NVL(a.taxincsub, 0) taxincsub, -- 세액감면(소득세법)
		   NVL(a.taxspesub, 0) taxspesub, -- 세액감면(조특법)
		   NVL(a.taxincspetot, 0) taxincspetot, -- 세액감면계
		   NVL(a.incomtaxsub, 0) incomtaxsub, -- 근로소득세액공제
		   NVL(a.taxcombsub, 0) taxcombsub, -- 을근납세조합공제
		   NVL(a.houseloansub, 0) houseloansub, -- 주택자금차입금이자세액공제
		   NVL(a.givegosub, 0) givegosub, -- 정치자금기부금세액공제
		   NVL(a.fortaxsub, 0) fortaxsub, -- 외국납부세액공제
		   NVL(a.cnreducesub, 0) cnreducesub, -- 청년취업세액공제
		   NVL(a.taxsubtot, 0) taxsubtot, -- 세액공제계
		   NVL(a.fixincometax, 0) fixincometax, -- 결정소득세
		   NVL(a.fixresitax, 0) fixresitax, -- 결정주민세
		   NVL(a.fixfarmtax, 0) fixfarmtax, -- 결정농특세
		   NVL(a.fixtaxtot, 0) fixtaxtot, -- 결정세액계
		   NVL(a.payincometax, 0) payincometax, -- 기납부소득세
		   NVL(a.payresitax, 0) payresitax, -- 기납부주민세
		   NVL(a.payfarmtax, 0) payfarmtax, -- 기납부농특세
		   NVL(a.paytaxtot, 0) paytaxtot, -- 기납부세액계
		   NVL(a.preincometax, 0) preincometax, -- 종전소득세
		   NVL(a.preresitax, 0) preresitax, -- 종전주민세
		   NVL(a.prefarmtax, 0) prefarmtax, -- 종전농특세
		   NVL(a.pretaxtot, 0) pretaxtot, -- 종전세액계
		   NVL(a.subincometax, 0) subincometax, -- 차감소득세
		   NVL(a.subresitax, 0) subresitax, -- 차감주민세
		   NVL(a.subfarmtax, 0) subfarmtax, -- 차감농특세
		   NVL(a.subtaxtot, 0) subtaxtot, -- 차감세액계
		   NVL(a.fixyn, '') fixyn, -- 마감여부
		   CASE WHEN NVL(a.fixyn, 'N') = 'N' THEN '미마감' ELSE '마감' END fixynnm
	FROM   PSYEARM a
		   JOIN PSYEARBASEM b
			   ON a.taxyear = b.taxyear
				  AND a.empcode = b.empcode
		   JOIN CMEMPM D ON a.empcode = D.empcode
		   LEFT JOIN vnDEPT E ON D.deptcode = E.deptcode
		   LEFT JOIN CMCOMMONM f
			   ON D.positiondiv = f.divcode
				  AND UPPER(f.cmmcode) = 'PS29'
		   LEFT JOIN CMCOMMONM G
			   ON D.responsibilitydiv = G.divcode
				  AND UPPER(G.cmmcode) = 'PS07'
		   LEFT JOIN CMCOMMONM h
			   ON D.sexdiv = h.divcode
				  AND UPPER(h.cmmcode) = 'PS30'
		   LEFT JOIN CMCOMMONM i
			   ON D.empdiv = i.divcode
				  AND UPPER(i.cmmcode) = 'PS41'
		   LEFT JOIN CMCOMMONM j
			   ON D.gradediv = j.divcode
				  AND UPPER(j.cmmcode) = 'PS01'
		   LEFT JOIN CMCOMMONM P
			   ON D.enterdiv = P.divcode
				  AND UPPER(P.cmmcode) = 'PS09'
		   LEFT JOIN CMCOMMONM Q
			   ON D.classdiv = Q.divcode
				  AND UPPER(Q.cmmcode) = 'PS42'
		   LEFT JOIN CMCOMMONM S
			   ON D.workdiv = S.divcode
				  AND UPPER(S.cmmcode) = 'PS26'
		   LEFT JOIN CMCOMMONM T
			   ON a.yeardiv = T.divcode
				  AND UPPER(T.cmmcode) = 'PS92'
/
