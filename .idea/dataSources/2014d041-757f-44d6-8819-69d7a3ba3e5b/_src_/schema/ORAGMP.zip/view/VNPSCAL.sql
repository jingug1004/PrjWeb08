CREATE VIEW VNPSCAL AS SELECT a.plantcode,
		   a.workdiv,
		   c.divname workdivnm,
		   a.calymd,
		   a.daydiv,
		   CASE WHEN a.daydiv = '7' THEN '토요일' WHEN a.daydiv = '1' THEN '일요일' WHEN a.daydiv = '2' THEN '월요일' WHEN a.daydiv = '3' THEN '화요일' WHEN a.daydiv = '4' THEN '수요일' WHEN a.daydiv = '5' THEN '목요일' WHEN a.daydiv = '6' THEN '금요일' END daydivnm,
		   a.caldiv,
		   b.divname caldivnm,
		   NVL(e.stdstime, ' ') stdstime,
		   NVL(e.stdetime, ' ') stdetime,
		   NVL(e.reststime, ' ') reststime,
		   NVL(e.restetime, ' ') restetime,
		   NVL(e.yjstime, ' ') yjstime,
		   NVL(e.yjetime, ' ') yjetime,
		   NVL(e.ygstime, ' ') jgstime,
		   NVL(e.ygetime, ' ') ygetime,
		   NVL(e.jcstime, ' ') jcstime,
		   NVL(e.jcetime, ' ') jcetime,
		   NVL(e.stdhour, 0) stdhour,
       NVL(e.resthour, 0) resthour,
       NVL(e.yjhour, 0) yjhour,
       NVL(e.yghour, 0) yghour,
       NVL(e.jchour, 0) jchour
  --,ISNULL(e.monthhour,0) as monthhour
  FROM   PSCALM a
       JOIN CMCOMMONM b
         ON a.caldiv = b.divcode
          AND b.cmmcode = 'PS06'
       JOIN CMCOMMONM c
         ON a.workdiv = c.divcode
          AND c.cmmcode = 'PS26'
       LEFT JOIN PSWORKTIMEM e ON a.workdiv = e.workdiv
--        select * from PSWORKTIMEM
/
