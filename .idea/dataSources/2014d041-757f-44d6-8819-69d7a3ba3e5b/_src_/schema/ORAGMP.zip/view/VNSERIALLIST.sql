CREATE VIEW VNSERIALLIST AS SELECT a.SNT_GTIN gtin,
		   a.SNT_SERIAL serialno,
		   a.SNT_ITEM gtinserialno,
		   a.SNT_LOT_NUMBER lotno,
		   --,c.itemcode
		   SNT_SERIAL_TYPE bundletype,
		   b.bundle1,
		   b.bundle2,
		   SNT_USED_STATUS statusyn
	FROM   SERIAL_NUMBER_COPY a
		   LEFT JOIN (SELECT SNT_ITEM bundle1,
							 SNT_PARENT bundle2
					  FROM	 SERIAL_NUMBER_COPY
					  WHERE  SNT_SERIAL_TYPE IN ('1', '2')) b
			   ON a.SNT_PARENT = b.bundle1
	WHERE  SNT_USED_STATUS = 'N' --AND SNT_SERIAL_STATUS != 60
	UNION
	SELECT RTRIM(LTRIM(a.SNT_GTIN)) gtin,
		   a.SNT_SERIAL serialno,
		   a.SNT_ITEM gtinserialno,
		   a.SNT_LOT_NUMBER lotno,
		   SNT_SERIAL_TYPE bundletype,
		   b.bundle1,
		   b.bundle2,
		   SNT_USED_STATUS statusyn
	FROM   SERIAL_NUMBER_XML a
		   LEFT JOIN (SELECT SNT_ITEM bundle1,
							 SNT_PARENT bundle2
					  FROM	 SERIAL_NUMBER_XML
					  WHERE  SNT_SERIAL_TYPE IN ('1', '2')) b
			   ON a.SNT_PARENT = b.bundle1
	WHERE  SNT_USED_STATUS = 'N'
/
