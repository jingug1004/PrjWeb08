CREATE VIEW VNPRODUCTRESULTS AS SELECT a.warehousingdiv, -- 입고구분(01:원자재, 02:상품, 03:위탁반제품)
		   a.warehousingno, -- 입고번호
		   --      ,case a.warehousingdiv
		   --when '02' then a.itemcode
		   --when '03' then e.itemcode
		   -- end as itemcode     -- 품목코드(상품)
		   a.itemcode,
		   a.warehousingdt, -- 입고일시
		   a.custcode, -- 구매처코드
		   c.custname, -- 구매처명
		   a.manufacturecode, -- 제조처코드
		   D.custname manufacturename, -- 제조처명
		   a.lotdate, -- 제조일자
		   a.lotno, -- 제조번호
		   a.validityperiod, -- 유통기한
		   a.totalwarehousingqty - NVL(b.totalwarehousingreturnqty, 0) totalwarehousingreturnqty, -- 총입고수량
		   a.buydiv, --
		   a.warehousingprice - NVL(warehousingreturningprice, 0) warehousingreturningprice, -- 단가
		   a.warehousingamt - NVL(warehousingreturningamt, 0) warehousingamt, -- 금액
		   a.vat - NVL(b.vat, 0) vat, -- 부가세
		   a.warehousediv, -- 창고구분
		   NVL(a.samplingpackqty, 0) samplingpackqty, -- 검체량
		   a.warehousingremark, -- 비고
		   a.warehousingtestresult, -- 입고검수결과
		   a.warehousingstate, -- 입고상태
		   a.testno, -- 시험의뢰번호
		   a.plantcode, -- 사업장코드
		   a.testresult, -- 시험결과
		   a.warehousestate -- 영업관련 제품입고필드
	--,a.orderno     -- 발주번호

	--,a.testdt     -- 입고검수일시

	-- ,a.packingqty - ISNULL(b.packingqty,0)

	--as  packingqty   -- 팩수량(ex) 1통, 2통...)

	--,a.totalwarehousingtestqty -- 총입고검수수량

	--,a.classifyjudgerate   -- 함량

	--,a.classifyjudgerateB  -- 함량B

	--,a.retestdate    -- 재시험일자
	FROM   Warehousing a
		   LEFT JOIN WarehousingReturning b ON a.warehousingno = b.warehousingno
		   LEFT JOIN CMCUSTM c ON a.custcode = c.custcode
		   LEFT JOIN CMCUSTM D ON a.manufacturecode = D.custcode
	--left outer join ItemRelation e

/
