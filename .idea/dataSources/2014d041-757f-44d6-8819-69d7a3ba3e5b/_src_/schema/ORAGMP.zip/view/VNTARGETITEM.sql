CREATE VIEW VNTARGETITEM AS SELECT	 a.plantcode,
			 a.yearmonth,
			 NVL(b.topdeptcode, '') AS topdeptcode,
			 NVL(b.seqtopdeptcode, '') AS seqtopdeptcode,
			 NVL(b.topdeptname, '') AS topdeptname,
			 NVL(b.predeptcode, '') AS predeptcode,
			 NVL(b.seqpredeptcode, '') AS seqpredeptcode,
			 NVL(b.predeptname, '') AS predeptname,
			 a.deptcode,
			 NVL(b.seqdeptcode, '') AS seqdeptcode,
       NVL(b.deptname, '') AS deptname,
       NVL(b.findname, '') AS findname,
       a.empcode,
       NVL(c.empname, '') AS empname,
       NVL(c.positiondiv, '') AS positiondiv,
       NVL(E.divname, '') AS jikwi,
       NVL(f.mitemcode, '') AS mitemcode,
       a.itemcode,
       NVL(f.itemname, '') AS itemname,
       NVL(f.itemunit, '') AS unit,
       NVL(f.unitqty, 0) AS unitqty,
       NVL(f.drugdiv, '') AS drugdiv,
       NVL(f.drugdivnm, '') AS drugdivnm,
       NVL(f.formdiv, '') AS formdiv,
       NVL(f.formdivnm, '') AS formdivnm,
       NVL(f.itempart, '') AS itempart,
       NVL(f.itempartnm, '') AS itempartnm,
       NVL(f.effectdiv, '') AS effectdiv,
       NVL(f.effectdivnm, '') AS effectdivnm,
       NVL(f.mainitemyn, '') AS mainitemyn,
       NVL(f.medimaxprc, '') AS medimaxprc,
       CASE WHEN NVL(f.mainitemyn, '') = 'Y' THEN '주력' ELSE '' END AS mainitemynnm,
       NVL(a.tarqty, 0) AS tarqty,
       NVL(a.drugprc, 0) AS drugprc,
       NVL(a.taramt, 0) AS taramt,
       NVL(c.retiredt, '') AS retiredt,
       NVL(b.deptgroup, '') AS deptgroup,
       f.repreitemcode -- 대표제품 추가 20140107:이세민
  FROM   SLTARGETitemM a
       LEFT JOIN vnDept b ON a.deptcode = b.deptcode
       LEFT JOIN CMEMPM c ON a.empcode = c.empcode
       LEFT JOIN CMCOMMONM E
         ON c.positiondiv = E.divcode
          AND E.cmmcode = 'PS29'
       LEFT JOIN vnItem f ON a.itemcode = f.itemcode
       JOIN vnDept h ON a.deptcode = h.deptcode
  -- MS SQL
  -- TOP (100) PERCENT
  -- ORACLE
  /*
       ROWNUM <=   TRUNC((
                           SELECT  COUNT(*)
                           FROM    SLTARGETitemM a
                                   LEFT JOIN vnDept b    ON a.deptcode = b.deptcode
                                   LEFT JOIN CMEMPM c    ON a.empcode = c.empcode
                                   LEFT JOIN CMCOMMONM E ON c.positiondiv = E.divcode
                                                            AND E.cmmcode = 'PS29'
                                   LEFT JOIN vnItem f    ON a.itemcode = f.itemcode
                                   JOIN vnDept h         ON a.deptcode = h.deptcode
                         ) / PERCENT값 )
       */
  ORDER BY a.plantcode, a.yearmonth, a.deptcode, a.empcode, a.itemcode
/
