CREATE VIEW NVSALESTOCK AS SELECT A.ITEMCODE
                      ,      SUM(BASEQTY)                                                    AS BASEQTY       -- 기초재고
                      ,      SUM(SALQTY)                                                     AS SALQTY        -- 주문수량
                      ,      SUM(OUTPUTQTY)                                                  AS OUTPUTQTY     -- 출고수량
                      ,      MAX(C.CONTROLQTY)                                               AS CONTROLQTY    -- 품절방지수량
                             --가용재고 = 현재고 - 주문수량 - 출고수량 - 품절방지수량
                      ,      SUM(BASEQTY) - SUM(SALQTY) - SUM(OUTPUTQTY) - MAX(C.CONTROLQTY) AS STOCKQTY      -- 재고수량
                      FROM  (
                            SELECT ITEMCODE
                            ,      SUM(QTY)         AS BASEQTY           -- 기초재고
                            ,      0                AS SALQTY            -- 주문수량
                            ,      0                AS OUTPUTQTY         -- 출고수량
                            FROM   SLWAREHOUSEM
                            WHERE  STOPYN   = 'N'                        -- 제조번호단위 출하중지 제외
                            GROUP  BY ITEMCODE

                            UNION  ALL

                            SELECT A.ITEMCODE
                            ,      0                AS BASEQTY
                            ,      SUM(A.SALQTY  )   AS SALQTY
                            ,      SUM(A.OUTPUTQTY) AS OUTPUTQTY
                            FROM   SLORDD A
                                   INNER JOIN SLORDM B
                                   ON  B.PLANTCODE = A.PLANTCODE
                                   AND B.ORDERNO   = A.ORDERNO
                                   AND B.SALDIV    LIKE 'A%'
                                   AND B.SALDIV    NOT IN ('A03', 'A07', 'A25', 'A40', 'A51', 'A53')  -- SL10 : A03. 이기(사용),
                                                                                                      --      : A07. 단가인상(사용안함)
                                                                                                      --      : A25. 코드없음(사용안함)
                                                                                                      --      : A40. 수정판매(사용안함)
                                                                                                      --      : A51. 코드없음(사용안함)
                                                                                                      --      : A53. 결제판매(사용안함)
                                   AND B.STATEDIV  NOT IN ('99')  -- 결재구분 : 99.반려
                            WHERE  1=1
                            AND    A.SALQTY   > A.OUTPUTQTY
                            GROUP  BY A.ITEMCODE ) A

                            INNER JOIN CMITEMM C
                            ON  A.ITEMCODE = C.ITEMCODE

                      GROUP BY A.ITEMCODE
                      --HAVING SUM(BASEQTY) - SUM(SALQTY) - SUM(OUTPUTQTY) < 0
/
