CREATE VIEW VNITEMINOUT AS SELECT a.plantcode,
		   NVL(gubun, ' ') gubun,
		   NVL(gubunnm, ' ') gubunnm,
		   a.inoutdate, -- isnull(a.inoutdate,'') as inoutdate
		   NVL(a.inoutseq, 0) inoutseq,
		   NVL(a.orderno, ' ') inoutno,
		   a.inoutdiv, -- isnull(a.inoutdiv,'') as inoutdiv
		   NVL(c.divname, ' ') inoutdivnm,
		   a.itemcode, -- isnull(a.itemcode,'') as itemcode
		   NVL(b.itemname, ' ') itemname,
		   NVL(b.itemunit, ' ') unit,
		   NVL(b.drugdiv, ' ') drugdiv, --의약구분(전문,일반...)
		   NVL(b.drugdivnm, ' ') drugdivnm,
		   NVL(b.formdiv, ' ') formdiv, --제형(정제, 주사제...)
		   NVL(b.formdivnm, ' ') formdivnm,
		   NVL(b.itempart, ' ') itempart, --제품종류(제품,상품...)
		   NVL(b.itempartnm, ' ') itempartnm,
		   NVL(b.effectdiv, ' ') effectdiv, --주효능(호흡기용, 소화기용...)
		   NVL(b.effectdivnm, ' ') effectdivnm,
		   NVL(b.productdiv, ' ') productdiv, --생산구분
		   NVL(b.productdivnm, ' ') productdivnm,
		   NVL(b.itemtype, ' ') itemtype, --제품유형
		   NVL(b.itemtypenm, ' ') itemtypenm,
		   NVL(a.lotno, ' ') lotno,
		   NVL(a.unitqty, 0) unitqty,
		   NVL(a.qty, 0) qty,
		   NVL(a.lotdate, ' ') lotdate,
		   NVL(a.expdate, ' ') expdate,
		   NVL(a.warehouse, ' ') warehouse,
		   NVL(D.whname, ' ') whname,
		   NVL(a.location, ' ') location,
		   NVL(a.custcode, ' ') custcode,
		   NVL(e.custname, ' ') custname,
		   NVL(e.addr1, ' ') addr1,
		   NVL(e.addr2, ' ') addr2,
		   NVL(D.workdiv, ' ') workdiv,
		   NVL(f.divname, ' ') workdivnm,
		   NVL(a.unitchg, ' ') unitchg,
		   --,isnull(b.maker,'') as maker
		   --,isnull(b.makername,'') as makername
		   NVL(a.qty, 0) * NVL(b.drugprc, 0) amt,
		   NVL(a.returnyn, 'N') returnyn
	FROM   (SELECT plantcode,
				   'out' gubun,
				   '출고' gubunnm,
				   outdate inoutdate,
				   outseq inoutseq,
				   orderno,
				   ' ' inoutdiv,
				   ' ' custcode,
				   itemcode,
				   lotno,
				   lotdate,
				   expdate,
				   0 unitqty,
				   outqty qty,
				   warehouse,
				   location,
				   'N' unitchg,
				   --,returnyn
				   ' ' returnyn
			FROM   SLITEMTAKINGOUT --MES연동처리 20131126:이세민
			UNION ALL
			SELECT plantcode,
				   'out' gubun,
				   '출고' gubunnm,
				   outdate inoutdate,
				   outseq inoutseq,
				   orderno,
				   outdiv inoutdiv,
				   custcode,
				   itemcode,
				   lotno,
				   lotdate,
				   expdate,
				   0 unitqty,
				   outqty qty,
				   warehouse,
				   location,
				   'N' unitchg,
				   returnyn
			FROM   SLITEMTAKINGOUTETC
			UNION ALL
			SELECT plantcode,
				   'in' gubun,
				   '입고' gubunnm,
				   indate,
				   inseq,
				   inputno,
				   indiv,
				   custcode,
				   itemcode,
				   lotno,
				   lotdate,
				   expdate,
				   --,isnull(unitqty,0) as unitqty
				   0 unitqty,
				   inqty,
				   warehouse,
				   location,
				   ' ' unitchg,
				   ' ' returnyn
			FROM   SLITEMWAREHOUSING --MES연동처리 20131126:이세민
									) a
		   LEFT JOIN vnItem b ON a.itemcode = b.itemcode
		   LEFT JOIN CMCOMMONM c
			   ON a.inoutdiv = c.divcode
				  AND c.cmmcode = 'SL25'
		   --left join dbo.slstorehousem (nolock) as d

		   LEFT JOIN SLSTOREHOUSEM -->>연동처리 20131127:이세민
								  D ON a.warehouse = D.warehouse
		   LEFT JOIN CMCUSTM e ON a.custcode = e.custcode
		   LEFT JOIN CMCOMMONM f
			   ON D.workdiv = f.divcode
				  AND f.cmmcode = 'PS26'
--select * from CMCOMMONM where cmmcode = 'SL25'
--select * from vnitem
/
