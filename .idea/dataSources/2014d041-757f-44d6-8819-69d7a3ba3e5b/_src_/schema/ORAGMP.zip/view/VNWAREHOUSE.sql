CREATE VIEW VNWAREHOUSE AS SELECT a.plantcode,
          a.warehouse,
          c.whname,
          a.location,
          b.mitemcode,
          a.itemcode,
          b.itemname,
          b.itemunit unit,
          NVL (b.drugdiv, '') drugdiv,                        --의약구분(전문,일반...)
          NVL (b.drugdivnm, '') drugdivnm,
          NVL (b.formdiv, '') formdiv,                        --제형(정제, 주사제...)
          NVL (b.formdivnm, '') formdivnm,
          NVL (b.itempart, '') itempart,                      --제품종류(제품,상품...)
          NVL (b.itempartnm, '') itempartnm,
          NVL (b.effectdiv, '') effectdiv,                --주효능(호흡기용, 소화기용...)
          NVL (b.effectdivnm, '') effectdivnm,
          NVL (b.productdiv, '') productdiv,                            --생산구분
          NVL (b.productdivnm, '') productdivnm,
          NVL (b.itemtype, '') itemtype,                                --제품유형
          NVL (b.itemtypenm, '') itemtypenm,
          lotno,
          lotdate,
          expdate,
          qty,
          qty * NVL (b.drugprc, 0) amt,
          b.drugprc,
          b.makingcost,
          c.workdiv,
          NVL (e.divname, '') workdivnm,
          NVL (b.maker, '') maker,
          NVL (b.makername, '') makername,
          NVL (f.locname, '') locname
     FROM SLWAREHOUSEM a
          JOIN vnitem b
             ON a.itemcode = b.itemcode
          LEFT JOIN SLSTOREHOUSEM c
             ON a.warehouse = c.warehouse
          LEFT JOIN CMCOMMONM e
             ON c.workdiv = e.divcode AND e.cmmcode = 'PS26'
          LEFT JOIN SLLOCATIONM f
             ON a.warehouse = f.warehouse
                AND RTRIM (a.location) = RTRIM (f.location)
/
