CREATE VIEW VNPSWORKEXP AS SELECT NVL(a.plantcode, ' ') plantcode,
		   NVL(a.expno, ' ') expno,
		   NVL(a.expremark, ' ') expremark,
		   NVL(a.empcode, ' ') empcode,
		   NVL(c.empname, ' ') empname,
		   NVL(c.positiondiv, ' ') positiondiv,
		   NVL(c.jikwi, ' ') jikwi,
		   NVL(a.deptcode, ' ') deptcode,
		   NVL(b.topdeptcode, ' ') topdeptcode,
		   NVL(b.topdeptname, ' ') topdeptname,
		   NVL(b.predeptcode, ' ') predeptcode,
		   NVL(b.predeptname, ' ') predeptname,
		   NVL(b.deptname, ' ') deptname,
		   NVL(b.findname, ' ') findname,
		   NVL(a.workdate1, ' ') workdate1,
		   NVL(a.worktm1, ' ') worktm1,
		   NVL(a.workdate2, ' ') workdate2,
		   NVL(a.worktm2, ' ') worktm2,
		   NVL(a.attenddiv, ' ') attenddiv,
		   NVL(f.divname, ' ') attenddivnm,
		   NVL(a.statediv, ' ') appyn,
		   CASE WHEN NVL(a.statediv, 'N') = 'N' THEN '미승인' ELSE '승인' END appynnm,
		   NVL(a.insertdt, NULL) insertdt,
		   NVL(a.iempcode, ' ') iempcode,
		   NVL(a.updatedt, NULL) updatedt,
		   NVL(a.uempcode, ' ') uempcode,
		   NVL(a.indate, NULL) indate,
		   NVL(c.workdiv, ' ') workdiv,
		   NVL(D.divname, ' ') workdivnm,
		   a.destination,
           a.returnreason
	FROM   PSWORKEXPM a
		   LEFT JOIN vnDEPT b ON a.deptcode = b.deptcode
		   LEFT JOIN vnEMP c
			   ON a.empcode = c.empcode
				  AND c.empdiv <> '09'
		   LEFT JOIN CMCOMMONM D
			   ON D.cmmcode = 'PS26'
				  AND c.workdiv = D.divcode
		   LEFT JOIN CMCOMMONM f
			   ON f.cmmcode = 'PS08'
				  AND a.attenddiv = f.divcode
/
