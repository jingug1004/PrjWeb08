CREATE VIEW TEST_VIEW AS select	c1
    from	test_table
    where	c1 = 1
/
