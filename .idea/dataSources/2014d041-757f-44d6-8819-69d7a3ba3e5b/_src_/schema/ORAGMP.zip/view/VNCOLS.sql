CREATE VIEW VNCOLS AS (SELECT a.plantcode,
			a.coldate orderdate,
			a.colseq orderseq,
      a.colno orderno,
      a.saldiv saldiv,
      SUBSTR(a.appdate, 1, 7) yymm,
      CASE WHEN NVL(a.tasooyn, 'N') = 'Y' THEN SL18.divname || '(타)' ELSE SL18.divname END saldivnm,
      NVL(a.tasooyn, 'N') tasooyn,
      a.coldiv coldiv,
      a.orderdiv orderdiv,
      a.custcode,
      b.custname custname,
      b.ceoname ceoname,
      b.businessno businessno,
      b.telno telno,
      b.faxno faxno,
      b.POST POST,
      b.addr1 addr1,
      b.addr2 addr2,
      b.addr1 || ' ' || b.addr2 addr,
      h.topdeptcode topdeptcode,
      h.topdeptname topdeptname,
      h.predeptcode predeptcode,
      h.predeptname predeptname,
      a.deptcode,
      h.findname findname,
      h.deptname deptname,
      a.empcode,
      i.positiondiv positiondiv,
      i.empname empname,
      u.divname jikwi,
      a.ecustcode,
      c.custname ecustname,
      j.topdeptcode etopdeptcode,
      j.topdeptname etopdeptname,
      j.predeptcode epredeptcode,
      j.predeptname epredeptname,
      a.edeptcode,
      j.findname efindname,
      j.deptname edeptname,
      a.eempcode,
      k.positiondiv epositiondiv,
      k.empname eempname,
      v.divname ejikwi,
      a.utdiv utdiv,
      o.divname utdivnm,
      a.eutdiv eutdiv,
      p.divname eutdivnm,
      a.appdate,
      a.statediv,
      l.divname statedivnm,
      a.remark remark,
      a.enuriyn enuriyn,
      CASE
        WHEN a.saldiv = 'C01'
           AND a.coldiv IN ('01', '02')
        THEN
          NVL(a.colamt, 0)
        ELSE
          0
      END
        cashcol, -- 현금수금
      CASE
        WHEN a.saldiv = 'C01'
           AND a.coldiv IN ('XZ')
        THEN
          NVL(a.colamt, 0)
        ELSE
          0
      END
        changecol, -- 물품대체
      CASE
        WHEN a.saldiv = 'C01'
           AND a.coldiv IN ('10')
        THEN
          NVL(a.colamt, 0)
        ELSE
          0
      END
        bankcol, -- 은행입금
      CASE
        WHEN a.saldiv = 'C01'
           AND a.coldiv IN ('21')
        THEN
          NVL(a.colamt, 0)
        ELSE
          0
      END
        cardcol, -- 카드수금
      --CASE WHEN a.saldiv = 'C01' and a.coldiv in ('30','33') THEN nvl(a.colamt, 0)
      CASE
        WHEN a.saldiv = 'C01'
           AND a.coldiv LIKE '3%'
        THEN
          NVL(a.colamt, 0)
        ELSE
          0
      END
        billcol, --어음수금
      CASE
        WHEN a.saldiv = 'C01'
           AND condr.divcode IS NULL
        THEN
          NVL(a.colamt, 0)
        ELSE
          0
      END
        etccol, --기타수금
      NVL(a.colamt, 0) colamt,
      a.custprtyn custprtyn,
      NVL(divmonth, 0) divmonth,
      CASE
        WHEN a.coldiv LIKE '3%'
        THEN
          aaa.divname --지급은행
        WHEN SUBSTR(a.coldiv, 0, 1) = '1'
        THEN
          s.accremark --계좌은행
        WHEN (SUBSTR(a.coldiv, 0, 1) = '2')
           AND (NVL(a.divmonth, 0) = 0)
        THEN
          AC17.divname --카드사
        WHEN (SUBSTR(a.coldiv, 0, 1) = '2')
           AND (NVL(a.divmonth, 0) > 0)
        THEN
          AC17.divname || ' ' || TO_CHAR(divmonth) || '개월' --카드사
        ELSE
          ''
      END
        gubun,
      a.paybankbr paybankbr,
      a.baeseo baeseo,
      a.billno billno,
      a.accountno accountno,
      CASE WHEN a.coldiv LIKE '3%' THEN a.issdate ELSE '' END issdate,
      CASE WHEN a.coldiv LIKE '3%' THEN a.expdate ELSE '' END expdate,
      CASE WHEN a.coldiv LIKE '3%' THEN a.discntdate ELSE '' END discntdate,
      a.issempnm issempnm,
      a.paybank paybank,
      a.cardcomp cardcomp,
      AC17.divname cardcompnm,
      ac17.filter2 cardjoin,
      a.carddate carddate,
      CASE WHEN SUBSTR(coldiv, 0, 1) = '2' THEN NVL(a.autoyn, 'N') ELSE '' END autoyn,
      a.cardno cardno,
      a.cardokno cardokno,
      s.accremark accountbanknm,
      a.pda pda,
      a.colnolink colnolink,
      b.areadiv areadiv,
      m.divname areadivnm,
      c.areadiv eareadiv,
      n.divname eareadivnm,
      i.retiredt retiredt,
      k.retiredt eretiredt,
      h.deptgroup deptgroup,
      j.deptgroup edeptgroup,
      b.custmajorcode custmajorcode,
      b.stopdate stopdate,
      c.stopdate estopdate,
      b.ascustcheck ascustcheck,
      c.ascustcheck eascustcheck,
      b.opendate opendate,
      c.opendate eopendate,
      a.bigo,
      a.insertdt,
      a.iempcode,
      a.updatedt,
      a.uempcode,
      ie.empname insertempname,
      ue.empname updateempname,
      h.seqtopdeptcode,
      h.seqpredeptcode,
      h.seqdeptcode,
      j.seqtopdeptcode eseqtopdeptcode,
      j.seqpredeptcode eseqpredeptcode,
      j.seqdeptcode eseqdeptcode,
      ss.divname orderdivnm, --추가 20131120:이세민
      b.sagodiv, --추가 20131220:이세민
      c.sagodiv esagodiv, --추가 20131220:이세민
      SL101.divname coldtldivnm,
      a.colvat,
      a.partdiv
   FROM  vnColsEnd a
      left JOIN CMCUSTM b ON a.custcode = b.custcode
      left JOIN CMCUSTM c ON a.ecustcode = c.custcode
      left JOIN vnDEPT h ON a.deptcode = h.deptcode
      left JOIN CMEMPM i ON a.empcode = i.empcode
      left JOIN vnDEPT j ON a.edeptcode = j.deptcode
      left JOIN CMEMPM k ON a.eempcode = k.empcode
      LEFT JOIN CMCOMMONM l
        ON a.statediv = l.divcode
           AND l.cmmcode = 'SL17'
      LEFT JOIN CMCOMMONM o
        ON a.utdiv = o.divcode
           AND o.cmmcode = 'CM15'
      LEFT JOIN CMCOMMONM p
        ON a.eutdiv = p.divcode
           AND p.cmmcode = 'CM15'
      LEFT JOIN CMCOMMONM SL18
        ON a.coldiv = SL18.divcode
           AND SL18.cmmcode = 'SL18'
      LEFT JOIN CMCOMMONM AC17
        ON a.cardcomp = AC17.divcode
           AND AC17.cmmcode = 'AC17'
      LEFT JOIN CMACCOUNTM s ON a.accountno = s.accountno
      LEFT JOIN CMCOMMONM u
        ON i.positiondiv = u.divcode
           AND u.cmmcode = 'PS29'
      LEFT JOIN CMCOMMONM v
        ON k.positiondiv = v.divcode
           AND v.cmmcode = 'PS29'
      LEFT JOIN CMCOMMONM m
        ON b.areadiv = m.divcode
           AND m.cmmcode = 'CM03'
      LEFT JOIN CMCOMMONM n
        ON c.areadiv = n.divcode
           AND n.cmmcode = 'CM03'
      LEFT JOIN CMCOMMONM aaa
        ON a.paybank = aaa.divcode
           AND aaa.cmmcode = 'PS32'
      LEFT JOIN CMEMPM ie ON a.iempcode = ie.empcode
      LEFT JOIN CMEMPM ue ON a.uempcode = ue.empcode
      LEFT JOIN CMCOMMONM ss
        ON a.orderdiv = ss.divcode
           AND ss.cmmcode = 'SL43'
      LEFT JOIN (SELECT divcode FROM SLCONDRESULT) condr ON a.coldiv = condr.divcode
      LEFT JOIN CMCOMMONM SL101
        ON a.coldtldiv = SL101.divcode
           AND SL101.cmmcode = 'SL101')
/
