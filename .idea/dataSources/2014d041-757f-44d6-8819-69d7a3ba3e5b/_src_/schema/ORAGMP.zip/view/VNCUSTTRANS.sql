CREATE VIEW VNCUSTTRANS AS SELECT a.plantcode, -- isnull(a.plantcode,'') as plantcode
		   a.entryno, -- isnull(a.entryno,'') as entryno
		   b.custcode, -- isnull(a.custcode,'') as custcode
		   a.entryno fixno,
		   NVL(c.custname, ' ') custname,
		   NVL(b.orderdiv, ' ') orderdiv,
		   NVL(a.fixdate, ' ') movedate,
		   NVL(D.topdeptcode, ' ') ttopdeptcode,
		   NVL(D.topdeptname, ' ') ttopdeptname,
		   NVL(D.predeptcode, ' ') tpredeptcode,
		   NVL(D.predeptname, ' ') tpredeptname,
		   NVL(a.tdeptcode, ' ') tdeptcode,
		   NVL(D.deptname, ' ') tdeptname,
		   NVL(D.findname, ' ') tfindname,
		   NVL(a.tempcode, ' ') tempcode,
		   NVL(e.empname, ' ') tempname,
		   NVL(e.positiondiv, ' ') tpositiondiv,
		   NVL(g.divname, ' ') tjikwi,
		   NVL(d1.topdeptcode, ' ') atopdeptcode,
		   NVL(d1.topdeptname, ' ') atopdeptname,
		   NVL(d1.predeptcode, ' ') apredeptcode,
		   NVL(d1.predeptname, ' ') apredeptname,
		   NVL(a.adeptcode, ' ') adeptcode,
		   NVL(d1.deptname, ' ') adeptname,
		   NVL(d1.findname, ' ') afindname,
		   NVL(a.aempcode, ' ') aempcode,
		   NVL(e1.empname, ' ') aempname,
		   NVL(e1.positiondiv, ' ') apositiondiv,
		   NVL(g1.divname, ' ') ajikwi,
		   NVL(b.balance, 0) balance,
		   NVL(b.pendbill, 0) pendbill,
		   NVL(b.custbalance, 0) custbalance,
       NVL(b.differentamt, 0) differentamt,
       NVL(a.remark, ' ') remark,
       b.ecustcode, --추가 20140520:이세민
       h.custname ecustname, --추가 20140520:이세민
       i.divname orderdivnm --추가 20140520:이세민
  FROM   SLTRANSMNGM a
       LEFT JOIN SLTRANSMNGD b ON a.entryno = b.entryno
       JOIN CMCUSTM c ON b.custcode = c.custcode
       JOIN vnDEPT D ON a.tdeptcode = D.deptcode
       JOIN vnDEPT d1 ON a.adeptcode = d1.deptcode
       JOIN CMEMPM e ON a.tempcode = e.empcode
       JOIN CMEMPM e1 ON a.aempcode = e1.empcode
       LEFT JOIN CMCOMMONM g
         ON e.positiondiv = g.divcode
          AND g.cmmcode = 'PS29'
       LEFT JOIN CMCOMMONM g1
         ON e1.positiondiv = g1.divcode
          AND g1.cmmcode = 'PS29'
       LEFT JOIN CMCUSTM h ON b.ecustcode = h.custcode
       LEFT JOIN CMCOMMONM i
         ON i.cmmcode = 'SL43'
          AND b.orderdiv = i.divcode
  WHERE  a.fixyn = 'Y'
       AND a.apprstatus = '03' --승인완료된 항목만 조회

--*/
/* --이전쿼리 2013-11-15: 이세민

           select      a.plantcode    -- isnull(a.plantcode,'') as plantcode
                       ,a.entryno    -- isnull(a.entryno,'') as entryno
                       ,a.fixno    -- isnull(a.fixno,'') as fixno
                       ,a.custcode    -- isnull(a.custcode,'') as custcode
             ,isnull(b.custname,'') as custname
                       ,isnull(a.orderdiv,'') as orderdiv
                       ,isnull(a.movedate,'') as movedate
                       ,isnull(c.topdeptcode,'') as ttopdeptcode
             ,isnull(c.topdeptname,'') as ttopdeptname
             ,isnull(c.predeptcode,'') as tpredeptcode
             ,isnull(c.predeptname,'') as tpredeptname
                       ,isnull(a.tdeptcode,'') as tdeptcode
             ,isnull(c.deptname,'') as tdeptname
             ,isnull(c.findname,'') as tfindname
                       ,isnull(a.tempcode,'') as tempcode
             ,isnull(d.empname,'') as tempname
             ,isnull(d.positiondiv,'') as tpositiondiv
             ,isnull(g.divname,'') as tjikwi
                       ,isnull(e.topdeptcode,'') as atopdeptcode
             ,isnull(e.topdeptname,'') as atopdeptname
             ,isnull(e.predeptcode,'') as apredeptcode
             ,isnull(e.predeptname,'') as apredeptname
                       ,isnull(a.adeptcode,'') as adeptcode
             ,isnull(e.deptname,'') as adeptname
             ,isnull(e.findname,'') as afindname
                       ,isnull(a.aempcode,'') as aempcode
             ,isnull(f.empname,'') as aempname
             ,isnull(f.positiondiv,'') as apositiondiv
             ,isnull(h.divname,'') as ajikwi
                       ,isnull(a.balance,0) as balance
                       ,isnull(a.pendbill,0) as pendbill
                       ,isnull(a.custbalance,0) as custbalance
                       ,isnull(a.differentamt,0) as differentamt
                       ,isnull(a.remark,'') as remark


           from        SLCUSTTRANSM (nolock) as a
             join CMCUSTM (nolock) as b
               on a.custcode = b.custcode
             join vndept (nolock) as c
               on a.tdeptcode = c.deptcode
             join cmempm (nolock) as d
               on a.tempcode = d.empcode
             join vndept (nolock) as e
               on a.adeptcode = e.deptcode
             join cmempm (nolock) as f
               on a.aempcode = f.empcode
             left join CMCOMMONM (nolock) as g
               on d.positiondiv = g.divcode
               and g.cmmcode = 'PS29'
             left join CMCOMMONM (nolock) as h
               on f.positiondiv = h.divcode
               and h.cmmcode = 'PS29'

       */
/
