CREATE VIEW VNEDI AS SELECT RTRIM(NVL(a.plantcode, ' ')) plantcode,
		   RTRIM(NVL(a.edidt, ' ')) edidt,
		   RTRIM(NVL(a.ediyymm, ' ')) ediyymm,
		   RTRIM(NVL(a.custcode, ' ')) custcode,
		   RTRIM(NVL(b.opendate, ' ')) opendate,
		   RTRIM(NVL(b.utdiv, ' ')) utdiv,
		   RTRIM(NVL(b.utdivnm, ' ')) utdivnm,
		   RTRIM(NVL(g.majorstudy, ' ')) majorstudy, -- 전공
		   RTRIM(NVL(h.divname, ' ')) majorstudyd,
		   RTRIM(NVL(b.custname, ' ')) custname,
		   RTRIM(NVL(b.ceoname, ' ')) ceoname,
		   RTRIM(NVL(b.addr, ' ')) addr,
		   RTRIM(NVL(b.areadiv, ' ')) areadiv,
		   RTRIM(NVL(b.areadivnm, ' ')) areadivnm,
		   RTRIM(NVL(e.topdeptcode, ' ')) topdeptcode,
		   RTRIM(NVL(e.topdeptname, ' ')) topdeptname,
		   RTRIM(NVL(e.predeptcode, ' ')) predeptcode,
		   RTRIM(NVL(e.predeptname, ' ')) predeptname,
		   RTRIM(NVL(a.deptcode, ' ')) deptcode,
		   RTRIM(NVL(e.deptname, ' ')) deptname,
		   RTRIM(NVL(e.findname, ' ')) findname,
		   RTRIM(NVL(a.empcode, ' ')) empcode,
		   RTRIM(NVL(c.positiondiv, ' ')) positiondiv,
		   RTRIM(NVL(c.empname, ' ')) empname,
		   RTRIM(NVL(f.divname, ' ')) jikwi,
		   RTRIM(NVL(c.classdiv, ' ')) classdiv, -- 직책코드
		   RTRIM(NVL(j.divname, ' ')) classdivnm, -- 직책구분
		   NVL(a1.seq, 0) seq,
		   RTRIM(NVL(D.mitemcode, ' ')) mitemcode,
		   RTRIM(NVL(a1.itemcode, ' ')) itemcode,
		   RTRIM(NVL(D.itemname, ' ')) itemname,
		   RTRIM(NVL(D.unit, ' ')) unit,
		   RTRIM(NVL(D.formdiv, ' ')) formdiv,
		   RTRIM(NVL(D.formdivnm, ' ')) formdivnm,
		   RTRIM(NVL(D.effectdiv, ' ')) effectdiv,
		   RTRIM(NVL(D.effectdivnm, ' ')) effectdivnm,
		   RTRIM(NVL(D.drugdiv, ' ')) drugdiv,
		   RTRIM(NVL(D.drugdivnm, ' ')) drugdivnm,
		   RTRIM(NVL(D.mainitemyn, ' ')) mainitemyn,
		   RTRIM(CASE WHEN NVL(D.mainitemyn, 'N') = 'N' THEN ' ' WHEN NVL(D.mainitemyn, 'N') = 'Y' THEN '주력' ELSE ' ' END) mainitemynnm,
		   RTRIM(NVL(D.incentiveyn, ' ')) incentiveyn,
		   RTRIM(CASE WHEN NVL(D.incentiveyn, 'N') = 'N' THEN '일반' WHEN NVL(D.incentiveyn, 'N') = 'Y' THEN '인센티브' ELSE ' ' END) incentiveynnm,
		   NVL(a1.qty, 0) qty,
		   NVL(a1.prc, 0) prc,
		   NVL(a1.amt, 0) amt,
		   RTRIM(NVL(a.spyn, ' ')) spyn,
		   RTRIM(NVL(a.spdt, ' ')) spdt,
		   RTRIM(NVL(c.retiredt, ' ')) retiredt,
		   RTRIM(NVL(e.deptgroup, ' ')) deptgroup,
		   i.divname ediiodivnm,
		   a1.ediiodiv, --원내/원외 구분
		   a.datauseyn,
		   a.apprstatus,
		   -- 현담당자 정보 추가 함 20140314 :이세민
		   b.empcode recempcode,
		   b.empname recempname,
		   b.deptcode recdeptcode,
		   b.deptname recdeptname
	--=======================================
	FROM   SLEDICM a
		   JOIN SLEDICD a1
			   ON a.edimanageno = a1.edimanageno
				  AND a.plantcode = a1.plantcode
				  AND a.edidt = a1.edidt
				  AND a.ediyymm = a1.ediyymm
				  AND a.custcode = a1.custcode
		   JOIN vnCUST b ON a.custcode = b.custcode
		   JOIN CMEMPM c ON a.empcode = c.empcode
		   JOIN vnItem D
			   ON a1.itemcode = D.itemcode
				  AND D.itemdiv IN ('03', '04' --완제도 포함.(20140121:이세민)>>수입완제품에 대한 EDI등록이 가능하도록 하기위함.
											  )
		   JOIN vnDEPT e ON a.deptcode = e.deptcode
       LEFT JOIN CMCOMMONM f
         ON c.positiondiv = f.divcode
          AND cmmcode = 'PS29'
       LEFT JOIN CMCOMMONM j
         ON c.classdiv = j.divcode
          AND j.cmmcode = 'PS42'
       LEFT JOIN vnCUSTHUM g ON a.custcode = g.custcode
       LEFT JOIN CMCOMMONM h
         ON g.majorstudy = h.divcode
          AND h.cmmcode = 'CM61'
       LEFT JOIN CMCOMMONM i
         ON i.cmmcode = 'CM09'
          AND a1.ediiodiv = i.divcode
--이전 쿼리=============================================================
--select  rtrim(isnull(a.plantcode,'')) as plantcode
--      ,  rtrim(isnull(a.edidt,'')) as edidt
--      ,  rtrim(isnull(a.ediyymm,'')) as ediyymm
--      ,  rtrim(isnull(a.custcode,'')) as custcode
--,  rtrim(isnull(b.opendate,'')) as opendate
--,  rtrim(isnull(b.utdiv,'')) as utdiv
--,  rtrim(isnull(b.utdivnm,'')) as utdivnm
--,  rtrim(ISNULL(g.majorstudy,'')) as majorstudy  -- 전공
--,  rtrim(ISNULL(h.divname,'')) as majorstudyd
--,  rtrim(isnull(b.custname,'')) as custname
--,  rtrim(isnull(b.ceoname,'')) as ceoname
--,  rtrim(isnull(b.addr,'')) as addr
--,  rtrim(ISNULL(b.areadiv,'')) as areadiv
--,  rtrim(ISNULL(b.areadivnm,'')) as areadivnm
--,  rtrim(isnull(e.topdeptcode,'')) as topdeptcode
--,  rtrim(isnull(e.topdeptname,'')) as topdeptname
--,  rtrim(isnull(e.predeptcode,'')) as predeptcode
--,  rtrim(isnull(e.predeptname,'')) as predeptname
--,  rtrim(isnull(a.deptcode,'')) as deptcode
--,  rtrim(isnull(e.deptname,'')) as deptname
--,  rtrim(isnull(e.findname,'')) as findname
--,  rtrim(isnull(a.empcode,'')) as empcode
--,  rtrim(isnull(c.positiondiv,'')) as positiondiv
--,  rtrim(isnull(c.empname,'')) as empname
--,  rtrim(isnull(f.divname,'')) as jikwi
--,  rtrim(ISNULL(c.classdiv,'')) as classdiv       -- 직책코드
--,  rtrim(ISNULL(j.divname,'')) as classdivnm       -- 직책구분
--,  isnull(a.seq,0) as seq
--,  rtrim(isnull(d.mitemcode,'')) as mitemcode
--,  rtrim(isnull(a.itemcode,'')) as itemcode
--,  rtrim(isnull(d.itemname,'')) as itemname
--,  rtrim(isnull(d.unit,'')) as unit
--,  rtrim(isnull(d.formdiv,'')) as formdiv
--,  rtrim(isnull(d.formdivnm,'')) as formdivnm
--,  rtrim(isnull(d.effectdiv,'')) as effectdiv
--,  rtrim(isnull(d.effectdivnm,'')) as effectdivnm
--,  rtrim(isnull(d.drugdiv,'')) as drugdiv
--,  rtrim(isnull(d.drugdivnm,'')) as drugdivnm
--,  rtrim(isnull(d.mainitemyn,'')) as mainitemyn
--,  rtrim(case when isnull(d.mainitemyn,'N') = 'N' then ''
--      when isnull(d.mainitemyn,'N') = 'Y' then '주력'
--      else '' end) as mainitemynnm
--,  rtrim(isnull(d.incentiveyn,'')) as incentiveyn
--,  rtrim(case when isnull(d.incentiveyn,'N') = 'N' then '일반'
--      when isnull(d.incentiveyn,'N') = 'Y' then '인센티브'
--      else '' end) as incentiveynnm
--,  isnull(a.qty,0) as qty
--,  isnull(a.prc,0) as prc
--,  isnull(a.amt,0) as amt
--,  rtrim(isnull(a.spyn,'')) as spyn
--,  rtrim(isnull(a.spdt,'')) as spdt
--,  rtrim(ISNULL(c.retiredt,'')) as retiredt
--,  rtrim(ISNULL(e.deptgroup,'')) as deptgroup
--      from  SLEDIM as a (nolock)
--    join vnCUST as b (nolock)
--      on a.custcode = b.custcode
--    join CMEMPM as c (nolock)
--      on a.empcode = c.empcode
--    join vnItem as d (nolock)
--      on a.itemcode = d.itemcode
--      and d.itemdiv = '03'
--    join vnDEPT as e (nolock)
--      on a.deptcode = e.deptcode
--    left join CMCOMMONM as f (nolock)
--      on c.positiondiv = f.divcode
--      and cmmcode = 'PS29'
--    left join CMCOMMONM as j (nolock)
--      on c.classdiv = j.divcode
--      and j.cmmcode = 'PS42'
--    left join vnCUSTHUM as g (nolock)
--      on a.custcode = g.custcode
--    left join CMCOMMONM as h (nolock)
--      on g.majorstudy = h.divcode
--      and h.cmmcode = 'CM61'
--=============================================================
/
