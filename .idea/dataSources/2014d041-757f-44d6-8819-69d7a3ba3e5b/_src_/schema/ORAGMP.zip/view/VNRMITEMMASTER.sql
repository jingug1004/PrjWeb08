CREATE VIEW VNRMITEMMASTER AS SELECT a.itemcode itemcode, --품목코드
		   a.itemdiv itemdiv, --품목구분
		   b.managecode managecode, --품목구분(시스템)
		   b.divname itemdivname, --품목구분명(*)
		   a.itemname itemkorname, --품목명(국문)
		   a.itemsname itemshortname, --품목명(약명)
		   a.itemename itemengname, --품목명(영문)
		   a.standarddiv standarddiv, --시험규격코드
		   c.divname standarddivname, --시험규격(*)
		   NVL(a.validityperiod, 0) validityperiod, --유통기한(월)
		   a.itemunit itemunit, --단위코드
		   D.divname itemunitname, --단위(*)
		   a.keepingmethod keepingmethod, --보관방법
		   a.itembranch itembranch, --품목분류코드
		   e.divname itembranchname, --품목분류(*)
		   a.warehouse keepingwarehouse, --보관창고코드
		   f.divname keepingwarehousename, --보관창고(*)
		   a.internaldiv internaldiv, --국내외구분코드(원자재/상품)
		   g.divname internaldivname, --국내외구분(*)
		   a.enteringrackdiv enteringrackdiv, --입고랙종류코드(원자재/상품)
		   h.divname enteringrackdivname, --입고랙종류(*)
		   a.enteringrackqty enteringrackqty, --입고랙적재량(원자재/상품)
		   a.testcheck testcheck, --시험여부
		   NULL safestockqty, --안전재고량
		   a.properstockqty properstockqty, --적정재고량
		   a.buyperiod buyperiod, --구매기간
		   CASE a.productdiv WHEN '90' THEN 'N' ELSE 'Y' END usediv, --사용여부
		   CASE a.productdiv WHEN '90' THEN '미사용' ELSE '사용중' END usedivname, --사용여부(*)
		   NULL notusediv, --미사용원인코드
		   NULL notusedivname, --미사용원인(*)
		   e.managecode itemdetaildiv,
		   CASE e.managecode WHEN 'A' THEN '01' WHEN 'B' THEN '02' ELSE '03' END itemdetaildiv2,
		   a.buyunit buyunit,
		   a.customcode customcode,
		   a.orderprice orderprice,
		   a.exchangeunit exchangeunit,
		   a.paydiv paydiv,
		   a.offer offer,
		   e.remark typemark,
		   a.plantcode plantcode
	FROM   CMITEMM a
		   LEFT JOIN CommonMaster b
			   ON b.cmmcode = 'CMM01'
				  AND b.divcode = a.itemdiv
		   LEFT JOIN CommonMaster c
			   ON c.cmmcode = 'LMM06'
				  AND c.divcode = a.standarddiv
		   LEFT JOIN CommonMaster D
			   ON D.cmmcode = 'CMM02'
				  AND D.divcode = a.unit
		   LEFT JOIN CommonMaster e
			   ON e.cmmcode = 'MPM09'
				  AND e.divcode = a.itembranch
		   LEFT JOIN CommonMaster f
			   ON f.cmmcode = 'MPM11'
				  AND f.divcode = a.warehouse
		   LEFT JOIN CommonMaster g
			   ON g.cmmcode = 'MPM15'
				  AND g.divcode = a.internaldiv
		   LEFT JOIN CommonMaster h
			   ON h.cmmcode = 'MPM08'
				  AND h.divcode = a.enteringrackdiv
--left join CommonMaster i on i.cmmcode = 'MPM12' and i.divcode = a.notusediv
/
