CREATE VIEW VNEMP AS SELECT (A.PLANTCODE) PLANTCODE,                                      -- 사업장
          (A.EMPCODE) EMPCODE,                                           -- 사원
          NVL (A.EMPNAME, '') EMPNAME,                                  -- 사원명
          NVL (B.TOPDEPTCODE, '') TOPDEPTCODE,                           -- 부서
          NVL (B.TOPDEPTNAME, '') TOPDEPTNAME,                          -- 부서명
          NVL (B.PREDEPTCODE, '') PREDEPTCODE,                           -- 지점
          NVL (B.PREDEPTNAME, '') PREDEPTNAME,                          -- 지점명
          (B.DEPTCODE) DEPTCODE,                                          -- 팀
          NVL (B.DEPTNAME, '') DEPTNAME,                                 -- 팀명
          NVL (B.FINDNAME, '') FINDNAME,                              -- 부서조회용
          NVL (A.ENTERDT, '') ENTERDT,                                 -- 입사일자
          NVL (A.RETIREDT, '') RETIREDT,                               -- 퇴직일자
          NVL (A.MIDCALCDT, '') MIDCALCDT,                           -- 중도정산일자
          NVL (A.TRAININGSDT, '') TRAININGSDT,                       -- 수습시작일자
          NVL (A.TRAININGEDT, '') TRAININGEDT,                       -- 수습만기일자
          NVL (A.POSITIONDIV, '') POSITIONDIV,                         -- 직책코드
          NVL (C.DIVNAME, '') JIKWI,                                     -- 직책
          NVL (A.RESPONSIBILITYDIV, '') RESPONSIBILITYDIV,             -- 직종코드
          NVL (D.DIVNAME, '') RESPONSIBILITYDIVNM,                       -- 직종
          NVL (A.CLASSDIV, '') CLASSDIV,                               -- 직책코드
          NVL (H.DIVNAME, '') CLASSDIVNM,                              -- 직책구분
          NVL (A.SEXDIV, '') SEXDIV,                                   -- 성별구분
          NVL (E.DIVNAME, '') SEXDIVNM,                                  -- 성별
          CASE
             WHEN A.BIRTHDAY IS NULL
             THEN
                   CASE
                      WHEN SUBSTR (PERSONID, 8, 1) IN ('1', '2') THEN '19'
                      WHEN SUBSTR (PERSONID, 8, 1) IN ('3', '4') THEN '20'
                   END
                || SUBSTR (PERSONID, 3, 2)
                || '-'
                || SUBSTR (PERSONID, 5, 2)
             ELSE
                A.BIRTHDAY
          END
             BIRTHDAY,                                                   -- 생일
          NVL (A.EMPDIV, '') EMPDIV,                                 -- 사원구분코드
          NVL (F.DIVNAME, '') EMPDIVNM,                                -- 사원구분
          NVL (A.ENTERDIV, '') ENTERDIV,                             -- 입사구분코드
          NVL (G.DIVNAME, '') ENTERDIVNM,                              -- 입사구분
          NVL (A.LASTACHIVE, '') LASTACHIVE,                           -- 최종학력
          NVL (L.DIVNAME, '') LASTACHIVENM,                           -- 최종학력명
          NVL (A.PDAID, '') PDAID,                                    -- PDAID
          NVL (A.PHONE, '') PHONE,
          NVL (A.PDALOGINDIV, '') PDALOGINDIV,           -- 로그인구분(1:가능, 0:불가능)
          NVL (A.EMAIL, '') EMAIL,
          NVL (A.MARRYDIV, '') MARRYDIV,
          NVL (A.SALPOWER, '') SALPOWER,                         -- 영업관리 조회 권한
          NVL (A.WORKDIV, '') WORKDIV,
          NVL (M.DIVNAME, '') WORKDIVNM,
          NVL (A.GRADEDIV, '') GRADEDIV,
          NVL (N.DIVNAME, '') GRADEDIVNM,
          NVL (TO_CHAR (A.EMPSTEP), '') EMPSTEP,
          NVL (TO_CHAR (O.PAYDIV), '') PAYDIV,
          NVL (TO_CHAR (P.DIVNAME), '') PAYDIVNM,
          NVL (TO_CHAR (O.DUTYYN), 'N') DUTYYN,
          NVL (TO_CHAR (A.LIVEYN), 'Y') LIVEYN,
          NVL (TO_CHAR (A.NATIONDIV), 'Y') NATIONDIV,
          NVL (TO_CHAR (A.NATIONCODE), '') NATIONCODE,
          NVL (TO_CHAR (Q.DIVNAME), '') NATIONCODENM,
          NVL (TO_CHAR (A.BIRTHDIV), '1') BIRTHDIV,
          NVL (R.DIVNAME, '') BIRTHDIVNM,
          NVL (TO_CHAR (A.TELL), '') TELL,
          NVL (TO_CHAR (A.SALEDIV), '') SALEDIV,
          NVL (S.DIVNAME, '') SALDIVNM,
          NVL (A.PERSONID, '') PERSONID,
          NVL (A.ADDRESS, '') ADDR1,
          NVL (A.DETAILADDRESS, '') ADDR2,
          CASE
             WHEN NVL (TRIM (A.ADDRESS) || TRIM (A.DETAILADDRESS), '')
                     IS NULL
             THEN
                ''
             ELSE
                A.ADDRESS || ' ' || A.DETAILADDRESS
          END
             AS ADDR,
          NVL (A.AREADIV, '') AREADIV,
          NVL (T.DIVNAME, '') AREADIVNM,
          A.PARTDIV           PARTDIV,
          NVL ( A.OUTYN, 'N') OUTYN
     FROM CMEMPM A
          LEFT JOIN VNDEPT B
             ON A.DEPTCODE = B.DEPTCODE
          LEFT JOIN CMCOMMONM C
             ON A.POSITIONDIV = C.DIVCODE AND UPPER (C.CMMCODE) = 'PS29'
          LEFT JOIN CMCOMMONM D
             ON A.RESPONSIBILITYDIV = D.DIVCODE
                AND UPPER (D.CMMCODE) = 'PS07'
          LEFT JOIN CMCOMMONM E
             ON A.SEXDIV = E.DIVCODE AND UPPER (E.CMMCODE) = 'PS30'
          LEFT JOIN CMCOMMONM F
             ON A.EMPDIV = F.DIVCODE AND UPPER (F.CMMCODE) = 'PS41'
          LEFT JOIN CMCOMMONM G
             ON A.ENTERDIV = G.DIVCODE AND UPPER (G.CMMCODE) = 'PS09'
          LEFT JOIN CMCOMMONM H
             ON A.CLASSDIV = H.DIVCODE AND UPPER (H.CMMCODE) = 'PS42'
          LEFT JOIN CMCOMMONM L
             ON A.LASTACHIVE = L.DIVCODE AND UPPER (L.CMMCODE) = 'PS03'
          LEFT JOIN CMCOMMONM M
             ON A.WORKDIV = M.DIVCODE AND UPPER (M.CMMCODE) = 'PS26'
          LEFT JOIN CMCOMMONM N
             ON A.GRADEDIV = N.DIVCODE AND UPPER (N.CMMCODE) = 'PS01'
          LEFT JOIN PSEMPPAYBASEM O
             ON A.PLANTCODE = O.PLANTCODE AND UPPER (A.EMPCODE) = O.EMPCODE
          LEFT JOIN CMCOMMONM P
             ON O.PAYDIV = P.DIVCODE AND UPPER (P.CMMCODE) = 'PS50'
          LEFT JOIN CMCOMMONM Q
             ON A.NATIONCODE = Q.DIVCODE AND UPPER (Q.CMMCODE) = 'CM70'
          LEFT JOIN CMCOMMONM R
             ON A.BIRTHDIV = R.DIVCODE AND UPPER (R.CMMCODE) = 'PS31'
          LEFT JOIN CMCOMMONM S
             ON A.SALEDIV = S.DIVCODE AND UPPER (S.CMMCODE) = 'PS45'
          LEFT JOIN CMCOMMONM T
             ON A.AREADIV = T.DIVCODE AND UPPER (T.CMMCODE) = 'CM03'
/
