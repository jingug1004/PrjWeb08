CREATE VIEW NVITEMGP AS SELECT a.itemcode itemcode, --품목코드
		   a.itemname itemkorname, --품목명(국문)
		   a.itemname itemname, --품목명(일반)
		   --     ,isnull(isnull(y.revisionno,a.revisionno),-1)
		   NVL(Y.revisionno, -1) --     ,isnull(a.revisionno,-1)
								revisionno, --품목허가개정번호
		   b.divcode itemdiv, --품목구분
		   b.filter1 managecode, --품목구분(시스템)
		   b.divname itemdivname, --품목구분명(*)
		   a.itemsname itemshortname, --품목명(약명)
		   a.itemname itemengname, --품목명(영문)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.standarddiv ELSE x.standarddiv END standarddiv, --시험규격코드
		   D.divname standarddivname, --시험규격(*)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.validityperiod ELSE x.validityperiod END validityperiod, --유통기한(월)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.unit WHEN a.itemdiv IN ('04') THEN x.unit ELSE a.unit END itemunit, --단위코드
		   e.divname itemunitname, --단위(*)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.keepingmethod ELSE x.keepingmethod END keepingmethod, --보관방법
		   a.itemdiv itembranch, --품목분류코드
		   b.divname itembranchname, --품목분류(*)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.warehouse ELSE x.warehouse END keepingwarehouse, --보관창고코드
		   g.whname keepingwarehousename, --보관창고(*)
		   a.internaldiv internaldiv, --국내외구분코드(원자재/상품)
		   M.divname internaldivname, --국내외구분(*)
		   a.enteringrackdiv enteringrackdiv, --입고랙종류코드(원자재/상품)
		   ' ' enteringrackdivname, --입고랙종류(*)
		   a.enteringrackqty enteringrackqty, --입고랙적재량(원자재/상품)
		   NVL(a.testcheck, 'Y') testcheck, --시험여부
		   a.safeqty safestockqty, --안전재고량
		   a.properstockqty properstockqty, --적정재고량
		   a.buyperiod buyperiod, --구매기간
		   a.usediv usediv, --사용여부
		   CASE a.usediv WHEN 'Y' THEN '사용중' ELSE '미사용' END usedivname, --사용여부(*)
		   NULL notusediv, --미사용원인코드
		   NULL notusedivname, --미사용원인(*)
		   a.revisionno itemrevisionid, --관리번호(제조제품)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.contentqty ELSE x.contentqty END contentqty, --함량Num(제조제품)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.contentunit ELSE x.contentunit END contentunit, --함량단위코드(제조제품)
		   i.divname contentunitname, --함량단위(*)
		   fnNumericToString(CASE WHEN a.itemdiv = '03' THEN a.contentqty ELSE x.contentqty END, 'S') || NVL(i.divname, ' ') contentqtyname, --함량Text(*)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.batchsize ELSE x.batchsize END batchsize,
		   --배치크기Num(제조제품)
		   fnNumericToString(CASE WHEN a.itemdiv = '03' THEN a.batchsize ELSE x.batchsize END, 'S') || NVL(e.divname, ' ') batchsizename, --배치크기Text(*)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.formdiv ELSE x.formdiv END itemformdiv, --제품유형코드(제조제품)
		   o.divname itemformdivname, --제품유형(*)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.maxmanageyield ELSE x.maxmanageyield END maxmanageyield, --관리수율(상한)(제조제품)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.minmanageyield ELSE x.minmanageyield END minmanageyield, --관리수율(하한)(제조제품)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.makingcost ELSE x.makingcost END makingcost, --제조원가(제조,포장)
		   a.docuno docuno, --문서번호(제조,포장)
		   a.productcheck productcheck, --생산여부(제조,포장)
		   a.notproductdiv notproductdiv, --미생산원인코드(제조,포장)
		   j.divname notproductdivname, --미생산원인(*)
		   a.mitemcode typicalitemcode, --대표제품코드(포장제품)
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.itemname ELSE x.itemname END typicalitemname, --대표제품명(*)
		   a.unitqty packingunitqty, --포장단위량Num(포장제품)
		   fnNumericToString(a.unitqty, 'S') || NVL(e.divname, ' ') packingunitqtyname, --포장단위Text(*)
		   a.packingtypediv packingtypediv, --포장타입코드(포장제품)
		   k.divname packingtypedivname, --포장타입(*)
		   a.typicalpackingcheck typicalpackingcheck, --포장대표여부(포장제품)
		   a.cartondiv cartondiv, --지함종류코드(포장제품)
		   l.divname cartondivname, --지함종류(*)
		   a.cartonqty cartonqty, --지함적재량(포장제품)
		   a.barcode barcode, --바코드(포장제품)
		   a.minpackingcheck minpackingcheck,
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.makediv ELSE x.makediv END productiondiv,
		   N.divname productiondivname,
		   N.remark productiontype,
		   Y.approvalcheck approvalcheck,
		   Y.permissionnum permissionnum,
		   Y.permissiondate permissiondate,
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.transunit ELSE x.transunit END transunit,
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.shape ELSE x.shape END shape,
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.transqty ELSE x.transqty END transqty,
		   NVL(r.divname, ' ') transunitname,
		   a.plantcode plantcode,
		   CASE WHEN a.itemdiv IN ('03', '05') THEN a.costcenter ELSE x.costcenter END costcenter,
		   Q.divname costcentername,
		   CASE
			   WHEN a.itemdiv = '03'
			   THEN
				   'A'
			   WHEN a.itemdiv = '04'
					AND Q.filter1 IN ('M')
			   THEN
				   'A'
			   WHEN a.itemdiv = '05'
			   THEN
				   'C'
			   ELSE
				   'B'
		   END
			   searchdiv,
		   -- A : 반제품(모든제품) + 포장제품(제제/바이알) => 처방전/ 표준운영절차 대상
		   -- A : 반제품(모든제품) + 포장제품(제제/바이알) => 처방전/ 표준운영절차 대상 제외
		   CASE a.itemdiv WHEN '05' THEN 'C' ELSE Q.filter1 END searchdetaildiv,
		   NVL(a.drugprc, 0) drugprc,
		   CASE WHEN a.itemdiv IN ('03') THEN a.stockwarehousediv WHEN a.itemdiv IN ('05') THEN '500' ELSE x.stockwarehousediv END stockwarehousediv,
		   c.divname stockwarehousedivname,
		   NVL(S.soprevisionno, ' ') soprevisionno,
		   NVL(Y.prescriptionid, ' ') prescriptionid,
		   a.factorydiv,
		   Y.revisionno permitrevisionno,
		   a.warehouse,
           a.informaltest              --약식시험여부
	FROM   CMITEMM a
		   LEFT JOIN CMITEMM x
			   ON x.itemdiv = '03'
				  AND a.mitemcode = x.itemcode
		   LEFT JOIN GoodsStandardRevision Y
			   ON Y.itemcode = a.itemcode
				  AND Y.itemrevisionid = a.revisionno
				  AND Y.usediv = 'Y'
		   JOIN CMCOMMONM b
			   ON b.cmmcode = 'CMM01'
				  AND b.divcode = a.itemdiv
		   LEFT JOIN CMCOMMONM D
			   ON D.cmmcode = 'LMM06'
				  AND D.divcode = CASE WHEN a.itemdiv = '03' THEN a.standarddiv ELSE x.standarddiv END
		   LEFT JOIN CMCOMMONM e
			   ON e.cmmcode = 'CMM02'
				  AND e.divcode = CASE WHEN a.itemdiv IN ('03', '05') THEN a.unit WHEN a.itemdiv IN ('04') THEN x.unit ELSE a.unit END
		   LEFT JOIN SLSTOREHOUSEM g ON g.warehouse = CASE WHEN a.itemdiv = '03' THEN a.warehouse ELSE x.warehouse END
		   LEFT JOIN CMCOMMONM i
			   ON i.cmmcode = 'CMM02'
				  AND i.divcode = CASE WHEN a.itemdiv = '03' THEN a.contentunit ELSE x.contentunit END
		   LEFT JOIN CMCOMMONM j
			   ON j.cmmcode = 'MPM24'
				  AND j.divcode = a.notproductdiv
		   LEFT JOIN CMCOMMONM k
			   ON k.cmmcode = 'MPM72'
				  AND k.divcode = a.packingtypediv
		   LEFT JOIN CMCOMMONM l
			   ON l.cmmcode = 'MPM67'
				  AND l.divcode = a.cartondiv
		   LEFT JOIN CMCOMMONM o
			   ON o.cmmcode = 'MPM29'
				  AND o.divcode = CASE WHEN a.itemdiv IN ('03', '05') THEN a.formdiv ELSE x.formdiv END
		   LEFT JOIN CMCOMMONM Q
			   ON Q.cmmcode = 'CMM61'
				  AND Q.divcode = CASE WHEN a.itemdiv = '03' THEN a.costcenter ELSE x.costcenter END
		   LEFT JOIN CMCOMMONM N
			   ON N.cmmcode = 'CMM55'
				  AND N.divcode = CASE WHEN a.itemdiv = '03' THEN a.makediv ELSE x.makediv END
		   LEFT JOIN CMCOMMONM M
			   ON M.cmmcode = 'MPM15'
				  AND a.internaldiv = M.divcode
		   LEFT JOIN CMCOMMONM r
			   ON r.cmmcode = 'CMM02'
				  AND r.divcode = CASE WHEN a.itemdiv = '03' THEN a.transunit ELSE x.transunit END
		   LEFT JOIN CMCOMMONM c
			   ON c.cmmcode = 'CMM64'
				  AND c.divcode = CASE WHEN a.itemdiv = '03' THEN a.stockwarehousediv WHEN a.itemdiv = '05' THEN '500' ELSE x.stockwarehousediv END
		   LEFT JOIN (SELECT   itemcode,
							   MAX(revisionno) soprevisionno
					  FROM	   SopRevisionManage
					  WHERE    usediv = 'Y'
					  GROUP BY itemcode) S
			   ON a.itemcode = S.itemcode
	WHERE  a.itemdiv IN ('03', '04', '05')
/
