CREATE TRIGGER TRIGGERATT_SECOM_PERSON
AFTER INSERT OR UPDATE OR DELETE
  ON T_SECOM_PERSON
FOR EACH ROW
  DECLARE
    p_userid        varchar2(20)    := ''; 
    p_reasondiv     varchar2(5)     := ''; 
    p_reasontext    varchar2(50)    := ''; 
    p_idata         varchar(1)      := ''; 
    p_ddata         varchar(1)      := ''; 
    STR             VARCHAR2(4000)  := '';
    atcnt           INT := 0;
 BEGIN
        FOR REC IN(
               SELECT COUNT(*) D1
            FROM   ATINFO
        )
        LOOP
               atcnt := REC.D1;
        END LOOP;
       IF (atcnt <> 0) THEN
   FOR REC IN(
       SELECT USERID,
              REASONDIV,
              REASONTEXT
       FROM   ATINFO
   )
   LOOP
       p_userid := REC.USERID;
       p_reasondiv := REC.REASONDIV;
       p_reasontext := REC.REASONTEXT;
   END LOOP;
       ELSE
       FOR REC IN(
            SELECT SUBSTR(NVL(s.username || '(' || s.terminal || ')', 'unKnown'),1,20) D1,
                   'SQL' D2,
                   'IP_' || SYS_CONTEXT ('USERENV', 'IP_ADDRESS') || '/MAC_' D3
            FROM   v$session s, v$process p
            WHERE  s.paddr = p.addr
                   AND s.sid = (SELECT sid
                                FROM   v$mystat
                                WHERE  ROWNUM = 1)
       )
       LOOP
           p_userid := REC.D1;
           p_reasondiv := REC.D2;
           p_reasontext := REC.D3;
       END LOOP;
       END IF;


    --입력/수정/삭제 이벤트를 알기 위한 변수 선언
    IF INSERTING THEN
       p_idata := 'I';
    END IF;
    IF DELETING THEN
       p_ddata := 'D';
    END IF;
    IF UPDATING THEN
       p_idata := 'I';
       p_ddata := 'D';
    END IF;

   FOR REC IN(
        SELECT ':NEW.' || COLUMN_NAME || ',' D1
        FROM USER_TAB_COLUMNS
        WHERE TABLE_NAME = 'T_SECOM_PERSON'
        )
        LOOP
            STR := STR || REC.D1;
        END LOOP;

        STR := SUBSTR(STR, 1,LENGTH(STR)-1);
    --입력이벤트  
    IF(p_idata is not null and p_ddata is null)  THEN

      insert into  atT_SECOM_PERSON

      (select SYSDATE,p_idata,p_userid,p_reasondiv,p_reasontext,:NEW.CARDNO,:NEW.CARDFULLDATA,:NEW.CARDTYPE,:NEW.NAME,:NEW.COMPANY,:NEW.DEPARTMENT,:NEW.TEAM,:NEW.PART,:NEW.GRADE,:NEW.DETAILGRADE,:NEW.JUMINNO,:NEW.SABUN,:NEW.WORKGROUP,:NEW.EMPLOYTYPE,:NEW.WORKSTATUS,:NEW.AUTHTYPE,:NEW.ISSUECOUNT,:NEW.PASSWORD,:NEW.WORKSCHEDULE,:NEW.JOININGDATE,:NEW.RETIREDATE,:NEW.ENABLEFINGERPRINT,:NEW.ENABLEWORKMANAGE,:NEW.ENABLEFOOD,:NEW.MODIFYFLAG,:NEW.USERLEVEL,:NEW.VALIDITYDATE,:NEW.PID,:NEW.SITECODE,:NEW.CODECOMPANY,:NEW.CODESITE,:NEW.CODELEVEL,:NEW.INSERTTIME,:NEW.UPDATETIME,:NEW.VERSION FROM DUAL);

    --삭제이벤트

    ELSIF(p_idata is null and p_ddata is not null) THEN

      insert into  atT_SECOM_PERSON

      (select SYSDATE,p_ddata,p_userid,p_reasondiv,p_reasontext,:OLD.CARDNO,:OLD.CARDFULLDATA,:OLD.CARDTYPE,:OLD.NAME,:OLD.COMPANY,:OLD.DEPARTMENT,:OLD.TEAM,:OLD.PART,:OLD.GRADE,:OLD.DETAILGRADE,:OLD.JUMINNO,:OLD.SABUN,:OLD.WORKGROUP,:OLD.EMPLOYTYPE,:OLD.WORKSTATUS,:OLD.AUTHTYPE,:OLD.ISSUECOUNT,:OLD.PASSWORD,:OLD.WORKSCHEDULE,:OLD.JOININGDATE,:OLD.RETIREDATE,:OLD.ENABLEFINGERPRINT,:OLD.ENABLEWORKMANAGE,:OLD.ENABLEFOOD,:OLD.MODIFYFLAG,:OLD.USERLEVEL,:OLD.VALIDITYDATE,:OLD.PID,:OLD.SITECODE,:OLD.CODECOMPANY,:OLD.CODESITE,:OLD.CODELEVEL,:OLD.INSERTTIME,:OLD.UPDATETIME,:OLD.VERSION FROM DUAL);

    --수정이벤트  
    ELSIF(p_idata is not null and p_ddata is not null) THEN 

      insert into  atT_SECOM_PERSON

      (select SYSDATE,'U',p_userid,p_reasondiv,p_reasontext,:NEW.CARDNO,:NEW.CARDFULLDATA,:NEW.CARDTYPE,:NEW.NAME,:NEW.COMPANY,:NEW.DEPARTMENT,:NEW.TEAM,:NEW.PART,:NEW.GRADE,:NEW.DETAILGRADE,:NEW.JUMINNO,:NEW.SABUN,:NEW.WORKGROUP,:NEW.EMPLOYTYPE,:NEW.WORKSTATUS,:NEW.AUTHTYPE,:NEW.ISSUECOUNT,:NEW.PASSWORD,:NEW.WORKSCHEDULE,:NEW.JOININGDATE,:NEW.RETIREDATE,:NEW.ENABLEFINGERPRINT,:NEW.ENABLEWORKMANAGE,:NEW.ENABLEFOOD,:NEW.MODIFYFLAG,:NEW.USERLEVEL,:NEW.VALIDITYDATE,:NEW.PID,:NEW.SITECODE,:NEW.CODECOMPANY,:NEW.CODESITE,:NEW.CODELEVEL,:NEW.INSERTTIME,:NEW.UPDATETIME,:NEW.VERSION FROM DUAL);

    END IF;
 END;
/
