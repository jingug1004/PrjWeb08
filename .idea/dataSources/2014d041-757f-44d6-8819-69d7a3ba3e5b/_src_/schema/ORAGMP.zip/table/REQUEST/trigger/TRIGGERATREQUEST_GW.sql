CREATE TRIGGER TRIGGERATREQUEST_GW
AFTER INSERT OR UPDATE OR DELETE
  ON REQUEST
FOR EACH ROW
  DECLARE
        
        V_CUSTNAME VARCHAR2(200);
        V_REQUESTQTY NUMBER(15,5);
        V_CHECK VARCHAR2(200);

BEGIN
 
        /*20180109 CHOE REQUEST값이 바뀌는 경우 그룹웨어 해당 정보를 UPDATE 해준다.
        결재 진행 중에 변경될 수 있다
        */                      
         IF UPDATING('CUSTCODE') THEN
                BEGIN   
                            
                        IF :NEW.CUSTCODE IS NOT NULL THEN
                                V_CUSTNAME := '';
                                SELECT CUSTNAME
                                INTO V_CUSTNAME
                                FROM ORAGMP.CMCUSTM
                                WHERE CUSTCODE = :NEW.CUSTCODE
                                ;                
                        
                                UPDATE HANAGROUPWARE.GW_EA_REQUISITION 
                                SET CUST_ID = :NEW.CUSTCODE
                                ,CUST_NM = V_CUSTNAME
                                WHERE REQUESTNO = :OLD.REQUESTNO
                                ;
                        END IF;
                EXCEPTION
                        WHEN OTHERS THEN     
                        raise_application_error( -20001,'구매청구 거래처 정보 수정시 ERROR 발생.' ) ;
                END;      
        
        END IF;
        
        IF UPDATING('PRICE') THEN        
                BEGIN
                
                        IF :NEW.PRICE IS NOT NULL THEN --AND :NEW.REQUESTQTY IS NOT NULL THEN
                                /*V_REQUESTQTY := 0;
                                SELECT REQUESTQTY
                                INTO V_REQUESTQTY
                                FROM ORAGMP.REQUEST REQ
                                WHERE REQUESTNO = :NEW.REQUESTNO  
                                ;
                                */                                
                                --IF V_REQUESTQTY > 0 THEN
                                        UPDATE HANAGROUPWARE.GW_EA_REQUISITION 
                                        SET DANGA = :NEW.PRICE
                                        ,AMT = :NEW.PRICE * :OLD.REQUESTQTY --:NEW.PRICE * V_REQUESTQTY
                                        WHERE REQUESTNO = :NEW.REQUESTNO
                                        ;
                                --END IF;
                        END IF;
                EXCEPTION
                        WHEN OTHERS THEN     
                        raise_application_error( -20001,'구매청구 단가 수정시 ERROR 발생.' +V_CHECK)                     
                        ;
                END;
                
        END IF;      
   
END;
/
