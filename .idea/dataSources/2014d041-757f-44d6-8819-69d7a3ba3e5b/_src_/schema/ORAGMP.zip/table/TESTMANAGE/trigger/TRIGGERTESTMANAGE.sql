CREATE TRIGGER TRIGGERTESTMANAGE
AFTER INSERT OR UPDATE OR DELETE
  ON TESTMANAGE
FOR EACH ROW
  DECLARE
    p_userid        varchar2(20)    := ''; 
    p_reasondiv     varchar2(5)     := ''; 
    p_reasontext    varchar2(50)    := ''; 
    p_idata         varchar(1)      := ''; 
    p_ddata         varchar(1)      := ''; 
    STR             VARCHAR2(4000)  := '';
    atcnt           INT := 0;
    p_itestresult	            varchar2(1) := '';
    p_dtestresult	            varchar2(1) := '';
    p_testno			        varchar2(20) := '';
    p_testdiv		            varchar2(5) := '';
    p_plantcode		            varchar2(4) := '';
    p_samplingqty	            decimal(15,4) := 0;
    p_testrequestremark2        varchar2(20) := '';
    p_dtestrequestremark2       varchar2(20) := '';
    p_testprogressstatus	    varchar2(5) := '';
    p_dtestprogressstatus	    varchar2(5) := '';
    p_content	                decimal(15,4) := 0;
    p_contentrate       	    decimal(15,4) := 0; 
    p_markmaterialno            varchar2(20) := '';

 BEGIN
        FOR REC IN(
               SELECT COUNT(*) D1
            FROM   ATINFO
        )
        LOOP
               atcnt := REC.D1;
        END LOOP;
       IF (atcnt <> 0) THEN
   FOR REC IN(
       SELECT USERID,
              REASONDIV,
              REASONTEXT
       FROM   ATINFO
   )
   LOOP
       p_userid := REC.USERID;
       p_reasondiv := REC.REASONDIV;
       p_reasontext := REC.REASONTEXT;
   END LOOP;
       ELSE
       FOR REC IN(
            SELECT SUBSTR(NVL(s.username || '(' || s.terminal || ')', 'unKnown'),1,20) D1,
                   'SQL' D2,
                   'IP_' || SYS_CONTEXT ('USERENV', 'IP_ADDRESS') || '/MAC_' D3
            FROM   v$session s, v$process p
            WHERE  s.paddr = p.addr
                   AND s.sid = (SELECT sid
                                FROM   v$mystat
                                WHERE  ROWNUM = 1)
       )
       LOOP
           p_userid := REC.D1;
           p_reasondiv := REC.D2;
           p_reasontext := REC.D3;
       END LOOP;
       END IF;


    --입력/수정/삭제 이벤트를 알기 위한 변수 선언
    IF INSERTING THEN
       p_idata := 'I';
    END IF;
    IF DELETING THEN
       p_ddata := 'D';
    END IF;
    IF UPDATING THEN
       p_idata := 'I';
       p_ddata := 'D';
    END IF;

--          임시주석
   FOR REC IN(
        SELECT ':NEW.' || COLUMN_NAME || ',' D1
        FROM USER_TAB_COLUMNS
        WHERE TABLE_NAME = 'TESTMANAGE'
        )
        LOOP
            STR := STR || REC.D1;
        END LOOP;
--
        STR := SUBSTR(STR, 1,LENGTH(STR)-1);

--    --입력이벤트  
--    IF(p_idata is not null and p_ddata is null)  THEN
--        
--        insert into PrintInformation
--        (
--            testmanageid
--            ,printmanage1
--            ,printmanage2
--            ,printmanage3
--            ,printmanage4
--            ,printmanage5
--            ,printmanage6	
--        )
--        select	:NEW.TESTMANAGEID
--                ,0
--                ,0
--                ,0
--                ,0
--                ,0
--                ,0
--        from	dual;
    
--    --삭제이벤트

    IF(p_idata is null and p_ddata is not null) THEN

       delete	PrintInformation
	     where	testmanageid in (select :NEW.TESTMANAGEID from dual);

    --수정이벤트  
    ELSIF(p_idata is not null and p_ddata is not null) THEN 

         if(:NEW.testprogressstatus = '10' or p_dtestprogressstatus = '10')THEN

            if(p_dtestprogressstatus = '10' and :NEW.testprogressstatus <> '10') THEN
            
                p_itestresult := null;
                p_testrequestremark2 := null;
            else
                p_itestresult := :NEW.testresultcode;
                p_testrequestremark2 := :NEW.testrequestremark2;
            END IF;
                
			update	warehousing set testresult = p_itestresult, samplingpackqty = :NEW.samplingqty where testno = :NEW.testno and plantcode = :NEW.plantcode;

			update	workflow set testresult = p_itestresult where testno = :NEW.testno and plantcode = :NEW.plantcode;
				
			update	PackingResults 
			set		goodstestresult = p_itestresult
					,warehousestate = case when p_testrequestremark2 = 'Y' and NVL(warehousestate,'') = '' then '01' else warehousestate end
			
			where	goodstestrequestno = :NEW.testno
					and plantcode = :NEW.plantcode;
				
			update	warehousing
			set		testresult = p_itestresult
					,warehousestate = case when p_testrequestremark2 = 'Y' and NVL(warehousestate,'') = '' then '01' else warehousestate end
					,classifyjudgerateB = :NEW.contentrate
					,classifyjudgerate = :NEW.price--p_content
			
			where	testno = :NEW.testno
					and plantcode = :NEW.plantcode;
        END IF;
    END IF;
 END;
/
