CREATE TRIGGER TRIGGERATPURCHASEORDER
AFTER INSERT OR UPDATE OR DELETE
  ON PURCHASEORDER
FOR EACH ROW
  DECLARE
    p_userid        varchar2(20)    := ''; 
    p_reasondiv     varchar2(5)     := ''; 
    p_reasontext    varchar2(50)    := ''; 
    p_idata         varchar(1)      := ''; 
    p_ddata         varchar(1)      := ''; 
    STR             VARCHAR2(4000)  := '';
    atcnt           INT := 0;
 BEGIN
        FOR REC IN(
               SELECT COUNT(*) D1
            FROM   ATINFO
        )
        LOOP
               atcnt := REC.D1;
        END LOOP;
       IF (atcnt <> 0) THEN
   FOR REC IN(
       SELECT USERID,
              REASONDIV,
              REASONTEXT
       FROM   ATINFO
   )
   LOOP
       p_userid := REC.USERID;
       p_reasondiv := REC.REASONDIV;
       p_reasontext := REC.REASONTEXT;
   END LOOP;
       ELSE
       FOR REC IN(
            SELECT SUBSTR(NVL(s.username || '(' || s.terminal || ')', 'unKnown'),1,20) D1,
                   'SQL' D2,
                   'IP_' || SYS_CONTEXT ('USERENV', 'IP_ADDRESS') || '/MAC_' D3
            FROM   v$session s, v$process p
            WHERE  s.paddr = p.addr
                   AND s.sid = (SELECT sid
                                FROM   v$mystat
                                WHERE  ROWNUM = 1)
       )
       LOOP
           p_userid := REC.D1;
           p_reasondiv := REC.D2;
           p_reasontext := REC.D3;
       END LOOP;
       END IF;


    --입력/수정/삭제 이벤트를 알기 위한 변수 선언
    IF INSERTING THEN
       p_idata := 'I';
    END IF;
    IF DELETING THEN
       p_ddata := 'D';
    END IF;
    IF UPDATING THEN
       p_idata := 'I';
       p_ddata := 'D';
    END IF;

   FOR REC IN(
        SELECT ':NEW.' || COLUMN_NAME || ',' D1
        FROM USER_TAB_COLUMNS
        WHERE TABLE_NAME = 'PURCHASEORDER'
        )
        LOOP
            STR := STR || REC.D1;
        END LOOP;

        STR := SUBSTR(STR, 1,LENGTH(STR)-1);
    --입력이벤트  
    IF(p_idata is not null and p_ddata is null)  THEN

      insert into  atPURCHASEORDER

      (select SYSDATE,p_idata,p_userid,p_reasondiv,p_reasontext,:NEW.PURCHASEORDERDIV,:NEW.ORDERNO,:NEW.REQUESTNO,:NEW.IMPORTSHTNO,:NEW.SHIPPINGNO,:NEW.ITEMCODE,:NEW.ORDERDATE,:NEW.CUSTCODE,:NEW.MANUFACTURECODE,:NEW.BUYDIV,:NEW.ORDERQTY,:NEW.ORDERPRICE,:NEW.ORDERAMT,:NEW.ORDERVAT,:NEW.PREARRDATE,:NEW.REMARK,:NEW.ORDERSTATE,:NEW.PRINTCHECK,:NEW.MAKEITEMCODE,:NEW.INTERNALDIV,:NEW.PLANTCODE,:NEW.KEYNO,:NEW.EXCHANGECODE,:NEW.SPECIALNOTE,:NEW.CHANGENOTE,:NEW.PRTLOTNO,:NEW.PRTLOTDATE,:NEW.PRTVALIDDATE,:NEW.PACKINGLOTNO,:NEW.MAKINGQTY,:NEW.LOTNO,:NEW.REQUESTOR,:NEW.ORDERSHEETNO,:NEW.BLCODE,:NEW.TRANSQTY,:NEW.MAKINGORDERNO,:NEW.PACKINGORDERNO FROM DUAL);

    --삭제이벤트

    ELSIF(p_idata is null and p_ddata is not null) THEN

      insert into  atPURCHASEORDER

      (select SYSDATE,p_ddata,p_userid,p_reasondiv,p_reasontext,:OLD.PURCHASEORDERDIV,:OLD.ORDERNO,:OLD.REQUESTNO,:OLD.IMPORTSHTNO,:OLD.SHIPPINGNO,:OLD.ITEMCODE,:OLD.ORDERDATE,:OLD.CUSTCODE,:OLD.MANUFACTURECODE,:OLD.BUYDIV,:OLD.ORDERQTY,:OLD.ORDERPRICE,:OLD.ORDERAMT,:OLD.ORDERVAT,:OLD.PREARRDATE,:OLD.REMARK,:OLD.ORDERSTATE,:OLD.PRINTCHECK,:OLD.MAKEITEMCODE,:OLD.INTERNALDIV,:OLD.PLANTCODE,:OLD.KEYNO,:OLD.EXCHANGECODE,:OLD.SPECIALNOTE,:OLD.CHANGENOTE,:OLD.PRTLOTNO,:OLD.PRTLOTDATE,:OLD.PRTVALIDDATE,:OLD.PACKINGLOTNO,:OLD.MAKINGQTY,:OLD.LOTNO,:OLD.REQUESTOR,:OLD.ORDERSHEETNO,:OLD.BLCODE,:OLD.TRANSQTY,:OLD.MAKINGORDERNO,:OLD.PACKINGORDERNO FROM DUAL);

    --수정이벤트  
    ELSIF(p_idata is not null and p_ddata is not null) THEN 

      insert into  atPURCHASEORDER

      (select SYSDATE,'U',p_userid,p_reasondiv,p_reasontext,:NEW.PURCHASEORDERDIV,:NEW.ORDERNO,:NEW.REQUESTNO,:NEW.IMPORTSHTNO,:NEW.SHIPPINGNO,:NEW.ITEMCODE,:NEW.ORDERDATE,:NEW.CUSTCODE,:NEW.MANUFACTURECODE,:NEW.BUYDIV,:NEW.ORDERQTY,:NEW.ORDERPRICE,:NEW.ORDERAMT,:NEW.ORDERVAT,:NEW.PREARRDATE,:NEW.REMARK,:NEW.ORDERSTATE,:NEW.PRINTCHECK,:NEW.MAKEITEMCODE,:NEW.INTERNALDIV,:NEW.PLANTCODE,:NEW.KEYNO,:NEW.EXCHANGECODE,:NEW.SPECIALNOTE,:NEW.CHANGENOTE,:NEW.PRTLOTNO,:NEW.PRTLOTDATE,:NEW.PRTVALIDDATE,:NEW.PACKINGLOTNO,:NEW.MAKINGQTY,:NEW.LOTNO,:NEW.REQUESTOR,:NEW.ORDERSHEETNO,:NEW.BLCODE,:NEW.TRANSQTY,:NEW.MAKINGORDERNO,:NEW.PACKINGORDERNO FROM DUAL);

    END IF;
 END;
/
