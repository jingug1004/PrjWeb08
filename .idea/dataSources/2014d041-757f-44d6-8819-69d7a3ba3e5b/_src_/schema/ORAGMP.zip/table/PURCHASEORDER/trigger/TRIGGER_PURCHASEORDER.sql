CREATE TRIGGER TRIGGER_PURCHASEORDER
INSTEAD OF INSERT OR UPDATE OR DELETE
  ON PURCHASEORDER
FOR EACH ROW
COMPOUND TRIGGER

    -- MPM04 10 100 자재입고구분 구매요청중
    -- MPM04 20 120 자재입고구분 구매발주중
    -- MPM04 30 100 자재입고구분 구매발주완료

    -- 업데이트 대상 찾기(insert, update, delete 공통) => 구매요청번호
    p_requestno           VARCHAR2(20) := '';   -- 구매요청번호
    p_requeststate        VARCHAR2(5)  := '';   -- 요청상태
    p_orderstate          VARCHAR2(5)  := '';   -- 발주상태
    p_purchaseorderdiv    VARCHAR2(5)  := '';   -- 구매발주표준구분


    AFTER EACH ROW IS BEGIN

        -- 업데이트 대상 찾기(insert, update, delete 공통) => 구매요청번호
        IF INSERTING THEN    -- INSERT

            p_requestno         := :NEW.requestno;
            p_purchaseorderdiv  := :NEW.purchaseorderdiv ;

        ELSIF UPDATING THEN -- UPDATE

            p_requestno         := :NEW.requestno;
            p_purchaseorderdiv  := :NEW.purchaseorderdiv ;

        ELSIF DELETING THEN -- DELETE

            p_requestno         := :OLD.requestno;
            p_purchaseorderdiv  := :OLD.purchaseorderdiv ;

        END IF;

    END AFTER EACH ROW;

    AFTER STATEMENT IS BEGIN

        -- 현재의 구매발주 정보에서 최대의 발주상태 값 검색
        FOR rec IN (
            SELECT  MAX(orderstate) AS alias1
            FROM    PurchaseOrder
            WHERE   requestno = p_requestno
                    AND purchaseorderdiv = p_purchaseorderdiv
        )
        LOOP
            p_orderstate := TO_CHAR( rec.alias1 ) ;
        END LOOP ;


        -- 발주상태값이 없으면 => 구매요청중
        IF(p_orderstate IS NULL) THEN

            p_requeststate := '10';

        -- 발주상태가 구매발주이면 -> 구매발주
        ELSIF( p_orderstate <> '10') THEN

            p_requeststate := '20';

        END IF;


        IF(p_purchaseorderdiv = '01' OR p_purchaseorderdiv = '02') THEN

            -- 구매요청 테이블에 상기 조건의 요청상태 값 저장
            UPDATE  Request
            SET     requeststate = p_requeststate
            WHERE   requestno = p_requestno
                    AND requeststate <> '30'
                    AND requestitemdiv = p_purchaseorderdiv ;

        END IF ;

    END AFTER STATEMENT;

END;
/
