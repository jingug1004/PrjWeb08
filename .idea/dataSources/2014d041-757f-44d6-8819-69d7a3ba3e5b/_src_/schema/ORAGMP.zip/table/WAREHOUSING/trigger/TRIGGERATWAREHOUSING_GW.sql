CREATE TRIGGER TRIGGERATWAREHOUSING_GW
AFTER INSERT OR UPDATE OR DELETE
  ON WAREHOUSING
FOR EACH ROW
  DECLARE
        
        V_CUSTNAME VARCHAR2(200);

BEGIN
        
        IF UPDATING('CUSTCODE') /*OR    
        UPDATING('PRICE')*/ THEN                
                BEGIN
                        V_CUSTNAME := 0;
                        SELECT CUSTNAME
                        INTO V_CUSTNAME
                        FROM ORAGMP.CMCUSTM
                        WHERE CUSTCODE = :NEW.CUSTCODE
                        ;                
                
                        /*UPDATE HANAGROUPWARE.GW_EA_REQUISITION 
                        SET CUST_ID = :NEW.CUSTCODE
                        ,CUST_NM = V_CUSTNAME                        
                        ,DANGA = :NEW.PRICE
                        WHERE REQUESTNO = :OLD.REQUESTNO
                        ;*/
                EXCEPTION
                        WHEN OTHERS THEN     
                        raise_application_error( -20001,'입고등록 수정시 ERROR 발생.' ) ;
                END;      
        
        END IF;
   
END;
/
