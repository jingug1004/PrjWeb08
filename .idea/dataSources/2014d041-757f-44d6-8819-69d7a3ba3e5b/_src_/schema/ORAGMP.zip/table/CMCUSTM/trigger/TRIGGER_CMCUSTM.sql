CREATE TRIGGER TRIGGER_CMCUSTM
AFTER UPDATE
  ON CMCUSTM
FOR EACH ROW
  DECLARE

    p_plantcode        VARCHAR2(4)   := '';
    p_custcode         VARCHAR2(20)  := '';
    p_custname         VARCHAR2(50)  := '';
    p_ceoname          VARCHAR2(20)  := '';
    p_post             VARCHAR2(10)  := '';
    p_addr1            VARCHAR2(100) := '';
    p_addr2            VARCHAR2(100) := '';
    p_businessno       VARCHAR2(20)  := '';
    p_corporationno    VARCHAR2(20)  := '';
    p_custcondition    VARCHAR2(50)  := '';
    p_custitem         VARCHAR2(50)  := '';
    p_opendate         VARCHAR2(10)  := '';
    p_telno            VARCHAR2(40)  := '';

    p_custdiv          VARCHAR2(12)  := '';
    p_chgdate          VARCHAR2(10)  := '';
    v_temp             NUMBER        := 0;

    USER_DEFINE_ERROR1 EXCEPTION;
    USER_DEFINE_ERROR2 EXCEPTION;

BEGIN


    IF UPDATING THEN

        IF( TRIM(:OLD.CUSTCODE) <> TRIM(:NEW.CUSTCODE) ) THEN

            RAISE USER_DEFINE_ERROR1;

        END IF ;

    END IF;


    -- 이력사항이 아닌 필드의 갱신은 처리하지 않는다.
    IF NOT( TRIM(:OLD.CUSTNAME)         <> TRIM(:NEW.CUSTNAME)
            OR TRIM(:OLD.CEONAME)       <> TRIM(:NEW.CEONAME)
            OR TRIM(:OLD.POST)          <> TRIM(:NEW.POST)
            OR TRIM(:OLD.ADDR1)         <> TRIM(:NEW.ADDR1)
            OR TRIM(:OLD.ADDR2)         <> TRIM(:NEW.ADDR2)
            OR TRIM(:OLD.BUSINESSNO)    <> TRIM(:NEW.BUSINESSNO)
            OR TRIM(:OLD.CORPORATIONNO) <> TRIM(:NEW.CORPORATIONNO)
            OR TRIM(:OLD.CUSTCONDITION) <> TRIM(:NEW.CUSTCONDITION)
            OR TRIM(:OLD.CUSTITEM)      <> TRIM(:NEW.CUSTITEM)
            OR TRIM(:OLD.OPENDATE)      <> TRIM(:NEW.OPENDATE)
            OR TRIM(:OLD.TELNO)         <> TRIM(:NEW.TELNO)

            OR TRIM(:OLD.creditlmt)         <> TRIM(:NEW.creditlmt)
            OR TRIM(:OLD.balancelmt)         <> TRIM(:NEW.balancelmt)
            OR TRIM(:OLD.nocollmt)         <> TRIM(:NEW.nocollmt)
            OR TRIM(:OLD.securitylmt)         <> TRIM(:NEW.securitylmt)
            OR TRIM(:OLD.jumun_limit)         <> TRIM(:NEW.jumun_limit)
            OR TRIM(:OLD.turnlmt)         <> TRIM(:NEW.turnlmt)
            OR TRIM(:OLD.avgamt)         <> TRIM(:NEW.avgamt)
            OR TRIM(:OLD.salamtlmt)         <> TRIM(:NEW.salamtlmt)

    ) THEN

        RETURN;

    END IF;


-- MS SQL 과 ORACLE 구조가 달라서 처리가 불가함. 티리거 내에서 INSERT, DELETE, UPDATE 몇건이 이루어졌는지 알수가 없음
--    IF ( SQL%ROWCOUNT > 1) THEN
--
--        RAISE USER_DEFINE_ERROR2; -- STEP 2
--
--        RETURN ;
--
--    END IF;


    p_custdiv := :NEW.CUSTDIV;

    IF ( p_custdiv IN ('1', '4', '5') ) THEN
        RETURN;
    END IF;


    -- 변경사항이 없으면 이력을 남기지 않는다.
    IF ( TRIM(:OLD.CUSTNAME)           = TRIM(:NEW.CUSTNAME)
          AND TRIM(:OLD.CEONAME)       = TRIM(:NEW.CEONAME)
          AND TRIM(:OLD.POST)          = TRIM(:NEW.POST)
          AND TRIM(:OLD.ADDR1)         = TRIM(:NEW.ADDR1)
          AND TRIM(:OLD.ADDR2)         = TRIM(:NEW.ADDR2)
          AND TRIM(:OLD.BUSINESSNO)    = TRIM(:NEW.BUSINESSNO)
          AND TRIM(:OLD.CORPORATIONNO) = TRIM(:NEW.CORPORATIONNO)
          AND TRIM(:OLD.CUSTCONDITION) = TRIM(:NEW.CUSTCONDITION)
          AND TRIM(:OLD.CUSTITEM)      = TRIM(:NEW.CUSTITEM)
          AND TRIM(:OLD.OPENDATE)      = TRIM(:NEW.OPENDATE)
          AND TRIM(:OLD.TELNO)         = TRIM(:NEW.TELNO)

          AND TRIM(:OLD.creditlmt)         <> TRIM(:NEW.creditlmt)
          AND TRIM(:OLD.balancelmt)         <> TRIM(:NEW.balancelmt)
          AND TRIM(:OLD.nocollmt)         <> TRIM(:NEW.nocollmt)
          AND TRIM(:OLD.securitylmt)         <> TRIM(:NEW.securitylmt)
          AND TRIM(:OLD.jumun_limit)         <> TRIM(:NEW.jumun_limit)
          AND TRIM(:OLD.turnlmt)         <> TRIM(:NEW.turnlmt)
          AND TRIM(:OLD.avgamt)         <> TRIM(:NEW.avgamt)
          AND TRIM(:OLD.salamtlmt)         <> TRIM(:NEW.salamtlmt)

    ) THEN

        RETURN;

    END IF;


    p_custcode := :OLD.CUSTCODE ;

    p_opendate := :OLD.OPENDATE;

    p_chgdate  := TO_CHAR(SYSDATE, 'YYYY-MM-DD');


    --입력당일 갱신된 자료는 제외(HISTORY를 남기지 않는다)
    IF( p_opendate = p_chgdate ) THEN
        RETURN;
    END IF ;


    FOR rec IN (
        SELECT  COUNT(CHANGDATE) AS alias1
        FROM    CMCUSTHISD
        WHERE   CUSTCODE = p_custcode
                AND CHANGDATE = p_chgdate
    )
    LOOP
        v_temp := rec.alias1 ;
    END LOOP ;


    IF( v_temp > 0 ) THEN --데이터가 있으면 UPDATE

        UPDATE  CMCUSTHISD
        SET     CUSTNAME        = :NEW.CUSTNAME
                ,CEONAME        = :NEW.CEONAME
                ,POST           = :NEW.POST
                ,ADDR1          = :NEW.ADDR1
                ,ADDR2          = :NEW.ADDR2
                ,BUSINESSNO     = :NEW.BUSINESSNO
                ,CORPORATIONNO  = :NEW.CORPORATIONNO
                ,CONDITION      = :NEW.CUSTCONDITION
                ,ITEM           = :NEW.CUSTITEM
                ,OPENDATE       = :NEW.OPENDATE
                ,TELNO          = :NEW.TELNO
                ,OLDCUSTNAME    = :OLD.CUSTNAME
                ,creditlmt      = :NEW.creditlmt
                ,balancelmt     = :NEW.balancelmt
                ,nocollmt       = :NEW.nocollmt
                ,securitylmt    = :NEW.securitylmt
                ,jumun_limit    = :NEW.jumun_limit
                ,turnlmt       = :NEW.turnlmt
                ,avgamt        = :NEW.avgamt
                ,salamtlmt     = :NEW.salamtlmt
        WHERE   CUSTCODE        = :OLD.CUSTCODE
                AND CHANGDATE   = p_chgdate ;

    ELSE --데이터가 없으면 INSERT

        INSERT INTO CMCUSTHISD (
            plantcode
            , custcode
            , changdate
            , oldcustname
            , oldceoname
            , oldbusinessno
            , oldcorporationno
            , oldcondition
            , olditem
            , oldpost
            , oldaddr1
            , oldaddr2
            , OLDTELNO
            , custname
            , ceoname
            , businessno
            , corporationno
            , condition
            , item
            , post
            , addr1
            , addr2
            , TELNO
            , opendate
            , insertdt
            , iempcode
            , updatedt
            , uempcode
            , creditlmt
            , balancelmt
            , nocollmt
            , securitylmt
            , jumun_limit
            , turnlmt
            , avgamt
            , salamtlmt
        )
        VALUES  (
            :NEW.plantcode
            , :NEW.custcode
            ,  p_chgdate
            , :OLD.CUSTNAME
            , :OLD.CEONAME
            , :OLD.BUSINESSNO
            , :OLD.CORPORATIONNO
            , :OLD.CUSTCONDITION
            , :OLD.CUSTITEM
            , :OLD.POST
            , :OLD.ADDR1
            , :OLD.ADDR2
            , :OLD.TELNO
            , :NEW.CUSTNAME
            , :NEW.CEONAME
            , :NEW.BUSINESSNO
            , :NEW.CORPORATIONNO
            , :NEW.CUSTCONDITION
            , :NEW.CUSTITEM
            , :NEW.POST
            , :NEW.ADDR1
            , :NEW.ADDR2
            , :NEW.TELNO
            , :NEW.OPENDATE
            , SYSDATE
            , ''
            , SYSDATE
            , ''
            , :NEW.creditlmt
            , :NEW.balancelmt
            , :NEW.nocollmt
            , :NEW.securitylmt
            , :NEW.jumun_limit
            , :NEW.turnlmt
            , :NEW.avgamt
            , :NEW.salamtlmt
        ) ;

    END IF;

    -- STEP 3
    -- 예외가 발생할 경우 해당 예외를 참조한다.
    EXCEPTION WHEN USER_DEFINE_ERROR1 THEN RAISE_APPLICATION_ERROR(-20000, 'PRIMARY KEY는 수정할 수 없습니다. 프로세스 = CMCUSTM_TU');
              WHEN USER_DEFINE_ERROR2 THEN RAISE_APPLICATION_ERROR(-20000, '1 레코드 이상 일괄처리 할 수 없습니다. 프로세스 = CMCUSTM_TU');

END;
/
