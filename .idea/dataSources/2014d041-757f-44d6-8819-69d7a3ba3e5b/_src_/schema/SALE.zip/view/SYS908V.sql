CREATE VIEW SYS908V AS SELECT jijum_cd, jijum_nm, bank_cd, edi_code
                         FROM SYS908C

/
