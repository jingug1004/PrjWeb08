CREATE VIEW SALE0306_V AS (SELECT YMD         ,
           CUST_ID     ,
           SAWON_ID    ,
           SUM(SU_AMT)     SU_AMT,
           SUM(MISU_AMT)   MISU_AMT,
           SUM(BEFORE_AMT) BEFORE_AMT
      FROM (SELECT YMD         ,
                   CUST_ID     ,
                   SAWON_ID    ,
                   SU_AMT      ,
                   MISU_AMT    ,
                   BEFORE_AMT
              FROM SALE0306 )
           GROUP BY YMD         ,
                    CUST_ID     ,
                    SAWON_ID
  )


/
