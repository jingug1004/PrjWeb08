CREATE VIEW SYS907V AS SELECT bank_cd, bank_nm, bank_snm, edi_code
                         FROM SYS907C

/
