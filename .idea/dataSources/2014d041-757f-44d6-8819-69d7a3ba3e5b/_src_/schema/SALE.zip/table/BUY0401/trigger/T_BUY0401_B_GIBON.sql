CREATE TRIGGER T_BUY0401_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON BUY0401
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : BUY0402                                                      */
/*  테이블명 : 구매발주 Master                                               */
/*  트리거명 : T_BUY0401_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2002.01.28(월)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 일자형, 코드 존재여부 확인                                  */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(100) ;
   v_message    VARCHAR2(250) ;

   user_err     EXCEPTION     ;

   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'BUY0402 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'BUY0402 수정 불가 !! ' ;
   ELSE
      v_message := 'BUY0402 삭제 불가 !! ' ;
   END IF ;

   IF INSERTING OR UPDATING('sawon_id') THEN
      :NEW.sawon_id := LTRIM(RTRIM(:NEW.sawon_id)) ;

      IF :NEW.sawon_id > ' ' THEN
         SELECT COUNT(*), NVL(MAX(dept_cd),' ')
           INTO v_count, v_dummy
           FROM SALE0007
          WHERE sawon_id = :NEW.sawon_id
            AND ROWNUM < 3 ;
         IF v_count = 0 OR v_dummy = ' ' THEN
            v_curr_error := '해당 사원은 등록되지 않았거나 소속부서가 없음. => '||:NEW.sawon_id ;
            RAISE user_err ;
         END IF ;
      END IF ;
   END IF ;

   IF INSERTING OR UPDATING('cust_id') THEN
      :NEW.cust_id := LTRIM(RTRIM(:NEW.cust_id)) ;

      IF :NEW.cust_id > ' ' THEN
         SELECT COUNT(*)
           INTO v_count
           FROM INV0011
          WHERE cust_id = :NEW.cust_id
            AND ROWNUM < 3 ;
         IF v_count = 0 THEN
            v_curr_error := '해당 거래처는 등록되지 않았음. => '||:NEW.cust_id ;
            RAISE user_err ;
         END IF ;
      END IF ;
   END IF ;

   IF INSERTING OR UPDATING('balju_ymd') OR UPDATING('ipgo_ymd') THEN
      v_curr_jakup := '일자 확인: ' ;
      IF F_CHECK_DATE('YMD', :NEW.balju_ymd) = 'FALSE' THEN
         v_curr_error := '발주일자값 오류임.=> '||:NEW.balju_ymd ;
         RAISE user_err ;
      END IF ;

      IF F_CHECK_DATE('YMD', :NEW.ipgo_ymd) = 'FALSE' THEN
         v_curr_error := '납기일자값 오류임.=> '||:NEW.ipgo_ymd ;
         RAISE user_err ;
      END IF ;
   END IF ;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
