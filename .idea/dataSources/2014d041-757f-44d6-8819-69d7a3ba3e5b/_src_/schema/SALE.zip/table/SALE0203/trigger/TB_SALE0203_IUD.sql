CREATE TRIGGER TB_SALE0203_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0203
FOR EACH ROW
  BEGIN

   /* ----------------------------------------------------------------*/
   /* 하나제약                                                        */
   /* 주문서를 입력하면 세금계산서/거래명세서를 자동발생하도록 한다.  */
   /* ----------------------------------------------------------------*/

   /* ------------------------------------------------------------------------ */
   /* 신규입력일 경우                                                          */
   /* ------------------------------------------------------------------------ */
   IF INSERTING THEN
      BEGIN


         INSERT INTO SALE0207 ( DEAL_NO           , DEAL_GB             , YMD                 , SAWON_ID       ,
                                RSAWON_ID         , CUST_ID             , RCUST_ID            , AMT_SUM        ,
                                VAT_SUM           , BIGO                , STORE_LOC           , GYULJAE_GB     ,
                                TAX_TYPE          , DECIMAL_PROC        , CHAMJO_NM           , CHAMJO_RANK    ,
                                GUMAE_NO          , GUBUN)
                       VALUES ( :NEW.GUMAE_NO     , NVL(:NEW.GUMAE_GB,'01'), :NEW.YMD         , :NEW.SAWON_ID  ,
                                :NEW.RSAWON_ID    , :NEW.CUST_ID        , :NEW.RCUST_ID       , :NEW.AMT_SUM   ,
                                :NEW.VAT_SUM      , :NEW.BIGO           , '01'                , :NEW.GYULJAE_GB,
                                :NEW.TAX_TYPE     , :NEW.DECIMAL_PROC   , :NEW.CHAMJO_NM      , :NEW.CHAMJO_RANK    ,
                                :NEW.GUMAE_NO     , :NEW.GUBUN);
      EXCEPTION
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, SQLERRM||' :NEW.GUMAE_NO : '||:NEW.GUMAE_NO) ;
      END;


      BEGIN

         INSERT INTO SALE0209 ( SALE_NO           , SALE_GB             , YMD                 , SAWON_ID       ,
                                RSAWON_ID         , CUST_ID             , RCUST_ID            , AMT_SUM        ,
                                VAT_SUM           , BIGO                , STORE_LOC           , GYULJAE_GB     ,
                                TAX_TYPE          , DECIMAL_PROC        , CHAMJO_NM           , CHAMJO_RANK    ,
                                DEAL_NO           )
                       VALUES ( :NEW.GUMAE_NO     , NVL(:NEW.GUMAE_GB,'01'), :NEW.YMD         , :NEW.SAWON_ID  ,
                                :NEW.RSAWON_ID    , :NEW.CUST_ID        , :NEW.RCUST_ID       , :NEW.AMT_SUM   ,
                                :NEW.VAT_SUM      , :NEW.BIGO           , '01'                , :NEW.GYULJAE_GB,
                                :NEW.TAX_TYPE     , :NEW.DECIMAL_PROC   , :NEW.CHAMJO_NM      , :NEW.CHAMJO_RANK    ,
                                :NEW.GUMAE_NO     );
      EXCEPTION
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, SQLERRM ) ;
      END;

   END IF;


   /* ------------------------------------------------------------------------ */
   /* 수정이 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF UPDATING THEN
         IF :OLD.YMD <> :NEW.YMD THEN
                   RAISE_APPLICATION_ERROR( -20001, '이미 저장된 자료는 날자를 수정 할 수 없습니다.' ) ;
         END IF;

         UPDATE SALE0207 SET
                DEAL_GB      = NVL(:NEW.GUMAE_GB,'01'),
                SAWON_ID     = :NEW.SAWON_ID  ,
                RSAWON_ID    = :NEW.RSAWON_ID ,
                CUST_ID      = :NEW.CUST_ID   ,
                RCUST_ID     = :NEW.RCUST_ID  ,
                AMT_SUM      = :NEW.AMT_SUM   ,
                VAT_SUM      = :NEW.VAT_SUM   ,
                BIGO         = :NEW.BIGO      ,
                STORE_LOC    = '01'           ,
                GYULJAE_GB   = :NEW.GYULJAE_GB,
                TAX_TYPE     = :NEW.TAX_TYPE  ,
                DECIMAL_PROC = :NEW.DECIMAL_PROC,
                CHAMJO_NM    = :NEW.CHAMJO_NM ,
                CHAMJO_RANK  = :NEW.CHAMJO_RANK,
                GUBUN        = :NEW.GUBUN
          WHERE DEAL_NO   = :OLD.GUMAE_NO;

         UPDATE SALE0209 SET
                SALE_GB      = NVL(:NEW.GUMAE_GB,'01'),
                SAWON_ID     = :NEW.SAWON_ID  ,
                RSAWON_ID    = :NEW.RSAWON_ID ,
                CUST_ID      = :NEW.CUST_ID   ,
                RCUST_ID     = :NEW.RCUST_ID  ,
                AMT_SUM      = :NEW.AMT_SUM   ,
                VAT_SUM      = :NEW.VAT_SUM   ,
                BIGO         = :NEW.BIGO      ,
                STORE_LOC    = '01'           ,
                GYULJAE_GB   = :NEW.GYULJAE_GB,
                TAX_TYPE     = :NEW.TAX_TYPE  ,
                DECIMAL_PROC = :NEW.DECIMAL_PROC,
                CHAMJO_NM    = :NEW.CHAMJO_NM ,
                CHAMJO_RANK  = :NEW.CHAMJO_RANK
          WHERE SALE_NO   = :OLD.GUMAE_NO;
   END IF;


   /* ------------------------------------------------------------------------ */
   /* 삭제가 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF DELETING THEN

      DELETE FROM SALE0207
            WHERE DEAL_NO   = :OLD.GUMAE_NO;

      DELETE FROM SALE0209
            WHERE SALE_NO   = :OLD.GUMAE_NO;

   END IF;

END TB_SALE0203_IUD;
/
