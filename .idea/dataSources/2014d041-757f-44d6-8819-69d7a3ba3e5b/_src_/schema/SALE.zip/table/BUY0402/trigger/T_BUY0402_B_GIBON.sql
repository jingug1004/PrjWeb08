CREATE TRIGGER T_BUY0402_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON BUY0402
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : BUY0402                                                      */
/*  테이블명 : 구매발주 Detail                                             */
/*  트리거명 : T_BUY0402_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2002.01.28(월)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 일자형, 코드 존재여부 확인                                  */
/*             2. 구매발주 Master 존재여부 확인                            */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(100) ;
   v_message    VARCHAR2(250) ;

   user_err     EXCEPTION     ;

   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'BUY0402 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'BUY0402 수정 불가 !! ' ;
   ELSE
      v_message := 'BUY0402 삭제 불가 !! ' ;
   END IF ;

   IF INSERTING OR UPDATING THEN
      v_curr_jakup := '구매발주Master(BUY0401) 존재여부 확인: ' ;

      SELECT COUNT(balju_no)
        INTO v_count
        FROM BUY0401
       WHERE balju_no = :NEW.balju_no
         AND ROWNUM < 3 ;

      IF v_count != 1 THEN
         v_curr_error := '해당 구매발주번호가 존재하지 않음.=> '||:NEW.balju_no ;
         RAISE user_err ;
      END IF ;
   END IF ;

   IF (UPDATING('balju_no')    AND :NEW.balju_no      != :OLD.balju_no) OR
      (UPDATING('material_id') AND :NEW.material_id != :OLD.material_id) OR
      DELETING THEN
      v_curr_jakup := '구매발주Detail(BUY0402) 존재여부 확인: ' ;

      SELECT COUNT(INV0302.balju_no), NVL(MAX(LTRIM(RTRIM(INV0302.ymd||'-'||INV0302.slip_no))),' ')
        INTO v_count, v_nm
        FROM INV0302,  --원부자재 입출고전표 Detail
             INV0001   --원부자재 입출고전표 구분
       WHERE INV0302.balju_no    = :OLD.balju_no
         AND INV0302.material_id = :OLD.material_id
         AND INV0302.junpyogb_cd = INV0001.junpyogb_cd
         AND INV0001.ipchul_gb   = '1'
         AND ROWNUM              < 3 ;

      IF v_count > 0 THEN
         v_curr_error := '해당 구매발주에 대한 입고가 존재하여 작업이 불가함. 원부자재입출고 전표번호=> '||v_nm ;
         RAISE user_err ;
      END IF ;
   END IF ;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
