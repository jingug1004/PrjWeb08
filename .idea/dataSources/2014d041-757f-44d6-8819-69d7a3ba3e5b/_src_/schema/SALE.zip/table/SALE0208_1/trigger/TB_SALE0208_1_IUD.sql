CREATE TRIGGER TB_SALE0208_1_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0208_1
FOR EACH ROW
  DECLARE  T_MSG        VARCHAR2(100) ;

BEGIN

   /* ------------------------------------------------------------------------ */
   /* 삭제가 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF DELETING THEN 
     
      BEGIN
          
          UPDATE SALE0305_1
             SET chulgo_qtys  = NVL(chulgo_qtys,0)  - NVL(:OLD.qty,0)
           WHERE store_loc  = :OLD.store_loc
             AND ymd        = :OLD.ymd
             AND item_id    = :OLD.item_id
             AND prod_no    = :OLD.prod_no;
            
      exception when OTHERS then
          raise_application_error( -20001,sqlerrm|| :OLD.qty||'-'||:OLD.store_loc  ||'-'||:OLD.item_id  ||'-'||:OLD.prod_no  ||'-'||:OLD.ymd) ;
      END;
      
   END IF;

END tb_sale0208_1_iud;
/
