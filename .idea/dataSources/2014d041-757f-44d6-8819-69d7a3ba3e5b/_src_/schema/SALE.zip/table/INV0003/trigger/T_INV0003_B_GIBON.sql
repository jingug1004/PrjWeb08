CREATE TRIGGER T_INV0003_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON INV0003
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : INV0003                                                      */
/*  테이블명 : 원부자재코드                                                      */
/*  트리거명 : T_INV0003_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2002.03.05(화)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 수정/삭제시 참조된 자료 존재여부 확인                        */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(100) ;
   v_message    VARCHAR2(250) ;

   user_err     EXCEPTION     ;
   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'INV0003 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'INV0003 수정 불가 !! ' ;
   ELSE
      v_message := 'INV0003 삭제 불가 !! ' ;
   END IF ;

   IF (UPDATING('material_id') AND :NEW.material_id != :OLD.material_id) OR
      DELETING THEN
      SELECT COUNT(*), MIN(prod_seq)
        INTO v_count, v_dummy
        FROM INV0305
       WHERE material_id  = :OLD.material_id
         AND ROWNUM < 3 ;
      IF v_count > 0 THEN
         v_curr_error := '해당 원부자재코드의 제조지시서 자료가 존재하므로 작업이 불가함. 관리자에게 문의바람.'||
                         '=> OLD원부자재코드 '||:OLD.material_id||' /제조지시서일련번호 '||v_dummy ;
         RAISE user_err ;
      END IF ;
      SELECT COUNT(*), MIN(ymd||'-'||slip_no)
        INTO v_count, v_dummy
        FROM INV0302
       WHERE material_id  = :OLD.material_id
         AND ROWNUM < 3 ;
      IF v_count > 0 THEN
         v_curr_error := '해당 원부자재코드의 입출고전표 자료가 존재하므로 작업이 불가함. 관리자에게 문의바람.'||
                         '=> OLD원부자재코드 '||:OLD.material_id||' /전표일자-번호 '||v_dummy ;
         RAISE user_err ;
      END IF ;
   END IF;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
