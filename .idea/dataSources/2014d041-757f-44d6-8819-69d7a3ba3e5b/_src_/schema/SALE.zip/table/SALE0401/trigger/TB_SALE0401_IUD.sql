CREATE TRIGGER TB_SALE0401_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0401
FOR EACH ROW
  DECLARE
     T_UPDATE_CHK NUMBER;
     T_CNT        NUMBER;     
     T_YMD        SALE0306.ymd%TYPE ;
     T_SU_AMT_OLD SALE0306.su_amt%TYPE ;
     T_SU_AMT_NEW SALE0306.su_amt%TYPE ;
BEGIN

   /* ----------------------------------------------------------------*/
   /* 하나제약                                                        */
   /* 현금 수금분에 대해 통장명세서 테이블에 CRUD처리한다             */
   /* 어음 수금분은 Detail(SALE0402)에서 CRUD처리한다.                */
   /* ----------------------------------------------------------------*/

   /* ------------------------------------------------------------------------ */
   /* 신규입력 또는 수정 이면서 현금 수금액이 있으면                           */
   /* 신규입력 때는 현금수금이 없다가 수정 때 현금 수금이 존재 할 수 있음으로  */
   /* 통장명세에 이미 존재하는지 여부를 체크한다.                              */
   /* ------------------------------------------------------------------------ */
   
   
   IF (INSERTING OR UPDATING) AND NVL(:NEW.CASH_AMT,0) <> 0 THEN

      /* ---------------------------------------------------------- */
      /* 현금수금/할인 내용을 통장발행 Table에 저장한다             */
      /* ---------------------------------------------------------- */
      T_UPDATE_CHK := 0;
      BEGIN
          SELECT COUNT(*)
            INTO T_UPDATE_CHK
            FROM SALE0409
           WHERE JUNPYO_NO   = :NEW.JUNPYO_NO
             AND INPUT_SEQ   IS NULL;
      EXCEPTION
            WHEN NO_DATA_FOUND THEN
                 T_UPDATE_CHK := 0;
            WHEN OTHERS THEN
                 RAISE_APPLICATION_ERROR( -20001, '통장 명세서 조회 Err:'||SQLERRM ) ;

      END;

      IF  T_UPDATE_CHK = 0 THEN
              INSERT INTO SALE0409 (
                     ISSU_NO  ,CUST_ID  ,TRAN_YMD ,GUBUN    ,REMARK   ,
                     AMT      ,VAT      ,SUKUM_AMT,GON_NO   ,PAGE_NO  ,
                     LINE_NO  ,ISSU_DATE,SALE_NO  ,JUNPYO_NO,INPUT_SEQ,
                     ADD_SIGN ,RCUST_ID)
              VALUES (ISSU_NO_SEQ.NEXTVAL,
                     :NEW.CUST_ID,
                     TO_CHAR(:NEW.YMD,'YYYYMMDD'),
                     DECODE(:NEW.JUNPYO_GB,'01','5'         --수금
                                          ,'10','6'         --할인
                                          ,'20','6'         --부실채권
                                          ,'30','6'         --거래이관
                                               ,'5'),
                     DECODE(:NEW.JUNPYO_GB,'01','현  금'
                                          ,'10','매출할인'
                                          ,'20',''          -- 부실채권은 통장에 금액만 표기한다.
                                          ,'30',SUBSTRB(:NEW.BIGO,1,20)   -- 거래이관은 비고내용을 표기한다.
                                               ,'기타수금'),
                     0,                                     --AMT
                     0,                                     --VAT
                     :NEW.CASH_AMT,                         --SUKUM_AMT
                     NULL,                                  --GON_NO
                     NULL,                                  --PAGE_NO
                     NULL,                                  --LINE_NO
                     NULL,                                  --ISSU_DATE
                     NULL,                                  --SALE_NO
                     :NEW.JUNPYO_NO,                        --JUNPYO_NO
                     NULL,                                  --INPUT_SEQ
                     '-',                                   --ADD_SIGN
                     :NEW.RCUST_ID);                        --RCUST_ID
      -- 거래처 코드와 매출처 코드가 틀리면 즉. 도매상을 통해 약국으로 납품되는 경우
      -- 거래처 코드로 통장을 발행 하고 매출처로도 통장을 발행한다.
          IF :NEW.CUST_ID <> :NEW.RCUST_ID THEN
              INSERT INTO SALE0409 (
                     ISSU_NO  ,CUST_ID  ,TRAN_YMD ,GUBUN    ,REMARK   ,
                     AMT      ,VAT      ,SUKUM_AMT,GON_NO   ,PAGE_NO  ,
                     LINE_NO  ,ISSU_DATE,SALE_NO  ,JUNPYO_NO,INPUT_SEQ,
                     ADD_SIGN ,RCUST_ID)
              VALUES (ISSU_NO_SEQ.NEXTVAL,
                     :NEW.CUST_ID,
                     TO_CHAR(:NEW.YMD,'YYYYMMDD'),
                     DECODE(:NEW.JUNPYO_GB,'01','5'         --수금
                                          ,'10','6'         --할인
                                          ,'20','6'         --부실채권
                                          ,'30','6'         --거래이관
                                               ,'5'),
                     DECODE(:NEW.JUNPYO_GB,'01','현  금'
                                          ,'10','매출할인'
                                          ,'20',''          -- 부실채권은 통장에 금액만 표기한다.
                                          ,'30',SUBSTRB(:NEW.BIGO,1,20)   -- 거래이관은 비고내용을 표기한다.
                                               ,'기타수금'),
                     0,                                     --AMT
                     0,                                     --VAT
                     :NEW.CASH_AMT,                         --SUKUM_AMT
                     NULL,                                  --GON_NO
                     NULL,                                  --PAGE_NO
                     NULL,                                  --LINE_NO
                     NULL,                                  --ISSU_DATE
                     NULL,                                  --SALE_NO
                     :NEW.JUNPYO_NO,                        --JUNPYO_NO
                     NULL,                                  --INPUT_SEQ
                     '-',                                   --ADD_SIGN
                     :NEW.CUST_ID);                         --RCUST_ID
          END IF;

      ELSE
          IF NVL(:NEW.CASH_AMT,0) <> NVL(:OLD.CASH_AMT,0) OR NVL(:NEW.JUNPYO_GB,' ') <> NVL(:OLD.JUNPYO_GB,' ')
             OR NVL(:NEW.BIGO,' ') <> NVL(:OLD.BIGO,' ') THEN
              UPDATE SALE0409 A SET
                     SUKUM_AMT = :NEW.CASH_AMT,
                     GUBUN     = DECODE(:NEW.JUNPYO_GB,'01','5'         --수금
                                                      ,'10','6'         --할인
                                                      ,'20','6'         --할인
                                                      ,'30','6'         --할인
                                                           ,'5'),
                     REMARK    = DECODE(:NEW.JUNPYO_GB,'01','현  금'
                                                      ,'10','매출할인'
                                                      ,'20',''
                                                      ,'30',SUBSTRB(:NEW.BIGO,1,18)   -- 거래이관은 비고내용을 표기한다.
                                                      ,'기타수금')
               WHERE A.JUNPYO_NO   = :NEW.JUNPYO_NO
                 AND A.INPUT_SEQ   IS NULL;
          END IF;
      END IF;

   /* ------------------------------------------------------------------------ */
   /* 수정 때 이전(OLD) 값에 현금 금액이 0 또는 null로 변경되면 통장명세의 현금*/
   /* 수금내역을 삭제한다.                                                     */
   /* ------------------------------------------------------------------------ */
   ELSIF UPDATING AND (:OLD.CASH_AMT IS NOT NULL AND :OLD.CASH_AMT <> 0) AND
         (:NEW.CASH_AMT IS NULL OR :NEW.CASH_AMT = 0)  THEN    -- 수정 중 현금이 0 Or null로 변경

         DELETE FROM SALE0409
               WHERE JUNPYO_NO   = :NEW.JUNPYO_NO
                 AND INPUT_SEQ   IS NULL;

   END IF;
   

   /* ------------------------------------------------------------------------ */
   /* 신규 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF INSERTING THEN
   
 
       T_YMD        := TO_DATE(TO_CHAR(:NEW.YMD,'YYYYMM')||'01','YYYYMMDD');  --거래처잔고에 ymd 에 바인딩할 변수
       T_SU_AMT_NEW := NVL(:NEW.CASH_AMT,0) + NVL(:NEW.BILL_AMT,0);  
       
      IF :NEW.CUST_ID IS NULL THEN
         RAISE_APPLICATION_ERROR( -20001, '거래처가 입력되지 않았습니다.');
      END IF;
       
      IF :NEW.RCUST_ID IS NULL THEN
         RAISE_APPLICATION_ERROR( -20001, '매출처가 입력되지 않았습니다.');
      END IF;


      SELECT COUNT(*) INTO T_CNT 
        FROM SALE0306 
       WHERE YMD        = T_YMD  
         AND CUST_ID    = :NEW.CUST_ID
         AND RCUST_ID   = :NEW.RCUST_ID;
      IF T_CNT = 0 THEN
         
         
         --RAISE_APPLICATION_ERROR( -20001, '수금 이월이 안되어 거래처잔고에 반영할 수 없습니다. 관리부에 이월작업을 요청하십시오.');
         --매달초에 영업 관리부에서  매출/수금마감 화면에서 전월이월을 처리하지만 신규거래처가 월중에 생기면 잔고에 신규생성해야함.
          BEGIN
              INSERT INTO SALE0306(YMD,CUST_ID,RCUST_ID,SAWON_ID,SU_AMT)
              VALUES (T_YMD,:NEW.CUST_ID,:NEW.RCUST_ID,:NEW.SAWON_ID,T_SU_AMT_NEW); 
          EXCEPTION
                 WHEN OTHERS THEN
                      RAISE_APPLICATION_ERROR( -20001, '수금 변경시 거래처잔고에 반영 Err:'||SQLERRM ) ;
          END;

      ELSE  
             
           --거래처잔고에 반영
          BEGIN
              UPDATE SALE0306
                 SET SU_AMT   = NVL(SU_AMT,0) + T_SU_AMT_NEW  -- 기존수금액에 더한다. 
               WHERE YMD        = T_YMD  
                 AND CUST_ID    = :NEW.CUST_ID
                 AND RCUST_ID   = :NEW.RCUST_ID;

          EXCEPTION
                 WHEN OTHERS THEN
                      RAISE_APPLICATION_ERROR( -20001, '수금 신규시 거래처잔고에 반영 Err:'||SQLERRM ) ;
          END;     
      END IF;   
          
   END IF;   

   /* ------------------------------------------------------------------------ */
   /* 변경 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF UPDATING THEN
       T_YMD        := TO_DATE(TO_CHAR(:NEW.YMD,'YYYYMM')||'01','YYYYMMDD');  --거래처잔고에 ymd 에 바인딩할 변수
       T_SU_AMT_OLD := NVL(:OLD.CASH_AMT,0) + NVL(:OLD.BILL_AMT,0);  
       T_SU_AMT_NEW := NVL(:NEW.CASH_AMT,0) + NVL(:NEW.BILL_AMT,0);  
    

      --거래처잔고에 반영        
      BEGIN
          UPDATE SALE0306
             SET SU_AMT   = NVL(SU_AMT,0) + (T_SU_AMT_NEW -  T_SU_AMT_OLD)  -- ( 변경금액 - 변경전금액)을 기존수금액에 더한다. 
           WHERE YMD        = T_YMD  
             AND CUST_ID    = :NEW.CUST_ID
             AND RCUST_ID   = :NEW.RCUST_ID
             AND SAWON_ID   = :NEW.SAWON_ID;

      EXCEPTION
             WHEN OTHERS THEN
                  RAISE_APPLICATION_ERROR( -20001, '수금 변경시 거래처잔고에 반영 Err:'||SQLERRM ) ;
      END;  
               
   END IF; 


   /* ------------------------------------------------------------------------ */
   /* 삭제가 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF DELETING THEN 
       T_YMD        := TO_DATE(TO_CHAR(:OLD.YMD,'YYYYMM')||'01','YYYYMMDD');  --거래처잔고에 ymd 에 바인딩할 변수
       T_SU_AMT_OLD := NVL(:OLD.CASH_AMT,0) + NVL(:OLD.BILL_AMT,0);   
 
      --통장잔액에 반영      
      BEGIN
          DELETE FROM SALE0409
                WHERE JUNPYO_NO   = :OLD.JUNPYO_NO
                  AND INPUT_SEQ   IS NULL;
      EXCEPTION
             WHEN OTHERS THEN
                  RAISE_APPLICATION_ERROR( -20001, '수금 삭제시 거래처잔고에 반영 Err:'||SQLERRM ) ;
      END;                      
              
      --거래처잔고에 반영
          BEGIN
              UPDATE SALE0306
                 SET SU_AMT   = NVL(SU_AMT,0) - T_SU_AMT_OLD --기존 수금액에서 삭제된 수금액을 뺀다. 
               WHERE YMD        = T_YMD --해당월1일 
                 AND CUST_ID    = :OLD.CUST_ID
                 AND RCUST_ID   = :OLD.RCUST_ID
                 AND SAWON_ID   = :OLD.SAWON_ID;

          EXCEPTION
                 WHEN OTHERS THEN
                      RAISE_APPLICATION_ERROR( -20001, '수금 삭제시 거래처잔고에 반영 Err:'||SQLERRM ) ;
          END;         
   
   END IF;
 

END TB_SALE0401_IUD;
/
