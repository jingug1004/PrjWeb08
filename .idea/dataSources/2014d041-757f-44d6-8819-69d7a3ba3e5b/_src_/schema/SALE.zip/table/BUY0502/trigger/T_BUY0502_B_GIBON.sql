CREATE TRIGGER T_BUY0502_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON BUY0502
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : BUY0502                                                      */
/*  테이블명 : 수입원장 Detail                                             */
/*  트리거명 : T_BUY0502_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2002.02.05(화)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 일자형, 코드 존재여부 확인                                  */
/*             2. 수입원장 Master 존재여부 확인                            */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(100) ;
   v_message    VARCHAR2(250) ;

   user_err     EXCEPTION     ;

   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'BUY0502 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'BUY0502 수정 불가 !! ' ;
   ELSE
      v_message := 'BUY0502 삭제 불가 !! ' ;
   END IF ;

   IF INSERTING OR UPDATING THEN
      v_curr_jakup := '수입원장Master(BUY0501) 존재여부 확인: ' ;

      SELECT COUNT(manage_no)
        INTO v_count
        FROM BUY0501
       WHERE manage_no = :NEW.manage_no
         AND ROWNUM < 3 ;

      IF v_count != 1 THEN
         v_curr_error := '해당 수입원장 관리번호가 존재하지 않음.=> '||:NEW.manage_no ;
         RAISE user_err ;
      END IF ;
   END IF ;

   IF INSERTING OR UPDATING('ymd') THEN
      v_curr_jakup := '일자 확인: ' ;
      IF F_CHECK_DATE('YMD', :NEW.ymd) = 'FALSE' THEN
         v_curr_error := '적요일자값 오류임.=> '||:NEW.ymd ;
         RAISE user_err ;
      END IF ;
   END IF ;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
