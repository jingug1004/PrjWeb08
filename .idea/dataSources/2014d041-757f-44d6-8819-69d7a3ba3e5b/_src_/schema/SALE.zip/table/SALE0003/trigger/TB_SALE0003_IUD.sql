CREATE TRIGGER TB_SALE0003_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0003
FOR EACH ROW
  DECLARE
        T_UPDATE_CHK   NUMBER;
        메시지         varchar2(1000) ;
        V_SFA_SALES_CODE_CNT NUMBER;
        V_CNT  NUMBER;
     
BEGIN
        /* 메시지 처리 준비 */
        IF INSERTING THEN
                메시지 := '거래처관리(SALE0003H) 추가 불가 !!  ' ;
        ELSIF UPDATING THEN
                메시지 := '거래처관리(SALE0003H) 수정 불가 !!  ' ;
        ELSE
                메시지 := '거래처관리(SALE0003H) 삭제 불가 !!  ' ;
        END IF ;

        /* ---------------------------------------------------------------------------- */
        /* 수정/삭제 되었을 경우                                                        */
        /* ---------------------------------------------------------------------------- */
        /* 잔고 통계테이블(SALE0409)에 존재하면 거래처코드를 수정/삭제 할 수 없도록     */
        /* 처리한다.                                                                    */
        /* ---------------------------------------------------------------------------- */
        IF DELETING THEN
        
               SELECT COUNT(*)
                 INTO T_UPDATE_CHK
                 FROM SALE0306
                WHERE CUST_ID  = :OLD.CUST_ID
                   OR RCUST_ID = :OLD.CUST_ID;
                IF T_UPDATE_CHK > 0 THEN
                   RAISE_APPLICATION_ERROR( -20001, '잔고 테이블에 해당거래처가 존재 함으로 삭제할 수 없습니다.') ;
                END IF;    
                                
        END IF;


        IF UPDATING AND :NEW.CUST_ID <> :OLD.CUST_ID THEN
               SELECT COUNT(*)
                 INTO T_UPDATE_CHK
                 FROM SALE0306
                WHERE CUST_ID  = :OLD.CUST_ID
                   OR RCUST_ID = :OLD.CUST_ID;
                IF T_UPDATE_CHK > 0 THEN
                        RAISE_APPLICATION_ERROR( -20001, '잔고 테이블에 해당거래처가 존재 함으로 수정할 수 없습니다.' ) ;
                END IF;
        END IF;

        /* ********************************************************************* */
        /* 수정될때                                                              */
        /* ********************************************************************* */
        IF UPDATING('UPTAE')            OR
          UPDATING('JONGMOK')          OR
          UPDATING('TEL')              OR
          UPDATING('HP')               OR
          UPDATING('FAX')              OR
          UPDATING('CUST_TYPE')        OR
          UPDATING('CUST_GB2')         OR
          UPDATING('EMAIL')            OR
          UPDATING('DAMDANG')          OR
          UPDATING('DAMDANG_LEVEL')    OR
          UPDATING('DANGA_BASE')       OR
          UPDATING('USE_YN')           OR
          UPDATING('USE_YMD')          OR
          UPDATING('USER_ID')          OR
          UPDATING('INPUT_YMD')        OR
          UPDATING('BIGO')             OR
          UPDATING('AREA')             OR
          UPDATING('CARD_ISSU_YN')     OR
          UPDATING('BUPIN_NO')         OR
          UPDATING('JUMIN_NO')         OR
          UPDATING('START_YMD')        OR
          UPDATING('SALE_BIGO')        OR
          UPDATING('CREDIT_LIMIT_AMT') OR
          UPDATING('ROOM_CNT')         OR
          UPDATING('YEONDAE')          OR
          UPDATING('GYEOYAK')          OR
          UPDATING('YEONDAE_2')        OR
          UPDATING('YEONDAE_3')        OR
          UPDATING('BUDONG_YN')        OR
          UPDATING('room_cnt')         OR
          UPDATING('email')            OR
          UPDATING('GPS_LAT')          OR
          UPDATING('GPS_LONG')         THEN
                BEGIN
                        UPDATE SALE0003H
                            set UPTAE            = :NEW.UPTAE,
                                JONGMOK          = :NEW.JONGMOK,
                                TEL              = :NEW.TEL,
                                HP               = :NEW.HP,
                                FAX              = :NEW.FAX,
                                CUST_TYPE        = :NEW.CUST_TYPE,
                                CUST_GB2         = :NEW.CUST_GB2,
                                ROOM_CNT         = :NEW.ROOM_CNT,
                                EMAIL            = :NEW.EMAIL,
                                DAMDANG          = :NEW.DAMDANG,
                                DAMDANG_LEVEL    = :NEW.DAMDANG_LEVEL,
                                DANGA_BASE       = :NEW.DANGA_BASE,
                                USE_YN           = :NEW.USE_YN,
                                USE_YMD          = :NEW.USE_YMD,
                                USER_ID          = :NEW.USER_ID,
                                INPUT_YMD        = sysdate,
                                BIGO             = :NEW.BIGO,
                                AREA             = :NEW.AREA,
                                CARD_ISSU_YN     = :NEW.CARD_ISSU_YN,
                                BUPIN_NO         = :NEW.BUPIN_NO,
                                JUMIN_NO         = :NEW.JUMIN_NO,
                                START_YMD        = :NEW.START_YMD,
                                SALE_BIGO        = :NEW.SALE_BIGO,
                                CREDIT_LIMIT_AMT = :NEW.CREDIT_LIMIT_AMT,
                                YEONDAE          = :NEW.YEONDAE,
                                GYEOYAK          = :NEW.GYEOYAK,
                                YEONDAE_2        = :NEW.YEONDAE_2,
                                YEONDAE_3        = :NEW.YEONDAE_3,
                                BUDONG_YN        = :NEW.BUDONG_YN,
                                GPS_LAT          = :NEW.GPS_LAT,
                                GPS_LONG         = :NEW.GPS_LONG                
                          WHERE CUST_ID     = :OLD.CUST_ID
                            AND TRAN_YMD_CD = :OLD.TRAN_YMD_CD ;
                EXCEPTION
                        WHEN OTHERS THEN     
                        raise_application_error( -20671, 메시지 || '거래처(SALE0003H) 수정시 ERROR 발생.' ) ;
                END ;     
           
        END IF ;

        /* ********************************************************************* */
        /* 추가/수정될때                                                         */
        /* ********************************************************************* */
        IF INSERTING            OR
          UPDATING('CUST_NM')  OR
          UPDATING('CUST_NM1') OR
          UPDATING('CUST_GB1') OR
          UPDATING('ZIP')      OR
          UPDATING('ADDR1')    OR
          UPDATING('ADDR2')    OR
          UPDATING('SAWON_ID') OR
          UPDATING('JUMUN_LIMIT') THEN
          -- ---------------------------------------------------------------------
          -- 내용 : 작업
          --        해당 데이타를 거래처등록이력(SALE0003H) 테이블에 등록한다.
          -- ---------------------------------------------------------------------
          -- 최종변경일자순번 칼럼의 값을 부여한다.
            :NEW.TRAN_YMD_CD := TO_CHAR(SYSDATE, 'YYYYMMDDHHMISS') ;
          
            -- 레코드를 추가한다.
                BEGIN
                        INSERT
                        INTO SALE0003H ( CUST_ID, TRAN_YMD_CD, TRAN_DATE, APPL_DATE, APPL_DATE1,
                                    CUST_NM, CUST_NM1, VOU_NO, 
                                    ZIP, ADDR1, ADDR2, 
                                    PRESIDENT, UPTAE, JONGMOK, 
                                    SAWON_ID, TEL, HP, 
                                    FAX, CUST_TYPE, CUST_GB1, 
                                    CUST_GB2, EMAIL, DAMDANG, 
                                    DAMDANG_LEVEL, DANGA_BASE, USE_YN, 
                                    USE_YMD, USER_ID, INPUT_YMD, 
                                    BIGO, AREA, CARD_ISSU_YN, 
                                    BUPIN_NO, START_YMD, SALE_BIGO, 
                                    CREDIT_LIMIT_AMT, ROOM_CNT, YEONDAE, 
                                    GYEOYAK, YEONDAE_2, YEONDAE_3, 
                                    BUDONG_YN, GPS_LAT, GPS_LONG, JUMUN_LIMIT )
                     VALUES( :NEW.CUST_ID, :NEW.TRAN_YMD_CD, TO_CHAR(SYSDATE, 'YYYYMMDD'), TO_CHAR(SYSDATE, 'YYYYMM')||'01', TO_CHAR(SYSDATE, 'YYYYMMDD'),
                             :NEW.CUST_NM, :NEW.CUST_NM1, :NEW.VOU_NO, 
                             :NEW.ZIP, :NEW.ADDR1, :NEW.ADDR2, 
                             :NEW.PRESIDENT, :NEW.UPTAE, :NEW.JONGMOK, 
                             :NEW.SAWON_ID, :NEW.TEL, :NEW.HP, 
                             :NEW.FAX, :NEW.CUST_TYPE, :NEW.CUST_GB1, 
                             :NEW.CUST_GB2, :NEW.EMAIL, :NEW.DAMDANG, 
                             :NEW.DAMDANG_LEVEL, :NEW.DANGA_BASE, :NEW.USE_YN, 
                             :NEW.USE_YMD, :NEW.USER_ID, sysdate, 
                             :NEW.BIGO, :NEW.AREA, :NEW.CARD_ISSU_YN, 
                             :NEW.BUPIN_NO, :NEW.START_YMD, :NEW.SALE_BIGO, 
                             :NEW.CREDIT_LIMIT_AMT, :NEW.ROOM_CNT, :NEW.YEONDAE, 
                             :NEW.GYEOYAK, :NEW.YEONDAE_2, :NEW.YEONDAE_3, 
                             :NEW.BUDONG_YN, :NEW.GPS_LAT, :NEW.GPS_LONG, :NEW.JUMUN_LIMIT ) ;
                EXCEPTION
                    -- 이미 존재하는 경우에는 에러를 발생시킨다.
                    WHEN DUP_VAL_ON_INDEX THEN
                         raise_application_error( -20671, 메시지 ||
                              '중복된 자료가 이미 존재하므로 추가가 불가능함 1.' ) ;
                END ;

                IF UPDATING('SAWON_ID') THEN
                 /* CHOE SET SAWON_ID 기본은 이것만
                    INPUT_USERID = :NEW.USER_ID  추가 
                    INPUT_DATE = :SYSDATE  추가
                 */ 

                        BEGIN
                                UPDATE SALE0405
                                      set SAWON_ID = :NEW.SAWON_ID,
                                           INPUT_USERID = :NEW.USER_ID,
                                           INPUT_DATE = SYSDATE
                                WHERE RCUST_ID = :OLD.CUST_ID ;
                        EXCEPTION
                                WHEN OTHERS THEN
                                raise_application_error( -20671, 메시지 || '매출처별단가등록(SALE0405) 수정시 ERROR 발생.' ) ;
                        END ;    
                END IF;
        END IF;
          
        
        IF INSERTING THEN
                --PDA에서 거래처에대해서 2개월간 서명이없을때 체크사항때문에 거래처코드등록에서
                --신규로 입력할 경우에 해당 테이블에 입력할 수 있도록 처리한다.  
                BEGIN
                        INSERT INTO SALE.SALE0402I ( YMD, CUST_ID, RCUST_ID, SAWON_ID, SIGN_YN, BIGO) 
                        VALUES (TO_CHAR(:NEW.START_YMD,'YYYYMMDD'), :NEW.CUST_ID, :NEW.CUST_ID, :NEW.SAWON_ID, 'Y', '신규거래처'  );      
                EXCEPTION
                -- 이미 존재하는 경우에는 에러를 발생시킨다.
                        WHEN DUP_VAL_ON_INDEX THEN
                                raise_application_error( -20671, 메시지 || '중복된 자료가 이미 존재하므로 추가가 불가능함 2' ) ;
                END;
        END IF;
        
       
        --IF INSERTING OR UPDATING THEN
        IF UPDATING THEN
                V_SFA_SALES_CODE_CNT := 0;
                BEGIN
                        SELECT COUNT(*)
                        INTO V_SFA_SALES_CODE_CNT 
                        FROM SFA_SALES_CODE
                        WHERE ERP_SALES_CODE = :OLD.CUST_ID ;
                EXCEPTION WHEN OTHERS THEN
                        raise_application_error( -20671, 'SFA거래처정보(SFA_SALES_CODE) 조회시 ERROR 발생.' ) ;
                END ;
                
                IF V_SFA_SALES_CODE_CNT > 0 THEN          
                        BEGIN
                             UPDATE SFA_SALES_CODE
                                   SET SFA_SALES_NO = :NEW.CUST_ID 
                                          ,ERP_SALES_CODE = :NEW.CUST_ID                          
                                          ,EMP_NO       = :NEW.SAWON_ID
                                          ,TRADE_NAME = :NEW.CUST_NM
                                          ,STATUS_NAME = :NEW.UPTAE 
                                          ,VITEM_NAME = :NEW.JONGMOK
                                          --,COMPANY_ADDR2  = :NEW.ADDR1  --CHOE 20130531 거래처등록의 주소 SYNC 컬럼 에서 기획실 지역배분주소로 변경
                                          --,BUNJI2 = :NEW.ADDR2                   --CHOE 20130531 거래처등록의 주소와 완전 별개임
                                          ,HP_NO = :NEW.HP
                                          ,TEL_NO = :NEW.TEL
                                          ,FAX_NO = :NEW.FAX
                                          ,PHARMACY_NO = :NEW.ROOM_CNT     
                                          --,GPS_NUM1 = :NEW.GPS_LAT   --CHOE 20121228 거래처등록의 위도경도 좌료 보다 SFA 좌료가 더 정확하다.     
                                          --,GPS_NUM2 = :NEW.GPS_LONG   
                                          ,MODIFY_DT = TO_CHAR(SYSDATE, 'YYYYMMDD')            
                                          ,MODIFY_WORKER = :NEW.USER_ID 
                                          ,CUST_STAT_GB = '01'
                              WHERE ERP_SALES_CODE = :OLD.CUST_ID ;
                        EXCEPTION WHEN OTHERS THEN
                                raise_application_error( -20671, 'SFA거래처정보(SFA_SALES_CODE) 수정시 ERROR 발생.' ) ;
                        END ;
                ELSIF V_SFA_SALES_CODE_CNT = 0 THEN
                        BEGIN
                             INSERT INTO SFA_SALES_CODE (SFA_SALES_SEQ  ,SFA_SALES_NO ,ERP_SALES_CODE, EMP_NO ,TRADE_NAME 
                                                                              ,TAX_NO ,MANAGER_NAME, STATUS_NAME ,VITEM_NAME ,ZIP_CODE 
                                                                              --,COMPANY_ADDR2, BUNJI2 ,HP_NO ,TEL_NO ,FAX_NO   -- CHOE 20130531  거래처등록의 주소 SYNC 컬럼 에서 기획실 지역배분주소로 변경
                                                                              ,HP_NO ,TEL_NO ,FAX_NO
                                                                              ,PHARMACY_NO ,GPS_NUM1 ,GPS_NUM2 ,INPUT_DT ,INPUT_WORKER 
                                                                              ,CUST_KIND ,CUST_STAT_GB )
                             SELECT ( SELECT MAX(SFA_SALES_SEQ) + 1 FROM SFA_SALES_CODE )
                                          ,:NEW.CUST_ID 
                                          ,:NEW.CUST_ID                             
                                          ,:NEW.SAWON_ID
                                          ,:NEW.CUST_NM   -- 5번째
                                          ,:NEW.VOU_NO  
                                          ,:NEW.PRESIDENT            
                                          ,:NEW.UPTAE 
                                          ,:NEW.JONGMOK
                                          ,SUBSTR(:NEW.ZIP ,1,3)||SUBSTR(:NEW.ZIP ,5,3)   --10번째    
                                          --,:NEW.ADDR1   --CHOE 20130531 거래처등록의 주소와 완전 별개임
                                          --,:NEW.ADDR2
                                          ,:NEW.HP
                                          ,:NEW.TEL
                                          ,:NEW.FAX      --15번째
                                          ,:NEW.ROOM_CNT     
                                          ,:NEW.GPS_LAT     
                                          ,:NEW.GPS_LONG   
                                          ,TO_CHAR(SYSDATE, 'YYYYMMDD')            
                                          ,:NEW.USER_ID 
                                          ,'18'
                                          ,'01'
                                FROM DUAL;                             
                        EXCEPTION WHEN OTHERS THEN
                                raise_application_error( -20671, 'SFA거래처정보(SFA_SALES_CODE) 신규시 ERROR 발생.'||:NEW.CUST_ID||' SQLCODE:' || TO_CHAR(SQLCODE) ) ;
                        END ;                     
                        --COMMIT;
                END IF;

        END IF;
        
        
        IF INSERTING THEN
                
                V_SFA_SALES_CODE_CNT := 0;
                BEGIN
                        SELECT COUNT(*)
                        INTO V_SFA_SALES_CODE_CNT 
                        FROM SFA_SALES_CODE
                        WHERE ERP_SALES_CODE = :NEW.CUST_ID ;
                EXCEPTION WHEN OTHERS THEN
                        raise_application_error( -20671, '고객정보테이블(sfa_com_customer) 조회시 ERROR 발생.' ) ;
                END ;
                
                IF V_SFA_SALES_CODE_CNT = 1 THEN 
                --대표고객을 고객테이블에 넣는다.
                        BEGIN

                            insert into sfa_com_customer
                            select 
                                    a.SFA_SALES_SEQ
                                    ,1                 -- ,a.SFA_CLIENT_NO
                                    ,''                -- ,a.CLIENT_GUBUN
                                    ,''                -- ,a.CLIENT_DEPT
                                    ,''                -- ,a.POSITION_NAME
                                    ,a.MANAGER_NAME      -- ,a.CLIENT_NAME
                                    ,''                -- ,a.MALE
                                    ,a.tel_no                -- ,a.TEL_NO
                                    ,''                -- ,a.HP_NO
                                    ,''                -- ,a.EMAIL
                                    ,''                -- ,a.BIRTHDAY
                                    ,''                -- a.BIRTHDAY_GUBUN
                                    ,''                -- a.ZIP_CODE
                                    ,''                -- a.DETAIL_ADDR1
                                    ,''                -- a.DETAIL_ADDR2
                                    ,''                -- a.MARRY_YN
                                    ,''                -- a.MARRY_DAY
                                    ,'N'                -- a.DEL_YN
                                    ,to_char(sysdate,'yyyymmdd')              -- a.MODIFY_DT
                                    ,'TRIGGER'                -- a.MODIFY_WORKER
                                    ,''                -- a.GITA
                                    ,'' --a.MAJORSUBJECT
                                    ,'' --a.LASTSCHOOL_NM
                                    ,'' --a.HOBBY
                                    ,'' --a.FRIENDHSIP
                               from sfa_sales_code a
                              where erp_sales_code = :NEW.CUST_ID; 
                        EXCEPTION WHEN OTHERS THEN
                                raise_application_error( -20671, '고객정보테이블(sfa_com_customer) 신규시 ERROR 발생.' ) ;
                        END ;
                        
                END IF;                       
               
                V_CNT := 0;
                SELECT COUNT(*)
                INTO V_CNT 
                FROM SFA_SALES_CODE_SAWON
                WHERE SFA_SALES_SEQ IN ( SELECT SFA_SALES_SEQ FROM SFA_SALES_CODE WHERE ERP_SALES_CODE = :OLD.CUST_ID )
                AND EMP_NO = :OLD.SAWON_ID 
                AND REQ_GB = '2'   --주문요청
                AND OK_STAT = '1'  --승인대기
                ;
                
                if V_CNT > 0 THEN
                       --거래처주문요청 테이블에 반영
                        BEGIN                  
                            UPDATE SFA_SALES_CODE_SAWON
                                  SET OK_STAT = '2'  --주문거래처 요청 승인 처리 : 방문활동, 주문, 수문에 사용하기 위해
                                        ,OK_DT = TO_CHAR(SYSDATE, 'YYYYMMDD')
                                        ,NO_REASON = :NEW.USER_ID||'의 TRIG 통한 승인요청'
                              WHERE SFA_SALES_SEQ IN ( SELECT SFA_SALES_SEQ FROM SFA_SALES_CODE WHERE ERP_SALES_CODE = :OLD.CUST_ID )
                                  AND EMP_NO = :OLD.SAWON_ID 
                                  AND REQ_GB = '2';
                        EXCEPTION 
                                WHEN NO_DATA_FOUND THEN
                                     T_UPDATE_CHK := 0;
                                WHEN OTHERS THEN
                                     raise_application_error( -20671, 메시지 || 'SFA거래처요청정보(SFA_SALES_CODE_SAWON) 에 반영시 ERROR 발생.' ) ;
                        END;  
                         
                END IF;
                
        END IF;
   

        /* ********************************************************************* */
        /* 삭제될 때                                                             */
        /* ********************************************************************* */
        IF DELETING THEN
        -- ---------------------------------------------------------------------
        -- 내용 : 작업
        --        거래처코드에 대응하는 모든 이력정보를 삭제한다.
        -- ---------------------------------------------------------------------
                BEGIN
                    DELETE SALE0003H
                    WHERE CUST_ID   = :OLD.CUST_ID ;
                END ;
                 
                --  거래처잔고확인서명관리 삭제 
                BEGIN
                   DELETE FROM SALE.SALE0402I
                    WHERE YMD      = TO_CHAR(:OLD.START_YMD,'YYYYMMDD')
                      AND CUST_ID  = :OLD.CUST_ID
                      AND RCUST_ID = :OLD.CUST_ID; 
                EXCEPTION
                        WHEN OTHERS THEN
                                raise_application_error( -20671, 메시지 || '거래처잔고확인서명관리 삭제시 오류발생' ) ;
                END;            
                                
        END IF;

END TB_SALE0003_IUD;
/
