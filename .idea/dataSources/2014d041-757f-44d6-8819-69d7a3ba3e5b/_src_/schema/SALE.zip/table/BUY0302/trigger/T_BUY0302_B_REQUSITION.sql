CREATE TRIGGER T_BUY0302_B_REQUSITION
BEFORE INSERT OR UPDATE OR DELETE
  ON BUY0302
FOR EACH ROW
  DECLARE
        
        V_MESSAGE VARCHAR2(255) := '작업불가';
        V_COUNT NUMBER;
    
        USER_ERR EXCEPTION;

BEGIN
        /* 메시지 처리 준비 */
        IF INSERTING THEN
                V_MESSAGE   := 'BUY0302 추가 불가 !! ' ;   
        ELSIF UPDATING THEN
                V_MESSAGE   := 'BUY0302 수정 불가 !! ' ;                
        ELSE
                V_MESSAGE   := 'BUY0302 삭제 불가 !! ' ;      
        END IF ;
        
     
        IF UPDATING('QTY') OR
            UPDATING('DANGA') OR
            UPDATING('CUST_ID') THEN
            
                V_MESSAGE := V_MESSAGE||' 수량/단가 변경' ;
                V_COUNT := 0;
                 
                SELECT COUNT(*)
                INTO V_COUNT
                FROM HANAGROUPWARE.GW_EA_REQUISITION A
                ,HANAGROUPWARE.GW_EA_APPROVAL_MASTER B
                WHERE A.APPROVAL_SEQ = B.APPROVAL_SEQ
                AND B.STATE IN ( 'E03002' , 'E02003')   --결재중 결재요청  
                AND A.REQ_NO = :NEW.REQ_NO 
                AND A.MATERIAL_ID = :NEW.MATERIAL_ID
                ;
                
                IF V_COUNT = 1 THEN
                        UPDATE HANAGROUPWARE.GW_EA_REQUISITION A SET A.QTY = :NEW.QTY
                        ,A.DANGA = :NEW.DANGA    
                        ,A.CUST_ID = :NEW.CUST_ID
                        ,A.CUST_NM = F_GET_NAME('INV0011' ,:NEW.CUST_ID ,'')    
                        WHERE A.APPROVAL_SEQ IN ( 
                                                                        SELECT APPROVAL_SEQ 
                                                                        FROM HANAGROUPWARE.GW_EA_APPROVAL_MASTER
                                                                        WHERE STATE IN ( 'E03002' , 'E02003')   --결재중 결재요청
                                                                     )  
                        AND A.REQ_NO = :NEW.REQ_NO 
                        AND A.MATERIAL_ID = :NEW.MATERIAL_ID  
                        ;
                END IF;
         
        END IF ;    
     
        EXCEPTION
                WHEN USER_ERR THEN
                        RAISE_APPLICATION_ERROR(-20001, SUBSTRB(V_MESSAGE,1,250));
                WHEN OTHERS THEN
                        RAISE_APPLICATION_ERROR(-20099, SUBSTRB(V_MESSAGE||SQLERRM,1,250));
END ;
/
