CREATE TRIGGER T_BUY0302_B_GIBON
BEFORE INSERT OR UPDATE OR DELETE
  ON BUY0302
FOR EACH ROW
  DECLARE
/* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
/* ************************************************************************ */
/*                                                                          */
/*  테 이 블 : BUY0302                                                      */
/*  테이블명 : 구매청구 Detail                                             */
/*  트리거명 : T_BUY0302_B_GIBON                                             */
/*                                                                          */
/*  Timing   : BEFORE                                                       */
/*  Event    : INSERT, UPDATE, DELETE                                       */
/*  Type     : ROW                                                          */
/*                                                                          */
/*  작성일자 : 2002.01.28(월)                                               */
/*  작 성 자 : 이 원 선                                                     */
/*                                                                          */
/*  작업내역 : 1. 일자형, 코드 존재여부 확인                                  */
/*             2. 구매청구 Master 존재여부 확인                            */
/* ************************************************************************ */
   v_count      NUMBER := 0 ;
   v_curr_jakup VARCHAR2(100) ;
   v_curr_error VARCHAR2(100) ;
   v_message    VARCHAR2(250) ;

   user_err     EXCEPTION     ;

   v_cd         VARCHAR2(20) ;
   v_nm         VARCHAR2(100) ;
   v_dummy      VARCHAR2(100) ;

BEGIN
   /* 메시지 처리 준비 */
   IF INSERTING THEN
      v_message := 'BUY0302 추가 불가 !! ' ;
   ELSIF UPDATING THEN
      v_message := 'BUY0302 수정 불가 !! ' ;
   ELSE
      v_message := 'BUY0302 삭제 불가 !! ' ;
   END IF ;

   IF INSERTING OR UPDATING THEN
      v_curr_jakup := '구매청구Master(BUY0301) 존재여부 확인: ' ;

      SELECT COUNT(req_no), NVL(MAX(LTRIM(RTRIM(jubsu_ymd))),' ')
        INTO v_count, v_nm
        FROM BUY0301
       WHERE req_no = :NEW.req_no
         AND ROWNUM < 3 ;

      IF v_count != 1 THEN
         v_curr_error := '해당 구매청구번호가 존재하지 않음.=> '||:NEW.req_no ;
         RAISE user_err ;
      END IF ;

      v_curr_jakup := '일자 확인: ' ;
      IF F_CHECK_DATE('YMD', :NEW.ipgo_ymd) = 'FALSE' THEN
         v_curr_error := '작업일자값 오류임.=> '||:NEW.ipgo_ymd ;
         RAISE user_err ;
      END IF ;
   END IF ;

   IF (UPDATING('req_no')      AND :NEW.req_no      != :OLD.req_no) OR
      (UPDATING('material_id') AND :NEW.material_id != :OLD.material_id) OR
      DELETING THEN
      v_curr_jakup := '구매발주Detail(BUY0402) 존재여부 확인: ' ;

      SELECT COUNT(balju_no), NVL(MAX(LTRIM(RTRIM(balju_no))),' ')
        INTO v_count, v_nm
        FROM BUY0402
       WHERE req_no      = :OLD.req_no
         AND material_id = :OLD.material_id
         AND ROWNUM      < 3 ;

      IF v_count > 0 THEN
         v_curr_error := '해당 구매청구에 대한 발주가 존재하여 작업이 불가함. 발주번호=> '||v_nm ;
         RAISE user_err ;
      END IF ;
   END IF ;

   EXCEPTION
      WHEN user_err THEN
         RAISE_APPLICATION_ERROR(-20001, SUBSTRB(v_message||v_curr_jakup||v_curr_error,1,250));
      WHEN OTHERS THEN
         RAISE_APPLICATION_ERROR(-20002, SUBSTRB(v_message||v_curr_jakup||v_curr_error||SQLERRM,1,250));
END;
/
