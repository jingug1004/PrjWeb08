CREATE TRIGGER TB_SALE0204_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0204
FOR EACH ROW
  DECLARE
     T_UPDATE_CHK   NUMBER;
     T_CUST_ID      SALE0203.CUST_ID%TYPE ;
     T_RCUST_ID     SALE0203.RCUST_ID%TYPE ;
BEGIN

   /* -------------------------------------------------------------------------*/
   /* 하나제약                                                                 */
   /* 주문서를 입력하면 세금계산서/거래명세서/통장명세를 자동발생하도록 한다.  */
   /* -------------------------------------------------------------------------*/

   /* ------------------------------------------------------------------------ */
   /* 신규입력일 경우                                                          */
   /* ------------------------------------------------------------------------ */
   IF INSERTING THEN
      /* 거래명세서 Detail 저장 */
      BEGIN

         INSERT INTO SALE0208 ( DEAL_NO              , INPUT_SEQ           , YMD                 , ITEM_ID        ,
                                QTY                  , DANGA               , AMT                 , VAT            ,
                                DC_AMT               , INPUT_YMD           , BIGO                , SALE_SEQ       ,
                                GUMAE_NO             , GUMAE_SEQ           , RATE                , DC_QTY)
                       VALUES ( :NEW.GUMAE_NO        , :NEW.INPUT_SEQ      , :NEW.YMD            , :NEW.ITEM_ID        ,
                                NVL(:NEW.QTY,0)      , NVL(:NEW.DANGA,0)   , NVL(:NEW.AMT,0)     , NVL(:NEW.VAT,0)     ,
                                NVL(:NEW.DC_AMT,0)   , SYSDATE             , :NEW.BIGO           , :NEW.SALE_SEQ     ,
                                :NEW.GUMAE_NO        , :NEW.INPUT_SEQ      , NVL(:NEW.RATE,0)    , NVL(:NEW.DC_QTY,0));
      EXCEPTION
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, '거래명세서 INS Err:'||SQLERRM ) ;
      END;

      /* 세금계산서 Detail 저장 */
      BEGIN
          INSERT INTO SALE0210 ( SALE_NO              , INPUT_SEQ           , YMD            ,
                                 ITEM_ID              , QTY                 , DANGA          ,
                                 AMT                  , VAT                 , RATE           ,
                                 DC_AMT               , BIGO                , DEAL_NO        ,
                                 DEAL_SEQ             , GUMAE_NO            , GUMAE_SEQ      )
                        VALUES ( :NEW.GUMAE_NO        , :NEW.INPUT_SEQ      , :NEW.YMD       ,
                                 :NEW.ITEM_ID         , NVL(:NEW.QTY,0)     , NVL(:NEW.DANGA,0)          ,
                                 NVL(:NEW.AMT,0)      , NVL(:NEW.VAT,0)     , NVL(:NEW.RATE,0)           ,
                                 NVL(:NEW.DC_AMT,0)   , :NEW.BIGO           , :NEW.GUMAE_NO       ,
                                 :NEW.INPUT_SEQ       , :NEW.GUMAE_NO       , :NEW.INPUT_SEQ );
      EXCEPTION
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, '세금계산서 INS Err:'||SQLERRM ) ;
      END;

      /* ---------------------------------------------------------- */
      /* 세금계산서 내용을 통장발행 Table에 저장한다                */
      /* GUBUN = '1' = '매출'                                       */
      /* 세금계산서 Master SALE0209가 먼저 저장 되어 있어야 한다.   */
      /* -----------------------------------------------------------*/
      T_UPDATE_CHK := 0;
      BEGIN
          SELECT COUNT(*)
            INTO T_UPDATE_CHK
            FROM SALE0409
           WHERE SALE_NO   = :NEW.GUMAE_NO
             AND INPUT_SEQ = :NEW.INPUT_SEQ;
      EXCEPTION
              WHEN NO_DATA_FOUND THEN
                   T_UPDATE_CHK := 0;
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR( -20001, '통장 명세서 조회 Err:'||SQLERRM ) ;

      END;

      IF  T_UPDATE_CHK = 0 THEN
          /* 거래명세서 Detail 저장 */
          BEGIN
                SELECT A.CUST_ID   CUST_ID,
                       A.RCUST_ID  RCUST_ID
                  INTO T_CUST_ID, T_RCUST_ID
                  FROM SALE0203 A
                 WHERE A.GUMAE_NO   = :NEW.GUMAE_NO;
          EXCEPTION
                WHEN NO_DATA_FOUND THEN
                     RAISE_APPLICATION_ERROR( -20001, '주문 마스터？저장되어 있지 않습니다.'||SQLERRM ) ;
                WHEN OTHERS THEN
                     RAISE_APPLICATION_ERROR( -20001, '주문 마스터 조회 Err:'||SQLERRM ) ;
          END;


          INSERT INTO SALE0409 (
                     ISSU_NO  ,CUST_ID  ,TRAN_YMD ,GUBUN    ,REMARK   ,
                     AMT      ,VAT      ,SUKUM_AMT,GON_NO   ,PAGE_NO  ,
                     LINE_NO  ,ISSU_DATE,SALE_NO  ,JUNPYO_NO,INPUT_SEQ,
                     ADD_SIGN ,RCUST_ID ,QTY)
                  (  SELECT ISSU_NO_SEQ.NEXTVAL,
                            CUST_ID,
                            TRAN_YMD,
                            GUBUN,
                            RPAD(SUBSTRB(ITEM_NM,1,17),17)||TO_CHAR(Qty,'999'),
                            AMT,
                            VAT,
                            0,
                            NULL,
                            NULL,
                            NULL,
                            NULL,
                            SALE_NO,
                            NULL,
                            INPUT_SEQ,
                            '+',
                            RCUST_ID,
                            QTY
                       FROM (SELECT C.CUST_ID                CUST_ID,
                                    C.RCUST_ID               RCUST_ID,
                                    TO_CHAR(A.YMD,'YYYYMMDD') TRAN_YMD,
                                    '1'                       GUBUN,
                                    B.ITEM_NM1                ITEM_NM,
                                    A.AMT                     AMT,
                                    A.VAT                     VAT,
                                    A.QTY                     QTY,
                                    A.SALE_NO                 SALE_NO,
                                    A.INPUT_SEQ               INPUT_SEQ
                               FROM SALE0210 A,
                                    SALE0004 B,
                                    SALE0209 C
                              WHERE A.SALE_NO   = :NEW.GUMAE_NO
                                AND A.INPUT_SEQ = :NEW.INPUT_SEQ
                                AND A.ITEM_ID   = B.ITEM_ID
                                AND A.SALE_NO   = C.SALE_NO));
          -- 거래처 코드와 매출처 코드가 틀리면 즉. 도매상을 통해 약국으로 납품되는 경우
          -- 거래처 코드로 통장을 발행 하고 매출처로도 통장을 발행한다.
          IF T_CUST_ID <> T_RCUST_ID THEN
              INSERT INTO SALE0409 (
                     ISSU_NO  ,CUST_ID  ,TRAN_YMD ,GUBUN    ,REMARK   ,
                     AMT      ,VAT      ,SUKUM_AMT,GON_NO   ,PAGE_NO  ,
                     LINE_NO  ,ISSU_DATE,SALE_NO  ,JUNPYO_NO,INPUT_SEQ,
                     ADD_SIGN ,RCUST_ID ,QTY)
                  (  SELECT ISSU_NO_SEQ.NEXTVAL,
                            CUST_ID,
                            TRAN_YMD,
                            GUBUN,
                            RPAD(SUBSTRB(ITEM_NM,1,17),17)||TO_CHAR(Qty,'999'),
                            AMT,
                            VAT,
                            0,
                            NULL,
                            NULL,
                            NULL,
                            NULL,
                            SALE_NO,
                            NULL,
                            INPUT_SEQ,
                            '+',
                            RCUST_ID,
                            QTY
                       FROM (SELECT C.CUST_ID                CUST_ID,
                                    C.CUST_ID                RCUST_ID,
                                    TO_CHAR(A.YMD,'YYYYMMDD') TRAN_YMD,
                                    '1'                       GUBUN,
                                    B.ITEM_NM1                ITEM_NM,
                                    A.AMT                     AMT,
                                    A.VAT                     VAT,
                                    A.QTY                     QTY,
                                    A.SALE_NO                 SALE_NO,
                                    A.INPUT_SEQ               INPUT_SEQ
                               FROM SALE0210 A,
                                    SALE0004 B,
                                    SALE0209 C
                              WHERE A.SALE_NO   = :NEW.GUMAE_NO
                                AND A.INPUT_SEQ = :NEW.INPUT_SEQ
                                AND A.ITEM_ID   = B.ITEM_ID
                                AND A.SALE_NO   = C.SALE_NO));
          END IF;

      ELSE
              UPDATE SALE0409 A SET
                     (REMARK, AMT, VAT, QTY)
                   = (SELECT RPAD(SUBSTRB(C.ITEM_NM1,1,17),17)||TO_CHAR(B.Qty,'999') REMARK,
                             B.AMT,
                             B.VAT,
                             b.QTY
                        FROM SALE0004 C,
                             SALE0210 B
                       WHERE B.SALE_NO   = :NEW.GUMAE_NO
                         AND B.INPUT_SEQ = :NEW.INPUT_SEQ
                         AND B.ITEM_ID   = C.ITEM_ID)
               WHERE A.SALE_NO   = :NEW.GUMAE_NO
                 AND A.INPUT_SEQ = :NEW.INPUT_SEQ;
      END IF;
   END IF;   --INSERT 완료

   /* ------------------------------------------------------------------------ */
   /* 수정이 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF UPDATING THEN
         --거래명세서 UPDATE
             UPDATE SALE0208 SET
                    ITEM_ID   = :NEW.ITEM_ID,
                    QTY       = NVL(:NEW.QTY,0),
                    DANGA     = NVL(:NEW.DANGA,0),
                    AMT       = NVL(:NEW.AMT,0),
                    VAT       = NVL(:NEW.VAT,0),
                    DC_AMT    = NVL(:NEW.DC_AMT,0),
                    SALE_SEQ      = :NEW.SALE_SEQ,
                    BIGO      = :NEW.BIGO,
                    RATE      = :NEW.RATE,
                    DC_QTY    = NVL(:NEW.DC_QTY,0)
              WHERE DEAL_NO   = :OLD.GUMAE_NO
                AND INPUT_SEQ = :OLD.INPUT_SEQ;

         --세금계산서 UPDATE
             UPDATE SALE0210 SET
                    ITEM_ID   = :NEW.ITEM_ID,
                    QTY       = NVL(:NEW.QTY,0),
                    DANGA     = NVL(:NEW.DANGA,0),
                    AMT       = NVL(:NEW.AMT,0),
                    VAT       = NVL(:NEW.VAT,0),
                    DC_AMT    = NVL(:NEW.DC_AMT,0),
                    BIGO      = :NEW.BIGO,
                    RATE      = :NEW.RATE
              WHERE SALE_NO   = :OLD.GUMAE_NO
                AND INPUT_SEQ = :OLD.INPUT_SEQ;


         --통장명세서 UPDATE
             UPDATE SALE0409 A SET
                    (REMARK, AMT, VAT, QTY)
                  = (SELECT RPAD(SUBSTRB(C.ITEM_NM1,1,17),17)||TO_CHAR(B.Qty,'999') REMARK,
                            B.AMT,
                            B.VAT,
                            B.QTY
                       FROM SALE0004 C,
                            SALE0210 B
                      WHERE B.SALE_NO   = :OLD.GUMAE_NO
                        AND B.INPUT_SEQ = :OLD.INPUT_SEQ
                        AND B.ITEM_ID   = C.ITEM_ID)
              WHERE A.SALE_NO   = :OLD.GUMAE_NO
                AND A.INPUT_SEQ = :OLD.INPUT_SEQ;

   END IF;


   /* ------------------------------------------------------------------------ */
   /* 삭제가 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF DELETING THEN

      DELETE FROM SALE0208
            WHERE DEAL_NO   = :OLD.GUMAE_NO
              AND INPUT_SEQ = :OLD.INPUT_SEQ;

      DELETE FROM SALE0210
            WHERE SALE_NO   = :OLD.GUMAE_NO
              AND INPUT_SEQ = :OLD.INPUT_SEQ;

      DELETE FROM SALE0409
            WHERE SALE_NO   = :OLD.GUMAE_NO
              AND INPUT_SEQ = :OLD.INPUT_SEQ;

   END IF;

END TB_SALE0204_IUD;
/
