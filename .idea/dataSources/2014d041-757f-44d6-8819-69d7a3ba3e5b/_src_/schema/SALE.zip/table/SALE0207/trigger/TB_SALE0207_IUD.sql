CREATE TRIGGER TB_SALE0207_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0207
FOR EACH ROW
  DECLARE  T_MSG VARCHAR2(100) ;
         T_YMD SALE0207.ymd%TYPE ;
         T_STORE_LOC SALE0207.store_loc%TYPE;
         T_CUST_ID SALE0207.cust_id%TYPE ;
         T_DEAL_NO SALE0208.deal_no%TYPE ;
         T_SAWON_ID SALE0207.sawon_id%TYPE ;
BEGIN
        

        /*---------------------------------------------------------------------
        삭제 작업
        
        CHOE 20160525 DISABLED 시
        w_sale01e09 dw_2 ue_delete 에서 detail 삭제 후 master 삭제 
        이유 : SALE0207의  DEAL_GB 거래구분 = 11 수취 거부 건을 찾아 내기 위해                
         // Update할 Datawindow를 정한다. KTA 20160421 삭제 트리거 시 DW_1 을 먼저 지우면 SALE0207 참조 오류 때문에 순서 변경함
        idw_upd[1] = dw_2
        idw_upd[2] = dw_1
        ---------------------------------------------------------------------*/
        IF DELETING THEN
                T_STORE_LOC := :OLD.store_loc;
                T_YMD := TO_DATE(TO_CHAR(:OLD.ymd ,'yyyy/mm')||'/01','yyyy/mm/dd');
                BEGIN
                        FOR c1 IN ( SELECT item_id, qty ,dc_qty , amt, vat
                        FROM SALE0208
                        WHERE deal_no = :OLD.deal_no
                        AND ymd     = :OLD.ymd )
                        LOOP
                                UPDATE SALE0305
                                SET chulgo_qty  = NVL(chulgo_qty,0) - NVL(c1.qty,0) - NVL(c1.dc_qty,0),
                                chulgo_qtyS = NVL(chulgo_qtyS,0) - DECODE(SIGN(NVL(c1.qty,0)), -1, 0, NVL(c1.qty,0)) - DECODE(SIGN(NVL(c1.dc_qty,0)), -1, 0, NVL(c1.dc_qty,0)),
                                chulgo_amt  = NVL(chulgo_amt,0) - NVL(c1.amt,0),
                                chulgo_vat  = NVL(chulgo_vat,0) - NVL(c1.vat,0)
                                WHERE store_loc  = T_STORE_LOC
                                AND item_id    = c1.item_id
                                AND ymd        = T_YMD;
                        END LOOP;
                END;
        END IF ;
END TB_SALE0207_IUD;
/
