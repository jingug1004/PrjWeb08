CREATE TRIGGER TB_SALE0209_IUD
BEFORE INSERT OR UPDATE OR DELETE
  ON SALE0209
FOR EACH ROW
  DECLARE  T_MSG        VARCHAR2(100) ;
         T_YMD        SALE0209.ymd%TYPE ;
         T_STORE_LOC  SALE0209.store_loc%TYPE ;
         T_CUST_ID    SALE0209.cust_id%TYPE ;
         T_RCUST_ID   SALE0209.rcust_id%TYPE ;
         T_SAWON_ID   SALE0209.sawon_id%TYPE ;

BEGIN
   /* ------------------------------------------------------------------------ */
   /* 삭제가 되었을 경우                                                       */
   /* ------------------------------------------------------------------------ */
   IF DELETING THEN
      T_SAWON_ID  := :OLD.sawon_id;
      T_CUST_ID   := :OLD.cust_id;
      T_RCUST_ID  := :OLD.rcust_id;
      T_STORE_LOC := :OLD.store_loc;
      T_YMD := TO_DATE(TO_CHAR(:OLD.ymd ,'yyyy/mm')||'/01','yyyy/mm/dd');

      BEGIN
        FOR c1 IN ( SELECT NVL(SUM(amt),0) amt ,
                           NVL(SUM(vat),0) vat
                      FROM SALE0210
                     WHERE sale_no = :OLD.sale_no
                       AND ymd     = :OLD.ymd )
        LOOP
          UPDATE SALE0306
             SET MISU_AMT   = NVL(MISU_AMT,0) - (c1.amt + c1.vat)
           WHERE YMD        = T_YMD
             AND CUST_ID    = T_CUST_ID
             AND RCUST_ID   = T_RCUST_ID
             AND SAWON_ID   = T_SAWON_ID;

           IF SQL%NOTFOUND THEN
               UPDATE SALE0306
                  SET MISU_AMT   = NVL(MISU_AMT,0) - (c1.amt + c1.vat)
                WHERE YMD        = T_YMD
                  AND CUST_ID    = T_CUST_ID
                  AND RCUST_ID   = T_RCUST_ID;

               IF SQL%NOTFOUND THEN
                  RAISE_APPLICATION_ERROR( -20001, 'SALE0306에서 정리 할 거래처를 찾지 못했습니다  T_YMD:'||T_YMD ||'/T_CUST_ID:'||T_CUST_ID||'/T_RCUST_ID:'||T_RCUST_ID) ;
               END IF ;
           END IF ;

        END LOOP;

--         if SQL%NOTFOUND then
--            raise_application_error( -20001,'DELETE ERROR' ) ;
--         end if ;
--         exception
--            when OTHERS then
--                 raise_application_error( -20001, sqlerrm ) ;
      END;
   END IF ;

END TB_SALE0209_IUD;
/
