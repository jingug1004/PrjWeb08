CREATE PROCEDURE      SP_Z_COLLECT_BLOB
   (in_JUNPYO_NO    IN VARCHAR2 DEFAULT NULL,
    in_SIGN_IMAGE   IN BLOB, 
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 카드수금-사인저장 
 호출프로그램 :  카드수금       
 수정기록 : 
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    

   ERROR_EXCEPTION     EXCEPTION;
   
   v_CNT  NUMBER;
BEGIN
  
insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_BLOB',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_JUNPYO_NO,sysdate,'in_JUNPYO_NO:'||in_JUNPYO_NO);
commit;


    v_CNT :=0;
    SELECT COUNT(*)
      INTO v_CNT
      FROM ORAGMP.SLCOLM
     WHERE colno = in_JUNPYO_NO;
    IF v_CNT = 0 THEN       
       out_CODE := 999;
       out_MSG := '수금마스터에수금내역없음';      
       RAISE ERROR_EXCEPTION;
    END IF;
    
    BEGIN
        UPDATE ORAGMP.SLCOLM
           SET signimage  = in_SIGN_IMAGE
         WHERE colno = in_JUNPYO_NO;
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '사인저장실패:'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
        RAISE ERROR_EXCEPTION;
    END;  
               
    out_CODE := 0;
    out_MSG := '수금 정상 처리 및 사인 이미지 처리 완료';


EXCEPTION
WHEN ERROR_EXCEPTION THEN 
   out_CODE := SQLCODE;
   out_MSG  := '사인장시 오류발생 : ' || (TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  := '사인장시 오류발생 : ' || (TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
