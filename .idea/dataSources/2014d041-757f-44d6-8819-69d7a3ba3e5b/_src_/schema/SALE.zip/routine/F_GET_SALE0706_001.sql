CREATE function      F_GET_SALE0706_001
        ( IN_YMD          VARCHAR2,  -- 주문일자
          IN_CUST_ID1     VARCHAR2,  -- 도매처
          IN_CUST_ID2     VARCHAR2,  -- 약국
          IN_ITEM_ID      VARCHAR2,  -- 품목코드
          IN_CALL_GB      VARCHAR2   -- 호출구분(1-3개월전수량,2-2개월전수량,3-1개월전수량,4-이달수량(오늘제외) 
        )
   RETURN NUMBER
AS
   user_err       exception   ;
   
   V_MONTH3AGO    VARCHAR2(6);
   V_MONTH2AGO    VARCHAR2(6);
   V_MONTH1AGO    VARCHAR2(6);
   V_MONTH_CUR    VARCHAR2(6);
   
   n_rtn_value    NUMBER;
   v_curr_error   VARCHAR2(250);
/*----------------------------------------------------------------
 개요  :도매출하사유서 화면에서 사용하기 위해 작성함 
        도매에서약국으로 주문된 기록을 영업관리부에서 수기로 입력하면  sale0706 에 쌓임
        이것을 사유서 화면에서 월별로 가져와서 보여줌 
        
 return값:주문수량 
 
   
 작성일:2014.08.13
 작성자:김태안 
----------------------------------------------------------------*/

BEGIN

    --주문일자로 3달전의 년월계산
    select to_char(add_months(to_date(in_ymd,'yyyymmdd'),-3),'yyyymm')  
          ,to_char(add_months(to_date(in_ymd,'yyyymmdd'),-2),'yyyymm')  
          ,to_char(add_months(to_date(in_ymd,'yyyymmdd'),-1),'yyyymm')  
          ,substr(in_ymd,1,6) 
      into V_MONTH3AGO,V_MONTH2AGO,V_MONTH1AGO,V_MONTH_CUR
      from dual;
      
    BEGIN
        if IN_CALL_GB = '1' then    --석달전수량          
           select qty into n_rtn_value from sale0706 where yyyymm = V_MONTH3AGO  and cust_id1 = IN_CUST_ID1 and cust_id2 = IN_CUST_ID2 and item_id = IN_ITEM_ID;  
        elsif IN_CALL_GB = '2' then --두달전수량      
           select qty into n_rtn_value from sale0706 where yyyymm = V_MONTH2AGO  and cust_id1 = IN_CUST_ID1 and cust_id2 = IN_CUST_ID2 and item_id = IN_ITEM_ID; 
        elsif IN_CALL_GB = '3' then --한달전수량      
           select qty into n_rtn_value from sale0706 where yyyymm = V_MONTH1AGO  and cust_id1 = IN_CUST_ID1 and cust_id2 = IN_CUST_ID2 and item_id = IN_ITEM_ID; 
        elsif IN_CALL_GB = '4' then ---석달평균      
           select round(sum(qty) / 3) into n_rtn_value from sale0706 where yyyymm between V_MONTH3AGO and V_MONTH1AGO  and cust_id1 = IN_CUST_ID1 and cust_id2 = IN_CUST_ID2 and item_id = IN_ITEM_ID;
        elsif IN_CALL_GB = '5' then --이달수량     
           
            SELECT SUM(MQTY)
              INTO n_rtn_value
              FROM (                                        
                    SELECT NVL(SUM(B.QTY),0) MQTY
                      FROM SALE0203 A, SALE0204 B
                     WHERE A.GUMAE_NO = B.GUMAE_NO
                       AND A.CUST_ID  = IN_CUST_ID1
                       AND A.RCUST_ID = IN_CUST_ID2                
                       AND A.YMD      >= TO_DATE(SUBSTR(IN_YMD,1,6)||'01')  
                       AND A.YMD      <= LAST_DAY(SUBSTR(IN_YMD,1,6)||'01')                                              
                       AND B.ITEM_ID   = IN_ITEM_ID
                   UNION ALL
                    SELECT NVL(SUM(B.QTY),0) MQTY
                      FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
                     WHERE A.GUMAE_NO = B.GUMAE_NO
                       AND A.CUST_ID  = IN_CUST_ID1
                       AND A.RCUST_ID = IN_CUST_ID2
                       AND A.YMD      >= TO_DATE(SUBSTR(IN_YMD,1,6)||'01')  
                       AND A.YMD      <= LAST_DAY(SUBSTR(IN_YMD,1,6)||'01')                                           
                       AND B.ITEM_ID   = IN_ITEM_ID
                       AND A.RECEIPT_GB = '1' 
                       AND A.WIBAN_ORDER_CONF_YN    <> '2'
                     );
                     
        elsif IN_CALL_GB = '6' then --전달수량   
          
            SELECT SUM(MQTY)
              INTO n_rtn_value
              FROM (                                        
                    SELECT NVL(SUM(B.QTY),0) MQTY
                      FROM SALE0203 A, SALE0204 B
                     WHERE A.GUMAE_NO = B.GUMAE_NO
                       AND A.CUST_ID  = IN_CUST_ID1
                       AND A.RCUST_ID = IN_CUST_ID2                
                       AND A.YMD      >= TO_DATE(SUBSTR(V_MONTH1AGO,1,6)||'01')  
                       AND A.YMD      <= LAST_DAY(SUBSTR(V_MONTH1AGO,1,6)||'01')                                              
                       AND B.ITEM_ID   = IN_ITEM_ID
                     );           
        
        
        end if;
    EXCEPTION WHEN OTHERS THEN
        n_rtn_value := null;
    END;    
        
    RETURN n_rtn_value;

EXCEPTION WHEN user_err THEN
          RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
          WHEN OTHERS THEN
          RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;

/
