CREATE PROCEDURE sale0306_load_temp2
--            ( O_MSG           OUT  VARCHAR2   -- 메시지
--)
IS
     T_UPDATE_CHK   NUMBER;
BEGIN

        for c1 in ( SELECT YMD,
                           CUST_ID,
                           RCUST_ID,
                           SAWON_ID,
                           SU_AMT,
                           MISU_AMT,
                           BEFORE_AMT
                      FROM sale0306_temp)  Loop


                    UPDATE SALE0306 SET
                           BEFORE_AMT = C1.before_amt
                     WHERE YMD      = C1.YMD
                       AND CUST_ID  = C1.CUST_ID
                       AND RCUST_ID = C1.RCUST_ID;

                    IF SQL%NOTFOUND THEN
                        INSERT INTO SALE0306
                                    (YMD,
                                     CUST_ID,
                                     RCUST_ID,
                                     SAWON_ID,
                                     SU_AMT,
                                     MISU_AMT,
                                     BEFORE_AMT)
                              VALUES
                                    (C1.YMD,
                                     C1.CUST_ID,
                                     C1.RCUST_ID,
                                     C1.SAWON_ID,
                                     C1.SU_AMT,
                                     C1.MISU_AMT,
                                     C1.BEFORE_AMT);

                    END IF;
        End Loop;
        COMMIT;
END  sale0306_load_temp2 ;


/
