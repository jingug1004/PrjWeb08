CREATE PROCEDURE      SP_Z_CUST_03_106
(
    in_SAWON_ID          IN  VARCHAR2,     -- 사용자 ID
    in_CLIENT_NM         IN  VARCHAR2,     -- 고객 명 코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   :  로그인 사번의 고객검색 
 호출프로그램  : customer.clientlist        
 수정사항    : CHOE 20160630 진료과코드 명 추가  
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼
                      
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_client_no          NUMBER;
    v_cust_no            NUMBER;
    
    v_insa_sawon_id      VARCHAR2(7);
    v_deptcode           VARCHAR2(4);
    v_query_deptcode         VARCHAR2(4);
    v_assgn_cd           VARCHAR2(5);
    v_adminloginyn      VARCHAR2(1);  -- admin 부서 로그인여부   
    
    SAWON_ID_NULL        EXCEPTION;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_STATUS_01',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_DEPT_CD,sysdate,'in_DEPT_CD:'||in_DEPT_CD||'/in_PART_CD '||in_PART_CD );
--commit;


    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
        RAISE SAWON_ID_NULL;
    END IF; 
                
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    select classdiv,deptcode into v_assgn_cd,v_deptcode from ORAGMP.CMEMPM  where empcode = in_SAWON_ID;
    
    v_query_deptcode := v_deptcode;              
    -- 조회부서:: 로그인 직책에따라 상위부서를 찾거나 본인부서를 찾는다.
    if v_assgn_cd in ('27010','27018','27023','27025','27026')  then   -- 본부장 ,부본부장, 총괄이사, 총괄지점장, 선임지점장       지점장,팀장, 임시팀장('27027','27030','27035') 은 1레벨위로 안가야 함   
       select deptcode 
         into v_query_deptcode 
         from ORAGMP.CMDEPTM 
        where useyn = 'Y' and level = 2 connect by deptcode = prior predeptcode start with plantcode = '1000' and deptcode = v_deptcode;
    end if;  
    
    if v_query_deptcode in ('0007','0004','0302','0114','0527') then 
       v_adminloginyn   := 'Y';
    else
       v_adminloginyn   := 'N';           
    end if;
    
    SELECT COUNT(*)
      INTO v_num            
      FROM SALE.SFA_HIRA_CUSTOMER a
          ,ORAGMP.CMHIRAM b
     WHERE b.plantcode = '1000' 
       AND a.hiracode  = b.hiracode 
       AND NVL(a.del_yn, 'N') = 'N' 
       AND a.client_name  LIKE  '%'||NVL(in_CLIENT_NM, '%')||'%'     
       AND a.hiracode  in ( SELECT hiracode
                              FROM (
                                    SELECT a.hiracode  --주문거래처 --활동거래처
                                      FROM ORAGMP.CMHIRAM a
                                     WHERE a.plantcode = '1000' 
                                       AND a.orderempcode  = in_SAWON_ID  or a.areaempcode    = in_SAWON_ID   
                                       AND v_assgn_cd = '27040' 
                                    UNION ALL
                                    SELECT a.hiracode  --주문거래처
                                      FROM ORAGMP.CMHIRAM a
                                     WHERE a.plantcode = '1000' 
                                       AND a.orderempcode in (select empcode from ORAGMP.CMEMPM where deptcode in (select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode))
                                        OR a.areaempcode  in (select empcode from ORAGMP.CMEMPM where deptcode in (select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode)) 
                                       AND v_assgn_cd <> '27040'
                                   )
                            WHERE v_adminloginyn = 'N' 
                            union all
                            SELECT hiracode
                              FROM (
                                    SELECT a.hiracode  --주문거래처 --활동거래처
                                      FROM ORAGMP.CMHIRAM a
                                     WHERE a.plantcode = '1000'  
                                   )
                            WHERE v_adminloginyn = 'Y'  
                          )
        AND rownum < 1001;  
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 고객이 존재하지 않습니다.';
    ELSIF (v_num >= 1000) THEN
        out_CODE := 1;
        out_MSG := '검색건수가 1000 건이 넘습니다.고객명을 2자이상 입력하십시오.';
    ELSE
        out_CODE := 0;
        out_MSG := '고객 검색 완료';    
     
        OPEN out_RESULT FOR 
        
            SELECT a.hiracode         AS out_SFA_SALES_SEQ
                  ,a.hiracode         AS out_CUST_CD
                  ,'['||F_SFA_CODE_NM('CUST_STAT_GB',decode(b.orderempcode,null,decode(b.areaempcode,null,'03','02'),'01'))||'-'||decode(b.orderempcode,null,decode(b.areaempcode,null,'',oragmp.fncommonnm('emp',b.areaempcode,'')),oragmp.fncommonnm('emp',b.orderempcode,''))||'] '||b.hiraname  AS out_CUST_NM
                  ,a.sfa_client_no    AS out_CLIENT_NO
                  ,a.client_name      AS out_CLIENT_NM
                  ,a.hp_no            AS out_HP_NO
                  ,a.birthday         AS out_BIRTHDAY
                  ,a.birthday_gubun   AS out_BIRTHDAY_GUBUN
                  ,oragmp.fncommonnm('comm','SL30',a.client_gubun)  AS out_CLIENT_GUBUNNM -- 고객구분명 
                  ,a.client_dept      AS out_CLIENT_DEPT --진료과목
                  ,oragmp.fncommonnm('comm','SL05',a.client_dept)   AS out_CLIENT_DEPTNM  -- 진료과명
              FROM SALE.SFA_HIRA_CUSTOMER a
                  ,ORAGMP.CMHIRAM b
             WHERE b.plantcode = '1000' 
               AND a.hiracode  = b.hiracode 
               AND NVL(a.del_yn, 'N') = 'N' 
               AND a.client_name  LIKE  '%'||NVL(in_CLIENT_NM, '%')||'%'     
               AND a.hiracode  in ( SELECT hiracode
                                      FROM (
                                            SELECT a.hiracode  --주문거래처 --활동거래처
                                              FROM ORAGMP.CMHIRAM a
                                             WHERE a.plantcode = '1000' 
                                               AND a.orderempcode  = in_SAWON_ID  or a.areaempcode    = in_SAWON_ID   
                                               AND v_assgn_cd = '27040' 
                                            UNION ALL
                                            SELECT a.hiracode  --주문거래처
                                              FROM ORAGMP.CMHIRAM a
                                             WHERE a.plantcode = '1000' 
                                               AND a.orderempcode in (select empcode from ORAGMP.CMEMPM where deptcode in (select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode))
                                                OR a.areaempcode  in (select empcode from ORAGMP.CMEMPM where deptcode in (select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode)) 
                                               AND v_assgn_cd <> '27040'
                                           )
                                    WHERE v_adminloginyn = 'N'
                                    union all
                                    SELECT hiracode
                                      FROM (
                                            SELECT a.hiracode  --주문거래처 --활동거래처
                                              FROM ORAGMP.CMHIRAM a
                                             WHERE a.plantcode = '1000'  
                                           )
                                    WHERE v_adminloginyn = 'Y'  
                                  )                                          
             ORDER BY out_CUST_NM,a.client_gubun
             ;
    END IF;
    
    
    
EXCEPTION   
WHEN SAWON_ID_NULL THEN
   out_CODE := 102;
   out_MSG := '사원ID가 누락되었습니다.';  
   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
