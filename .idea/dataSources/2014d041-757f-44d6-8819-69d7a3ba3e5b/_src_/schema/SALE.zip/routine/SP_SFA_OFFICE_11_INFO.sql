CREATE PROCEDURE      SP_SFA_OFFICE_11_INFO   
(   
    in_SAWON_ID         IN  VARCHAR2, --영업사번
    in_DOCNO              IN  VARCHAR2,  --결재문서
    in_DOCKNDNO        IN  VARCHAR2,  --결재문서종류  : 1차 기안서만 : 000022
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
        V_NUM                                         NUMBER; 
        V_SALE0007_INSA_SAWON_ID       VARCHAR2(10); 
        V_TCMUSR_UNO                           VARCHAR2(10); 
        
        SAWON_ID_NULL                          EXCEPTION;
        DOCNO_NULL                               EXCEPTION;
        DOCKNDNO_NULL                         EXCEPTION;
        ERROR_EXCEPTION                      EXCEPTION;
         /*---------------------------------------------------------------------------
        프로그램명   : office.Decision : 결재승인 문서내용  : SALE.SP_SFA_OFFICE_11_INFO
        호출프로그램 :       
        ---------------------------------------------------------------------------*/    
    
BEGIN

        /*  0. PARAMETER 확인        */
        IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
                RAISE SAWON_ID_NULL;
        END IF;
    
        IF in_DOCNO IS NULL OR TRIM(in_DOCNO) = '' THEN
                RAISE DOCNO_NULL;
        END IF;
        
        IF in_DOCKNDNO IS NULL OR TRIM(in_DOCKNDNO) = '' THEN
                RAISE DOCKNDNO_NULL;
        END IF;  
        
        
        V_SALE0007_INSA_SAWON_ID := '';     
        V_TCMUSR_UNO := '';   
        /* 1-1. 영업사원번호  -> 인사사원번호 변경 */
        BEGIN
                SELECT INSA_SAWON_ID
                INTO V_SALE0007_INSA_SAWON_ID 
                FROM SALE.SALE0007 
                WHERE SAWON_ID = in_SAWON_ID;
        EXCEPTION WHEN OTHERS THEN
                out_CODE := 1;
                out_MSG := '<인사사원번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END;
        
        IF V_SALE0007_INSA_SAWON_ID = '' THEN
                out_CODE := 1;
                out_MSG := '<인사사원번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END IF;
              
          
        /* 1-2. 인사사원번호 -> 그룹웨어 UNO 변경 */
        BEGIN                
                SELECT UNO 
                INTO V_TCMUSR_UNO 
                FROM HANAGW.TCMUSR 
                WHERE LOIN_USID = V_SALE0007_INSA_SAWON_ID;                
        EXCEPTION WHEN OTHERS THEN
                out_CODE := 1;
                out_MSG := '<그룹웨어번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END;   
        
        IF V_TCMUSR_UNO = '' THEN
                out_CODE := 1;
                out_MSG := '<인사사원번호 조회 err 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END IF;         

        /*2. 해당 자료 확인 */
        BEGIN
                /* 차량사고보고서  20121211 22건 */
                IF in_DOCKNDNO = '000017' THEN
                        SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWCARACDT                         
                        WHERE TGWCARACDT.DOCNO = in_DOCNO;
                        
                /* 거래처사고보고서  20121211 44건  */
                ELSIF in_DOCKNDNO = '000018' THEN
                        SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWCUSTACDT                          
                        WHERE TGWCUSTACDT.DOCNO = in_DOCNO;
                        
                 /* IT SERVICE BOARD  20121211 11건 */
                ELSIF in_DOCKNDNO = '000019' THEN
                        SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWITBOARD                          
                        WHERE TGWITBOARD.DOCNO = in_DOCNO;
                        
                 /* 구매신청서  20121211  6225건  GRID*/
                ELSIF in_DOCKNDNO = '000020' THEN
                        SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWPCHRQST                          
                        WHERE TGWPCHRQST.DOCNO = in_DOCNO;

                /* 기안서  20121211  4633건 */
                ELSIF in_DOCKNDNO = '000022' OR in_DOCKNDNO = '000032' THEN
                        SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWPRE                          
                        WHERE TGWPRE.DOCNO = in_DOCNO;
                        
                /* 샘플신청서  20121211 1099건  GRID */
                ELSIF in_DOCKNDNO = '000023' THEN
                        SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWSAMRQST                          
                        WHERE TGWSAMRQST.DOCNO = in_DOCNO;
                                
                /* 증명발급신청서  20121211 290건  */
                ELSIF in_DOCKNDNO = '000024' THEN
                       SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWCRTFRQST                          
                        WHERE TGWCRTFRQST.DOCNO = in_DOCNO;

                /* 시간외근무신청서  20121211  12134건  GRID*/
                ELSIF in_DOCKNDNO = '000025' THEN
                       SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWOVERTIME                          
                        WHERE TGWOVERTIME.DOCNO = in_DOCNO;

                /* 휴가신청서  20121211  1844건  */
                ELSIF in_DOCKNDNO = '000026' THEN
                        SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWREST                          
                        WHERE TGWREST.DOCNO = in_DOCNO;

                /* 교육훈련세미나참가신청서  20121211  318건  */
                ELSIF in_DOCKNDNO = '000027' THEN
                        SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWJOIN                         
                        WHERE TGWJOIN.DOCNO = in_DOCNO;

                /* 근태계(지각조퇴결근) 20121211  624건  */
                ELSIF in_DOCKNDNO = '000029' THEN
                        SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWLBR                          
                        WHERE TGWLBR.DOCNO = in_DOCNO;

                /* 사내통신 20121211  1177건  */
                ELSIF in_DOCKNDNO = '000030' OR in_DOCKNDNO = '000031' THEN
                        SELECT count(*)
                           INTO V_NUM
                          FROM HANAGW.TGWCOMM                          
                        WHERE TGWCOMM.DOCNO = in_DOCNO;
                END IF;       
        EXCEPTION WHEN OTHERS THEN
                out_CODE := 1;
                out_MSG := '<결재문서를 조회 중에 err가 발생 되었습니다. 관련부서에 문의 하세요.>'; 
                RAISE ERROR_EXCEPTION;
        END;  
       
       
    out_COUNT := V_NUM;
    DBMS_OUTPUT.put_line('out_COUNT:'||to_char(out_COUNT));
    
        IF (V_NUM = 0) THEN
            out_CODE := 1;
            out_MSG := '조회할 결재문서가  없습니다.';
        ELSIF (V_NUM >= 1) THEN
            out_CODE := 0;
            out_MSG := '조회할 결재문서 확인완료'; 
                                    
              
                 /* 차량사고보고서  20121211 22건 */
                IF in_DOCKNDNO = '000017' THEN
                        out_CODE := 1;
                        out_MSG := '차량사고보고서는 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWCARACDT                         
                        WHERE TGWCARACDT.DOCNO = in_DOCNO;*/
                        
                /* 거래처사고보고서  20121211 44건  */
                ELSIF in_DOCKNDNO = '000018' THEN
                        out_CODE := 1;
                        out_MSG := '거래처사고보고서는 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWCUSTACDT                          
                        WHERE TGWCUSTACDT.DOCNO = in_DOCNO;*/
                        
                 /* IT SERVICE BOARD  20121211 11건 */
                ELSIF in_DOCKNDNO = '000019' THEN
                         out_CODE := 1;
                        out_MSG := 'IT SERVICE BORAD 는 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWITBOARD                          
                        WHERE TGWITBOARD.DOCNO = in_DOCNO;*/
                        
                 /* 구매신청서  20121211  6225건  GRID*/
                ELSIF in_DOCKNDNO = '000020' THEN
                        out_CODE := 1;
                        out_MSG := '구매신청서는 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWPCHRQST                          
                        WHERE TGWPCHRQST.DOCNO = in_DOCNO;*/

                /* 기안서  20121211  4633건 */
                ELSIF in_DOCKNDNO = '000022' OR in_DOCKNDNO = '000032' THEN
                        OPEN out_RESULT FOR   
                        SELECT TO_CHAR(TGWPRE.START_DTM, 'YYYY-MM-DD')  AS out_INFO_DATA1  --기안서 시행일
                              ,TO_CHAR(TGWPRE.DRW_DTM, 'YYYY-MM-DD') AS out_INFO_DATA2  --기안서 개시일
                              ,TGWPRE.PRE_MAN AS out_INFO_DATA3 --문서기안
                              ,TGWPRE.SEND_DIV AS out_INFO_DATA4 --발신부서
                              ,TGWPRE.CTRL AS out_INFO_DATA5 --통제부서
                              ,TGWPRE.CORPER AS out_INFO_DATA6 --협조부서 
                              ,TGWPRE.TITL AS out_INFO_DATA7  --제목
                              ,TGWPRE.CONT AS out_INFO_DATA8  --내용
                              ,'' AS out_INFO_DATA9  --공백
                              ,'' AS out_INFO_DATA10  --공백
                        FROM HANAGW.TGWPRE                          
                     WHERE TGWPRE.DOCNO = in_DOCNO;    
                        
                /* 샘플신청서  20121211 1099건  GRID */
                ELSIF in_DOCKNDNO = '000023' THEN
                        out_CODE := 1;
                        out_MSG := '샘플신청서는 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWSAMRQST                          
                        WHERE TGWSAMRQST.DOCNO = in_DOCNO;*/
                                
                /* 증명발급신청서  20121211 290건  */
                ELSIF in_DOCKNDNO = '000024' THEN
                        out_CODE := 1;
                        out_MSG := '증명발급신청서는 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWCRTFRQST                          
                        WHERE TGWCRTFRQST.DOCNO = in_DOCNO;*/

                /* 시간외근무신청서  20121211  12134건  GRID*/
                ELSIF in_DOCKNDNO = '000025' THEN
                        out_CODE := 1;
                        out_MSG := '시간외근무신청서는 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWOVERTIME                          
                        WHERE TGWOVERTIME.DOCNO = in_DOCNO;*/

                /* 휴가신청서  20121211  1844건  */
                ELSIF in_DOCKNDNO = '000026' THEN
                        out_CODE := 1;
                        out_MSG := '휴가신청서는 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWREST                          
                        WHERE TGWREST.DOCNO = in_DOCNO;*/

                /* 교육훈련세미나참가신청서  20121211  318건  */
                ELSIF in_DOCKNDNO = '000027' THEN
                        out_CODE := 1;
                        out_MSG := '교육훈련세미나신청서는 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWJOIN                         
                        WHERE TGWJOIN.DOCNO = in_DOCNO;*/

                /* 근태계(지각조퇴결근) 20121211  624건  */
                ELSIF in_DOCKNDNO = '000029' THEN
                        out_CODE := 1;
                        out_MSG := '근태계는 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWLBR                          
                        WHERE TGWLBR.DOCNO = in_DOCNO;*/

                /* 사내통신 20121211  1177건  */
                ELSIF in_DOCKNDNO = '000030' OR in_DOCKNDNO = '000031' THEN
                        out_CODE := 1;
                        out_MSG := '사내통신은 준비 중입니다.';
                        /*SELECT *
                          FROM HANAGW.TGWCOMM                          
                        WHERE TGWCOMM.DOCNO = in_DOCNO;*/
                END IF;                    
             
        END IF;
         
EXCEPTION
WHEN SAWON_ID_NULL THEN
        out_CODE := 101;
        out_MSG  := '사원코드가 누락되었습니다.';
WHEN DOCNO_NULL THEN
        out_CODE := 101;
        out_MSG  := '조회기간이 잘못되었습니다.';
WHEN DOCKNDNO_NULL THEN
        out_CODE := 101;
        out_MSG  := '조회기간이 잘못되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
