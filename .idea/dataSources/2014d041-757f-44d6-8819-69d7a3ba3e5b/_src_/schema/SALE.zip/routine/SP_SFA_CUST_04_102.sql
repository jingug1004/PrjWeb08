CREATE PROCEDURE      SP_SFA_CUST_04_102
(
    in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3)
    in_SFA_SALES_SEQ     IN  NUMBER,       -- 거래처 코드
    in_CLIENT_NO         IN  NUMBER,       -- 고객 코드
    in_CLIENT_GUBUN      IN  VARCHAR2,     -- 고객 구분(1:대표, 2:의사, 3:약사, 4:사무장, 5:일반)
    in_CLIENT_DEPT       IN  VARCHAR2,     -- 전문과
    in_CLIENT_JIKWI      IN  VARCHAR2,     -- 직위코드
    in_CLIENT_NM         IN  VARCHAR2,     -- 고객명
    in_MALE              IN  VARCHAR2,     -- 성별 (1:남, 2:여)
    in_TEL_NO            IN  VARCHAR2,     -- 전화번호
    in_HP_NO             IN  VARCHAR2,     -- 핸드폰번호
    in_EMAIL             IN  VARCHAR2,     -- E-MAIL
    in_BIRTHDAY          IN  VARCHAR2,     -- 생일
    in_BIRTHDAY_GUBUN    IN  VARCHAR2,     -- 생일구분 (1:음력, 2:양력)
    in_ZIP_CODE          IN  VARCHAR2,     -- 우편번호
    in_DETAIL_ADDR1      IN  VARCHAR2,     -- 상세주소1
    in_DETAIL_ADDR2      IN  VARCHAR2,     -- 상세주소2
    in_MARRY_YN          IN  VARCHAR2,     -- 결혼유무 (Y:결혼, N:미혼)
    in_MARRY_DAY         IN  VARCHAR2,     -- 결혼일
    in_INPUT_DT          IN  VARCHAR2,     -- 입력일
    in_INPUT_SAWON       IN  VARCHAR2,     -- 입력자 사번
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    v_client_no          NUMBER;
    v_main_client        NUMBER;
    v_self_cust          NUMBER;
    
    v_cust_cd            VARCHAR2(10);
    CUST_CD_NULL         EXCEPTION;

BEGIN
 /*---------------------------------------------------------------------------
 프로그램명   : 고객 상세
 호출프로그램 : 103버전으로 대체 삭제할것.       
 ---------------------------------------------------------------------------*/    

 

insert into SFA_SP_CALLED_HIST
values ('SP_SFA_CUST_04_102','1',sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN||'/in_CLIENT_DEPT:'||in_CLIENT_DEPT||'/in_CLIENT_JIKWI:'||in_CLIENT_JIKWI);
COMMIT;

    IF in_SFA_SALES_SEQ IS NULL OR in_SFA_SALES_SEQ = 0 THEN
        RAISE CUST_CD_NULL;
    END IF;

    IF in_BTN_GUBUN = 0 THEN   -- 조회처리 
    
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_COM_CUSTOMER
         WHERE SFA_SALES_SEQ  = in_SFA_SALES_SEQ;
        IF (v_num = 0) THEN
            out_CODE := 11;
            out_MSG  := '고객 정보가 존재하지 않습니다';
        ELSIF (v_num >= 1) THEN
            out_COUNT := v_num;
            out_CODE  := 0;
            out_MSG   := '고객 정보 확인완료';

            OPEN out_RESULT FOR
            SELECT ( SELECT SFA_SALES_NO FROM SFA_SALES_CODE A WHERE  A.SFA_SALES_SEQ = B.SFA_SALES_SEQ ) AS out_CUST_CD
                 , ( SELECT TRADE_NAME   FROM SFA_SALES_CODE A WHERE  A.SFA_SALES_SEQ = B.SFA_SALES_SEQ ) AS out_CUST_NM    
                 , SFA_CLIENT_NO      AS out_CLIENT_NO
                 , CLIENT_GUBUN       AS out_CLIENT_GUBUN
                 , CLIENT_DEPT        AS out_CLIENT_DEPT
                 , CLIENT_NAME        AS out_CLIENT_NM
                 , MALE               AS out_MALE
                 , TEL_NO             AS out_TEL_NO
                 , HP_NO              AS out_HP_NO
                 , EMAIL              AS out_EMAIL
                 , BIRTHDAY           AS out_BIRTHDAY
                 , BIRTHDAY_GUBUN     AS out_BIRTHDAY_GUBUN
                 , ZIP_CODE           AS out_ZIP_CODE
                 , DETAIL_ADDR1       AS out_DETAIL_ADDR1
                 , DETAIL_ADDR2       AS out_DETAIL_ADDR2
                 , MARRY_YN           AS out_MARRY_YN
                 , MARRY_DAY          AS out_MARRY_DAY
                 , MODIFY_DT          AS out_INPUT_DT
                 , MODIFY_WORKER      AS out_INPUT_SAWON
                 , DECODE(SFA_CLIENT_NO, '1', 'Y', 'N') AS out_MAIN_YN  -- 대표고객여부 
                 , DECODE(SFA_CLIENT_NO, '1',  '대표고객', '고객') AS out_MAIN_NM 
                FROM SFA_COM_CUSTOMER B
             WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
               AND DEL_YN = 'N';
        END IF;
    END IF;     
    
    
    IF in_BTN_GUBUN = 1 THEN -- 등록버튼 클릭한 경우
    
        IF in_SFA_SALES_SEQ IS NULL OR in_SFA_SALES_SEQ = 0 THEN
            RAISE CUST_CD_NULL;
        END IF;
        
        -- 고객번호 MAX 생성. 무조건 MAX 생성
        SELECT NVL(MAX(SFA_CLIENT_NO),0)+1
          INTO v_client_no
          FROM SFA_COM_CUSTOMER
         ; 
                    
        INSERT INTO SFA_COM_CUSTOMER ( SFA_SALES_SEQ, SFA_CLIENT_NO , CLIENT_GUBUN, CLIENT_DEPT , POSITION_NAME,
                                       CLIENT_NAME  , MALE          , TEL_NO      , HP_NO       , EMAIL,
                                       BIRTHDAY     , BIRTHDAY_GUBUN, ZIP_CODE    , DETAIL_ADDR1, DETAIL_ADDR2,
                                       MARRY_YN     , MARRY_DAY     , DEL_YN      , MODIFY_DT   , MODIFY_WORKER  , GITA    )
              VALUES(in_SFA_SALES_SEQ, v_client_no      , in_CLIENT_GUBUN , in_CLIENT_DEPT ,in_CLIENT_JIKWI,
                     in_CLIENT_NM    , in_MALE          , in_TEL_NO       , in_HP_NO                    , in_EMAIL,
                     in_BIRTHDAY     , in_BIRTHDAY_GUBUN, in_ZIP_CODE     , in_DETAIL_ADDR1             , in_DETAIL_ADDR2,
                     in_MARRY_YN     , in_MARRY_DAY     , 'N'             , TO_CHAR(SYSDATE, 'YYYYMMDD'), in_INPUT_SAWON ,'신규');
                         
        OPEN out_RESULT FOR
        SELECT ( SELECT SFA_SALES_NO FROM SFA_SALES_CODE A WHERE  A.SFA_SALES_SEQ = B.SFA_SALES_SEQ ) AS out_CUST_CD
             , ( SELECT TRADE_NAME   FROM SFA_SALES_CODE A WHERE  A.SFA_SALES_SEQ = B.SFA_SALES_SEQ ) AS out_CUST_NM
             , SFA_CLIENT_NO      AS out_CLIENT_NO
             , CLIENT_GUBUN       AS out_CLIENT_GUBUN
             , CLIENT_DEPT        AS out_CLIENT_DEPT
             , CLIENT_NAME        AS out_CLIENT_NM
             , MALE               AS out_MALE
             , TEL_NO             AS out_TEL_NO
             , HP_NO              AS out_HP_NO
             , EMAIL              AS out_EMAIL
             , BIRTHDAY           AS out_BIRTHDAY
             , BIRTHDAY_GUBUN     AS out_BIRTHDAY_GUBUN
             , ZIP_CODE           AS out_ZIP_CODE
             , DETAIL_ADDR1       AS out_DETAIL_ADDR1
             , DETAIL_ADDR2       AS out_DETAIL_ADDR2
             , MARRY_YN           AS out_MARRY_YN
             , MARRY_DAY          AS out_MARRY_DAY
             , MODIFY_DT          AS out_INPUT_DT
             , MODIFY_WORKER      AS out_INPUT_SAWON
             , DECODE(SFA_CLIENT_NO, '1', 'Y', 'N') AS out_MAIN_YN  -- 대표고객여부 
             , DECODE(SFA_CLIENT_NO, '1',  '대표고객', '고객') AS out_MAIN_NM
            FROM SFA_COM_CUSTOMER B
         WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
           AND SFA_CLIENT_NO = v_client_no
               AND DEL_YN = 'N';

        out_COUNT := 111;
        out_CODE  := 0;
        out_MSG   := '고객 등록이 완료되었습니다';  
        
    END IF;
    
    IF in_BTN_GUBUN = 2 THEN -- 수정버튼 클릭한 경우
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_COM_CUSTOMER
         WHERE SFA_SALES_SEQ  = in_SFA_SALES_SEQ  
           AND SFA_CLIENT_NO  = in_CLIENT_NO;
        IF v_num < 1 THEN
            out_COUNT := v_num;
            out_CODE  := 1;
            out_MSG   := '기존 등록된 고객이 없습니다';
        ELSE
            UPDATE SFA_COM_CUSTOMER
               SET CLIENT_GUBUN      = in_CLIENT_GUBUN
                 , POSITION_NAME     = in_CLIENT_DEPT
                 , CLIENT_DEPT       = in_CLIENT_JIKWI
                 , CLIENT_NAME       = in_CLIENT_NM
                 , TEL_NO            = in_TEL_NO
                 , HP_NO             = in_HP_NO
                 , EMAIL             = in_EMAIL
                 , BIRTHDAY          = in_BIRTHDAY
                 , BIRTHDAY_GUBUN    = in_BIRTHDAY_GUBUN
                 , ZIP_CODE          = in_ZIP_CODE
                 , DETAIL_ADDR1      = in_DETAIL_ADDR1
                 , DETAIL_ADDR2      = in_DETAIL_ADDR2
                 , MARRY_YN          = in_MARRY_YN
                 , MARRY_DAY         = in_MARRY_DAY
                 , MODIFY_DT         = TO_CHAR(SYSDATE, 'YYYYMMDD')
                 , MODIFY_WORKER     = in_INPUT_SAWON
                 , MALE              = in_MALE
                 , GITA              = '수정'
             WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
               AND SFA_CLIENT_NO = in_CLIENT_NO
               AND DEL_YN = 'N';

            COMMIT;

            OPEN out_RESULT FOR
            SELECT (SELECT SFA_SALES_NO FROM SFA_SALES_CODE A WHERE  A.SFA_SALES_SEQ = B.SFA_SALES_SEQ ) AS out_CUST_CD
                 , (SELECT TRADE_NAME   FROM SFA_SALES_CODE A WHERE  A.SFA_SALES_SEQ = B.SFA_SALES_SEQ ) AS out_CUST_NM    
                 , SFA_CLIENT_NO      AS out_CLIENT_NO
                 , CLIENT_GUBUN       AS out_CLIENT_GUBUN
                 , CLIENT_DEPT        AS out_CLIENT_DEPT
                 , CLIENT_NAME        AS out_CLIENT_NM
                 , MALE               AS out_MALE
                 , TEL_NO             AS out_TEL_NO
                 , HP_NO              AS out_HP_NO
                 , EMAIL              AS out_EMAIL
                 , BIRTHDAY           AS out_BIRTHDAY
                 , BIRTHDAY_GUBUN     AS out_BIRTHDAY_GUBUN
                 , ZIP_CODE           AS out_ZIP_CODE
                 , DETAIL_ADDR1       AS out_DETAIL_ADDR1
                 , DETAIL_ADDR2       AS out_DETAIL_ADDR2
                 , MARRY_YN           AS out_MARRY_YN
                 , MARRY_DAY          AS out_MARRY_DAY
                 , MODIFY_DT          AS out_INPUT_DT
                 , MODIFY_WORKER      AS out_INPUT_SAWON
                 , DECODE(SFA_CLIENT_NO, '1', 'Y', 'N') AS out_MAIN_YN  -- 대표고객여부 
                 , DECODE(SFA_CLIENT_NO, '1',  '대표고객', '고객') AS out_MAIN_NM 
                FROM SFA_COM_CUSTOMER B
             WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
               AND SFA_CLIENT_NO = in_CLIENT_NO
               AND DEL_YN = 'N';

            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '고객 수정이 완료되었습니다';
        END IF;
        
    END IF;
    
    IF in_BTN_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우
    
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_COM_CUSTOMER
         WHERE SFA_SALES_SEQ  = in_SFA_SALES_SEQ  
           AND SFA_CLIENT_NO  = in_CLIENT_NO;
        IF v_num < 1 THEN
            out_COUNT := v_num;
            out_CODE  := 1;
            out_MSG   := '기존 등록된 고객이 없습니다12';
        ELSE
 
            UPDATE SFA_COM_CUSTOMER
               SET DEL_YN       = 'Y'
             WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
               AND SFA_CLIENT_NO = in_CLIENT_NO; 
               
            OPEN out_RESULT FOR
            SELECT (SELECT SFA_SALES_NO FROM SFA_SALES_CODE A WHERE  A.SFA_SALES_SEQ = B.SFA_SALES_SEQ ) AS out_CUST_CD
                 , (SELECT TRADE_NAME   FROM SFA_SALES_CODE A WHERE  A.SFA_SALES_SEQ = B.SFA_SALES_SEQ ) AS out_CUST_NM    
                 , SFA_CLIENT_NO      AS out_CLIENT_NO
                 , CLIENT_GUBUN       AS out_CLIENT_GUBUN
                 , CLIENT_DEPT        AS out_CLIENT_DEPT
                 , CLIENT_NAME        AS out_CLIENT_NM
                 , MALE               AS out_MALE
                 , TEL_NO             AS out_TEL_NO
                 , HP_NO              AS out_HP_NO
                 , EMAIL              AS out_EMAIL
                 , BIRTHDAY           AS out_BIRTHDAY
                 , BIRTHDAY_GUBUN     AS out_BIRTHDAY_GUBUN
                 , ZIP_CODE           AS out_ZIP_CODE
                 , DETAIL_ADDR1       AS out_DETAIL_ADDR1
                 , DETAIL_ADDR2       AS out_DETAIL_ADDR2
                 , MARRY_YN           AS out_MARRY_YN
                 , MARRY_DAY          AS out_MARRY_DAY
                 , MODIFY_DT          AS out_INPUT_DT
                 , MODIFY_WORKER      AS out_INPUT_SAWON
                 , DECODE(SFA_CLIENT_NO, '1', 'Y', 'N') AS out_MAIN_YN  -- 대표고객여부 
                 , DECODE(SFA_CLIENT_NO, '1',  '대표고객', '고객') AS out_MAIN_NM 
                FROM SFA_COM_CUSTOMER B
             WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ 
               AND DEL_YN = 'N';

            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '고객 삭제가 완료되었습니다';
         END IF;
  
        END IF;
        
        
        
EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG := '거래처코드가 누락되었습니다.';
   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
   
END;

/
