CREATE PROCEDURE      SP_SFA_CUST_03
(
    in_SAWON_ID          IN  VARCHAR2,     -- 사용자 ID
    in_CUST_CD           IN  VARCHAR2,     -- 거래처 코드
    in_CLIENT_NM         IN  VARCHAR2,     -- 고객 명 코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 고객검색  
 호출프로그램 : customer.clientlist
         
 105버전으로 대체 
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_client_no          NUMBER;
    v_cust_no            NUMBER;
    
    v_insa_sawon_id     VARCHAR2(7);
    v_insa_dept_cd      VARCHAR2(4);
    v_assgn_cd          VARCHAR2(5);
    
    CUST_CD_NULL         EXCEPTION;
    SAWON_ID_NULL        EXCEPTION;
BEGIN

       
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_03','1',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_CUST_CD:'||in_CUST_CD||'/in_CLIENT_NM:'||in_CLIENT_NM);
--COMMIT;

    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
        RAISE SAWON_ID_NULL;
    END IF;
     
    --로그인사원의 인사사번   
    select insa_sawon_id into v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID and gubun = 'Y';
    
    --로그인사원이 팀원인지,팀원이아닌 본부장,팀장인지 파악
    select assgn_cd into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    
    --본부장이면 한레벨 상위부서코드를 찾고 팀장이면 자기부서를 찾는다.
    if v_assgn_cd = '27010' then --본부장
        select dept_cd
          into v_insa_dept_cd  
          from hr_co_depart_0 
         where use_yn = 'Y' and level = 2
       connect by dept_cd = prior up_dept_cd start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id);
                       
    elsif v_assgn_cd = '27027' or v_assgn_cd = '27030' then --팀장
        select dept_cd into v_insa_dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    end if;        
    
   SELECT COUNT(*)
      INTO v_num            
      FROM SFA_COM_CUSTOMER 
     WHERE SFA_SALES_SEQ IN 
      (SELECT *
              FROM (SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE    
                     WHERE EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                          from sale0007 
                                         where insa_sawon_id in (
                                                                select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                 where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                    connect by prior dept_cd = up_dept_cd
                                                                                      start with dept_cd = v_insa_dept_cd
                                                                                  )
                                                                   and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                )
                                          and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                     )
                    UNION
                     SELECT A.SFA_SALES_SEQ
                      FROM SFA_SALES_CODE_SAWON A
                          ,SFA_SALES_CODE B
                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                       AND A.EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                          from sale0007 
                                         where insa_sawon_id in (
                                                                select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                 where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                    connect by prior dept_cd = up_dept_cd
                                                                                      start with dept_cd = v_insa_dept_cd
                                                                                   )
                                                                   and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                )
                                          and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                     )
                       AND A.REQ_GB  = '1'  --활동거래처
                       AND A.OK_STAT = '2'  --승인
                   )
             WHERE v_assgn_cd <> '27040' --팀원아니고 팀장 또는 본부장이면
            UNION ALL
            SELECT *
              FROM (SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE    
                     WHERE EMP_NO      = in_SAWON_ID
                    UNION
                     SELECT A.SFA_SALES_SEQ
                      FROM SFA_SALES_CODE_SAWON A
                          ,SFA_SALES_CODE B
                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                       AND A.EMP_NO LIKE  NVL(in_SAWON_ID, '%')
                       AND A.REQ_GB  = '1'  --활동거래처
                       AND A.OK_STAT = '2'  --승인
                   ) 
             WHERE v_assgn_cd = '27040' --팀원이면
          )
      AND CLIENT_NAME LIKE  '%'||NVL(in_CLIENT_NM, '%')||'%';
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 고객이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '고객 검색 완료';    
     
        OPEN out_RESULT FOR 
        
         SELECT F_CUST_NM_KEY('CODE',A.SFA_SALES_SEQ)      AS out_CUST_CD
               ,F_CUST_NM_KEY('NAME',A.SFA_SALES_SEQ)   AS out_CUST_NM 
               ,A.SFA_CLIENT_NO       AS out_CLIENT_NO
               ,A.CLIENT_NAME         AS out_CLIENT_NM
               ,A.HP_NO               AS out_HP_NO
               ,A.BIRTHDAY            AS out_BIRTHDAY
               ,A.BIRTHDAY_GUBUN      AS out_BIRTHDAY_GUBUN
               , DECODE(A.SFA_CLIENT_NO, '1', 'Y', 'N') AS out_MAIN_YN  -- 대표고객여부 
               , DECODE(A.SFA_CLIENT_NO, '1',  '대표고객', '고객') AS out_MAIN_NM 
         FROM SFA_COM_CUSTOMER A
         WHERE A.SFA_SALES_SEQ IN 
          (SELECT *
                  FROM (SELECT SFA_SALES_SEQ
                          FROM SFA_SALES_CODE    
                         WHERE EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                              from sale0007 
                                             where insa_sawon_id in (
                                                                    select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                     where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                        connect by prior dept_cd = up_dept_cd
                                                                                          start with dept_cd = v_insa_dept_cd
                                                                                      )
                                                                       and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                    )
                                              and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                         ) 
                        UNION
                         SELECT A.SFA_SALES_SEQ
                          FROM SFA_SALES_CODE_SAWON A
                              ,SFA_SALES_CODE B
                         WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                           AND A.EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                              from sale0007 
                                             where insa_sawon_id in (
                                                                    select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                     where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                        connect by prior dept_cd = up_dept_cd
                                                                                          start with dept_cd = v_insa_dept_cd
                                                                                       )
                                                                       and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                    )
                                              and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사)
                                         ) 
                           AND A.REQ_GB  = '1'  --활동거래처
                           AND A.OK_STAT = '2'  --승인
                       )
                 WHERE v_assgn_cd <> '27040' --팀원아니고 팀장 또는 본부장이면
                UNION ALL
                SELECT *
                  FROM (SELECT SFA_SALES_SEQ
                          FROM SFA_SALES_CODE    
                         WHERE EMP_NO      = in_SAWON_ID 
                        UNION
                         SELECT A.SFA_SALES_SEQ
                          FROM SFA_SALES_CODE_SAWON A
                              ,SFA_SALES_CODE B
                         WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                           AND A.EMP_NO LIKE '%'||NVL(in_SAWON_ID, '%')||'%'
                           AND A.REQ_GB  = '1'  --활동거래처
                           AND A.OK_STAT = '2'  --승인
                       ) 
                 WHERE v_assgn_cd = '27040' --팀원이면
              )
          AND A.CLIENT_NAME LIKE   '%'||NVL(in_CLIENT_NM, '%')||'%';
         
    END IF;
    
EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG := '거래처코드가 누락되었습니다.';  
WHEN SAWON_ID_NULL THEN
   out_CODE := 102;
   out_MSG := '사원ID가 누락되었습니다.';  
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
