CREATE PROCEDURE      SP_Z_ORDER_CHECK_TESTKTA
(
       IN_DATA  VARCHAR2 ,
        out_CODE     OUT NUMBER,
        out_MSG      OUT VARCHAR2 

  )
IS
/*---------------------------------------------------------------------------
프로그램명  : 주문체크
호출프로그램 : 주문서등록의 수량입력후    
                                   
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼
                   - GMP에서 생성한 펑션을 호？하여 수량체크한다. 
 ---------------------------------------------------------------------------*/ 
        v_ITEM_ID   VARCHAR2(10);
        v_QTY       VARCHAR2(13);
        v_DANGA     VARCHAR2(13);
    
        v_retmsg    VARCHAR2(400);   
        
        --제품체크 
        SLORDITEMCHECK_CURSOR      oragmp.types.DataSet;
        v_piecechk                 VARCHAR2(5); --생산중단제품(단종)   
        v_discontinuechk           VARCHAR2(5); --낱알품목 출하제한

BEGIN     


        v_retmsg := ORAGMP.fnSLordItemCheck('1000', to_char(sysdate+4,'YYYY-MM-DD'), '1150172', '8110078', '500911', to_number(101), 0, '20', to_number(100001));
        
      
 
EXCEPTION  
        WHEN OTHERS THEN
             out_CODE := SQLCODE;
             out_MSG :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM || out_MSG);      
END;
/
