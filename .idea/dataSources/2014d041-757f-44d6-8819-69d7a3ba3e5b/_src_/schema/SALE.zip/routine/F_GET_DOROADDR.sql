CREATE function      F_GET_DOROADDR
        ( A_CUST_ID      VARCHAR2   
        )
   RETURN VARCHAR2
AS
   user_err       exception   ;   
   v_cust_nm      VARCHAR2(50); 
   n_rtn_value    VARCHAR2(250);
   v_curr_error   VARCHAR2(250);

/*----------------------------------------------------------------
 개요  :거래처코드를 받아서 SFA거래처테이블에서 도로주소를찾아 리턴
 작성일:2014.01.22
 작성자:김태안 
----------------------------------------------------------------*/
    BEGIN
           
       select cust_nm into v_cust_nm from sale0003 where cust_id = A_CUST_ID;
       v_curr_error := A_CUST_ID||'-'||v_cust_nm;
       
       SELECT company_addr1 ||' ' ||bunji1
         INTO n_rtn_value
         FROM sfa_sales_code
        WHERE erp_sales_code    =  A_CUST_ID;
                
        RETURN n_rtn_value;

    EXCEPTION WHEN user_err THEN
                   RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
              WHEN NO_DATA_FOUND THEN
                   v_curr_error := '거래처 ( '|| v_curr_error || ' )가  SFA에 등록되지 않아서 도로명을 찾아올 수 없습니다.';
                   --RAISE_APPLICATION_ERROR(-20002, v_curr_error); 
                   RETURN 'v_curr_error';
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||'   '||SQLERRM,1,250));
    END;

/
