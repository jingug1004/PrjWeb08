CREATE PROCEDURE      SP_SFA_GIS_01
(
    in_DEPT_CD           IN  VARCHAR2,  -- 부서코드
    in_DT                IN  VARCHAR2,  -- 기준일자
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 활동경로분석
 호출프로그램 : 웹페이지        
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM (/* 방문계획, 실행 건수 */
            SELECT DEPT_NO                       AS tmp_DEPT_CD,  -- 지점코드   
                   EMP_NO                        AS tmp_EMP_NO,     -- 담당자사번 
                   SALES_PLAN_NO                 AS tmp_PLAN_DT,    -- 방문일자   
                   COUNT(DETAIL_PLAN_NO)         AS tmp_PLAN_CNT,   -- 계획건수   
             --      SUM(DECODE(STATUS,'99',1,0))  AS tmp_ACTION_CNT  -- 실행건수    
                   SUM(DECODE(CALL_YN,'Y',1,0))  AS tmp_ACTION_CNT  -- 실행건수    
              FROM SFA_VISIT_PLANACT
             WHERE SALES_PLAN_NO   = NVL(in_DT, TO_CHAR(SYSDATE, 'YYYYMMDD'))
               AND DEPT_NO LIKE NVL(in_DEPT_CD, '%')
             GROUP BY DEPT_NO, EMP_NO, SALES_PLAN_NO) ;
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT tmp_DEPT_CD                                                                         AS out_DEPT_CD      -- 부서코드
             , (SELECT DEPT_NM  FROM SALE0008 WHERE DEPT_CD = tmp_DEPT_CD)                         AS out_DEPT_NM      -- 부서명
             , tmp_EMP_NO                                                                          AS out_EMP_NO       -- 담당자사번
             , F_SAWON_NM(tmp_EMP_NO)                                                              AS out_EMP_NM       -- 담당자명
             , tmp_PLAN_DT                                                                         AS out_PLAN_DT      -- 방문일자
             , DECODE(SIGN(NVL(tmp_PLAN_CNT,0)),1,NVL(tmp_ACTION_CNT,0)||'/'||NVL(tmp_PLAN_CNT,0)) AS out_ACT_PLAN_CNT -- 실행/계획
             , NVL(tmp_PLAN_CNT,0)                                                                 AS out_PLAN_CNT     -- 계획건수
             , NVL(tmp_ACTION_CNT,0)                                                               AS out_ACTION_CNT   -- 실행건수
         FROM (/* 방문계획, 실행 건수 */
                SELECT DEPT_NO                         AS tmp_DEPT_CD,  -- 지점코드   
                       EMP_NO                          AS tmp_EMP_NO,     -- 담당자사번
                       SALES_PLAN_NO                   AS tmp_PLAN_DT,    -- 방문일자   
                       COUNT(DETAIL_PLAN_NO)           AS tmp_PLAN_CNT,   -- 계획건수   
                       SUM(DECODE(CALL_YN,'Y',1,0))    AS tmp_ACTION_CNT  -- 실행건수    
                  FROM SFA_VISIT_PLANACT
                 WHERE SALES_PLAN_NO   = NVL(in_DT, TO_CHAR(SYSDATE, 'YYYYMMDD'))
                   AND DEPT_NO LIKE NVL(in_DEPT_CD, '%')
    --                       AND EMP_NO    = in_EMP_NO
                 GROUP BY DEPT_NO, EMP_NO, SALES_PLAN_NO);
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
