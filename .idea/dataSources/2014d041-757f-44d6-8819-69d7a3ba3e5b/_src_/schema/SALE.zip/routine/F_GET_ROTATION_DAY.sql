CREATE FUNCTION F_Get_Rotation_Day
        ( a_ymd   VARCHAR2,  -- 기준일자
          a_cust  VARCHAR2   -- 거래처 
                  )
   RETURN NUMBER

AS
   v_misu_amt_sum NUMBER;
   v_rotation_day NUMBER;
   v_avg_amt      NUMBER;
   v_jango_amt    NUMBER;

BEGIN

   v_misu_amt_sum := 0;
   v_rotation_day := 0;
   v_avg_amt      := 0;
   v_jango_amt    := 0;

   FOR c1 IN (
                SELECT YMD,
                       SUM(NVL(BEFORE_AMT,0) + NVL(MISU_AMT,0) - NVL(SU_AMT,0)) JANGO_AMT,
                       SUM(MISU_AMT)                 MISU_AMT
                  FROM SALE0306 
                 WHERE YMD BETWEEN ADD_MONTHS(TO_DATE(SUBSTR(a_ymd,1,6)||'01','YYYY/MM/DD'),-11)
                           AND TO_DATE(SUBSTR(a_ymd,1,6)||'01','YYYY/MM/DD')
				   AND CUST_ID = a_cust				 
                 GROUP BY YMD 
                 ORDER BY YMD DESC    
                   )      
		LOOP

       IF TO_DATE(SUBSTR(a_ymd,1,6)||'01','YYYY/MM/DD') = c1.ymd THEN
          v_jango_amt := c1.jango_amt;
       END IF;

       IF v_jango_amt > 0 THEN
          v_misu_amt_sum := v_misu_amt_sum + c1.misu_amt;

          IF v_jango_amt - v_misu_amt_sum = 0 THEN
             v_rotation_day := (LAST_DAY(a_ymd) - c1.ymd) + 1;
             EXIT;
          ELSIF v_jango_amt - v_misu_amt_sum < 0 THEN
             v_rotation_day := (LAST_DAY(a_ymd) - ADD_MONTHS(c1.ymd,1)) + 1;
             v_avg_amt := c1.misu_amt / TO_CHAR(LAST_DAY(c1.ymd),'DD');
             v_rotation_day := v_rotation_day + ROUND((v_jango_amt - (v_misu_amt_sum - c1.misu_amt)) / v_avg_amt,0);
             EXIT;
          END IF;
       END IF;
   END LOOP;
				
				
    IF (v_jango_amt > 0 AND v_rotation_day = 0) OR (v_rotation_day > 366) THEN
       v_rotation_day := 366;
    END IF;


    RETURN v_rotation_day;
END;


/
