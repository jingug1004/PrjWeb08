CREATE PROCEDURE      SP_SFA_OFFICE_01_102_bak1
(   
    in_SAWON_ID          IN  VARCHAR2, --영업사번
    in_STR_DT            IN  VARCHAR2,
    in_END_DT            IN  VARCHAR2,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 공지사항조회 
 호출프로그램 : 오피스>공지사항
 수정기록      2015.05.28 -새로 개발한 hanagw 의 게시판을 조회하도록 수정
       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER; 
    v_sawon_id           VARCHAR2(10); --영업사번
    
BEGIN

    --공지사항은 인사사번기준으로 자료가 들어있다.
    --따라서, 영업사원아이디가 넘어오므로 인사사번으로 변경해야 함. 
    select insa_sawon_id into v_sawon_id from sale0007 where sawon_id = in_SAWON_ID;

    --로그인사번에게 온 공지 
   SELECT count(*)
     INTO v_num
     FROM (
            SELECT GON.SEQ,
                   GON.SUBJECT,
                   GON.NOTI_KIND CD,
                   GCC.CD_NM NOTI_KIND,
                   GON.CONTENTS,
                   GON.READ_CNT,
                   TA.COMMENT_CNT,
                   (SELECT DECODE (SIGN (COUNT (*)), 1, 'Y', 'N') FROM hanagroupware.gw_of_notice_target WHERE seq = gon.seq AND emp_no = v_sawon_id ) READ_YN
                   ,TB.ATTACH_CNT,
                   SUBSTR(GON.START_YMD,1,4)||'-'|| SUBSTR(GON.START_YMD,5,2)||'-'||SUBSTR(GON.START_YMD,7,2) START_YMD,
                   SUBSTR(GON.END_YMD,1,4)||'-'|| SUBSTR(GON.END_YMD,5,2)||'-'||SUBSTR(GON.END_YMD,7,2) END_YMD,
                   TO_CHAR (GON.CREATE_DT, 'YYYY-MM-DD HH24:MI:SS') CREATE_DT,
                   HANAHR.F_GET_EMP_KO_NM(GON.CREATE_NO) EMP_KO_NM, GON.DELETE_YN, GON.CREATE_NO
              FROM hanagroupware.GW_OF_NOTICE GON
                  ,hanagroupware.GW_CO_CODE GCC
                  ,(SELECT SEQ,COUNT (*) AS COMMENT_CNT FROM hanagroupware.GW_OF_NOTICE_COMMENT NC WHERE DELETE_YN != 'Y' GROUP BY SEQ) TA
                  ,(SELECT OFA.SEQ, COUNT(*) AS ATTACH_CNT FROM hanagroupware.GW_OF_FILE_ATTACH OFA WHERE OFA.DELETE_YN='N' AND OFA.CD = 'O01000' GROUP BY OFA.SEQ) TB
             WHERE GON.NOTI_KIND = GCC.CD
               AND GON.SEQ = TA.SEQ(+)
               AND GON.SEQ = TB.SEQ(+)
           ) TC
    WHERE TC.DELETE_YN != 'Y'
      AND ((TC.START_YMD <= TO_DATE(in_END_DT,'yyyy-mm-dd') AND TC.END_YMD >= TO_DATE(in_STR_DT,'yyyy-mm-dd')) OR     
           (TC.START_YMD <= TO_DATE(in_STR_DT,'yyyy-mm-dd') AND TC.END_YMD >= TO_DATE(in_END_DT,'yyyy-mm-dd'))
          );
           
       
       
    out_COUNT := v_num;
    DBMS_OUTPUT.put_line('out_COUNT:'||to_char(out_COUNT));
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '공지사항이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '공지사항 정보 확인완료';    
         
        OPEN out_RESULT FOR

            select out_BOARD_ID       -- 공지사항 ID
                  ,ROWNUM as out_BOARD_SEQ      -- 공지 번호(SEQ)
                  ,out_TITLE          -- 공지 제목
                  ,out_DISCRIPTION    -- 공지 내용
                  ,out_START_DATE     -- 공지 시작일
                  ,out_READ_YN  -- 읽었는지여부
              from (
                       SELECT TC.SEQ                      AS out_BOARD_ID 
                             ,TC.SUBJECT                  AS out_TITLE
                             ,TC.CONTENTS                 AS out_DISCRIPTION
                             ,SUBSTR(TC.START_YMD, 1,8)   AS out_START_DATE
                             ,TC.READ_YN                  AS out_READ_YN 
                         FROM (
                                SELECT GON.SEQ,
                                       GON.SUBJECT,
                                       GON.NOTI_KIND CD,
                                       GCC.CD_NM NOTI_KIND,
                                       GON.CONTENTS,
                                       GON.READ_CNT,
                                       TA.COMMENT_CNT,
                                       (SELECT DECODE (SIGN (COUNT (*)), 1, 'Y', 'N') FROM hanagroupware.gw_of_notice_target WHERE seq = gon.seq AND emp_no = v_sawon_id ) READ_YN
                                       ,TB.ATTACH_CNT,
                                       SUBSTR(GON.START_YMD,1,4)||'-'|| SUBSTR(GON.START_YMD,5,2)||'-'||SUBSTR(GON.START_YMD,7,2) START_YMD,
                                       SUBSTR(GON.END_YMD,1,4)||'-'|| SUBSTR(GON.END_YMD,5,2)||'-'||SUBSTR(GON.END_YMD,7,2) END_YMD,
                                       TO_CHAR (GON.CREATE_DT, 'YYYY-MM-DD HH24:MI:SS') CREATE_DT,
                                       HANAHR.F_GET_EMP_KO_NM(GON.CREATE_NO) EMP_KO_NM, GON.DELETE_YN, GON.CREATE_NO
                                  FROM hanagroupware.GW_OF_NOTICE GON
                                      ,hanagroupware.GW_CO_CODE GCC
                                      ,(SELECT SEQ,COUNT (*) AS COMMENT_CNT FROM hanagroupware.GW_OF_NOTICE_COMMENT NC WHERE DELETE_YN != 'Y' GROUP BY SEQ) TA
                                      ,(SELECT OFA.SEQ, COUNT(*) AS ATTACH_CNT FROM hanagroupware.GW_OF_FILE_ATTACH OFA WHERE OFA.DELETE_YN='N' AND OFA.CD = 'O01000' GROUP BY OFA.SEQ) TB
                                 WHERE GON.NOTI_KIND = GCC.CD
                                   AND GON.SEQ = TA.SEQ(+)
                                   AND GON.SEQ = TB.SEQ(+)
                               ) TC
                        WHERE TC.DELETE_YN != 'Y'
                          AND ((TC.START_YMD <= TO_DATE(in_END_DT,'yyyy-mm-dd') AND TC.END_YMD >= TO_DATE(in_STR_DT,'yyyy-mm-dd')) OR     
                               (TC.START_YMD <= TO_DATE(in_STR_DT,'yyyy-mm-dd') AND TC.END_YMD >= TO_DATE(in_END_DT,'yyyy-mm-dd'))
                              )
           
                    )
               order by ROWNUM;
         
    END IF;
         
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
