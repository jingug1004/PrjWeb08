CREATE PROCEDURE      SP_SFA_COLLECT_01_110
(
    in_SAWON_ID          IN  VARCHAR2,   
    in_CDT_FR      IN  VARCHAR2,    
    in_CDT_TO      IN  VARCHAR2,    
    in_GUBUN     IN  VARCHAR2,    
    in_CUSTOMER_CODE     IN  VARCHAR2,    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
        /*---------------------------------------------------------------------------
         프로그램명 : 수금현황
         호출프로그램 : 
         수정기록 : 
         - 20130218 kta 영수증재발행 버튼 추가관련 수정. 
         - 20150424 kta 수금사원 기준으로 조회되던것을 실제담당사원기준으로
                               조회되도록 변경 ( 도매 이승원부장이 팀원들과 거래처조정하면서
                               변경된 본인 거래처만 나오도록 요청 한 것임) - 윤홍주차장 확인.
         - 20150721 인수인계 이전 자료를 조회 가능하도록 수정 - 영업사원 김정원            
         ---------------------------------------------------------------------------*/    

        v_num                NUMBER;
        GUBUN_NULL         EXCEPTION;     
        
    
BEGIN

        IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
                RAISE GUBUN_NULL;
        END IF;        
    
        
        IF in_GUBUN = '0' THEN  --전체
                IF in_SAWON_ID = '2014048' AND in_CUSTOMER_CODE = '4900764' THEN   --CHOE 20150721 임시로 설정함
                        SELECT COUNT(*)
                        INTO v_num
                        FROM (
                                SELECT Z.*
                                ,F_GET_SALE0401_SAWONIDH(Z.CUST_ID ,Z.YMD) AS SILJUK_SAWON_ID
                                FROM SALE0401 Z
                                ) A
                        WHERE A.YMD BETWEEN in_CDT_FR AND in_CDT_TO
                        AND A.CUST_ID Like '%'||NVL(in_CUSTOMER_CODE, '%')||'%'
                        --AND A.SILJUK_SAWON_ID = in_SAWON_ID
                        ;
                ELSE
                        SELECT COUNT(*)
                        INTO v_num
                        FROM (
                                SELECT Z.*
                                ,F_GET_SALE0401_SAWONIDH(Z.CUST_ID ,Z.YMD) AS SILJUK_SAWON_ID
                                FROM SALE0401 Z
                                ) A
                        WHERE A.YMD BETWEEN in_CDT_FR AND in_CDT_TO
                        AND A.CUST_ID Like '%'||NVL(in_CUSTOMER_CODE, '%')||'%'
                        AND A.SILJUK_SAWON_ID = in_SAWON_ID
                        ;
                END IF;
           
        ELSIF in_GUBUN = '1' THEN --현금
                SELECT COUNT(*)
                INTO v_num
                FROM (
                        SELECT Z.*
                        ,F_GET_SALE0401_SAWONIDH(Z.CUST_ID ,Z.YMD) AS SILJUK_SAWON_ID
                        FROM SALE0401 Z
                        ) A
                WHERE A.SAWON_ID IN (SELECT SAWON_ID FROM SALE0007 WHERE SIL_SAWON_ID = in_SAWON_ID )
                AND A.CUST_ID LIKE '%'||NVL(in_CUSTOMER_CODE, '%')||'%'
                AND A.CASH_AMT <> '0' 
                AND A.YMD BETWEEN in_CDT_FR AND in_CDT_TO
                AND A.SILJUK_SAWON_ID = in_SAWON_ID
                ;
           
           
        ELSIF in_GUBUN = '2' THEN --카드
                SELECT COUNT(*)
                INTO v_num
                FROM (
                        SELECT Z.*
                        ,F_GET_SALE0401_SAWONIDH(Z.CUST_ID ,Z.YMD) AS SILJUK_SAWON_ID
                        FROM SALE0401 Z
                        ) A
                WHERE A.SAWON_ID  IN (SELECT SAWON_ID FROM SALE0007 WHERE SIL_SAWON_ID = in_SAWON_ID )
                AND A.CUST_ID LIKE '%'||NVL(in_CUSTOMER_CODE, '%')||'%'
                AND A.BILL_AMT <> '0' 
                AND A.YMD BETWEEN in_CDT_FR AND in_CDT_TO
                AND A.SILJUK_SAWON_ID = in_SAWON_ID;
        END IF;                
                    
                    
    
        out_COUNT := v_num;
    
        IF v_num = 0 THEN
                out_CODE := 1;
                out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
                out_CODE := 0;
                out_MSG := '검색 완료';    
     
                IF in_GUBUN = '0' THEN  --전체
                        IF in_SAWON_ID = '2014048' AND in_CUSTOMER_CODE = '4900764' THEN   --CHOE 20150721 임시로 설정함
                        OPEN out_RESULT FOR
                                SELECT F_CUST_NM(TO_NUMBER(A.CUST_ID)) AS out_CUST_ID   --거래처
                                ,F_CUST_NM(TO_NUMBER(A.RCUST_ID)) AS out_RCUST_ID  --매출처   
                                ,A.JUNPYO_NO AS out_JUNPYO_NO --전표번호                       
                                ,A.CASH_AMT AS out_CASH_AMT  --현금
                                ,A.BILL_AMT AS out_CARD_AMT  --카드
                                ,A.YMD AS out_COLL_DATE  --매출일자          
                                ,A.CARD_COMP AS out_CARD_COMP --카드사     
                                ,A.CARD_NO AS out_CARD_NO --카드번호     
                                ,A.CARD_USE_PERIOD AS out_CARD_USE_PERIOD --유효기간    
                                ,A.CARD_ACCEPT_NO AS out_CARD_ACCEPT_NO --승인번호    
                                ,A.CARD_BILL_GB AS out_CARD_BILL_GB --거래종류(신용결재승인,신용결재취소)    
                                ,A.CARD_ALLOTMENT AS out_CARD_ALLOTMENT --할부개월수
                                FROM (
                                        SELECT Z.*
                                        ,F_GET_SALE0401_SAWONIDH(Z.CUST_ID ,Z.YMD) AS SILJUK_SAWON_ID
                                        FROM SALE0401 Z
                                        ) A
                                WHERE A.YMD BETWEEN in_CDT_FR AND in_CDT_TO
                                AND A.CUST_ID Like '%'||NVL(in_CUSTOMER_CODE, '%')||'%'
                                --AND A.SILJUK_SAWON_ID = in_SAWON_ID
                                ORDER BY A.JUNPYO_NO
                                ;
                        ELSE
                        OPEN out_RESULT FOR
                                SELECT F_CUST_NM(TO_NUMBER(A.CUST_ID)) AS out_CUST_ID   --거래처
                                ,F_CUST_NM(TO_NUMBER(A.RCUST_ID)) AS out_RCUST_ID  --매출처   
                                ,A.JUNPYO_NO AS out_JUNPYO_NO --전표번호                       
                                ,A.CASH_AMT AS out_CASH_AMT  --현금
                                ,A.BILL_AMT AS out_CARD_AMT  --카드
                                ,A.YMD AS out_COLL_DATE  --매출일자          
                                ,A.CARD_COMP AS out_CARD_COMP --카드사     
                                ,A.CARD_NO AS out_CARD_NO --카드번호     
                                ,A.CARD_USE_PERIOD AS out_CARD_USE_PERIOD --유효기간    
                                ,A.CARD_ACCEPT_NO AS out_CARD_ACCEPT_NO --승인번호    
                                ,A.CARD_BILL_GB AS out_CARD_BILL_GB --거래종류(신용결재승인,신용결재취소)    
                                ,A.CARD_ALLOTMENT AS out_CARD_ALLOTMENT --할부개월수
                                FROM (
                                        SELECT Z.*
                                        ,F_GET_SALE0401_SAWONIDH(Z.CUST_ID ,Z.YMD) AS SILJUK_SAWON_ID
                                        FROM SALE0401 Z
                                        ) A
                                WHERE A.YMD BETWEEN in_CDT_FR AND in_CDT_TO
                                AND A.CUST_ID Like '%'||NVL(in_CUSTOMER_CODE, '%')||'%'
                                AND A.SILJUK_SAWON_ID = in_SAWON_ID
                                ORDER BY A.JUNPYO_NO
                                ;
                        END IF;
             
                ELSIF in_GUBUN = '1' THEN --현금
                        OPEN out_RESULT FOR
                                SELECT F_CUST_NM(TO_NUMBER(A.CUST_ID)) AS out_CUST_ID   --거래처
                                ,F_CUST_NM(TO_NUMBER(A.RCUST_ID)) AS out_RCUST_ID  --매출처   
                                ,A.JUNPYO_NO AS out_JUNPYO_NO --전표번호                       
                                ,A.CASH_AMT AS out_CASH_AMT  --현금
                                ,A.BILL_AMT AS out_CARD_AMT  --카드
                                ,A.YMD AS out_COLL_DATE  --매출일자          
                                ,A.CARD_COMP AS out_CARD_COMP --카드사     
                                ,A.CARD_NO AS out_CARD_NO --카드번호     
                                ,A.CARD_USE_PERIOD AS out_CARD_USE_PERIOD --유효기간    
                                ,A.CARD_ACCEPT_NO AS out_CARD_ACCEPT_NO --승인번호    
                                ,A.CARD_BILL_GB AS out_CARD_BILL_GB --거래종류(신용결재승인,신용결재취소)    
                                ,A.CARD_ALLOTMENT AS out_CARD_ALLOTMENT --할부개월수
                                FROM ( 
                                        SELECT Z.*
                                        ,F_GET_SALE0401_SAWONIDH(Z.CUST_ID ,Z.YMD) AS SILJUK_SAWON_ID
                                        FROM SALE0401 Z
                                        ) A
                                WHERE A.YMD BETWEEN in_CDT_FR AND in_CDT_TO
                                AND A.CASH_AMT <> '0' 
                                AND A.CUST_ID Like '%'||NVL(in_CUSTOMER_CODE, '%')||'%'
                                AND A.SILJUK_SAWON_ID = in_SAWON_ID
                                ORDER BY A.JUNPYO_NO
                                ;
             
                ELSIF in_GUBUN = '2'THEN --카드        
                        OPEN out_RESULT FOR
                                SELECT F_CUST_NM(TO_NUMBER(A.CUST_ID)) AS out_CUST_ID   --거래처
                                ,F_CUST_NM(TO_NUMBER(A.RCUST_ID)) AS out_RCUST_ID  --매출처   
                                ,A.JUNPYO_NO AS out_JUNPYO_NO --전표번호                       
                                ,A.CASH_AMT AS out_CASH_AMT  --현금
                                ,A.BILL_AMT AS out_CARD_AMT  --카드
                                ,A.YMD AS out_COLL_DATE  --매출일자     
                                ,A.CARD_COMP AS out_CARD_COMP --카드사     
                                ,A.CARD_NO AS out_CARD_NO --카드번호     
                                ,A.CARD_USE_PERIOD AS out_CARD_USE_PERIOD --유효기간    
                                ,A.CARD_ACCEPT_NO AS out_CARD_ACCEPT_NO --승인번호    
                                ,A.CARD_BILL_GB AS out_CARD_BILL_GB --거래종류(신용결재승인,신용결재취소)    
                                ,A.CARD_ALLOTMENT AS out_CARD_ALLOTMENT --할부개월수
                                FROM( 
                                        SELECT Z.*
                                        ,F_GET_SALE0401_SAWONIDH(Z.CUST_ID ,Z.YMD) AS SILJUK_SAWON_ID
                                        FROM SALE0401 Z
                                        ) A
                                WHERE A.YMD BETWEEN in_CDT_FR AND in_CDT_TO
                                AND A.BILL_AMT <> '0' 
                                AND A.CUST_ID Like '%'||NVL(in_CUSTOMER_CODE, '%')||'%'
                                AND A.SILJUK_SAWON_ID = in_SAWON_ID
                                ORDER BY A.JUNPYO_NO
                                ;
                                
                END IF;
         
        END IF;
    
EXCEPTION
        WHEN GUBUN_NULL THEN
                out_CODE := 101;
                out_MSG := '구분코드가 누락되었습니다.'; 
        WHEN OTHERS THEN
                out_CODE := SQLCODE;
                out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
