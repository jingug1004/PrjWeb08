CREATE PROCEDURE      SP_SFA_VISIT_03
(
    in_SAWON_ID          IN  VARCHAR2,     
    in_CUST_KEY           IN  VARCHAR2,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 개인방문계획업체별 고객
 호출프로그램 :108 버전으로 대체됨       
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;

BEGIN


    SELECT COUNT(*)
      INTO v_num
      FROM SFA_COM_CUSTOMER A
     WHERE A.SFA_SALES_SEQ   = in_CUST_KEY;
       
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
       out_CODE := 0;
       out_MSG := '검색 완료';    
     
        OPEN out_RESULT FOR
        SELECT A.SFA_SALES_SEQ               AS out_SFA_SALES_SEQ,      
               A.SFA_CLIENT_NO                AS out_CLIENT_NO,
               F_CUST_NM_KEY('NAME',A.SFA_SALES_SEQ)  AS out_SFA_SALES_NM,                
               A.CLIENT_NAME                AS out_CLIENT_NAME       
          FROM SFA_COM_CUSTOMER A
         WHERE A.SFA_SALES_SEQ   = in_CUST_KEY
           AND A.DEL_YN = 'N';
        
    END IF;

    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
