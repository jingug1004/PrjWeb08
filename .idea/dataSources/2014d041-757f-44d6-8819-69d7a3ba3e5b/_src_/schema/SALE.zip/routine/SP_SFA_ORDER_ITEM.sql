CREATE PROCEDURE      SP_SFA_ORDER_ITEM   
(   
    in_GUMAE_NO          IN VARCHAR2 default NULL,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문상세내역
 호출프로그램 : 주문서등록 OrderNew 에서 호출 
                주문현황 OrderList 에서 호출
                간납처주문현황 ROrderList 에서 호출 
                130 버전이 있으나 이것을 사용함.130 버전은 사용하지 않음. 
                
                
                
        CHOE 20160810 수정사항 주문수량과 승인수량이 달라지는 경우를 표시 해 달라고 함
        주의 주문번호 정보가  SALE.SALE0203 : GUMAE_NO  = SALEON.SALE0203 : GUMAE_NO 경우만 
         IF v_num > 0 THEN 이용하고 (SALEON.SALE0204 이용하고)
         
         주문번호 SALE.SALE0203 : GUMAE_NO  = 승인번호 SALEON.SALE0203 : GUMAE_NOT 경우에는 
         ELSE 이용하게 된다. (SALE.SALE0204
        
 ---------------------------------------------------------------------------*/    

        v_num NUMBER;
        V_ITEM_CNT NUMBER;   
        V_GUMAE_NO SALE_ON.SALE0203.GUMAE_NOT%TYPE;
        
BEGIN
        
        --1. 온라인 주문에 주문번호로 자료가 있는지 조회 한다. 
        SELECT COUNT(*)
        INTO v_num
        FROM SALE_ON.SALE0204 A
        WHERE A.GUMAE_NO  = in_gumae_no
        ;     
        
        
        --out_CODE := 1;
        --out_MSG := '조회한 내역이 존재하지 않습니다.';
        --insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDER_ITEM','1',sysdate,'in_GUMAE_NO:'||in_GUMAE_NO );
       --COMMIT;         
      
        IF v_num > 0 THEN  --선택한 주문번호로 상세내역을 조회하는 것이므로 있으면 sale_on에 있음, 없으면 sale에 있음   
                out_COUNT := v_num;
                out_CODE := 0;
                out_MSG := '검색 완료';        
               
                OPEN out_RESULT FOR
                SELECT 
                F_ITEM_NM(A.ITEM_ID) AS out_ITEM_ID,                        
                DECODE(NVL(A.QTY,'0') ,NVL(A.REQ_QTY,'0') ,TO_CHAR(A.QTY) ,TO_CHAR(A.QTY)||'/'||TO_CHAR(A.REQ_QTY) ) AS out_QTY,   -- CHOE 주문수량과 다른 경우 표시  
                A.DANGA                 AS out_DANGA,   
                A.AMT                   AS out_AMT,
                A.VAT                   AS out_VAT,
                A.AMT + A.VAT           AS out_AMOUNT
                FROM SALE_ON.SALE0204 A
                WHERE A.GUMAE_NO = in_GUMAE_NO                        
                ORDER BY A.INPUT_SEQ DESC
                ;
                
        ELSE  --선택한 주문번호로 상세내역을 조회하는 것이므로 있으면 sale_on에 있음, 없으면 sale에 있음:보통 간납처주문으로 본사에서 입력한것임.
                --2. 온라인 주문에 승인 번호로 자료가 있는지 조회한다.  온라인 주문에서 승인번호에 대한 주문 번호를 찾는다.
                
                SELECT COUNT(*)
                INTO v_num
                FROM SALE_ON.SALE0203 A
                WHERE A.GUMAE_NOT  = in_gumae_no                                
                ;  
                
                IF v_num > 0 THEN   --2번에 찾고자하는 자료는  SFA 화면에서 SALE의 주문번호 = 온라인 승인 번호인 경우를 찾으려고
                
                        V_GUMAE_NO := '';
                         SELECT GUMAE_NO
                        INTO V_GUMAE_NO
                        FROM SALE_ON.SALE0203 A
                        WHERE A.GUMAE_NOT  = in_gumae_no
                        GROUP BY GUMAE_NO                
                        ;  
                        
                        V_ITEM_CNT := 0;
                        SELECT COUNT(*)
                        INTO V_ITEM_CNT
                        FROM SALE_ON.SALE0204 A
                        WHERE A.GUMAE_NO  = V_GUMAE_NO
                        ;
                        out_COUNT := V_ITEM_CNT;
                        out_CODE := 0;
                        out_MSG := '검색 완료';        
                       
                        OPEN out_RESULT FOR
                        SELECT 
                        F_ITEM_NM(A.ITEM_ID) AS out_ITEM_ID,                        
                        DECODE(NVL(A.QTY,'0') ,NVL(A.REQ_QTY,'0') ,TO_CHAR(A.QTY) ,TO_CHAR(A.QTY)||'/'||TO_CHAR(A.REQ_QTY) ) AS out_QTY,   -- CHOE 주문수량과 다른 경우 표시  
                        A.DANGA                 AS out_DANGA,   
                        A.AMT                   AS out_AMT,
                        A.VAT                   AS out_VAT,
                        A.AMT + A.VAT           AS out_AMOUNT
                        FROM SALE_ON.SALE0204 A     
                        WHERE A.GUMAE_NO = V_GUMAE_NO                   
                        ORDER BY A.INPUT_SEQ DESC
                        ;
                         
                ELSE
                        SELECT COUNT(*)
                        INTO v_num
                        FROM SALE0204 A
                        WHERE A.GUMAE_NO  = in_gumae_no;
                 
                        out_COUNT := v_num;
                        
                        IF v_num = 0 THEN
                                out_CODE := 1;
                                out_MSG := '조회한 내역이 존재하지 않습니다.';
                        ELSE
                                out_CODE := 0;
                                out_MSG := '검색 완료';    
                       
                                OPEN out_RESULT FOR
                                SELECT 
                                F_ITEM_NM(A.ITEM_ID) AS out_ITEM_ID,
                                A.QTY                   AS out_QTY,   
                                A.DANGA                 AS out_DANGA,   
                                A.AMT                   AS out_AMT,
                                A.VAT                   AS out_VAT,
                                A.AMT + A.VAT           AS out_AMOUNT
                                FROM SALE0204 A
                                WHERE A.GUMAE_NO = in_gumae_no
                                ORDER BY A.INPUT_SEQ DESC;
                        END IF;
                END IF;   
        END IF;        
    
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
