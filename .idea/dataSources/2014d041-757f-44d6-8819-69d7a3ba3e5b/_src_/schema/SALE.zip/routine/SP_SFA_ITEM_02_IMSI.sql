CREATE PROCEDURE      SP_SFA_ITEM_02_IMSI    -- 제품 조회 상세
(
    in_ITEM_ID           IN  VARCHAR2,  
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   :제품조회상세 
 호출프로그램 102 버전으로 대체 삭제할것.
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    ITEM_ID_NULL         EXCEPTION;
BEGIN
    
    IF in_ITEM_ID IS NULL THEN
        RAISE ITEM_ID_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM SALE0004  A   LEFT OUTER JOIN SFA_OFFICE_ITEMDOC  B
                          ON   A.ITEM_ID  = TO_CHAR(B.ITEM_CODE)
     WHERE A.ITEM_ID  = in_ITEM_ID;
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT A.ITEM_ID              AS out_ITEM_ID        -- 제품코드
             , A.ITEM_NM              AS out_ITEM_NM        -- 제품명
             , A.STANDARD             AS out_STANDARD       -- 규격
             , A.UNIT                 AS out_UNIT           -- 단위
             , A.OUT_DANGA            AS out_DANGA          -- 단가(출고단가)  
             , NULL                   AS out_STOCK          -- 재고
             , A.CHUL_YN              AS out_CHUL_YN        -- 출하중지여부 (Y:중지?, N:출하?)
             , DECODE(A.CHUL_YN, 'Y', '중지', '출하')  AS out_CHUL_NM   -- 출하중지여부명
             , NULL                   AS out_STOCK_GUBUN    -- 재고구분
             , A.VIEW_TXT             AS out_VIEW_TXT       -- 효능효과? 
             , B.ITEM_POINT           AS out_ITEM_POINT     -- 특장점
             , B.ITEM_EFFECT          AS out_EFFECT         -- 효능효과(제품상세설명)
             , B.ITEM_USE_DOES        AS out_ITEM_USE_DOES  -- 용량용법
             , B.ITEM_ATTENTION        AS out_ITEM_ATTENTION -- 주의사항
             , B.ITEM_PHOTO           AS out_PHOTO          -- 이미지     
             , B.ITEM_1SPEECH         AS out_ITEM_1SPEECH   -- 1분 스피치
             , B.ITEM_3SPEECH         AS out_ITEM_3SPEECH   -- 3분 스피치
             , A.SAUPJANG_CD          AS out_SAUPJANG_CD    --사업장코드(101-하길,102-도매,103-도매(향정))        
          FROM SALE0004  A   LEFT OUTER JOIN SFA_OFFICE_ITEMDOC  B
                                  ON   A.ITEM_ID  = TO_CHAR(B.ITEM_CODE)
         WHERE A.ITEM_ID  = in_ITEM_ID
         ORDER BY ITEM_NM;
    END IF;
    
EXCEPTION
WHEN ITEM_ID_NULL THEN
   out_CODE := '101';
   out_MSG  := '제품코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
