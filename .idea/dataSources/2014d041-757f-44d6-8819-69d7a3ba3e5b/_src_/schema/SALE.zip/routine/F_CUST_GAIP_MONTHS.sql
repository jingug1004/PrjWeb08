CREATE function      f_cust_gaip_months
                          (in_YMD       IN  DATE,         -- 주문일자
                           in_CUST_ID   IN  VARCHAR2      -- 거래처코드
                           )  RETURN number   IS   

    v_ret    number := 0;   --개시개월수

/*----------------------------------------------------------------------------*
 기능: 주문거래처의 가입개월수 return
 작성자:김태안
 작성일:2014.07.25
 수정기록
 참고사항: 
 *----------------------------------------------------------------------------*/          


BEGIN

    SELECT trunc(months_between(to_date(to_char(in_YMD,'yyyymm'),'yyyymm'), to_date(to_char(START_YMD,'yyyymm'),'yyyymm')))  --일자로 하지 않고 1일로 바꿔서 
      INTO v_ret
      FROM SALE.SALE0003
     WHERE CUST_ID = in_CUST_ID;         
     
    IF v_ret > 3 THEN
       v_ret := 3;
    ELSIF    v_ret = 0 THEN    
       v_ret := 1;
    END IF; 

    return  v_ret;

END;

/
