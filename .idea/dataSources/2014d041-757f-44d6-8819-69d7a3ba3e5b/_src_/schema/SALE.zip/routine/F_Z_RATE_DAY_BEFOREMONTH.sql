CREATE FUNCTION      F_Z_RATE_DAY_BEFOREMONTH 
(
    in_YYYYMMDD  IN  VARCHAR2,  --기준일자 
    in_CUST_CD IN  VARCHAR2   --거래처코드
) 
RETURN VARCHAR2 IS

    v_rateday   VARCHAR2(20);  
    
    
/*----------------------------------------------------------------------------*
  기능    :  회전일을 찾음     
 추가설명   :        
 작성자    : 김태안
 작성일    : 2017.12.12
 수정기록                
 *----------------------------------------------------------------------------*/          
BEGIN
 
 
    
    --당월 회전일
    SELECT to_char(turndccnt) 
      INTO v_rateday 
      FROM TABLE(oragmp.fnSLcustTURN('1000',in_CUST_CD, '%',  '%', in_YYYYMMDD, 0));        
    
    RETURN v_rateday;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '0';
END;
/
