CREATE FUNCTION      F_SFA_VISIT_PLANACT_CNT  
(
        in_SALES_PLAN_NO IN  VARCHAR2 
        ,in_EMP_NO  IN  VARCHAR2
        ,in_SFA_SALES_SEQ IN VARCHAR2
        ,in_SFA_CLIENT_NO IN  NUMBER            
) 
RETURN NUMBER IS

        V_MARK NUMBER;
    
BEGIN

        /*--------------------------------------------------------------------------------------
        CHOE 20131101
        월별 거래처의 고객 방문 카운트를 하기 위한 FUCTION
        in_SALES_PLAN_NO - 방문한 월을 찾는다.  yyyymm 으로 받는다.
        in_EMP_NO - 담당사원 정보
        in_DETAIL_PLAN_NO - 방문순버(pk 키를 찾기 위한 방법)
        in_SFA_CLIENT_NO - 같은 거래처에 고객이 다른 경우, 즉 고객별 방문 내용을 확인하기 위한 정보
        --------------------------------------------------------------------------------------*/
        SELECT COUNT(*)
        INTO V_MARK
        FROM SFA_VISIT_PLANACT
        WHERE SALES_PLAN_NO LIKE in_SALES_PLAN_NO||'%'
        AND EMP_NO = in_EMP_NO
        AND SFA_SALES_SEQ = in_SFA_SALES_SEQ
        AND SFA_CLIENT_NO = in_SFA_CLIENT_NO
        AND VISIT = 'Y'  
        ;     
        
        DBMS_OUTPUT.PUT_LINE(V_MARK);        
        RETURN V_MARK;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN 0;
END;

/
