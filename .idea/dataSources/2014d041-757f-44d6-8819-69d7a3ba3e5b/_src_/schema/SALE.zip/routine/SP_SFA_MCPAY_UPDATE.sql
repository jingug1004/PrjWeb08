CREATE PROCEDURE      SP_SFA_MCPAY_UPDATE
(
    in_SAWON_ID          IN VARCHAR2, --영업사번 
    in_BT_ID             IN VARCHAR2,
    in_BT_NM             IN VARCHAR2,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 카드단말기설정 정보 저장 
 호출프로그램 : 설정>단말기설정        
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER; 
    
    SAWON_ID_NULL        EXCEPTION;
    BT_ID_NULL  EXCEPTION;
    BT_NM_NULL  EXCEPTION;
     

BEGIN
    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
        RAISE SAWON_ID_NULL;
    END IF;
    
    IF in_BT_ID IS NULL OR TRIM(in_BT_ID) = '' THEN
        RAISE BT_ID_NULL;
    END IF;
    
    IF in_BT_NM IS NULL OR TRIM(in_BT_NM) = '' THEN
        RAISE BT_NM_NULL;
    END IF;
  
   SELECT COUNT(*) 
     INTO v_num
     FROM SALE0007  
    WHERE SAWON_ID = in_SAWON_ID;

    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '사원 정보가 존재하지 않습니다.';
    ELSIF (v_num = 1) THEN
        out_CODE := 0;
        out_MSG := '사원 정보 확인완료';
        
        UPDATE SALE0007
           SET BT_NM = in_BT_NM
              ,BT_ID = in_BT_ID
         WHERE SAWON_ID   = in_SAWON_ID; 
             
        out_CODE := 0;
        out_MSG := '카드단말기 정보를 저장하였습니다'; 
            
    END IF;
  
EXCEPTION
WHEN SAWON_ID_NULL THEN
   out_CODE := 101;
   out_MSG := '사원ID가 누락되었습니다.';  
WHEN BT_NM_NULL THEN
   out_CODE := 102;
   out_MSG := 'BT 기기명을 입력하십시오.';  
WHEN BT_ID_NULL THEN
   out_CODE := 103;
   out_MSG := 'BT 아이디를 입력하십시오.';  
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
