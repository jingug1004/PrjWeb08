CREATE function      fn_get_prod_zero_cust_nm(
       v_codel in varchar2, 
       v_code2 in varchar2, 
       v_code3 in varchar2) 
   return varchar2 
AS 
   v_cust_nm varchar2(4000) ;
     
begin 

    select REGEXP_REPLACE(XMLAGG(XMLELEMENT(C,cust_nm)).GETSTRINGVAL(), '<[C/]+>', ' ')        
      into v_cust_nm
      from (
              select (select cust_nm from sale0003 where cust_id = c.cust_id )||'('||sum(a.qty)||')' as cust_nm
                from sale0208_1 a
                    ,sale0208 b
                    ,sale0207 c
               where a.deal_no = b.deal_no
                 and a.item_id = b.item_id
                 and a.input_seq = b.input_seq
                 and b.deal_no = c.deal_no
                 and a.deal_no like v_codel||'%'
                 and a.item_id = v_code2
                 and a.prod_no = v_code3
               group by c.cust_id
             );          

 return v_cust_nm;

end fn_get_prod_zero_cust_nm;

/
