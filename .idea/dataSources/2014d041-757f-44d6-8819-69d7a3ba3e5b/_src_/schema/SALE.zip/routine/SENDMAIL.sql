CREATE PROCEDURE      SENDMAIL 
(pSender    VARCHAR2,
 pRecipient VARCHAR2,
 pSubject   VARCHAR2,
 pMessage   VARCHAR2
) IS

mailhost  CONSTANT VARCHAR2(30) := '59.150.42.21';
crlf      CONSTANT VARCHAR2(2):= CHR(13) || CHR(10);
mesg      VARCHAR2(1000);
mail_conn utl_smtp.connection;

ERROR1 exception; 

/*-------------------------------------------------------------------
기능: 인자로 들어온 값으로 메일을 발송한다.
호출:
      이 프로시져가 utl_smtp.mail(mail_conn, pSender);
      부분에서 에러가 발생하는데
      아마도 java가 설치되지 않아서 인듯함.
     참조사이트
       http://psoug.org/reference/utl_smtp.html
      
-------------------------------------------------------------------*/    

BEGIN

   BEGIN 
        mail_conn := utl_smtp.open_connection(mailhost, 25);
   EXCEPTION WHEN OTHERS THEN  
        RAISE  ERROR1;
   END;

   mesg := 'Date: ' ||
        TO_CHAR( SYSDATE, 'dd Mon yy hh24:mi:ss') || crlf ||
           'From: <'|| pSender ||'>' || crlf ||
           'Subject: '|| pSubject || crlf ||
           'To: '||pRecipient || crlf || '' || crlf || pMessage;

   BEGIN 
        utl_smtp.helo(mail_conn, mailhost);
   EXCEPTION WHEN OTHERS THEN  
        RAISE  ERROR1;
   END;
   
   BEGIN 
        utl_smtp.mail(mail_conn, pSender);
   EXCEPTION WHEN OTHERS THEN  
        RAISE  ERROR1;
   END;
   
   BEGIN 
        utl_smtp.rcpt(mail_conn, pRecipient);
   EXCEPTION WHEN OTHERS THEN  
        RAISE  ERROR1;
   END;
   
   
   BEGIN 
        utl_smtp.data(mail_conn, mesg);
   EXCEPTION WHEN OTHERS THEN  
        RAISE  ERROR1;
   END;
   
   BEGIN 
        utl_smtp.quit(mail_conn); 
   EXCEPTION WHEN OTHERS THEN  
        RAISE  ERROR1;
   END; 
   
EXCEPTION
  WHEN ERROR1 THEN
    NULL; 
  WHEN OTHERS THEN
    NULL; 
    
END;

/
