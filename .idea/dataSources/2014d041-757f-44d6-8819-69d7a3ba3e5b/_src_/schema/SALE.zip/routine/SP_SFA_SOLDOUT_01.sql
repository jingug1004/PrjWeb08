CREATE PROCEDURE      SP_SFA_SOLDOUT_01
(
    in_ITEM_CD           IN  VARCHAR2,   -- 제품코드
    in_ITEM_NM           IN  VARCHAR2,   -- 제품 명
    in_REG_DATE         IN  VARCHAR2,   -- 조회시각  type yyyymmdd
    out_CODE              OUT NUMBER,
    out_MSG                OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
        /*---------------------------------------------------------------------------
        프로그램명   : 품절현황 
        호출프로그램 : state.soldout        
        ---------------------------------------------------------------------------*/    

        v_num                NUMBER;
    
BEGIN
    
        SELECT COUNT(*)
        INTO v_num
        FROM SALE0705_1 A
                 ,SALE0004 B
        WHERE A.ITEM_ID = B.ITEM_ID  
        AND A.ITEM_ID LIKE '%'||NVL(in_ITEM_CD, '%')||'%'
        AND B.ITEM_NM  LIKE '%'||NVL(in_ITEM_NM, '%')||'%'
        AND SUBSTR(A.REG_DATE ,1 ,8) <= in_REG_DATE
        ;
    
        out_COUNT := v_num;
        
        IF (v_num = 0) THEN
                out_CODE := 1;
                out_MSG := '검색내용이 없습니다.';
        ELSIF (v_num >= 1) THEN
                out_CODE := 0;
                out_MSG := '검색 확인완료';    
         
                OPEN out_RESULT FOR
                        SELECT A.ITEM_ID AS out_ITEM_ID,        -- 제품코드
                                    B.ITEM_NM AS out_ITEM_NM,        -- 제품명
                                    B.STANDARD AS out_STANDARD,           -- 규격                
                                    A.DUE_DATE AS out_DUE_DATE,  --입고예정일
                                    A.EXPLANATION AS out_EXPLANATION,   --비고
                                    SUBSTR(A.REG_DATE ,1 ,8) AS out_REG_DATE            
                        FROM SALE0705_1 A
                                ,SALE0004 B
                        WHERE A.ITEM_ID = B.ITEM_ID 
                        AND A.ITEM_ID LIKE '%'||NVL(in_ITEM_CD, '%')||'%'
                        AND B.ITEM_NM  LIKE '%'||NVL(in_ITEM_NM, '%')||'%'
                        AND SUBSTR(A.REG_DATE ,1 ,8) <= in_REG_DATE
                        ORDER BY A.DUE_DATE DESC ,B.ITEM_NM 
                        ;
        END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
