CREATE PROCEDURE      P_SUGUMPRO
              ( AS_YMDF IN  VARCHAR2,
                AS_YMDT IN  VARCHAR2,
                AS_CUST_IDF VARCHAR2,
                AS_CUST_IDT VARCHAR2
              )
                
IS
 /* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
 /* ************************
 ******************************************************* */
 /*   TITLE        :  거래처(3******,4******)별 수금%를 임시테이블에 저장           */
 /*   PROJECT      :  영업관리부                                                    */
 /*   AUTHOR       :                                                                */
 /*   PROGRAM_ID   :  P_DOCYCLE                                                     */
 /*   HISTORY      :  2011.01.25(화)                                                */
 /*   PROCESS      :  항목별로 데이타 넣는다                                        */
 /* ******************************************************************************* */
    SUGUM_YMDT   VARCHAR2(8);
    T_CUST_ID    VARCHAR2(10);
    T_REAMT      NUMBER;
    T_CHGCNT     NUMBER;
    PRO18_DATEF  DATE;
    PRO18_DATET  DATE;
    PRO12_DATEF  DATE;
    PRO12_DATET  DATE;
    PRO06_DATEF  DATE;
    PRO06_DATET  DATE;

    T_DEALNOF    VARCHAR2(14);
    T_DEALNOT    VARCHAR2(14);
    T_INPUTSEQF  VARCHAR2(14);
    T_INPUTSEQT  VARCHAR2(14);
    T_REAMTF     NUMBER;
    T_REAMTT     NUMBER;
    
    T_CNT        NUMBER;
    
    T_SALE_AMT   NUMBER;
    T_SUGUM_AMT  NUMBER;

    VN_BEFORE_AMT NUMBER; 
    VN_SUGUM_AMT  NUMBER;
    VN_AMT18      NUMBER;
    VN_AMT12      NUMBER;
    VN_AMT06      NUMBER;
    VN_AMTPER18   NUMBER;
    VN_AMTPER12   NUMBER;
    VN_AMTPER06   NUMBER;
 	
    v_temp   varchar2(1000);
   CURSOR CUR1 IS
        SELECT A.CUST_ID, B.CUST_NM, A.YMD, SUM(A.CASH_AMT) CASH_AMT
          FROM (
                --기간내 현금금액
                SELECT A.CUST_ID, A.YMD, SUM(A.CASH_AMT) CASH_AMT
                  FROM SALE0401 A
                 WHERE SUBSTR(A.JUNPYO_NO,1,8) BETWEEN AS_YMDF AND AS_YMDT
                   AND A.CUST_ID BETWEEN NVL(AS_CUST_IDF,'3') AND NVL(AS_CUST_IDT,'4999999') 
                   AND A.CASH_AMT <> 0
                   AND A.JUNPYO_GB = '01' --수금인것만
                 GROUP BY A.CUST_ID, A.YMD   
                UNION ALL    
                --기간내 신용카드,압인금액 ,수기카드 
                SELECT A.CUST_ID, A.YMD, SUM(B.AMT) CASH_AMT
                  FROM SALE0401 A, SALE0402 B
                 WHERE SUBSTR(A.JUNPYO_NO,1,8) BETWEEN AS_YMDF AND AS_YMDT
                   AND A.CUST_ID BETWEEN NVL(AS_CUST_IDF,'3') AND NVL(AS_CUST_IDT,'4999999') 
                   AND A.JUNPYO_NO = B.JUNPYO_NO
                   AND B.BILL_GB IN ('100','101','102') 
                   AND A.JUNPYO_GB = '01' --수금인것만
                 GROUP BY A.CUST_ID, A.YMD   
               ) A,
               SALE0003 B
         WHERE A.CUST_ID = B.CUST_ID(+)
           --AND A.CUST_ID IN ('3002589','3001170','3002359')
           AND A.CUST_ID IN ('3101009')
         GROUP BY A.CUST_ID, B.CUST_NM, A.YMD
         ORDER BY A.CUST_ID, A.YMD;  

   CURSOR CUR2 IS
        SELECT A.DEAL_NO                     DEAL_NO,
               B.INPUT_SEQ                   INPUT_SEQ,
               A.YMD                         YMD,
               B.ITEM_ID                     ITEM_ID,
               (NVL(B.AMT,0) + NVL(B.VAT,0)) AMT
          FROM SALE0207 A, SALE0208 B
         WHERE A.DEAL_NO = B.DEAL_NO
           AND A.YMD     = B.YMD
           AND A.YMD     BETWEEN TO_DATE('20080101','YYYY/MM/DD') AND TO_DATE(SUGUM_YMDT,'YYYY/MM/DD')
           AND A.CUST_ID = T_CUST_ID
         ORDER BY 1 DESC,2 DESC;
         
 BEGIN
    --DELETE FROM SALE0204 WHERE GUMAE_NO IN (SELECT GUMAE_NO FROM SUGUMPRO WHERE CDATEF >= AS_YMDF AND CDATET <= AS_YMDT AND CUST_ID BETWEEN NVL(AS_CUST_IDF,'3') AND NVL(AS_CUST_IDT,'4999999'));

    --DELETE FROM SALE0203 WHERE GUMAE_NO IN (SELECT GUMAE_NO FROM SUGUMPRO WHERE CDATEF >= AS_YMDF AND CDATET <= AS_YMDT AND CUST_ID BETWEEN NVL(AS_CUST_IDF,'3') AND NVL(AS_CUST_IDT,'4999999'));
    
    --작업전 해당기간내에 전표생성건이 있으면 작업불가.
    SELECT COUNT(*)
      INTO T_CNT
      FROM SUGUMPRO
     WHERE CDATEF >= AS_YMDF AND CDATET <= AS_YMDT
       AND GUMAE_NO IS NOT NULL;
    
    IF T_CNT > 0 THEN
       RAISE_APPLICATION_ERROR(-20001, '해당기간내에 내역에 전표생성건이 있습니다. 확인바랍니다.');
       RETURN;
    END IF;
       
    --해당기간내 자료를 작업전 삭제한다.
    DELETE FROM SUGUMPRO WHERE CDATEF >= AS_YMDF AND CDATET <= AS_YMDT AND CUST_ID BETWEEN NVL(AS_CUST_IDF,'3') AND NVL(AS_CUST_IDT,'4999999');
     
    FOR C1 IN CUR1 LOOP
        T_CUST_ID  := C1.CUST_ID;                 --거래처코드 
        SUGUM_YMDT := TO_CHAR(C1.YMD,'YYYYMMDD'); --수금일자 

        --현재잔액을 구한다....
        SELECT MAX(NVL(B.BEFORE_AMT,0)) + SUM(NVL(A.AMT,0) + NVL(A.VAT,0) - NVL(A.SUKUM,0)) REAMT
          INTO T_REAMT
          FROM (
                SELECT A.CUST_ID                     CUST_ID,
                       B.AMT                         AMT,
                       B.VAT                         VAT,
                       0                             SUKUM               
                  FROM SALE0207 A, 
                       SALE0208 B
                 WHERE A.DEAL_NO = B.DEAL_NO
                   AND A.YMD     = B.YMD
                   AND TO_CHAR(A.YMD,'YYYYMMDD') BETWEEN AS_YMDF AND SUGUM_YMDT
                   AND A.CUST_ID = T_CUST_ID
                UNION ALL /*  수금(할인) 내역 */
                SELECT A.CUST_ID                     CUST_ID,
                       0                             AMT,
                       0                             VAT,
                       CASH_AMT                      SUKUM
                  FROM SALE0401 A
                 WHERE TO_CHAR(A.YMD,'YYYYMMDD') BETWEEN AS_YMDF AND SUGUM_YMDT
                   AND A.CUST_ID   = T_CUST_ID
                   AND A.CASH_AMT <> 0
                UNION ALL
                SELECT A.CUST_ID                     CUST_ID,
                       0                             AMT,
                       0                             VAT,
                       B.AMT                         SUKUM
                  FROM SALE0402  B,
                       SALE0401  A
                 WHERE TO_CHAR(A.YMD,'YYYYMMDD') BETWEEN AS_YMDF AND SUGUM_YMDT
                   AND A.JUNPYO_NO = B.JUNPYO_NO
                   AND A.CUST_ID   = T_CUST_ID
               ) A,
               (SELECT CUST_ID                  CUST_ID,
                       NVL(SUM(BEFORE_AMT),0)   BEFORE_AMT
                  FROM (SELECT CUST_ID,                   /*전월 잔액 */
                               BEFORE_AMT      BEFORE_AMT
                          FROM SALE0306
                         WHERE CUST_ID = T_CUST_ID
                           AND YMD     = TO_DATE(SUBSTR(AS_YMDF,1,6)||'01','YYYY/MM/DD')
                        UNION ALL
                        SELECT CUST_ID,                  /*금월의 조회조건 기간까지의 잔액*/
                               NVL(A.AMT,0) + NVL(A.VAT,0) BEFORE_AMT
                          FROM SALE0207  B,
                               SALE0208  A
                         WHERE A.DEAL_NO = B.DEAL_NO
                           AND A.YMD     = B.YMD
                           AND B.CUST_ID = T_CUST_ID
                           AND A.YMD     >= TO_DATE(SUBSTR(AS_YMDF,1,6)||'01','YYYY/MM/DD')
                           AND A.YMD     <  TO_DATE(AS_YMDF,'YYYY/MM/DD')
                        UNION ALL
                        SELECT CUST_ID,     
                               (NVL(A.bill_amt,0) + NVL(A.cash_amt,0))*-1 BEFORE_AMT
                          FROM SALE0401  A
                         WHERE A.CUST_ID = T_CUST_ID
                           AND A.YMD     >= TO_DATE(SUBSTR(AS_YMDF,1,6)||'01','YYYY/MM/DD')
                           AND A.YMD     <  TO_DATE(AS_YMDF,'YYYY/MM/DD'))
                 GROUP BY CUST_ID  
               ) B ;

        --전월잔액을 구한다....
        SELECT SUM(BEFORE_AMT)  BEFORE_AMT
          INTO VN_BEFORE_AMT
          FROM SALE0306
         WHERE CUST_ID = T_CUST_ID
           AND YMD     = TO_DATE(SUBSTR(AS_YMDF,1,6)||'01','YYYY/MM/DD');
               
        --금월판매액을 구한다......
        SELECT NVL(SUM(B.AMT),0) + NVL(SUM(B.VAT),0) SALE_AMT
          INTO T_SALE_AMT
          FROM SALE0207 A, SALE0208 B
         WHERE A.DEAL_NO = B.DEAL_NO
           AND A.YMD     = B.YMD
           AND TO_CHAR(A.YMD,'YYYYMMDD') BETWEEN SUBSTR(AS_YMDF,1,6)||'01' AND SUGUM_YMDT
           AND A.CUST_ID = T_CUST_ID;
               
        --금월수금액을 구한다......
        SELECT NVL(SUM(A.SUKUM),0) REAMT
          INTO VN_SUGUM_AMT
          FROM (
                SELECT CASH_AMT SUKUM
                  FROM SALE0401 A
                 WHERE TO_CHAR(A.YMD,'YYYYMMDD') = SUGUM_YMDT
                   AND A.CUST_ID   = T_CUST_ID
                   AND A.CASH_AMT <> 0
                UNION ALL
                SELECT B.AMT    SUKUM
                  FROM SALE0402  B,
                       SALE0401  A
                 WHERE TO_CHAR(A.YMD,'YYYYMMDD') = SUGUM_YMDT
                   AND A.JUNPYO_NO = B.JUNPYO_NO
                   AND A.CUST_ID   = T_CUST_ID
               ) A;
               
        --수금프로에 대상이되는 판매 시작종료일자를 구한다.--------------------------------------------        
        T_CHGCNT := 1;
        FOR C2 IN CUR2 LOOP
            --반품금액은 패스....
            IF C2.AMT > 0 THEN
               T_REAMT := T_REAMT - C2.AMT;
            END IF;
            --종료일자를 구한다.
            IF T_REAMT <= 0 AND T_CHGCNT = 1 THEN
               T_DEALNOT   := C2.DEAL_NO;
               T_INPUTSEQT := C2.INPUT_SEQ;
               T_REAMTT    := T_REAMT * -1;       --종료일자금액에서 0이되는금액을 제외한 나머지 금액을 남긴다. 
               T_REAMT     := C1.CASH_AMT;        --수금액으로 치환한다. 
               T_REAMT     := T_REAMT - T_REAMTT; --여기서부터 수금액을 차감한다. 
               T_CHGCNT    := 2;
            END IF;
            --시작일자를 구한다.
            IF T_REAMT <= 0 AND T_CHGCNT = 2 THEN
               T_DEALNOF   := C2.DEAL_NO;
               T_INPUTSEQF := C2.INPUT_SEQ;
               T_REAMTF    := C2.AMT + T_REAMT;   --시작일자금액에서 0이되는 금액을 남긴다.
               EXIT;
            END IF;
        END LOOP;
                
        --수금프로기준일에대한 할인금액을 구한다.
        -----1.이전달에 수금이있는지 확인한다...
        SELECT NVL(SUM(A.SUKUM),0) REAMT
          INTO T_SUGUM_AMT
          FROM (
                SELECT CASH_AMT SUKUM
                  FROM SALE0401 A
                 WHERE TO_CHAR(A.YMD,'YYYYMM') = TO_CHAR(ADD_MONTHS(TO_DATE(AS_YMDF,'YYYY-MM-DD'),-1),'YYYYMM')
                   AND A.CUST_ID   = T_CUST_ID
                   AND A.CASH_AMT <> 0
                UNION ALL
                SELECT B.AMT    SUKUM
                  FROM SALE0402  B,
                       SALE0401  A
                 WHERE TO_CHAR(A.YMD,'YYYYMM') = TO_CHAR(ADD_MONTHS(TO_DATE(AS_YMDF,'YYYY-MM-DD'),-1),'YYYYMM')
                   AND A.JUNPYO_NO = B.JUNPYO_NO
                   AND A.CUST_ID   = T_CUST_ID
               ) A;
        PRO18_DATEF := TO_DATE(SUGUM_YMDT, 'YYYY-MM-DD') - 1;
        IF T_SUGUM_AMT > 0 THEN
           PRO18_DATET := ADD_MONTHS(PRO18_DATEF - 15,-1);
        ELSE
           PRO18_DATET := ADD_MONTHS(PRO18_DATEF,-1);
        END IF;
        VN_AMT18    := 0;        
        VN_AMT12    := 0;        
        VN_AMT06    := 0;        

        SELECT COUNT(*) 
          INTO T_CNT
          FROM (
                SELECT A.YMD
                  FROM SALE0207 A, SALE0208 B
                 WHERE A.DEAL_NO = B.DEAL_NO
                   AND A.YMD     = B.YMD
                   AND A.CUST_ID = T_CUST_ID  
                   AND A.DEAL_NO||B.INPUT_SEQ BETWEEN T_DEALNOF||T_INPUTSEQF AND T_DEALNOT||T_INPUTSEQT
                   AND NVL(B.AMT,0) > 0 --반품은 제외 
               ) A
         WHERE A.YMD BETWEEN PRO18_DATET AND PRO18_DATEF;

        IF T_CNT > 0 THEN --1.8%에 해당 
           PRO12_DATEF := PRO18_DATET - 1; 
           PRO12_DATET := ADD_MONTHS(PRO18_DATEF,-2);
           PRO06_DATEF := PRO12_DATET - 1; 
           PRO06_DATET := ADD_MONTHS(PRO18_DATEF,-3); --T_REAMTF

           SELECT NVL(SUM(A.AMT),0)
             INTO VN_AMT18
             FROM (
                   SELECT A.YMD,
                          DECODE(A.DEAL_NO||B.INPUT_SEQ,T_DEALNOF||T_INPUTSEQF, T_REAMTF, 
                          DECODE(A.DEAL_NO||B.INPUT_SEQ,T_DEALNOT||T_INPUTSEQT, T_REAMTT, (NVL(B.AMT,0) + NVL(B.VAT,0)))) AMT
                     FROM SALE0207 A, SALE0208 B
                    WHERE A.DEAL_NO = B.DEAL_NO
                      AND A.YMD     = B.YMD
                      AND A.CUST_ID = T_CUST_ID  
                      AND A.DEAL_NO||B.INPUT_SEQ BETWEEN T_DEALNOF||T_INPUTSEQF AND T_DEALNOT||T_INPUTSEQT
                      AND A.DEAL_GB LIKE '0%'
                  ) A
            WHERE A.YMD BETWEEN PRO18_DATET AND PRO18_DATEF;
           
           SELECT NVL(SUM(A.AMT),0)
             INTO VN_AMT12
             FROM (
                   SELECT A.YMD,
                          DECODE(A.DEAL_NO||B.INPUT_SEQ,T_DEALNOF||T_INPUTSEQF, T_REAMTF, 
                          DECODE(A.DEAL_NO||B.INPUT_SEQ,T_DEALNOT||T_INPUTSEQT, T_REAMTT, (NVL(B.AMT,0) + NVL(B.VAT,0)))) AMT
                     FROM SALE0207 A, SALE0208 B
                    WHERE A.DEAL_NO = B.DEAL_NO
                      AND A.YMD     = B.YMD
                      AND A.CUST_ID = T_CUST_ID  
                      AND A.DEAL_NO||B.INPUT_SEQ BETWEEN T_DEALNOF||T_INPUTSEQF AND T_DEALNOT||T_INPUTSEQT
                      AND A.DEAL_GB LIKE '0%'
                  ) A
            WHERE A.YMD BETWEEN PRO12_DATET AND PRO12_DATEF;
           
           SELECT NVL(SUM(A.AMT),0)
             INTO VN_AMT06
             FROM (
                   SELECT A.YMD,
                          DECODE(A.DEAL_NO||B.INPUT_SEQ,T_DEALNOF||T_INPUTSEQF, T_REAMTF, 
                          DECODE(A.DEAL_NO||B.INPUT_SEQ,T_DEALNOT||T_INPUTSEQT, T_REAMTT, (NVL(B.AMT,0) + NVL(B.VAT,0)))) AMT
                     FROM SALE0207 A, SALE0208 B
                    WHERE A.DEAL_NO = B.DEAL_NO
                      AND A.YMD     = B.YMD
                      AND A.CUST_ID = T_CUST_ID  
                      AND A.DEAL_NO||B.INPUT_SEQ BETWEEN T_DEALNOF||T_INPUTSEQF AND T_DEALNOT||T_INPUTSEQT
                      AND A.DEAL_GB LIKE '0%'
                  ) A
            WHERE A.YMD BETWEEN PRO06_DATET AND PRO06_DATEF;

        ELSE

/*차후 참조용.......
           PRO12_DATEF := ADD_MONTHS(PRO18_DATEF,-1) - 1;
           PRO12_DATET := ADD_MONTHS(PRO18_DATEF,-2);
           PRO06_DATEF := PRO12_DATET - 1; 
           PRO06_DATET := ADD_MONTHS(PRO18_DATEF,-3);
*/
/*
           PRO12_DATEF := '20101027';
           PRO12_DATET := '20100927';
           PRO06_DATEF := '20100926'; 
           PRO06_DATET := '20100826';
*/
           PRO12_DATEF := ADD_MONTHS(PRO18_DATEF,-1) - 1;
           PRO12_DATET := ADD_MONTHS(PRO18_DATEF,-2);
           PRO06_DATEF := PRO12_DATET - 1; 
           PRO06_DATET := ADD_MONTHS(PRO18_DATEF,-3);

           SELECT NVL(SUM(A.AMT),0)
             INTO VN_AMT12
             FROM (
                   SELECT A.YMD,
                          DECODE(A.DEAL_NO||B.INPUT_SEQ,T_DEALNOF||T_INPUTSEQF, T_REAMTF, 
                          DECODE(A.DEAL_NO||B.INPUT_SEQ,T_DEALNOT||T_INPUTSEQT, T_REAMTT, (NVL(B.AMT,0) + NVL(B.VAT,0)))) AMT
                     FROM SALE0207 A, SALE0208 B
                    WHERE A.DEAL_NO = B.DEAL_NO
                      AND A.YMD     = B.YMD
                      AND A.CUST_ID = T_CUST_ID  
                      AND A.DEAL_NO||B.INPUT_SEQ BETWEEN T_DEALNOF||T_INPUTSEQF AND T_DEALNOT||T_INPUTSEQT
                      AND A.DEAL_GB LIKE '0%'
                  ) A
            WHERE A.YMD BETWEEN PRO12_DATET AND PRO12_DATEF;
           
           SELECT NVL(SUM(A.AMT),0)
             INTO VN_AMT06
             FROM (
                   SELECT A.YMD,
                          DECODE(A.DEAL_NO||B.INPUT_SEQ,T_DEALNOF||T_INPUTSEQF, T_REAMTF, 
                          DECODE(A.DEAL_NO||B.INPUT_SEQ,T_DEALNOT||T_INPUTSEQT, T_REAMTT, (NVL(B.AMT,0) + NVL(B.VAT,0)))) AMT
                     FROM SALE0207 A, SALE0208 B
                    WHERE A.DEAL_NO = B.DEAL_NO
                      AND A.YMD     = B.YMD
                      AND A.CUST_ID = T_CUST_ID  
                      AND A.DEAL_NO||B.INPUT_SEQ BETWEEN T_DEALNOF||T_INPUTSEQF AND T_DEALNOT||T_INPUTSEQT
                      AND A.DEAL_GB LIKE '0%'
                  ) A
            WHERE A.YMD BETWEEN PRO06_DATET AND PRO06_DATEF;

        END IF;
        
        VN_AMTPER18 := VN_AMT18 * 0.018;
        VN_AMTPER12 := VN_AMT12 * 0.012;
        VN_AMTPER06 := VN_AMT06 * 0.006;
        
        --수금프로테이블에 저장한다.
        --begin
        INSERT INTO SALE.SUGUMPRO (CDATEF,      CDATET,      CUST_ID,     CUST_NM,    YMD,
                                   REAMT,       SALE_AMT,    SUGUM_AMT,   SUGUM_GB,        
                                   AMT01,       AMT02,       AMT03,     
                                   AMTPER01,    AMTPER02,    AMTPER03,     
                                   BIGO) 
                           VALUES (AS_YMDF,        AS_YMDT,     T_CUST_ID,   C1.CUST_NM, SUGUM_YMDT, 
                                   VN_BEFORE_AMT,  T_SALE_AMT,  VN_SUGUM_AMT, '',
                                   VN_AMT18,       VN_AMT12,    VN_AMT06, 
                                   VN_AMTPER18,    VN_AMTPER12, VN_AMTPER06, 
                                   '');
            
        --exception when others then    2013.05.24 : 4월분 수기카드분이 반영이 안되어 수기카드만 따로 돌리다가 4월에 이미 존재하는 자료가 있는 거래처를 찾기위해 잠시 넣은 로직임.          
          --v_temp :=    SUBSTRB('오류!'||SQLCODE||'/'||SQLERRM,1,250);                      
          --insert into SFA_SP_CALLED_HIST values ('P_SUGUMPRO','111',sysdate,'CUST_ID:'||T_CUST_ID||'/CUST_NM:'||C1.CUST_NM);                                                             
        --end;
        
    END LOOP;
    
    COMMIT;
    
    EXCEPTION
       WHEN OTHERS THEN
          ROLLBACK;
          RAISE_APPLICATION_ERROR(-20001, SUBSTRB('오류!'||SQLCODE||'/'||SQLERRM,1,250)||'###'||T_CUST_ID) ;
   
 END P_SUGUMPRO;
/
