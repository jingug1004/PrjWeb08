CREATE PROCEDURE      SP_SFA_COMMON_02_105
(
    in_GUBUN             IN  NUMBER,    -- 1:코드, 2:거래처명
    in_ITEM              IN  VARCHAR2,  -- 거래처 코드/명
    in_DEPT_CD           IN  VARCHAR2,  -- 부서코드
    in_SAWON_ID          IN  VARCHAR2,  -- 사원코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처 검색 팝업 
 호출프로그램 : 주문서등록의 거래처선택을 제외한 모든 거래처선택팝업
                110 버전으로 대체됨          
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_pda_auth          VARCHAR2(1);  --영업시스템권한  A:전체,P-개인,D-부서
    v_insa_sawon_id     VARCHAR2(7);
    v_insa_dept_cd      VARCHAR2(4);
    v_assgn_cd          VARCHAR2(5);
    
    GUBUN_NULL           EXCEPTION;
BEGIN

    
    IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
        RAISE GUBUN_NULL;
    END IF;    
     
    --로그인사원의 인사사번   
    select pda_auth,insa_sawon_id into v_pda_auth, v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID --and gubun = 'Y' CHOE20130123
    ;
    
    --로그인사원이 팀원인지,팀원이아닌 본부장,팀장인지 파악
    select decode(v_pda_auth,'A','27000',assgn_cd) into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    
   --인사기본테이블에서 총괄팀장 이면 한레벨 상위부서코드를 찾고 팀장이면 자기부서를 찾는다.
    if v_assgn_cd = '27010' or v_assgn_cd = '27020' then --본부장,총괄팀장
        select dept_cd
          into v_insa_dept_cd  
          from hr_co_depart_0 
         where use_yn = 'Y' and level = 2
       connect by dept_cd = prior up_dept_cd start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id);
                       
    elsif v_assgn_cd = '27030' then --팀장
        select dept_cd into v_insa_dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    end if;    
     
    --admin은 모든 부서찾기 가능 ,팀원이면 본인의 부서, 본부장,총괄팀장 또는 팀장이면 하위모든 사원의 부서를 찾는다.
    SELECT COUNT(*)
      INTO v_num
      FROM (SELECT *
              FROM (SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE    
                     WHERE EMP_NO in (  select sawon_id --본부장,총괄팀장,팀장인경우 하위 모든 사원(영업사원테이블)
                                          from sale0007 
                                         where insa_sawon_id in (
                                                                select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                 where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                    connect by prior dept_cd = up_dept_cd
                                                                                      start with dept_cd = v_insa_dept_cd
                                                                                  )
                                                                   --and ENGAG_DIV in ('70010','70030') --재직,휴직 CHOE20130123
                                                                )
                                          --and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사) CHOE20130123
                                          union
                                          select sawon_id
                                          from sale0007
                                          where sawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)
                                     )
                       AND DECODE(in_GUBUN, 1, TO_CHAR(SFA_SALES_NO), TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                       AND CUST_STAT_GB IN ('01') --주문거래처
                    UNION
                     SELECT A.SFA_SALES_SEQ
                      FROM SFA_SALES_CODE_SAWON A
                          ,SFA_SALES_CODE B
                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                       AND A.EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                          from sale0007 
                                         where insa_sawon_id in (
                                                                select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                 where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                    connect by prior dept_cd = up_dept_cd
                                                                                      start with dept_cd = v_insa_dept_cd
                                                                                   )
                                                                   --and ENGAG_DIV in ('70010','70030') --재직,휴직 CHOE20130123
                                                                )
                                          --and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사) CHOE20130123
                                          union
                                          select sawon_id
                                          from sale0007
                                          where sawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)
                                     )
                       AND DECODE(in_GUBUN, 1, TO_CHAR(B.SFA_SALES_NO), B.TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                       AND A.REQ_GB  = '1'  --활동거래처
                       AND A.OK_STAT = '2'  --승인
                   )
             WHERE v_assgn_cd in ('27010','27020','27030') --본부장,총괄팀장,팀장
            UNION ALL
            SELECT *
              FROM (SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE    
                     WHERE EMP_NO      IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) --LIKE  NVL(in_SAWON_ID, '%')
                       AND DECODE(in_GUBUN, 1, TO_CHAR(SFA_SALES_NO), TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                       AND CUST_STAT_GB IN ('01') --주문거래처
                    UNION
                     SELECT A.SFA_SALES_SEQ
                      FROM SFA_SALES_CODE_SAWON A
                          ,SFA_SALES_CODE B
                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                       AND A.EMP_NO      IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) --LIKE  NVL(in_SAWON_ID, '%')
                       AND DECODE(in_GUBUN, 1, TO_CHAR(B.SFA_SALES_NO), B.TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                       AND A.REQ_GB  = '1'  --활동거래처
                       AND A.OK_STAT = '2'  --승인
                   ) 
             WHERE v_assgn_cd = '27040' --팀원이면
            UNION ALL
            SELECT *
              FROM (SELECT SFA_SALES_SEQ
                      FROM SFA_SALES_CODE    
                     WHERE DECODE(in_GUBUN, 1, TO_CHAR(SFA_SALES_NO), TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                       AND CUST_STAT_GB IN ('01') --주문거래처
                    UNION
                     SELECT A.SFA_SALES_SEQ
                      FROM SFA_SALES_CODE_SAWON A
                          ,SFA_SALES_CODE B
                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                       AND DECODE(in_GUBUN, 1, TO_CHAR(B.SFA_SALES_NO), B.TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                       AND A.REQ_GB  = '1'  --활동거래처
                       AND A.OK_STAT = '2'  --승인
                   ) 
             WHERE v_assgn_cd = '27000' --admin 이면 (영업사원정보에 pda_auth가 'A' 인 사원
          );
    
-- insert into SFA_SP_CALLED_HIST values ('SP_SFA_COMMON_02','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||' / v_num:'||to_char(v_num));
 
    out_COUNT := v_num;
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT *
          FROM (
                SELECT  A.SFA_SALES_NO                                   AS out_CUST_CD    -- 거래처코드
                       ,'['||DECODE(B.USE_YN,'N',NVL(A.TRADE_NAME,' ')||'-중지됨',NVL(A.TRADE_NAME,' '))||']'        AS out_CUST_NM    -- 거래처명
                       ,A.COMPANY_ADDR1||' '||A.BUNJI1                     AS out_ADDRESS    -- 거래처 주소
                       ,'['||F_SFA_CODE_NM('CUST_STAT_GB',A.CUST_STAT_GB)||'-'||SUBSTR(F_SFA_CUST_SAWON_NM(in_SAWON_ID,A.SFA_SALES_SEQ),2)||']'  AS out_MANAGER_NM  -- 거래처담당사원명 1인이상이면 외몇명
                       ,A.SFA_SALES_SEQ  AS out_SFA_SALES_SEQ  --SFA거래처키컬럼
                  FROM SFA_SALES_CODE A, SALE0003 B
                 WHERE A.ERP_SALES_CODE = B.CUST_ID(+)
                   AND SFA_SALES_SEQ IN (   SELECT SFA_SALES_SEQ
                                              FROM (SELECT SFA_SALES_SEQ
                                                      FROM SFA_SALES_CODE    
                                                     WHERE EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                                                          from sale0007 
                                                                         where insa_sawon_id in (
                                                                                                select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                                                 where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                                                    connect by prior dept_cd = up_dept_cd
                                                                                                                      start with dept_cd = v_insa_dept_cd)
                                                                                                                        --and ENGAG_DIV in ('70010','70030') --재직,휴직 CHOE20130123
                                                                                                )
                                                                          --and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사) CHOE20130123
                                                                          union
                                                                          select sawon_id
                                                                          from sale0007
                                                                          where sawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)
                                                                     )
                                                       AND DECODE(in_GUBUN, 1, TO_CHAR(SFA_SALES_NO), TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                                       AND CUST_STAT_GB IN ('01') --주문거래처
                                                    UNION
                                                     SELECT A.SFA_SALES_SEQ
                                                      FROM SFA_SALES_CODE_SAWON A
                                                          ,SFA_SALES_CODE B
                                                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                                       AND A.EMP_NO in (  select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                                                          from sale0007 
                                                                         where insa_sawon_id in (
                                                                                                select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                                                 where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                                                    connect by prior dept_cd = up_dept_cd
                                                                                                                      start with dept_cd = v_insa_dept_cd)
                                                                                                                        --and ENGAG_DIV in ('70010','70030') --재직,휴직 CHOE20130123
                                                                                                )
                                                                          --and gubun = 'Y' -- 재직구분 ( Y - 재직 / N -퇴사) CHOE20130123
                                                                          union
                                                                          select sawon_id
                                                                          from sale0007
                                                                          where sawon_id in (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID)
                                                                     )
                                                       AND DECODE(in_GUBUN, 1, TO_CHAR(B.SFA_SALES_NO), B.TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                                       AND A.REQ_GB  = '1'  --활동거래처
                                                       AND A.OK_STAT = '2'  --승인
                                                   )
                                             WHERE v_assgn_cd in ('27010','27020','27030') --본부장,총괄팀장,팀장
                                            UNION ALL
                                            SELECT SFA_SALES_SEQ
                                              FROM (SELECT SFA_SALES_SEQ
                                                      FROM SFA_SALES_CODE    
                                                     WHERE EMP_NO      IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) --LIKE  NVL(in_SAWON_ID, '%')
                                                       AND DECODE(in_GUBUN, 1, TO_CHAR(SFA_SALES_NO), TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                                       AND CUST_STAT_GB IN ('01') --주문거래처
                                                    UNION
                                                     SELECT A.SFA_SALES_SEQ
                                                      FROM SFA_SALES_CODE_SAWON A
                                                          ,SFA_SALES_CODE B
                                                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                                       AND A.EMP_NO      IN (select sawon_id from sale0007 where sil_sawon_id = in_SAWON_ID) --LIKE  NVL(in_SAWON_ID, '%')
                                                       AND DECODE(in_GUBUN, 1, TO_CHAR(B.SFA_SALES_NO), B.TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                                       AND A.REQ_GB  = '1'  --활동거래처
                                                       AND A.OK_STAT = '2'  --승인
                                                   ) 
                                             WHERE v_assgn_cd = '27040' --팀원이면
                                            UNION ALL
                                            SELECT SFA_SALES_SEQ
                                              FROM (SELECT SFA_SALES_SEQ
                                                      FROM SFA_SALES_CODE    
                                                     WHERE DECODE(in_GUBUN, 1, TO_CHAR(SFA_SALES_NO), TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                                       AND CUST_STAT_GB IN ('01') --주문거래처
                                                    UNION
                                                     SELECT A.SFA_SALES_SEQ
                                                      FROM SFA_SALES_CODE_SAWON A
                                                          ,SFA_SALES_CODE B
                                                     WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                                       AND DECODE(in_GUBUN, 1, TO_CHAR(B.SFA_SALES_NO), B.TRADE_NAME) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                                                       AND A.REQ_GB  = '1'  --활동거래처
                                                       AND A.OK_STAT = '2'  --승인
                                                   ) 
                                             WHERE v_assgn_cd = '27000'  --admin 이면 (영업사원정보에 pda_auth가 'A' 인 사원
                                         )
         )
         ORDER BY 4,2; 
         
         
    END IF;
    
EXCEPTION
WHEN GUBUN_NULL THEN
   out_CODE := 101;
   out_MSG  := '검색 구분코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
