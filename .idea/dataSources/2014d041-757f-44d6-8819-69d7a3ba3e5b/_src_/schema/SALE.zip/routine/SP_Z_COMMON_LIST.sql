CREATE PROCEDURE      SP_Z_COMMON_LIST   
(
    in_CODE_GB           IN  VARCHAR2,  -- 그룹코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 공통코드 현황
 호출프로그램 : LoginActivity - bizCommonCodes
 최초작성   : 2012.10.01
 수정기록   : 2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
BEGIN 
     
    --공통코드는 반드시 존재하므로 SQL 로 숫자카운터 하지 않음  
    v_num := 1; 
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT cmmcode                   AS out_CODE_GB  
              ,cmmname                   AS out_CODE_GB_NM
              ,divcode                   AS out_CODE1   
              ,divname                   AS out_CODE1_NM  
          FROM ORAGMP.CMCOMMONM                    
         WHERE usediv = 'Y'      
           AND cmmcode in ('SL05','SL30','SL42','CM15','CM20','MPM21') --진료과목,고객구분,직책,유통구분,거래처상태,반품사유구분   
        UNION ALL
        SELECT 'MPM21' AS out_CODE_GB ,'' AS out_CODE_GB_NM,'00' AS out_CODE1 ,'' AS out_CODE1_NM FROM DUAL --반품사유구분 널체크위한 빈값    
        UNION ALL
        SELECT cmmcode                   AS out_CODE_GB  
              ,cmmname                   AS out_CODE_GB_NM
              ,divcode                   AS out_CODE1   
              ,divname                   AS out_CODE1_NM  
          FROM ORAGMP.CMCOMMONM                    
         WHERE usediv = 'Y'      
           AND cmmcode = 'SL18' -- 어음구분 수금구분중 어음구분에 해당되는 코드만 약속어음,가게수표,당좌수표  
           AND divcode in ('30','31','32')
        UNION ALL
        SELECT 'SL18' AS out_CODE_GB ,'' AS out_CODE_GB_NM,'00' AS out_CODE1 ,'' AS out_CODE1_NM FROM DUAL  --어음구분 널체크위한 빈값      
        UNION ALL
        SELECT 'SL18_1'                  AS out_CODE_GB  
              ,cmmname                   AS out_CODE_GB_NM
              ,divcode                   AS out_CODE1   
              ,divname                   AS out_CODE1_NM  
          FROM ORAGMP.CMCOMMONM                    
         WHERE usediv = 'Y'      
           AND cmmcode = 'SL18' -- 수금구분 
           AND divcode in ('01','10','21','30','31','32','35')
        UNION ALL
        SELECT 'SL18_1' AS out_CODE_GB ,'' AS out_CODE_GB_NM,'00' AS out_CODE1 ,'전체' AS out_CODE1_NM FROM DUAL  --수금구분 널체크위한 빈값      
        UNION ALL
        SELECT cmmcode                   AS out_CODE_GB  
              ,cmmname                   AS out_CODE_GB_NM
              ,divname                   AS out_CODE1    --코드명으로 저장하기 위함 
              ,divname                   AS out_CODE1_NM  
          FROM ORAGMP.CMCOMMONM                    
         WHERE usediv = 'Y'      
           AND cmmcode = 'SL63' -- 콜미방문사유 
        UNION ALL
        SELECT 'SL63' AS out_CODE_GB ,'' AS out_CODE_GB_NM,'00' AS out_CODE1 ,'' AS out_CODE1_NM FROM DUAL  --콜미방문사유 널체크위한 빈값    
        UNION ALL
        SELECT 'ACNT'                    AS out_CODE_GB     -- 그룹코드(회계 계정)
             , '그룹웨어 회계계정'              AS out_CODE_GB_NM  -- 그룹코드명
             , A.acccode                 AS out_CODE1       -- 계정과목
             , A.accname                 AS out_CODE1_NM    -- 사용과목명
          FROM (SELECT acccode,accname,'식당,술집'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '복리후생비%'  UNION ALL
                SELECT acccode,accname,'주유소,차수리,교통카드충전,하이패스'    AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '차량유지비%'  UNION ALL
                SELECT acccode,accname,'교통비(버스,기차,비행기),숙박비,주차비' AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '여비교통비%'  UNION ALL
                SELECT acccode,accname,'가전제품매장,철물점 등'            AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '소모품비%'    UNION ALL
                SELECT acccode,accname,'회의비'                     AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '회의비%'      UNION ALL
                SELECT acccode,accname,'교육훈련비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '교육훈련비%'  UNION ALL
                SELECT acccode,accname,'도서인쇄비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '도서인쇄비%'  UNION ALL
                SELECT acccode,accname,'운반비'                     AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '운반비%'      UNION ALL
                SELECT acccode,accname,'철도청,반환수수료'               AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '지급수수료%'  UNION ALL
                SELECT acccode,accname,'지급수수료'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '집기비품%'    UNION ALL
                SELECT acccode,accname,'판매촉진비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '판매촉진비%'  UNION ALL
                SELECT acccode,accname,'통신비'                     AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '통신비%'      UNION ALL
                SELECT acccode,accname,'광고선전비'                   AS BIGO FROM oragmp.acaccm  WHERE accname LIKE '광고선전비%'
                )                A,            
                oragmp.acaccm   B
          WHERE B.acccode = A.acccode 
            AND B.orduseyn = 'Y'
            AND B.acccode IN ('73300000','73310000','73110000','73120000','73220000','73550100')
         UNION ALL
         SELECT 'ACNT','그룹웨어 회계계정','','선택안함' FROM DUAL   
         ORDER BY 1, 3;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
