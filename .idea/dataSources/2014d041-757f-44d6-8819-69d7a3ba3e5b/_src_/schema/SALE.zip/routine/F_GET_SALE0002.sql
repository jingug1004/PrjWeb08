CREATE function      F_GET_SALE0002
        ( a_column        VARCHAR2  -- 가져올컬럼
        )
   RETURN VARCHAR2
AS
   user_err     exception   ;
   v_curr_jakup varchar2(100) ;
   v_curr_error varchar2(100) ;
   v_message    varchar2(250) ;

   v_rtn_value VARCHAR2(100) ;

   v_column    varchar2(20) ;
   v_dummy     varchar2(20) ;
   
BEGIN

    Begin
        v_rtn_value := ' '; 
        v_column    := LTRIM(RTRIM(a_column)) ;

        If NVL(v_column, ' ') = ' 'Then
           goto the_end;
        End if ;

        If v_column = 'CUST_NM' Then --회사명
           select nvl(CUST_NM, ' ') into v_rtn_value from SALE0002;
           
        ElsIf v_column = 'ADDR' Then --주소
           select nvl(ADDR, ' ') into v_rtn_value from SALE0002;
           
        ElsIf v_column = 'VOU_NO' Then -- 사업자번호
           select nvl(VOU_NO, ' ') into v_rtn_value from SALE0002;
           
        End If ;

        <<the_end>>

        RETURN v_rtn_value;

    EXCEPTION WHEN user_err THEN
                   RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_jakup||v_curr_error,1,250));
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_jakup||v_curr_error||SQLERRM,1,250));
    END ;

END;
/
