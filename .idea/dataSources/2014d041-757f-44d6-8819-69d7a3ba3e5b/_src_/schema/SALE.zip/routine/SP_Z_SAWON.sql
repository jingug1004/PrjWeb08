CREATE PROCEDURE      SP_Z_SAWON
(
    in_PART_CD           IN  VARCHAR2,      -- PART 코드--넘어오지만 사용하지 않음 
    in_DEPT_CD           IN  VARCHAR2,      -- 부서코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : PART별 부서별 사원 검색
 호출프로그램 : 실적현황에서 부서선택시 사원 spinner 조회
           수금현황에서 팀원옵션버튼 선택시 spinner 조회
 수정기록 : 
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_temp               VARCHAR2(10);
    v_deptcode          VARCHAR2(4);  -- 로그인사원부서
    v_assgn_cd          VARCHAR2(5);
    v_query_deptcode     VARCHAR2(4); -- 조회부서 
    v_adminloginyn      VARCHAR2(1);  -- admin 부서 로그인여부  
BEGIN


--insert into SFA_SP_CALLED_HIST values ('SP_SFA_SAWON',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_DEPT_CD,sysdate,'in_DEPT_CD:'||in_DEPT_CD||'/in_PART_CD '||in_PART_CD );
--commit;
  
   
    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.CMEMPM A
     WHERE a.plantcode = '1000'
       AND a.deptcode in (SELECT deptcode FROM ORAGMP.CMDEPTM
                          WHERE useyn = 'Y' 
                        CONNECT BY PRIOR deptcode = predeptcode START WITH plantcode = '1000' and deptcode = in_DEPT_CD)
       AND rownum = 1;
     
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        
        out_CODE := 0;
        out_MSG := '검색 확인완료';     
 
        OPEN out_RESULT FOR
        SELECT a.empcode            AS out_SAWON_ID
              ,a.empname            AS out_SAWON_NM
             -- ,a.empname||'  '||a.empcode||decode(retiredt,null,'','(퇴직)')             AS out_SAWON_NM
          FROM ORAGMP.CMEMPM A
         WHERE a.plantcode = '1000'
           AND a.deptcode in (SELECT deptcode FROM ORAGMP.CMDEPTM
                              WHERE useyn = 'Y' 
                            CONNECT BY PRIOR deptcode = predeptcode START WITH plantcode = '1000' and deptcode = in_DEPT_CD)
        ORDER BY a.gradediv,a.empname;
        
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
