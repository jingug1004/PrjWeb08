CREATE PROCEDURE      SP_Z_VISIT_NON_REASON_ACCEPT 
(
    in_SAWON_ID          IN  VARCHAR2,   
    in_CDT               IN  VARCHAR2,    
    in_STATUS               IN  VARCHAR2,    
    out_CODE             out NUMBER,
    out_MSG              out VARCHAR2,
    out_COUNT            out NUMBER,
    out_RESULT           out TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문현황
 호출프로그램 : 
 수정내역
  1.2014.04.08 KTA 위반주문 팀장승인상태를 화면에 보여주도록 수정함.    
  2.2014.12.12 KTA 수정버튼시 주문등록화면으로 넘어가면서 가지고갈 회전일 추가.  
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_deptcode           VARCHAR2(10);
    v_query_deptcode     VARCHAR2(10);
    v_assgn_cd           VARCHAR2(10);
    
BEGIN
    insert into SFA_SP_CALLED_HIST values ('SP_SFA_VISIT_NON_REASON_LIST','1',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_CDT:'||in_CDT||'/in_STATUS:'||in_STATUS );
    
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    select classdiv,deptcode into v_assgn_cd,v_deptcode from ORAGMP.CMEMPM  where empcode = in_SAWON_ID;
        
    --로그인직책이 SFA승인업무별 승인자 관리테이블에 존재하지 않으면 RETURN
    select count(*) into v_num from sfa_seonginja_info where biz_gb = '2' and jikcheck_cd = v_assgn_cd;--미방문사유승인
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '반품승인할수 있는 직책이 아닙니다. 승인을 하시려면 기획부에 직책등록을 요청하십시요';
       RETURN;
    END IF;
        
    v_query_deptcode := v_deptcode;               
    -- 조회부서:: 로그인 직책에따라 상위부서를 찾거나 본인부서를 찾는다.
    if v_assgn_cd in ('27010','27018','27023','27025','27026')  then   -- 본수장 ,부본부장, 총괄이사, 총괄지점장, 선임지점장       지점장,팀장, 임시팀장('27027','27030','27035') 은 1레벨위로 안가야 함
       select deptcode 
         into v_query_deptcode 
         from ORAGMP.CMDEPTM 
        where useyn = 'Y' and level = 2 connect by deptcode = prior predeptcode start with plantcode = '1000' and deptcode = v_deptcode;
    end if;
        
    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_VISIT_NON_REASON_LIST','1',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_CDT:'||in_CDT||'/in_STATUS:'||in_STATUS ||'/v_assgn_cd:'||v_assgn_cd||'/v_query_deptcode:'||v_query_deptcode);
    
    SELECT COUNT(*)
      INTO v_num
         FROM HANACOMM.CO_LUNARSOLARCAL A
             ,(select x.SALES_PLAN_NO,x.EMP_NO,x.REASON_GB1,x.REASON_GB2,x.REASON_GB3,x.NONVISIT_REASON,x.SEONGINJA_CONF_YN,x.COMPANY_CONF_YN,y.PLAN_CNT,y.CALL_CNT
                 from  (SELECT SALES_PLAN_NO,EMP_NO,REASON_GB1,REASON_GB2,REASON_GB3,NONVISIT_REASON,SEONGINJA_CONF_YN,COMPANY_CONF_YN FROM SFA_VISIT_NON_REASON WHERE EMP_NO in (select empcode from oragmp.cmempm  where deptcode in (select deptcode from oragmp.cmdeptm connect by prior deptcode = predeptcode and deptcode = v_query_deptcode))) x
                      ,(SELECT SALES_PLAN_NO,EMP_NO,COUNT(*) PLAN_CNT,SUM(DECODE(CALL_YN,'Y',1,0)) CALL_CNT FROM SFA_VISIT_PLANACT WHERE  SALES_PLAN_NO like ''||NVL(in_CDT, '%')||'%'   and DEPT_NO in (select deptcode from oragmp.cmdeptm connect by prior deptcode = predeptcode and deptcode = v_query_deptcode) GROUP BY SALES_PLAN_NO,EMP_NO ) y
                where x.SALES_PLAN_NO = y.SALES_PLAN_NO(+)
                  and x.EMP_NO        = y.EMP_NO(+)
              ) B
         WHERE A.SOLAR_DATE = B.SALES_PLAN_NO        
           AND A.SOLAR_DATE LIKE ''||NVL(in_CDT, '%')||'%'    
           AND B.SEONGINJA_CONF_YN like in_STATUS || '%'
           AND B.NONVISIT_REASON is not null
          AND rownum = 1
    ; 
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
    
        OPEN out_RESULT FOR
        SELECT  SUBSTR(A.SOLAR_DATE,7,2)||'('||SUBSTR(TO_CHAR(TO_DATE(SOLAR_DATE), 'day'),1,1) ||')' AS out_VISIT_DT,
              F_Z_GET_WORKDAY_STATUS(in_SAWON_ID,A.SOLAR_DATE) AS out_BIGO,  
              B.PLAN_CNT AS out_PLAN_CNT,
              B.CALL_CNT AS out_CALL_CNT,
              B.REASON_GB1 AS out_REASON1, 
              B.REASON_GB2 AS out_REASON2, 
              B.REASON_GB3 AS out_REASON3,
              B.NONVISIT_REASON AS out_REASON,
              DECODE(B.SEONGINJA_CONF_YN,'0','대기','1','승인','2','반려','')  AS out_APPR,
              A.SOLAR_DATE AS out_SOLAR,
              oragmp.fncommonnm('emp',B.EMP_NO,'') AS out_USER,
              B.EMP_NO AS out_EMPNO
         FROM HANACOMM.CO_LUNARSOLARCAL A
             ,(select x.SALES_PLAN_NO,x.EMP_NO,x.REASON_GB1,x.REASON_GB2,x.REASON_GB3,x.NONVISIT_REASON,x.SEONGINJA_CONF_YN,x.COMPANY_CONF_YN,y.PLAN_CNT,y.CALL_CNT
                 from  (SELECT SALES_PLAN_NO,EMP_NO,REASON_GB1,REASON_GB2,REASON_GB3,NONVISIT_REASON,SEONGINJA_CONF_YN,COMPANY_CONF_YN FROM SFA_VISIT_NON_REASON WHERE EMP_NO in (select empcode from oragmp.cmempm  where deptcode in (select deptcode from oragmp.cmdeptm connect by prior deptcode = predeptcode and deptcode = v_query_deptcode))) x
                      ,(SELECT SALES_PLAN_NO,EMP_NO,COUNT(*) PLAN_CNT,SUM(DECODE(CALL_YN,'Y',1,0)) CALL_CNT FROM SFA_VISIT_PLANACT WHERE  SALES_PLAN_NO like ''||NVL(in_CDT, '%')||'%'   and DEPT_NO in (select deptcode from oragmp.cmdeptm connect by prior deptcode = predeptcode and deptcode = v_query_deptcode) GROUP BY SALES_PLAN_NO,EMP_NO ) y
                where x.SALES_PLAN_NO = y.SALES_PLAN_NO(+)
                  and x.EMP_NO        = y.EMP_NO(+)
              ) B
         WHERE A.SOLAR_DATE = B.SALES_PLAN_NO       
           AND A.SOLAR_DATE LIKE ''||NVL(in_CDT, '%')||'%'    
           ORDER BY out_VISIT_DT,out_USER;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
