CREATE PROCEDURE      SP_SFA_SALES_CODE_SAWON_01 
(
    in_GUBUN         IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3)
    in_SFA_SALES_SEQ     IN  NUMBER,       -- SFA거래처 키컬럼
    in_EMP_NO            IN  VARCHAR2,     -- 요청사번
    in_REQ_GB            IN  VARCHAR2,     -- 요청구분(1-활동거래처요청,2-주문거래처요청)
    in_REQ_DT            IN  VARCHAR2,     -- 요청일자
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처요청 입력,수정,삭제
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_cust_stat_gb       VARCHAR2(2);
    
    SFA_SALES_SEQ_NULL  EXCEPTION;
    EMP_NO_NULL         EXCEPTION;
    REQ_GB_NULL         EXCEPTION;
    REQ_INSERT_ERR1     EXCEPTION;
BEGIN
    
    IF in_SFA_SALES_SEQ IS NULL OR TRIM(in_SFA_SALES_SEQ) = '' THEN
        RAISE SFA_SALES_SEQ_NULL;
    END IF;
         
    IF in_GUBUN = 1 THEN -- 등록버튼 클릭한 경우
    
        IF in_EMP_NO IS NULL OR TRIM(in_EMP_NO) = '' THEN
            RAISE EMP_NO_NULL;
        END IF;
        
        IF in_REQ_GB IS NULL OR TRIM(in_REQ_GB) = '' THEN
            RAISE REQ_GB_NULL;
        END IF;        
        
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_SALES_CODE_SAWON
         WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
           AND EMP_NO        = in_EMP_NO
           AND REQ_GB        = in_REQ_GB;    
    
        IF v_num >= 1 THEN

            SELECT COUNT(*)
              INTO v_num
              FROM SFA_SALES_CODE_SAWON
             WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
               AND EMP_NO        = in_EMP_NO
               AND REQ_GB        = in_REQ_GB
               AND OK_STAT       = '2'; --승인상태(1-대기/2-승인/3-불가)           
            IF v_num >= 1 THEN 
                out_COUNT := v_num;
                out_CODE := 1;
                out_MSG := '이 거래처는 지금 요청사원에게 승인된 상태입니다.';
                RETURN;
            END IF;
            
            -- 기존요청내용은 필요없으므로 기존요청내용을 초기화하여 다시 요청하도록 한다. 김태안
            UPDATE SFA_SALES_CODE_SAWON  
               SET REQ_GB    = in_REQ_GB
                  ,REQ_DT    = TO_CHAR(SYSDATE,'YYYYMMDD')
                  ,OK_STAT   = '1'  --승인상태(1-대기/2-승인/3-불가)
                  ,OK_DT     = NULL
                  ,NO_REASON = NULL
             WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
               AND EMP_NO        = in_EMP_NO
               AND REQ_GB        = in_REQ_GB;
                        
            out_COUNT := 0;
            out_CODE := 0;
            out_MSG := '거래처요청이 완료되었습니다1';
            
        ELSE
            
            -- 비활동거래처를 주문거래처 요청하면 안됨
            IF in_REQ_GB = '2' THEN
               SELECT CUST_STAT_GB INTO v_cust_stat_gb FROM SFA_SALES_CODE WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ;
               IF v_cust_stat_gb = '03' THEN
                  out_COUNT :=0;
                  RAISE REQ_INSERT_ERR1;
               END IF;
                    
            END IF;
            
            -- 대표자명으로 기본고객을 생성. CLIENT_GUBUN 은 1(대표)로 설정.
            INSERT INTO SFA_SALES_CODE_SAWON(SFA_SALES_SEQ,EMP_NO,REQ_GB,REQ_DT)
            VALUES(in_SFA_SALES_SEQ,in_EMP_NO,in_REQ_GB,TO_CHAR(SYSDATE,'YYYYMMDD'));
                        
            out_COUNT := 0;
            out_CODE := 0;
            out_MSG := '거래처요청이 완료되었습니다2';
        END IF;
    ELSIF in_GUBUN = 2 THEN -- 수정버튼 클릭한 경우
           
        --수정버튼 없음
        IF v_num < 1 THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '기존 등록된 거래처요청이 없습니다';
        ELSE
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '거래처 수정이 완료되었습니다';
        END IF;
        
    ELSIF in_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우
        
        --삭제버튼 없음.
        IF v_num < 1 THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '기존 등록된 거래처가 없습니다';
        ELSE
            DELETE SFA_SALES_CODE_SAWON
             WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
               AND EMP_NO        = in_EMP_NO
               AND REQ_GB        = in_REQ_GB;
             
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '거래처 삭제가 완료되었습니다';
         END IF;
   /*      
    ELSE   -- 조회처리
    
        IF in_EMP_NO IS NULL OR TRIM(in_EMP_NO) = '' THEN
            RAISE EMP_NO_NULL;
        END IF; 
        
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_SALES_CODE_SAWON
         WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
           AND EMP_NO        = in_EMP_NO;    
               
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '거래처요청 정보가 존재하지 않습니다.';
        ELSIF (v_num >= 1) THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '거래처요청 정보 확인완료';    
             
            OPEN out_RESULT FOR
            SELECT SFA_SALES_SEQ AS out_FA_SALES_SEQ
                  ,EMP_NO        AS out_MP_NO
                  ,REQ_GB        AS out_EQ_GB
                  ,REQ_DT        AS out_EQ_DT
                  ,OK_STAT       AS out_K_STAT
                  ,OK_DT         AS out_K_DT
                  ,NO_REASON     AS out_NO_REASON
              FROM SFA_SALES_CODE_SAWON
             WHERE SFA_SALES_SEQ = in_SFA_SALES_SEQ
               AND EMP_NO        = in_EMP_NO;               
        END IF;
        */
    END IF;
    
EXCEPTION
WHEN SFA_SALES_SEQ_NULL THEN
   out_CODE := 101;
   out_MSG := '거래처키컬럼이 누락되었습니다.';  
WHEN EMP_NO_NULL THEN
   out_CODE := 102;
   out_MSG := '거래처요청사번이 누락되었습니다.';  
WHEN REQ_GB_NULL THEN
   out_CODE := 103;
   out_MSG := '거래처요청구분이 누락되었습니다.';  
WHEN REQ_INSERT_ERR1 THEN
   out_CODE := 104;
   out_MSG := '비활동 거래처를 주문거래처로 요청할 수 없습니다.';  
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
