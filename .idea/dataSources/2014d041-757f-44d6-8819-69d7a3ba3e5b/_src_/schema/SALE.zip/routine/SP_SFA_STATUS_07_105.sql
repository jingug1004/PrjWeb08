CREATE PROCEDURE      SP_SFA_STATUS_07_105
(
    in_DEPT_CD           IN  VARCHAR2,    -- 부서코드
    in_SAWON_ID          IN  VARCHAR2,    -- 사원코드
    in_DT_FR             IN  VARCHAR2,    -- 기간 FROM
    in_DT_TO             IN  VARCHAR2,    -- 기간 TO
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 출퇴근현황 
 호출프로그램 :115 버전으로대체       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
    DEPT_CD_NULL         EXCEPTION;
    SAWON_ID_NULL        EXCEPTION;
    DT_NULL              EXCEPTION;
BEGIN

     --insert into SFA_SP_CALLED_HIST values ('SP_SFA_STATUS_07','1',sysdate,'in_GRAD_CD:'||in_GRAD_CD||'/in_DEPT_CD:'||in_DEPT_CD||'/in_SAWON_ID:'||in_SAWON_ID ||'/in_DT_FR:'||in_DT_FR ||'/in_DT_TO:'||in_DT_TO );


    IF in_DEPT_CD IS NULL THEN
        RAISE DEPT_CD_NULL;
    END IF;
    
    IF in_SAWON_ID IS NULL THEN
        RAISE SAWON_ID_NULL;
    END IF;
    
    IF in_DT_FR IS NULL OR in_DT_TO IS NULL THEN
        RAISE DT_NULL;
    END IF;
    
     
     SELECT COUNT(*)
      INTO v_num   
      FROM (SELECT A.EMP_NO
                 , C.DEPT_NM   
                 , B.SAWON_NM  
                 , SALES_PLAN_NO 
                 , SUBSTR(MIN(A.EMP_CALL_DTM),9,14)
                 , SUBSTR(MAX(A.EMP_CALL_DTM),9,14) 
              FROM SFA_VISIT_PLANACT A, SALE0007 B, SALE0008 C
             WHERE A.EMP_NO = B.SAWON_ID(+)
               AND B.DEPT_CD = C.DEPT_CD(+)
               AND A.SALES_PLAN_NO BETWEEN in_DT_FR AND in_DT_TO
               AND A.EMP_NO = in_SAWON_ID
             GROUP BY A.EMP_NO, C.DEPT_NM, B.SAWON_NM, SALES_PLAN_NO
            );
   
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
          
        OPEN out_RESULT FOR
        SELECT A.EMP_NO                           AS out_SAWON_ID    -- 사원ID
             , C.DEPT_NM                          AS out_DEPT_NM     -- 부서명
             , B.SAWON_NM                         AS out_SAWON_NM    -- 사원명
             , SALES_PLAN_NO
               ||'  ('||case to_char(to_date(SALES_PLAN_NO,'yyyymmdd'),'d') 
                       when '1' then '일' when '2' then '월'  when '3' then '화' when '4' then '수' 
                       when '5' then '목' when '6' then '금'  when '7' then '토' end ||')' 
               AS out_DT          -- 근무일
             , SUBSTR(MIN(A.EMP_CALL_DTM),9,14)   AS out_START_TIME  -- 출근시간
             , SUBSTR(MAX(A.EMP_CALL_DTM),9,14)   AS out_END_TIME    -- 퇴근시간
          FROM SFA_VISIT_PLANACT A, SALE0007 B, SALE0008 C
         WHERE A.EMP_NO = B.SAWON_ID(+)
           AND B.DEPT_CD = C.DEPT_CD(+)
           AND A.SALES_PLAN_NO BETWEEN in_DT_FR AND in_DT_TO
           AND A.EMP_NO = in_SAWON_ID
         GROUP BY A.EMP_NO, C.DEPT_NM, B.SAWON_NM, SALES_PLAN_NO
         ORDER BY SALES_PLAN_NO                
         ;
    END IF;
    
    
EXCEPTION
WHEN DEPT_CD_NULL THEN
   out_CODE := 102;
   out_MSG  := '부서코드가 누락되었습니다.';
WHEN SAWON_ID_NULL THEN
   out_CODE := 103;
   out_MSG  := '사원번호가 누락되었습니다.';
WHEN DT_NULL THEN
   out_CODE := 104;
   out_MSG  := '기간입력이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
