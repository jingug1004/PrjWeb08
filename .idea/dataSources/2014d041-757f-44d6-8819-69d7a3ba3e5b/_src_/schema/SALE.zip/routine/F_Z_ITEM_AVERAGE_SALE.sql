CREATE FUNCTION      F_Z_ITEM_AVERAGE_SALE  
(
    in_CUST_CD   IN VARCHAR2,
    in_RCUST_CD  IN VARCHAR2,
    in_ORDER_YMD  IN VARCHAR2,  -- 하이픈 붙어서 넘어옴 
    in_ITEM_ID   IN VARCHAR2 
) 
RETURN NUMBER IS
           
        v_jumun_limit   NUMBER;    
        v_month_sumqty  NUMBER; 
        v_month_avgqty  NUMBER; 
        
        v_cnt           NUMBER; 
        
        v_frdate         VARCHAR2(10);
        v_todate         VARCHAR2(10);
     
BEGIN

        /*----------------------------------------------------------------------------------------
        3 개월 평균 주문수량을 구한다.  
        ----------------------------------------------------------------------------------------*/
        
       
        v_frdate  := to_char(ADD_MONTHS(TO_DATE(SUBSTR(in_ORDER_YMD,1,7)||'-01','yyyy-mm-dd') ,-3),'YYYY-MM-DD');
        v_todate  := to_char(LAST_DAY(ADD_MONTHS(TO_DATE(SUBSTR(in_ORDER_YMD,1,7)||'-01','yyyy-mm-dd') ,-1)),'YYYY-MM-DD'); 

                
        SELECT COUNT(*)
          INTO v_cnt
          FROM oragmp.SLORDM a
              ,oragmp.SLORDD b
         WHERE a.orderno = b.orderno
           AND a.custcode  = in_CUST_CD
           AND a.ecustcode = in_RCUST_CD       
           AND a.statediv  = '09' --매출확정                                                  
           AND a.orderdate BETWEEN v_frdate AND v_todate       
           AND b.itemcode   = in_ITEM_ID
           ;               
                        
        IF v_cnt > 0 THEN 
                                      
              /* 주문승인된 내용 수량*/ 
              SELECT SUM(b.salqty)
                INTO v_month_sumqty
                FROM oragmp.SLORDM a
                    ,oragmp.SLORDD b
               WHERE a.orderno = b.orderno
                 AND a.custcode  = in_CUST_CD
                 AND a.ecustcode = in_RCUST_CD         
                 AND a.statediv  = '09' --매출확정                                                                
                 AND a.orderdate BETWEEN v_frdate AND v_todate 
                 AND b.itemcode  = in_ITEM_ID
           ;  
                                 
              /*  3개월 평균을 구하는 경우에는 허용한도를 곱하고 3개월로 나눠준다.*/  
              
              SELECT ROUND ((v_month_sumqty / 3) * jumun_limit )  INTO v_month_avgqty FROM oragmp.CMCUSTM WHERE custcode = in_CUST_CD;      
              
                          
        ELSE
            v_month_avgqty := 0;      
        END IF;    
        
        RETURN v_month_avgqty;

END F_Z_ITEM_AVERAGE_SALE;
/
