CREATE function      F_GET_SALE0007H_DEPT_CD
        ( A_SAWON_ID      VARCHAR2,  
          A_YMD          DATE       
        )
   RETURN VARCHAR2
AS
   user_err       exception   ;
   A_SYMD         VARCHAR2(8);
   V_TRAN_YMD_CD  VARCHAR2(14);
   V_YMD          DATE ;
   V_SYMD         VARCHAR2(8);
   V_SAWON_NM     VARCHAR2(20);
   n_rtn_value    VARCHAR2(250);
   v_curr_error   VARCHAR2(250);

/*----------------------------------------------------------------
 개요  :사원번호 와 일자를 받아서 해당시점의 사원이 속해있던 부서코드를 리턴
 작성일:2014.01.09
 작성자:김태안 
----------------------------------------------------------------*/
BEGIN
       A_SYMD := TO_CHAR(A_YMD, 'YYYYMMDD');
       
       select sawon_nm into V_SAWON_NM from sale0007 where sawon_id = A_SAWON_ID;   
       
       v_curr_error := '사번:'||NVL(A_SAWON_ID,'NULL') || '/ 일자:' || NVL(A_SYMD,'NULL');
       
        select /*+ index_desc(A IE_SALE0007H_02) */
               dept_cd
          into n_rtn_value
          from sale0007h a
         where sil_sawon_id = (select sil_sawon_id from sale0007 where sawon_id = A_SAWON_ID)
           and appl_date = (select max(appl_date) 
                              from sale0007h 
                             where sil_sawon_id = (select sil_sawon_id from sale0007 where sawon_id = A_SAWON_ID) 
                               and appl_date <= A_YMD  )
           and rownum = 1;
 
        RETURN n_rtn_value;

        EXCEPTION WHEN user_err THEN
                       RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
                  WHEN NO_DATA_FOUND THEN
                       IF A_SAWON_ID = '00000' THEN
                          RAISE_APPLICATION_ERROR(-20002,'사원정보가 매출처별단가관리 이력에 존재하지 않습니다.'|| v_curr_error);
                       ELSE
                            RAISE_APPLICATION_ERROR(-20002,A_SAWON_ID||'/'||V_SAWON_NM || '의 사원이력이 존재하지 않습니다.'  || v_curr_error);
                       END IF;
                  WHEN OTHERS THEN
                       RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;

/
