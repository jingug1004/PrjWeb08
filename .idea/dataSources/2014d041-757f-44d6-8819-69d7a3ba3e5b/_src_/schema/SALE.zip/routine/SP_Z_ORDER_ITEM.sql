CREATE PROCEDURE      SP_Z_ORDER_ITEM   
(   
    in_GUMAE_NO          IN VARCHAR2 default NULL,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문상세내역
 호출프로그램 : 주문서등록 OrderNew 에서 호출 
          주문현황 OrderList 에서 호출
          간납처주문현황 ROrderList 에서 호출   
      2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
        
 ---------------------------------------------------------------------------*/    

    v_num NUMBER;
    V_ITEM_CNT NUMBER;   
    V_GUMAE_NO VARCHAR2(20);
        
BEGIN
         
--insert into SFA_SP_CALLED_HIST values ('SP_Z_ORDER_ITEM',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_GUMAE_NO,sysdate,'in_GUMAE_NO:'||in_GUMAE_NO );
--commit; 

    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.SLORDD A
     WHERE a.orderno  = in_GUMAE_NO
    ;     
         
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
      
        out_COUNT := v_num;
        out_CODE := 0;
        out_MSG := '검색 완료';        
               
        OPEN out_RESULT FOR
        SELECT 
            (select itemname||' '||itemunit from ORAGMP.CMITEMM where itemdiv = '04' and itemcode = a.itemcode) AS out_ITEM_ID                      
           --,DECODE(NVL(a.salqty,'0') ,NVL(a.reqqty,'0') ,TO_CHAR(a.salqty) ,TO_CHAR(a.salqty))||'/'||TO_CHAR(a.reqqty)  AS out_QTY  
            ,NVL(a.reqqty,'0')||'/'||TO_CHAR(a.reqqty)  AS out_QTY  
           ,a.salprc                 AS out_DANGA   
           ,a.salamt                 AS out_AMT
           ,a.salvat                 AS out_VAT
           ,a.salamt + a.salvat      AS out_AMOUNT
        FROM ORAGMP.SLORDD A
        WHERE a.orderno = in_GUMAE_NO                        
        ORDER BY a.seq DESC
        ;
        END IF;        
    
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
