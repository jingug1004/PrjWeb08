CREATE PROCEDURE      SP_SFA_ORDER_ITEM_130   
(   
    in_GUMAE_NO          IN VARCHAR2 default NULL,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문상세내역
 호출프로그램 : 주문서등록 OrderNew 에서 호출 
                주문현황 OrderList 에서 호출
                간납처주문현황 ROrderList 에서 호출  
 작성일       : 2014.12.12
 작성자       : KTA                
 추가내역     : out_ITEM_ID  추가     

 사용하지 않음            
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
BEGIN


--INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_ITEM_130','1000',sysdate,'김태안...이프로시져 사용되는 것인지 체크하고 있음....');
    --COMMIT; 
    
    
    
    SELECT COUNT(*)
      INTO v_num
      FROM SALE_ON.SALE0204 A
     WHERE A.GUMAE_NO  = in_gumae_no;          
    
    IF v_num > 0 THEN  --선택한 주문번호로 상세내역을 조회하는 것이므로 있으면 sale_on에 있음, 없으면 sale에 있음           
    
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';        
               
            OPEN out_RESULT FOR
            SELECT 
                   A.ITEM_ID               AS out_ITEM_ID,
                   F_ITEM_NM(A.ITEM_ID)    AS out_ITEM_NM,
                   (SELECT STANDARD FROM SALE0004 WHERE ITEM_ID = A.ITEM_ID)    AS out_STANDARD,                   
                   A.QTY                   AS out_QTY,   
                   A.DANGA                 AS out_DANGA,   
                   A.AMT                   AS out_AMT,
                   A.VAT                   AS out_VAT,
                   A.AMT + A.VAT           AS out_AMOUNT
              FROM SALE_ON.SALE0204 A
             WHERE A.GUMAE_NO = in_gumae_no
               ORDER BY A.INPUT_SEQ DESC;
        END IF;
        
        
    ELSE  --선택한 주문번호로 상세내역을 조회하는 것이므로 있으면 sale_on에 있음, 없으면 sale에 있음:보통 간납처주문으로 본사에서 입력한것임.
    
        --insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDER_ITEM','1',sysdate,'in_GUMAE_NO:'||in_GUMAE_NO );
    
        SELECT COUNT(*)
          INTO v_num
          FROM SALE0204 A
         WHERE A.GUMAE_NO  = in_gumae_no;
         
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
               
            OPEN out_RESULT FOR
            SELECT 
                   F_ITEM_NM(A.ITEM_ID)    AS out_ITEM_ID,
                   A.QTY                   AS out_QTY,   
                   A.DANGA                 AS out_DANGA,   
                   A.AMT                   AS out_AMT,
                   A.VAT                   AS out_VAT,
                   A.AMT + A.VAT           AS out_AMOUNT
              FROM SALE0204 A
             WHERE A.GUMAE_NO = in_gumae_no
               ORDER BY A.INPUT_SEQ DESC;
        END IF;
    
    
    
    END IF;        
    
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
