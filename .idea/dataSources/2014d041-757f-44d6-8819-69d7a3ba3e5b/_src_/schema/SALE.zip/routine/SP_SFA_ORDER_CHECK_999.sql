CREATE PROCEDURE      SP_SFA_ORDER_CHECK_999
  (
    in_CUST_ID            IN VARCHAR2 default NULL, 
    in_flag      IN  VARCHAR2 DEFAULT NULL,
    in_ymd       IN  date,
    in_GUMAE_NO  IN  VARCHAR2 DEFAULT NULL, 
    in_INPUT_SEQ IN  VARCHAR2 DEFAULT NULL, 
    in_ITEM_ID   IN  VARCHAR2 DEFAULT NULL, 
    in_QTY       IN  VARCHAR2 DEFAULT NULL, 
    in_DANGA     IN  NUMBER DEFAULT NULL, 
    in_AMT       IN  VARCHAR2 DEFAULT NULL, 
    in_VAT       IN  VARCHAR2 DEFAULT NULL, 
    in_DC_AMT    IN  VARCHAR2 DEFAULT NULL,
    in_DC_QTY    IN  VARCHAR2 DEFAULT NULL, 
    in_DC_DANGA  IN  VARCHAR2 DEFAULT NULL,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE

  )
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문체크
 호출프로그램 :주문서등록의 수량입력후    
           
 수정기록     :
 1.20140403/ 김태안/ 위반주문 체크를 위한 수량체크 
  저장 프로시져 SP_SFA_ORDER_110 에서 수량체크를 하여 수량 초과이면 주문불가
  처리하였으나 그런 주문도 약속내용을 입력하면 주문가능하도록 로직변경하면서 
  수량체크를 하도록 함.(윤홍주 요청)
 ---------------------------------------------------------------------------*/    

      
    N_COUNT      NUMBER := 0;
    N_JAEGO      NUMBER := 0;
    V_ITEM_NM    VARCHAR2(200);
    v_use_yn     VARCHAR2(1);
    v_chul_yn    VARCHAR2(1); 

    V_ITEM_DANGA NUMBER := 0;
    V_PSB_QTY    NUMBER := 0;
    V_M_QTY      NUMBER := 0;
    V_CUST_ID    VARCHAR2(10);
    ERROR_RAISE        EXCEPTION; 

BEGIN 

    INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_CHECK_999','1000',sysdate,'김태안...이프로시져 사용되는 것인지 체크하고 있음....');
    COMMIT; 

    N_JAEGO :=0;

    if in_flag = 'I' then
        select  item_nm, use_yn, chul_yn , OUT_DANGA AS danga
        into V_ITEM_NM,v_use_yn, v_chul_yn, V_ITEM_DANGA
        from  sale.sale0004 
        where item_id = in_ITEM_ID;

        if v_use_yn != 'Y' then
            out_CODE := -20000;
            out_MSG := '<' || V_ITEM_NM || ' 사용중지 중입니다.'|| '>';
            RAISE ERROR_RAISE;
            -- raise_application_error (-20000,'<' || V_ITEM_NM || ' 사용중지 중입니다.'|| '>' );
        end if;

        if v_chul_yn = 'Y' then
            out_CODE := -20000;
            out_MSG := '<' || V_ITEM_NM || ' 출하중지 중입니다.'|| '>';
            RAISE ERROR_RAISE;
            --raise_application_error (-20000,'<' || V_ITEM_NM || ' 출하중지 중입니다.'|| '>' );
        end if;

        ------2011 03 08 DangaCheck  -- jo

        if V_ITEM_DANGA != in_DANGA then
            out_CODE := -20000;
            out_MSG := '<' || V_ITEM_NM || ' 제품정보 새로받기를 해주세요 '|| '>' ;
            RAISE ERROR_RAISE;
            --raise_application_error (-20000,'<' || V_ITEM_NM || ' 제품정보 새로받기를 해주세요 '|| '>' );
        end if;

        ------

        select count(*) 
        into n_count
        from sale.sale0305 a , sale.sale0004 b
        where a.item_id = b.item_id
        and  ymd= to_char(sysdate, 'yyyyMM')||'01' and a.item_id = in_ITEM_ID
        and store_loc = '01' ;

        if n_count >0 then

        --재고 체크
        select NVL(before_qtys,0)+ NVL(IPGO_QTYS,0) - NVL(CHULGO_QTYS,0) - NVL(CHULGO_QTYST,0) + NVL(BANPUM_QTYS,0) as ajego_qtys,
               b.item_nm
          into N_JAEGO, V_ITEM_NM
          from sale.sale0305 a , sale.sale0004 b
         where a.item_id = b.item_id
           and  ymd= to_char(sysdate, 'yyyyMM')||'01' and a.item_id = in_ITEM_ID
           and store_loc = '01' ;
           
        end if;


        if N_JAEGO <  to_number(in_QTY) then
            --raise_application_error (-20000,'<' || ' 재고가 불충분 합니다'|| '>' );
            out_CODE := -20000;
            out_MSG := '<' || V_ITEM_NM || ' (' || N_JAEGO ||  ') | ' || in_ITEM_ID || ' 재고가 불충분 합니다'|| '>' ;
            RAISE ERROR_RAISE;
            ----    raise_application_error (-20000,'<' || V_ITEM_NM || ' (' || N_JAEGO ||  ') | ' || in_ITEM_ID || ' 재고가 불충분 합니다'|| '>' );
        end if;

        --주문수량통제---------------------------------------------------------------------
       -- select CUST_ID
       --   into V_CUST_ID 
       --   from SALE_on.SALE0203
       --  where GUMAE_NO = in_GUMAE_NO;   
         V_CUST_ID :=in_CUST_ID;

        --1.개시일자부터 3개월간은 주문수량 통과
          SELECT COUNT(*)
            INTO n_count
            FROM SALE.SALE0003
           WHERE CUST_ID = V_CUST_ID
             AND in_ymd BETWEEN START_YMD AND ADD_MONTHS(START_YMD,3) ;        

          if n_count = 0 then
             --2.해당월 20개까지는 주문수량 통과
             --  향정제외(6****),아네폴빼고(43201,43215,43216,43217,43218,43256,43257) 

            SELECT ROUND(A.QTY * B.JLIMIT) - (C.MQTY + D.MQTY), C.MQTY + D.MQTY                
              INTO V_PSB_QTY, V_M_QTY
              FROM (
                      SELECT ROUND((NVL(SUM(B.QTY),0)/3)) QTY
                         FROM SALE.SALE0203 A, SALE.SALE0204 B
                        WHERE A.CUST_ID  = V_CUST_ID
                          AND A.YMD      < TO_DATE(SUBSTR(in_ymd,1,6)||'01') 
                          AND A.YMD      >= ADD_MONTHS(TO_DATE(SUBSTR(in_ymd,1,6)||'01') ,-3)
                          AND A.GUMAE_NO = B.GUMAE_NO 
                          AND B.ITEM_ID  = in_ITEM_ID
                     ) A,
                     (
                      SELECT (JUMUN_LIMIT /100) JLIMIT 
                        FROM SALE.SALE0003 
                       WHERE CUST_ID = V_CUST_ID
                     ) B,
                     (
                      SELECT NVL(SUM(B.QTY),0) MQTY
                         FROM SALE.SALE0203 A, SALE.SALE0204 B
                        WHERE A.CUST_ID  = V_CUST_ID
                          AND A.YMD      >= TO_DATE(SUBSTR(in_ymd,1,6)||'01')  
                          AND A.YMD      <= LAST_DAY(SUBSTR(in_ymd,1,6)||'01') 
                          AND A.GUMAE_NO = B.GUMAE_NO 
                          AND B.ITEM_ID  = in_ITEM_ID
                     ) C,
                     (
                      SELECT NVL(SUM(B.QTY),0) MQTY
                         FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
                        WHERE A.CUST_ID    = V_CUST_ID
                          AND A.YMD        >= TO_DATE(SUBSTR(in_ymd,1,6)||'01')  
                          AND A.YMD        <= LAST_DAY(SUBSTR(in_ymd,1,6)||'01') 
                          AND A.GUMAE_NO   = B.GUMAE_NO 
                          AND A.RECEIPT_GB = '1' --접수 
                          AND B.ITEM_ID    = in_ITEM_ID
                     ) D;

              if SUBSTR(in_ITEM_ID,1,1) = '6' then
                 if TO_NUMBER(in_QTY) >  NVL(V_PSB_QTY,0) then      
                     out_CODE := -20000;
                    out_MSG := '< '|| V_ITEM_NM || ' (' || in_ITEM_ID || ') 의 주문한도수량이 ' || TO_CHAR(TO_NUMBER(in_QTY) - NVL(V_PSB_QTY,0)) ||
                                                   'EA 초과되었습니다. 수량을 조정하여 재 입력 바랍니다. 신규품목의 경우 관리부로 문의 바랍니다.'||'>' ;
                  RAISE ERROR_RAISE;
                  end if;
              else
                 if (TO_NUMBER(in_QTY) + V_M_QTY) > 20 then
                     if TO_NUMBER(in_QTY) >  NVL(V_PSB_QTY,0) then      
                        out_CODE := -20000;
                    out_MSG := '< '|| V_ITEM_NM || ' (' || in_ITEM_ID || ') 의 주문한도수량이 ' || TO_CHAR(TO_NUMBER(in_QTY) - NVL(V_PSB_QTY,0)) ||
                                                       'EA 초과되었습니다. 수량을 조정하여 재 입력 바랍니다. 신규품목의 경우 관리부로 문의 바랍니다.'||'>';
            RAISE ERROR_RAISE;
                     end if;
                 end if;
              end if;
          end if;
            

        
            out_CODE := 0;
            out_COUNT := 1;
            out_MSG := '데이타 체크 완료';
        OPEN out_RESULT FOR
        select in_INPUT_SEQ as out_TEMP
        from dual ;
        

    
    end if;
EXCEPTION 
   WHEN ERROR_RAISE THEN
   out_CODE := 1;
   -- out_MSG := 'Error Data = .' || V_ITEM_NM ; 
   WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM || out_MSG);      
end;
/
