CREATE FUNCTION      F_CUST_NM  -- 거래처명 가져오기
(
    in_CUST_CD  IN  NUMBER
) 
RETURN VARCHAR2 IS

        v_cust_nm   VARCHAR2(75);
        v_cust_cd   VARCHAR2(7);
    
BEGIN

        /* CHOE 20121007
        SELECT TRADE_NAME
        INTO v_cust_nm
        FROM SFA_SALES_CODE
        WHERE SFA_SALES_SEQ    = in_CUST_CD;*/
             
        v_cust_cd := TO_CHAR(in_CUST_CD);
              
        SELECT TRADE_NAME
        INTO v_cust_nm
        FROM SFA_SALES_CODE
        WHERE ERP_SALES_CODE = v_cust_cd;
        --WHERE ERP_SALES_CODE = in_CUST_CD;
        
        RETURN v_cust_nm;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;
/
