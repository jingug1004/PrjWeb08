CREATE PROCEDURE      SP_SFA_BRD_CATEGORY    -- 자료실 카테고리
(
    in_TYPE              IN  VARCHAR2,  -- 게시 타입. 0:게시판, 2:자료실
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
    TYPE_NULL          EXCEPTION;
BEGIN
    
    IF in_TYPE IS NULL THEN
        RAISE TYPE_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM hanagw.TGWBDRM 
     WHERE BRD_TYPE = in_TYPE;   -- 자료실 카테고리 체크
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT BRD_NO             AS out_BRD_NO      -- 카테고리 코드 NUMBER
             , BRD_NM             AS out_BRD_NM     -- 카테고리 명               
          FROM hanagw.TGWBDRM 
         WHERE BRD_TYPE = in_TYPE
         ORDER BY BRD_NO;
    END IF;
    
EXCEPTION
WHEN TYPE_NULL THEN
   out_CODE := 101;
   out_MSG  := '게시판 유형이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
