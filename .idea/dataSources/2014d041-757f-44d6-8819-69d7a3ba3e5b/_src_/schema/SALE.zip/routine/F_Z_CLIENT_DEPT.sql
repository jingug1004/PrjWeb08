CREATE FUNCTION      F_Z_CLIENT_DEPT  -- 방문 고객의 진료과명 (고객소속)
(
    in_SFA_SALES_SEQ  IN  VARCHAR2,
    in_CLIENT_CD  IN  NUMBER
) 
RETURN VARCHAR2 IS

    v_client_dept   VARCHAR2(75);
    
BEGIN

    SELECT oragmp.fncommonnm('comm','SL05',CLIENT_DEPT)  
      INTO v_client_dept
      FROM SFA_HIRA_CUSTOMER
     WHERE HIRACODE    = in_SFA_SALES_SEQ
       and SFA_CLIENT_NO    = in_CLIENT_CD;
        
    RETURN v_client_dept;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;
/
