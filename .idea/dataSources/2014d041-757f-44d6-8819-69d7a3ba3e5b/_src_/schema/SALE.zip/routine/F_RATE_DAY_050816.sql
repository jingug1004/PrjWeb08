CREATE function F_RATE_DAY_050816
                          (I_YM_F           IN  VARCHAR2,     -- 조회월일
                           I_CUST_ID        IN  VARCHAR2      -- 거래처코드
                           )  RETURN DATE   IS  -- 외전일자
						   
          T_FLAG               VARCHAR2(1);
		  T_MISU_AMT           NUMBER;
		  T_SU_AMT_TOT         NUMBER;
		  T_SU_AMT_TOT_BEFORE  NUMBER;
		  T_RATE_DATE          DATE;
		  T_RATE_DATE_BEFORE   DATE;
		  T_TEMP_DATE          DATE;
		  

           CURSOR C1  IS
               SELECT YMD        YMD,
			          SU_AMT     SU_AMT,
					  MISU_AMT   MISU_AMT,
					  BEFORE_AMT BEFORE_AMT
			     FROM SALE0306 
				WHERE CUST_ID = I_CUST_ID  
				  AND YMD    <= TO_DATE(I_YM_F || '01','YYYYMMDD')
				  AND SU_AMT > -1
			  ORDER BY YMD;
			  
		CURSOR C2 IS	  
			  SELECT B.YMD                     YMD,
			         B.AMT + B.VAT - B.DC_AMT  AMT
			    FROM SALE0203 A,
				     SALE0204 B
			   WHERE A.YMD      = B.YMD
			     AND A.GUMAE_NO = B.GUMAE_NO
			     AND A.CUST_ID  = I_CUST_ID
				 AND A.GUMAE_NO LIKE TO_CHAR(T_RATE_DATE,'YYYYMM') || '%';	
				 
		CURSOR C3 IS	  
			  SELECT B.YMD                     YMD,
			         B.AMT + B.VAT - B.DC_AMT  AMT
			    FROM SALE0203 A,
				     SALE0204 B
			   WHERE A.YMD      = B.YMD
			     AND A.GUMAE_NO = B.GUMAE_NO
			     AND A.CUST_ID  = I_CUST_ID
				 AND A.GUMAE_NO LIKE TO_CHAR(T_RATE_DATE_BEFORE,'YYYYMM') || '%';				   

      BEGIN
	  
	      T_FLAG       := '0';
		  T_MISU_AMT   := 0;
		  T_SU_AMT_TOT := 0;
		  T_SU_AMT_TOT_BEFORE := 0;
		  
            FOR A1 IN C1 LOOP
			
			    IF T_FLAG     = '0' THEN  -- 처음
				
				   SELECT SUM(SU_AMT)   --수금 전채 금액을 구한다
				     INTO T_SU_AMT_TOT
					 FROM SALE0306
					WHERE CUST_ID = I_CUST_ID  
				      AND YMD    <= TO_DATE(I_YM_F || '01','YYYYMMDD')
					  AND SU_AMT > -1;
					  
				   T_MISU_AMT := A1.MISU_AMT + A1.BEFORE_AMT;    
				   
				   T_FLAG     :='1';				   
				   
				ELSE                      -- 두번째 부터
				
				   T_MISU_AMT := T_MISU_AMT + A1.MISU_AMT;  

			    END IF;
				
				T_SU_AMT_TOT        :=  T_SU_AMT_TOT - T_MISU_AMT;
               
			
				IF T_SU_AMT_TOT = 0 THEN	
				   T_RATE_DATE := A1.YMD;
				   
				   IF T_SU_AMT_TOT_BEFORE = 0 THEN
					      RETURN (A1.YMD);
				   END IF;	
				   
				   FOR A2 IN C2 LOOP			        
					   
					   T_SU_AMT_TOT_BEFORE := T_SU_AMT_TOT_BEFORE - A2.AMT;
					   
					   IF T_SU_AMT_TOT_BEFORE = 0 THEN
					      RETURN (A2.YMD);					   
					   ELSIF T_SU_AMT_TOT_BEFORE < 0 THEN
					      RETURN (T_TEMP_DATE);
					   END IF;
					      T_TEMP_DATE := A2.YMD;  
			   
				   END LOOP;     
										       

				ELSIF T_SU_AMT_TOT < 0 THEN
				   T_RATE_DATE := A1.YMD;
				
				   IF T_SU_AMT_TOT_BEFORE = 0 THEN
					      RETURN (A1.YMD);
				   END IF; 	 
				
				   FOR A3 IN C3 LOOP
				   
				       T_SU_AMT_TOT_BEFORE := T_SU_AMT_TOT_BEFORE - A3.AMT;
					   
					   IF T_SU_AMT_TOT_BEFORE = 0 THEN
					      RETURN (A3.YMD);					   
					   ELSIF T_SU_AMT_TOT_BEFORE < 0 THEN
					      RETURN (T_TEMP_DATE);
					   END IF;
					   T_TEMP_DATE := A3.YMD; 
				       
				   
				   END LOOP;
				   	  
			    END IF;
				
				T_RATE_DATE_BEFORE  := A1.YMD;
				
				T_SU_AMT_TOT_BEFORE := T_SU_AMT_TOT ;	
				
            END LOOP;
			
			RETURN (T_RATE_DATE_BEFORE);

           
       EXCEPTION
          WHEN OTHERS THEN
               ROLLBACK;
               RAISE_APPLICATION_ERROR(-20099, 'F_RATE_DAY '||substrb('오류!'||SQLCODE||'/'||SQLERRM,1,250)) ;

      END;


/
