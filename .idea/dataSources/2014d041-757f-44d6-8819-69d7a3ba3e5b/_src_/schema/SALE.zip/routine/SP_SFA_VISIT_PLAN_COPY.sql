CREATE PROCEDURE      SP_SFA_VISIT_PLAN_COPY
(
    in_PROCESS_TYPE      IN  VARCHAR2,     -- 1:의미없이 1들어옴
    in_SALES_PLAN_NO     IN  VARCHAR2,     -- 방문일자 Key
    in_EMP_NO            IN  VARCHAR2,     -- 담당자 사번
    in_DT                IN  VARCHAR2,     -- 기준일자:가져올날짜 
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 방문계획 복사(과거의방문계획을 복사하여 방문계획을 만든다)  
 호출프로그램 : 115버전으로대체
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    ERROR_EXCEPTION      EXCEPTION;
    V_ASSGN_CD           VARCHAR2(5); --팀장여부 
    V_APPLY_YN           VARCHAR2(1); --승인여부 : 팀장계획은 자동승인처리하기 위함.

BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_VISIT_PLAN_COPY','1',sysdate,'in_SALES_PLAN_NO:'||in_SALES_PLAN_NO||'/in_EMP_NO:'||in_EMP_NO||'/in_DT:'||in_DT );
--commit;

    IF in_PROCESS_TYPE = '1' THEN
    
        --전주금요일까지 이주 계획이 완료되어야 하는 로직적용으로 이 부분 막음
        --VisitDaily.java 에 방문계획과 계획복사 버튼에서 처리
        --복사하려는 날짜가 오늘이전이면 불가
        /*
        IF TO_CHAR(SYSDATE,'YYYYMMDD') > in_SALES_PLAN_NO THEN
           out_MSG := '등록실패 : 서버일자는'||TO_CHAR(SYSDATE,'YYYY.MM.DD')||' 입니다. 과거의 일자에 방문계획복사가 불가능합니다..';
           RAISE ERROR_EXCEPTION;                          
         END IF;             
    
        --당일의 계획복사 는 시간체크
        IF TO_CHAR(SYSDATE,'YYYYMMDD') = in_SALES_PLAN_NO THEN
            
            IF TO_CHAR(SYSDATE,'HH24') > '08' THEN                       
                out_MSG := '등록실패 : 서버시간은 '||TO_CHAR(SYSDATE,'HH24')||' 시 입니다. 당일의 방문계획은 오전9시 까지만 가능합니다.';
                RAISE ERROR_EXCEPTION;                          
            END IF; 
            
         END IF;
        */     
    
       --복사하려는 날에 자료가 있으면 알려주고 그냥나감 
       v_num := 0;
       SELECT COUNT(*)
          INTO v_num
          FROM SFA_VISIT_PLANACT A              
         WHERE A.EMP_NO         = in_EMP_NO
           AND A.SALES_PLAN_NO  = in_SALES_PLAN_NO  --계획일자
         ;    
       IF v_num > 0 THEN                 
          out_MSG := '등록실패 : 복사하려는 날짜에 방문계획이 존재합니다.지우고 시도 하십시오.';
          RAISE ERROR_EXCEPTION;  
       END IF;
         
       v_num := 0;
       SELECT COUNT(*)
          INTO v_num
          FROM SFA_VISIT_PLANACT A              
         WHERE A.EMP_NO         = in_EMP_NO
           AND A.SALES_PLAN_NO  = in_DT  --계획일자
           AND A.VISIT_KIND = '0' --방문종류(0-계획방법,1-추가방문,2-출퇴경유)
         ;
                 
        IF v_num = 0 THEN
            out_COUNT := v_num;  
            out_CODE := 1;
            out_MSG  := '이 날짜로는 방문계획으로 등록된 자료가 없습니다(출퇴근,경유지만 있는지 확인하십시오)';
        ELSIF v_num > 25 THEN
            out_COUNT := v_num;  
            out_CODE := 1;
            out_MSG  := '이 날짜로 등록된 방문계획이 25건이 넘습니다(1일 방문계획은 25개 이하로 제한합니다.)';
        ELSE
            out_CODE := 0;
            out_MSG  := '방문계획 복사 완료';
            
            --작성자가 팀장이면자동승인처리한다.
            --팀장여부
            SELECT ASSGN_CD INTO V_ASSGN_CD
              FROM HR_HC_EMPBAS_0  
             WHERE EMP_NO  = (SELECT INSA_SAWON_ID FROM SALE0007 WHERE SAWON_ID = in_EMP_NO AND GUBUN = 'Y');

            IF V_ASSGN_CD = '27030' THEN
               V_APPLY_YN := 'Y';
            ELSE
               V_APPLY_YN := 'N';
            END IF;
            
            
            INSERT INTO SFA_VISIT_PLANACT(
                    SALES_PLAN_NO  
                   ,EMP_NO         
                   ,DETAIL_PLAN_NO 
                   ,DEPT_NO        
                   ,SFA_SALES_SEQ  
                   ,SFA_CLIENT_NO  
                   ,DESCRIPTION    
                   ,TOGETHER_YN    
                   ,TOGETHER_EMP_NO
                   ,APPLY_YN       
                   ,STATUS         
                   ,GPS_NUM1       
                   ,GPS_NUM2       
                   ,EMP_CALL_DTM   
                   ,ACTIVITY_CODE  
                   ,ACTIVITY_DESC  
                   ,MAIN_ITEM1     
                   ,MAIN_ITEM2     
                   ,MAIN_ITEM3     
                   ,VISIT          
                   ,VISIT_KIND     
                   ,ACTIVITY_YN    
                   ,REJECT_DESC    
                   ,CALL_YN
                   )
            SELECT in_SALES_PLAN_NO --SALES_PLAN_NO     /*방문일자                                                     */
                  ,EMP_NO           --EMP_NO            /*사번                                                         */
                  ,ROWNUM           --DETAIL_PLAN_NO    /*방문순번                                                     */
                  ,DEPT_NO          --DEPT_NO           /*사번의부서                                                   */
                  ,SFA_SALES_SEQ    --SFA_SALES_SEQ     /*SFA거래처KEY컬럼                                             */
                  ,SFA_CLIENT_NO    --SFA_CLIENT_NO     /*고객코드                                                     */
                  ,DESCRIPTION      --DESCRIPTION       /*방문목적                                                     */
                  ,TOGETHER_YN      --TOGETHER_YN       /*동행여부                                                     */
                  ,TOGETHER_EMP_NO  --TOGETHER_EMP_NO   /*동행자코드                                                   */
                  ,V_APPLY_YN       --APPLY_YN            /*방문계획승인여부(Y-승인,N-대기,R-보류,NULL-출퇴경유)       */
                  ,'00'             --STATUS              /*상태(방문CALL시 99를 입력해야 WEB관리자에서 지도지점표시됨)*/
                  ,''               --GPS_NUM1            /*좌표_위도                                                  */
                  ,''                --GPS_NUM2            /*좌표_경도                                                 */
                  ,''               --EMP_CALL_DTM        /*콜시간                                                     */
                  ,''               --ACTIVITY_CODE       /*방문활동코드(SALE0001의 COGE_GB='0060')                    */
                  ,''               --ACTIVITY_DESC       /*활동내역                                                   */
                  ,''               --MAIN_ITEM1          /*주품목코드1                                                */
                  ,''               --MAIN_ITEM2          /*주품목코드2                                                */
                  ,''               --MAIN_ITEM3          /*주품목코드3                                                */
                  ,'N'              --VISIT               /*방문완료여부(N-대기,Y-완료,NULL-출퇴경)                    */
                  ,'0'              --VISIT_KIND          /*방문종류(0-계획방법,1-추가방문,2-출퇴경유)                 */
                  ,'N'              --ACTIVITY_YN         /*활동내역작성유무(Y-작성완료,N-대기)                        */
                  ,''               --REJECT_DESC         /*팀장반려사유                                               */
                  ,'N'               --CALL_YN            /*CALL여부(Y/N)                                              */
             FROM SFA_VISIT_PLANACT A
            WHERE A.EMP_NO         = in_EMP_NO
              AND A.SALES_PLAN_NO  = in_DT      --계획일자
              AND A.VISIT_KIND     = '0'        --방문종류(0-계획방법,1-추가방문,2-출퇴경유)
            ;                                   
           
        END IF; 
    END IF;  
     
EXCEPTION   
WHEN ERROR_EXCEPTION THEN
   out_CODE := 1;
   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
