CREATE PROCEDURE      SP_SFA_ORDER_CHECK_998
  (
    in_CUST_ID            IN VARCHAR2 default NULL, 
    in_flag      IN  VARCHAR2 DEFAULT NULL,
    in_ymd       IN  date,
    in_GUMAE_NO  IN  VARCHAR2 DEFAULT NULL, 
    in_INPUT_SEQ IN  VARCHAR2 DEFAULT NULL, 
    in_ITEM_ID   IN  VARCHAR2 DEFAULT NULL, 
    in_QTY       IN  VARCHAR2 DEFAULT NULL, 
    in_DANGA     IN  NUMBER DEFAULT NULL, 
    in_AMT       IN  VARCHAR2 DEFAULT NULL, 
    in_VAT       IN  VARCHAR2 DEFAULT NULL, 
    in_DC_AMT    IN  VARCHAR2 DEFAULT NULL,
    in_DC_QTY    IN  VARCHAR2 DEFAULT NULL, 
    in_DC_DANGA  IN  VARCHAR2 DEFAULT NULL,
    out_CODE     OUT NUMBER,
    out_MSG      OUT VARCHAR2,
    out_COUNT    OUT NUMBER,
    out_RESULT   OUT TYPES.CURSOR_TYPE

  )
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문체크
 호출프로그램 :주문서등록의 수량입력후    
           
 수정기록     :
 1.20140403/ 김태안/ 위반주문 체크를 위한 수량체크 
  저장 프로시져 SP_SFA_ORDER_110 에서 수량체크를 하여 수량 초과이면 주문불가
  처리하였으나 그런 주문도 약속내용을 입력하면 주문가능하도록 로직변경하면서 
  수량체크를 하도록 함.(윤홍주 요청)
 ---------------------------------------------------------------------------*/    
    
    ll_months    number := 0;   --개시개월수
    ll_mqty      number := 0;   --이달의주문수량계
    ll_avgqty    number := 0;   --평균주문수량(3개월)
    ll_mamt      number := 0;   --이달의주문금액계
    ll_avgamt    number := 0;   --평균주문금액(3개월)
    ll_limit     number := 0;   --주문한도        
    ll_SupplySum number := 0;   --주문금액계산용TEMP 
    
    v_CUST_ID    VARCHAR2(10); 
    v_ITEM_ID    VARCHAR2(10);
    v_date_first DATE;
    v_date_last  DATE;
    v_QTY        VARCHAR2(12);
    v_AMT        VARCHAR2(13);
    v_VAT        VARCHAR2(13);
    v_ITEM_NM    VARCHAR2(50);
    
    
    v_retmsg     VARCHAR2(400);    
    ERROR_RAISE        EXCEPTION; 

BEGIN  
    
--    INSERT INTO SFA_SP_CALLED_HIST 
--    VALUES ('SP_SFA_ORDER_CHECK','1000',sysdate,'in_CUST_ID'||in_CUST_ID
--            ||'||in_flag     :'||in_flag
--            ||'||in_ymd      :'||to_char(in_ymd,'yyyymmdd')
--            ||'||in_GUMAE_NO :'||in_GUMAE_NO
--            ||'||in_INPUT_SEQ:'||in_INPUT_SEQ
--            ||'||in_ITEM_ID  :'||in_ITEM_ID
--            ||'||in_QTY      :'||in_QTY
--            ||'||in_DANGA    :'||in_DANGA
--            ||'||in_VAT      :'||in_VAT
--            ||'||in_DC_AMT   :'||in_DC_AMT
--            ||'||in_DC_QTY   :'||in_DC_QTY
--            ||'||in_DC_DANGA :'||in_DC_DANGA
--            );
--    COMMIT; 
           
 INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_CHECK_998','1000',sysdate,'김태안...이프로시져 사용되는 것인지 체크하고 있음....');
    COMMIT; 
         
   IF in_FLAG = 'I' THEN            
        --주문수량통제 start ---------------------------------------------------------------------
        BEGIN
    
            v_CUST_ID := in_CUST_ID;
            v_ITEM_ID := in_ITEM_ID;    
            v_date_first := to_date(to_char(in_YMD,'yyyymm')||'01','yyyymmdd');
            v_date_last  := last_day(to_date(to_char(in_YMD,'yyyymm')||'01','yyyymmdd'));
            v_QTY        := in_QTY;
            --v_AMT        := in_AMT; --주문로직에서 분리하면서 안들어옴   
            select  item_nm into v_ITEM_NM from  sale.sale0004 where item_id = v_ITEM_ID;  

            --주문월-개시월=개시개월수
            ll_months := 0;
            SELECT trunc(months_between(to_date(to_char(in_YMD,'yyyymm'),'yyyymm'), to_date(to_char(START_YMD,'yyyymm'),'yyyymm')))  --일자로 하지 않고 1일로 바꿔서 
              INTO ll_months
              FROM SALE.SALE0003
             WHERE CUST_ID = v_CUST_ID;
                               
           --이달주문수량(이번 주문포함)
            SELECT sum(QTY1) + sum(QTY2) + v_QTY
              INTO ll_mqty
              FROM (--ERP 이달주문수량
                    SELECT NVL(SUM(B.QTY),0) QTY1 , 0 AS QTY2
                      FROM SALE0203 A, SALE0204 B  
                     WHERE A.CUST_ID    = v_CUST_ID
                       AND A.YMD        >= v_date_first
                       AND A.YMD        <= LAST_DAY(TO_DATE(TO_CHAR(in_YMD,'YYYYMM')||'01','YYYYMMDD'))
                       AND A.GUMAE_NO   = B.GUMAE_NO 
                       AND B.ITEM_ID    = v_ITEM_ID
                   UNION
                   --온라인 이달주문수량
                    SELECT 0 AS QTY1 , NVL(SUM(B.QTY),0) QTY2
                      FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B 
                     WHERE A.CUST_ID    = v_CUST_ID
                       AND A.YMD        >= v_date_first
                       AND A.YMD        <= v_date_last
                       AND A.GUMAE_NO   = B.GUMAE_NO
                       AND A.RECEIPT_GB = '1'--접수구분(1.접수, 2.승인, 3.반려) 
                       AND B.ITEM_ID    = v_ITEM_ID
                   );
                             
            --수량을 선택하면서 이프로시져가 호출되었기에  v_AMT 와 v_VAT는 값이 들어오지 않는다.
            --따라서 이달의 주문금액을 위해 이번 주문의 금액을 먼저 계산한다. 
            --3번 4번으로 시작하는 거래처는 소숫점이하 1자리가 .1 이상이면 일의자리를 +1 해준다       
            
            --이번주문의 주문금액  
            SELECT OUT_DANGA * to_number(in_QTY) INTO ll_SupplySum FROM SALE0004 WHERE ITEM_ID = in_ITEM_ID;
            
            IF SUBSTR(v_CUST_ID,1,1) = '3' OR SUBSTR(v_CUST_ID,1,1) = '4' THEN
               if ll_SupplySum >= 0 then
                  v_AMT := round(ll_SupplySum / 1.1 + 0.4);
               else
                  v_AMT := round(ll_SupplySum / 1.1 - 0.4);
               end if;
               v_VAT := ll_SupplySum - v_AMT;
            ELSE               
               v_VAT := ll_SupplySum * 0.1;
            END IF;
             
                     
            --이달주문금액(이번 주문포함)
            SELECT sum(AMT1) + sum(AMT2) + NVL(v_AMT,0) + NVL(v_VAT,0) 
              INTO ll_mamt
              FROM (--ERP 이달주문수량
                    SELECT NVL(SUM(B.AMT),0) + NVL(SUM(B.VAT),0) AS AMT1
                          ,0 AS AMT2
                      FROM SALE0203 A, SALE0204 B  
                     WHERE A.CUST_ID    = v_CUST_ID
                       AND A.YMD        >= v_date_first
                       AND A.YMD        <= v_date_last
                       AND A.GUMAE_NO   = B.GUMAE_NO 
                       AND B.ITEM_ID    = v_ITEM_ID
                   UNION
                   --온라인 이달주문수량
                    SELECT 0 AS AMT1
                          ,NVL(SUM(B.AMT),0) + NVL(SUM(B.VAT),0) AS AMT2
                      FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B 
                     WHERE A.CUST_ID    = v_CUST_ID
                       AND A.YMD        >= v_date_first
                       AND A.YMD        <= v_date_last
                       AND A.GUMAE_NO   = B.GUMAE_NO
                       AND A.RECEIPT_GB = '1'--접수구분(1.접수, 2.승인, 3.반려) 
                       AND B.ITEM_ID    = v_ITEM_ID
                   );

                               
            --주문한도율
            SELECT JUMUN_LIMIT / 100
              INTO ll_limit
              FROM SALE.SALE0003 
             WHERE CUST_ID = v_CUST_ID
            ; 
                        
            IF ll_months = 0 THEN      --이달개시거래처 또는 향정제품은 이달수량만 체크

                IF ll_mqty > 20 THEN  --이달주문수량
                    --v_retmsg := '1';
                    v_retmsg := v_ITEM_NM || '의 이달 주문합계수량('|| ll_mqty || ')이 20개를 초과하였습니다(개시당월)';
                    RAISE ERROR_RAISE;
                END IF;
                            
            ELSIF ll_months = 1  THEN  --개시개월1달
                        
                --평균주문수량(1개월)의1.5배,평균주문금액(1개월)의1.5배
                SELECT ROUND(QTY * ll_limit),ROUND(AMT * ll_limit)
                  INTO ll_avgqty,ll_avgamt
                  FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 1 )) QTY
                                ,ROUND((NVL(SUM(B.AMT + B.VAT),0) /1 )) AMT
                            FROM SALE.SALE0203 A, SALE.SALE0204 B 
                           WHERE A.GUMAE_NO = B.GUMAE_NO
                             AND A.CUST_ID  = v_CUST_ID 
                             AND B.ITEM_ID  = v_ITEM_ID 
                         );
                                     
                IF ll_avgqty = 0 THEN  --첫주문인 경우
                    IF ll_mqty > 20 THEN  --이달주문수량
                        --v_retmsg := '2';
                        v_retmsg := v_ITEM_NM || '의 이달 주문합계수량('|| ll_mqty || ')이 20개를 초과하였습니다(개시1개월)';
                        RAISE ERROR_RAISE;
                    END IF;
                                 
                ELSE      
                
                    IF ll_mqty > ll_avgqty THEN  --이달주문수량이 월평균주문수량(1개월)의1.5배 보다 크면                        
                       v_retmsg := v_ITEM_NM || '의 이달 주문합계수량('|| ll_mqty || ')이 1개월평균주문수량의1.5배인 '|| ll_avgqty ||' 개를 초과하였습니다(개시1개월)';
                       RAISE ERROR_RAISE;
                    END IF;             

                    --평균주문수량(1개월)의1.5배,평균주문금액(1개월)의1.5배
                    SELECT ROUND(AMT * ll_limit)
                      INTO ll_avgamt
                      FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 1 )) QTY
                                    ,ROUND((NVL(SUM(B.AMT + B.VAT),0) /1 )) AMT
                                FROM SALE.SALE0203 A, SALE.SALE0204 B 
                               WHERE A.GUMAE_NO = B.GUMAE_NO
                                 AND A.CUST_ID  = v_CUST_ID   
                             );                            

                    IF ll_mamt > ll_avgamt THEN  --이달주문금액이 월평균주문금액(1개월) 보다 크면 
                        --v_retmsg := '4';
                        v_retmsg := v_ITEM_NM || '의 이달 주문합계금액('|| ll_mamt || ')이 1개월평균주문금액의1.5배인 '|| ll_avgamt ||' 원을 초과하였습니다(개시1개월)';
                        RAISE ERROR_RAISE;
                    END IF; 
                                                       
                END IF;    
                            
            ELSIF ll_months = 2  THEN  --개시개월2달
                        
                             
                --평균주문수량(2개월)의1.5배,평균주문금액(2개월)의1.5배
                SELECT ROUND(QTY * ll_limit),ROUND(AMT * ll_limit)
                  INTO ll_avgqty,ll_avgamt
                  FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 2 )) QTY
                                ,ROUND((NVL(SUM(B.AMT + B.VAT),0) / 2 )) AMT
                            FROM SALE.SALE0203 A, SALE.SALE0204 B 
                           WHERE A.GUMAE_NO = B.GUMAE_NO
                             AND A.CUST_ID  = v_CUST_ID 
                             AND B.ITEM_ID  = v_ITEM_ID 
                         );
                                     
                IF ll_avgqty = 0 THEN  --첫주문인 경우
                    IF ll_mqty > 20 THEN  --이달주문수량
                        --v_retmsg := '5';
                        v_retmsg := v_ITEM_NM || '의 이달 주문합계수량('|| ll_mqty || ')이 20개를 초과하였습니다(개시2개월)';
                        RAISE ERROR_RAISE;
                    END IF; 
                                
                ELSE     
                                                    

                    IF ll_mqty > ll_avgqty THEN  --이달주문수량이 월평균주문수량(1개월)의1.5배 보다 크면                        
                       v_retmsg := v_ITEM_NM || '의 이달 주문합계수량('|| ll_mqty || ')이 2개월평균주문수량의1.5배인 '|| ll_avgqty ||' 개를 초과하였습니다(개시2개월)';
                       RAISE ERROR_RAISE;
                    END IF;      
                                    
                    --평균주문수량(1개월)의1.5배,평균주문금액(1개월)의1.5배
                    SELECT ROUND(AMT * ll_limit)
                      INTO ll_avgamt
                      FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 2 )) QTY
                                    ,ROUND((NVL(SUM(B.AMT + B.VAT),0) /2 )) AMT
                                FROM SALE.SALE0203 A, SALE.SALE0204 B 
                               WHERE A.GUMAE_NO = B.GUMAE_NO
                                 AND A.CUST_ID  = v_CUST_ID   
                             );                            
                                
                    IF ll_mamt > ll_avgamt THEN  --이달주문금액이 월평균주문금액(2개월) 보다 크면 
                        --v_retmsg := '7';
                        v_retmsg := v_ITEM_NM || '의 이달 주문합계금액('|| ll_mamt || ')이 2개월평균주문금액의1.5배인 '|| ll_avgamt ||' 원을 초과하였습니다(개시2개월)';
                        RAISE ERROR_RAISE;
                    END IF;                      
                END IF;                                  

                         
            ELSE                         --개시개월3달이상
                        
                        
                --이때는 이 제품의 3개월간의 총수량으로 한다.
                --평균주문수량(3개월)의1.5배
                SELECT ROUND(QTY * ll_limit)
                  INTO ll_avgqty
                  FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 3 )) QTY
                                ,ROUND((NVL(SUM(B.AMT + B.VAT),0) / 3 )) AMT
                            FROM SALE.SALE0203 A, SALE.SALE0204 B 
                           WHERE A.GUMAE_NO = B.GUMAE_NO
                             AND A.YMD      < v_date_first
                             AND A.YMD      >= ADD_MONTHS(v_date_first ,-3)
                             AND A.CUST_ID  = v_CUST_ID 
                             AND B.ITEM_ID  = v_ITEM_ID 
                         );
                                     
                --이때는 제품에 관계없이 3개월간의 총수량으로 한다.
                --평균주문금액(3개월)의1.5배
                SELECT ROUND(AMT * ll_limit)
                  INTO ll_avgamt
                  FROM   (SELECT ROUND((NVL(SUM(B.QTY),0) / 3 )) QTY
                                ,ROUND((NVL(SUM(B.AMT + B.VAT),0) / 3 )) AMT
                            FROM SALE.SALE0203 A, SALE.SALE0204 B 
                           WHERE A.GUMAE_NO = B.GUMAE_NO
                             AND A.YMD      < v_date_first
                             AND A.YMD      >= ADD_MONTHS(v_date_first ,-3)
                             AND A.CUST_ID  = v_CUST_ID 
                             --AND B.ITEM_ID  = v_ITEM_ID   --제품에 관계없이...윤차장과 협의 
                         );
                                        
                                     
                IF ll_avgqty = 0 THEN  --첫주문인 경우
                    IF ll_mqty > 20 THEN  --이달주문수량
                        --v_retmsg := '8';
                        v_retmsg := v_ITEM_NM || '의 이달 주문합계수량('|| ll_mqty || ')이 20개를 초과하였습니다(개시3개월이상)';
                        RAISE ERROR_RAISE;
                    END IF; 
                                
                ELSE     
                            
                    IF ll_mqty > ll_avgqty THEN  --이달주문수량이 월평균주문수량(1개월)의1.5배 보다 크면                        
                       v_retmsg := v_ITEM_NM || '의 이달 주문합계수량('|| ll_mqty || ')이 3개월평균주문수량의1.5배인 '|| ll_avgqty ||' 개를 초과하였습니다(개시3개월이상)';
                       RAISE ERROR_RAISE;
                    END IF;
                        
                    IF ll_mamt > ll_avgamt THEN  --이달주문금액이 월평균주문금액(3개월) 보다 크면 
                        --v_retmsg := '10';
                        v_retmsg := v_ITEM_NM || '의 이달 주문합계금액('|| ll_mamt || ')이 3개월평균주문금액의1.5배인 '|| ll_avgamt ||' 원을 초과하였습니다(개시3개월이상)';
                        RAISE ERROR_RAISE;
                    END IF;

                END IF;  
                                                
            END IF;  

        END;
                    
        --주문수량통제 end --------------------------------------------------------------------- 
    
    END IF;
    
    
      
    out_CODE := 1;     --0이면 out_MSG 가 client에 넘어가지 않음.
    out_MSG := '정상'; --이곳을 타면 수량은 정상임..   
  
EXCEPTION 
   WHEN ERROR_RAISE THEN
        out_CODE := 1;     --0이면 out_MSG 가 client에 넘어가지 않음.
        out_MSG := v_retmsg ||' - 주문은 가능합니다' ; --이곳을 타면 수량위반   
        
   WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM || out_MSG);      
END;
/
