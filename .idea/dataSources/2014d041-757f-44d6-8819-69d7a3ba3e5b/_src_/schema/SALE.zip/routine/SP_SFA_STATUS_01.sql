CREATE PROCEDURE      SP_SFA_STATUS_01
(
    in_PART_CD           IN  VARCHAR2,     -- 파트 코드
    in_DEPT_CD           IN  VARCHAR2,     -- 부서 코드
    in_SAWON_ID          IN  VARCHAR2,     -- 사원 ID
    in_DT_FR             IN  VARCHAR2,     -- 기준일자 FROM
    in_DT_TO             IN  VARCHAR2,     -- 기준일자 TO
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 실적조회
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_gubun              NUMBER;
    
    DT_NULL              EXCEPTION;
BEGIN
    
    IF in_DT_FR IS NULL OR in_DT_TO IS NULL THEN
        RAISE DT_NULL;
    END IF;
    
    SELECT COUNT(*)
      INTO v_num
      FROM SALEPART_BATCH2
     WHERE DATE_TIME  BETWEEN in_DT_FR  AND in_DT_TO
       AND PART_CD    LIKE    NVL((SELECT SALE_DEPT_CD FROM hanahr.HR_CO_DEPART_0 WHERE DEPT_CD = in_PART_CD), '%') 
       AND TEAM_CD    LIKE    NVL((SELECT SALE_DEPT_CD FROM hanahr.HR_CO_DEPART_0  
                             WHERE LEVEL <> 1                AND USE_YN = 'Y' 
                               AND SALE_DEPT_CD IS NOT NULL  AND  DEPT_CD = in_DEPT_CD 
                             CONNECT BY PRIOR DEPT_CD = UP_DEPT_CD START WITH DEPT_CD LIKE NVL(in_PART_CD, '%')), '%')
       AND EMP_NO     LIKE    NVL(in_SAWON_ID, '%')           
       AND EMP_NM NOT LIKE '%도매%'
       AND EMP_NM NOT LIKE '%기타%'
       AND EMP_NM NOT LIKE '%미지정%'
       AND EMP_NM NOT LIKE '%채권관리부%';

    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
        
        -- in_PART_CD NULL : 파트 전체 검색
        -- in_PART_CD NOT NULL  NULL : 부서 전체 검색
        -- in_PART_CD NOT NULL  NOT NULL 11018 NULL : 부서의 전체 사원 검색
        -- in_PART_CD NOT NULL  NOT NULL 11018 NOT NULL : 사원 검색
        IF in_PART_CD IS NULL AND in_DEPT_CD IS NULL AND in_SAWON_ID IS NULL THEN
            v_gubun := 1;  -- 파트 전체 검색
        ELSIF in_PART_CD IS NOT NULL AND in_DEPT_CD IS NULL AND in_SAWON_ID IS NULL THEN
            v_gubun := 2;  -- 부서 전체 검색
        ELSIF in_PART_CD IS NOT NULL AND in_DEPT_CD IS NOT NULL AND in_SAWON_ID IS NULL THEN
            v_gubun := 3;  -- 파트별 부서별 전체 사원 검색
        ELSIF in_PART_CD IS NOT NULL AND in_DEPT_CD IS NOT NULL AND in_SAWON_ID IS NOT NULL THEN
            v_gubun := 4;  -- 파트별 부서별 개별 사원 검색
        END IF;
                
        OPEN out_RESULT FOR
        SELECT DECODE(v_gubun, 1, '', 2, PART_CD, 3, TEAM_CD, EMP_NO)   AS out_GUBUN_CD         -- 구분코드
             , DECODE(v_gubun, 1, '', 2, PART_NM, 3, TEAM_NM, EMP_NM)   AS out_GUBUN_NM         -- 구분명
             , '00'                                                     AS out_RPT_GB           -- 생성구분
             , SUM(SALE_AMT)                                            AS out_SALE_AMT         -- 판매목표
             /*, SUM(SALE_AMT_SILJUK) + SUM(SALE_AMT_HALINS02)            AS out_SALE_AMT_SILJUK  -- 판매금액*/
             , (SUM(SALE_AMT_SILJUK) + SUM(SALE_AMT_HALINS02)) * ( 90.909 * 0.01 )           AS out_SALE_AMT_SILJUK -- 판매금액
             /*, ROUND((((SUM(SALE_AMT_SILJUK) + SUM(SALE_AMT_HALINS02))/DECODE(SUM(SALE_AMT),0, 1,SUM(SALE_AMT)))*100), 2)  AS out_SALE_PERCENT     -- 판매달성율*/
             , ROUND((((SUM(SALE_AMT_SILJUK) + SUM(SALE_AMT_HALINS02))/DECODE(SUM(SALE_AMT),0, 1,SUM(SALE_AMT)))*100) * ( 90.909 * 0.01 ), 2)  AS out_SALE_PERCENT     -- 판매달성율
             , SUM(IN_AMT)                                              AS out_IN_AMT           -- 수금목표
             /*, SUM(IN_AMT_SILJUK)                                       AS out_IN_AMT_SILJUK    -- 수금금액*/
             , SUM(IN_AMT_SILJUK) * ( 90.909 * 0.01 )             AS out_IN_AMT_SILJUK    -- 수금금액
             /*, ROUND(((SUM(IN_AMT_SILJUK)/DECODE(SUM(IN_AMT),0,1,SUM(IN_AMT)))*100), 2)         AS out_IN_PERCENT       -- 수금달성율   */
             , ROUND(((SUM(IN_AMT_SILJUK)/DECODE(SUM(IN_AMT),0,1,SUM(IN_AMT)))*100) * ( 90.909 * 0.01 )  , 2)         AS out_IN_PERCENT       -- 수금달성율   
             , TO_DATE(MAX(PROC_DATE), 'YYYYMMDDHH24MISS')              AS out_PROC_DATE          -- batch data 생성시각
          FROM SALEPART_BATCH2 
         WHERE DATE_TIME  BETWEEN in_DT_FR  AND in_DT_TO
           AND PART_CD    LIKE    NVL((SELECT SALE_DEPT_CD FROM HR_CO_DEPART_0 WHERE DEPT_CD = in_PART_CD), '%')
           AND TEAM_CD    LIKE    NVL((SELECT SALE_DEPT_CD FROM HR_CO_DEPART_0 
                             WHERE LEVEL <> 1                AND USE_YN = 'Y' 
                               AND SALE_DEPT_CD IS NOT NULL  AND  DEPT_CD = in_DEPT_CD 
                             CONNECT BY PRIOR DEPT_CD = UP_DEPT_CD START WITH DEPT_CD LIKE NVL(in_PART_CD, '%')), '%')
           AND EMP_NO     LIKE    NVL(in_SAWON_ID, '%')           
           AND EMP_NM NOT LIKE '%도매%'
           AND EMP_NM NOT LIKE '%기타%'
           AND EMP_NM NOT LIKE '%미지정%'
           AND EMP_NM NOT LIKE '%채권관리부%'
         GROUP BY DECODE(v_gubun, 1, '', 2, PART_CD, 3, TEAM_CD, EMP_NO), DECODE(v_gubun, 1, '', 2, PART_NM, 3, TEAM_NM, EMP_NM)
        UNION ALL
        SELECT DECODE(v_gubun, 1, PART_CD, 2, TEAM_CD, EMP_NO)          AS out_GUBUN_CD         -- 구분코드
             , DECODE(v_gubun, 1, PART_NM, 2, TEAM_NM, EMP_NM)          AS out_GUBUN_NM         -- 구분명
             , MAX(RPT_GB)                                              AS out_RPT_GB           -- 생성구분
             , SUM(SALE_AMT)                                            AS out_SALE_AMT         -- 판매목표
              , (SUM(SALE_AMT_SILJUK) + SUM(SALE_AMT_HALINS02)) * ( 90.909 * 0.01 )           AS out_SALE_AMT_SILJUK -- 판매금액
             , ROUND((((SUM(SALE_AMT_SILJUK) + SUM(SALE_AMT_HALINS02))/DECODE(SUM(SALE_AMT),0, 1,SUM(SALE_AMT)))*100) * ( 90.909 * 0.01 ), 2)  AS out_SALE_PERCENT     -- 판매달성율
             , SUM(IN_AMT)                                              AS out_IN_AMT           -- 수금목표
              , SUM(IN_AMT_SILJUK) * ( 90.909 * 0.01 )             AS out_IN_AMT_SILJUK    -- 수금금액
              , ROUND(((SUM(IN_AMT_SILJUK)/DECODE(SUM(IN_AMT),0,1,SUM(IN_AMT)))*100) * ( 90.909 * 0.01 )  , 2)         AS out_IN_PERCENT       -- 수금달성율   
             , TO_DATE(MAX(PROC_DATE), 'YYYYMMDDHH24MISS')              AS out_PROC_DATE          -- batch data 생성시각
          FROM SALEPART_BATCH2
         WHERE DATE_TIME  BETWEEN in_DT_FR  AND in_DT_TO
           AND PART_CD    LIKE    NVL((SELECT SALE_DEPT_CD FROM HR_CO_DEPART_0 WHERE DEPT_CD = in_PART_CD), '%')
           AND TEAM_CD    LIKE    NVL((SELECT SALE_DEPT_CD FROM HR_CO_DEPART_0  
                             WHERE LEVEL <> 1                AND USE_YN = 'Y' 
                               AND SALE_DEPT_CD IS NOT NULL  AND  DEPT_CD = in_DEPT_CD 
                             CONNECT BY PRIOR DEPT_CD = UP_DEPT_CD START WITH DEPT_CD LIKE NVL(in_PART_CD, '%')), '%')
           AND EMP_NO     LIKE    NVL(in_SAWON_ID, '%')           
           AND EMP_NM NOT LIKE '%도매%'
           AND EMP_NM NOT LIKE '%기타%'
           AND EMP_NM NOT LIKE '%미지정%'
           AND EMP_NM NOT LIKE '%채권관리부%'
         GROUP BY DECODE(v_gubun, 1, PART_CD, 2, TEAM_CD, EMP_NO), DECODE(v_gubun, 1, PART_NM, 2, TEAM_NM, EMP_NM) 
         ORDER BY 1,2;
        
    END IF;
    
EXCEPTION
WHEN DT_NULL THEN
   out_CODE := 101;
   out_MSG  := '조회기간이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
