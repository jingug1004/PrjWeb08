CREATE PROCEDURE      SP_SFA_ADMIN_09    -- 상병코드 검색
(
    in_SANGBYEONG_NM          IN  VARCHAR2,  -- 상병명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_SANGBYUNGCODE
     WHERE SANGBYUNG_NM LIKE '%'||NVL(in_SANGBYEONG_NM, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR 
            SELECT SANGBYUNG_CD                AS out_SANGBYEONG_CD     
                 , SANGBYUNG_SEQ               AS out_SANGBYEONG_SEQ    
                 , SANGBYUNG_NM                AS out_SANGBYEONG_NM    
                 , SANGBYUNG_YN                AS out_SANGBYEONG_YN    
                 , ITEM_PATH               AS out_ITEM_PATH    
                 , ITEM_NAME               AS out_ITEM_NM      
                 , SAVE_ITEM_NAME               AS out_SAVE_ITEM_NM   
          FROM SFA_OFFICE_SANGBYUNGCODE
         WHERE SANGBYUNG_NM LIKE '%'||NVL(in_SANGBYEONG_NM, '%')||'%'
         ORDER BY SANGBYUNG_NM;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
