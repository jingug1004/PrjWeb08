CREATE PROCEDURE      P_SALEPART_DAILY_COMPLEMENT ( AS_YMD IN VARCHAR2
                                                                                         ,AS_USER_FLAG IN VARCHAR2
                                                                                         ,AS_DO IN VARCHAR2
                                                                                         ,AS_JONG IN VARCHAR2
                                                                                         ,AS_SEMI IN VARCHAR2
                                                                                         ,AS_LOCAL IN VARCHAR2
                                                                                         ,AS_DO2 IN VARCHAR2
                                                                                         )IS
        /*------------------------------------------------------------------
        CHOE 20130809
        일일 실적표  : 날짜, 파트코드, 파트명으로 월별data를 생성해서 보관한다. 
        PARAMETER
                AS_YMD - 실적 생성하고자 하는 일자 ( YYYY MM DD )
                               SALEPART_DAILY_COMPLEMENT YYYY MM 으로 월 단뒤 저장
                AS_USER_FLAG - Y 휴일관리의 내용도 저장해 주기로
                                          N 일일실적생성만 진행
                AS_DO - 부가세 제거 값 1.1로 현재 통일 (DO 도매 JONG 종병 .....
         
        실적 값이 없는 경우 0으로 만든다
        실적값이 0인 경우는 휴일관리 내역의 TEXT을 화면에 표현하도록 설정한다.
        
        화면에서는  01~ 오늘 날짜 까지의 DATA를 다시 생성한다. 
        ------------------------------------------------------------------*/ 

        V_TMP_CNT              NUMBER; 
        V_CURR_ERROR        VARCHAR2(1000) ;
        USER_ERR                EXCEPTION;
        V_USER_FLAG           VARCHAR2(1) ;


BEGIN 
        DBMS_OUTPUT.PUT_LINE('--------------------------------- START P_SALEPART_DAILY_COMPLEMENT ');       
        V_CURR_ERROR := '';       
        V_USER_FLAG := AS_USER_FLAG;
        
        /*1. 이전 자료의 내용을 찾는다. */
        BEGIN
                V_TMP_CNT := 0;
                
                SELECT COUNT(*) /* COUNT 5개면 DATA 정상 */
                INTO V_TMP_CNT 
                FROM SALEPART_DAILY_COMPLEMENT
                WHERE DATE_TIME = SUBSTR(AS_YMD, 1, 6);  /* 월 단위 저장 */   
            
        EXCEPTION  WHEN OTHERS THEN 
                V_CURR_ERROR := 'ERR COUNT CHECK : '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                RAISE USER_ERR;  
        END;              
             

       /*1-1. DATA가 없는 경우 이번달 처음 생성하는 경우 : 01일 DATA 입니다.*/
        IF V_TMP_CNT = 0 THEN  
                BEGIN
                        DBMS_OUTPUT.PUT_LINE('NOW INSERT JOB');                 
                        INSERT INTO SALEPART_DAILY_COMPLEMENT (  DATE_TIME , PART_CD ,PART_NM , SILJUK_AMT_1   , SILJUK_AMT_2   ,   SILJUK_AMT_3   ,  SILJUK_AMT_4   ,  SILJUK_AMT_5   ,   
                          SILJUK_AMT_6   ,  SILJUK_AMT_7   ,  SILJUK_AMT_8   ,  SILJUK_AMT_9   ,  SILJUK_AMT_10  ,
                          SILJUK_AMT_11  ,  SILJUK_AMT_12  ,  SILJUK_AMT_13  ,  SILJUK_AMT_14  ,  SILJUK_AMT_15  ,
                          SILJUK_AMT_16  ,  SILJUK_AMT_17  ,  SILJUK_AMT_18  ,  SILJUK_AMT_19  ,  SILJUK_AMT_20  ,
                          SILJUK_AMT_21  ,  SILJUK_AMT_22  ,  SILJUK_AMT_23  ,  SILJUK_AMT_24  ,  SILJUK_AMT_25  ,
                          SILJUK_AMT_26  ,  SILJUK_AMT_27  ,  SILJUK_AMT_28  ,  SILJUK_AMT_29  ,  SILJUK_AMT_30  ,  SILJUK_AMT_31 )
                        SELECT SUBSTR(AS_YMD, 1, 6) AS AS_YMD
                        ,B.CODE1 AS PART_CD
                        ,NVL(B.CODE1_NM, ' ') AS PART_NM                        
                        ,ROUND( SUM(NVL(X.TOTAL_AMT, 0))  / DECODE(B.CODE1 ,'01' ,AS_DO ,'02' ,AS_JONG ,'03' ,AS_SEMI ,'04' ,AS_LOCAL ,'14' ,AS_DO2 ,1), 0 ) AS SILJUK_AMT_1
                        ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0 ,0                                                               
                        FROM SALE0007 A
                        ,( SELECT CODE1, CODE1_NM, CODE2, CODE2_NM FROM SALE0001 WHERE CODE_GB = '0013' AND CODE1 IN ('01','02','03','04','14')) B
                        ,(
                                 SELECT F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)))+    --,
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)))+    ---,
                                        sum(decode(substr(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),0)) + --,
                                        sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                  '12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))+ --, 
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) + --,                                                                            
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                        sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),'13', 
                                                DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0)) +
                                        sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),'4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),'13', 
                                        DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),'4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0))  as TOTAL_AMT                                                                           
                                   from SALE0207 GEORAE, SALE0208 GEORAE_D
                                     where GEORAE.ymd BETWEEN to_date(NVl(AS_YMD,'19000101'),'yyyymmdd') AND to_date(NVl(AS_YMD,'29000101'),'yyyymmdd')                                                                       
                                    and GEORAE.deal_no  = GEORAE_D.deal_no
                                    and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                                  group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD)                                                                                             
                        ) X
                        WHERE A.SAWON_ID = X.SAWON_ID (+) 
                        AND A.PART_GB  =  B.CODE1 
                        GROUP BY B.CODE1, NVL(B.CODE1_NM, ' ') ;
                        
                        /*처음에는 휴일관리를 강제로 한번 실행해 준다.*/
                        V_USER_FLAG := 'Y';
                EXCEPTION WHEN OTHERS THEN
                        V_CURR_ERROR := 'ERR 01 INSERT '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                        RAISE USER_ERR;
                END;
        /*1-2. 이미 등록되어 있는 경우 01일을 등록한 이후는 이곳을 타게 되어 있음*/         
        ELSE
                DBMS_OUTPUT.PUT_LINE('NOW UPDATE JOB');      
                FOR C1 IN (                                       
                        SELECT AS_YMD AS AS_YMD
                        ,B.CODE1 AS PART_CD
                        ,NVL(B.CODE1_NM, ' ') AS PART_NM                        
                        ,ROUND( SUM(NVL(X.TOTAL_AMT, 0))  / DECODE(B.CODE1 ,'01' ,AS_DO ,'02' ,AS_JONG ,'03' ,AS_SEMI ,'04' ,AS_LOCAL ,'14' ,AS_DO2 ,1), 0 ) AS SILJUK_AMT                                                                                            
                        FROM SALE0007 A
                        ,( SELECT CODE1, CODE1_NM, CODE2, CODE2_NM FROM SALE0001 WHERE CODE_GB = '0013' AND CODE1 IN ('01','02','03','04','14')) B
                        ,(
                                 SELECT F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD) SAWON_ID,
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'05',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'10',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'70',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'90',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'99',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)))+    --,
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'20',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0)))+    ---,
                                        sum(decode(substr(GEORAE.DEAL_GB,1,1),'1',DECODE(GEORAE.DEAL_GB, '10', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),0)) + --,
                                        sum(decode(GEORAE.DEAL_GB,'07',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),
                                                                  '12',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))+ --, 
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'60',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) + --,                                                                            
                                        sum(decode(GEORAE.DEAL_GB,'07',0,'08',0,'10',0,'11',0,'12',0,'13',0,'14',0,'15',0,'20',0, decode(F_GET_SALE0003H_CUSTGB1(GEORAE.RCUST_ID, GEORAE.YMD),'80',NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),0))) +
                                        sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)),'13', 
                                                DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', 0, '4', 0, NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0)), 0)) +
                                        sum(decode(GEORAE.DEAL_GB,'08', DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),'4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0),'13', 
                                        DECODE(SUBSTR(GEORAE.CUST_ID,1,1),'3', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0),'4', NVL(GEORAE_D.amt,0)+NVL(GEORAE_D.vat,0)-NVL(GEORAE_D.dc_amt*1.1,0), 0), 0))  as TOTAL_AMT                                                                           
                                   from SALE0207 GEORAE, SALE0208 GEORAE_D
                                     where GEORAE.ymd BETWEEN to_date(NVl(AS_YMD,'19000101'),'yyyymmdd') AND to_date(NVl(AS_YMD,'29000101'),'yyyymmdd')                                                                       
                                    and GEORAE.deal_no  = GEORAE_D.deal_no
                                    and (NVL(GEORAE_D.amt,0) <> 0 or NVL(GEORAE_D.vat,0) <> 0 or NVL(GEORAE_D.dc_amt, 0) <> 0)
                                  group by F_GET_SALE0405_SAWONIDH(GEORAE.DEAL_NO, GEORAE.CUST_ID, GEORAE.RCUST_ID, GEORAE_D.ITEM_ID, GEORAE.YMD)                                                                                             
                        ) X
                        WHERE A.SAWON_ID = X.SAWON_ID 
                        AND A.PART_GB  =  B.CODE1 
                        GROUP BY B.CODE1, NVL(B.CODE1_NM, ' ')     
                ) LOOP
                        IF SUBSTR(C1.AS_YMD, 7, 2) = '01' THEN  
                                BEGIN      
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_1 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD; 
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 01 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '02' THEN  
                                BEGIN      
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_2 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD; 
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 02 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '03' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_3 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 03 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '04' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_4 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 04 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '05' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_5 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 05 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;              
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '06' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_6 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 06 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '07' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_7 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 07 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;  
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '08' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_8 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 08 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '09' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_9 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 09 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '10' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_10 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 10 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;              
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '11' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_11 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 11 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '12' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_12 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 12 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END; 
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '13' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_13 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 13 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '14' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_14 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 14 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '15' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_15 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 15 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;              
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '16' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_16 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 16 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '17' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_17 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 17 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;  
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '18' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_18 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 18 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '19' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_19 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 19 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '20' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_20 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 20 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END; 
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '21' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_21 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 21 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '22' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_22 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 22 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END; 
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '23' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_23 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 23 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '24' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_24 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 24 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '25' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_25 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 25 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;              
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '26' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_26 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 26 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '27' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_27 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 27 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;  
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '28' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_28 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 28 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '29' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_29 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 29 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '30' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_30 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 30 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END; 
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '31' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET SILJUK_AMT_31 = C1.SILJUK_AMT
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 31 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END; 
                        END IF;                        
                END LOOP;             
        END IF; 

        
        /*2. 일일실적에 사용될 휴일관리내용을 UPDATE 한다.*/       
        IF V_USER_FLAG = 'Y' THEN
                DBMS_OUTPUT.PUT_LINE('NOW AS_USER_FLAG JOB');      
                FOR C1 IN (
                SELECT AS_YMD
                            ,PART_CD
                            ,PART_NM 
                            ,HOLIDAY
                 FROM (                            
                        SELECT A.HOLI_DT  AS AS_YMD
                                    ,B.CODE1 AS PART_CD
                                    ,NVL(B.CODE1_NM, ' ') AS PART_NM
                                    ,NVL(A.REMARK, '-') AS HOLIDAY
                        FROM HANAHR.HR_CO_HOLIDA_0 A 
                               ,( SELECT CODE1, CODE1_NM, CODE2, CODE2_NM FROM SALE0001 WHERE CODE_GB = '0013' AND CODE1 IN ('01','02','03','04','14') ) B
                        WHERE HOLI_DT BETWEEN AS_YMD and AS_YMD
                        UNION
                        SELECT --TO_CHAR(RQ_FR_DT, 'YYYYMMDD') AS AS_YMD
                                     AS_YMD AS AS_YMD
                                    ,B.CODE1 AS PART_CD
                                    ,NVL(B.CODE1_NM, ' ') AS PART_NM
                                    ,'공동연차' AS HOLIDAY
                        FROM HANAHR.HR_WK_DLIAPP_0 A
                        ,( SELECT CODE1, CODE1_NM, CODE2, CODE2_NM FROM SALE0001 WHERE CODE_GB = '0013' AND CODE1 IN ('01','02','03','04','14') ) B
                        WHERE RQ_REMARK LIKE '%공동연차%'
                        AND AS_YMD BETWEEN TO_CHAR(RQ_FR_DT, 'YYYYMMDD') AND TO_CHAR(RQ_TO_DT, 'YYYYMMDD') 
                        GROUP BY A.RQ_FR_DT, B.CODE1, NVL(B.CODE1_NM, ' ')     
                           )
                ) LOOP
                        IF SUBSTR(C1.AS_YMD, 7, 2) = '01' THEN  
                                BEGIN      
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_1 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD; 
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 01 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '02' THEN  
                                BEGIN      
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_2 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD; 
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 02 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '03' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_3 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 03 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '04' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_4 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 04 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '05' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_5 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 05 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;              
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '06' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_6 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 06 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '07' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_7 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 07 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;  
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '08' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_8 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 08 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '09' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_9 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 09 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '10' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_10 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 10 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;              
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '11' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_11 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 11 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '12' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_12 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 12 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END; 
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '13' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_13 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 13 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '14' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_14 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 14 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '15' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_15 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 15 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;              
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '16' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_16 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 16 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '17' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_17 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 17 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;  
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '18' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_18 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 18 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '19' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_19 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 19 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '20' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_20 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 20 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END; 
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '21' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_21 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 21 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '22' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_22 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 22 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END; 
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '23' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_23 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 23 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '24' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_24 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 24 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '25' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_25 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 25 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;              
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '26' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_26 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 26 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '27' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_27 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 27 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;  
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '28' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_28 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 28 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;       
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '29' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_29 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 29 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END;   
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '30' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_30 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 30 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END; 
                        ELSIF SUBSTR(C1.AS_YMD, 7, 2) = '31' THEN
                                BEGIN
                                        UPDATE SALEPART_DAILY_COMPLEMENT SET HOLIDAY_31 = C1.HOLIDAY
                                        WHERE DATE_TIME = SUBSTR(C1.AS_YMD, 1, 6) 
                                        AND PART_CD = C1.PART_CD;   
                                EXCEPTION WHEN OTHERS THEN
                                        V_CURR_ERROR := 'ERR 31 UPDATE '||' 에러 '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                                        RAISE USER_ERR;
                                END; 
                        END IF;                        
                END LOOP; 
        END IF; 
    
        COMMIT;    
        DBMS_OUTPUT.PUT_LINE('--------------------------------- END P_SALEPART_DAILY_COMPLEMENT');     
  
EXCEPTION   
    WHEN USER_ERR THEN
            RAISE_APPLICATION_ERROR(-20001, V_CURR_ERROR);             
            ROLLBACK;
            
             /* ERR 처리 결과 저장 */
            INSERT INTO SALEPART_DAILY_COMPLEMENT (DATE_TIME, PART_CD, PROC_COMMENT) 
            SELECT TO_CHAR(SYSDATE, 'YYYYMM') ,'99999',V_CURR_ERROR||TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') FROM DUAL ;      
            COMMIT; 
            RETURN;
    WHEN OTHERS THEN
            V_CURR_ERROR := 'ERR OTHERS ' || TO_CHAR(SQLCODE)|| '-'|| substr(sqlerrm, 1, 90);
            DBMS_OUTPUT.PUT_LINE(V_CURR_ERROR);
            ROLLBACK;
            
            /* ERR 처리 결과 저장 */
            INSERT INTO SALEPART_DAILY_COMPLEMENT (DATE_TIME, PART_CD, PROC_COMMENT) 
            SELECT TO_CHAR(SYSDATE, 'YYYYMM') ,'99999',V_CURR_ERROR||TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS') FROM DUAL ;          
            COMMIT; 
            RETURN;
    
END P_SALEPART_DAILY_COMPLEMENT;

/
