CREATE function      F_GET_DANGA
        ( A_CUST_ID      VARCHAR2, -- 직납처
          A_RCUST_ID     VARCHAR2, -- 간납처
          A_ITEM_ID      VARCHAR2  -- 제품코드 
        )
   RETURN VARCHAR2
AS
   V_CNT        NUMBER ;
   V_OUT_DANGA  NUMBER ;
   
/*----------------------------------------------------------------
 2017.09.20 KTA
 제품이  비급여여부에 따라 단가 다르게 적용
 - 급여 -> SALE0004 의 OUT_DANGA
 - 비급여 -> SALE0405 의 BAL_AMT
  
  호출하는곳 : SP_SFA_ITEM_MULTI_139 
----------------------------------------------------------------*/

BEGIN

       V_CNT := 0;
       V_OUT_DANGA := 0;
       
       SELECT COUNT(*)
         INTO V_CNT
         FROM SALE0004
        WHERE ITEM_ID  = A_ITEM_ID
          AND NOPAYITEM_YN = 'Y';
                    
       IF V_CNT > 0 THEN                 
           SELECT NVL(BAL_AMT,0)
             INTO V_OUT_DANGA
             FROM SALE0405
            WHERE CUST_ID  = A_CUST_ID
              AND RCUST_ID = A_RCUST_ID
              AND ITEM_ID  = A_ITEM_ID
              AND YMD >=to_char(sysdate,'yyyymmdd');  
       ELSE
           SELECT OUT_DANGA
             INTO V_OUT_DANGA
             FROM SALE0004
            WHERE ITEM_ID  = A_ITEM_ID;       
                     
       END IF; 
       
       RETURN NVL(V_OUT_DANGA,0);
       
EXCEPTION WHEN OTHERS THEN
       RETURN 0;
END;
/
