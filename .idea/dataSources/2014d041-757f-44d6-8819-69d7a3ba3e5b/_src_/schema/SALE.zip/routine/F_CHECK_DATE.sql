CREATE function F_CHECK_DATE
        ( a_gb          VARCHAR2,
          a_value       VARCHAR2)
   RETURN VARCHAR2
AS
   user_err     exception   ;
   v_curr_jakup varchar2(100) ;
   v_curr_error varchar2(100) ;
   v_message    varchar2(250) ;

   v_rtn_value VARCHAR2(10) ;
   
   v_gb        varchar2(10) ;
   v_value     varchar2(20) ;
   v_length    Number ;
   v_count     Number ;
   v_dummy     varchar2(20) ;
BEGIN
  
    Begin
        If NVL(LTRIM(RTRIM(a_value)), ' ') = ' ' Then
           goto the_end;
        End if ;
        v_rtn_value := 'FALSE';
        v_gb    := upper(a_gb) ;
        IF v_gb = 'YM' THEN
           v_gb := 'YYYYMM' ;
        ELSIF v_gb = 'YMD' THEN
           v_gb := 'YYYYMMDD' ;
        END IF ;
        
        v_value := a_value ;
        v_length := Lengthb(v_value) ;
        
        v_curr_jakup := '파라미터값 확인: ' ;
        If v_length < 4 or v_length > 8 Then
           v_curr_error := '확인할 일자 값의 길이가 4보다 작거나 8보다 큼.=> '||v_value ;
           RAISE user_err ;
        End If;
        If v_gb != 'YYYY'   and 
           v_gb != 'YYYYMM' and 
           v_gb != 'YYYYMMDD'    and 
           v_gb != 'YYYYMMDDHH24MISS'  Then
           v_curr_error := 'Date타입을 정의하는 값은 YYYY,YYYYMM,YM,YMD,YYYYMMDD 이중 하나여야 함.' ;
           RAISE user_err ;
        End If;
        
        If (v_gb = 'YYYY'     and v_length != 4) or
           (v_gb = 'YYYYMM'   and v_length != 6) or
           (v_gb = 'YYYYMMDD' and v_length != 8) or
           (v_gb = 'YYYYMMDDHH24MISS' and v_length != 14) Then
           v_curr_error := 'Date타입을 정의하는 값 대비 날짜값의 길이가 맞지 않음.=> '||a_gb||'/'||v_value ;
           RAISE user_err ;
        End If;

        v_curr_jakup := '년월일값 확인: ' ;        
        If substrb(v_value,1,4) < '0001' or substrb(v_value,1,4) > '9999' Then
           v_curr_error := '년도값 오류.=> '||v_value ;
           RAISE user_err ;
        End If;
        If v_gb != 'YYYY' and
           (substrb(v_value,5,2) < '01' or substrb(v_value,5,2) > '12') Then
           v_curr_error := '월값 오류.=> '||v_value ;
           RAISE user_err ;
        End If;
        If (v_gb = 'YYYYMMDD' or v_gb = 'YYYYMMDDHH24MISS')  Then
           select substrb(to_char(last_day(to_date(substrb(v_value,1,6),'yyyymm')),'YYYYMMDD'),7,2)
             into v_dummy
             from dual ;
           If (substrb(v_value,7,2) < '01' or substrb(v_value,7,2) > v_dummy) Then
              v_curr_error := '일자값 오류.=> '||substrb(v_value,7,2) ;
              RAISE user_err ;
           End If;
        End If;
        <<the_end>>
        v_rtn_value := 'TRUE';
 
    EXCEPTION WHEN user_err THEN
                   RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_jakup||v_curr_error,1,250));
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_jakup||v_curr_error||SQLERRM,1,250));
    END ;

    RETURN v_rtn_value;
END;

/
