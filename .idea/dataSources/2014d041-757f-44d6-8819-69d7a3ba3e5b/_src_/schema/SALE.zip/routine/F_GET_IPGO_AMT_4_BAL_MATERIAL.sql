CREATE function F_GET_IPGO_AMT_4_BAL_MATERIAL
        ( a_balju_no     VARCHAR2, -- 발주번호
          a_material_id  VARCHAR2  -- 원부자재 코드
        )
   RETURN number
AS
   user_err     exception   ;
   v_curr_jakup varchar2(100) ;
   v_curr_error varchar2(100) ;
   v_message    varchar2(250) ;

   n_rtn_value   varchar2(50) ;
   
   v_balju_no    varchar2(10) ;
   v_material_id varchar2(10) ;
   v_count       Number ;
   v_dummy       varchar2(20) ;
BEGIN
  
    Begin
        v_curr_jakup  := '조건 확인: ' ;
        n_rtn_value   := ' ' ;
        v_balju_no    := LTRIM(RTRIM(a_balju_no)) ;
        v_material_id := LTRIM(RTRIM(a_material_id)) ;

        If NVL(v_balju_no, ' ') = ' ' or NVL(v_material_id, ' ') = ' ' Then
           goto the_end;
        End if ;
        
        v_curr_jakup  := '입고금액 구하기: ' ;
        SELECT NVL(SUM(A.amt),0)
          INTO n_rtn_value
          FROM INV0302 A, -- 원부자재입출고전표 Detail
               INV0301 B, -- 원부자재입출고전표 Master
               INV0001 C  -- 전표(장표)구분코드
         WHERE A.balju_no    = v_balju_no
           AND A.material_id = v_material_id
           AND A.ymd         = B.ymd
           AND A.slip_no     = B.slip_no
           AND B.junpyogb_cd = C.junpyogb_cd
           AND C.ipchul_gb   = '1' ;  -- 입출구분 1 입고, 2 출고
           
        <<the_end>>
        RETURN n_rtn_value;

    EXCEPTION WHEN user_err THEN
                   RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_jakup||v_curr_error,1,250));
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_jakup||v_curr_error||SQLERRM,1,250));
    END ;
    
END;



/
