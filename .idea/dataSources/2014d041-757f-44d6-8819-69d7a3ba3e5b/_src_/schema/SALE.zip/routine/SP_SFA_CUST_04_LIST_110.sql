CREATE PROCEDURE      SP_SFA_CUST_04_LIST_110
(
    in_SAWON_ID          IN  VARCHAR2,     -- 사용자 ID
    in_SFA_SALES_SEQ     IN  NUMBER,       -- 거래처 코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 고객 상세 하단 리스트
 호출프로그램 :
 수정내역     : 20130115-출신학교,전공과목,취미,친밀도 항목추가        
 진료과명 코드와 이름으로 분리 110 생성
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_client_no          NUMBER;
    v_main_client        NUMBER;

    CUST_CD_NULL         EXCEPTION;

BEGIN

 --insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_04_LIST_109','1',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_SFA_SALES_SEQ:'||in_SFA_SALES_SEQ);
 
   IF in_SFA_SALES_SEQ IS NULL OR TRIM(in_SFA_SALES_SEQ) = '' THEN
        RAISE CUST_CD_NULL;
    END IF;

    SELECT COUNT(*)
      INTO v_num
      FROM SFA_COM_CUSTOMER
     WHERE SFA_SALES_SEQ  = in_SFA_SALES_SEQ  
       AND NVL(DEL_YN, 'N') = 'N';

    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '고객 정보가 존재하지 않습니다.';
    ELSIF (v_num >= 1) THEN
        out_COUNT := v_num;
        out_CODE := 0;
        out_MSG := '고객 정보 확인완료';

        OPEN out_RESULT FOR
           SELECT  SFA_SALES_SEQ  AS out_SFA_SALES_SEQ   --거래처키값
                 , ( SELECT SFA_SALES_NO FROM SFA_SALES_CODE A WHERE  A.SFA_SALES_SEQ = B.SFA_SALES_SEQ ) AS out_CUST_CD --sfa거래처코드
                 , ( SELECT TRADE_NAME   FROM SFA_SALES_CODE A WHERE  A.SFA_SALES_SEQ = B.SFA_SALES_SEQ ) AS out_CUST_NM --sfa거래처명    
                 , SFA_CLIENT_NO      AS out_CLIENT_NO     --고객번호
                 , CLIENT_GUBUN       AS out_CLIENT_GUBUN  --고객구분(01:대표,02:의사,03:약사, 04:사무장, 05:일반)
                 , CLIENT_DEPT        AS out_CLIENT_DEPT   --고객소thr => 진료과명으로 변경
                 , POSITION_NAME      AS out_POSITION_NM --직책
                 , CLIENT_NAME        AS out_CLIENT_NM     --고객명
                 , MALE               AS out_MALE          --성별
                 , TEL_NO             AS out_TEL_NO        --전화번호
                 , HP_NO              AS out_HP_NO         --휴대폰번호
                 , EMAIL              AS out_EMAIL         --이메일
                 , BIRTHDAY           AS out_BIRTHDAY      --생년월일
                 , BIRTHDAY_GUBUN     AS out_BIRTHDAY_GUBUN --생일구분(음/양)
                 , ZIP_CODE           AS out_ZIP_CODE       --우편번호
                 , DETAIL_ADDR1       AS out_DETAIL_ADDR1   --주소
                 , DETAIL_ADDR2       AS out_DETAIL_ADDR2   --상세주소
                 , MARRY_YN           AS out_MARRY_YN       --결혼여부
                 , MARRY_DAY          AS out_MARRY_DAY      --결혼일  
                 , fn_get_codenm('0061' ,B.CLIENT_GUBUN)    AS out_CLIENT_GUBUNNM --고객구분명 
                 , fn_get_codenm('0072' ,B.CLIENT_DEPT)       AS out_CLIENT_DEPTNM   --CHOE 20160630 진료과명
                 , LASTSCHOOLNM       AS out_LASTSCHOOLNM    --출신학교     
                 , MAJORSUBJECT       AS out_MAJORSUBJECT   --전공학과
                 , HOBBY              AS out_HOBBY          --취미     
                 , FRIENDSHIP         AS out_FRIENDSHIP     --고객과친밀도    
            FROM SFA_COM_CUSTOMER B
         WHERE SFA_SALES_SEQ  = in_SFA_SALES_SEQ
           AND NVL(DEL_YN, 'N') = 'N';
    END IF;

EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG := '거래처코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
