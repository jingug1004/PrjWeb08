CREATE PROCEDURE      SP_Z_OFFICE_12
(
    in_SANGBYEONG_NM    IN  VARCHAR2,  
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
/*---------------------------------------------------------------------------
프로그램명   : 상병코드조회  
호출프로그램 : 제품> 상병코드       
          2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
---------------------------------------------------------------------------*/    

        v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_SANGBYUNGCODE
     WHERE sangbyung_nm LIKE '%'||NVL(in_SANGBYEONG_NM, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT sangbyung_cd        AS out_SANGBYEONG_CD,        -- 브로셔 CD
               sangbyung_seq       AS out_SANGBYEONG_SEQ,       -- 브로셔 SEQ
               sangbyung_nm        AS out_SANGBYEONG_NM,        -- 브로셔 명
               sangbyung_yn        AS out_SANGBYEONG_YN,        -- 브로셔 사용여부
               item_path           AS out_SANGBYEONG_PATH,      -- FILE PATH
               item_name           AS out_SANGBYEONG_NAME,      -- FILE 명
               save_item_name      AS out_SANGBYEONG_SAVE       -- DB에 저장된 파일명 
          FROM SFA_OFFICE_SANGBYUNGCODE
     WHERE sangbyung_nm LIKE '%'||NVL(in_SANGBYEONG_NM, '%')||'%'
     ORDER BY sangbyung_nm;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
