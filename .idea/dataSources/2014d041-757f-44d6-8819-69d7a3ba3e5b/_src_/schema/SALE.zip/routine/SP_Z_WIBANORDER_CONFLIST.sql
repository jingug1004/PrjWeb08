CREATE PROCEDURE      SP_Z_WIBANORDER_CONFLIST   
(
    in_SAWON_ID          IN  VARCHAR2,    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 회전일위반 주문 승인용 리스트조회
 호출프로그램 : 일일방문화면에서 내역이 있을때 팝업에서 호출된다.                    
 수정사항     :
    2015.04.15 kta 총괄지점장은 위반주문승인이 하위지점들 모두의 것이 보이도록 처리함. (김민진 차장이 중부총괄지점장과 원주팀장을 겸직하면서 위반주문승인해줘야 해서)  
    2015.06.08 KTA  - 임시팀장 직책코드 추가관련 수정  
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼               
 ---------------------------------------------------------------------------*/    

    v_num               NUMBER;    
    v_insa_sawon_id     VARCHAR2(7);
    v_query_deptcode    VARCHAR2(4);
    v_assgn_cd          VARCHAR2(5);
    v_deptcode          VARCHAR2(5);
    v_turncnt           NUMBER; 
    
BEGIN
                
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    select classdiv,deptcode into v_assgn_cd,v_deptcode from ORAGMP.CMEMPM  where empcode = in_SAWON_ID;
    
    v_query_deptcode := v_deptcode;             
    -- 조회부서:: 로그인 직책에따라 상위부서를 찾거나 본인부서를 찾는다.
    if v_assgn_cd in ('27010','27018','27023','27025','27026')  then   -- 본부장, 부본부장, 총괄이사, 총괄지점장, 선임지점장       지점장,팀장, 임시팀장('27027','27030','27035') 은 1레벨위로 안가야 함 
       select deptcode 
         into v_query_deptcode 
         from ORAGMP.CMDEPTM 
        where useyn = 'Y' and level = 2 connect by deptcode = prior predeptcode start with plantcode = '1000' and deptcode = v_deptcode;
    end if;      
    
    -- 로그인한 사원의 납품처에 납품된 제품중 거래처별단가테이블에서 담당제품으로 주문된것들...
    SELECT COUNT(*)
      INTO v_num
      from oragmp.slordm a      
     where a.plantcode = '1000' 
       and a.orderdate >= to_char(sysdate - 30,'yyyy-mm-dd')
       and a.statediv in ('01','03')   -- 01-입력 03 채권불량 
       and a.wibanorderreqyn  = 'Y'   --요청여부
       and a.wibanorderconfstatus = '0' --위반오더승인여부:0-대기,1-승인,2-반려 지점장이 처리 
       and a.empcode in ( 
                          select empcode from ORAGMP.CMEMPM --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                           where plantcode = '1000' 
                             and deptcode in (   select deptcode from ORAGMP.CMDEPTM
                                               connect by prior deptcode = predeptcode
                                                 start with plantcode = '1000' and deptcode = v_query_deptcode
                                             ) 
                         )  
       and v_assgn_cd in ('27018','27023','27025','27026','27027','27030','27035');  -- 부본부장, 총괄이사, 총괄지점장, 선임지점장, 지점장,팀장, 임시팀장,  
    
       
       
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_WIBANORDER_CONFLIST','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||' / v_query_deptcode:'||v_query_deptcode||' / v_assgn_cd:'||v_assgn_cd);
--COMMIT;
    


    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
            
        OPEN out_RESULT FOR        
            select a.orderno                                 AS out_GUMAE_NO
                  ,replace(a.orderdate,'-','')               AS out_ORDER_DATE
                  ,oragmp.fncommonnm('cust',a.custcode,'')   AS out_CUST_NM
                  ,decode(a.wibankind,'1','회전일','2','수량')   AS out_WIBAN_KIND             
                  ,oragmp.fncommonnm('emp',a.empcode,'')     AS out_SAWON_NM
                  ,a.bigo                                    AS out_PBIGO 
                  ,oragmp.fngetturncnt(a.custcode,to_char(add_months(sysdate,-1),'yyyy-mm'))  AS out_RATE_DAY -- 전 월의회전일
                  ,(select turnlmt from oragmp.cmcustm where custcode = a.custcode)   AS out_CONTROL_RATE_DAY  -- 거래처마스터의  회전일한도  
               from oragmp.slordm a    
             where a.plantcode = '1000' 
               and a.orderdate >= to_char(sysdate - 30,'yyyy-mm-dd')
               and a.statediv in ('01','03')   -- 01-입력 03 채권불량 
               and a.wibanorderreqyn  = 'Y'   --요청여부
               and a.wibanorderconfstatus = '0' --위반오더승인여부:0-대기,1-승인,2-반려 지점장이 처리 
               and a.empcode in ( 
                                  select empcode from ORAGMP.CMEMPM --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                   where plantcode = '1000'                                          
                                     and deptcode in (   select deptcode from ORAGMP.CMDEPTM
                                                        connect by prior deptcode = predeptcode
                                                          start with plantcode = '1000' and deptcode = v_query_deptcode
                                                     ) 
                                 )  
               and v_assgn_cd in ('27018','27023','27025','27026','27027','27030','27035');  -- 부본부장, 총괄이사, 총괄지점장, 선임지점장, 지점장,팀장, 임시팀장,  
       
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
