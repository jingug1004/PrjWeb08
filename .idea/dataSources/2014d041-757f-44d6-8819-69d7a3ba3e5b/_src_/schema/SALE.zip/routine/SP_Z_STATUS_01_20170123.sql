CREATE PROCEDURE      SP_Z_STATUS_01_20170123
(
    in_PART_CD           IN  VARCHAR2,     -- 파트 코드
    in_DEPT_CD           IN  VARCHAR2,     -- 부서 코드
    in_SAWON_ID          IN  VARCHAR2,     -- 사원 ID
    in_DT_FR             IN  VARCHAR2,     -- 기준일자 FROM
    in_DT_TO             IN  VARCHAR2,     -- 기준일자 TO
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 실적조회
 호출프로그램 :       
 수정기록 : 
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_gubun              NUMBER;
    p_frdate             VARCHAR2(10);
    p_todate             VARCHAR2(10);
    p_fryymm             VARCHAR2(10);
    p_toyymm             VARCHAR2(10);
    
    p_partdiv            VARCHAR2(10);
    p_deptcode           VARCHAR2(10);
    p_empcode            VARCHAR2(10);
    p_amtgb              VARCHAR2(10);
    
    DT_NULL              EXCEPTION;
BEGIN
    
    out_CODE := 1;
    out_MSG := '실적조회는  내용확인을 위해 잠시 중단합니다. 금일중 확인후에 다시 오픈할예정입니다.'; 

    --RETURN;


    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_STATUS_01',to_char(sysdate,'yyyymmdd hh24miss')||' - in_SAWON_ID:'||in_SAWON_ID,sysdate,'p_fryymm:'||p_fryymm||'/p_toyymm '||p_toyymm ||'/p_partdiv:'||p_partdiv||'/p_deptcode:'||p_deptcode||'/p_empcode:'||p_empcode);
    --commit; 

    IF in_DT_FR IS NULL OR in_DT_TO IS NULL THEN
        RAISE DT_NULL;
    END IF; 

        
    IF in_PART_CD IS NULL AND in_DEPT_CD IS NULL AND in_SAWON_ID IS NULL THEN
        v_gubun := 1;  -- 파트 전체 검색
    ELSIF in_PART_CD IS NOT NULL AND in_DEPT_CD IS NULL AND in_SAWON_ID IS NULL THEN
        v_gubun := 2;  -- 부서 전체 검색
    ELSIF in_PART_CD IS NOT NULL AND in_DEPT_CD IS NOT NULL AND in_SAWON_ID IS NULL THEN
        v_gubun := 3;  -- 사원전체
    ELSIF in_PART_CD IS NOT NULL AND in_DEPT_CD IS NOT NULL AND in_SAWON_ID IS NOT NULL THEN
        v_gubun := 4;  -- 사원선택
    END IF;
                


    p_frdate := TO_CHAR(to_date(in_DT_FR,'YYYYMMDD'),'YYYY-MM-DD');
    p_todate := TO_CHAR(to_date(in_DT_TO,'YYYYMMDD'),'YYYY-MM-DD'); 
    p_fryymm   := SUBSTR(p_frdate,1,7);
    p_toyymm   := SUBSTR(p_todate,1,7);
    
    p_partdiv  := NVL(in_PART_CD,'%'); 
    p_deptcode := NVL(in_DEPT_CD,'%'); 
    p_empcode  := NVL(in_SAWON_ID,'%');  
    
    p_amtgb    := '1'; 
     
    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_STATUS_01',to_char(sysdate,'yyyymmdd hh24miss')||' - in_SAWON_ID:'||in_SAWON_ID,sysdate,'p_fryymm:'||p_fryymm||'/p_toyymm '||p_toyymm ||'/p_partdiv:'||p_partdiv||'/p_deptcode:'||p_deptcode||'/p_empcode:'||p_empcode);

    IF v_gubun = 1 THEN  -- 파트: 전 체  부서 : 전체  담당자: 전체   파트별 실적- 직능별 조회

        SELECT count(*)
          INTO v_num
          FROM (
          
                     SELECT X.PARTDIV                                AS PARTDIV                    ,  --직능코드
                        MAX(C.DIVNAME)                                AS PARTDIVNAME              --직능명(파트명)
                       FROM
                         ( SELECT NVL(A.PARTDIV, '99')               AS PARTDIV                 ,
                              A.DEPTCODE                         AS DEPTCODE                ,
                              A.EMPCODE                          AS EMPCODE                 
                             FROM
                                ( --목표
                                  SELECT A.UTDIV                                                   AS PARTDIV                 ,
                                     A.DEPTCODE                                                AS DEPTCODE                ,
                                     A.EMPCODE                                                 AS EMPCODE
                                    FROM oragmp.SLTARGETSALEM A
                                   WHERE A.YEARMONTH BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.UTDIV   ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.DEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EMPCODE ,' ') LIKE p_empcode  || '%'
                                GROUP BY A.UTDIV, A.DEPTCODE, A.EMPCODE
                               UNION ALL
                                  --판매
                                  SELECT B.ITPARTDIV                                                                                                                    AS PARTDIV                 ,
                                     B.ITDEPTCODE                                                                                                                   AS DEPTCODE                ,  --부서코드
                                     B.EMPCODE                                                                                                                      AS EMPCODE                    --사원코드
                                    FROM oragmp.SLORDM A,
                                         oragmp.SLORDD B
                                   WHERE A.STATEDIV = '09'
                                     AND A.ORDERNO  = B.ORDERNO
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(B.ITPARTDIV ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(B.ITDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(B.EMPCODE   ,' ') LIKE p_empcode  || '%'
                                GROUP BY B.ITPARTDIV, B.ITDEPTCODE, B.EMPCODE
                               UNION ALL
                                  --수금
                                  SELECT A.PARTDIV                                                                                                                      AS PARTDIV              ,
                                     A.EDEPTCODE                                                                                                                    AS DEPTCODE                 ,  --부서코드
                                     A.EEMPCODE                                                                                                                     AS EMPCODE                     --사원코드
                                    FROM oragmp.SLCOLM A
                                   WHERE A.STATEDIV = '09'
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                     AND A.COLDIV <> '55'   --잔고이월 제외 
                                     AND A.COLDIV NOT LIKE '3%'
                                GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                UNION ALL
                                SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                   A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                   A.EEMPCODE                                                                                                                     AS EMPCODE                   --사원코드
                                  FROM oragmp.SLCOLM A
                                 WHERE A.STATEDIV = '09'
                                   AND SUBSTR(A.APPDATE,1,7) BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_fryymm || '01','YYYY-MM-DD'), -24), 'YYYY-MM') AND p_toyymm
                                   AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                   AND A.COLDIV <> '55'   --잔고이월 제외 
                                   AND A.COLDIV LIKE '3%'
                              GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                ) A
                         GROUP BY A.PARTDIV, A.DEPTCODE, A.EMPCODE
                         ) X,
                           oragmp.CMEMPM    A,
                           oragmp.CMDEPTM   B,
                           oragmp.CMCOMMONM C
                     WHERE X.EMPCODE  = A.EMPCODE (+)
                       AND X.DEPTCODE = B.DEPTCODE(+)
                       AND 'SL90'     = C.CMMCODE (+) -- 직능분류 10-종병 20-병원 30-의원 40-도매 
                       AND X.PARTDIV  = C.DIVCODE (+)
                       AND ROWNUM = 1
                     GROUP BY X.PARTDIV
               ); 
        
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
           
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
            
           OPEN out_RESULT FOR
           SELECT PARTDIV            AS out_GUBUN_CD         -- 구분코드           
                 ,PARTDIVNAME        AS out_GUBUN_NM         -- 구분명                           
                 ,'XX'               AS out_RPT_GB           -- 생성구분         
                 ,SALE_AMT           AS out_SALE_AMT         -- 판매목표           
                 ,SALE_AMT_SILJUK    AS out_SALE_AMT_SILJUK  -- 판매금액           
                 ,SALE_PERCENT       AS out_SALE_PERCENT     -- 판매달성율         
                 ,IN_AMT             AS out_IN_AMT           -- 수금목표           
                 ,IN_AMT_SILJUK      AS out_IN_AMT_SILJUK    -- 수금금액           
                 ,IN_PERCENT         AS out_in_PERCENT       -- 수금달성율  
                 ,TO_CHAR(SYSDATE,'YYYY-MM-DD hh24:mi') || ' 약정가기준' AS out_PROC_DATE        -- batch data 생성시각
            FROM (              
                     SELECT X.PARTDIV                                AS PARTDIV                    ,  --직능코드
                            MAX(C.DIVNAME)                                AS PARTDIVNAME                ,  --직능명(파트명)
                            SUM(X.SALE_AMT)                          AS SALE_AMT                   ,  --판매목표
                            SUM(X.SALE_AMT_SILJUK_BYUNG)             AS SALE_AMT_SILJUK_BYUNG      ,  --판매종합병원
                            SUM(X.SALE_AMT_SILJUK_MBYUNG)            AS SALE_AMT_SILJUK_MBYUNG     ,  --판매준종합병원
                            SUM(X.SALE_AMT_SILJUK_IN)                AS SALE_AMT_SILJUK_IN         ,  --
                            SUM(X.SALE_AMT_SILJUK_IN_LOCAL)          AS SALE_AMT_SILJUK_IN_LOCAL   ,  --판매도매로컬
                            SUM(X.SALE_AMT_SILJUK_IN_01)             AS SALE_AMT_SILJUK_IN_01      ,  --판매의원
                            SUM(X.SALE_AMT_SILJUK_IN_02)             AS SALE_AMT_SILJUK_IN_02      ,  --판매일반간납
                            SUM(X.SALE_AMT_SILJUK_IN_03)             AS SALE_AMT_SILJUK_IN_03      ,  --판매턴키
                            SUM(X.SALE_AMT_SILJUK_IN_04)             AS SALE_AMT_SILJUK_IN_04      ,  --판매입찰
                            SUM(X.SALE_AMT_SILJUK_IN_05)             AS SALE_AMT_SILJUK_IN_05      ,  --판매기타
                            SUM(X.SALE_AMT_SILJUK_OUT)               AS SALE_AMT_SILJUK_OUT        ,  --판매약국
                            SUM(X.SALE_AMT_BANPUM)                   AS SALE_AMT_BANPUM            ,  --판매반품
                            SUM(X.SALE_AMT_HALIN)                    AS SALE_AMT_HALIN             ,  --판매매출할인
                            SUM(X.SALE_AMT_HALINS01)                 AS SALE_AMT_HALINS01          ,  --판매수금할인(일반)
                            SUM(X.SALE_AMT_HALINS02)                 AS SALE_AMT_HALINS02          ,  --판매수금할인(조건)
                            SUM(X.SALE_AMT_SILJUK_IN)     + SUM(X.SALE_AMT_SILJUK_OUT) + SUM(X.SALE_AMT_SILJUK_BYUNG) +
                            SUM(X.SALE_AMT_SILJUK_MBYUNG) + SUM(X.SALE_AMT_BANPUM)     + (SUM(X.SALE_AMT_HALIN)       +
                            SUM(X.SALE_AMT_HALINS01))                AS SALE_AMT_SILJUK            ,  --판매계(수금할인조건제외)
                            DECODE(SUM(NVL(X.SALE_AMT,0)),0, 0,
                            ROUND((SUM(X.SALE_AMT_SILJUK_IN)    + SUM(X.SALE_AMT_SILJUK_OUT)    +
                                   SUM(X.SALE_AMT_SILJUK_BYUNG) + SUM(X.SALE_AMT_SILJUK_MBYUNG) +
                                   SUM(X.SALE_AMT_BANPUM)       + SUM(X.SALE_AMT_HALIN)         +
                                   SUM(X.SALE_AMT_HALINS01))    / SUM(X.SALE_AMT) * 100,2))
                                                                     AS SALE_PERCENT               ,  --
                            SUM(X.IN_AMT)                            AS IN_AMT                     ,  --수금목표
                            SUM(X.IN_AMT_SILJUK_BYUNG)               AS IN_AMT_SILJUK_BYUNG        ,  --수금종합병원
                            SUM(X.IN_AMT_SILJUK_MBYUNG)              AS IN_AMT_SILJUK_MBYUNG       ,  --수금준종합병원
                            SUM(X.IN_AMT_SILJUK_IN)                  AS IN_AMT_SILJUK_IN           ,  --
                            SUM(X.IN_AMT_SILJUK_IN_LOCAL)            AS IN_AMT_SILJUK_IN_LOCAL     ,  --수금도매
                            SUM(X.IN_AMT_SILJUK_IN_01)               AS IN_AMT_SILJUK_IN_01        ,  --수금의원
                            SUM(X.IN_AMT_SILJUK_IN_02)               AS IN_AMT_SILJUK_IN_02        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_03)               AS IN_AMT_SILJUK_IN_03        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_04)               AS IN_AMT_SILJUK_IN_04        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_05)               AS IN_AMT_SILJUK_IN_05        ,  --수금기타
                            SUM(X.IN_AMT_SILJUK_OUT)                 AS IN_AMT_SILJUK_OUT          ,  --수금약국
                            SUM(X.IN_AMT_SILJUK_IN)                  AS IN_AMT_SILJUK              ,  --수금계                              
                            DECODE(SUM(NVL(X.IN_AMT,0)), 0, 0,
                            ROUND((SUM(X.IN_AMT_SILJUK_IN)      + SUM(X.IN_AMT_SILJUK_OUT) +
                                   SUM(X.IN_AMT_SILJUK_BYUNG)   +
                                   SUM(X.IN_AMT_SILJUK_MBYUNG)) / SUM(X.IN_AMT) * 100,2))
                                                                     AS IN_PERCENT                    --수금달성률
                      FROM
                         ( SELECT NVL(A.PARTDIV, '99')               AS PARTDIV                 ,
                                  A.DEPTCODE                         AS DEPTCODE                ,
                                  A.EMPCODE                          AS EMPCODE                 ,
                                  SUM(A.SALE_AMT)                    AS SALE_AMT                ,
                                  SUM(A.SALE_AMT_SILJUK_BYUNG)       AS SALE_AMT_SILJUK_BYUNG   ,
                                  SUM(A.SALE_AMT_SILJUK_MBYUNG)      AS SALE_AMT_SILJUK_MBYUNG  ,
                                  SUM(A.SALE_AMT_SILJUK_IN)          AS SALE_AMT_SILJUK_IN      ,
                                  SUM(A.SALE_AMT_SILJUK_IN_LOCAL)    AS SALE_AMT_SILJUK_IN_LOCAL,
                                  SUM(A.SALE_AMT_SILJUK_IN_01)       AS SALE_AMT_SILJUK_IN_01   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_02)       AS SALE_AMT_SILJUK_IN_02   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_03)       AS SALE_AMT_SILJUK_IN_03   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_04)       AS SALE_AMT_SILJUK_IN_04   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_05)       AS SALE_AMT_SILJUK_IN_05   ,
                                  SUM(A.SALE_AMT_SILJUK_OUT)         AS SALE_AMT_SILJUK_OUT     ,
                                  SUM(A.SALE_AMT_BANPUM)             AS SALE_AMT_BANPUM         ,
                                  SUM(A.SALE_AMT_HALIN)              AS SALE_AMT_HALIN          ,
                                  SUM(A.SALE_AMT_HALINS01)           AS SALE_AMT_HALINS01       ,
                                  SUM(A.SALE_AMT_HALINS02)           AS SALE_AMT_HALINS02       ,
                                  SUM(A.IN_AMT)                      AS IN_AMT                  ,
                                  SUM(A.IN_AMT_SILJUK_IN)            AS IN_AMT_SILJUK_IN        ,
                                  SUM(A.IN_AMT_SILJUK_IN_LOCAL)      AS IN_AMT_SILJUK_IN_LOCAL  ,
                                  SUM(A.IN_AMT_SILJUK_IN_01)         AS IN_AMT_SILJUK_IN_01     ,
                                  SUM(A.IN_AMT_SILJUK_IN_02)         AS IN_AMT_SILJUK_IN_02     ,
                                  SUM(A.IN_AMT_SILJUK_IN_03)         AS IN_AMT_SILJUK_IN_03     ,
                                  SUM(A.IN_AMT_SILJUK_IN_04)         AS IN_AMT_SILJUK_IN_04     ,
                                  SUM(A.IN_AMT_SILJUK_IN_05)         AS IN_AMT_SILJUK_IN_05     ,
                                  SUM(A.IN_AMT_SILJUK_OUT)           AS IN_AMT_SILJUK_OUT       ,
                                  SUM(A.IN_AMT_SILJUK_BYUNG)         AS IN_AMT_SILJUK_BYUNG     ,
                                  SUM(A.IN_AMT_SILJUK_MBYUNG)        AS IN_AMT_SILJUK_MBYUNG
                             FROM
                                ( --목표
                                  SELECT A.UTDIV                                                   AS PARTDIV                 ,
                                         A.DEPTCODE                                                AS DEPTCODE                ,
                                         A.EMPCODE                                                 AS EMPCODE                 ,
                                         SUM(CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END) AS SALE_AMT                ,  --판매목표
                                         0                                                         AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         0                                                         AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         0                                                         AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         0                                                         AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         0                                                         AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         0                                                         AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         0                                                         AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         0                                                         AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         0                                                         AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         0                                                         AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         0                                                         AS SALE_AMT_BANPUM         ,  --매출:반품
                                         0                                                         AS SALE_AMT_HALIN          ,  --매출:매출할인외
                                         0                                                         AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         0                                                         AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         SUM(CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END) AS IN_AMT                  ,  --수금목표
                                         0                                                         AS IN_AMT_SILJUK_IN        ,  --수금:간납합계
                                         0                                                         AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매로컬
                                         0                                                         AS IN_AMT_SILJUK_IN_01     ,  --수금:의원
                                         0                                                         AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                         AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                         AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         0                                                         AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         0                                                         AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         0                                                         AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         0                                                         AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLTARGETSALEM A
                                   WHERE A.YEARMONTH BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.UTDIV   ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.DEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EMPCODE ,' ') LIKE p_empcode  || '%'
                                GROUP BY A.UTDIV, A.DEPTCODE, A.EMPCODE
                               UNION ALL
                                  --판매
                                  SELECT B.ITPARTDIV                                                                                                                    AS PARTDIV                 ,
                                         B.ITDEPTCODE                                                                                                                   AS DEPTCODE                ,  --부서코드
                                         B.EMPCODE                                                                                                                      AS EMPCODE                 ,  --사원코드
                                         0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '60'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '80'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV IN ('05','10','70','90','99')            THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '05'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '10' AND SUBSTR(A.ECUSTCODE,1,1) = '4' THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '10' AND SUBSTR(A.ECUSTCODE,1,1) > '6' THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '70'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '90'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '99'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '20'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         SUM(CASE WHEN A.SALDIV IN ('B01','B10')                                                             THEN -B.SALAMT1 ELSE 0 END) AS SALE_AMT_BANPUM         ,  --매출:반품
                                         0                                                                                                                              AS SALE_AMT_HALIN          ,  --매출:매출할인
                                         0                                                                                                                              AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         0                                                                                                                              AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN        ,  --수금:간납합계
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매로컬
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_01     ,  --수금:의원
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         0                                                                                                                              AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         0                                                                                                                              AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         0                                                                                                                              AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLORDM A,
                                         oragmp.SLORDD B
                                   WHERE A.STATEDIV = '09'
                                     AND A.ORDERNO  = B.ORDERNO
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(B.ITPARTDIV ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(B.ITDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(B.EMPCODE   ,' ') LIKE p_empcode  || '%'
                                GROUP BY B.ITPARTDIV, B.ITDEPTCODE, B.EMPCODE
                               UNION ALL
                                  --수금
                                  SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                         A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                         A.EEMPCODE                                                                                                                     AS EMPCODE                 ,  --사원코드
                                         0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                         0                                                                                                                              AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         0                                                                                                                              AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         0                                                                                                                              AS SALE_AMT_BANPUM         ,  --매출:반품
                                         SUM(CASE WHEN A.COLDIV = '52' THEN -A.COLAMT ELSE 0 END)                   AS SALE_AMT_HALIN          ,  --매출:매출할인
                                         SUM(CASE WHEN A.COLDIV = '59' AND SUBSTR(A.CUSTCODE,1,1) NOT IN ('3','4')  THEN -A.COLAMT ELSE 0 END) AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         SUM(CASE WHEN A.COLDIV = '59' AND SUBSTR(A.CUSTCODE,1,1) IN ('3','4')       THEN -A.COLAMT ELSE 0 END)                         AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN        ,  --수금:합계                                                       
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('40', '45') THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '10' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_01  ,  --수금:의원
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '99' THEN A.COLAMT 
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '20' THEN A.COLAMT 
                                                  ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '60' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '80' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLCOLM A
                                   WHERE A.STATEDIV = '09'
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                     AND A.COLDIV <> '55'   --잔고이월 제외 
                                     AND A.COLDIV NOT LIKE '3%'
                                GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE                                
                                UNION ALL        
                                SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                       A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                       A.EEMPCODE                                                                                                                     AS EMPCODE                 ,  --사원코드
                                       0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                       0                                                                                                                              AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                       0                                                                                                                              AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                       0                                                                                                                              AS SALE_AMT_BANPUM         ,  --매출:반품
                                       0                                                                  AS SALE_AMT_HALIN          ,  --매출:매출할인
                                       0                                                                  AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                       0                                                                  AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                       0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN        ,  --수금:합계                                                       
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('40', '45') THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV IN ('40', '45') AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '10' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '10' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT 
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_01  ,  --수금:의원
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '99' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '99' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT 
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '20' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '20' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                               ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '60' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '60' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '80' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '80' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                  FROM oragmp.SLCOLM A
                                 WHERE A.STATEDIV = '09'
                                   AND SUBSTR(A.APPDATE,1,7) BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_fryymm || '01','YYYY-MM-DD'), -24), 'YYYY-MM') AND p_toyymm
                                   AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                   AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                   AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                   AND A.COLDIV <> '55'   --잔고이월 제외 
                                   AND A.COLDIV LIKE '3%'
                              GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                ) A
                         GROUP BY A.PARTDIV, A.DEPTCODE, A.EMPCODE
                         ) X,
                           oragmp.CMEMPM    A,
                           oragmp.CMDEPTM   B,
                           oragmp.CMCOMMONM C
                     WHERE X.EMPCODE  = A.EMPCODE (+)
                       AND X.DEPTCODE = B.DEPTCODE(+)
                       AND 'SL90'     = C.CMMCODE (+) -- 직능분류 10-종병 20-병원 30-의원 40-도매 
                       AND X.PARTDIV  = C.DIVCODE (+)
                     GROUP BY X.PARTDIV
                     ORDER BY X.PARTDIV 
              );
         
         END IF; 
        
    END IF;   -- 파트  실적 -- 직능별 조회



 


    IF v_gubun = 2 THEN  -- 파트: 선택    부서 : 전체    담당자: 전체   부서별실적

        SELECT count(*)
          INTO v_num
          FROM (
          
                     SELECT X.DEPTCODE                               AS DEPTCODE                   ,  --부서코드
                            B.DEPTNAME                               AS DEPTNAME                      --부서명(지점/팀명)
                       FROM
                         ( SELECT NVL(A.PARTDIV, '99')               AS PARTDIV                 ,
                              A.DEPTCODE                         AS DEPTCODE                ,
                              A.EMPCODE                          AS EMPCODE                 
                             FROM
                                ( --목표
                                  SELECT A.UTDIV                                                   AS PARTDIV                 ,
                                     A.DEPTCODE                                                AS DEPTCODE                ,
                                     A.EMPCODE                                                 AS EMPCODE
                                    FROM oragmp.SLTARGETSALEM A
                                   WHERE A.YEARMONTH BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.UTDIV   ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.DEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EMPCODE ,' ') LIKE p_empcode  || '%'
                                GROUP BY A.UTDIV, A.DEPTCODE, A.EMPCODE
                               UNION ALL
                                  --판매
                                  SELECT B.ITPARTDIV                                                                                                                    AS PARTDIV                 ,
                                     B.ITDEPTCODE                                                                                                                   AS DEPTCODE                ,  --부서코드
                                     B.EMPCODE                                                                                                                      AS EMPCODE                    --사원코드
                                    FROM oragmp.SLORDM A,
                                         oragmp.SLORDD B
                                   WHERE A.STATEDIV = '09'
                                     AND A.ORDERNO  = B.ORDERNO
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(B.ITPARTDIV ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(B.ITDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(B.EMPCODE   ,' ') LIKE p_empcode  || '%'
                                GROUP BY B.ITPARTDIV, B.ITDEPTCODE, B.EMPCODE
                               UNION ALL
                                  --수금
                                  SELECT A.PARTDIV                                                                                                                      AS PARTDIV              ,
                                     A.EDEPTCODE                                                                                                                    AS DEPTCODE                 ,  --부서코드
                                     A.EEMPCODE                                                                                                                     AS EMPCODE                     --사원코드
                                    FROM oragmp.SLCOLM A
                                   WHERE A.STATEDIV = '09'
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                     AND A.COLDIV <> '55'   --잔고이월 제외 
                                     AND A.COLDIV NOT LIKE '3%'
                                GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                UNION ALL
                                SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                   A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                   A.EEMPCODE                                                                                                                     AS EMPCODE                   --사원코드
                                  FROM oragmp.SLCOLM A
                                 WHERE A.STATEDIV = '09'
                                   AND SUBSTR(A.APPDATE,1,7) BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_fryymm || '01','YYYY-MM-DD'), -24), 'YYYY-MM') AND p_toyymm
                                   AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                   AND A.COLDIV <> '55'   --잔고이월 제외 
                                   AND A.COLDIV LIKE '3%'
                              GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                ) A
                         GROUP BY A.PARTDIV, A.DEPTCODE, A.EMPCODE
                         ) X,
                           oragmp.CMEMPM    A,
                           oragmp.CMDEPTM   B,
                           oragmp.CMCOMMONM C
                     WHERE X.EMPCODE  = A.EMPCODE (+)
                       AND X.DEPTCODE = B.DEPTCODE(+)
                       AND 'SL90'     = C.CMMCODE (+) -- 직능분류 10-종병 20-병원 30-의원 40-도매 
                       AND X.PARTDIV  = C.DIVCODE (+)
                       AND ROWNUM = 1
                     GROUP BY X.PARTDIV, C.DIVNAME, X.DEPTCODE, B.DEPTNAME
               ); 
        
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
           
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
            
           OPEN out_RESULT FOR
           SELECT DEPTCODE           AS out_GUBUN_CD         -- 구분코드           
                 ,DEPTNAME           AS out_GUBUN_NM         -- 구분명                         
                 ,'XX'               AS out_RPT_GB           -- 생성구분            
                 ,SALE_AMT           AS out_SALE_AMT         -- 판매목표           
                 ,SALE_AMT_SILJUK    AS out_SALE_AMT_SILJUK  -- 판매금액           
                 ,SALE_PERCENT       AS out_SALE_PERCENT     -- 판매달성율         
                 ,IN_AMT             AS out_IN_AMT           -- 수금목표           
                 ,IN_AMT_SILJUK      AS out_IN_AMT_SILJUK    -- 수금금액           
                 ,IN_PERCENT         AS out_in_PERCENT       -- 수금달성율  
                 ,TO_CHAR(SYSDATE,'YYYY-MM-DD hh24:mi:ss') || ' 약정가기준'  AS out_PROC_DATE        -- batch data 생성시각
            FROM (              
                     SELECT X.DEPTCODE                               AS DEPTCODE                   ,  --부서코드
                            B.DEPTNAME                               AS DEPTNAME                   ,  --부서명(지점/팀명)
                            SUM(X.SALE_AMT)                          AS SALE_AMT                   ,  --판매목표
                            SUM(X.SALE_AMT_SILJUK_BYUNG)             AS SALE_AMT_SILJUK_BYUNG      ,  --판매종합병원
                            SUM(X.SALE_AMT_SILJUK_MBYUNG)            AS SALE_AMT_SILJUK_MBYUNG     ,  --판매준종합병원
                            SUM(X.SALE_AMT_SILJUK_IN)                AS SALE_AMT_SILJUK_IN         ,  --
                            SUM(X.SALE_AMT_SILJUK_IN_LOCAL)          AS SALE_AMT_SILJUK_IN_LOCAL   ,  --판매도매로컬
                            SUM(X.SALE_AMT_SILJUK_IN_01)             AS SALE_AMT_SILJUK_IN_01      ,  --판매의원
                            SUM(X.SALE_AMT_SILJUK_IN_02)             AS SALE_AMT_SILJUK_IN_02      ,  --판매일반간납
                            SUM(X.SALE_AMT_SILJUK_IN_03)             AS SALE_AMT_SILJUK_IN_03      ,  --판매턴키
                            SUM(X.SALE_AMT_SILJUK_IN_04)             AS SALE_AMT_SILJUK_IN_04      ,  --판매입찰
                            SUM(X.SALE_AMT_SILJUK_IN_05)             AS SALE_AMT_SILJUK_IN_05      ,  --판매기타
                            SUM(X.SALE_AMT_SILJUK_OUT)               AS SALE_AMT_SILJUK_OUT        ,  --판매약국
                            SUM(X.SALE_AMT_BANPUM)                   AS SALE_AMT_BANPUM            ,  --판매반품
                            SUM(X.SALE_AMT_HALIN)                    AS SALE_AMT_HALIN             ,  --판매매출할인
                            SUM(X.SALE_AMT_HALINS01)                 AS SALE_AMT_HALINS01          ,  --판매수금할인(일반)
                            SUM(X.SALE_AMT_HALINS02)                 AS SALE_AMT_HALINS02          ,  --판매수금할인(조건)
                            SUM(X.SALE_AMT_SILJUK_IN)     + SUM(X.SALE_AMT_SILJUK_OUT) + SUM(X.SALE_AMT_SILJUK_BYUNG) +
                            SUM(X.SALE_AMT_SILJUK_MBYUNG) + SUM(X.SALE_AMT_BANPUM)     + (SUM(X.SALE_AMT_HALIN)       +
                            SUM(X.SALE_AMT_HALINS01))                AS SALE_AMT_SILJUK            ,  --판매계(수금할인조건제외)
                            DECODE(SUM(NVL(X.SALE_AMT,0)),0, 0,
                            ROUND((SUM(X.SALE_AMT_SILJUK_IN)    + SUM(X.SALE_AMT_SILJUK_OUT)    +
                                   SUM(X.SALE_AMT_SILJUK_BYUNG) + SUM(X.SALE_AMT_SILJUK_MBYUNG) +
                                   SUM(X.SALE_AMT_BANPUM)       + SUM(X.SALE_AMT_HALIN)         +
                                   SUM(X.SALE_AMT_HALINS01))    / SUM(X.SALE_AMT) * 100,2))
                                                                     AS SALE_PERCENT               ,  --
                            SUM(X.IN_AMT)                            AS IN_AMT                     ,  --수금목표
                            SUM(X.IN_AMT_SILJUK_BYUNG)               AS IN_AMT_SILJUK_BYUNG        ,  --수금종합병원
                            SUM(X.IN_AMT_SILJUK_MBYUNG)              AS IN_AMT_SILJUK_MBYUNG       ,  --수금준종합병원
                            SUM(X.IN_AMT_SILJUK_IN)                  AS IN_AMT_SILJUK_IN           ,  --
                            SUM(X.IN_AMT_SILJUK_IN_LOCAL)            AS IN_AMT_SILJUK_IN_LOCAL     ,  --수금도매
                            SUM(X.IN_AMT_SILJUK_IN_01)               AS IN_AMT_SILJUK_IN_01        ,  --수금의원
                            SUM(X.IN_AMT_SILJUK_IN_02)               AS IN_AMT_SILJUK_IN_02        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_03)               AS IN_AMT_SILJUK_IN_03        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_04)               AS IN_AMT_SILJUK_IN_04        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_05)               AS IN_AMT_SILJUK_IN_05        ,  --수금기타
                            SUM(X.IN_AMT_SILJUK_OUT)                 AS IN_AMT_SILJUK_OUT          ,  --수금약국
                            SUM(X.IN_AMT_SILJUK_IN)                  AS IN_AMT_SILJUK              ,  --수금계                              
                            DECODE(SUM(NVL(X.IN_AMT,0)), 0, 0,
                            ROUND((SUM(X.IN_AMT_SILJUK_IN)      + SUM(X.IN_AMT_SILJUK_OUT) +
                                   SUM(X.IN_AMT_SILJUK_BYUNG)   +
                                   SUM(X.IN_AMT_SILJUK_MBYUNG)) / SUM(X.IN_AMT) * 100,2))
                                                                     AS IN_PERCENT                    --수금달성률
                      FROM
                         ( SELECT NVL(A.PARTDIV, '99')               AS PARTDIV                 ,
                                  A.DEPTCODE                         AS DEPTCODE                ,
                                  A.EMPCODE                          AS EMPCODE                 ,
                                  SUM(A.SALE_AMT)                    AS SALE_AMT                ,
                                  SUM(A.SALE_AMT_SILJUK_BYUNG)       AS SALE_AMT_SILJUK_BYUNG   ,
                                  SUM(A.SALE_AMT_SILJUK_MBYUNG)      AS SALE_AMT_SILJUK_MBYUNG  ,
                                  SUM(A.SALE_AMT_SILJUK_IN)          AS SALE_AMT_SILJUK_IN      ,
                                  SUM(A.SALE_AMT_SILJUK_IN_LOCAL)    AS SALE_AMT_SILJUK_IN_LOCAL,
                                  SUM(A.SALE_AMT_SILJUK_IN_01)       AS SALE_AMT_SILJUK_IN_01   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_02)       AS SALE_AMT_SILJUK_IN_02   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_03)       AS SALE_AMT_SILJUK_IN_03   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_04)       AS SALE_AMT_SILJUK_IN_04   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_05)       AS SALE_AMT_SILJUK_IN_05   ,
                                  SUM(A.SALE_AMT_SILJUK_OUT)         AS SALE_AMT_SILJUK_OUT     ,
                                  SUM(A.SALE_AMT_BANPUM)             AS SALE_AMT_BANPUM         ,
                                  SUM(A.SALE_AMT_HALIN)              AS SALE_AMT_HALIN          ,
                                  SUM(A.SALE_AMT_HALINS01)           AS SALE_AMT_HALINS01       ,
                                  SUM(A.SALE_AMT_HALINS02)           AS SALE_AMT_HALINS02       ,
                                  SUM(A.IN_AMT)                      AS IN_AMT                  ,
                                  SUM(A.IN_AMT_SILJUK_IN)            AS IN_AMT_SILJUK_IN        ,
                                  SUM(A.IN_AMT_SILJUK_IN_LOCAL)      AS IN_AMT_SILJUK_IN_LOCAL  ,
                                  SUM(A.IN_AMT_SILJUK_IN_01)         AS IN_AMT_SILJUK_IN_01     ,
                                  SUM(A.IN_AMT_SILJUK_IN_02)         AS IN_AMT_SILJUK_IN_02     ,
                                  SUM(A.IN_AMT_SILJUK_IN_03)         AS IN_AMT_SILJUK_IN_03     ,
                                  SUM(A.IN_AMT_SILJUK_IN_04)         AS IN_AMT_SILJUK_IN_04     ,
                                  SUM(A.IN_AMT_SILJUK_IN_05)         AS IN_AMT_SILJUK_IN_05     ,
                                  SUM(A.IN_AMT_SILJUK_OUT)           AS IN_AMT_SILJUK_OUT       ,
                                  SUM(A.IN_AMT_SILJUK_BYUNG)         AS IN_AMT_SILJUK_BYUNG     ,
                                  SUM(A.IN_AMT_SILJUK_MBYUNG)        AS IN_AMT_SILJUK_MBYUNG
                             FROM
                                ( --목표
                                  SELECT A.UTDIV                                                   AS PARTDIV                 ,
                                         A.DEPTCODE                                                AS DEPTCODE                ,
                                         A.EMPCODE                                                 AS EMPCODE                 ,
                                         SUM(CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END) AS SALE_AMT                ,  --판매목표
                                         0                                                         AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         0                                                         AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         0                                                         AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         0                                                         AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         0                                                         AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         0                                                         AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         0                                                         AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         0                                                         AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         0                                                         AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         0                                                         AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         0                                                         AS SALE_AMT_BANPUM         ,  --매출:반품
                                         0                                                         AS SALE_AMT_HALIN          ,  --매출:매출할인외
                                         0                                                         AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         0                                                         AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         SUM(CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END) AS IN_AMT                  ,  --수금목표
                                         0                                                         AS IN_AMT_SILJUK_IN        ,  --수금:간납합계
                                         0                                                         AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매로컬
                                         0                                                         AS IN_AMT_SILJUK_IN_01     ,  --수금:의원
                                         0                                                         AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                         AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                         AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         0                                                         AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         0                                                         AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         0                                                         AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         0                                                         AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLTARGETSALEM A
                                   WHERE A.YEARMONTH BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.UTDIV   ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.DEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EMPCODE ,' ') LIKE p_empcode  || '%'
                                GROUP BY A.UTDIV, A.DEPTCODE, A.EMPCODE
                               UNION ALL
                                  --판매
                                  SELECT B.ITPARTDIV                                                                                                                    AS PARTDIV                 ,
                                         B.ITDEPTCODE                                                                                                                   AS DEPTCODE                ,  --부서코드
                                         B.EMPCODE                                                                                                                      AS EMPCODE                 ,  --사원코드
                                         0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '60'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '80'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV IN ('05','10','70','90','99')            THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '05'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '10' AND SUBSTR(A.ECUSTCODE,1,1) = '4' THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '10' AND SUBSTR(A.ECUSTCODE,1,1) > '6' THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '70'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '90'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '99'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '20'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         SUM(CASE WHEN A.SALDIV IN ('B01','B10')                                                             THEN -B.SALAMT1 ELSE 0 END) AS SALE_AMT_BANPUM         ,  --매출:반품
                                         0                                                                                                                              AS SALE_AMT_HALIN          ,  --매출:매출할인
                                         0                                                                                                                              AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         0                                                                                                                              AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN        ,  --수금:간납합계
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매로컬
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_01     ,  --수금:의원
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         0                                                                                                                              AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         0                                                                                                                              AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         0                                                                                                                              AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLORDM A,
                                         oragmp.SLORDD B
                                   WHERE A.STATEDIV = '09'
                                     AND A.ORDERNO  = B.ORDERNO
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(B.ITPARTDIV ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(B.ITDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(B.EMPCODE   ,' ') LIKE p_empcode  || '%'
                                GROUP BY B.ITPARTDIV, B.ITDEPTCODE, B.EMPCODE
                               UNION ALL
                                  --수금
                                  SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                         A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                         A.EEMPCODE                                                                                                                     AS EMPCODE                 ,  --사원코드
                                         0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                         0                                                                                                                              AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         0                                                                                                                              AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         0                                                                                                                              AS SALE_AMT_BANPUM         ,  --매출:반품
                                         SUM(CASE WHEN A.COLDIV = '52' THEN -A.COLAMT ELSE 0 END)                   AS SALE_AMT_HALIN          ,  --매출:매출할인
                                         SUM(CASE WHEN A.COLDIV = '59' AND SUBSTR(A.CUSTCODE,1,1) NOT IN ('3','4')  THEN -A.COLAMT ELSE 0 END) AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         SUM(CASE WHEN A.COLDIV = '59' AND SUBSTR(A.CUSTCODE,1,1) IN ('3','4')       THEN -A.COLAMT ELSE 0 END)                         AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN        ,  --수금:합계                                                       
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('40', '45') THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '10' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_01  ,  --수금:의원
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '99' THEN A.COLAMT 
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '20' THEN A.COLAMT 
                                                  ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '60' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '80' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLCOLM A
                                   WHERE A.STATEDIV = '09'
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                     AND A.COLDIV <> '55'   --잔고이월 제외 
                                     AND A.COLDIV NOT LIKE '3%'
                                GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE                                
                                UNION ALL        
                                SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                       A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                       A.EEMPCODE                                                                                                                     AS EMPCODE                 ,  --사원코드
                                       0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                       0                                                                                                                              AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                       0                                                                                                                              AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                       0                                                                                                                              AS SALE_AMT_BANPUM         ,  --매출:반품
                                       0                                                                  AS SALE_AMT_HALIN          ,  --매출:매출할인
                                       0                                                                  AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                       0                                                                  AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                       0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN        ,  --수금:합계                                                       
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('40', '45') THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV IN ('40', '45') AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '10' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '10' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT 
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_01  ,  --수금:의원
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '99' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '99' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT 
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '20' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '20' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                               ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '60' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '60' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '80' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '80' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                  FROM oragmp.SLCOLM A
                                 WHERE A.STATEDIV = '09'
                                   AND SUBSTR(A.APPDATE,1,7) BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_fryymm || '01','YYYY-MM-DD'), -24), 'YYYY-MM') AND p_toyymm
                                   AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                   AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                   AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                   AND A.COLDIV <> '55'   --잔고이월 제외 
                                   AND A.COLDIV LIKE '3%'
                              GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                ) A
                         GROUP BY A.PARTDIV, A.DEPTCODE, A.EMPCODE
                         ) X,
                           oragmp.CMEMPM    A,
                           oragmp.CMDEPTM   B,
                           oragmp.CMCOMMONM C
                     WHERE X.EMPCODE  = A.EMPCODE (+)
                       AND X.DEPTCODE = B.DEPTCODE(+)
                       AND 'SL90'     = C.CMMCODE (+) -- 직능분류 10-종병 20-병원 30-의원 40-도매 
                       AND X.PARTDIV  = C.DIVCODE (+)
                     GROUP BY X.PARTDIV, C.DIVNAME, X.DEPTCODE, B.DEPTNAME
                     ORDER BY X.PARTDIV, X.DEPTCODE
              );
         
         END IF; 
        
    END IF;   -- 부서별 조회
     
    
    
    
    
    
    
    IF v_gubun = 3 THEN  -- 파트 :선택  부서: 선택   사원:전체
        SELECT count(*)
          INTO v_num
          FROM (
          
                     SELECT X.EMPCODE                                AS EMPCODE                    ,  --사원번호
                            A.EMPNAME                                AS EMPNAME                      --사원명(담당사원)
                       FROM
                         ( SELECT NVL(A.PARTDIV, '99')               AS PARTDIV                 ,
                              A.DEPTCODE                         AS DEPTCODE                ,
                              A.EMPCODE                          AS EMPCODE                 
                             FROM
                                ( --목표
                                  SELECT A.UTDIV                                                   AS PARTDIV                 ,
                                     A.DEPTCODE                                                AS DEPTCODE                ,
                                     A.EMPCODE                                                 AS EMPCODE
                                    FROM oragmp.SLTARGETSALEM A
                                   WHERE A.YEARMONTH BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.UTDIV   ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.DEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EMPCODE ,' ') LIKE p_empcode  || '%'
                                GROUP BY A.UTDIV, A.DEPTCODE, A.EMPCODE
                               UNION ALL
                                  --판매
                                  SELECT B.ITPARTDIV                                                                                                                    AS PARTDIV                 ,
                                     B.ITDEPTCODE                                                                                                                   AS DEPTCODE                ,  --부서코드
                                     B.EMPCODE                                                                                                                      AS EMPCODE                    --사원코드
                                    FROM oragmp.SLORDM A,
                                         oragmp.SLORDD B
                                   WHERE A.STATEDIV = '09'
                                     AND A.ORDERNO  = B.ORDERNO
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(B.ITPARTDIV ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(B.ITDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(B.EMPCODE   ,' ') LIKE p_empcode  || '%'
                                GROUP BY B.ITPARTDIV, B.ITDEPTCODE, B.EMPCODE
                               UNION ALL
                                  --수금
                                  SELECT A.PARTDIV                                                                                                                      AS PARTDIV              ,
                                     A.EDEPTCODE                                                                                                                    AS DEPTCODE                 ,  --부서코드
                                     A.EEMPCODE                                                                                                                     AS EMPCODE                     --사원코드
                                    FROM oragmp.SLCOLM A
                                   WHERE A.STATEDIV = '09'
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                     AND A.COLDIV <> '55'   --잔고이월 제외 
                                     AND A.COLDIV NOT LIKE '3%'
                                GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                UNION ALL
                                SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                   A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                   A.EEMPCODE                                                                                                                     AS EMPCODE                   --사원코드
                                  FROM oragmp.SLCOLM A
                                 WHERE A.STATEDIV = '09'
                                   AND SUBSTR(A.APPDATE,1,7) BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_fryymm || '01','YYYY-MM-DD'), -24), 'YYYY-MM') AND p_toyymm
                                   AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                   AND A.COLDIV <> '55'   --잔고이월 제외 
                                   AND A.COLDIV LIKE '3%'
                              GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                ) A
                         GROUP BY A.PARTDIV, A.DEPTCODE, A.EMPCODE
                         ) X,
                           oragmp.CMEMPM    A,
                           oragmp.CMDEPTM   B,
                           oragmp.CMCOMMONM C
                     WHERE X.EMPCODE  = A.EMPCODE (+)
                       AND X.DEPTCODE = B.DEPTCODE(+)
                       AND 'SL90'     = C.CMMCODE (+) -- 직능분류 10-종병 20-병원 30-의원 40-도매 
                       AND X.PARTDIV  = C.DIVCODE (+)
                       AND ROWNUM = 1
                  GROUP BY X.PARTDIV, C.DIVNAME, X.DEPTCODE, B.DEPTNAME, A.GRADEDIV, X.EMPCODE, A.EMPNAME 
               ); 
        
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
           
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
            
           OPEN out_RESULT FOR
           SELECT EMPCODE            AS out_GUBUN_CD         -- 구분코드           
                 ,EMPNAME            AS out_GUBUN_NM         -- 구분명                           
                 ,'XX'               AS out_RPT_GB           -- 생성구분           
                 ,SALE_AMT           AS out_SALE_AMT         -- 판매목표           
                 ,SALE_AMT_SILJUK    AS out_SALE_AMT_SILJUK  -- 판매금액           
                 ,SALE_PERCENT       AS out_SALE_PERCENT     -- 판매달성율         
                 ,IN_AMT             AS out_IN_AMT           -- 수금목표           
                 ,IN_AMT_SILJUK      AS out_IN_AMT_SILJUK    -- 수금금액           
                 ,IN_PERCENT         AS out_in_PERCENT       -- 수금달성율  
                 ,TO_CHAR(SYSDATE,'YYYY-MM-DD hh24:mi:ss') || ' 약정가기준'  AS out_PROC_DATE        -- batch data 생성시각
            FROM (              
                     SELECT X.EMPCODE                                AS EMPCODE                    ,  --사원번호
                            A.EMPNAME                                AS EMPNAME                    ,  --사원명(담당사원)
                            SUM(X.SALE_AMT)                          AS SALE_AMT                   ,  --판매목표
                            SUM(X.SALE_AMT_SILJUK_BYUNG)             AS SALE_AMT_SILJUK_BYUNG      ,  --판매종합병원
                            SUM(X.SALE_AMT_SILJUK_MBYUNG)            AS SALE_AMT_SILJUK_MBYUNG     ,  --판매준종합병원
                            SUM(X.SALE_AMT_SILJUK_IN)                AS SALE_AMT_SILJUK_IN         ,  --
                            SUM(X.SALE_AMT_SILJUK_IN_LOCAL)          AS SALE_AMT_SILJUK_IN_LOCAL   ,  --판매도매로컬
                            SUM(X.SALE_AMT_SILJUK_IN_01)             AS SALE_AMT_SILJUK_IN_01      ,  --판매의원
                            SUM(X.SALE_AMT_SILJUK_IN_02)             AS SALE_AMT_SILJUK_IN_02      ,  --판매일반간납
                            SUM(X.SALE_AMT_SILJUK_IN_03)             AS SALE_AMT_SILJUK_IN_03      ,  --판매턴키
                            SUM(X.SALE_AMT_SILJUK_IN_04)             AS SALE_AMT_SILJUK_IN_04      ,  --판매입찰
                            SUM(X.SALE_AMT_SILJUK_IN_05)             AS SALE_AMT_SILJUK_IN_05      ,  --판매기타
                            SUM(X.SALE_AMT_SILJUK_OUT)               AS SALE_AMT_SILJUK_OUT        ,  --판매약국
                            SUM(X.SALE_AMT_BANPUM)                   AS SALE_AMT_BANPUM            ,  --판매반품
                            SUM(X.SALE_AMT_HALIN)                    AS SALE_AMT_HALIN             ,  --판매매출할인
                            SUM(X.SALE_AMT_HALINS01)                 AS SALE_AMT_HALINS01          ,  --판매수금할인(일반)
                            SUM(X.SALE_AMT_HALINS02)                 AS SALE_AMT_HALINS02          ,  --판매수금할인(조건)
                            SUM(X.SALE_AMT_SILJUK_IN)     + SUM(X.SALE_AMT_SILJUK_OUT) + SUM(X.SALE_AMT_SILJUK_BYUNG) +
                            SUM(X.SALE_AMT_SILJUK_MBYUNG) + SUM(X.SALE_AMT_BANPUM)     + (SUM(X.SALE_AMT_HALIN)       +
                            SUM(X.SALE_AMT_HALINS01))                AS SALE_AMT_SILJUK            ,  --판매계(수금할인조건제외)
                            DECODE(SUM(NVL(X.SALE_AMT,0)),0, 0,
                            ROUND((SUM(X.SALE_AMT_SILJUK_IN)    + SUM(X.SALE_AMT_SILJUK_OUT)    +
                                   SUM(X.SALE_AMT_SILJUK_BYUNG) + SUM(X.SALE_AMT_SILJUK_MBYUNG) +
                                   SUM(X.SALE_AMT_BANPUM)       + SUM(X.SALE_AMT_HALIN)         +
                                   SUM(X.SALE_AMT_HALINS01))    / SUM(X.SALE_AMT) * 100,2))
                                                                     AS SALE_PERCENT               ,  --
                            SUM(X.IN_AMT)                            AS IN_AMT                     ,  --수금목표
                            SUM(X.IN_AMT_SILJUK_BYUNG)               AS IN_AMT_SILJUK_BYUNG        ,  --수금종합병원
                            SUM(X.IN_AMT_SILJUK_MBYUNG)              AS IN_AMT_SILJUK_MBYUNG       ,  --수금준종합병원
                            SUM(X.IN_AMT_SILJUK_IN)                  AS IN_AMT_SILJUK_IN           ,  --
                            SUM(X.IN_AMT_SILJUK_IN_LOCAL)            AS IN_AMT_SILJUK_IN_LOCAL     ,  --수금도매
                            SUM(X.IN_AMT_SILJUK_IN_01)               AS IN_AMT_SILJUK_IN_01        ,  --수금의원
                            SUM(X.IN_AMT_SILJUK_IN_02)               AS IN_AMT_SILJUK_IN_02        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_03)               AS IN_AMT_SILJUK_IN_03        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_04)               AS IN_AMT_SILJUK_IN_04        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_05)               AS IN_AMT_SILJUK_IN_05        ,  --수금기타
                            SUM(X.IN_AMT_SILJUK_OUT)                 AS IN_AMT_SILJUK_OUT          ,  --수금약국
                            SUM(X.IN_AMT_SILJUK_IN)                  AS IN_AMT_SILJUK              ,  --수금계                              
                            DECODE(SUM(NVL(X.IN_AMT,0)), 0, 0,
                            ROUND((SUM(X.IN_AMT_SILJUK_IN)      + SUM(X.IN_AMT_SILJUK_OUT) +
                                   SUM(X.IN_AMT_SILJUK_BYUNG)   +
                                   SUM(X.IN_AMT_SILJUK_MBYUNG)) / SUM(X.IN_AMT) * 100,2))
                                                                     AS IN_PERCENT                    --수금달성률
                      FROM
                         ( SELECT NVL(A.PARTDIV, '99')               AS PARTDIV                 ,
                                  A.DEPTCODE                         AS DEPTCODE                ,
                                  A.EMPCODE                          AS EMPCODE                 ,
                                  SUM(A.SALE_AMT)                    AS SALE_AMT                ,
                                  SUM(A.SALE_AMT_SILJUK_BYUNG)       AS SALE_AMT_SILJUK_BYUNG   ,
                                  SUM(A.SALE_AMT_SILJUK_MBYUNG)      AS SALE_AMT_SILJUK_MBYUNG  ,
                                  SUM(A.SALE_AMT_SILJUK_IN)          AS SALE_AMT_SILJUK_IN      ,
                                  SUM(A.SALE_AMT_SILJUK_IN_LOCAL)    AS SALE_AMT_SILJUK_IN_LOCAL,
                                  SUM(A.SALE_AMT_SILJUK_IN_01)       AS SALE_AMT_SILJUK_IN_01   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_02)       AS SALE_AMT_SILJUK_IN_02   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_03)       AS SALE_AMT_SILJUK_IN_03   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_04)       AS SALE_AMT_SILJUK_IN_04   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_05)       AS SALE_AMT_SILJUK_IN_05   ,
                                  SUM(A.SALE_AMT_SILJUK_OUT)         AS SALE_AMT_SILJUK_OUT     ,
                                  SUM(A.SALE_AMT_BANPUM)             AS SALE_AMT_BANPUM         ,
                                  SUM(A.SALE_AMT_HALIN)              AS SALE_AMT_HALIN          ,
                                  SUM(A.SALE_AMT_HALINS01)           AS SALE_AMT_HALINS01       ,
                                  SUM(A.SALE_AMT_HALINS02)           AS SALE_AMT_HALINS02       ,
                                  SUM(A.IN_AMT)                      AS IN_AMT                  ,
                                  SUM(A.IN_AMT_SILJUK_IN)            AS IN_AMT_SILJUK_IN        ,
                                  SUM(A.IN_AMT_SILJUK_IN_LOCAL)      AS IN_AMT_SILJUK_IN_LOCAL  ,
                                  SUM(A.IN_AMT_SILJUK_IN_01)         AS IN_AMT_SILJUK_IN_01     ,
                                  SUM(A.IN_AMT_SILJUK_IN_02)         AS IN_AMT_SILJUK_IN_02     ,
                                  SUM(A.IN_AMT_SILJUK_IN_03)         AS IN_AMT_SILJUK_IN_03     ,
                                  SUM(A.IN_AMT_SILJUK_IN_04)         AS IN_AMT_SILJUK_IN_04     ,
                                  SUM(A.IN_AMT_SILJUK_IN_05)         AS IN_AMT_SILJUK_IN_05     ,
                                  SUM(A.IN_AMT_SILJUK_OUT)           AS IN_AMT_SILJUK_OUT       ,
                                  SUM(A.IN_AMT_SILJUK_BYUNG)         AS IN_AMT_SILJUK_BYUNG     ,
                                  SUM(A.IN_AMT_SILJUK_MBYUNG)        AS IN_AMT_SILJUK_MBYUNG
                             FROM
                                ( --목표
                                  SELECT A.UTDIV                                                   AS PARTDIV                 ,
                                         A.DEPTCODE                                                AS DEPTCODE                ,
                                         A.EMPCODE                                                 AS EMPCODE                 ,
                                         SUM(CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END) AS SALE_AMT                ,  --판매목표
                                         0                                                         AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         0                                                         AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         0                                                         AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         0                                                         AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         0                                                         AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         0                                                         AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         0                                                         AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         0                                                         AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         0                                                         AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         0                                                         AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         0                                                         AS SALE_AMT_BANPUM         ,  --매출:반품
                                         0                                                         AS SALE_AMT_HALIN          ,  --매출:매출할인외
                                         0                                                         AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         0                                                         AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         SUM(CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END) AS IN_AMT                  ,  --수금목표
                                         0                                                         AS IN_AMT_SILJUK_IN        ,  --수금:간납합계
                                         0                                                         AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매로컬
                                         0                                                         AS IN_AMT_SILJUK_IN_01     ,  --수금:의원
                                         0                                                         AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                         AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                         AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         0                                                         AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         0                                                         AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         0                                                         AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         0                                                         AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLTARGETSALEM A
                                   WHERE A.YEARMONTH BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.UTDIV   ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.DEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EMPCODE ,' ') LIKE p_empcode  || '%'
                                GROUP BY A.UTDIV, A.DEPTCODE, A.EMPCODE
                               UNION ALL
                                  --판매
                                  SELECT B.ITPARTDIV                                                                                                                    AS PARTDIV                 ,
                                         B.ITDEPTCODE                                                                                                                   AS DEPTCODE                ,  --부서코드
                                         B.EMPCODE                                                                                                                      AS EMPCODE                 ,  --사원코드
                                         0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '60'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '80'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV IN ('05','10','70','90','99')            THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '05'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '10' AND SUBSTR(A.ECUSTCODE,1,1) = '4' THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '10' AND SUBSTR(A.ECUSTCODE,1,1) > '6' THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '70'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '90'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '99'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '20'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         SUM(CASE WHEN A.SALDIV IN ('B01','B10')                                                             THEN -B.SALAMT1 ELSE 0 END) AS SALE_AMT_BANPUM         ,  --매출:반품
                                         0                                                                                                                              AS SALE_AMT_HALIN          ,  --매출:매출할인
                                         0                                                                                                                              AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         0                                                                                                                              AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN        ,  --수금:간납합계
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매로컬
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_01     ,  --수금:의원
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         0                                                                                                                              AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         0                                                                                                                              AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         0                                                                                                                              AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLORDM A,
                                         oragmp.SLORDD B
                                   WHERE A.STATEDIV = '09'
                                     AND A.ORDERNO  = B.ORDERNO
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(B.ITPARTDIV ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(B.ITDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(B.EMPCODE   ,' ') LIKE p_empcode  || '%'
                                GROUP BY B.ITPARTDIV, B.ITDEPTCODE, B.EMPCODE
                               UNION ALL
                                  --수금
                                  SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                         A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                         A.EEMPCODE                                                                                                                     AS EMPCODE                 ,  --사원코드
                                         0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                         0                                                                                                                              AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         0                                                                                                                              AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         0                                                                                                                              AS SALE_AMT_BANPUM         ,  --매출:반품
                                         SUM(CASE WHEN A.COLDIV = '52' THEN -A.COLAMT ELSE 0 END)                   AS SALE_AMT_HALIN          ,  --매출:매출할인
                                         SUM(CASE WHEN A.COLDIV = '59' AND SUBSTR(A.CUSTCODE,1,1) NOT IN ('3','4')  THEN -A.COLAMT ELSE 0 END) AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         SUM(CASE WHEN A.COLDIV = '59' AND SUBSTR(A.CUSTCODE,1,1) IN ('3','4')       THEN -A.COLAMT ELSE 0 END)                         AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN        ,  --수금:합계                                                       
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('40', '45') THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '10' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_01  ,  --수금:의원
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '99' THEN A.COLAMT 
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '20' THEN A.COLAMT 
                                                  ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '60' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '80' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLCOLM A
                                   WHERE A.STATEDIV = '09'
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                     AND A.COLDIV <> '55'   --잔고이월 제외 
                                     AND A.COLDIV NOT LIKE '3%'
                                GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE                                
                                UNION ALL        
                                SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                       A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                       A.EEMPCODE                                                                                                                     AS EMPCODE                 ,  --사원코드
                                       0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                       0                                                                                                                              AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                       0                                                                                                                              AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                       0                                                                                                                              AS SALE_AMT_BANPUM         ,  --매출:반품
                                       0                                                                  AS SALE_AMT_HALIN          ,  --매출:매출할인
                                       0                                                                  AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                       0                                                                  AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                       0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN        ,  --수금:합계                                                       
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('40', '45') THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV IN ('40', '45') AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '10' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '10' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT 
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_01  ,  --수금:의원
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '99' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '99' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT 
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '20' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '20' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                               ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '60' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '60' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '80' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '80' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                  FROM oragmp.SLCOLM A
                                 WHERE A.STATEDIV = '09'
                                   AND SUBSTR(A.APPDATE,1,7) BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_fryymm || '01','YYYY-MM-DD'), -24), 'YYYY-MM') AND p_toyymm
                                   AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                   AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                   AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                   AND A.COLDIV <> '55'   --잔고이월 제외 
                                   AND A.COLDIV LIKE '3%'
                              GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                ) A
                         GROUP BY A.PARTDIV, A.DEPTCODE, A.EMPCODE
                         ) X,
                           oragmp.CMEMPM    A,
                           oragmp.CMDEPTM   B,
                           oragmp.CMCOMMONM C
                     WHERE X.EMPCODE  = A.EMPCODE (+)
                       AND X.DEPTCODE = B.DEPTCODE(+)
                       AND 'SL90'     = C.CMMCODE (+) -- 직능분류 10-종병 20-병원 30-의원 40-도매 
                       AND X.PARTDIV  = C.DIVCODE (+)
                     GROUP BY X.PARTDIV, C.DIVNAME, X.DEPTCODE, B.DEPTNAME, A.GRADEDIV, X.EMPCODE, A.EMPNAME
                     ORDER BY X.PARTDIV, X.DEPTCODE, A.GRADEDIV, X.EMPCODE
              );
         
         END IF; 
        
    END IF;
    
    
    
    
    

     
    
    
    
    
    
    
    IF v_gubun = 4 THEN  -- 파트 :선택  부서: 선택   사원: 선택
        SELECT count(*)
          INTO v_num
          FROM (
          
                     SELECT X.EMPCODE                                AS EMPCODE                    ,  --사원번호
                            A.EMPNAME                                AS EMPNAME                      --사원명(담당사원)
                       FROM
                         ( SELECT NVL(A.PARTDIV, '99')               AS PARTDIV                 ,
                              A.DEPTCODE                         AS DEPTCODE                ,
                              A.EMPCODE                          AS EMPCODE                 
                             FROM
                                ( --목표
                                  SELECT A.UTDIV                                                   AS PARTDIV                 ,
                                     A.DEPTCODE                                                AS DEPTCODE                ,
                                     A.EMPCODE                                                 AS EMPCODE
                                    FROM oragmp.SLTARGETSALEM A
                                   WHERE A.YEARMONTH BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.UTDIV   ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.DEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EMPCODE ,' ') LIKE p_empcode  || '%'
                                GROUP BY A.UTDIV, A.DEPTCODE, A.EMPCODE
                               UNION ALL
                                  --판매
                                  SELECT B.ITPARTDIV                                                                                                                    AS PARTDIV                 ,
                                     B.ITDEPTCODE                                                                                                                   AS DEPTCODE                ,  --부서코드
                                     B.EMPCODE                                                                                                                      AS EMPCODE                    --사원코드
                                    FROM oragmp.SLORDM A,
                                         oragmp.SLORDD B
                                   WHERE A.STATEDIV = '09'
                                     AND A.ORDERNO  = B.ORDERNO
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(B.ITPARTDIV ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(B.ITDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(B.EMPCODE   ,' ') LIKE p_empcode  || '%'
                                GROUP BY B.ITPARTDIV, B.ITDEPTCODE, B.EMPCODE
                               UNION ALL
                                  --수금
                                  SELECT A.PARTDIV                                                                                                                      AS PARTDIV              ,
                                     A.EDEPTCODE                                                                                                                    AS DEPTCODE                 ,  --부서코드
                                     A.EEMPCODE                                                                                                                     AS EMPCODE                     --사원코드
                                    FROM oragmp.SLCOLM A
                                   WHERE A.STATEDIV = '09'
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                     AND A.COLDIV <> '55'   --잔고이월 제외 
                                     AND A.COLDIV NOT LIKE '3%'
                                GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                UNION ALL
                                SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                   A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                   A.EEMPCODE                                                                                                                     AS EMPCODE                   --사원코드
                                  FROM oragmp.SLCOLM A
                                 WHERE A.STATEDIV = '09'
                                   AND SUBSTR(A.APPDATE,1,7) BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_fryymm || '01','YYYY-MM-DD'), -24), 'YYYY-MM') AND p_toyymm
                                   AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                   AND A.COLDIV <> '55'   --잔고이월 제외 
                                   AND A.COLDIV LIKE '3%'
                              GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                ) A
                         GROUP BY A.PARTDIV, A.DEPTCODE, A.EMPCODE
                         ) X,
                           oragmp.CMEMPM    A,
                           oragmp.CMDEPTM   B,
                           oragmp.CMCOMMONM C
                     WHERE X.EMPCODE  = A.EMPCODE (+)
                       AND X.DEPTCODE = B.DEPTCODE(+)
                       AND 'SL90'     = C.CMMCODE (+) -- 직능분류 10-종병 20-병원 30-의원 40-도매 
                       AND X.PARTDIV  = C.DIVCODE (+)
                       AND ROWNUM = 1
                  GROUP BY X.PARTDIV, C.DIVNAME, X.DEPTCODE, B.DEPTNAME, A.GRADEDIV, X.EMPCODE, A.EMPNAME 
               ); 
        
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
           
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
            
           OPEN out_RESULT FOR
           SELECT EMPCODE            AS out_GUBUN_CD         -- 구분코드           
                 ,EMPNAME            AS out_GUBUN_NM         -- 구분명                  
                 ,'XX'               AS out_RPT_GB           -- 생성구분          
                 ,SALE_AMT           AS out_SALE_AMT         -- 판매목표           
                 ,SALE_AMT_SILJUK    AS out_SALE_AMT_SILJUK  -- 판매금액           
                 ,SALE_PERCENT       AS out_SALE_PERCENT     -- 판매달성율         
                 ,IN_AMT             AS out_IN_AMT           -- 수금목표           
                 ,IN_AMT_SILJUK      AS out_IN_AMT_SILJUK    -- 수금금액           
                 ,IN_PERCENT         AS out_in_PERCENT       -- 수금달성율  
                 ,TO_CHAR(SYSDATE,'YYYY-MM-DD hh24:mi:ss') || ' 약정가기준'  AS out_PROC_DATE        -- batch data 생성시각
            FROM (              
                     SELECT X.EMPCODE                                AS EMPCODE                    ,  --사원번호
                            A.EMPNAME                                AS EMPNAME                    ,  --사원명(담당사원)
                            SUM(X.SALE_AMT)                          AS SALE_AMT                   ,  --판매목표
                            SUM(X.SALE_AMT_SILJUK_BYUNG)             AS SALE_AMT_SILJUK_BYUNG      ,  --판매종합병원
                            SUM(X.SALE_AMT_SILJUK_MBYUNG)            AS SALE_AMT_SILJUK_MBYUNG     ,  --판매준종합병원
                            SUM(X.SALE_AMT_SILJUK_IN)                AS SALE_AMT_SILJUK_IN         ,  --
                            SUM(X.SALE_AMT_SILJUK_IN_LOCAL)          AS SALE_AMT_SILJUK_IN_LOCAL   ,  --판매도매로컬
                            SUM(X.SALE_AMT_SILJUK_IN_01)             AS SALE_AMT_SILJUK_IN_01      ,  --판매의원
                            SUM(X.SALE_AMT_SILJUK_IN_02)             AS SALE_AMT_SILJUK_IN_02      ,  --판매일반간납
                            SUM(X.SALE_AMT_SILJUK_IN_03)             AS SALE_AMT_SILJUK_IN_03      ,  --판매턴키
                            SUM(X.SALE_AMT_SILJUK_IN_04)             AS SALE_AMT_SILJUK_IN_04      ,  --판매입찰
                            SUM(X.SALE_AMT_SILJUK_IN_05)             AS SALE_AMT_SILJUK_IN_05      ,  --판매기타
                            SUM(X.SALE_AMT_SILJUK_OUT)               AS SALE_AMT_SILJUK_OUT        ,  --판매약국
                            SUM(X.SALE_AMT_BANPUM)                   AS SALE_AMT_BANPUM            ,  --판매반품
                            SUM(X.SALE_AMT_HALIN)                    AS SALE_AMT_HALIN             ,  --판매매출할인
                            SUM(X.SALE_AMT_HALINS01)                 AS SALE_AMT_HALINS01          ,  --판매수금할인(일반)
                            SUM(X.SALE_AMT_HALINS02)                 AS SALE_AMT_HALINS02          ,  --판매수금할인(조건)
                            SUM(X.SALE_AMT_SILJUK_IN)     + SUM(X.SALE_AMT_SILJUK_OUT) + SUM(X.SALE_AMT_SILJUK_BYUNG) +
                            SUM(X.SALE_AMT_SILJUK_MBYUNG) + SUM(X.SALE_AMT_BANPUM)     + (SUM(X.SALE_AMT_HALIN)       +
                            SUM(X.SALE_AMT_HALINS01))                AS SALE_AMT_SILJUK            ,  --판매계(수금할인조건제외)
                            DECODE(SUM(NVL(X.SALE_AMT,0)),0, 0,
                            ROUND((SUM(X.SALE_AMT_SILJUK_IN)    + SUM(X.SALE_AMT_SILJUK_OUT)    +
                                   SUM(X.SALE_AMT_SILJUK_BYUNG) + SUM(X.SALE_AMT_SILJUK_MBYUNG) +
                                   SUM(X.SALE_AMT_BANPUM)       + SUM(X.SALE_AMT_HALIN)         +
                                   SUM(X.SALE_AMT_HALINS01))    / SUM(X.SALE_AMT) * 100,2))
                                                                     AS SALE_PERCENT               ,  --
                            SUM(X.IN_AMT)                            AS IN_AMT                     ,  --수금목표
                            SUM(X.IN_AMT_SILJUK_BYUNG)               AS IN_AMT_SILJUK_BYUNG        ,  --수금종합병원
                            SUM(X.IN_AMT_SILJUK_MBYUNG)              AS IN_AMT_SILJUK_MBYUNG       ,  --수금준종합병원
                            SUM(X.IN_AMT_SILJUK_IN)                  AS IN_AMT_SILJUK_IN           ,  --
                            SUM(X.IN_AMT_SILJUK_IN_LOCAL)            AS IN_AMT_SILJUK_IN_LOCAL     ,  --수금도매
                            SUM(X.IN_AMT_SILJUK_IN_01)               AS IN_AMT_SILJUK_IN_01        ,  --수금의원
                            SUM(X.IN_AMT_SILJUK_IN_02)               AS IN_AMT_SILJUK_IN_02        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_03)               AS IN_AMT_SILJUK_IN_03        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_04)               AS IN_AMT_SILJUK_IN_04        ,  --
                            SUM(X.IN_AMT_SILJUK_IN_05)               AS IN_AMT_SILJUK_IN_05        ,  --수금기타
                            SUM(X.IN_AMT_SILJUK_OUT)                 AS IN_AMT_SILJUK_OUT          ,  --수금약국
                            SUM(X.IN_AMT_SILJUK_IN)                  AS IN_AMT_SILJUK              ,  --수금계                              
                            DECODE(SUM(NVL(X.IN_AMT,0)), 0, 0,
                            ROUND((SUM(X.IN_AMT_SILJUK_IN)      + SUM(X.IN_AMT_SILJUK_OUT) +
                                   SUM(X.IN_AMT_SILJUK_BYUNG)   +
                                   SUM(X.IN_AMT_SILJUK_MBYUNG)) / SUM(X.IN_AMT) * 100,2))
                                                                     AS IN_PERCENT                    --수금달성률
                      FROM
                         ( SELECT NVL(A.PARTDIV, '99')               AS PARTDIV                 ,
                                  A.DEPTCODE                         AS DEPTCODE                ,
                                  A.EMPCODE                          AS EMPCODE                 ,
                                  SUM(A.SALE_AMT)                    AS SALE_AMT                ,
                                  SUM(A.SALE_AMT_SILJUK_BYUNG)       AS SALE_AMT_SILJUK_BYUNG   ,
                                  SUM(A.SALE_AMT_SILJUK_MBYUNG)      AS SALE_AMT_SILJUK_MBYUNG  ,
                                  SUM(A.SALE_AMT_SILJUK_IN)          AS SALE_AMT_SILJUK_IN      ,
                                  SUM(A.SALE_AMT_SILJUK_IN_LOCAL)    AS SALE_AMT_SILJUK_IN_LOCAL,
                                  SUM(A.SALE_AMT_SILJUK_IN_01)       AS SALE_AMT_SILJUK_IN_01   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_02)       AS SALE_AMT_SILJUK_IN_02   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_03)       AS SALE_AMT_SILJUK_IN_03   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_04)       AS SALE_AMT_SILJUK_IN_04   ,
                                  SUM(A.SALE_AMT_SILJUK_IN_05)       AS SALE_AMT_SILJUK_IN_05   ,
                                  SUM(A.SALE_AMT_SILJUK_OUT)         AS SALE_AMT_SILJUK_OUT     ,
                                  SUM(A.SALE_AMT_BANPUM)             AS SALE_AMT_BANPUM         ,
                                  SUM(A.SALE_AMT_HALIN)              AS SALE_AMT_HALIN          ,
                                  SUM(A.SALE_AMT_HALINS01)           AS SALE_AMT_HALINS01       ,
                                  SUM(A.SALE_AMT_HALINS02)           AS SALE_AMT_HALINS02       ,
                                  SUM(A.IN_AMT)                      AS IN_AMT                  ,
                                  SUM(A.IN_AMT_SILJUK_IN)            AS IN_AMT_SILJUK_IN        ,
                                  SUM(A.IN_AMT_SILJUK_IN_LOCAL)      AS IN_AMT_SILJUK_IN_LOCAL  ,
                                  SUM(A.IN_AMT_SILJUK_IN_01)         AS IN_AMT_SILJUK_IN_01     ,
                                  SUM(A.IN_AMT_SILJUK_IN_02)         AS IN_AMT_SILJUK_IN_02     ,
                                  SUM(A.IN_AMT_SILJUK_IN_03)         AS IN_AMT_SILJUK_IN_03     ,
                                  SUM(A.IN_AMT_SILJUK_IN_04)         AS IN_AMT_SILJUK_IN_04     ,
                                  SUM(A.IN_AMT_SILJUK_IN_05)         AS IN_AMT_SILJUK_IN_05     ,
                                  SUM(A.IN_AMT_SILJUK_OUT)           AS IN_AMT_SILJUK_OUT       ,
                                  SUM(A.IN_AMT_SILJUK_BYUNG)         AS IN_AMT_SILJUK_BYUNG     ,
                                  SUM(A.IN_AMT_SILJUK_MBYUNG)        AS IN_AMT_SILJUK_MBYUNG
                             FROM
                                ( --목표
                                  SELECT A.UTDIV                                                   AS PARTDIV                 ,
                                         A.DEPTCODE                                                AS DEPTCODE                ,
                                         A.EMPCODE                                                 AS EMPCODE                 ,
                                         SUM(CASE WHEN A.SALDIV = 'A' THEN A.TARGETAMT ELSE 0 END) AS SALE_AMT                ,  --판매목표
                                         0                                                         AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         0                                                         AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         0                                                         AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         0                                                         AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         0                                                         AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         0                                                         AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         0                                                         AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         0                                                         AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         0                                                         AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         0                                                         AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         0                                                         AS SALE_AMT_BANPUM         ,  --매출:반품
                                         0                                                         AS SALE_AMT_HALIN          ,  --매출:매출할인외
                                         0                                                         AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         0                                                         AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         SUM(CASE WHEN A.SALDIV = 'C' THEN A.TARGETAMT ELSE 0 END) AS IN_AMT                  ,  --수금목표
                                         0                                                         AS IN_AMT_SILJUK_IN        ,  --수금:간납합계
                                         0                                                         AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매로컬
                                         0                                                         AS IN_AMT_SILJUK_IN_01     ,  --수금:의원
                                         0                                                         AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                         AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                         AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         0                                                         AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         0                                                         AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         0                                                         AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         0                                                         AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLTARGETSALEM A
                                   WHERE A.YEARMONTH BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.UTDIV   ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.DEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EMPCODE ,' ') LIKE p_empcode  || '%'
                                GROUP BY A.UTDIV, A.DEPTCODE, A.EMPCODE
                               UNION ALL
                                  --판매
                                  SELECT B.ITPARTDIV                                                                                                                    AS PARTDIV                 ,
                                         B.ITDEPTCODE                                                                                                                   AS DEPTCODE                ,  --부서코드
                                         B.EMPCODE                                                                                                                      AS EMPCODE                 ,  --사원코드
                                         0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '60'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '80'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV IN ('05','10','70','90','99')            THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '05'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '10' AND SUBSTR(A.ECUSTCODE,1,1) = '4' THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '10' AND SUBSTR(A.ECUSTCODE,1,1) > '6' THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '70'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '90'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '99'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         SUM(CASE WHEN A.SALDIV IN ('A01','A21','A22') AND A.EUTDIV = '20'                                   THEN B.SALAMT1  ELSE 0 END) AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         SUM(CASE WHEN A.SALDIV IN ('B01','B10')                                                             THEN -B.SALAMT1 ELSE 0 END) AS SALE_AMT_BANPUM         ,  --매출:반품
                                         0                                                                                                                              AS SALE_AMT_HALIN          ,  --매출:매출할인
                                         0                                                                                                                              AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         0                                                                                                                              AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN        ,  --수금:간납합계
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매로컬
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_01     ,  --수금:의원
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         0                                                                                                                              AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         0                                                                                                                              AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         0                                                                                                                              AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLORDM A,
                                         oragmp.SLORDD B
                                   WHERE A.STATEDIV = '09'
                                     AND A.ORDERNO  = B.ORDERNO
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(B.ITPARTDIV ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(B.ITDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(B.EMPCODE   ,' ') LIKE p_empcode  || '%'
                                GROUP BY B.ITPARTDIV, B.ITDEPTCODE, B.EMPCODE
                               UNION ALL
                                  --수금
                                  SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                         A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                         A.EEMPCODE                                                                                                                     AS EMPCODE                 ,  --사원코드
                                         0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                         0                                                                                                                              AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                         0                                                                                                                              AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                         0                                                                                                                              AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                         0                                                                                                                              AS SALE_AMT_BANPUM         ,  --매출:반품
                                         SUM(CASE WHEN A.COLDIV = '52' THEN -A.COLAMT ELSE 0 END)                   AS SALE_AMT_HALIN          ,  --매출:매출할인
                                         SUM(CASE WHEN A.COLDIV = '59' AND SUBSTR(A.CUSTCODE,1,1) NOT IN ('3','4')  THEN -A.COLAMT ELSE 0 END) AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                         SUM(CASE WHEN A.COLDIV = '59' AND SUBSTR(A.CUSTCODE,1,1) IN ('3','4')       THEN -A.COLAMT ELSE 0 END)                         AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                         0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN        ,  --수금:합계                                                       
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('40', '45') THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '10' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_01  ,  --수금:의원
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                         0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '99' THEN A.COLAMT 
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '20' THEN A.COLAMT 
                                                  ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '60' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                         SUM(CASE WHEN A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '80' THEN A.COLAMT  
                                                  ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                    FROM oragmp.SLCOLM A
                                   WHERE A.STATEDIV = '09'
                                     AND SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm
                                     AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                     AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                     AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                     AND A.COLDIV <> '55'   --잔고이월 제외 
                                     AND A.COLDIV NOT LIKE '3%'
                                GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE                                
                                UNION ALL        
                                SELECT A.PARTDIV                                                                                                                      AS PARTDIV                 ,
                                       A.EDEPTCODE                                                                                                                    AS DEPTCODE                ,  --부서코드
                                       A.EEMPCODE                                                                                                                     AS EMPCODE                 ,  --사원코드
                                       0                                                                                                                              AS SALE_AMT                ,  --판매목표
                                       0                                                                                                                              AS SALE_AMT_SILJUK_BYUNG   ,  --매출:종합병원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_MBYUNG  ,  --매출:준종합병원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN      ,  --매출:간납합계
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_LOCAL,  --매출:도매로컬
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_01   ,  --매출:의원
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_02   ,  --매출:일반간납
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_03   ,  --매출:턴키
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_04   ,  --매출:입찰
                                       0                                                                                                                              AS SALE_AMT_SILJUK_IN_05   ,  --매출:기타
                                       0                                                                                                                              AS SALE_AMT_SILJUK_OUT     ,  --매출:약국
                                       0                                                                                                                              AS SALE_AMT_BANPUM         ,  --매출:반품
                                       0                                                                  AS SALE_AMT_HALIN          ,  --매출:매출할인
                                       0                                                                  AS SALE_AMT_HALINS01       ,  --매출:수금할인(일반)
                                       0                                                                  AS SALE_AMT_HALINS02       ,  --매출:수금할인(조건)
                                       0                                                                                                                              AS IN_AMT                  ,  --수금목표
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV IN ('10', '20', '40', '45', '60', '80', '99') AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN        ,  --수금:합계                                                       
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV IN ('40', '45') THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV IN ('40', '45') AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_LOCAL  ,  --수금:도매
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '10' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '10' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT 
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_01  ,  --수금:의원
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_02     ,  --수금:일반간납
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_03     ,  --수금:턴키
                                       0                                                                                                                              AS IN_AMT_SILJUK_IN_04     ,  --수금:입찰
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '99' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '99' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT 
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_IN_05     ,  --수금:기타
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '20' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '20' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                               ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_OUT       ,  --수금:약국
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '60' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '60' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                           AS IN_AMT_SILJUK_BYUNG     ,  --수금:종합병원
                                       SUM(CASE WHEN SUBSTR(A.APPDATE,1,7) BETWEEN p_fryymm AND p_toyymm AND A.COLDIV NOT IN ('52', '59') AND A.EUTDIV = '80' THEN 
                                                CASE WHEN A.EXPDATE <= TO_CHAR(LAST_DAY(ADD_MONTHS(TO_DATE(A.APPDATE,'YYYY-MM-DD'),6)),'YYYY-MM-DD') THEN A.COLAMT 
                                                     ELSE 0 END
                                                WHEN A.EUTDIV = '80' AND MONTHS_BETWEEN(TO_DATE(SUBSTR(A.EXPDATE, 1, 7), 'YYYY-MM'), TO_DATE(p_toyymm, 'YYYY-MM')) BETWEEN 6 - MONTHS_BETWEEN(TO_DATE(p_toyymm, 'YYYY-MM'), TO_DATE(p_fryymm, 'YYYY-MM')) AND 6 THEN A.COLAMT
                                                ELSE 0 END)                                                                                                            AS IN_AMT_SILJUK_MBYUNG       --수금:준종합병원
                                  FROM oragmp.SLCOLM A
                                 WHERE A.STATEDIV = '09'
                                   AND SUBSTR(A.APPDATE,1,7) BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(p_fryymm || '01','YYYY-MM-DD'), -24), 'YYYY-MM') AND p_toyymm
                                   AND NVL(A.PARTDIV  ,' ') LIKE p_partdiv  || '%'
                                   AND NVL(A.EDEPTCODE,' ') LIKE p_deptcode || '%'
                                   AND NVL(A.EEMPCODE ,' ') LIKE p_empcode  || '%'
                                   AND A.COLDIV <> '55'   --잔고이월 제외 
                                   AND A.COLDIV LIKE '3%'
                              GROUP BY A.PARTDIV, A.EDEPTCODE, A.EEMPCODE
                                ) A
                         GROUP BY A.PARTDIV, A.DEPTCODE, A.EMPCODE
                         ) X,
                           oragmp.CMEMPM    A,
                           oragmp.CMDEPTM   B,
                           oragmp.CMCOMMONM C
                     WHERE X.EMPCODE  = A.EMPCODE (+)
                       AND X.DEPTCODE = B.DEPTCODE(+)
                       AND 'SL90'     = C.CMMCODE (+) -- 직능분류 10-종병 20-병원 30-의원 40-도매 
                       AND X.PARTDIV  = C.DIVCODE (+)
                     GROUP BY X.PARTDIV, C.DIVNAME, X.DEPTCODE, B.DEPTNAME, A.GRADEDIV, X.EMPCODE, A.EMPNAME
                     ORDER BY X.PARTDIV, X.DEPTCODE, A.GRADEDIV, X.EMPCODE
              );
         
         END IF; 
        
    END IF;    
    
        
    
EXCEPTION
WHEN DT_NULL THEN
   out_CODE := 101;
   out_MSG  := '조회기간이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
