CREATE function      F_GET_SALE0405_AMT
        ( A_CUST_ID      VARCHAR2, -- 직납처
          A_RCUST_ID     VARCHAR2, -- 간납처
          A_ITEM_ID      VARCHAR2, -- 제품코드
          A_YMD          DATE,     -- 전표일자
          A_GUBUN        VARCHAR2  -- 구분('BAS_AMT','BAL_AMT','YAK_AMT','YAK_AMT1','AMT_YUL','C','GC' ,'ETC','BIGO') 
        )
   RETURN VARCHAR2
AS
   user_err     exception   ;
   V_YMD        DATE ;
   n_rtn_value  VARCHAR2(250);
   v_curr_error VARCHAR2(250);

/*----------------------------------------------------------------
  이력관리 하기이전 평션 (2009.12.31일까지 유효) 
----------------------------------------------------------------*/

BEGIN
	   SELECT MIN(YMD) 
	     INTO V_YMD
	     FROM SALE0405
	    WHERE CUST_ID  = A_CUST_ID
	      AND RCUST_ID = A_RCUST_ID
	      AND ITEM_ID  = A_ITEM_ID
	      AND YMD      >= A_YMD;
		  
	   IF V_YMD IS NULL  THEN
	      RETURN '0';
	   END IF;
	  
	   v_curr_error := A_CUST_ID||':'||A_RCUST_ID||':'||A_ITEM_ID||':'||A_YMD||':'||A_GUBUN||':'||V_YMD;
	  
        If A_GUBUN = 'BAS_AMT' Then
		   SELECT TO_CHAR(NVL(BAS_AMT,0))
		     INTO n_rtn_value
		     FROM SALE0405
		    WHERE CUST_ID  = A_CUST_ID
		      AND RCUST_ID = A_RCUST_ID
		      AND ITEM_ID  = A_ITEM_ID
		      AND YMD      = V_YMD;
		   IF SQL%NOTFOUND THEN
	          RETURN '0';
		   END IF;
        End if ;
	        
        If A_GUBUN = 'BAL_AMT' Then
		   SELECT TO_CHAR(NVL(BAL_AMT,0))
		     INTO n_rtn_value
		     FROM SALE0405
		    WHERE CUST_ID  = A_CUST_ID
		      AND RCUST_ID = A_RCUST_ID
		      AND ITEM_ID  = A_ITEM_ID
		      AND YMD      = V_YMD;
		   IF SQL%NOTFOUND THEN
	          RETURN '0';
		   END IF;
        End if ;
        
        If A_GUBUN = 'YAK_AMT' Then
		   SELECT TO_CHAR(NVL(YAK_AMT,0))  
		     INTO n_rtn_value
		     FROM SALE0405
		    WHERE CUST_ID  = A_CUST_ID
		      AND RCUST_ID = A_RCUST_ID
		      AND ITEM_ID  = A_ITEM_ID
		      AND YMD      = V_YMD;
		   IF SQL%NOTFOUND THEN
	          RETURN '0';
		   END IF;
        End if ;
        
        If A_GUBUN = 'YAK_AMT1' Then
		   SELECT TO_CHAR(NVL((ROUND(TRUNC(YAK_AMT / 1.1) / 10) * 10) * 1.1,0))  
		     INTO n_rtn_value
		     FROM SALE0405
		    WHERE CUST_ID  = A_CUST_ID
		      AND RCUST_ID = A_RCUST_ID
		      AND ITEM_ID  = A_ITEM_ID
		      AND YMD      = V_YMD;
		   IF SQL%NOTFOUND THEN
	          RETURN '0';
		   END IF;
        End if ;
        
        If A_GUBUN = 'AMT_YUL' Then
		   SELECT TO_CHAR(NVL(AMT_YUL,0))
		     INTO n_rtn_value
		     FROM SALE0405
		    WHERE CUST_ID  = A_CUST_ID
		      AND RCUST_ID = A_RCUST_ID
		      AND ITEM_ID  = A_ITEM_ID
		      AND YMD      = V_YMD;
		   IF SQL%NOTFOUND THEN
	          RETURN '0';
		   END IF;
        End if ;
        
        If A_GUBUN = 'C' Then
		   SELECT TO_CHAR(NVL(C,0))
		     INTO n_rtn_value
		     FROM SALE0405
		    WHERE CUST_ID  = A_CUST_ID
		      AND RCUST_ID = A_RCUST_ID
		      AND ITEM_ID  = A_ITEM_ID
		      AND YMD      = V_YMD;
		   IF SQL%NOTFOUND THEN
	          RETURN '0';
		   END IF;
        End if ;
        
        If A_GUBUN = 'GC' Then
		   SELECT TO_CHAR(NVL(GC,0))
		     INTO n_rtn_value
		     FROM SALE0405
		    WHERE CUST_ID  = A_CUST_ID
		      AND RCUST_ID = A_RCUST_ID
		      AND ITEM_ID  = A_ITEM_ID
		      AND YMD      = V_YMD;
		   IF SQL%NOTFOUND THEN
	          RETURN '0';
		   END IF;
        End if ;
       
        If A_GUBUN = 'ETC' Then
		   SELECT TO_CHAR(NVL(ETC,0))
		     INTO n_rtn_value
		     FROM SALE0405
		    WHERE CUST_ID  = A_CUST_ID
		      AND RCUST_ID = A_RCUST_ID
		      AND ITEM_ID  = A_ITEM_ID
		      AND YMD      = V_YMD;
		   IF SQL%NOTFOUND THEN
	          RETURN '0';
		   END IF;
        End if ;
       
        If A_GUBUN = 'BIGO' Then
		   SELECT BIGO
		     INTO n_rtn_value
		     FROM SALE0405
		    WHERE CUST_ID  = A_CUST_ID
		      AND RCUST_ID = A_RCUST_ID
		      AND ITEM_ID  = A_ITEM_ID
		      AND YMD      = V_YMD;
		   IF SQL%NOTFOUND THEN
	          RETURN '0';
		   END IF;
        End if ;
       
        RETURN n_rtn_value;

	    EXCEPTION WHEN user_err THEN
	                   RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
	              WHEN OTHERS THEN
	                   RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;

/
