CREATE PROCEDURE      SP_SFA_RORDER_CONFIRM
 (
  in_SAWON_ID           IN VARCHAR2 default NULL,
  in_COUNT              IN NUMBER,
  in_DATASET            IN VARCHAR2 default NULL,
  out_CODE              OUT NUMBER,
  out_MSG               OUT VARCHAR2       
  )
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 간납처주문내역 관련자 확인체크한거  업데이트
 호출프로그램 : 일일방문 간납처주문내역 확인 팝업화면에서 체크후 확인버튼시        
 수정기록     :               
 ---------------------------------------------------------------------------*/
 
    v_gumae_no   VARCHAR2(12);
    v_sawon_gb   VARCHAR2(1); --1:발행사원,2:실사원
    
    ERROR_RAISE EXCEPTION;
    
BEGIN  

     --insert into SFA_SP_CALLED_HIST values ('SP_SFA_RORDER_CONFIRM','s',sysdate,'in_DATASET:'||in_DATASET||' /in_COUNT:'||to_char(in_COUNT));        

    FOR ll_loop IN 1.. in_COUNT LOOP  

        v_gumae_no  := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 1 + 12*(ll_loop -1),  12));  
        
        --insert into SFA_SP_CALLED_HIST values ('SP_SFA_RORDER_CONFIRM',to_char(ll_loop),sysdate,'v_gumae_no:'||v_gumae_no);
        
        --발행사원인지 실사원인지 체크
        select decode(in_SAWON_ID,sawon_id,'1',rsawon_id,'2')
          into v_sawon_gb    
          from sale0203
         where gumae_no = v_gumae_no;
                  
        if v_sawon_gb = '1' then
            update sale0203 set confirm_sawon_yn = 'Y' where gumae_no = v_gumae_no; 
        else
            update sale0203 set confirm_rsawon_yn = 'Y' where gumae_no = v_gumae_no;                    
        end if; 
          

    END LOOP; 
         
    out_CODE  := 0;
    out_MSG   := '저장 완료';              
                  


EXCEPTION
     WHEN ERROR_RAISE THEN 
          ROLLBACK; 

     WHEN OTHERS THEN
          out_CODE := SQLCODE;
          out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 

END;

/
