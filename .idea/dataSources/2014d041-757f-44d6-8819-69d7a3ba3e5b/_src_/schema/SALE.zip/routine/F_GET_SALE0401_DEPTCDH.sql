CREATE function      F_GET_SALE0401_DEPTCDH
        ( A_CUST_ID      VARCHAR2, -- 직납처
          A_YMD          DATE      -- 전표일자 
        )
   RETURN VARCHAR2
AS
   user_err       exception   ;
   A_SYMD         VARCHAR2(8);
   V_TRAN_YMD_CD  VARCHAR2(14);
   V_YMD          DATE ;
   V_SYMD         VARCHAR2(8);
   n_rtn_value    VARCHAR2(250);
   v_curr_error   VARCHAR2(250);

/*----------------------------------------------------------------
  이력관리적용부터 사용되는 평션 (2010.01.01 일부터 유효) 
    ==============================================================
   <주의사항> - RETURN갑시이 정상적이 않을을 처리하기 위한 방법  
      1.사원코드등록에 (00000)미지정으로 사원코드들 등록한다.
      2.부서코드등록에 (Z0)미지정으로 부서코들 등록한다.
      3.사원코드등록에서 '00000'코드에 부서코드'Z0'를 지정한다.
    ==============================================================
 개요 :수금실적사원의 당시 소속부서를 리턴 
 작성자: 김태안
 작성일:2014.01.13     
----------------------------------------------------------------*/
BEGIN
       A_SYMD := TO_CHAR(A_YMD, 'YYYYMMDD'); 

       SELECT MAX(APPL_DATE) 
         INTO V_SYMD
         FROM SALE0003H
        WHERE CUST_ID   =  A_CUST_ID
          AND APPL_DATE <= A_SYMD;

       SELECT MAX(TRAN_YMD_CD) 
         INTO V_TRAN_YMD_CD
         FROM SALE0003H
        WHERE CUST_ID   = A_CUST_ID
          AND APPL_DATE = V_SYMD;
          
       v_curr_error := A_CUST_ID||':'||A_SYMD||':'||V_TRAN_YMD_CD||':'||V_SYMD;

       IF (V_SYMD IS NULL) OR (V_TRAN_YMD_CD IS NULL)  THEN
          RETURN '00000'; --미지정사원코드 
--          RETURN '00000'||'::'||v_curr_error; --미지정사원코드(에러체크용)  
       END IF;
      
        SELECT F_GET_SALE0007H_DEPT_CD(SAWON_ID,A_SYMD)
          INTO n_rtn_value
          FROM SALE0003H
         WHERE CUST_ID     = A_CUST_ID
           AND TRAN_YMD_CD = V_TRAN_YMD_CD
           AND APPL_DATE   = V_SYMD;
           
        IF SQL%NOTFOUND THEN
              RETURN '00000';
--                 RETURN '00000'||'::'||v_curr_error; --미지정사원코드(에러체크용)  
        END IF;
            
        RETURN n_rtn_value;

        EXCEPTION WHEN user_err THEN
                       RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
                  WHEN OTHERS THEN
                       RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;

/
