CREATE PROCEDURE      PROC_PDA_ACT_REGISTER2
  (IN_STATUS IN VARCHAR2 DEFAULT NULL,
   IN_SABUN IN VARCHAR2 DEFAULT NULL,
   IN_YMD IN VARCHAR2 DEFAULT NULL,
   IN_ACT_NO IN VARCHAR2 DEFAULT NULL,
   IN_DESC_CD IN VARCHAR2 DEFAULT NULL,
   IN_DESC_NM IN VARCHAR2 DEFAULT NULL, 
   IN_GPS_LAT IN VARCHAR2 DEFAULT NULL,
   IN_GPS_LON IN VARCHAR2 DEFAULT NULL, 
   IN_GPS_ADDR IN VARCHAR2 DEFAULT NULL, 
   IN_ACTTIME IN VARCHAR2 DEFAULT NULL
        )
IS
    ll_max number; 

BEGIN

-- DECODE(A.STATUS, '1', '미방문', '2', '도착','3',  '사유발생','4'  , '완료' 5,'업무종료') STATUS
if in_status = '2' then


update sale.saleact set status = in_status 
, startlatitude1 = in_gps_lat , startlongitude1 = in_gps_lon , starttime = in_acttime,
startaddr = in_gps_addr
where actdt = in_ymd and  sabun = in_sabun and seq = in_act_no ;


elsif in_status = '3' then


update sale.saleact set status = in_status 
, actdesccd = in_desc_cd , actdescnm = in_desc_nm
where actdt = in_ymd and  sabun = in_sabun and seq = in_act_no ;


--update sale.saleact set status = in_status 
--where actdt = in_ymd and  sabun = in_sabun and seq = in_act_no ;

elsif in_status = '4' then

update sale.saleact set status = in_status 
, endlatitude2 = in_gps_lat , endlongitude2 = in_gps_lon , endtime = in_acttime ,endaddr = in_gps_addr
where actdt = in_ymd and  sabun = in_sabun and seq = in_act_no ;

elsIF in_status = '5' then --업무종료

SP_SYS100C_MAX_VALUE('SALEACT', sysdate, null,null, null, null, ll_max );

 INSERT INTO SALE.SALEACT (
   ACTDT, SABUN, SEQ, endtime,
   CREATED, 
   CREATEDBY, status )
   VALUES ( in_ymd, in_sabun, ll_max, 		TO_CHAR(sysdate,'yyyy-MM-dd HH24:MI:SS'),
    sysdate, in_sabun ,'5' );
/*
update sale.saleact set status = in_status 
, endlatitude2 = in_gps_lat , endlongitude2 = in_gps_lon , endtime = in_acttime
where actdt = in_ymd and  sabun = in_sabun and seq = in_act_no ;
*/
  
end if;


        
     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패   ');
            ROLLBACK;
            return;
     END IF;
            
        
end;

/
