CREATE PROCEDURE      SP_SFA_LOGIN_WEB
(
    in_SAWON_ID          IN VARCHAR2,   -- 로그인사번(인사사번으로로그인한다)
    in_SAWON_PSWD        IN VARCHAR2,   -- 로그인비밀변경
    in_HP                IN VARCHAR2,   -- 핸드폰 번호
    in_GUBUN             IN VARCHAR2,   -- A:안드로이드, W:웹
    in_COMM_DT           IN VARCHAR2,   -- 공통코드 변경유무 기준일자시간(14자리, 24시간)
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
    v_retir_dt           VARCHAR2(8);
    v_engag_div          VARCHAR2(5);
    v_sawon_pswd         VARCHAR2(20); 
     

BEGIN
 /*---------------------------------------------------------------------------
 프로그램명   :  SFA웹페이지 로그인
 호출프로그램 :  SFA로그인 페이지
 개요         : 전산실은 모든 프로그램의 로그인은 인사사번으로 하기로 하였다.
 따라서 로그인은 인사사번으로 하고 권한이 맞으면 영업사번으로 업무를 처리한다.
  수정기록    :2014.06.05 KTA - SP_SFA_LOGIN 을 사용하지 않고 이것을 사용함
   

 ---------------------------------------------------------------------------*/     
  
    --입력된 로그인 사번은  인사사번이어야 하므로 체크    
    SELECT COUNT(*) INTO v_num FROM hanahr.hr_hc_empbas_0 WHERE EMP_NO = in_SAWON_ID;
    IF (v_num = 0) THEN
        out_CODE := 104;
        out_MSG := '로그인 정보가 존재하지 않습니다.(인사사번을 입력하셔야 합니다)';    
        RETURN;
    END IF;
    
    --입력받은 인사사번이 hanaerp시스템  사용자정보테이블에 등록되어 있는지 체크
    SELECT COUNT(*) INTO v_num FROM hanacomm.co_us_member_0 WHERE EMP_NO = in_SAWON_ID ;
    IF (v_num = 0) THEN
        out_CODE := 105;
        out_MSG := '로그인 정보가 존재하지 않습니다.(관리자에게 문의하십시오)';     
        RETURN;
    END IF;
 
    --입력받은 인사사번이 사용가능한지 체크 
    SELECT COUNT(*) INTO v_num FROM hanacomm.co_us_member_0 WHERE EMP_NO = in_SAWON_ID and USE_YN = 'Y';
    IF (v_num = 0) THEN
        out_CODE := 106;
        out_MSG := '입력한 사번은 사용중지중입니다.';     
        RETURN;
    END IF;
    
    --비밀번호체크
    SELECT PASS_WORD INTO v_sawon_pswd FROM hanacomm.co_us_member_0 WHERE EMP_NO = in_SAWON_ID and USE_YN = 'Y';
    IF in_SAWON_PSWD <> v_sawon_pswd  THEN
        out_CODE := 107;
        out_MSG := '비밀번호가 틀립니다.pro';     
        RETURN;
    END IF;
   

    --퇴직,휴직체크            
    SELECT C.ENGAG_DIV, C.RETIR_DT 
      INTO v_engag_div, v_retir_dt 
      FROM hanahr.hr_hc_empbas_0 C
     WHERE C.EMP_NO = in_SAWON_ID;
                               
    IF v_engag_div <> '70010' OR v_retir_dt IS NOT NULL THEN  -- 70010:재직, 70020:퇴직, 70030:휴직
       out_CODE := 108;
       out_MSG  := CASE WHEN v_engag_div = '70020' THEN '퇴사한 직원입니다.' ELSE '휴직한 직원입니다.' END;   
       RETURN;
    END IF; 
             
    out_COUNT := 1;             
    
    OPEN out_RESULT FOR
    SELECT A.EMP_NO                       AS out_SAWON_ID,   -- 사원ID
           A.EMP_KO_NM                    AS out_SAWON_NM,   -- 사원명
           v_sawon_pswd                   AS out_SAWON_PSWD, -- 패스워드
           A.DEPT_CD                      AS out_DEPT_CD,    -- 부서코드
           B.DEPT_KO_NM                   AS out_DEPT_NM,    -- 부서명
           A.ASSGN_CD                     AS out_GRAD_CD,    -- 직급코드(27030:팀장, 27040:팀원)
           C.COMN_NM                      AS out_GRAD_KO_NM, -- 직급코드명(27030:팀장, 27040:팀원)
           'N'                            AS out_CHANGE_YN,  -- 공통코드 변경여부(Y이면 변경사항이 있음)
           0                              AS out_NOTICE_CNT, -- 안읽은 공지사항 건수
           '0'                            AS out_TIME_OUT,   -- 타임아웃. 분단위/정수형 스트링 구현
           '0'                            AS out_VERSION     -- mobilesfa버전
      FROM hanahr.hr_hc_empbas_0 A
          ,hanahr.hr_co_depart_0 B
          ,hanahr.hr_co_common_0 C  
     WHERE A.DEPT_CD   = B.DEPT_CD
       AND A.ASSGN_CD  = C.COMN_CD
       AND A.EMP_NO = in_SAWON_ID;
     
      out_CODE := 0;
      out_MSG := '로그인이 정상 처리되었습니다.';
    
EXCEPTION 
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 
END;
/
