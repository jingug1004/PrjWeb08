CREATE FUNCTION      FNC_LONG2CHAR (
   arg_NTCNO VARCHAR
)
   RETURN VARCHAR
AS
   longCont   VARCHAR2 (32767);
   sqlQuery   VARCHAR2 (2000);
 
BEGIN
    -- CHOE 20120918 내용을 가져오는 부분은 상용 서버가 아님 TEST 서버로 바꿔준다.
   --sqlQuery := 'SELECT NTC_CONT FROM TGWNT_M@HANA_GW.HANA.CO.KR WHERE NTCNO = '||CHR (39)||arg_NTCNO||CHR (39);
   sqlQuery := 'SELECT NTC_CONT FROM HANAGW.TGWNT_M WHERE NTCNO = '||CHR (39)||arg_NTCNO||CHR (39);
 
   EXECUTE IMMEDIATE sqlQuery INTO longCont;
     
   longCont := SUBSTR(longCont, 1, 4000);
   RETURN longCont;
END;

/
