CREATE FUNCTION      F_Z_GET_WORKDAY_STATUS(I_EMP_NO IN STRING,I_YMD IN STRING)
  RETURN VARCHAR2 IS
  V_RESULT           VARCHAR2(100); 
  V_YMD              VARCHAR2(10);
  /* ---------------------------------------------------------------------------------
    SUBJECT  : 사원이 해당일에 어떤 그문상태였느지를 돌려준다
               근태 관리(휴가신청 포함) 테이블- HR_WK_DLIAPP_0
               휴일테이블테이블 - HR_CO_HOLIDA_0
               
    ARGUMENT : E_EMP_NO  사번
               I_YMD  특정일
    RETURN   : 해당일의 근태상태
    ---------------------------------------------------------------------------------*/
 
  
BEGIN

   V_YMD := substr(I_YMD,1,4)||'-'||substr(I_YMD,5,2)||'-'||substr(I_YMD,7,2);

   BEGIN
     SELECT workstatus
       INTO V_RESULT
       FROM ( select oragmp.FNCOMMONNM('comm','PS06',caldiv) workstatus from oragmp.PSWORKDAYM where caldiv <> '01' and  empcode = I_EMP_NO  and workdate = V_YMD
              union
              select oragmp.FNCOMMONNM('comm','PS06',caldiv) workstatus from oragmp.PSCALM where calymd = V_YMD and workdiv = '05'
            )
     ;
            
   EXCEPTION WHEN NO_DATA_FOUND THEN 
             V_RESULT := '출근' ;           
   END;
            
   RETURN V_RESULT;
  
END F_Z_GET_WORKDAY_STATUS;
/
