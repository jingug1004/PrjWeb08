CREATE PROCEDURE      SP_SFA_OFFICE_09
(
    in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3)
    in_BRD_NO            IN  NUMBER,       -- 게시판 번호
    in_BRDWRT_NO         IN  NUMBER,       -- 게시글 번호
    in_BRDWRT_SEQ        IN  NUMBER,       -- 게시글 순번
    in_SAWON_ID          IN  VARCHAR2,     -- 사번
    in_COM_SEQ           IN  NUMBER,       -- 댓글 순번
    in_COM_CONT          IN  VARCHAR2,     -- 내용
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 게시판 댓글 등록 
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_seq                NUMBER;
    
    v_uno                VARCHAR(7);
    v_ent_uno            VARCHAR(7);
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM hanagw.TGWBDCOM
     WHERE BRD_NO      = in_BRD_NO
       AND BRDWRT_NO   = in_BRDWRT_NO
       AND BRDWRT_SEQ  = in_BRDWRT_SEQ;
         
    out_COUNT := v_num;
    IF in_BTN_GUBUN = 1 THEN -- 등록버튼 클릭한 경우
        SELECT COUNT(*)
          INTO v_num
          FROM hanagw.TGWBDCOM
         WHERE BRD_NO      = in_BRD_NO
           AND BRDWRT_NO   = in_BRDWRT_NO
           AND BRDWRT_SEQ  = in_BRDWRT_SEQ
           AND COM_SEQ     = in_COM_SEQ;
           
        IF v_num >= 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 있습니다';
        ELSE
            -- 필수값 체크 루틴 넣을것.
            SELECT NVL(UNO, '0000000')
              INTO v_uno
              FROM V_SAWON_ID_MAP
             WHERE SAWON_ID = in_SAWON_ID;
     
            -- 게시댓글번호 MAX 생성
            SELECT NVL(MAX(COM_SEQ),0) + 1
              INTO v_seq
              FROM hanagw.TGWBDCOM
             WHERE BRD_NO      = in_BRD_NO
               AND BRDWRT_NO   = in_BRDWRT_NO
               AND BRDWRT_SEQ  = in_BRDWRT_SEQ;
                          
            -- 등록    
            INSERT INTO hanagw.TGWBDCOM(BRD_NO,    BRDWRT_NO,     BRDWRT_SEQ,      COM_SEQ,    COM_CONT,    DRWMAN,       DRW_DTM,                               ENT_UNO,     ENT_DTM) 
                           VALUES(in_BRD_NO, in_BRDWRT_NO,  in_BRDWRT_SEQ,   v_seq,      in_COM_CONT, v_uno,  TO_CHAR(SYSDATE, 'YYYYMMDDHH24MISS'),  v_uno, SYSDATE) ;
            
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT BRD_NO                 AS out_BRD_NO            --게시판 번호
                 , BRDWRT_NO              AS out_BRDWRT_NO         --게시글 번호
                 , BRDWRT_SEQ             AS out_BRDWRT_SEQ        --게시글 일련번호
                 , COM_SEQ                AS out_COM_SEQ           --게시글 댓글 일련번호
                 , SUBSTR(DRW_DTM,1,8)    AS out_DRW_DTM           --작성일자
                 , COM_CONT               AS out_COM_CONT          --게시글 내용
                 , DRWMAN                 AS out_DRWMAN            --게시자 사번
                 , (SELECT EMP_KO_NM FROM V_SAWON_ID_MAP WHERE UNO = DRWMAN AND SAWON_ID = in_SAWON_ID)          AS out_DRW_NM            --게시자 명 
                 , (SELECT NVL(SAWON_ID, EMP_NO) FROM V_SAWON_ID_MAP WHERE UNO = DRWMAN AND SAWON_ID = in_SAWON_ID)  AS out_SAWON_ID   -- UNO 변환 SALE사번
                FROM hanagw.TGWBDCOM
             WHERE BRD_NO      = in_BRD_NO
               AND BRDWRT_NO   = in_BRDWRT_NO
               AND BRDWRT_SEQ  = in_BRDWRT_SEQ
               AND COM_SEQ     = v_seq;
             
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '등록이 완료되었습니다';
        END IF;
    ELSIF in_BTN_GUBUN = 2 THEN -- 수정버튼 클릭한 경우
        IF v_num < 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            SELECT NVL(UNO, '0000000')
              INTO v_uno
              FROM V_SAWON_ID_MAP
             WHERE SAWON_ID = in_SAWON_ID;
            
            SELECT ENT_UNO
              INTO v_ent_uno
              FROM hanagw.TGWBDCOM
             WHERE BRD_NO      = in_BRD_NO
               AND BRDWRT_NO   = in_BRDWRT_NO
               AND BRDWRT_SEQ  = in_BRDWRT_SEQ
               AND COM_SEQ     = in_COM_SEQ;
               
            IF v_uno <> v_ent_uno THEN
                out_CODE := 1;
                out_MSG := '본인이 등록한 게시 댓글이 아닙니다.';
            ELSE   
                UPDATE hanagw.TGWBDCOM
                   SET COM_CONT    = in_COM_CONT
                     , UPD_UNO     = v_uno
                     , UPD_DTM     = SYSDATE
                 WHERE BRD_NO      = in_BRD_NO
                   AND BRDWRT_NO   = in_BRDWRT_NO
                   AND BRDWRT_SEQ  = in_BRDWRT_SEQ
                   AND COM_SEQ     = in_COM_SEQ;
                  
                COMMIT;
    
                OPEN out_RESULT FOR
                SELECT BRD_NO                 AS out_BRD_NO            --게시판 번호
                     , BRDWRT_NO              AS out_BRDWRT_NO         --게시글 번호
                     , BRDWRT_SEQ             AS out_BRDWRT_SEQ        --게시글 일련번호
                     , COM_SEQ                AS out_COM_SEQ           --게시글 댓글 일련번호
                     , SUBSTR(DRW_DTM,1,8)    AS out_DRW_DTM           --작성일자
                     , COM_CONT               AS out_COM_CONT          --게시글 내용
                     , DRWMAN                 AS out_DRWMAN            --게시자 사번
                     , (SELECT EMP_KO_NM FROM V_SAWON_ID_MAP WHERE UNO = DRWMAN AND SAWON_ID = in_SAWON_ID)               AS out_DRW_NM            --게시자 명 
                     , (SELECT NVL(SAWON_ID, EMP_NO) FROM V_SAWON_ID_MAP WHERE UNO = DRWMAN AND SAWON_ID = in_SAWON_ID)  AS out_SAWON_ID   -- UNO 변환 SALE사번
                    FROM hanagw.TGWBDCOM
                 WHERE BRD_NO      = in_BRD_NO
                   AND BRDWRT_NO   = in_BRDWRT_NO
                   AND BRDWRT_SEQ  = in_BRDWRT_SEQ
                   AND COM_SEQ     = in_COM_SEQ;
                 
                out_CODE := 0;
                out_MSG := '수정이 완료되었습니다';
            END IF;
        END IF;
    ELSIF in_BTN_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우
        IF v_num < 1 THEN
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            SELECT NVL(UNO, '0000000')
              INTO v_uno
              FROM V_SAWON_ID_MAP
             WHERE SAWON_ID = in_SAWON_ID;
            
            SELECT ENT_UNO
              INTO v_ent_uno
              FROM hanagw.TGWBDCOM
             WHERE BRD_NO      = in_BRD_NO
               AND BRDWRT_NO   = in_BRDWRT_NO
               AND BRDWRT_SEQ  = in_BRDWRT_SEQ
               AND COM_SEQ     = in_COM_SEQ;
               
            IF v_uno <> v_ent_uno THEN
                out_CODE := 1;
                out_MSG := '본인이 등록한 게시 댓글이 아닙니다.';
            ELSE   
                DELETE FROM hanagw.TGWBDCOM
                 WHERE BRD_NO          = in_BRD_NO
                   AND BRDWRT_NO       = in_BRDWRT_NO
                   AND BRDWRT_SEQ      = in_BRDWRT_SEQ
                   AND COM_SEQ         = in_COM_SEQ;
                  
                COMMIT;
                
                OPEN out_RESULT FOR
                SELECT BRD_NO                 AS out_BRD_NO            --게시판 번호
                     , BRDWRT_NO              AS out_BRDWRT_NO         --게시글 번호
                     , BRDWRT_SEQ             AS out_BRDWRT_SEQ        --게시글 일련번호
                     , COM_SEQ                AS out_COM_SEQ           --게시글 댓글 일련번호
                     , SUBSTR(DRW_DTM,1,8)    AS out_DRW_DTM           --작성일자
                     , COM_CONT               AS out_COM_CONT          --게시글 내용
                     , DRWMAN                 AS out_DRWMAN            --게시자 사번
                     , (SELECT EMP_KO_NM FROM V_SAWON_ID_MAP WHERE UNO = DRWMAN AND SAWON_ID = in_SAWON_ID)                 AS out_DRW_NM            --게시자 명 
                     , (SELECT NVL(SAWON_ID, EMP_NO) FROM V_SAWON_ID_MAP WHERE UNO = DRWMAN AND SAWON_ID = in_SAWON_ID)  AS out_SAWON_ID   -- UNO 변환 SALE사번
                    FROM hanagw.TGWBDCOM
                 WHERE BRD_NO      = in_BRD_NO
                   AND BRDWRT_NO   = in_BRDWRT_NO
                   AND BRDWRT_SEQ  = in_BRDWRT_SEQ
                   AND COM_SEQ     = (SELECT MAX(COM_SEQ) FROM hanagw.TGWBDCOM WHERE BRD_NO = in_BRD_NO  AND BRDWRT_NO   = in_BRDWRT_NO AND BRDWRT_SEQ  = in_BRDWRT_SEQ);
                 
                out_CODE := 0;
                out_MSG := '삭제가 완료되었습니다';
            END IF;
         END IF;
    ELSE   -- 조회처리
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '정보가 존재하지 않습니다.';
        ELSIF (v_num >= 1) THEN
            out_CODE := 0;
            out_MSG := '정보 확인완료';    
             
            OPEN out_RESULT FOR
            SELECT BRD_NO                 AS out_BRD_NO            --게시판 번호
                 , BRDWRT_NO              AS out_BRDWRT_NO         --게시글 번호
                 , BRDWRT_SEQ             AS out_BRDWRT_SEQ        --게시글 일련번호
                 , COM_SEQ                AS out_COM_SEQ           --게시글 댓글 일련번호
                 , SUBSTR(DRW_DTM,1,8)    AS out_DRW_DTM           --작성일자
                 , COM_CONT               AS out_COM_CONT          --게시글 내용
                 , DRWMAN                 AS out_DRWMAN            --게시자 사번
                 , (SELECT EMP_KO_NM FROM V_SAWON_ID_MAP WHERE UNO = DRWMAN AND SAWON_ID = in_SAWON_ID)               AS out_DRW_NM            --게시자 명 
                 , (SELECT NVL(SAWON_ID, EMP_NO) FROM V_SAWON_ID_MAP WHERE UNO = DRWMAN AND SAWON_ID = in_SAWON_ID)  AS out_SAWON_ID   -- UNO 변환 SALE사번
                FROM hanagw.TGWBDCOM
             WHERE BRD_NO      = in_BRD_NO
               AND BRDWRT_NO   = in_BRDWRT_NO
               AND BRDWRT_SEQ  = in_BRDWRT_SEQ;
        END IF;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
