CREATE PROCEDURE      SP_Z_COMMON_04
(
    in_GUBUN             IN  NUMBER,    -- 1:사번, 2:이름 3-사번으로 전체사원검색   4-이름으로 전체사원검색
    in_ITEM              IN  VARCHAR2,  -- 사번/이름
    in_SAWON_ID          IN  VARCHAR2,  -- 로그인 사번
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 사번 또는 사원명으로 사원검색
          사번에 따라 하위부서의 사원들도 검색되어야 함
 호출프로그램 : 방문>방문활동내역 의 담당자 
           현황> 출퇴근현황 의 담당자
 수정내역     2014.08.18 CHOE - 기획실 인형진 요청 팀장이 아니더라도 부서 권한만 있다면 확인 가능하도록
          2015.04.09 KTA  - 기획실 인형진 확인 임시팀장인 경우는 현재 송민호대리뿐이라 인사에서 지정된 직책으로 하위사원 가져오는 처리해도 된다고 함. 
                           - admin 으로 로그인 했을 경우 전체 사원조회하도록 프로그램 되어있지 않아서 되도록 수정함.
          2015.06.08 KTA  - 임시팀장 직책코드 추가관련 수정
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER; 
    
    v_deptcode           VARCHAR2(4); --로그인사원의 부서
    v_assgn_cd           VARCHAR2(5); --직책
    v_query_deptcode     VARCHAR2(4); --로그인사원에 따른 조회부서
    v_pda_auth           VARCHAR2(1); --영업시스템권한  A:전체,P-개인,D-부서 
    v_adminloginyn       VARCHAR2(1);  -- admin 부서 로그인여부    
    
    GUBUN_NULL           EXCEPTION;
BEGIN

    
    IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
        RAISE GUBUN_NULL;
    END IF;  
    
    IF in_GUBUN in ('3','4' ) THEN  -- 1:사번, 2:이름 3-사번으로 전체사원검색   4-이름으로 전체사원검색
    
            --사원이면 사원리스트 검색안됨 
            SELECT COUNT(*)
              INTO v_num
              FROM (
                        SELECT deptcode,empcode,classdiv
                          FROM ORAGMP.CMEMPM
                         WHERE plantcode = '1000' 
                           AND DECODE(in_GUBUN, 1, empcode, empname ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%') 
                           AND rownum = 1
                   ) 
            ; 
                           
                           
            out_COUNT := v_num;
            IF (v_num = 0) THEN
                out_CODE := 1;
                out_MSG := '검색내용이 없습니다.';
            ELSIF (v_num >= 1) THEN
                out_CODE := 0;
                out_MSG := '검색 확인완료';    
                 
                OPEN out_RESULT FOR
                SELECT deptcode                          AS out_DEPT_CD    -- 부서코드
                      ,deptname                          AS out_DEPT_NM    -- 부서명
                      ,empcode                           AS out_SAWON_ID   -- 사원 ID
                      ,'  '||empname||' '||classdivname||' '|| jajikgb  AS out_SAWON_NM    -- 사원명              
                  FROM (
                        SELECT deptcode,oragmp.fncommonnm('dept',deptcode,'') as deptname 
                              ,empcode ,oragmp.fncommonnm('emp' ,empcode,'') as empname
                              ,classdiv,oragmp.fncommonnm('COMM','PS42',classdiv) as classdivname
                              ,decode(RETIREDT,null,'재직','퇴직')  as jajikgb
                          FROM ORAGMP.CMEMPM
                         WHERE plantcode = '1000' 
                           AND empdiv = '01' --사원구분 - PS41
                           AND DECODE(in_GUBUN, 1, empcode, empname ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')                      
                        )  
                 ORDER BY out_SAWON_NM;
                 
            END IF;    
    
    END IF;
    
    
    
    -- 로그인 사원의 직책에 에 따라 검색 
    IF in_GUBUN not in ('3','4' ) THEN   -- 1:사번, 2:이름 3-사번으로 전체사원검색   4-이름으로 전체사원검색
 
            --로그인사원의 직책,부서
            select classdiv,deptcode into v_assgn_cd,v_deptcode from ORAGMP.CMEMPM  where empcode = in_SAWON_ID;
                
            v_query_deptcode := v_deptcode;              
            -- 조회부서:: 로그인 직책에따라 상위부서를 찾거나 본인부서를 찾는다.
            if v_assgn_cd in ('27010','27018','27023','27025','27026')  then   -- 본부장 ,부본부장, 총괄이사, 총괄지점장, 선임지점장       지점장,팀장, 임시팀장('27027','27030','27035') 은 1레벨위로 안가야 함 
               select deptcode 
                 into v_query_deptcode 
                 from ORAGMP.CMDEPTM 
                where useyn = 'Y' and level = 2 connect by deptcode = prior predeptcode start with plantcode = '1000' and deptcode = v_deptcode; 
            end if; 
            
            if v_query_deptcode in ('0007','0004','0302','0114','0527') then 
               v_adminloginyn   := 'Y';
            else
               v_adminloginyn   := 'N';           
            end if;
        
            --사원이면 사원리스트 검색안됨 
            SELECT COUNT(*)
              INTO v_num
              FROM (
                        SELECT deptcode,empcode,classdiv
                          FROM ORAGMP.CMEMPM
                         WHERE plantcode = '1000' 
                           AND DECODE(in_GUBUN, 1, empcode, empname ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                           AND deptcode in ( SELECT deptcode FROM ORAGMP.CMDEPTM WHERE useyn = 'Y' AND v_assgn_cd in ('27010','27018','27023','27025','27026')   --본부장   부본부장, 총괄이사, 총괄지점장, 선임지점장
                                                    CONNECT BY PRIOR deptcode = predeptcode START WITH plantcode = '1000' and deptcode = v_query_deptcode
                                             union all
                                             SELECT v_query_deptcode FROM DUAL WHERE v_assgn_cd in ('27027','27030','27035') -- 지점장,  팀장,임시팀장 
                                            )
                           AND v_adminloginyn   = 'N' 
                           AND rownum = 1               
                         UNION ALL 
                        SELECT deptcode,empcode,classdiv
                          FROM ORAGMP.CMEMPM
                         WHERE plantcode = '1000' 
                           AND DECODE(in_GUBUN, 1, empcode, empname ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%') 
                           AND v_adminloginyn   = 'Y'   
                           AND rownum = 1                                      
                   ) 
            ; 
                           
                           
            out_COUNT := v_num;
            IF (v_num = 0) THEN
                out_CODE := 1;
                out_MSG := '검색내용이 없습니다.';
            ELSIF (v_num >= 1) THEN
                out_CODE := 0;
                out_MSG := '검색 확인완료';    
                 
                OPEN out_RESULT FOR
                SELECT deptcode                          AS out_DEPT_CD    -- 부서코드
                      ,deptname                          AS out_DEPT_NM    -- 부서명
                      ,empcode                           AS out_SAWON_ID   -- 사원 ID
                      ,'  '||empname||' '||classdivname  AS out_SAWON_NM    -- 사원명              
                  FROM (
                        SELECT deptcode,oragmp.fncommonnm('dept',deptcode,'') as deptname 
                              ,empcode ,oragmp.fncommonnm('emp' ,empcode,'') as empname
                              ,classdiv,oragmp.fncommonnm('COMM','PS42',classdiv) as classdivname
                          FROM ORAGMP.CMEMPM
                         WHERE plantcode = '1000' 
                           AND DECODE(in_GUBUN, 1, empcode, empname ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%')
                           AND deptcode in ( SELECT deptcode FROM ORAGMP.CMDEPTM WHERE useyn = 'Y' AND v_assgn_cd in ('27010','27018','27023','27025','27026')   --본부장   부본부장, 총괄이사, 총괄지점장, 선임지점장
                                                    CONNECT BY PRIOR deptcode = predeptcode START WITH plantcode = '1000' and deptcode = v_query_deptcode
                                             union all
                                             SELECT v_query_deptcode FROM DUAL WHERE v_assgn_cd in ('27027','27030','27035') -- 지점장,  팀장,임시팀장 
                                            )
                           AND v_adminloginyn   = 'N'    
                                       
                         UNION ALL
                          
                        SELECT deptcode,oragmp.fncommonnm('dept',deptcode,'') as deptname 
                              ,empcode ,oragmp.fncommonnm('emp' ,empcode,'') as empname
                              ,classdiv,oragmp.fncommonnm('COMM','PS42',classdiv) as classdivname
                          FROM ORAGMP.CMEMPM 
                         WHERE plantcode = '1000' 
                           AND DECODE(in_GUBUN, 1, empcode, empname ) LIKE DECODE(in_GUBUN, 1, NVL(in_ITEM,'%'), '%'||NVL(in_ITEM,'%')||'%') 
                           AND v_adminloginyn   = 'Y'                          
                        )  
                 ORDER BY deptcode,empcode;
                 
            END IF;
    END IF;
            
EXCEPTION
WHEN GUBUN_NULL THEN
   out_CODE := 101;
   out_MSG  := '검색 구분코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
