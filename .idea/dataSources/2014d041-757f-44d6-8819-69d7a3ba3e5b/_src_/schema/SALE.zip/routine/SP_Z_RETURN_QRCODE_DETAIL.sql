CREATE PROCEDURE      SP_Z_RETURN_QRCODE_DETAIL 
(
    in_PROCESS      IN  VARCHAR2,   
    in_SAWON_ID     IN  VARCHAR2,   
    in_QRCODE       IN  VARCHAR2,   
    out_CODE             out NUMBER,
    out_MSG              out VARCHAR2,
    out_COUNT            out NUMBER,
    out_RESULT           out TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
BEGIN

 insert into SFA_SP_CALLED_HIST values ('SP_Z_RETURN_QRCODE_DETAIL','1',sysdate,'in_PROCESS:'||in_PROCESS||'/in_SAWON_ID:'||in_SAWON_ID||'/in_QRCODE:'||in_QRCODE  );
 commit;
   
    IF in_PROCESS = '0' THEN -- QR CODE 읽은데이타가 사입이력이 있는지
    
        /*  제조번호 사용기한을 피킹정보에서 찾는것은 2018년이후 출고분 부터 발생하기때문에 사용못함 
        SELECT COUNT(*)
            INTO v_num
        from rfid_user.DELIVERY_TAGINFO a
                 ,oragmp.slordm b
                 ,oragmp.slordd c
                 ,oragmp.SLITEMTAKINGOUT d
        where   a.delivery_order_no = b.orderno
            and a.delivery_order_no = c.orderno
            and a.item_no           = c.itemcode
            and a.delivery_order_no = d.orderno(+)
            and a.item_no           = d.itemcode(+)
            and a.lot_no            = d.lotno(+)
            and a.tagid             = in_QRCODE;
       */     
            

        SELECT COUNT(*)
            INTO v_num
        from rfid_user.DELIVERY_TAGINFO a
             ,oragmp.slordm b
             ,oragmp.slordd c
             ,rfid_user.rfidproductinfo d
        where a.delivery_order_no = b.orderno
          and a.delivery_order_no = c.orderno
          and a.item_no           = c.itemcode
          and a.item_no           = d.item_no 
          and a.lot_no            = d.lot_no 
          and a.tagid             = in_QRCODE;
                        
    ELSE
         SELECT COUNT(*)
           INTO v_num
           FROM sfa_banpum_reason 
          WHERE YMD = in_QRCODE;
    END IF;
    
    out_COUNT := v_num;
     
    IF in_PROCESS = '0' THEN -- QR CODE 읽은데이타가 사입이력이 있는지
        IF v_num = 0 THEN -- 신규등록
            out_CODE := 1;
            out_MSG := '사입내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '요청하신 작업이 확인되었습니다.';      
            
            OPEN out_RESULT FOR
            
            /*
             제조번호 사용기한을 피킹정보에서 찾는것은 2018년이후 출고분 부터 발생하기때문에 사용못함 
            select  b.orderdate                                 out_YMD  -- 출고일자
                   ,b.custcode                                  out_CUSTID  -- 거래처코드
                   ,oragmp.fncommonnm('cust',b.custcode,'')     out_CUSTNM  -- 거래처명
                   ,b.ecustcode                                 out_RCUSTID -- 납품처코드
                   ,oragmp.fncommonnm('cust',b.ecustcode,'')    out_RCUSTNM -- 납품처명 
                   ,c.itemcode                                  out_ITEM_CD -- 제품코드
                   ,oragmp.fncommonnm('item',c.itemcode,'')     out_ITEM_NM -- 제품명
                   ,d.lotno                                     out_PRODNO  -- 제조번호
                   ,d.expdate                                   out_USEDYMD -- 사용기간
                   ,c.salprc                                    out_PRICE   -- 단가
                   ,b.empcode                                   out_SAWON_ID -- 거래처담당CODE
                   ,oragmp.fncommonnm('emp',b.empcode,'')       out_SAWON_NM -- 거래처담당명
                   ,b.eempcode                                  out_RSAWON_ID --납품처담당CODE
                   ,oragmp.fncommonnm('emp',b.eempcode,'')     out_RSAWON_NM --납품처담당명
                   ,b.orderno                                   out_ORDER_NO -- 주문번호
               from rfid_user.DELIVERY_TAGINFO a
                   ,oragmp.slordm b
                   ,oragmp.slordd c
                   ,oragmp.SLITEMTAKINGOUT d
              where a.delivery_order_no = b.orderno
                and a.delivery_order_no = c.orderno
                and a.item_no           = c.itemcode
                and a.delivery_order_no = d.orderno(+)
                and a.item_no           = d.itemcode(+)
                and a.lot_no            = d.lotno(+)
                and a.tagid = in_QRCODE;
                */
                
            select  b.orderdate                                 out_YMD  -- 출고일자
                   ,b.custcode                                  out_CUSTID  -- 거래처코드
                   ,oragmp.fncommonnm('cust',b.custcode,'')     out_CUSTNM  -- 거래처명
                   ,b.ecustcode                                 out_RCUSTID -- 납품처코드
                   ,oragmp.fncommonnm('cust',b.ecustcode,'')    out_RCUSTNM -- 납품처명 
                   ,c.itemcode                                  out_ITEM_CD -- 제품코드
                   ,oragmp.fncommonnm('item',c.itemcode,'')     out_ITEM_NM -- 제품명
                   ,d.lot_no                                    out_PRODNO  -- 제조번호
                   ,d.exp_ymd                                   out_USEDYMD -- 사용기간
                   ,c.salprc                                    out_PRICE   -- 단가
                   ,b.empcode                                   out_SAWON_ID -- 거래처담당CODE
                   ,oragmp.fncommonnm('emp',b.empcode,'')       out_SAWON_NM -- 거래처담당명
                   ,b.eempcode                                  out_RSAWON_ID --납품처담당CODE
                   ,oragmp.fncommonnm('emp',b.eempcode,'')      out_RSAWON_NM --납품처담당명
                   ,b.orderno                                   out_ORDER_NO -- 주문번호    
               from rfid_user.DELIVERY_TAGINFO a
                   ,oragmp.slordm b
                   ,oragmp.slordd c
                   ,rfid_user.rfidproductinfo d
              where a.delivery_order_no = b.orderno
                and a.delivery_order_no = c.orderno
                and a.item_no           = c.itemcode
                and a.item_no           = d.item_no 
                and a.lot_no            = d.lot_no 
                and a.tagid             = in_QRCODE;            
                                         
        END IF;
        
    ELSE
        
        out_CODE := 2;
        out_MSG := '222 사입내역이 존재하지 않습니다.';
        
        
    END IF;
     
    
      
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
