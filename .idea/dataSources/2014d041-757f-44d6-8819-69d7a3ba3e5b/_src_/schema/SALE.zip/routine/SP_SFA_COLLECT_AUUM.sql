CREATE PROCEDURE      SP_SFA_COLLECT_AUUM
   (in_FLAG         IN VARCHAR2 DEFAULT NULL,  --처리구분    
    in_CUST_ID      IN VARCHAR2 DEFAULT NULL,  --거래처코드
    in_RCUST_ID     IN VARCHAR2 DEFAULT NULL,  --간납처코드
    in_AMT          IN VARCHAR2 DEFAULT NULL,  --금액
    in_SAWON_ID     IN VARCHAR2 DEFAULT NULL,  --로그인사번
    in_BIGO         IN VARCHAR2 DEFAULT NULL,  --비고          
    in_BILL_GB      IN VARCHAR2 DEFAULT NULL,  --어음구분    
    in_BILL_NO      IN VARCHAR2 DEFAULT NULL,  --어음번호   
    in_BALHANG      IN VARCHAR2 DEFAULT NULL,  --발행처     
    in_JIGEUB       IN VARCHAR2 DEFAULT NULL,  --지급처(은행지점코드)    
    in_START_YMD    IN VARCHAR2 DEFAULT NULL,  --발행일
    in_END_YMD      IN VARCHAR2 DEFAULT NULL,  --만기일    
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2 
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   :어음수금  
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    
 
    ll_max number := 0;
    ll_count number := 0;
    
    v_SAWON_ID     VARCHAR2(20);  --거래처담당사원                     
    v_JUNPYO_NO    VARCHAR2(20);  --수금전표번호 
 
    
    ERROR_EXCEPTION     EXCEPTION;
    
BEGIN    
 
 
/*                 
 insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_AUUM','1',sysdate,'in_FLAG:'||in_FLAG ||'/in_CUST_ID:'||in_CUST_ID ||'/in_RCUST_ID:'||in_RCUST_ID  
                                        ||'/in_AMT:'||in_AMT||'/in_SAWON_ID:'||in_SAWON_ID ||'/in_BIGO:'||in_BIGO     
                                        ||'/in_BILL_GB:'||in_BILL_GB||'/in_BILL_NO:'||in_BILL_NO ||'/in_BALHANG:'||in_BALHANG      
                                        ||'/in_START_YMD:'||in_START_YMD||'/in_BILL_NO:'||in_END_YMD                                            
                                        ); 
*/                                        

   -- 담당사원  ID 가져오기   
    BEGIN
        select  sawon_id  into v_SAWON_ID from sale.sale0003 where cust_id = in_CUST_ID ;
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '<거래처에 담당영업사원이 지정되지 않았습니다. 관리부에 문의하십시오>';
        RAISE ERROR_EXCEPTION;
    END; 
        
    ll_max := 0;
    SP_SYS100C_MAX_VALUE('SALE0401', to_char(sysdate, 'yyyyMMdd'), null,null, null, null, ll_max );

    IF ll_max < 1 THEN 
        out_CODE := 1;
        out_MSG := '전표번호 생성 오류'; 
    ELSE 
        out_CODE := 0;
        out_MSG := '전표번호 생성완료'; 
    
        SELECT to_char(sysdate, 'yyyyMMdd') || Lpad(to_char(ll_max),4,'0') 
          INTO v_JUNPYO_NO
          FROM dual;
        
    END IF;    
    
    BEGIN
        INSERT INTO SALE.SALE0401
               (YMD        --일자
               ,JUNPYO_GB  --전표구분
               ,JUNPYO_NO  --전표번호
               ,CUST_ID    --거래처코드
               ,RCUST_ID   --실거래처코드
               ,CASH_AMT   --현금금액
               ,BILL_AMT   --어음금액
               ,SAWON_ID   --거래처담당사원
               ,INPUT_ID   --입력사번
               ,INPUT_YMD  --입력일자
               ,BIGO       --비고 
               ,LOG_DATE   --등록일시
               )
        VALUES (TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')
               ,'01'
               ,v_JUNPYO_NO
               ,in_CUST_ID
               ,in_RCUST_ID
               ,0
               ,decode( NVL(in_AMT, ''),'','0',to_number(in_AMT))
               ,v_SAWON_ID   --거래처담당사번
               ,in_SAWON_ID  --로그인사번
               ,SYSDATE
               ,in_BIGO
               ,SYSDATE
               );
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
        RAISE ERROR_EXCEPTION;
    END;
     
     --상세내역 저장
    BEGIN
        INSERT INTO SALE.SALE0402
              ( YMD          --일자
               ,JUNPYO_NO    --전표번호
               ,INPUT_SEQ    --순번
               ,BILL_GB      --어음구분
               ,BILL_NO      --어음번호(카드번호)
               ,START_YMD    --발행일
               ,END_YMD      --만기일
               ,BALHANG      --발행처
               ,JIGEUB       --지금처
               ,AMT          --금액 
               ,GYULJAE_YMD  --결재일
               ,BIGO         --비고
              )
       VALUES ( TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')
               ,v_JUNPYO_NO
               ,'0001'
               ,in_BILL_GB
               ,in_BILL_NO
               ,in_START_YMD
               ,in_END_YMD
               ,in_BALHANG
               ,in_JIGEUB
               ,decode( NVL(in_AMT, ''),'','0',to_number(in_AMT))
               ,TO_DATE(TO_CHAR(sysdate,'YYYYMMDD'),'YYYYMMDD')
               ,in_BIGO
              );
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '어음수금상세 저장실패:'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
        RAISE ERROR_EXCEPTION;
    END; 

    out_CODE := 0;
    out_MSG := '어음수금 정상 처리';
     
EXCEPTION
WHEN ERROR_EXCEPTION THEN
   out_CODE := 1;
   ROLLBACK;
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
