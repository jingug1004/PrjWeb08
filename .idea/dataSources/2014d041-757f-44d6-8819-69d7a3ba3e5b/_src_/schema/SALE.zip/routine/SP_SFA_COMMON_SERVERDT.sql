CREATE PROCEDURE      SP_SFA_COMMON_SERVERDT
(
    in_GUBUN             IN  VARCHAR2,  --요청구분 1
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 서버시각조회 
 호출프로그램 :         
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
BEGIN
     

    IF in_GUBUN = '1' THEN  --현재일자
    
        out_COUNT := 1;
        out_CODE := 0;
        out_MSG := '검색 확인완료';   
                     
        OPEN out_RESULT FOR
        SELECT TO_CHAR(SYSDATE,'YYYYMMDD')         as out_SERVER_YMD
              ,TO_CHAR(SYSDATE,'YYYYMMDDHH24MISS') as out_SERVER_YMDHMS
              ,TO_CHAR(SYSDATE,'HH24MISS')         as out_SERVER_HMS
          FROM DUAL; 
        
    END IF;      
    
 

EXCEPTION   
    WHEN OTHERS THEN
       out_CODE := SQLCODE;
       out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
