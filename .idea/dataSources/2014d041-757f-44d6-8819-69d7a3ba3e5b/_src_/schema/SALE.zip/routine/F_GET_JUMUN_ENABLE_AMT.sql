CREATE function      F_GET_JUMUN_ENABLE_AMT
        ( A_CUST_ID      VARCHAR2, -- 직납처 
          A_CREDIT_LIMIT_AMT NUMBER --여신한도액
        )
   RETURN VARCHAR2
AS
   user_err         exception   ;
   n_tot_credit     NUMBER; 
   n_sale_dambo_amt NUMBER;
   n_dambo_rate     NUMBER;
   n_rtn_value      NUMBER;
   v_curr_error     VARCHAR2(250);

/*----------------------------------------------------------------
  해당 거래처의 주문가능금액을 계산한다.
  사용한곳 :온라인주문 승인화면에서 주문내역 리스트 SQL   
   
----------------------------------------------------------------*/
BEGIN
  
    --총여신 
    SELECT NVL(F.BEFORE_AMT,0) + NVL(F.MISU_AMT,0) - NVL(F.SU_AMT,0)  + NVL(L.BILL_010_AMT,0) + NVL(L.BILL_020_AMT,0) + NVL(L.BILL_030_AMT,0) + NVL(L.BILL_100_AMT,0) + NVL(L.BILL_900_AMT,0)  
          ,NVL(H.SALE_DAMBO_AMT,0)
      INTO n_tot_credit, n_sale_dambo_amt       
      FROM ( SELECT CUST_ID , 
                    SUM(BEFORE_AMT)  BEFORE_AMT,
                    SUM(MISU_AMT)    MISU_AMT,
                    SUM(SU_AMT)      SU_AMT
               FROM SALE.SALE0306
              WHERE YMD        = TO_DATE(TO_CHAR(sysdate,'YYYY/MM')||'/01','YYYY/MM/DD')
                AND CUST_ID    = A_CUST_ID
              GROUP BY CUST_ID
            ) F,
            ( SELECT X.CUST_ID, NVL(SUM(X.SALE_DAMBO_AMT),0) SALE_DAMBO_AMT, COUNT(BILL_GB) BILL_CNT,
                     (SELECT (SELECT CODE1_NM FROM SALE.SALE0001 WHERE CODE_GB = '0022' AND CODE1 = X.BILL_GB ) BILL_GB
                        FROM SALE.SALE0404 X
                       WHERE X.CUST_ID    = A_CUST_ID
                         AND NVL(X.CHULGO_YMD,TO_DATE('2999/01/01','YYYY/MM/DD')) = TO_DATE('2999/01/01','YYYY/MM/DD')
                         AND ROWNUM = 1)  BILL_KIND
                FROM SALE.SALE0404 X
               WHERE X.CUST_ID    = A_CUST_ID
                 AND NVL(X.CHULGO_YMD,TO_DATE('2999/01/01','YYYY/MM/DD')) = TO_DATE('2999/01/01','YYYY/MM/DD')
               GROUP BY X.CUST_ID 
            ) H,
            (
             SELECT X.CUST_ID        CUST_ID ,
                    NVL(SUM(DECODE(Y.BILL_GB,'010',Y.AMT)),0)  BILL_010_AMT,
                    NVL(SUM(DECODE(Y.BILL_GB,'020',Y.AMT)),0)  BILL_020_AMT,
                    NVL(SUM(DECODE(Y.BILL_GB,'025',Y.AMT)),0)  BILL_025_AMT,
                    NVL(SUM(DECODE(Y.BILL_GB,'030',Y.AMT)),0)  BILL_030_AMT,
                    NVL(SUM(DECODE(Y.BILL_GB,'035',Y.AMT)),0)  BILL_035_AMT,
                    NVL(SUM(DECODE(Y.BILL_GB,'040',Y.AMT)),0)  BILL_040_AMT,
                    NVL(SUM(DECODE(Y.BILL_GB,'100',Y.AMT)),0)  BILL_100_AMT,
                    NVL(SUM(DECODE(Y.BILL_GB,'900',Y.AMT)),0)  BILL_900_AMT
               FROM SALE.SALE0401 X ,
                    SALE.SALE0402 Y
              WHERE X.YMD       = Y.YMD
                AND X.JUNPYO_NO = Y.JUNPYO_NO 
                AND Y.END_YMD  >= SYSDATE
                AND X.CUST_ID   = A_CUST_ID
              GROUP BY X.CUST_ID
            ) L
      WHERE F.CUST_ID    = A_CUST_ID
        AND F.CUST_ID    = H.CUST_ID(+)
        AND F.CUST_ID    = L.CUST_ID(+);

   -- 여신하도액이 0 보다크면  여신한도액 - 총여신
   --              0 이면      (거래처담보확보액 / 확보율) - 총여신
    IF A_CREDIT_LIMIT_AMT > 0 THEN          
       n_rtn_value := A_CREDIT_LIMIT_AMT - n_tot_credit;
    
    ELSE 
      --거래처 담보확보율 
       SELECT TO_NUMBER(BIGO) INTO n_dambo_rate FROM SALE0001 WHERE CODE_GB = '4001' AND CODE1 = '02';
       
       n_rtn_value := round(n_sale_dambo_amt/n_dambo_rate,0) - n_tot_credit;
       
    END IF; 
       
       
    RETURN n_rtn_value;

EXCEPTION WHEN user_err THEN
               RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
          WHEN OTHERS THEN
               RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;

/
