CREATE PROCEDURE      SP_SFA_ADMIN_02    -- 의학용어 등록
(
    in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3, 거래요청:4)
    in_SEQ_NO            IN  NUMBER,     -- SEQ
    in_DICT_HANGUL       IN  VARCHAR2,       -- 의학용어(한글)
    in_DICT_ENG          IN  VARCHAR2,       -- 의학용어(영문)
    in_DICT_DESC         IN  VARCHAR2,     -- 용어설명
    in_DICT_CODE         IN  VARCHAR2,     -- 분류코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    v_seq                NUMBER;
    v_dict_cd            NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_MEDIDICT
     WHERE SEQ_NO  = in_SEQ_NO;
         
    out_COUNT := v_num;
    IF in_BTN_GUBUN = 1 THEN -- 등록버튼 클릭한 경우
        IF in_SEQ_NO IS NOT NULL AND v_num >= 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 있습니다';
        ELSE
            -- 필수값 체크 루틴 넣을것.
            
            -- 의학용어 SEQ번호 MAX 생성
            SELECT NVL(MAX(SEQ_NO),0)+1
              INTO v_seq
              FROM SFA_OFFICE_MEDIDICT;
              
            -- 분류코드 MAX 생성
            --SELECT NVL(MAX(TO_NUMBER(DICT_CODE)), 0)+1
            --  INTO v_dict_cd
            --  FROM SFA_OFFICE_MEDIDICT;
              
            -- 의학용어 등록
            INSERT INTO SFA_OFFICE_MEDIDICT(SEQ_NO,    DICT_HANGUL,    DICT_ENG,     DICT_DESC,    DICT_CODE) 
                                      VALUES(v_seq,     in_DICT_HANGUL, in_DICT_ENG,  in_DICT_DESC, in_DICT_CODE) ;
            
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT v_seq                 AS out_SEQ_NO
                 , in_DICT_HANGUL        AS out_DICT_HANGUL
                 , in_DICT_ENG           AS out_DICT_ENG
                 , in_DICT_DESC          AS out_DICT_DESC
                 , in_DICT_CODE          AS out_DICT_CODE
                FROM DUAL;
             
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '등록이 완료되었습니다';
        END IF;
    ELSIF in_BTN_GUBUN = 2 THEN -- 수정버튼 클릭한 경우
        IF v_num < 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            UPDATE SFA_OFFICE_MEDIDICT
               SET DICT_HANGUL =    in_DICT_HANGUL
                 , DICT_ENG    =    in_DICT_ENG
                 , DICT_DESC   =    in_DICT_DESC
             WHERE SEQ_NO      =    in_SEQ_NO;
              
            COMMIT;

            OPEN out_RESULT FOR
            SELECT SEQ_NO                AS out_SEQ_NO
                 , DICT_HANGUL           AS out_DICT_HANGUL
                 , DICT_ENG              AS out_DICT_ENG
                 , DICT_DESC             AS out_DICT_DESC
                 , DICT_CODE             AS out_DICT_CODE  
                FROM SFA_OFFICE_MEDIDICT
             WHERE SEQ_NO      =    in_SEQ_NO;
             
            out_CODE := 0;
            out_MSG := '수정이 완료되었습니다';
        END IF;
    ELSIF in_BTN_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우
        IF v_num < 1 THEN
            out_CODE := 1;
            out_MSG := '기존 등록된 답글이 없습니다';
        ELSE
            DELETE FROM SFA_OFFICE_MEDIDICT
             WHERE SEQ_NO      =    in_SEQ_NO;
              
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT SEQ_NO                AS out_SEQ_NO
                 , DICT_HANGUL           AS out_DICT_HANGUL
                 , DICT_ENG              AS out_DICT_ENG
                 , DICT_DESC             AS out_DICT_DESC
                 , DICT_CODE             AS out_DICT_CODE  
                FROM SFA_OFFICE_MEDIDICT
             WHERE SEQ_NO      =    (in_SEQ_NO - 1);
             
            out_CODE := 0;
            out_MSG := '삭제가 완료되었습니다';
         END IF;
    ELSE   -- 조회처리
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '정보가 존재하지 않습니다.';
        ELSIF (v_num >= 1) THEN
            out_CODE := 0;
            out_MSG := '정보 확인완료';    
             
            OPEN out_RESULT FOR
            SELECT SEQ_NO                AS out_SEQ_NO
                 , DICT_HANGUL           AS out_DICT_HANGUL
                 , DICT_ENG              AS out_DICT_ENG
                 , DICT_DESC             AS out_DICT_DESC
                 , DICT_CODE             AS out_DICT_CODE  
                FROM SFA_OFFICE_MEDIDICT
             WHERE SEQ_NO      = in_SEQ_NO
               AND DICT_HANGUL LIKE '%'||NVL(in_DICT_HANGUL, '%')||'%';
        END IF;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
