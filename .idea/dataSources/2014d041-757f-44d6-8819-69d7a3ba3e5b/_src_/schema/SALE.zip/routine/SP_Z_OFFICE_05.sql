CREATE PROCEDURE      SP_Z_OFFICE_05    -- office.MedicalDicRegist : 의학용어 FUNC_INSERT :SP_SFA_OFFICE_05
(
    in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3, 거래요청:4)
    in_SEQ_NO            IN  NUMBER,       -- SEQ
    in_DICT_HANGUL       IN  VARCHAR2,     -- 의학용어(한글)
    in_DICT_ENG          IN  VARCHAR2,     -- 의학용어(영문)
    in_DICT_DESC         IN  VARCHAR2,     -- 용어설명
    in_DICT_CODE         IN  VARCHAR2,     -- 분류코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 의학용어 신규,수정,삭제
 호출프로그램 : office.MedicalDicRegist
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_seq                NUMBER;
    v_dict_cd            NUMBER;
BEGIN

    IF in_BTN_GUBUN = 1 THEN -- 등록버튼 클릭한 경우
        IF in_SEQ_NO IS NOT NULL AND v_num >= 1 THEN            
            out_CODE := 1;
            out_COUNT := 0;
            out_MSG := '기존 등록된 용어가 있습니다';
        ELSE
            -- 필수값 체크 루틴 넣을것.
            
            -- SEQ MAX 생성
            SELECT NVL(MAX(SEQ_NO),0)+1
              INTO v_seq
              FROM SFA_OFFICE_MEDIDICT;
              
            IF v_dict_cd < 1000000000 THEN
                v_dict_cd := 1000000001;
            END IF;
              
            -- 의학용어 등록
            INSERT INTO SFA_OFFICE_MEDIDICT(SEQ_NO,    DICT_HANGUL,    DICT_ENG,     DICT_DESC,    DICT_CODE) 
                                      VALUES(v_seq,     in_DICT_HANGUL, in_DICT_ENG,  in_DICT_DESC, in_DICT_CODE) ;
            
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT SEQ_NO                AS out_SEQ_NO
                 , DICT_HANGUL           AS out_DICT_HANGUL
                 , DICT_ENG              AS out_DICT_ENG
                 , DICT_DESC             AS out_DICT_DESC
                 , DICT_CODE             AS out_DICT_CODE  
                FROM SFA_OFFICE_MEDIDICT
             WHERE SEQ_NO      =    v_seq;
             
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '의학용어 등록이 완료되었습니다';
        END IF;
    ELSIF in_BTN_GUBUN = 2 THEN -- 수정버튼 클릭한 경우
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_OFFICE_MEDIDICT
         WHERE SEQ_NO      =    in_SEQ_NO;

        out_COUNT := v_num;
        IF v_num < 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 용어가 없습니다';
        ELSE
            UPDATE SFA_OFFICE_MEDIDICT
               SET DICT_HANGUL =    in_DICT_HANGUL
                 , DICT_ENG    =    in_DICT_ENG
                 , DICT_DESC   =    in_DICT_DESC
--                 , DICT_CODE   =    in_DICT_CODE
             WHERE SEQ_NO        =    in_SEQ_NO;
              
            COMMIT;

            OPEN out_RESULT FOR
            SELECT SEQ_NO                AS out_SEQ_NO
                 , DICT_HANGUL           AS out_DICT_HANGUL
                 , DICT_ENG              AS out_DICT_ENG
                 , DICT_DESC             AS out_DICT_DESC
                 , DICT_CODE             AS out_DICT_CODE  
                FROM SFA_OFFICE_MEDIDICT
             WHERE SEQ_NO        =    in_SEQ_NO;
             
            out_CODE := 0;
            out_MSG := '수정이 완료되었습니다';
        END IF;
    ELSIF in_BTN_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_OFFICE_MEDIDICT
         WHERE SEQ_NO      =    in_SEQ_NO;
        
        out_COUNT := v_num;
        IF v_num < 1 THEN
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            DELETE FROM SFA_OFFICE_MEDIDICT
             WHERE SEQ_NO      =    in_SEQ_NO;
              
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT SEQ_NO                AS out_SEQ_NO
                 , DICT_HANGUL           AS out_DICT_HANGUL
                 , DICT_ENG              AS out_DICT_ENG
                 , DICT_DESC             AS out_DICT_DESC
                 , DICT_CODE             AS out_DICT_CODE  
                FROM SFA_OFFICE_MEDIDICT
             WHERE SEQ_NO      =    (SELECT MAX(SEQ_NO) FROM SFA_OFFICE_MEDIDICT);
             
            out_CODE := 0;
            out_MSG := '삭제가 완료되었습니다';
         END IF;
    ELSE   -- 조회처리
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_OFFICE_MEDIDICT
         WHERE DECODE(in_SEQ_NO, NULL, 1, SEQ_NO)      =    NVL(in_SEQ_NO, 1)
           AND DICT_HANGUL LIKE '%'||NVL(in_DICT_HANGUL, '%')||'%';

        out_COUNT := v_num;
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '정보가 존재하지 않습니다.';
        ELSIF (v_num >= 1) THEN
            out_CODE := 0;
            out_MSG := '정보 확인완료';    
             
            OPEN out_RESULT FOR
            SELECT SEQ_NO                AS out_SEQ_NO
                 , DICT_HANGUL           AS out_DICT_HANGUL
                 , DICT_ENG              AS out_DICT_ENG
                 , DICT_DESC             AS out_DICT_DESC
                 , DICT_CODE             AS out_DICT_CODE  
                FROM SFA_OFFICE_MEDIDICT
             WHERE DECODE(in_SEQ_NO, NULL, 1, SEQ_NO)     =    NVL(in_SEQ_NO, 1)
               AND DICT_HANGUL LIKE '%'||NVL(in_DICT_HANGUL, '%')||'%';
        END IF;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
