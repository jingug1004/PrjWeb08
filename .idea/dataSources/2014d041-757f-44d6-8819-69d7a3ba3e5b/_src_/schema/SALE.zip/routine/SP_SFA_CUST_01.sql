CREATE PROCEDURE      SP_SFA_CUST_01
(
    in_DEPT_CD           IN  VARCHAR2,    -- 부서코드
    in_SAWON_ID          IN  VARCHAR2,    -- 사원 ID
    in_CUST_NM           IN  VARCHAR2,    -- 거래처명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처검색
 호출프로그램 :customer.CustomerList       
 
  105버전으로 대체 
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_insa_sawon_id     VARCHAR2(7);
    v_insa_dept_cd      VARCHAR2(4);
    v_assgn_cd          VARCHAR2(5);
    
    DEPT_CD_NULL         EXCEPTION;
    SAWON_ID_NULL        EXCEPTION;
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_CUST_01','1',sysdate,'in_DEPT_CD:'||in_DEPT_CD||'/in_SAWON_ID:'||in_SAWON_ID||'/in_CUST_NM:'||in_CUST_NM);
--COMMIT;
    
    IF in_DEPT_CD IS NULL OR TRIM(in_DEPT_CD) = '' THEN
        RAISE DEPT_CD_NULL;
    END IF;
    
    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
        RAISE SAWON_ID_NULL;
    END IF;
     
    --로그인사원의 인사사번   
    select insa_sawon_id into v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID and gubun = 'Y';
    
    --로그인사원이 팀원인지,팀원이아닌 본부장,팀장인지 파악
    select assgn_cd into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
        
--인사기본테이블에서 총괄팀장 이면 한레벨 상위부서코드를 찾고 팀장이면 자기부서를 찾는다.
    if v_assgn_cd = '27020' then --총괄팀장
        select dept_cd
          into v_insa_dept_cd  
          from hr_co_depart_0 
         where use_yn = 'Y' and level = 2
       connect by dept_cd = prior up_dept_cd start with dept_cd = (select dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id);
                       
    elsif v_assgn_cd = '27027' or v_assgn_cd = '27030' then --팀장
        select dept_cd into v_insa_dept_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
    end if;
        
    DBMS_OUTPUT.PUT_LINE(' v_insa_dept_cd   '||v_insa_dept_cd);
    
    
    --검색건수
    --팀원이면 본인의 부서만찾고 ,본부장 또는 팀장이면 하위모든 사원의 부서를 찾는다.
    SELECT COUNT(*) 
      INTO v_num
    FROM (    
          SELECT *
            FROM (
                SELECT SFA_SALES_SEQ
                  FROM SFA_SALES_CODE
               WHERE ERP_SALES_CODE IN ( SELECT CUST_ID FROM SALE0003 WHERE SAWON_ID = in_SAWON_ID )
                   AND TRADE_NAME  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND CUST_STAT_GB IN ('01') --주문거래처
                UNION    
                 SELECT A.SFA_SALES_SEQ
                  FROM SFA_SALES_CODE_SAWON A
                      ,SFA_SALES_CODE B
                 WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                   AND A.EMP_NO LIKE  NVL(in_SAWON_ID, '%')
                   AND B.TRADE_NAME  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND A.REQ_GB  = '1'  --활동거래처
                   AND A.OK_STAT = '2'  --승인
                 )
           WHERE  v_assgn_cd = '27040' --팀원이면         
         UNION ALL
          SELECT *
            FROM (
                SELECT SFA_SALES_SEQ
                  FROM SFA_SALES_CODE
               WHERE ERP_SALES_CODE IN ( SELECT CUST_ID 
                                           FROM SALE0003 
                                          WHERE SAWON_ID in (select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                                              from sale0007 
                                                             where insa_sawon_id in (
                                                                                    select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                                     where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                                        connect by prior dept_cd = up_dept_cd
                                                                                                          start with dept_cd = v_insa_dept_cd)
                                                                                                            and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                                    )
                                                              and gubun = 'Y') -- 재직구분 ( Y - 재직 / N -퇴사)
                                       )
                   AND TRADE_NAME  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND CUST_STAT_GB IN ('01') --주문거래처
                UNION    
                 SELECT A.SFA_SALES_SEQ
                  FROM SFA_SALES_CODE_SAWON A
                      ,SFA_SALES_CODE B
                 WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                   AND A.EMP_NO LIKE  NVL(in_SAWON_ID, '%')
                   AND B.TRADE_NAME  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND A.REQ_GB  = '1'  --활동거래처
                   AND A.OK_STAT = '2'  --승인
                 )
           WHERE  v_assgn_cd <> '27040' --팀원아니면                    
          )
    ;    

    DBMS_OUTPUT.PUT_LINE('v_num'||TO_CHAR(v_num));
    
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT SFA_SALES_NO                          AS out_CUST_CD        -- 거래처코드
             , NVL(TRADE_NAME,' ')                   AS out_CUST_NM        -- 거래처명
             , NVL(MANAGER_NAME, ' ')                AS out_MANAGER_NM     -- 대표자명
             , ERP_SALES_CODE                        AS out_ERP_CD         -- ERP 코드
             , DECODE(CUST_STAT_GB , '01', 'Y', 'N') AS out_YN 
             , DECODE(CUST_STAT_GB , '01', '거래', '비거래') AS out_TRADE_NM 
             , '['||F_SFA_CODE_NM('CUST_STAT_GB',CUST_STAT_GB)||'-'||SUBSTR(F_SFA_CUST_SAWON_NM(in_SAWON_ID,SFA_SALES_SEQ),2)||'] '||NVL(COMPANY_ADDR1, ' ')               AS out_ADDR1          -- 주소
             , NVL(COMPANY_ADDR2, ' ')               AS out_ADDR2          -- 상세주소
          FROM SFA_SALES_CODE
        WHERE SFA_SALES_SEQ IN (  SELECT SFA_SALES_SEQ
                                    FROM (
                                        SELECT SFA_SALES_SEQ
                                          FROM SFA_SALES_CODE
                                       WHERE ERP_SALES_CODE IN ( SELECT CUST_ID FROM SALE0003 WHERE SAWON_ID = in_SAWON_ID )
                                           AND TRADE_NAME  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                                           AND CUST_STAT_GB IN ('01') --주문거래처
                                        UNION    
                                         SELECT A.SFA_SALES_SEQ
                                          FROM SFA_SALES_CODE_SAWON A
                                              ,SFA_SALES_CODE B
                                         WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                           AND A.EMP_NO LIKE  NVL(in_SAWON_ID, '%')
                                           AND B.TRADE_NAME  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                                           AND A.REQ_GB  = '1'  --활동거래처
                                           AND A.OK_STAT = '2'  --승인
                                         )
                                   WHERE  v_assgn_cd = '27040' --팀원이면                
                                 UNION ALL
                                  SELECT SFA_SALES_SEQ
                                    FROM (
                                        SELECT SFA_SALES_SEQ
                                          FROM SFA_SALES_CODE
                                       WHERE ERP_SALES_CODE IN ( SELECT CUST_ID 
                                                                   FROM SALE0003 
                                                                  WHERE SAWON_ID in (select sawon_id --본부장,팀장인경우 하위 모든 사원(영업사원테이블)
                                                                                      from sale0007 
                                                                                     where insa_sawon_id in (
                                                                                                            select emp_no from hr_hc_empbas_0 --본부장,팀장인경우 하위 모든 사원(인사사원테이블)
                                                                                                             where dept_cd in (  select dept_cd from hr_co_depart_0
                                                                                                                                connect by prior dept_cd = up_dept_cd
                                                                                                                                  start with dept_cd = v_insa_dept_cd)
                                                                                                                                    and ENGAG_DIV in ('70010','70030') --재직,휴직
                                                                                                            )
                                                                                      and gubun = 'Y') -- 재직구분 ( Y - 재직 / N -퇴사)
                                                               )
                                           AND TRADE_NAME  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                                           AND CUST_STAT_GB IN ('01') --주문거래처
                                        UNION    
                                         SELECT A.SFA_SALES_SEQ
                                          FROM SFA_SALES_CODE_SAWON A
                                              ,SFA_SALES_CODE B
                                         WHERE A.SFA_SALES_SEQ = B.SFA_SALES_SEQ
                                           AND A.EMP_NO LIKE  NVL(in_SAWON_ID, '%')
                                           AND B.TRADE_NAME  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                                           AND A.REQ_GB  = '1'  --활동거래처
                                           AND A.OK_STAT = '2'  --승인
                                         )
                                   WHERE  v_assgn_cd <> '27040' --팀원아니면                          
                                  )
         ORDER BY SUBSTR(F_SFA_CUST_SAWON_NM(in_SAWON_ID,SFA_SALES_SEQ),1,1),F_SFA_CODE_NM('CUST_STAT_GB',CUST_STAT_GB),TRADE_NAME;
    END IF;
    
EXCEPTION
WHEN DEPT_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '부서코드가 누락되었습니다.';
WHEN SAWON_ID_NULL THEN
   out_CODE := 102;
   out_MSG  := '사원 ID가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
