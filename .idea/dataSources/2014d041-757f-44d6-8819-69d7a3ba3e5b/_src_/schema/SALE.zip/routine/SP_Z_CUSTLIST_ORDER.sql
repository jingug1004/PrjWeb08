CREATE PROCEDURE      SP_Z_CUSTLIST_ORDER
(
    in_GUBUN             IN  NUMBER,    -- 1:코드, 2:거래처명
    in_ITEM              IN  VARCHAR2,  -- 거래처 코드/명
    in_DEPT_CD           IN  VARCHAR2,  -- 부서코드
    in_SAWON_ID          IN  VARCHAR2,  -- 사원코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 전체주문거래처   
 호출프로그램 :반품사유서등록 납품처검색   반품사유서조회 거래처,납품처검색 
         로그인 사버에 해당되는 거래처만 나옴 
          2018.01.18 KTA - 신규 
 ---------------------------------------------------------------------------*/    
    v_num               NUMBER; 
    v_assgn_cd          VARCHAR2(5);
    v_deptcode          VARCHAR2(4);  -- 로그인사원부서
    v_query_deptcode    VARCHAR2(4);  -- 조회부서
    v_adminloginyn      VARCHAR2(1);  -- admin 부서 로그인여부              
    
    v_cust_cd           VARCHAR2(7);  
    v_cust_nm           VARCHAR2(20);
    
    GUBUN_NULL           EXCEPTION;
BEGIN

    
    IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
        RAISE GUBUN_NULL;
    END IF;     
    
    --insert into SFA_SP_CALLED_HIST values ('SP_Z_CUSTLIST_ORDER','1',sysdate,'in_GUBUN'||in_GUBUN||' / in_ITEM:'||in_ITEM||'/in_DEPT_CD:'||in_DEPT_CD||'/in_SAWON_ID:'||in_SAWON_ID);
    --commit;
    
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    select classdiv,deptcode into v_assgn_cd,v_deptcode from ORAGMP.CMEMPM  where empcode = in_SAWON_ID;
    
    v_query_deptcode := v_deptcode;               
    -- 조회부서:: 로그인 직책에따라 상위부서를 찾거나 본인부서를 찾는다.
    if v_assgn_cd in ('27010','27018','27023','27025','27026')  then   -- 본부장 ,부본부장, 총괄이사, 총괄지점장, 선임지점장       지점장,팀장, 임시팀장('27027','27030','27035') 은 1레벨위로 안가야 함  
       select deptcode 
         into v_query_deptcode 
         from ORAGMP.CMDEPTM 
        where useyn = 'Y' and level = 2 connect by deptcode = prior predeptcode start with plantcode = '1000' and deptcode = v_deptcode;              
    end if; 
    
    if v_query_deptcode in ('0007','0004','0302','0114','0527') then 
       v_adminloginyn   := 'Y';
    else
       v_adminloginyn   := 'N';           
    end if;
    
  
    IF in_GUBUN = 1 THEN
       v_cust_cd := in_ITEM; 
    ELSE
       v_cust_nm := in_ITEM;
    END IF;
           
    SELECT count(*)
      INTO v_num
      FROM ( 
                SELECT a.custcode , a.custname ,a.ceoname, a.empcode  ,a.addr1||' '||a.addr2 addr 
                  FROM ORAGMP.CMCUSTM a
                 WHERE a.plantcode = '1000'
                   AND a.custdiv   = '2'  --매출거래처  
                   AND a.custcode  LIKE '%'||NVL(v_cust_cd,'%')||'%'
                   AND a.custname  LIKE '%'||NVL(v_cust_nm,'%')||'%'
                   AND a.empcode in (select empcode from ORAGMP.CMEMPM where v_assgn_cd <> '27040' and plantcode = '1000' 
                                        and deptcode in ( select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode)
                                      union
                                     select in_SAWON_ID from dual where v_assgn_cd = '27040'
                                    ) 
                   AND v_adminloginyn   = 'N' 
               UNION ALL
                SELECT a.custcode , a.custname ,a.ceoname, a.empcode  ,a.addr1||' '||a.addr2 addr 
                  FROM ORAGMP.CMCUSTM a
                 WHERE a.plantcode = '1000'
                   AND a.custdiv   = '2'  --매출거래처  
                   AND a.custcode  LIKE '%'||NVL(v_cust_cd,'%')||'%'
                   AND a.custname  LIKE '%'||NVL(v_cust_nm,'%')||'%' 
                   AND v_adminloginyn   = 'Y'                                         
             );
     
                 
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
        
        if v_num > 1000 then           
           out_CODE := 1;
           out_MSG := '검색건수가 1000건이 넘습니다. 거래처명을 2자이상 조건으로 입력해주세요';
           return;
        end if;
         
        OPEN out_RESULT FOR 
        
        SELECT custcode                                                 AS out_CUST_CD    -- 거래처코드
              ,oragmp.fncommonnm ('cust',custcode,'')                   AS out_CUST_NM    -- 거래처명
              ,addr                                                     AS out_ADDRESS    -- 거래처 주소
              ,ceoname                                                  AS out_MANAGER_NM -- 대표자 명                
              ,oragmp.fngetturncnt(custcode,to_char(sysdate,'yyyy-mm')) AS out_PURCHASE_NM    -- 회전일  
              ,empcode                                                  AS out_EMP_NO     -- 담당사원 ID
              ,oragmp.fncommonnm ('emp',empcode,'')                     AS out_EMP_NM      -- 담당사원명   
         FROM ( 
                SELECT a.custcode , a.custname ,a.ceoname, a.empcode  ,a.addr1||' '||a.addr2 addr 
                  FROM ORAGMP.CMCUSTM a
                 WHERE a.plantcode = '1000'
                   AND a.custdiv   = '2'  --매출거래처  
                   AND a.custcode  LIKE '%'||NVL(v_cust_cd,'%')||'%'
                   AND a.custname  LIKE '%'||NVL(v_cust_nm,'%')||'%'
                   AND a.empcode in (select empcode from ORAGMP.CMEMPM where v_assgn_cd <> '27040' and plantcode = '1000' 
                                        and deptcode in ( select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode)
                                      union
                                     select in_SAWON_ID from dual where v_assgn_cd = '27040'
                                    ) 
                   AND v_adminloginyn   = 'N' 
               UNION ALL
                SELECT a.custcode , a.custname ,a.ceoname, a.empcode  ,a.addr1||' '||a.addr2 addr 
                  FROM ORAGMP.CMCUSTM a
                 WHERE a.plantcode = '1000'
                   AND a.custdiv   = '2'  --매출거래처  
                   AND a.custcode  LIKE '%'||NVL(v_cust_cd,'%')||'%'
                   AND a.custname  LIKE '%'||NVL(v_cust_nm,'%')||'%' 
                   AND v_adminloginyn   = 'Y'    
             )  
         ;
    
    END IF;
    
EXCEPTION
WHEN GUBUN_NULL THEN
   out_CODE := 101;
   out_MSG  := '검색 구분코드가 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
