CREATE PROCEDURE      SP_SFA_COLLECT_MAX_105
(
    in_GUBUN             IN  VARCHAR2, -- 의미없는 값으로 1들어옴.
    in_CUST_ID           IN  VARCHAR2, 
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 수금전표번호채번
 호출프로그램 :105 버전다운후 지울것 
 ---------------------------------------------------------------------------*/    

    ll_max   NUMBER;
    ll_count NUMBER;
    v_SAWON_ID VARCHAR2(7);
    ERROR_EXCEPTION     EXCEPTION;
    
    
BEGIN 

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_MAX_105',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate,'in_CUST_ID:'||in_CUST_ID||'/in_GUBUN '||in_GUBUN );
--commit;


    IF in_CUST_ID IS NULL OR TRIM(in_CUST_ID) = '' THEN
        out_COUNT := 0;
        out_CODE := 1;
        out_MSG := '<거래처를 반드시 선택해야 합니다.>'; 
        RAISE ERROR_EXCEPTION;
    END IF;
    
   -- 담당사원  ID 가져오기
   -- 이곳에서 v_SAWON_ID 는 사용하지 않지만 카드수금요청후에 ERP에 저장시에 이 SQL 문이 존재하므로 
   -- 카드결제가 이루어진 후 이체크가 문제가 되어 수금내역저장이 실패할수 있기때문에 미리 체크함.
    BEGIN
        select  sawon_id 
        into v_SAWON_ID
        from sale.sale0003
        where cust_id = in_CUST_ID ; 
        IF v_SAWON_ID IS NULL OR TRIM(v_SAWON_ID) = ''  THEN
            out_CODE := SQLCODE;
            out_MSG  := '<이거래처로 담당자가 지정되어 있지 않습니다.관리부로 연락하십시오. >';
            RAISE ERROR_EXCEPTION;           
        END IF;
    
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '<이거래처로 담당자가 지정되어 있지 않습니다.관리부로 연락하십시오. >';
        RAISE ERROR_EXCEPTION;
    END;      

   --중지거래처  통제(다른거래처에 수금입력 오류방지)   
    SELECT COUNT(*) INTO ll_count  FROM SALE0003 WHERE CUST_ID = in_CUST_ID AND NVL(USE_YN,'Y') <> 'Y';
    IF ll_count > 0 THEN
        out_COUNT := 0;
        out_CODE := 1;
        out_MSG := '<중지된 거래처입니다. 관리부로 연락하십시오.>'; 
        RAISE ERROR_EXCEPTION;
    END IF; 
     
    ll_max := 0;
    SP_SYS100C_MAX_VALUE('SALE0401', to_char(sysdate, 'yyyyMMdd'), null,null, null, null, ll_max );

    IF ll_max < 1 THEN
        out_COUNT := 0;
        out_CODE := 1;
        out_MSG := '전표번호 생성 오류'; 
    ELSE
        out_COUNT := 1;
        out_CODE := 0;
        out_MSG := '전표번호 생성완료'; 
    
        OPEN out_RESULT FOR
        SELECT to_char(sysdate, 'yyyyMMdd') || Lpad(to_char(ll_max),4,'0')  AS out_JUNPYO_NO
              ,in_CUST_ID AS out_CUST_ID
          FROM dual;
        DBMS_OUTPUT.PUT_LINE('---------------------------------  ll_max'||ll_max);
    END IF;
    
EXCEPTION
WHEN ERROR_EXCEPTION THEN
   out_CODE := 1;
   ROLLBACK;
WHEN OTHERS THEN 
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
