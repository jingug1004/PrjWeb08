CREATE FUNCTION      F_PART_GROUPING  
(
    in_DEPT_CD  IN  VARCHAR2
) 
RETURN VARCHAR2 IS

        V_CNT NUMBER;
        V_RETRUN VARCHAR2(100);
        V_DEPT_CD HANAHR.HR_CO_DEPART_0.DEPT_CD%TYPE; --인사의 부서코드
        V_DEPT_KO_NM HANAHR.HR_CO_DEPART_0.DEPT_KO_NM%TYPE; --인사의 부서명    
        V_UP_DEPT_CD HANAHR.HR_CO_DEPART_0.UP_DEPT_CD%TYPE; --인사의 부서코드 조회 -> CONNECT BY 를 위해서
       
BEGIN

        /* CHOE 20170131
        파트안에서 다시 그룹을 할때 사용한다. 
        2017.01.30 기획실 요청으로 종병에 대해서만 진행한다. 
        인사 부서의 정보를 이용하도록 하였다        
        */
        V_CNT := 0;
        SELECT COUNT(*)
        INTO V_CNT
        FROM SALE0008
        WHERE DEPT_CD = in_DEPT_CD
        ;
        
        IF V_CNT = 0 THEN
               V_RETRUN := '';  --없음 찾을 수 없음 
        ELSIF V_CNT = 1 THEN
        
                /*인사관리 부서에 영업부서 코드 매칭이 되어 있어야 한다.*/
                V_CNT := 0;
                SELECT COUNT(*)
                INTO V_CNT
                FROM HANAHR.HR_CO_DEPART_0
                WHERE SALE_DEPT_CD = in_DEPT_CD
                AND USE_YN = 'Y'
                ;
                
                IF V_CNT  = 0 THEN
                        V_RETRUN := '';  --없음 찾을 수 없음 
                ELSIF V_CNT  = 1 THEN
                
                        /*현재 부서의 정보를 찾는다.*/
                        V_DEPT_CD := '';
                        V_DEPT_KO_NM := '';
                        V_UP_DEPT_CD := '';
                        SELECT DEPT_CD ,DEPT_KO_NM ,UP_DEPT_CD
                        INTO V_DEPT_CD ,V_DEPT_KO_NM ,V_UP_DEPT_CD
                        FROM HANAHR.HR_CO_DEPART_0
                        WHERE SALE_DEPT_CD = in_DEPT_CD
                        AND USE_YN = 'Y'
                        ;
                        
                        /*상위 부서의 정보를 찾는다.*/
                        IF V_UP_DEPT_CD = '' THEN
                                V_RETRUN := '';  --없음 찾을 수 없음 
                        ELSE
                                SELECT DEPT_KO_NM
                                INTO V_RETRUN
                                FROM HANAHR.HR_CO_DEPART_0
                                WHERE DEPT_CD = V_UP_DEPT_CD
                                AND USE_YN = 'Y'
                                ;
                        END IF;
                        
                        /*SELECT A.DEPT_CD
                        FROM HR_CO_DEPART_0 A
                        WHERE A.USE_YN = 'Y' 
                        CONNECT BY PRIOR A.DEPT_CD = A.UP_DEPT_CD
                        START WITH A.DEPT_CD = V_UP_DEPT_CD
                        ;*/
                        
                ELSE
                        V_RETRUN := '';  --2개 이상 찾을 수 없음
                END IF;                        
        ELSE
                V_RETRUN := '';  --2개 이상 찾을 수 없음
        END IF;    
       
        RETURN V_RETRUN;    
EXCEPTION
        WHEN NO_DATA_FOUND THEN
        RETURN '';
END;
/
