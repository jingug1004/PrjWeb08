CREATE PROCEDURE      SP_Z_VISIT_04_115
(
    in_PROCESS           IN  VARCHAR2,    --2.신규등록,3- 출,퇴,경 입력 4. 삭제
    in_SALES_PLAN_NO     IN  VARCHAR2,    -- 방문날짜
    in_SAWON_ID          IN  VARCHAR2,    -- 사원 IDF
    in_DETAIL_PLAN_NO    IN  NUMBER,      -- 방문순번
    in_DEPT_NO           IN  VARCHAR2,    -- 부서코드
    in_SFA_SALES_SEQ     IN  VARCHAR2,    -- SFA거래처KEY컬럼 hiracode
    in_SFA_CLIENT_NO     IN  NUMBER,      -- 거래처별 고객 순번
    in_DESCRIPTION       IN  VARCHAR2,    -- 방문목적
    in_VISIT_KIND        IN  VARCHAR2,    -- 방문종류(0-계획방법,1-추가방문,2-출퇴경유)
    in_GPS_NUM1          IN  VARCHAR2, 
    in_GPS_NUM2          IN  VARCHAR2,
    in_CALL_ADDR         IN  VARCHAR2,   --CHOE 2012114 call 주소 저장
    in_FAKEGPS_YN        IN  VARCHAR2,   --위치속이는 프로그램설치유무
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 
/*---------------------------------------------------------------------------
프로그램명   :방문계획등록
호출프로그램 : bizVisitPlanReg  - 방문추가등록 팝업 

 
수정내역     - 팀장이 승인하면 자동승인되도록 처리함-팀장의 승인을 본부장 또는 총괄팀장이 하는 관계로... 
        이주의 방문계획은 전주에 모두 세우도록 클라이언트에서 처리하여 이곳에 있는 채크들은 막음.
      - 1.1.3버전:2013.03.06 kta
       :회사에서 규제하는 앱이 설치되어 있는지 채크한다.(예를 들면 fakegps같은)
        채크할 앱이름을 공통코드에(code_gb='0069') 넣고 로그인시 sfa에 공통변수에 저장하여 일과시작처리시 채크시 존재유무 들어옴)    
      - 2015.01.14 kta 특정 사원의 경우 경유지 횟수 체크하지 않는다.
      - 2015.01.14 kta 특정 사원의 경우 경유지 1km미터 체크하지 않는다.
      - 2016.11.09 CHOE 방문계획 3달 까지만 가능
      - 2016.12.07 CHOE 방문계획 F_DAY_OF_WEEK 함수 처리
     2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
---------------------------------------------------------------------------*/    
        v_num                NUMBER;
        v_plan_no            NUMBER;
        v_PLAN_DT            VARCHAR2(8); --방문날짜:새벽일과종료 때문에 필요 
        v_CALL_DTM           VARCHAR2(14); --콜시간:새벽일과종료 때문에 필요 
        V_ASSGN_CD           VARCHAR2(5); --팀장여부 
        V_APPLY_YN           VARCHAR2(1); --승인여부 : 팀장계획은 자동승인처리하기 위함.
            
        v_pre_gps_num1       NUMBER; --직전 콜이 경유지일때 좌표위도 
        v_pre_gps_num2       NUMBER; --직전 콜이 경유지일때 좌표경도
        v_distince           NUMBER; --직전콜과의직선거리 
        v_hiracode           VARCHAR2(7); --hiracode
    
        V_ADD_3MONTH VARCHAR2(8); --CHOE 20161109 방문계획 3달까지만 가능 비교 
        V_ADD_3MONTH_YN VARCHAR2(8); --CHOE 20161109 Y 등록 가능 N 등록 불가
        
        V_DAY_OF_WEEK VARCHAR2(8); --CHOE 20161207 F_DAY_OF_WEEK 함수 리턴
    
        PROCESS_NULL         EXCEPTION;
        SAWON_ID_NULL        EXCEPTION;
        HIRACODE_NULL        EXCEPTION;
        SFA_CLIENT_NO_NULL   EXCEPTION;
        DESCRIPTION_NULL     EXCEPTION;
        ERROR_EXCEPTION      EXCEPTION;
        
BEGIN

        IF in_PROCESS IS NULL OR TRIM(in_PROCESS) = '' THEN
            RAISE PROCESS_NULL;
        END IF;
        IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
            RAISE SAWON_ID_NULL;
        END IF;  
        IF in_SFA_SALES_SEQ IS NULL OR in_SFA_SALES_SEQ = ''  THEN
            RAISE HIRACODE_NULL;
        END IF;  
      
        out_CODE := 1;
        out_MSG := '조회한 내역이 존재하지 않습니다.';


        SELECT NVL(MAX(DETAIL_PLAN_NO+1),0)
        INTO v_plan_no
        FROM SFA_VISIT_PLANACT
        WHERE SALES_PLAN_NO = in_SALES_PLAN_NO 
        ;
        IF v_plan_no IS NULL OR v_plan_no = 0 THEN
                v_plan_no := 1;
        END IF;
           
        --일과종료시간때문에 ..
        v_PLAN_DT  := in_SALES_PLAN_NO;         
        v_CALL_DTM := to_char(SYSDATE,'YYYYMMDDHH24MISS');
       
       -- 방문계획등록
        IF in_PROCESS = '2' THEN    
    
                IF in_SFA_CLIENT_NO IS NULL OR in_SFA_CLIENT_NO = 0 THEN
                        RAISE SFA_CLIENT_NO_NULL;
                END IF;  
        
        
                --중복계획체크
                v_num := 0;
                select count(*) into v_num from SFA_VISIT_PLANACT
                 where sales_plan_no = in_SALES_PLAN_NO
                   and emp_no        = in_SAWON_ID
                   and hiracode      = in_SFA_SALES_SEQ
                   and sfa_client_no = in_SFA_CLIENT_NO;
                if v_num > 0 then
                   out_MSG := '동일거래처에 동일고객이 이미 등록되어 있습니다.';
                   RAISE ERROR_EXCEPTION;           
                end if;
        
        
                --계획방법으로 등록하는 경우 당일의 방문계획은 시간체크
                --이 부분로직은 방문계획은 한주 전에 세워야 한다는 규정에 의해 막음. 클라이언트화면에서 수정된 로직처리.
                --CHOE 20161207 방문 계획을 세울 수 없는 경우 확인
                IF in_VISIT_KIND = '0' THEN  
                        V_DAY_OF_WEEK := '0';
                        V_DAY_OF_WEEK := F_DAY_OF_WEEK(in_SALES_PLAN_NO);
                        IF V_DAY_OF_WEEK = '1' THEN  
                                out_MSG := '당일 방문 계획은 등록 할 수 없습니다. 방문 추가만 가능합니다.';  
                                RAISE ERROR_EXCEPTION;
                        ELSIF V_DAY_OF_WEEK = '2' THEN      
                                out_MSG := '지난 방문 계획은 등록 할 수 없습니다.'; --소스코드에서 먼저 잡음
                                RAISE ERROR_EXCEPTION;
                        ELSIF V_DAY_OF_WEEK = '3' THEN      
                                out_MSG := '이번 주 방문 계획은 월요일 오전 09시 이전에 등록 할 수 있습니다.';
                                RAISE ERROR_EXCEPTION;
                        ELSIF V_DAY_OF_WEEK = '4' THEN      
                                out_MSG := '이번 주 방문 계획은 등록 할 수 없습니다.';
                                RAISE ERROR_EXCEPTION;
                        --ELSE
                        END IF;
                END IF;

                --계획방문의 건수는 하루 25개 이하로 한다.
                v_num := 0;
                SELECT COUNT(*)
                  INTO v_num
                  FROM SFA_VISIT_PLANACT
                 WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
                   AND EMP_NO        = in_SAWON_ID
                   AND VISIT_KIND    = '0'  --방문종류(0-계획방법,1-추가방문,2-출퇴경유)
                ; 
                IF v_num > 25 THEN
                   out_MSG := '방문계획은 하루에 25 개 까지만 가능합니다_방문계획등록.';
                   RAISE ERROR_EXCEPTION;
                END IF;        
          
        
                --방문종류가 추가방문인 경우 하루 3번까지만 허용한다.
                v_num := 0;
                SELECT COUNT(*)
                  INTO v_num
                  FROM SFA_VISIT_PLANACT
                 WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
                   AND EMP_NO        = in_SAWON_ID
                   AND VISIT_KIND    = '1'  --방문종류(0-계획방법,1-추가방문,2-출퇴경유)
                ;        
                IF v_num > 4 THEN
                   out_MSG := '추가방문은 하루에 5번까지만 가능합니다_방문 등록.';             
                   RAISE ERROR_EXCEPTION;
                END IF;        
        
        
                --CHOE 20161109 기획실 요청 방문계획은 3달이 넘어선 안된다.
                V_ADD_3MONTH := '';
                SELECT TO_CHAR(ADD_MONTHS(SYSDATE, 3) ,'YYYYMMDD')
                INTO V_ADD_3MONTH
                FROM DUAL
                ;            
                V_ADD_3MONTH_YN := 'Y';
                SELECT CASE WHEN TO_DATE(V_ADD_3MONTH ,'YYYYMMDD' ) < TO_DATE(in_SALES_PLAN_NO, 'YYYYMMDD') THEN 'N'
                        ELSE 'Y'
                         END YN
                INTO V_ADD_3MONTH_YN
                FROM DUAL
                ;                        
                IF V_ADD_3MONTH_YN = 'N' THEN
                        out_MSG := '오늘로 부터 3달 이후의 방문계획은 세울 수 업습니다.';             
                        RAISE ERROR_EXCEPTION;
                END IF;
                    
        
                --자동승인처리한다 
                V_APPLY_YN := 'Y';  
                
                -- 방문계획등록
                INSERT INTO  SFA_VISIT_PLANACT (
                        SALES_PLAN_NO, EMP_NO       ,DETAIL_PLAN_NO ,DEPT_NO         ,SFA_SALES_SEQ    ,
                        SFA_CLIENT_NO, DESCRIPTION  ,TOGETHER_YN    ,TOGETHER_EMP_NO ,APPLY_YN         ,
                        STATUS       , GPS_NUM1     ,GPS_NUM2       ,EMP_CALL_DTM    ,ACTIVITY_CODE    ,
                        ACTIVITY_DESC, MAIN_ITEM1   ,MAIN_ITEM2     ,       
                        MAIN_ITEM3   , VISIT        ,VISIT_KIND     ,
                        ACTIVITY_YN  , CALL_YN      ,CALL_ADDR      ,FAKEGPS_YN       ,hiracode,visit_client_dept 
                        ) 
                VALUES(
                        in_SALES_PLAN_NO, in_SAWON_ID,       v_plan_no,    in_DEPT_NO,         0,     
                        in_SFA_CLIENT_NO, in_DESCRIPTION,    'N',          '',                V_APPLY_YN, 
                        '00',            '',                '',           '',                '',
                        '',              '',            '',                 
                        '',              'N',       in_VISIT_KIND,
                        'N',             'N',       in_CALL_ADDR,in_FAKEGPS_YN  ,in_SFA_SALES_SEQ
                        ,(select client_dept from sfa_hira_customer where hiracode = in_SFA_SALES_SEQ and sfa_client_no = in_SFA_CLIENT_NO)
                 );
                               
                -- SFA_VISIT_PLAN 은 날자/사원별 존재한다.
                out_CODE := 0;
                out_MSG := '요청하신 작업이 처리되었습니다_방문 등록.';  
             
        
        --일과시작,일과종료,경유를 처리한다.    
        ELSIF in_PROCESS = '3' THEN   -- 일과시작/경유/일과종료

                IF in_DESCRIPTION IS NULL OR TRIM(in_DESCRIPTION) = '' THEN
                            RAISE DESCRIPTION_NULL;
                END IF;          


                IF in_SFA_SALES_SEQ = '0000001' THEN  --일과시작지입력 
                        SELECT COUNT(*)
                        INTO v_num
                        FROM SFA_VISIT_PLANACT
                        WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
                        AND EMP_NO =in_SAWON_ID
                        --AND SFA_SALES_SEQ = 1
                        AND HIRACODE = '0000001'
                        ;
                        IF v_num > 0 THEN
                                out_MSG := '이미 일과시작 처리를 하였습니다_일과시작.';
                                RAISE ERROR_EXCEPTION;
                        END IF;
           

                        SELECT COUNT(*)
                        INTO v_num
                        FROM SFA_VISIT_PLANACT
                        WHERE SALES_PLAN_NO=in_SALES_PLAN_NO
                        AND EMP_NO =in_SAWON_ID
                        --AND SFA_SALES_SEQ = 3
                        AND HIRACODE = '0000003'
                        ; 
                        IF v_num > 0 THEN
                                out_MSG := '일과종료 처리되어 일과시작 처리를 할수 없습니다_일과시작.';
                                RAISE ERROR_EXCEPTION;
                        END IF;            
                  
                        out_CODE := 0;
                        out_MSG := '요청하신 작업이 처리되었습니다_일과시작.';        
                  
                ELSIF in_SFA_SALES_SEQ = '0000002' THEN  --경유지 처리 
        
                        v_num := 0;
                        SELECT COUNT(*)
                        INTO v_num
                        FROM SFA_VISIT_PLANACT
                        WHERE SALES_PLAN_NO=in_SALES_PLAN_NO
                        AND EMP_NO =in_SAWON_ID
                        --AND SFA_SALES_SEQ = 3
                        AND HIRACODE = '0000003'
                        ;
                        IF v_num > 0 THEN
                                out_MSG := '일과종료 처리되어 경유처리를 할수 없습니다_경유지.';
                                RAISE ERROR_EXCEPTION;
                        END IF;
                            
                        --1일 경유지는 3개까지만 처리가능
                        v_num := 0;
                        SELECT COUNT(*)
                        INTO v_num
                        FROM SFA_VISIT_PLANACT
                        WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
                        AND EMP_NO = in_SAWON_ID
                        --AND SFA_SALES_SEQ = 2
                        AND HIRACODE = '0000002'
                        ; 
            
                        --2015.01.14 kta 특정 사원의 경우 경유지 횟수 체크하지 않는다.
                        IF NOT (in_SAWON_ID = '2012060'   --김태안
                        OR in_SAWON_ID = '2010110'   --최순호
                        OR in_SAWON_ID = '2013142'   --운전기사
                        ) THEN 
                                IF v_num > 2 THEN
                                        out_MSG := '경유지처리는 하루에 3번까지만 가능합니다_경유지.';
                                        RAISE ERROR_EXCEPTION;
                                END IF;   
                        END IF; 
                
                        --이전콜이 경유지인경우 이전경유지와의 거리가 1000 미터 이내이면 불가처리
                        --오늘 본인의 콜중 바로전의 콜이  경유지일때 좌표를 가져온다.            
                        v_pre_gps_num1 := 0;
                        v_pre_gps_num2 := 0;
                        
                        BEGIN
                                SELECT  /*+ INDEX_DESC(A IDX_SFA_VISIT_PLANACT_01) */
                                GPS_NUM1,GPS_NUM2
                                INTO v_pre_gps_num1,v_pre_gps_num2
                                FROM SFA_VISIT_PLANACT A
                                WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
                                AND A.EMP_NO         = in_SAWON_ID
                                AND A.CALL_YN        = 'Y'
                                --AND A.SFA_SALES_SEQ  = 2 --경유
                                AND HIRACODE = '0000002'
                                AND A.EMP_CALL_DTM > ' '   --인덱스를 사용하려면 반드시 있어야 함.
                                AND ROWNUM = 1      --콜시간을 인덱스역순으로 잡았으므로 1개만 가져오면 최종콜한 시간임.                   
                                ;
                        EXCEPTION WHEN OTHERS THEN
                                v_pre_gps_num1 := 0;
                                v_pre_gps_num2 := 0;
                        END;
            

                        --2015.01.14 kta 특정 사원의 경우 경유지 1km미터 체크하지 않는다.
                        IF NOT (in_SAWON_ID = '2012060'   --김태안
                                OR in_SAWON_ID = '2010110'   --최순호 
                               ) THEN  
                                        
                                IF v_pre_gps_num1 > 0 THEN  
                                        --거리계산
                                        v_distince := F_SFA_DISTANCE(v_pre_gps_num1,v_pre_gps_num2,to_number(in_GPS_NUM1),to_number(in_GPS_NUM2)) * 1000;
                                        
                                       --거리가 1000 미터가 넘는지 확인
                                       IF v_distince < 1000 THEN
                                           out_CODE := 1;
                                           out_MSG  := '바로 이전 콜이 경유지이며 거리가 1KM 이내 이므로 경유지 등록은 불가합니다_경유지.';                              
                                           RETURN;
                                       END IF;
                                END IF; 
                                   
                        END IF;
                
                       out_CODE := 0;
                       out_MSG := '요청하신 작업이 처리되었습니다_경유지.';        

                ELSIF in_SFA_SALES_SEQ = '0000003' THEN  --일과종료처리 

                        --일과종료시간이 다음날 오전 6 시 이전인경우엔 방문일시를 전날짜23시59분59초 로 변경::밤샘업무후 새벽퇴근인경우임.
                        IF TO_CHAR(SYSDATE,'HH24') >= '00' AND TO_CHAR(SYSDATE,'HH24') < '06' THEN
                                   
                            SELECT TO_CHAR(TO_DATE(in_SALES_PLAN_NO,'YYYYMMDD') - 1,'YYYYMMDD') INTO v_PLAN_DT FROM DUAL; 
                            v_CALL_DTM := v_PLAN_DT||'235959';
                                      
                        ELSE
                          
                                SELECT COUNT(*)
                                INTO v_num
                                FROM SFA_VISIT_PLANACT
                                WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
                                AND EMP_NO = in_SAWON_ID
                                AND hiracode = '0000001'
                                ;
                                IF v_num = 0 THEN
                                   out_MSG := '일과시작이 없이 일과종료를 처리할 수 없습니다_일과종료.';
                                   RAISE ERROR_EXCEPTION;
                                END IF;
                        
                        
                                BEGIN
                                    --이전콜이 경유지인경우 일과종료콜 불가 
                                    v_hiracode := '';
                                    SELECT /*+ INDEX_DESC(A IDX_SFA_VISIT_PLANACT_01) */
                                           hiracode
                                    INTO v_hiracode
                                    FROM SFA_VISIT_PLANACT A
                                    WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
                                    AND EMP_NO  = in_SAWON_ID
                                    AND CALL_YN = 'Y'   
                                    AND EMP_CALL_DTM > ' '         
                                    AND ROWNUM = 1          
                                    ; 
                                EXCEPTION WHEN OTHERS THEN
                                    v_hiracode := '';
                                END;
                             
                                IF v_hiracode = '0000002' THEN  -- 경유지
                                   out_MSG := '일과종료콜 이전의 콜이 경유지인 경우 일과종료콜 처리를 할수 없습니다_일과종료.';
                                   RAISE ERROR_EXCEPTION;
                                END IF;
                                    
                                SELECT COUNT(*)
                                INTO v_num
                                FROM SFA_VISIT_PLANACT
                                WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
                                AND EMP_NO   = in_SAWON_ID
                                AND hiracode = '0000002';
                                IF v_num > 0 THEN
                                   out_MSG := '이미 일과종료 처리되었습니다_일과종료.';
                                   RAISE ERROR_EXCEPTION;
                                END IF;                
                                  
                        
                                v_PLAN_DT  := in_SALES_PLAN_NO;
                                v_CALL_DTM := to_char(SYSDATE,'YYYYMMDDHH24MISS');
                        
                        END IF;  
            
            
                        out_CODE := 0;
                        out_MSG := '요청하신 작업이 처리되었습니다_일과종료.';        
            
                END IF;       
       
                -- 방문계획등록
                INSERT INTO  SFA_VISIT_PLANACT a (
                        SALES_PLAN_NO,    EMP_NO,          DETAIL_PLAN_NO    ,DEPT_NO        ,   SFA_SALES_SEQ    ,
                        SFA_CLIENT_NO,    DESCRIPTION    ,    TOGETHER_YN    ,TOGETHER_EMP_NO,   APPLY_YN    ,
                        STATUS        ,   GPS_NUM1    ,    GPS_NUM2,       EMP_CALL_DTM    ,   ACTIVITY_CODE    ,
                        ACTIVITY_DESC,  MAIN_ITEM1    ,    MAIN_ITEM2    ,       
                        MAIN_ITEM3    ,VISIT        ,       VISIT_KIND    ,
                        ACTIVITY_YN    ,   CALL_YN  ,    CALL_ADDR ,FAKEGPS_YN,hiracode ,visit_client_dept)

                        VALUES(v_PLAN_DT , in_SAWON_ID,       v_plan_no,    in_DEPT_NO,         0,     
                        '',in_DESCRIPTION,    'N',          '',                '', 
                        '00',            in_GPS_NUM1,          in_GPS_NUM2,  v_CALL_DTM,                '',
                        '',              '',            '',                 
                        '',                 '',       in_VISIT_KIND,
                        '',              'Y',       in_CALL_ADDR ,in_FAKEGPS_YN,in_SFA_SALES_SEQ
                        ,(select client_dept from sfa_hira_customer where hiracode = in_SFA_SALES_SEQ and sfa_client_no = in_SFA_CLIENT_NO)
                );
              
              
        ELSIF in_PROCESS = '4' THEN   -- 삭제한다.
                -- 오늘날자것만 삭제한다.
                out_CODE := 0;
                out_MSG := '요청하신 작업이 처리되었습니다_삭제.';   
                    
                --    DELETE FROM SFA_VISIT_PLANACT
                --     WHERE SALES_PLAN_NO = in_CDT
                --       AND DETAIL_PLAN_NO= in_DETAIL_PLAN_NO
                --       AND EMP_NO = in_SAWON_ID;
        END IF ;                           
     
    
        DBMS_OUTPUT.PUT_LINE('003--->in_PROCESS'||in_PROCESS );
    
EXCEPTION
        WHEN PROCESS_NULL THEN
                out_CODE := 101;
                out_MSG := '구분코드가 누락되었습니다.'; 
        WHEN SAWON_ID_NULL THEN
                out_CODE := 102;
                out_MSG := '사원 ID가 누락되었습니다.'; 
        WHEN HIRACODE_NULL THEN
                out_CODE := 103;
                out_MSG := '거래처가 누락되었습니다.'; 
        WHEN SFA_CLIENT_NO_NULL THEN
                out_CODE := 104;
                out_MSG := '고객이 누락되었습니다.';  
        WHEN DESCRIPTION_NULL THEN
                out_CODE := 105;
                out_MSG := '비고가 누락되었습니다.';
        WHEN ERROR_EXCEPTION THEN
                out_CODE := 1;
        WHEN OTHERS THEN
                out_CODE := SQLCODE;
                out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                DBMS_OUTPUT.PUT_LINE('003--->out_MSG'||out_MSG );
END;
/
