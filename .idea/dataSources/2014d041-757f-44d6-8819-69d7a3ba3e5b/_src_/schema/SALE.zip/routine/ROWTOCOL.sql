CREATE FUNCTION rowtocol( p_slct IN VARCHAR2, p_dlmtr IN VARCHAR2 DEFAULT ',' ) RETURN VARCHAR2 
      AUTHID CURRENT_USER AS
     /*
      1) Column should be character type.
      2) If it is non-character type, column has to be converted into character type. 
      3) If the returned rows should in a specified order, put that ORDER BY CLASS in the SELECT statement argument.
      4) If the SQL statement happened to return duplicate values, and if you don't want that to happen, put DISTINCT in the SELECT statement argument.
     */
     TYPE c_refcur IS REF CURSOR;
     lc_str VARCHAR2(4000);
     lc_colval VARCHAR2(4000);
     c_dummy c_refcur;
     l number;

     BEGIN
     OPEN c_dummy FOR p_slct;
       LOOP
         FETCH c_dummy INTO lc_colval;
         EXIT WHEN c_dummy%NOTFOUND;
         lc_str := lc_str || p_dlmtr || lc_colval;
       END LOOP;
     CLOSE c_dummy;

     RETURN SUBSTR(lc_str,2);

     EXCEPTION 
       WHEN OTHERS THEN
         lc_str := SQLERRM;
         IF c_dummy%ISOPEN THEN
     CLOSE c_dummy;
     END IF;
     RETURN lc_str;

     END;
/
