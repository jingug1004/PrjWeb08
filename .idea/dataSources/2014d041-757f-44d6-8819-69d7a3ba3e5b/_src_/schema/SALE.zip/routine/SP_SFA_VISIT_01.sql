CREATE PROCEDURE      SP_SFA_VISIT_01
(
    in_PROCESS_TYPE      IN  VARCHAR2,     -- 1:일일방문, 2:방문승인,3:사번,날짜,순번으로 1건조회,4:계획복사를 위한 조회
    in_SALES_PLAN_NO     IN  VARCHAR2,     -- 방문일자 Key
    in_EMP_NO            IN  VARCHAR2,     -- 담당자 사번
    in_DETAIL_PLAN_NO    IN  VARCHAR2,     -- 방문순번 
    in_DT                IN  VARCHAR2,     -- 기준일자
    in_DEPT_CD           IN  VARCHAR2,     -- 소속부서 방문승인에서 사용
    in_GUBUN             IN  VARCHAR2,     -- 방문승인에서 사용 조회 기준
     
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 일일방문리스트 105버전으로대체 
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
BEGIN


    IF in_PROCESS_TYPE = '1' THEN 
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_VISIT_PLANACT 
         WHERE EMP_NO         LIKE  NVL(in_EMP_NO, '%')
           AND SALES_PLAN_NO = in_DT
         order by SALES_PLAN_NO ;
       
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
         
            OPEN out_RESULT FOR
            SELECT 
                   A.SFA_SALES_SEQ                               AS out_CUST_KEY,       -- 거래처코드Key
                   F_CUST_NM_KEY('CODE',A.SFA_SALES_SEQ)         AS out_CUST_CD,        -- 거래처코드
                   F_CUST_NM_KEY('NAME',A.SFA_SALES_SEQ)         AS out_CUST_NM,        -- 거래처명
                   A.SFA_CLIENT_NO                               AS out_CLIENT_NO,      -- 고객코드
                   F_CLIENT_NM(A.SFA_SALES_SEQ, A.SFA_CLIENT_NO) AS out_CLIENT_NM,      -- 고객명
                   A.DETAIL_PLAN_NO                              AS out_DETAIL_PLAN_NO, -- 방문순번
                   A.DEPT_NO                                     AS out_DEPT,           -- 사번의부서 <- 소속(전문과)
                  
                  case 
                    when (A.VISIT_KIND = '2')  then A.DESCRIPTION --경유지일경우 비고를 방문결과에 
                    when (A.APPLY_YN = 'N' and A.CALL_YN ='Y' and A.VISIT ='Y')     then '방문완료'     -- 추가방문
                    when (A.APPLY_YN = 'N' and A.CALL_YN ='Y')                      then 'Call 완료'    -- 추가방문
                    when (A.APPLY_YN = 'N')                                         then 'Call 대기'    -- 일반 및 추가방문
                    
                    when (A.APPLY_YN = 'Y' and A.CALL_YN ='Y' and A.VISIT ='Y')     then '방문완료' 
                    when (A.APPLY_YN = 'Y' and A.CALL_YN ='Y')                      then 'Call 완료' 
                    when (A.APPLY_YN = 'Y')                                         then 'Call 대기' 
                    
                    else '' end as out_VISIT_STATUS,
                  
                   A.CALL_YN  as out_CALL_YN,  --CALL 여부 
                   A.APPLY_YN as out_APPLY_YN,  -- 승인여부
                   case 
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'N')     then '대기'  -- 계획승인대기
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'Y')     then '승인'  -- 방문계획승인
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'R')     then '반려'  -- 방문계획반려
                    
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'N')     then '대기'  -- 추가승인대기
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'Y')     then '승인'  -- 추가방문승인
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'R')     then '반려'  -- 추가방문반려
                    
                    else '' end as out_APPLY_NM,                                    -- 승인여부
                   
                   
                   A.TOGETHER_YN                            AS out_TOGETHER_YN,     -- 동행여부
                   A.SALES_PLAN_NO                          AS out_SALES_PLAN_NO,   -- 방문일자
                   A.VISIT                                  AS out_VISIT,           --방문완료여부 Y/N
                   A.DESCRIPTION                            AS out_DESCRIPTION,     -- 방문목적
                   A.REJECT_DESC                            AS out_REJECT_DESC,     -- 반려사유
                   A.VISIT_KIND                             AS out_VISIT_KIND,      -- 방문유형
                   F_SFA_CODE_NM('VISIT_KIND',A.VISIT_KIND) AS out_VISIT_KIND_NM,   -- 방문유형
                   A.EMP_NO                                 AS out_EMP_NO,          -- 방문자사번
                   F_SAWON_NM(A.EMP_NO)                     AS out_EMP_NM,          -- 방문자이름   
                   B.COMPANY_ADDR1                          AS out_CUST_ADDR,       -- 거래처주소
                   B.GPS_NUM1                               AS out_CUST_GPS_NUM1,   -- 거래처 경도
                   B.GPS_NUM2                               AS out_CUST_GPS_NUM2,   -- 거래처 위도
                   
                   A.ACTIVITY_CODE                          AS out_ACTIVITY_CODE,   -- 활동황목코드
                   A.ACTIVITY_DESC                          AS out_ACTIVITY_DESC,   -- 방문활동
                   A.MAIN_ITEM1                             AS out_ITEM1_CD,        -- 주품목명1
                   F_ITEM_NM(A.MAIN_ITEM1)                  AS out_MAIN_ITEM_DESC1, -- 주품목명1
                   A.MAIN_ITEM2                             AS out_ITEM2_CD,        -- 주품목명1
                   F_ITEM_NM(A.MAIN_ITEM2)                  AS out_MAIN_ITEM_DESC2, -- 주품목명2
                   ACTIVITY_YN                              AS out_ACTIVITY_YN,     -- 방문활동여부 Y/N
                   (select code2_nm from sale0001 where code_gb = '0064' and code1 = b.cust_kind ) AS out_CALL_DIST --CALL오차인정거리               
              FROM SFA_VISIT_PLANACT A 
                  ,SFA_SALES_CODE    B 
             WHERE A.SFA_SALES_SEQ  = B.SFA_SALES_SEQ(+)
               AND A.EMP_NO         LIKE  NVL(in_EMP_NO, '%')
               AND A.SALES_PLAN_NO  =     in_DT
             ORDER BY A.SALES_PLAN_NO, A.DETAIL_PLAN_NO;
        END IF;
    END IF;  

    IF in_PROCESS_TYPE = '2' THEN 
    

        SELECT COUNT(*)
          INTO v_num
          FROM SFA_VISIT_PLANACT 
         WHERE DEPT_NO  = in_DEPT_CD
           AND SALES_PLAN_NO = in_DT
           AND APPLY_YN LIKE NVL(in_GUBUN,'%')
         order by SALES_PLAN_NO ;
       
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
         
            OPEN out_RESULT FOR
            SELECT 
                   A.SFA_SALES_SEQ                         AS out_CUST_KEY,           -- 거래처코드Key
                   F_CUST_NM_KEY('CODE',A.SFA_SALES_SEQ)       AS out_CUST_CD,           -- 거래처코드
                   F_CUST_NM_KEY('NAME',A.SFA_SALES_SEQ)       AS out_CUST_NM,           -- 거래처명
                   A.SFA_CLIENT_NO                          AS out_CLIENT_NO,         -- 고객코드
                   F_CLIENT_NM(A.SFA_SALES_SEQ, A.SFA_CLIENT_NO)             AS out_CLIENT_NM,         -- 고객명
                   A.DETAIL_PLAN_NO                         AS out_DETAIL_PLAN_NO,    -- 방문순번
                   A.DEPT_NO                                AS out_DEPT,              -- 사번의부서 <- 소속(전문과)
                  
                  case 
                    when (A.APPLY_YN = 'N' and A.CALL_YN ='Y' and A.VISIT ='Y')     then '방문완료'     -- 추가방문
                    when (A.APPLY_YN = 'N' and A.CALL_YN ='Y')                      then 'Call 완료'    -- 추가방문
                    when (A.APPLY_YN = 'N')                                         then 'Call 대기'    -- 일반 및 추가방문
                    
                    when (A.APPLY_YN = 'Y' and A.CALL_YN ='Y' and A.VISIT ='Y')     then '방문완료' 
                    when (A.APPLY_YN = 'Y' and A.CALL_YN ='Y')                      then 'Call 완료' 
                    when (A.APPLY_YN = 'Y')                                         then 'Call 대기' 
                    
                    else '' end as out_VISIT_STATUS,
                  
                   A.CALL_YN  as out_CALL_YN,  --CALL 여부 
                   A.APPLY_YN as out_APPLY_YN,  -- 승인여부
                   case 
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'N')     then '대기'     -- 계획승인대기
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'Y')     then '승인'     -- 방문계획승인
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'R')     then '반려'     -- 방문계획반려
                    
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'N')     then '대기'     -- 추가승인대기
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'Y')     then '승인'     -- 추가방문승인
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'R')     then '반려'     -- 추가방문반려
                    
                    else '' end as out_APPLY_NM,                                    -- 승인여부
                   
                   
                   A.TOGETHER_YN                            AS out_TOGETHER_YN,   -- 동행여부
                   A.SALES_PLAN_NO                          AS out_SALES_PLAN_NO,   -- 방문일자
                   A.VISIT                                  AS out_VISIT,            --방문완료여부 Y/N
                   A.DESCRIPTION                            AS out_DESCRIPTION,   -- 방문목적
                   A.REJECT_DESC                            AS out_REJECT_DESC,      -- 반려사유
                   A.VISIT_KIND                             AS out_VISIT_KIND,       -- 방문유형
                   F_SFA_CODE_NM('VISIT_KIND',A.VISIT_KIND) AS out_VISIT_KIND_NM,       -- 방문유형
                   A.EMP_NO                                 AS out_EMP_NO,       -- 방문자사번
                   F_SAWON_NM(A.EMP_NO)                     AS out_EMP_NM,       -- 방문자이름   
                   B.COMPANY_ADDR1                          AS out_CUST_ADDR,           -- 거래처주소
                   B.GPS_NUM1                          AS out_CUST_GPS_NUM1,           -- 거래처 경도
                   B.GPS_NUM2                          AS out_CUST_GPS_NUM2,           -- 거래처 위도
                   
                   A.ACTIVITY_CODE                          AS out_ACTIVITY_CODE,  -- 활동황목코드
                   A.ACTIVITY_DESC                          AS out_ACTIVITY_DESC,     -- 방문활동
                   A.MAIN_ITEM1                             AS out_ITEM1_CD,   -- 주품목명1
                   F_ITEM_NM(A.MAIN_ITEM1)                  AS out_MAIN_ITEM_DESC1,   -- 주품목명1
                   A.MAIN_ITEM2                             AS out_ITEM2_CD,   -- 주품목명1
                   F_ITEM_NM(A.MAIN_ITEM2)                  AS out_MAIN_ITEM_DESC2,    -- 주품목명2
                   ACTIVITY_YN                  AS out_ACTIVITY_YN,    -- 방문활동여부 Y/N
                   '' AS out_CALL_DIST 
              FROM SFA_VISIT_PLANACT A 
                    LEFT OUTER JOIN SFA_SALES_CODE  B
              ON   A.SFA_SALES_SEQ  = B.SFA_SALES_SEQ
         WHERE A.DEPT_NO  = in_DEPT_CD
           AND A.SALES_PLAN_NO        = in_DT
         order by A.SALES_PLAN_NO, A.DETAIL_PLAN_NO;
        END IF;
    END IF; 

    -- 기본 키값으로 나온 1건의 데이타 보기
    IF in_PROCESS_TYPE = '3' THEN 
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_VISIT_PLANACT 
         WHERE EMP_NO         LIKE  NVL(in_EMP_NO, '%')
           AND SALES_PLAN_NO = in_SALES_PLAN_NO
           AND DETAIL_PLAN_NO = in_DETAIL_PLAN_NO
         order by SALES_PLAN_NO ;
       
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
         
            OPEN out_RESULT FOR
            SELECT 
                   A.SFA_SALES_SEQ                         AS out_CUST_KEY,           -- 거래처코드Key
                   F_CUST_NM_KEY('CODE',A.SFA_SALES_SEQ)       AS out_CUST_CD,           -- 거래처코드
                   F_CUST_NM_KEY('NAME',A.SFA_SALES_SEQ)       AS out_CUST_NM,           -- 거래처명
                   A.SFA_CLIENT_NO                          AS out_CLIENT_NO,         -- 고객코드
                   F_CLIENT_NM(A.SFA_SALES_SEQ, A.SFA_CLIENT_NO)             AS out_CLIENT_NM,         -- 고객명
                   A.DETAIL_PLAN_NO                         AS out_DETAIL_PLAN_NO,    -- 방문순번
                   A.DEPT_NO                                AS out_DEPT,              -- 사번의부서 <- 소속(전문과)
                  
                  case 
                    when (A.APPLY_YN = 'N' and A.CALL_YN ='Y' and A.VISIT ='Y')     then '방문완료'     -- 추가방문
                    when (A.APPLY_YN = 'N' and A.CALL_YN ='Y')                      then 'Call 완료'    -- 추가방문
                    when (A.APPLY_YN = 'N')                                         then 'Call 대기'    -- 일반 및 추가방문
                    
                    when (A.APPLY_YN = 'Y' and A.CALL_YN ='Y' and A.VISIT ='Y')     then '방문완료' 
                    when (A.APPLY_YN = 'Y' and A.CALL_YN ='Y')                      then 'Call 완료' 
                    when (A.APPLY_YN = 'Y')                                         then 'Call 대기' 
                    
                    else '' end as out_VISIT_STATUS,
                  
                   A.CALL_YN  as out_CALL_YN,  --CALL 여부 
                   A.APPLY_YN as out_APPLY_YN,  -- 승인여부
                   case 
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'N')     then '계획승인대기'     -- 계획승인대기
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'Y')     then '방문계획승인'     -- 방문계획승인
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'R')     then '방문계획반려'     -- 방문계획반려
                    
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'N')     then '추가승인대기'     -- 추가승인대기
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'Y')     then '추가방문승인'     -- 추가방문승인
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'R')     then '추가방문반려'     -- 추가방문반려
                    
                    else '' end as out_APPLY_NM,                                    -- 승인여부
                   
                   
                   A.TOGETHER_YN                            AS out_TOGETHER_YN,   -- 동행여부
                   A.SALES_PLAN_NO                          AS out_SALES_PLAN_NO,   -- 방문일자
                   A.VISIT                                  AS out_VISIT,            --방문완료여부 Y/N
                   A.DESCRIPTION                            AS out_DESCRIPTION,   -- 방문목적
                   A.REJECT_DESC                            AS out_REJECT_DESC,      -- 반려사유
                   A.VISIT_KIND                             AS out_VISIT_KIND,       -- 방문유형
                   F_SFA_CODE_NM('VISIT_KIND',A.VISIT_KIND) AS out_VISIT_KIND_NM,       -- 방문유형
                   A.EMP_NO                                 AS out_EMP_NO,       -- 방문자사번
                   F_SAWON_NM(A.EMP_NO)                     AS out_EMP_NM,       -- 방문자이름   
                   B.COMPANY_ADDR1                          AS out_CUST_ADDR,           -- 거래처주소
                   B.GPS_NUM1                          AS out_CUST_GPS_NUM1,           -- 거래처 경도
                   B.GPS_NUM2                          AS out_CUST_GPS_NUM2,           -- 거래처 위도
                   
                   A.ACTIVITY_CODE                          AS out_ACTIVITY_CODE,  -- 활동황목코드
                   A.ACTIVITY_DESC                          AS out_ACTIVITY_DESC,     -- 방문활동
                   A.MAIN_ITEM1                             AS out_ITEM1_CD,   -- 주품목명1
                   F_ITEM_NM(A.MAIN_ITEM1)                  AS out_MAIN_ITEM_DESC1,   -- 주품목명1
                   A.MAIN_ITEM2                             AS out_ITEM2_CD,   -- 주품목명1
                   F_ITEM_NM(A.MAIN_ITEM2)                  AS out_MAIN_ITEM_DESC2,    -- 주품목명2
                   ACTIVITY_YN                  AS out_ACTIVITY_YN,    -- 방문활동여부 Y/N
                   '' AS out_CALL_DIST 
              FROM SFA_VISIT_PLANACT A 
                    LEFT OUTER JOIN SFA_SALES_CODE  B
              ON   A.SFA_SALES_SEQ  = B.SFA_SALES_SEQ
              
         WHERE A.EMP_NO         LIKE  NVL(in_EMP_NO, '%')
           AND A.SALES_PLAN_NO        = in_SALES_PLAN_NO
           AND DETAIL_PLAN_NO = in_DETAIL_PLAN_NO
         order by A.SALES_PLAN_NO, A.DETAIL_PLAN_NO;
        END IF;
    END IF; 

    -- 계획복사화면의 조회 : 출근,퇴근 경유는 제외하고 조회
    IF in_PROCESS_TYPE = '4' THEN 
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_VISIT_PLANACT A              
         WHERE A.EMP_NO         = in_EMP_NO
           AND A.SALES_PLAN_NO  = in_DT  --계획일자
           AND A.VISIT_KIND = '0' --방문종류(0-계획방법,1-추가방문,2-출퇴경유)
         ;
       
        out_COUNT := v_num;
        IF v_num = 0 THEN
           out_CODE := 1;
           out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    
         
            OPEN out_RESULT FOR
            SELECT 
                   A.SFA_SALES_SEQ                         AS out_CUST_KEY,           -- 거래처코드Key
                   F_CUST_NM_KEY('CODE',A.SFA_SALES_SEQ)       AS out_CUST_CD,           -- 거래처코드
                   F_CUST_NM_KEY('NAME',A.SFA_SALES_SEQ)       AS out_CUST_NM,           -- 거래처명
                   A.SFA_CLIENT_NO                          AS out_CLIENT_NO,         -- 고객코드
                   F_CLIENT_NM(A.SFA_SALES_SEQ, A.SFA_CLIENT_NO)             AS out_CLIENT_NM,         -- 고객명
                   A.DETAIL_PLAN_NO                         AS out_DETAIL_PLAN_NO,    -- 방문순번
                   A.DEPT_NO                                AS out_DEPT,              -- 사번의부서 <- 소속(전문과)
                  
                  case 
                    when (A.APPLY_YN = 'N' and A.CALL_YN ='Y' and A.VISIT ='Y')     then '방문완료'     -- 추가방문
                    when (A.APPLY_YN = 'N' and A.CALL_YN ='Y')                      then 'Call 완료'    -- 추가방문
                    when (A.APPLY_YN = 'N')                                         then 'Call 대기'    -- 일반 및 추가방문
                    
                    when (A.APPLY_YN = 'Y' and A.CALL_YN ='Y' and A.VISIT ='Y')     then '방문완료' 
                    when (A.APPLY_YN = 'Y' and A.CALL_YN ='Y')                      then 'Call 완료' 
                    when (A.APPLY_YN = 'Y')                                         then 'Call 대기' 
                    
                    else '' end as out_VISIT_STATUS,
                  
                   A.CALL_YN  as out_CALL_YN,  --CALL 여부 
                   A.APPLY_YN as out_APPLY_YN,  -- 승인여부
                   case 
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'N')     then '계획승인대기'     -- 계획승인대기
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'Y')     then '방문계획승인'     -- 방문계획승인
                    when (A.VISIT_KIND = '0' and A.APPLY_YN = 'R')     then '방문계획반려'     -- 방문계획반려
                    
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'N')     then '추가승인대기'     -- 추가승인대기
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'Y')     then '추가방문승인'     -- 추가방문승인
                    when (A.VISIT_KIND = '1' and A.APPLY_YN = 'R')     then '추가방문반려'     -- 추가방문반려
                    
                    else '' end as out_APPLY_NM,                                    -- 승인여부
                   
                   
                   A.TOGETHER_YN                            AS out_TOGETHER_YN,   -- 동행여부
                   A.SALES_PLAN_NO                          AS out_SALES_PLAN_NO,   -- 방문일자
                   A.VISIT                                  AS out_VISIT,            --방문완료여부 Y/N
                   A.DESCRIPTION                            AS out_DESCRIPTION,   -- 방문목적
                   A.REJECT_DESC                            AS out_REJECT_DESC,      -- 반려사유
                   A.VISIT_KIND                             AS out_VISIT_KIND,       -- 방문유형
                   F_SFA_CODE_NM('VISIT_KIND',A.VISIT_KIND) AS out_VISIT_KIND_NM,       -- 방문유형
                   A.EMP_NO                                 AS out_EMP_NO,       -- 방문자사번
                   F_SAWON_NM(A.EMP_NO)                     AS out_EMP_NM,       -- 방문자이름   
                   B.COMPANY_ADDR1                          AS out_CUST_ADDR,           -- 거래처주소
                   B.GPS_NUM1                          AS out_CUST_GPS_NUM1,           -- 거래처 경도
                   B.GPS_NUM2                          AS out_CUST_GPS_NUM2,           -- 거래처 위도
                   
                   A.ACTIVITY_CODE                          AS out_ACTIVITY_CODE,  -- 활동황목코드
                   A.ACTIVITY_DESC                          AS out_ACTIVITY_DESC,     -- 방문활동
                   A.MAIN_ITEM1                             AS out_ITEM1_CD,   -- 주품목명1
                   F_ITEM_NM(A.MAIN_ITEM1)                  AS out_MAIN_ITEM_DESC1,   -- 주품목명1
                   A.MAIN_ITEM2                             AS out_ITEM2_CD,   -- 주품목명1
                   F_ITEM_NM(A.MAIN_ITEM2)                  AS out_MAIN_ITEM_DESC2,    -- 주품목명2
                   ACTIVITY_YN                  AS out_ACTIVITY_YN,    -- 방문활동여부 Y/N
                   '' AS out_CALL_DIST 
              FROM SFA_VISIT_PLANACT A 
                    LEFT OUTER JOIN SFA_SALES_CODE  B
              ON   A.SFA_SALES_SEQ  = B.SFA_SALES_SEQ              
         WHERE A.EMP_NO         = in_EMP_NO
           AND A.SALES_PLAN_NO  = in_DT  --계획일자
           AND A.VISIT_KIND = '0' --방문종류(0-계획방법,1-추가방문,2-출퇴경유)
         order by A.SALES_PLAN_NO, A.DETAIL_PLAN_NO;
        END IF;
    END IF; 
 
   
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
