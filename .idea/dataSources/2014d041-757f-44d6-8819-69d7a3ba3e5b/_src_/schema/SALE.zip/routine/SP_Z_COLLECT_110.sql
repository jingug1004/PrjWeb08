CREATE PROCEDURE      SP_Z_COLLECT_110
   (in_FLAG         IN VARCHAR2 DEFAULT NULL,
    in_YMD          IN date,
    in_JUNPYO_NO    IN VARCHAR2 DEFAULT NULL,
    in_CUST_ID      IN VARCHAR2 DEFAULT NULL, 
    in_RCUST_ID     IN VARCHAR2 DEFAULT NULL, 
    in_AMT          IN VARCHAR2 DEFAULT NULL, 
    in_SAWON_ID     IN VARCHAR2 DEFAULT NULL, 
    in_BIGO         IN VARCHAR2 DEFAULT NULL,
    in_BALHANG      IN VARCHAR2 DEFAULT NULL, 
    in_JIGEUB       IN VARCHAR2 DEFAULT NULL, 
    in_BILL_NO      IN VARCHAR2 DEFAULT NULL, 
    in_BILL_GB      IN VARCHAR2 DEFAULT NULL, --카드 수금은 100   수기카드 수금은 102
    in_GYULJAE_YMD  IN VARCHAR2 DEFAULT NULL,
    in_SIGN_IMAGE   IN VARCHAR2 DEFAULT NULL, --사인은 여기서 저장하지 않음. apachetomcat서버 측에서 직접 update함.
    in_PDA_RPRT     IN VARCHAR2 DEFAULT NULL,    
    in_CARD_COMP       IN VARCHAR2 DEFAULT NULL,  --카드사 
    in_CARD_NO         IN VARCHAR2 DEFAULT NULL,--카드번호
    in_CARD_USE_PERIOD IN VARCHAR2 DEFAULT NULL,--유효기간
    in_CARD_ACCEPT_NO  IN VARCHAR2 DEFAULT NULL,--승인번호
    in_CARD_BILL_GB    IN VARCHAR2 DEFAULT NULL,--카드거래종류(신용결재승인,신용결재취소)
    in_CARD_ALLOTMENT  IN VARCHAR2 DEFAULT NULL,--카드할부개월
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2,
    out_COUNT       OUT NUMBER,
    out_RESULT      OUT TYPES.CURSOR_TYPE  
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 카드수금 과 수기카드수금 
 호출프로그램 : 
 수정기록 : 
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    

    ll_count     number := 0;
    
    v_sawon_id     VARCHAR2(20);  --거래처담당사원                     
    v_dept_cd      VARCHAR2(4);   --거래처담당사원소속부서
    v_colno        VARCHAR2(100);  --수금전표번호  
    v_card_gb      VARCHAR2(100);  --카드수금 수기카드   
    v_auto_yn      VARCHAR2(1);  --카드수금='Y'  수기카드='N'
    v_cardcompcd   VARCHAR2(100);  --카드사코드  하나제약 카드사공통코드 와 매핑 
    v_cardcompcd2  VARCHAR2(100);  --카드사코드  하나제약 카드사공통코드 와 매핑2 
    v_cardcompnm   VARCHAR2(100);  --카드사명  하나제약 카드사공통코드 와 매핑 
    
    p_ymd          VARCHAR2(10); --수금일자     
     
    v_spSLSALERESULT_N_param   VARCHAR2 (256);
    IO_CURSOR      ORAGMP.TYPES.DataSet;    
    
    ERROR_EXCEPTION     EXCEPTION;
    
BEGIN  
 
insert into SFA_SP_CALLED_HIST values ('SP_Z_COLLECT_110_BEGIN',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate,'in_YMD:'||to_char(in_YMD) ||' in_SAWON_ID '||in_SAWON_ID||'in_AMT  '||to_char(in_AMT)||'in_CARD_ACCEPT_NO '||in_CARD_ACCEPT_NO ||'in_BILL_GB '||in_BILL_GB||'in_CARD_COMP '||in_CARD_COMP);
commit;
             
    IF in_YMD IS NULL THEN
       p_ymd := TO_CHAR(SYSDATE,'YYYY-MM-DD');
    ELSE
       p_ymd := TO_CHAR(in_YMD,'YYYY-MM-DD');
    END IF; 
                            
    IF in_CUST_ID IS NULL OR TRIM(in_CUST_ID) = '' THEN
        out_CODE := 1;
        out_MSG := '<거래처를 반드시 선택해야 합니다.>'; 
        RAISE ERROR_EXCEPTION;
    END IF;
                                          
    IF in_AMT IS NULL OR TRIM(in_AMT) = '' THEN
        out_CODE := 1;
        out_MSG := '<수금액을 반드시 입력해야 합니다.>'; 
        RAISE ERROR_EXCEPTION;
    END IF; 
    
    --담당사원체크
    BEGIN
        select empcode,deptcode
        into v_sawon_id,v_dept_cd
        from ORAGMP.CMCUSTM
        where plantcode = '1000'
          and custcode = in_CUST_ID ;
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '<이거래처로 담당자가 지정되어 있지 않습니다.관리부로 연락하십시오. >';
        RAISE ERROR_EXCEPTION;
    END;      

   --중지거래처  통제(다른거래처에 수금입력 오류방지)   
    SELECT COUNT(*) INTO ll_count  FROM ORAGMP.CMCUSTM WHERE custcode = in_CUST_ID AND useyn = 'N';
    IF ll_count > 0 THEN
        out_CODE := 1;
        out_MSG := '<중지된 거래처입니다. 관리부로 연락하십시오.>'; 
        RAISE ERROR_EXCEPTION;
    END IF; 
    
    v_colno := in_JUNPYO_NO;
    
    v_cardcompcd := nvl(substr(in_CARD_COMP,1,instr(in_CARD_COMP,'@')-1),in_CARD_COMP);
    v_cardcompnm := nvl(substr(in_CARD_COMP,instr(in_CARD_COMP,'@')+1),in_CARD_COMP);
    
    IF in_BILL_GB = '100' THEN        
        v_card_gb := '카드수금 '||v_cardcompnm;
        v_auto_yn  := 'Y';
        v_cardcompcd2 := v_cardcompcd;
    ELSE  
        
        -- 하나제약 카드사 공통코드와 KICC 카드사 코드  매칭
        v_cardcompcd2 := '';
        /*
        if v_cardcompcd = '016'  then  v_cardcompcd2 := '010'; end if;  -- 국민카드
        if v_cardcompcd = '031'  then  v_cardcompcd2 := '020'; end if;  -- 삼성카드
        if v_cardcompcd = '029'  then  v_cardcompcd2 := '040'; end if;  -- 신한
        if v_cardcompcd = '007'  then  v_cardcompcd2 := '040'; end if;  -- 신한
        if v_cardcompcd = '050'  then  v_cardcompcd2 := '060'; end if;  -- 비자         해외카드라 승인안됨
        if v_cardcompcd = '026'  then  v_cardcompcd2 := '070'; end if;  -- BC카드
        if v_cardcompcd = '027'  then  v_cardcompcd2 := '080'; end if;  -- 현대카드
        if v_cardcompcd = '008'  then  v_cardcompcd2 := '140'; end if;  -- 외환은 하나sk로 변경됨 
        if v_cardcompcd = '046'  then  v_cardcompcd2 := '100'; end if;  -- 동양(A/X)  해외카드라 승인안됨
        if v_cardcompcd = '048'  then  v_cardcompcd2 := '100'; end if;  -- 동양(A/X)  해외카드라 승인안됨
        if v_cardcompcd = '022'  then  v_cardcompcd2 := '110'; end if;  -- 씨티카드
        if v_cardcompcd = '036'  then  v_cardcompcd2 := '110'; end if;  -- 씨티카드
        if v_cardcompcd = '045'  then  v_cardcompcd2 := '120'; end if;  -- 롯데카드
        if v_cardcompcd = '047'  then  v_cardcompcd2 := '120'; end if;  -- 롯데카드
        if v_cardcompcd = '011'  then  v_cardcompcd2 := '130'; end if;  -- 롯데카드
        if v_cardcompcd = '006'  then  v_cardcompcd2 := '150'; end if;  -- 하나SK
        if v_cardcompcd = '021'  then  v_cardcompcd2 := '170'; end if;  -- 우리
        if v_cardcompcd = '002'  then  v_cardcompcd2 := '190'; end if;  -- 광주
        if v_cardcompcd = '018'  then  v_cardcompcd2 := '200'; end if;  -- 농협   
        if v_cardcompcd = '017'  then  v_cardcompcd2 := '230'; end if;  -- 수협
        if v_cardcompcd = '010'  then  v_cardcompcd2 := '240'; end if;  -- 전북
        if v_cardcompcd = '001'  then  v_cardcompcd2 := '999'; end if;  -- 조흥 
        if v_cardcompcd = '058'  then  v_cardcompcd2 := '280'; end if;  -- 산업KDB 
        if v_cardcompcd = '028'  then  v_cardcompcd2 := '999'; end if;  -- 해외 JCB       해외카드라 승인안됨
        if v_cardcompcd = '049'  then  v_cardcompcd2 := '999'; end if;  -- 해외 MASTER    해외카드라 승인안됨
        if v_cardcompcd = '081'  then  v_cardcompcd2 := '999'; end if;  -- 은련           해외카드라 승인안됨
       */
       
        if    v_cardcompcd = '016'  then  v_cardcompcd2 := '010';   -- 국민카드
        elsif v_cardcompcd = '031'  then  v_cardcompcd2 := '020';   -- 삼성카드
        elsif v_cardcompcd = '029'  then  v_cardcompcd2 := '040';   -- 신한
        elsif v_cardcompcd = '007'  then  v_cardcompcd2 := '040';   -- 신한
        elsif v_cardcompcd = '026'  then  v_cardcompcd2 := '070';   -- BC카드
        elsif v_cardcompcd = '027'  then  v_cardcompcd2 := '080';   -- 현대카드
        elsif v_cardcompcd = '008'  then  v_cardcompcd2 := '140';   -- 외환은 하나sk로 변경됨 
        elsif v_cardcompcd = '022'  then  v_cardcompcd2 := '110';   -- 씨티카드
        elsif v_cardcompcd = '036'  then  v_cardcompcd2 := '110';   -- 씨티카드
        elsif v_cardcompcd = '045'  then  v_cardcompcd2 := '120';   -- 롯데카드
        elsif v_cardcompcd = '047'  then  v_cardcompcd2 := '120';   -- 롯데카드
        elsif v_cardcompcd = '011'  then  v_cardcompcd2 := '130';   -- 롯데카드
        elsif v_cardcompcd = '006'  then  v_cardcompcd2 := '150';   -- 하나SK
        elsif v_cardcompcd = '021'  then  v_cardcompcd2 := '170';   -- 우리
        elsif v_cardcompcd = '002'  then  v_cardcompcd2 := '190';   -- 광주
        elsif v_cardcompcd = '018'  then  v_cardcompcd2 := '200';   -- 농협   
        elsif v_cardcompcd = '017'  then  v_cardcompcd2 := '230';   -- 수협
        elsif v_cardcompcd = '010'  then  v_cardcompcd2 := '240';   -- 전북
        elsif v_cardcompcd = '058'  then  v_cardcompcd2 := '280';   -- 산업KDB
        elsif v_cardcompcd = '001'  then  v_cardcompcd2 := '040';   -- 조흥  
        elsif v_cardcompcd = '046'  then  v_cardcompcd2 := '100';   -- 동양(A/X)   해외카드라 승인안됨
        elsif v_cardcompcd = '048'  then  v_cardcompcd2 := '100';   -- 동양(A/X)   해외카드라 승인안됨
        elsif v_cardcompcd = '050'  then  v_cardcompcd2 := '060';   -- 비자        해외카드라 승인안됨
        elsif v_cardcompcd = '028'  then  v_cardcompcd2 := '';      -- 해외 JCB    해외카드라 승인안됨
        elsif v_cardcompcd = '049'  then  v_cardcompcd2 := '';      -- 해외 MASTER 해외카드라 승인안됨
        elsif v_cardcompcd = '081'  then  v_cardcompcd2 := '';      -- 은련        해외카드라 승인안됨
        else  v_cardcompcd2 := '' ;  
        end if;   
    
        v_card_gb := '수기카드 '||v_cardcompcd||' '||v_cardcompnm;
        v_auto_yn  := 'N';
        
    END IF; 
        
    ORAGMP.spSLcol0000P1 (
                       p_div          => 'I',
                       p_plantcode    => '1000',                                --사업장
                       p_coldate      => p_ymd ,         --수금일자
                       p_coldate1     => p_ymd,         --수금일자
                       p_colseq       => SUBSTR(v_colno,9,4),                   --수금전표순번
                       p_saldiv       => 'C01',                                 --영업구분  
                       p_coldiv       => '21',                                  --수금구분01-현금입금 10-통장입금 11-선수금(수출) 21-신용카드 30-약속어음 31-가계수표 32-당좌수표 35-전자어음 51-결손(대손) 52-매출할인 53-부도처리 54-잔고정리 55-잔고이월 57-판매대행 59-판매장려금 99-기타  
                       p_orderdiv     => '4',                                   --영업영역 1-도매ETC 2-도매OTC 3-간납 4-직납 5-거점 6-직접수출 7-간접수출
                       p_tasooyn      => '', -- in_BILL_GB,                            --어음 자수타수구분(N:자수,Y:타수)
                       p_custcode     => in_CUST_ID,                            --수금처코드
                       p_deptcode     => v_dept_cd,                             --수금담당부서코드
                       p_empcode      => v_sawon_id,                            --수금담당코드
                       p_ecustcode    => in_CUST_ID,    
                       p_edeptcode    => v_dept_cd,  
                       p_eempcode     => v_sawon_id,   
                       p_utdiv        => '',                                    --유통구분                       
                       p_eutdiv       => '',                                    --간납유통구분
                       p_colamt       => TO_NUMBER(in_AMT),                     --수금액
                       p_colvat       => 0,                                     --판매대행수수료(부가세)
                       p_moneycode    => '',  
                       p_exrtrate     => 0,                                     --환율
                       p_exrtamt      => 0,  
                       p_accountno    => '',  
                       p_billno       => '',                                    --어음번호
                       p_issdate      => '',                                    --어음 발행일자
                       p_expdate      => replace(in_CARD_USE_PERIOD,'/',''),    --어음 만기일  카드유효기간도 함께 사용 
                       p_paybank      => '',                                    --어음 지급은행코드
                       p_paybankbr    => '',                                    --어음 은행지점명
                       p_issempnm     => '',                                    --어음 발행처 발행인
                       p_baeseo       => '',                                    --어음 배서인
                       p_cardcomp     => v_cardcompcd2,                         --카드사코드
                       p_cardno       => in_CARD_NO,                            --카드번호
                       p_cardokno     => in_CARD_ACCEPT_NO,                     --카드승인번호
                       p_carddate     => p_ymd,          --카드매출일자
                       p_autoyn       => v_auto_yn,                             --카드수금='Y' 수기카드 ='N"   
                       p_divmonth     => in_CARD_ALLOTMENT,                     --카드할부개월
                       p_enuriyn      => '',   
                       p_appdate      => p_ymd,          --카드승인일자 
                       p_discntdate   => '',  
                       p_custprtyn    => 'N',                                   --거래장출력여부
                       p_bigo         => in_CARD_BILL_GB,                       --비고  카드거래종류(신용결재승인,신용결재취소)   
                       p_remark       => v_card_gb,                             --비고  카드수금 수기카드 
                       p_statediv     => '09',                                  --상태구분 00:저장    01:입력  09:수금확정    99:반려
                       p_iempcode     => in_SAWON_ID,                           --입력사번
                       p_uempcode     => in_SAWON_ID,                           --수정사번
                       p_salpower     => '',  
                       p_colno        => v_colno,                               --수금번호
                       p_apprstatus   => '03',                                  --진행상태  00:입력    01:상신   03:확정완료    04:반려완료
                       p_coldtldiv    => '',  
                       p_apprclassdiv => '',  
                       p_yearmonth    => '',
                       MESSAGE        => v_spSLSALERESULT_N_param,
                       IO_CURSOR      => IO_CURSOR   
                    );     
                
                
    if v_spSLSALERESULT_N_param = '데이터 확인' then
         out_CODE := 100;
         out_MSG := '저장시 오류가 발생하였습니다. 오류내용: '||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);      
         ROLLBACK;
         
        insert into SFA_SP_CALLED_HIST values ('SP_Z_COLLECT_110_ERROR_3',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate,'in_YMD:'||to_char(in_YMD) ||' in_SAWON_ID '||in_SAWON_ID||'in_AMT  '||to_char(in_AMT)||'in_CARD_ACCEPT_NO '||in_CARD_ACCEPT_NO ||'in_BILL_GB '||in_BILL_GB||'in_CARD_COMP '||in_CARD_COMP||' / out_MSG'||out_MSG);
        commit;
        
    else  
    
        insert into SFA_SP_CALLED_HIST values ('SP_Z_COLLECT_110_END',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate,'in_YMD:'||to_char(in_YMD) ||' in_SAWON_ID '||in_SAWON_ID||'in_AMT  '||to_char(in_AMT)||'in_CARD_ACCEPT_NO '||in_CARD_ACCEPT_NO ||'in_BILL_GB '||in_BILL_GB||'in_CARD_COMP '||in_CARD_COMP);
        commit;
     
         out_CODE := 0;
         out_MSG := '정상처리 되었습니다.';
         COMMIT;
        
    end if;
     
EXCEPTION
WHEN ERROR_EXCEPTION THEN
       ROLLBACK; 
       
        insert into SFA_SP_CALLED_HIST values ('SP_Z_COLLECT_110_ERROR 1',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate,'in_YMD:'||to_char(in_YMD) ||' in_SAWON_ID '||in_SAWON_ID||'in_AMT  '||to_char(in_AMT)||'in_CARD_ACCEPT_NO '||in_CARD_ACCEPT_NO ||'in_BILL_GB '||in_BILL_GB||'in_CARD_COMP '||in_CARD_COMP||' / out_MSG'||out_MSG);
        commit;       
   
WHEN OTHERS THEN
       out_CODE := SQLCODE;
       out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
       ROLLBACK; 
       
       
        insert into SFA_SP_CALLED_HIST values ('SP_Z_COLLECT_110_ERROR 2',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate,'in_YMD:'||to_char(in_YMD) ||' in_SAWON_ID '||in_SAWON_ID||'in_AMT  '||to_char(in_AMT)||'in_CARD_ACCEPT_NO '||in_CARD_ACCEPT_NO ||'in_BILL_GB '||in_BILL_GB||'in_CARD_COMP '||in_CARD_COMP||' / out_MSG'||out_MSG);
        commit;
       
END;
/
