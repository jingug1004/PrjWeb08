CREATE PROCEDURE      P_Eijing_20130128
              ( AS_YM    IN  VARCHAR2,
                AS_CUSTF IN  VARCHAR2,
                AS_CUSTT IN  VARCHAR2)
                
IS
 /* ******** 코멘트를 DB에 저장하기 위해 여기에 기록함. ********************** */
 /* ******************************************************************************* */
 /*   TITLE        :  에이징차트 임시테이블에 저장                                  */
 /*   PROJECT      :  채권관리부                                                    */
 /*   AUTHOR       :                                                                */
 /*   PROGRAM_ID   :  EIJING                                                        */
 /*   HISTORY      :  2006.11.31(목)                                                */
 /*   PROCESS      :  항목별로 데이타 넣는다                                        */
 /* ******************************************************************************* */
 -- 2010.05.18 금월잔고를 가지고 12개월 매출금액 잔고를 구한다. 
 
 	V_I          NUMBER;
 	T_MM01       NUMBER;
 	T_MM02       NUMBER;
 	T_MM03       NUMBER;
 	T_MM04       NUMBER;
 	T_MM05       NUMBER;
 	T_MM06       NUMBER;
 	T_MM07       NUMBER;
 	T_MM08       NUMBER;
 	T_MM09       NUMBER;
 	T_MM10       NUMBER;
 	T_MM11       NUMBER;
 	T_MM12       NUMBER;
 	T_MM13       NUMBER;
 	T_DAMBO      NUMBER;
 	T_RATEDAY    NUMBER;
 	T_SALE_AMT   NUMBER;
 	V_REAM_AMT   NUMBER; --당월잔액 
 	T_REAM_AMT   NUMBER; --전월잔액 
 	T_CUST_ID    VARCHAR2(10);
 	T_YYMM       VARCHAR2(6);
 	
   CURSOR CUR1 IS
        SELECT A.CUST_ID         CUST_ID,
               SUM(A.BEFORE_AMT) BEFORE_AMT, /*전월 잔액 */
               SUM(A.SALE_AMT)   SALE_AMT,   /* 판매 */ 
               SUM(A.BACK_AMT)   BACK_AMT,   /* 반품 */ 
               SUM(A.DISC_AMT)   DISC_AMT,   /* 할인 */ 
               SUM(A.ACTU_AMT)   ACTU_AMT,   /* 실판매*/
               SUM(A.CASH_AMT)   CASH_AMT,   /* 현금+카드 */
               SUM(A.BILL_AMT)   BILL_AMT,   /* 어음 */      
               NVL(SUM(A.CASH_AMT),0) + NVL(SUM(A.BILL_AMT),0) COLL_AMT, /*수금계*/
               SUM(A.BEFORE_AMT) + NVL(SUM(A.ACTU_AMT),0) - NVL(SUM(A.CASH_AMT),0) - NVL(SUM(A.BILL_AMT),0) REAM_AMT, /*금월잔고*/
               SUM(A.JSAU_AMT)   JSAU_AMT,   /* 미결어음(자수) */      
               SUM(A.TASU_AMT)   TASU_AMT,   /* 미결어음(타수) */      
               SUM(A.BEFORE_AMT) + NVL(SUM(A.ACTU_AMT),0) - NVL(SUM(A.CASH_AMT),0) - NVL(SUM(A.BILL_AMT),0) + NVL(SUM(A.JSAU_AMT),0) NET_AMT  /*NET잔고*/
          FROM (SELECT CUST_ID    CUST_ID,      
                       BEFORE_AMT BEFORE_AMT, /*전월 잔액 */
                       0          SALE_AMT,   /* 판매 */      
                       0          BACK_AMT,   /* 반품 */      
                       0          DISC_AMT,   /* 할인 */      
                       0          ACTU_AMT,   /* 실판매*/     
                       0          CASH_AMT,   /* 현금+카드 */ 
                       0          BILL_AMT,   /* 어음 */      
                       0          JSAU_AMT,   /* 미결어음(자수) */      
                       0          TASU_AMT    /* 미결어음(타수) */      
                  FROM SALE0306
                 WHERE YMD = TO_DATE(AS_YM||'/01','YYYY/MM/DD')
                   AND CUST_ID BETWEEN AS_CUSTF AND AS_CUSTT
                UNION ALL
                SELECT A.CUST_ID                                                              CUST_ID,
                       0                                                                      BEFORE_AMT,/*전월 잔액 */
                       SUM(DECODE(SUBSTR(A.DEAL_GB,1,1),'0', NVL(B.AMT,0) + NVL(B.VAT,0),
                                                        '2', NVL(B.AMT,0) + NVL(B.VAT,0), 0)) SALE_AMT,  /* 판매 */ 
                       SUM(DECODE(A.DEAL_GB,'10', NVL(-B.AMT,0) + NVL(-B.VAT,0), 0))          BACK_AMT,  /* 반품 */ 
                       SUM(DECODE(A.DEAL_GB,'12', NVL(-B.AMT,0) + NVL(-B.VAT,0),
                                            '13', NVL(-B.AMT,0) + NVL(-B.VAT,0), 0))          DISC_AMT,  /* 할인 */ 
                       SUM(NVL(B.AMT,0) + NVL(B.VAT,0))                                       ACTU_AMT,  /* 실판매*/
                       0                                                                      CASH_AMT,  /* 현금+카드 */
                       0                                                                      BILL_AMT,  /* 어음 */
                       0                                                                      JSAU_AMT,  /* 미결어음(자수) */      
                       0                                                                      TASU_AMT   /* 미결어음(타수) */      
                  FROM SALE0207 A, 
                       SALE0208 B, 
                       SALE0203 E
                 WHERE A.DEAL_NO  = B.DEAL_NO
                   AND A.YMD      = B.YMD
                   AND A.GUMAE_NO = E.GUMAE_NO(+)
                   AND A.YMD      BETWEEN TO_DATE(AS_YM||'01','YYYY/MM/DD') AND LAST_DAY(TO_DATE(AS_YM||'01','YYYY/MM/DD'))
                   AND A.CUST_ID  BETWEEN AS_CUSTF AND AS_CUSTT
                 GROUP BY A.CUST_ID
                UNION ALL /*  수금(할인) 내역 */
                SELECT A.CUST_ID,
                       0               BEFORE_AMT,/*전월 잔액 */
                       0               SALE_AMT,  /* 판매 */ 
                       0               BACK_AMT,  /* 반품 */ 
                       0               DISC_AMT,  /* 할인 */ 
                       0               ACTU_AMT,  /* 실판매*/
                       SUM(A.CASH_AMT) CASH_AMT,  /* 현금+카드 */
                       SUM(A.BILL_AMT) BILL_AMT,  /* 어음 */
                       0               JSAU_AMT,  /* 미결어음(자수) */      
                       0               TASU_AMT   /* 미결어음(타수) */      
                  FROM (
                        SELECT A.CUST_ID     CUST_ID,
                               CASH_AMT      CASH_AMT, /* 현금+카드 */
                               0             BILL_AMT  /* 어음 */
                          FROM SALE0401  A
                         WHERE A.YMD      BETWEEN TO_DATE(AS_YM||'01','YYYY/MM/DD') AND LAST_DAY(TO_DATE(AS_YM||'01','YYYY/MM/DD'))
                           AND A.CASH_AMT <> 0
                           AND A.CUST_ID BETWEEN AS_CUSTF AND AS_CUSTT
                        UNION ALL
                        SELECT A.CUST_ID                                         CUST_ID,
                               DECODE(B.BILL_GB, '100', B.AMT, '101', B.AMT, 0)  CASH_AMT, /* 현금+카드 */
                               DECODE(SUBSTR(B.BILL_GB,1,1), '1', 0, B.AMT)      BILL_AMT  /* 어음 */
                          FROM SALE0401 A, SALE0402 B
                         WHERE A.YMD     BETWEEN TO_DATE(AS_YM||'01','YYYY/MM/DD') AND LAST_DAY(TO_DATE(AS_YM||'01','YYYY/MM/DD'))
                           AND A.CUST_ID BETWEEN AS_CUSTF AND AS_CUSTT
                           AND A.JUNPYO_NO = B.JUNPYO_NO
                       ) A 
                 GROUP BY A.CUST_ID
                UNION ALL /*  미결어음 */
                SELECT X.CUST_ID  CUST_ID ,
                       0          BEFORE_AMT, /*전월 잔액 */
                       0          SALE_AMT,   /* 판매 */      
                       0          BACK_AMT,   /* 반품 */      
                       0          DISC_AMT,   /* 할인 */      
                       0          ACTU_AMT,   /* 실판매*/     
                       0          CASH_AMT,   /* 현금+카드 */ 
                       0          BILL_AMT,   /* 어음 */      
                       NVL(SUM(DECODE(Y.BILL_GB,'010',Y.AMT)),0) +
                       NVL(SUM(DECODE(Y.BILL_GB,'020',Y.AMT)),0) +
                       NVL(SUM(DECODE(Y.BILL_GB,'030',Y.AMT)),0) +
                       NVL(SUM(DECODE(Y.BILL_GB,'900',Y.AMT)),0) JASU_AMT,
                       NVL(SUM(DECODE(Y.BILL_GB,'025',Y.AMT)),0) +
                       NVL(SUM(DECODE(Y.BILL_GB,'035',Y.AMT)),0) +
                       NVL(SUM(DECODE(Y.BILL_GB,'040',Y.AMT)),0) TASU_AMT
                  FROM SALE0401 X, SALE0402 Y
                 WHERE X.YMD       = Y.YMD
                   AND X.JUNPYO_NO = Y.JUNPYO_NO 
                   AND Y.END_YMD   > LAST_DAY(TO_DATE(AS_YM||'01','YYYY/MM/DD'))
                   AND X.CUST_ID   BETWEEN AS_CUSTF AND AS_CUSTT
                 GROUP BY X.CUST_ID
               )  A,
               SALE0003 B
         WHERE A.CUST_ID = B.CUST_ID
           AND B.USE_YN  = 'Y'     
         GROUP BY A.CUST_ID;
         
 BEGIN

    FOR C1 IN CUR1 LOOP

     	T_MM01 := 0;
     	T_MM02 := 0;
     	T_MM03 := 0;
     	T_MM04 := 0;
     	T_MM05 := 0;
     	T_MM06 := 0;
     	T_MM07 := 0;
     	T_MM08 := 0;
     	T_MM09 := 0;
     	T_MM10 := 0;
     	T_MM11 := 0;
     	T_MM12 := 0;
     	T_MM13 := 0;
        
        IF (C1.COLL_AMT <= 0) AND (C1.REAM_AMT <= 0) THEN
            T_RATEDAY := 0;
            
        ELSE
            FOR I IN 0..12 LOOP
                V_I := I * -1;
             
                SELECT NVL(SUM(DECODE(SUBSTR(A.DEAL_GB,1,1),'0', NVL(B.AMT,0) + NVL(B.VAT,0),
                                                            '2', NVL(B.AMT,0) + NVL(B.VAT,0), 0)),0) SALE_AMT  /* 판매 */ 
                  INTO T_SALE_AMT
                  FROM SALE0207 A, 
                       SALE0208 B, 
                       SALE0203 E
                 WHERE A.DEAL_NO  = B.DEAL_NO
                   AND A.YMD      = B.YMD
                   AND A.GUMAE_NO = E.GUMAE_NO(+)
                   AND A.CUST_ID  = C1.CUST_ID
                   AND TO_CHAR(A.YMD,'YYYYMM') = TO_CHAR(ADD_MONTHS(TO_DATE(AS_YM||'01','YYYY/MM/DD'),V_I),'YYYYMM');
               
                IF V_I = 0 THEN
                   T_REAM_AMT := C1.REAM_AMT;
                   V_REAM_AMT := C1.REAM_AMT - T_SALE_AMT;
                ELSE
                   V_REAM_AMT := T_REAM_AMT - T_SALE_AMT;
                END IF;   
               
                IF V_REAM_AMT > 0 THEN
                   T_REAM_AMT := V_REAM_AMT;
               
                   IF V_I = 0 THEN
                      T_MM01 := T_SALE_AMT;
                   END IF;
                   IF V_I = -1 THEN
                      T_MM02 := T_SALE_AMT;
                   END IF;
                   IF V_I = -2 THEN
                      T_MM03 := T_SALE_AMT;
                   END IF;
                   IF V_I = -3 THEN
                      T_MM04 := T_SALE_AMT;
                   END IF;
                   IF V_I = -4 THEN
                      T_MM05 := T_SALE_AMT;
                   END IF;
                   IF V_I = -5 THEN
                      T_MM06 := T_SALE_AMT;
                   END IF;
                   IF V_I = -6 THEN
                      T_MM07 := T_SALE_AMT;
                   END IF;
                   IF V_I = -7 THEN
                      T_MM08 := T_SALE_AMT;
                   END IF;
                   IF V_I = -8 THEN
                      T_MM09 := T_SALE_AMT;
                   END IF;
                   IF V_I = -9 THEN
                      T_MM10 := T_SALE_AMT;
                   END IF;
                   IF V_I = -10 THEN
                      T_MM11 := T_SALE_AMT;
                   END IF;
                   IF V_I = -11 THEN
                      T_MM12 := T_SALE_AMT;
                   END IF;
                   IF V_I = -12 THEN
                      T_MM13 := T_REAM_AMT + T_SALE_AMT;
                   END IF;

                ELSE
                   IF V_I = 0 THEN
                      T_MM01 := T_REAM_AMT;
                   END IF;
                   IF V_I = -1 THEN
                      T_MM02 := T_REAM_AMT;
                   END IF;
                   IF V_I = -2 THEN
                      T_MM03 := T_REAM_AMT;
                   END IF;
                   IF V_I = -3 THEN
                      T_MM04 := T_REAM_AMT;
                   END IF;
                   IF V_I = -4 THEN
                      T_MM05 := T_REAM_AMT;
                   END IF;
                   IF V_I = -5 THEN
                      T_MM06 := T_REAM_AMT;
                   END IF;
                   IF V_I = -6 THEN
                      T_MM07 := T_REAM_AMT;
                   END IF;
                   IF V_I = -7 THEN
                      T_MM08 := T_REAM_AMT;
                   END IF;
                   IF V_I = -8 THEN
                      T_MM09 := T_REAM_AMT;
                   END IF;
                   IF V_I = -9 THEN
                      T_MM10 := T_REAM_AMT;
                   END IF;
                   IF V_I = -10 THEN
                      T_MM11 := T_REAM_AMT;
                   END IF;
                   IF V_I = -11 THEN
                      T_MM12 := T_REAM_AMT;
                   END IF;
                   IF V_I = -12 THEN
                      T_MM13 := T_REAM_AMT;
                   END IF;

                   EXIT; --최종잔액을 보여주고 다음거래처로 이동 
               
                END IF;
        
            END LOOP;

            T_REAM_AMT := C1.REAM_AMT; --금월잔액 
            FOR C2 IN (
                        SELECT A.YYMM,
                               SUM(A.SALE_AMT) SALE_AMT
                          FROM (
                                SELECT TO_CHAR(A.YMD,'YYYYMM') YYMM,
                                       -NVL(SUM(DECODE(SUBSTR(A.DEAL_GB,1,1),'0', NVL(B.AMT,0) + NVL(B.VAT,0),
                                                                             '2', NVL(B.AMT,0) + NVL(B.VAT,0), 0)),0) SALE_AMT  /* 판매 */ 
                                  FROM SALE0207 A, 
                                       SALE0208 B, 
                                       SALE0203 E
                                 WHERE A.DEAL_NO  = B.DEAL_NO
                                   AND A.YMD      = B.YMD
                                   AND A.GUMAE_NO = E.GUMAE_NO(+)
                                   AND A.CUST_ID  = C1.CUST_ID
                                   AND TO_CHAR(A.YMD,'YYYYMM') <= AS_YM
                                GROUP BY TO_CHAR(A.YMD,'YYYYMM')
                                UNION ALL
                                SELECT TO_CHAR(YMD,'YYYYMM') YYMM,
                                       NVL(SUM(NVL(CASH_AMT,0) + NVL(BILL_AMT,0)),0) /* 수금 */
                                  FROM SALE0401
                                 WHERE TO_CHAR(YMD,'YYYYMM') = AS_YM
                                   AND CUST_ID                  = C1.CUST_ID
                                   AND (CASH_AMT <> 0 OR BILL_AMT <> 0)
                                GROUP BY TO_CHAR(YMD,'YYYYMM')
                               ) A
                         GROUP BY A.YYMM
                         ORDER BY A.YYMM DESC
                      ) 
            LOOP
                T_REAM_AMT := T_REAM_AMT + C2.SALE_AMT; 
                T_YYMM := C2.YYMM; --회전일이 끝나는 달 
                IF T_REAM_AMT <= 0 THEN --회전일이 끝나는 달 
                   EXIT;
                END IF;
            END LOOP;
        
            --회전일계산
            SELECT MONTHS_BETWEEN(AS_YM||'01', T_YYMM||'01') INTO T_RATEDAY FROM DUAL;
        
            IF T_RATEDAY <= 1 THEN
               T_RATEDAY := 30; 
            ELSE
               T_RATEDAY := T_RATEDAY * 30; 
            END IF;
        END IF;
        
        --거래처 담보율계산 
         T_DAMBO := 0;
         SELECT ROUND(F_MOD_EXCEPTION(NVL(H.SALE_DAMBO_AMT,0), 
                                     (NVL(F.BEFORE_AMT,0) + NVL(F.MISU_AMT,0) - NVL(F.SU_AMT,0) + NVL(L.BILL_010_AMT,0) + NVL(L.BILL_020_AMT,0) + NVL(L.BILL_030_AMT,0) + NVL(L.BILL_100_AMT,0) + NVL(L.BILL_900_AMT,0))) * 100, 2)
           INTO T_DAMBO
           FROM SALE0003 A,
                ( SELECT CUST_ID , 
                         SUM(BEFORE_AMT)  BEFORE_AMT,
                         SUM(MISU_AMT)    MISU_AMT,
                         SUM(SU_AMT)      SU_AMT
                    FROM SALE0306
                   WHERE YMD        = TO_DATE(AS_YM||'/01','YYYY/MM/DD')
                     AND CUST_ID    = C1.CUST_ID
                   GROUP BY CUST_ID
                ) F,
                ( SELECT X.CUST_ID, NVL(SUM(X.SALE_DAMBO_AMT),0) SALE_DAMBO_AMT
                    FROM SALE0404 X
                   WHERE X.CUST_ID    = C1.CUST_ID
                     AND NVL(X.CHULGO_YMD,TO_DATE('2999/01/01','YYYY/MM/DD')) = TO_DATE('2999/01/01','YYYY/MM/DD')
                   GROUP BY X.CUST_ID 
                ) H,
                (
                  SELECT X.CUST_ID        CUST_ID ,
                         NVL(SUM(DECODE(Y.BILL_GB,'010',Y.AMT)),0)  BILL_010_AMT,
                         NVL(SUM(DECODE(Y.BILL_GB,'020',Y.AMT)),0)  BILL_020_AMT,
                         NVL(SUM(DECODE(Y.BILL_GB,'025',Y.AMT)),0)  BILL_025_AMT,
                         NVL(SUM(DECODE(Y.BILL_GB,'030',Y.AMT)),0)  BILL_030_AMT,
                         NVL(SUM(DECODE(Y.BILL_GB,'035',Y.AMT)),0)  BILL_035_AMT,
                         NVL(SUM(DECODE(Y.BILL_GB,'040',Y.AMT)),0)  BILL_040_AMT,
                         NVL(SUM(DECODE(Y.BILL_GB,'100',Y.AMT)),0)  BILL_100_AMT,
                         NVL(SUM(DECODE(Y.BILL_GB,'900',Y.AMT)),0)  BILL_900_AMT
                    FROM SALE0401 X ,
                         SALE0402 Y
                   WHERE X.YMD       = Y.YMD
                     AND X.JUNPYO_NO = Y.JUNPYO_NO 
                     AND X.CUST_ID   = C1.CUST_ID
                     AND Y.END_YMD  >= SYSDATE
                   GROUP BY X.CUST_ID
                  ) L
          WHERE A.CUST_ID = C1.CUST_ID
            AND A.CUST_ID = F.CUST_ID(+)
            AND A.CUST_ID = H.CUST_ID(+)
            AND A.CUST_ID = L.CUST_ID(+);   
                 
        --에이징 테이블에 INSERT  
        INSERT INTO EIJING (CUST_ID, YM_F, BEFORE_AMT, 
                            SALE, BANPUM, HALIN, 
                            SIL_SALE, CASH_CARD, BILL, 
                            SU_AMT, JANGO, MIDORA_JA, 
                            MIDORA_CHA, NET, MM_1, 
                            MM_2, MM_3, MM_4, 
                            MM_5, MM_6, MM_7, 
                            MM_8, MM_9, MM_10, 
                            MM_11, MM_12, MM_13, 
                            RATEDAY, DAMBO, MANGI) 
                     VALUES (C1.CUST_ID, AS_YM,      C1.BEFORE_AMT, 
                             C1.SALE_AMT,C1.BACK_AMT,C1.DISC_AMT,
                             C1.ACTU_AMT,C1.CASH_AMT,C1.BILL_AMT,  
                             C1.COLL_AMT,C1.REAM_AMT,C1.JSAU_AMT,  
                             C1.TASU_AMT,C1.NET_AMT, T_MM01,
                             T_MM02,     T_MM03,     T_MM04,
                             T_MM05,     T_MM06,     T_MM07,
                             T_MM08,     T_MM09,     T_MM10,
                             T_MM11,     T_MM12,     T_MM13,
                             T_RATEDAY,  T_DAMBO,    0);
    
    END LOOP;
    
    COMMIT;
    
    EXCEPTION
       WHEN OTHERS THEN
          ROLLBACK;
          RAISE_APPLICATION_ERROR(-20099, SUBSTRB('오류!'||SQLCODE||'/'||SQLERRM,1,250)) ;
   
    END P_Eijing;

/
