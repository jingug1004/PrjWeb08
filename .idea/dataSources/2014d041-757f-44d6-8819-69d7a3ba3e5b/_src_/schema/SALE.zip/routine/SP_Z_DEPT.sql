CREATE PROCEDURE      SP_Z_DEPT
(
    in_PART_CD           IN  VARCHAR2,      -- PART 코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : PART별 부서 검색
 호출프로그램 :  실적현황 파트선택시           
   2017.11.01 KTA - NEW ERP메 맞게 컨버젼     
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_deptcode           VARCHAR2(20);
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_DEPT',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_PART_CD,sysdate,'in_PART_CD:'||in_PART_CD);
--commit;
    
    if in_PART_CD = '10' then  --종병
       v_deptcode := '0520';
    elsif in_PART_CD = '20' then  --병원
       v_deptcode := '0465';    
    elsif in_PART_CD = '30' then  --의원    
       v_deptcode := '0466';
    elsif in_PART_CD = '40' then  --도매
       v_deptcode := '0111';
    
    end if;

/*
0520    종병본부
0466    의원본부
0465    병원본부
0111    도매본부
*/

    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.CMDEPTM
     WHERE LEVEL <> 1
       AND useyn = 'Y'
       and  rownum = 1
       CONNECT BY PRIOR deptcode = predeptcode    START WITH  plantcode = '1000' and deptcode = v_deptcode  
     ; 
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT deptcode                 AS out_DEPT_CD    -- 부서 코드(영업)
             , deptname                 AS out_DEPT_NM    -- 부서 명
             , deptcode                 AS out_SALE_DEPT_CD -- 영업DB 부서코드
          FROM ORAGMP.CMDEPTM
         WHERE LEVEL <> 1
           AND useyn = 'Y'
       CONNECT BY PRIOR deptcode = predeptcode    START WITH  plantcode = '1000' and deptcode = v_deptcode
         ORDER BY deptname; 
        END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
