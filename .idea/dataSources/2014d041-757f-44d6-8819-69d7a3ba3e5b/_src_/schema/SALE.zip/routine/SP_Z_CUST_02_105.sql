CREATE PROCEDURE      SP_Z_CUST_02_105
(
    in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(조회:0, 등록:1, 수정:2, 삭제:3,가상계좌없데이트:6 ) 
    in_SFA_SALES_SEQ     IN  VARCHAR2,     -- SFA거래처키컬럼
    in_CUST_CD           IN  VARCHAR2,     -- SFA거래처코드
    in_CUST_GUBUN        IN  VARCHAR2,     -- 거래처 구분
    in_CUST_NM           IN  VARCHAR2,     -- 거래처 명
    in_TAX_NO            IN  VARCHAR2,     -- 사업자 번호
    in_MANAGER_NM        IN  VARCHAR2,     -- 대표자 명
    in_USE_YN            IN  VARCHAR2,     -- 거래여부
    in_STATUS_NM         IN  VARCHAR2,     -- 업태
    in_VITEM_NM          IN  VARCHAR2,     -- 업종
    in_ZIP_CODE          IN  VARCHAR2,     -- 우편버호
    in_ADDR1             IN  VARCHAR2,     -- 주소
    in_ADDR2             IN  VARCHAR2,     -- 상세주소
    in_EMAIL             IN  VARCHAR2,     -- E-MAIL
    in_HP_NO             IN  VARCHAR2,     -- 핸드폰번호
    in_TEL_NO            IN  VARCHAR2,     -- 전화번호
    in_FAX_NO            IN  VARCHAR2,     -- 팩스번호
    in_LICENSE_NO        IN  VARCHAR2,     -- 면허번호
    in_FLOW              IN  VARCHAR2,     -- 유통구분
    in_PHARM_NO          IN  VARCHAR2,     -- 요양기관
    in_GPS_NUM1          IN  VARCHAR2,     -- SFA_SALES_CODE.GPS_NUM1%TYPE,       -- 위도
    in_GPS_NUM2          IN  VARCHAR2,     -- SFA_SALES_CODE.GPS_NUM2%TYPE,       -- 경도
    in_INPUT_DT          IN  VARCHAR2,     -- 입력일자
    in_INPUT_SAWON       IN  VARCHAR2,     -- 입력자 사번
    in_SAWON_ID          IN  VARCHAR2,     -- 사용자 ID
    in_CLIENT_NO         IN  VARCHAR2,     -- 고객코드
    in_ERP_CD            IN  VARCHAR2,     -- ERP 코드
    in_DEPT_CD           IN  VARCHAR2,     -- 부서코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 거래처정보 팝업_수정 
 호출프로그램  : 거래처>거래처검색> 거래처리스트 클릭시 거래처정보팝업화면 열릴때
 개발자기록   :
           거래처정보의 신규,수정,삭제는 노트에서는 불가함 관리자가 관리함.     
          2015.10.13 kta : 가상계좌등록버튼시 몇몇 거래처에서end of input charctor 에러발생:원인불명.수작업으로 가상계좌 등록해줌.      
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼            
 ---------------------------------------------------------------------------*/   
    v_num                NUMBER;
    v_cnt                NUMBER;
    v_cust_no            NUMBER;
    v_client_no          NUMBER;
    v_gps_num1           NUMBER;    
    v_gps_num2           NUMBER;
    
    v_virtual_no         VARCHAR2(14);
    
    CUST_CD_NULL         EXCEPTION;
    VIRTUAL_NO_NULL      EXCEPTION;
    ERROR_OCCURS         EXCEPTION;

BEGIN 

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_STATUS_01',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_DEPT_CD,sysdate,'in_DEPT_CD:'||in_DEPT_CD||'/in_PART_CD '||in_PART_CD );
--commit;

    --신규가 아닌데 거래처키컬럼 없으면 에러 
    IF in_BTN_GUBUN <> 1 AND (in_SFA_SALES_SEQ IS NULL OR TRIM(in_SFA_SALES_SEQ) = '') THEN
        RAISE CUST_CD_NULL;
    END IF;
             
    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.CMHIRAM
     WHERE hiracode = in_SFA_SALES_SEQ;
     
     
    IF in_BTN_GUBUN = 1 THEN -- 등록버튼 클릭한 경우 : 노트에서 신규없음 
     
    
        IF v_num >= 1 THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '기존 등록된 거래처가 있습니다';
        ELSE 
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '거래처 등록이 완료되었습니다';
        
        END IF;
        
    ELSIF in_BTN_GUBUN = 2 THEN -- 수정버튼 클릭한 경우::노트에서 수정없음 
        IF v_num < 1 THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '기존 등록된 거래처가 없습니다';
        ELSE
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '거래처 수정이 완료되었습니다 02';
        END IF;
        
    ELSIF in_BTN_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우: 노트에서 삭제없음.
    
        IF v_num < 1 THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '기존 등록된 거래처가 없습니다 02';
        ELSE   
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '거래처 삭제가 완료되었습니다 02';
            
         END IF;
         

    ELSIF in_BTN_GUBUN = 6 THEN  -- 가상계좌저장
    
    
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '거래처 정보가 존재하지 않습니다.';
            
        ELSIF (v_num >= 1) THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '거래처 정보 존재함111 ';  
            
            --SFA거래처코드가 ERP거래처코드에 매칭되지 않는 거래처를 가상계좌요청한 경우 불가처리            
            v_cnt := 0;
            SELECT count(*)
              INTO v_cnt
              FROM ORAGMP.CMCUSTM
             WHERE plantcode = '1000'
               AND custdiv   = '2'
               AND hiracode = in_CUST_CD;            
            IF v_cnt = 0 THEN
                out_MSG := '주문거래처가 아닙니다.주문거래처만 가상계좌 등록가능 합니다.';
                RAISE ERROR_OCCURS;
            END IF;

            
            --이미 등록되어 있는지 확인한다.
            v_cnt := 0;
            SELECT count(*)
              INTO v_cnt
              FROM ORAGMP.CMCUSTM
             WHERE plantcode = '1000'
               AND custdiv   = '2'
               AND hiracode = in_CUST_CD
               AND virtualaccount is not null;            
            IF v_cnt > 0 THEN
                out_MSG := '가상계좌가 이미 등록되어 있습니다.';
                RAISE ERROR_OCCURS;
            END IF;

            
            --사용할 가상계좌 번호를 찾아온다: 
            SELECT MIN(VIRTUAL_NO) INTO v_virtual_no 
              FROM SALE.SALE0003VN a 
             WHERE not exists  (select 'x' from ORAGMP.CMCUSTM where plantcode = '1000' and virtualaccount = a.virtual_no);
            
            IF v_virtual_no is null THEN  
                out_MSG := '등록할 가상계좌 번호가 없습니다.(SALE.SALE0003VN 테이블 확인)';  
                RAISE VIRTUAL_NO_NULL;
            END IF; 


            BEGIN
                UPDATE ORAGMP.CMCUSTM SET virtualaccount = v_virtual_no WHERE plantcode = '1000' AND custdiv   = '2' AND hiracode  = in_CUST_CD; 
                
                
                UPDATE SALE.SALE0003VN SET cust_id  = in_CUST_CD WHERE VIRTUAL_NO   = v_virtual_no; 
            EXCEPTION WHEN OTHERS THEN              
                out_MSG  :='가상계좌 저장실패:'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                RAISE ERROR_OCCURS;
            END;
             
            OPEN out_RESULT FOR
            SELECT a.hiracode            AS out_SFA_SALES_SEQ -- sfa거래처키컬럼
                 , a.hiracode            AS out_CUST_CD       -- sfa거래처코드
                 , a.custcode            AS out_ERP_CD        -- erp거래처코드
                 , b.sagodiv             AS out_CUST_GUBUN    --  SFA_SALES_GUBUN  거래처상태(CM20)
                 , a.hiraname            AS out_CUST_NM       -- 거래처명
                 , a.businessno          AS out_TAX_NO        -- 사업자번호
                 , a.ceoname             AS out_MANAGER_NM    -- 대표자명 
                 , decode(a.orderempcode,null,'N','Y')  AS out_USE_YN        -- TRADE_YN
                 , b.custcondition       AS out_STATUS_NM     -- 업태
                 , b.custitem            AS out_VITEM_NM      -- 업종
                 , a.hirapost            AS out_ZIP_CODE      -- 우편번호
                 , a.hiraaddr            AS out_ADDR1         -- 주소
                 , ''                    AS out_ADDR2         -- 주소상세
                 , b.custemptel          AS out_HP_NO         -- 핸드폰 거래처담당자전화
                 , a.telno               AS out_TEL_NO        -- 전화번호
                 , b.faxno               AS out_FAX_NO        -- 팩스번호
                 , b.licenseno           AS out_LICENSE_NO    -- 면허번호
                 , b.utdiv               AS out_FLOW          -- FLOW
                 , oragmp.fncommonnm('comm','CM15',b.utdiv) AS out_FLOW_NM       -- F_CODE_ITEM_NM('0020', FLOW)
                 , b.medicalcode         AS out_PHARM_NO      -- 요양기관번호
                 , TO_CHAR(NVL(a.latitude,0)) AS out_GPS_NUM1 -- GPS위도 
                 , TO_CHAR(NVL(a.longitude,0)) AS out_GPS_NUM2 -- GPS경도
                 , ''                    AS out_CLIENT_NO      --SFA_CLIENT_NO
                 ,virtualaccount         AS out_VIRTUAL_NO     -- 가상계좌
            FROM ORAGMP.CMHIRAM a
                ,ORAGMP.CMCUSTM b
           WHERE a.plantcode = '1000'
             AND a.hiracode  = b.hiracode(+)
             AND a.hiracode  = in_SFA_SALES_SEQ;
             
        END IF;
    
    ELSE   -- 조회처리
    
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '거래처 정보가 존재하지 않습니다. ';
        ELSIF (v_num >= 1) THEN
            out_COUNT := v_num;
            out_CODE := 0;
            out_MSG := '거래처 정보 존재함 ';    
            
            OPEN out_RESULT FOR
            SELECT a.hiracode            AS out_SFA_SALES_SEQ -- sfa거래처키컬럼
                 , a.hiracode            AS out_CUST_CD       -- sfa거래처코드
                 , a.custcode            AS out_ERP_CD        -- erp거래처코드
                 , b.sagodiv             AS out_CUST_GUBUN    --  SFA_SALES_GUBUN   거래처상태(CM20)
                 , a.hiraname            AS out_CUST_NM       -- 거래처명
                 , a.businessno          AS out_TAX_NO        -- 사업자번호
                 , a.ceoname             AS out_MANAGER_NM    -- 대표자명 
                 , decode(a.orderempcode,null,'N','Y')   AS out_USE_YN        -- TRADE_YN
                 , b.custcondition       AS out_STATUS_NM     -- 업태
                 , b.custitem            AS out_VITEM_NM      -- 업종
                 , a.hirapost            AS out_ZIP_CODE      -- 우편번호
                 , a.hiraaddr            AS out_ADDR1         -- 주소
                 , ''                    AS out_ADDR2         -- 주소상세
                 , b.custemptel          AS out_HP_NO         -- 핸드폰 거래처담당자전화
                 , a.telno               AS out_TEL_NO        -- 전화번호
                 , b.faxno               AS out_FAX_NO        -- 팩스번호
                 , b.licenseno           AS out_LICENSE_NO    -- 면허번호
                 , b.utdiv               AS out_FLOW          -- FLOW   유통구분
                 , oragmp.fncommonnm('comm','CM15',b.utdiv) AS out_FLOW_NM       -- 유통구분명 
                 , b.medicalcode         AS out_PHARM_NO      -- 요양기관번호
                 , TO_CHAR(NVL(a.latitude,0)) AS out_GPS_NUM1 -- GPS위도 
                 , TO_CHAR(NVL(a.longitude,0)) AS out_GPS_NUM2 -- GPS경도
                 , ''                       AS out_CLIENT_NO--SFA_CLIENT_NO
                 ,virtualaccount         AS out_VIRTUAL_NO     -- 가상계좌
            FROM ORAGMP.CMHIRAM a
                ,ORAGMP.CMCUSTM b
           WHERE a.plantcode = '1000'
             AND a.hiracode = b.hiracode(+)
             AND a.hiracode = in_SFA_SALES_SEQ;
     
        END IF;
        
        
    END IF;
    
EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG := '거래처코드가 누락되었습니다.'; 

WHEN VIRTUAL_NO_NULL THEN
   out_CODE := 102;
   out_MSG := '가상계좌 여유분이 없습니다.관리자에게 연락바랍니다.'; 

WHEN ERROR_OCCURS THEN
   out_CODE := 103; 
    
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
