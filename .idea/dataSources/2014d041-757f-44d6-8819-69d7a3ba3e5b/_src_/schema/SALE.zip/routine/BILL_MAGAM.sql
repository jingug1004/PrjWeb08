CREATE PROCEDURE BILL_MAGAM 
            ( O_MSG           OUT  VARCHAR2   -- 메시지
) IS 
   CURSOR CUR1 IS -- 만기일이 지나버린 미도래 어음을 얻는다.
          SELECT A.YMD          YMD,
                 A.JUNPYO_NO    JUNPYO_NO,
                 A.INPUT_SEQ    INPUT_SEQ,
                 A.START_YMD    START_YMD,
                 A.END_YMD      END_YMD,
                 A.AMT          AMT,
                 A.JIGEUB       JIGEUB,
                 A.BALHANG      BALHANG,
                 A.BILL_NO      BILL_NO,
                 A.BILL_GB      BILL_GB,
                 A.BIGO         BIGO,
                 A.GYULJAE_YMD  GYULJAE_YMD
            FROM SALE0402 A
           WHERE A.END_YMD <= SYSDATE
             AND NVL(A.GYULJAE_YMD,to_date('1900/01/01','yyyy/mm/dd')) = to_date('1900/01/01','yyyy/mm/dd');
BEGIN
--   RAISE_APPLICATION_ERROR(-20001,'휴직및 퇴직자 입니다. 확인요망 ');
   FOR C1 IN CUR1 LOOP
               UPDATE SALE0402 SET GYULJAE_YMD =  C1.END_YMD
                             WHERE YMD         =  C1.YMD
                               AND JUNPYO_NO   =  C1.JUNPYO_NO
                               AND INPUT_SEQ   =  C1.INPUT_SEQ ;
   END LOOP;
   O_MSG := 'OK : 미도래 만기일 처리가 완료 되었습니다.';   
   COMMIT; 
END  BILL_MAGAM ;


/
