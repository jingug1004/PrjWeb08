CREATE FUNCTION      F_INSA_ASSGN_CD  --사원번호를 받아서 직책을  RETURN
(
    in_SAWON_ID       IN  VARCHAR2  --영업사번
) 
RETURN VARCHAR2 IS 

    v_insa_sawon_id     VARCHAR2(7);
    v_assgn_cd          VARCHAR2(5);
    
BEGIN
    --

    --로그인사원의 인사사번   
    select insa_sawon_id into v_insa_sawon_id from sale0007 where sawon_id = in_SAWON_ID and rownum = 1; -- and gubun = 'Y';
    
    --로그인사원이 팀원인지,팀원이아닌 본부장,팀장인지 파악
    select assgn_cd into v_assgn_cd from hr_hc_empbas_0 where emp_no = v_insa_sawon_id;
     
    
    RETURN v_assgn_cd;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;

/
