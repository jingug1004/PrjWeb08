CREATE PROCEDURE      SP_Z_ORDER_123 (
        in_FLAG               IN VARCHAR2 DEFAULT NULL,
        in_YMD                IN date,
        in_GUMAE_NO           IN VARCHAR2 default NULL,
        in_SAWON_ID           IN VARCHAR2 default NULL,   --납품처사번 --sfa 주문은 직납주문만 처리하므로 거래처사번과 납품처사번은 동일함
        in_CUST_ID            IN VARCHAR2 default NULL,   --거래처코드 --sfa 주문은 직납주문만 처리하므로 거래처코드 와  납품처코드는  동일함
        in_RSAWON_ID          IN VARCHAR2 default NULL,   --납품처사번 --sfa 주문은 직납주문만 처리하므로 거래처사번과 납품처사번은 동일함
        in_RCUST_ID           IN VARCHAR2 default NULL,   --납품 거래처코드 --sfa 주문은 직납주문만 처리하므로 거래처코드 와  납품처코드는  동일함
        in_BAESONJI           IN VARCHAR2 default NULL,
        in_AMT_SUM            IN VARCHAR2 default NULL,
        in_VAT_SUM            IN VARCHAR2 default NULL,
        in_BIGO               IN VARCHAR2 default NULL,
        in_WIBAN_KIND         IN VARCHAR2 default NULL,
        in_COUNT              IN NUMBER,
        in_DATASET            IN VARCHAR2 default NULL,
        out_CODE              OUT NUMBER,
        out_MSG               OUT VARCHAR2       
        )
IS
    /*---------------------------------------------------------------------------
    프로그램명   : 주문등록(주문마스터와 주문상세를 모두 이곳에서 처리)
    호출프로그램 : 주문서등록의 등록버튼,       
    수정기록     :
    2013.01.30/ 김태안/ 주문프로세서 재정리에 따라 로직 수정함(윤홍주차장요청)
        <개요>신규처도 수량체크,회전일180초과시주문불가,월평균판매량,월평균판매금액적용.
          
        -SFA 주문등록 화면에서 회전일이 180일을 넘는 거래처는 주문불가 하도록 처리함.
        -신규처 개월수 = 0 일때 해당월판매량이 20개이상이면 return
        개월수 <>0 일때 해당월판매량20개이상이면 월평균판매량의1.5배이상일때 return
        해당월판매량20개이하이면 월평균판매량의1.5배이상일때 월평균판매금액의1.5배이상일때 return
        -기존처:해당월판매량20개이상이면 월평균판매량의1.5배이상일때 return
        해당월판매량20개이하이면 월평균판매량의1.5배이상일때 월평균판매금액의1.5배이상일때 return
        2.2013.03.04/김태안/거래처회전일을 위한 에이징이 전달로 생성이 안되어있으면 주문불가      
        3.2014.04.03/김태안/주문위반(회전일,수량) 주문을 할수 있도록 로직추가함.
        - in_BIGO는 사용하지 않으므로  를 위반약속내용 용도로 사용하고 PBIGO 컬럼에 넣는다.
        4.2015.01.30/김태안/적용율추가  거래처별단가에 있음.  
        5.2016.05.04/김태안/주문합계금액이 0인경우 주문불가체크 추가
        6.2017.04.03/김태안/사업장101 을 100 으로 변경하면서 100 에 대한 로직 추가함.다른사업장의 제품제어부분 수정         
        7. CHOE 20170727 위반 주문 등록시 본부장인 직접 주문을 넣은 경우 승인 된 것으로 처리         
        8.2017.09.19/김태안/비급여품목인경우 매출처별단가등록에 단가등록되어있지 않으면 주문불가처리   
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼 
    2017.11.28 YMB - 배송지순번 컬럼추가
   ---------------------------------------------------------------------------*/
        v_empcode   VARCHAR2(10);  --거래처담당사번
        v_eempcode  VARCHAR2(10);  --간납처담당사번
        v_deptcode  VARCHAR2(4);   --거래처담당사번의 소속부서
        v_edeptcode VARCHAR2(4);   --간납처담당사번의 소속부서
        v_utdiv     VARCHAR2(10);  --유통구분 
         
        v_orderno   VARCHAR2(14);  --채번한 주문번호 
        IO_CURSOR   oragmp.types.DataSet;

        ll_loop     NUMBER := 0;  
        v_ITEM_ID   VARCHAR2(10);
        v_QTY       VARCHAR2(13);
        v_DANGA     VARCHAR2(13);
        v_AMT       VARCHAR2(13);
        v_VAT       VARCHAR2(13);  
        v_drugprc   VARCHAR2(13);  -- 기준단가   
        
        
        --사업장이다른 제품 섞여있는지 체크용
        v_mplantcode VARCHAR2(4);  --관리사업장        
        v_cnt_1001   NUMBER;
        v_cnt_1002   NUMBER;
        v_cnt_2001   NUMBER;
        v_cnt_2002   NUMBER;
        
        --주문마스터와상세의 금액합계 비교용
        v_amt_sumadd NUMBER; 
         
        v_wiban_order_conf_status VARCHAR2(1); --위반오더승인상태 
        v_wiban_order_conf_dtm DATE;       --위반오더승인일시 
        v_classdivloginemp  VARCHAR2(13); --로그인사번 직책
        v_deptcodeloginemp VARCHAR2(14);  --로그인사번의 소속부서 
        
        --에러처리    
        ERROR_RAISE EXCEPTION; 
    
        v_retmsg VARCHAR2(400);  
        
        --거래처체크
        SLORDCHECK_CURSOR          oragmp.types.DataSet;
        
        v_creditck                 VARCHAR2(5); --신용한도체크      
        v_sagock                   VARCHAR2(5); --사고처체크  
        v_loanlmtck                VARCHAR2(5); --여신한도체크  
        v_balancelmtck             VARCHAR2(5); --잔고한도체크
        v_nocollmtck               VARCHAR2(5); --무수금한도체크  
        v_securitylmtck            VARCHAR2(5); --담보가치한도체크
        v_turnlmtck                VARCHAR2(5); --회전일한도 체크
        v_orderctrlyn              VARCHAR2(5); --주문제한처 체크 
        v_stopdiv                  VARCHAR2(5); --중지거래처 체크 
        v_custdivchk               VARCHAR2(5); --직거래처여부
        v_emailchk                 VARCHAR2(5); --이메일존재여부
        v_medicalcodechk           VARCHAR2(5); --요양기관번호 존재여부
                
        v_sunipgumyn               VARCHAR2(5); --선입금처여부
        
        --제품체크 
        SLORDITEMCHECK_CURSOR      oragmp.types.DataSet;
        v_piecechk                 VARCHAR2(5); --생산중단제품(단종)   
        v_discontinuechk           VARCHAR2(5); --낱알품목 출하제한  
        
        v_statediv                 VARCHAR2(2); --상태구분  01-입력 03-채권불량 09-매출확정 99-반려
        v_apprstatus               VARCHAR2(2); --진행상태 00-등록 01-상신 03-승인
        v_wibanorderreqyn          VARCHAR2(1); --위반오더요청여부:주문사원이 요청함  Y-위반 N-정상 
        
        --단가정보의 제품담당자
        v_itemempcode              VARCHAR2(10); --매출사원: 단가테이블 납품처담당사번
        v_itdeptcode               VARCHAR2(10); --매출부서: 단가테이블 납품처담당자의 부서
        v_itpartdiv                VARCHAR2(10); --매출직능: 단가테이블 납품처담당자의 직능 
        
        
   
BEGIN


    --사번오류체크
    /*    
    IF in_SAWON_ID <> '2012060' THEN
       out_CODE := 101;
       out_MSG := '정상화 될때 까지 잠시 사용 중지 합니다. ';  
       RETURN;
    END IF;
    */  
    

    IF  in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = ''  THEN
        out_CODE := 101;
        out_MSG := '납품처사번이 존재하지 않습니다. ';  
        RAISE ERROR_RAISE;
    END IF;
    
    IF  in_CUST_ID IS NULL OR TRIM(in_CUST_ID) = ''  THEN
        out_CODE := 102;
        out_MSG := '거래처코드가 존재하지 않습니다. ';  
        RAISE ERROR_RAISE;
    END IF;    
    
    IF  in_RCUST_ID IS NULL OR TRIM(in_RCUST_ID) = ''  THEN
        out_CODE := 102;
        out_MSG := '납품처코드가 존재하지 않습니다. ';  
        RAISE ERROR_RAISE;
    END IF;    
    
    ----------------------------------------------------------------------------
    --주문마스터 시작 : 주문서의 삭제 수정은 SFA 에서는 불가함
    ----------------------------------------------------------------------------
    IF in_FLAG = 'I' THEN         

                
        --주문일자와 시스템일자 체크 
        IF TO_CHAR(in_YMD, 'YYYYMMDD') <> TO_CHAR(SYSDATE, 'YYYYMMDD') THEN
           out_MSG := '주문일자가 다릅니다. SFA프로그램을 재시작후 주문등록해 주시기 바랍니다.';
           RAISE ERROR_RAISE;    
        END IF; 
 

        --주문거래처의 담당사번및소속부서
        select empcode,deptcode,utdiv into v_empcode,v_deptcode,v_utdiv from ORAGMP.CMCUSTM where plantcode = '1000' and custcode = in_CUST_ID;
                
        --판매처의 담당사번및소속부서
        select empcode,deptcode into v_eempcode,v_edeptcode from ORAGMP.CMCUSTM where plantcode = '1000' and custcode = in_RCUST_ID;
            
        --로그인사번의 직책및 소속부서                 
        select classdiv,deptcode into v_classdivloginemp,v_deptcodeloginemp from ORAGMP.CMEMPM  where empcode = in_SAWON_ID; 
            
        --로그인 사원이 팀원아니면 위반승인인경우 자동승인                
        v_wibanorderreqyn         := 'N';  --위반오더요청여부:주문사원이 요청함  Y-위반 N-정상
        v_wiban_order_conf_status := '0';  --0-대기,1-승인,2-반려 지점장이 처리
        v_statediv                := '01'; --상태구분 01-입력 03-채권불량 09-매출확정 99-반려
        v_apprstatus              := '01'; --진행상태 00-반려, 01-등록,02-상신, 03-승인 04-관리부반려 
                        
        IF  in_WIBAN_KIND <> '0' THEN   --0-정상,1-회전일,2-수량   
            v_wibanorderreqyn         := 'Y';   --위반오더요청여부:주문사원이 요청함  Y-위반 N-정상
            v_apprstatus              := '01';  --진행상태 00-반려, 01-등록,02-상신, 03-승인 04-관리부반려 
                                                          
            IF v_classdivloginemp  = '27040' THEN  --팀원이면
               v_wiban_order_conf_status := '0';   -- 0-대기,1-승인,2-반려 지점장이 처리  
               v_statediv                := '03';  --상태구분  01-입력 03-채권불량 09-매출확정 99-반려
            ELSE
               v_wiban_order_conf_status := '1';    -- 0-대기,1-승인,2-반려 지점장이 처리  
               v_wiban_order_conf_dtm    := SYSDATE;--to_char(sysdate,'yyyymmddhh24miss');    
               v_statediv                := '01';   --상태구분  01-입력 03-채권불량 09-매출확정 99-반려    
            END IF; 
        END IF;    

        --3,4 번대 거래처 체크
        IF NOT(SUBSTR(in_CUST_ID,1,1) = '3' OR SUBSTR(in_CUST_ID,1,1) = '4') THEN
            out_CODE := 101;
            out_MSG := 'SFA에서는 직거래처만 주문할수 있습니다.';
            RAISE ERROR_RAISE;            
        END IF;
            
             
        --거래처체크   
        OPEN SLORDCHECK_CURSOR FOR  
        SELECT * FROM TABLE(ORAGMP.fnSLordCheck('1000', to_char(in_YMD,'YYYY-MM-DD'), to_char(in_YMD,'YYYY-MM'), in_CUST_ID, in_CUST_ID,to_char(to_number(in_AMT_SUM) + to_number(in_VAT_SUM))));  
        LOOP
          FETCH SLORDCHECK_CURSOR INTO v_creditck, v_sagock, v_loanlmtck, v_balancelmtck, v_nocollmtck, v_securitylmtck, v_turnlmtck, v_orderctrlyn, v_stopdiv, v_custdivchk, v_emailchk, v_medicalcodechk;
          EXIT WHEN SLORDCHECK_CURSOR%NOTFOUND ;  
        END LOOP;
        CLOSE SLORDCHECK_CURSOR;  
            
        if v_stopdiv = '*'          then -- 사용중지처
            out_CODE := 101;
            out_MSG := '사용중지처 입니다.';
            RAISE ERROR_RAISE;            
        elsif v_orderctrlyn = '*'   then --주문일시중지처
            out_CODE := 102;
            out_MSG := '주문일시중지처 입니다.';
            RAISE ERROR_RAISE;        
        elsif v_custdivchk <> '*'    then --직거래처여부3,4 - 직거래처이면 별표
            out_CODE := 103;
            out_MSG := '직거래처만 주문가능 합니다.';
            RAISE ERROR_RAISE;        
        elsif v_emailchk = '*'      then --이메일유무
            out_CODE := 104;
            out_MSG := '이메일이 없습니다. 관리부에 연락바랍니다.';
            RAISE ERROR_RAISE;        
        elsif v_medicalcodechk= '*' then --요양기관번호유무
            out_CODE := 105;
            out_MSG := '요양기관번호가 없습니다. 관리부에 연락바랍니다.';
            RAISE ERROR_RAISE;        
        elsif v_sagock = '*'        then --사고처여부
            out_CODE := 106;
            out_MSG := '사고처 입니다.';
            RAISE ERROR_RAISE;        
        elsif v_loanlmtck = '*'     then --여신한도
            out_CODE := 107;
            out_MSG := '여신한도를 초과하였습니다.';
            RAISE ERROR_RAISE;        
        --elsif v_turnlmtck = '*'     then --회전일한도  - SFA기기에서 거래처정보조회시 회전일정보로 저장시 회전일위반주문처리하므로 여기서는 체크하지 않음 
        --    out_CODE := 108;
        --    out_MSG := '회전일한도 초과 입니다.';
        --    RAISE ERROR_RAISE;        
        elsif v_securitylmtck = '*' then --담보체크
            out_CODE := 109;
            out_MSG := '담보가 부족합니다 '; 
            RAISE ERROR_RAISE;        
        end if; 
            
        -- 주문번호채번 
        if in_GUMAE_NO IS NULL then                 
            oragmp.spCreateTableSerial('SLORDM',TO_CHAR(in_YMD,'YYYY-MM-DD'),v_orderno );
            IF SQLCODE <> 0 THEN
                out_CODE := 100;
                out_MSG := '주문번호 채번오류';
                RAISE ERROR_RAISE;                
            END IF;  
                           
        end if;  
            
        --주문마스터 INSERT
        BEGIN 
                INSERT INTO ORAGMP.SLORDM(
                           PLANTCODE            --사업장                                                              
                          ,ORDERNO              --주문번호                                                            
                          ,ORDERDATE            --주문일자                                                            
                          ,ORDERSEQ             --주문일련번호                                                        
                          ,SALDIV               --영업구분      A01:판매                                              
                          ,DATADIV              --자료구분      11:직납,12:간납                                       
                          ,ORDERDIV             --영업영역      3:간납, 4:직납                                        
                          ,OUTPUTDIV            --출하구분      1:택배, 9:직배                                        
                          ,TRANSFERDIV          --배송구분      1:거래선착                                            
                          ,CUSTCODE             --거래처                                                              
                          ,DEPTCODE             --부서코드                                                            
                          ,EMPCODE              --담당자코드                                                          
                          ,ECUSTCODE            --간납처코드                                                          
                          ,EDEPTCODE            --영업소(간납)                                                        
                          ,EEMPCODE             --담당자(간납)                                                        
                          ,UTDIV                --거래처유통구분                                                      
                          ,EUTDIV               --간납처유통구분                                                      
                          ,BNORDERNO            --상계주문번호(출하번호)                                              
                          ,TAXDATE              --세금계산서 발행일자                                                 
                          ,TRADEDATE            --거래명세서 발행일자                                                 
                          ,TAXMANAGEDATE        --세금계산서 발행일자                                                 
                          ,TRADEMANAGEDATE      --거래명세서 발행일자                                                 
                          ,FIXDATE              --주문확정일자                                                        
                          ,FIXSEQ               --주문확정차수                                                        
                          ,CREDITCK             --신용불량                                                            
                          ,SAGOCK               --사고처                                                              
                          ,LOANLMTCK            --여신한도                                                            
                          ,BALANCELMTCK         --잔고한도                                                            
                          ,NOCOLLMTCK           --무수금한도                                                          
                          ,SECURITYLMTCK        --담보가치한도                                                        
                          ,AVGAMTLMTCK          --평균판매금액한도                                                    
                          ,SAMPCK               --샘플출고체크                                                        
                          ,TURNLMTCK            --회전일한도                                                          
                          ,APPDATE              --출고일자                                                            
                          ,YYMM                 --출고년월                                                            
                          ,STATEDIV             --상태구분  01-입력 03-채권불량 09-매출확정 99-반려        
                          ,REMARK               --비고                                                                
                          ,BIGO                 --비고2                                                               
                          ,WAREHOUSE            --창고구분                                                            
                          ,APPRSTATUS           --진행상태  00-등록 01-상신                                           
                          ,INSERTDT             --입력일자                                                            
                          ,IEMPCODE             --입력사번                                                            
                          ,UPDATEDT             --수정일자                                                            
                          ,UEMPCODE             --수정사번       
                          ,ADDRSEQ              --배송지 순번                                                       
                          ,ORDERKIND            --주문종류              10:온라인 20:SFA 30:ERP     
                          ,CLEANDATE            --매출할인일자                                                        
                          ,CLEANSEQ             --매출할인일자작업순번                                                
                          ,THREEAVGCK           --3개월 주문수량 위반여부                                             
                          ,WIBANORDERREQYN      --위반오더요청여부:주문사원이 요청함                                  
                          ,WIBANORDERCONFSTATUS --위반오더승인상태      0-대기,1-승인,2-반려 지점장이 처리            
                          ,WIBANKIND            --위반유형              0-정상,1-회전일,2-수량                        
                          ,WIBANCONFDTM         --위반오더 지점장승인일시                                                                                              
                       )
                VALUES (
                     '1000'                                                                 --PLANTCODE            --사업장     
                     ,v_orderno                                                             --ORDERNO              --주문번호      
                     ,TO_CHAR(in_YMD,'YYYY-MM-DD')                                          --ORDERDATE            --주문일자  
                     ,SUBSTR(v_orderno,9,4)                                                 --ORDERSEQ             --주문일련번호  
                     ,'A01'                                                                 --SALDIV               --영업구분      A01:판매
                     ,CASE WHEN in_CUST_ID = in_RCUST_ID THEN '11' ELSE '12' END            --DATADIV              --자료구분      11:직납,12:간납 
                     ,CASE WHEN in_CUST_ID = in_RCUST_ID THEN '4'  ELSE '3'  END            --ORDERDIV             --영업영역      3:간납, 4:직납
                     ,'1'                                                                   --OUTPUTDIV            --출하구분      1:택배, 9:직배
                     ,'1'                                                                   --TRANSFERDIV          --배송구분      1:거래선착
                     ,in_CUST_ID                                                            --CUSTCODE             --거래처  
                     ,v_deptcode                                                            --DEPTCODE             --부서코드  
                     ,v_empcode                                                             --EMPCODE              --담당자코드  
                     ,in_RCUST_ID                                                           --ECUSTCODE            --간납처코드  
                     ,v_edeptcode                                                           --EDEPTCODE            --영업소(간납)  
                     ,v_eempcode                                                            --EEMPCODE             --담당자(간납)  
                     ,v_utdiv                                                               --UTDIV                --거래처유통구분   
                     ,v_utdiv                                                               --EUTDIV               --간납처유통구분  
                     ,''                                                                    --BNORDERNO            --상계주문번호(출하번호)  
                     ,''                                                                    --TAXDATE              --세금계산서 발행일자  
                     ,''                                                                    --TRADEDATE            --거래명세서 발행일자  
                     ,''                                                                    --TAXMANAGEDATE        --세금계산서 발행일자  
                     ,''                                                                    --TRADEMANAGEDATE      --거래명세서 발행일자  
                     ,''                                                                    --FIXDATE              --주문확정일자 
                     ,''                                                                    --FIXSEQ               --주문확정차수 
                     ,'N'                                                                   --CREDITCK             --신용불량 
                     ,'N'                                                                   --SAGOCK               --사고처 
                     ,'N'                                                                   --LOANLMTCK            --여신한도 
                     ,'N'                                                                   --BALANCELMTCK         --잔고한도 
                     ,'N'                                                                   --NOCOLLMTCK           --무수금한도 
                     ,'N'                                                                   --SECURITYLMTCK        --담보가치한도 
                     ,'N'                                                                   --AVGAMTLMTCK          --평균판매금액한도 
                     ,'N'                                                                   --SAMPCK               --샘플출고체크 
                     ,decode(in_WIBAN_KIND,'1','*','N')                                     --TURNLMTCK            --회전일위반   정상 'N'  위반 '*'
                     ,''                                                                    --APPDATE              --출고일자  
                     ,''                                                                    --YYMM                 --출고년월 
                     ,v_statediv                                                            --STATEDIV             --상태구분  01-입력 03-채권불량 09-매출확정 99-반려
                     ,''                                                                    --REMARK               --비고 
                     ,in_BIGO                                                               --BIGO                 --비고2
                     ,'001'                                                                 --WAREHOUSE            --창고구분 
                     ,v_apprstatus                                                          --APPRSTATUS           --진행상태 00-반려, 01-등록,02-상신, 03-승인 04-관리부반려 
                     ,SYSDATE                                                               --INSERTDT             --입력일자 
                     ,in_SAWON_ID                                                           --IEMPCODE             --입력사번 
                     ,SYSDATE                                                               --UPDATEDT             --수정일자
                     ,in_SAWON_ID                                                           --UEMPCODE             --수정사번
                     ,in_BAESONJI                                                           --ADDRSEQ              --배송지선택번호                         
                     ,'20'                                                                  --ORDERKIND            --주문종류              10:온라인 20:SFA 30:ERP
                     ,''                                                                    --CLEANDATE            --매출할인일자 
                     ,0                                                                     --CLEANSEQ             --매출할인일자작업순번 
                     ,decode(in_WIBAN_KIND,'2','*','N')                                     --THREEAVGCK           --3개월 주문수량 위반여부   정상 'N'  위반 '*'
                     ,v_wibanorderreqyn                                                     --WIBANORDERREQYN      --위반오더요청여부:주문사원이 요청함  Y-위반 N-정상 
                     ,v_wiban_order_conf_status                                             --WIBANORDERCONFSTATUS --위반오더승인상태      0-대기,1-승인,2-반려 지점장이 처리
                     ,NVL(in_WIBAN_KIND,'0')                                                --WIBANKIND            --위반유형           0-정상,1-회전일,2-수량
                     ,''                                                                    --WIBANCONFDTM         --위반오더 지점장승인일시-  SP_Z_WIBANORDER_CONF 에서 저장됨 
                );
                                         
        EXCEPTION 
                WHEN OTHERS THEN  
                out_CODE := 109;
                out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM||'- v_orderno:'||v_orderno);
                RAISE ERROR_RAISE;         
        END; 



        --------------------------------------------------------------------------
        --주문상세 시작
        --------------------------------------------------------------------------
        v_cnt_1001 := 0;
        v_cnt_1002 := 0;
        v_cnt_2001 := 0;
        v_cnt_2002 := 0;   
        v_amt_sumadd := 0;  
       
        -- 사업장이 석여있는 제품이 들어오면 허용불가..
        --client 에서 제조사업장이 다른 제품이 들어오는것은 막았는데 아직 업그레이드 하지 않아서...
        FOR ll_loop IN 1.. in_COUNT LOOP 

            v_ITEM_ID  := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 1 +61*(ll_loop -1),  10)); --v_ITEM_ID
            v_QTY      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 11+61*(ll_loop -1),  12)); --v_QTY
            v_DANGA    := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 23+61*(ll_loop -1),  13)); --v_DANGA
            v_AMT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 36+61*(ll_loop -1),  13)); --v_AMT
            v_VAT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 49+61*(ll_loop -1),  13)); --v_VAT
            
            v_mplantcode := '';
            SELECT a.mplantcode INTO v_mplantcode FROM ORAGMP.CMITEMM A WHERE a.itemcode  = v_ITEM_ID;
            
            if v_mplantcode = '2001' then  --하길마약,일반
                  v_cnt_2001 := 1;
            elsif v_mplantcode = '1001' then --도매지점
                  v_cnt_1001 := 1;
            elsif v_mplantcode = '1002' then --도매향정
                  v_cnt_1002 := 1;
            elsif v_mplantcode = '2002' then --하길향정
                  v_cnt_2002 := 1;
            end if;
            
            --제품금액누적
            v_amt_sumadd := v_amt_sumadd + v_AMT;

        END LOOP;
        
        if  v_cnt_2001 + v_cnt_1001 + v_cnt_1002 + v_cnt_2002 > 1 then
                out_CODE := 301;
                out_MSG := '동일사업장이 아닌 제품이 섞여 있습니다.주문을 분리하십시오.';
                RAISE ERROR_RAISE;            
        end if;                       
 
        if  TO_NUMBER(in_AMT_SUM) = 0 then
                out_CODE := 302;
                out_MSG := '주문금액 0원은 주문불가 합니다';
                RAISE ERROR_RAISE;            
        end if;                    
 
        if  TO_NUMBER(in_AMT_SUM)  <> v_amt_sumadd then
                out_CODE := 303;
                out_MSG := '주문금액과 제품합계금액이 틀립니다.확인하십시오.';
                RAISE ERROR_RAISE;            
        end if;                 
            
        FOR ll_loop IN 1.. in_COUNT LOOP 

            v_ITEM_ID  := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 1 +61*(ll_loop -1),  10)); --v_ITEM_ID
            v_QTY      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 11+61*(ll_loop -1),  12)); --v_QTY
            v_DANGA    := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 23+61*(ll_loop -1),  13)); --v_DANGA
            v_AMT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 36+61*(ll_loop -1),  13)); --v_AMT
            v_VAT      := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 49+61*(ll_loop -1),  13)); --v_VAT     

            --수량이 0이 아닌 경우만 처리
            if v_QTY is not null or v_QTY <> '' then  

                    
                if v_DANGA = 0 or v_AMT = 0 then                       
                    out_CODE := 201;
                    out_MSG := '단가 또는 금액이 0 인 제품 있습니다.제품코드 ['||v_ITEM_ID||']';
                end if;

                --제품체크1 :생산중단품과 낱알품목체크는 client 별 처리함    
                OPEN SLORDITEMCHECK_CURSOR FOR  
                SELECT * FROM TABLE(ORAGMP.fnSLordItemCheckT(v_ITEM_ID));  
                LOOP
                  FETCH SLORDITEMCHECK_CURSOR INTO v_piecechk, v_discontinuechk;
                  EXIT WHEN SLORDITEMCHECK_CURSOR%NOTFOUND ;  
                END LOOP;
                CLOSE SLORDITEMCHECK_CURSOR;  
                    
                if v_piecechk = '*'          then -- 생산중단제품(단종)
                    out_CODE := 201;
                    out_MSG := '단종 품목 입니다.';
                    RAISE ERROR_RAISE;         
                elsif v_discontinuechk = '*'   then --낱알품목 출하제한
                    out_CODE := 202;
                    out_MSG := '낱알 품목으로 등록할수 없습니다.';
                    RAISE ERROR_RAISE;         
                end if;                   
                
                
               --제품체크2 수량체크 ::이 체크로직은 SFA에서는 두곳에서 체크됨 : SP_Z_ORDER_CHECK 와 SP_Z_ORDR_123 
               BEGIN
                    
                    /* 이렇게 sql에서 펑션을 호출하면 SPDEBUG 테이블에 이력이 안남기때문에 아래 방식으로 변경함 
                    SELECT ORAGMP.fnSLordItemCheck('1000', to_char(in_ymd,'YYYY-MM-DD'), in_CUST_ID, in_CUST_ID, v_ITEM_ID, to_number(v_QTY), 0, '20', to_number(v_DANGA))
                      INTO v_retmsg
                      FROM DUAL; 
                    */  
                    v_retmsg := ORAGMP.fnSLordItemCheck('1000', to_char(in_ymd,'YYYY-MM-DD'), in_CUST_ID, in_CUST_ID, v_ITEM_ID, to_number(v_QTY), 0, '20', to_number(v_DANGA)); --10 saleon 20-sfa 30-erp  
                            
                    IF SUBSTR(v_retmsg,1,1) = '0' THEN                       
                        out_CODE := 1;          -- 정상  --체크통과처리함
                    ELSIF SUBSTR(v_retmsg,1,2) = '20' THEN --1 로 리턴은 수량통제 위반 이므로  수량위반주문 되어야 함 
                        out_CODE := 2;          -- 수량위반 -- 이체크는 수량선택시 체크할때 한번 걸렀고 이미 수량위반으로 주문저장넘어온 상태일것이므로 체크통과되도록 처리한것임 
                    ELSIF SUBSTR(v_retmsg,1,2) <> '20' THEN --0 도 아니고 11 도 아니면 주문불가   
                        out_CODE := 3;        -- 0이면 out_MSG 가 client에 넘어가지 않음.
                        out_MSG := v_retmsg   ; -- 주문불가 
                        RAISE ERROR_RAISE;         
                    END IF;
               END;     
                    
                --제품관련정보 
                SELECT mplantcode,drugprc
                  INTO v_mplantcode ,v_drugprc
                  FROM oragmp.CMITEMM WHERE  itemcode = v_ITEM_ID and itemdiv = '04' 
                ;
                    
                --계약단가 정보에 제품담당자  사번,부서,직능  
                BEGIN
                    SELECT a.empcode,b.deptcode,b.partdiv 
                      INTO v_itemempcode,v_itdeptcode,v_itpartdiv
                      FROM oragmp.SLPROMPRCM a
                          ,oragmp.CMEMPM b
                     WHERE a.empcode = b.empcode
                       AND a.plantcode = '1000' and a.custcode = in_CUST_ID and a.ecustcode = in_CUST_ID and a.itemcode = v_ITEM_ID and a.edate >= TO_CHAR(in_YMD,'YYYY-MM-DD');  
                EXCEPTION 
                        WHEN OTHERS THEN  
                        v_itemempcode := in_SAWON_ID;  
                        v_itdeptcode  := '';
                        v_itpartdiv   := '';     
                END;  
                                    
                --주문상세 INSERT
                BEGIN
                   INSERT INTO ORAGMP.SLORDD (
                            ORDERNO     --주문번호
                           ,PLANTCODE   --사업장
                           ,SEQ         --일련번호
                           ,ORDERDATE   --주문일자
                           ,ORDERSEQ    --주문순번
                           ,ITEMCODE    --제품코드
                           ,SALQTY      --판매수량
                           ,GIVQTY      --증품(할증)수량
                           ,BONUSQTY    --추가증품수량
                           ,DRUGPRC     --기준가
                           ,DRUGAMT     --기준금액
                           ,MAKINGCOST  --제조원가
                           ,EXRTPRC
                           ,EXRTAMT
                           ,SALPRC      --단가
                           ,SALAMT      --매출액
                           ,SALVAT      --부가세
                           ,TOTAMT      --매출합계
                           ,BEFAMT      --사전
                           ,AFTAMT      --사후
                           ,INCAMT      --수수료
                           ,TOTDISCOUNT --총할인
                           ,GIVRATE     --할증비율
                           ,BEFRATE     --사전비율
                           ,AFTRATE     --사후비율
                           ,INCRATE     --수수료비율
                           ,SALPRC1     --출하단가1
                           ,SALAMT1     --공급가액1
                           ,SALVAT1     --부가세1
                           ,TOTAMT1     --총금액1
                           ,CUSTPRTYN   --거래장출력여부
                           ,OUTPUTQTY   --출하수량
                           ,RECALLDIV   --반품유형
                           ,ABSYN       --품절여부
                           ,PIECEYN     --낱알여부
                           ,ENURIYN     --매출할인정리구분
                           ,JUORDNO
                           ,BPQTY
                           ,LOTNO       --제조번호
                           ,EXPDATE     --유효기간
                           ,INSERTDT    --입력일자
                           ,IEMPCODE    --입력자 사번
                           ,UPDATEDT    --수정일자
                           ,UEMPCODE    --수정자 사번
                           ,AVGQTY      --평균수량
                           ,AVGQTYLMTCK
                           ,LOTDATE     --제조일자
                           ,PIECEQTY
                           ,REALOUTQTY
                           ,SUPPLYDIV   --공급구분
                           ,EMPCODE     --담당자 사번
                           ,ORDQTYBSUNIT--주문수량배수단위
                           ,OUTPROTYN   --퇴장방지여부
                           ,MPLANTCODE  --관리사업장
                           ,PAIDYN      --급여/비급여구분
                           ,REQQTY      --요청수량
                           ,THREEAVGCK  --주문수량한도 위반여부
                           ,ITDEPTCODE  --매출부서: 단가테이블 납품처담당자의 부서
                           ,ITPARTDIV   --매출직능: 단가테이블 납품처담당자의 직능 
                          )
                   VALUES (
                            v_orderno                                                             --ORDERNO     --주문번호
                           ,'1000'                                                                --PLANTCODE   --사업장
                           ,ll_loop                                                               --SEQ         --일련번호
                           ,TO_CHAR(in_YMD,'YYYY-MM-DD')                                          --ORDERDATE   --주문일자
                           ,SUBSTR(v_orderno,9,4)                                                 --ORDERSEQ    --주문순번
                           ,v_ITEM_ID                                                             --ITEMCODE    --제품코드
                           ,v_QTY                                                                 --SALQTY      --판매수량
                           ,0                                                                     --GIVQTY      --증품(할증)수량
                           ,0                                                                     --BONUSQTY    --추가증품수량
                           ,v_drugprc                                                             --DRUGPRC     --기준가 
                           ,v_drugprc *  v_QTY                                                    --DRUGAMT     --기준금액   
                           ,0                                                                     --MAKINGCOST  --제조원가
                           ,0                                                                     --EXRTPRC     
                           ,0                                                                     --EXRTAMT     
                           ,v_DANGA                                                               --SALPRC      --단가
                           ,v_AMT                                                                 --SALAMT      --매출액
                           ,v_VAT                                                                 --SALVAT      --부가세
                           ,v_AMT + v_VAT                                                         --TOTAMT      --매출합계
                           ,0                                                                     --BEFAMT      --사전
                           ,0                                                                     --AFTAMT      --사후
                           ,0                                                                     --INCAMT      --수수료
                           ,0                                                                     --TOTDISCOUNT --총할인
                           ,0                                                                     --GIVRATE     --할증비율
                           ,0                                                                     --BEFRATE     --사전비율
                           ,0                                                                     --AFTRATE     --사후비율
                           ,0                                                                     --INCRATE     --수수료비율
                           ,v_DANGA                                                               --SALPRC1     --출하단가1
                           ,v_AMT                                                                --SALAMT1     --공급가액1
                           ,v_VAT                                                                 --SALVAT1     --부가세1
                           ,v_AMT + v_VAT                                                         --TOTAMT1     --총금액1
                           ,'Y'                                                                   --CUSTPRTYN   --거래장출력여부
                           ,0                                                                     --OUTPUTQTY   --출하수량
                           ,''                                                                    --RECALLDIV   --반품유형
                           ,'N'                                                                   --ABSYN       --품절여부
                           ,'N'                                                                   --PIECEYN     --낱알여부
                           ,''                                                                    --ENURIYN     --매출할인정리구분
                           ,''                                                                    --JUORDNO     
                           ,''                                                                    --BPQTY       
                           ,''                                                                    --LOTNO       --제조번호
                           ,''                                                                    --EXPDATE     --유효기간
                           ,SYSDATE                                                               --INSERTDT    --입력일자
                           ,in_SAWON_ID                                                           --IEMPCODE    --입력자 사번
                           ,SYSDATE                                                               --UPDATEDT    --수정일자 
                           ,in_SAWON_ID                                                           --UEMPCODE    --수정자 사번
                           ,0                                                                     --AVGQTY      --평균수량
                           ,''                                                                    --AVGQTYLMTCK 
                           ,''                                                                    --LOTDATE     --제조일자
                           ,0                                                                     --PIECEQTY    
                           ,''                                                                    --REALOUTQTY  
                           ,''                                                                    --SUPPLYDIV   --공급구분
                           ,NVL(v_itemempcode,in_SAWON_ID)                                        --EMPCODE     --담당자 사번  단가테이블의 제품담당자 , 없는 경우 납품처의 담당자                                
                           ,0                                                                     --ORDQTYBSUNIT--주문수량배수단위
                           ,'N'                                                                   --OUTPROTYN   --퇴장방지여부
                           ,v_mplantcode                                                          --MPLANTCODE  --관리사업장
                           ,'N'                                                                   --PAIDYN      --급여/비급여구분
                           ,v_QTY                                                                 --REQQTY      --요청수량
                           ,''                                                                    --THREEAVGCK  --급여/비급여구분
                           ,v_itdeptcode                                                          --ITDEPTCODE  --매출부서 : 단가테이블 납품처담당자의 부서 
                           ,v_itpartdiv                                                           --ITPARTDIV   --매출직능 : 단가테이블 납품처담당자의 직능
                   );
                EXCEPTION 
                   WHEN OTHERS THEN
                        out_CODE := SQLCODE;
                        out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                        RAISE ERROR_RAISE;
                END;  
 

            END IF;

        END LOOP ;  
            
        --선입금처여부
        select sunipgumyn into v_sunipgumyn from ORAGMP.CMCUSTM where custdiv = '2' and custcode = in_CUST_ID;
        IF v_sunipgumyn = 'Y' THEN      
            out_CODE  := 1;
            out_MSG := '주문이 정상처리되었습니다.<선입금처이므로 입금되어야 출하가 됩니다>';   
        ELSE            
            out_CODE  := 1;
            out_MSG := '주문이 정상처리되었습니다.';     
        END IF;
            
            

        -- 결재정보
        INSERT INTO oragmp.SLAPPRHORD
           (PLANTCODE ,ORDERNO    ,APPRDIV , APPRLASTSEQ , APPRWORKSEQ , INSERT_DT   ,IEMPCODE    )
        SELECT '1000' ,v_orderno  ,APPRDIV , APPRLASTSEQ , APPRWORKSEQ , sysdate   ,in_SAWON_ID
          FROM oragmp.SLAPPRM
         WHERE APPRDIV = '01';

        INSERT INTO oragmp.SLAPPRHDORD
              (PLANTCODE , ORDERNO   , APPRSEQ   , APPRCODE  , EDITYN  , EMPCODE   , APPRYN    , INSERT_DT , IEMPCODE  )
        SELECT '1000' , v_orderno, APPRSEQ    , APPRCODE   , EDITYN    , in_SAWON_ID  , 'N'    , sysdate  , in_SAWON_ID
          FROM oragmp.SLAPPRD
         WHERE APPRDIV = '01';
            
    END IF;  
      
        
EXCEPTION
        WHEN ERROR_RAISE THEN 
            ROLLBACK; 
            
            insert into SFA_SP_CALLED_HIST values ('SP_Z_ORDER_123_4',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate, 'in_SAWON_ID:'||in_SAWON_ID||'in_RCUST_ID:'||in_RCUST_ID||'in_AMT_SUM:'||in_AMT_SUM||'/in_VAT_SUM:'|| in_VAT_SUM||' '||out_MSG);
            commit;            

        WHEN OTHERS THEN
            out_CODE := SQLCODE;
            out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 
            ROLLBACK; 

end;
/
