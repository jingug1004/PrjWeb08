CREATE PROCEDURE      SP_Z_ITEM_MULTI_139
(
    in_CUST_ID           IN  VARCHAR2,  -- 거래처
    in_RCUST_ID          IN  VARCHAR2,  -- 판매처
    in_PROD_NM           IN  VARCHAR2,  -- 제품명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
/*---------------------------------------------------------------------------
 프로그램명   : 주문 제품 검색 팝업
 호출프로그램 : 주문>제품건건버튼> 제품멀티선택화면>조회버튼      
                    
         2017.09.20/김태안  단가를 F_GET_DANGA() 으로 처리 - 비급여품목인경우 매출처별단가등록에 단가가져옴in_CUST_ID,in_RCUST_ID 추가함 
         2017.11.01 KTA - NEW ERP메 맞게 컨버젼 - FZ_GET_DANGA 함수 추가 
         
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
     
BEGIN 

--insert into SFA_SP_CALLED_HIST values ('SP_SFA_ITEM_MULTI_139',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate,'in_RCUST_ID '||in_RCUST_ID|| ' in_PROD_NM '||in_PROD_NM|| '  in_PROD_NM '||in_PROD_NM );
     
    SELECT COUNT(*)
      INTO v_num
          FROM (
                SELECT a.itemcode ,a.itemname,a.itemunit,a.unit,a.mplantcode
                  FROM ORAGMP.CMITEMM a
                 WHERE a.plantcode in ('2000','3000')   --하길 상신 
                   AND a.itemdiv   = '04'     --완제품          
                   AND a.usediv    = 'Y'  
                   AND a.productdiv <> '04'   --중지품목제외               
                   AND a.mplantcode IN ('2001','2002','1001') --하길마약제외 2001-하길마약 2002-하길향정 1001-도매지점 1002-도매향정    
                   AND a.itemname LIKE '%'||in_PROD_NM||'%'
                   AND TRIM(a.itemunit) not in ('1A', '1A(PP)', '1C', '1C(P)', '1P', '1T', '1T(B)', '1T(P)', '1V', '1ml', '5ml*1포' )     
                UNION
                SELECT a.itemcode ,a.itemname,a.itemunit,a.unit,a.mplantcode
                  FROM ORAGMP.CMITEMM a
                 WHERE a.plantcode in ('2000','3000')   --하길 상신  
                   AND a.itemdiv   = '04'     --완제품      
                   AND a.usediv    = 'Y'  
                   AND a.productdiv <> '04'   --중지품목제외                 
                   AND a.mplantcode IN ('2001','2002','1001') --하길마약제외 2001-하길마약 2002-하길향정 1001-도매지점 1002-도매향정    
                   AND a.itemname LIKE '%'||in_PROD_NM||'%'
                   AND a.itemcode IN ('122011') --하니반정1T 짜리는 포함     
                 )  a                   
    ; 
    
    out_COUNT := v_num;
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다. (주문제품검색)';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR 

        SELECT a.itemcode     AS out_PROD_CD
              ,a.itemname     AS out_PROD_NM
              ,a.itemunit     AS out_STANDARD
              ,a.unit         AS out_UNIT
              ,FZ_GET_DANGA(in_CUST_ID,in_RCUST_ID,itemcode) AS out_DANGA
              ,a.mplantcode   AS out_SAUPJANG_CD  --oragmp.fnGetPlantcode(a.mplantcode)  
          FROM (
                SELECT a.itemcode ,a.itemname,a.itemunit,a.unit,a.mplantcode
                  FROM ORAGMP.CMITEMM a
                 WHERE a.plantcode in ('2000','3000')   --하길 상신 
                   AND a.itemdiv   = '04'     --완제품                     
                   AND a.mplantcode IN ('2001','2002','1001') --하길마약제외 2001-하길마약 2002-하길향정 1001-도매지점 1002-도매향정         
                   AND a.usediv = 'Y'  
                   AND a.productdiv <> '04'  --중지품목
                   AND a.itemname LIKE '%'||in_PROD_NM||'%'
                   AND TRIM(a.itemunit) not in ('1A', '1A(PP)', '1C', '1C(P)', '1P', '1T', '1T(B)', '1T(P)', '1V', '1ml', '5ml*1포' )     
                UNION
                SELECT a.itemcode ,a.itemname,a.itemunit,a.unit,a.mplantcode
                  FROM ORAGMP.CMITEMM a
                 WHERE a.plantcode in ('2000','3000')   --하길 상신  
                   AND a.itemdiv   = '04'     --완제품                     
                   AND a.mplantcode IN ('2001','2002','1001') --하길마약제외 2001-하길마약 2002-하길향정 1001-도매지점 1002-도매향정         
                   AND a.usediv = 'Y'  
                   AND a.productdiv <> '04'  --중지품목
                   AND a.itemname LIKE '%'||in_PROD_NM||'%'
                   AND a.itemcode IN ('122011') --하니반정1T 짜리는 포함     
                 )  a                 
        ORDER BY a.itemname   
        ;  
             
    END IF;
    
EXCEPTION 
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
