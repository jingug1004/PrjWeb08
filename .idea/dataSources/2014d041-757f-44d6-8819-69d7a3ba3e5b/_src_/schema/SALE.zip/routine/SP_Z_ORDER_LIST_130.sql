CREATE PROCEDURE      SP_Z_ORDER_LIST_130   
(
    in_SAWON_ID          IN  VARCHAR2,   
    in_CUST_ID           IN  VARCHAR2,    
    in_RCUST_ID          IN  VARCHAR2,    
    in_CDT_FR            IN  VARCHAR2,    
    in_CDT_TO            IN  VARCHAR2,    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문현황
 호출프로그램 : 
 수정내역
      2014.04.08 KTA 위반주문 팀장승인상태를 화면에 보여주도록 수정함.    
      2014.12.12 KTA 수정버튼시 주문등록화면으로 넘어가면서 가지고갈 회전일 추가.     
      2017.11.01  KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN


    SELECT COUNT(*)
      INTO v_num
      FROM ORAGMP.SLORDM a
     WHERE a.empcode  = in_SAWON_ID 
       AND a.custcode Like '%'||NVL(in_CUST_ID, '%')||'%'
       AND REPLACE(a.orderdate,'-','') BETWEEN in_CDT_FR AND in_CDT_TO;
    
--insert into SFA_SP_CALLED_HIST values ('SP_Z_ORDER_LIST_130','1',sysdate,'in_SAWON_ID'||in_SAWON_ID||'/in_CUST_ID'||in_CUST_ID||' / in_CDT_FR:'||in_CDT_FR||' / in_CDT_TO:'||in_CDT_TO);
--COMMIT;
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
    
        OPEN out_RESULT FOR
        SELECT a.orderno                                    AS out_GUMAE_NO
              ,REPLACE(a.orderdate,'-','')                  AS out_ORDER_DATE
              ,oragmp.fncommonnm ('COMM','SL10',a.saldiv)   AS out_GUBUN
              ,oragmp.fncommonnm ('COMM','SL17',a.statediv) AS OUT_ACCEPT_YN
              ,a.custcode                                   AS out_CUST_ID
              ,a.ecustcode                                  AS out_RCUST_ID  
              ,oragmp.fncommonnm ('CUST',a.custcode,'')     AS out_CUST_NM   
              ,oragmp.fncommonnm ('CUST',a.ecustcode,'')    AS out_RCUST_NM   
              ,ORAGMP.fnTotalAmount(a.orderno,'salamt') * decode(substr(saldiv,1,1),'B',-1,1)     AS out_AMT_SUM
              ,ORAGMP.fnTotalAmount(a.orderno,'salvat') * decode(substr(saldiv,1,1),'B',-1,1)     AS out_VAT_SUM
              ,ORAGMP.fnTotalAmount(a.orderno,'totamt') * decode(substr(saldiv,1,1),'B',-1,1)     AS out_AMOUNT
              ,a.empcode                                    AS out_SAWON_ID
              ,a.empcode                                    AS out_RSAWON_ID
              ,oragmp.fncommonnm ('EMP',a.empcode,'')       AS out_SAWON_NM
              ,oragmp.fncommonnm ('EMP',a.eempcode,'')      AS out_RSAWON_NM
              ,DECODE(a.wibanorderconfstatus,'0','접수','1','승인','반려')  AS out_WIBAN_ORDER_CONF_YN  
              ,(select turncnt from oragmp.slresultm where plantcode = a.plantcode and yearmonth = substr(a.orderdate,1,7) and custcode = a.custcode and ecustcode = a.ecustcode and orderdiv = a.orderdiv)  AS out_RATE_DAY -- 회전일
          FROM ORAGMP.SLORDM A
         WHERE a.empcode  = in_SAWON_ID                   
           AND a.custcode Like '%'||NVL(in_CUST_ID, '%')||'%'           
           AND REPLACE(a.orderdate,'-','') BETWEEN in_CDT_FR AND in_CDT_TO
         ORDER BY a.orderno DESC;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
