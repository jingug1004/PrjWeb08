CREATE FUNCTION      f_join  
(
    p_cursor SYS_REFCURSOR, 
    p_del    varchar2
) RETURN VARCHAR2 
  IS
    l_value VARCHAR2(32767);
    l_result VARCHAR2(32767);
    
BEGIN

    loop
       fetch p_cursor into l_value;
       exit when p_cursor%notfound;
       if l_result is not null then
            l_result := l_result || p_del;
       end if;
       l_result := l_result || l_value;                   
    end loop;
        
    close p_cursor;
    return l_result; 
    
END f_join;
/
