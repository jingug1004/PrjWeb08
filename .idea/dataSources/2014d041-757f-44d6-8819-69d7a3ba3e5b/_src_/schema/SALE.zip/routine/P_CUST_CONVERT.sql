CREATE PROCEDURE P_CUST_CONVERT
IS
BEGIN


      for c1 in (  SELECT NEW_CUST_ID,
                          OLD_CUST_ID,
                          SAWON_ID
                     FROM SALE0098
                    WHERE proc_yn = 'N' )
      loop

	      -- 거래처코드변경
	      BEGIN
	              UPDATE SALE0003 A SET
	                     A.CUST_ID  = c1.NEW_CUST_ID,
	                     A.SAWON_ID = NVL(c1.SAWON_ID,A.SAWON_ID)
	               WHERE CUST_ID    = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '거래처코드변경 Err1:['||c1.NEW_CUST_ID||']'||sqlerrm ) ;
	      END;


	              -- 주문서변경
	      BEGIN
	              UPDATE SALE0203 A SET
	                     A.CUST_ID = c1.NEW_CUST_ID,
	                     A.SAWON_ID = NVL(c1.SAWON_ID,A.SAWON_ID)
	               WHERE CUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '주문서변경 Err1:'||sqlerrm ) ;
	      END;

	      BEGIN
	              UPDATE SALE0203 A SET
	                     A.RCUST_ID = c1.NEW_CUST_ID,
	                     A.RSAWON_ID = NVL(c1.SAWON_ID,A.RSAWON_ID)
	               WHERE RCUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '주문서변경 Err2:'||sqlerrm ) ;
	      END;


	              -- 거래명세서변경
	      BEGIN
	              UPDATE SALE0207 A SET
	                     A.CUST_ID = c1.NEW_CUST_ID,
	                     A.SAWON_ID = NVL(c1.SAWON_ID,A.SAWON_ID)
	               WHERE CUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '거래명세서변경 Err1:'||sqlerrm ) ;
	      END;

	      BEGIN
	              UPDATE SALE0207 A SET
	                     A.RCUST_ID = c1.NEW_CUST_ID,
	                     A.RSAWON_ID = NVL(c1.SAWON_ID,A.RSAWON_ID)
	               WHERE RCUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '거래명세서변경 Err2:'||sqlerrm ) ;
	      END;

	              -- 세금계산서변경
	      BEGIN
	              UPDATE SALE0209 A SET
	                     A.CUST_ID = c1.NEW_CUST_ID,
	                     A.SAWON_ID = NVL(c1.SAWON_ID,A.SAWON_ID)
	               WHERE CUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '세금계산서변경 Err1:'||sqlerrm ) ;
	      END;

	      BEGIN
	              UPDATE SALE0209 A SET
	                     A.RCUST_ID = c1.NEW_CUST_ID,
	                     A.RSAWON_ID = NVL(c1.SAWON_ID,A.RSAWON_ID)
	               WHERE RCUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '세금계산서변경 Err2:'||sqlerrm ) ;
	      END;

	              -- 잔액테이블변경
	      BEGIN
	              UPDATE SALE0306 A SET
	                     A.CUST_ID = c1.NEW_CUST_ID
	               WHERE CUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '잔액테이블변경 Err1:'||sqlerrm ) ;
	      END;

	      BEGIN
	              UPDATE SALE0306 A SET
	                     A.RCUST_ID = c1.NEW_CUST_ID,
	                     A.SAWON_ID = NVL(c1.SAWON_ID,A.SAWON_ID)
	               WHERE RCUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '잔액테이블변경Err2:'||sqlerrm ) ;
	      END;

	              -- 수금테이블변경
	      BEGIN
	              UPDATE SALE0401 A SET
	                     A.CUST_ID = c1.NEW_CUST_ID
	               WHERE CUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '수금테이블변경 Err1:'||sqlerrm ) ;
	      END;

	      BEGIN
	              UPDATE SALE0401 A SET
	                     A.RCUST_ID = c1.NEW_CUST_ID,
	                     A.SAWON_ID = NVL(c1.SAWON_ID,A.SAWON_ID)
	               WHERE RCUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '수금테이블변경 Err2:'||sqlerrm ) ;
	      END;

	              -- 단가계약테이블변경
	      BEGIN
	              UPDATE SALE0405 A SET
	                     A.CUST_ID = c1.NEW_CUST_ID
	               WHERE CUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '단가계약테이블변경 Err1:'||sqlerrm ) ;
	      END;

	      BEGIN
	              UPDATE SALE0405 A SET
	                     A.RCUST_ID = c1.NEW_CUST_ID
	               WHERE RCUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '단가계약테이블변경 Err2:'||sqlerrm ) ;
	      END;

	              -- 통장테이블변경
	      BEGIN
	              UPDATE SALE0409 A SET
	                     A.CUST_ID = c1.NEW_CUST_ID
	               WHERE CUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '통장테이블변경 Err1:'||sqlerrm ) ;
	      END;

	      BEGIN
	              UPDATE SALE0409 A SET
	                     A.RCUST_ID = c1.NEW_CUST_ID
	               WHERE RCUST_ID   = c1.OLD_CUST_ID;
	      EXCEPTION
	              WHEN OTHERS THEN
	                   raise_application_error( -20001, '통장테이블변경 Err2:'||sqlerrm ) ;
	      END;

      end loop;

END  P_CUST_CONVERT;


/
