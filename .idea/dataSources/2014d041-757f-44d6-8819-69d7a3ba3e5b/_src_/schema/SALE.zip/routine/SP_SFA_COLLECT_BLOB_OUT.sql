CREATE PROCEDURE      SP_SFA_COLLECT_BLOB_OUT
(       in_JUNPYO_NO    IN VARCHAR2 DEFAULT NULL,
        out_CODE OUT NUMBER,
        out_MSG OUT VARCHAR2,
        out_COUNT OUT NUMBER,
        out_RESULT OUT TYPES.CURSOR_TYPE
)
IS
        /*---------------------------------------------------------------------------
        프로그램명   : 카드수금 저장된 이미지 다시 파일로 만듬 
        호출프로그램 : COLLECTLIST.JAVA
        CHOE 20140930   
         SP_SFA_COLLECT_BLOB 으로 in_SIGN_IMAGE   IN BLOB 전달 저장한 이미지를 다시 파일로 note에 저장    
        ---------------------------------------------------------------------------*/    

        ERROR_EXCEPTION EXCEPTION;   
        v_CNT NUMBER;
        
BEGIN
  
       -- insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_BLOB','1_'||in_JUNPYO_NO,sysdate,'in_JUNPYO_NO:'||in_JUNPYO_NO );
      --  commit;

        v_CNT :=0;
        SELECT COUNT(*)
        INTO v_CNT
        FROM SALE0402
        WHERE JUNPYO_NO = in_JUNPYO_NO
        AND SIGN_IMAGE IS NOT NULL
        ;
        IF v_CNT = 0 THEN       
                out_CODE := 999;
                out_MSG := '수금디테일에 수금사인정보없음';      
                RAISE ERROR_EXCEPTION;
        ELSIF v_CNT > 1 THEN
                out_CODE := 999;
                out_MSG := '수금디테일에 수금사인정보 너무 많음';      
                RAISE ERROR_EXCEPTION;
        END IF;
    
        out_COUNT := v_CNT;

        BEGIN
                OPEN out_RESULT FOR
                SELECT SIGN_IMAGE AS out_SIGN_IMAGE              
                FROM SALE0402              
                WHERE JUNPYO_NO = in_JUNPYO_NO
                ;
        EXCEPTION WHEN OTHERS THEN
                out_CODE := SQLCODE;
                out_MSG  := '사인로드실패:'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                RAISE ERROR_EXCEPTION;
        END;  
               
        out_CODE := 0;
        out_MSG := '수금 사인 이미지 로딩 완료';


EXCEPTION
        WHEN ERROR_EXCEPTION THEN 
                out_CODE := SQLCODE;
                out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                --insert into SFA_SP_CALLED_HIST    values ('SP_SFA_COLLECT_BLOB_OUT' ,in_JUNPYO_NO ,sysdate ,'[out_MSG1:'||out_MSG||']');
   
        WHEN OTHERS THEN
                out_CODE := SQLCODE;
                out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
               -- insert into SFA_SP_CALLED_HIST values ('SP_SFA_COLLECT_BLOB_OUT','1_'||in_JUNPYO_NO,sysdate,'[out_MSG1:'||out_MSG||']');
END;

/
