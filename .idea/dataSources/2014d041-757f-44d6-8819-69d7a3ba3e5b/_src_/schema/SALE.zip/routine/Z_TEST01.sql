CREATE PROCEDURE Z_TEST01 IS
tmpVar NUMBER;
/******************************************************************************
   NAME:       Z_TEST01
   PURPOSE:    

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        2014-11-28   kta       1. Created this procedure.

   NOTES:

   Automatically available Auto Replace Keywords:
      Object Name:     Z_TEST01
      Sysdate:         2014-11-28
      Date and Time:   2014-11-28, 오전 10:59:26, and 2014-11-28 오전 10:59:26
      Username:        kta (set in TOAD Options, Procedure Editor)
      Table Name:       (set in the "New PL/SQL Object" dialog)

******************************************************************************/
BEGIN
   tmpVar := 0;
   
  
   
   
   
   EXCEPTION
     WHEN NO_DATA_FOUND THEN
       NULL;
     WHEN OTHERS THEN
       -- Consider logging the error and then re-raise
       RAISE;
END Z_TEST01;

/
