CREATE PROCEDURE      SP_Z_FORE_COLLECT_LIST 
(
    in_SAWON_ID          IN  VARCHAR2,   
    in_CDT               IN  VARCHAR2,    --년도
    out_CODE             out NUMBER,
    out_MSG              out VARCHAR2,
    out_COUNT            out NUMBER,
    out_RESULT           out TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 판매수금예상실적등록
 호출프로그램 : 
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
    FROM ORAGMP.SLTARGETSALEM A
        ,ORAGMP.SLTARGETSALEM B
        ,(SELECT in_CDT || '-' || LPAD(LEVEL, 2, '0') YMD FROM DUAL A CONNECT BY LEVEL <= 12) C
    WHERE A.YEARMONTH LIKE ''||NVL(in_CDT ||'-', '%')||'%' 
      AND A.YEARMONTH = B.YEARMONTH(+)
      AND B.YEARMONTH = C.YMD(+)
      AND A.EMPCODE = in_SAWON_ID
      AND B.EMPCODE = in_SAWON_ID
      AND A.SALDIV = 'A'
      AND B.SALDIV = 'C'
      AND rownum = 1
    ;
    
    --insert into SFA_SP_CALLED_HIST values ('SP_Z_FORE_COLLECT_LIST','1',sysdate,'v_num:'||v_num|| 'in_CDT:'||in_CDT||'/in_SAWON_ID:'||in_SAWON_ID );
   
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
    
        OPEN out_RESULT FOR
        SELECT  C.YMD           AS out_YYYYMM 
                ,A.TARGETAMT    AS out_ATARGETAMT 
                ,A.SFAMT        AS out_ASFAMT 
                ,A.SALDIV       AS out_ASALDIV 
                ,A.CONFIRMYN    AS out_ACONFIRM
                ,B.TARGETAMT    AS out_CTARGETAMT
                ,B.SFAMT        AS out_CSFAMT
                ,B.SALDIV       AS out_CSALDIV
                ,B.CONFIRMYN    AS out_CCONFIRM
                ,A.EMPCODE      AS out_EMP_NO
            FROM ORAGMP.SLTARGETSALEM A
                ,ORAGMP.SLTARGETSALEM B
                ,(SELECT in_CDT || '-' || LPAD(LEVEL, 2, '0') YMD FROM DUAL A CONNECT BY LEVEL <= 12) C
           WHERE A.YEARMONTH LIKE ''||NVL(in_CDT ||'-', '%')||'%' 
             AND A.YEARMONTH = B.YEARMONTH(+)
             AND B.YEARMONTH = C.YMD(+)
             AND A.EMPCODE = in_SAWON_ID
             AND B.EMPCODE = in_SAWON_ID
             AND A.SALDIV = 'A'  --판매
             AND B.SALDIV = 'C'  --수금
           ORDER BY A.YEARMONTH;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
