CREATE PROCEDURE sale0306_load_temp 
--            ( O_MSG           OUT  VARCHAR2   -- 메시지
--) 
IS 
     T_UPDATE_CHK   NUMBER;
BEGIN
        for c1 in ( SELECT YMD,
                           CUST_ID,
                           RCUST_ID,
                           SAWON_ID,
                           SU_AMT,
                           MISU_AMT,
                           BEFORE_AMT
                      FROM sale0306_imsi)  Loop
                T_UPDATE_CHK := 0;
                BEGIN
                    SELECT NVL(before_amt,0)
                      INTO T_UPDATE_CHK
                      FROM SALE0306
                     WHERE YMD      = C1.YMD
                       AND CUST_ID  = C1.CUST_ID
                       AND RCUST_ID = C1.RCUST_ID;
                EXCEPTION
                        WHEN NO_DATA_FOUND THEN
                              INSERT INTO SALE0306
                                    (YMD,
                                     CUST_ID,
                                     RCUST_ID,
                                     SAWON_ID,
                                     SU_AMT,
                                     MISU_AMT,
                                     BEFORE_AMT)
                              VALUES
                                    (C1.YMD,
                                     C1.CUST_ID,
                                     C1.RCUST_ID,
                                     C1.SAWON_ID,
                                     C1.SU_AMT,
                                     C1.MISU_AMT,
                                     C1.BEFORE_AMT);
                        WHEN OTHERS THEN
                             IF T_UPDATE_CHK <> NVL(C1.BEFORE_AMT,0) THEN
                                raise_application_error( -20001, '중복 데이타 Err:'||TO_CHAR(C1.YMD,'YYYYMMDD')||'/'||C1.CUST_ID||'/'||C1.RCUST_ID ) ;                   
                             END IF;
                END;
        End Loop;                 
           --if SQL%NOTFOUND then
        COMMIT;
END  sale0306_load_temp ;


/
