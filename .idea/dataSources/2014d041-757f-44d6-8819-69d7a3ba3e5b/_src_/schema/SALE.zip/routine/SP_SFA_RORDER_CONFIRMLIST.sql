CREATE PROCEDURE      SP_SFA_RORDER_CONFIRMLIST   
(
    in_SAWON_ID          IN  VARCHAR2,    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    /*---------------------------------------------------------------------------
    프로그램명   : 간납처 주문내역 관련자 확인용 리스트조회
    호출프로그램 : 일일방문화면에서 내역이 있을때 팝업에서 호출된다.
    
    CHOE 20150513 추가 변경 사항 
    간납처 주문내역 이 100건 이상인 경우 과거 자료 부터 보이도록 해 준다.
    과거 자료 부터 개인이 등록 처리를 하고 최근 날짜로 등록 하도록 한다.      
    ---------------------------------------------------------------------------*/    

    v_num         NUMBER;
    v_SILSAWON_ID VARCHAR2(7);
    
BEGIN

    --실사원id를 찾는다.
    select sil_sawon_id into v_SILSAWON_ID from sale0007 where sawon_id = in_SAWON_ID;
    
    IF v_silsawon_id IS NULL OR v_silsawon_id = '' THEN
       out_CODE := 1;
       out_MSG := '사번 ' || in_SAWON_ID || ' 은 실사원아이디가 존재하지 않습니다. 관리자에게 문의 하십시오.';
       RETURN;
    END IF;

    -- 로그인한 사원의 납품처에 납품된 제품중 거래처별단가테이블에서 담당제품으로 주문된것들...
    SELECT COUNT(*)
      INTO v_num
      from sale0203 a
          ,sale0204 b
     where a.gumae_no = b.gumae_no
       --and a.ymd >= to_date('20140501','yyyymmdd')  --이날 이후로 간납처주문 발행사원,실사원확인여부 체크하기로 했음.
       and a.ymd >= ADD_MONTHS(SYSDATE, -3)  --CHOE 20140916 간납처주문내역을 확인하지 않는 경우가 많아 3달 까지만 표시 하도록 수정
       and a.cust_id <> a.rcust_id   
       and (a.sawon_id = v_silsawon_id or a.rsawon_id =   v_silsawon_id)
       and decode(a.sawon_id ,v_silsawon_id,a.confirm_sawon_yn,a.confirm_rsawon_yn) = 'N'
       ;
         
         
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDER_LIST','1',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'v_silsawon_id:'||v_silsawon_id );
--COMMIT;
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSIF  v_num > 50 THEN  --CHOE 20150415 확인 하지 않은 간납처 내역이 너무 많은 경우 시스템이 다운되는 것을 막는다.
        /*out_CODE := 1;
        out_MSG := '간납처 주문 내역이 너무 많아 표시 할수 없습니다. 본사로 연락해 주시기 바랍니다.';*/
        out_CODE := 0;
        out_MSG := '검색 완료';
        
        OPEN out_RESULT FOR
        SELECT A.GUMAE_NO AS out_GUMAE_NO
        ,A.YMD AS out_ORDER_DATE
        ,C.CUST_NM AS out_CUST_NM
        ,D.CUST_NM AS out_RCUST_NM
        ,F_ITEM_NM(B.ITEM_ID) AS out_ITEM_NM
        ,B.QTY AS out_QTY
        ,B.AMT+B.VAT AS out_AMOUNT              
        FROM SALE0203 A              
        ,SALE0204 B
        ,SALE0003 C
        ,SALE0003 D
        WHERE A.GUMAE_NO = B.GUMAE_NO
        AND A.CUST_ID = C.CUST_ID
        AND A.RCUST_ID = D.CUST_ID   
        AND A.YMD >= ADD_MONTHS(SYSDATE, -3)  --CHOE 20140916 간납처주문내역을 확인하지 않는 경우가 많아 3달 까지만 표시 하도록 수정  
        AND A.CUST_ID <> A.RCUST_ID
        AND (A.SAWON_ID = v_silsawon_id OR A.RSAWON_ID = v_silsawon_id)    
        AND DECODE(A.SAWON_ID ,v_silsawon_id ,A.CONFIRM_SAWON_YN , A.CONFIRM_RSAWON_YN) = 'N'  
        AND ROWNUM < 100   
        ORDER BY A.GUMAE_NO
        ;
    ELSE     
        out_CODE := 0;
        out_MSG := '검색 완료';    
    
        OPEN out_RESULT FOR
        select a.gumae_no              AS out_GUMAE_NO
              ,a.ymd                   AS out_ORDER_DATE
              ,c.cust_nm               AS out_CUST_NM
              ,d.cust_nm               AS out_RCUST_NM
              ,F_ITEM_NM(b.ITEM_ID)    AS out_ITEM_NM
              ,b.qty                   AS out_QTY
              ,b.amt + b.vat           AS out_AMOUNT
          from sale0203 a
              ,sale0204 b
              ,sale0003 c
              ,sale0003 d
         where a.gumae_no = b.gumae_no
           and a.cust_id  = c.cust_id
           and a.rcust_id = d.cust_id
           --and a.ymd     >= to_date('20140501','yyyymmdd')  --이날 이후로 간납처주문 발행사원,실사원확인여부 체크하기로 했음.
            and a.ymd >= ADD_MONTHS(SYSDATE, -3)  --CHOE 20140916 간납처주문내역을 확인하지 않는 경우가 많아 3달 까지만 표시 하도록 수정
           and a.cust_id <> a.rcust_id   
           and (a.sawon_id = v_silsawon_id or a.rsawon_id = v_silsawon_id)
           and decode(a.sawon_id ,v_silsawon_id,a.confirm_sawon_yn,a.confirm_rsawon_yn) = 'N';
           
       
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
