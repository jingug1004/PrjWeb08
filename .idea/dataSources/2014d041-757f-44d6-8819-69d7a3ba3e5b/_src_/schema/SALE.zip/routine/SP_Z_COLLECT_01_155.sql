CREATE PROCEDURE      SP_Z_COLLECT_01_155
(
    in_SAWON_ID      IN  VARCHAR2,   
    in_CDT_FR        IN  VARCHAR2,    
    in_CDT_TO        IN  VARCHAR2,    
    in_GUBUN         IN  VARCHAR2,    
    in_CUSTOMER_CODE IN  VARCHAR2,    
    out_CODE         OUT NUMBER,
    out_MSG          OUT VARCHAR2,
    out_COUNT        OUT NUMBER,
    out_RESULT       OUT TYPES.CURSOR_TYPE
)
IS
/*---------------------------------------------------------------------------
 프로그램명 : 수금현황
 호출프로그램 : 
 수정기록 : 
 - 20130218 kta 영수증재발행 버튼 추가관련 수정. 
 - 20150424 kta 수금사원 기준으로 조회되던것을 실제담당사원기준으로
                       조회되도록 변경 ( 도매 이승원부장이 팀원들과 거래처조정하면서
                       변경된 본인 거래처만 나오도록 요청 한 것임) - 윤홍주차장 확인.
 - 20150721 인수인계 이전 자료를 조회 가능하도록 수정 - 영업사원 김정원         
   2017.11.01 KTA - NEW ERP메 맞게 컨버젼       
   2018.01.31 KTA - 매출할인 수금할인 안보이게 수정
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_gubun              VARCHAR2(2);
    GUBUN_NULL           EXCEPTION;     
        
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_Z_COLLECT_01_155',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_SAWON_ID,sysdate ,'/in_GUBUN:'||in_GUBUN);
--commit;

        SELECT COUNT(*) 
          INTO v_num
          FROM ORAGMP.SLCOLM a 
         WHERE a.plantcode = '1000'
           AND a.STATEDIV  = '09'  -- 9:수금확정         
           AND a.coldiv       IN ('01','10','21','30','31','32','35')                
           AND a.coldiv       LIKE  decode(in_GUBUN,'00','%',in_GUBUN)  -- 01-현금입금 10-통장입금  21-신용카드 30-약속어음 31-가계수표 32-당좌수표 35-전자어음    --안보임  51-결손(대손) 52-매출할인  54-잔고정리  57-판매대행  99-기타            
           AND a.coldate   BETWEEN TO_CHAR(TO_DATE(in_CDT_FR,'YYYYMMDD'),'YYYY-MM-DD') AND TO_CHAR(TO_DATE(in_CDT_TO,'YYYYMMDD'),'YYYY-MM-DD')                               
           AND a.custcode     LIKE NVL(in_CUSTOMER_CODE, '%')||'%'                                 
           AND a.empcode         = in_SAWON_ID
           AND rownum = 1;  
    
    
        out_COUNT := v_num;
    
        IF v_num = 0 THEN
                out_CODE := 1;
                out_MSG := '조회한 내역이 존재하지 않습니다.';
        ELSE
            out_CODE := 0;
            out_MSG := '검색 완료';    


            OPEN out_RESULT FOR
                SELECT oragmp.fncommonnm ('CUST',a.custcode,'')  AS out_CUST_ID   --거래처
                      ,oragmp.fncommonnm ('CUST',a.ecustcode,'')  AS out_RCUST_ID  --수금거래처
                      ,a.colno                                 AS out_JUNPYO_NO --전표번호
                      ,decode(a.coldiv,'01',a.colamt,'10',a.colamt,0)        AS out_CASH_AMT  --현금수금액   01-현금입금, 10-통장입금 
                      ,decode(a.coldiv,'21',a.colamt,'30',a.colamt,'31',a.colamt,'32',a.colamt,'35',a.colamt,0)        AS out_CARD_AMT  --21-카드수금액 30-약속어음 31-가계수표, 32-당좌수표 35-전자어음
                      ,to_date(a.coldate,'yyyy-mm-dd')         AS out_COLL_DATE  --일자
                      ,a.cardcomp                              AS out_CARD_COMP --카드사    
                      ,a.cardno                                AS out_CARD_NO --카드번호  
                      ,a.expdate                               AS out_CARD_USE_PERIOD --유효기간 
                      ,a.cardokno                              AS out_CARD_ACCEPT_NO --승인번호  
                      ,a.bigo                                  AS out_BIGO   --비고   
                      ,a.divmonth                              AS out_CARD_ALLOTMENT --할부개월수
                      ,oragmp.fncommonnm('comm','SL18',a.coldiv)  AS out_CARD_BILL_GB --수금구분01-현금입금 10-통장입금 11-선수금(수출) 21-신용카드 30-약속어음 31-가계수표 32-당좌수표 35-전자어음 51-결손(대손) 52-매출할인 53-부도처리 54-잔고정리 55-잔고이월 57-판매대행 59-판매장려금 99-기타   
                      ,a.colamt                                AS out_COL_AMT  
                  FROM ORAGMP.SLCOLM a 
                 WHERE a.plantcode = '1000'
                   AND a.statediv  = '09'  -- 9:수금확정
                   AND a.coldiv       IN ('01','10','21','30','31','32','35')               
                   AND a.coldiv       LIKE  decode(in_GUBUN,'00','%',in_GUBUN)  -- 01-현금입금 10-통장입금  21-신용카드 30-약속어음 31-가계수표 32-당좌수표 35-전자어음  --안보임  51-결손(대손) 52-매출할인  54-잔고정리  57-판매대행  99-기타          
                   AND a.coldate   BETWEEN TO_CHAR(TO_DATE(in_CDT_FR,'YYYYMMDD'),'YYYY-MM-DD') AND TO_CHAR(TO_DATE(in_CDT_TO,'YYYYMMDD'),'YYYY-MM-DD')                               
                   AND a.custcode     LIKE NVL(in_CUSTOMER_CODE, '%')||'%'                                 
                   AND a.empcode         = in_SAWON_ID
                   AND a.empcode       = in_SAWON_ID            
                 ORDER BY a.colno
               ;
        END IF;
    
EXCEPTION
        WHEN GUBUN_NULL THEN
                out_CODE := 101;
                out_MSG := '구분코드가 누락되었습니다.'; 
        WHEN OTHERS THEN
                out_CODE := SQLCODE;
                out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
