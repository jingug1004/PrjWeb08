CREATE PROCEDURE      PROC_PDA_ORDER_DETAIL_ON
  (in_flag     IN  VARCHAR2 DEFAULT NULL,
  in_ymd       IN  date,
  in_GUMAE_NO  IN  VARCHAR2 DEFAULT NULL, 
  in_INPUT_SEQ IN  VARCHAR2 DEFAULT NULL, 
  in_ITEM_ID   IN  VARCHAR2 DEFAULT NULL, 
  in_QTY       IN  VARCHAR2 DEFAULT NULL, 
  in_DANGA     IN  VARCHAR2 DEFAULT NULL, 
  in_AMT       IN  VARCHAR2 DEFAULT NULL, 
  in_VAT       IN  VARCHAR2 DEFAULT NULL, 
  in_DC_AMT    IN  VARCHAR2 DEFAULT NULL,
  in_DC_QTY    IN  VARCHAR2 DEFAULT NULL, 
  in_DC_DANGA  IN  VARCHAR2 DEFAULT NULL
--  OUT_MSG      OUT VARCHAR2
  )
IS
  
N_COUNT      NUMBER := 0;
N_JAEGO      NUMBER := 0;
V_ITEM_NM    VARCHAR2(200);
v_use_yn     VARCHAR2(1);
v_chul_yn    VARCHAR2(1); 

V_ITEM_DANGA NUMBER := 0;
V_PSB_QTY    NUMBER := 0;
V_M_QTY      NUMBER := 0;
V_CUST_ID    VARCHAR2(10);

/*
  raise_application_error (-20000,'<' || V_ITEM_NM || ' 사용중지 중입니다.'|| '>' );
   -->해당문장을 PDA와 연동시 에러코드는 -20000D으로 약속하고 처리한다.   
*/

BEGIN 

insert into SFA_SP_CALLED_HIST values ('PROC_PDA_ORDER_DETAIL_ON','1',sysdate,  'in_GUMAE_NO'||in_GUMAE_NO);

N_JAEGO :=0;
if in_flag = 'I' then
    select  item_nm, use_yn, chul_yn , OUT_DANGA AS danga
    into V_ITEM_NM,v_use_yn, v_chul_yn, V_ITEM_DANGA
    from  sale.sale0004 
    where item_id = in_ITEM_ID;

    if v_use_yn != 'Y' then
        raise_application_error (-20000,'<' || V_ITEM_NM || ' 사용중지 중입니다.'|| '>' );
    end if;

    if v_chul_yn = 'Y' then
        raise_application_error (-20000,'<' || V_ITEM_NM || ' 출하중지 중입니다.'|| '>' );
    end if;

    ------2011 03 08 DangaCheck  -- jo

    if V_ITEM_DANGA != in_DANGA then
        raise_application_error (-20000,'<' || V_ITEM_NM || ' 제품정보 새로받기를 해주세요 '|| '>' );
    end if;

    ------

    select count(*) 
    into n_count
    from sale.sale0305 a , sale.sale0004 b
    where a.item_id = b.item_id
    and  ymd= to_char(sysdate, 'yyyyMM')||'01' and a.item_id = in_ITEM_ID
    and store_loc = '01' ;

    if n_count >0 then

    --재고 체크
    select NVL(before_qtys,0)+ NVL(IPGO_QTYS,0) - NVL(CHULGO_QTYS,0) - NVL(CHULGO_QTYST,0) + NVL(BANPUM_QTYS,0) as ajego_qtys,
           b.item_nm
      into N_JAEGO, V_ITEM_NM
      from sale.sale0305 a , sale.sale0004 b
     where a.item_id = b.item_id
       and  ymd= to_char(sysdate, 'yyyyMM')||'01' and a.item_id = in_ITEM_ID
       and store_loc = '01' ;
       
    end if;


    if N_JAEGO <  to_number(in_QTY) then
       raise_application_error (-20000,'<' || V_ITEM_NM || ' (' || N_JAEGO ||  ') | ' || in_ITEM_ID || ' 재고가 불충분 합니다'|| '>' );
    end if;

    --주문수량통제---------------------------------------------------------------------
    select CUST_ID
      into V_CUST_ID 
      from SALE_on.SALE0203
     where GUMAE_NO = in_GUMAE_NO;   

	--1.개시일자부터 3개월간은 주문수량 통과
	  SELECT COUNT(*)
	    INTO n_count
	    FROM SALE.SALE0003
	   WHERE CUST_ID = V_CUST_ID
		 AND in_ymd BETWEEN START_YMD AND ADD_MONTHS(START_YMD,3) ;		

      if n_count = 0 then
		 --2.해당월 20개까지는 주문수량 통과
		 --  향정제외(6****),아네폴빼고(43201,43215,43216,43217,43218,43256,43257) 

        SELECT ROUND(A.QTY * B.JLIMIT) - (C.MQTY + D.MQTY), C.MQTY + D.MQTY                
          INTO V_PSB_QTY, V_M_QTY
          FROM (
                  SELECT ROUND((NVL(SUM(B.QTY),0)/3)) QTY
                     FROM SALE.SALE0203 A, SALE.SALE0204 B
                    WHERE A.CUST_ID  = V_CUST_ID
                      AND A.YMD      < TO_DATE(SUBSTR(in_ymd,1,6)||'01') 
                      AND A.YMD      >= ADD_MONTHS(TO_DATE(SUBSTR(in_ymd,1,6)||'01') ,-3)
                      AND A.GUMAE_NO = B.GUMAE_NO 
                      AND B.ITEM_ID  = in_ITEM_ID
                 ) A,
                 (
                  SELECT (JUMUN_LIMIT /100) JLIMIT 
                    FROM SALE.SALE0003 
                   WHERE CUST_ID = V_CUST_ID
                 ) B,
                 (
                  SELECT NVL(SUM(B.QTY),0) MQTY
                     FROM SALE.SALE0203 A, SALE.SALE0204 B
                    WHERE A.CUST_ID  = V_CUST_ID
                      AND A.YMD      >= TO_DATE(SUBSTR(in_ymd,1,6)||'01')  
                      AND A.YMD      <= LAST_DAY(SUBSTR(in_ymd,1,6)||'01') 
                      AND A.GUMAE_NO = B.GUMAE_NO 
                      AND B.ITEM_ID  = in_ITEM_ID
                 ) C,
                 (
                  SELECT NVL(SUM(B.QTY),0) MQTY
                     FROM SALE_ON.SALE0203 A, SALE_ON.SALE0204 B
                    WHERE A.CUST_ID    = V_CUST_ID
                      AND A.YMD        >= TO_DATE(SUBSTR(in_ymd,1,6)||'01')  
                      AND A.YMD        <= LAST_DAY(SUBSTR(in_ymd,1,6)||'01') 
                      AND A.GUMAE_NO   = B.GUMAE_NO 
                      AND A.RECEIPT_GB = '1' --접수 
                      AND B.ITEM_ID    = in_ITEM_ID
                 ) D;

		  /*if SUBSTR(in_ITEM_ID,1,1) = '6' then
             if TO_NUMBER(in_QTY) >  NVL(V_PSB_QTY,0) then      
                --OUT_MSG := '< '|| V_ITEM_NM || ' (' || in_ITEM_ID || ') 의 주문한도수량이 ' || TO_CHAR(TO_NUMBER(in_QTY) - NVL(V_PSB_QTY,0)) ||
                --          'EA 초과되어, 반려될 수 있습니다. 신규품목의 경우 관리부로 문의 바랍니다.'||'>';
                raise_application_error(-20000,'< '|| V_ITEM_NM || ' (' || in_ITEM_ID || ') 의 주문한도수량이 ' || TO_CHAR(TO_NUMBER(in_QTY) - NVL(V_PSB_QTY,0)) ||
                                               'EA 초과되었습니다. 수량을 조정하여 재 입력 바랍니다. 신규품목의 경우 관리부로 문의 바랍니다.'||'>');
             end if;
          else
			 if (TO_NUMBER(in_QTY) + V_M_QTY) > 20 then
                 if TO_NUMBER(in_QTY) >  NVL(V_PSB_QTY,0) then      
                    --OUT_MSG := '< '|| V_ITEM_NM || ' (' || in_ITEM_ID || ') 의 주문한도수량이 ' || TO_CHAR(TO_NUMBER(in_QTY) - NVL(V_PSB_QTY,0)) ||
                    --          'EA 초과되어, 반려될 수 있습니다. 신규품목의 경우 관리부로 문의 바랍니다.'||'>';
                    raise_application_error(-20000,'< '|| V_ITEM_NM || ' (' || in_ITEM_ID || ') 의 주문한도수량이 ' || TO_CHAR(TO_NUMBER(in_QTY) - NVL(V_PSB_QTY,0)) ||
                                                   'EA 초과되었습니다. 수량을 조정하여 재 입력 바랍니다. 신규품목의 경우 관리부로 문의 바랍니다.'||'>');
                 end if;
             end if;
          end if;*/
          
        /* CHOE 20111208  위쪽에 내용 막고 아래로 변경 요청 BY 윤홍주 c
           항정 품목에 대해서 조건 검색하여 오류를 내보내던 것을 다른 품목들과 동일하게 수량 검색 조건만 적용  
        */  
          if (TO_NUMBER(in_QTY) + V_M_QTY) > 20 then
                 if TO_NUMBER(in_QTY) >  NVL(V_PSB_QTY,0) then      
                    --OUT_MSG := '< '|| V_ITEM_NM || ' (' || in_ITEM_ID || ') 의 주문한도수량이 ' || TO_CHAR(TO_NUMBER(in_QTY) - NVL(V_PSB_QTY,0)) ||
                    --          'EA 초과되어, 반려될 수 있습니다. 신규품목의 경우 관리부로 문의 바랍니다.'||'>';
                    raise_application_error(-20000,'< '|| V_ITEM_NM || ' (' || in_ITEM_ID || ') 의 주문한도수량이 ' || TO_CHAR(TO_NUMBER(in_QTY) - NVL(V_PSB_QTY,0)) ||
                                                   'EA 초과되었습니다. 수량을 조정하여 재 입력 바랍니다. 신규품목의 경우 관리부로 문의 바랍니다.'||'>');
                 end if;
          end if;
          
      end if;
        
       
    INSERT INTO SALE_ON.SALE0204 (
       YMD, GUMAE_NO, INPUT_SEQ, 
       ITEM_ID, QTY, DANGA, 
       AMT, VAT,
       BALJU_YN, CHULGO_YN) 
    VALUES (in_YMD, in_GUMAE_NO, LPAD(in_INPUT_SEQ,4,'0'), 
       in_ITEM_ID, in_QTY, in_DANGA, 
       in_AMT, in_VAT, 
       'N', 'N') ;
    
    
    -- 재고 업데이트
    update sale.sale0305
    set chulgo_qtyst = nvl(chulgo_qtyst,0) + in_qty
    where ymd = to_char(sysdate, 'yyyyMM')||'01'
          and store_loc = '01' and item_id = in_ITEM_ID;
        
        
     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패  INSERT INTO SALE.SALE0401');
            ROLLBACK;
            return;
     END IF;
else
    
   dbms_output.put_line('update'  );
        UPDATE SALE.SALE0204
        SET    YMD       = in_YMD,
               GUMAE_NO  = in_GUMAE_NO,
               INPUT_SEQ =  LPAD(in_INPUT_SEQ,4,'0'),
               ITEM_ID   = in_ITEM_ID,
               QTY       = in_QTY,
               DANGA     = in_DANGA,
               AMT       = in_AMT,
               VAT       = in_VAT,
               DC_AMT    = in_DC_AMT,       
               DC_QTY    = in_DC_QTY,
               DC_DANGA  = in_DC_DANGA
        WHERE  YMD       = in_YMD
        AND    GUMAE_NO  = in_GUMAE_NO
        AND    INPUT_SEQ = in_INPUT_SEQ
        AND    ITEM_ID   = in_ITEM_ID;
 
    
    IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패 UPDATE SALE.SALE0203');
            ROLLBACK;
            return;
    END IF;
 
end if;
        
end;

/
