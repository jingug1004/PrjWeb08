CREATE function F_GET_MATERIAL_FINALJAEGO
        ( a_material_id VARCHAR2  -- 재고 확인할 원부자재 코드
        )
   RETURN number
AS
   user_err     exception   ;
   v_curr_jakup varchar2(100) ;
   v_curr_error varchar2(100) ;
   v_message    varchar2(250) ;

   v_rtn_value   number := 0;
   
   v_ymd         varchar2(8) ;
   v_material_id varchar2(10) ;
   v_count       Number ;
   v_dummy       varchar2(20) ;
BEGIN
  
    Begin
        v_rtn_value := 0 ;
        v_material_id := LTRIM(RTRIM(a_material_id)) ;
        
        If NVL(v_material_id, ' ') = ' ' Then
           goto the_end;
        End if ;
                
        SELECT NVL(MAX(ymd), ' ')
          INTO v_ymd
          FROM INV0402  /* 일계 */
         WHERE ymd > ' ' 
           AND MATERIAL_ID = v_material_id ;
        If NVL(v_ymd, ' ') = ' ' Then
           goto the_end;
        End if ;
                   
        SELECT  NVL(SUM(A.IPGO_QTY),0) - NVL(SUM(A.CHULGO_QTY),0)
          INTO  v_rtn_value
          FROM ( SELECT NVL(SUM(A.IPGO_QTY),0)   IPGO_QTY,   
                        NVL(SUM(A.CHULGO_QTY),0) CHULGO_QTY
                   FROM INV0403 A  /* 월계 */
                  WHERE A.yyyymm      >= SUBSTRB(v_ymd ,1,4)||'00'
                    AND A.yyyymm      <  SUBSTRB(v_ymd ,1,6)
                    AND A.MATERIAL_ID =  v_material_id
                 UNION ALL
                 SELECT NVL(SUM(A.IPGO_QTY),0)   IPGO_QTY,   
                        NVL(SUM(A.CHULGO_QTY),0) CHULGO_QTY
                   FROM INV0402 A  /* 일계 */
                  WHERE A.ymd         >= SUBSTRB(v_ymd,1,6)||'01'
                    AND A.ymd         <= v_ymd
                    AND A.MATERIAL_ID = v_material_id
                  GROUP BY A.MATERIAL_ID
               ) A   ;
           
        <<the_end>>
        RETURN v_rtn_value;

    EXCEPTION WHEN user_err THEN
                   RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_jakup||v_curr_error,1,250));
              WHEN OTHERS THEN
                   RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_jakup||v_curr_error||SQLERRM,1,250));
    END ;
    
END;



/
