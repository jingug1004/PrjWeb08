CREATE PROCEDURE      SP_SFA_VISIT_04_113  
(
    in_PROCESS           IN  VARCHAR2,    --2.신규등록,3- 출,퇴,경 입력 4. 삭제
    in_SALES_PLAN_NO     IN  VARCHAR2,    -- 방문날짜
    in_SAWON_ID          IN  VARCHAR2,    -- 사원 ID
    in_DETAIL_PLAN_NO    IN  NUMBER,      -- 방문순번
    in_DEPT_NO           IN  VARCHAR2,    -- 부서코드
    in_SFA_SALES_SEQ     IN  NUMBER,      -- SFA거래처KEY컬럼
    in_SFA_CLIENT_NO     IN  NUMBER,      -- 거래처별 고객 순번
    in_DESCRIPTION       IN  VARCHAR2,    -- 방문목적
    in_VISIT_KIND        IN  VARCHAR2,    -- 방문종류(0-계획방법,1-추가방문,2-출퇴경유)
    in_GPS_NUM1          IN  VARCHAR2, 
    in_GPS_NUM2          IN  VARCHAR2,
    in_CALL_ADDR         IN  VARCHAR2,   --CHOE 2012114 call 주소 저장
    in_FAKEGPS_YN        IN  VARCHAR2,   --위치속이는 프로그램설치유무
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 방문계획 등록 
 호출프로그램 :일일방문콜, 출퇴경등록
 수정내역     -팀장이 승인하면 자동승인되도록 처리함-팀장의 승인을 본부장 또는 총괄팀장이 하는 관계로... 
               이주의 방문계획은 전주에 모두 세우도록 클라이언트에서 처리하여 이곳에 있는 채크들은 막음.
              -1.1.3버전:2013.03.06 kta
               :회사에서 규제하는 앱이 설치되어 있는지 채크한다.(예를 들면 fakegps같은)
                채크할 앱이름을 공통코드에(code_gb='0069') 넣고 로그인시 sfa에 공통변수에 저장하여 출근처리시 채크시 존재유무 들어옴)    
  115 버전으로대체                
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_plan_no            NUMBER;
    v_PLAN_DT            VARCHAR2(8); --방문날짜:새벽퇴근때문에 필요 
    v_CALL_DTM           VARCHAR2(14); --콜시간:새벽퇴근때문에 필요 
    V_ASSGN_CD           VARCHAR2(5); --팀장여부 
    V_APPLY_YN           VARCHAR2(1); --승인여부 : 팀장계획은 자동승인처리하기 위함.
    
    v_pre_gps_num1       NUMBER; --직전 콜이 경유지일때 좌표위도 
    v_pre_gps_num2       NUMBER; --직전 콜이 경유지일때 좌표경도
    v_distince           NUMBER; --직전콜과의직선거리 
    v_sfa_sales_seq      NUMBER; --직전콜과의직선거리
    
    PROCESS_NULL         EXCEPTION;
    SAWON_ID_NULL        EXCEPTION;
    SFA_SALES_SEQ_NULL   EXCEPTION;
    SFA_CLIENT_NO_NULL   EXCEPTION;
    DESCRIPTION_NULL     EXCEPTION;
    ERROR_EXCEPTION      EXCEPTION;
        
BEGIN

    IF in_PROCESS IS NULL OR TRIM(in_PROCESS) = '' THEN
        RAISE PROCESS_NULL;
    END IF;
    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
        RAISE SAWON_ID_NULL;
    END IF;  
    IF in_SFA_SALES_SEQ IS NULL OR in_SFA_SALES_SEQ = 0  THEN
        RAISE SFA_SALES_SEQ_NULL;
    END IF;  
      
    out_CODE := 1;
    out_MSG := '조회한 내역이 존재하지 않습니다.';


    SELECT NVL(MAX(DETAIL_PLAN_NO+1),0)
      INTO v_plan_no
      FROM SFA_VISIT_PLANACT
     WHERE SALES_PLAN_NO = in_SALES_PLAN_NO 
     --AND EMP_NO = in_SAWON_ID  --야간에 푼다.
    ;
         
    IF v_plan_no IS NULL OR v_plan_no = 0 THEN
        v_plan_no := 1;
    END IF;
           
    --퇴근시간때문에 ..
    v_PLAN_DT  := in_SALES_PLAN_NO;         
    v_CALL_DTM := to_char(SYSDATE,'YYYYMMDDHH24MISS');
       
    IF in_PROCESS = '2' THEN    -- 방문계획등록
    
        IF in_SFA_CLIENT_NO IS NULL OR in_SFA_CLIENT_NO = 0 THEN
            RAISE SFA_CLIENT_NO_NULL;
        END IF;  
        
        
        --계획방법으로 등록하는 경우 당일의 방문계획은 시간체크
        /*이 부분로직은 방문계획은 한주 전에 세워야 한다는 규정에 의해 막음. 클라이언트화면에서 수정된 로직처리.
        IF TO_CHAR(SYSDATE,'YYYYMMDD') = in_SALES_PLAN_NO AND in_VISIT_KIND    = '0' THEN
           --방문계획은 오전 9시까지만 가능합니다.
            IF TO_CHAR(SYSDATE,'HH24') > '08' THEN                       
                out_MSG := '등록실패 : 서버시간은 '||TO_CHAR(SYSDATE,'HH24')||' 시 입니다. 당일의 방문계획은 오전9시 까지만 가능합니다.';
                RAISE ERROR_EXCEPTION;                          
            END IF; 
            
         END IF;    
        */
        --계획방문의 건수는 하루 25개 이하로 한다.
        v_num := 0;
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_VISIT_PLANACT
         WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
           AND EMP_NO        = in_SAWON_ID
           AND VISIT_KIND    = '0'  --방문종류(0-계획방법,1-추가방문,2-출퇴경유)
           ; 
        IF v_num > 25 THEN
            out_MSG := '방문계획은 하루에 25 개 까지만 가능합니다.';
            RAISE ERROR_EXCEPTION;
        END IF;        
          
        --방문종류가 추가방문인 경우 하루 3번까지만 허용한다.
        v_num := 0;
        SELECT COUNT(*)
          INTO v_num
          FROM SFA_VISIT_PLANACT
         WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
           AND EMP_NO        = in_SAWON_ID
           AND VISIT_KIND    = '1'  --방문종류(0-계획방법,1-추가방문,2-출퇴경유)
           ; 
        IF v_num > 4 THEN
            out_MSG := '추가방문은 하루에 다섯번 번까지만 가능합니다.';
            RAISE ERROR_EXCEPTION;
        END IF;
        
        --팀장여부
        SELECT ASSGN_CD INTO V_ASSGN_CD
          FROM HR_HC_EMPBAS_0  
         WHERE EMP_NO  = (SELECT INSA_SAWON_ID FROM SALE0007 WHERE SAWON_ID = in_SAWON_ID AND GUBUN = 'Y');

        --팀장이 계획을 세우면 자동승인처리한다.
        IF V_ASSGN_CD = '27030' THEN
           V_APPLY_YN := 'Y';
        ELSE
           V_APPLY_YN := 'N';
        END IF;
                
        -- 방문계획등록
        INSERT INTO  SFA_VISIT_PLANACT (
                        SALES_PLAN_NO, EMP_NO,          DETAIL_PLAN_NO    ,DEPT_NO        ,   SFA_SALES_SEQ    ,
                        SFA_CLIENT_NO, DESCRIPTION    ,    TOGETHER_YN    ,TOGETHER_EMP_NO,   APPLY_YN    ,
                        STATUS       , GPS_NUM1    ,    GPS_NUM2,       EMP_CALL_DTM    ,   ACTIVITY_CODE    ,
                        ACTIVITY_DESC, MAIN_ITEM1    ,    MAIN_ITEM2    ,       
                        MAIN_ITEM3   , VISIT        ,       VISIT_KIND    ,
                        ACTIVITY_YN  , CALL_YN,   CALL_ADDR,FAKEGPS_YN )

               VALUES(in_SALES_PLAN_NO, in_SAWON_ID,       v_plan_no,    in_DEPT_NO,         in_SFA_SALES_SEQ,     
                      in_SFA_CLIENT_NO, in_DESCRIPTION,    'N',          '',                V_APPLY_YN, 
                       '00',            '',                '',           '',                '',
                       '',              '',            '',                 
                       '',              'N',       in_VISIT_KIND,
                       'N',             'N',       in_CALL_ADDR,in_FAKEGPS_YN);
           
        -- SFA_VISIT_PLAN 은 날자/사원별 존재한다.
        out_CODE := 0;
        out_MSG := '요청하신 작업이 처리되었습니다.';   
             
        
        
        
    --출근,퇴근,경유를 처리한다.    
    ELSIF in_PROCESS = '3' THEN   -- 출근/경유/퇴근

        IF in_DESCRIPTION IS NULL OR TRIM(in_DESCRIPTION) = '' THEN
            RAISE DESCRIPTION_NULL;
        END IF;          

        out_CODE := 0;
        out_MSG := '요청하신 작업이 처리되었습니다.';        
    
        IF in_SFA_SALES_SEQ = 1 THEN  --출근지입력 
            SELECT COUNT(*)
            INTO v_num
             FROM SFA_VISIT_PLANACT
             WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
               AND EMP_NO =in_SAWON_ID
               AND SFA_SALES_SEQ = 1
               ;
           IF v_num > 0 THEN
                out_MSG := '이미 출근처리를 하였습니다.';
                RAISE ERROR_EXCEPTION;
           END IF;
           

         SELECT COUNT(*)
           INTO v_num
           FROM SFA_VISIT_PLANACT
          WHERE SALES_PLAN_NO=in_SALES_PLAN_NO
               AND EMP_NO =in_SAWON_ID
               AND SFA_SALES_SEQ = 3
               ; 
           IF v_num > 0 THEN
                out_MSG := '퇴근 처리되어 출근 처리를 할수 없습니다.';
                RAISE ERROR_EXCEPTION;
           END IF;            
          
        ELSIF in_SFA_SALES_SEQ = 2 THEN  --경유지 처리
            v_num := 0;
            SELECT COUNT(*)
              INTO v_num
              FROM SFA_VISIT_PLANACT
             WHERE SALES_PLAN_NO=in_SALES_PLAN_NO
               AND EMP_NO =in_SAWON_ID
               AND SFA_SALES_SEQ = 3
            ;
            IF v_num > 0 THEN
                out_MSG := '퇴근 처리되어 경유처리를 할수 없습니다.';
                RAISE ERROR_EXCEPTION;
            END IF;
                            
            --1일 경유지는 3개까지만 처리가능
            v_num := 0;
            SELECT COUNT(*)
            INTO v_num
            FROM SFA_VISIT_PLANACT
            WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
               AND EMP_NO = in_SAWON_ID
               AND SFA_SALES_SEQ = 2
            ; 
            IF v_num > 2 THEN
                out_MSG := '경유지처리는 하루에 3번까지만 가능합니다.';
                RAISE ERROR_EXCEPTION;
            END IF;          
            
            --'첫콜(출근콜 바로 다음콜)은 경유지 못하도록 처리
            v_num := 0;
            SELECT COUNT(*)
              INTO v_num
              FROM SFA_VISIT_PLANACT A
             WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
               AND EMP_NO  = in_SAWON_ID
               AND CALL_YN = 'Y'
            ;
            IF v_num = 1 then --콜이1개인경우일때만 두번째콜 체크진행 
                --바로이전콜이 출근인경우 경유처리 불가
                v_sfa_sales_seq := 0;
                SELECT SFA_SALES_SEQ
                  INTO v_sfa_sales_seq
                  FROM SFA_VISIT_PLANACT A
                 WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
                   AND EMP_NO  = in_SAWON_ID
                   AND CALL_YN = 'Y'                       
                ;
                IF v_sfa_sales_seq = 1 THEN  --출근콜이 가장 최근의 콜인경우
                    out_MSG := '첫콜(출근콜 바로 다음콜)은 경유처리를 할수 없습니다.';
                    RAISE ERROR_EXCEPTION;
                END IF;     
            END IF;
                
            --이전콜이 경유지인경우 이전경유지와의 거리가 1000 미터 이내이면 불가처리
            --오늘 본인의 콜중 바로전의 콜이  경유지일때 좌표를 가져온다.            
            v_pre_gps_num1 := 0;
            v_pre_gps_num2 := 0;
            SELECT  /*+ INDEX_DESC(A IDX_SFA_VISIT_PLANACT_01) */
                   GPS_NUM1,GPS_NUM2
              INTO v_pre_gps_num1,v_pre_gps_num2
            FROM SFA_VISIT_PLANACT A
            WHERE A.SALES_PLAN_NO  = in_SALES_PLAN_NO
              AND A.EMP_NO         = in_SAWON_ID
              AND A.CALL_YN        = 'Y'
              AND A.EMP_CALL_DTM > ' '   --인덱스를 사용하려면 반드시 있어야 함.
              AND ROWNUM = 1      --콜시간을 인덱스역순으로 잡았으므로 1개만 가져오면 최종콜한 시간임.                   
            ;
            IF v_pre_gps_num1 > 0 THEN  
               --거리계산
               v_distince := F_SFA_DISTANCE(v_pre_gps_num1,v_pre_gps_num2,to_number(in_GPS_NUM1),to_number(in_GPS_NUM2)) * 1000;
                    
               --거리가 1000 미터가 넘는지 확인
               IF v_distince < 1000 THEN
                   out_CODE := 1;
                   out_MSG  := '바로 이전 콜이 경유지이며 거리가 1KM 이내 이므로 경유지 등록은 불가합니다.';                              
                   RETURN;
               END IF;
            END IF; 
                

        ELSIF in_SFA_SALES_SEQ = 3 THEN  --퇴근처리 
        
            --이전콜이 경유지인경우 퇴근콜 불가 
            v_sfa_sales_seq := 0;
            SELECT /*+ INDEX_DESC(A IDX_SFA_VISIT_PLANACT_01) */
                   SFA_SALES_SEQ
              INTO v_sfa_sales_seq
              FROM SFA_VISIT_PLANACT A
             WHERE SALES_PLAN_NO = in_SALES_PLAN_NO
               AND EMP_NO  = in_SAWON_ID
               AND CALL_YN = 'Y'   
               AND EMP_CALL_DTM > ' '         
               AND ROWNUM = 1          
            ;
            IF v_sfa_sales_seq = 2 THEN  -- 경유지
                out_MSG := '퇴근콜 이전의 콜이 경유지인 경우 퇴근콜 처리를 할수 없습니다.';
                RAISE ERROR_EXCEPTION;
            END IF;

            --퇴근시간이 다음날 오전 6 시 이전인경우엔 방문일짜를 전날짜로 변경
            IF TO_CHAR(SYSDATE,'HH24') >= '00' AND TO_CHAR(SYSDATE,'HH24') < '06' THEN
                       
              SELECT TO_CHAR(TO_DATE(in_SALES_PLAN_NO,'YYYYMMDD') - 1,'YYYYMMDD') INTO v_PLAN_DT FROM DUAL; 
              v_CALL_DTM := v_PLAN_DT||'115959';
                          
            ELSE
              v_PLAN_DT  := in_SALES_PLAN_NO;
              v_CALL_DTM := to_char(SYSDATE,'YYYYMMDDHH24MISS');
            END IF;  
                  
            SELECT COUNT(*)
             INTO v_num
             FROM SFA_VISIT_PLANACT
            WHERE SALES_PLAN_NO = v_PLAN_DT
              AND EMP_NO   = in_SAWON_ID
              AND SFA_SALES_SEQ = 3;
            IF v_num > 0 THEN
                out_MSG := '이미 퇴근 처리되었습니다.';
                RAISE ERROR_EXCEPTION;
            END IF;
            
        END IF;       
         
     /*
     insert into SFA_SP_CALLED_HIST
    values ('SP_SFA_VISIT_04',in_PROCESS,sysdate,'in_SALES_PLAN_NO:'||in_SALES_PLAN_NO||'/in_SAWON_ID:'||in_SAWON_ID||'/in_DETAIL_PLAN_NO:'||in_DETAIL_PLAN_NO||'/in_DEPT_NO:'||in_DEPT_NO||'/in_SFA_SALES_SEQ:'||in_SFA_SALES_SEQ);
    */
         -- 방문계획등록
            INSERT INTO  SFA_VISIT_PLANACT (
                            SALES_PLAN_NO,    EMP_NO,          DETAIL_PLAN_NO    ,DEPT_NO        ,   SFA_SALES_SEQ    ,
                            SFA_CLIENT_NO,    DESCRIPTION    ,    TOGETHER_YN    ,TOGETHER_EMP_NO,   APPLY_YN    ,
                            STATUS        ,   GPS_NUM1    ,    GPS_NUM2,       EMP_CALL_DTM    ,   ACTIVITY_CODE    ,
                            ACTIVITY_DESC,  MAIN_ITEM1    ,    MAIN_ITEM2    ,       
                            MAIN_ITEM3    ,VISIT        ,       VISIT_KIND    ,
                            ACTIVITY_YN    ,   CALL_YN  ,    CALL_ADDR ,FAKEGPS_YN)

                   VALUES(v_PLAN_DT , in_SAWON_ID,       v_plan_no,    in_DEPT_NO,         in_SFA_SALES_SEQ,     
                           '',in_DESCRIPTION,    'N',          '',                '', 
                           '00',            in_GPS_NUM1,          in_GPS_NUM2,  v_CALL_DTM,                '',
                           '',              '',            '',                 
                           '',                 '',       in_VISIT_KIND,
                           '',              'Y',       in_CALL_ADDR ,in_FAKEGPS_YN);
              
              
    ELSIF in_PROCESS = '4' THEN   -- 삭제한다.
       -- 오늘날자것만 삭제한다.
       out_CODE := 0;
        out_MSG := '3 요청하신 작업이 처리되었습니다.';   
    
        --    DELETE FROM SFA_VISIT_PLANACT
        --     WHERE SALES_PLAN_NO = in_CDT
        --       AND DETAIL_PLAN_NO= in_DETAIL_PLAN_NO
        --       AND EMP_NO = in_SAWON_ID;
    END IF ;                           
     
    
    DBMS_OUTPUT.PUT_LINE('003--->in_PROCESS'||in_PROCESS );
    
EXCEPTION
WHEN PROCESS_NULL THEN
   out_CODE := 101;
   out_MSG := '구분코드가 누락되었습니다.'; 
WHEN SAWON_ID_NULL THEN
   out_CODE := 102;
   out_MSG := '사원 ID가 누락되었습니다.'; 
WHEN SFA_SALES_SEQ_NULL THEN
   out_CODE := 103;
   out_MSG := '거래처가 누락되었습니다.'; 
WHEN SFA_CLIENT_NO_NULL THEN
   out_CODE := 104;
   out_MSG := '고객이 누락되었습니다.';  
WHEN DESCRIPTION_NULL THEN
   out_CODE := 105;
   out_MSG := '비고가 누락되었습니다.';  
   
WHEN ERROR_EXCEPTION THEN
   out_CODE := 1;
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
   DBMS_OUTPUT.PUT_LINE('003--->out_MSG'||out_MSG );
END;

/
