CREATE PROCEDURE      SP_Z_OFFICE_01_102
(   
    in_SAWON_ID          IN  VARCHAR2, --영업사번
    in_STR_DT            IN  VARCHAR2,
    in_END_DT            IN  VARCHAR2,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 공지사항조회 
 호출프로그램 : 오피스> 공지사항
 수정기록     2015.05.28 -새로 개발한 hanagw 의 게시판을 조회하도록 수정    
          2017.11.01  KTA - NEW ERP메 맞게 컨버젼
       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;  
    
BEGIN
    
    --로그인사번에게 온 공지 
   SELECT count(*)
     INTO v_num
     FROM ( SELECT noticeid
                  ,title
                  ,noticecontents
                  ,noticedate
                  ,(SELECT DECODE (SIGN (COUNT (*)), 1, 'Y', 'N') FROM ORAGMP.NOTICEMANAGEREADHIST WHERE noticeid = a.noticeid AND readloginid = in_SAWON_ID ) READ_YN
              FROM ORAGMP.NOTICEMANAGE a 
             WHERE SFA = 'Y' 
           );
            
       
    out_COUNT := v_num; 
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '공지사항이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '공지사항 정보 확인완료';    
         
        OPEN out_RESULT FOR
              
               SELECT noticeid                      AS out_BOARD_ID     -- 공지사항 ID
                     ,ROWNUM                        AS out_BOARD_SEQ    -- 공지 번호(SEQ)
                     ,title                         AS out_TITLE        -- 공지 제목
                     ,noticecontents                AS out_DISCRIPTION  -- 공지 내용
                     ,replace(noticedate,'-','')    AS out_START_DATE   -- 공지 시작일
                     ,READ_YN                       AS out_READ_YN      -- 읽었는지여부
                 FROM (
                        SELECT noticeid
                              ,title
                              ,noticecontents
                              ,noticedate
                              ,(SELECT DECODE (SIGN (COUNT (*)), 1, 'Y', 'N') FROM ORAGMP.NOTICEMANAGEREADHIST WHERE noticeid = a.noticeid AND readloginid = in_SAWON_ID ) READ_YN
                          FROM ORAGMP.NOTICEMANAGE a 
                         WHERE SFA = 'Y' 
                      )   
                 order by noticedate desc;   
         
    END IF;
         
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
