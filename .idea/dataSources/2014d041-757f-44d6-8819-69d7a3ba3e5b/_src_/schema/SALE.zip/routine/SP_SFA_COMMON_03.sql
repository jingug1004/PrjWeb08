CREATE PROCEDURE      SP_SFA_COMMON_03 
(
    in_GUBUN             IN  NUMBER,   -- 1:코드, 2:부서명. DEFAULT 2:부서명 설정.
    in_ITEM              IN  VARCHAR2,  -- 부서명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 부서 검색 팝업
 호출프로그램 :       
 ---------------------------------------------------------------------------*/   
    v_num                NUMBER;
    
BEGIN 

    
    SELECT COUNT(*)
      INTO v_num
      FROM SALE0008
     WHERE DEPT_NM    LIKE '%'||NVL(in_ITEM, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT DEPT_CD                                AS out_DEPT_CD,    -- 부서코드
               DEPT_NM                                AS out_DEPT_NM    -- 부서명
          FROM SALE0008
         WHERE DEPT_NM    LIKE '%'||NVL(in_ITEM, '%')||'%'
         ORDER BY DEPT_NM;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
