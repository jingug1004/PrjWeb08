CREATE PROCEDURE      SP_SFA_WIBANORDER_CONF
 (
  in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(승인:1,반려:2)
  in_SAWON_ID           IN VARCHAR2 default NULL,
  in_COUNT              IN NUMBER,
  in_DATASET            IN VARCHAR2 default NULL,
  out_CODE              OUT NUMBER,
  out_MSG               OUT VARCHAR2       
  )
IS
 /*---------------------------------------------------------------------------
 프로그램명   :  위반 주문 승인체크한거  업데이트
 호출프로그램 : 일일방문 간납처주문내역 확인 팝업화면에서 체크후 확인버튼시        
 수정기록     :               
 ---------------------------------------------------------------------------*/
 
    v_gumae_no  VARCHAR2(12); 
    v_item_id   VARCHAR2(10);
    v_qty       NUMBER;
    
    ERROR_RAISE EXCEPTION;
    
BEGIN  

     --insert into SFA_SP_CALLED_HIST values ('SP_SFA_RORDER_CONFIRM','s',sysdate,'in_DATASET:'||in_DATASET||' /in_COUNT:'||to_char(in_COUNT));        

    FOR ll_loop IN 1.. in_COUNT LOOP  

       v_gumae_no  := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 1 + 12*(ll_loop -1),  12));   
       
       IF in_BTN_GUBUN = 1 THEN            
          update sale_on.sale0203 set wiban_order_conf_yn = '1',wiban_conf_dtm = sysdate where gumae_no = v_gumae_no; --승인
       ELSE
          update sale_on.sale0203 set wiban_order_conf_yn = '2',wiban_conf_dtm = sysdate where gumae_no = v_gumae_no; --반려

          
          --주문상세삭제 --삭제된주문에 대한 모든  제품의 수량을 SALE0305 의 에 반영시킨다.
          DECLARE CURSOR Cur_1 IS    
             SELECT ITEM_ID,QTY    
               FROM SALE_ON.SALE0204
              WHERE GUMAE_NO = v_gumae_no;
          BEGIN               
                FOR cur IN Cur_1 LOOP 
                    v_item_id  := cur.ITEM_ID;
                    v_qty      := cur.QTY;
                                 
                    --온라인주문용출고수량에 빼준다
                    BEGIN
                        UPDATE sale.sale0305
                           SET chulgo_qtyst = nvl(chulgo_qtyst,0) - v_qty
                         WHERE ymd       = to_date(to_char(sysdate, 'yyyymm')||'01','yyyymmdd')
                           AND store_loc = '01' 
                           AND item_id   = v_item_id;        
                    EXCEPTION 
                         WHEN OTHERS THEN                  
                              out_CODE := SQLCODE; 
                              out_MSG  :='온라인주문용출고수량에 반영 에러=>'||'(제품:'||v_item_id||')'||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                              ROLLBACK;
                              RETURN;
                    END;
                                
                END LOOP ;                  
          END;
                    
       END IF;
          

    END LOOP; 
         
    out_CODE  := 0;
    out_MSG   := '저장 완료';              
                  


EXCEPTION
     WHEN ERROR_RAISE THEN 
          ROLLBACK; 

     WHEN OTHERS THEN
          out_CODE := SQLCODE;
          out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 

END;
/
