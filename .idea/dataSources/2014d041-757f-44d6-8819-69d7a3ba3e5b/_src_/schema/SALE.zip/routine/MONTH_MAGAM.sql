CREATE PROCEDURE      MONTH_MAGAM
            (  I_GUBUN         IN   VARCHAR2,  -- 마감구분
               I_YMD           IN   DATE    ,  -- 마감년월
               O_MSG           OUT  VARCHAR2   -- 메시지
) IS
   T_YMD      DATE;
   T_YMD_F    DATE;
   T_YMD_T    DATE;
   T_CNT      NUMBER(5) := 0;
   T_CUST_ID  VARCHAR2(20);
   T_RCUST_ID VARCHAR2(20);


-- SUM(DECODE(X.DEAL_GB,'10',(NVL(Y.AMT,0) + NVL(Y.VAT,0)) * -1,(NVL(Y.AMT,0) + NVL(Y.VAT,0))))  SALE_AMT

   CURSOR CUR1 IS -- 월별 매출액 마감 / 거래처별,사원별
       SELECT X.CUST_ID , X.RCUST_ID,
              SUM(NVL(Y.AMT,0) + NVL(Y.VAT,0))  SALE_AMT
         FROM SALE0207 X , SALE0208 Y
        WHERE X.YMD BETWEEN T_YMD_F AND T_YMD_T
          AND X.YMD     = Y.YMD
          AND X.DEAL_NO = Y.DEAL_NO
        GROUP BY X.CUST_ID, X.RCUST_ID;
      
   CURSOR CUR2 IS -- 월별 수금액 마감
       SELECT CUST_ID ,RCUST_ID,
              SUM(NVL(CASH_AMT,0) + NVL(BILL_AMT,0)) SU_AMT
         FROM SALE0401 A
        WHERE YMD BETWEEN T_YMD_F AND T_YMD_T
        GROUP BY CUST_ID, RCUST_ID;
        
   CURSOR CUR3 IS -- 만기일 마감
       SELECT YMD, JUNPYO_NO, INPUT_SEQ
         FROM SALE0402
        WHERE END_YMD = I_YMD ;
        
   CURSOR CUR4 IS -- 전월이월
       SELECT A.CUST_ID, A.RCUST_ID, A.SAWON_ID ,
              nvl(A.BEFORE_AMT,0) + nvl(MISU_AMT,0) - nvl(SU_AMT,0)    BEFORE_AMT
	 FROM SALE0306 A
	WHERE A.YMD  = ADD_MONTHS(T_YMD,-1)
	  AND nvl(A.BEFORE_AMT,0) + nvl(MISU_AMT,0) - nvl(SU_AMT,0) <> 0;
 
   CURSOR CUR11 IS -- 거래처별 사원변경
    select a.cust_id , a.rcust_id, b.sawon_id
      from (select cust_id, rcust_id, max(ymd) ymd
                 from (select ymd, cust_id, rcust_id
                         from sale0203
                        where ymd BETWEEN T_YMD_F AND T_YMD_T
                        union
                       select ymd, cust_id, rcust_id
                        from sale0207
                       where ymd BETWEEN T_YMD_F AND T_YMD_T)
                group by cust_id, rcust_id) a,
            (select ymd, cust_id, rcust_id, sawon_id
                from sale0203
                  where ymd BETWEEN T_YMD_F AND T_YMD_T
             union
              select ymd, cust_id, rcust_id, sawon_id
                 from sale0207
                  where ymd BETWEEN T_YMD_F AND T_YMD_T ) b
    where a.cust_id  = b.cust_id
      and a.rcust_id = b.rcust_id
      and a.ymd      = b.ymd;    
      
   CURSOR CUR12 IS -- 거래처별 사원변경
	select a.cust_id , a.rcust_id, b.sawon_id
	  from (select cust_id, rcust_id, max(ymd) ymd
                 from (select ymd, cust_id, rcust_id
                        from sale0207
                       where ymd BETWEEN T_YMD_F AND T_YMD_T)
                group by cust_id, rcust_id) a,
	        (select ymd, cust_id, rcust_id, sawon_id
  	           from sale0207
                  where ymd BETWEEN T_YMD_F AND T_YMD_T ) b
	where a.cust_id  = b.cust_id
	  and a.rcust_id = b.rcust_id
	  and a.ymd      = b.ymd;
      
   CURSOR CUR13 IS -- 거래처별 사원변경
	select a.cust_id , a.rcust_id, b.sawon_id
	  from (select cust_id, rcust_id, max(ymd) ymd
                 from (select ymd, cust_id, rcust_id
                        from sale0207
                       where ymd BETWEEN T_YMD_F AND T_YMD_T)
                group by cust_id, rcust_id) a,
	        (select ymd, cust_id, rcust_id, sawon_id
  	           from sale0207
                  where ymd BETWEEN T_YMD_F AND T_YMD_T ) b
	where a.cust_id  = b.cust_id
	  and a.rcust_id = b.rcust_id
	  and a.ymd      = b.ymd;
      
BEGIN
--   RAISE_APPLICATION_ERROR(-20001,'휴직및 퇴직자 입니다. 확인요망 ');


   -- 일자를 만든다
   T_YMD   := TO_DATE(TO_CHAR(I_YMD,'YYYY/MM')||'/01','YYYY/MM/DD');
   T_YMD_F := T_YMD;
   T_YMD_T := LAST_DAY(T_YMD);
   
   IF T_YMD < '2001-10-01' THEN
      RETURN;
   END IF;   
   
   IF I_GUBUN = '01' THEN  --월별 매출마감
       UPDATE SALE0306 SET MISU_AMT =  0 WHERE YMD      =  T_YMD;
	   FOR C1 IN CUR1 LOOP
       	   UPDATE SALE0306 SET MISU_AMT =  C1.SALE_AMT
	        WHERE YMD      =  T_YMD
	          AND CUST_ID  =  C1.CUST_ID
	          AND RCUST_ID =  C1.RCUST_ID ;
	       IF SQL%NOTFOUND  THEN
                  INSERT INTO SALE0306 (YMD,     CUST_ID,    RCUST_ID,    MISU_AMT ) VALUES (T_YMD,   C1.CUST_ID, C1.RCUST_ID, C1.SALE_AMT );
	       END IF;
	   END LOOP;
       
   ELSIF I_GUBUN = '02' THEN --월별 수금마감
       UPDATE SALE0306 SET SU_AMT   =  0 WHERE YMD      =  T_YMD;
	   FOR C2 IN CUR2 LOOP
	       UPDATE SALE0306 SET SU_AMT   =  C2.SU_AMT
	        WHERE YMD      =  T_YMD
	          AND CUST_ID  =  C2.CUST_ID
	          AND RCUST_ID =  C2.RCUST_ID;
	       IF SQL%NOTFOUND  THEN
	          INSERT INTO SALE0306 (YMD,     CUST_ID,     RCUST_ID,    SU_AMT ) VALUES (T_YMD,   C2.CUST_ID,  C2.RCUST_ID, C2.SU_AMT );
	       END IF;
               T_CNT := T_CNT + 1;
	   END LOOP;
       
	   UPDATE SALE0099 SET EN_YN     = 'N',PROC_YMD  = TO_CHAR(SYSDATE,'YYYYMMDD')
        WHERE YM        = TO_CHAR(T_YMD,'YYYYMM')
          AND EN_GB     = '01';
       IF SQL%NOTFOUND  THEN
	      INSERT INTO SALE0099 (YM,     EN_GB,     EN_YN,    PROC_YMD ) VALUES (TO_CHAR(T_YMD,'YYYYMM'),   '01',  'N', TO_CHAR(SYSDATE,'YYYYMMDD'));
	   END IF;
       
   ELSIF I_GUBUN = '03' THEN  --일별 만기일 마감
	   FOR C3 IN CUR3 LOOP
	        UPDATE SALE0402 SET GYULJAE_YMD = END_YMD
	         WHERE YMD           = C3.YMD
	           AND JUNPYO_NO     = C3.JUNPYO_NO
	           AND INPUT_SEQ     = C3.INPUT_SEQ;
	   END LOOP;
       
   ELSIF I_GUBUN = '04' THEN  --일별 만기일 마감
	   FOR C3 IN CUR3 LOOP
	        UPDATE SALE0402 SET GYULJAE_YMD = END_YMD
	         WHERE YMD           = C3.YMD
	           AND JUNPYO_NO     = C3.JUNPYO_NO
	           AND INPUT_SEQ     = C3.INPUT_SEQ;
	   END LOOP; 
       
   ELSIF I_GUBUN = '06' THEN  --전월 이월
       UPDATE SALE0306 SET BEFORE_AMT = 0, MISU_AMT =  0, SU_AMT  =  0 WHERE YMD  =  T_YMD;
       -- 전월잔고 이월
	   FOR C4 IN CUR4 LOOP
           T_CUST_ID  := C4.CUST_ID;
           T_RCUST_ID := C4.RCUST_ID;    
       
   	       UPDATE SALE0306 
              SET BEFORE_AMT =  C4.BEFORE_AMT,
                  SAWON_ID   =  C4.SAWON_ID
            WHERE YMD        =  T_YMD
              AND CUST_ID    =  C4.CUST_ID
              AND RCUST_ID   =  C4.RCUST_ID ;
	       IF SQL%NOTFOUND  THEN
	          INSERT INTO SALE0306 (YMD,CUST_ID,RCUST_ID,BEFORE_AMT ,SAWON_ID) VALUES (T_YMD,   C4.CUST_ID,  C4.RCUST_ID, C4.BEFORE_AMT , C4.SAWON_ID );
	       END IF;
	   END LOOP;
       -- 매출생성
	   FOR C1 IN CUR1 LOOP
       	   UPDATE SALE0306 SET MISU_AMT =  C1.SALE_AMT
	        WHERE YMD      =  T_YMD
	          AND CUST_ID  =  C1.CUST_ID
	          AND RCUST_ID =  C1.RCUST_ID ;
	       IF SQL%NOTFOUND  THEN
              INSERT INTO SALE0306 (YMD,     CUST_ID,    RCUST_ID,    MISU_AMT ) VALUES (T_YMD,   C1.CUST_ID, C1.RCUST_ID, C1.SALE_AMT );
	       END IF;
	   END LOOP;
       --수금생성
	   FOR C2 IN CUR2 LOOP
	       UPDATE SALE0306 SET SU_AMT   =  C2.SU_AMT
	        WHERE YMD      =  T_YMD
	          AND CUST_ID  =  C2.CUST_ID
	          AND RCUST_ID =  C2.RCUST_ID;
	       IF SQL%NOTFOUND  THEN
	          INSERT INTO SALE0306 (YMD,     CUST_ID,     RCUST_ID,    SU_AMT ) VALUES (T_YMD,   C2.CUST_ID,  C2.RCUST_ID, C2.SU_AMT );
	       END IF;
               T_CNT := T_CNT + 1;
	   END LOOP;
       
   ELSIF I_GUBUN = '07' THEN --거래처 사원 변경
       FOR C12 IN CUR12 LOOP
       	   UPDATE SALE0306 SET SAWON_ID =  C12.SAWON_ID
	        WHERE YMD      =  T_YMD
	          AND CUST_ID  =  C12.CUST_ID
	          AND RCUST_ID =  C12.RCUST_ID ;
       END LOOP;
       
   ELSIF I_GUBUN = '08' THEN --거래처 사원 변경
       T_YMD_T := LAST_DAY(SYSDATE);
       FOR C13 IN CUR13 LOOP
       	   UPDATE SALE0306 SET SAWON_ID =  C13.SAWON_ID
	        WHERE YMD      =  T_YMD
	          AND CUST_ID  =  C13.CUST_ID 
	          AND RCUST_ID =  C13.RCUST_ID;
       END LOOP;
       
   END IF;
   
   IF I_GUBUN = '01' THEN
      O_MSG := 'OK : 월별 매출마감이 완료 되었습니다.';
   ELSIF I_GUBUN = '02' THEN
      O_MSG := 'OK : 월별 수금마감이 완료 되었습니다.'||'('||to_char(T_CNT)||')';
   ELSIF I_GUBUN = '03' THEN
      O_MSG := 'OK : 일별 만기일 마감이 완료 되었습니다.';
   ELSIF I_GUBUN = '04' THEN
      O_MSG := 'OK : 일별 만기일 마감이 완료 되었습니다.';
   ELSIF I_GUBUN = '05' THEN
      O_MSG := 'OK : 거래처 사원 변경이 완료 되었습니다.';
   ELSIF I_GUBUN = '06' THEN
      O_MSG := 'OK : 전월 이월이 완료 되었습니다.';
   ELSIF I_GUBUN = '07' THEN
      O_MSG := 'OK : 거래처 사원 변경이 완료 되었습니다.';
   ELSIF I_GUBUN = '08' THEN
      O_MSG := 'OK : 거래처 사원 변경이 완료 되었습니다.';
   END IF;
   
   COMMIT;
   
--   O_MSG := 'Err : 월별 마감작업도중 Error 발생';

   EXCEPTION
        WHEN OTHERS THEN
             raise_application_error( -20001, T_YMD||':'||T_CUST_ID||':'||T_RCUST_ID||':'||sqlerrm ) ;

END  MONTH_MAGAM;
/
