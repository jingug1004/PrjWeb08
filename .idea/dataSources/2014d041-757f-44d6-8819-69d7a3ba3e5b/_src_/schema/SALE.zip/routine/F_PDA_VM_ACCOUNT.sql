CREATE FUNCTION      f_pda_VM_ACCOUNT
	    (in_cust_id  IN    VARCHAR2,
        in_sabun IN VARCHAR2 )        -- 기준일자

RETURN VARCHAR2 
IS 
pragma autonomous_transaction;

v_return   VARCHAR2(30) default null;
i_count number ;

BEGIN
v_return :='';

  select count(*) as cnt 
  into i_count 
  from sale.sale0003vn
  where cust_id = in_cust_id;

  if(i_count > 0) then

      select nvl(virtual_no,'') as virtual_no
      into v_return 
      from sale.sale0003vn 
      where cust_id = in_cust_id;

  else
    --v_return := '111';
    select min(virtual_no) ,count(*) as cnt 
    into v_return, i_count 
    from sale.sale0003vn 
    where cust_id is null;
    
    if i_count > 0 then

       update sale.sale0003vn set cust_id = in_cust_id
       , input_date = sysdate
       , input_id = in_sabun
       where virtual_no = v_return;

     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패  INSERT INTO SALE.SALE0401');
            ROLLBACK;
            return '';
     END IF;
     
    end if;
    
  end if;
commit;  

  RETURN(v_return);
END;

/
