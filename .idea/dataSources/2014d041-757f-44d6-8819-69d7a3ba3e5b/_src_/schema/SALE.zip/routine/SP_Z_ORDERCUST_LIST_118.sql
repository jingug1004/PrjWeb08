CREATE PROCEDURE      SP_Z_ORDERCUST_LIST_118 
(
    in_CUST_CD           IN  VARCHAR2,  -- 거래처 코드
    in_CUST_NM           IN  VARCHAR2,  -- 거래처명
    in_SAWON_ID          IN  VARCHAR2,  -- 사원코드    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 주문거래처 거래처 검색 팝업 - 3 4 번대 거래처만 보임
 호출프로그램 : 주문서등록
 수정기록   :2014.05.13 KTA - 사용중지거래처는 리스트에 안나오도록 함 
         2015.06.08 KTA - 임시팀장 직책코드 추가관련 수정   
         2017.11.01 KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_insa_sawon_id     VARCHAR2(7);
    v_deptcode          VARCHAR2(4);  -- 로그인사원부서
    v_assgn_cd          VARCHAR2(5);
    v_query_deptcode     VARCHAR2(4); -- 조회부서 
    v_adminloginyn      VARCHAR2(1);  -- admin 부서 로그인여부  
    
    GUBUN_NULL           EXCEPTION;
    JUMUN_STOP           EXCEPTION;
    
    v_temp              VARCHAR2(6);
    
BEGIN 
    
    --insert into SFA_SP_CALLED_HIST values ('SP_Z_ORDERCUST_LIST_118','1',sysdate,'in_CUST_CD'||in_CUST_CD||' / in_CUST_NM:'||in_CUST_NM||'/in_SAWON_ID:'||in_SAWON_ID);
    
    --로그인사원이 팀원인지,팀원이아닌 총괄팀장,팀장 파악
    select classdiv,deptcode into v_assgn_cd,v_deptcode from ORAGMP.CMEMPM  where empcode = in_SAWON_ID;
         
    v_query_deptcode := v_deptcode;               
    -- 조회부서:: 로그인 직책에따라 상위부서를 찾거나 본인부서를 찾는다..
    if v_assgn_cd in ('27010','27018','27023','27025','27026')  then   -- 본수장 ,부본부장, 총괄이사, 총괄지점장, 선임지점장       지점장,팀장, 임시팀장('27027','27030','27035') 은 1레벨위로 안가야 함  
       select deptcode 
         into v_query_deptcode 
         from ORAGMP.CMDEPTM 
        where useyn = 'Y' and level = 2 connect by deptcode = prior predeptcode start with plantcode = '1000' and deptcode = v_deptcode;  
    end if; 
    
    if v_query_deptcode in ('0007','0004','0302','0114','0527') then 
       v_adminloginyn   := 'Y';
    else
       v_adminloginyn   := 'N';           
    end if;
    

    --insert into SFA_SP_CALLED_HIST values ('KTA_SP_Z_ORDERCUST_LIST_118','1',sysdate,'v_query_deptcode'||v_query_deptcode||' / v_adminloginyn:'||v_adminloginyn||'/in_SAWON_ID:'||in_SAWON_ID||'/v_assgn_cd:'||v_assgn_cd);

    

 
   SELECT count(*) 
      INTO v_num
          from (
                SELECT a.custcode  
                  FROM ORAGMP.CMCUSTM a
                 WHERE a.plantcode = '1000'
                   AND a.custdiv   = '2' --매출
                   AND a.sagodiv   = '1'
                   --AND substr(a.custcode,1,1)  in ('3','4')  --직거래병약국,직거래병원
                   AND a.empcode in (select empcode from ORAGMP.CMEMPM  where v_assgn_cd <> '27040' 
                                        and plantcode = '1000' and deptcode in ( select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode)
                                     union
                                     select in_SAWON_ID from dual where v_assgn_cd = '27040'
                                    )
                   AND a.custcode  LIKE '%'||NVL(in_CUST_CD,'%')||'%'
                   AND a.custname  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND v_adminloginyn = 'N'
                   and rownum < 1100
                union 
               SELECT a.custcode 
                  FROM ORAGMP.CMCUSTM a
                 WHERE a.plantcode = '1000'
                   AND a.custdiv   = '2' --매출
                   AND a.sagodiv   = '1'
                  -- AND substr(a.custcode,1,1)  in ('3','4')  --직거래병약국,직거래병원
                   AND a.custcode  LIKE '%'||NVL(in_CUST_CD,'%')||'%'
                   AND a.custname  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND v_adminloginyn = 'Y'
                   and rownum < 1100
                 ) a            
    ;           
                 
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
        
        if v_num > 1000 then           
           out_CODE := 1;
           out_MSG := '검색건수가 1000건이 넘습니다. 거래처명을 2자이상 조건으로 입력해주세요';
           return;
        end if;
         
        OPEN out_RESULT FOR
        select *
          from (
                SELECT a.custcode                             AS out_CUST_CD    -- 거래처코드
                      ,a.custname                             AS out_CUST_NM    -- 거래처명
                      ,a.addr1||' '||a.addr2                  AS out_ADDRESS    -- 거래처 주소
                      ,a.ceoname                              AS out_MANAGER_NM -- 대표자 명                
                      ,oragmp.fngetturncnt(a.custcode,to_char(add_months(sysdate,-1),'yyyy-mm'))  AS out_RATE_DAY    -- 회전일  
                      ,a.empcode                              AS out_EMP_NO     -- 담당사원 ID
                      ,oragmp.fncommonnm ('emp',a.empcode,'') AS out_EMP_NM      -- 담당사원명
                      ,nvl(a.turnlmt,120)                     AS out_CONTROL_RATE_DAY --주문제어회전일  거래처의 회전일한도 비어있으면 120 일 
                      ,TO_CHAR(SYSDATE, 'YYYY.MM.DD')         AS out_SERVER_YMD  --CHOE 20130701서버의 날자를 가져가서 주문일자로 사용한다.
                  FROM ORAGMP.CMCUSTM a
                 WHERE a.plantcode = '1000'
                   AND a.custdiv   = '2' --매출
                   AND a.sagodiv   = '1'
                  -- AND substr(a.custcode,1,1)  in ('3','4')  --직거래병약국,직거래병원 
                   AND a.empcode in (select empcode from ORAGMP.CMEMPM where v_assgn_cd <> '27040' and plantcode = '1000' and deptcode in ( select deptcode from ORAGMP.CMDEPTM connect by prior deptcode = predeptcode start with plantcode = '1000' and deptcode = v_query_deptcode)
                                     union
                                     select in_SAWON_ID from dual where v_assgn_cd = '27040'
                                    )
                   AND a.custcode  LIKE '%'||NVL(in_CUST_CD,'%')||'%'
                   AND a.custname  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND v_adminloginyn = 'N'
                union 
               SELECT a.custcode                             AS out_CUST_CD    -- 거래처코드
                      ,a.custname                             AS out_CUST_NM    -- 거래처명
                      ,a.addr1||' '||a.addr2                  AS out_ADDRESS    -- 거래처 주소
                      ,a.ceoname                              AS out_MANAGER_NM -- 대표자 명                
                      ,oragmp.fngetturncnt(a.custcode,to_char(add_months(sysdate,-1),'yyyy-mm'))  AS out_RATE_DAY    -- 회전일  
                      ,a.empcode                              AS out_EMP_NO     -- 담당사원 ID
                      ,oragmp.fncommonnm ('emp',a.empcode,'') AS out_EMP_NM      -- 담당사원명
                      ,nvl(a.turnlmt,120)                     AS out_CONTROL_RATE_DAY --주문제어회전일  거래처의 회전일한도 비어있으면 120 일 
                      ,TO_CHAR(SYSDATE, 'YYYY.MM.DD')         AS out_SERVER_YMD  --CHOE 20130701서버의 날자를 가져가서 주문일자로 사용한다.
                  FROM ORAGMP.CMCUSTM a
                 WHERE a.plantcode = '1000'
                   AND a.custdiv   = '2' --매출
                   AND a.sagodiv   = '1'
                   --AND substr(a.custcode,1,1)  in ('3','4')  --직거래병약국,직거래병원 
                   AND a.custcode  LIKE '%'||NVL(in_CUST_CD,'%')||'%'
                   AND a.custname  LIKE '%'||NVL(in_CUST_NM,'%')||'%'
                   AND v_adminloginyn = 'Y'
                 ) a             
         ORDER BY out_CUST_NM
         
        ; 
    
    END IF;
    
EXCEPTION
WHEN GUBUN_NULL THEN
   out_CODE := 101;
   out_MSG  := '검색 구분코드가 누락되었습니다.';
WHEN JUMUN_STOP THEN
   out_CODE := 102;
   out_MSG  := '전산시스템 점검작업으로 2시간동안 주문불가합니다. 공지를 참고하십시요';   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
