CREATE PROCEDURE      SP_Z_STATUS_02    -- 거래처 여신현황
(
    in_CUST_CD           IN  VARCHAR2,    -- 거래처코드
    in_DT                IN  VARCHAR2,    -- 기간
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 거래처여신현황 
 호출프로그램 : 거래처> 거래처현황      
          2017.11.01 KTA - NEW ERP메 맞게 컨버젼    
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    p_gjdate             VARCHAR2(7); 
    
    CUST_CD_NULL         EXCEPTION;
    DT_NULL              EXCEPTION;
    
BEGIN

--insert into SFA_SP_CALLED_HIST values ('SP_Z_STATUS_02',to_char(sysdate,'yyyymmdd hh24miss') ,sysdate,'in_CUST_CD:'||in_CUST_CD||'/in_DT '||in_DT );
--commit; 
    
    IF in_CUST_CD IS NULL THEN
        RAISE CUST_CD_NULL;
    END IF;
    
    IF in_DT IS NULL THEN
        RAISE DT_NULL;
    END IF;
    
    p_gjdate := SUBSTR(in_DT,1,4)||'-'||SUBSTR(in_DT,5,2); 
   
    
    SELECT COUNT(*)
      INTO v_num
      FROM oragmp.SLRESULTM 
     WHERE yearmonth = SUBSTR(p_gjdate, 0, 7)         
       AND custcode  = in_CUST_CD
    ; 

    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
                   
        
        OPEN out_RESULT FOR
       SELECT  CUSTCODE                                     AS out_CUST_ID,
               CUSTNAME                                     AS out_CUST_NM,
               ''                                           AS out_SAWON_ID,
               ''                                           AS out_SAWON_NM,
               ''                                           AS out_DEPT_NM,
               DWRMAMT                                      AS out_JANGO,        --현잔고 
               0                                            AS out_MIDORAE_CHA,  --자수
               0                                            AS out_MIDORAE_TASU, --타수
               TOTJANGO                                     AS out_TOT,          --총여신
               0                                            AS out_EOEUM,        
               0                                            AS out_SUPYO,        
               0                                            AS out_GITA,         
               SCRTAMT                                      AS out_TOT_DAMBO,    --담보총금액
               SCRTAMTRATE                                  AS out_YUL,          --확보율
               SCRTKIND                                     AS out_BILL_GB,
               REPRESENTATION                               AS out_YEONDAE_1,    --대표연대보증
               THIRDPARTY                                   AS out_YEONDAE_2,    --제3자연대보증
               CUSTNAME                                     AS out_YEONDAE_3,    --담보예외
               ''                                           AS out_START_YMD,
               0                                            AS out_AVG_SALE ,
               0                                            AS out_TODAY_AMT,
               0                                            AS out_AVG_SU_AMT ,
               0                                            AS out_TODAY_SU_AMT,
               0                                            AS out_GYEOYAK
          FROM (
                  
                    SELECT A.CUSTCODE   ,  --거래처코드
                           A.CUSTNAME   ,  --거래처명
                           A.SECURITYEXYN, --담보예외여부
                           P.DWRMAMT    ,  -- 현잔고
                           P.DWRMAMT + P.JASUAMT AS TOTJANGO, --총여신
                           J.SCRTAMT    ,  --담보액
                           CASE WHEN (NVL(P.DWRMAMT, 0) + NVL(P.JASUAMT, 0)) = 0 THEN 0
                                ELSE ROUND((J.SCRTAMT / (NVL(P.DWRMAMT, 0) + NVL(P.JASUAMT, 0))) * 100, 2) END AS SCRTAMTRATE,               --담보확보율 
                           J.SCRTKIND   , --담보종류
                           NVL(J.THIRDPARTY, 'X') THIRDPARTY, --제3자 보증
                           NVL(J.REPRESENTATION, 'X') REPRESENTATION -- 대표자 보증
                      FROM (
                              SELECT CUSTCODE
                                ,      MAX(JWRMAMT)  AS JWRMAMT
                                ,      MAX(DWRMAMT)  AS DWRMAMT
                                ,      MAX(JASUAMT)  AS JASUAMT
                                ,      MAX(TASUAMT)  AS TASUAMT
                                FROM
                                      ( --전월 / 현잔고
                                        SELECT CUSTCODE,
                                            SUM(CASE WHEN A.YEARMONTH = TO_CHAR(ADD_MONTHS(TO_DATE(SUBSTR(p_gjdate,1,7),'YYYY-MM'), -1),'YYYY-MM') THEN BALANCE ELSE 0 END) AS JWRMAMT,    --전월잔고
                                            SUM(CASE WHEN A.YEARMONTH = SUBSTR(p_gjdate,1,7)                                                       THEN BALANCE ELSE 0 END) AS DWRMAMT,    --현잔고
                                            SUM(CASE WHEN A.YEARMONTH = SUBSTR(p_gjdate,1,7) THEN PENDBILLCOLJ + PENDBILLCOLJ7 ELSE 0 END)                                     AS JASUAMT,    --미도래어음(자수)
                                            SUM(CASE WHEN A.YEARMONTH = SUBSTR(p_gjdate,1,7) THEN PENDBILLCOLT + PENDBILLCOLT7 ELSE 0 END)                                     AS TASUAMT     --미도래어음(타수)
                                       FROM oragmp.SLRESULTM A
                                      WHERE YEARMONTH BETWEEN TO_CHAR(ADD_MONTHS(TO_DATE(SUBSTR(p_gjdate,1,7),'YYYY-MM'), -1),'YYYY-MM') AND SUBSTR(p_gjdate,1,7)
                                   GROUP BY CUSTCODE
                                     ) A
                                     GROUP BY CUSTCODE
                                 ) P
                           JOIN oragmp.CMCUSTM A
                               ON P.CUSTCODE = A.CUSTCODE
                           LEFT JOIN (
                                         SELECT CUSTCODE
                                         ,      MAX(SCRTAMT) SCRTAMT
                                         ,      MAX(SCRTKIND) SCRTKIND
                                         ,      MAX(THIRDPARTY) THIRDPARTY
                                         ,      MAX(REPRESENTATION) REPRESENTATION
                                         FROM(
                                                  SELECT CUSTCODE
                                                  ,      NVL(SUM(scrtamt), 0) AS scrtamt
                                                  ,      '' AS SCRTKIND
                                                  ,      '' AS THIRDPARTY
                                                  ,      '' AS REPRESENTATION
                                                    FROM oragmp.CMCUSTSCRTD
                                                   WHERE NVL(returnyn, ' ') <> 'Y'
                                                GROUP BY CUSTCODE
                                                
                                                UNION ALL
                                                
                                                  SELECT CUSTCODE
                                                  ,      0 AS scrtamt
                                                  ,      oragmp.FNCOMMONNM('COMM', 'SL04', MAX(SCRTDIV)) || ' 외' || COUNT(*) || '건' AS SCRTKIND
                                                  ,      '' AS THIRDPARTY
                                                  ,      '' AS REPRESENTATION
                                                    FROM oragmp.CMCUSTSCRTD
                                                   WHERE NVL(returnyn, ' ') <> 'Y' -- 반환된 담보 제외
                                                     AND SCRTDIV != '1' --연대 보증인 제외
                                                GROUP BY CUSTCODE
                                                
                                                UNION ALL
                                                
                                                  SELECT CUSTCODE
                                                  ,      0 AS scrtamt
                                                  ,      '' AS SCRTKIND
                                                  ,      MAX(GUARANTOR) AS THIRDPARTY
                                                  ,      '' AS REPRESENTATION
                                                    FROM oragmp.CMCUSTSCRTD
                                                   WHERE NVL(returnyn, ' ') <> 'Y' -- 반환된 담보 제외
                                                     AND SCRTDIV = '1' --연대 보증인 제외
                                                     AND GUARANTYDIV = '02' -- 제 3자 보증
                                                GROUP BY CUSTCODE
                                                
                                                UNION ALL
                                                
                                                  SELECT CUSTCODE
                                                  ,      0 AS scrtamt
                                                  ,      '' AS SCRTKIND
                                                  ,      '' AS THIRDPARTY
                                                  ,      MAX(GUARANTOR) AS REPRESENTATION
                                                    FROM oragmp.CMCUSTSCRTD
                                                   WHERE NVL(returnyn, ' ') <> 'Y' -- 반환된 담보 제외
                                                     AND SCRTDIV = '1' --연대 보증인 제외
                                                     AND GUARANTYDIV = '01' -- 대표자 보증
                                                GROUP BY CUSTCODE
                                                ) A
                                                GROUP BY CUSTCODE
                                        ) J
                               ON A.CUSTCODE = J.CUSTCODE
                     WHERE A.CUSTCODE = in_CUST_CD  
                       AND A.CUSTDIV  = '2'
                  ORDER BY P.CUSTCODE 
               );
               
    END IF;
    
EXCEPTION
WHEN CUST_CD_NULL THEN
   out_CODE := 101;
   out_MSG  := '거래처 코드가 누락되었습니다.';
WHEN DT_NULL THEN
   out_CODE := 102;
   out_MSG  := '조회 년월이 누락되었습니다.';
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
