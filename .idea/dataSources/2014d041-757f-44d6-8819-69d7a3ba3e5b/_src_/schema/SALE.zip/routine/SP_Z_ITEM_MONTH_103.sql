CREATE PROCEDURE      SP_Z_ITEM_MONTH_103
(
    in_SAWON_ID          IN  VARCHAR2,  --영업사원id
    in_CUST_ID           IN  VARCHAR2,  
    in_FROM_DT           IN  VARCHAR2,  
    in_TO_DT             IN  VARCHAR2,  
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 1달간주문제품리스트조회
 호출프로그램 : 주문등록화면 제품한달버튼  bizItemInfo_Month      
         2017.11.01 KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_cnt                NUMBER;
    v_maxorderdate       VARCHAR2(8);
    v_FROM_DT            VARCHAR2(8);
    v_TO_DT              VARCHAR2(8);
    
    SAWON_ID_NULL        EXCEPTION;
    CUST_ID_NULL         EXCEPTION; 
    FROM_DT_NULL         EXCEPTION; 
    TO_DT_NULL           EXCEPTION; 
         
BEGIN
    
    IF in_SAWON_ID IS NULL THEN
        RAISE SAWON_ID_NULL;
    END IF;
    
    IF in_CUST_ID IS NULL THEN
        RAISE CUST_ID_NULL;
    END IF;    
    
    IF in_FROM_DT IS NULL THEN
        RAISE FROM_DT_NULL;
    END IF;    
    
    IF in_TO_DT IS NULL THEN
        RAISE TO_DT_NULL;
    END IF;    
    
    
    v_FROM_DT :=  in_FROM_DT;
    v_TO_DT   :=  in_TO_DT;
   --주문일부터 최근한달주문이 없으면마지막 주문일부터 1달
   SELECT count(*) INTO v_cnt FROM ORAGMP.SLORDM a
    WHERE a.plantcode = '1000'
      AND a.empcode   = in_SAWON_ID      
      AND a.custcode  = in_CUST_ID
      AND REPLACE(a.orderdate,'-','') BETWEEN in_FROM_DT AND in_TO_DT
      AND rownum = 1;
   IF v_cnt = 0 then
      SELECT MAX(REPLACE(orderdate,'-','')) INTO v_TO_DT FROM ORAGMP.SLORDM a
       WHERE a.plantcode = '1000'
         AND a.empcode   = in_SAWON_ID      
         AND a.custcode  = in_CUST_ID
      ;               
      IF v_TO_DT IS NOT NULL THEN
         v_FROM_DT := TO_CHAR(TO_DATE(v_TO_DT,'YYYYMMDD') - 30 ,'YYYYMMDD');
      ELSE    
         v_FROM_DT :=  in_FROM_DT;
         v_TO_DT   :=  in_TO_DT;
      END IF;
   END IF;
    
--insert into SFA_SP_CALLED_HIST values ('SP_Z_ITEM_MONTH_103','1',sysdate,'v_FROM_DT'||v_FROM_DT||' / v_TO_DT:'||v_TO_DT||'/in_SAWON_ID:'||in_SAWON_ID||'/in_CUST_ID:'||in_CUST_ID);
--commit;   

   SELECT count(distinct b.itemcode)
     INTO v_num
     FROM ORAGMP.SLORDM A,
          ORAGMP.SLORDD B
    WHERE a.orderno  = b.orderno
      AND a.plantcode = '1000'
      AND a.empcode   = in_SAWON_ID      
      AND a.custcode  = in_CUST_ID      
      AND REPLACE(a.orderdate,'-','') BETWEEN v_FROM_DT AND v_TO_DT; 

    out_CODE := 1;
    out_COUNT := v_num;

    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_COUNT := 1;
        out_CODE := 0;
        out_MSG := '검색 확인rrr완료';    
         
        OPEN out_RESULT FOR
        
        SELECT a.itemcode                                     AS out_ITEM_ID        -- 제품코드
             , a.itemname                                     AS out_ITEM_NM        -- 제품명
             , a.itemunit                                     AS out_STANDARD       -- 규격
             , a.unit                                         AS out_UNIT           -- 단위
             , FZ_GET_DANGA(in_CUST_ID,in_CUST_ID,a.itemcode)   AS out_DANGA          -- 단가(출고단가)  
             , NULL                                           AS out_STOCK          -- 재고
             , DECODE(a.productdiv, '04', 'Y', 'N')           AS out_CHUL_YN    -- 출하중지여부 (Y:중지, N:출하)
             , DECODE(a.productdiv, '04', '중지', '출하')         AS out_CHUL_NM   -- 출하중지여부명
             , NULL                                           AS out_STOCK_GUBUN    -- 재고구분
             , ''                                             AS out_VIEW_TXT       -- 효능효과
             , ''                                             AS out_ITEM_POINT     -- 특장점
             , ''                                             AS out_EFFECT         -- 효능효과(제품상세설명)
             , 'a'                                            AS out_ITEM_USE_DOES  -- 용량용법
             , ''                                             AS out_ITEM_ATTENTION -- 주의사항
             , ''                                             AS out_PHOTO          -- 이미지     
             , ''                                             AS out_ITEM_1SPEECH   -- 1분 스피치
             , ''                                             AS out_ITEM_3SPEECH   -- 3분 스피치
             --,oragmp.fncommonnm ('COMM','SL03',a.mplantcode)  AS out_SAUPJANG_CD    --사업장코드(101-하길,102-도매,103-도매(향정))   
             ,a.mplantcode                                     AS out_SAUPJANG_CD    --사업장코드(2001-하길마약, 2002-하길향정 , 1001 -도매향정 )   
          FROM ORAGMP.CMITEMM A 
              ,(
                 SELECT distinct b.itemcode,b.salprc
                   FROM ORAGMP.SLORDM A,
                        ORAGMP.SLORDD B
                  WHERE a.orderno = b.orderno
                    AND a.plantcode = '1000'
                    AND A.empcode   = in_SAWON_ID      
                    AND a.custcode  = in_CUST_ID      
                    AND REPLACE(a.orderdate,'-','') BETWEEN v_FROM_DT AND v_TO_DT              
               ) B
         WHERE a.itemcode = b.itemcode
         ORDER BY a.itemname;          
         
    END IF;
    
EXCEPTION
WHEN SAWON_ID_NULL THEN
   out_CODE := '1';
   out_MSG  := '사원ID가 누락되었습니다.';
   DBMS_OUTPUT.PUT_LINE('out_MSG :'||out_MSG);
   
WHEN CUST_ID_NULL THEN
   out_CODE := '2';
   out_MSG  := '거래처가 누락되었습니다.';
   DBMS_OUTPUT.PUT_LINE('out_MSG :'||out_MSG);
   
   
WHEN FROM_DT_NULL THEN
   out_CODE := '3';
   out_MSG  := 'FROM 일자가 누락되었습니다.';
   DBMS_OUTPUT.PUT_LINE('out_MSG :'||out_MSG);
   
   
WHEN TO_DT_NULL THEN
   out_CODE := '4';
   out_MSG  := 'TO 일자가 누락되었습니다.';
   DBMS_OUTPUT.PUT_LINE('out_MSG :'||out_MSG);
   
   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
   DBMS_OUTPUT.PUT_LINE('out_MSG OTHERS :'||out_MSG);
   
END;
/
