CREATE PROCEDURE      SP_SFA_COMMON_07_BACK
(
    in_BANK_NM           IN  VARCHAR2,  -- 은행명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 은행검색 팝업 
 호출프로그램 :         
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
BEGIN
    


    SELECT COUNT(*)
      INTO v_num
      FROM SYS907C   
     WHERE bank_nm like NVL(in_bank_nm,'')||'%';
    
    out_COUNT := v_num;
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
        
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT bank_cd   as out_BANK_CD
              ,bank_nm   as out_BANK_NM
        FROM SYS907C   
        WHERE bank_nm LIKE NVL(in_bank_nm,'')||'%'
        ORDER BY bank_nm;
         
    END IF; 
    
    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_COMMON_07','1',sysdate,'in_BANK_NM:'||in_BANK_NM||'/v_num:'||TO_CHAR(v_num)  );
 

EXCEPTION   
    WHEN OTHERS THEN
       out_CODE := SQLCODE;
       out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
