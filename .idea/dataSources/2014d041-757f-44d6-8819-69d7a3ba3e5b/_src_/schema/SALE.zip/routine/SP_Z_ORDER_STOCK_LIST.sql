CREATE PROCEDURE      SP_Z_ORDER_STOCK_LIST
(
    in_SAWON_ID         IN  VARCHAR2,   -- 영업사원번호    
    out_CODE              OUT NUMBER,
    out_MSG                OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
/*---------------------------------------------------------------------------
    프로그램명   : 품절제품  입고현황 
    호출프로그램 : VISIT.VISITDAILY 의 입고 현황 POPUP     
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼    
  ---------------------------------------------------------------------------*/    

        v_num NUMBER;
        v_sale0705_2_num NUMBER; --입고현황 입력된 수
        v_sale0705_3_num NUMBER; --영업사원이 입고현황 확인 한 수 
    
BEGIN      
        
        v_num := 0;
        v_sale0705_2_num := 0;
        v_sale0705_3_num := 0; 
        FOR C1 IN (
                SELECT ITEM_ID     AS ITEM_ID
                      ,REG_DATE    AS REG_DATE
                      ,STOCK_DATE  AS STOCK_DATE
                      ,EXPLANATION AS EXPLANATION                              
                FROM SALE0705_2
        )LOOP
                -- 입고현황에 등록된 LIST COUNT
                v_sale0705_2_num := v_sale0705_2_num + 1;
                
                -- 영업사원이 입고현황을 확인한 수(삭제된 입고현황은 이곳에서 조회 count 하지않는다.) 
                SELECT COUNT(*)
                  INTO v_num
                  FROM SALE0705_3 A
                 WHERE A.ITEM_ID = C1.ITEM_ID
                   AND A.REG_DATE = C1.REG_DATE
                   AND A.SAWON_ID = in_SAWON_ID                        
                ;
                
                v_sale0705_3_num := v_sale0705_3_num + v_num;
        END LOOP;
        
        /*INSERT INTO SFA_SP_CALLED_HIST VALUES ('SP_SFA_ORDER_STOCK_LIST' ,'1' ,SYSDATE ,'in_SAWON_ID:'||in_SAWON_ID||' ,2_num: '||v_sale0705_2_num||' ,3_num: '||v_sale0705_3_num );
        COMMIT;*/
    
        out_COUNT := v_sale0705_2_num;
        
        IF v_sale0705_2_num = v_sale0705_3_num THEN
                out_CODE := 1;
                out_MSG := '검색내용이 없습니다.';  
        ELSE
                out_CODE := 0;
                out_MSG := '검색 확인완료';    
         
                OPEN out_RESULT FOR
                SELECT A.ITEM_ID AS out_ITEM_ID,        -- 제품코드
                       B.ITEMNAME AS out_ITEM_NM,        -- 제품명
                       B.ITEMUNIT AS out_STANDARD,           -- 규격                
                       A.STOCK_DATE AS out_STOCK_DATE,  --입고일
                       A.EXPLANATION AS out_EXPLANATION,   --비고
                       A.REG_DATE AS out_REG_DATE            
                  FROM (
                         SELECT ITEM_ID
                                ,REG_DATE  
                                ,STOCK_DATE
                                ,EXPLANATION                       
                           FROM SALE0705_2        
                        ) A
                        ,oragmp.CMITEMM B                      
                 WHERE A.ITEM_ID = B.itemcode
                   AND A.ITEM_ID||A.REG_DATE NOT IN ( SELECT ITEM_ID||REG_DATE FROM SALE0705_3 WHERE SAWON_ID = in_SAWON_ID)
                ORDER BY A.STOCK_DATE DESC ,B.ITEMNAME
                        ;
        END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
