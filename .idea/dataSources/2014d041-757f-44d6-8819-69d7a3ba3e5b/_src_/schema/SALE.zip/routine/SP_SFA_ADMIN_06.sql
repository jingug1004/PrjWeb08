CREATE PROCEDURE      SP_SFA_ADMIN_06    -- 브로셔 등록
(
    in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3)
    in_BRUSH_CD          IN  VARCHAR2,     -- 제품코드
    in_BRUSH_SEQ         IN  NUMBER,       -- SEQ
    in_BRUSH_NM          IN  VARCHAR2,     -- 제품명
    in_BRUSH_YN          IN  VARCHAR2,     -- 사용여부
    in_ITEM_PATH         IN  VARCHAR2,       -- 파일경로
    in_ITEM_NM           IN  VARCHAR2,       -- 원래파일명
    in_SAVE_ITEM_NM      IN  VARCHAR2,       -- 폴더저장파일명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    v_seq                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_BRUSHER
     WHERE BRUSH_CD   = in_BRUSH_CD
       AND BRUSH_SEQ  = in_BRUSH_SEQ;
         
    out_COUNT := v_num;
    IF in_BTN_GUBUN = 1 THEN -- 등록버튼 클릭한 경우
        IF in_BRUSH_SEQ IS NOT NULL AND v_num >= 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 있습니다';
        ELSE
            -- 필수값 체크 루틴 넣을것.
            
            -- SEQ MAX 생성
            SELECT NVL(MAX(BRUSH_SEQ),0)+1
              INTO v_seq
              FROM SFA_OFFICE_BRUSHER
             WHERE BRUSH_CD  = in_BRUSH_CD;
              
            -- 브로숴 등록
            INSERT INTO SFA_OFFICE_BRUSHER(BRUSH_CD, BRUSH_SEQ, BRUSH_NM, BRUSH_YN, ITEM_PATH, ITEM_NAME, SAVE_ITEM_NAME) 
                           VALUES(in_BRUSH_CD, v_seq,  in_BRUSH_NM, in_BRUSH_YN, in_ITEM_PATH, in_ITEM_NM, in_SAVE_ITEM_NM);
            
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT BRUSH_CD                AS out_BRUSH_CD   
                 , BRUSH_SEQ               AS out_BRUSH_SEQ  
                 , BRUSH_NM                AS out_BRUSH_NM   
                 , BRUSH_YN                AS out_BRUSH_YN   
                 , ITEM_PATH               AS out_ITEM_PATH  
                 , ITEM_NAME               AS out_ITEM_NM    
                 , SAVE_ITEM_NAME          AS out_SAVE_ITEM_NM    
                FROM SFA_OFFICE_BRUSHER
               WHERE BRUSH_CD   = in_BRUSH_CD
                 AND BRUSH_SEQ  = v_seq;
             
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '등록이 완료되었습니다';
        END IF;
    ELSIF in_BTN_GUBUN = 2 THEN -- 수정버튼 클릭한 경우
        IF v_num < 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            UPDATE SFA_OFFICE_BRUSHER
               SET BRUSH_NM     =    in_BRUSH_NM
                 , BRUSH_YN     =    in_BRUSH_YN
                 , ITEM_PATH    =    in_ITEM_PATH
                 , ITEM_NAME    =    in_ITEM_NM
                 , SAVE_ITEM_NAME =  in_SAVE_ITEM_NM
             WHERE BRUSH_NM     =    in_BRUSH_NM
               AND BRUSH_SEQ    =    in_BRUSH_SEQ;
              
            COMMIT;

            OPEN out_RESULT FOR
            SELECT BRUSH_CD                AS out_BRUSH_CD  
                 , BRUSH_SEQ               AS out_BRUSH_SEQ 
                 , BRUSH_NM                AS out_BRUSH_NM  
                 , BRUSH_YN                AS out_BRUSH_YN  
                 , ITEM_PATH               AS out_ITEM_PATH 
                 , ITEM_NAME               AS out_ITEM_NM   
                 , SAVE_ITEM_NAME               AS out_SAVE_ITEM_NM   
                FROM SFA_OFFICE_BRUSHER
               WHERE BRUSH_CD   = in_BRUSH_CD
                 AND BRUSH_SEQ  = in_BRUSH_SEQ;
             
            out_CODE := 0;
            out_MSG := '수정이 완료되었습니다';
        END IF;
    ELSIF in_BTN_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우
        IF v_num < 1 THEN
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            DELETE FROM SFA_OFFICE_BRUSHER
             WHERE BRUSH_CD   = in_BRUSH_CD   AND  BRUSH_SEQ      =    in_BRUSH_SEQ;
              
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT BRUSH_CD                AS out_BRUSH_CD   
                 , BRUSH_SEQ               AS out_BRUSH_SEQ  
                 , BRUSH_NM                AS out_BRUSH_NM   
                 , BRUSH_YN                AS out_BRUSH_YN   
                 , ITEM_PATH               AS out_ITEM_PATH  
                 , ITEM_NAME               AS out_ITEM_NM    
                 , SAVE_ITEM_NAME               AS out_SAVE_ITEM_NM    
                FROM SFA_OFFICE_BRUSHER
               WHERE BRUSH_CD   = in_BRUSH_CD
                 AND BRUSH_SEQ  = in_BRUSH_SEQ;
             
            out_CODE := 0;
            out_MSG := '삭제가 완료되었습니다';
         END IF;
    ELSE   -- 조회처리
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '정보가 존재하지 않습니다.';
        ELSIF (v_num >= 1) THEN
            out_CODE := 0;
            out_MSG := '정보 확인완료';    
             
            OPEN out_RESULT FOR
            SELECT BRUSH_CD                AS out_BRUSH_CD    
                 , BRUSH_SEQ               AS out_BRUSH_SEQ   
                 , BRUSH_NM                AS out_BRUSH_NM    
                 , BRUSH_YN                AS out_BRUSH_YN    
                 , ITEM_PATH               AS out_ITEM_PATH   
                 , ITEM_NAME               AS out_ITEM_NM     
                 , SAVE_ITEM_NAME               AS out_SAVE_ITEM_NM     
                FROM SFA_OFFICE_BRUSHER
               WHERE BRUSH_CD   = in_BRUSH_CD
                 AND BRUSH_SEQ  = in_BRUSH_SEQ
               ORDER BY BRUSH_NM;
        END IF;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
