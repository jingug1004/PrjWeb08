CREATE PROCEDURE      P_SENDBILL ( AS_FROM_DT IN VARCHAR2
                                                                ,AS_TO_DT IN VARCHAR2
                                                                ,AS_CUST_ID IN VARCHAR2 
                                                                ,AS_COR IN VARCHAR2
                                                                ,AS_BILLTYPE IN VARCHAR2
)IS
        /*------------------------------------------------------------------
        CHOE 20170322 
        센드빌 자료 생성을 위한 프로시져
        
        
        SALE0209 -> BILL_TRANS_HIST
        SALE0210 -> BILL_TRANS_ITEM_HIST
        BILL_TRANS_BILLSEQ_HIST : SALE_NO를 기록하고 자료를 생성할때 제외 시킨다.
        
        AS_FROM_DT : 자료를 만들고자 하는 날짜를 넘긴다.
        AS_TO_DT
        
        AS_CUST_ID : 이 컬럼이 넘어는 경우 해당 자료만 만든다.
                        가장 먼저 이 컬럼의 값이 있는지 확인 한다.
                        
        AS_COR : 상신 도매 구분                  
        AS_BILLTYPE : 거래명세서  31 세금계산서 11
        ------------------------------------------------------------------*/        
        V_CUST_ID SALE0003.CUST_ID%TYPE;        
        V_PROCESS VARCHAR2(1);   --A 모든 자료 생성 ,C 하나의 거래처만 생성
        
        V_SALE_NO SALE0209.SALE_NO%TYPE;   --SALE_NO 발행 번호 확인
        
        V_CURR_ERROR       VARCHAR2(1000) ;        
        USER_ERR           EXCEPTION;         

BEGIN 
  
        DBMS_OUTPUT.PUT_LINE('--------------------------------- START P_SENDBILL ');      
        
        /*0. AS_CUST_ID 정보가 정확하게 넘어 왔는지 파악한다.
                7자리인 경우 하나의 거래처에 대해서 생성하는 경우 C
                입력내용이 없는 경우 전체 자료에 대해서 생성 A
                V_PROCESS / V_CUST_ID 는 확인하는 차원에서 진행한다.
        */
                
        IF LENGTH(AS_CUST_ID) = 7 THEN        
                V_PROCESS := 'C';        
                SELECT CUST_ID
                INTO V_CUST_ID
                FROM SALE.SALE0003
                WHERE CUST_ID = AS_CUST_ID 
                ;
        ELSIF AS_CUST_ID IS NULL THEN
                V_CUST_ID := '';
                V_PROCESS := 'A';  
        ELSE 
                V_CURR_ERROR := '거래처의 코드가 정상적이지 않습니다.';
                RAISE USER_ERR;                
        END IF;
       DBMS_OUTPUT.PUT_LINE(' P_SENDBILL - V_CUST_ID : '||V_CUST_ID);  
               
        IF AS_BILLTYPE = '11' THEN
                DBMS_OUTPUT.PUT_LINE('정상 : '||AS_BILLTYPE);
        ELSIF AS_BILLTYPE = '31' THEN
                DBMS_OUTPUT.PUT_LINE('정상 : '||AS_BILLTYPE);
        ELSE
                V_CURR_ERROR := '거래처의 코드가 정상적이지 않습니다.';
                RAISE USER_ERR;
        END IF;        
        
       
        V_CURR_ERROR := '';      
        /*1. Master 자료 생성 
        */        
        BEGIN
        
                /*INSERT INTO SENDLINK.BILL_TRANS_BILLSEQ_HIST
                VALUES(
                TO_CHAR(SYSDATE ,'YYYYMMDDHH24MISS')
                ,'1'
                ,'2'
                ,'3'
                ,AS_FROM_DT||'-'||AS_TO_DT||'-'||V_CURR_ERROR
                )
                ;            
                COMMIT;*/ 
        
                INSERT INTO SENDLINK.BILL_TRANS_HIST
                SELECT MAX(A.SALE_NO) AS BILLSEQ
                ,'0000000029' /*CAST(DECODE(:AS_CORPORATE,101,'1248556942',102,'2208527916','xxx') AS VARCHAR2(20))*/ AS SVENDERNO  --공급자사업자번호
                ,DECODE(A.SALE_GB,'07',D.VOU_NO ||'-07', --07 12 매출할인
                                         '12',D.VOU_NO ||'-07',
                                         '08',D.VOU_NO ||'-07', 
                                         '13',D.VOU_NO ||'-07',
                                         '14',D.VOU_NO ||'-14', --14 판매대행수수료
                                         '15',D.VOU_NO ||'-15', --15 수입수수료  
                                         D.VOU_NO||'-00') AS RVENDERNO  --공급받는자사업자번호                
                ,TO_CHAR(MAX(A.YMD) , 'YYYYMMDD') AS DT  --세금계산서작성일
                ,SUM(A.AMT_SUM) AS SUPMONEY  --공급가총액
                ,SUM(A.VAT_SUM) AS TAXMONEY  --세액총액 
                ,'0' AS TAXRATE  --과세구분 0과세율
                ,0 AS CASH  --현금지급액
                ,0 AS CHECKS  --수표지급액
                ,0 AS NOTE --어음지급액
                ,SUM(NVL(A.AMT_SUM, 0)) + SUM(NVL(A.VAT_SUM, 0))  AS CREDIT  --외상미수금
                ,'2' AS GUBUN  --청구구분 1영수2청구    
                ,'' AS BIGO  --
                ,AS_BILLTYPE AS BILLTYPE --세금계산서종류 0과세율
                /*공급자*/
                ,CAST(DECODE(AS_COR ,101,'하나제약(주)하길공장',102,'하나제약(주)도매지점','xxx') AS VARCHAR2(20))  AS SCOMPANY  --공급자업체명
                ,CASE WHEN MAX(A.YMD) < TO_DATE('20111125') THEN '조경일'
                        ELSE '최동재'                                                                                                                         
                END AS SCEONAME -- 공급자대표자명
                ,CAST(DECODE(AS_COR ,101,'제조',102,'도매','xxx') AS VARCHAR2(40)) AS SUPTAE  --공급자업태
                ,CAST(DECODE(AS_COR ,101,'양약',102,'의약품','xxx') AS VARCHAR2(40)) AS SUPJONG  --공급자업종
                ,CAST(DECODE(AS_COR ,101, CASE WHEN MAX(A.YMD) < TO_DATE('20111125') THEN '경기도 화성시 향남읍 하길리'
                                                            ELSE '경기도 화성시 향남읍 제약단지로 13-39'
                                                    END,                                          
                                              102, CASE WHEN MAX(A.YMD) < TO_DATE('20111125') THEN '서울특별시 서초구 양재동 2-28'
                                                            ELSE '경기도 화성시 향남읍 삼천병마로 173-5'
                                                    END               
                                             ,'xxx') AS VARCHAR2(150)) AS SADDRESS  --공급자주소
                ,CAST(DECODE(AS_COR ,101, CASE WHEN MAX(A.YMD) < TO_DATE('20111125') THEN ''
                                                            ELSE ''
                                                    END,                                          
                                              102, CASE WHEN MAX(A.YMD) < TO_DATE('20111125') THEN '4층 401'
                                                            ELSE '(에이스존 302호)'
                                                    END        
                                              ,'xxx') AS VARCHAR2(150)) AS SADDRESS2  --공급자상세주소
                ,CAST(DECODE(AS_COR ,101,'안상윤',102,'윤홍주','xxx') AS VARCHAR2(10)) AS SUSER --공급자담당자명
                ,'관리부' AS SDIVISION  --공급자부서명
                ,'025777667' AS STELNO  --공급자전화번호
                ,'jlee@hanaph.co.kr' AS SEMAIL  --공급자이메일
                ,'' AS SREG_ID  --공급자종코드
                /*공급받는자*/
                ,SUBSTR(MAX(D.CUST_NM), 1, 50) AS RCOMPANY --공급받는자업체명
                ,MAX(D.PRESIDENT) AS RCEONAME  --공급받는자대표자명
                ,SUBSTR(MAX(D.UPTAE), 1, 20) AS RUPTAE  --공급받는자업태
                ,SUBSTR(MAX(D.JONGMOK), 1, 20) AS RUPJONG  --공급받는자업종
                ,SUBSTR(MAX(D.ADDR1) ,1 ,150) AS RADDRESS  --공급받는자주소
                ,SUBSTR(MAX(D.ADDR2) ,1 ,80) AS RADDRESS2  --공급받는자상세주소
                ,MAX(D.PRESIDENT) AS RUSER  --공급받는자담당자명
                ,'' AS RDIVISION  --공급받는자부서명 
                ,MAX(NVL(D.TEL, '0')) AS RTELNO  --공급받는자전화번호
                ,'jlee@hanaph.co.kr' /*MAX(D.EMAIL)*/ AS REMAIL  --공급받는자이메일
                ,'' AS RREG_ID  --공급받는자종코드
                ,'' AS REPORT_STAT  --국세청신고상태
                ,'' AS REPORT_AMEND_CD --신고문서수정사유코드
                ,'' AS REPORT_ISSUE_ID  --신고문서고유코드
                ,'Y' AS REPORT_EXCEPT_YN  --신고제외여부 Y발행예정 N즉시신고
                ,'' AS REPORT_RSLT_CD  --신고결과 코드
                ,TO_CHAR(MAX(A.YMD) , 'YYYYMMDD') AS CREATE_DT  --생성일자
                ,'' AS BOOK_NO  --권번호
                ,'' AS PAGE_NO  --페이지번호
                ,'' AS SERIAL_NO  --일련번호
                ,'N' AS TRANSYN  --전송여부 초기값N
                ,'N' AS REVERSEYN  --역발행여부 초기값N
                ,'t005' AS SENDID --공급자아이디
                ,'' AS RECVID  --공급받는자 아이디
                ,'' AS USER_SET_DIV  --유저검색구분코드
                ,'' AS USER_SET_VALUE  --유저검색값
                ,'Y' AS TEST_YN  --테스트여부
                ,'' AS MD5  --고유번호암호값
                ,'' AS FILE_URL  --첨부파일URL
                ,'' AS UPBILLSEQ  --상위문서고유번호
                ,'' AS CLOSE_DT  --역발행문서 전송가능일자
                ,'A' AS CREAT_DIV  --생성구분 A송신, B수신
                ,'' AS RUSER2  --공급받는자 담당자2 이름
                ,'' AS RTELNO2  --공급받는자 담당자 전화2
                ,'' AS REMAIL2  --공급받는자 담당자 이메일2
                ,'' AS SACCOUNT_NO  --매출자계정코드
                ,'' AS RACCOUNT_NO  --매입자계정코드
                ,'' AS ETC01  --ID구분
                ,'N' AS ETC02  --거래명세서 첨부여부 'N'-첨부하지 않음, 'Y'-첨부함
                ,'N' AS ETC03  --자동회원가입여부 'N'-자동회원가입안함, 'Y'-자동회원가입함
                ,'' AS ETC04  --기타04
                ,'' AS ETC05  --기타05
                ,'' AS ETC06  --기타06
                ,'' AS ETC07  --기타07
                ,'' AS ETC08  --기타08
                ,'' AS ETC09  --기타09
                ,'' AS REPORT_ETC01  --국세청신고기타1
                ,'' AS REPORT_ETC02  --국세청신고기타2
                FROM SALE.SALE0209 A
                ,(
                SELECT SALE_NO ,YMD
                FROM SALE.SALE0210
                WHERE (F_GET_SALE0004H_SAUPJANGCD(ITEM_ID, YMD) = DECODE(AS_COR ,'101','101','') OR
                       F_GET_SALE0004H_SAUPJANGCD(ITEM_ID, YMD) = DECODE(AS_COR ,'102','102','') OR
                       F_GET_SALE0004H_SAUPJANGCD(ITEM_ID, YMD) = DECODE(AS_COR ,'102','103',''))
                GROUP BY SALE_NO ,YMD       
                ) B
                ,SALE.SALE0003 D
                WHERE A.CUST_ID = D.CUST_ID
                AND A.YMD = B.YMD
                AND A.SALE_NO = B.SALE_NO
                AND A.YMD BETWEEN TO_DATE(AS_FROM_DT ,'YYYYMMDD') AND TO_DATE(AS_TO_DT ,'YYYYMMDD')
                AND A.CUST_ID LIKE NVL(V_CUST_ID ,'%')
                AND A.SALE_NO NOT IN (
                SELECT SALE_NO
                FROM SENDLINK.BILL_TRANS_BILLSEQ_HIST
                ) 
                GROUP BY DECODE(A.SALE_GB,'07',D.VOU_NO ||'-07', --07 12 매출할인
                                         '12',D.VOU_NO ||'-07',
                                         '08',D.VOU_NO ||'-07', 
                                         '13',D.VOU_NO ||'-07',
                                         '14',D.VOU_NO ||'-14', --14 판매대행수수료
                                         '15',D.VOU_NO ||'-15', --15 수입수수료  
                                         D.VOU_NO||'-00')
                ;
                COMMIT;
                
        EXCEPTION  WHEN OTHERS THEN 
                V_CURR_ERROR := 'ERR : '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                RAISE USER_ERR;
        END;
        
        
        /*3. Detail 자료 등록
        */
        BEGIN
        
                INSERT INTO SENDLINK.BILL_TRANS_ITEM_HIST
                SELECT MAX(B.SALE_NO) AS BILLSEQ
                ,TO_NUMBER(MAX(B.INPUT_SEQ)) AS ITEMSEQ
                ,SUM(NVL(B.VAT ,0)) AS TAX
                ,SUM(NVL(B.AMT ,0)) AS SUP
                ,MAX(B.DANGA) AS DANGA
                ,MAX(B.QTY) AS VLM
                ,MAX(C.STANDARD) AS UNIT
                ,MIN(C.ITEM_NM)||' 외' AS OBJ 
                ,TO_CHAR(MAX(B.YMD), 'YYYY-MM-DD') AS DT
                ,''/*B.BIGO*/ AS REMARK_D
                FROM (
                        SELECT A.YMD ,A.SALE_NO ,A.SALE_GB ,D.VOU_NO
                        FROM SALE.SALE0209 A
                        ,SALE.SALE0003 D
                        WHERE A.CUST_ID = D.CUST_ID                        
                        AND A.CUST_ID LIKE NVL(V_CUST_ID ,'%')      
                        AND A.SALE_NO NOT IN (
                                SELECT SALE_NO
                                FROM SENDLINK.BILL_TRANS_BILLSEQ_HIST
                                )                                         
                ) SER
                ,SALE.SALE0210 B
                ,SALE.SALE0004 C
                WHERE B.YMD = SER.YMD
                AND B.SALE_NO = SER.SALE_NO  
                AND B.ITEM_ID = C.ITEM_ID
                AND B.YMD BETWEEN TO_DATE(AS_FROM_DT ,'YYYYMMDD') AND TO_DATE(AS_TO_DT ,'YYYYMMDD')
                AND (F_GET_SALE0004H_SAUPJANGCD(B.ITEM_ID, B.YMD) = DECODE(AS_COR ,'101','101','') OR
                       F_GET_SALE0004H_SAUPJANGCD(B.ITEM_ID, B.YMD) = DECODE(AS_COR ,'102','102','') OR
                       F_GET_SALE0004H_SAUPJANGCD(B.ITEM_ID, B.YMD) = DECODE(AS_COR ,'102','103',''))               
                GROUP BY DECODE(SER.SALE_GB,'07',SER.VOU_NO ||'-07', --07 12 매출할인
                                         '12',SER.VOU_NO ||'-07',
                                         '08',SER.VOU_NO ||'-07', 
                                         '13',SER.VOU_NO ||'-07',
                                         '14',SER.VOU_NO ||'-14', --14 판매대행수수료
                                         '15',SER.VOU_NO ||'-15', --15 수입수수료  
                                         SER.VOU_NO||'-00')
                ;
                
        EXCEPTION  WHEN OTHERS THEN 
                V_CURR_ERROR := 'ERR DATE : '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                RAISE USER_ERR;
        END;            
         
        
        
         /*9. BILL_TRANS_BILLSEQ_HIST에 전표번호를 모두 등록해 놓는다.
        */
        
        BEGIN
        
                FOR C1 IN (
                        SELECT MAX(A.SALE_NO) AS SALE_NO
                        ,DECODE(A.SALE_GB,'07',D.VOU_NO ||'-07', --07 12 매출할인
                                                 '12',D.VOU_NO ||'-07',
                                                 '08',D.VOU_NO ||'-07', 
                                                 '13',D.VOU_NO ||'-07',
                                                 '14',D.VOU_NO ||'-14', --14 판매대행수수료
                                                 '15',D.VOU_NO ||'-15', --15 수입수수료  
                                                 D.VOU_NO||'-00') AS VOU_NO 
                        FROM SALE.SALE0209 A
                        ,(
                        SELECT SALE_NO ,YMD
                        FROM SALE.SALE0210
                        WHERE (F_GET_SALE0004H_SAUPJANGCD(ITEM_ID, YMD) = DECODE(AS_COR ,'101','101','') OR
                               F_GET_SALE0004H_SAUPJANGCD(ITEM_ID, YMD) = DECODE(AS_COR ,'102','102','') OR
                               F_GET_SALE0004H_SAUPJANGCD(ITEM_ID, YMD) = DECODE(AS_COR ,'102','103',''))
                        GROUP BY SALE_NO ,YMD       
                        ) B
                        ,SALE.SALE0003 D
                        WHERE A.CUST_ID = D.CUST_ID
                        AND A.YMD = B.YMD
                        AND A.SALE_NO = B.SALE_NO
                        AND A.YMD BETWEEN TO_DATE(AS_FROM_DT ,'YYYYMMDD') AND TO_DATE(AS_TO_DT ,'YYYYMMDD')
                        AND A.CUST_ID LIKE NVL(V_CUST_ID ,'%')
                        AND A.SALE_NO NOT IN (
                        SELECT SALE_NO
                        FROM SENDLINK.BILL_TRANS_BILLSEQ_HIST
                        )
                        GROUP BY DECODE(A.SALE_GB,'07',D.VOU_NO ||'-07', --07 12 매출할인
                                                 '12',D.VOU_NO ||'-07',
                                                 '08',D.VOU_NO ||'-07', 
                                                 '13',D.VOU_NO ||'-07',
                                                 '14',D.VOU_NO ||'-14', --14 판매대행수수료
                                                 '15',D.VOU_NO ||'-15', --15 수입수수료  
                                                 D.VOU_NO||'-00')    
                 ) LOOP
                        
                        INSERT INTO SENDLINK.BILL_TRANS_BILLSEQ_HIST
                        SELECT A.SALE_NO
                        ,TO_CHAR(SYSDATE , 'YYYYMMDDHH24MISS')
                        ,C1.SALE_NO                        
                        ,C1.VOU_NO
                        ,'정상등록완료' 
                        FROM SALE.SALE0209 A
                        ,SALE.SALE0003 D
                        WHERE A.CUST_ID = D.CUST_ID
                        AND DECODE(A.SALE_GB,'07',D.VOU_NO ||'-07', --07 12 매출할인
                                                 '12',D.VOU_NO ||'-07',
                                                 '08',D.VOU_NO ||'-07', 
                                                 '13',D.VOU_NO ||'-07',
                                                 '14',D.VOU_NO ||'-14', --14 판매대행수수료
                                                 '15',D.VOU_NO ||'-15', --15 수입수수료  
                                                 D.VOU_NO||'-00') = C1.VOU_NO
                        AND A.YMD BETWEEN TO_DATE(AS_FROM_DT ,'YYYYMMDD') AND TO_DATE(AS_TO_DT ,'YYYYMMDD')
                        ;                
                        
                END LOOP
                ;                
                
        EXCEPTION  WHEN OTHERS THEN 
                V_CURR_ERROR := 'ERR DATE : '||TO_CHAR(SQLCODE)||'-'||TO_CHAR(SQLERRM);
                RAISE USER_ERR;
        END;  
        
        
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('--------------------------------- END P_SENDBILL');     
  
EXCEPTION   
    WHEN USER_ERR THEN
            ROLLBACK; 
            INSERT INTO SENDLINK.BILL_TRANS_BILLSEQ_HIST
            VALUES(
            TO_CHAR(SYSDATE ,'YYYYMMDDHH24MISS')
            ,'1'
            ,'2'
            ,'3'
            ,AS_FROM_DT||'-'||AS_TO_DT||'-'||V_CURR_ERROR
            )
            ;            
            COMMIT; 
            RAISE_APPLICATION_ERROR(-20001, V_CURR_ERROR);             

    WHEN OTHERS THEN
            V_CURR_ERROR := 'ERR OTHERS ' || TO_CHAR(SQLCODE)|| '-'|| substr(sqlerrm, 1, 90);
            ROLLBACK;  
            INSERT INTO SENDLINK.BILL_TRANS_BILLSEQ_HIST
            VALUES(
            TO_CHAR(SYSDATE ,'YYYYMMDDHH24MISS')
            ,'1'
            ,'2'
            ,'3'
            ,AS_FROM_DT||'-'||AS_TO_DT||'-'||V_CURR_ERROR
            )
            ;            
            COMMIT; 
            RAISE_APPLICATION_ERROR(-20001, V_CURR_ERROR);    
    
END P_SENDBILL;
/
