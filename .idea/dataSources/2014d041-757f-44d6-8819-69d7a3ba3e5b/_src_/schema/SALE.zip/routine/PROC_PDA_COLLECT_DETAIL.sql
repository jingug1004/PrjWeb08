CREATE PROCEDURE      PROC_PDA_COLLECT_DETAIL
  (in_flag IN VARCHAR2 DEFAULT NULL,
  in_ymd IN date,
   in_JUNPYO_NO IN VARCHAR2 DEFAULT NULL,
   in_INPUT_SEQ IN VARCHAR2 DEFAULT NULL, 
   in_END_YMD IN VARCHAR2 DEFAULT NULL, 
   in_AMT IN VARCHAR2 DEFAULT NULL, 
   in_START_YMD IN VARCHAR2 DEFAULT NULL, 
   in_BALHANG IN VARCHAR2 DEFAULT NULL, 
   in_JIGEUB IN VARCHAR2 DEFAULT NULL, 
   in_BILL_NO IN VARCHAR2 DEFAULT NULL, 
   in_BILL_GB IN VARCHAR2 DEFAULT NULL, 
   in_GYULJAE_YMD IN VARCHAR2 DEFAULT NULL,
   in_BIGO IN VARCHAR2 DEFAULT NULL,
   in_PDA_RPRT IN VARCHAR2 DEFAULT NULL
        )
IS
    ll_max number;
BEGIN

if in_flag = 'I' then

    --SP_SYS100C_MAX_VALUE('SALE0401', sysdate, null,null, null, null, ll_max );
    dbms_output.put_line(ll_max  );

     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패 SP_SYS100C_MAX_VALUE');
            ROLLBACK;
            return;
     END IF;
 
/*INSERT INTO SALE.SALE0402 (
YMD, JUNPYO_NO, INPUT_SEQ, 
END_YMD, AMT, START_YMD, 
BALHANG, JIGEUB, BILL_NO, 
BILL_GB, GYULJAE_YMD, BIGO) 
VALUES ( , , ,
    , , ,
    , , ,
    , , )*/
    
    INSERT INTO SALE.SALE0402 (
       YMD, JUNPYO_NO, INPUT_SEQ, 
       END_YMD, AMT, START_YMD, 
       BALHANG, JIGEUB, BILL_NO, 
       BILL_GB, GYULJAE_YMD, BIGO, PDA_RPRT) 
    VALUES ( in_YMD, in_JUNPYO_NO, lpad(in_INPUT_SEQ,4,'0'), 
       in_END_YMD, decode(nvl(in_AMT,''),'','0', in_AMT), in_START_YMD, 
       in_BALHANG, in_JIGEUB, in_BILL_NO, 
       in_BILL_GB, in_GYULJAE_YMD, in_BIGO, in_PDA_RPRT);

        
     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패  INSERT INTO SALE.SALE0401');
            ROLLBACK;
            return;
     END IF;
else

/*UPDATE SALE.SALE0402
SET    YMD         = :YMD,
       JUNPYO_NO   = :JUNPYO_NO,
       INPUT_SEQ   = :INPUT_SEQ,
       END_YMD     = :END_YMD,
       AMT         = :AMT,
       START_YMD   = :START_YMD,
       BALHANG     = :BALHANG,
       JIGEUB      = :JIGEUB,
       BILL_NO     = :BILL_NO,
       BILL_GB     = :BILL_GB,
       GYULJAE_YMD = :GYULJAE_YMD,
       BIGO        = :BIGO
WHERE  JUNPYO_NO   = :JUNPYO_NO
AND    INPUT_SEQ   = :INPUT_SEQ
*/

UPDATE SALE.SALE0402
SET    YMD         = in_YMD,
       JUNPYO_NO   = in_JUNPYO_NO,
       INPUT_SEQ   = lpad(in_INPUT_SEQ,4,'0'),
       END_YMD     = in_END_YMD,
       AMT         = decode(nvl(in_AMT,''),'','0', in_AMT),
       START_YMD   = in_START_YMD,
       BALHANG     = in_BALHANG,
       JIGEUB      = in_JIGEUB,
       BILL_NO     = in_BILL_NO,
       BILL_GB     = in_BILL_GB,
       GYULJAE_YMD = in_GYULJAE_YMD,
       BIGO        = in_BIGO
WHERE  JUNPYO_NO   = in_JUNPYO_NO
AND    INPUT_SEQ   = lpad(in_INPUT_SEQ,4,'0');

     IF SQLCODE <> 0 THEN
         dbms_output.put_line('실패 UPDATE SALE.SALE0401');
            ROLLBACK;
            return;
     END IF;
end if;
        
        
    

end;

/
