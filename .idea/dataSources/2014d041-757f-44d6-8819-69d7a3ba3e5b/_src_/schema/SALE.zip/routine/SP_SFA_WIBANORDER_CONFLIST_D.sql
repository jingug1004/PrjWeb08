CREATE PROCEDURE      SP_SFA_WIBANORDER_CONFLIST_D   
(
    in_GUMAE_NO          IN  VARCHAR2,    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 회전일위반 주문 승인용 리스트조회
 호출프로그램 : 일일방문화면에서 내역이 있을때 팝업에서 호출된다.      
 ---------------------------------------------------------------------------*/    

    v_num         NUMBER; 
    
BEGIN
 

    -- 로그인한 사원의 납품처에 납품된 제품중 거래처별단가테이블에서 담당제품으로 주문된것들...
    SELECT COUNT(*)
      INTO v_num 
      from sale_on.sale0203 a
          ,sale_on.sale0204 b
     where a.gumae_no = b.gumae_no
       and a.gumae_no = in_GUMAE_NO
      ;                         
        
--insert into SFA_SP_CALLED_HIST values ('SP_SFA_ORDER_LIST','1',sysdate,'in_GUMAE_NO'||in_GUMAE_NO||'/in_CUST_ID'||in_CUST_ID||' / v_num:'||to_char(v_num));
--COMMIT
    
    out_COUNT := v_num;
    IF v_num = 0 THEN
       out_CODE := 1;
       out_MSG := '조회한 내역이 존재하지 않습니다.';
    ELSE
        out_CODE := 0;
        out_MSG := '검색 완료';    
    
        OPEN out_RESULT FOR        
        select a.gumae_no              AS out_GUMAE_NO
              ,''                      AS out_ORDER_DATE
              ,c.cust_nm               AS out_CUST_NM
              ,''                      AS out_WIBAN_KIND             
              ,F_ITEM_NM(b.ITEM_ID)    AS out_ITEM_NM
              ,b.qty                   AS out_QTY
              ,F_ITEM_AVERAGE_SALE (A.CUST_ID, A.RCUST_ID, ADD_MONTHS(TO_DATE(SUBSTR(B.YMD,1,6)||'01') ,-3), ADD_MONTHS(LAST_DAY(SUBSTR(B.YMD, 1,6)||'01'), -1), B.ITEM_ID, 'Y' )  AS out_MONTH3_QTY
              ,''  AS out_RATE_DAY              
          from sale_on.sale0203 a
              ,sale_on.sale0204 b
              ,sale0003 c
         where a.cust_id  = c.cust_id
           and a.gumae_no = b.gumae_no
           and a.gumae_no = in_GUMAE_NO
          ;                         
       
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
