CREATE PROCEDURE      SP_SFA_ITEM_01
(
    in_ITEM_CD           IN  VARCHAR2,   -- 제품코드
    in_ITEM_NM           IN  VARCHAR2,   -- 제품 명
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 제품검색 
 호출프로그램 : product.ProductList        
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM SALE0004
     WHERE ITEM_ID    LIKE NVL(in_ITEM_CD, '%')
       AND ITEM_NM    LIKE '%'||NVL(in_ITEM_NM, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT ITEM_ID              AS out_ITEM_ID,        -- 제품코드
               ITEM_NM||' '||UNIT   AS out_ITEM_NM,        -- 제품명
               UNIT                 AS out_UNIT,           -- 단위
               OUT_DANGA            AS out_DANGA,           -- 단가(공급단가)
               STANDARD             AS out_STANDARD           -- 규격
          FROM SALE0004
         WHERE ITEM_ID    LIKE NVL(in_ITEM_CD, '%')
           AND ITEM_NM    LIKE '%'||NVL(in_ITEM_NM, '%')||'%'
         ORDER BY ITEM_NM;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
