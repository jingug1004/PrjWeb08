CREATE PROCEDURE      SP_SFA_ADMIN_01    -- 의학용어 검색
(
    in_DICT_HANGUL       IN  VARCHAR2,  -- 의학용어(한글)
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
/*-------------------------------------------------------------------
기능:
호출:SFA-오피스-의학용어-조회
-------------------------------------------------------------------*/    
BEGIN

    -- insert into SFA_SP_CALLED_HIST values ('SP_SFA_ADMIN_01','1',sysdate,'in_DICT_HANGUL:'||in_DICT_HANGUL);


    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_MEDIDICT
     WHERE DICT_HANGUL LIKE '%'||NVL(in_DICT_HANGUL, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT SEQ_NO               AS out_SEQ_NO,         -- 의학용어 SEQ
               DICT_HANGUL          AS out_DICT_HANGUL,    -- 의학용어명(한글)
               DICT_ENG             AS out_DICT_ENG,       -- 의학용어명(영어)
               DICT_DESC            AS out_DICT_DESC,      -- 용어설명
               DICT_CODE            AS out_DICT_CODE       -- 분류코드
          FROM SFA_OFFICE_MEDIDICT
         WHERE DICT_HANGUL LIKE '%'||NVL(in_DICT_HANGUL, '%')||'%'
         ORDER BY DICT_HANGUL, DICT_CODE;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
