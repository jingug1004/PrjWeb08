CREATE PROCEDURE      SP_Z_RETURN_UPDATE
(
    in_PROCESS      IN  VARCHAR2,   --0- QR CODE 신규등록1-바코드수량리셋 2- 수기수량변경 3- 수기입력 4- 목록에서 반품리스트 삭제 5- 반품사유변경 6-입력상태변경 
    in_EMP_NO       IN  VARCHAR2,   --로그인사번 
    in_YMD          IN  VARCHAR2,
    in_CUST_ID      IN  VARCHAR2,
    in_RCUST_ID     IN  VARCHAR2,
    in_ITEM_CD      IN  VARCHAR2,
    in_PRODNO       IN  VARCHAR2,
    in_USEDYMD      IN  VARCHAR2,  --유효기간 
    in_PRICE        IN  VARCHAR2,  --안들어옴 
    in_SAWON_ID     IN  VARCHAR2,  --거래처담당
    in_RSAWON_ID    IN  VARCHAR2,  --납품처담당
    in_ORDER_NO     IN  VARCHAR2,  
    in_MANUALQTY    IN  VARCHAR2,  --수기수량
    in_REASON_CODE  IN  VARCHAR2,  --반품사유
    in_DANGA        IN  VARCHAR2,  --단가 
    in_TAGINFO      IN  VARCHAR2,  --QR코드 
    in_DATASET      IN  VARCHAR2 default NULL,  -- input_state 체크값  저장을 위한 dataset
    in_COUNT        IN  NUMBER,  
    out_CODE        out NUMBER,
    out_MSG         out VARCHAR2
)
IS
 /*---------------------------------------------------------------------------
 프로그램명
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_tnum               NUMBER; 
    v_JUMUN_NO           VARCHAR2(12);
    v_LAST_ORDER_YMD     VARCHAR2(10); -- 최종주문일자(해당거래처 남품처 제품에 대한) 
     
    -- in_DATASET 받을 변수 
    v_ymd         VARCHAR2(10);
    v_cust_id     VARCHAR2(10); 
    v_rcust_id    VARCHAR2(10);
    v_item_id     VARCHAR2(10);
    v_prod_no     VARCHAR2(10);
    v_input_state VARCHAR2(10);
    
    
BEGIN


    out_CODE := 0;
    out_MSG  := '';    
   
    IF in_PROCESS = '0' THEN -- QR CODE 스캔하여  신규등록
    
     insert into SFA_SP_CALLED_HIST values ('SP_Z_RETURN_UPDATE',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_PROCESS,sysdate,
          'in_YMD:'||in_YMD||' in_CUST_ID '||in_CUST_ID||' in_RCUST_ID '||in_RCUST_ID||' in_ITEM_CD '||in_ITEM_CD ||' in_PRODNO '||in_PRODNO);
    commit;
    
        --신규는 금일자만 가능하도록체크 
        IF in_YMD <> TO_CHAR(SYSDATE,'YYYYMMDD') THEN        
           out_CODE := 101;
           out_MSG  := '신규입력은 오늘만 가능합니다.' ; 
           RETURN;
        END IF;
          
        -- 반품사유서 건수 
        SELECT COUNT(*) INTO v_num
          FROM sfa_banpum_reason a 
        where a.YMD = to_char(sysdate,'YYYYMMDD')
          and a.CUST_ID       = in_CUST_ID
          and a.RCUST_ID      = in_RCUST_ID
          and a.ITEM_ID       = in_ITEM_CD
          and a.PROD_NO       = in_PRODNO;
            
        --테그정보 건수  
        SELECT COUNT(*) INTO v_tnum
        FROM sfa_banpum_reason_taginfo a 
        where a.TAGINFO       = in_TAGINFO;     
                
            
        IF v_num = 0 and v_tnum = 0 THEN -- 기존 데이타 없음 => 신규 
                 
            -- 해당거래처 납품처로 이 반품제품의 최종주문일자
            BEGIN 
                SELECT /*+ index_desc(a PK_SLORDM) */
                       replace(a.orderdate,'-','')
                  INTO v_LAST_ORDER_YMD
                  FROM oragmp.slordm a, oragmp.slordd b
                 WHERE a.orderno = b.orderno
                   AND a.custcode = in_CUST_ID
                   AND a.ecustcode = in_RCUST_ID
                   AND b.itemcode = in_ITEM_CD
                   AND ROWNUM = 1
                ;
            EXCEPTION WHEN OTHERS THEN
               v_LAST_ORDER_YMD := '';
            END; 
            
            BEGIN 
                insert into sfa_banpum_reason
                         ( ymd
                          ,cust_id
                          ,rcust_id
                          ,item_id
                          ,prod_no
                          ,use_ymd_to
                          ,danga
                          ,cust_sawon_id
                          ,rcust_sawon_id
                          ,jumun_no
                          ,barcode_qty
                          ,manual_qty
                          ,banpum_qty
                          ,amt
                          ,seongin_state
                          ,input_dt
                          ,input_worker
                          ,create_sawon_id
                          ,banpum_reason
                          ,last_order_ymd
                          ,input_state
                         ) 
                  values ( to_char(sysdate,'YYYYMMDD')        -- ymd              --작성일자      
                          ,in_CUST_ID                         -- cust_id          --거래처
                          ,in_RCUST_ID                        -- rcust_id         --납품처 
                          ,in_ITEM_CD                         -- item_id          --제품 
                          ,in_PRODNO                          -- prod_no          --제조번호 
                          ,in_USEDYMD                         -- use_ymd_to       --사용기한 
                          ,in_DANGA                           -- danga            --단가 
                          ,in_SAWON_ID                        -- cust_sawon_id    --거래처담당 
                          ,in_RSAWON_ID                       -- rcust_sawon_id   --납품처담당 
                          ,in_ORDER_NO                        -- jumun_no         --주문번호 
                          ,1                                  -- barcode_qty      --바코드수량 
                          ,0                                  -- manual_qty       --수기수량 
                          ,1                                  -- banpum_qty       --반품수량 
                          ,in_DANGA * 1                       -- amt              --금액 
                          ,'1'                                -- seongin_state    --승인상태 1-대기,2-승인,3-불가
                          , sysdate                           -- input_dt         --입력일자 
                          ,in_EMP_NO                          -- input_worker     --입력자 
                          ,in_EMP_NO                          -- create_sawon_id  --작성사번 
                          ,in_REASON_CODE                     -- banpum_reason    --반품사유코드 
                          ,replace(v_LAST_ORDER_YMD,'-','')   -- last_order_ymd   --이제품최종주문일자 
                          ,'0'                                -- input_state      -- 입력상태 0-대기 1-확정 
                          );   
                
            EXCEPTION WHEN OTHERS THEN               
               out_CODE := 101;
               out_MSG  := '반영오류입니다.1 : '||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                 
               ROLLBACK;
               RETURN;
            END;  
            
            BEGIN                                           
                                            
                insert into sfa_banpum_reason_taginfo(  ymd,cust_id,rcust_id,item_id,prod_no, JUMUN_NO,TAGINFO,CREATE_SAWON_ID) 
                     values (to_char(sysdate,'YYYYMMDD') ,in_CUST_ID,in_RCUST_ID,in_ITEM_CD,in_PRODNO, in_ORDER_NO,in_TAGINFO,in_EMP_NO);
                
            EXCEPTION WHEN OTHERS THEN               
               out_CODE := 102;
               out_MSG  := '반영오류입니다.2 : '||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
               ROLLBACK;
               RETURN;
            END;    
            
            out_CODE := 0;
            out_MSG := 'I0 요청하신 작업이 등록되었습니다.';                      
            COMMIT; 
            
                                                        
        ELSIF v_num = 1 and v_tnum = 0 THEN -- sfa_banpum_reason 에 데이타 있고 sfa_banpum_reason_taginfo 에는 데이타 없음=> 바코드수량추가 
            out_CODE := 0;
            out_MSG := 'I0 요청하신 작업이 등록되었습니다.';   
            
            update sfa_banpum_reason 
               set BARCODE_QTY    = BARCODE_QTY + 1 
                  ,BANPUM_QTY     = BANPUM_QTY + 1
                  ,AMT            = (BANPUM_QTY + 1 ) * DANGA
             where CUST_SAWON_ID = in_EMP_NO
               and CUST_ID       = in_CUST_ID
               and RCUST_ID      = in_RCUST_ID
               and ITEM_ID       = in_ITEM_CD
               and PROD_NO       = in_PRODNO;                         
                                            
            insert into sfa_banpum_reason_taginfo(  ymd,cust_id,rcust_id,item_id,prod_no,JUMUN_NO,TAGINFO,CREATE_SAWON_ID)
            values (to_char(sysdate,'YYYYMMDD') ,in_CUST_ID,in_RCUST_ID,in_ITEM_CD,in_PRODNO, in_ORDER_NO,in_TAGINFO,in_EMP_NO);
                                                                                        
            commit;
        
        ELSIF v_num = 1 and v_tnum > 0 THEN -- sfa_banpum_reason 에 데이타 있고 sfa_banpum_reason_taginfo 에도 데이타 있음
            out_CODE := 1;
            out_MSG := 'X0 xxxx 이미 등록된 자료입니다.';   
            
        ELSE    -- 업데이트
            out_CODE := 1;
            out_MSG := 'X0 이미 등록된 자료입니다.';      
            
        END IF;
        
        
        
    ELSIF in_PROCESS = '1' THEN -- 반품사유서등록 화면에서 바코드수량리셋
    
    --insert into SFA_SP_CALLED_HIST values ('SP_Z_RETURN_UPDATE',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_PROCESS,sysdate,'in_ITEM_CD:'||in_ITEM_CD ||' in_PRODNO '||in_PRODNO);
    
         SELECT COUNT(*) INTO v_num
         FROM sfa_banpum_reason a
         where  a.ymd = in_YMD
            and a.CREATE_SAWON_ID = in_EMP_NO
            and a.CUST_ID       = in_CUST_ID
            and a.RCUST_ID      = in_RCUST_ID
            and a.ITEM_ID       = in_ITEM_CD
            and a.PROD_NO       = in_PRODNO;
            
        IF v_num > 0 THEN -- 업데이트할 데이타 있음
            out_CODE := 0;
            out_MSG := 'U1 요청하신 작업이 수정되었습니다.';  
            update sfa_banpum_reason 
               set BARCODE_QTY = 0
                  ,BANPUM_QTY  = MANUAL_QTY - BARCODE_QTY
                  ,AMT         = (MANUAL_QTY - BARCODE_QTY) * DANGA                   
             where ymd             = in_YMD
               and CREATE_SAWON_ID = in_EMP_NO
               and CUST_ID         = in_CUST_ID
               and RCUST_ID        = in_RCUST_ID
               and ITEM_ID         = in_ITEM_CD
               and PROD_NO         = in_PRODNO;
                    
            delete from sfa_banpum_reason_taginfo 
             where ymd             = in_YMD
               and CREATE_SAWON_ID = in_EMP_NO   --로그인 사번이 처리한 바코드들만 삭제   
               and CUST_ID       = in_CUST_ID
               and RCUST_ID      = in_RCUST_ID
               and ITEM_ID       = in_ITEM_CD
               and PROD_NO       = in_PRODNO  ;
                     
            commit;                                            
        ELSE
            out_CODE := 1;
            out_MSG := 'X1 요청하신 작업이 수정되었습니다.' || v_num ;  

        END IF;
    
    
    
    ELSIF in_PROCESS = '2' THEN -- 수기수량변경
    
         SELECT COUNT(*) INTO v_num
           FROM sfa_banpum_reason a
          where a.ymd             = in_YMD
            and a.CREATE_SAWON_ID = in_EMP_NO
            and a.CUST_ID       = in_CUST_ID
            and a.RCUST_ID      = in_RCUST_ID
            and a.ITEM_ID       = in_ITEM_CD
            and a.PROD_NO       = in_PRODNO;
            
        IF v_num = 1 THEN -- 업데이트할 데이타 있음
            out_CODE := 0;
            out_MSG := 'U2 요청하신 작업이 수정되었습니다.';  
            update sfa_banpum_reason            
               set  MANUAL_QTY =in_MANUALQTY
                    ,BANPUM_QTY = BARCODE_QTY + in_MANUALQTY
                    ,AMT        = (BARCODE_QTY + in_MANUALQTY) * DANGA
             where ymd             = in_YMD
               and CREATE_SAWON_ID = in_EMP_NO
               and CUST_ID       = in_CUST_ID
               and RCUST_ID      = in_RCUST_ID
               and ITEM_ID       = in_ITEM_CD
               and PROD_NO       = in_PRODNO;  
            commit;                                            
        ELSE
            out_CODE := 1;
            out_MSG := 'X2 요청하신 작업이 수정되었습니다.' || v_num ;  

        END IF;
        
        
        
    ELSIF in_PROCESS = '3' THEN -- 수기입력 신규등록
        insert into SFA_SP_CALLED_HIST values ('SP_Z_RETURN_UPDATE',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_PROCESS,sysdate,
          'in_YMD:'||in_YMD||' in_CUST_ID '||in_CUST_ID||' in_RCUST_ID '||in_RCUST_ID||' in_ITEM_CD '||in_ITEM_CD ||' in_PRODNO '||in_PRODNO);
    commit;

        --신규는 금일자만 가능하도록체크 
        IF in_YMD <> TO_CHAR(SYSDATE,'YYYYMMDD') THEN        
           out_CODE := 101;
           out_MSG  := '신규입력은 오늘만 가능합니다.' ; 
           RETURN;
        END IF; 
    
         SELECT COUNT(*)
           INTO v_num
           FROM sfa_banpum_reason a
          where a.ymd = to_char(SYSDATE,'YYYYMMDD')
            and CUST_ID = in_CUST_ID
            and RCUST_ID = in_RCUST_ID
            and ITEM_ID= in_ITEM_CD
            and PROD_NO= in_PRODNO;
        IF v_num = 0 THEN -- 등록할 데이타 없음
            out_CODE := 0;
            out_MSG := 'I3 요청하신 작업이 등록되었습니다.';   
            
            -- 해당거래처 납품처로 이 반품제품의 최종주문일자
            BEGIN 
                SELECT /*+ index_desc(a PK_SLORDM) */
                       replace(a.orderdate,'-','')
                  INTO v_LAST_ORDER_YMD
                  FROM oragmp.slordm a, oragmp.slordd b
                 WHERE a.orderno = b.orderno
                   AND a.custcode = in_CUST_ID
                   AND a.ecustcode = in_RCUST_ID
                   AND b.itemcode = in_ITEM_CD
                   AND ROWNUM = 1
                ;
            EXCEPTION WHEN OTHERS THEN
               v_LAST_ORDER_YMD := '';
            END;            
            
            BEGIN 
                insert into sfa_banpum_reason
                         ( ymd
                          ,cust_id
                          ,rcust_id
                          ,item_id
                          ,prod_no
                          ,use_ymd_to
                          ,danga
                          ,cust_sawon_id
                          ,rcust_sawon_id
                          ,jumun_no
                          ,barcode_qty
                          ,manual_qty
                          ,banpum_qty
                          ,amt
                          ,seongin_state
                          ,input_dt
                          ,input_worker
                          ,create_sawon_id
                          ,banpum_reason
                          ,last_order_ymd
                          ,input_state
                         )
                 values ( to_char(SYSDATE,'YYYYMMDD')                   -- ymd              --작성일자
                          ,in_CUST_ID                                   -- cust_id          --거래처
                          ,in_RCUST_ID                                  -- rcust_id         --납품처
                          ,in_ITEM_CD                                   -- item_id          --제품
                          ,in_PRODNO                                    -- prod_no          --제조번호
                          , to_char(to_date(in_USEDYMD),'YYYY-MM-DD')   -- use_ymd_to       --사용기한
                          , in_DANGA                                    -- danga            --단가
                          , in_SAWON_ID                                 -- cust_sawon_id    --거래처담당
                          , in_RSAWON_ID                                -- rcust_sawon_id   --납품처담당
                          , ''                                          -- jumun_no         --주문번호
                          , 0                                           -- barcode_qty      --바코드수량
                          , in_MANUALQTY                                -- manual_qty       --수기수량
                          , in_MANUALQTY                                -- banpum_qty       --반품수량
                          , in_MANUALQTY *  in_DANGA                    -- amt              --금액
                          , '1'                                         -- seongin_state    --승인상태 1-대기,2-승인,3-불가
                          , sysdate                                     -- input_dt         --입력일자
                          , in_EMP_NO                                   -- input_worker     --입력자
                          , in_EMP_NO                                   -- create_sawon_id  --작성사번
                          , in_REASON_CODE                              -- banpum_reason    --반품사유코드
                          , replace(v_LAST_ORDER_YMD,'-','')            -- last_order_ymd   --이제품최종주문일자
                          ,'0'                                          -- input_state      -- 입력상태 0-대기 1-확정 
                         );
            EXCEPTION WHEN OTHERS THEN             
               out_CODE := 101;
               out_MSG  := ' 수기입력 신규등록 : '||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
                 
               ROLLBACK;
               RETURN;
            END;            

            commit;                                            
        ELSE
            out_CODE := 1;
            out_MSG := 'X3 요청하신 작업이 등록되었습니다.' || v_num ;  

        END IF; 
        
        
    
    ELSIF in_PROCESS = '4' THEN -- 목록에서 반품리스트 삭제 -  대기상태인것만 가능
     
         SELECT COUNT(*)
           INTO v_num
           FROM sfa_banpum_reason a
          where a.ymd = in_YMD
            and CUST_ID = in_CUST_ID
            and RCUST_ID = in_RCUST_ID
            and ITEM_ID= in_ITEM_CD
            and PROD_NO= in_PRODNO 
            and SEONGIN_STATE = '1';     
        IF v_num > 0 THEN -- 업데이트할 데이타 있음
            out_CODE := 0;
            out_MSG := 'D4 요청하신 작업이 처리되었습니다.';  
            delete from sfa_banpum_reason 
             where ymd         = in_YMD
               and CUST_ID     = in_CUST_ID
               and RCUST_ID    = in_RCUST_ID
               and ITEM_ID     = in_ITEM_CD
               and PROD_NO     = in_PRODNO 
               and SEONGIN_STATE = '1'; 
                        
            delete from sfa_banpum_reason_taginfo 
             where ymd         = in_YMD
               and CUST_ID     = in_CUST_ID
               and RCUST_ID    = in_RCUST_ID
               and ITEM_ID     = in_ITEM_CD
               and PROD_NO     = in_PRODNO ;
                                    
            commit;                                                                    
        ELSE
            out_CODE := 1;
            out_MSG := 'X4 삭제할 자료가 없습니다.' || v_num ;  

        END IF;      
        
        
        
        
    
    ELSIF in_PROCESS = '5' THEN -- 반품사유변경
         SELECT COUNT(*) INTO v_num
         FROM sfa_banpum_reason a
         where a.ymd             = in_YMD
           and a.CREATE_SAWON_ID = in_EMP_NO
           and a.CUST_ID       = in_CUST_ID
           and a.RCUST_ID      = in_RCUST_ID
           and a.ITEM_ID       = in_ITEM_CD
           and a.PROD_NO       = in_PRODNO;
        IF v_num = 1 THEN -- 업데이트할 데이타 있음
            out_CODE := 0;
            out_MSG := 'U5 요청하신 작업이 수정되었습니다.';  
            update sfa_banpum_reason            
               set  BANPUM_REASON =in_REASON_CODE
             where ymd             = in_YMD
               and CREATE_SAWON_ID = in_EMP_NO
               and CUST_ID       = in_CUST_ID
               and RCUST_ID      = in_RCUST_ID
               and ITEM_ID       = in_ITEM_CD
               and PROD_NO       = in_PRODNO;  
            commit;                                            
        ELSE
            out_CODE := 1;
            out_MSG := 'X5 요청하신 작업이 수정되었습니다.' || v_num ;  

        END IF;    
        
        
        
        
    ELSIF in_PROCESS = '6' THEN -- 입력상태 변경
     
        FOR ll_loop IN 1.. in_COUNT LOOP  
        
            -- 날자(10) + 거래처ID(10) + 납품처ID(10) + 아이템CD(10) + 제조번호(10) +  입력상태(1)     
                  
            v_ymd         := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '),  1 + 60*(ll_loop -1),  10));  
            v_cust_id     := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 11 + 60*(ll_loop -1),  10));  
            v_rcust_id    := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 21 + 60*(ll_loop -1),  10));  
            v_item_id     := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 31 + 60*(ll_loop -1),  10));  
            v_prod_no     := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 41 + 60*(ll_loop -1),  10));  
            v_input_state := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 51 + 60*(ll_loop -1),  10));  
                        
            
--insert into SFA_SP_CALLED_HIST values ('SP_Z_RETURN_UPDATE',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_PROCESS,sysdate,'v_cust_id:'||v_cust_id||' / v_rcust_id: '||v_rcust_id||' / v_item_id: '||v_item_id ||' / v_prod_no: '||v_prod_no||' / v_input_state: '||v_input_state);
--commit;            
            SELECT COUNT(*) INTO v_num
              FROM sfa_banpum_reason a
             where CREATE_SAWON_ID  = in_EMP_NO
               and YMD              = v_ymd
               and CUST_ID          = v_cust_id
               and RCUST_ID         = v_rcust_id
               and ITEM_ID          = v_item_id
               and PROD_NO          = v_prod_no;  
                   
            IF v_num = 1 THEN -- 업데이트할 데이타 있음
            
                out_CODE := 0;
                out_MSG := 'U6 요청하신 작업이 수정되었습니다.';  
                update sfa_banpum_reason            
                   set INPUT_STATE = v_input_state
                 where CREATE_SAWON_ID  = in_EMP_NO
                   and YMD              = v_ymd
                   and CUST_ID          = v_cust_id
                   and RCUST_ID         = v_rcust_id
                   and ITEM_ID          = v_item_id
                   and PROD_NO          = v_prod_no;  
                COMMIT;        
                                                    
            ELSE
                out_CODE := 1;
                out_MSG := 'X6 요청하신 작업이 수정되었습니다.' || v_num ;  

            END IF;
            
        END LOOP;  
        
    
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
