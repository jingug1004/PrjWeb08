CREATE PROCEDURE      SP_Z_COLLECT_AUUM_153
   (in_FLAG         IN VARCHAR2 DEFAULT NULL,  --처리구분    
    in_CUST_ID      IN VARCHAR2 DEFAULT NULL,  --거래처코드
    in_RCUST_ID     IN VARCHAR2 DEFAULT NULL,  --간납처코드
    in_AMT          IN VARCHAR2 DEFAULT NULL,  --금액
    in_SAWON_ID     IN VARCHAR2 DEFAULT NULL,  --로그인사번
    in_BIGO         IN VARCHAR2 DEFAULT NULL,  --비고          
    in_BILL_GB      IN VARCHAR2 DEFAULT NULL,  --어음구분    
    in_BILL_NO      IN VARCHAR2 DEFAULT NULL,  --어음번호   
    in_BALHANG      IN VARCHAR2 DEFAULT NULL,  --발행처 발행인     
    in_JIGEUB       IN VARCHAR2 DEFAULT NULL,  --지급은행코드
    in_JIJUMNM      IN VARCHAR2 DEFAULT NULL,  --지점명    
    in_START_YMD    IN VARCHAR2 DEFAULT NULL,  --발행일
    in_END_YMD      IN VARCHAR2 DEFAULT NULL,  --만기일 
    in_TASOOYN      IN VARCHAR2 DEFAULT NULL,  --타수여부     
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2 
)
IS
 /*---------------------------------------------------------------------------
 프로그램명  : 어음수금  
 호출프로그램 : CollectAuum           
 수정기록 : 
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼   
 ---------------------------------------------------------------------------*/    
 
    ll_count number := 0;
    
    v_sawon_id     VARCHAR2(20);  --거래처담당사원                     
    v_dept_cd      VARCHAR2(4);   --거래처담당사원소속부서
    v_colno        VARCHAR2(20);  --수금전표번호 
    
    v_str_ymd      VARCHAR2(10);  --어음발행일자
    v_end_ymd      VARCHAR2(10);  --어음만기일자 
    v_spSLSALERESULT_N_param   VARCHAR2 (256);
    IO_CURSOR      ORAGMP.TYPES.DataSet;
 
    v_temp VARCHAR2 (256);
 
    ERROR_EXCEPTION     EXCEPTION;
    
BEGIN    
 
  --insert into SFA_SP_CALLED_HIST values ('SP_Z_COLLECT_AUUM_153',to_char(sysdate,'yyyymmdd hh24miss')||' - '||in_CUST_ID,sysdate,'in_START_YMD:'||in_START_YMD||'in_TASOOYN:'||in_TASOOYN);
  -- commit;
     
                                          
    IF in_CUST_ID IS NULL OR TRIM(in_CUST_ID) = '' THEN
        out_CODE := 1;
        out_MSG := '<거래처를 반드시 선택해야 합니다.>'; 
        RAISE ERROR_EXCEPTION;
    END IF;
                                          
    IF in_AMT IS NULL OR TRIM(in_AMT) = '' THEN
        out_CODE := 1;
        out_MSG := '<수금액을 반드시 입력해야 합니다.>'; 
        RAISE ERROR_EXCEPTION;
    END IF;
    
   -- 담당사원체크
    BEGIN
        select empcode,deptcode
        into v_sawon_id,v_dept_cd
        from ORAGMP.CMCUSTM
        where plantcode = '1000'
          and custcode = in_CUST_ID ;
    EXCEPTION WHEN OTHERS THEN
        out_CODE := SQLCODE;
        out_MSG  := '<이거래처로 담당자가 지정되어 있지 않습니다.관리부로 연락하십시오. >';
        RAISE ERROR_EXCEPTION;
    END;      

   --중지거래처  통제(다른거래처에 수금입력 오류방지)   
    SELECT COUNT(*) INTO ll_count  FROM ORAGMP.CMCUSTM WHERE custcode = in_CUST_ID AND useyn = 'N';
    IF ll_count > 0 THEN
        out_CODE := 1;
        out_MSG := '<중지된 거래처입니다. 관리부로 연락하십시오.>'; 
        RAISE ERROR_EXCEPTION;
    END IF;   

    v_str_ymd  := TO_CHAR(TO_DATE(REPLACE(in_START_YMD,'.',''),'YYYYMMDD'),'YYYY-MM-DD');
    v_end_ymd  := TO_CHAR(TO_DATE(REPLACE(in_END_YMD,'.',''),'YYYYMMDD'),'YYYY-MM-DD'); 
        
    ORAGMP.spSLcol0000P1 (
                       p_div          => 'I',
                       p_plantcode    => '1000',                                --사업장
                       p_coldate      => TO_CHAR(sysdate,'YYYY-MM-DD'),         --수금일자
                       p_coldate1     => TO_CHAR(sysdate,'YYYY-MM-DD'),         --수금일자
                       p_colseq       => SUBSTR(v_colno,9,4),                   --수금전표순번
                       p_saldiv       => 'C01',                                 --영업구분  
                       p_coldiv       => '30',                                  --수금구분SL18 01-현금입금 10-통장입금 11-선수금(수출) 21-신용카드 30-약속어음 31-가계수표 32-당좌수표 35-전자어음 51-결손(대손) 52-매출할인 53-부도처리 54-잔고정리 55-잔고이월 57-판매대행 59-판매장려금 99-기타  
                       p_orderdiv     => '4',                                   --영업영역 1-도매ETC 2-도매OTC 3-간납 4-직납 5-거점 6-직접수출 7-간접수출
                       p_tasooyn      => in_TASOOYN,                            --어음 자수타수구분(N:자수,Y:타수)
                       p_custcode     => in_CUST_ID,                            --수금처코드
                       p_deptcode     => v_dept_cd,                             --수금담당부서코드
                       p_empcode      => v_sawon_id,                            --수금담당코드
                       p_ecustcode    => in_CUST_ID,    
                       p_edeptcode    => v_dept_cd,  
                       p_eempcode     => v_sawon_id,   
                       p_utdiv        => '',                                    --유통구분                       
                       p_eutdiv       => '',                                    --간납유통구분
                       p_colamt       => TO_NUMBER(in_AMT),                     --수금액
                       p_colvat       => 0,                                     --판매대행수수료(부가세)
                       p_moneycode    => '',  
                       p_exrtrate     => 0,                                     --환율
                       p_exrtamt      => 0,  
                       p_accountno    => '',  
                       p_billno       => in_BILL_NO,                            --어음번호
                       p_issdate      => v_str_ymd,                             --어음 발행일자
                       p_expdate      => v_end_ymd,                             --어음 만기일
                       p_paybank      => in_JIGEUB,                             --어음 지급은행코드
                       p_paybankbr    => in_JIJUMNM,                            --어음 은행지점명
                       p_issempnm     => in_BALHANG,                            --어음 발행처 발행인
                       p_baeseo       => '',  
                       p_cardcomp     => '',                                    --카드사
                       p_cardno       => '',                                    --카드번호
                       p_cardokno     => '',                                    --카드승인번호
                       p_carddate     => TO_CHAR(sysdate,'YYYY-MM-DD'),         --매출일자(카드)
                       p_autoyn       => '',  
                       p_divmonth     => 0,                                     --할부개월
                       p_enuriyn      => '',   
                       p_appdate      => '',
                       p_discntdate   => '',  
                       p_custprtyn    => 'N',                                   --거래장출력여부
                       p_remark       => 'SFA어음수금',                             --비고
                       p_statediv     => '09',                                  --상태구분 00:저장    01:입력  09:수금확정    99:반려
                       p_iempcode     => in_SAWON_ID,                           --입력사번
                       p_uempcode     => in_SAWON_ID,                           --수정사번
                       p_salpower     => '',  
                       p_colno        => v_colno,                               --수금번호
                       p_apprstatus   => '03',                                  --진행상태  00:입력    01:상신   03:확정완료    04:반려완료
                       p_coldtldiv    => '',  
                       p_apprclassdiv => '',  
                       p_yearmonth    => '',
                       MESSAGE        => v_spSLSALERESULT_N_param,
                       IO_CURSOR      => IO_CURSOR
                    );   
    
    if v_spSLSALERESULT_N_param = '데이터 확인' then
         out_CODE := 100;
         out_MSG := '어음수금 저장시 오류가 발생하였습니다.';      
         ROLLBACK;
    else  
         out_CODE := 0;
         out_MSG := '어음수금이 정상처리 되었습니다.';
    end if;
     
EXCEPTION
WHEN ERROR_EXCEPTION THEN 
     ROLLBACK;
WHEN OTHERS THEN
     out_CODE := SQLCODE;
     out_MSG  := '어음수금 저장오류 : '||(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
     ROLLBACK;
END;
/
