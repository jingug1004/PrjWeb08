CREATE PROCEDURE      SP_Z_LOGIN_132
(
    in_SAWON_ID       IN VARCHAR2,   -- 로그인사번(인사사번으로로그인한다)
    in_SAWON_PSWD     IN VARCHAR2,   -- 로그인비밀변경
    in_HP             IN VARCHAR2,   -- 핸드폰 번호
    in_GUBUN          IN VARCHAR2,   -- A:안드로이드, W:웹
    in_COMM_DT        IN VARCHAR2,   -- 공통코드 변경유무 기준일자시간(14자리, 24시간)
    in_DEVICEID       IN VARCHAR2,  -- 디바이스 ID 
    in_BUILDID        IN VARCHAR2,  -- 빌드 ID
    out_CODE          OUT NUMBER,
    out_MSG           OUT VARCHAR2,
    out_COUNT         OUT NUMBER,
    out_RESULT        OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 안드로이드폰로그인
 호출프로그램 : LoginActivity   spLogin
  ---------------------------------------------------------------------------
 전산실은 모든 프로그램의 로그인은 인사사번으로 하기로 하였다.
 따라서 로그인은 인사사번으로 하고 권한이 맞으면 영업사번으로 업무를 처리한다.
 수정기록   :2013.02.16 KTA - 카드리더기없이수기카드사용가능여부컬럼 추가 
             2013.03.04 KTA - 위치속이는프로그램 노트에 설치되어 있는지 관련 수정   
             2013.07.05 CHOE - 고유ID값을 저장하고 저장된 값이 있으면 비교해 다른사람이 로그인 불가하다록 한다.
             2013.07.19 KTA - 고유ID값체크시 영업사원이아니면 다른ID 로그인 가능하도록 한다.  
             2013.11.12 KTA - 방문계획일시 제어여부 컬럼을 공통코드에 추가. 필요시 풀어줄수 있도록함. 
             2014.06.10 KTA - ERP비밀번호통합을 위하여 1111을 비번으로 하는 모든 사용자의 비번변경유도 로직 추가
             2015.05.15 KTA - SFA상단에 사원명 바로 옆에 직급을 표시하기 위해 직급코드명추가
             2017.11.01  KTA - NEW ERP메 맞게 컨버젼  
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    v_cnt                NUMBER;
    v_out_code           NUMBER;
    v_out_msg            VARCHAR2(100);
    v_out_count          NUMBER;
    
    v_retir_dt           VARCHAR2(8);
    v_engag_div          VARCHAR2(5);
    v_sawon_pswd         VARCHAR2(20);
    v_hp                 VARCHAR2(12);
    
    v_change_cnt         NUMBER;
    v_change_yn          CHAR(1);
    v_notice_cnt         NUMBER; 
    v_time_out           VARCHAR2(50);
    v_version            VARCHAR2(10); 
        
    v_msg_no             NUMBER;
    v_seq                NUMBER;
    v_message            VARCHAR2(4000);
    
    v_bt_id              VARCHAR2(30);       
    v_bt_nm              VARCHAR2(30);  
    v_fakegpsapp_nm      VARCHAR2(30);  
    v_visitplan_control_yn VARCHAR2(1); --방문계획일시제어여부 : 임시로 제어하지 안을때 N 로 만든다::영업시스템 공통코드에 등록됨.
    
    v_buildid            VARCHAR2(30); 
    v_android_id_deny    VARCHAR2(1);
    v_device_empcode     VARCHAR2(30);
    v_device_deptcd      VARCHAR2(30); 
     
BEGIN 
 
    --사번오류체크   
    /*
    IF in_SAWON_ID <> '2012060' THEN
       out_CODE := 101;
       out_MSG := '정상화 될때 까지 잠시 사용 중지 합니다. ';  
       RETURN;
    END IF; 
    */
    
    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_LOGIN_132','1',sysdate,in_SAWON_ID);
    --commit;
    
    out_CODE := 0;
    out_MSG := '로그인이 정상 처리되었습니다.';
    
    --버전체크
    SELECT MAX(ver) INTO v_version FROM SFA_SYS_VERSION;
                  
    --사번오류체크          
    IF in_SAWON_ID IS NULL OR TRIM(in_SAWON_ID) = '' THEN
       out_CODE := 101;
       out_MSG := '사원ID를 입력하십시오.';  
       RETURN;
    END IF;
    
    --비번오류체크
    IF in_SAWON_PSWD IS NULL OR TRIM(in_SAWON_PSWD) = '' THEN
       out_CODE := 102;
       out_MSG := '패스워드를 입력하십시오.'; 
       RETURN;
    END IF;
    
    --로그인구분( A:안드로이드, W:웹) 오류체크
    IF in_GUBUN IS NULL OR TRIM(in_GUBUN) = '' THEN
       out_CODE := 103;
       out_MSG := '로그인구분이 누락되었습니다(관리자에 연락바랍니다.)'; 
       RETURN;
    END IF;

    --로그인구분( A:안드로이드, W:웹) A 이면 공통코드테이블의 변경유무 체크
    IF in_GUBUN = 'A'  THEN 
        IF in_COMM_DT IS NULL THEN   -- 변경기준일자가 없는 경우에는 무조건 공통코드를 받는다.
            v_change_yn := 'Y';
        ELSE 
            select COUNT(*) INTO v_change_cnt from ORAGMP.CMCOMMONM WHERE TO_CHAR(updatedt, 'YYYYMMDDHH24MISS') >= in_COMM_DT;
             
            IF v_change_cnt > 0 OR in_COMM_DT IS NULL THEN   -- 공통코드 변경사항이 있는 경우
                v_change_yn := 'Y';
            ELSE                       -- 없는 경우
                v_change_yn := 'N'; 
            END IF;
        END IF;
    END IF;
            
    
    --인사마스터 존재 체크    
    select COUNT(*) INTO v_num from ORAGMP.CMEMPM where empcode = in_SAWON_ID; 
    IF (v_num = 0) THEN
        out_CODE := 104;
        out_MSG := '사원 정보가 존재하지 않습니다.(총무부에 문의하십시오)';    
        RETURN;
    END IF; 
     
    --로그인정보테이블 존재체크    
    SELECT COUNT(*) INTO v_num FROM ORAGMP.ELECTRONICSIGN WHERE empcode = in_SAWON_ID ;    
    IF (v_num = 0) THEN
        out_CODE := 105;
        out_MSG := '로그인 정보가 존재하지 않습니다.(관리자에게 문의하십시오)';     
        RETURN;
    END IF;
         
    --입력받은 인사사번이 사용가능한지 체크 
    SELECT COUNT(*) INTO v_num FROM ORAGMP.ELECTRONICSIGN WHERE empcode = in_SAWON_ID and exityn = 'Y';
    IF (v_num > 0) THEN
        out_CODE := 106;
        out_MSG := '입력한 사번은 사용중지중입니다.';     
        RETURN;
    END IF;

   --비밀번호 암호화하여여 비교 :: 새로운 비빈번호 비교로직 적용시까지 막음 kta 2017.11.06 
     --사번오류체크   
   
    v_cnt := 0; 
    select count(*) into v_cnt from ORAGMP.CMEMPM where buildid = in_BUILDID and deptcode in ('0007','0004','0302','0114','0527'); --전산팀,관리부,총괄팀장(관리총무구매경리),기획부,법무팀  
    IF v_cnt = 0 THEN  
        select count(*)  into v_cnt from ORAGMP.ELECTRONICSIGN where empcode = in_SAWON_ID and pwd = hanacomm.hanacryptpass(in_SAWON_PSWD);  
        
        if v_cnt = 0 then
            out_CODE := 107;
            out_MSG := '비밀번호가 일치하지 안습니다..';
            RETURN;
        end if;     
    END IF; 

   -- insert into SFA_SP_CALLED_HIST values ('SP_SFA_LOGIN_132','2',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_DEVICEID:'||in_DEVICEID||'/in_BUILDID:'||in_BUILDID);
   -- commit;
        
     -- 사원정보 
    select trim(btid),trim(btname),trim(buildid)  into v_bt_id,v_bt_nm,v_buildid  from ORAGMP.CMEMPM where empcode = in_SAWON_ID; 
    
    -- 로그인하는 기기가 특정부서의  기기이면 빌드아이디체크 체크하지 않음 
    v_cnt := 0;
    select count(*) into v_cnt from ORAGMP.CMEMPM where buildid = in_BUILDID and deptcode in ('0007','0004','0302','0114','0527'); --전산팀,관리부,총괄팀장(관리총무구매경리),기획부,법무팀  
    IF v_cnt > 0 THEN
       v_android_id_deny := 'Y'; 
    ELSE
        
       -- 로그인하는 기기가 특정부서의 기기가 아니면 빌드아이디체크 체크 
        IF  v_buildid IS NULL THEN
            UPDATE ORAGMP.CMEMPM SET buildid = in_BUILDID WHERE empcode = in_SAWON_ID;
            v_android_id_deny := 'Y';  
                     
        ELSE  
      
            IF v_buildid = in_BUILDID THEN
               v_android_id_deny := 'Y';   
            ELSE      
               v_android_id_deny := 'N';   --로그인 불가  
               out_CODE := 111;
               out_MSG  := 'ID ['||SUBSTR(in_BUILDID,1,4)||'****'||SUBSTR(in_BUILDID,9,4) || '****] 기기사용자정보가 일치하지 않습니다. 기획실로 연락바랍니다.';   
               RETURN;                                       
            END IF;
        END IF; 
    END IF;

    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_LOGIN_132','3',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_DEVICEID:'||in_DEVICEID||'/in_BUILDID:'||in_BUILDID);
   -- commit;     
    
    --전산팀 긴급공지 처리
    BEGIN
        SELECT msg_no,message INTO v_msg_no,v_message FROM SFA_SYS_HOTMSG A 
         WHERE NOT EXISTS (SELECT 'X' FROM SFA_SYS_HOTMSGREADERS WHERE MSG_NO = A.MSG_NO  AND SAWON_ID = in_SAWON_ID)
           AND CURRENT_MSG_YN = 'Y';
    EXCEPTION WHEN NO_DATA_FOUND THEN
        v_android_id_deny := 'Y'; 
    END;   
    
    IF v_msg_no > 0 THEN           
       SELECT max(seq) + 1 INTO v_seq FROM SFA_SYS_HOTMSGREADERS WHERE msg_no = v_msg_no;         
       INSERT INTO SFA_SYS_HOTMSGREADERS VALUES(v_msg_no,nvl(v_seq,1),in_SAWON_ID,sysdate);
    END IF; 

   -- insert into SFA_SP_CALLED_HIST values ('SP_SFA_LOGIN_132','4',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_DEVICEID:'||in_DEVICEID||'/in_BUILDID:'||in_BUILDID);
    --commit;
    
    -- 공지사항(안읽은 공지사항) 건수 넘겨주기
    -- 공지사항은 인사사번기준으로 데이터가 생성되어 있으므로 인사사번으로 검색해야 함.      
    select count(*)
      into v_notice_cnt
      from (
               SELECT noticeid                      AS out_BOARD_ID     -- 공지사항 ID
                     ,ROWNUM                        AS out_BOARD_SEQ    -- 공지 번호(SEQ)
                     ,title                         AS out_TITLE        -- 공지 제목
                     ,noticecontents                AS out_DISCRIPTION  -- 공지 내용
                     ,replace(noticedate,'-','')    AS out_START_DATE   -- 공지 시작일
                     ,READ_YN                       AS out_READ_YN      -- 읽었는지여부
                 FROM (
                        SELECT noticeid
                              ,title
                              ,noticecontents
                              ,noticedate
                              ,(SELECT DECODE (SIGN (COUNT (*)), 1, 'Y', 'N') FROM ORAGMP.NOTICEMANAGEREADHIST WHERE noticeid = a.noticeid AND readloginid = in_SAWON_ID ) READ_YN
                          FROM ORAGMP.NOTICEMANAGE a
                         WHERE SFA = 'Y' 
                      )   
           )
      where out_READ_YN = 'N'
    ;  
     
          
    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_LOGIN_132','5',sysdate,'in_SAWON_ID:'||in_SAWON_ID||'/in_DEVICEID:'||in_DEVICEID||'/in_BUILDID:'||in_BUILDID);
   -- commit;
      
   -- 타임아웃. 분단위/정수형 스트링 구현
    v_time_out := '10';     -- 10 분 설정

    --위치속이는앱이름을 찾도록 공통테이블에서 찾음:: 공통코드에서 관리하도록 해야함  kta 
    v_fakegpsapp_nm := 'fakegps';
        
 
    -- 방문계획일시 제어여부::  컬럼없이 전산팀이 이곳에서 제어 kta
    v_visitplan_control_yn := 'N';  
    
    
    
    out_COUNT := 1;         
    -- sql문 필요함
    OPEN out_RESULT FOR
    SELECT A.empcode                      AS out_SAWON_ID   -- 사원ID
          ,A.empname                      AS out_SAWON_NM   -- 사원명
          ,''                             AS out_SAWON_PSWD -- 패스워드
          ,A.deptcode                     AS out_DEPT_CD    -- 부서코드
          ,B.deptname                     AS out_DEPT_NM    -- 부서명
          ,A.classdiv                     AS out_ASSIGN_CD  -- 직책코드(27020:관리이사, 27030:팀장, 27040:팀원)참고: 27000은 sfa상에서 전체권한의 의미를 부여함.
          ,oragmp.fncommonnm ('COMM','PS42',classdiv)    AS out_ASSIGN_NM -- 직책코드명(27020:관리이사, 27030:팀장, 27040:팀원)
          ,v_change_yn                    AS out_CHANGE_YN  -- 공통코드 변경여부(Y 이면 변경사항이 있음)
          ,v_notice_cnt                   AS out_NOTICE_CNT -- 안읽은 공지사항 건수
          ,v_time_out                     AS out_TIME_OUT   -- 타임아웃. 분단위/정수형 스트링 구현
          ,v_version                      AS out_VERSION    -- sfa 버전
          ,v_message                      AS out_MESSAGE    -- 긴급공지 
          ,A.PDAID                        AS out_PDA_ID     -- 카드리더기기사용을 위한 VAN 사에서 제공한 번호 영업사원에게 부여되어야 수금가능함
          ,A.partdiv                      AS out_PART_GB    -- 직능 = 파트 (01-도매,02-종병,03-세미,04-로컬,05-도매로컬,06-O/A,07-제주지점  
          ,v_bt_id                        AS out_BT_ID      -- 카드리더기 BT아이디
          ,v_bt_nm                        AS out_BT_NM      -- 카드리더기 BT기기명
          ,B.deptname                     AS out_INSA_DEPT_NM --인사부서명
          ,'Y'                            AS out_BT_FREE_YN   --카드리더기없이수금가능여부(Y-가능,N-불가) 사원마다 지정할 수 있다 
          ,v_fakegpsapp_nm                AS out_FAKEGPSAPP_NM   -- 위치속이는앱이름
          ,TO_CHAR(SYSDATE,'YYYYMMDD')    AS out_SERVER_YMD --서버일자    
          ,v_android_id_deny              AS out_ANDROID_ID_DENY  -- sfa사용가능여부     
          ,v_visitplan_control_yn         AS out_VISITPLAN_CONTROL_YN   --방문계획일시 제어여부 : 임시로 제어하지 안을때 N 로 만든다:  컬럼없이 전산팀이 이곳에서 제어 kta
          ,oragmp.fncommonnm ('COMM','PS01',a.gradediv)      AS out_GRAD_NM     --직급코드명
          ,oragmp.fncommonnm ('COMM','SL90',a.partdiv)       AS out_PARTDIV_NM --직능명
          ,(SELECT filter1 FROM oragmp.CMCOMMONM WHERE CMMCODE = 'SL90' AND DIVCODE = A.PARTDIV)  AS out_DAYPERCALL --규정콜수
      FROM ORAGMP.CMEMPM A 
          ,ORAGMP.CMDEPTM B  
     WHERE A.deptcode      = B.deptcode(+)
       AND A.empcode       = in_SAWON_ID
     ; 
 

     --insert into SFA_SP_CALLED_HIST values ('SP_SFA_LOGIN_132','2',sysdate,in_SAWON_ID);
     --commit;

EXCEPTION 
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 
END;
/
