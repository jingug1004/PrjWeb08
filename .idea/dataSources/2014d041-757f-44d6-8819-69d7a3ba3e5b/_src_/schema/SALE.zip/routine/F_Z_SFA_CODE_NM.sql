CREATE FUNCTION      F_Z_SFA_CODE_NM  -- 그룹코드-구분별 ITEM명 가져오기(SFA사용) 
(
    in_GUBUN    IN  VARCHAR2
,   in_ITEM_CD  IN  VARCHAR2
) 
RETURN VARCHAR2 IS

    v_item_nm   VARCHAR2(50);
    
BEGIN

    IF in_GUBUN = 'DIRECT_YN' THEN    -- 직간납여부
        CASE 
            WHEN TRIM(in_ITEM_CD) = '1' THEN v_item_nm := '직납처';
            WHEN TRIM(in_ITEM_CD) = '2' THEN v_item_nm := '간납처';
            ELSE v_item_nm := '미정의';
        END CASE;
    ELSIF in_GUBUN = 'TRADE_YN' THEN    -- 거래유무
        CASE 
            WHEN TRIM(in_ITEM_CD) = 'Y' THEN v_item_nm := '거래';
            WHEN TRIM(in_ITEM_CD) = 'N' THEN v_item_nm := '비거래';
            ELSE v_item_nm := '미정의';
        END CASE;
    ELSIF in_GUBUN = 'VISIT_KIND' THEN    -- 방문유형
        CASE 
            WHEN TRIM(in_ITEM_CD) = '0' THEN v_item_nm := '방문계획';
            WHEN TRIM(in_ITEM_CD) = '1' THEN v_item_nm := '추가계획';
            ELSE v_item_nm := '미정의';
        END CASE;
    ELSIF in_GUBUN IN ('FLOW', 'FLOW_CODE')THEN    -- 유통구분
        CASE 
            WHEN TRIM(in_ITEM_CD) = '1' THEN v_item_nm := '도매';
            WHEN TRIM(in_ITEM_CD) = '2' THEN v_item_nm := '종합병원';
            WHEN TRIM(in_ITEM_CD) = '3' THEN v_item_nm := '준종합';
            WHEN TRIM(in_ITEM_CD) = '4' THEN v_item_nm := '병,의원';
            ELSE v_item_nm := '미정의';
        END CASE;        
    ELSIF in_GUBUN = 'APPLY_GUBUN' THEN    -- 거래요청상태
       CASE 
            WHEN TRIM(in_ITEM_CD) = '0' THEN v_item_nm := '요청대상';   -- 신규등록
            WHEN TRIM(in_ITEM_CD) = '1' THEN v_item_nm := '요청진행';   -- 승인요청
 --           WHEN TRIM(in_ITEM_CD) = '2' THEN v_item_nm := '승인';
 --           WHEN TRIM(in_ITEM_CD) = '3' THEN v_item_nm := '부결';
            ELSE v_item_nm := '미정의';
        END CASE;        
    ELSIF in_GUBUN = 'DEL_YN' THEN    -- 삭제여부
       CASE 
            WHEN TRIM(in_ITEM_CD) = 'Y' THEN v_item_nm := '삭제';
            WHEN TRIM(in_ITEM_CD) = 'N' THEN v_item_nm := '사용';
            ELSE v_item_nm := '미정의';
        END CASE;    
--    ELSIF in_GUBUN = 'CLIENT_GUBUN' THEN   -- 고객구분(하나 ERP 코드 사용) 
--
    ELSIF in_GUBUN = 'MALE' THEN    -- 성별
       CASE 
            WHEN TRIM(in_ITEM_CD) = '1' THEN v_item_nm := '남';
            WHEN TRIM(in_ITEM_CD) = '2' THEN v_item_nm := '여';
            ELSE v_item_nm := '미정의';
        END CASE;        
    ELSIF in_GUBUN = 'BIRTHDAY_GUBUN' THEN    -- 생일구분
       CASE 
            WHEN TRIM(in_ITEM_CD) = '1' THEN v_item_nm := '음력';
            WHEN TRIM(in_ITEM_CD) = '2' THEN v_item_nm := '양력';
            ELSE v_item_nm := '미정의';
        END CASE;        
    ELSIF in_GUBUN = 'MARRY_YN' THEN    -- 결혼유무
       CASE 
            WHEN TRIM(in_ITEM_CD) = 'Y' THEN v_item_nm := '결혼';
            WHEN TRIM(in_ITEM_CD) = 'N' THEN v_item_nm := '미혼';
            ELSE v_item_nm := '미정의';
        END CASE;        
    ELSIF in_GUBUN = 'APPLY_YN' THEN    -- 거래요청상태
       CASE 
            WHEN TRIM(in_ITEM_CD) = 'Y' THEN v_item_nm := '승인';
            WHEN TRIM(in_ITEM_CD) = 'R' THEN v_item_nm := '부결';
            WHEN TRIM(in_ITEM_CD) = 'C' THEN v_item_nm := '취소';
            
            WHEN TRIM(in_ITEM_CD) = '0' THEN v_item_nm := '계획승인대기';
            WHEN TRIM(in_ITEM_CD) = '1' THEN v_item_nm := '방문계획승인';
            WHEN TRIM(in_ITEM_CD) = '2' THEN v_item_nm := '방문계획반려';
            
            WHEN TRIM(in_ITEM_CD) = '3' THEN v_item_nm := '추가승인대기';
            WHEN TRIM(in_ITEM_CD) = '4' THEN v_item_nm := '추가방문승인';
            WHEN TRIM(in_ITEM_CD) = '5' THEN v_item_nm := '추가방문반려';
            
            WHEN TRIM(in_ITEM_CD) = '6' THEN v_item_nm := '거래요청대기';
            WHEN TRIM(in_ITEM_CD) = '7' THEN v_item_nm := '거래요청승인';
            WHEN TRIM(in_ITEM_CD) = '8' THEN v_item_nm := '거래요청반려';
            
            ELSE v_item_nm := '미정의';
        END CASE;        
    ELSIF in_GUBUN = 'TOGETHER_YN' THEN    -- 동행여부
       CASE 
            WHEN TRIM(in_ITEM_CD) = 'Y' THEN v_item_nm := '동행';
            WHEN TRIM(in_ITEM_CD) = 'N' THEN v_item_nm := '미동행';
            ELSE v_item_nm := '미정의';
        END CASE;        
    ELSIF in_GUBUN = 'CONFIRM_YN' THEN    -- 방문CALL 인정여부
       CASE 
            WHEN TRIM(in_ITEM_CD) = 'Y' THEN v_item_nm := '인정';
            WHEN TRIM(in_ITEM_CD) = 'N' THEN v_item_nm := '불인정';
            ELSE v_item_nm := '미정의';
        END CASE;       
    ELSIF in_GUBUN = 'STATUS' THEN    -- 방문관리 좌표보정 상태
       CASE 
            WHEN TRIM(in_ITEM_CD) = 'Y' THEN v_item_nm := '방문';
            WHEN TRIM(in_ITEM_CD) = '00' THEN v_item_nm := '미방문';
            WHEN TRIM(in_ITEM_CD) = '01' THEN v_item_nm := '진행중';
            WHEN TRIM(in_ITEM_CD) = '90' THEN v_item_nm := '보정';
            WHEN TRIM(in_ITEM_CD) = '98' THEN v_item_nm := '이탈';  --??
            WHEN TRIM(in_ITEM_CD) = '99' THEN v_item_nm := '일치';
            ELSE v_item_nm := '미정의';
        END CASE;        
    ELSIF in_GUBUN = 'CUST_STAT_GB' THEN    --거래처상태
       CASE 
            WHEN TRIM(in_ITEM_CD) in('01','1') THEN v_item_nm := '주';
            WHEN TRIM(in_ITEM_CD) in('02','2') THEN v_item_nm := '활';
            WHEN TRIM(in_ITEM_CD) in('03','3') THEN v_item_nm := '비';
            ELSE v_item_nm := '미정의';
        END CASE;        
    ELSE
        v_item_nm := '미정의';
    END IF;
        
    RETURN v_item_nm;
    
EXCEPTION
WHEN NO_DATA_FOUND THEN
    RETURN '';
END;
/
