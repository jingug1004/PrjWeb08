CREATE function      F_GET_CUST_HALINYOUBO_AMT
        ( A_CUST_ID      VARCHAR2, -- 거래처코드 
          A_YMD          VARCHAR2, -- 검색 기준일
          A_CALL_GB      VARCHAR2  -- 호츨구분 'ME'-매출할인보유 'SU'-수금할인보유   
        )
   RETURN NUMBER
AS
   user_err         exception   ; 
   n_rtn_value      NUMBER;
   v_curr_error     VARCHAR2(250);

/*----------------------------------------------------------------
  미도래 어음을 가져온다
----------------------------------------------------------------*/
BEGIN
  
    IF A_CALL_GB = 'ME' THEN
    
       SELECT NVL(SUM(A.HAL_AMT),0) + NVL(SUM(A.BOSANG_AMT),0) 
         INTO n_rtn_value       
         FROM SALE_TURNSDAY_BATCH A
             ,SALE0208 B
        WHERE A.DEAL_NO = B.DEAL_NO AND A.INPUT_SEQ = B.INPUT_SEQ AND A.YMD = B.YMD AND A.ITEM_ID = B.ITEM_ID
          AND A.CUST_ID = A_CUST_ID
          AND A.YMD <= TO_DATE(A_YMD,'YYYYMMDD')
          AND NVL(B.DC_EN_YN,'N') = 'N';
            
          
    ELSIF  A_CALL_GB = 'SU' THEN
    
       SELECT NVL(SUM(A.HALIN_AMT),0) 
         INTO n_rtn_value       
         FROM SALE_TURNSDAY2_BATCH A 
             ,SALE0208 B 
             ,SALE0401 C 
        WHERE A.JUNPYO_NO = B.DEAL_NO 
          AND A.YMD       = B.YMD 
          AND A.JUNPYO_NO = C.JUNPYO_NO 
          AND A.CUST_ID   = A_CUST_ID
          AND A.YMD <= TO_DATE(A_YMD,'YYYYMMDD')
          AND NVL(B.DC_EN_YN,'N') = 'N' 
          AND NVL(C.HALIN_JUNGRI_YN,'N') LIKE 'N' ;
          
    ELSIF  A_CALL_GB = 'MESU' THEN
   
       SELECT SUM(AMT) 
         INTO n_rtn_value       
         FROM (
               SELECT NVL(SUM(A.HAL_AMT),0) + NVL(SUM(A.BOSANG_AMT),0) AS AMT 
                 FROM SALE_TURNSDAY_BATCH A
                     ,SALE0208 B
                WHERE A.DEAL_NO = B.DEAL_NO AND A.INPUT_SEQ = B.INPUT_SEQ AND A.YMD = B.YMD AND A.ITEM_ID = B.ITEM_ID
                  AND A.CUST_ID = A_CUST_ID
                  AND A.YMD <= TO_DATE(A_YMD,'YYYYMMDD')
                  AND NVL(B.DC_EN_YN,'N') = 'N'
               UNION ALL
               SELECT NVL(SUM(A.HALIN_AMT),0)                           AS AMT
                 FROM SALE_TURNSDAY2_BATCH A 
                     ,SALE0208 B 
                     ,SALE0401 C 
                WHERE A.JUNPYO_NO = B.DEAL_NO 
                  AND A.YMD       = B.YMD 
                  AND A.JUNPYO_NO = C.JUNPYO_NO 
                  AND A.CUST_ID   = A_CUST_ID
                  AND A.YMD <= TO_DATE(A_YMD,'YYYYMMDD')
                  AND NVL(B.DC_EN_YN,'N') = 'N' 
                  AND NVL(C.HALIN_JUNGRI_YN,'N') LIKE 'N' 
              );       
    
    END IF;
                                          
       
    RETURN n_rtn_value;

EXCEPTION WHEN user_err THEN
               RAISE_APPLICATION_ERROR(-20001, substrb(v_curr_error,1,250));
          WHEN OTHERS THEN
               RAISE_APPLICATION_ERROR(-20002, substrb(v_curr_error||SQLERRM,1,250));
END;
/
