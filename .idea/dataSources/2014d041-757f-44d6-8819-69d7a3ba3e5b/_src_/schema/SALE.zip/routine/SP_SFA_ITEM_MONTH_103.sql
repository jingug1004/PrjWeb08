CREATE PROCEDURE      SP_SFA_ITEM_MONTH_103
(
    in_SAWON_ID          IN  VARCHAR2,  --영업사원id
    in_CUST_ID           IN  VARCHAR2,  
    in_FROM_DT           IN  VARCHAR2,  
    in_TO_DT             IN  VARCHAR2,  
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 1달간주문제품리스트조회
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER;
    v_Item_No            NUMBER;
    v_temp1              NUMBER;
    
    SAWON_ID_NULL        EXCEPTION;
    CUST_ID_NULL         EXCEPTION; 
    FROM_DT_NULL         EXCEPTION; 
    TO_DT_NULL           EXCEPTION; 
         
BEGIN
    
    IF in_SAWON_ID IS NULL THEN
        RAISE SAWON_ID_NULL;
    END IF;
    
    IF in_CUST_ID IS NULL THEN
        RAISE CUST_ID_NULL;
    END IF;    
    
    IF in_FROM_DT IS NULL THEN
        RAISE FROM_DT_NULL;
    END IF;    
    
    IF in_TO_DT IS NULL THEN
        RAISE TO_DT_NULL;
    END IF;    
    

   SELECT count(distinct b.item_id)
     INTO v_num
     FROM SALE_ON.SALE0203 A,
          SALE_ON.SALE0204 B
    WHERE A.GUMAE_NO = B.GUMAE_NO
      AND A.sawon_id = in_SAWON_ID      
      AND A.CUST_ID  = in_CUST_ID      
      AND A.YMD      BETWEEN TO_DATE(in_FROM_DT,'YYYYMMDD') AND TO_DATE(in_TO_DT,'YYYYMMDD');
  
    out_CODE := 1;
    out_COUNT := v_num;

    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_COUNT := 1;
        out_CODE := 0;
        out_MSG := '검색 확인rrr완료';    
         
        OPEN out_RESULT FOR
        
        SELECT A.ITEM_ID              AS out_ITEM_ID        -- 제품코드
             , A.ITEM_NM              AS out_ITEM_NM        -- 제품명
             , A.STANDARD             AS out_STANDARD       -- 규격
             , A.UNIT                 AS out_UNIT           -- 단위
             , A.OUT_DANGA            AS out_DANGA          -- 단가(출고단가)  
             , NULL                   AS out_STOCK          -- 재고
             , A.CHUL_YN              AS out_CHUL_YN        -- 출하중지여부 (Y:중지, N:출하)
             , DECODE(A.CHUL_YN, 'Y', '중지', '출하')  AS out_CHUL_NM   -- 출하중지여부명
             , NULL                   AS out_STOCK_GUBUN    -- 재고구분
             , ''                     AS out_VIEW_TXT       -- 효능효과
             , ''                     AS out_ITEM_POINT     -- 특장점
             , ''                     AS out_EFFECT         -- 효능효과(제품상세설명)
             , 'a'                     AS out_ITEM_USE_DOES  -- 용량용법
             , ''                     AS out_ITEM_ATTENTION -- 주의사항
             , ''                     AS out_PHOTO          -- 이미지     
             , ''                     AS out_ITEM_1SPEECH   -- 1분 스피치
             , ''                     AS out_ITEM_3SPEECH   -- 3분 스피치
             , A.SAUPJANG_CD          AS out_SAUPJANG_CD    --사업장코드(101-하길,102-도매,103-도매(향정))          
          FROM SALE0004 A 
              ,SFA_OFFICE_ITEMDOC  B
         WHERE A.ITEM_ID  = B.ITEM_CODE(+)
           AND A.ITEM_ID  in (
                               SELECT distinct b.item_id
                                 FROM SALE_ON.SALE0203 A,
                                      SALE_ON.SALE0204 B
                                WHERE A.GUMAE_NO = B.GUMAE_NO
                                  AND A.sawon_id = in_SAWON_ID      
                                  AND A.CUST_ID  = in_CUST_ID      
                                  AND A.YMD      BETWEEN TO_DATE(in_FROM_DT,'YYYYMMDD') AND TO_DATE(in_TO_DT,'YYYYMMDD')
                              )
         ORDER BY ITEM_NM;          
         
         /*
         SELECT COUNT(*) INTO v_temp1
          FROM SALE0004 A 
              ,SFA_OFFICE_ITEMDOC  B
         WHERE A.ITEM_ID  = B.ITEM_CODE(+)
           AND A.ITEM_ID  in (
                               SELECT distinct b.item_id
                                 FROM SALE_ON.SALE0203 A,
                                      SALE_ON.SALE0204 B
                                WHERE A.GUMAE_NO = B.GUMAE_NO
                                  AND A.sawon_id = in_SAWON_ID      
                                  AND A.CUST_ID  = in_CUST_ID      
                                  AND A.YMD      BETWEEN TO_DATE(in_FROM_DT,'YYYYMMDD') AND TO_DATE(in_TO_DT,'YYYYMMDD')
                              )
         ORDER BY ITEM_NM;                   
         
         DBMS_OUTPUT.PUT_LINE('v_temp1 :'||TO_CHAR(v_temp1));
         */
    END IF;
    
EXCEPTION
WHEN SAWON_ID_NULL THEN
   out_CODE := '1';
   out_MSG  := '사원ID가 누락되었습니다.';
   DBMS_OUTPUT.PUT_LINE('out_MSG :'||out_MSG);
   
WHEN CUST_ID_NULL THEN
   out_CODE := '2';
   out_MSG  := '거래처가 누락되었습니다.';
   DBMS_OUTPUT.PUT_LINE('out_MSG :'||out_MSG);
   
   
WHEN FROM_DT_NULL THEN
   out_CODE := '3';
   out_MSG  := 'FROM 일자가 누락되었습니다.';
   DBMS_OUTPUT.PUT_LINE('out_MSG :'||out_MSG);
   
   
WHEN TO_DT_NULL THEN
   out_CODE := '4';
   out_MSG  := 'TO 일자가 누락되었습니다.';
   DBMS_OUTPUT.PUT_LINE('out_MSG :'||out_MSG);
   
   
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
   DBMS_OUTPUT.PUT_LINE('out_MSG OTHERS :'||out_MSG);
   
END;

/
