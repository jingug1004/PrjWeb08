CREATE PROCEDURE      SP_SFA_OFFICE_12
(
    in_SANGBYEONG_NM    IN  VARCHAR2,  
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
        /*---------------------------------------------------------------------------
        프로그램명   : 상병코드조회  
        호출프로그램 : SANGBYEONG.JAVA
        ---------------------------------------------------------------------------*/    

        v_num                NUMBER;
    
BEGIN
    
    SELECT COUNT(*)
      INTO v_num
      FROM /*SALE.SFA_BRUSH@HANA3_SALE.HANA.CO.KR*/SFA_OFFICE_SANGBYUNGCODE
     WHERE SANGBYUNG_NM LIKE '%'||NVL(in_SANGBYEONG_NM, '%')||'%';
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT SANGBYUNG_CD AS out_SANGBYEONG_CD,        -- 브로셔 CD
               SANGBYUNG_SEQ AS out_SANGBYEONG_SEQ,       -- 브로셔 SEQ
               SANGBYUNG_NM AS out_SANGBYEONG_NM,        -- 브로셔 명
               SANGBYUNG_YN AS out_SANGBYEONG_YN,        -- 브로셔 사용여부
               ITEM_PATH AS out_SANGBYEONG_PATH,       -- FILE PATH
               ITEM_NAME AS out_SANGBYEONG_NAME,        -- FILE 명
               SAVE_ITEM_NAME AS out_SANGBYEONG_SAVE -- DB에 저장된 파일명 
          FROM /*SALE.SFA_BRUSH@HANA3_SALE.HANA.CO.KR*/SFA_OFFICE_SANGBYUNGCODE
     WHERE SANGBYUNG_NM LIKE '%'||NVL(in_SANGBYEONG_NM, '%')||'%'
     ORDER BY SANGBYUNG_NM;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
