CREATE PROCEDURE      SP_SFA_ADMIN_08    -- 제품상세설명 등록
(
    in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(등록:1, 수정:2, 삭제:3)
    in_ITEM_CD           IN  NUMBER,       -- 제품상세코드(품목코드)    
    in_ITEM_NM           IN  VARCHAR2,     -- 제품상세명
    in_ITEM_POINT        IN  VARCHAR2,     -- 특장점
    in_ITEM_EFFECT       IN  VARCHAR2,     -- 효능효과
    
    in_ITEM_USE_DOES     IN  VARCHAR2,     -- 용량,용법
    in_ITEM_ATTENTION    IN  VARCHAR2,     -- 주의사항
    in_ITEM_PHOTO        IN  BLOB,         -- 제품이미지    
    in_ITEM_1SPEECH      IN  VARCHAR2,     -- 1분스피치
    in_ITEM_3SPEECH      IN  VARCHAR2,     -- 3분스피치
        
    in_ITEM_KIND1        IN  VARCHAR2,     -- 의약품분류1-전문,2-일반    
    in_ITEM_KD_NO        IN  VARCHAR2,     -- KD번호
    in_ITEM_MAIN_SOURCE  IN  VARCHAR2,     -- 주성분
    in_ITEM_MAIN_SOURCE_SIZE  IN  VARCHAR2,     -- 주성분함량    
    in_ITEM_POJANG_UNIT  IN  VARCHAR2,     -- 포장단위
    
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
    v_num                NUMBER;
    
BEGIN
     
    SELECT COUNT(*)
      INTO v_num
      FROM SFA_OFFICE_ITEMDOC
     WHERE ITEM_CODE   = to_char(in_ITEM_CD) ;
         
    out_COUNT := v_num;
    
    IF in_BTN_GUBUN = 1 THEN -- 등록버튼 클릭한 경우
        IF v_num >= 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 있습니다';
            
/*   INSERT INTO SFA_SP_CALLED_HIST 
    VALUES ('SP_SFA_ADMIN_08','1000',sysdate,'in_BTN_GUBUN:'||in_BTN_GUBUN
            ||'/in_ITEM_CD:'||to_char(in_ITEM_CD)     
            ||'/in_ITEM_NM:'||in_ITEM_NM     
            );
    COMMIT;
    */   
    
            RETURN;    
        ELSE 
            
            -- 제품상세설명 등록
            INSERT INTO SFA_OFFICE_ITEMDOC(ITEM_CODE, ITEM_NAME, ITEM_POINT, ITEM_EFFECT, ITEM_USE_DOES, ITEM_ATTENTION, ITEM_PHOTO, ITEM_1SPEECH, ITEM_3SPEECH,ITEM_KIND1,ITEM_KD_NO,ITEM_MAIN_SOURCE,ITEM_MAIN_SOURCE_SIZE,ITEM_POJANG_UNIT) 
                           VALUES(in_ITEM_CD, in_ITEM_NM, in_ITEM_POINT, in_ITEM_EFFECT, in_ITEM_USE_DOES, in_ITEM_ATTENTION, in_ITEM_PHOTO, in_ITEM_1SPEECH, in_ITEM_3SPEECH,in_ITEM_KIND1,in_ITEM_KD_NO,in_ITEM_MAIN_SOURCE,in_ITEM_MAIN_SOURCE_SIZE,in_ITEM_POJANG_UNIT);            
            COMMIT;     
    
            OPEN out_RESULT FOR
            SELECT ITEM_CODE              AS out_ITEM_ID        -- 제품코드
                 , ITEM_NAME              AS out_ITEM_NM        -- 제품명
                 , ITEM_POINT             AS out_ITEM_POINT          -- 특장점
                 , ITEM_EFFECT            AS out_ITEM_EFFECT         -- 효능효과
                 , ITEM_USE_DOES          AS out_ITEM_USE_DOES  -- 용량용법
                 , ITEM_ATTENTION         AS out_ITEM_ATTENTION -- 주의사항
                 , ITEM_PHOTO             AS out_ITEM_PHOTO          -- 이미지
                 , ITEM_1SPEECH           AS out_ITEM_1SPEECH       -- 1분스피치
                 , ITEM_3SPEECH           AS out_ITEM_3SPEECH       --3분스피치
                 , ITEM_KIND1             AS out_ITEM_KIND1       --의약품분류1-전문,2-일반
                 , ITEM_KD_NO             AS out_ITEM_KD_NO       -- KD번호
                 , ITEM_MAIN_SOURCE       AS out_ITEM_MAIN_SOURCE     --주성분
                 , ITEM_MAIN_SOURCE_SIZE  AS out_ITEM_MAIN_SOURCE_SIZE     --주성분함량
                 , ITEM_POJANG_UNIT       AS out_ITEM_POJANG_UNIT     --포장단위
              FROM SFA_OFFICE_ITEMDOC
             WHERE ITEM_CODE   = in_ITEM_CD
             ORDER BY ITEM_NAME;
                 
            out_COUNT := 1;
            out_CODE := 0;
            out_MSG := '등록이 완료되었습니다';
        END IF;
        
    ELSIF in_BTN_GUBUN = 2 THEN -- 수정버튼 클릭한 경우
        IF v_num < 1 THEN            
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            UPDATE SFA_OFFICE_ITEMDOC
               SET ITEM_NAME              = in_ITEM_NM        -- 제품명
                 , ITEM_POINT             = in_ITEM_POINT          -- 특장점
                 , ITEM_EFFECT            = in_ITEM_EFFECT         -- 효능효과
                 , ITEM_USE_DOES          = in_ITEM_USE_DOES  -- 용량용법
                 , ITEM_ATTENTION         = in_ITEM_ATTENTION -- 주의사항
                 , ITEM_PHOTO             = in_ITEM_PHOTO          -- 이미지는 update 별도로..
                 , ITEM_1SPEECH           = in_ITEM_1SPEECH       -- 1분스피치
                 , ITEM_3SPEECH           = in_ITEM_3SPEECH       --3분스피치
                 , ITEM_KIND1             = in_ITEM_KIND1         
                 , ITEM_KD_NO             = in_ITEM_KD_NO      
                 , ITEM_MAIN_SOURCE       = in_ITEM_MAIN_SOURCE    
                 , ITEM_MAIN_SOURCE_SIZE  = in_ITEM_MAIN_SOURCE_SIZE   
                 , ITEM_POJANG_UNIT       = in_ITEM_POJANG_UNIT  
             WHERE ITEM_CODE   = in_ITEM_CD;
              
            COMMIT;

            OPEN out_RESULT FOR
            SELECT ITEM_CODE              AS out_ITEM_ID        -- 제품코드
                 , ITEM_NAME              AS out_ITEM_NM        -- 제품명
                 , ITEM_POINT             AS out_ITEM_POINT          -- 특장점
                 , ITEM_EFFECT            AS out_ITEM_EFFECT         -- 효능효과
                 , ITEM_USE_DOES          AS out_ITEM_USE_DOES  -- 용량용법
                 , ITEM_ATTENTION         AS out_ITEM_ATTENTION -- 주의사항
                 , ITEM_PHOTO             AS out_ITEM_PHOTO          -- 이미지
                 , ITEM_1SPEECH           AS out_ITEM_1SPEECH       -- 1분스피치
                 , ITEM_3SPEECH           AS out_ITEM_3SPEECH       --3분스피치
                 , ITEM_KIND1             AS out_ITEM_KIND1       --의약품분류1-전문,2-일반
                 , ITEM_KD_NO             AS out_ITEM_KD_NO       -- KD번호
                 , ITEM_MAIN_SOURCE       AS out_ITEM_MAIN_SOURCE     --주성분
                 , ITEM_MAIN_SOURCE_SIZE  AS out_ITEM_MAIN_SOURCE_SIZE     --주성분함량
                 , ITEM_POJANG_UNIT       AS out_ITEM_POJANG_UNIT  --포장단위
              FROM SFA_OFFICE_ITEMDOC
             WHERE ITEM_CODE   = in_ITEM_CD
             ORDER BY ITEM_NAME;
             
            out_CODE := 0;
            out_MSG := '수정이 완료되었습니다';
        END IF;
        
    ELSIF in_BTN_GUBUN = 3 THEN  -- 삭제버튼 클릭한 경우
        IF v_num < 1 THEN
            out_CODE := 1;
            out_MSG := '기존 등록된 자료가 없습니다';
        ELSE
            DELETE FROM SFA_OFFICE_ITEMDOC
             WHERE ITEM_CODE   = in_ITEM_CD;
              
            COMMIT;
            
            OPEN out_RESULT FOR
            SELECT ITEM_CODE              AS out_ITEM_ID        -- 제품코드
                 , ITEM_NAME              AS out_ITEM_NM        -- 제품명
                 , ITEM_POINT             AS out_ITEM_POINT          -- 특장점
                 , ITEM_EFFECT            AS out_ITEM_EFFECT         -- 효능효과
                 , ITEM_USE_DOES          AS out_ITEM_USE_DOES  -- 용량용법
                 , ITEM_ATTENTION         AS out_ITEM_ATTENTION -- 주의사항
                 , ITEM_PHOTO             AS out_ITEM_PHOTO          -- 이미지
                 , ITEM_1SPEECH           AS out_ITEM_1SPEECH       -- 1분스피치
                 , ITEM_3SPEECH           AS out_ITEM_3SPEECH       --3분스피치
                 , ITEM_KIND1             AS out_ITEM_KIND1       --의약품분류1-전문,2-일반
                 , ITEM_KD_NO             AS out_ITEM_KD_NO       -- KD번호
                 , ITEM_MAIN_SOURCE       AS out_ITEM_MAIN_SOURCE     --주성분
                 , ITEM_MAIN_SOURCE_SIZE  AS out_ITEM_MAIN_SOURCE_SIZE     --주성분함량
                 , ITEM_POJANG_UNIT       AS out_ITEM_POJANG_UNIT  --포장단위
              FROM SFA_OFFICE_ITEMDOC
             WHERE ITEM_CODE   = in_ITEM_CD
             ORDER BY ITEM_NAME;
             
            out_CODE := 0;
            out_MSG := '삭제가 완료되었습니다';
         END IF;
    ELSE   -- 조회처리
        IF (v_num = 0) THEN
            out_CODE := 1;
            out_MSG := '정보가 존재하지 않습니다.';
        ELSIF (v_num >= 1) THEN
            out_CODE := 0;
            out_MSG := '정보 확인완료';    
             
            OPEN out_RESULT FOR
            SELECT ITEM_CODE              AS out_ITEM_ID        -- 제품코드
                 , ITEM_NAME              AS out_ITEM_NM        -- 제품명
                 , ITEM_POINT             AS out_ITEM_POINT          -- 특장점
                 , ITEM_EFFECT            AS out_ITEM_EFFECT         -- 효능효과
                 , ITEM_USE_DOES          AS out_ITEM_USE_DOES  -- 용량용법
                 , ITEM_ATTENTION         AS out_ITEM_ATTENTION -- 주의사항
                 , ITEM_PHOTO             AS out_ITEM_PHOTO          -- 이미지
                 , ITEM_1SPEECH           AS out_ITEM_1SPEECH       -- 1분스피치
                 , ITEM_3SPEECH           AS out_ITEM_3SPEECH       --3분스피치
                 , ITEM_KIND1             AS out_ITEM_KIND1       --의약품분류1-전문,2-일반
                 , ITEM_KD_NO             AS out_ITEM_KD_NO       -- KD번호
                 , ITEM_MAIN_SOURCE       AS out_ITEM_MAIN_SOURCE     --주성분
                 , ITEM_MAIN_SOURCE_SIZE  AS out_ITEM_MAIN_SOURCE_SIZE     --주성분함량
                 , ITEM_POJANG_UNIT       AS out_ITEM_POJANG_UNIT  --포장단위
              FROM SFA_OFFICE_ITEMDOC
             WHERE ITEM_CODE   = in_ITEM_CD
             ORDER BY ITEM_NAME;
        END IF;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
