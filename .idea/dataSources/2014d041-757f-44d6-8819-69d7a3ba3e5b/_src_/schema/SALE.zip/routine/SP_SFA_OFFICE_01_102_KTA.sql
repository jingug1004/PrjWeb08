CREATE PROCEDURE      SP_SFA_OFFICE_01_102_KTA
(   
    in_SAWON_ID          IN  VARCHAR2, --영업사번
    in_STR_DT            IN  VARCHAR2,
    in_END_DT            IN  VARCHAR2,
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : 공지사항조회 
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    

    v_num                NUMBER; 
    v_sawon_id            VARCHAR2(10); --영업사번
    
BEGIN

    --공지사항은 인사사번기준으로 자료가 들어있다.
    --따라서, 영업사원아이디가 넘어오므로 인사사번으로 변경해야 함. 
    select insa_sawon_id into v_sawon_id from sale0007 where sawon_id = in_SAWON_ID;

    --로그인사번에게 온 공지
    select count(*)
      into v_num
      from hanagw.TGWNT_M a
          ,hanagw.TGWNTTGT b
     where a.ntcno = b.ntcno
       and b.tgt_orguno in (select uno from hanagw.tcmusr where loin_usid = v_sawon_id
                          union
                          select orgno
                            from hanagw.tcmorg
                         connect by  orgno = prior supr_orgno
                           start with orgno = ( select orgno
                                                from hanagw.tcmorg_r
                                               where uno = (select uno from hanagw.tcmusr where loin_usid = v_sawon_id)
                                              )
                         )
       and a.ntc_str_dtm between in_STR_DT and in_END_DT;       
       
       
    out_COUNT := v_num;
    DBMS_OUTPUT.put_line('out_COUNT:'||to_char(out_COUNT));
    
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '공지사항이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '공지사항 정보 확인완료';    
         
        OPEN out_RESULT FOR

            select out_BOARD_ID       -- 공지사항 ID
                  ,ROWNUM as out_BOARD_SEQ      -- 공지 번호(SEQ)
                  ,out_TITLE          -- 공지 제목
                  ,out_DISCRIPTION    -- 공지 내용
                  ,out_START_DATE     -- 공지 시작일
                  ,out_READ_YN  -- 읽었는지여부
              from (
                    select A.NTCNO                               AS out_BOARD_ID 
                          ,A.NTC_TITL                            AS out_TITLE
                          ,FNC_LONG2CHAR(A.NTCNO)                AS out_DISCRIPTION
                          ,SUBSTR(A.NTC_STR_DTM, 1,8)            AS out_START_DATE
                          ,(select decode(min(inq_uno),null,'New','읽음') 
                              from hanagw.TGWNTCFM 
                             where ntcno = a.ntcno and inq_uno = (select uno from hanagw.tcmusr where loin_usid = v_sawon_id)) as out_READ_YN 
                      from hanagw.TGWNT_M a  --공지사항 MASTER
                          ,hanagw.TGWNTTGT b  --공지사항 공지대상
                     where a.ntcno = b.ntcno
                       and b.tgt_orguno in (  select uno from hanagw.tcmusr where loin_usid = v_sawon_id
                                              union
                                              select orgno
                                                from hanagw.tcmorg  --그룹웨어부서정
                                             connect by  orgno = prior supr_orgno
                                               start with orgno = ( select orgno
                                                                    from hanagw.tcmorg_r --그룹웨어유저와부서연결정보
                                                                   where uno = (select uno from hanagw.tcmusr where loin_usid = v_sawon_id) -- 그룹웨어유정보 
                                                                  )
                                             )
                       and a.ntc_str_dtm between in_STR_DT and in_END_DT
                       order by A.NTC_STR_DTM desc
                    )
               order by ROWNUM;
         
    END IF;
         
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
