CREATE PROCEDURE      SP_Z_WIBANORDER_CONF
 (
  in_BTN_GUBUN         IN  NUMBER,       -- 버튼 구분(승인:1,반려:2)
  in_SAWON_ID           IN VARCHAR2 default NULL,
  in_COUNT              IN NUMBER,
  in_DATASET            IN VARCHAR2 default NULL,
  out_CODE              OUT NUMBER,
  out_MSG               OUT VARCHAR2       
  )
IS
 /*---------------------------------------------------------------------------
 프로그램명  :  위반 주문 승인체크한거  업데이트
 호출프로그램 : 일일방문 간납처주문내역 확인 팝업화면에서 체크후 확인버튼시        
 수정기록   :               
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼 
 ---------------------------------------------------------------------------*/
 
    v_gumae_no  VARCHAR2(12); 
    v_item_id   VARCHAR2(10);
    v_qty       NUMBER;
    
    ERROR_RAISE EXCEPTION;
    
BEGIN  

    --insert into SFA_SP_CALLED_HIST values ('SP_SFA_RORDER_CONFIRM','s',sysdate,'in_DATASET:'||in_DATASET||' /in_COUNT:'||to_char(in_COUNT));        

    FOR ll_loop IN 1.. in_COUNT LOOP  

       v_gumae_no  := TRIM(SUBSTR(REPLACE(in_DATASET,'@',' '), 1 + 12*(ll_loop -1),  12));   
       
       IF in_BTN_GUBUN = 1 THEN      -- 팀장승인      
          update oragmp.slordm 
             set wibanconfdtm         = sysdate  
                ,wibanorderconfstatus = '1'  -- 위반오더승인상태      0-대기,1-승인,2-반려 지점장이 처리
                ,statediv             = '01'     --주문상태구분  01-입력 03-채권불량 09-매출확정 99-반려
                ,apprstatus           = '01'     --결재진행상태  00-등록 01-상신 03-승인
                ,updatedt             = sysdate
                ,uempcode             = in_SAWON_ID
           where orderno = v_gumae_no;
           
           insert into SFA_SP_CALLED_HIST values ('SP_SFA_RORDER_CONFIRM','승인사번:'||in_SAWON_ID,sysdate,'v_gumae_no:'||v_gumae_no||' /in_COUNT:'||to_char(in_COUNT));
            
       ELSE                          -- 팀장반려
          update oragmp.slordm  
             set wibanconfdtm         = sysdate 
                ,wibanorderconfstatus = '2'  -- 위반오더승인상태      0-대기,1-승인,2-반려 지점장이 처리
                ,statediv             = '99'     --상태구분  01-입력 03-채권불량 09-매출확정 99-반려
                ,apprstatus           = '00'     --결재진행상태  00-sfa반려  01-등록,02-상신 03-승인, 04-관리부반려  
                ,updatedt             = sysdate
                ,uempcode             = in_SAWON_ID
           where orderno = v_gumae_no; 
 
           insert into SFA_SP_CALLED_HIST values ('SP_SFA_RORDER_CONFIRM','반려사번:'||in_SAWON_ID,sysdate,'v_gumae_no:'||v_gumae_no||' /in_COUNT:'||to_char(in_COUNT));
                    
       END IF;
          

    END LOOP; 
         
    out_CODE  := 0;
    out_MSG   := '저장 완료';              
                  


EXCEPTION
     WHEN ERROR_RAISE THEN 
          ROLLBACK; 

     WHEN OTHERS THEN
          out_CODE := SQLCODE;
          out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM); 

END;
/
