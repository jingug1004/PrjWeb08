CREATE PROCEDURE      SP_SFA_SAWON
(
    in_PART_CD           IN  VARCHAR2,      -- PART 코드
    in_DEPT_CD           IN  VARCHAR2,      -- 부서코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   : PART별 부서별 사원 검색
 호출프로그램 : 실적현황에서 사원조회 SPINNER 선택시
                수금현황 오픈시 사원조회 SPINNER      
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
BEGIN

    --파트코드가 없으면 이로직 필수
    --파트코드가 없는 경우는 수금현황 화면 OPEN시 팀원 spinner조회 때문에 호출되므로  
    --이때 넘어오는 부서코드는 인사부서코드가 아니라 영업부서코드임.
    --따라서 영업부서코드로 사원리스트를 가져와야 함.
    
    IF in_PART_CD IS NULL THEN
        SELECT COUNT(*)
          INTO v_num
          FROM SALE0007 A
         WHERE A.DEPT_CD = in_DEPT_CD;
         
         --insert into SFA_SP_CALLED_HIST values ('SP_SFA_SAWON','1',sysdate,'in_PART_CD:'||in_PART_CD||'in_DEPT_CD:'||in_DEPT_CD );
    ELSE        
    
        SELECT COUNT(*)
          INTO v_num
          FROM SALE0007 A
         WHERE A.DEPT_CD = (SELECT SALE_DEPT_CD FROM HR_CO_DEPART_0  
                             WHERE LEVEL <> 1 
                              AND GUBUN = 'Y' 
                               AND SALE_DEPT_CD IS NOT NULL  AND  DEPT_CD = in_DEPT_CD 
                             CONNECT BY PRIOR DEPT_CD = UP_DEPT_CD START WITH DEPT_CD LIKE NVL(in_PART_CD, '%'));
         --insert into SFA_SP_CALLED_HIST values ('SP_SFA_SAWON','2',sysdate,'in_PART_CD:'||in_PART_CD||'in_DEPT_CD:'||in_DEPT_CD );                    
    END IF;
    
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
    
        IF in_PART_CD IS NULL THEN
             
            OPEN out_RESULT FOR
            SELECT A.SAWON_ID             AS out_SAWON_ID
                 , A.SAWON_NM             AS out_SAWON_NM
              FROM SALE0007 A 
             WHERE A.DEPT_CD = in_DEPT_CD
            ORDER BY out_SAWON_NM;
        ELSE
             
            OPEN out_RESULT FOR
            SELECT A.SAWON_ID             AS out_SAWON_ID
                 , A.SAWON_NM             AS out_SAWON_NM
              FROM SALE0007 A 
             WHERE A.DEPT_CD = (SELECT SALE_DEPT_CD FROM HR_CO_DEPART_0 
                                 WHERE LEVEL <> 1                 
                                   AND GUBUN = 'Y' 
                                   AND SALE_DEPT_CD IS NOT NULL  AND  DEPT_CD = in_DEPT_CD 
                                 CONNECT BY PRIOR DEPT_CD = UP_DEPT_CD START WITH DEPT_CD LIKE NVL(in_PART_CD, '%'))
            ORDER BY out_SAWON_NM;
            
        END IF; 
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;
/
