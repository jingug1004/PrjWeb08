CREATE PROCEDURE      SP_SFA_COMMON_LIST   
(
    in_CODE_GB           IN  VARCHAR2,  -- 그룹코드
    out_CODE             OUT NUMBER,
    out_MSG              OUT VARCHAR2,
    out_COUNT            OUT NUMBER,
    out_RESULT           OUT TYPES.CURSOR_TYPE
)
IS
 /*---------------------------------------------------------------------------
 프로그램명   :공통코드 현황
 호출프로그램 :       
 ---------------------------------------------------------------------------*/    
    v_num                NUMBER;
    
BEGIN 
     
    SELECT SUM(CNT)
      INTO v_num
      FROM (SELECT COUNT(*) AS CNT
              FROM SALE0001
             WHERE CODE_GB LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,3) = 'BRD' THEN 'NO-ENTRY' ELSE NVL(in_CODE_GB,'%') END)
               AND NVL(USE_YN,'Y')  = 'Y'
               AND CODE_GB||CODE1 <> '0007101'  --압인
               AND CODE_GB||CODE1 <> '0007100'  --신용카드
             /*UNION ALL
             SELECT COUNT(*) AS CNT
              FROM SALE0001
             WHERE  CODE_GB||CODE1 LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,3) = 'BRD' THEN 'NO-ENTRY' ELSE NVL(in_CODE_GB,'%') END)
               AND NVL(USE_YN,'Y')  = 'Y'*/
            UNION ALL
            SELECT COUNT(*) AS CNT          
              FROM hanagw.TGWBDRM 
             WHERE BRD_TYPE LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,5) IN ( 'BRD-0', 'BRD-2') THEN NVL(in_CODE_GB,'%') ELSE 'NO' END)
            UNION ALL
            SELECT COUNT(*) AS CNT   
              FROM hanagw.TCMORG 
             WHERE ORGNO IN (SELECT DISTINCT ORGNO FROM hanagw.TCMORG_R)
               AND 'BRD-D'||ORGNO LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,5) = 'BRD-D' THEN NVL(in_CODE_GB,'%')||'%'  ELSE 'NO' END)
            UNION ALL
            SELECT COUNT(*) AS CNT  
              FROM (SELECT GAEJUNG_CD,GAEJUNG_NM,'식당,술집'                              AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%복리후생비%'  UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'주유소,차수리,교통카드충전,하이패스'    AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%차량유지비%'  UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'교통비(버스,기차,비행기),숙박비,주차비' AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%여비교통비%'  UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'가전제품매장,철물점 등'                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%소모품비%'    UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'회의비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%회의비%'      UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'교육훈련비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%교육훈련비%'  UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'도서인쇄비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%도서인쇄비%'  UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'운반비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%운반비%'      UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'철도청,반환수수료'                      AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%지급수수료%'  UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'지급수수료'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%집기비품%'    UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'판매촉진비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%판매촉진비%'  UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'통신비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%통신비%'      UNION ALL
                    SELECT GAEJUNG_CD,GAEJUNG_NM,'광고선전비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%광고선전비%'
                    )                A,            
                    ACCOUNT.FACA03C  B
              WHERE B.GAEJUNG_CD = A.GAEJUNG_CD
                AND B.JUNPYO_YN = 'Y'
                AND B.SAYONG_YN = 'Y'
                AND B.GAEJUNG_CD IN ('81050AA','81110AB','81230AA','81060AA','81170AA','81050AA','81210AA')
             UNION ALL
             SELECT COUNT(*) AS CNT  FROM DUAL   
                        
           );
    
    out_COUNT := v_num;
    IF (v_num = 0) THEN
        out_CODE := 1;
        out_MSG := '검색내용이 없습니다.';
    ELSIF (v_num >= 1) THEN
        out_CODE := 0;
        out_MSG := '검색 확인완료';    
         
        OPEN out_RESULT FOR
        SELECT CODE_GB                      AS out_CODE_GB         -- 그룹코드
             , CODE_GB_NM                   AS out_CODE_GB_NM      -- 그룹코드명
             , CODE1                        AS out_CODE1           -- 항목코드
             , CODE1_NM                     AS out_CODE1_NM        -- 항목코드명
          FROM SALE0001
         WHERE CODE_GB LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,3) = 'BRD' THEN 'NO-ENTRY' ELSE NVL(in_CODE_GB,'%') END)
           AND NVL(USE_YN,'Y')  = 'Y'
             AND CODE_GB||CODE1 <> '0007101'   --압인제외 어음수금항목 
             AND CODE_GB||CODE1 <> '0007100'  --신용카드
        /*UNION ALL
        SELECT CODE_GB                      AS out_CODE_GB         -- 그룹코드
             , CODE_GB_NM                   AS out_CODE_GB_NM      -- 그룹코드명
             , CODE1                        AS out_CODE1           -- 항목코드
             , CODE1_NM                     AS out_CODE1_NM        -- 항목코드명
          FROM SALE0001
         WHERE CODE_GB||CODE1  LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,3) = 'BRD' THEN 'NO-ENTRY' ELSE NVL(in_CODE_GB,'%') END)
           AND NVL(USE_YN,'Y')  = 'Y'   --압인항목      */    
        UNION ALL
        SELECT 'BRD-'||BRD_TYPE             AS out_CODE_GB     -- 카테고리 그룹코드(0:게시판, 2:자료실)
             , DECODE(BRD_TYPE, '0', '게시판', '2', '자료실', '미정의') AS out_CODE_GB_NM
             , TO_CHAR(BRD_NO)              AS out_CODE1      -- 카테고리 코드 NUMBER
             , BRD_NM                       AS out_CODE1_NM     -- 카테고리 명               
          FROM hanagw.TGWBDRM 
         WHERE 'BRD-'||BRD_TYPE LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,5) IN ( 'BRD-0', 'BRD-2') THEN NVL(in_CODE_GB,'%') ELSE 'NO' END)
        UNION ALL
        SELECT 'BRD-D'                      AS out_CODE_GB     -- 그룹코드
             , '그룹웨어 부서'              AS out_CODE_GB_NM  -- 그룹코드명
             , ORGNO                        AS out_CODE1       -- 부서코드 
             , ORG_NM                       AS out_CODE1_NM     -- 부서 명               
          FROM hanagw.TCMORG 
         WHERE ORGNO IN (SELECT DISTINCT ORGNO FROM hanagw.TCMORG_R)
           AND 'BRD-D'||ORGNO LIKE (CASE WHEN in_CODE_GB IS NULL THEN '%' WHEN SUBSTR(in_CODE_GB,1,5) = 'BRD-D' THEN NVL(in_CODE_GB,'%')||'%'  ELSE 'NO' END)
        UNION ALL
        SELECT 'ACNT'                    AS out_CODE_GB     -- 그룹코드(회계 계정)
             , '그룹웨어 회계계정'          AS out_CODE_GB_NM  -- 그룹코드명
             , A.GAEJUNG_CD                 AS out_CODE1       -- 계정과목
             , A.GAEJUNG_NM                 AS out_CODE1_NM    -- 사용과목명
          FROM (SELECT GAEJUNG_CD,GAEJUNG_NM,'식당,술집'                              AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%복리후생비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'주유소,차수리,교통카드충전,하이패스'    AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%차량유지비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'교통비(버스,기차,비행기),숙박비,주차비' AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%여비교통비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'가전제품매장,철물점 등'                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%소모품비%'    UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'회의비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%회의비%'      UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'교육훈련비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%교육훈련비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'도서인쇄비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%도서인쇄비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'운반비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%운반비%'      UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'철도청,반환수수료'                      AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%지급수수료%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'지급수수료'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%집기비품%'    UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'판매촉진비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%판매촉진비%'  UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'통신비'                                 AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%통신비%'      UNION ALL
                SELECT GAEJUNG_CD,GAEJUNG_NM,'광고선전비'                             AS BIGO FROM ACCOUNT.FACA03C WHERE GAEJUNG_NM LIKE '%광고선전비%'
                )                A,            
                ACCOUNT.FACA03C  B
          WHERE B.GAEJUNG_CD = A.GAEJUNG_CD
            AND B.JUNPYO_YN = 'Y'
            AND B.SAYONG_YN = 'Y'
            AND B.GAEJUNG_CD IN ('81050AA','81110AB','81230AA','81060AA','81170AA','81050AA','81210AA')
         UNION ALL
         SELECT 'ACNT','그룹웨어 회계계정','','선택안함' FROM DUAL   
         ORDER BY 1, 3;
    END IF;
    
EXCEPTION
WHEN OTHERS THEN
   out_CODE := SQLCODE;
   out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
END;

/
