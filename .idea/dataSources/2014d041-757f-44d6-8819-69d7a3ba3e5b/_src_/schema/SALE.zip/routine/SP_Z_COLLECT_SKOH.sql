CREATE PROCEDURE      SP_Z_COLLECT_SKOH
   (in_FLAG         IN VARCHAR2 DEFAULT NULL,
    out_CODE        OUT NUMBER,
    out_MSG         OUT VARCHAR2,
    out_COUNT       OUT NUMBER,
    out_RESULT      OUT TYPES.CURSOR_TYPE  
)
AS
 /*---------------------------------------------------------------------------
 프로그램명   : 카드수금 과 수기카드수금 테스트용으로 작성함  
 ---------------------------------------------------------------------------*/    
   
    ERROR_EXCEPTION     EXCEPTION;
    
BEGIN  
    OPEN out_RESULT for 
        SELECT * 
        FROM SFA_SP_CALLED_HIST 
        WHERE sp_nm like 'SP_Z_COLLECT_110_ERROR 1%' and key_col like '20180131%' 
        order by call_dt;
     
EXCEPTION
WHEN ERROR_EXCEPTION THEN
       ROLLBACK; 
   
WHEN OTHERS THEN
       out_CODE := SQLCODE;
       out_MSG  :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM);
       ROLLBACK; 
       
END;
/
