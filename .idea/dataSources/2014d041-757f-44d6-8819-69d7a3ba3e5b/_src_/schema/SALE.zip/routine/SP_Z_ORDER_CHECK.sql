CREATE PROCEDURE      SP_Z_ORDER_CHECK
(
        in_CUST_ID            IN VARCHAR2 default NULL, 
        in_flag      IN  VARCHAR2 DEFAULT NULL,
        in_ymd       IN  date,
        in_GUMAE_NO  IN  VARCHAR2 DEFAULT NULL, 
        in_INPUT_SEQ IN  VARCHAR2 DEFAULT NULL, 
        in_ITEM_ID   IN  VARCHAR2 DEFAULT NULL, 
        in_QTY       IN  VARCHAR2 DEFAULT NULL, 
        in_DANGA     IN  NUMBER   DEFAULT NULL, 
        in_AMT       IN  VARCHAR2 DEFAULT NULL, 
        in_VAT       IN  VARCHAR2 DEFAULT NULL, 
        in_DC_AMT    IN  VARCHAR2 DEFAULT NULL,
        in_DC_QTY    IN  VARCHAR2 DEFAULT NULL, 
        in_DC_DANGA  IN  VARCHAR2 DEFAULT NULL,
        out_CODE     OUT NUMBER,
        out_MSG      OUT VARCHAR2,
        out_COUNT    OUT NUMBER,
        out_RESULT   OUT TYPES.CURSOR_TYPE

  )
IS
/*---------------------------------------------------------------------------
프로그램명  : 주문체크
호출프로그램 : 주문서등록의 수량입력후    
                                   
    2017.11.01 KTA - NEW ERP메 맞게 컨버젼
                   - GMP에서 생성한 펑션을 호？하여 수량체크한다. 
 ---------------------------------------------------------------------------*/ 
        v_ITEM_ID   VARCHAR2(10);
        v_QTY       VARCHAR2(13);
        v_DANGA     VARCHAR2(13);
    
        v_retmsg    VARCHAR2(400);   
        
        --제품체크 
        SLORDITEMCHECK_CURSOR      oragmp.types.DataSet;
        v_piecechk                 VARCHAR2(5); --생산중단제품(단종)   
        v_discontinuechk           VARCHAR2(5); --낱알품목 출하제한

BEGIN     

    --insert into SFA_SP_CALLED_HIST values ('SP_Z_ORDER_CHECK','s',sysdate,'in_CUST_ID:'||in_CUST_ID||' /v_ITEM_ID:'||to_char(v_ITEM_ID));
                            
   IF in_FLAG = 'I' THEN


        --3,4 번대 거래처 체크
        IF NOT(SUBSTR(in_CUST_ID,1,1) = '3' OR SUBSTR(in_CUST_ID,1,1) = '4') THEN
            out_CODE := 101;
            out_MSG := 'SFA에서는 직거래처만 주문할수 있습니다.';
            RETURN;             
        END IF;
            
        v_ITEM_ID  := in_ITEM_ID;
        v_QTY      := in_QTY;
        v_DANGA    := to_char(in_DANGA);
 
   
        --제품체크1 :생산중단품과 낱알품목체크    
        OPEN SLORDITEMCHECK_CURSOR FOR  
        SELECT * FROM TABLE(ORAGMP.fnSLordItemCheckT(v_ITEM_ID));  
        LOOP
          FETCH SLORDITEMCHECK_CURSOR INTO v_piecechk, v_discontinuechk;
          EXIT WHEN SLORDITEMCHECK_CURSOR%NOTFOUND ;  
        END LOOP;
        CLOSE SLORDITEMCHECK_CURSOR;  
                    
        if v_piecechk = '*'          then -- 생산중단제품(단종)
            out_CODE := 3;
            out_MSG := '단종 품목 입니다.';
            RETURN;          
        elsif v_discontinuechk = '*'   then --낱알품목 출하제한
            out_CODE := 3;
            out_MSG := '낱알 품목으로 등록할수 없습니다.';  
            RETURN;          
        end if;                   
   
       --제품체크2 수량체크 ::이 체크로직은 SFA에서는 두곳에서 체크됨 : SP_Z_ORDER_CHECK 와 SP_Z_ORDR_123 
       /* 이렇게 sql에서 펑션을 호출하면 SPDEBUG 테이블에 이력이 안남기때문에 아래 방식으로 변경함 
        SELECT ORAGMP.fnSLordItemCheck('1000', to_char(in_ymd,'YYYY-MM-DD'), in_CUST_ID, in_CUST_ID, v_ITEM_ID, to_number(v_QTY), 0, '20', to_number(v_DANGA)) --10 saleon 20-sfa 30-erp
          INTO v_retmsg
          FROM DUAL;
       */ 
   
        v_retmsg := ORAGMP.fnSLordItemCheck('1000', to_char(in_ymd,'YYYY-MM-DD'), in_CUST_ID, in_CUST_ID, v_ITEM_ID, to_number(v_QTY), 0, '20', to_number(v_DANGA)); --10 saleon 20-sfa 30-erp
        
   --IF SUBSTR(v_retmsg,1,1) <> '0' THEN      
   --insert into SFA_SP_CALLED_HIST values ('SP_Z_ORDER_CHECK','11',sysdate,'in_CUST_ID:'||in_CUST_ID||   ' /v_ITEM_ID:'||v_ITEM_ID||' /in_ymd:'||to_char(in_ymd,'YYYY-MM-DD')||'  '||v_retmsg);  
   -- END IF;   
    
                     
        IF SUBSTR(v_retmsg,1,1) = '0' THEN                       
            out_CODE := 1;          -- 정상  --체크통과처리함
            out_MSG := '정상';        -- 주문가능
        ELSIF SUBSTR(v_retmsg,1,2) = '20' THEN --20 로 리턴은 수량통제 위반 이므로  수량위반주문 되어야 함 
            out_CODE := 2;          -- 수량위반  
            out_MSG := v_retmsg ||' - 주문은 가능합니다'    ; -- 주문가능
            RETURN;          
        ELSIF SUBSTR(v_retmsg,1,2) <> '11' THEN --0 도 아니고 11 도 아니면 주문불가   
            out_CODE := 3;          -- 0이면 out_MSG 가 client에 넘어가지 않음.
            out_MSG := v_retmsg   ; -- 주문불가 
            RETURN;          
        ELSE    
            out_CODE := 4;          -- 0이면 out_MSG 가 client에 넘어가지 않음.
            out_MSG := v_retmsg   ; -- 주문불가 
            RETURN;    
        END IF;                            
   
   
    END IF; 
      
 
EXCEPTION  
        WHEN OTHERS THEN
             out_CODE := SQLCODE;
             out_MSG :=(TO_CHAR(SQLCODE) ||'-'|| SQLERRM || out_MSG);      
END;
/
